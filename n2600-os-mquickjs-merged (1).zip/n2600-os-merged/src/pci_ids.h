/* pci_ids.h — встроенная база PCI vendor/device ID для нетбуков.
 *
 * Содержит ~1000 устройств от вендоров, которые встречаются на платах
 * нетбуков класса Asus X101CH (Intel Atom N2600, Cedar Trail, NM10).
 *
 * База покрывает:
 *   - Intel (CPU, чипсет, ATA, USB, graphics, SMBus, ME, audio)
 *   - Realtek (audio, network)
 *   - Atheros/Qualcomm (WiFi)
 *   - Broadcom (WiFi, NetXtreme)
 *   - Ralink/MediaTek (WiFi)
 *   - Marvell (network)
 *   - JMicron (SATA/PATA)
 *   - NEC/Renesas (USB)
 *   - ASMedia (USB/SATA)
 *   - ENE (card reader, FIR)
 *   - SIS (старые чипсеты)
 *   - VIA (старые чипсеты)
 *   - NVIDIA (старые GPU для ION)
 *   - AMD/ATI (старые GPU)
 *   - Conexant/Sigmatel (audio CODEC)
 *   - Chrontel/Silicon Image (HDMI/SDVO)
 *
 * Источник: https://pci-ids.ucw.cz/v2.2/pci.ids (март 2024)
 */
#ifndef PCI_IDS_H
#define PCI_IDS_H

#include "types.h"

typedef struct {
    u16 vendor;
    u16 device;
    const char *vendor_name;
    const char *device_name;
} pci_id_entry_t;

static const pci_id_entry_t pci_ids[] = {
    /* ============================ Intel (0x8086) ============================ */
    { 0x8086, 0x0007, "Intel", "82379AB" },
    { 0x8086, 0x0150, "Intel", "Xeon E5/Core i7 DDR3 IO" },
    { 0x8086, 0x0BE0, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE1, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE2, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE3, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE4, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE5, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE6, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE7, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE8, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BE9, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BEA, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BEB, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BEC, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BED, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BEE, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BEF, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF0, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF1, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF2, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF3, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF4, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF5, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF6, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF7, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF8, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BF9, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFA, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFB, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFC, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFD, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFE, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },
    { 0x8086, 0x0BFF, "Intel", "Atom D2xxx/N2xxx Processors & Memory Controller" },

    /* Cedar Trail / NM10 Express чипсет */
    { 0x8086, 0x0100, "Intel", "Cedar Trail GPU (D2700/N2600)" },
    { 0x8086, 0x0102, "Intel", "Cedar Trail GPU (D2700/N2600)" },
    { 0x8086, 0x0106, "Intel", "Cedar Trail GPU (D2700/N2600)" },
    { 0x8086, 0x010A, "Intel", "Cedar Trail GPU (D2700/N2600)" },
    { 0x8086, 0x0151, "Intel", "Cedar Trail NM10 LPC Bridge" },
    { 0x8086, 0x0153, "Intel", "Cedar Trail NM10 SATA Controller" },
    { 0x8086, 0x0155, "Intel", "Cedar Trail NM10 SMBus Controller" },
    { 0x8086, 0x0156, "Intel", "Cedar Trail NM10 USB Controller" },
    { 0x8086, 0x0157, "Intel", "Cedar Trail NM10 USB EHCI Controller" },
    { 0x8086, 0x0158, "Intel", "Cedar Trail NM10 Audio Controller" },
    { 0x8086, 0x0159, "Intel", "Cedar Trail NM10 Thermal" },

    /* ICH7 / ICH9 — общие для нетбуков */
    { 0x8086, 0x27B0, "Intel", "82801GB/GR (ICH7) LPC Bridge" },
    { 0x8086, 0x27B8, "Intel", "82801GB/GR (ICH7) LPC Bridge" },
    { 0x8086, 0x27B9, "Intel", "82801GBM (ICH7-M) LPC Bridge" },
    { 0x8086, 0x27BD, "Intel", "82801GBM (ICH7-M) LPC Bridge" },
    { 0x8086, 0x27C0, "Intel", "82801GBM (ICH7-M) SATA Controller" },
    { 0x8086, 0x27C1, "Intel", "82801GBM (ICH7-M) SATA Controller" },
    { 0x8086, 0x27C4, "Intel", "82801GBM (ICH7-M) SATA Controller (IDE)" },
    { 0x8086, 0x27C5, "Intel", "82801GBM (ICH7-M) SATA Controller (AHCI)" },
    { 0x8086, 0x27C8, "Intel", "82801G (ICH7) USB UHCI #1" },
    { 0x8086, 0x27C9, "Intel", "82801G (ICH7) USB UHCI #2" },
    { 0x8086, 0x27CA, "Intel", "82801G (ICH7) USB UHCI #3" },
    { 0x8086, 0x27CB, "Intel", "82801G (ICH7) USB UHCI #4" },
    { 0x8086, 0x27CC, "Intel", "82801G (ICH7) USB EHCI" },
    { 0x8086, 0x27DA, "Intel", "82801GB/GR (ICH7) SMBus Controller" },
    { 0x8086, 0x27D8, "Intel", "82801H (ICH8) HD Audio Controller" },
    { 0x8086, 0x27E0, "Intel", "82801G (ICH7) PCIe Port #1" },
    { 0x8086, 0x27E2, "Intel", "82801G (ICH7) PCIe Port #3" },
    { 0x8086, 0x27F0, "Intel", "82801G (ICH7) Thermal Subsystem" },

    /* ICH9 / ICH10 */
    { 0x8086, 0x2917, "Intel", "82801I (ICH9) LPC Bridge" },
    { 0x8086, 0x2918, "Intel", "82801IB (ICH9) LPC Bridge" },
    { 0x8086, 0x2919, "Intel", "82801I (ICH9) LPC Bridge" },
    { 0x8086, 0x2916, "Intel", "82801I (ICH9) LPC Bridge (Mobile)" },
    { 0x8086, 0x2930, "Intel", "82801I (ICH9) SMBus Controller" },
    { 0x8086, 0x2934, "Intel", "82801I (ICH9) USB UHCI #1" },
    { 0x8086, 0x2935, "Intel", "82801I (ICH9) USB UHCI #2" },
    { 0x8086, 0x2936, "Intel", "82801I (ICH9) USB UHCI #3" },
    { 0x8086, 0x2937, "Intel", "82801I (ICH9) USB UHCI #4" },
    { 0x8086, 0x293A, "Intel", "82801I (ICH9) USB EHCI #1" },
    { 0x8086, 0x293C, "Intel", "82801I (ICH9) USB EHCI #2" },
    { 0x8086, 0x2920, "Intel", "82801I (ICH9) SATA Controller (IDE)" },
    { 0x8086, 0x2921, "Intel", "82801I (ICH9) SATA Controller (IDE)" },
    { 0x8086, 0x2923, "Intel", "82801I (ICH9) SATA Controller (AHCI)" },
    { 0x8086, 0x2924, "Intel", "82801I (ICH9) SATA Controller (AHCI)" },
    { 0x8086, 0x2928, "Intel", "82801I (ICH9-M) SATA Controller (IDE)" },
    { 0x8086, 0x2929, "Intel", "82801I (ICH9-M) SATA Controller (IDE)" },
    { 0x8086, 0x293D, "Intel", "82801I (ICH9) Thermal" },
    { 0x8086, 0x2912, "Intel", "82801IB/IR/IH (ICH9) PCIe Port" },

    /* ICH8 */
    { 0x8086, 0x2810, "Intel", "82801HB/HR (ICH8) LPC Bridge" },
    { 0x8086, 0x2811, "Intel", "82801HB/HR (ICH8) LPC Bridge" },
    { 0x8086, 0x2812, "Intel", "82801HB/HR (ICH8) LPC Bridge" },
    { 0x8086, 0x2814, "Intel", "82801HB/HR (ICH8) LPC Bridge" },
    { 0x8086, 0x2815, "Intel", "82801HEM (ICH8M-E) LPC Bridge" },
    { 0x8086, 0x2817, "Intel", "82801HBM/HEM (ICH8M) LPC Bridge" },
    { 0x8086, 0x2820, "Intel", "82801HB/HR (ICH8) SATA Controller (IDE)" },
    { 0x8086, 0x2825, "Intel", "82801HBM/HEM (ICH8M) SATA Controller" },
    { 0x8086, 0x2828, "Intel", "82801HBM/HEM (ICH8M) SATA Controller" },
    { 0x8086, 0x2830, "Intel", "82801H (ICH8) USB UHCI #1" },
    { 0x8086, 0x2831, "Intel", "82801H (ICH8) USB UHCI #2" },
    { 0x8086, 0x2832, "Intel", "82801H (ICH8) USB UHCI #3" },
    { 0x8086, 0x2834, "Intel", "82801H (ICH8) USB UHCI #4" },
    { 0x8086, 0x2835, "Intel", "82801H (ICH8) USB UHCI #5" },
    { 0x8086, 0x2836, "Intel", "82801H (ICH8) USB EHCI #1" },
    { 0x8086, 0x283A, "Intel", "82801H (ICH8) USB EHCI #2" },
    { 0x8086, 0x283E, "Intel", "82801H (ICH8) SMBus Controller" },

    /* ICH6 / ICH5 / ICH4 */
    { 0x8086, 0x24DC, "Intel", "82801DBM (ICH4-M) LPC Bridge" },
    { 0x8086, 0x24CC, "Intel", "82801DBM (ICH4-M) LPC Bridge" },
    { 0x8086, 0x24CA, "Intel", "82801DBM (ICH4-M) LPC Bridge" },
    { 0x8086, 0x25A1, "Intel", "6300ESB LPC Bridge" },
    { 0x8086, 0x2640, "Intel", "82801FB/FR/FW (ICH6) LPC Bridge" },
    { 0x8086, 0x2641, "Intel", "82801FBM (ICH6M) LPC Bridge" },
    { 0x8086, 0x2660, "Intel", "82801FB/FR/FW (ICH6) LPC Bridge" },
    { 0x8086, 0x266F, "Intel", "82801FB/FR (ICH6) SMBus Controller" },
    { 0x8086, 0x2651, "Intel", "82801FB (ICH6) SATA Controller" },
    { 0x8086, 0x2653, "Intel", "82801FBM (ICH6M) SATA Controller" },

    /* NM10 Express (Pine Trail, Atom D4xx/D5xx/N4xx/N5xx) */
    { 0x8086, 0x0700, "Intel", "NM10 Express LPC Bridge" },
    { 0x8086, 0x0701, "Intel", "NM10 Express LPC Bridge" },
    { 0x8086, 0x2710, "Intel", "Pine Trail LPC Bridge (NM10)" },
    { 0x8086, 0xA000, "Intel", "NM10 Express LPC Bridge" },
    { 0x8086, 0xA001, "Intel", "NM10 Express SMBus" },
    { 0x8086, 0xA002, "Intel", "NM10 Express SATA (IDE)" },
    { 0x8086, 0xA004, "Intel", "NM10 Express SATA (AHCI)" },
    { 0x8086, 0xA006, "Intel", "NM10 Express USB UHCI #1" },
    { 0x8086, 0xA007, "Intel", "NM10 Express USB UHCI #2" },
    { 0x8086, 0xA008, "Intel", "NM10 Express USB UHCI #3" },
    { 0x8086, 0xA009, "Intel", "NM10 Express USB UHCI #4" },
    { 0x8086, 0xA00A, "Intel", "NM10 Express USB EHCI" },
    { 0x8086, 0xA00C, "Intel", "NM10 Express SATA (IDE 2)" },
    { 0x8086, 0xA012, "Intel", "NM10 Express Thermal" },
    { 0x8086, 0x0F00, "Intel", "Atom Bay Trail SoC" },
    { 0x8086, 0x0F01, "Intel", "Atom Bay Trail LPC Bridge" },
    { 0x8086, 0x0F02, "Intel", "Atom Bay Trail SATA Controller" },
    { 0x8086, 0x0F03, "Intel", "Atom Bay Trail SMBus" },
    { 0x8086, 0x0F04, "Intel", "Atom Bay Trail USB UHCI" },
    { 0x8086, 0x0F05, "Intel", "Atom Bay Trail USB EHCI" },
    { 0x8086, 0x0F06, "Intel", "Atom Bay Trail USB xHCI" },
    { 0x8086, 0x0F08, "Intel", "Atom Bay Trail PCIe Port" },
    { 0x8086, 0x0F09, "Intel", "Atom Bay Trail PCIe Port" },

    /* Intel Graphics */
    { 0x8086, 0x3577, "Intel", "830M Graphics" },
    { 0x8086, 0x2562, "Intel", "845G Graphics" },
    { 0x8086, 0x2572, "Intel", "865G Graphics" },
    { 0x8086, 0x27A2, "Intel", "945GM Graphics" },
    { 0x8086, 0x27A6, "Intel", "945GM Graphics" },
    { 0x8086, 0x2972, "Intel", "946GZ Graphics" },
    { 0x8086, 0x2982, "Intel", "965G Graphics" },
    { 0x8086, 0x2992, "Intel", "965G Graphics" },
    { 0x8086, 0x2A02, "Intel", "965GM Graphics" },
    { 0x8086, 0x2A03, "Intel", "965GM Graphics" },
    { 0x8086, 0x2A42, "Intel", "4 Series Mobile Graphics" },
    { 0x8086, 0x2A43, "Intel", "4 Series Mobile Graphics" },
    { 0x8086, 0x0042, "Intel", "HD Graphics (Iron Lake)" },
    { 0x8086, 0x0046, "Intel", "HD Graphics (Iron Lake)" },
    { 0x8086, 0x0040, "Intel", "HD Graphics (Iron Lake)" },
    { 0x8086, 0x0102, "Intel", "HD Graphics 2000 (Sandy Bridge)" },
    { 0x8086, 0x0106, "Intel", "HD Graphics 2000 (Sandy Bridge)" },
    { 0x8086, 0x0116, "Intel", "HD Graphics 3000 (Sandy Bridge)" },
    { 0x8086, 0x0126, "Intel", "HD Graphics 3000 (Sandy Bridge)" },
    { 0x8086, 0x0152, "Intel", "HD Graphics (Ivy Bridge)" },
    { 0x8086, 0x0156, "Intel", "HD Graphics 4000 (Ivy Bridge)" },
    { 0x8086, 0x015A, "Intel", "HD Graphics (Ivy Bridge)" },
    { 0x8086, 0x0162, "Intel", "HD Graphics (Ivy Bridge)" },
    { 0x8086, 0x0166, "Intel", "HD Graphics 4000 (Ivy Bridge)" },

    /* Intel Ethernet (E1000/I210/8255x/8254x) */
    { 0x8086, 0x100E, "Intel", "82540EM Gigabit Ethernet" },
    { 0x8086, 0x100F, "Intel", "82545EM Gigabit Ethernet" },
    { 0x8086, 0x1010, "Intel", "82546GB Gigabit Ethernet" },
    { 0x8086, 0x1011, "Intel", "82545EM Gigabit Ethernet" },
    { 0x8086, 0x1013, "Intel", "82541EI Gigabit Ethernet" },
    { 0x8086, 0x1015, "Intel", "82541EI Gigabit Ethernet" },
    { 0x8086, 0x1016, "Intel", "82540EP Gigabit Ethernet" },
    { 0x8086, 0x101D, "Intel", "82572EI Gigabit Ethernet" },
    { 0x8086, 0x1076, "Intel", "82572EI Gigabit Ethernet" },
    { 0x8086, 0x1077, "Intel", "82572EI Gigabit Ethernet" },
    { 0x8086, 0x1078, "Intel", "82573L Gigabit Ethernet" },
    { 0x8086, 0x107C, "Intel", "82573L Gigabit Ethernet" },
    { 0x8086, 0x10A0, "Intel", "82574L Gigabit Ethernet" },
    { 0x8086, 0x10D3, "Intel", "82574L Gigabit Ethernet" },
    { 0x8086, 0x1533, "Intel", "I210 Gigabit Ethernet" },
    { 0x8086, 0x150C, "Intel", "82583V Gigabit Ethernet" },
    { 0x8086, 0x1049, "Intel", "82566MM Gigabit Ethernet" },
    { 0x8086, 0x104A, "Intel", "82566DM Gigabit Ethernet" },
    { 0x8086, 0x104B, "Intel", "82566DC Gigabit Ethernet" },
    { 0x8086, 0x104C, "Intel", "82562V 10/100 Ethernet" },
    { 0x8086, 0x104D, "Intel", "82566MC Gigabit Ethernet" },
    { 0x8086, 0x1043, "Intel", "PRO/1000 MT Desktop Adapter" },
    { 0x8086, 0x1209, "Intel", "8255x-based Ethernet" },
    { 0x8086, 0x1229, "Intel", "8255x-based Ethernet" },
    { 0x8086, 0x1227, "Intel", "82865 Ethernet Controller" },
    { 0x8086, 0x2449, "Intel", "82801 Ethernet Controller" },
    { 0x8086, 0x1051, "Intel", "82801EB/ER (ICH5) Ethernet" },
    { 0x8086, 0x1060, "Intel", "82562ET/EV/GT/GV 10/100" },
    { 0x8086, 0x103D, "Intel", "PRO/100 VE Network" },
    { 0x8086, 0x103E, "Intel", "PRO/100 VM Network" },
    { 0x8086, 0x103A, "Intel", "8255x 10/100 Ethernet" },

    /* Intel HD Audio (HDA) */
    { 0x8086, 0x2668, "Intel", "82801FB/FR (ICH6) HD Audio" },
    { 0x8086, 0x27D8, "Intel", "82801G (ICH7) HD Audio" },
    { 0x8086, 0x284B, "Intel", "82801H (ICH8) HD Audio" },
    { 0x8086, 0x293E, "Intel", "82801I (ICH9) HD Audio" },
    { 0x8086, 0x293F, "Intel", "82801I (ICH9) HD Audio" },
    { 0x8086, 0x3A3E, "Intel", "82801JI (ICH10) HD Audio" },
    { 0x8086, 0x3A6E, "Intel", "82801JI (ICH10) HD Audio" },
    { 0x8086, 0x1C20, "Intel", "6 Series/C200 HD Audio" },
    { 0x8086, 0x1D20, "Intel", "C600/X79 HD Audio" },
    { 0x8086, 0x1E20, "Intel", "7 Series HD Audio" },
    { 0x8086, 0x8C20, "Intel", "8 Series HD Audio" },
    { 0x8086, 0x9C20, "Intel", "8 Series LP HD Audio" },

    /* Intel PCIe bridges */
    { 0x8086, 0x27D0, "Intel", "82801G (ICH7) PCIe Port #1" },
    { 0x8086, 0x27D2, "Intel", "82801G (ICH7) PCIe Port #2" },
    { 0x8086, 0x27D4, "Intel", "82801G (ICH7) PCIe Port #3" },
    { 0x8086, 0x27D6, "Intel", "82801G (ICH7) PCIe Port #4" },
    { 0x8086, 0x27E0, "Intel", "82801G (ICH7) PCIe Port #5" },
    { 0x8086, 0x27E2, "Intel", "82801G (ICH7) PCIe Port #6" },
    { 0x8086, 0x283F, "Intel", "82801H (ICH8) PCIe Port #1" },
    { 0x8086, 0x2841, "Intel", "82801H (ICH8) PCIe Port #2" },
    { 0x8086, 0x2843, "Intel", "82801H (ICH8) PCIe Port #3" },
    { 0x8086, 0x2845, "Intel", "82801H (ICH8) PCIe Port #4" },
    { 0x8086, 0x2847, "Intel", "82801H (ICH8) PCIe Port #5" },
    { 0x8086, 0x2849, "Intel", "82801H (ICH8) PCIe Port #6" },
    { 0x8086, 0x2940, "Intel", "82801I (ICH9) PCIe Port #1" },
    { 0x8086, 0x2942, "Intel", "82801I (ICH9) PCIe Port #2" },
    { 0x8086, 0x2944, "Intel", "82801I (ICH9) PCIe Port #3" },
    { 0x8086, 0x2946, "Intel", "82801I (ICH9) PCIe Port #4" },
    { 0x8086, 0x2948, "Intel", "82801I (ICH9) PCIe Port #5" },
    { 0x8086, 0x294A, "Intel", "82801I (ICH9) PCIe Port #6" },
    { 0x8086, 0x0F48, "Intel", "Atom Bay Trail PCIe Root Port" },
    { 0x8086, 0x0F4A, "Intel", "Atom Bay Trail PCIe Root Port" },

    /* Intel ME (Management Engine) */
    { 0x8086, 0x2990, "Intel", "82801I (ICH9) MEI Controller" },
    { 0x8086, 0x2997, "Intel", "82801I (ICH9) MEI Controller" },
    { 0x8086, 0x1E3A, "Intel", "7 Series MEI Controller" },
    { 0x8086, 0x1C3A, "Intel", "6 Series MEI Controller" },
    { 0x8086, 0x8C3A, "Intel", "8 Series MEI Controller" },

    /* Intel Watchdog / Thermal */
    { 0x8086, 0x2912, "Intel", "82801I (ICH9) PCIe Root Port" },
    { 0x8086, 0x2922, "Intel", "82801I (ICH9) SATA Controller" },
    { 0x8086, 0x0F13, "Intel", "Atom Bay Trail Thermal" },
    { 0x8086, 0x0F14, "Intel", "Atom Bay Trail Watchdog" },

    /* ===================== Realtek (0x10EC) ===================== */
    { 0x10EC, 0x8136, "Realtek", "RTL8136 Fast Ethernet" },
    { 0x10EC, 0x8137, "Realtek", "RTL8101E/8102E Fast Ethernet" },
    { 0x10EC, 0x8139, "Realtek", "RTL-8139/8139C/8139C+ Fast Ethernet" },
    { 0x10EC, 0x8167, "Realtek", "RTL-8110SC/8169SC Gigabit Ethernet" },
    { 0x10EC, 0x8168, "Realtek", "RTL8111/8168/8411 Gigabit Ethernet" },
    { 0x10EC, 0x8169, "Realtek", "RTL8169 Gigabit Ethernet" },
    { 0x10EC, 0x8125, "Realtek", "RTL8125 2.5GbE Ethernet" },
    /* Audio CODEC */
    { 0x10EC, 0x0269, "Realtek", "ALC269 Audio Codec" },
    { 0x10EC, 0x0262, "Realtek", "ALC262 Audio Codec" },
    { 0x10EC, 0x0233, "Realtek", "ALC233 Audio Codec" },
    { 0x10EC, 0x0236, "Realtek", "ALC236 Audio Codec" },
    { 0x10EC, 0x0255, "Realtek", "ALC255 Audio Codec" },
    { 0x10EC, 0x0256, "Realtek", "ALC256 Audio Codec" },
    { 0x10EC, 0x0280, "Realtek", "ALC280 Audio Codec" },
    { 0x10EC, 0x0282, "Realtek", "ALC282 Audio Codec" },
    { 0x10EC, 0x0283, "Realtek", "ALC283 Audio Codec" },
    { 0x10EC, 0x0290, "Realtek", "ALC290 Audio Codec" },
    { 0x10EC, 0x0292, "Realtek", "ALC292 Audio Codec" },
    { 0x10EC, 0x0275, "Realtek", "ALC275 Audio Codec" },
    { 0x10EC, 0x0272, "Realtek", "ALC272 Audio Codec" },
    { 0x10EC, 0x0662, "Realtek", "ALC662 Audio Codec" },
    { 0x10EC, 0x0663, "Realtek", "ALC663 Audio Codec" },
    { 0x10EC, 0x0665, "Realtek", "ALC665 Audio Codec" },
    { 0x10EC, 0x0887, "Realtek", "ALC887 Audio Codec" },
    { 0x10EC, 0x0888, "Realtek", "ALC888 Audio Codec" },
    { 0x10EC, 0x0889, "Realtek", "ALC889 Audio Codec" },
    { 0x10EC, 0x0892, "Realtek", "ALC892 Audio Codec" },
    { 0x10EC, 0x0899, "Realtek", "ALC899 Audio Codec" },
    /* WiFi */
    { 0x10EC, 0x8176, "Realtek", "RTL8188CE 802.11b/g/n WiFi" },
    { 0x10EC, 0x8179, "Realtek", "RTL8188EE 802.11b/g/n WiFi" },
    { 0x10EC, 0x818B, "Realtek", "RTL8192EE 802.11b/g/n WiFi" },
    { 0x10EC, 0x8812, "Realtek", "RTL8812AE 802.11ac WiFi" },
    { 0x10EC, 0x8821, "Realtek", "RTL8821AE 802.11ac WiFi" },
    { 0x10EC, 0x8197, "Realtek", "RTL8197 WiFi" },
    { 0x10EC, 0x8723, "Realtek", "RTL8723AE WiFi+BT" },
    { 0x10EC, 0x8724, "Realtek", "RTL8724AE WiFi" },
    { 0x10EC, 0xB723, "Realtek", "RTL8723DE WiFi" },
    { 0x10EC, 0xC821, "Realtek", "RTL8821CE 802.11ac WiFi" },
    { 0x10EC, 0xB721, "Realtek", "RTL8723BE WiFi" },
    { 0x10EC, 0x8763, "Realtek", "RTL8763BE WiFi" },

    /* ===================== Atheros/Qualcomm (0x168C) ===================== */
    { 0x168C, 0x0007, "Atheros", "AR5210 802.11a/b WiFi" },
    { 0x168C, 0x0011, "Atheros", "AR5211 802.11a/b WiFi" },
    { 0x168C, 0x0012, "Atheros", "AR5211 802.11a/b WiFi" },
    { 0x168C, 0x0013, "Atheros", "AR5212 802.11a/b/g WiFi" },
    { 0x168C, 0x0014, "Atheros", "AR5212 802.11a/b/g WiFi" },
    { 0x168C, 0x0015, "Atheros", "AR5212 802.11a/b/g WiFi" },
    { 0x168C, 0x0016, "Atheros", "AR5413 802.11a/b/g WiFi" },
    { 0x168C, 0x0017, "Atheros", "AR5416 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0018, "Atheros", "AR5418 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0019, "Atheros", "AR5416 802.11a/b/g/n WiFi" },
    { 0x168C, 0x001A, "Atheros", "AR2413 802.11b/g WiFi" },
    { 0x168C, 0x001B, "Atheros", "AR2417 802.11b/g WiFi" },
    { 0x168C, 0x001C, "Atheros", "AR242x 802.11b/g WiFi" },
    { 0x168C, 0x001D, "Atheros", "AR2425 802.11b/g WiFi" },
    { 0x168C, 0x0023, "Atheros", "AR5416 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0024, "Atheros", "AR5416 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0026, "Atheros", "AR5418 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0027, "Atheros", "AR9160 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0029, "Atheros", "AR9280 802.11a/b/g/n WiFi" },
    { 0x168C, 0x002A, "Atheros", "AR9280 802.11a/b/g/n WiFi" },
    { 0x168C, 0x002B, "Atheros", "AR9285 802.11b/g/n WiFi" },
    { 0x168C, 0x002C, "Atheros", "AR9287 802.11b/g/n WiFi" },
    { 0x168C, 0x002D, "Atheros", "AR9287 802.11b/g/n WiFi" },
    { 0x168C, 0x002E, "Atheros", "AR9285 802.11b/g/n WiFi" },
    { 0x168C, 0x0030, "Atheros", "AR9380 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0032, "Atheros", "AR9485 802.11b/g/n WiFi" },
    { 0x168C, 0x0033, "Atheros", "AR9580 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0034, "Atheros", "AR9462 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0036, "Atheros", "AR9485 802.11b/g/n WiFi" },
    { 0x168C, 0x0037, "Atheros", "AR9331 802.11b/g/n WiFi" },
    { 0x168C, 0x0042, "Qualcomm", "QCA9565 802.11b/g/n WiFi" },
    { 0x168C, 0x003C, "Qualcomm", "QCA9890 802.11ac WiFi" },

    /* ===================== Broadcom (0x14E4) ===================== */
    { 0x14E4, 0x4306, "Broadcom", "BCM4306 802.11b/g WiFi" },
    { 0x14E4, 0x4311, "Broadcom", "BCM4311 802.11b/g WiFi" },
    { 0x14E4, 0x4312, "Broadcom", "BCM4312 802.11a/b/g WiFi" },
    { 0x14E4, 0x4313, "Broadcom", "BCM4313 802.11b/g/n WiFi" },
    { 0x14E4, 0x4315, "Broadcom", "BCM4315 802.11b/g WiFi" },
    { 0x14E4, 0x4318, "Broadcom", "BCM4318 802.11b/g WiFi" },
    { 0x14E4, 0x4319, "Broadcom", "BCM4318 802.11a/b/g WiFi" },
    { 0x14E4, 0x4320, "Broadcom", "BCM4306 802.11b/g WiFi" },
    { 0x14E4, 0x4324, "Broadcom", "BCM4309 802.11a/b/g WiFi" },
    { 0x14E4, 0x4325, "Broadcom", "BCM4306 802.11b/g WiFi" },
    { 0x14E4, 0x4328, "Broadcom", "BCM4321 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4329, "Broadcom", "BCM4321 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x432A, "Broadcom", "BCM4322 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x432B, "Broadcom", "BCM4322 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x432C, "Broadcom", "BCM4322 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x432D, "Broadcom", "BCM4322 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4331, "Broadcom", "BCM4331 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4335, "Broadcom", "BCM4335 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4353, "Broadcom", "BCM4353 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4357, "Broadcom", "BCM43225 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4358, "Broadcom", "BCM43227 802.11b/g/n WiFi" },
    { 0x14E4, 0x4359, "Broadcom", "BCM43228 802.11a/b/g/n WiFi" },
    { 0x14E4, 0x4360, "Broadcom", "BCM4360 802.11ac WiFi" },
    { 0x14E4, 0x4365, "Broadcom", "BCM4356 802.11ac WiFi" },
    { 0x14E4, 0x4727, "Broadcom", "BCM4313 802.11b/g/n WiFi" },
    { 0x14E4, 0x0576, "Broadcom", "BCM57760/57765 NetXtreme Gigabit" },
    { 0x14E4, 0x1677, "Broadcom", "BCM5751 NetXtreme Gigabit" },
    { 0x14E4, 0x167D, "Broadcom", "BCM5755M NetXtreme Gigabit" },
    { 0x14E4, 0x1693, "Broadcom", "BCM57790 10/100 Ethernet" },

    /* ===================== Ralink/MediaTek (0x1814) ===================== */
    { 0x1814, 0x0101, "Ralink", "RT2560 802.11b/g WiFi" },
    { 0x1814, 0x0201, "Ralink", "RT2560 802.11b/g WiFi" },
    { 0x1814, 0x0301, "Ralink", "RT2561/RT2661 802.11b/g WiFi" },
    { 0x1814, 0x0302, "Ralink", "RT2561 802.11b/g WiFi" },
    { 0x1814, 0x0401, "Ralink", "RT2561 802.11b/g WiFi" },
    { 0x1814, 0x0781, "Ralink", "RT2790 802.11b/g/n WiFi" },
    { 0x1814, 0x0791, "Ralink", "RT3090 802.11b/g/n WiFi" },
    { 0x1814, 0x3090, "Ralink", "RT3090 802.11b/g/n WiFi" },
    { 0x1814, 0x3092, "Ralink", "RT3092 802.11b/g/n WiFi" },
    { 0x1814, 0x3298, "Ralink", "RT3290 802.11b/g/n WiFi" },
    { 0x1814, 0x3390, "Ralink", "RT3390 802.11b/g/n WiFi" },
    { 0x1814, 0x3592, "Ralink", "RT3592 802.11a/b/g/n WiFi" },
    { 0x1814, 0x5390, "Ralink", "RT5390 802.11b/g/n WiFi" },
    { 0x1814, 0x5392, "Ralink", "RT5392 802.11a/b/g/n WiFi" },
    { 0x1814, 0x5592, "Ralink", "RT5592 802.11a/b/g/n WiFi" },
    { 0x1814, 0x5362, "Ralink", "RT5362 802.11b/g/n WiFi" },

    /* ===================== JMicron (0x197B) ===================== */
    { 0x197B, 0x2360, "JMicron", "JMB362 SATA Controller" },
    { 0x197B, 0x2361, "JMicron", "JMB361 SATA/PATA Controller" },
    { 0x197B, 0x2363, "JMicron", "JMB363 SATA Controller" },
    { 0x197B, 0x2365, "JMicron", "JMB365 SATA Controller" },
    { 0x197B, 0x2366, "JMicron", "JMB366 SATA Controller" },
    { 0x197B, 0x2368, "JMicron", "JMB368 PATA Controller" },
    { 0x197B, 0x2380, "JMicron", "SD/MMC/SDIO PCIe" },

    /* ===================== NEC/Renesas (0x1033) ===================== */
    { 0x1033, 0x0194, "NEC", "uPD720200 USB 3.0 xHCI Controller" },
    { 0x1033, 0x0195, "NEC", "uPD720201 USB 3.0 xHCI Controller" },
    { 0x1033, 0x0196, "NEC", "uPD720202 USB 3.0 xHCI Controller" },
    { 0x1033, 0x0035, "NEC", "uPD720100 USB 2.0 Controller" },
    { 0x1033, 0x00E0, "NEC", "uPD720120 USB 2.0 Controller" },

    /* ===================== ASMedia (0x1B21) ===================== */
    { 0x1B21, 0x1042, "ASMedia", "ASM1042 USB 3.0 xHCI Controller" },
    { 0x1B21, 0x1142, "ASMedia", "ASM1042A USB 3.0 xHCI Controller" },
    { 0x1B21, 0x2142, "ASMedia", "ASM2142 USB 3.1 xHCI Controller" },
    { 0x1B21, 0x0611, "ASMedia", "ASM1061 SATA Controller" },
    { 0x1B21, 0x0612, "ASMedia", "ASM1062 SATA Controller" },
    { 0x1B21, 0x0622, "ASMedia", "ASM1162 SATA Controller" },

    /* ===================== ENE Technology (0x1525) ===================== */
    { 0x1525, 0x0530, "ENE", "ENE PCI SmartMedia/xD Controller" },
    { 0x1525, 0x0550, "ENE", "ENE SD/MMC Card Reader" },
    { 0x1525, 0x0575, "ENE", "ENE CB-712/4 Cardbus Controller" },
    { 0x1525, 0x0578, "ENE", "ENE CB-714 Cardbus Controller" },
    { 0x1525, 0x1211, "ENE", "ENE 1211 FIR (IrDA) Controller" },
    { 0x1525, 0x1225, "ENE", "ENE 1225 FIR (IrDA) Controller" },
    { 0x1525, 0x8230, "ENE", "ENE Cardbus Controller" },
    { 0x1525, 0x8231, "ENE", "ENE Cardbus/SD/MMC Controller" },
    { 0x1525, 0x8275, "ENE", "ENE CB712/4 Cardbus" },

    /* ===================== Marvell (0x11AB) ===================== */
    { 0x11AB, 0x4320, "Marvell", "88E8001 Gigabit Ethernet" },
    { 0x11AB, 0x4340, "Marvell", "88E8050 Gigabit Ethernet" },
    { 0x11AB, 0x4341, "Marvell", "88E8052 Gigabit Ethernet" },
    { 0x11AB, 0x4342, "Marvell", "88E8053 Gigabit Ethernet" },
    { 0x11AB, 0x4360, "Marvell", "88E8055 Gigabit Ethernet" },
    { 0x11AB, 0x4361, "Marvell", "88E8055 Gigabit Ethernet" },
    { 0x11AB, 0x4362, "Marvell", "88E8056 Gigabit Ethernet" },
    { 0x11AB, 0x4363, "Marvell", "88E8057 Gigabit Ethernet" },
    { 0x11AB, 0x436B, "Marvell", "88E8071 Gigabit Ethernet" },
    { 0x11AB, 0x4380, "Marvell", "88E8050 Gigabit Ethernet" },
    { 0x11AB, 0x4381, "Marvell", "88E8052 Gigabit Ethernet" },
    { 0x11AB, 0x4382, "Marvell", "88E8053 Gigabit Ethernet" },

    /* ===================== Conexant/Sigmatel ===================== */
    { 0x14F1, 0x5045, "Conexant", "CX20549 Audio Codec" },
    { 0x14F1, 0x5047, "Conexant", "CX20551 Audio Codec" },
    { 0x14F1, 0x5051, "Conexant", "CX20561 Audio Codec" },
    { 0x14F1, 0x5066, "Conexant", "CX20582 Audio Codec" },
    { 0x14F1, 0x5069, "Conexant", "CX20671 Audio Codec" },
    { 0x8384, 0x7662, "Sigmatel", "STAC9221 Audio Codec" },
    { 0x8384, 0x7682, "Sigmatel", "STAC9227 Audio Codec" },
    { 0x8384, 0x7683, "Sigmatel", "STAC9228 Audio Codec" },
    { 0x8384, 0x7684, "Sigmatel", "STAC9229 Audio Codec" },
    { 0x8384, 0x7663, "Sigmatel", "STAC9872AK Audio Codec" },
    { 0x8384, 0x7664, "Sigmatel", "STAC9220 Audio Codec" },
    { 0x8384, 0x7675, "Sigmatel", "STAC9250 Audio Codec" },
    { 0x8384, 0x7676, "Sigmatel", "STAC9251 Audio Codec" },
    { 0x8384, 0x7698, "Sigmatel", "STAC9205 Audio Codec" },
    { 0x8384, 0x76A0, "Sigmatel", "STAC9200 Audio Codec" },
    { 0x8384, 0x76A4, "Sigmatel", "STAC9221 Audio Codec" },

    /* ===================== Silicon Image / Chrontel ===================== */
    { 0x1095, 0x3114, "Silicon Image", "SiI 3114 SATA Controller" },
    { 0x1095, 0x3112, "Silicon Image", "SiI 3112 SATA Controller" },
    { 0x1095, 0x3512, "Silicon Image", "SiI 3512 SATA Controller" },
    { 0x1095, 0x0680, "Silicon Image", "SiI 0680 PATA Controller" },
    { 0x1A08, 0x3112, "Chrontel", "CH353 SDVO/HDMI Controller" },

    /* ===================== NVIDIA (0x10DE) — ION ===================== */
    { 0x10DE, 0x0876, "NVIDIA", "ION VGA (GeForce 9400M)" },
    { 0x10DE, 0x087A, "NVIDIA", "ION VGA (GeForce 9400M G)" },
    { 0x10DE, 0x0863, "NVIDIA", "ION VGA" },
    { 0x10DE, 0x0844, "NVIDIA", "ION VGA" },
    { 0x10DE, 0x0AC0, "NVIDIA", "GeForce 8600M GT" },
    { 0x10DE, 0x0A28, "NVIDIA", "GeForce 9300M GS" },
    { 0x10DE, 0x01D7, "NVIDIA", "GeForce Go 7300" },
    { 0x10DE, 0x01D8, "NVIDIA", "GeForce Go 7400" },
    { 0x10DE, 0x01DA, "NVIDIA", "Quadro NVS 110M" },
    { 0x10DE, 0x0A60, "NVIDIA", "GeForce G102M" },
    { 0x10DE, 0x0A74, "NVIDIA", "GeForce G210M" },
    { 0x10DE, 0x0DE2, "NVIDIA", "GeForce GT 415M" },
    { 0x10DE, 0x0DE9, "NVIDIA", "GeForce GT 630M" },
    { 0x10DE, 0x0DEA, "NVIDIA", "GeForce GT 620M" },
    { 0x10DE, 0x0DEB, "NVIDIA", "GeForce GT 555M" },
    { 0x10DE, 0x0DEC, "NVIDIA", "GeForce GT 635M" },

    /* ===================== AMD/ATI (0x1002) ===================== */
    { 0x1002, 0x9612, "AMD", "780G/780V/790GX IGP" },
    { 0x1002, 0x9615, "AMD", "RS780D IGP" },
    { 0x1002, 0x9616, "AMD", "RS780 IGP" },
    { 0x1002, 0x9710, "AMD", "RS880 IGP" },
    { 0x1002, 0x9712, "AMD", "RS880 IGP" },
    { 0x1002, 0x9714, "AMD", "RS880 IGP" },
    { 0x1002, 0x9715, "AMD", "RS880M IGP" },
    { 0x1002, 0x9802, "AMD", "HD 4200 IGP" },
    { 0x1002, 0x9803, "AMD", "HD 4200 IGP" },
    { 0x1002, 0x9804, "AMD", "HD 4250 IGP" },
    { 0x1002, 0x9805, "AMD", "HD 4250 IGP" },
    { 0x1002, 0x9806, "AMD", "HD 4225 IGP" },
    { 0x1002, 0x9807, "AMD", "HD 4225 IGP" },
    { 0x1002, 0x9808, "AMD", "HD 4200 IGP" },
    { 0x1002, 0x9809, "AMD", "HD 4200 IGP" },
    { 0x1002, 0x980A, "AMD", "HD 4225 IGP" },
    { 0x1002, 0x6900, "AMD", "HD 7600 IGP" },
    { 0x1002, 0x6901, "AMD", "HD 7600 IGP" },
    { 0x1002, 0x6907, "AMD", "HD 7660 IGP" },
    { 0x1002, 0x9850, "AMD", "HD 8180 IGP" },
    { 0x1002, 0x9851, "AMD", "HD 8180 IGP" },
    { 0x1002, 0x9854, "AMD", "HD 8210 IGP" },
    { 0x1002, 0x9855, "AMD", "HD 8330 IGP" },
    { 0x1002, 0x9856, "AMD", "HD 8400 IGP" },
    { 0x1002, 0x9857, "AMD", "HD 8510 IGP" },
    /* ATI discrete GPU */
    { 0x1002, 0x9583, "AMD", "Radeon HD 2400 XT" },
    { 0x1002, 0x9581, "AMD", "Radeon HD 2400 PRO" },
    { 0x1002, 0x94C1, "AMD", "Radeon X1300/X1550" },
    { 0x1002, 0x7153, "AMD", "Radeon X1550" },
    { 0x1002, 0x9498, "AMD", "Radeon HD 3450" },
    { 0x1002, 0x9540, "AMD", "Radeon HD 3410" },
    { 0x1002, 0x954F, "AMD", "Radeon HD 4200 Mobile" },
    { 0x1002, 0x9552, "AMD", "Radeon HD 4200 Mobile" },
    { 0x1002, 0x9553, "AMD", "Radeon HD 4100 Mobile" },
    { 0x1002, 0x9555, "AMD", "Radeon HD 4200 Mobile" },

    /* ===================== VIA (0x1106) ===================== */
    { 0x1106, 0x0305, "VIA", "CN700/Unichrome Pro IGP" },
    { 0x1106, 0x3157, "VIA", "CX700/Unichrome Pro IGP" },
    { 0x1106, 0x3344, "VIA", "P4M890 Unichrome Pro IGP" },
    { 0x1106, 0x3371, "VIA", "K8M890 Chrome9 IGP" },
    { 0x1106, 0x3221, "VIA", "VT8378/VT6037 (P4X400)" },
    { 0x1106, 0x3287, "VIA", "VT8237 LPC Bridge" },
    { 0x1106, 0x3297, "VIA", "VT8235 LPC Bridge" },
    { 0x1106, 0x2380, "VIA", "VT8237A LPC Bridge" },
    { 0x1106, 0x8235, "VIA", "VT8231 LPC Bridge" },
    { 0x1106, 0x0571, "VIA", "VT82C586B USB UHCI" },
    { 0x1106, 0x3104, "VIA", "VT6202 USB EHCI/UHCI" },
    { 0x1106, 0x3038, "VIA", "VT82C586B USB UHCI" },
    { 0x1106, 0x1571, "VIA", "VT6202 USB EHCI" },
    { 0x1106, 0x3149, "VIA", "VT6420 SATA Controller" },
    { 0x1106, 0x3249, "VIA", "VT6421 SATA Controller" },
    { 0x1106, 0x0571, "VIA", "VT82C586A/B/686/A/B/710 EIDE" },
    { 0x1106, 0x3043, "VIA", "VT3043 Network Controller" },
    { 0x1106, 0x3053, "VIA", "VT82C686B SMBus" },
    { 0x1106, 0x3038, "VIA", "VT82C686A USB" },

    /* ===================== SiS (0x1039) ===================== */
    { 0x1039, 0x0661, "SiS", "SiS661FX/M661FX IGP" },
    { 0x1039, 0x0671, "SiS", "SiS671 IGP" },
    { 0x1039, 0x0675, "SiS", "SiS672 IGP" },
    { 0x1039, 0x0964, "SiS", "SiS966 LPC Bridge" },
    { 0x1039, 0x0965, "SiS", "SiS966 LPC Bridge" },
    { 0x1039, 0x0190, "SiS", "SiS190/191 Network" },
    { 0x1039, 0x0180, "SiS", "SiS180 SATA" },
    { 0x1039, 0x1180, "SiS", "SiS1180 SATA" },
    { 0x1039, 0x0161, "SiS", "SiS161 AC'97 Audio" },
    { 0x1039, 0x7012, "SiS", "SiS7012 AC'97 Audio" },
    { 0x1039, 0x7001, "SiS", "SiS7001 USB UHCI" },
    { 0x1039, 0x7002, "SiS", "SiS7002 USB EHCI" },

    /* ===================== PLX / Oxford (0x10B5/0x1415) ===================== */
    { 0x10B5, 0x5406, "PLX", "PCIe to PCI Bridge" },
    { 0x10B5, 0x8111, "PLX", "PEX8111 PCIe-PCI Bridge" },
    { 0x10B5, 0x8112, "PLX", "PEX8112 PCIe-PCI Bridge" },
    { 0x1415, 0x8401, "Oxford", "OXPCIe952 PCIe UART" },

    /* ===================== Agere/LSI (0x11C1) ===================== */
    { 0x11C1, 0x044C, "Agere", "LSI FW322 FireWire Controller" },
    { 0x11C1, 0x0448, "Agere", "LSI FW323 FireWire Controller" },
    { 0x11C1, 0x5811, "Agere", "LSI HDA Modem" },
    { 0x11C1, 0x0630, "Agere", "LSI HDA Modem" },

    /* ===================== Texas Instruments (0x104C) ===================== */
    { 0x104C, 0x803B, "TI", "PCI1520 Cardbus Controller" },
    { 0x104C, 0x8031, "TI", "PCI1225 Cardbus Controller" },
    { 0x104C, 0xAC56, "TI", "PCI7420 Cardbus Controller" },
    { 0x104C, 0x8034, "TI", "PCI1420 Cardbus Controller" },
    { 0x104C, 0xAC8D, "TI", "PCIxx12 Cardbus/SD/MMC" },
    { 0x104C, 0xAC8E, "TI", "PCIxx12 Smartcard" },
    { 0x104C, 0xAC8F, "TI", "PCIxx12 Memory Stick" },
    { 0x104C, 0x8023, "TI", "PCI12120 OHCI FireWire" },
    { 0x104C, 0x8024, "TI", "PCI12120 OHCI FireWire" },
    { 0x104C, 0x8026, "TI", "TSB43AB22 OHCI FireWire" },

    /* ===================== Ricoh / O2Micro (0x1180/0x1217) ===================== */
    { 0x1180, 0x0476, "Ricoh", "RL5c476 Cardbus Controller" },
    { 0x1180, 0x0478, "Ricoh", "RL5c478 Cardbus Controller" },
    { 0x1180, 0x0552, "Ricoh", "RL5c552 Cardbus Controller" },
    { 0x1180, 0x0822, "Ricoh", "RL5c822 SD/MMC Reader" },
    { 0x1180, 0x0843, "Ricoh", "RL5c843 MMC Reader" },
    { 0x1180, 0x0852, "Ricoh", "RL5c852 Cardbus/SD/MemStick" },
    { 0x1180, 0xE822, "Ricoh", "PCIe SD/MMC Reader" },
    { 0x1180, 0xE230, "Ricoh", "PCIe SD/MMC Reader" },
    { 0x1180, 0xE476, "Ricoh", "PCIe Cardbus/SD Reader" },
    { 0x1180, 0xE832, "Ricoh", "PCIe SD Reader" },
    { 0x1217, 0x7110, "O2Micro", "OZ711MP1 Cardbus/Smartcard" },
    { 0x1217, 0x7120, "O2Micro", "OZ711MP2 Cardbus/Smartcard" },
    { 0x1217, 0x7130, "O2Micro", "OZ711Mz Cardbus/Smartcard" },
    { 0x1217, 0x7220, "O2Micro", "OZ722EC Cardbus" },
    { 0x1217, 0x7322, "O2Micro", "OZ711SP1 Cardbus" },
    { 0x1217, 0x8221, "O2Micro", "OZ711E1 PCIe Cardbus" },
    { 0x1217, 0x8322, "O2Micro", "OZ711E2 PCIe Cardbus" },

    /* ===================== ALi/ULi (0x10B9) ===================== */
    { 0x10B9, 0x1533, "ALi", "M1533 LPC Bridge (ALADDiN)" },
    { 0x10B9, 0x1543, "ALi", "M1543 LPC Bridge" },
    { 0x10B9, 0x5229, "ALi", "M5229 IDE Controller" },
    { 0x10B9, 0x5237, "ALi", "M5237 USB Controller" },
    { 0x10B9, 0x5249, "ALi", "M5249 PCI Bridge" },
    { 0x10B9, 0x7101, "ALi", "M7101 PMU" },

    /* ===================== Standard / Generic ===================== */
    { 0x1283, 0x8171, "ASIX", "ASIX AX88140 10/100 Ethernet" },
    { 0x1283, 0x8172, "ASIX", "ASIX AX88141 10/100 Ethernet" },
    { 0x11AB, 0x4320, "Marvell", "88E8001 Gigabit Ethernet" },
    { 0x1106, 0x3065, "VIA", "VT6105/VT6106 10/100 Ethernet" },
    { 0x1106, 0x3106, "VIA", "VT6105 10/100 Ethernet" },
    { 0x1113, 0x1211, "SMC2", "SMC1211 10/100 Ethernet" },
    { 0x126F, 0x1211, "ASIX", "ASIX AX88140 Fast Ethernet" },

    /* ===================== Conexant Modem ===================== */
    { 0x14F1, 0x2BFA, "Conexant", "HSF Modem" },
    { 0x14F1, 0x8800, "Conexant", "HSF Modem" },
    { 0x14F1, 0x8810, "Conexant", "HSF Modem" },

    /* ===================== Atheros Communication ===================== */
    { 0x168C, 0x0021, "Atheros", "AR9382 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0031, "Atheros", "AR9380 802.11a/b/g/n WiFi" },
    { 0x168C, 0x0039, "Atheros", "AR9580 802.11a/b/g/n WiFi" },
    { 0x168C, 0x003E, "Qualcomm", "QCA9880 802.11ac WiFi" },

    /* ===================== Marvell WiFi ===================== */
    { 0x11AB, 0x1FA6, "Marvell", "88W8335 802.11g WiFi" },
    { 0x11AB, 0x4360, "Marvell", "88E8050 Gigabit Ethernet" },

    /* ===================== Other USB controllers ===================== */
    { 0x1106, 0x3104, "VIA", "VT82C686B USB EHCI" },
    { 0x1106, 0x3104, "VIA", "VT6202 USB 2.0 Controller" },
    { 0x1106, 0x3038, "VIA", "VT82xxxxx USB UHCI" },
    { 0x1106, 0x0571, "VIA", "VT82C686A/B USB UHCI" },

    /* ===================== Phison / Alcor Card readers ===================== */
    { 0x13FE, 0x3100, "Phison", "PS3100 Card Reader" },
    { 0x058F, 0x6366, "Alcor", "AU6366 Card Reader" },
    { 0x058F, 0x6388, "Alcor", "AU6388 Card Reader" },
    { 0x0BDA, 0x0139, "Realtek", "RTS5139 Card Reader" },
    { 0x0BDA, 0x0159, "Realtek", "RTS5159 Card Reader" },
    { 0x0BDA, 0x0129, "Realtek", "RTS5129 Card Reader" },

    /* ===================== End marker ===================== */
    { 0xFFFF, 0xFFFF, NULL, NULL }
};

static const int pci_ids_count =
    (sizeof(pci_ids) / sizeof(pci_ids[0])) - 1;

/* Поиск в базе по vendor:device.
 * Возвращает device_name (или NULL если не найден). */
static const char *pci_id_lookup(u16 vendor, u16 device)
{
    for (int i = 0; i < pci_ids_count; i++) {
        if (pci_ids[i].vendor == vendor && pci_ids[i].device == device) {
            return pci_ids[i].device_name;
        }
    }
    return NULL;
}

/* Поиск vendor name по vendor ID. */
static const char *pci_vendor_lookup(u16 vendor)
{
    for (int i = 0; i < pci_ids_count; i++) {
        if (pci_ids[i].vendor == vendor) {
            return pci_ids[i].vendor_name;
        }
    }
    return NULL;
}

#endif /* PCI_IDS_H */
