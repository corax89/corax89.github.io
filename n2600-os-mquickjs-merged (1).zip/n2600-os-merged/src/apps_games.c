/* apps_games.c — «Игры»: окно-лаунчер со значками игр N2600-OS.
 *
 * Заменяет «Пример приложения» (apps_example.c, сессия 19): в меню
 * «Пуск» вместо шаблона — набор значков, каждый открывает свою игру.
 * Первая игра — «Сапёр» (GUI-порт minesweeper.c от vietanhdev, см.
 * apps_mines.c / msweeper.h).
 *
 * ДОБАВИТЬ ИГРУ: допишите запись в games_table[] (имя, функция
 * открытия, значок 16x16 строками 'X'/'o'/'.') — окно само раскладает
 * значки сеткой. Значок: 'X' — основной цвет, 'o' — блик, '.' —
 * прозрачный пиксель; рисуется 3x (48x48 px на плитке 84x84).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "string.h"
#include "mem.h"
#include "mouse.h"

/* значок мины 16x16 ('X' — корпус, 'o' — блик) */
static const char *icon_mine16[16] = {
    "................",
    ".......XX.......",
    "......XXXX......",
    "..X...XXXX...X..",
    "...X.XXXXXX.X...",
    "....XXXXXXXX....",
    "...XXXXXXXXXX...",
    "..XXXXXXXXXXXX..",
    "..XXoXXXXXXXXX..",
    "..XXXXXXXXXXXX..",
    "...XXXXXXXXXX...",
    "....XXXXXXXX....",
    "...X.XXXXXX.X...",
    "..X...XXXX...X..",
    "......XXXX......",
    ".......XX.......",
};

/* значок шашки 16x16: «монета» с кольцом и меткой дамки ('X' — корпус,
 * 'o' — блик/кольцо) */
static const char *icon_checkers16[16] = {
    "................",
    "................",
    ".....XXXXXX.....",
    "....XXXXXXXX....",
    "...XXXXXXXXXX...",
    "..XXooooooooXX..",
    "..XoXXXXXXXXoX..",
    "..XoXXooooXXoX..",
    "..XoXXooooXXoX..",
    "..XoXXXXXXXXoX..",
    "..XXooooooooXX..",
    "...XXXXXXXXXX...",
    "....XXXXXXXX....",
    ".....XXXXXX.....",
    "................",
    "................",
};

/* каталог игр: имя, функция открытия, значок */
typedef struct {
    const char        *name;
    void            (*open_fn)(void);
    const char *const *icon;      /* 16 строк по 16 символов */
} game_def_t;

static const game_def_t games_table[] = {
    { "Сапёр", app_mines_open, icon_mine16 },
    { "Шашки", app_checkers_open, icon_checkers16 },
};
#define GAMES_N ((int)(sizeof(games_table) / sizeof(games_table[0])))

/* ------------------ геометрия плитки ------------------ */
#define TILE_W   84
#define TILE_H   100
#define TILE_PAD 14            /* отступ сетки от краёв окна */
#define TILE_GAP 16            /* зазор между плитками */
#define COLS_MAX 3

#define ICON_BODY  fb_rgb(0x14, 0x18, 0x1E)   /* корпус значка (мина) */

typedef struct {
    int hover;                 /* плитка под курсором или -1 */
} games_t;

static void tile_rect(int i, int *x, int *y)
{
    int col = i % COLS_MAX, row = i / COLS_MAX;
    *x = TILE_PAD + col * (TILE_W + TILE_GAP);
    *y = 34 + row * (TILE_H + TILE_GAP);
}

static int tile_at(int mx, int my)
{
    for (int i = 0; i < GAMES_N; i++) {
        int x, y;
        tile_rect(i, &x, &y);
        if (mx >= x && mx < x + TILE_W && my >= y && my < y + TILE_H)
            return i;
    }
    return -1;
}

/* ------------------ отрисовка ------------------ */

static void draw_icon(const char *const *icon, int x, int y, u32 body)
{
    u32 glare = fb_rgb(0xC8, 0xD2, 0xDC);
    for (int r = 0; r < 16; r++) {
        const char *row = icon[r];
        for (int c = 0; c < 16; c++) {
            if (row[c] == 'X')
                fb_fill_rect(x + c * 3, y + r * 3, 3, 3, body);
            else if (row[c] == 'o')
                fb_fill_rect(x + c * 3, y + r * 3, 3, 3, glare);
        }
    }
}

static void games_draw(window_t *w)
{
    games_t *d = (games_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    fb_text(TILE_PAD, 10, "Игры N2600-OS", wm_theme_text_info(), -1);

    for (int i = 0; i < GAMES_N; i++) {
        int x, y;
        tile_rect(i, &x, &y);
        u32 frame = (i == d->hover) ? wm_theme_accent() : wm_theme_border();
        fb_fill_rect(x, y, TILE_W, TILE_H, wm_theme_win_bg_alt());
        fb_rect(x, y, TILE_W, TILE_H, frame);
        /* «внутренняя» плитка под значок — как закрытая клетка сапёра */
        fb_fill_rect(x + 18, y + 10, 48, 48, fb_rgb(0x39, 0x43, 0x4F));
        draw_icon(games_table[i].icon, x + 18, y + 10, ICON_BODY);
        /* сессия 20: центровка по СИМВОЛАМ (strlen кириллицы вдвое шире
         * отрисованного текста), длинные имена обрезаются */
        wm_text_fit(x, y + 66, games_table[i].name, TILE_W, wm_theme_text(), 1);
    }

    fb_text(TILE_PAD, ch - 18, "Клик по значку — играть",
            wm_theme_text_dim(), -1);
}

/* ------------------ ввод ------------------ */

static void games_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    games_t *d = (games_t *)w->data;

    /* подсветка плитки под курсором (перерисовка только при смене) */
    int hov = (mx >= 0 && my >= 0) ? tile_at(mx, my) : -1;
    if (hov != d->hover) {
        d->hover = hov;
        win_invalidate(w);
    }

    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return;
    int i = tile_at(mx, my);
    if (i >= 0 && games_table[i].open_fn)
        apps_launch(games_table[i].open_fn);   /* сессия 22: контроль запуска */
}

static void games_key(window_t *w, const key_event_t *ev)
{
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) win_close(w);
}

static void games_close(window_t *w)
{
    free(w->data);
}

void app_games_open(void)
{
    games_t *d = (games_t *)malloc(sizeof(games_t));
    if (!d) return;
    d->hover = -1;

    int cols = GAMES_N < COLS_MAX ? (GAMES_N < 1 ? 1 : GAMES_N) : COLS_MAX;
    int rows = (GAMES_N + COLS_MAX - 1) / COLS_MAX;
    int ww = TILE_PAD * 2 + cols * TILE_W + (cols - 1) * TILE_GAP;
    int wh = 34 + rows * TILE_H + 30;
    if (ww < 220) ww = 220;

    u32 W = fb_width(), H = fb_height();
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    window_t *w = win_create("Игры", (int)W / 2 - ww / 2, 40, ww, wh,
                             games_draw, games_key, games_mouse,
                             NULL, games_close, d);
    if (!w) free(d);
}
