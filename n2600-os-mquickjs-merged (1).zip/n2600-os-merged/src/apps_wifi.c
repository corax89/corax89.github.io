/* apps_wifi.c — графическая утилита сканирования WiFi точек доступа.
 * Сессия 11: + кнопка [Connect], состояние подключения в шапке,
 * автосохранение профиля (WIFI.CFG). Сессия 12: + WPA2-PSK ввод пароля.
 * Сессия 28: ПОЛНОЦЕННАЯ МЫШЬ (клик по строке — выбор, повторный клик —
 * подключение, ПКМ — контекстное меню, колесо — прокрутка, кнопки
 * «Подключиться»/«Отмена» в панели пароля); пароль показывается
 * ОТКРЫТО (без звёздочек, запрос пользователя) с мигающим курсором;
 * текст статуса больше не наезжает на кнопки (x после кнопок +
 * обрезка по ширине wm_text_fit); после ввода пароля список сетей
 * больше не выглядит «перезапущенным» (wifi_core хранит список между
 * сканами) и статус подключения показывается явно.
 *
 * Данные: wifi_core.c (Atheros AR9285/9287/9485, RTL8192EU).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "wifi_core.h"
#include "timer.h"
#include "task.h"
#include "kernel.h"     /* wifi_pending() — фоновая init */

#define WIFI_ROWS   10
#define WIFI_COLS   76
#define WIFI_HDR    22
#define WIFI_BTN_W  80
#define WIFI_BTN_H  18
#define WIFI_LOG_H  8      /* строк журнала на панели */
#define WIFI_COLHDR 18     /* высота шапки колонок */
#define WIFI_ROW_H  18

/* X статусного текста: ПРАВЕЕ двух кнопок (4 + 80 + 4 + 80 + 8) —
 * раньше fb_text(100, ...) рисовал поверх кнопки [Connect] */
#define WIFI_STATUS_X  (4 + 2 * (WIFI_BTN_W + 4) + 8)

typedef struct {
    wifi_ap_t aps[WIFI_MAX_APS];
    int  ap_count;
    int  sel;
    int  scroll;
    int  scanning;
    int  scan_progress;    /* индекс канала 0..13 */
    int  btn_hot;
    int  btn_pressed;
    int  hot_row;          /* строка под курсором (-1 = нет) */
    wifi_stats_t stats;
    char logbuf[2048];
    /* ввод пароля WPA2 для выбранной сети */
    int  pw_mode;          /* 1 = ждём пароль */
    int  pw_btn;           /* горячая кнопка панели: 0=Подключиться 1=Отмена */
    int  pw_pressed;
    char pw_ssid[33];      /* к какой сети подключаемся */
    char psw[65];          /* введённый пароль */
} wifi_mgr_t;

static void wifi_start_scan(wifi_mgr_t *m) {
    if (m->scanning) return;
    if (!wifi_present()) return;
    if (!wifi_ready()) return;
    m->scanning = 1;
    m->scan_progress = 0;
    wifi_scan_start();
}

static void wifi_draw_btn(int idx, const char *label, int hot, int pressed) {
    int bx = 4 + idx * (WIFI_BTN_W + 4);
    int by = 2;
    u32 bg = pressed ? fb_rgb(0x4A, 0x7F, 0xB0) :
             hot ? fb_rgb(0x32, 0x60, 0x8E) :
             fb_rgb(0x25, 0x4A, 0x70);
    wm_button_draw(bx, by, WIFI_BTN_W, WIFI_BTN_H, label,
                   bg, wm_theme_text(), wm_theme_accent());
}

static const char *security_str(u8 sec) {
    switch (sec) {
    case WIFI_SEC_OPEN:     return "Open";
    case WIFI_SEC_WPA2_PSK: return "WPA2";
    case WIFI_SEC_WPA_PSK:  return "WPA";
    default:                return "WEP/other";
    }
}

static void wifi_draw_bars(int x, int y, i8 rssi) {
    int bars = 0;
    if (rssi > -50) bars = 5;
    else if (rssi > -60) bars = 4;
    else if (rssi > -70) bars = 3;
    else if (rssi > -80) bars = 2;
    else bars = 1;
    u32 colors[] = { fb_rgb(0xFF, 0x60, 0x60), fb_rgb(0xFF, 0xA0, 0x60),
                    fb_rgb(0xFF, 0xE0, 0x60), fb_rgb(0x90, 0xEE, 0x90),
                    fb_rgb(0x60, 0xE0, 0x60) };
    for (int i = 0; i < 5; i++) {
        int h = 4 + i * 3;
        u32 c = (i < bars) ? colors[i] : fb_rgb(0x30, 0x30, 0x30);
        fb_fill_rect(x + i * 5, y + (15 - h), 4, h, c);
    }
}

/* геометрия списка (общая для draw/mouse) */
static void wifi_list_rect(window_t *w, int *area_y0, int *area_h, int *vis) {
    int ch = win_content_h(w);
    int log_h = WIFI_LOG_H * 11 + 16;
    int y0 = WIFI_HDR + WIFI_COLHDR;
    int h = ch - y0 - log_h - 14;
    if (h < 36) h = 36;
    int v = h / WIFI_ROW_H;
    if (v < 1) v = 1;
    *area_y0 = y0; *area_h = h; *vis = v;
}

static void wifi_draw(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка: кнопки + статус ПРАВЕЕ кнопок (не наезжает) */
    fb_fill_rect(0, 0, cw, WIFI_HDR, wm_theme_title());
    wifi_draw_btn(0, "Scan", m->btn_hot == 0, m->btn_pressed == 0);
    wifi_draw_btn(1, "Connect", m->btn_hot == 1, m->btn_pressed == 1);

    const char *chip = wifi_present() ? wifi_chip_name() :
                       (wifi_pending() ? "Инициализация адаптера..." :
                                         "Нет WiFi-адаптера");
    wm_text_fit(WIFI_STATUS_X, 2, chip, cw - WIFI_STATUS_X - 6,
                wm_theme_text(), 0);

    /* Состояние подключения */
    if (wifi_present()) {
        char cs[96];
        if (wifi_conn_ssid()[0])
            snprintf(cs, sizeof(cs), "%s: \"%s\" ch %d  %d dBm",
                     wifi_conn_state_name(), wifi_conn_ssid(),
                     wifi_conn_channel(), wifi_conn_rssi());
        else
            snprintf(cs, sizeof(cs), "%s", wifi_conn_state_name());
        wm_text_fit(WIFI_STATUS_X, 12, cs, cw - WIFI_STATUS_X - 6,
                    wifi_conn_state() == WIFI_CONN_CONNECTED
                        ? fb_rgb(0x90, 0xEE, 0x90)
                        : fb_rgb(0x8A, 0xC8, 0xE8), 0);
    }

    /* Заголовки колонок */
    int y0 = WIFI_HDR;
    fb_fill_rect(0, y0, cw, WIFI_COLHDR, wm_theme_win_bg_alt());
    fb_text(4, y0 + 5, "SSID                  BSSID               RSSI  Ch  Security",
            wm_theme_text(), -1);

    /* Список AP */
    int area_y0, area_h, vis;
    wifi_list_rect(w, &area_y0, &area_h, &vis);
    fb_fill_rect(0, area_y0, cw, area_h, wm_theme_win_bg());

    int connecting = (wifi_conn_state() == WIFI_CONN_SCAN ||
                      wifi_conn_state() == WIFI_CONN_AUTH ||
                      wifi_conn_state() == WIFI_CONN_ASSOC ||
                      wifi_conn_state() == WIFI_CONN_4WAY);

    if (!wifi_present()) {
        fb_text(12, area_y0 + 6, "WiFi adapter not found", fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, area_y0 + 22, "Atheros AR9285/9287/9485 или RTL8192EU (USB)",
                wm_theme_text_dim(), -1);
    } else if (!wifi_ready()) {
        fb_text(12, area_y0 + 6, "Adapter init FAILED (see log below)", fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, area_y0 + 22, "Serial log has details (dmesg)", wm_theme_text_dim(), -1);
    } else if (m->ap_count == 0 && !m->scanning) {
        fb_text(12, area_y0 + 6, "No access points found", wm_theme_text_dim(), -1);
        fb_text(12, area_y0 + 22, "Click [Scan] to start scanning", wm_theme_text_info(), -1);
    } else {
        int vis_max = (vis < m->ap_count) ? vis : m->ap_count;
        int y = area_y0 + 2;
        for (int i = 0; i < vis_max; i++) {
            int idx = m->scroll + i;
            if (idx >= m->ap_count) break;
            wifi_ap_t *ap = &m->aps[idx];
            char line[200];
            char ssid[21];
            int sl = (int)strlen(ap->ssid);
            if (sl > 20) sl = 20;
            memcpy(ssid, ap->ssid, sl);
            ssid[sl] = 0;
            char mac[20];
            snprintf(mac, sizeof(mac), "%02x:%02x:%02x:%02x:%02x:%02x",
                     ap->bssid[0], ap->bssid[1], ap->bssid[2],
                     ap->bssid[3], ap->bssid[4], ap->bssid[5]);
            snprintf(line, sizeof(line), "%-20s  %-17s  %4d  %2d  %-10s",
                     ssid, mac, (int)ap->rssi, (int)ap->channel,
                     security_str(ap->sec));
            u32 fg = (ap->sec == WIFI_SEC_OPEN) ? fb_rgb(0x90, 0xEE, 0x90)
                  : (ap->sec == WIFI_SEC_WPA2_PSK ? fb_rgb(0x8A, 0xC8, 0xE8)
                                                  : wm_theme_text());
            int is_sel = (idx == m->sel);
            if (is_sel) {
                fb_fill_rect(0, y, cw, WIFI_ROW_H, wm_theme_sel_bg());
            } else if (i == m->hot_row) {
                fb_fill_rect(0, y, cw, WIFI_ROW_H, wm_theme_win_bg_alt());
            }
            fb_text(4, y, line, fg, -1);
            wifi_draw_bars(cw - 40, y + 1, ap->rssi);
            y += WIFI_ROW_H;
        }
        /* СЕССИЯ 32: видимая полоса прокрутки. Колесо (PgUp/PgDn) и
         * клавиши работали и раньше, но без полосы пользователь не
         * видел, что список из 30+ сетей прокручивается (640x480). */
        if (m->ap_count > vis) {
            int tx = cw - 7;
            int ty = area_y0 + 1, th = area_h - 2;
            fb_fill_rect(tx, ty, 6, th, fb_rgb(0x1C, 0x22, 0x28));
            fb_rect(tx, ty, 6, th, fb_rgb(0x2A, 0x33, 0x3D));
            int hh = th * vis / m->ap_count;
            if (hh < 10) hh = 10;
            int maxs = m->ap_count - vis;
            int off = (maxs > 0) ? ((th - hh) * m->scroll) / maxs : 0;
            fb_fill_rect(tx + 1, ty + off, 4, hh, fb_rgb(0x50, 0x64, 0x78));
        }
    }

    /* прогресс скана — только когда НЕ идёт подключение (иначе
     * выглядело как «поиск начался заново» после ввода пароля) */
    if (m->scanning && !connecting) {
        char pbar[80];
        snprintf(pbar, sizeof(pbar), "Scanning channel %d/14",
                 m->stats.channel ? m->stats.channel : 1);
        fb_text(cw - 8 - (int)fb_text_w(pbar), 5, pbar,
                fb_rgb(0xFF, 0xE0, 0x60), -1);
        int pw = (cw - 8) * (m->stats.channel ? m->stats.channel : 1) / 14;
        fb_fill_rect(4, WIFI_HDR - 4, pw, 2, fb_rgb(0x90, 0xEE, 0x90));
    }

    /* Панель журнала драйвера */
    int log_y = area_y0 + area_h;
    int log_h = WIFI_LOG_H * 11 + 16;
    fb_fill_rect(0, log_y, cw, log_h, fb_rgb(0x10, 0x14, 0x18));
    fb_rect(0, log_y, cw, log_h, fb_rgb(0x2A, 0x33, 0x3D));
    fb_text(4, log_y + 2, "Driver log:", wm_theme_text_info(), -1);
    {
        int got = wifi_log_tail(m->logbuf, sizeof(m->logbuf) - 1, WIFI_LOG_H);
        if (got > 0) {
            m->logbuf[got] = 0;
            int ly = log_y + 14;
            const char *p = m->logbuf;
            while (*p && ly < log_y + log_h - 4) {
                char line[110];
                int ll = 0;
                while (*p && *p != '\n' && ll < (int)sizeof(line) - 1)
                    line[ll++] = *p++;
                line[ll] = 0;
                if (*p == '\n') p++;
                if (ll) {
                    fb_text(8, ly, line, wm_theme_text_dim(), -1);
                }
                ly += 11;
            }
        } else {
            fb_text(8, log_y + 14, "(empty)", fb_rgb(0x5A, 0x63, 0x6C), -1);
        }
    }

    /* Панель ввода пароля: текст ОТКРЫТ (без звёздочек) + кнопки */
    if (m->pw_mode) {
        int pw_h = 56;
        int pw_y = ch - 14 - pw_h;
        fb_fill_rect(0, pw_y, cw, pw_h, fb_rgb(0x1A, 0x14, 0x10));
        fb_rect(0, pw_y, cw, pw_h, fb_rgb(0xE0, 0x50, 0x50));
        char lt[128];
        snprintf(lt, sizeof(lt), "Пароль WPA2 для \"%s\"", m->pw_ssid);
        fb_text(8, pw_y + 4, lt, fb_rgb(0xFF, 0xC0, 0x40), -1);
        /* поле пароля (слева, до кнопок) */
        int fld_w = cw - 8 - 200 - 8;
        if (fld_w < 60) fld_w = 60;
        fb_fill_rect(8, pw_y + 22, fld_w, 18, wm_theme_win_bg());
        fb_rect(8, pw_y + 22, fld_w, 18, fb_rgb(0x2C, 0x31, 0x38));
        {
            /* видимый пароль + мигающий курсор (сессия 28: без звёздочек) */
            char shown[80];
            int maxn = (fld_w - 12) / 8;
            if (maxn > (int)sizeof(shown) - 2) maxn = (int)sizeof(shown) - 2;
            int n = (int)strlen(m->psw);
            if (n > maxn - 1) n = maxn - 1;
            memcpy(shown, m->psw, (u32)n);
            if (wm_blink()) shown[n++] = '_';
            shown[n] = 0;
            if (shown[0]) fb_text(12, pw_y + 26, shown, wm_theme_text(), -1);
        }
        /* кнопки справа */
        u32 bbg = wm_theme_title();
        wm_button_draw(cw - 8 - 92, pw_y + 20, 92, 18, "Подключиться",
                       m->pw_pressed == 0 ? fb_rgb(0x2E, 0x62, 0x36) : bbg,
                       wm_theme_text(), wm_theme_accent());
        wm_button_draw(cw - 8 - 92 - 96, pw_y + 20, 92, 18, "Отмена",
                       m->pw_pressed == 1 ? fb_rgb(0x6E, 0x3A, 0x2A) : bbg,
                       wm_theme_text(), wm_theme_accent());
        fb_text(8, pw_y + 44,
                "Enter — подключиться   Esc — отмена   Backspace — стереть",
                wm_theme_text_dim(), -1);
    }

    /* Статус-строка */
    fb_fill_rect(0, ch - 14, cw, 14, wm_theme_win_bg_alt());
    char s2[140];
    if (m->pw_mode)
        snprintf(s2, sizeof(s2), "Ввод пароля WPA2 (%d симв.)",
                 (int)strlen(m->psw));
    else if (connecting)
        snprintf(s2, sizeof(s2), "Подключение к \"%s\": %s",
                 wifi_conn_ssid(), wifi_conn_state_name());
    else if (m->scanning)
        snprintf(s2, sizeof(s2), "Scanning ch %d/14 | %d AP",
                 m->stats.channel ? m->stats.channel : 1, m->ap_count);
    else
        snprintf(s2, sizeof(s2),
                 "%d AP | клик — выбор, повторный — подключить, ПКМ — меню",
                 m->ap_count);
    fb_text(4, ch - 12, s2, wm_theme_text_info(), -1);
}

static void wifi_tick(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    wifi_get_stats(&m->stats);
    if (m->scanning) {
        m->scan_progress = m->stats.channel ? m->stats.channel - 1 : 0;
        m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
        if (!wifi_scan_active()) m->scanning = 0;
    } else {
        /* список обновляется маяками и между сканами — подтягиваем */
        m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
    }
    if (m->sel >= m->ap_count) m->sel = m->ap_count - 1;
    /* Сессия 15: фоновая инициализация — адаптер готов, сразу скан */
    static int was_pending = -1;
    int p = wifi_pending();
    if (p != was_pending) {
        was_pending = p;
        if (!p && wifi_present() && !wifi_scan_active())
            wifi_scan_start();
    }
    win_invalidate(w);
}

/* Сессия 12→28: подключение к выбранной сети (с учётом защиты). */
static void wifi_connect_selected(wifi_mgr_t *m) {
    if (m->sel < 0 || m->sel >= m->ap_count) return;
    wifi_ap_t *ap = &m->aps[m->sel];
    if (ap->sec == WIFI_SEC_OPEN) {
        if (wifi_connect(ap->ssid))
            m->scanning = wifi_scan_active();
        return;
    }
    /* защищённая сеть: есть сохранённый профиль — подключаемся сразу */
    char ssid[33], psk[65];
    if (wifi_profile_load(ssid, sizeof(ssid)) &&
        strcmp(ssid, ap->ssid) == 0 &&
        wifi_profile_load_psk(psk, sizeof(psk))) {
        if (wifi_connect_psk(ap->ssid, psk))
            m->scanning = wifi_scan_active();
        return;
    }
    m->pw_mode = 1;               /* просим пароль */
    m->psw[0] = 0;
    strncpy(m->pw_ssid, ap->ssid, sizeof(m->pw_ssid) - 1);
    m->pw_ssid[sizeof(m->pw_ssid) - 1] = 0;
    if (ap->sec == WIFI_SEC_WPA2_PSK)
        wifi_log("Connect: введите пароль WPA2 для \"%s\"", ap->ssid);
    else
        wifi_log("Connect: \"%s\" — тип защиты неизвестен, пробуем как WPA2-PSK",
                 ap->ssid);
}

/* подтвердить/отменить панель пароля (Enter/кнопка) */
static void wifi_pw_confirm(wifi_mgr_t *m) {
    m->pw_mode = 0;
    if (strlen(m->psw) >= 8) {
        if (wifi_connect_psk(m->pw_ssid, m->psw))
            m->scanning = wifi_scan_active();
    } else {
        wifi_log("пароль короче 8 символов — отмена");
    }
}

static void wifi_pw_cancel(wifi_mgr_t *m) {
    m->pw_mode = 0;
    wifi_log("ввод пароля отменён");
}

static void wifi_key(window_t *w, const key_event_t *ev) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* --- режим ввода пароля WPA2 --- */
    if (m->pw_mode) {
        if (ev->ch == 0x1B || ev->code == 0x01) {
            wifi_pw_cancel(m);
        } else if (ev->code == 0x1C || ev->ch == '\n') {
            wifi_pw_confirm(m);
        } else if (ev->code == 0x0E) {          /* Backspace */
            int nn = (int)strlen(m->psw);
            if (nn > 0) m->psw[nn - 1] = 0;
        } else if (ev->ch >= 0x20 && ev->ch < 0x7F) {
            int nn = (int)strlen(m->psw);
            if (nn < (int)sizeof(m->psw) - 1) {
                m->psw[nn] = (char)ev->ch;
                m->psw[nn + 1] = 0;
            }
        }
        win_invalidate(w);
        return;
    }

    if (ev->code == 0x3B || ev->ch == 's' || ev->ch == 'S') {  /* F1 or S */
        wifi_start_scan(m);
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x3C || ev->ch == 'c' || ev->ch == 'C') {  /* F2 or C */
        wifi_connect_selected(m);
        win_invalidate(w);
        return;
    }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == 0x1C || ev->ch == '\n') {   /* Enter = подключить */
        wifi_connect_selected(m);
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_UP) {
        if (m->sel > 0) m->sel--;
        if (m->sel < m->scroll) m->scroll = m->sel;   /* выделение не уезжает */
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_DOWN) {
        if (m->sel + 1 < m->ap_count) m->sel++;
        {
            int area_y0, area_h, vis2;
            wifi_list_rect(w, &area_y0, &area_h, &vis2);
            if (m->sel >= m->scroll + vis2) m->scroll = m->sel - vis2 + 1;
        }
        win_invalidate(w);
        return;
    }
    /* колесо мыши приходит как PgUp/PgDn (wm_mouse_poll) */
    int area_y0, area_h, vis;
    wifi_list_rect(w, &area_y0, &area_h, &vis);
    int max_scroll = m->ap_count - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (ev->code == 0x49) {                     /* PgUp = колесо вверх */
        m->scroll -= 3;
        if (m->scroll < 0) m->scroll = 0;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x51) {                     /* PgDn = колесо вниз */
        m->scroll += 3;
        if (m->scroll > max_scroll) m->scroll = max_scroll;
        win_invalidate(w);
        return;
    }
}

/* контекстное меню строки (ПКМ) */
static void wifi_menu_cb(int id, void *uctx) {
    window_t *w = (window_t *)uctx;
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    if (id == 1) wifi_connect_selected(m);
    else if (id == 2) wifi_start_scan(m);
    win_invalidate(w);
}

static void wifi_mouse(window_t *w, int mx, int my, u8 btn, u8 changed) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* --- панель пароля — модальна --- */
    if (m->pw_mode) {
        int pw_h = 56;
        int pw_y = ch - 14 - pw_h;
        if (my >= pw_y && my < ch - 14) {
            int ok_x = cw - 8 - 92, cn_x = ok_x - 96;
            if ((changed & MSB_LEFT) && my >= pw_y + 20 && my < pw_y + 38) {
                if (mx >= ok_x && mx < ok_x + 92) {
                    m->pw_pressed = 0;
                    wifi_pw_confirm(m);
                    win_invalidate(w);
                    return;
                }
                if (mx >= cn_x && mx < cn_x + 92) {
                    m->pw_pressed = 1;
                    wifi_pw_cancel(m);
                    win_invalidate(w);
                    return;
                }
            }
            if (!(btn & MSB_LEFT) && m->pw_pressed != -1) {
                m->pw_pressed = -1;
                win_invalidate(w);
            }
        }
        return;   /* остальная область игнорируется в модальном режиме */
    }

    /* --- кнопки шапки --- */
    if (my < WIFI_HDR) {
        if (my >= 2 && my < 2 + WIFI_BTN_H) {
            for (int b = 0; b < 2; b++) {
                int bx = 4 + b * (WIFI_BTN_W + 4);
                if (mx >= bx && mx < bx + WIFI_BTN_W) {
                    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
                        m->btn_pressed = b;
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT) &&
                        m->btn_pressed == b) {
                        m->btn_pressed = -1;
                        if (b == 0) {
                            wifi_start_scan(m);
                        } else {
                            wifi_connect_selected(m);
                        }
                    }
                    if (m->btn_hot != b) {
                        m->btn_hot = b;
                        win_invalidate(w);
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT))
                        win_invalidate(w);
                    return;
                }
            }
        }
        if (m->btn_hot != -1 || m->btn_pressed != -1) {
            m->btn_hot = -1;
            m->btn_pressed = -1;
            win_invalidate(w);
        }
        return;
    }

    /* --- список AP: выбор/подключение/меню --- */
    int area_y0, area_h, vis;
    wifi_list_rect(w, &area_y0, &area_h, &vis);
    if (my >= area_y0 && my < area_y0 + area_h && m->ap_count > 0) {
        int row = (my - area_y0) / WIFI_ROW_H;
        int idx = m->scroll + row;
        if (idx < 0) idx = 0;
        if (idx >= m->ap_count) idx = m->ap_count - 1;

        /* hot-подсветка строки */
        if (m->hot_row != row && row < vis) {
            m->hot_row = row;
            win_invalidate(w);
        }

        if (changed & MSB_RIGHT) {
            /* контекстное меню */
            m->sel = idx;
            wm_menu_item_t items[3];
            items[0].label = "Подключиться";  items[0].id = 1; items[0].disabled = 0;
            items[1].label = "Сканировать";   items[1].id = 2; items[1].disabled = 0;
            items[2].label = NULL;            items[2].id = 0; items[2].disabled = 0;
            wm_menu_open(w, mx, my, items, 3, wifi_menu_cb, w);
            win_invalidate(w);
            return;
        }
        if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {   /* клик (отпускание) */
            if (m->sel == idx) {
                /* повторный клик по выбранной — подключиться */
                wifi_connect_selected(m);
            } else {
                m->sel = idx;
            }
            win_invalidate(w);
            return;
        }
        return;
    }
    if (m->hot_row != -1) {
        m->hot_row = -1;
        win_invalidate(w);
    }
}

static void wifi_close(window_t *w) {
    if (w->data) free(w->data);
}

void app_wifi_open(void) {
    wifi_mgr_t *m = (wifi_mgr_t *)malloc(sizeof(wifi_mgr_t));
    if (!m) return;
    memset(m, 0, sizeof(wifi_mgr_t));
    m->btn_hot = -1;
    m->btn_pressed = -1;
    m->hot_row = -1;
    m->pw_pressed = -1;

    m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
    wifi_get_stats(&m->stats);

    u32 W = fb_width(), H = fb_height();
    int ww = WIFI_COLS * 8 + 12;
    int wh = WIFI_ROWS * WIFI_ROW_H + WIFI_HDR + WIFI_COLHDR +
             (WIFI_LOG_H * 11 + 16) + 14 + 24 + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;

    win_create("WiFi Scanner", 120, 30, ww, wh,
               wifi_draw, wifi_key, wifi_mouse, wifi_tick, wifi_close, m);
}
