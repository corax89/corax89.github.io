/* kbd.c — драйвер клавиатуры PS/2 (скан-код набор 1, раскладка US) */
#include "kbd.h"
#include "io.h"
#include "idt.h"

#define RING_SIZE 64

static volatile key_event_t ring[RING_SIZE];
static volatile u32 r_head = 0, r_tail = 0;

static u8 shift_state = 0, ctrl_state = 0, alt_state = 0, caps_state = 0;
static int e0_prefix = 0;

/* скан-код -> символ (набор 1, без Shift), ровно 128 элементов */
static const unsigned char sc_map[128] = {
    /* 00 */ 0, 0x1B, '1','2','3','4','5','6','7','8','9','0','-','=',
    /* 0E */ '\b',
    /* 0F */ '\t','q','w','e','r','t','y','u','i','o','p','[',']',
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 'a','s','d','f','g','h','j','k','l',';','\'','`',
    /* 2A */ 0,
    /* 2B */ '\\',
    /* 2C */ 'z','x','c','v','b','n','m',',','.','/',
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};

/* скан-код -> символ с Shift */
static const unsigned char sc_map_shift[128] = {
    /* 00 */ 0, 0x1B, '!','@','#','$','%','^','&','*','(',')','_','+',
    /* 0E */ '\b',
    /* 0F */ '\t','Q','W','E','R','T','Y','U','I','O','P','{','}',
    /* 1C */ '\n',
    /* 1D */ 0,
    /* 1E */ 'A','S','D','F','G','H','J','K','L',':','"','~',
    /* 2A */ 0,
    /* 2B */ '|',
    /* 2C */ 'Z','X','C','V','B','N','M','<','>','?',
    /* 36 */ 0,
    /* 37 */ '*',
    /* 38 */ 0,
    /* 39 */ ' ',
    /* 3A..7F */ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0
};

static void push_event(u8 code, char ch, u8 flags)
{
    u32 h = r_head;
    u32 nh = (h + 1) % RING_SIZE;
    if (nh == r_tail) return;         /* буфер полон — теряем */
    ring[h].code = code;
    ring[h].ch = ch;
    ring[h].flags = flags;
    r_head = nh;
}

/* Публичная обёртка для push_event — используется USB-HID драйвером
 * для инжекции событий от USB-клавиатуры в общий kbd ring. */
void kbd_push_event(u8 code, char ch, u8 flags)
{
    push_event(code, ch, flags);
}

static void kbd_irq(void)
{
    u8 sc = inb(0x60);

    if (e0_prefix) {
        e0_prefix = 0;
        switch (sc) {
        case 0x48: push_event(KBD_UP, 0, shift_state); return;
        case 0x4B: push_event(KBD_LEFT, 0, shift_state); return;
        case 0x4D: push_event(KBD_RIGHT, 0, shift_state); return;
        case 0x50: push_event(KBD_DOWN, 0, shift_state); return;
        case 0x1C: push_event(0x1C, '\n', shift_state); return;
        default: return; /* прочие E0-коды не используем */
        }
    }

    switch (sc) {
    case 0x2A: case 0x36: shift_state |= KF_SHIFT; return;
    case 0xAA: case 0xB6: shift_state &= (u8)~KF_SHIFT; return;
    case 0x1D: ctrl_state |= KF_CTRL; return;
    case 0x9D: ctrl_state &= (u8)~KF_CTRL; return;
    case 0x38: alt_state |= KF_ALT; return;
    case 0xB8: alt_state &= (u8)~KF_ALT; return;
    case 0x3A: caps_state ^= 1; return;
    case 0xE0: e0_prefix = 1; return;
    default: break;
    }

    u8 rel = 0, code = sc;
    if (code & 0x80) { rel = KF_RELEASED; code &= 0x7F; }

    u8 flags = (u8)(shift_state | ctrl_state | alt_state | rel);
    if (code >= 0x47 && code <= 0x53) {
        /* numpad — игнорируем */
        if (!rel) push_event(code, 0, flags);
        return;
    }

    char ch = 0;
    if (code < 128) {
        u8 base = sc_map[code];
        u8 shifted = sc_map_shift[code];
        if (base >= 'a' && base <= 'z') {
            /* для букв регистр = Shift XOR CapsLock */
            ch = (char)(((shift_state & KF_SHIFT) ^ (caps_state ? KF_SHIFT : 0))
                        ? base - 'a' + 'A' : base);
        } else {
            ch = (char)((shift_state & KF_SHIFT) ? shifted : base);
        }
    }
    if (!rel) push_event(code, ch, flags);
}

void kbd_init(void)
{
    /* осушаем буфер контроллера от мусора после GRUB */
    for (int i = 0; i < 64 && (inb(0x64) & 1); i++) (void)inb(0x60);
    irq_install(1, kbd_irq);
}

int kbd_pop(key_event_t *out)
{
    if (r_tail == r_head) return 0;
    *out = ring[r_tail];
    r_tail = (r_tail + 1) % RING_SIZE;
    return 1;
}
