/* c4gfx.c — окно графики для c4-программ (VM-путь F9 и native .bin).
 *
 * ПРОБЛЕМА, которую решает модуль: kfill/ktext c4 рисуют «на экран»
 * прямыми вызовами fb-примитивов. После перехода на многопоточный WM
 * (сессия 4) ЭКРАНОМ владеет композитор: любое примечание dirty он
 * закрашивает фоном и окнами — прямая запись на экран стирается в
 * следующем же кадре. Рисунок c4-программы был НЕВИДЕН (осталось
 * только «окно вывода» с printf).
 *
 * РЕШЕНИЕ: ленивое окно «C4: <имя>» при ПЕРВОМ графическом вызове:
 *   - canvas окна переподключается с потока окна на ЗАДАЧУ ПРОГРАММЫ
 *     (fb-примитивы в её контексте пишут прямо в canvas);
 *   - kflip() = отметить область окна на экране (композитор заблитит
 *     canvas на экран);
 *   - окно fixed_size: realloc canvas при resize отвалил бы указатель
 *     рисующей задачи;
 *   - клавиши: поток окна пересылает события в слот задачи программы
 *     (kevent читает его; раньше kbd_pop конкурировал с kmain —
 *     события клавиатуры до c4-программ НЕ ДОХОДИЛИ);
 *   - после завершения программы canvas остаётся у окна (последний
 *     кадр виден), окно закрывается по Esc/крестику.
 */
#include "c4gfx.h"
#include "wm.h"
#include "fb.h"
#include "task.h"
#include "types.h"

typedef struct {
    window_t *win;              /* окно графики (NULL = ещё не нужно) */
    char      title[32];        /* имя программы для заголовка */
    /* слот события kevent (писатель: поток окна; читатель: программа) */
    volatile int ev_ready;
    volatile u8  ev_ch, ev_code, ev_flags;
} c4gfx_t;

static c4gfx_t g_c4gfx[MAX_TASKS];

/* ---- колбэки окна (выполняются в ПОТОКЕ окна) ---- */

static void c4gfx_draw(window_t *w)
{
    /* Содержимое рисует сама программа прямо в canvas — тут нечего
     * делать (canvas уже подключён к её задаче). */
    (void)w;
}

static void c4gfx_key(window_t *w, const key_event_t *ev)
{
    int me = (int)(unsigned long)w->data;   /* задача программы */
    if (me < 0 || me >= MAX_TASKS) return;

    if (g_c4gfx[me].win != w) {
        /* программа завершилась: окно показывает последний кадр;
         * Esc — закрыть */
        if (ev->ch == 0x1B || ev->code == 0x01) win_close(w);
        return;
    }
    /* программа жива: переслать событие в её слот kevent */
    if (!g_c4gfx[me].ev_ready) {
        g_c4gfx[me].ev_ch   = ev->ch;
        g_c4gfx[me].ev_code = (u8)ev->code;
        g_c4gfx[me].ev_flags = (u8)ev->flags;
        g_c4gfx[me].ev_ready = 1;
    }
}

/* ---- API ---- */

void c4_gfx_set_name(const char *name)
{
    int me = task_current();
    if (me < 0 || me >= MAX_TASKS) return;
    c4gfx_t *g = &g_c4gfx[me];
    u32 i = 0;
    while (name && name[i] && i < sizeof(g->title) - 1) {
        g->title[i] = name[i];
        i++;
    }
    g->title[i] = 0;
}

void c4_gfx_ensure(void)
{
    int me = task_current();
    if (me < 0 || me >= MAX_TASKS) return;
    c4gfx_t *g = &g_c4gfx[me];
    if (g->win) return;                     /* уже создано */

    u32 W = fb_width(), H = fb_height();
    int ww = (int)W, wh = (int)H - TBAR_H;
    if (ww < 100) ww = 100;
    if (wh < 100) wh = 100;

    char title[40];
    const char *base = "C4";
    {
        /* extern snprintf */
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        if (g->title[0])
            snprintf(title, sizeof(title), "C4: %s", g->title);
        else
            snprintf(title, sizeof(title), "C4 %s", base);
    }

    /* лёгкий каскад, чтобы несколько программ не сливались в точку */
    int off = (me % 5) * 24;

    window_t *w = win_create(title, off, off, ww, wh,
                             c4gfx_draw, c4gfx_key, NULL, NULL, NULL,
                             (void *)(unsigned long)me);
    if (!w) return;

    /* canvas → контекст ЗАДАЧИ ПРОГРАММЫ (рисование идёт в нём).
     * Сессия 12: помечаем окно ДО detach — иначе поток окна, запущенный
     * win_create, ждёт свой (уже отключённый) canvas и не обрабатывает
     * события (queue full, фокус крадётся). */
    win_set_no_canvas(w);
    if (w->task > 0) fb_task_canvas_detach(w->task);
    if (!fb_task_canvas_attach(me, w->canvas, w->cvs_w, w->cvs_h)) {
        /* не хватило слота canvas — окно бесполезно, закрыть */
        win_close(w);
        return;
    }
    w->fixed_size = 1;          /* realloc canvas запрещён (см. wm.c) */
    g->win = w;
}

void c4_gfx_detach(void)
{
    int me = task_current();
    if (me < 0 || me >= MAX_TASKS) return;
    c4gfx_t *g = &g_c4gfx[me];
    if (g->win) {
        /* canvas отсоединяем от задачи, но ПАМЯТЬ остаётся у окна:
         * последний кадр продолжает показываться, окно живёт до
         * закрытия пользователем. */
        fb_task_canvas_detach(me);
        g->win = NULL;
    }
    g->title[0] = 0;
    g->ev_ready = 0;
}

/* ---- обёртки примитивов (kapi + VM) ---- */

void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c)
{
    c4_gfx_ensure();
    fb_fill_rect(x, y, w, h, c);
}

void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg)
{
    c4_gfx_ensure();
    fb_text(x, y, s, fg, bg);
}

void c4_gfx_fill_screen(u32 c)
{
    c4_gfx_ensure();
    fb_fill_screen(c);
}

u32 c4_gfx_width(void)
{
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && g_c4gfx[me].win)
        return (u32)g_c4gfx[me].win->cvs_w;
    return fb_width();
}

u32 c4_gfx_height(void)
{
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && g_c4gfx[me].win)
        return (u32)g_c4gfx[me].win->cvs_h;
    return fb_height();
}

/* kflip(): показать нарисованное — отметить область окна на экране.
 * Семантика win_invalidate(window_t*) — вызывается и из native-кода
 * (c4_x86 KFLIP пушит win), и из VM. */
void c4_gfx_flip(struct window *unused)
{
    (void)unused;
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && g_c4gfx[me].win) {
        window_t *w = g_c4gfx[me].win;
        fb_touch(w->x, w->y, w->w, w->h);
        return;
    }
    /* окна нет (программа ещё ничего не рисовала) — полный кадр */
    fb_touch_all();
    fb_flush();
}

/* kevent: событие из очереди ОКНА программы (kbd_pop больше не
 * используется — kmain вытягивает клавиатуру раньше). */
int c4_gfx_event_poll(void *out_buf)
{
    int me = task_current();
    if (me < 0 || me >= MAX_TASKS) return 0;
    c4gfx_t *g = &g_c4gfx[me];
    if (!g->ev_ready) return 0;
    if (out_buf) {
        u8 *out = (u8 *)out_buf;
        out[0] = g->ev_ch;
        out[1] = g->ev_code;
        out[2] = g->ev_flags;
    }
    g->ev_ready = 0;
    if (g->ev_ch == 0x1B || g->ev_code == 0x01) return 3;   /* Esc = выход */
    return 1;
}
