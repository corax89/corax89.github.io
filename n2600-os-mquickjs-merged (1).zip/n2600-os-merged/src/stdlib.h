/* stdlib.h — перехватчик <stdlib.h> для ядра N2600-OS.
 *
 * Зачем: stb_image.h (src/stb_image.h) безусловно делает
 * #include <stdlib.h>; в freestanding-сборке libc нет, а сборка идёт
 * с -Isrc, поэтому этот заголовок перехватывает <stdlib.h> для модулей
 * ядра. Реальных функций здесь НЕТ и объявлять malloc/free не нужно:
 * stb_image работает через STBI_MALLOC/STBI_REALLOC_SIZED/STBI_FREE
 * (см. src/stb_image.c — отображены на malloc/free ядра).
 *
 * На хост-сборках (тесты, __STDC_HOSTED__ != 0) заглушка прозрачна:
 * include_next проводит к настоящей libc-версии.
 *
 * Прочие libc-заголовки не нужны: stb_image собран с STBI_NO_STDIO/
 * STBI_ASSERT/STBI_NO_HDR; <stdarg.h>, <stddef.h>, <limits.h>
 * обслуживаются встроенными заголовками GCC и src/limits.h. */
#ifndef STDLIB_H
#define STDLIB_H

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include_next <stdlib.h>          /* хост: настоящая libc */
#else
#include <stddef.h>               /* freestanding: size_t, NULL */
#endif

#endif /* STDLIB_H */
