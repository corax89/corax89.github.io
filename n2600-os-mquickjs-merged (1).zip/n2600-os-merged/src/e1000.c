/* e1000.c — драйвер Intel 82540EM (E1000) Gigabit Ethernet.
 *
 * Реализация минимального polling-драйвера для VMware и QEMU:
 *   1. PCI-сканирование (vendor=0x8086, поддерживаем devices: 0x100E/0x100F/0x1010/0x1011/0x1013/0x1015/0x1016/0x1017/0x1018/0x1019/0x101A/0x101D/0x1076/0x1077/0x1078/0x107C/0x10A0/0x10D3/0x1533)
 *   2. Включение Bus Master + Memory Space
 *   3. Сброс чипа
 *   4. Чтение MAC-адреса из EEPROM (EERD)
 *   5. Настройка TX/RX descriptor rings (legacy mode, 16-byte descriptors)
 *   6. Приём/передача через опрос (polling)
 *
 * Особенности:
 *   - Дескрипторы выделяются статически по 32 приёма/32 передачи (32*16=1024 байта)
 *   - Буферы пакетов СТАТИЧЕСКИЕ (FIX аудита: malloc не используется —
 *     при отказе выделения дескриптор получал addr=0, NIC писал в
 *     нулевую физическую память)
 *   - Прерывания замаскированы, polling из главного цикла
 *   - Multicast не настроен (BAM бит установлен для broadcast приёма)
 */
#include "e1000.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);
static void serial_putc_local(char c);
static void serial_puthex_local(u32 v);

/* ---------- PCI IDs (Intel) ---------- */
#define INTEL_VENDOR_ID  0x8086
/* Поддерживаемые device IDs. QEMU/VMware обычно 0x100E (82540EM). */
static const u16 e1000_device_ids[] = {
    0x100E, /* 82540EM (QEMU, VMware default) */
    0x100F, /* 82545EM */
    0x1010, /* 82546GB */
    0x1011, /* 82545EM */
    0x1013, /* 82541EI */
    0x1015, /* 82541EI */
    0x1016, /* 82540EP */
    0x1017, /* 82540EP */
    0x101D, /* 82572EI */
    0x1076, /* 82572EI */
    0x1077, /* 82572EI */
    0x1078, /* 82573L */
    0x107C, /* 82573L */
    0x10A0, /* 82574L */
    0x10D3, /* 82574L */
    0x1533, /* I210 */
    0  /* sentinel */
};

/* ---------- E1000 регистры (offsets от MMIO base) ---------- */
#define E1000_CTRL    0x0000
#define E1000_STATUS  0x0008
#define E1000_EECD    0x0010
#define E1000_EERD    0x0014   /* EEPROM Read */
#define E1000_RDBAL   0x2800   /* RX Descriptor Base Low */
#define E1000_RDBAH   0x2804   /* RX Descriptor Base High */
#define E1000_RDLEN   0x2808   /* RX Descriptor Length */
#define E1000_RDH     0x2810   /* RX Descriptor Head */
#define E1000_RDT     0x2818   /* RX Descriptor Tail */
#define E1000_RCTL    0x0100   /* RX Control */
#define E1000_TDBAL   0x3800   /* TX Descriptor Base Low */
#define E1000_TDBAH   0x3804
#define E1000_TDLEN   0x3808
#define E1000_TDH     0x3810
#define E1000_TDT     0x3818
#define E1000_TCTL    0x0400   /* TX Control */
#define E1000_IMC     0x00D8   /* Interrupt Mask Clear */
#define E1000_RAL     0x5400   /* Receive Address Low */
#define E1000_RAH     0x5404   /* Receive Address High */
#define E1000_MTA     0x5200   /* Multicast Table Array */

/* CTRL bits */
#define CTRL_RST       (1u << 26)  /* 0x04000000 — Global reset. СЕССИЯ 14, ФИКС:
                                    * прежде был бит 3 — а это LRST! QEMU (set_ctrl:
                                    * val & ~E1000_CTRL_RST) не считал его сбросом и НЕ
                                    * обнулял бит → наш цикл «ждать очистки RST» крутился
                                    * вечно. Значения выверены по Linux e1000_hw.h /
                                    * QEMU e1000x_regs.h. */
#define CTRL_LRST      (1u << 3)   /* 0x00000008 — Link reset (наш прежний «RST») */
#define CTRL_ILOS      (1u << 7)   /* 0x80 — наш прежний «LRST» был этим битом! */
#define CTRL_SLU       (1u << 6)   /* Set Link Up */
#define CTRL_FRCSPD    (1u << 11)

/* EECD bits */
#define EECD_EE_PRES   (1u << 8)
#define EECD_SK        (1u << 0)
#define EECD_CS        (1u << 1)
#define EECD_DI        (1u << 2)
#define EECD_DO        (1u << 3)

/* EERD bits */
#define EERD_START     (1u << 0)
#define EERD_DONE      (1u << 1)
#define EERD_ADDR_SHIFT 8
#define EERD_DATA_SHIFT 16

/* RCTL bits */
#define RCTL_EN        (1u << 1)   /* Receiver Enable */
#define RCTL_SBP       (1u << 2)   /* Store Bad Packets */
#define RCTL_UPE       (1u << 3)   /* Unicast Promiscuous */
#define RCTL_MPE       (1u << 4)   /* Multicast Promiscuous */
/* FIX [E2] (e1000 был ГЛУХ к broadcast): BAM — бит 15 (0x8000), а не 10!
 * По даташиту 8254x (и Linux e1000_hw.h E1000_RCTL_BAM 0x00008000).
 * Из-за неверного бита NIC отбрасывал ВСЕ broadcast-кадры: DHCP
 * OFFER/ACK (сервер шлёт в 255.255.255.255), чужие ARP-запросы и т.д.
 * Unicast (ARP replies, TCP) работал — поэтому баг не ловился. */
#define RCTL_BAM       (1u << 15)  /* Broadcast Accept Mode (бит 15!) */
#define RCTL_BSIZE_2048 0
#define RCTL_BSIZE_1024 (1u << 16)
#define RCTL_BSIZE_512  (1u << 17)
#define RCTL_BSIZE_256  ((1u<<16)|(1u<<17))
/* FIX (аудит): SECRC — бит 26 (0x04000000; Linux E1000_RCTL_SECRC),
 * НЕ бит 12: в RCTL биты 12-13 — поле MO (Multicast Offset). Макрос
 * ранее держал неверное значение (бит 12) и не использовался.
 * ВКЛЮЧАТЬ его не спешим: стек справляется с хвостовым CRC
 * (ip_len-проверка игнорирует лишние 4 байта), а длина дескриптора
 * при выключенном SECRC включает CRC — сетевой стек это уже учитывает. */
#define RCTL_SECRC     (1u << 26)  /* Strip Ethernet CRC (НЕ 12 — это MO!) */

/* СЕССИЯ 15 (VMware, все режимы сети): очередь RX/TX нужно ЯВНО
 * включать битом ENABLE (25) в RXDCTL/TXDCTL — контроллеры 82574
 * (E1000E в VMware, dev 10D3) и новее (82576/I210) НЕ работают без
 * этого: дескрипторы не обрабатываются — кадры не уходят и не
 * приходят, хотя все остальные регистры настроены верно. Источник:
 * Intel 82574 Datasheet (RXDCTL/TXDCTL, бит ENABLE) и Linux e1000e
 * (e1000_configure_rx: "Enable receive on the queue" для
 * mac.type >= e1000_82574). На классических 82540/82545 бит
 * зарезервирован и игнорируется — пишем только для семейства 82574+. */
#define E1000_RXDCTL0  0x2828      /* очередь 0: RX Descriptor Control */
#define E1000_TXDCTL0  0x3828      /* очередь 0: TX Descriptor Control */
#define QCTL_ENABLE    (1u << 25)

/* ICR (причины прерываний — для диагностики) */
#define E1000_ICR      0x00C0

/* TCTL bits */
#define TCTL_EN        (1u << 1)   /* Transmit Enable */
#define TCTL_PSP       (1u << 3)   /* Pad Short Packets */
#define TCTL_CT_SHIFT  4
#define TCTL_COLD_SHIFT 12

/* Status */
#define STATUS_LU      (1u << 1)   /* Link Up */

/* Legacy descriptor (16 bytes). */
typedef struct __attribute__((packed, aligned(16))) {
    u64 addr;        /* buffer address */
    u16 length;      /* data length */
    u16 csum;        /* checksum (or 0) */
    u8  status;      /* DD=0x01, etc. */
    u8  errors;
    u16 special;     /* VLAN tag (or 0) */
} e1000_desc_t;

#define E1000_RX_COUNT 32
#define E1000_TX_COUNT 32

/* TX descriptor command bits (in legacy mode these are in low byte of special field,
 * but for legacy "Read" descriptor format, status field is at offset 8 and DD bit
 * is the LSB. We use the legacy "legacy" descriptor format. */
#define TXD_CMD_EOP    0x01   /* End of Packet */
#define TXD_CMD_IFCS   0x02
#define TXD_CMD_RS     0x08   /* Report Status (set DD on completion) */

#define RXD_STAT_DD    0x01   /* Descriptor Done */

typedef struct {
    int  present;
    int  bus, dev, func;
    u32  mmio_base;
    u16  device_id;
    char chip_name[40];
    u8   mac[6];
    /* Descriptor rings */
    e1000_desc_t rx_desc[E1000_RX_COUNT] __attribute__((aligned(16)));
    e1000_desc_t tx_desc[E1000_TX_COUNT] __attribute__((aligned(16)));
    /* FIX (аудит): буферы СТАТИЧЕСКИЕ, не malloc. Прежде при malloc()==NULL
     * дескриптор получал addr=0 — NIC молча писал пакеты в нулевую физическую
     * память (порча ядра). Статические буферы также гарантируют физическую
     * непрерывность и валидный адрес до старта VM-пейджинга (ядро N2600
     * выполняется с тождественным отображением: виртуальные адреса = физические;
     * x86 + PCI — DMA когерентен с кэшем по спецификации шины, explicit cache
     * flush не нужен). */
    u8   rx_bufs[E1000_RX_COUNT][2048];   /* приёмный буфер: ровно под RCTL BSIZE 2048 */
    u8   tx_bufs[E1000_TX_COUNT][E1000_PKT_MAX];
    u32  rx_tail;
    u32  tx_head;
    u32  tx_tail;
    u32  tx_hw_done;   /* СЕССИЯ 15: кадров, ПОДТВЕРЖДЁННЫХ железом (DD).
                        * Диагностика: считается по дескриптору, который
                        * переиспользуется в данный момент — может быть
                        * заниженным; для строгой статистики не годится. */
    u32  tx_requests;  /* запросов отправки от стека */
} e1000_state_t;

static e1000_state_t g_e1000;

/* ---------- Барьеры для DMA (FIX аудита) ----------
 * Ядро x86 (TSO) само не переупорядочивает обычные записи друг с другом,
 * а MMIO-регистры — UC-память: запись дескриптора (WB) гарантированно
 * видна NIC раньше записи в TDT/RDT (UC) НА УРОВНЕ CPU. Остаётся
 * КОМПИЛЯТОР: он имеет право переставить неволатильные записи после
 * volatile-записи. memory-clobber запрещает ему это. */
static inline void dma_wmb(void) { __asm__ volatile("" ::: "memory"); }
static inline void dma_rmb(void) { __asm__ volatile("" ::: "memory"); }

/* ---------- MMIO helpers ---------- */
static inline u32 e1000_read(u32 reg)
{
    return *(volatile u32 *)(unsigned long)(g_e1000.mmio_base + reg);
}

static inline void e1000_write(u32 reg, u32 val)
{
    *(volatile u32 *)(unsigned long)(g_e1000.mmio_base + reg) = val;
}

/* ---------- Отладка ---------- */
static void serial_putc_local(char c)
{
    /* FIX (аудит): ожидание THRE ограничено — если UART занят/висит,
    * не блокируем систему навсегда. Нет COM1: LSR читается 0xFF,
    * бит 0x20 «установлен», цикл проходит мгновенно. */
    for (int i = 0; i < 100000; i++)
        if (inb(0x3F8 + 5) & 0x20) break;
    outb(0x3F8, (u8)c);
}

static void serial_puts_local(const char *s)
{
    for (; *s; s++) {
        if (*s == '\n') serial_putc_local('\r');
        serial_putc_local(*s);
    }
}

static void serial_puthex_local(u32 v)
{
    const char *d = "0123456789abcdef";
    serial_puts_local("0x");
    for (int i = 28; i >= 0; i -= 4) serial_putc_local(d[(v >> i) & 0xF]);
}

/* ---------- EEPROM чтение (одного 16-битного слова) ----------
 * Сессия 14: ожидание DONE ограничено РЕАЛЬНЫМ временем (2 мс).
 * Прежний счётчик 100000 итераций MMIO-чтений на VMware = 0.2-0.5 с
 * на слово (при чтении MAC — три слова, до 1.5 с блокировки загрузки). */
static int e1000_eeprom_read(u8 addr, u16 *out)
{
    u32 v = ((u32)addr << EERD_ADDR_SHIFT) | EERD_START;
    e1000_write(E1000_EERD, v);

    u32 dl = timer_poll_deadline();
    for (;;) {
        u32 s = e1000_read(E1000_EERD);
        if (s & EERD_DONE) {
            *out = (u16)((s >> EERD_DATA_SHIFT) & 0xFFFF);
            return 1;
        }
        if (timer_poll_expired(dl, 2000)) return 0;
    }
}

/* ---------- Сброс чипа ----------
 * СЕССИЯ 14: писать ТОЛЬКО бит 26 (Global reset) и ждать ТОЛЬКО его.
 * Бит 3 (LRST) в QEMU не самоочищается — ждать его было нельзя. */
static void e1000_reset(void)
{
    u32 ctrl = e1000_read(E1000_CTRL);
    e1000_write(E1000_CTRL, ctrl | CTRL_RST);
    /* ~10 мс после записи сброса (PIT-дедлайн; прежде — 50000×inb(0x80) —
     * на VMware это 100-250 мс реального времени) */
    {
        u32 dl = timer_poll_deadline();
        while (!timer_poll_expired(dl, 10000)) { }
    }
    /* Ждём самосброса бита RST — до 50 мс (PIT-дедлайны точны до ~55 мс;
     * прежде — до 1000000 MMIO-читений = секунды на VMware) */
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            if (!(e1000_read(E1000_CTRL) & CTRL_RST)) break;
            if (timer_poll_expired(dl, 50000)) break;
        }
    }
}

/* ---------- СЕССИЯ 15: включение очередей RX/TX (семейство 82574+) ----------
 * E1000E в VMware = 82574L (dev 10D3): без бита ENABLE (25) в RXDCTL/
 * TXDCTL дескрипторы НЕ обрабатываются. Симптом у пользователя:
 * «адаптер определяется, шлёт запросы (DHCP DISCOVER), но ответов
 * нет» — кадры даже не покидали NIC. Linux e1000e включает очередь
 * и ПОЛИТ бит, пока он не поднимется (жело подтверждает готовность). */
static int e1000_is_82574_family(u16 devid)
{
    /* 82574L/82574LA: 0x10D3 (PCI), 0x10A0; I210: 0x1533; 82576: 0x10C9
     * (в списке драйвера — 10D3/10A0/1533). */
    return devid == 0x10D3 || devid == 0x10A0 || devid == 0x1533;
}

static void e1000_enable_queues(u16 devid)
{
    if (!e1000_is_82574_family(devid)) return;   /* 82540/45: не нужно */

    /* RX-очередь: включить и дождаться подтверждения (до 100 мс) */
    e1000_write(E1000_RXDCTL0, e1000_read(E1000_RXDCTL0) | QCTL_ENABLE);
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            if (e1000_read(E1000_RXDCTL0) & QCTL_ENABLE) break;
            if (timer_poll_expired(dl, 100000)) {
                serial_puts_local("[e1000] ВНИМАНИЕ: RX-очередь не подтвердила ENABLE\n");
                break;
            }
        }
    }
    /* TX-очередь: включить и дождаться подтверждения */
    e1000_write(E1000_TXDCTL0, e1000_read(E1000_TXDCTL0) | QCTL_ENABLE);
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            if (e1000_read(E1000_TXDCTL0) & QCTL_ENABLE) break;
            if (timer_poll_expired(dl, 100000)) {
                serial_puts_local("[e1000] ВНИМАНИЕ: TX-очередь не подтвердила ENABLE\n");
                break;
            }
        }
    }
    serial_puts_local("[e1000] очереди 82574: RXDCTL/TXDCTL ENABLE готово\n");
}

/* ---------- Настройка RX ---------- */
static void e1000_setup_rx(void)
{
    /* Буферы статические (см. e1000_state_t) — ни malloc, ни NULL.
     * FIX (аудит): прежде при malloc()==NULL дескриптор получал addr=0. */
    for (int i = 0; i < E1000_RX_COUNT; i++) {
        memset(g_e1000.rx_bufs[i], 0, sizeof(g_e1000.rx_bufs[i]));
        g_e1000.rx_desc[i].addr = (u64)(unsigned long)g_e1000.rx_bufs[i];
        g_e1000.rx_desc[i].length = (u16)sizeof(g_e1000.rx_bufs[i]);
        g_e1000.rx_desc[i].status = 0;
        g_e1000.rx_desc[i].errors = 0;
        g_e1000.rx_desc[i].special = 0;
        g_e1000.rx_desc[i].csum = 0;
    }
    dma_wmb();
    g_e1000.rx_tail = 0;

    /* RDBAL/RDBAH */
    u32 addr = (u32)(unsigned long)g_e1000.rx_desc;
    e1000_write(E1000_RDBAL, addr);
    e1000_write(E1000_RDBAH, 0);
    e1000_write(E1000_RDLEN, E1000_RX_COUNT * sizeof(e1000_desc_t));
    e1000_write(E1000_RDH, 0);
    /* Модель кольца (сверено с QEMU hw/net/e1000.c): NIC обрабатывает
     * дескрипторы, пока RDH != RDT, и СТОПорится при равенстве. Значит:
     * «кольцо пусто» == RDH == RDT, а RDT — индекс ПОСЛЕДНЕГО
     * доступного дескриптора (не «один за ним», как в иных трактовках
     * спецификации). Поэтому: инициализация RDT = N-1; после возврата
     * обработанного дескриптора tail пишем RDT = tail. Поведение
     * проверено на QEMU (DHCP/TCP работают); при портировании на
     * реальное 82574/I210 — перепроверить DD/RDH/RDT согласованность. */
    e1000_write(E1000_RDT, E1000_RX_COUNT - 1);

    /* RCTL: enable + broadcast accept, MPE/UPE off, буфер 2048.
     * (бит 12, ошибочно считавшийся SECRC, убран — CRC приходит
     * в кадре, но ip_len-проверка стека её игнорирует) */
    u32 rctl = RCTL_EN | RCTL_BAM | RCTL_BSIZE_2048;
    e1000_write(E1000_RCTL, rctl);
}

/* ---------- Настройка TX ---------- */
static void e1000_setup_tx(void)
{
    /* Очищаем дескрипторы (буферы статические — см. e1000_state_t) */
    for (int i = 0; i < E1000_TX_COUNT; i++) {
        memset(g_e1000.tx_bufs[i], 0, sizeof(g_e1000.tx_bufs[i]));
        g_e1000.tx_desc[i].addr = 0;
        g_e1000.tx_desc[i].length = 0;
        g_e1000.tx_desc[i].status = 0;
        g_e1000.tx_desc[i].csum = 0;
        g_e1000.tx_desc[i].errors = 0;
        g_e1000.tx_desc[i].special = 0;
    }
    g_e1000.tx_head = 0;
    g_e1000.tx_tail = 0;

    u32 addr = (u32)(unsigned long)g_e1000.tx_desc;
    e1000_write(E1000_TDBAL, addr);
    e1000_write(E1000_TDBAH, 0);
    e1000_write(E1000_TDLEN, E1000_TX_COUNT * sizeof(e1000_desc_t));
    e1000_write(E1000_TDH, 0);
    e1000_write(E1000_TDT, 0);

    /* TCTL: enable, pad short packets, cold=0x10 (full-duplex), collision threshold = 0x10 */
    u32 tctl = TCTL_EN | TCTL_PSP
             | (0x10 << TCTL_CT_SHIFT)
             | (0x40 << TCTL_COLD_SHIFT);
    e1000_write(E1000_TCTL, tctl);
}

/* ---------- Поиск устройства по PCI ---------- */
static int e1000_find_device(u16 *out_device_id)
{
    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            /* Без multi-function сканирования — но проверим func 0/1 */
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor != INTEL_VENDOR_ID) {
                    if (func == 0) {
                        u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                        if (!(hdr & 0x80)) break;
                    }
                    continue;
                }
                /* Совпадение device id с известными E1000 */
                for (int k = 0; e1000_device_ids[k]; k++) {
                    if (device == e1000_device_ids[k]) {
                        g_e1000.bus = bus;
                        g_e1000.dev = dev;
                        g_e1000.func = func;
                        g_e1000.device_id = device;
                        *out_device_id = device;
                        return 1;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    return 0;
}

/* Полный 6-байтовый MAC валиден? (не все нули и не все FF).
 * FIX (аудит): прежняя проверка RAL/RAH требовала (RAH & 0xFFFF) != 0 —
 * MAC вида xx:xx:xx:xx:00:00 отвергался, хотя он полностью корректен. */
static int e1000_mac_valid(const u8 *m)
{
    int all_zero = 1, all_ff = 1;
    for (int i = 0; i < 6; i++) {
        if (m[i] != 0)   all_zero = 0;
        if (m[i] != 0xFF) all_ff = 0;
    }
    return !all_zero && !all_ff;
}

/* ---------- Чтение MAC ----------
 * На QEMU EEPROM читается через EERD (legacy mode).
 * На реальном железе/VMware RAL/RAH могут быть уже запрограммированы
 * BIOS/прошивкой — попробуем их сначала.
 * NOTE (аудит): EERD — путь для семейства 8254x; на 82574/I210 доступ к
 * NVM имеет нюансы (для них ниже есть резервные пути: RAL/RAH до и
 * после сброса, локально-администрируемый MAC). */
static int e1000_read_mac(void)
{
    /* Способ 1: прочитать RAL/RAH (если BIOS уже записал MAC).
     * Валидность — по всему 6-байтовому MAC (см. e1000_mac_valid). */
    u32 ral = e1000_read(E1000_RAL);
    u32 rah = e1000_read(E1000_RAH);
    {
        u8 m[6];
        m[0] = (u8)(ral & 0xFF);
        m[1] = (u8)((ral >> 8) & 0xFF);
        m[2] = (u8)((ral >> 16) & 0xFF);
        m[3] = (u8)((ral >> 24) & 0xFF);
        m[4] = (u8)(rah & 0xFF);
        m[5] = (u8)((rah >> 8) & 0xFF);
        /* Если железо выставило AV (Address Valid) — доверяем сразу;
         * иначе полагаемся на общую проверку не-нуля/не-FF. */
        if ((rah & (1u << 31)) || e1000_mac_valid(m)) {
            memcpy(g_e1000.mac, m, 6);
            serial_puts_local("[e1000] MAC read from RAL/RAH\n");
            return 1;
        }
    }

    /* Способ 2: чтение из EEPROM через EERD (legacy 82540EM mode). */
    u16 words[3];
    int ok = 1;
    for (int i = 0; i < 3; i++) {
        if (!e1000_eeprom_read((u8)i, &words[i])) {
            ok = 0;
            break;
        }
    }
    if (ok) {
        g_e1000.mac[0] = (u8)(words[0] & 0xFF);
        g_e1000.mac[1] = (u8)((words[0] >> 8) & 0xFF);
        g_e1000.mac[2] = (u8)(words[1] & 0xFF);
        g_e1000.mac[3] = (u8)((words[1] >> 8) & 0xFF);
        g_e1000.mac[4] = (u8)(words[2] & 0xFF);
        g_e1000.mac[5] = (u8)((words[2] >> 8) & 0xFF);
        if (e1000_mac_valid(g_e1000.mac)) {
            serial_puts_local("[e1000] MAC read from EEPROM\n");
            return 1;
        }
    }
    return 0;
}

/* ---------- Программирование MAC-фильтра (RAL/RAH 0) ---------- */
static void e1000_program_mac(void)
{
    u32 ral = ((u32)g_e1000.mac[0])
            | ((u32)g_e1000.mac[1] << 8)
            | ((u32)g_e1000.mac[2] << 16)
            | ((u32)g_e1000.mac[3] << 24);
    u32 rah = ((u32)g_e1000.mac[4])
            | ((u32)g_e1000.mac[5] << 8)
            | (1u << 31);  /* AV bit — Address Valid */
    e1000_write(E1000_RAL, ral);
    e1000_write(E1000_RAH, rah);

    /* Очистим MTA (multicast) — 128 записей по 4 байта */
    for (int i = 0; i < 128; i++) {
        e1000_write(E1000_MTA + i * 4, 0);
    }
}

/* ---------- Публичный API ---------- */

int e1000_init(void)
{
    g_e1000.present = 0;
    g_e1000.mmio_base = 0;

    serial_puts_local("[e1000] init...\n");

    u16 dev_id = 0;
    if (!e1000_find_device(&dev_id)) {
        serial_puts_local("[e1000] no Intel NIC found\n");
        return 0;
    }

    /* Считаем BAR0 (MMIO base).
     * FIX (аудит): раньше адрес брался вслепую. Теперь проверяем:
     *  - бит 0 = 1 → это I/O-порт BAR, а не память — отказ;
     *  - биты 2:1 = 10 → 64-битный BAR — читаем старшую половину
     *    (при ненулевой — отказ: ядро 32-битное);
     *  - нулевой адрес — отказ. */
    u32 bar0 = pci_read32(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x10);
    if (bar0 & 1) {
        serial_puts_local("[e1000] BAR0 — I/O-порты, а не MMIO: отказ\n");
        return 0;
    }
    if (((bar0 >> 1) & 3) == 2) {
        u32 hi = pci_read32(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x14);
        if (hi) {
            serial_puts_local("[e1000] BAR0 выше 4 ГиБ — не поддерживаем\n");
            return 0;
        }
    }
    g_e1000.mmio_base = bar0 & 0xFFFFFFF0u;
    if (!g_e1000.mmio_base) {
        serial_puts_local("[e1000] BAR0 нулевой — отказ\n");
        return 0;
    }

    /* Включаем Bus Master + Memory Space */
    u16 cmd = pci_read16(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x04);
    cmd |= 0x06;   /* BME | MSE */
    pci_write16(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x04, cmd);

    /* Имя чипа (СЕССИЯ 15: различаем E1000E — у него свои требования) */
    if (dev_id == 0x10D3 || dev_id == 0x10A0)
        snprintf(g_e1000.chip_name, sizeof(g_e1000.chip_name),
                 "Intel 82574 E1000E (dev %04x)", (unsigned)dev_id);
    else
        snprintf(g_e1000.chip_name, sizeof(g_e1000.chip_name),
                 "Intel 8254x (dev %04x)", (unsigned)dev_id);

    serial_puts_local("[e1000] found device=0x");
    {
        char buf[16];
        const char *h = "0123456789abcdef";
        buf[0]=h[(dev_id>>12)&0xF]; buf[1]=h[(dev_id>>8)&0xF];
        buf[2]=h[(dev_id>>4)&0xF];  buf[3]=h[dev_id&0xF];
        buf[4]=0;
        serial_puts_local(buf);
        serial_puts_local(" mmio=0x");
        serial_puthex_local(g_e1000.mmio_base);
        serial_puts_local("\n");
    }

    /* СЕССИЯ 15: MAC ДО сброса — BIOS/гипервизор мог запрограммировать
     * RAL/RAH (VMware делает это всегда); global reset на некоторых
     * реализациях их стирает. Сохранённое значение используем как
     * резерв при отказе EEPROM. */
    u8 mac_prereset[6] = {0};
    {
        u32 ral = e1000_read(E1000_RAL);
        u32 rah = e1000_read(E1000_RAH);
        mac_prereset[0] = (u8)(ral & 0xFF);
        mac_prereset[1] = (u8)((ral >> 8) & 0xFF);
        mac_prereset[2] = (u8)((ral >> 16) & 0xFF);
        mac_prereset[3] = (u8)((ral >> 24) & 0xFF);
        mac_prereset[4] = (u8)(rah & 0xFF);
        mac_prereset[5] = (u8)((rah >> 8) & 0xFF);
    }

    /* Сброс */
    serial_puts_local("[e1000] resetting chip...\n");
    e1000_reset();

    /* Отключаем все прерывания (мы работаем в polling) */
    e1000_write(E1000_IMC, 0xFFFFFFFFu);

    /* Установим SLU */
    {
        u32 c = e1000_read(E1000_CTRL);
        c |= CTRL_SLU;
        e1000_write(E1000_CTRL, c);
    }

    /* Чтение MAC: RAL/RAH (после сброса) → EEPROM → RAL/RAH до сброса.
     * СЕССИЯ 15: НЕ подставляем MAC от QEMU (52:54:00:...) — на
     * VMware это ЧУЖОЙ адрес: в режиме моста виртуальный коммутатор
     * режет кадры с посторонним source-MAC (анти-спуфинг), и DHCP
     * не отвечает даже в NAT. Остающееся решение — локально
     * администрируемый адрес (02:...) при полном отказе всех путей. */
    if (!e1000_read_mac()) {
        /* попытка №3: MAC, прочитанный ДО сброса (BIOS/гипервизор) */
        int ok = 0;
        int all_zero = 1, all_ff = 1;
        for (int i = 0; i < 6; i++) {
            if (mac_prereset[i] != 0) all_zero = 0;
            if (mac_prereset[i] != 0xFF) all_ff = 0;
        }
        if (!all_zero && !all_ff) {
            memcpy(g_e1000.mac, mac_prereset, 6);
            ok = 1;
            serial_puts_local("[e1000] MAC восстановлен из RAL/RAH (до сброса)\n");
        }
        if (!ok) {
            /* локально-администрируемый MAC (не конфликтует ни с кем):
             * 02:xx:xx:xx:xx:xx из таймера — работает в NAT/host-only;
             * в мосте зависит от настроек коммутатора. */
            u32 t = timer_ticks();
            g_e1000.mac[0] = 0x02;
            g_e1000.mac[1] = (u8)(t >> 24);
            g_e1000.mac[2] = (u8)(t >> 16);
            g_e1000.mac[3] = (u8)(t >> 8);
            g_e1000.mac[4] = (u8)t;
            g_e1000.mac[5] = (u8)(t >> 3);
            serial_puts_local("[e1000] ВНИМАНИЕ: MAC не найден, назначен локальный 02:..\n");
        }
    }

    serial_puts_local("[e1000] MAC: ");
    {
        const char *h = "0123456789abcdef";
        for (int i = 0; i < 6; i++) {
            serial_putc_local(h[(g_e1000.mac[i] >> 4) & 0xF]);
            serial_putc_local(h[g_e1000.mac[i] & 0xF]);
            if (i < 5) serial_putc_local(':');
        }
        serial_puts_local("\n");
    }

    /* Программируем MAC в RAL/RAH */
    e1000_program_mac();

    /* Настройка TX и RX колец */
    e1000_setup_tx();
    e1000_setup_rx();

    /* СЕССИЯ 15: для 82574+ (E1000E в VMware) — ВКЛЮЧИТЬ очереди
     * RXDCTL/TXDCTL битом ENABLE ПОСЛЕ настройки колец (без этого
     * дескрипторы не обрабатываются: «шлём запросы — ответов нет»). */
    e1000_enable_queues(dev_id);

    /* Подождём установки линка — до 3 с реального времени (сессия 14;
     * было 2000000 MMIO-читений: на VMware это ДО 6 СЕКУНД блокировки
     * загрузки). Дальше линк проверяет netmon через e1000_link_up()
     * (живое чтение STATUS.LU) — контроллер сам поднимет LU, когда PHY
     * договорится; netmon дождётся и запустит DHCP только при готовом
     * линке. */
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            if (e1000_read(E1000_STATUS) & STATUS_LU) break;
            if (timer_poll_expired(dl, 3000000)) break;
        }
    }
    u32 status = e1000_read(E1000_STATUS);
    serial_puts_local("[e1000] status: 0x");
    serial_puthex_local(status);
    serial_puts_local(status & STATUS_LU ? " (link up)\n" : " (link ещё не поднят — netmon дождётся)\n");

    g_e1000.present = 1;
    serial_puts_local("[e1000] ready\n");
    return 1;
}

/* Сессия 14: живой опрос линка для netmon (см. комментарий в e1000.h). */
int e1000_link_up(void)
{
    if (!g_e1000.present) return 0;
    return (e1000_read(E1000_STATUS) & STATUS_LU) ? 1 : 0;
}

int e1000_present(void)
{
    return g_e1000.present;
}

const char *e1000_chip_name(void)
{
    return g_e1000.chip_name[0] ? g_e1000.chip_name : "no NIC";
}

int e1000_get_mac(u8 out_mac[6])
{
    if (!g_e1000.present) return 0;
    memcpy(out_mac, g_e1000.mac, 6);
    return 1;
}

void e1000_set_dest_mac(const u8 mac[6])
{
    (void)mac;
    /* сейчас используется promiscuous + broadcast — заглушка */
}

/* ---------- Отправка пакета ---------- */
int e1000_send(const void *buf, u32 len)
{
    if (!g_e1000.present) return -1;
    if (len == 0 || len > E1000_PKT_MAX) return -1;

    /* Проверим, есть ли свободный дескриптор */
    u32 head = e1000_read(E1000_TDH);
    u32 tail = g_e1000.tx_tail;
    u32 next = (tail + 1) % E1000_TX_COUNT;
    if (next == head) {
        /* Кольцо заполнено — ждём ПО РЕАЛЬНОМУ ВРЕМЕНИ (FIX аудита:
         * прежние 1000 итераций MMIO-чтений зависели от скорости шины;
         * дедлайн 10 мс предсказуем и не даёт NIC-подвесу заморозить
         * систему надолго) */
        u32 dl = timer_poll_deadline();
        for (;;) {
            head = e1000_read(E1000_TDH);
            if (next != head) break;
            if (timer_poll_expired(dl, 10000)) return -1;
        }
    }

    /* Копируем данные в наш буфер (статический — валиден всегда) */
    u8 *tbuf = g_e1000.tx_bufs[tail];
    /* СЕССИЯ 15 (диагностика): если ЖЕЛЕЗО подтвердило прошлый кадр
     * с этого дескриптора (DD) — посчитаем. Если tx_hw_done == 0 при
     * растущем tx_requests — очередь TX не работает (типично для
     * 82574 без RXDCTL/TXDCTL ENABLE — см. e1000_enable_queues). */
    if (g_e1000.tx_desc[tail].status & RXD_STAT_DD)
        g_e1000.tx_hw_done++;
    g_e1000.tx_requests++;
    memcpy(tbuf, buf, len);
    /* Если пакет короче 60 байт — дополним нулями (CSMA/CD минимум) */
    if (len < 60) {
        for (u32 i = len; i < 60; i++) tbuf[i] = 0;
        len = 60;
    }

    /* Заполняем дескриптор */
    g_e1000.tx_desc[tail].addr = (u64)(unsigned long)tbuf;
    g_e1000.tx_desc[tail].length = (u16)len;
    g_e1000.tx_desc[tail].csum = 0;
    g_e1000.tx_desc[tail].status = 0;
    g_e1000.tx_desc[tail].errors = 0;
    g_e1000.tx_desc[tail].special = 0;

    /* FIX [E1] (e1000 TX НИКОГДА не работал в QEMU/на железе):
     * команда legacy TX-дескриптора лежит в байте 11 — это СТАРШИЙ байт
     * поля csum (u16 @10). Раньше биты EOP|IFCS|RS писались в special
     * (байты 14-15 — туда их никто не читает): эмулятор видел cmd=0,
     * без EOP пакет навсегда оставался в буфере — НИ ОДИН кадр не
     * уходил в сеть (RDH не двигался, ping молчал, браузер — тем более).
     * Правильно: cmd в байте 11 = csum = cmd << 8. */
    g_e1000.tx_desc[tail].csum = (u16)((TXD_CMD_EOP | TXD_CMD_IFCS | TXD_CMD_RS) << 8);

    /* Барьер: дескриптор и данные должны дойти до памяти ДО записи TDT */
    dma_wmb();

    /* Уведомляем чип: продвигаем tail */
    g_e1000.tx_tail = next;
    e1000_write(E1000_TDT, g_e1000.tx_tail);

    return (int)len;
}

/* ---------- Приём пакета ----------
 * FIX (аудит): ориентируемся на бит DD дескриптора [rx_tail], а не на
 * RDH: NIC выставляет DD ПОСЛЕ записи пакета в буфер; в части
 * реализаций/эмуляторов RDH отстаёт или трактуется иначе — проверка
 * только DD надёжнее и ловит пакет сразу, как он готов. Кольцо пусто
 * ⇔ DD на [rx_tail] сброшен (мы сами чистим status при возврате
 * дескриптора). Возвращает РЕАЛЬНО скопированное число байт (прежде
 * возвращалась длина пакета даже при усечении — вызывающий читал
 * за пределами своего буфера). */
u32 e1000_recv(void *out_buf, u32 out_max)
{
    if (!g_e1000.present || !out_buf || out_max == 0) return 0;

    u32 tail = g_e1000.rx_tail;
    e1000_desc_t *d = &g_e1000.rx_desc[tail];
    if (!(d->status & RXD_STAT_DD)) return 0;   /* пакет ещё не готов */

    u32 len = d->length;
    if (len > E1000_PKT_MAX) len = E1000_PKT_MAX;
    u32 copy = (len < out_max) ? len : out_max;

    dma_rmb();   /* данные буфера — после проверки статуса дескриптора */
    memcpy(out_buf, g_e1000.rx_bufs[tail], copy);

    /* Возвращаем дескриптор в пул */
    d->status = 0;
    d->errors = 0;
    d->length = (u16)sizeof(g_e1000.rx_bufs[tail]);
    d->special = 0;
    g_e1000.rx_tail = (tail + 1) % E1000_RX_COUNT;
    dma_wmb();   /* очистка статуса — раньше записи RDT */
    /* RDT = индекс только что освобождённого дескриптора (модель
     * кольца описана в e1000_setup_rx) */
    e1000_write(E1000_RDT, tail);

    return copy;
}

/* ---------- Polling: проверим наличие пакетов ---------- */
void e1000_poll(void)
{
    /*Polling делается через e1000_recv из главного цикла/стека.
     * Здесь мы только пинаем чип, проверяя состояние ICR (если захотим прерывания). */
    (void)0;
}

/* Отладочный дамп состояния NIC в serial.
 * СЕССИЯ 15: + device id, RXDCTL/TXDCTL (очереди 82574), ICR,
 * счётчики подтверждений TX (tx_hw_done) — ключевая диагностика
 * «шлём запросы, ответов нет» на VMware. */
void e1000_debug_dump(void)
{
    serial_puts_local("[e1000] debug dump:\n");
    serial_puts_local("  STATUS = "); serial_puthex_local(e1000_read(E1000_STATUS));
    serial_puts_local("\n  RCTL   = "); serial_puthex_local(e1000_read(E1000_RCTL));
    serial_puts_local("\n  CTRL   = "); serial_puthex_local(e1000_read(E1000_CTRL));
    serial_puts_local("\n  RAL/RAH= "); serial_puthex_local(e1000_read(E1000_RAL));
    serial_puts_local("/"); serial_puthex_local(e1000_read(E1000_RAH));
    serial_puts_local("\n  RDH    = "); serial_puthex_local(e1000_read(E1000_RDH));
    serial_puts_local("\n  RDT    = "); serial_puthex_local(e1000_read(E1000_RDT));
    serial_puts_local("\n  RDBAL  = "); serial_puthex_local(e1000_read(E1000_RDBAL));
    serial_puts_local("\n  RDLEN  = "); serial_puthex_local(e1000_read(E1000_RDLEN));
    serial_puts_local("\n  RXDCTL = "); serial_puthex_local(e1000_read(E1000_RXDCTL0));
    serial_puts_local("\n  TXDCTL = "); serial_puthex_local(e1000_read(E1000_TXDCTL0));
    serial_puts_local("\n  ICR    = "); serial_puthex_local(e1000_read(E1000_ICR));
    serial_puts_local("\n  sw.rx_tail = "); serial_puthex_local(g_e1000.rx_tail);
    serial_puts_local("\n  TX: req="); serial_puthex_local(g_e1000.tx_requests);
    serial_puts_local(" hw_done="); serial_puthex_local(g_e1000.tx_hw_done);
    serial_puts_local(g_e1000.tx_requests && !g_e1000.tx_hw_done
                      ? "  (!!! очередь TX не подтверждает кадры)" : "");
    serial_puts_local("\n  desc[0]: addr="); serial_puthex_local((u32)(unsigned long)g_e1000.rx_desc[0].addr);
    serial_puts_local(" status="); serial_puthex_local(g_e1000.rx_desc[0].status);
    serial_puts_local(" len="); serial_puthex_local(g_e1000.rx_desc[0].length);
    serial_puts_local("\n  desc[1]: status="); serial_puthex_local(g_e1000.rx_desc[1].status);
    serial_puts_local("\n  TCTL   = "); serial_puthex_local(e1000_read(E1000_TCTL));
    serial_puts_local("\n  TDH    = "); serial_puthex_local(e1000_read(E1000_TDH));
    serial_puts_local("  TDT    = "); serial_puthex_local(e1000_read(E1000_TDT));
    serial_puts_local("\n");
}
