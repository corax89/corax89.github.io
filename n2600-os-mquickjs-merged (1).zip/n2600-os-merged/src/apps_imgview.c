/* apps_imgview.c — просмотрщик изображений N2600-OS (сессия 60).
 *
 * Компактный просмотрщик на СУЩЕСТВУЮЩЕЙ библиотеке ОС: декодирование —
 * imgsvc (stb_image: PNG/JPEG/BMP/GIF, см. imgsvc.h), отрисовка —
 * fb_blit_rgba (целочисленный nearest-neighbor, безопасен в любом
 * потоке). Режимы: «вписать» (билинейное img_scale, кэш масштаба) и
 * «1:1» (Space переключает).
 *
 * Открытие: файловый менеджер → двойной клик по .png/.jpg/.jpeg/.bmp/.gif
 * — app_imgview_open_with(имя, данные, длина) с ПЕРЕДАЧЕЙ ВЛАДЕНИЯ
 * буфером (просмотрщик сам его освобождает). Из лаунчера — подсказка. */
#include "types.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "apps.h"
#include "imgsvc.h"
#include "kbd.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

typedef struct {
    char   name[64];
    char  *data;          /* файл (владелец — просмотрщик) */
    u32    len;
    img_t  img;           /* декодированная картинка (rgba malloc) */
    int    ok;            /* 1 = декодировано */
    int    fit;           /* 1 = вписать в окно, 0 = 1:1 */
    img_t  sc;            /* кэш масштабированной копии */
    int    sc_w, sc_h;    /* размер кэша (0 = кэша нет) */
} iv_t;

/* вычислить целевые размеры показа */
static void iv_target(const iv_t *v, int cw, int ch, int *dw, int *dh)
{
    *dw = (int)v->img.w;
    *dh = (int)v->img.h;
    if (!v->fit || v->img.w == 0 || v->img.h == 0) return;
    /* вписать с сохранением пропорций; мельче 1:1 не увеличиваем */
    if (*dw <= cw - 8 && *dh <= ch - 8) return;      /* и так влезает */
    int aw = cw - 8, ah = ch - 24;
    u64 k1 = ((u64)aw * 1000u) / (u32)v->img.w;
    u64 k2 = ((u64)ah * 1000u) / (u32)v->img.h;
    u64 k  = (k1 < k2) ? k1 : k2;
    if (k >= 1000u) return;                          /* влезает 1:1 */
    *dw = (int)(((u64)v->img.w * k) / 1000u);
    *dh = (int)(((u64)v->img.h * k) / 1000u);
    if (*dw < 1) *dw = 1;
    if (*dh < 1) *dh = 1;
}

static void iv_draw(window_t *w)
{
    iv_t *v = (iv_t *)w->data;
    if (!v) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, wm_theme_win_bg());

    if (!v->ok) {
        fb_text(10, 10, "Не удалось показать картинку:", wm_theme_text(), -1);
        fb_text(10, 30, img_errstr(), fb_rgb(0xE0, 0x9A, 0x9A), -1);
        return;
    }

    int dw, dh;
    iv_target(v, cw, ch, &dw, &dh);

    /* масштабированная копия (кэш: перерасчёт только при смене размера) */
    if ((dw != v->img.w || dh != v->img.h) &&
        (dw != v->sc_w || dh != v->sc_h)) {
        if (v->sc.rgba) { img_dispose(&v->sc); memset(&v->sc, 0, sizeof(v->sc)); }
        if (img_scale(&v->img, dw, dh, &v->sc) == 0) {
            v->sc_w = dw;
            v->sc_h = dh;
        } else {
            v->sc_w = v->sc_h = 0;   /* не вышло — покажем 1:1 */
        }
    }

    const u8 *rgba = v->img.rgba;
    int sw = (int)v->img.w, sh = (int)v->img.h;
    if (v->sc.rgba && dw != v->img.w) {
        rgba = v->sc.rgba;
        sw = v->sc_w;
        sh = v->sc_h;
    }
    int dx = (cw - sw) / 2, dy = (ch - 16 - sh) / 2;
    if (dx < 0) dx = 0;
    if (dy < 0) dy = 0;
    if (rgba) fb_blit_rgba(rgba, sw, sh, dx, dy, sw, sh);

    /* статусная строка */
    char st[128];
    if (sw == (int)v->img.w && sh == (int)v->img.h)
        snprintf(st, sizeof(st), "%u x %u — 1:1 (Space — вписать)",
                 v->img.w, v->img.h);
    else
        snprintf(st, sizeof(st), "%u x %u — показ %d x %d (Space — 1:1)",
                 v->img.w, v->img.h, sw, sh);
    fb_text(8, ch - 15, st, wm_theme_text_dim(), -1);
}

static void iv_key(window_t *w, const key_event_t *ev)
{
    iv_t *v = (iv_t *)w->data;
    if (!v) return;
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == 0x39) {                     /* Space: fit / 1:1 */
        v->fit = !v->fit;
        if (v->sc.rgba) { img_dispose(&v->sc); memset(&v->sc, 0, sizeof(v->sc)); }
        v->sc_w = v->sc_h = 0;
        win_invalidate(w);
    }
}

static void iv_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    (void)w; (void)mx; (void)my; (void)btn;
    (void)changed;
    /* компактная версия: мышь не используется */
}

static void iv_close(window_t *w)
{
    iv_t *v = (iv_t *)w->data;
    if (!v) return;
    if (v->sc.rgba) img_dispose(&v->sc);
    if (v->ok && v->img.rgba) img_dispose(&v->img);
    if (v->data) free(v->data);
    free(v);
}

/* Открыть картинку из памяти (владение буфером data переходит
 * просмотрщику). Форматы: PNG/JPEG/BMP/GIF (imgsvc/stb_image). */
void app_imgview_open_with(const char *name, const char *data, u32 len)
{
    if (!data || len == 0) {
        if (data) free((void *)data);
        app_outwin_open("Просмотр", "Файл пуст.\n", 11);
        return;
    }

    iv_t *v = (iv_t *)malloc(sizeof(iv_t));
    if (!v) { free((void *)data); return; }
    memset(v, 0, sizeof(iv_t));

    if (name && name[0]) {
        strncpy(v->name, name, sizeof(v->name) - 1);
        v->name[sizeof(v->name) - 1] = 0;
    } else {
        strcpy(v->name, "image");
    }
    v->data = (char *)data;      /* владение буфером — у просмотрщика */
    v->len = len;
    v->fit = 1;

    v->ok = (img_decode_mem((const u8 *)data, len, &v->img) == 0);

    u32 W = fb_width(), H = fb_height();
    int ww = (int)W * 3 / 4, wh = (int)H * 3 / 4;
    if (v->ok) {
        /* окно чуть больше картинки, но не больше 3/4 экрана */
        int iw = (int)v->img.w + 24, ih = (int)v->img.h + 56;
        if (iw > ww) iw = ww;
        if (ih > wh) ih = wh;
        if (iw < 320) iw = 320;
        if (ih < 240) ih = 240;
        ww = iw;
        wh = ih;
    }
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - 28) wh = (int)H - 28;

    char title[80];
    if (v->ok)
        snprintf(title, sizeof(title), "Картинка: %s (%u x %u)",
                 v->name, v->img.w, v->img.h);
    else
        snprintf(title, sizeof(title), "Картинка: %s", v->name);

    win_create(title, 60, 40, ww, wh,
               iv_draw, iv_key, iv_mouse, NULL, iv_close, v);
}

/* Из лаунчера: подсказка. */
void app_imgview_open(void)
{
    const char *msg =
        "Просмотрщик изображений N2600-OS (stb_image).\n\n"
        "Откройте .png/.jpg/.jpeg/.bmp/.gif двойным кликом\n"
        "в приложении «Файлы» (RAM disk / HDD / USB / CD).\n"
        "Управление: Space — «вписать»/«1:1», Esc — закрыть.\n";
    app_outwin_open("Просмотр", msg, (u32)strlen(msg));
}
