/* sync.h — мини-блокировки для многозадачного ядра (без зависимостей).
 *
 * FIX (зависший процесс вешает систему): блокировки теперь ХРАНЯТ ВЛАДЕЛЬЦА.
 * Значение блокировки: 0 = свободна, N>0 = владелец — задача N-1.
 *
 * Два сценария, которые раньше намертво фризили всю ОС:
 *
 *  1. УБИЙСТВО ДЕРЖАТЕЛЯ. task_kill (диспетчер задач, команда kill) и
 *     ватчдог помечают задачу finished в ПРОИЗВОЛЬНОЙ точке исполнения —
 *     в том числе внутри критической секции (между s_lock и s_unlock).
 *     Блокировка оставалась захваченной навсегда. Дальше: kmain берёт её
 *     (composite -> wm_glock каждый кадр; wm_key -> qlock окна) и крутится
 *     в цикле ожидания ВЕЧНО — а kmain делает всё: мышь, клавиатура,
 *     композитинг, опрос сети. Итог: полное зависание системы от одного
 *     зависшего/убитого процесса. Теперь ждущий видит, что владелец мёртв
 *     (task_finished), принудительно освобождает блокировку и продолжает.
 *
 *  2. ЗАВИСАНИЕ ДЕРЖАТЕЛЯ ВНУТРИ СЕКЦИИ. Задача зависла (бесконечный
 *     цикл) в критической секции — жива, но никогда не отпустит.
 *     Ватчдог её не видит (она исправно получает слоты round-robin).
 *     Теперь ждущий держит счётчик ожидания: если владелец жив, но не
 *     отпускает блокировку дольше SLOCK_STALE_TICKS (20 с) — блокировка
 *     освобождается принудительно (с громким предупреждением в serial).
 *
 * s_unlock отпускает ТОЛЬКО СВОЮ блокировку (сверяет владельца):
 * поздний unlock задачи, у которой блокировку отобрали по таймауту,
 * не сбивает захват нового владельца.
 *
 * Использование: volatile int mylock = 0; в модуле,
 *   s_lock(&mylock); ... s_unlock(&mylock);
 * Критическая секция держателя прерываема (IF восстановлен) — можно
 * держать долго (дисковый I/O, HTTP-транзакция); конкурент спит (hlt).
 */
#ifndef SYNC_H
#define SYNC_H

#include "types.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
/* ======== хост-сборки (тесты движка/моста на Linux): однопоточные
 * заглушки вместо cli/sti-спинлоков и зависимостей task.h.
 * Ядро N2600-OS собирается с -ffreestanding и идёт полной веткой.
 * Тест моста (test_mqjs_host.c) определяет MQJS_HOST_TASK_STUBS_EXTERN:
 * тогда task_current/task_finished берутся ВНЕШНИМИ — тест эмулирует
 * смерть задач (самолечение REPL после ватчдога/kill). ======== */
#ifdef MQJS_HOST_TASK_STUBS_EXTERN
extern int task_current(void);
extern int task_finished(int t);
#else
static inline int task_current(void) { return 0; }
static inline int task_finished(int t) { (void)t; return 0; }
#endif
static inline void task_set_lockwait_me(int v) { (void)v; }
static inline void s_lock(volatile int *l) { (void)l; __asm__ __volatile__("" ::: "memory"); }
static inline void s_unlock(volatile int *l) { (void)l; __asm__ __volatile__("" ::: "memory"); }
static inline int s_trylock(volatile int *l) { (void)l; return 1; }
extern void serial_puts(const char *s);

#else /* --- ядро N2600-OS: полная реализация --- */

#include "task.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* Сколько тиков (1 тик = 10 мс) ждать живого, но не отпускающего
 * блокировку владельца, прежде чем отобрать её силой. 2000 = 20 с:
 * с запасом дольше самой долгой легитимной секции (HTTP-таймаут 12 с,
 * FAT32-чтение и компиляция c4 — доли секунды..секунды). */
#define SLOCK_STALE_TICKS 2000

/* Значение блокировки = владелец + 1 (0 = свободна). Задача 0 (kmain)
 * кодируется как 1 — блокировки совместимы со старым смыслом «1 = занято». */
static inline int slock_owner_of(int v)
{
    return v > 0 ? v - 1 : -1;
}

static inline void s_unlock(volatile int *l)
{
    /* Отпускаем только СВОЙ захват: если блокировку уже отобрали
     * (мы зависли >20 с внутри секции), поздний unlock не должен
     * сбить захват нового владельца. */
    int me = task_current() + 1;
    if (*l == me) *l = 0;
    __asm__ __volatile__("" ::: "memory");
}

static inline void s_lock(volatile int *l)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (*l == 0) {
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return;
    }
    /* СЕССИЯ 68: ПОВТОРНЫЙ захват СВОЕЙ блокировки (reentrancy).
     * Раньше задача ждала 20 с, ОТБИРАЛА блокировку у самой себя и
     * продолжала — два «входа» в нереентерабельную секцию одной задачей
     * (глобальные буферы транзакции, связные списки) = порча кучи.
     * Теперь: громкая диагностика ОДИН раз на блокировку и немедленный
     * вход (владелец — мы сами; чужих в секции нет). */
    if (slock_owner_of((int)*l) == task_current()) {
        static volatile int reentr_reported = 0;
        if (!reentr_reported) {
            reentr_reported = 1;
            serial_puts("[sync] s_lock: ПОВТОРНЫЙ вход той же задачи — "
                        "реентерабельность, проверить вызывающего!\n");
        }
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return;
    }
    /* занято: ждём (прерываемо), контролируя состояние владельца */
    {
        u32 wait_start = 0;
        int  timed = 0;
        /* ВАЖНО (ватчдог): помечаем себя как «жду блокировку» — ватчдог
         * НЕ убивает такие задачи (ими управляет SLOCK_STALE_TICKS ниже).
         * Без этого ватчдог выкашивал ждущие окна через 5 с, ещё до
         * отбора блокировки у зависшего держателя. Мы под cli — атомарно. */
        task_set_lockwait_me(1);
        while (*l) {
            int owner = slock_owner_of((int)*l);
            if (owner >= 1 && task_finished(owner)) {
                /* владелец УБИТ, держа блокировку — освобождаем силой */
                serial_puts("[sync] блокировка освобождена: владелец-задача мёртв\n");
                *l = 0;
                break;
            }
            if (owner >= 1 && !timed) {
                wait_start = timer_ticks();
                timed = 1;
            } else if (owner >= 1 && timed &&
                       timer_ticks() - wait_start > SLOCK_STALE_TICKS) {
                /* владелец жив, но завис внутри секции >20 с — отбираем */
                serial_puts("[sync] блокировка отобрана: владелец завис >20 c\n");
                *l = 0;
                break;
            }
            /* впускаем прерывания и спим до тика (ожидающий не жжёт CPU;
             * планировщик продолжает переключать задачи) */
            __asm__ __volatile__("sti\n\thlt" ::: "memory");
            __asm__ __volatile__("cli" ::: "memory");
        }
        task_set_lockwait_me(0);
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Попытка захвата без ожидания. Тоже чинит мёртвого владельца:
 * без этого trylock ПОСТОЯННО отказывал бы на блокировке, утёкшей
 * с убитой задачей (окно навсегда оставалось бы с заглушкой кадра). */
static inline int s_trylock(volatile int *l)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (*l == 0) {
        *l = task_current() + 1;
        __asm__ __volatile__("" ::: "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return 1;
    }
    {
        int owner = slock_owner_of((int)*l);
        if (owner >= 1 && task_finished(owner)) {
            serial_puts("[sync] trylock: освобождена мёртвым владельцем\n");
            *l = task_current() + 1;
            __asm__ __volatile__("" ::: "memory");
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            return 1;
        }
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return 0;
}

#endif /* hosted */

#endif /* SYNC_H */
