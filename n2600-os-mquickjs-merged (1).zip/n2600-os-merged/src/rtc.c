/* rtc.c — чтение времени из CMOS RTC (порты 0x70/0x71) */
#include "rtc.h"
#include "io.h"

static u8 cmos_read(u8 reg)
{
    outb(0x70, reg);
    return inb(0x71);
}

static int rtc_updating(void)
{
    outb(0x70, 0x0A);
    return inb(0x71) & 0x80;
}

static u8 bcd2bin(u8 v) { return (u8)((v & 0x0F) + (v >> 4) * 10); }

void rtc_get_time(int *hours, int *mins, int *secs)
{
    u32 guard = 1000000;
    while (rtc_updating() && --guard) {}

    u8 s  = cmos_read(0x00);
    u8 m  = cmos_read(0x02);
    u8 h  = cmos_read(0x04);
    u8 rb = cmos_read(0x0B);

    if (!(rb & 0x04)) {         /* BCD -> двоичное */
        s = bcd2bin(s);
        m = bcd2bin(m);
        h = bcd2bin(h);
    }
    if (!(rb & 0x02) && (h & 0x80)) {  /* 12-часовой формат */
        h = (u8)((h & 0x7F) % 12);
        h += 12; /* PM */
    }
    if (secs) *secs = s;
    if (mins) *mins = m;
    if (hours) *hours = h;
}

int rtc_get_date(int *year, int *month, int *day)
{
    u32 guard = 1000000;
    while (rtc_updating() && --guard) {}
    if (!guard) return 0;

    u8 d  = cmos_read(0x07);   /* день месяца */
    u8 mo = cmos_read(0x08);   /* месяц */
    u8 y  = cmos_read(0x09);   /* год (две цифры) */
    u8 c  = cmos_read(0x32);   /* век (есть не везде) */
    u8 rb = cmos_read(0x0B);

    if (!(rb & 0x04)) {        /* BCD -> двоичное */
        d  = bcd2bin(d);
        mo = bcd2bin(mo);
        y  = bcd2bin(y);
        c  = bcd2bin(c);
    }

    int full;
    if (c >= 19 && c <= 21) {
        full = (int)c * 100 + (int)y;
    } else {
        /* century-регистра нет (0 или мусор) — эвристика BIOS */
        full = (y >= 70) ? (1900 + (int)y) : (2000 + (int)y);
    }

    if (year)  *year  = full;
    if (month) *month = mo;
    if (day)   *day   = d;
    return 1;
}
