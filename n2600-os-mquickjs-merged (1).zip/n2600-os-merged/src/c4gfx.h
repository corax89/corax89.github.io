/* c4gfx.h — окно графики для c4-программ (kfill/ktext/kflip/kclear).
 *
 * Многопоточный WM владеет экраном: прямая запись c4-программы на экран
 * стирается композитором. Модуль даёт каждой c4-программе (VM F9 и
 * native .bin) ленивое окно с canvas, подключённым к задаче программы.
 */
#ifndef C4GFX_H
#define C4GFX_H

#include "types.h"

struct window;

/* Задать имя программы для заголовка окна (вызывает loader/editor
 * ДО запуска; хранится по текущей задаче). */
void c4_gfx_set_name(const char *name);

/* Создать окно, если ещё нет (вызывается неявно из обёрток примитивов
 * при первом графическом вызове). */
void c4_gfx_ensure(void);

/* Отсоединить canvas от задачи ПОСЛЕ завершения программы (память
 * остаётся у окна — последний кадр виден). */
void c4_gfx_detach(void);

/* Обёртки примитивов: ensure + настоящий примитив. */
void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c);
void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg);
void c4_gfx_fill_screen(u32 c);
u32  c4_gfx_width(void);
u32  c4_gfx_height(void);

/* kflip(): отметить область окна (композитор выведет canvas на экран).
 * Семантика win_invalidate(window_t*). */
void c4_gfx_flip(struct window *unused);

/* kevent(): 0=нет, 1=клавиша (out[0]=ch,[1]=code,[2]=flags), 3=Esc. */
int  c4_gfx_event_poll(void *out_buf);

#endif /* C4GFX_H */
