/* gdt.c — GDT: ядро (flat) + ПЕСПОЧНИЦЫ ЗАДАЧ.
 *
 * Защита памяти (flat-модель без MMU): каждой задаче, запускающей
 * нативный код (C4-бинарники), выделяется дескриптор сегмента данных
 * [base .. base+limit]. Задача работает с DS/ES/SS = свой селектор —
 * дикая запись за пределы региона даёт #GP: приложение погибает,
 * ядро и соседние задачи живут (см. loader.c: sandbox_call).
 *
 * Селекторы: 0x08 — код ядра, 0x10 — данные ядра (4 ГБ),
 *            0x18 + tid*8 — сегмент задачи tid (если назначен).
 */
#include "gdt.h"
#include "types.h"
#include "task.h"

/* Структура дескриптора GDT (ровно 8 байт) */
typedef struct {
    u16 limit_low;
    u16 base_low;
    u8  base_middle;
    u8  access;
    u8  granularity;
    u8  base_high;
} __attribute__((packed)) gdt_entry_t;

/* 3 записи ядра + по одной на каждую возможную задачу */
static gdt_entry_t gdt[3 + MAX_TASKS];

void gdt_init(void)
{
    /* Локальная packed-структура для команды lgdt (защита от выравнивания) */
    struct {
        u16 limit;
        u32 base;
    } __attribute__((packed)) gp;

    gp.limit = (u16)(sizeof(gdt) - 1);
    gp.base  = (u32)(unsigned long)gdt;

    /* 0x00: Null Descriptor */
    gdt[0].limit_low   = 0; gdt[0].base_low    = 0;
    gdt[0].base_middle = 0; gdt[0].access      = 0;
    gdt[0].granularity = 0; gdt[0].base_high   = 0;

    /* 0x08: Kernel Code Segment (Лимит 4 ГБ, 32-бит) */
    gdt[1].limit_low   = 0xFFFF; gdt[1].base_low    = 0;
    gdt[1].base_middle = 0;      gdt[1].access      = 0x9A;
    gdt[1].granularity = 0xCF;   gdt[1].base_high   = 0; /* 0xCF = 4K гранулярность + 32-бит + лимит 0xF */

    /* 0x10: Kernel Data Segment (Лимит 4 ГБ, 32-бит) */
    gdt[2].limit_low   = 0xFFFF; gdt[2].base_low    = 0;
    gdt[2].base_middle = 0;      gdt[2].access      = 0x92;
    gdt[2].granularity = 0xCF;   gdt[2].base_high   = 0;

    /* Сегменты задач — пустые (present=0): заполняются при spawn */
    for (int i = 0; i < MAX_TASKS; i++) {
        gdt[3 + i].limit_low = 0; gdt[3 + i].base_low = 0;
        gdt[3 + i].base_middle = 0; gdt[3 + i].access = 0;
        gdt[3 + i].granularity = 0; gdt[3 + i].base_high = 0;
    }

    /*
     * БЕЗОПАСНАЯ ЗАГРУЗКА GDT И ПЕРЕЗАГРУЗКА СЕГМЕНТОВ:
     * 1. lgdt загружает таблицу.
     * 2. Обновляем регистры данных (DS, ES, FS, GS, SS).
     * 3. Используем pushl + lret вместо ljmp для обновления CS.
     *    Это обходит баги MinGW и гарантирует применение лимита 4 ГБ.
     */
    __asm__ __volatile__(
        "lgdt %0\n\t"             /* Загружаем GDT */
        "mov $0x10, %%ax\n\t"     /* Селектор данных = 0x10 */
        "mov %%ax, %%ds\n\t"
        "mov %%ax, %%es\n\t"
        "mov %%ax, %%fs\n\t"
        "mov %%ax, %%gs\n\t"
        "mov %%ax, %%ss\n\t"
        "pushl $0x08\n\t"         /* Селектор кода = 0x08 в стек */
        "pushl $1f\n\t"           /* Адрес следующей метки в стек */
        "lret\n\t"                /* Дальний возврат: обновляет CS и EIP */
        "1:\n\t"                  /* Метка, куда мы прыгаем */
        :
        : "m"(gp)                 /* Ограничение "m" читает структуру прямо из памяти */
        : "eax", "memory"
    );
}

/* ---------- песочницы задач ---------- */

u16 gdt_task_selector(int tid)
{
    if (tid < 0 || tid >= MAX_TASKS) return 0x10;
    return (u16)(0x18 + tid * 8);
}

int gdt_task_region(int tid, u32 *base, u32 *limit)
{
    if (tid < 0 || tid >= MAX_TASKS) return 0;
    gdt_entry_t *e = &gdt[3 + tid];
    if (!(e->access & 0x80)) return 0;          /* не назначен */
    u32 lim = ((u32)(e->granularity & 0x0F) << 16) | e->limit_low;
    if (e->granularity & 0x80) lim = (lim << 12) | 0xFFF;   /* 4K гранулярность */
    if (base)  *base  = ((u32)e->base_high << 24) |
                        ((u32)e->base_middle << 16) | e->base_low;
    if (limit) *limit = lim;
    return 1;
}

/* Назначить задаче tid сегмент [base, base+size). size округляется
 * вверх до страницы (гранулярность 4K). Кешируемая запись перезагружается
 * при следующем переключении сегмента (задача ещё не запущена). */
void gdt_set_task_region(int tid, u32 base, u32 size)
{
    if (tid < 0 || tid >= MAX_TASKS || size == 0) return;
    u32 pages = (size + 0xFFFu) >> 12;          /* число 4K-страниц */
    if (pages > 0xFFFFFu) pages = 0xFFFFFu;
    u32 lim = pages - 1;                        /* лимит в страницах - 1 */
    gdt_entry_t *e = &gdt[3 + tid];
    e->base_low    = (u16)(base & 0xFFFF);
    e->base_middle = (u8)((base >> 16) & 0xFF);
    e->base_high   = (u8)((base >> 24) & 0xFF);
    e->limit_low   = (u16)(lim & 0xFFFF);
    e->granularity = (u8)(0x80 /* 4K */ | 0x40 /* 32-bit */ |
                          ((lim >> 16) & 0x0F));
    e->access      = 0x92;                      /* present, data, rw, ring0 */
}

void gdt_clear_task_region(int tid)
{
    if (tid < 0 || tid >= MAX_TASKS) return;
    gdt[3 + tid].access = 0;                    /* not present */
}
