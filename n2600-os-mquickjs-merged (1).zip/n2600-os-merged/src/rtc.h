/* rtc.h — часы реального времени (CMOS) */
#ifndef RTC_H
#define RTC_H

void rtc_get_time(int *hours, int *mins, int *secs);

/* Дата CMOS (для TLS: проверка сроков действия сертификатов).
 * year — полный год (например 2026); century-регистр 0x32 учитывается,
 * при его отсутствии/мусоре год выводится из 0x09 (>=70 → 19xx, иначе 20xx).
 * Возвращает 1 при успехе, 0 если CMOS не отвечает (guard). */
int  rtc_get_date(int *year, int *month, int *day);

#endif
