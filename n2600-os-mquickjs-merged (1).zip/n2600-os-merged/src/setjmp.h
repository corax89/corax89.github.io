/* setjmp.h — минимальная freestanding-реализация setjmp/longjmp для ядра
 * N2600-OS (i386).
 *
 * Зачем: MicroQuickJS использует setjmp/longjmp для обработки исключений
 * (mquickjs.c: js_setjmp/js_longjmp через стандартные имена). В
 * freestanding-сборке libc нет, поэтому реализация здесь.
 *
 * Сохраняются callee-saved регистры i386 ABI: ebx, esi, edi, ebp, esp, eip.
 * eax/ecx/edx — caller-saved, после longjmp их значения не определены
 * (это соответствует стандарту C).
 *
 * Используется ТОЛЬКО движком mquickjs (mquickjs.c включает <setjmp.h>,
 * который через -Isrc резолвится в этот файл). */
#ifndef SETJMP_H
#define SETJMP_H

#ifndef __i386__
/* Хост-сборки (тесты движка на Linux x86-64) используют системный
 * <setjmp.h>: этот файл должен перекрываться им через include_next. */
#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include_next <setjmp.h>
#else
#error "setjmp.h: поддерживается только i386 (freestanding) и hosted-сборки"
#endif
#else

typedef int jmp_buf[6];   /* ebx, esi, edi, ebp, esp, eip */

int setjmp(jmp_buf env) __attribute__((returns_twice));
void longjmp(jmp_buf env, int val) __attribute__((noreturn));

#endif /* __i386__ */

#endif /* SETJMP_H */
