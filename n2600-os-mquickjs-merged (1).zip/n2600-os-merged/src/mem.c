/* mem.c — скан карты памяти Multiboot + простой аллокатор (first-fit со слиянием)
 *
 * Учёт памяти ПО ЗАДАЧАМ (диспетчер задач показывает «Mem»):
 * поле used блока хранит task_idx+1 владельца (0 = блок свободен).
 * malloc атрибутирует блок текущей задаче; task_spawn переносит владение
 * стеком новой задачи (mem_reassign); mem_task_used() суммирует блоки. */
#include "mem.h"
#include "string.h"
#include "io.h"
#include "task.h"

/* символы linker-скрипта: в C пишем без подчёркивания, COFF добавит '_' */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

static u32 heap_start = 0, heap_end = 0, heap_pos = 0;
static u64 ram_total = 0;

typedef struct {
    u32 size;   /* полный размер блока, включая заголовок */
    u32 used;
} mblock_t;

#define MBLOCK_HDR sizeof(mblock_t)
#define ALIGN8(x)  (((x) + 7u) & ~7u)

static u32 align_up(u32 v, u32 a) { return (v + a - 1) & ~(a - 1); }

void mem_init(const mb_info_t *mb)
{
    u32 kend = align_up((u32)(unsigned long)bss_end, 4096);
    u32 best_start = 0, best_size = 0;

    ram_total = 0;

    if (mb->flags & MBIF_MMAP) {
        const u8 *p = (const u8 *)(unsigned long)mb->mmap_addr;
        const u8 *endp = p + mb->mmap_length;
        while (p + 4 <= endp) {
            const mb_mmap_t *e = (const mb_mmap_t *)p;
            if (e->size < 20) break;
            if (e->type == 1) {
                u64 reg_end = e->addr + e->len;
                ram_total += e->len;
                /* ищем самый большой пригодный кусок выше конца ядра */
                if (reg_end > (u64)kend + 0x1000000u) { /* >16МБ после ядра */
                    u64 hs = (e->addr > kend) ? e->addr : kend;
                    u64 sz = reg_end - hs;
                    if (sz > (u64)best_size) {
                        best_size = (u32)sz;
                        best_start = (u32)hs;
                    }
                }
            }
            p += e->size + 4;
        }
    }
    if (!best_start && (mb->flags & MBIF_MEM) && mb->mem_upper > 2048) {
        /* запасной путь: mem_upper (КБ выше 1М) */
        u32 top = 0x100000u + mb->mem_upper * 1024u;
        if (top > kend + 0x400000u) {
            best_start = (kend > 0x200000u) ? kend : 0x200000u;
            best_size = top - best_start;
        }
    }
    if (!best_start) {
        /* крайний случай: 32 МиБ начиная с 2М (обычно не сработает лишь на экзотике) */
        best_start = 0x200000u;
        best_size = 0x2000000u;
    }

    heap_start = align_up(best_start, 4096);
    /* не захватываем больше 512 МиБ — на реальном железе за картой могут быть дыры */
    u32 cap = (best_size > 0x20000000u) ? 0x20000000u : best_size;
    heap_end = heap_start + cap;

    /* первый пустой блок на весь регион */
    mblock_t *b = (mblock_t *)heap_start;
    b->size = heap_end - heap_start;
    b->used = 0;
    heap_pos = heap_start;
}

/* FIX [M1]: атомарность кучи. Планировщик вытесняет ЛЮБУЮ задачу на IRQ0
 * посреди malloc()/free() (мутация связного списка блоков), а другая
 * задача в это же время зовёт malloc — список свободных блоков калечится,
 * что даёт случайные падения/зависания всей системы. Обе функции теперь
 * выполняются с запрещёнными прерываниями (с корректным восстановлением
 * IF — если звали из уже критической секции, IF остаётся 0). */
static void heap_irq_save(int *if_had)
{
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(*if_had) :: "memory");
}
static void heap_irq_restore(int if_had)
{
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Сессия 59: ЗДОРОВЬЕ ЗАГОЛОВКА БЛОКА. Порча кучи (лог пользователя:
 * «блок size=0 — запись мимо буфера») раньше проявлялась как ШТОРМ
 * сообщений на каждый malloc/free и полный паралич аллокатора. Теперь
 * walk останавливается на любом нездоровом заголовке (size < HDR,
 * не кратен 8 или выходит за heap_end), а диагностика печатается ОДИН
 * раз (лесипка), чтобы serial оставался читаемым для поиска виновника.
 * Возвращает 1 = заголовок здоров. */
static volatile int heap_corrupt_reported = 0;

static int blk_hdr_ok(const mblock_t *b)
{
    u32 sz = b->size;
    if (sz < MBLOCK_HDR) return 0;
    if (sz & 7u) return 0;                          /* выравнивание 8 */
    if ((u32)(unsigned long)b + sz > heap_end) return 0;
    return 1;
}

static void heap_report_corrupt(const mblock_t *b, const char *where)
{
    if (heap_corrupt_reported) return;
    heap_corrupt_reported = 1;
    extern void serial_puts(const char *s);
    char tb[160];
    extern int snprintf(char*,u32,const char*,...);
    snprintf(tb, sizeof(tb),
             "[mem] ПОРЧА КУЧИ (%s): блок %x size=%u used=%u — walk остановлен, "
             "проверь канарейки стеков ниже в логе\n",
             where, (unsigned)(unsigned long)b,
             (unsigned)b->size, (unsigned)b->used);
    serial_puts(tb);
    mem_dump_blocks();
}

void *malloc(u32 n)
{
    if (!heap_start || n == 0) return NULL;
    u32 need = ALIGN8(n) + MBLOCK_HDR;

    int if_had;
    heap_irq_save(&if_had);

    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        /* Сессия 59: порча кучи — нездоровый заголовок (size=0 у
         * пользователя был частным случаем). Останавливаем walk,
         * диагностируем ОДИН раз и отказываемся от аллокации вместо
         * шторма сообщений/зависания под cli. */
        if (!blk_hdr_ok(b)) {
            heap_report_corrupt(b, "malloc");
            heap_irq_restore(if_had);
            return NULL;
        }
        if (!b->used && b->size >= need) {
            /* расщепление, если остаток вмещает ещё один блок */
            if (b->size >= need + MBLOCK_HDR + 16) {
                mblock_t *nb = (mblock_t *)((u8 *)b + need);
                nb->size = b->size - need;
                nb->used = 0;
                b->size = need;
            }
            /* владелец: текущая задача (+1; kmain = задача 0 → 1) */
            {
                int t = task_current();
                b->used = (u32)(t + 1);
            }
            heap_irq_restore(if_had);
            return (u8 *)b + MBLOCK_HDR;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_irq_restore(if_had);
    return NULL;
}

void free(void *p)
{
    if (!p) return;
    int if_had;
    heap_irq_save(&if_had);      /* FIX [M1] */
    mblock_t *b = (mblock_t *)((u8 *)p - MBLOCK_HDR);
    /* Сессия 59: дикий free (указатель мимо кучи / не выровнен /
     * заголовок нездоров) раньше молча писал used=0 в чужую память.
     * Теперь отказ с диагностикой — запись НЕ делается. */
    if ((u32)(unsigned long)p < heap_start + MBLOCK_HDR ||
        (u32)(unsigned long)p >= heap_end ||
        ((u32)(unsigned long)p & 7u) || !blk_hdr_ok(b)) {
        heap_report_corrupt(b, "free");
        heap_irq_restore(if_had);
        return;
    }
    if (!b->used) {
        /* двойной free — слияние уже сделано, просто игнорируем */
        heap_irq_restore(if_had);
        return;
    }
    b->used = 0;

    /* слияние с последующими свободными */
    mblock_t *next;
    for (;;) {
        next = (mblock_t *)((u8 *)b + b->size);
        if ((u32)(unsigned long)next >= heap_end || next->used) break;
        b->size += next->size;
    }
    heap_irq_restore(if_had);    /* FIX [M1] */
}

u32 mem_used(void)
{
    u32 used = 0;
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59: порча — стоп */
        if (b->used) used += b->size;
        b = (mblock_t *)((u8 *)b + b->size);
    }
    return used;
}

/* Перенести владение уже выделенным блоком на другую задачу.
 * Используется task_spawn: стек новой задачи выделяется в контексте
 * ПОРОЖДАЮЩЕЙ задачи — переносим на нового владельца. */
void mem_reassign(void *p, int task_idx)
{
    if (!p) return;
    int if_had;
    heap_irq_save(&if_had);
    mblock_t *b = (mblock_t *)((u8 *)p - MBLOCK_HDR);
    if ((u32)(unsigned long)b >= heap_start &&
        (u32)(unsigned long)b < heap_end && b->used) {
        b->used = (u32)(task_idx + 1);
    }
    heap_irq_restore(if_had);
}

/* Суммарная память, занятая задачей task_idx (один проход по куче). */
u32 mem_task_used(int task_idx)
{
    u32 used = 0;
    u32 owner = (u32)(task_idx + 1);
    int if_had;
    heap_irq_save(&if_had);
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59 */
        if (b->used == owner) used += b->size;
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_irq_restore(if_had);
    return used;
}

u32 mem_heap_size(void) { return heap_end - heap_start; }

u32 mem_ram_mib(void) { return (u32)(ram_total >> 20); }


/* Сессия 13 (диагностика): обход кучи — свободные байты/блоки/макс.блок */
u32 mem_debug_walk(u32 *largest, u32 *nfree)
{
    u32 free_total = 0;
    u32 lg = 0, nf = 0;
    if (!heap_start) return 0;
    int if_had;
    heap_irq_save(&if_had);
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) break;              /* сессия 59 */
        if (!b->used) {
            free_total += b->size;
            nf++;
            if (b->size > lg) lg = b->size;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_irq_restore(if_had);
    if (largest) *largest = lg;
    if (nfree) *nfree = nf;
    return free_total;
}


/* Сессия 13 (диагностика): полный дамп блоков кучи в serial */
void mem_dump_blocks(void)
{
    extern void serial_puts(const char *s);
    if (!heap_start) return;
    int if_had;
    heap_irq_save(&if_had);
    mblock_t *b = (mblock_t *)heap_start;
    int n = 0;
    while ((u32)(unsigned long)b < heap_end && n < 200) {
        char tb[96];
        extern int snprintf(char*,u32,const char*,...);
        snprintf(tb, sizeof(tb), "  blk %x size=%u owner=%u%s\n",
                 (unsigned)(unsigned long)b, (unsigned)b->size,
                 (unsigned)(b->used ? b->used - 1 : 0xFFFFFFFFu),
                 b->used ? "" : " (free)");
        serial_puts(tb);
        if (!blk_hdr_ok(b)) {
            serial_puts("  ...(заголовок побит — walk стоп, блоки выше не видны)\n");
            break;
        }
        b = (mblock_t *)((u8 *)b + b->size);
        n++;
    }
    heap_irq_restore(if_had);
}


/* Сессия 13: сторож — есть ли size==0 (порча)? 1 = есть */
int mem_check_corrupt(void)
{
    if (!heap_start) return 0;
    int if_had;
    heap_irq_save(&if_had);
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!blk_hdr_ok(b)) {                   /* сессия 59: любая порча */
            heap_irq_restore(if_had);
            return 1;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    heap_irq_restore(if_had);
    return 0;
}
