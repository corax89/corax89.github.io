/* wm_scrollbar.c — переиспользуемая полоса прокрутки (сессия 17).
 *
 * Один виджет на все приложения ОС (браузер, «Система», HTTP Trace,
 * просмотрщик файлов, окна вывода, редакторы на editor.c). Цвета
 * берутся из ТЕМЫ при каждой отрисовке:
 *   - желоб            = wm_theme_win_bg_alt()
 *   - ползунок         = wm_theme_accent()
 *   - ползунок при drag = смешение accent с белым (col_mix)
 * Semantics: pos — первая видимая строка, max = всего - vis,
 * pos ∈ [0..max]. Реализация вынесена в отдельный файл, чтобы
 * редакторская библиотека и хост-тесты подключали только её. */
#include "wm.h"
#include "fb.h"
#include "mouse.h"    /* MSB_LEFT */

/* локальное смешение (в wm.c есть col_mix, но он static) */
static u32 sb_mix(u32 a, u32 b, int fa)
{
    if (fa < 0) fa = 0;
    if (fa > 255) fa = 255;
    int fb = 255 - fa;
    int r = ((int)((a >> 16) & 0xFF) * fa + (int)((b >> 16) & 0xFF) * fb) / 255;
    int g = ((int)((a >> 8) & 0xFF) * fa + (int)((b >> 8) & 0xFF) * fb) / 255;
    int bl = ((int)(a & 0xFF) * fa + (int)(b & 0xFF) * fb) / 255;
    return 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | (u32)bl;
}

static int sb_clamp_pos(int pos, int max)
{
    if (pos < 0) pos = 0;
    if (pos > max) pos = max;
    return pos;
}

void wm_scrollbar_draw(wm_scrollbar_t *sb, int x, int y, int w, int h,
                       int pos, int max, int vis)
{
    if (!sb) return;
    if (w < 2) w = 2;
    if (h < 2) h = 2;

    pos = sb_clamp_pos(pos, max < 0 ? 0 : max);
    sb->x = x; sb->y = y; sb->w = w; sb->h = h;
    sb->pos = pos; sb->max = max; sb->vis = vis;

    fb_fill_rect(x, y, w, h, wm_theme_win_bg_alt());

    if (max <= 0 || vis <= 0) {          /* прокрутка не нужна */
        sb->thumb_y = y;
        sb->thumb_h = 0;
        return;
    }

    int th = h * vis / (max + vis);
    if (th < 8) th = 8;
    if (th > h) th = h;
    int ty = y + (h - th) * pos / max;   /* ПРОЯМО: pos=0 -> сверху */
    sb->thumb_h = th;
    sb->thumb_y = ty;

    u32 c = wm_theme_accent();
    if (sb->dragging) c = sb_mix(c, 0xFFFFFFu, 60);
    fb_fill_rect(x, ty, w, th, c);
}

int wm_scrollbar_mouse(wm_scrollbar_t *sb, int mx, int my,
                       u8 buttons, u8 changed)
{
    if (!sb) return -1;

    /* --- FIX «мышь соскочила с полосы — скроллинг остановился» (сессия 20) ---
     * ПОКА ТАЩИМ ПОЛЗУНОК: события обрабатываются НЕЗАВИСИМО от позиции
     * курсора — он может выйти за пределы полосы и даже ОКНА (WM с
     * неявным захватом доставляет такие события; координаты клампятся
     * в желоб). Захват отпускается ТОЛЬКО по отпусканию ЛКМ. */
    if (sb->dragging) {
        if (!(buttons & MSB_LEFT) || sb->max <= 0 || sb->h <= 0 ||
            sb->thumb_h <= 0) {
            sb->dragging = 0;
            return -1;
        }
        if (changed & MSB_LEFT) return -1;  /* само событие нажатия уже обработано */
        int span = sb->h - sb->thumb_h;
        if (span <= 0) { sb->dragging = 0; return -1; }
        int myc = my;                       /* курсор клампим в желоб */
        if (myc < sb->y) myc = sb->y;
        if (myc > sb->y + sb->h - 1) myc = sb->y + sb->h - 1;
        int ry = myc - sb->drag_off - sb->y;
        int np = sb_clamp_pos((ry * sb->max + span / 2) / span, sb->max);
        return np != sb->pos ? np : -1;
    }

    if (sb->max <= 0 || sb->h <= 0) return -1;

    /* зона ЗАХВАТА (нажатия) шире полосы на 2 px с каждой стороны */
    if (mx < sb->x - 2 || mx >= sb->x + sb->w + 2) return -1;

    int newpos = sb->pos;
    int page = sb->vis > 1 ? sb->vis - 1 : 1;

    if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
        if (sb->thumb_h > 0 && my >= sb->thumb_y &&
            my < sb->thumb_y + sb->thumb_h) {
            sb->dragging = 1;
            sb->drag_off = my - sb->thumb_y;
        } else if (my < sb->thumb_y) {
            newpos = sb_clamp_pos(sb->pos - page, sb->max);
        } else {
            newpos = sb_clamp_pos(sb->pos + page, sb->max);
        }
    }

    newpos = sb_clamp_pos(newpos, sb->max);
    return newpos != sb->pos ? newpos : -1;
}

/* ------------------- ГОРИЗОНТАЛЬНАЯ полоса (сессия 19) -------------------
 * Те же желоб/ползунок/тема, оси поменяны: позиция считается по X.
 * Геометрия хранится в тех же полях (thumb_y/thumb_h = x/ширина
 * ползунка); drag_off — смещение курсора от ЛЕВОГО края ползунка. */
void wm_scrollbar_hdraw(wm_scrollbar_t *sb, int x, int y, int w, int h,
                        int pos, int max, int vis)
{
    if (!sb) return;
    if (w < 2) w = 2;
    if (h < 2) h = 2;

    pos = sb_clamp_pos(pos, max < 0 ? 0 : max);
    sb->x = x; sb->y = y; sb->w = w; sb->h = h;
    sb->pos = pos; sb->max = max; sb->vis = vis;

    fb_fill_rect(x, y, w, h, wm_theme_win_bg_alt());

    if (max <= 0 || vis <= 0) {          /* прокрутка не нужна */
        sb->thumb_y = x;
        sb->thumb_h = 0;
        return;
    }

    int tw = w * vis / (max + vis);
    if (tw < 8) tw = 8;
    if (tw > w) tw = w;
    int tx = x + (w - tw) * pos / max;   /* ПРОЯМО: pos=0 -> слева */
    sb->thumb_h = tw;
    sb->thumb_y = tx;

    u32 c = wm_theme_accent();
    if (sb->dragging) c = sb_mix(c, 0xFFFFFFu, 60);
    fb_fill_rect(tx, y, tw, h, c);
}

int wm_scrollbar_hmouse(wm_scrollbar_t *sb, int mx, int my,
                        u8 buttons, u8 changed)
{
    if (!sb) return -1;

    /* --- FIX «мышь соскочила — скроллинг встал»: то же, что для
     * вертикальной полосы — drag живёт до ОТпускания ЛКМ, курсор
     * может выходить за пределы полосы и окна --- */
    if (sb->dragging) {
        if (!(buttons & MSB_LEFT) || sb->max <= 0 || sb->w <= 0 ||
            sb->thumb_h <= 0) {
            sb->dragging = 0;
            return -1;
        }
        if (changed & MSB_LEFT) return -1;
        int span = sb->w - sb->thumb_h;
        if (span <= 0) { sb->dragging = 0; return -1; }
        int mxc = mx;                       /* курсор клампим в желоб */
        if (mxc < sb->x) mxc = sb->x;
        if (mxc > sb->x + sb->w - 1) mxc = sb->x + sb->w - 1;
        int rx = mxc - sb->drag_off - sb->x;
        int np = sb_clamp_pos((rx * sb->max + span / 2) / span, sb->max);
        return np != sb->pos ? np : -1;
    }

    if (sb->max <= 0 || sb->w <= 0) return -1;

    /* зона захвата шире полосы на 2 px по вертикали */
    if (my < sb->y - 2 || my >= sb->y + sb->h + 2) return -1;

    int newpos = sb->pos;
    int page = sb->vis > 1 ? sb->vis - 1 : 1;

    if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
        if (sb->thumb_h > 0 && mx >= sb->thumb_y &&
            mx < sb->thumb_y + sb->thumb_h) {
            sb->dragging = 1;
            sb->drag_off = mx - sb->thumb_y;
        } else if (mx < sb->thumb_y) {
            newpos = sb_clamp_pos(sb->pos - page, sb->max);
        } else {
            newpos = sb_clamp_pos(sb->pos + page, sb->max);
        }
    }

    newpos = sb_clamp_pos(newpos, sb->max);
    return newpos != sb->pos ? newpos : -1;
}
