/* mqjs_os.h — публичный интерфейс движка MicroQuickJS в N2600-OS.
 *
 * Заменяет cmscript.h: тот же контракт запуска скриптов (mquickjs_run —
 * бывший cmscript_run) плюс REPL-режим для терминала.
 *
 * JS-скриптам доступны те же host-функции, что были у CMScript
 * (регистрация — в сгенерированном src/mqjs_stdlib_os.h, реализация —
 * src/mquickjs_api.c):
 *
 *   print(...args)           — вывод в буфер запуска без '\n' (как в
 *                                CMScript), аргументы через пробел
 *   print_int(n)             — вывод числа
 *   console.log(...args)     — вывод с '\n'
 *   screen_width() / screen_height()
 *   fill_rect(x,y,w,h,c)     — прямоугольник на экране
 *   draw_text(x,y,str,color) — текст
 *   get_color(r,g,b)         — цвет 0xRRGGBB
 *   clear_screen(color) / flip()
 *   delay(ms)                — кооперативная задержка (task_yield)
 *   uptime()                 — секунды с загрузки
 *   strlen(s) / malloc(n) / free(h) / memset(h,v,n) / memcmp(h1,h2,n)
 *                            — память по числовым дескрипторам
 *   ramfs_read(name[, h, max]) -> строка | длина (запись в буфер h)
 *   ramfs_write(name, str[, len]) -> 0|1
 *   ramfs_list()             -> массив имён
 *   win_open(title,x,y,w,h) -> id | -1
 *   win_close(id) / win_alive(id) -> 1|0
 *   win_clear(id,color) / win_rect(id,x,y,w,h,color)
 *   win_text(id,x,y,str,color) / win_update(id)
 *   btn_add(id,x,y,w,h,label) -> номер | -1
 *   btn_clicked(id) -> номер нажатой кнопки | -1
 *   btn_set_label(id,btn,label)
 *   img_load(path) -> id | -1  (RAM disk или http(s)://; сеть блокирующая)
 *   img_free(id) / img_w(id) / img_h(id)
 *   img_pixel(id,x,y) -> 0xRRGGBB | -1
 *   img_draw(id,x,y) / img_draw_scaled(id,x,y,w,h)
 *   win_img(id,img,x,y) / win_img_scaled(id,img,x,y,w,h)
 *   Date()/Date.now(), performance.now() — миллисекунды с загрузки
 *   setTimeout(fn,ms) / clearTimeout(id) — кооперативные (прокачка в delay/flip)
 *   gc()
 */
#ifndef MQJS_OS_H
#define MQJS_OS_H

#include "types.h"

/* Запустить JS-скрипт (замена cmscript_run).
 * src     — NUL-terminated исходник;
 * out     — буфер вывода print()/print_int()/console.log()/ошибок;
 * out_max — размер буфера.
 * Возвращает 0 при успехе, -1 при ошибке (синтаксис/исключение). */
int mquickjs_run(const char *src, char *out, u32 out_max);

/* ---------- REPL (терминал: команда `js`) ----------
 * Модель: контекст живёт между строками; каждая строка исполняется в
 * ОТДЕЛЬНОЙ задаче (не блокирует WM); вывод забирается poll'ом из
 * отрисовки терминала. */
int  mqjs_repl_start(void);              /* 0 = ок, -1 = нет памяти */
void mqjs_repl_stop(void);               /* выйти из REPL, освободить контекст */
int  mqjs_repl_eval(const char *line);   /* 0 = запущено, 1 = занято,
                                          * 2 = нужен ещё ввод (многострочность) */
int  mqjs_repl_poll(char *out, u32 out_max); /* забрать готовый вывод, -> длина */
int  mqjs_repl_busy(void);               /* 1 = строка ещё исполняется */
int  mqjs_repl_pending(void);            /* 1 = накоплен незакрытый блок ({...) */
void mqjs_repl_abort(void);              /* Ctrl+C: прервать текущую строку */
void mqjs_repl_reset_input(void);        /* выбросить накопленный ввод */

/* Окно терминала для win_invalidate() по завершении задачи (кросс-
 * задачная перерисовка — так же делают скриптовые окна sg_repaint). */
struct window;
void mqjs_repl_set_window(struct window *w);

/* Жнец памяти JS-сессий: освобождает (raw-free) пулы и сегменты задач
 * jsfile, убитых ватчдогом/kill'ом, не дошедших до своей разборки.
 * Вызывать из главного цикла раз в секунду (kernel.c). */
void mquickjs_sessions_reap(void);

#endif /* MQJS_OS_H */
