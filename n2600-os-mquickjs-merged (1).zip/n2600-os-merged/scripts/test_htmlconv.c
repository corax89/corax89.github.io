/* test_htmlconv.c — ХОСТОВОЙ тест HTML->Markdown конвертера (src/htmlconv.c).
 *
 * Компилируется на Linux:  gcc -DHOST_TEST -fsanitize=address,undefined
 * Запуск:                  timeout 10 ./test_htmlconv
 *   (timeout ловит регрессию бесконечного цикла FIX [H1] — старый код
 *    зависал намертво; ASAN ловит выход за границы буфера).
 *
 * Покрывает:
 *   [H1] регресс: текст после закрытого тега (раньше — infinite loop)
 *   [H3] entities в КОНЦЕ файла (&lt; требует ровно 4 байта остатка)
 *   [H4] закрывающие теги: </a>, </pre>, </ul> раньше читались как
 *        открывающие и ломали разметку
 *   переполнение буфера назначения (маленький md_max)
 *   двухоконную независимость (FIX [H2] на уровне API: буфер caller-а)
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#undef HOST_TEST

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0, total = 0;

static void expect(const char *name, const char *in, const char *want)
{
    char md[4096];
    int n = html_to_md(in, (int)strlen(in), md, (int)sizeof(md));
    total++;
    if (strcmp(md, want) == 0) {
        printf("PASS %-34s -> \"%.60s\"\n", name, md);
        (void)n;
    } else {
        fails++;
        printf("FAIL %s\n   got : \"%s\"\n   want: \"%s\"\n", name, md, want);
    }
}

int main(void)
{
    printf("=== htmlconv host test ===\n");

    /* --- базовые теги --- */
    /* закрывающие теги дают ENSURE_NL — хвостовой \n в конце вывода
     * нормален (браузер рисует построчно, хвостовой \n не виден) */
    expect("h1+p", "<h1>Title</h1><p>para one</p><p>two</p>",
           "# Title\n\npara one\n\ntwo\n");
    expect("h2", "<h2>Sub</h2>", "## Sub\n");
    expect("h4", "<h4>Deep</h4>", "#### Deep\n");
    expect("br", "a<br>b", "a\nb");
    expect("hr", "a<hr>b", "a\n---\nb");
    expect("bold/italic/code",
           "<b>bold</b> <i>it</i> <code>c</code>",
           "**bold** *it* `c`");
    expect("strong/em", "<strong>s</strong><em>e</em>", "**s***e*");
    /* ^ "**s**" от <strong>/</strong> + "*e*" от <em>/</em> */

    /* --- FIX [H1]: текст после закрытого тега (бывший infinite loop) --- */
    expect("text-after-close [H1]", "<b>x</b>tail", "**x**tail");
    expect("two tags then text [H1]",
           "<p>a</p><p>b</p>plain text after tags",
           "a\n\nb\nplain text after tags");
    /* ^ <p> при mi==0 даёт один \n (первые "if" опущены), затем "a";
     *   второй <p> при md[...]="a" даёт "\n\n" + "b"; далее обычный
     *   текст сразу после тега — раньше именно здесь зависали. */

    /* --- entities --- */
    expect("ents mix",
           "&quot;q&quot;&nbsp;&#39;s&#39;&gt;",
           "\"q\" 's'>");
    expect("amp mid", "x &amp; y", "x & y");
    expect("lt mid", "1 &lt; 2", "1 < 2");
    expect("gt mid", "2 &gt; 1", "2 > 1");
    /* FIX [H3]: entity ровно в конце файла */
    expect("lt at EOF [H3]", "a&lt;", "a<");
    expect("gt at EOF [H3]", "a&gt;", "a>");
    expect("amp at EOF [H3]", "a&amp;", "a&");
    expect("nbsp at EOF [H3]", "e&nbsp;", "e ");
    expect("quot at EOF [H3]", "q&quot;", "q\"");
    expect("39 at EOF [H3]", "s&#39;", "s'");
    /* неизвестный entity остаётся как есть */
    expect("unknown entity", "a&foo;b", "a&foo;b");

    /* --- FIX [H4]: закрывающие теги --- */
    /* сессия 55: <a href> теперь даёт ПОЛНУЮ markdown-ссылку */
    expect("link [H4]", "See <a href=\"page.html\">docs</a> now",
           "See [docs](page.html) now");
    expect("link nohref", "See <a>docs</a> now",
           "See [docs]() now");
    expect("link anchor", "<a name=\"x\">top</a>", "[top]()");
    /* сессия 55: <img src> — строка-маркер ![alt](src) */
    expect("img marker", "before <img src=\"p/logo.png\" alt=\"logo\"> after",
           "before\n![logo](p/logo.png)\nafter");
    expect("img noalt", "<img src='x.png'>", "\n![](x.png)\n");
    expect("img nosrc", "<img alt=\"x\"> keep", "keep");
    /* сессия 55 (FIX залипания '=' в html_attr): второй атрибут ищется
     * после перепрыгивания значения первого */
    expect("img src+alt", "<img alt=\"A\" src=\"s.png\">", "\n![A](s.png)\n");
    expect("a href+rel", "<a rel=\"n\" href=\"h.html\">d</a>", "[d](h.html)");
    expect("pre close [H4]", "<pre>a  b</pre>after",
           "```\na  b\n```\nafter");
    expect("ul close [H4]", "<ul><li>one</li><li>two</li></ul>text",
           "- one\n- two\ntext");
    expect("script skip", "<script>var a = 1 < 2;</script>ok", "ok");
    expect("style skip", "<style>.x{a:b}</style>ok", "ok");

    /* --- незакрытый тег в конце файла (не виснет, добирает до EOF) --- */
    expect("unclosed tag EOF", "abc<div tail", "abc");
    /* ^ <div ...> читает имя до EOF, тега '>' нет -> i==html_len, цикл
     *   завершается; вывод только "abc". Главное — возврат за конечное
     *   время (проверяется timeout'ом раннера). */

    /* --- пробелы/переводы строк вне pre сжимаются --- */
    expect("ws squeeze", "a \t\n  b", "a b");

    /* --- FIX [H2]: буферы вызова независимы (два «окна») --- */
    {
        char w1[512], w2[512];
        const char *doc = "<h1>T</h1><ul><li>x &lt; y</li></ul><p>e</p>";
        html_to_md(doc, (int)strlen(doc), w1, (int)sizeof(w1));
        html_to_md(doc, (int)strlen(doc), w2, (int)sizeof(w2));
        total++;
        if (strcmp(w1, w2) == 0)
            printf("PASS two-windows independent       -> \"%s\"\n", w1);
        else {
            fails++;
            printf("FAIL two-windows: \"%s\" != \"%s\"\n", w1, w2);
        }
    }

    /* --- переполнение: маленький md_max --- */
    {
        char small[16];
        const char *big =
            "<h1>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</h1>";
        int n = html_to_md(big, (int)strlen(big), small, (int)sizeof(small));
        total++;
        if (n <= (int)sizeof(small) - 1 && small[n] == 0 &&
            n <= 15) {
            printf("PASS truncation                    -> len=%d (<=15)\n", n);
        } else {
            fails++;
            printf("FAIL truncation: n=%d (md_max=16)\n", n);
        }
    }

    /* --- дегенерированные входы --- */
    {
        char out[8];
        total++;
        if (html_to_md(NULL, 10, out, 8) == 0 && out[0] == 0) {
            printf("PASS null input\n");
        } else {
            fails++;
            printf("FAIL null input\n");
        }
        total++;
        if (html_to_md("x", 0, out, 8) == 0 && out[0] == 0) {
            printf("PASS zero len\n");
        } else {
            fails++;
            printf("FAIL zero len\n");
        }
    }

    printf("=== %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
