#!/bin/sh
# mingw_check.sh — сессия 62: золотая проверка фикса emutls.
# Воспроизводит конвейер build.bat (MSYS2 i686-w64-mingw32) на локально
# распакованном Debian-тулчейне (work/mingw-x/sysroot, БЕЗ root):
#   1) СТАРЫЙ stb_image.c (без STBI_NO_THREAD_LOCALS) -> nm должен
#      показать U __emutls_get_address (ошибка пользователя);
#   2) ТЕКУЩИЙ stb_image.c -> emutls ссылок быть НЕ должно;
#   3) полная сборка всех src/*.c флагами bat + линковка -nostdlib
#      + objcopy -O binary (продукт: build-mingw/kernel-mingw.bin).
set -e
cd "$(dirname "$0")/.."

CC=/home/z/my-project/work/mingw-x/sysroot/usr/bin/i686-w64-mingw32-gcc-14-win32
OBJCOPY=/home/z/my-project/work/mingw-x/sysroot/usr/bin/i686-w64-mingw32-objcopy
export PATH=/home/z/my-project/work/mingw-x/sysroot/usr/bin:$PATH

CFLAGS="-m32 -march=i686 -mtune=atom -mno-sse -mno-sse2 -mno-mmx -mno-3dnow \
-ffreestanding -fno-pic -fno-pie -fno-stack-protector \
-fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
-O2 -Wall -Wextra -Isrc"

echo "== [1] СТАРЫЙ stb (без define) — ожидаем U __emutls_get_address =="
mkdir -p /tmp/n2600_oldstb
sed '/#define STBI_NO_THREAD_LOCALS/d' src/stb_image.c > /tmp/n2600_oldstb/stb_image.c
$CC $CFLAGS -c /tmp/n2600_oldstb/stb_image.c -o /tmp/n2600_oldstb/stb_image.o
if nm /tmp/n2600_oldstb/stb_image.o | grep -q emutls; then
    echo "   ПОДТВЕРЖДЕНО: старый stb тянет __emutls_get_address:"
    nm /tmp/n2600_oldstb/stb_image.o | grep emutls | sort -u | head -3
else
    echo "   (!) неожиданно: emutls не найден у старого stb"
fi

echo "== [2] ТЕКУЩИЙ stb — emutls ссылок быть не должно =="
mkdir -p build-mingw
$CC $CFLAGS -c src/stb_image.c -o build-mingw/stb_image.o
if nm build-mingw/stb_image.o | grep -q emutls; then
    echo "   ОШИБКА: emutls всё ещё есть!"; exit 1
fi
echo "   ОК: emutls ссылок нет (TLS-переменные стали обычными static)"

echo "== [3] Полная сборка флагами build.bat =="
for f in src/*.c; do
    o=build-mingw/$(basename "${f%.c}").o
    echo "  CC $f"
    $CC $CFLAGS -c "$f" -o "$o"
done

echo "== [4] Линковка как в build.bat (-nostdlib, без -lgcc) =="
$CC -m32 -nostdlib -Wl,-T,linker.ld -Wl,--image-base=0x100000 \
    -o build-mingw/kernel.tmp.exe build-mingw/*.o

echo "== [5] Плоский бинарник =="
$OBJCOPY -O binary build-mingw/kernel.tmp.exe build-mingw/kernel-mingw.bin
ls -la build-mingw/kernel-mingw.bin

echo "== РЕЗУЛЬТАТ: MinGW-сборка (конвейер build.bat) УСПЕШНА =="
