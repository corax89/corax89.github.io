#!/usr/bin/env python3
"""gen_imgres.py — перегенерация src/imgres.c (встроенные ресурсы RAM disk).

Берёт файлы из ramdisk/ и вшивает их в ядро:
  LOGO.PNG  — демо-картинка браузера   (seed: только если файла нет)
  IMG.CS    — демо CMScript            (seed: только если файла нет)
  HELP.MD   — справка браузера/терминала (seed: ПРИНУДИТЕЛЬНО — справка
              должна соответствовать возможностям ЯДРА; у старого ISO
              (in-place патч ядра без пересборки) в /boot/ramdisk лежит
              устаревшая справка — ядро её заменяет)

Запуск:  python3 scripts/gen_imgres.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RD = os.path.join(ROOT, "ramdisk")
OUT = os.path.join(ROOT, "src", "imgres.c")

RESOURCES = [
    # (имя файла в ramdisk, символ C, force)
    ("LOGO.PNG", "imgres_logo_png", 0),
    ("IMG.CS",   "imgres_img_cs",   0),
    ("HELP.MD",  "imgres_help_md",  1),
]


def c_array(data, per_line=16):
    lines = []
    for i in range(0, len(data), per_line):
        chunk = data[i:i + per_line]
        lines.append("    " + ",".join(f"0x{b:02x}" for b in chunk) + ",")
    return "\n".join(lines)


def c_string_array(data, per_line=64):
    # HELP.MD — текст: вшиваем как string-литерал построчно (читаемо)
    out = []
    text = data.decode("utf-8")
    for line in text.split("\n"):
        esc = line.replace("\\", "\\\\").replace('"', '\\"')
        out.append(f'    "{esc}\\n"')
    return "\n".join(out)


def main():
    parts = []
    parts.append('''/* imgres.c — встроенные ресурсы RAM disk (сессия 55, сессия 56).
 *
 * ЗАЧЕМ: /boot/ramdisk живёт в ISO; in-place патч ядра (update_iso.py)
 * не умеет добавлять НОВЫЕ файлы в ISO. Поэтому LOGO.PNG (демо-картинка
 * для браузера) и IMG.CS (демо CMScript) зашиты в ядро и засеиваются
 * в RAM disk при загрузке ТОЛЬКО если файла ещё нет (imgres_seed,
 * вызывается после ramfs_seed_from_iso): у кого ISO пересобран с
 * ramdisk/LOGO.PNG — побеждает файл из ISO.
 * HELP.MD (сессия 56) засеивается ПРИНУДИТЕЛЬНО (delete+create):
 * справка обязана соответствовать возможностям ядра; у ISO,
 * пропатченного in-place, в /boot/ramdisk остаётся устаревшая справка.
 *
 * Перегенерация: python3 scripts/gen_imgres.py (берёт файлы из каталога ramdisk).
 */
#include "types.h"
#include "imgres.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* Есть ли файл в RAM disk (без учёта регистра — как браузер/imgsvc). */
static int imgres_have(const char *name)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        const char *a = ents[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) return 1;
    }
    return 0;
}

static void imgres_put(const char *name, const void *data, u32 len)
{
    if (imgres_have(name)) return;         /* приоритет у пользователя */
    if (!ramfs_create(name, len)) return;
    ramfs_write(name, data, len);
}

/* force: заменить существующий файл (справка — часть ядра). */
static void imgres_put_force(const char *name, const void *data, u32 len)
{
    if (imgres_have(name)) ramfs_delete(name);
    if (!ramfs_create(name, len)) return;
    ramfs_write(name, data, len);
}

void imgres_seed(void)
{
    imgres_put("logo.png", imgres_logo_png, imgres_logo_png_len);
    imgres_put("img.cs", imgres_img_cs, imgres_img_cs_len);
    imgres_put_force("help.md", imgres_help_md, imgres_help_md_len);
}
''')

    for fname, sym, force in RESOURCES:
        path = os.path.join(RD, fname)
        if not os.path.isfile(path):
            print(f"ERROR: нет {path}", file=sys.stderr)
            return 1
        data = open(path, "rb").read()
        parts.append(f"\n/* ramdisk/{fname}, {len(data)} байт */\n")
        if fname.upper().endswith(".PNG"):
            parts.append(f"const unsigned char {sym}[] = {{\n")
            parts.append(c_array(data))
            parts.append("\n};\n")
            parts.append(f"const unsigned int {sym}_len = {len(data)};\n")
        elif fname.upper().endswith(".MD"):
            parts.append(f"const char {sym}[] =\n")
            parts.append(c_string_array(data))
            parts.append(";\n")
            # длина: без учёта завершающего NUL, с последним \n
            parts.append(f"const unsigned int {sym}_len = sizeof({sym}) - 1;\n")
        else:
            # IMG.CS: текст-скрипт, вшиваем строкой
            parts.append(f"const char {sym}[] =\n")
            parts.append(c_string_array(data))
            parts.append(";\n")
            parts.append(f"const unsigned int {sym}_len = sizeof({sym}) - 1;\n")

    with open(OUT, "w") as f:
        f.write("".join(parts))
    print(f"OK: {OUT} ({os.path.getsize(OUT)} байт)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
