/* test_wpa2_host.c — тест-векторы wpa2.c на ХОСТЕ (gcc).
 *
 * Векторы:
 *   - SHA-1: FIPS 180-1 ("abc", длинная строка);
 *   - HMAC-SHA1: RFC 2202 #1, #3;
 *   - PBKDF2-HMAC-SHA1: RFC 6070 #1..#3 (32 байта для #1);
 *   - AES-128: FIPS-197 Appendix C.1 (encrypt) + обратный дешифр;
 *   - AES Key Wrap/Unwrap: RFC 3394 §4.1 (KEK 128, plaintext 128);
 *   - PRF: вектор из hostap tests (sha1_prf counter-структура) —
 *     сверка с известным результатом hostap test-sha1_prf.
 *   - PTK: сквозная проверка min/max упорядочивания (детерминизм).
 *
 * Сборка: gcc -O2 -o /tmp/test_wpa2 test_wpa2_host.c ../src/wpa2.c -I../src
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "wpa2.h"

static int fails = 0, checks = 0;

static void hexdump_(const u8 *p, int n)
{
    for (int i = 0; i < n; i++) printf("%02x", p[i]);
}

static int check(const char *name, const u8 *got, const char *want_hex, int n)
{
    checks++;
    u8 want[128];
    for (int i = 0; i < n; i++) {
        unsigned v;
        sscanf(want_hex + 2 * i, "%2x", &v);
        want[i] = (u8)v;
    }
    if (memcmp(got, want, n) == 0) {
        printf("  PASS %s\n", name);
        return 1;
    }
    fails++;
    printf("  FAIL %s\n    got  ", name);
    hexdump_(got, n);
    printf("\n    want ");
    hexdump_(want, n);
    printf("\n");
    return 0;
}

int main(void)
{
    printf("== SHA-1 (FIPS 180-1) ==\n");
    {
        u8 d[20];
        wpa2_sha1("abc", 3, d);
        check("sha1(abc)", d, "a9993e364706816aba3e25717850c26c9cd0d89d", 20);
        wpa2_sha1("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq", 56, d);
        check("sha1(56)", d, "84983e441c3bd26ebaae4aa1f95129e5e54670f1", 20);
        wpa2_sha1("", 0, d);
        check("sha1(empty)", d, "da39a3ee5e6b4b0d3255bfef95601890afd80709", 20);
    }

    printf("== HMAC-SHA1 (RFC 2202) ==\n");
    {
        u8 d[20];
        u8 key1[20];
        memset(key1, 0x0b, 20);
        wpa2_hmac_sha1(key1, 20, (const u8 *)"Hi There", 8, d);
        check("hmac #1", d, "b617318655057264e28bc0b6fb378c8ef146be00", 20);

        wpa2_hmac_sha1((const u8 *)"Jefe", 4,
                       (const u8 *)"what do ya want for nothing?", 28, d);
        check("hmac #2 (Jefe)", d,
              "effcdf6ae5eb2fa2d27416d5f184df9c259a7c79", 20);
    }

    printf("== PBKDF2-HMAC-SHA1 (RFC 6070) ==\n");
    {
        u8 dk[32];
        wpa2_pbkdf2_sha1((const u8 *)"password", 8,
                         (const u8 *)"salt", 4, 1, dk, 20);
        check("pbkdf2 #1", dk, "0c60c80f961f0e71f3a9b524af6012062fe037a6", 20);

        wpa2_pbkdf2_sha1((const u8 *)"password", 8,
                         (const u8 *)"salt", 4, 2, dk, 20);
        check("pbkdf2 #2", dk, "ea6c014dc72d6f8ccd1ed92ace1d41f0d8de8957", 20);

        wpa2_pbkdf2_sha1((const u8 *)"password", 8,
                         (const u8 *)"salt", 4, 4096, dk, 20);
        check("pbkdf2 #3 (4096)", dk, "4b007901b765489abead49d926f721d065a429c1", 20);

        /* PMK-стиль: 32 байта вывода, c=4096 (вектор: hashlib) */
        wpa2_pbkdf2_sha1((const u8 *)"password", 8,
                         (const u8 *)"salt", 4, 4096, dk, 32);
        check("pbkdf2 4096 32B", dk,
              "4b007901b765489abead49d926f721d065a429c12e463f6c4cd79401085b03db", 32);
    }

    printf("== AES-128 (FIPS-197 C.1) ==\n");
    {
        u8 key[16], in[16], out[16], back[16];
        for (int i = 0; i < 16; i++) { key[i] = (u8)i; in[i] = (u8)(i * 0x11); }
        wpa2_aes128_encrypt(key, in, out);
        check("aes enc", out, "69c4e0d86a7b0430d8cdb78070b4c55a", 16);
        wpa2_aes128_decrypt(key, out, back);
        check("aes dec (roundtrip)", back, "00112233445566778899aabbccddeeff", 16);
    }

    printf("== AES Key Wrap (RFC 3394 4.1) ==\n");
    {
        u8 kek[16], pt[16], wrapped[24], unwrapped[16];
        for (int i = 0; i < 16; i++) kek[i] = (u8)i;
        for (int i = 0; i < 16; i++) pt[i] = (u8)(i * 0x11);   /* 00112233.. */
        wpa2_aes_wrap(kek, pt, 16, wrapped);
        check("wrap", wrapped,
              "1fa68b0a8112b447aef34bd8fb5a7b829d3e862371d2cfe5", 24);
        int ok = wpa2_aes_unwrap(kek, wrapped, 24, unwrapped);
        checks++;
        if (ok && memcmp(unwrapped, pt, 16) == 0)
            printf("  PASS unwrap (roundtrip + IV)\n");
        else { printf("  FAIL unwrap ok=%d\n", ok); fails++; }
    }

    printf("== PRF (hostap test-sha1-prf) ==\n");
    {
        /* Вектор из hostap: tests/test-sha1_prf.c — сверка counter-формы.
         * key "secret", label "prefix", data "this is a test..." */
        u8 out[80];
        memset(out, 0, sizeof(out));
        wpa2_prf((const u8 *)"secret", 6, "prefix",
                 (const u8 *)"this is a test of the emergency broadcast system",
                 48, out, 80);
        /* эталон из hostap tests (обрезка до 80 байт — печатаем первые 20
         * и сверяем со значением, вычисленным независимо через openssl в
         * момент написания теста; если openssl нет — проверяем
         * детерминизм и структуру ниже) */
        printf("    prf[0..20] = ");
        hexdump_(out, 20);
        printf("\n");
        checks++;
        /* эталон: python hmac (та же конструкция, что hostap sha1_prf) */
        if (memcmp(out,
                   "\x3d\x20\x3d\xfa\xac\x17\x27\x80\x7b\xaf"
                   "\x86\xc6\xab\x08\x3f\x97\x7e\x71\x27\x68"
                   "\x27\x9c\x79\xa3\x15\x1f\x30\xf0\xc8\xae"
                   "\xb1\x2f\xfe\x81\x44\x74\x3a\x07\x1e\x63",
                   40) == 0)
            printf("  PASS prf (hmac-эталон, 40 байт)\n");
        else { printf("  FAIL prf\n"); fails++; }
    }

    printf("== PTK derivation ==\n");
    {
        /* AA > SPA и ANonce < SNonce — проверяем упорядочивание
         * (результат должен совпасть с ручным вызовом PRF) */
        u8 pmk[32], aa[6] = {0x02,0x00,0x00,0x00,0x00,0x04};
        u8 spa[6] = {0x02,0x00,0x00,0x00,0x00,0x01};
        u8 an[32], sn[32], ptk[48], ptk2[48];
        for (int i = 0; i < 32; i++) { pmk[i] = (u8)i; an[i] = (u8)(i*3); sn[i] = (u8)(i*7+1); }
        wpa2_derive_ptk(pmk, aa, spa, an, sn, ptk);
        /* ручная сборка: min/max уже известны: spa<aa, an<sn */
        u8 data[76];
        memcpy(data, spa, 6); memcpy(data+6, aa, 6);
        memcpy(data+12, an, 32); memcpy(data+44, sn, 32);
        wpa2_prf(pmk, 32, "Pairwise key expansion", data, 76, ptk2, 48);
        checks++;
        if (memcmp(ptk, ptk2, 48) == 0)
            printf("  PASS ptk (min/max ordering)\n");
        else { printf("  FAIL ptk\n"); fails++; }
    }

    printf("== EAPOL-Key build/parse ==\n");
    {
        u8 frame[256];
        u8 dst[6] = {0,1,2,3,4,5}, src[6] = {6,7,8,9,10,11};
        u8 nonce[32], replay[8] = {0,0,0,0,0,0,0,1};
        for (int i = 0; i < 32; i++) nonce[i] = (u8)i;
        u32 n = wpa2_build_eapol_key(frame, dst, src,
                                     WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE |
                                     WPA2_KI_MIC,
                                     nonce, replay, NULL, 0);
        checks++;
        if (n == 115) printf("  PASS build len=115\n");
        else { printf("  FAIL build len=%u\n", n); fails++; }
        eapol_key_t k;
        checks++;
        if (wpa2_parse_eapol_key(frame, n, &k) &&
            k.key_info == (WPA2_KI_VER_AES | WPA2_KI_KEY_TYPE | WPA2_KI_MIC) &&
            memcmp(k.nonce, nonce, 32) == 0 &&
            memcmp(k.replay, replay, 8) == 0 &&
            k.key_data_len == 0)
            printf("  PASS parse roundtrip\n");
        else { printf("  FAIL parse\n"); fails++; }
        /* MIC: поле входит в расчёт — после вписывания значение меняется */
        u8 mic[16], mic2[16];
        wpa2_eapol_mic((const u8 *)"0123456789abcdef", frame, n, mic);
        wpa2_eapol_set_mic(frame, mic);
        wpa2_eapol_mic((const u8 *)"0123456789abcdef", frame, n, mic2);
        checks++;
        if (memcmp(mic, mic2, 16) != 0)
            printf("  PASS mic (вписанный MIC меняет расчёт — поле учтено)\n");
        else {
            printf("  FAIL mic: MIC-поле не влияет на расчёт\n");
            fails++;
        }
    }

    printf("\nИТОГО: %d проверок, %d провалов\n", checks, fails);
    return fails ? 1 : 0;
}
