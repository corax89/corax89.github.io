#!/usr/bin/env python3
"""patch_iso_grow.py — заменить /boot/kernel.bin в os.iso, расширив образ.

update_iso.py пишет новое ядро в ТОТ ЖЕ экстент; если ядро выросло и не
помещается в хвост образа, этот скрипт (переиспользуя разбор ISO из
update_iso.py):
  1) дописывает в конец ISO нулевые сектора, чтобы новое ядро поместилось
     по СТАРОМУ LBA;
  2) пишет новое ядро в экстент;
  3) правит размер файла в каталогах PVD (ISO9660) и SVD (Joliet);
  4) правит Volume Space Size (PVD/SVD) под новый размер образа.
El Torito и isohybrid-MBR не затрагиваются (загрузочность сохраняется).

Использование: python3 patch_iso_grow.py <os.iso> <kernel.bin>
"""
import importlib.util
import os
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "update_iso", os.path.join(HERE, "update_iso.py"))
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)

SECT = u.SECT


def main():
    iso_path, ker_path = sys.argv[1], sys.argv[2]
    with open(iso_path, "rb") as f:
        iso = bytearray(f.read())
    with open(ker_path, "rb") as f:
        ker = f.read()

    # ---- найти /boot/kernel.bin и его СТАРЫЙ LBA (экстент) ----
    vds = u.volume_descriptors(iso)
    if not vds:
        print("ERROR: том не распознан")
        return 1
    entry = None
    old_lba = None
    for t, sec in vds:
        vd = iso[sec * SECT:(sec + 1) * SECT]
        root_lba = struct.unpack("<I", vd[156 + 2:156 + 6])[0]
        root_size = struct.unpack("<I", vd[156 + 10:156 + 14])[0]
        tree = u.walk_tree(iso, root_lba, root_size, joliet=(t == 2))
        for path in tree:
            if path.rstrip("/").endswith("/kernel.bin"):
                lba, size, rec = tree[path]
                print(f"{'Joliet' if t == 2 else 'ISO9660'}: {path} "
                      f"LBA {lba}, {size} байт (rec @{rec})")
                if entry is None:
                    entry = (lba, size, rec)
                if old_lba is None:
                    old_lba = lba
                else:
                    assert old_lba == lba, "экстенты PVD/SVD расходятся!"
                # правим размер прямо здесь (для каждого тома своя запись)
                struct.pack_into("<I", iso, rec + 10, len(ker))

    if entry is None:
        print("ERROR: /boot/kernel.bin не найден")
        return 1

    # ---- расширить образ при необходимости и записать ядро ----
    end_off = old_lba * SECT + len(ker)
    if end_off > len(iso):
        need = ((end_off - len(iso)) + SECT - 1) // SECT * SECT
        iso += b"\x00" * need
        print(f"образ расширен на {need} байт -> {len(iso)}")

    iso[old_lba * SECT:old_lba * SECT + len(ker)] = ker
    print(f"ядро {entry[1]} -> {len(ker)} байт записано @LBA {old_lba}")

    # ---- Volume Space Size под новый размер ----
    total_sect = len(iso) // SECT
    for t, sec in vds:
        vd_off = sec * SECT
        struct.pack_into("<I", iso, vd_off + 80, total_sect)
        struct.pack_into(">I", iso, vd_off + 84, total_sect)
    print(f"Volume Space Size -> {total_sect} секторов")

    with open(iso_path, "wb") as f:
        f.write(iso)

    # ---- контроль: перечитать и сверить ----
    with open(iso_path, "rb") as f:
        f.seek(old_lba * SECT)
        chk = f.read(len(ker))
    print("контроль записи:", "OK" if chk == ker else "FAIL")
    print(f"итого: {os.path.getsize(iso_path)} байт")
    return 0 if chk == ker else 1


if __name__ == "__main__":
    sys.exit(main())
