#!/usr/bin/env python3
"""test_c4new.py — проверка новых возможностей c4 на уровне ОС:
расширенный c4test (массивы/escape/unsigned/comma/switch/прототипы,
VM-путь) читается OCR-ом окна терминала + регресс cc/run (serial)."""
import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_strip, load_glyphs

ISO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "os.iso"))
SERIAL_LOG = "/tmp/os-serial.log"
SHOTS = "/tmp/shots_c4new"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []
def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail[-260:]}" if detail and not cond else ""))

def serial_text():
    try:
        return open(SERIAL_LOG, "rb").read().decode("utf-8", "replace")
    except FileNotFoundError:
        return ""

def wait_serial(substr, timeout=40, tail_from=None):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = serial_text()
        if tail_from is not None:
            s = s[tail_from:] if tail_from < len(s) else ""
        if substr in s:
            return True
        time.sleep(0.3)
    return False

def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)

print("=== Новые возможности c4 (расширенный c4test, VM-путь) ===")
with QMon(ISO, extra_args=["-serial", f"file:{SERIAL_LOG}"]) as q:
    time.sleep(12)

    type_cmd(q, "c4test")
    time.sleep(4.0)
    q.screendump(f"{SHOTS}/c4test.ppm")
    # Терминал: контент-оригин (21,41), строки на экране (25, 45+16i)
    lines = ocr_strip(f"{SHOTS}/c4test.ppm", 25, 45, 62, 17)
    text = "\n".join(lines)
    print("  OCR терминала:", text.replace("\n", " | "))
    check("локальные массивы: arr[4] = 16", "arr[4] = 16" in text, text)
    check("sum = 30 (исходный цикл цел)", "sum = 30" in text, text)
    check("escape-\\t: tab-ok", "tab-ok" in text, text)
    check("unsigned >>=: u28=00000008", "u28=00000008" in text, text)
    check("составные >>= и +=: half+1=16", "half+1=16" in text, text)
    check("оператор запятая: comma: d2=30 sum=6", "comma: d2=30 sum=6" in text, text)
    check("switch/case: switch: six", "switch: six" in text, text)
    check("прототип: twice(21) = 42", "twice(21) = 42" in text, text)
    check("exit code: 0", "exit code: 0" in text, text)

    # регресс native-пути (cc/run) на t5
    pos0 = len(serial_text())
    type_cmd(q, "cc t5.c")
    ok1 = wait_serial("native binary saved: t5.bin", 30, pos0)
    check("cc t5.c: нативный бинарник собран", ok1, serial_text()[pos0:])
    if ok1:
        pos1 = len(serial_text())
        type_cmd(q, "run t5.bin")
        ok2 = wait_serial("[c4out:t5.bin] exit code: 91", 30, pos1)
        check("run t5.bin: exit code 91", ok2, serial_text()[pos1:])

print(f"\n=== ИТОГ: {len(PASS)} PASS, {len(FAIL)} FAIL ===")
if FAIL:
    print("Провалены:", *FAIL, sep="\n  - ")
    sys.exit(1)
