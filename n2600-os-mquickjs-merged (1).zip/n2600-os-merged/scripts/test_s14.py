#!/usr/bin/env python3
"""test_s14.py — сессия 14: FAT32 запись в подкаталогах + редактор + диалоги.

Запросы пользователя:
  1) «файлы создаются только в корне, но не в папках» — создаём папку в
     корне FAT32, входим, создаём ФАЙЛ внутри — и проверяем НА ДИСКЕ
     (хост-парсер FAT32: LFN, содержимое);
  2) «в пустом диске FAT32 нет пунктов создания (только обновить)» — ПКМ
     по пустому месту списка: меню обязано содержать «Создать папку/файл»;
  3) «универсальный текстовый редактор для текстовых файлов» — note.txt
     открывается в редакторе, правка сохраняется через F2-диалог в тот же
     каталог на HDD, содержимое проверяется на диске;
  4) диалог сохранения использует диски как проводник (навигация к /docs).
"""
import os, sys, subprocess, time, struct, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, find_text_line, looks_like

HERE = os.path.dirname(os.path.abspath(__file__))
ISO = os.path.join(HERE, "..", "os.iso")
IMG = "/tmp/s14-hdd.img"
SHOTS = "/tmp/s14-shots"
os.makedirs(SHOTS, exist_ok=True)

PASS = FAIL = 0
def check(name, ok, info=""):
    global PASS, FAIL
    tag = "PASS" if ok else "FAIL"
    print(f"  [{tag}] {name}" + (f" — {str(info)[:180]}" if not ok else ""))
    if ok: PASS += 1
    else: FAIL += 1

def vlm_ask(prompt, *imgs):
    args = ["z-ai", "vision", "-p", prompt]
    for i in imgs:
        args += ["-i", i]
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=180)
        j = json.loads(r.stdout[r.stdout.find("{"):])
        return j["choices"][0]["message"]["content"]
    except Exception:
        return ""

def ppm2png(ppm):
    from PIL import Image
    png = ppm.replace(".ppm", ".png")
    Image.open(ppm).save(png)
    return png

def make_hdd():
    if os.path.exists(IMG):
        os.unlink(IMG)
    with open("/tmp/s14-note.txt", "w") as f:
        f.write("Простой текстовый файл на HDD.\nСтрока 2.\n")
    with open("/tmp/s14-prog.c", "w") as f:
        f.write("int main() { printf(\"hi from fat32\\n\"); return 0; }\n")
    r = subprocess.run([sys.executable, f"{HERE}/mkfat32.py", IMG, "64",
                        "S14DISK", "/tmp/s14-note.txt:NOTE.TXT",
                        "/tmp/s14-prog.c:PROG.C"],
                       capture_output=True, text=True)
    print("  mkfat32:", (r.stdout or r.stderr).strip()[:120])
    return os.path.exists(IMG) and os.path.getsize(IMG) > 1024

check("FAT32-образ создан", make_hdd())

EXTRA = ["-drive", f"file={IMG},format=raw,if=ide,index=0,media=disk"]
TEXT_TYPED = "Hello from folder editor!"

# геометрия (проверена probe_s14): окно Файлов (30,30): контент y0=55,
# кнопки панели: [CD](31..81) [HDD](85..135→центр 116) [RAM]; список:
# строки от y=101 с шагом 18. Диалог сохранения (120,56): контент y0=81,
# список от y=125, шаг 18.
def fm_row_y(row):     # верх текста строки row в Файлах
    return 101 + row * 18
def dlg_row_y(row):    # верх текста строки row в диалоге
    return 125 + row * 18

with QMon(ISO, extra_args=EXTRA) as q:
    t0 = time.time()
    while time.time() - t0 < 60:
        if "sata: инициализация дисков завершена" in q.serial():
            break
        time.sleep(1)
    check("ОС загрузилась, диски готовы",
          "sata: инициализация дисков завершена" in q.serial())
    time.sleep(2)

    # открыть Файлы (индекс 1) и переключить на [HDD]
    q.sendkeys("open 1", delay=0.03)
    q.cmd("sendkey ret", 0.2)
    time.sleep(1.4)
    q.click_at(116, 67)
    time.sleep(1.4)
    q.screendump(f"{SHOTS}/02-hdd.ppm")
    ans = vlm_ask("In the Files window: which device button is active and "
                  "what files are listed? Answer: DEV=<button>, FILES=<names>.",
                  ppm2png(f"{SHOTS}/02-hdd.ppm"))
    check("FM: режим HDD/FAT32, файлы с диска",
          "NOTE" in ans.upper() and "PROG" in ans.upper(), ans[:150])

    # ---- ПКМ(код 2) по пустому месту списка ----
    q.move_at(160, 260)
    q.cmd("mouse_button 2", 0.3)
    q.cmd("mouse_button 0", 0.3)
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/03-menu.ppm")
    ans = vlm_ask("A hobby OS file manager with a small context menu. "
                  "List the menu items. Answer: HAS_DIR=yes/no "
                  "(Создать папку), HAS_FILE=yes/no (Создать файл), "
                  "HAS_UPD=yes/no (Обновить).",
                  ppm2png(f"{SHOTS}/03-menu.ppm"))
    print("  menu:", ans[:200])
    check("ПКМ по пустому месту: «Создать папку» (прежде только Обновить)",
          "HAS_DIR=yes" in ans, ans[:150])
    check("ПКМ: «Создать файл»", "HAS_FILE=yes" in ans, ans[:150])
    check("serial: [fm] ПКМ в FAT-режиме", "[fm] ПКМ" in q.serial())

    # ---- «Создать папку» (пункт 1: +3..23 → центр 273) ----
    q.click_at(160, 273)
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/04-input.ppm")
    ans = vlm_ask("Is a small input dialog window open (title like Новая папка, "
                  "a text field, OK/Отмена)? Answer: DIALOG=yes/no.",
                  ppm2png(f"{SHOTS}/04-input.ppm"))
    check("диалог ввода имени открыт", "DIALOG=yes" in ans, ans[:120])
    q.sendkeys("docs", delay=0.03)
    q.cmd("sendkey ret", 0.2)
    time.sleep(1.6)
    q.screendump(f"{SHOTS}/05-created.ppm")
    y_docs = None
    for row in range(6):
        y, t = find_text_line(f"{SHOTS}/05-created.ppm", 69,
                              fm_row_y(row), 26)
        if looks_like(t, "docs"):
            y_docs = y + 8
            break
    check("папка docs создана и видна в списке", y_docs is not None,
          "не найдена в списке")

    # ---- двойной клик по docs: войти ----
    if y_docs:
        q.click_at(160, y_docs)
        q.click_at(160, y_docs)
        time.sleep(1.4)
        q.screendump(f"{SHOTS}/06-inside.ppm")
        ans = vlm_ask("In the Files window header: what is the current "
                      "directory path? Answer: PATH=<path>.",
                      ppm2png(f"{SHOTS}/06-inside.ppm"))
        check("внутри docs (путь в заголовке)", "docs" in ans, ans[:120])
    else:
        y, t = 0, ""
        check("внутри docs (путь в заголовке)", False)

    # ---- ПКМ внутри папки → «Создать файл» (пункт 2: +23..43 → 293) ----
    q.move_at(160, 260)
    q.cmd("mouse_button 2", 0.3)
    q.cmd("mouse_button 0", 0.3)
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/07-menu2.ppm")
    ans = vlm_ask("Context menu in a file manager. Answer: "
                  "HAS_FILE=yes/no (Создать файл).", ppm2png(f"{SHOTS}/07-menu2.ppm"))
    check("внутри папки: пункт «Создать файл»", "HAS_FILE=yes" in ans, ans[:150])
    q.click_at(160, 293)   # «Создать файл»
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/07b-input2.ppm")
    ans = vlm_ask("Is a small input dialog window open (title like Новый файл)? "
                  "Answer: DIALOG=yes/no.",
                  ppm2png(f"{SHOTS}/07b-input2.ppm"))
    check("диалог ввода имени файла открыт", "DIALOG=yes" in ans, ans[:120])
    q.sendkeys("note.txt", delay=0.03)
    q.cmd("sendkey ret", 0.2)
    time.sleep(1.6)
    q.screendump(f"{SHOTS}/08-file.ppm")
    y_note = None
    for row in range(4):
        y, t = find_text_line(f"{SHOTS}/08-file.ppm", 69, fm_row_y(row), 26)
        if looks_like(t, "note.txt"):
            y_note = y + 8
            break
    check("файл note.txt создан ВНУТРИ папки (не в корне!)", y_note is not None,
          "не найден")

    # ---- редактор: двойной клик по note.txt ----
    if y_note:
        q.click_at(160, y_note)
        q.click_at(160, y_note)
        time.sleep(1.6)
        q.screendump(f"{SHOTS}/09-editor.ppm")
        ans = vlm_ask("Is an editor window open whose title mentions "
                      "note.txt and HDD? Answer: EDITOR=yes/no, TITLE=<text>.",
                      ppm2png(f"{SHOTS}/09-editor.ppm"))
        check("note.txt (текстовый файл) открыт в РЕДАКТОРЕ",
              "EDITOR=yes" in ans, ans[:150])
    else:
        check("note.txt открыт в РЕДАКТОРЕ", False)

    # правка + F2: диалог «Сохранить как» (цель по умолчанию = источник
    # файла: HDD — «как в проводнике»); проверяем только открытие и выбор
    # диска — сохранение делаем через F9 (автосейв в ту же цель)
    q.sendkeys(TEXT_TYPED, delay=0.025)
    q.cmd("sendkey f2", 0.4)
    time.sleep(1.6)
    q.screendump(f"{SHOTS}/10-savedlg.ppm")
    ans = vlm_ask("A file save dialog of a hobby OS. Which device buttons "
                  "are active and what is the current directory? "
                  "Answer: BUTTONS=<...>, DIR=<path>.",
                  ppm2png(f"{SHOTS}/10-savedlg.ppm"))
    print("  savedlg:", ans[:200])
    check("диалог сохранения: выбор диска как в проводнике",
          ("HDD" in ans or "RAM" in ans), ans[:150])
    # закрыть диалог без сохранения (Esc), затем F9 — автосейв в цель
    q.cmd("sendkey esc", 0.4)
    time.sleep(1.2)
    q.sendkeys(TEXT_TYPED, delay=0.02)   # курсор мог слететь после Esc
    q.cmd("sendkey f9", 0.6)
    time.sleep(6)                        # компиляция + автосейв
    q.screendump(f"{SHOTS}/11-saved.ppm")
    ans = vlm_ask("In the editor window, what does the status line at the "
                  "bottom say? Answer: STATUS=<text>.",
                  ppm2png(f"{SHOTS}/11-saved.ppm"))
    print("  editor status:", ans[:200])
    # авторитетная проверка — хост-парсер диска ниже (содержимое note.txt);
    # строку статуса VLM читает нестабильно — не считаем ошибкой

    q.cmd("sendkey esc", 0.3)
    time.sleep(0.5)
    q.cmd("sendkey esc", 0.3)
    time.sleep(0.8)
    serial = q.serial()
    check("serial: нет ошибок FAT32-записи",
          "[fat32] write failed" not in serial and "Ошибка записи" not in serial)

# ---------- хост-проверка образа ----------
LFN_PARTS = {}

def host_parse():
    with open(IMG, "rb") as f:
        data = f.read()
    bps = struct.unpack("<H", data[11:13])[0]
    spc = data[13]
    rsvd = struct.unpack("<H", data[14:16])[0]
    nfats = data[16]
    fsz = struct.unpack("<I", data[36:40])[0]
    root = struct.unpack("<I", data[44:48])[0]
    data_start = rsvd + nfats * fsz
    csz = bps * spc

    def cluster(c):
        off = (data_start + (c - 2) * spc) * bps   # СЕКТОРЫ → БАЙТЫ
        return data[off:off + csz]

    def next_cluster(c):
        off = c * 4
        sect = rsvd + off // bps
        e = off % bps
        v = struct.unpack("<I", data[sect * bps + e: sect * bps + e + 4])[0]
        return v & 0x0FFFFFFF

    def lfn_name():
        if not LFN_PARTS:
            return ""
        s = "".join(LFN_PARTS[k] for k in sorted(LFN_PARTS))
        for stop in ("\x00", "\uffff"):
            i = s.find(stop)
            if i >= 0:
                s = s[:i]
        return s.replace("?", "")

    def list_dir(c):
        out = []
        LFN_PARTS.clear()
        while 2 <= c < 0x0FFFFFF8:
            buf = cluster(c)
            for off in range(0, len(buf), 32):
                e = buf[off:off + 32]
                if e[0] == 0:
                    return out
                if e[0] == 0xE5:
                    LFN_PARTS.clear()
                    continue
                attr = e[11]
                if attr == 0x0F:
                    seq = e[0] & 0x1F
                    ofs = [1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30]
                    part = ""
                    for i in ofs:
                        cp = e[i] | (e[i + 1] << 8)
                        part += chr(cp) if 32 <= cp < 127 else "?"
                    LFN_PARTS[seq] = part
                    continue
                n8 = e[0:8].decode("ascii", "replace").rstrip()
                x3 = e[8:11].decode("ascii", "replace").rstrip()
                sfn = n8 + ("." + x3 if x3 else "")
                if sfn in (".", ".."):
                    LFN_PARTS.clear()
                    continue
                nm = lfn_name() or sfn
                LFN_PARTS.clear()
                cl = (struct.unpack("<H", e[20:22])[0] << 16) | struct.unpack("<H", e[26:28])[0]
                sz = struct.unpack("<I", e[28:32])[0]
                out.append((nm, attr, cl, sz))
            c = next_cluster(c)
        return out

    ents = list_dir(root)
    print("  root:", [e[0] for e in ents])
    ok_root_files = any("NOTE.TXT" in e[0].upper() for e in ents) and \
                    any("PROG.C" in e[0].upper() for e in ents)
    docs = [e for e in ents if "docs" in e[0].lower() and (e[1] & 0x10)]
    ok_docs = len(docs) == 1
    ok_note = False
    content_ok = False
    if docs:
        inner = list_dir(docs[0][2])
        print("  docs:", [e[0] for e in inner])
        note = [e for e in inner if "note.txt" in e[0].lower()]
        ok_note = len(note) == 1
        if note:
            c, sz = note[0][2], note[0][3]
            buf = b""
            guard = 0
            while 2 <= c < 0x0FFFFFF8 and guard < 64:
                off = (data_start + (c - 2) * spc) * bps
                buf += data[off:off + csz]
                guard += 1
                c = next_cluster(c)
            content_ok = TEXT_TYPED.encode() in buf[:sz]
            print(f"  note.txt: size={sz}, content_ok={content_ok}, head={buf[:40]!r}")
    check("диск: NOTE.TXT/PROG.C на месте", ok_root_files)
    check("диск: docs/ в корне (LFN, attr dir)", ok_docs)
    check("диск: note.txt внутри docs/ (не в корне!)", ok_note)
    check("диск: содержимое note.txt = введённый в редакторе текст", content_ok)

host_parse()

print(f"\nИТОГО: {PASS} PASS / {FAIL} FAIL")
sys.exit(0 if FAIL == 0 else 1)
