#!/usr/bin/env python3
"""test_filter_net.py — сессия 12:
A) fileman ДО формата: диск-мусор → кнопки [HDD] быть НЕ должно;
B) ne2000 + restrict (DHCP недоступен): IP не «мигает» — повторы DHCP
   с нарастающим backoff (5→10→20→30 c), адрес по умолчанию остаётся.
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon
import subprocess, json

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/s12b"
os.makedirs(SHOTS, exist_ok=True)
PASS, FAIL = [], []

def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))

def vlm_ask(prompt, *imgs):
    args = ["z-ai", "vision", "-p", prompt]
    for i in imgs:
        args += ["-i", i]
    out = "/tmp/s12b/_vlm.json"
    subprocess.run(args + ["-o", out], capture_output=True, text=True, timeout=180)
    try:
        return json.load(open(out))["choices"][0]["message"]["content"]
    except Exception:
        return ""

def ppm2png(ppm):
    from PIL import Image
    png = ppm.replace(".ppm", ".png")
    Image.open(ppm).save(png)
    return png

IMG = "/tmp/s12b_junk.img"

print("== A: fileman c диском-мусором (нет поддерживаемой ФС) ==")
with open(IMG, "wb") as f:
    f.write(b"\x00" * 512 * 4096)
    f.write(os.urandom(512 * 2048))
    f.truncate(32 * 1024 * 1024)
open("/tmp/os-serial.log", "w").close()
with QMon(ISO, extra_args=[
        "-drive", f"file={IMG},format=raw,if=ide,index=1,media=disk"]) as q:
    time.sleep(16)
    q.sendkeys("open 1", delay=0.04)      # Файлы
    q.cmd("sendkey ret", 0.1)
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/fm-before.ppm")
    ans = vlm_ask(
        "Screenshot of a hobby OS Files (Файлы) window. Which device "
        "buttons are visible in the top row (CD, HDD, RAM, USB)? "
        "Is there an HDD button? Answer: BUTTONS=<list>, HDD=yes/no.",
        ppm2png(f"{SHOTS}/fm-before.ppm"))
    print("  VLM:", ans[:200])
    check("fileman: [HDD] скрыт (ФС не поддержана)",
          "HDD=no" in ans or ("HDD" not in ans.split("BUTTONS=")[-1]), ans[:150])
    ser = q.serial()
    check("диск найден, ФС нет", "ata: HDD" in ser and "not found" in ser, "")

print("== B: ne2000 + restrict (DHCP мёртв) — стабильность IP ==")
open("/tmp/os-serial.log", "w").close()
t0 = time.time()
with QMon(ISO, extra_args=[
        "-netdev", "socket,id=net0,listen=127.0.0.1:41234",
        "-device", "ne2k_pci,netdev=net0,romfile="]) as q:
    time.sleep(14)
    fails_seen = []
    while time.time() - t0 < 75:
        ser = q.serial()
        fails_seen = [l for l in ser.splitlines() if "DHCP не ответил" in l]
        time.sleep(5)
    # интервалы между повторами: пары соседних «DHCP не ответил» должны
    # расти (backoff 5→10→20→30) и между ними НЕТ сплошного потока
    ser = q.serial()
    print("  повторов DHCP не удалось:", len(fails_seen))
    check("повторы идут (DHCP недоступен)", len(fails_seen) >= 2,
          str(len(fails_seen)))
    check("backoff: не чаще 1 раза в ~5+ с (не спам)",
          len(fails_seen) <= 8, str(len(fails_seen)))
    # BOUND не случился — IP остался умолчанием (10.0.2.15 в Настройках)
    check("DHCP не прошёл (restrict)", "netcfg: DHCP ok" not in ser, "")

print(f"\nИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
if FAIL:
    print("FAILURES:", FAIL)
sys.exit(1 if FAIL else 0)
