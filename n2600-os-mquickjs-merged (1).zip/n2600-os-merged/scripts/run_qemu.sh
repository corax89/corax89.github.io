#!/bin/bash
# Запуск N2600-OS в QEMU (Linux). Требуется qemu-system-i386.
# Сеть: e1000 + user-mode (10.0.2.x, шлюз 10.0.2.2 = хост).
# Примеры в терминале ОС:  ping 10.0.2.2   |   curl http://10.0.2.2:8080/
# (curl на порт шлюза попадает на 127.0.0.1 хоста — поднимите там HTTP-сервер)
cd "$(dirname "$0")/.."
ISO=os.iso
[ -f "$ISO" ] || ISO=prebuilt/os.iso
exec qemu-system-i386 -m 512 -cdrom "$ISO" -boot d \
    -netdev user,id=net0 -device e1000,netdev=net0 \
    -serial stdio -no-reboot "$@"
