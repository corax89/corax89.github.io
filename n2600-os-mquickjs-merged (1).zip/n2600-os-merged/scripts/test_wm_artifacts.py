#!/usr/bin/env python3
"""test_wm_artifacts.py — пиксельная проверка композитора.
Открываем 10 приложений, снимок A; гоняем курсор по всем окнам; снимок B
(после успокоения). Валидный композитор: B == A (кроме часов/миганий).
Дополнительно: чёрные прямоугольники в контенте окон (0x0B0E11) — след
старого бага rlock→dark fill."""
import sys, time, os
sys.path.insert(0, "/home/z/my-project/work/n2600/proj/scripts")
from qmon import QMon
from PIL import Image, ImageChops

ISO = "/home/z/my-project/work/n2600/proj/os.iso"
SHOTS = "/tmp/wmart"
os.makedirs(SHOTS, exist_ok=True)

W, H = 800, 600
MENU_BTN = (36, H - 28 + 14)
def menu_item_y(i): return 169 + i * 26 + 13

# порядок открытия как в repro_overlap2: разные приложения
APPS = [0, 1, 3, 5, 6, 7, 8, 9, 10, 11]

def mask_volatile(im):
    """маскируем: таскбар (часы), область под ним"""
    px = im.load()
    for y in range(H - 28, H):
        for x in range(W):
            px[x, y] = (0, 0, 0)
    return im

def count_dark_blocks(im):
    """считаем крупные связные области цвета 0x0B0E11 (тёмная заглушка)"""
    px = im.load()
    blocks = 0
    for y in range(0, H - 28, 4):
        run = 0
        for x in range(0, W, 4):
            r, g, b = px[x, y][:3]
            if abs(r - 0x0B) < 6 and abs(g - 0x0E) < 6 and abs(b - 0x11) < 6:
                run += 1
            else:
                if run >= 25:   # >= 100px тёмного подряд = заглушка
                    blocks += 1
                run = 0
        if run >= 25: blocks += 1
    return blocks

with QMon(ISO) as q:
    time.sleep(12)
    for app in APPS:
        q.click_at(*MENU_BTN); time.sleep(0.35)
        q.click_at(60, menu_item_y(app)); time.sleep(0.5)
    time.sleep(1.2)
    q.screendump(f"{SHOTS}/A.ppm")

    path = [(400, 300), (200, 250), (600, 400), (250, 500), (500, 150),
            (120, 350), (700, 280), (350, 550), (80, 80), (750, 520)]
    q.mouse_to(400, 300)
    for r in range(4):
        for (x, y) in path:
            q.mouse_to(x, y)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/B.ppm")
    print("shots done")

A = mask_volatile(Image.open(f"{SHOTS}/A.ppm").convert("RGB"))
B = mask_volatile(Image.open(f"{SHOTS}/B.ppm").convert("RGB"))
diff = ImageChops.difference(A, B)
bbox = diff.getbbox()
if bbox:
    # считаем число отличающихся пикселей
    hist = diff.convert("L").histogram()
    changed = sum(hist[8:])   # порог 8
    print(f"DIFF: {changed} пикселей, bbox={bbox}")
    diff.save(f"{SHOTS}/diff.png")
else:
    print("DIFF: нет (идентичны)")

# Примечание: 0x0B0E11 — ЛЕГИТИМНЫЙ фон страницы браузера (apps_browser
# рисует его сам), поэтому отдельная проверка «тёмных заглушек» убрана:
# ключевой критерий — стабильность A vs B после успокоения (исчезнувшее
# окно дало бы тысячи пикселей диффа, а мигающие кареты — лишь ~350).
hist = ImageChops.difference(A, B).convert("L").histogram()
changed = sum(hist[16:])
print(f"changed(>15): {changed}")
ok = changed < 1200
print("RESULT:", "PASS" if ok else "FAIL")
