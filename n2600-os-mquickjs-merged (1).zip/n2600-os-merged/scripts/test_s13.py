#!/usr/bin/env python3
"""test_s13.py — сессия 13: пять запросов пользователя.

1) ЗАПРЕТ форматирования NTFS-разделов (mkntfs-образ → Настройки → F →
   «ЗАПРЕЩЕНО» вместо предупреждения);
2) БЫСТРОЕ форматирование («только создание оглавления», выбор [Q]/[P],
   пакеты записи 128 секторов — формат 64 МиБ за секунды, не минуты);
3) прогресс-бар строго ВНУТРИ красного прямоугольника (FIX «полоса с
   надписью слегка выходит за границы»);
4) СТАНДАРТНОЕ КОНТЕКСТНОЕ МЕНЮ (переиспользуемый wm-компонент):
   правый клик в «Файлах» → меню (Открыть/Создать папку/Создать файл/
   Удалить/Обновить);
5) СОЗДАНИЕ ПАПОК И ФАЙЛОВ в проводнике: иерархия RAM disk (mkdir/
   list_dir/rm), навигация по каталогам, ввод имени через переиспользуемый
   диалог.

Плюс база exc13: cc prog.c + run prog.bin в QEMU (exit 0; QEMU не
проверяет лимиты сегментов — полноценная проверка на Bochs/железе
недоступна, добавлены EIP-диагностика и GRUB «без песочницы»).

Часть проверок — AUTORUN-скрипт (терминал исполняет команды сам);
UI-части — мышью (qmon) + VLM-анализ скриншотов.
"""
import sys, time, os, subprocess, json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/s13shots"
os.makedirs(SHOTS, exist_ok=True)
PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def vlm_ask(prompt, *imgs):
    args = ["z-ai", "vision", "-p", prompt]
    for i in imgs:
        args += ["-i", i]
    out = f"{SHOTS}/_vlm.json"
    try:
        r = subprocess.run(args + ["-o", out], capture_output=True, text=True, timeout=180)
        return json.load(open(out))["choices"][0]["message"]["content"]
    except Exception:
        return ""


def ppm2png(ppm):
    from PIL import Image
    png = ppm.replace(".ppm", ".png")
    Image.open(ppm).save(png)
    return png


def make_junk_disk(path, mib=64):
    with open(path, "wb") as f:
        f.write(b"\x00" * 512 * 2048)
        f.write(os.urandom(512 * 2048))
        f.truncate(mib * 1024 * 1024)


def write_autorun(lines):
    """Положить тестовый AUTORUN.TXT в ramdisk/ и пересобрать ISO."""
    proj = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    with open(os.path.join(proj, "ramdisk", "AUTORUN.TXT"), "w") as f:
        f.write("\n".join(lines) + "\n")
    subprocess.run(["python3", os.path.join(proj, "scripts", "update_iso.py")],
                   check=True, capture_output=True)


AUTORUN_KEEP = None


def restore_autorun():
    proj = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    if AUTORUN_KEEP is not None:
        with open(os.path.join(proj, "ramdisk", "AUTORUN.TXT"), "w") as f:
            f.write(AUTORUN_KEEP)
    else:
        with open(os.path.join(proj, "ramdisk", "AUTORUN.TXT"), "w") as f:
            f.write("# AUTORUN.TXT — автозапуск терминала (сессия 13).\n"
                    "# Строки исполняются по одной; '#' — комментарий.\n")
    subprocess.run(["python3", os.path.join(proj, "scripts", "update_iso.py")],
                   check=True, capture_output=True)


W, H = 800, 600


def menu_open_settings(q):
    q.sendkeys("open 10", delay=0.04)
    q.cmd("sendkey ret", 0.15)
    time.sleep(1.0)
    q.cmd("sendkey tab", 0.1)     # вкладка «Диски»
    time.sleep(0.6)


def part1_ramfs_and_c4():
    """AUTORUN: иерархия RAM disk + терминальные команды + база exc13."""
    print("== Часть 1: иерархия RAM disk (AUTORUN) + cc/run prog.bin ==")
    write_autorun([
        "# тест s13: ramfs + exc13-база",
        "mkdir dir1",
        "touch dir1/hello.txt",
        "ramwrite dir1/privet.txt Privet",
        "mkdir dir1/sub",
        "touch dir1/sub/x.c",
        "ramtree",
        "rmdir dir1",
        "rm dir1/hello.txt",
        "rm dir1/sub/x.c",
        "ramtree",
        "cc prog.c",
        "run prog.bin",
    ])
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO) as q:
        time.sleep(45)      # 3 с + 12 команд × 1.5 с + компиляция/запуск
        ser = q.serial()
        pos = ser.find("[autorun]")
        chunk = ser[pos:] if pos >= 0 else ser
        check("autorun исполнился", "[autorun]" in ser, ser[-200:])
        check("mkdir dir1", "[term] mkdir ok: dir1" in chunk, chunk[:300])
        check("touch dir1/hello.txt", "[term] touch ok: dir1/hello.txt" in chunk, chunk[:400])
        check("mkdir dir1/sub", "[term] mkdir ok: dir1/sub" in chunk, chunk[:400])
        check("ramtree видит иерархию",
              "[ramtree] dir1/ " in chunk and "[ramtree] dir1/hello.txt 1" in chunk
              and "[ramtree] dir1/privet.txt 7" in chunk
              and "[ramtree] dir1/sub/ " in chunk and "[ramtree] dir1/sub/x.c 1" in chunk,
              chunk[:500])
        check("rmdir непустого запрещён", "[term] delete FAIL: dir1" in chunk, chunk[:500])
        check("rm файла ок", "[term] delete ok: dir1/hello.txt" in chunk, chunk[:600])
        check("rm в подкаталоге ок", "[term] delete ok: dir1/sub/x.c" in chunk, chunk[:600])
        check("ramtree после rm: файла нет",
              "[ramtree] dir1/hello.txt" not in chunk[chunk.find("delete ok: dir1/hello.txt"):] if "delete ok: dir1/hello.txt" in chunk else True,
              "")
        # exc13-база: тот же сценарий, что у пользователя
        check("cc prog.c (native)", "native binary saved: prog.bin" in chunk, chunk[-500:])
        i = chunk.find("[c4out:prog.bin]")
        check("run prog.bin: без падения, вывод корректный",
              "[c4out:prog.bin] exit code: 0" in chunk and "sum = 143" in chunk
              and "app crashed" not in chunk,
              chunk[i:i+300] if i >= 0 else chunk[-400:])
        q.screendump(f"{SHOTS}/p1-ramfs.ppm")


def part2_settings_ui():
    """Настройки: запрет NTFS, Q/P, прогресс внутри бокса."""
    print("== Часть 2: Настройки — запрет NTFS, режимы, прогресс ==")
    from mkntfs import build as mkntfs_build
    IMG = "/tmp/s13_ntfs.img"
    if os.path.exists(IMG):
        os.unlink(IMG)
    mkntfs_build(IMG, 64, [])

    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG},format=raw,if=ide,index=1,media=disk",
        ]) as q:
        time.sleep(20)
        ser = q.serial()
        check("NTFS смонтирована (mkntfs)", "ntfs" in ser.lower(), ser[-300:])

        # --- запрет NTFS ---
        menu_open_settings(q)
        q.cmd("sendkey f", 0.15)
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/p2-deny.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window (Russian). Is there a RED box "
            "saying formatting is FORBIDDEN (ЗАПРЕЩЕНО) because the disk has NTFS? "
            "Answer briefly: FORBIDDEN=yes/no, TEXT=<quote>.",
            ppm2png(f"{SHOTS}/p2-deny.ppm"))
        print("  VLM:", ans[:200])
        check("запрет формата NTFS", "FORBIDDEN=yes" in ans.upper() or "ЗАПРЕЩЕНО" in ans.upper(), ans[:150])
        q.cmd("sendkey esc", 0.15)   # закрыть запрет
        time.sleep(0.4)
        q.cmd("sendkey esc", 0.15)   # закрыть Настройки
        time.sleep(0.6)

    # --- быстрый формат на мусорном диске ---
    IMG2 = "/tmp/s13_junk.img"
    make_junk_disk(IMG2)
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG2},format=raw,if=ide,index=1,media=disk",
        ]) as q:
        time.sleep(18)
        menu_open_settings(q)
        q.cmd("sendkey f", 0.15)
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/p2-warn.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window (Russian). Answer three things "
            "briefly: WARN=yes/no (red box about formatting deleting all data), "
            "MODES=yes/no (a line offering Быстрое [Q] and Полное [P] modes), "
            "CURRENT=<which mode line is shown>.",
            ppm2png(f"{SHOTS}/p2-warn.ppm"))
        print("  VLM:", ans[:250])
        check("предупреждение + режимы Q/P",
              "WARN=yes" in ans and "MODES=yes" in ans, ans[:200])

        # переключить в ПОЛНОЕ (P), проверить строку режима, вернуть в БЫСТРОЕ
        q.cmd("sendkey p", 0.15)
        time.sleep(0.5)
        q.screendump(f"{SHOTS}/p2-full.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window (Russian). Look at the "
            "Режим line and the [Q]/[P] line. Does the CURRENT mode say ПОЛНОЕ "
            "(i.e. the asterisk * is on the [P] Полное side, and the Режим line "
            "mentions ПОЛНОЕ/очистка)? Answer: FULL=yes/no, MODE_LINE=<quote>.",
            ppm2png(f"{SHOTS}/p2-full.ppm"))
        check("переключение [P] полное", "FULL=yes" in ans, ans[:150])
        q.cmd("sendkey q", 0.15)
        time.sleep(0.5)

        # Enter: быстрый формат 64 МиБ — теперь ПАКЕТАМИ, ждём немного
        q.cmd("sendkey ret", 0.15)
        t0 = time.time()
        done = False
        while time.time() - t0 < 120:
            time.sleep(2)
            ser = q.serial()
            if "структуры записаны" in ser or "смонтирована после форматирования" in ser:
                done = True
                break
        dur = time.time() - t0
        check("быстрый формат завершён", done)
        check("быстрый формат быстрый (пакеты 128 секторов)", dur < 60, f"{dur:.1f} c")
        ser = q.serial()
        check("FAT32 смонтирована после формата",
              "смонтирована после форматирования" in ser, ser[-300:])

        # прогресс-бокс: геометрия на ПОЛНОМ формате большого диска
        # (1024 МиБ: очистка даёт окно в десятки секунд). ПИКСЕЛЬНАЯ
        # проверка (VLM путается): ищем красную рамку, синюю полосу;
        # полоса и зона подписи должны быть СТРОГО ВНУТРИ рамки.
        q.cmd("sendkey esc", 0.15)   # закрыть Настройки
        time.sleep(0.5)

    def geom_check(path):
        from qmon import read_ppm
        w, h, img = read_ppm(path)
        def px(x, y):
            o = (y * w + x) * 3
            return img[o], img[o+1], img[o+2]
        def close(c, want, tol=45):
            return all(abs(c[i]-want[i]) <= tol for i in range(3))
        RED = (0xE0, 0x50, 0x50)
        BLUE = (0x3E, 0x7D, 0xBF)
        rows = {}
        for y in range(40, 470):
            cnt = sum(1 for x in range(60, 600) if close(px(x, y), RED))
            if cnt > 40:
                rows[y] = cnt
        if not rows:
            return "нет красного бокса"
        ys = sorted(rows)
        top, bot = ys[0], ys[-1]
        blue_rows = [y for y in range(top + 1, bot)
                     if sum(1 for x in range(60, 600) if close(px(x, y), BLUE)) > 4]
        if not blue_rows:
            return "полоса не найдена"
        bar_top, bar_bot = min(blue_rows), max(blue_rows)
        inside = (top + 2) <= bar_top and bar_bot <= (bot - 2)
        label_zone = range(bar_bot + 2, bot - 1)
        has_text = any(
            sum(1 for x in range(60, 600) if sum(px(x, y)) > 260) > 8
            for y in label_zone) if label_zone else False
        return ("BAR_INSIDE=" + ("yes" if inside else "no")
                + ", LABEL_ZONE=" + ("yes" if has_text else "no")
                + f" [box {top}..{bot}, bar {bar_top}..{bar_bot}]")

    IMG3 = "/tmp/s13_big.img"
    make_junk_disk(IMG3, mib=256)
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG3},format=raw,if=ide,index=1,media=disk",
        ]) as q:
        time.sleep(20)
        menu_open_settings(q)
        q.cmd("sendkey f", 0.15); time.sleep(0.5)
        q.cmd("sendkey p", 0.15); time.sleep(0.4)   # ПОЛНОЕ
        q.cmd("sendkey ret", 0.15)

        verdicts = []
        for delay, tag in ((6, "a"),):
            time.sleep(delay)
            q.screendump(f"{SHOTS}/p2-progress-{tag}.ppm")
            v = geom_check(f"{SHOTS}/p2-progress-{tag}.ppm")
            print(f"  geom[{tag}]:", v)
            verdicts.append(v)
        ans = " ".join(verdicts)
        check("полоса внутри красного прямоугольника", "BAR_INSIDE=yes" in ans, ans[:250])
        check("подпись под полосой — внутри бокса", "LABEL_ZONE=yes" in ans, ans[:250])
        t0 = time.time()
        while time.time() - t0 < 300:
            time.sleep(5)
            if "структуры записаны" in q.serial() or "смонтирована после форматирования" in q.serial():
                break
        check("полный формат завершён (256 МиБ)",
              "структуры записаны" in q.serial() or "смонтирована после форматирования" in q.serial(),
              q.serial()[-300:])


def part3_fileman_ui():
    """Файлы: контекстное меню + создание папки/файла мышью."""
    print("== Часть 3: Файлы — контекстное меню, создание папки ==")
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO) as q:
        time.sleep(16)
        q.sendkeys("open 1", delay=0.04)
        q.cmd("sendkey ret", 0.15)
        time.sleep(1.5)

        # окно Файлов создаётся в (30,30): контент ~ (31, 30+24+?); уточним
        # по скрину: щёлкнем в середину списка (RAM-режим по умолчанию при
        # загрузке с CD? По умолчанию CD; переключимся на RAM клавишей Tab
        # (CD→HDD→RAM): Tab дважды (HDD недоступен без диска — пропустится)
        # детерминированно: КЛИК по кнопке [RAM] в панели устройств.
        # Окно Файлов в (30,30); панель y = 30+24+2..+24; кнопки: [CD][RAM]
        # (HDD/USB скрыты) — [RAM] вторая: x = 6+54..6+54+50 → центр ~114.
        q.click_at(114, 30 + 24 + 2 + 11)
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/p3-ram.ppm")

        # правый клик по списку: координаты — центр окна Файлов.
        # бит правой кнопки в QEMU monitor: 2 или 4 — пробуем оба.
        ans = ""
        for rmb in (4, 2):
            q.move_at(160, 200)
            q.cmd(f"mouse_button {rmb}", 0.2)
            q.cmd("mouse_button 0", 0.2)
            time.sleep(0.8)
            q.screendump(f"{SHOTS}/p3-menu.ppm")
            ans = vlm_ask(
            "Screenshot of a hobby OS Files window (Russian) with a small context "
            "menu. List the menu items you can read. Answer: MENU=<items>, "
            "HAS_CREATE_DIR=yes/no (Создать папку), HAS_CREATE_FILE=yes/no "
            "(Создать файл), HAS_DELETE=yes/no (Удалить).",
            ppm2png(f"{SHOTS}/p3-menu.ppm"))
            print(f"  VLM[rmb={rmb}]:", ans[:300])
            if "HAS_CREATE_DIR=yes" in ans:
                break
        check("контекстное меню открылось",
              "MENU=" in ans and "menu" in ans.lower(), ans[:200])
        check("пункт «Создать папку»", "HAS_CREATE_DIR=yes" in ans, ans[:200])
        check("пункт «Создать файл»", "HAS_CREATE_FILE=yes" in ans, ans[:200])

        # выбрать «Создать папку» — верхний пункт меню после «Открыть»
        # (меню у точки клика ~ (160,200) в экранных): пункт 2 = +3+20/2+? —
        # ведём мышью на пункт и кликаем ЛКМ
        if "HAS_CREATE_DIR=yes" in ans:
            # пункты при on_item: Открыть(+3..23) sep(23..32) Создать папку
            # (32..52) → центр ≈ +42 от верха меню (меню у точки клика)
            q.move_at(160, 200 + 42)
            q.cmd("mouse_button 1", 0.2)
            q.cmd("mouse_button 0", 0.2)
            time.sleep(1.0)
            q.screendump(f"{SHOTS}/p3-input.ppm")
            ans2 = vlm_ask(
                "Screenshot of a hobby OS (Russian). Is there a small dialog window "
                "titled like 'Новая папка' with a text input field and OK/Отмена "
                "buttons? Answer: DIALOG=yes/no, TITLE=<what>.",
                ppm2png(f"{SHOTS}/p3-input.ppm"))
            print("  VLM:", ans2[:200])
            check("диалог ввода имени открыт", "DIALOG=yes" in ans2, ans2[:150])
            q.sendkeys("screens", delay=0.03)
            q.cmd("sendkey ret", 0.2)
            time.sleep(1.2)
            # после Enter диалог закрывается сам; фокус возвращается к Файлам —
            # закрываем их (Esc), фокус у исходного терминала
            q.cmd("sendkey esc", 0.3)
            time.sleep(0.6)
            q.sendkeys("ramtree", delay=0.035)
            q.cmd("sendkey ret", 0.25)
            time.sleep(2.0)
            ser = q.serial()
            check("папка создана через UI (ramtree)",
                  "[ramtree] screens/ " in ser, ser[-400:])
            q.screendump(f"{SHOTS}/p3-created.ppm")


def main():
    global AUTORUN_KEEP
    os.makedirs("/tmp/shots", exist_ok=True)
    proj = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    try:
        AUTORUN_KEEP = open(os.path.join(proj, "ramdisk", "AUTORUN.TXT")).read()
    except FileNotFoundError:
        AUTORUN_KEEP = None
    try:
        part1_ramfs_and_c4()
        part2_settings_ui()
        part3_fileman_ui()
    finally:
        restore_autorun()
    print(f"\nИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
    if FAIL:
        print("FAILURES:", FAIL)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
