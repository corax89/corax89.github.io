#!/usr/bin/env python3
"""test_settings.py — приоритет адаптеров + Настройки (сессия 11).

QEMU с ДВУМЯ NIC (e1000 + virtio-net, оба на user-сетях): раньше стек
жёстко выбирал первый найденный. Теперь:
  1) авто-режим: активен e1000 (первый ethernet с линком);
  2) команда adapters показывает оба адаптера;
  3) ручной выбор virtio: DHCP перезапускается на нём, ping работает;
  4) возврат в авто: e1000 снова активен, DHCP повторился;
  5) несуществующий адаптер отвергается.
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at, ocr_strip

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/s11set"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


def main():
    glyphs = load_glyphs()
    print("== загрузка: e1000 + virtio, авто-режим ==")
    with QMon(ISO, extra_args=[
            "-netdev", "user,id=n1", "-device", "e1000,netdev=n1,romfile=",
            "-netdev", "user,id=n2", "-device", "virtio-net-pci,netdev=n2,romfile="]) as q:
        t0 = time.time()
        ok = False
        while time.time() - t0 < 90:
            s = q.serial()
            if "netcfg: DHCP ok" in s and ("Загрузка завершена" in s or "entering main loop" in s):
                ok = True
                break
            time.sleep(1)
        check("ОС загрузилась, DHCP получен", ok)
        s = q.serial()
        check("реестр: 2 адаптера", "адаптеров: 2" in s, s[-300:])
        check("авто: активен e1000 (первый с линком)",
              "активный адаптер: e1000" in s, s[-300:])

        print("== команда adapters ==")
        type_cmd(q, "adapters")
        time.sleep(2.0)
        q.screendump(f"{SHOTS}/adapters.ppm")
        rows = ocr_strip(f"{SHOTS}/adapters.ppm", 25, 45, 60, 12)
        joined = "".join(rows).replace(" ", "")
        print("  adapters:", [l for l in rows if l.strip()][:8])
        check("adapters: оба NIC видны", "e1000" in joined and "virtio" in joined, joined[:200])

        print("== ручной выбор virtio ==")
        type_cmd(q, "adapter virtio")
        time.sleep(10)     # ждём повторный DHCP
        s = q.serial()
        check("активен virtio", "активный адаптер: virtio" in s, s[-300:])
        dhcp_ok = s.count("netcfg: DHCP ok")
        check("DHCP перезапущен на virtio (2+ успешных)", dhcp_ok >= 2, f"DHCP ok: {dhcp_ok}")

        print("== ping через virtio ==")
        type_cmd(q, "ping 10.0.2.2")
        time.sleep(6)
        q.screendump(f"{SHOTS}/ping.ppm")
        rows = ocr_strip(f"{SHOTS}/ping.ppm", 25, 45, 60, 12)
        joined = "".join(rows)
        print("  ping:", [l for l in rows if l.strip()][:6])
        check("ping шлюза работает", "0%" in joined or "0о%" in joined or "time" in joined.lower(),
              joined[:200])

        print("== возврат в авто ==")
        type_cmd(q, "adapter auto")
        time.sleep(10)
        s = q.serial()
        check("авто вернул e1000", "активный адаптер: e1000 (авто" in s, s[-300:])

        print("== некорректное имя ==")
        type_cmd(q, "adapter xyz")
        time.sleep(2)
        s = q.serial()
        check("неизвестный адаптер отвергнут", "Нет такого адаптера" in s or "не найден" in s)

    print()
    print(f"ИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
    if FAIL:
        print("Провалено:", ", ".join(FAIL))
        sys.exit(1)


if __name__ == "__main__":
    main()
