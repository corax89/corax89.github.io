#!/usr/bin/env python3
"""test_resize.py — сессия 7: терминал учитывает РАЗМЕР ОКНА.

Пользователь: «консоль не учитывает размеры окна, а использует всегда
одинаковую область». Проверяем:
  R1: в обычном окне (61 колонка ввода) 50 символов — без переноса
  R2: после maximize (~94 колонки) строка из 80 символов НЕ переносится
  R3: после maximize видно БОЛЬШЕ строк (буфер заполняется dmesg)
  R4: после restore та же строка ПЕРЕНОСИТСЯ по ширине окна
"""
import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_at, load_glyphs, looks_like

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/rzshots"
os.makedirs(SHOTS, exist_ok=True)
GL = load_glyphs()

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def vis_x(s):
    return len(s.rstrip()) - len(s.rstrip().replace("x", "").replace("X", ""))


def cmd(q, c, settle=1.5):
    q.sendkeys(c, delay=0.03)
    q.cmd("sendkey ret", 0.05)
    time.sleep(settle)


with QMon(ISO, extra_args=["-netdev", "user,id=net0",
                           "-device", "e1000,netdev=net0,romfile="]) as q:
    time.sleep(12)

    # --- R1: узкое окно: echo 50 символов одной строкой ---
    cmd(q, "echo " + "x" * 50, 1.5)
    q.screendump(f"{SHOTS}/01-narrow.ppm")
    rows1 = [ocr_at(f"{SHOTS}/01-narrow.ppm", 25, 45 + 16 * r, 70, GL, 400)
             for r in range(8)]
    xs = [vis_x(t) for t in rows1]
    print("  узко, x по строкам:", xs)
    check("R1 узкое окно: 50 символов одной строкой (без переноса)",
          any(45 <= n <= 61 for n in xs) and not any(n > 61 for n in xs), str(xs))

    # --- maximize: [□] у терминала (20,16,506x318) на x≈484..504 ---
    q.click_at(493, 28)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/02-max.ppm")
    mx_title = ocr_at(f"{SHOTS}/02-max.ppm", 8, 4, 10)
    check("R2 maximize: окно развернуто", looks_like(mx_title, "Терминал"), mx_title)

    # 80 символов: в узком окне ввод такой длинный не влез (лимит 60),
    # в развёрнутом (94) — влезает и НЕ переносится
    cmd(q, "echo " + "x" * 80, 1.5)
    q.screendump(f"{SHOTS}/03-max-wide.ppm")
    rowsw = [ocr_at(f"{SHOTS}/03-max-wide.ppm", 5, 29 + 16 * r, 95, GL, 400)
             for r in range(10)]
    xsw = [vis_x(t) for t in rowsw]
    print("  широко, x по строкам:", xsw)
    # строка "> echo x*80" = 87 колонок: без переноса была бы ОДНА строка
    # с 80 x, следующая — вывод тоже 80 x, и НИКАКИХ строк-обрывков
    check("R2 maximize: 80 символов ОДНОЙ строкой (>= 78 x)",
          any(n >= 78 for n in xsw), str(xsw))
    frag = False
    for i, n in enumerate(xsw):
        if n >= 78 and i + 1 < len(xsw) and 0 < xsw[i + 1] < 78:
            frag = True   # перенос разбил бы строку: обрывок на следующей
    check("R2 maximize: ширина > 62 колонок (без обрывков)",
          not frag, str(xsw))

    # --- R4: restore ([□] у развёрнутого окна на x≈758) — 80-x строки
    #     теперь переносятся по 61 колонке (перенос при ОТРИСОВКЕ) ---
    q.click_at(767, 12)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/04-restored.ppm")
    r_title = ocr_at(f"{SHOTS}/04-restored.ppm", 28, 20, 12)
    check("R4 restore: окно вернулось", looks_like(r_title, "Терминал"), r_title)
    rows4 = [ocr_at(f"{SHOTS}/04-restored.ppm", 25, 45 + 16 * r, 70, GL, 400)
             for r in range(16)]
    xs4 = [vis_x(t) for t in rows4]
    print("  restore, x по строкам:", xs4)
    total = sum(xs4)
    wrapped_ok = any(0 < n <= 61 for n in xs4) and total >= 150
    check("R4 restore: 80-символьные строки переносятся по ширине окна",
          wrapped_ok, str(xs4))

    # --- R3 (после R4): глубина развёрнутого окна: dmesg заполняет
    #     буфер — контент виден глубже 17 строк (узкое окно = 16) ---
    q.click_at(493, 28)   # снова maximize (узкое окно)
    time.sleep(1.5)
    cmd(q, "dmesg", 2.0)
    q.screendump(f"{SHOTS}/03b-max-deep.ppm")
    deep_rows = []
    for r in (18, 20, 22):
        t = ocr_at(f"{SHOTS}/03b-max-deep.ppm", 5, 29 + 16 * r, 80, GL, 400)
        deep_rows.append((r, t))
        print(f"  строка {r}: {t.strip()[:50]!r}")
    check("R3 maximize: контент глубже 17 строк (строки 18-22 непусты)",
          any(len(t.strip()) > 3 for _, t in deep_rows), str([t[:20] for _, t in deep_rows]))

print(f"\n=== ИТОГ: {len(PASS)} PASS / {len(FAIL)} FAIL ===")
for f in FAIL:
    print("  FAIL:", f)
sys.exit(0 if not FAIL else 1)
