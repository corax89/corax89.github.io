#!/usr/bin/env python3
"""mkntfs.py — генератор МИНИМАЛЬНОГО корректного NTFS-образа для тестов.

Создаёт образ, который читается нашим ntfs.c (и структурно соответствует
спецификации): MBR с одним разделом, boot-сектор NTFS, $MFT с записями,
каталоги через $INDEX_ROOT (+$INDEX_ALLOCATION/INDX для больших),
файлы resident/non-resident/sparse/LZNT1-сжатые.

Использование: mkntfs.py <файл> <МиБ> <файлы-наполнители...>
"""
import struct
import sys

SEC = 512
CLUSTER = 4096
SPC = CLUSTER // SEC            # секторов в кластере = 8
REC = 1024                      # размер записи MFT
INDX = 4096                     # размер INDX-блока

MFT_LCN = 4                     # $MFT начинается с кластера 4
MFT_RECORDS = 128               # резерв записей (128 КиБ = 32 кластера)
DATA_LCN = MFT_LCN + MFT_RECORDS * REC // CLUSTER   # данные после $MFT
PART_START = 128                # абсолютный LBA начала раздела


def u16(v): return struct.pack('<H', v)
def u32(v): return struct.pack('<I', v)
def u64(v): return struct.pack('<Q', v)


class ClusterAlloc:
    """Простой последовательный аллокатор кластеров."""

    def __init__(self, start_lcn):
        self.next = start_lcn

    def alloc(self, n=1):
        first = self.next
        self.next += n
        return first


# ---------------- атрибуты ----------------

def attr_resident(atype, val, flags=0):
    """Resident-атрибут: заголовок 0x18 + значение."""
    val = bytearray(val)
    while len(val) % 8:
        val.append(0)
    ln = 0x18 + len(val)
    # resident-заголовок = 0x18 байт: type,len,nonres,namelen,nameoff,
    # flags,instance | val_len, val_off(=0x18), indexed-flags
    hdr = u32(atype) + u32(ln) + b'\x00' + b'\x00' + u16(0) + u16(flags) + \
        u16(0) + u32(len(val)) + u16(0x18) + u16(0)
    assert len(hdr) == 0x18, len(hdr)
    return bytes(hdr) + bytes(val)


def encode_run(offset, length):
    """Один data run: varint длины + varint смещения (со знаком)."""
    lb = []
    x = length
    while x:
        lb.append(x & 0xFF)
        x >>= 8
    ob = []
    if offset < 0:
        # дополнительный код
        bits = 8 * 8
        v = offset & ((1 << bits) - 1)
        v |= (1 << (bits - 1)) if offset < 0 else 0
    else:
        v = offset
    while v:
        ob.append(v & 0xFF)
        v >>= 8
    # знаковость: старший бит последнего байта должен быть знаковым
    if ob and ob[-1] & 0x80:
        ob.append(0xFF if offset < 0 else 0x00)
    return bytes([len(lb) | (len(ob) << 4)]) + bytes(lb) + bytes(ob)


def attr_nonresident(atype, runs, alloc, real, init, flags=0, comp_unit=0):
    """Non-resident: заголовок 0x40 + runs. runs — bytes (готовые)."""
    total = 0x40 + len(runs)
    pad = (8 - total % 8) % 8
    total += pad
    hdr = u32(atype) + u32(total) + b'\x01' + b'\x00' + u16(0) + u16(flags) + \
        u16(0) + u64(0) + u64((alloc + CLUSTER - 1) // CLUSTER - 1) + \
        u16(0x40) + u16(comp_unit) + u32(0) + \
        u64(alloc) + u64(real) + u64(init)
    return bytes(hdr) + runs + b'\x00' * pad


def file_name_value(parent_mref, name, is_dir, real_size=0):
    """$FILE_NAME: parent + times + размеры + флаги + имя (UTF-16LE)."""
    nb = name.encode('utf-16-le')
    v = u64(parent_mref) + u64(0) * 4
    v += u64((real_size + CLUSTER - 1) // CLUSTER * CLUSTER)  # allocated
    v += u64(real_size)
    v += u32(0x10 if is_dir else 0x20)   # archive/dir
    v += u32(0)                           # reparse
    v += bytes([len(nb) // 2, 1])         # name len (chars), Win32 ns
    v += nb
    return v


def index_entry(mref, key, last=False, subnode=None):
    """Элемент индекса: mref + длины + флаги + key($FILE_NAME)."""
    ln = 0x10 + len(key) + (8 if subnode is not None else 0)
    flags = 0
    if last:
        flags |= 0x02
    if subnode is not None:
        flags |= 0x01
    e = u64(mref) + u16(ln) + u16(len(key)) + u16(flags) + u16(0) + key
    if subnode is not None:
        e += u64(subnode)
    return e


def index_root_value(entries):
    """"$INDEX_ROOT: type=FILE_NAME + элементы."""
    v = u32(0x30) + u32(1) + u32(INDX) + bytes([1]) + b'\x00' * 3
    v += b''.join(entries)
    return v


def apply_fixup(buf, magic):
    """Вставить USA: последние u16 каждого сектора → в массив, вместо них USN."""
    buf = bytearray(buf)
    usa_off = struct.unpack_from('<H', buf, 4)[0]
    nsec = len(buf) // SEC
    cnt = nsec + 1
    struct.pack_into('<H', buf, 6, cnt)
    usn = 0x4D4D
    # USA: [usn, orig0, orig1, ...]
    usa = bytearray(u16(usn))
    for s in range(nsec):
        off = s * SEC + SEC - 2
        usa += buf[off:off + 2]
        buf[off:off + 2] = u16(usn)
    buf[usa_off:usa_off + 2 * cnt] = usa
    return bytes(buf)


def make_record(rec_no, attrs, is_dir=False):
    """Запись MFT: заголовок + USA + атрибуты + END."""
    flags = 0x01 | (0x02 if is_dir else 0)
    hdr_len = 0x30
    # временный буфер для подсчёта: USA занимает 2*(2+1)=6 байт от 0x30
    body = b''.join(attrs) + u32(0xFFFFFFFF)
    used = 0x30 + 6 + len(body)
    while used % 8:
        body += b'\x00'
        used += 1
    assert 0x30 + 6 + len(body) <= REC - 2, \
        f"запись MFT не влезает: {0x36 + len(body)} > {REC}"
    buf = bytearray(REC)
    buf[0:4] = b'FILE'
    struct.pack_into('<H', buf, 4, 0x30)     # USA offset
    struct.pack_into('<H', buf, 6, 3)        # USA count (2 сектора + 1)
    buf[8:16] = u64(0)                       # $LSN
    struct.pack_into('<H', buf, 0x10, 1)     # sequence
    struct.pack_into('<H', buf, 0x12, 1)     # link count
    struct.pack_into('<H', buf, 0x14, 0x30 + 6)  # attrs offset
    struct.pack_into('<H', buf, 0x16, flags)
    struct.pack_into('<I', buf, 0x18, used)
    struct.pack_into('<I', buf, 0x1C, REC)
    buf[0x20:0x28] = u64(0)
    buf[0x30 + 6:0x30 + 6 + len(body)] = body
    return apply_fixup(bytes(buf), 'FILE')


def make_indx_block(entries, vcn):
    """INDX-блок: заголовок + USA + элементы."""
    body = b''.join(entries)
    total = 0x18 + len(body)
    if total > INDX - 2 * (INDX // SEC + 1):
        raise ValueError('INDX overflow')
    buf = bytearray(INDX)
    buf[0:4] = b'INDX'
    struct.pack_into('<H', buf, 4, 0x30)
    struct.pack_into('<H', buf, 6, INDX // SEC + 1)
    buf[8:16] = u64(0)
    buf[0x10:0x18] = u64(vcn)
    buf[0x18:0x18 + len(body)] = body
    return apply_fixup(bytes(buf), 'INDX')


# ---------------- LZNT1 ----------------

def lznt1_chunk_compress(data):
    """Сжать один 4096-байтовый чанк простым LZ77 (offset ≤ 4095, len 3..18).
    Валидный LZNT1-поток (не максимальное сжатие — этого достаточно).
    Совпадение может заходить за текущую позицию (перекрывающаяся копия):
    декомпрессор копирует побайтно out[op]=out[src], src всегда < op."""
    out = bytearray()
    i = 0
    while i < len(data):
        flags = 0
        group = bytearray()
        for b in range(8):
            if i >= len(data):
                break
            best_len = 0
            best_off = 0
            start = max(0, i - 4095)
            for j in range(start, i):
                l = 0
                while (i + l < len(data) and l < 18 and
                       data[j + l] == data[i + l]):
                    l += 1
                if l > best_len:
                    best_len = l
                    best_off = i - j
                    if best_len >= 18:
                        break
            if best_len >= 3:
                flags |= (1 << b)
                w = ((best_len - 3) << 12) | (best_off - 1)
                group += u16(w)
                i += best_len
            else:
                group.append(data[i])
                i += 1
        out.append(flags)
        out += group
    return bytes(out)


def lznt1_compress(data):
    """Сжатие по чанкам 4096 с заголовками 0xB000|((n-1)&0xFFF)."""
    out = bytearray()
    pos = 0
    while pos < len(data):
        chunk = data[pos:pos + 4096]
        pos += len(chunk)
        units = (len(chunk) + 4095) // 4096    # 1 для полного чанка
        comp = lznt1_chunk_compress(chunk)
        if len(comp) < len(chunk):
            out += u16(0x8000 | (units - 1)) + comp
        else:
            out += u16(units - 1) + chunk
    return bytes(out)


# ---------------- сборка образа ----------------

def build(path, mib, extra_files):
    total_secs = mib * 1024 * 1024 // SEC
    img = bytearray(mib * 1024 * 1024)

    ca = ClusterAlloc(DATA_LCN)    # данные сразу после $MFT
    records = {}                   # rec_no -> bytes

    # --- планирование: записи MFT ---
    # 0 $MFT, 1 $MFTMirr, 2 $LogFile, 3 $Volume, 4-5 reserved,
    # 5 = root (используем 5), 6+ файлы
    next_rec = [16]

    def new_rec():
        r = next_rec[0]
        next_rec[0] += 1
        return r

    def put_data(abs_lcn, blob):
        off = PART_START * SEC + abs_lcn * CLUSTER
        img[off:off + len(blob)] = blob

    root_rec = 5

    # --- $Volume (rec 3) ---
    records[3] = make_record(3, [
        attr_resident(0x60, 'NETBOOK'.encode('utf-16-le')),
    ])

    # --- содержимое ---
    files = []            # (name, is_dir, rec_no, parent_rec, data|None)
    dirs = {}             # name -> {entries: [(mref, key, name, is_dir, size)]}
    root_entries = []

    def add_file(parent, name, data, mref_holder, is_dir=False, size=None):
        r = new_rec()
        mref = r | (1 << 48)
        files.append((name, is_dir, r, parent, data, mref))
        return r

    # 1) resident: HELLO.TXT
    hello = b'Hello from NTFS! Sektor test.\n' * 2
    # 2) resident C-source: PROG.C
    prog = b'int main() {\n    return 42;\n}\n'
    # 3) non-resident: BIG.BIN — 40 КиБ псевдослучайных
    big = bytearray()
    x = 12345
    for i in range(40 * 1024):
        x = (x * 1103515245 + 12345) & 0x7FFFFFFF
        big.append(x & 0xFF)
    big = bytes(big)
    # 4) sparse: ZEROS.BIN — 5 кластеров дыр + 3 кластера данных
    sparse_tail = b'SPARSE-TAIL-DATA' + b'\x5A' * (3 * CLUSTER - 17)
    # 5) сжатый: COMP.BIN — 8 КиБ повторов (2 чанка)
    comp_data = (b'NTFS-COMPRESS-TEST-PATTERN-' * 320)[:8192]
    # 6) каталог DIR1 с INNER.TXT (resident)
    inner = b'Inner file in NTFS directory.\n'

    # записи:
    r_hello = new_rec()
    r_prog = new_rec()
    r_big = new_rec()
    r_zeros = new_rec()
    r_comp = new_rec()
    r_dir1 = new_rec()
    r_inner = new_rec()
    r_dirbig = new_rec()

    def mref(r):
        return r | (1 << 48)

    # --- кластеры данных ---
    big_lcn = ca.alloc(10)                     # 40 КиБ
    put_data(big_lcn, big)
    zeros_data_lcn = ca.alloc(3)               # хвост 3 кластера (5 до него — sparse)
    put_data(zeros_data_lcn, sparse_tail)
    comp_lcn = ca.alloc(1)
    comp_stream = lznt1_compress(comp_data)
    put_data(comp_lcn, comp_stream + b'\x00' * (CLUSTER - len(comp_stream)))

    # DIR1: маленький каталог — только INDEX_ROOT
    inner_key = file_name_value(mref(r_dir1), 'INNER.TXT', False, len(inner))
    dir1_entries = [
        index_entry(mref(r_inner), inner_key),
        index_entry(0, b'', last=True),
    ]

    # DIRBIG: 80 файлов — INDEX_ROOT (10) + INDX-блоки (70)
    dirbig_root_entries = []
    dirbig_indx_entries = []
    dirbig_files = []
    for i in range(80):
        name = f'FILE{i:03d}.DAT'
        content = f'dirbig file {i}\n'.encode()
        r = new_rec()
        dirbig_files.append((r, name, content))
    for i, (r, name, content) in enumerate(dirbig_files):
        key = file_name_value(mref(r_dirbig), name, False, len(content))
        e = index_entry(mref(r), key)
        if i < 5:
            dirbig_root_entries.append(e)
        else:
            dirbig_indx_entries.append(e)

    # INDX-блоки DIRBIG: 70 записей по ~100 б = ~7000 б → 2 блока
    indx_blocks = []
    chunk_sz = 35
    chunks = [dirbig_indx_entries[k:k + chunk_sz]
              for k in range(0, len(dirbig_indx_entries), chunk_sz)]
    dirbig_indx_lcns = []
    for ci, ch in enumerate(chunks):
        entries = ch + [index_entry(0, b'', last=True)]
        blk = make_indx_block(entries, vcn=ci)
        lcn = ca.alloc(1)
        put_data(lcn, blk)
        dirbig_indx_lcns.append(lcn)

    # --- записи MFT файлов ---
    root_mref = mref(root_rec)

    records[r_hello] = make_record(r_hello, [
        attr_resident(0x30, file_name_value(root_mref, 'HELLO.TXT', False, len(hello))),
        attr_resident(0x80, hello),
    ])
    records[r_prog] = make_record(r_prog, [
        attr_resident(0x30, file_name_value(root_mref, 'PROG.C', False, len(prog))),
        attr_resident(0x80, prog),
    ])
    records[r_big] = make_record(r_big, [
        attr_resident(0x30, file_name_value(root_mref, 'BIG.BIN', False, len(big))),
        attr_nonresident(0x80, encode_run(big_lcn, 10),
                         10 * CLUSTER, len(big), len(big)),
    ])
    # sparse: [дыра 5 кластеров][данные 3 кластера]
    runs_sparse = encode_run(0, 5) + encode_run(zeros_data_lcn, 3)
    records[r_zeros] = make_record(r_zeros, [
        attr_resident(0x30, file_name_value(root_mref, 'ZEROS.BIN', False, 8 * CLUSTER)),
        attr_nonresident(0x80, runs_sparse, 8 * CLUSTER, 8 * CLUSTER,
                         8 * CLUSTER, flags=0x4000),
    ])
    # сжатый: CU = 16 кластеров (comp_unit=4)
    records[r_comp] = make_record(r_comp, [
        attr_resident(0x30, file_name_value(root_mref, 'COMP.BIN', False, len(comp_data))),
        attr_nonresident(0x80, encode_run(comp_lcn, 1),
                         CLUSTER, len(comp_data), len(comp_data),
                         flags=0x0001, comp_unit=4),
    ])
    records[r_inner] = make_record(r_inner, [
        attr_resident(0x30, file_name_value(mref(r_dir1), 'INNER.TXT', False, len(inner))),
        attr_resident(0x80, inner),
    ])
    records[r_dir1] = make_record(r_dir1, [
        attr_resident(0x30, file_name_value(root_mref, 'DIR1', True, 0)),
        attr_resident(0x90, index_root_value(dir1_entries)),
    ], is_dir=True)
    # DIRBIG: INDEX_ROOT (первые 5) + INDEX_ALLOCATION (runs по блокам)
    dirbig_indx_entries_fin = dirbig_root_entries + [index_entry(0, b'', last=True)]
    runs_indx = b''
    prev = 0
    for lcn in dirbig_indx_lcns:
        runs_indx += encode_run(lcn - prev if prev else lcn, 1)
        prev = lcn
    records[r_dirbig] = make_record(r_dirbig, [
        attr_resident(0x30, file_name_value(root_mref, 'DIRBIG', True, 0)),
        attr_resident(0x90, index_root_value(dirbig_indx_entries_fin)),
        attr_nonresident(0xA0, runs_indx,
                         len(dirbig_indx_lcns) * CLUSTER,
                         len(dirbig_indx_lcns) * CLUSTER,
                         len(dirbig_indx_lcns) * CLUSTER),
        attr_resident(0xB0, bytes([0xFF] * len(dirbig_indx_lcns))),
    ], is_dir=True)
    for r, name, content in dirbig_files:
        records[r] = make_record(r, [
            attr_resident(0x30, file_name_value(mref(r_dirbig), name, False, len(content))),
            attr_resident(0x80, content),
        ])

    # --- корневой каталог (rec 5) ---
    root_list = [
        (mref(r_hello), 'HELLO.TXT', False, len(hello)),
        (mref(r_prog), 'PROG.C', False, len(prog)),
        (mref(r_big), 'BIG.BIN', False, len(big)),
        (mref(r_zeros), 'ZEROS.BIN', False, 8 * CLUSTER),
        (mref(r_comp), 'COMP.BIN', False, len(comp_data)),
        (mref(r_dir1), 'DIR1', True, 0),
        (mref(r_dirbig), 'DIRBIG', True, 0),
    ]
    root_entries = []
    for m, name, isdir, sz in root_list:
        key = file_name_value(root_mref, name, isdir, sz)
        root_entries.append(index_entry(m, key))
    root_entries.append(index_entry(0, b'', last=True))

    # INDX-блоки корня не нужны (всё в resident INDEX_ROOT)
    records[root_rec] = make_record(root_rec, [
        attr_resident(0x30, file_name_value(root_mref, '.', True, 0)),
        attr_resident(0x90, index_root_value(root_entries)),
    ], is_dir=True)

    # --- $MFT: фиксированный резерв MFT_RECORDS записей ---
    mft_recs = MFT_RECORDS
    mft_clusters = mft_recs * REC // CLUSTER
    # $LogFile (rec 2) — пустой resident; $MFTMirr (rec 1) — первые записи
    records[2] = make_record(2, [attr_resident(0x80, b'\x00' * 16)])

    def mft_blob():
        b = bytearray()
        for i in range(mft_recs):
            b += records.get(i, make_record(i, []))
        return b

    mft_bytes = mft_blob()
    # $MFTMirr: resident-копия 4 записей НЕ ВЛЕЗАЕТ в запись (4 КиБ > 1 КиБ).
    # Реальные тома хранят её non-resident; наш драйвер её не читает —
    # достаточно корректной пустой записи.
    records[1] = make_record(1, [
        attr_resident(0x80, b'\x00' * 16),
    ])
    records[0] = make_record(0, [
        attr_nonresident(0x80, encode_run(MFT_LCN, mft_clusters),
                         mft_clusters * CLUSTER, len(mft_bytes), len(mft_bytes)),
    ])
    mft_bytes = mft_blob()
    assert len(mft_bytes) == mft_clusters * CLUSTER, \
        f"MFT размер {len(mft_bytes)} != резерв {mft_clusters * CLUSTER}"
    put_data(MFT_LCN, bytes(mft_bytes))

    # --- boot-сектор NTFS (в начале раздела) ---
    part_secs = total_secs - PART_START
    bs = bytearray(SEC)
    bs[0:3] = b'\xEB\x52\x90'
    bs[3:11] = b'NTFS    '
    struct.pack_into('<H', bs, 0x0B, SEC)
    bs[0x0D] = SPC
    struct.pack_into('<H', bs, 0x0E, 0)        # reserved
    bs[0x10] = 0                                # media
    struct.pack_into('<H', bs, 0x11, 0)         # hidden sectors part
    struct.pack_into('<I', bs, 0x18, 0)
    struct.pack_into('<Q', bs, 0x28, part_secs)  # total sectors
    struct.pack_into('<Q', bs, 0x30, MFT_LCN)
    struct.pack_into('<Q', bs, 0x38, 0)          # $MFTMirr LCN
    bs[0x40] = 0xF6                              # -10: запись 1024 б
    bs[0x44] = 1                                  # 1 кластер на INDX
    struct.pack_into('<Q', bs, 0x48, 0)          # serial
    struct.pack_into('<I', bs, 0x50, 0)          # checksum
    bs[510:512] = b'\x55\xAA'
    off = PART_START * SEC
    img[off:off + SEC] = bs

    # --- MBR ---
    mbr = bytearray(SEC)
    mbr[0:16] = b'\x00' * 16
    # запись MBR = 16 байт: boot(1) + CHS start(3) + type(1) +
    # CHS end(3) + LBA start(4) + sectors(4)
    entry = bytes([0x80, 0x03, 0x00, 0x20]) + bytes([0x07]) + \
        bytes([0xFE, 0xFF, 0xFF]) + u32(PART_START) + u32(part_secs)
    assert len(entry) == 16, len(entry)
    mbr[0x1BE:0x1BE + 16] = entry
    mbr[510:512] = b'\x55\xAA'
    img[0:SEC] = mbr

    with open(path, 'wb') as f:
        f.write(img)

    print(f"mkntfs: {path}: {mib} МиБ, записей MFT: {mft_recs}, "
          f"кластер {SPC} сект., COMP.BIN {len(comp_data)} -> "
          f"{len(comp_stream)} б (LZNT1)")
    return True


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    build(sys.argv[1], int(sys.argv[2]), sys.argv[3:])
