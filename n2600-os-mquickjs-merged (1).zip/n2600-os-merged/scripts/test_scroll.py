#!/usr/bin/env python3
"""test_scroll.py — визуальная проверка прокрутки boot-лога.

Ранняя консоль (early LFB) и dbg()-строки должны прокручивать экран
вверх у нижнего края: последние строки лога всегда видимы.
Снимаем кадр в момент «wm_init...» (последняя dbg-строка до десктопа)
и проверяем, что текст лога доходит до низа экрана и виден вверху.
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/s10shots"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


glyphs = load_glyphs()

with QMon(ISO, ram=512) as q:
    # ждём предпоследнюю строку лога, пока экран ещё в текстовом режиме
    t0 = time.time()
    hit = False
    while time.time() - t0 < 90:
        s = q.serial()
        if "wm_init" in s:
            hit = True
            break
        time.sleep(0.15)
    check("wm_init достигнут (лог идёт)", hit)
    q.screendump(f"{SHOTS}/scroll-mid.ppm")
    # немедленно ещё один кадр: следующая строка лога
    time.sleep(0.3)
    q.screendump(f"{SHOTS}/scroll-mid2.ppm")

    # ждём полной загрузки
    t0 = time.time()
    while time.time() - t0 < 60:
        s = q.serial()
        if "entering main loop" in s or "Загрузка завершена" in s:
            break
        time.sleep(0.5)

# анализ кадров: лог должен занимать экран от верхних строк до низа.
# QEMU-скрин по умолчанию 800x600, строки по 16px.
from PIL import Image
for name in ("scroll-mid.ppm", "scroll-mid2.ppm"):
    p = f"{SHOTS}/{name}"
    if not os.path.exists(p):
        check(f"{name}: кадр снят", False)
        continue
    img = Image.open(p).convert("L")
    w, h = img.size
    px = img.load()
    # ищем текстовые строки (пиксели ярче фона) в колонке 0..800
    rows_with_text = []
    for y in range(0, h, 2):
        cnt = 0
        for x in range(0, w, 3):
            if px[x, y] > 100:
                cnt += 1
        if cnt >= 3:
            rows_with_text.append(y)
    if not rows_with_text:
        check(f"{name}: лог на экране", False, "нет текста")
        continue
    top, bot = rows_with_text[0], rows_with_text[-1]
    fill = (bot - top) / h
    # текст должен простираться почти до низа (>85% высоты) — т.е. лог
    # НЕ ушёл за экран, экран прокрутился
    check(f"{name}: лог доходит до низа (заполнение {fill:.0%})",
          bot > h * 0.85 and top < h * 0.25, f"top={top} bottom={bot} h={h}")
    # OCR последних строк
    tail = ocr_at(p, 4, bot - 32, 100, glyphs)
    print("   хвост лога:", repr(tail[:100]))

print()
print(f"ИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
if FAIL:
    print("Провалено:", ", ".join(FAIL))
    sys.exit(1)
