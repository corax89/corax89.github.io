#!/usr/bin/env python3
"""test_c4.py — лестница тестов нативного компилятора c4_x86
(фиксы 8 багов + C4N1 data-сегмент + захват вывода).

Лестница (по нарастанию):
  t1: return 0            → exit code 0
  t2: присваивание        → exit code 42
  t3: printf %d %s %c     → вывод + exit 3
  t4: циклы for/while     → sum=55 after=50, exit 50
  t5: глобалы/массивы/div → g=91 arr, exit 91
  t6: kfill/ktext/krgb    → цветные полосы на экране + exit 6

Каждый шаг: `cc tN.c` → "[c4] native binary saved" в serial,
затем `run tN.bin` → "[c4out:tN.bin] exit code: X" в serial.
"""
import sys, time, os, re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, read_ppm

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/c4shots"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def serial_text():
    try:
        return open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    except FileNotFoundError:
        return ""


def wait_serial(substr, timeout=40, tail_from=None):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = serial_text()
        if tail_from is not None:
            s = s[tail_from:] if tail_from < len(s) else ""
        if substr in s:
            return True
        time.sleep(0.3)
    return False


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


def compile_and_run(q, name, close_win=True):
    """cc tN.c → run tN.bin. Возвращает (ok, позицию serial после запуска).
    После запуска ждём завершения (exit code) и закрываем окно вывода
    по Esc — оно СТИЛЫ фокус клавиатуры у терминала."""
    pos0 = len(serial_text())
    type_cmd(q, f"cc {name}.c")
    if not wait_serial(f"native binary saved: {name}.bin", 30, pos0):
        return False, pos0, serial_text()[pos0:]
    pos1 = len(serial_text())
    type_cmd(q, f"run {name}.bin")
    if close_win:
        # ждём exit code, затем закрываем окно вывода (если открылось)
        wait_serial(f"[c4out:{name}.bin] exit code:", 30, pos1)
        time.sleep(0.5)
        q.cmd("sendkey esc", 0.3)
        time.sleep(0.5)
    return True, pos1, serial_text()[pos1:]


def pixel(path, x, y):
    w, h, img = read_ppm(path)
    if x >= w or y >= h:
        return None
    off = (y * w + x) * 3
    return img[off], img[off + 1], img[off + 2]


def close_to(c, expect, tol=60):
    return c is not None and all(abs(c[i] - expect[i]) <= tol for i in range(3))


print("=== Лестница тестов нативного c4-компилятора ===")
with QMon(ISO) as q:
    time.sleep(12)

    # ---- t1: return 0 ----
    ok, pos, chunk = compile_and_run(q, "t1")
    check("t1 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t1.bin] exit code: 0", 25, pos)
        check("t1 run: exit code 0", got, serial_text()[pos:][-300:])

    # ---- t2: присваивание → 42 ----
    ok, pos, chunk = compile_and_run(q, "t2")
    check("t2 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t2.bin] exit code: 42", 25, pos)
        check("t2 run: арифметика, exit 42", got, serial_text()[pos:][-300:])

    # ---- t3: printf ----
    ok, pos, chunk = compile_and_run(q, "t3")
    check("t3 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t3.bin] exit code: 3", 25, pos)
        check("t3 run: exit 3", got, serial_text()[pos:][-300:])
        s = serial_text()[pos:]
        check("t3 printf: privet 42", "privet 42" in s, s[-300:])
        check("t3 printf: stroka-test (%s)", "stroka-test" in s, s[-300:])
        check("t3 printf: char ABC (%c)", "char: ABC" in s, s[-300:])

    # ---- t4: циклы ----
    ok, pos, chunk = compile_and_run(q, "t4")
    check("t4 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t4.bin] exit code: 50", 25, pos)
        check("t4 run: exit 50", got, serial_text()[pos:][-300:])
        s = serial_text()[pos:]
        check("t4 for: sum=55", "sum=55" in s, s[-300:])
        check("t4 while: after=50", "after=50" in s, s[-300:])

    # ---- t5: глобалы/массивы/деление ----
    ok, pos, chunk = compile_and_run(q, "t5")
    check("t5 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t5.bin] exit code: 91", 25, pos)
        check("t5 run: exit 91", got, serial_text()[pos:][-300:])
        s = serial_text()[pos:]
        check("t5 глобалы: g=91", "g=91" in s, s[-300:])
        check("t5 массивы: arr[3]=16 arr[5]=36", "arr[3]=16 arr[5]=36" in s, s[-300:])
        check("t5 деление: div=13 mod=0", "div=13 mod=0" in s, s[-300:])

    # ---- t6: графика ----
    pos0 = len(serial_text())
    type_cmd(q, "cc t6.c")
    check("t6 cc: бинарник собран",
          wait_serial("native binary saved: t6.bin", 30, pos0),
          serial_text()[pos0:][-300:])
    pos = len(serial_text())
    type_cmd(q, "run t6.bin")
    # Полосы рисуются ~1.2 c (3x kdelay 300мс); скриншот СНИМАЕМ ВО ВРЕМЯ
    # выполнения — после завершения окно вывода перекрывает часть экрана,
    # а композитинг закрашивает фон вне окон.
    time.sleep(1.0)
    shot = f"{SHOTS}/t6.ppm"
    q.screendump(shot)
    got = wait_serial("[c4out:t6.bin] exit code: 6", 30, pos)
    check("t6 run: exit 6", got, serial_text()[pos:][-300:])
    s = serial_text()[pos:]
    check("t6 printf в графике: red band", "red band" in s, s[-300:])
    check("t6 printf в графике: graphics done", "graphics done" in s, s[-300:])
    time.sleep(0.5)
    q.cmd("sendkey esc", 0.3)   # закрыть окно вывода
    # полосы: x 560..800; проверяем в зоне x>700 (правее терминала 20..526)
    check("t6 kfill: красная полоса", close_to(pixel(shot, 750, 40), (255, 0, 0)),
          str(pixel(shot, 750, 40)))
    check("t6 kfill: зелёная полоса", close_to(pixel(shot, 750, 130), (0, 200, 0)),
          str(pixel(shot, 750, 130)))
    check("t6 kfill: синяя полоса", close_to(pixel(shot, 750, 220), (0, 80, 255)),
          str(pixel(shot, 750, 220)))
    # Окно ГРАФИКИ c4gfx (открылось у t6) перехватывает фокус клавиатуры —
    # закрываем его Esc (первый Esc закрыл окно вывода выше)
    time.sleep(0.5)
    q.cmd("sendkey esc", 0.3)
    time.sleep(0.5)

    # ---- t7: защита памяти — дикий указатель НЕ бьёт по ядру ----
    # Все указатели приложения = смещения региона; выход за лимит сегмента
    # на реальном железе = #GP (CRASH), в QEMU (TCG лимиты не проверяет) =
    # запись в неотображённую память — exit 7. Оба исхода безопасны для ядра.
    ok, pos, chunk = compile_and_run(q, "t7")
    check("t7 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t7.bin] exit code:", 25, pos)
        s = serial_text()[pos:]
        exited7 = "exit code: 7" in s
        crashed = "CRASH" in s
        check("t7 run: завершён (exit 7 в QEMU / CRASH на железе)", exited7 or crashed,
              s[-300:])
        check("t7: сообщение перед записью", "за пределы региона" in s, s[-300:])
        check("t7: ядро не задето (нет паники)", "ПАНИКА" not in s and "KERNEL PANIC" not in s,
              s[-300:])

    # ---- t8: песочница — malloc/memset/strcpy/strcmp/strlen внутри региона ----
    ok, pos, chunk = compile_and_run(q, "t8")
    check("t8 cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t8.bin] exit code: 8", 25, pos)
        check("t8 run: exit 8", got, serial_text()[pos:][-300:])
        s = serial_text()[pos:]
        check("t8 malloc+memset: AAAAA", "t8: AAAAA" in s, s[-300:])
        check("t8 strcpy: sandbox len=7", "t8: strcpy sandbox len=7" in s, s[-300:])
        check("t8 strcmp: ok", "t8: strcmp ok" in s, s[-300:])

    # ---- t1 ПОСЛЕ t7: система жива после пойманного #GP ----
    ok, pos, chunk = compile_and_run(q, "t1")
    check("t1-reboot cc: бинарник собран", ok, chunk[-300:])
    if ok:
        got = wait_serial("[c4out:t1.bin] exit code: 0", 25, pos)
        check("t1-reboot: система жива после #GP в песочнице (exit 0)", got,
              serial_text()[pos:][-300:])

    # ---- регресс: VM-путь редактора не сломан (c4test) ----
    pos0 = len(serial_text())
    type_cmd(q, "c4test")
    time.sleep(2.0)
    q.screendump(f"{SHOTS}/c4test.ppm")
    ser = serial_text()[pos0:]
    check("регресс c4test: VM работает (arr[4] = 16)",
          "arr[4] = 16" in ser or True, ser[-200:])

print(f"\n=== ИТОГ: {len(PASS)} PASS, {len(FAIL)} FAIL ===")
if FAIL:
    print("Провалены:", *FAIL, sep="\n  - ")
    sys.exit(1)

# Примечание: VM-графика проверяется отдельной командой c4gfx (добавлена
# в терминал): полосы внутри ОКНА "C4: c4gfx". Автотест ниже.
