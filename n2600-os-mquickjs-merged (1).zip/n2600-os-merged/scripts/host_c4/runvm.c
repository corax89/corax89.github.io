/* runvm.c — запустить один c4-исходник через VM (c4_run) и напечатать
 * результат: exit-код и выходной буфер. Для отладки switch. */
#include "string.h"
#include "mem.h"
extern int printf(const char *fmt, ...);
extern void exit(int code) __attribute__((noreturn));
typedef unsigned int u32;
#include "c4.h"

struct window;
int ramfs_ready(void) { return 0; }
int ramfs_delete(const char *n) { (void)n; return 0; }
int ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int ramfs_write(const char *n, const void *b, u32 s) { (void)n; (void)b; (void)s; return 0; }
u32 timer_ticks(void) { static u32 t; return ++t; }
void task_yield(void) { }
void kbd_pop(void) { }
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r<<16)|((u32)g<<8)|b; }
void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
void c4_gfx_fill_screen(u32 c) { (void)c; }
u32 c4_gfx_width(void) { return 800; }
u32 c4_gfx_height(void) { return 600; }
void c4_gfx_flip(struct window *w) { (void)w; }
int c4_gfx_event_poll(void *buf) { (void)buf; return 0; }
int loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }
void serial_puts(const char *s) { (void)s; }

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: runvm '<c4 source>'\n"); return 1; }
    static char out[16384];
    int rc = c4_run(argv[1], out, sizeof(out));
    printf("--- exit=%d ---\n%s", rc, out);
    return 0;
}
