#!/bin/bash
# Хост-сборка тестбеда нативного c4-кодогенератора (i386, статическая).
# Тулчейн собран вручную из .deb (без root): 32-бит libc.a из libc6-dev-i386,
# libgcc.a/crtbegin из libgcc-14-dev:i386.
set -e
cd "$(dirname "$0")"
LIBC32=${LIBC32:-/tmp/libc32/usr/lib32}
GCC32=${GCC32:-/tmp/gcc32/usr/lib/gcc/i686-linux-gnu/14}

# 0) Свежие копии c4-файлов (чтобы quoted-include шли в shim, а не в src/)
mkdir -p gen
cp ../../src/c4.c ../../src/c4.h ../../src/c4_x86.c ../../src/kapi.h gen/

# 1) Компиляция (без libc-заголовков)
gcc -m32 -g -O2 -fno-pie -Wall -ffreestanding -fno-builtin \
    -I shim -I gen -I ../../src \
    -c harness.c -o harness.o
gcc -m32 -g -O2 -fno-pie -Wall -ffreestanding -fno-builtin \
    -I shim -I gen -I ../../src \
    -c gen/c4.c -o c4.o
gcc -m32 -g -O2 -fno-pie -Wall -ffreestanding -fno-builtin \
    -I shim -I gen -I ../../src \
    -c gen/c4_x86.c -o c4_x86.o

# 2) Линковка (ld напрямую; динамическая — через qemu-i386 -L /tmp/libc32root)
ld -m elf_i386 -o harness \
    "$LIBC32/crt1.o" "$LIBC32/crti.o" "$GCC32/crtbegin.o" \
    harness.o c4.o c4_x86.o \
    "$GCC32/crtend.o" "$LIBC32/crtn.o" \
    --start-group "$GCC32/libgcc.a" "$GCC32/libgcc_eh.a" --end-group \
    --dynamic-linker /lib/ld-linux.so.2 \
    -rpath /usr/lib \
    "$LIBC32/libc.so.6" "$LIBC32/libm.so.6" "$LIBC32/ld-linux.so.2"
echo "OK: harness (32-bit dynamic, запускать: qemu-i386 -L /tmp/libc32root ./harness)"
