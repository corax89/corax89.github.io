/* irdump.c — дамп байт-кода c4 (для отладки switch/case эмиттера).
 * Компилирует исходник через c4_compile (compile-only) и печатает
 * текст-пул пофчейково с именами опкодов и расшифровкой целей
 * переходов (cell index). Запуск: irdump '<src>' */
#include "string.h"
#include "mem.h"
extern int printf(const char *fmt, ...);
extern void exit(int code) __attribute__((noreturn));
typedef unsigned int u32;
#include "c4.h"

/* опкоды c4 (дубликат enum из c4.c — там он не экспортирован) */
enum {
    LEA=0, IMM, JMP, JSR, BZ, BNZ, ENT, ADJ, LEV, LI, LC, SI, SC, PSH,
    OR, XOR, AND, EQ, NE, LT, GT, LE, GE, SHL, SHR, ADD, SUB, MUL, DIV, MOD,
    OPEN, READ, CLOS, PRTF, MALC, FREE, MSET, MCMP, EXIT,
    KINIT, KQUIT, KDELAY, KFILL, KTEXT, KFLIP, KRGB, KEVENT,
    KCLEAR, KW, KH, KMTIME, STRLEN, STRCPY, STRCMP, USHR
};

static const char *opnames[] = {
    "LEA","IMM","JMP","JSR","BZ","BNZ","ENT","ADJ","LEV","LI","LC","SI","SC","PSH",
    "OR","XOR","AND","EQ","NE","LT","GT","LE","GE","SHL","SHR","ADD","SUB","MUL","DIV","MOD",
    "OPEN","READ","CLOS","PRTF","MALC","FREE","MSET","MCMP","EXIT",
    "KINIT","KQUIT","KDELAY","KFILL","KTEXT","KFLIP","KRGB","KEVENT",
    "KCLEAR","KW","KH","KMTIME","STRLEN","STRCPY","STRCMP","USHR"
};
#define N_OPS (int)(sizeof(opnames)/sizeof(opnames[0]))

/* операнды этих опкодов — цели переходов (указатели на ячейки) */
static int is_jump_op(int op) {
    return op == JMP || op == JSR || op == BZ || op == BNZ;
}
/* операнды этих опкодов — смещения (LEA) или счётчики (ADJ) */
static int has_imm_operand(int op) {
    return op == LEA || op == IMM || op == JMP || op == JSR || op == BZ ||
           op == BNZ || op == ENT || op == ADJ || op == PRTF;
}

/* ---- заглушки окружения ОС (как в harness.c) ---- */
struct window;
int ramfs_ready(void) { return 0; }
int ramfs_delete(const char *n) { (void)n; return 0; }
int ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int ramfs_write(const char *n, const void *b, u32 s) { (void)n; (void)b; (void)s; return 0; }
u32 timer_ticks(void) { static u32 t; return ++t; }
void task_yield(void) { }
void kbd_pop(void) { }
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r<<16)|((u32)g<<8)|b; }
void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
void c4_gfx_fill_screen(u32 c) { (void)c; }
u32 c4_gfx_width(void) { return 800; }
u32 c4_gfx_height(void) { return 600; }
void c4_gfx_flip(struct window *w) { (void)w; }
int c4_gfx_event_poll(void *buf) { (void)buf; return 0; }
int loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }
void serial_puts(const char *s) { (void)s; }

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: irdump '<c4 source>'\n"); return 1; }
    static int bc[65536];
    static u8  dat[65536];
    u32 bc_len = 0, dat_len = 0, entry = 0;
    char diag[256] = {0};
    if (!c4_compile(argv[1], diag, sizeof(diag), bc, sizeof(bc), &bc_len,
                    dat, sizeof(dat), &dat_len, &entry)) {
        printf("COMPILE ERROR: %s\n", diag);
        return 1;
    }
    printf("cells=%u data=%u entry@cell %u  (pool base not known here; jump targets shown as raw int)\n",
           bc_len, dat_len, entry);
    u32 c = 1;
    while (c < bc_len) {
        int op = bc[c];
        if (op < 0 || op >= N_OPS) {
            printf("%4u: ??? (%d = 0x%x)\n", c, op, (unsigned)op);
            c++;
            continue;
        }
        if (has_imm_operand(op)) {
            int v = bc[c + 1];
            if (is_jump_op(op))
                printf("%4u: %-6s -> raw 0x%08x\n", c, opnames[op], (unsigned)v);
            else
                printf("%4u: %-6s %d\n", c, opnames[op], v);
            c += 2;
        } else {
            printf("%4u: %s\n", c, opnames[op]);
            c++;
        }
    }
    return 0;
}
