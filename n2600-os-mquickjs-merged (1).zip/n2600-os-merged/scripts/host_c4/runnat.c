/* runnat.c — скомпилировать c4-исходник в native и запустить entry()
 * (как run_test в harness.c), печать exit-кода и вывода. Отладка t11. */
#include "string.h"
#include "mem.h"
extern int printf(const char *fmt, ...);
extern void exit(int code) __attribute__((noreturn));
extern int fprintf(void *stream, const char *fmt, ...);
extern char *getenv(const char *name);
extern void *stderr;
extern int fflush(void *f);
typedef unsigned int u32;
typedef unsigned char u8_;
#include "c4.h"
#include "kapi.h"

static u32 host_ticks = 0;
u32 timer_ticks(void) { return ++host_ticks; }
void task_yield(void) { }
void task_msleep(u32 ms) { (void)ms; }
int kbd_pop(void *ev) { (void)ev; return 0; }
void fb_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
void fb_touch_all(void) { }
void fb_flush(void) { }
int fb_width(void) { return 800; }
int fb_height(void) { return 600; }
void fb_fill_screen(u32 c) { (void)c; }
struct window;
void win_invalidate_stub(struct window *w) { (void)w; }
int ramfs_ready(void) { return 0; }
int ramfs_delete(const char *n) { (void)n; return 0; }
int ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int ramfs_write(const char *n, const void *b, u32 s) { (void)n; (void)b; (void)s; return 0; }
u32 ramfs_read(const char *n, void *b, u32 m) { (void)n; (void)b; (void)m; return 0; }
void serial_puts(const char *s) { (void)s; }
void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
void c4_gfx_fill_screen(u32 c) { (void)c; }
u32 c4_gfx_width(void) { return 800; }
u32 c4_gfx_height(void) { return 600; }
void c4_gfx_flip(struct window *w) { (void)w; }
int c4_gfx_event_poll(void *buf) { (void)buf; return 0; }
int loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }

static char g_out[16384];
static u32 g_out_len = 0;
static void h_print_str(const char *s, u32 len) {
    for (u32 i = 0; i < len && g_out_len + 1 < sizeof(g_out); i++)
        g_out[g_out_len++] = s[i];
    g_out[g_out_len] = 0;
}
static int h_printf_va(const char *fmt, int nargs, int *args_reversed) {
    int nprinted = 0;
    int actual = nargs - 1;
    if (actual < 0) actual = 0;
    int argidx = 0;
    while (*fmt) {
        if (*fmt != '%') { g_out[g_out_len++] = *fmt++; nprinted++; continue; }
        fmt++;
        if (*fmt == 'd') {
            if (argidx < actual) {
                int v = args_reversed[actual - 1 - argidx];
                char b[16]; int i = 0;
                if (v < 0) { g_out[g_out_len++] = '-'; v = -v; nprinted++; }
                do { b[i++] = '0' + v % 10; v /= 10; } while (v);
                while (i--) { g_out[g_out_len++] = b[i]; nprinted++; }
                argidx++;
            }
            fmt++;
        } else if (*fmt == 's') {
            if (argidx < actual) {
                const char *s = (const char *)(unsigned long)args_reversed[actual - 1 - argidx];
                if (s) while (*s) { g_out[g_out_len++] = *s++; nprinted++; }
                argidx++;
            }
            fmt++;
        } else if (*fmt == 'c') {
            if (argidx < actual) {
                g_out[g_out_len++] = (char)args_reversed[actual - 1 - argidx];
                nprinted++;
                argidx++;
            }
            fmt++;
        } else if (*fmt == 'x') {
            if (argidx < actual) {
                u32 v = (u32)args_reversed[actual - 1 - argidx];
                for (int i = 28; i >= 0; i -= 4) {
                    int d = (v >> i) & 0xF;
                    g_out[g_out_len++] = d < 10 ? '0' + d : 'a' + d - 10;
                    nprinted++;
                }
                argidx++;
            }
            fmt++;
        } else {
            g_out[g_out_len++] = '%'; nprinted++;
            if (*fmt) { g_out[g_out_len++] = *fmt++; nprinted++; }
        }
    }
    g_out[g_out_len] = 0;
    return nprinted;
}

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: runnat '<c4 source>'\n"); return 1; }
    static u8 out_buf[256 * 1024];
    u32 out_size = 0;
    char diag[256] = {0};
    int r = c4_compile_to_native(argv[1], diag, sizeof(diag), out_buf, sizeof(out_buf), &out_size);
    if (r != 0) { printf("COMPILE FAIL: %s\n", diag); return 1; }
    extern u8 c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int c4_x86_n_data_relocs_out;
    u32 data_len = c4_x86_data_out_len;
    u32 n_rel = (u32)c4_x86_n_data_relocs_out;
    extern void *mmap(void *addr, unsigned long len, int prot, int flags, int fd, long off);
    u8 *code = (u8 *)mmap(0, (out_size + 4095) & ~4095UL, 7, 0x22, -1, 0);
    memcpy(code, out_buf, out_size);
    u8 *data = data_len ? malloc(data_len) : NULL;
    if (data_len) memcpy(data, c4_x86_data_out, data_len);
    for (u32 i = 0; i < n_rel; i++)
        *(u32 *)(code + c4_x86_data_relocs_out[i]) += (u32)(unsigned long)data;
    kapi_t k;
    memset(&k, 0, sizeof(k));
    k.fb_fill_rect = fb_fill_rect;
    k.fb_text = fb_text;
    k.fb_rgb = fb_rgb;
    k.fb_fill_screen = fb_fill_screen;
    k.win_invalidate = win_invalidate_stub;
    k.fb_width = (u32 (*)(void))fb_width;
    k.fb_height = (u32 (*)(void))fb_height;
    k.c4_print_str = h_print_str;
    k.c4_event_poll = c4_gfx_event_poll;
    k.c4_printf_va = h_printf_va;
    k.msleep = task_msleep;
    g_out_len = 0; g_out[0] = 0;
    int (*entry)(kapi_t *, void *) = (int (*)(kapi_t *, void *))(void *)code;
    int rc = entry(&k, NULL);
    printf("--- exit=%d ---\n%s", rc, g_out);
    return 0;
}
