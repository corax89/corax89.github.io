#ifndef SHIM_TASK_H
#define SHIM_TASK_H
#include "types.h"
void task_yield(void);
void task_msleep(u32 ms);
#endif
