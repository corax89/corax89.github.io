#ifndef SHIM_TIMER_H
#define SHIM_TIMER_H
#include "types.h"
u32 timer_ticks(void);
#endif
