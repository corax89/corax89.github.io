#ifndef SHIM_KBD_H
#define SHIM_KBD_H
#include "types.h"
typedef struct { u8 ch; u8 code; u8 flags; } key_event_t;
int kbd_pop(key_event_t *ev);
#endif
