#ifndef SHIM_FB_H
#define SHIM_FB_H
#include "types.h"
void fb_fill_rect(int x, int y, int w, int h, u32 color);
void fb_text(int x, int y, const char *s, u32 fg, int bg);
u32  fb_rgb(u8 r, u8 g, u8 b);
void fb_touch_all(void);
void fb_flush(void);
int  fb_width(void);
int  fb_height(void);
void fb_fill_screen(u32 color);
#endif
