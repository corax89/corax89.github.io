#include "string.h"
#include "mem.h"
extern int printf(const char *fmt, ...);
extern int fprintf(void *stream, const char *fmt, ...);
extern void *stderr;
int c4_run(const char *src_text, char *out, u32 out_max);
static void t(const char *label, const char *src) {
    char out[4096] = {0};
    fprintf(stderr, "--- %s ---\n", label);
    int r = c4_run(src, out, sizeof(out));
    fprintf(stderr, "rc=%d out=\"%s\"\n", r, out);
}
int main(void) {
    t("return 5", "int main() { return 5; }");
    t("assign", "int main() { int a; a = 3; return a; }");
    t("add", "int main() { int a; a = 3 + 4; return a; }");
    t("addvar", "int main() { int a; int b; a = 3; b = a + 1; return b; }");
    t("loop", "int main() { int i; int s; s = 0; for (i = 0; i < 5; i = i + 1) { s = s + i; } return s; }");
    t("printf", "int main() { printf(\"hi %d\\n\", 7); return 1; }");
    return 0;
}
