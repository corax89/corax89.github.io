#!/usr/bin/env python3
"""test_s5.py — сессия 5 (БЕЗ МЫШИ: PS/2-клики в QEMU нестабильны).

Порядок подобран так, чтобы терминал оставался единственным/верхним окном
на этапах печати команд: каждый pop-up (браузер после curl, HTTP Trace,
Файлы) закрывается по Esc. Диспетчер задач проверяется ПОСЛЕДНИМ.

Геометрия (800x600, TBAR_H=28, TITLE_H=24):
  Терминал: окно (20,16) 506x318, строки (25, 45+16i).
  Часы таскбара: x 700..796, y 574..600 — тикают каждую секунду,
  пока жив kmain (детектор «система жива/заморожена»).
  Диспетчер: окно (100,40) 620x384, строки задач (105, 107+16i).
  HTTP Trace: окно (60,60) 732x480, строки отчёта (65, 109+16i).
  Файлы: окно (30,30) 520x380, панель устройств (43,59), путь (37,80),
  строки списка (37, 102+18i).
"""
import sys, time, os, threading, http.server, socketserver, re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at, ocr_strip, read_ppm

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/s5shots"
os.makedirs(SHOTS, exist_ok=True)
os.makedirs("/tmp/shots", exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


# ---------------- HTTP-сервер ----------------
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = (b"<html><head><title>N2600-OS test</title></head>"
                b"<body><h1>Zagolovok testa</h1>"
                b"<p>HTTP works from N2600-OS via QEMU user-net.</p>"
                b"</body></html>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


socketserver.TCPServer.allow_reuse_address = True
httpd = socketserver.TCPServer(("127.0.0.1", 8081), H)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
print("HTTP-сервер 127.0.0.1:8081 (гостю: 10.0.2.2:8081)")


def wait_serial(substr, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
            if substr in s:
                return True
        except FileNotFoundError:
            pass
        time.sleep(0.3)
    return False


def serial_text():
    try:
        return open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    except FileNotFoundError:
        return ""


def clock_region(path):
    w, h, img = read_ppm(path)
    box = []
    for y in range(574, min(600, h)):
        base = y * w * 3
        for x in range(700, min(796, w)):
            off = base + x * 3
            box.append(img[off:off + 3])
    return b"".join(box)


def clock_ticks(q, tag, gap=3.0):
    a = f"{SHOTS}/{tag}-a.ppm"
    b = f"{SHOTS}/{tag}-b.ppm"
    q.screendump(a)
    time.sleep(gap)
    q.screendump(b)
    return clock_region(a) != clock_region(b)


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


def term_lines(path, n=6, y0=45):
    return ocr_strip(path, 25, y0, 60, n)


print("\n=== Сессия 5: ramfs-процесс, dmesg, disks, nettrace, живучесть ===")
with QMon(ISO) as q:
    time.sleep(12)
    q.screendump(f"{SHOTS}/01-boot.ppm")

    # --- T1: загрузка ---
    lines = term_lines(f"{SHOTS}/01-boot.ppm", 3)
    print("  терминал:", lines[:2])
    check("T1 загрузка: приветствие терминала",
          any("N2600-OS" in l for l in lines), str(lines))
    ser = serial_text()
    check("T1 serial: ramfs-сервер запущен",
          "ramfs: сервер запущен (задача 1)" in ser, ser[-400:])
    check("T1 serial: irq on", "irq on" in ser)

    # --- T2: tasks → ramfs (системная) ---
    type_cmd(q, "tasks")
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/02-tasks.ppm")
    tl = term_lines(f"{SHOTS}/02-tasks.ppm", 10)
    print("  tasks:", [l for l in tl if l.strip()][:8])
    check("T2 tasks: ramfs в списке", any("ramfs" in l for l in tl), str(tl))
    check("T2 tasks: ramfs помечена системной",
          any("ramfs" in l and "(" in l.split("ramfs", 1)[1] for l in tl),
          str(tl))

    # --- T4: dmesg (до диспетчера — терминал единственное окно) ---
    type_cmd(q, "dmesg")
    time.sleep(2)
    q.screendump(f"{SHOTS}/04-dmesg.ppm")
    dl = term_lines(f"{SHOTS}/04-dmesg.ppm", 16)
    print("  dmesg:", [l for l in dl if l.strip()][:16])
    check("T4 dmesg: журнал выводится (вехи загрузки)",
          any("e1000_init" in l or "task_init" in l or "wifi" in l
              or "usb" in l or "sata:" in l or "netcfg:" in l
              for l in dl), str(dl))
    check("T4 dmesg: конец журнала (полный вывод)",
          any("кoнeц жypнaлa" in l or "конец журнала" in l for l in dl), str(dl))

    # --- T5: disks ---
    type_cmd(q, "disks")
    time.sleep(2)
    q.screendump(f"{SHOTS}/05-disks.ppm")
    dkl = term_lines(f"{SHOTS}/05-disks.ppm", 16)
    print("  disks:", [l for l in dkl if l.strip()][:16])
    check("T5 disks: CD/ATAPI виден", any("CD" in l for l in dkl), str(dkl))
    check("T5 disks: RAM disk виден", any("RAM" in l for l in dkl), str(dkl))
    check("T5 disks: ISO9660 готов", any("ISO" in l for l in dkl), str(dkl))

    # --- T6: spin — система жива ---
    type_cmd(q, "spin")
    time.sleep(2)
    alive = clock_ticks(q, "06-spin")
    check("T6 spin: система жива (часы тикают)", alive)
    type_cmd(q, "clear")
    time.sleep(0.6)
    type_cmd(q, "tasks")
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/07-spin-tasks.ppm")
    st = term_lines(f"{SHOTS}/07-spin-tasks.ppm", 10)
    spin_id = None
    for l in st:
        if "spin" in l:
            m = re.search(r"\[(\d+)\]", l)
            if m:
                spin_id = m.group(1)
            break
    check("T6 spin: задача spin в списке", spin_id is not None, str(st))

    # --- T7: kill spin ---
    if spin_id:
        type_cmd(q, f"kill {spin_id}")
        time.sleep(2)
        alive = clock_ticks(q, "08-kill")
        check("T7 kill spin: система жива после kill", alive)
        type_cmd(q, "clear")
        time.sleep(0.6)
        type_cmd(q, "tasks")
        time.sleep(1.5)
        q.screendump(f"{SHOTS}/09-after-kill.ppm")
        ak = term_lines(f"{SHOTS}/09-after-kill.ppm", 10)
        check("T7 kill spin: задачи spin нет",
              not any(("spin" in l and "spinlock" not in l) for l in ak), str(ak))
    else:
        check("T7 kill spin: id найден", False, str(st))

    # --- T8: curl HTTP (браузер откроется поверх — закроем по Esc) ---
    type_cmd(q, "curl http://10.0.2.2:8081/")
    ok = wait_serial("[curl] 10.0.2.2:8081 ->", timeout=45)
    ser = serial_text()
    check("T8 curl: HTTP-ответ получен", ok, ser[-300:])
    time.sleep(2)          # дать браузеру отрисовать контент
    q.screendump(f"{SHOTS}/08b-browser.ppm")
    # браузер (50,16) 700x420: контент-оригин (51,41), строки canvas(4,24) → (55,65)
    br = ocr_strip(f"{SHOTS}/08b-browser.ppm", 55, 65, 80, 4)
    print("  браузер:", [l for l in br if l.strip()][:4])
    check("T8 curl: браузер показывает страницу",
          any("Zagolovok" in l or "HTTP works" in l or "N2600" in l for l in br),
          str(br))
    q.cmd("sendkey esc", 0.4)   # закрыть браузер
    time.sleep(1)
    ser = serial_text()
    check("T8 curl: нет ошибки запроса", "Ошибка запроса" not in ser[-3000:]
          and "response timeout" not in ser[-3000:])

    # --- T9: HTTP Trace (терминал снова единственное окно) ---
    type_cmd(q, "spawn nettrace")
    time.sleep(2.5)
    q.cmd("sendkey ctrl-l", 0.2)
    q.sendkeys("http://10.0.2.2:8081/", delay=0.05)
    time.sleep(0.3)
    q.cmd("sendkey ret", 0.3)
    time.sleep(8)                # трассировка (таймаут клиента 12 с)
    q.screendump(f"{SHOTS}/10-nettrace.ppm")
    nt = ocr_strip(f"{SHOTS}/10-nettrace.ppm", 65, 109, 90, 14)
    print("  nettrace:", [l for l in nt if l.strip()][:14])
    check("T9 nettrace: окно открылось (HTTP TRACE)",
          any("TRACE" in l or "HTTP" in l for l in nt), str(nt[:4]))
    check("T9 nettrace: тайминги фаз", any("ARP" in l or "TCP" in l or "DNS" in l
                                           for l in nt), str(nt))
    check("T9 nettrace: ИТОГ", any("ИТОГ" in l or "OK" in l for l in nt), str(nt))
    check("T9 nettrace: точный запрос (GET)",
          any("GET /" in l for l in nt), str(nt))
    q.cmd("sendkey esc", 0.4)   # закрыть nettrace
    time.sleep(1)

    # --- T10: файловый менеджер [CD][HDD][RAM][USB] ---
    type_cmd(q, "spawn files")
    time.sleep(2.5)
    q.screendump(f"{SHOTS}/11-files.ppm")
    fm_dev = ocr_at(f"{SHOTS}/11-files.ppm", 43, 59, 40)
    fm_hdr = ocr_at(f"{SHOTS}/11-files.ppm", 37, 80, 40)
    print("  fileman devbar:", repr(fm_dev))
    print("  fileman path:", repr(fm_hdr))
    check("T10 fileman: окно открылось (панель устройств)",
          "CD" in fm_dev or "RAM" in fm_dev, fm_dev)
    check("T10 fileman: кнопка CD на панели", "CD" in fm_dev, fm_dev)
    check("T10 fileman: CD активен по умолчанию (ISO9660: /)",
          "ISO" in fm_hdr or "CD" in fm_hdr, fm_hdr)
    fm_list = ocr_strip(f"{SHOTS}/11-files.ppm", 37, 102, 44, 4)
    print("  fileman список:", [l for l in fm_list if l.strip()])
    check("T10 fileman: список корня CD непуст",
          any("boot" in l or "grub" in l or "[D]" in l for l in fm_list),
          str(fm_list))
    q.cmd("sendkey esc", 0.4)   # закрыть Файлы (новое: Esc)
    time.sleep(1)

    # --- T11-13: spinlock — заморозка и восстановление ---
    print("  ... spinlock: UI замрёт ~20 с, ждём восстановления")
    type_cmd(q, "spinlock")
    time.sleep(3)
    frozen = not clock_ticks(q, "12-frozen", gap=3.0)
    check("T11 spinlock: UI заморожен (баг воспроизведён)", frozen)

    recovered_ser = wait_serial("[sync]", timeout=35)
    time.sleep(2.5)
    alive = clock_ticks(q, "13-recovered", gap=3.0)
    check("T12 spinlock: serial-сообщение о восстановлении", recovered_ser)
    check("T13 spinlock: UI ожил после отбора блокировки", alive)
    # окна должны ПЕРЕЖИТЬ заморозку (lock_wait + wake-grace защищают)
    q.screendump(f"{SHOTS}/13b-alive.ppm")
    tt = ocr_at(f"{SHOTS}/13b-alive.ppm", 28, 20, 12)
    rows = term_lines(f"{SHOTS}/13b-alive.ppm", 18)
    check("T13 spinlock: окно терминала пережило заморозку",
          "epм" in tt or "ерм" in tt, repr(tt))
    check("T13 spinlock: терминал отвечает (команды в scrollback)",
          any("spinlock" in l for l in rows), str(rows))

    # --- T14: убить spinlock-задачу ---
    type_cmd(q, "clear")
    time.sleep(0.6)
    type_cmd(q, "tasks")
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/14-tasks2.ppm")
    t2 = term_lines(f"{SHOTS}/14-tasks2.ppm", 12)
    sl_id = None
    for l in t2:
        if "spinlock" in l:
            m = re.search(r"\[(\d+)\]", l)
            if m:
                sl_id = m.group(1)
            break
    if sl_id:
        type_cmd(q, f"kill {sl_id}")
        time.sleep(2)
        alive = clock_ticks(q, "15-final", gap=3.0)
        check("T14 kill spinlock: система жива", alive)
    else:
        check("T14 kill spinlock: id найден", False, str(t2))

    # --- T3: диспетчер задач ПОСЛЕДНИМ (терминал больше не нужен) ---
    type_cmd(q, "spawn taskmgr")
    time.sleep(3)
    q.cmd("sendkey down")
    q.cmd("sendkey down")
    time.sleep(1)
    q.screendump(f"{SHOTS}/03-taskmgr.ppm")
    rows = ocr_strip(f"{SHOTS}/03-taskmgr.ppm", 105, 107, 50, 8)
    print("  taskmgr rows:", [r for r in rows if r.strip()][:8])
    check("T3 taskmgr: строка ramfs", any("ramfs" in r for r in rows), str(rows))
    ramfs_rows = [r for r in rows if "ramfs" in r]
    check("T3 taskmgr: ramfs SYS-статус", any("SYS" in r for r in ramfs_rows),
          str(ramfs_rows))
    big = any("ramfs" in r and any(tok.isdigit() and int(tok) > 40000
                                   for tok in r.replace("K", " ").split())
              for r in ramfs_rows)
    check("T3 taskmgr: ramfs Mem > 40 МБ (владение ramdisk)", big, str(ramfs_rows))

    time.sleep(1)
    q.screendump(f"{SHOTS}/16-final.ppm")
    ser = serial_text()
    wd = [l for l in ser.splitlines() if "watchdog" in l]
    print("  watchdog-сообщения:", wd if wd else "(нет — окна не убивались)")

print(f"\n=== ИТОГ: {len(PASS)} PASS, {len(FAIL)} FAIL ===")
if FAIL:
    print("Провалены:", FAIL)
sys.exit(1 if FAIL else 0)
