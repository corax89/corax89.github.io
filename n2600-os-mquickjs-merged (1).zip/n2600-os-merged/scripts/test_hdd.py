#!/usr/bin/env python3
"""test_hdd.py — проверка видимости НЖМД (FAT32) с диском, подключенным
к IDE: disks-команда, fileman [HDD], чтение файла с HDD."""
import sys, time, os, subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at, ocr_strip

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
IMG = "/tmp/s5_hdd.img"
SHOTS = "/tmp/s5shots"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


# --- создать FAT32-образ (mkfat32.py — без root/mkfs.fat) ---
def make_hdd():
    if os.path.exists(IMG):
        os.unlink(IMG)
    with open("/tmp/hello_hdd.txt", "w") as f:
        f.write("Hello from HDD! Test file.\n")
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, f"{here}/mkfat32.py", IMG, "64",
                        "N2600HDD", "/tmp/hello_hdd.txt:HELLO.TXT"],
                       capture_output=True, text=True)
    print("  mkfat32:", r.stdout.strip() or r.stderr.strip())
    return os.path.exists(IMG) and os.path.getsize(IMG) > 1024



ok_img = make_hdd()
print("FAT32-образ:", "создан" if ok_img else "НЕ создан")
if not ok_img:
    sys.exit(2)

# --- загрузка с НЖМД на Secondary Slave (CD на Secondary Master,
#     HDD на Primary Master — как в реальной машине) ---
EXTRA = ["-drive", f"file={IMG},format=raw,if=ide,index=0,media=disk"]
with QMon(ISO, extra_args=EXTRA) as q:
    # ждём фоновую инициализацию дисков (сессия 11: FAT32 монтируется
    # фоновой задачей sata после старта ОС)
    t0 = time.time()
    while time.time() - t0 < 60:
        if "sata: инициализация дисков завершена" in q.serial():
            break
        time.sleep(1)
    time.sleep(1)
    type_cmd(q, "disks")
    time.sleep(2.5)
    q.screendump(f"{SHOTS}/h1-disks.ppm")
    rows = ocr_strip(f"{SHOTS}/h1-disks.ppm", 25, 45, 60, 16)
    print("  disks:", [l for l in rows if l.strip()][:16])
    joined = "".join(rows)
    check("HDD: строка НЖМД в disks", any("HDD" in l for l in rows), str(rows))
    # OCR читает кириллицу гомоглифами (o вместо о) — сравниваем по-простому
    check("HDD: модель/размер видны (QEMU HARDDISK, МиБ)",
          any("HDD" in l and ("QEMU" in l or "MиБ" in l or "МиБ" in l) for l in rows),
          str(rows))
    nospace = joined.replace(" ", "")
    check("HDD: FAT32 смонтирован (FAT32 готов)",
          "FAT32" in nospace and ("гот" in nospace or "гoт" in nospace), nospace[-200:])

    # --- fileman: кнопка [HDD] ---
    type_cmd(q, "spawn files")
    time.sleep(2.5)
    q.screendump(f"{SHOTS}/h2-files.ppm")
    # Tab переключает: CD → HDD (после Tab активная кнопка [HDD] яркая)
    q.cmd("sendkey tab", 0.5)
    q.screendump(f"{SHOTS}/h2b-files-tab.ppm")
    # сетка глифов кнопок начинается с x=97 ([HDD] яркая — активный режим)
    fm_hdd = ocr_at(f"{SHOTS}/h2b-files-tab.ppm", 97, 59, 6, bright=200)
    fm_dev = ocr_at(f"{SHOTS}/h2b-files-tab.ppm", 43, 59, 40)
    print("  fileman [HDD]:", repr(fm_hdd))
    print("  fileman devbar (после Tab):", repr(fm_dev))
    check("fileman: [HDD] на панели (яркая после Tab)", "HDD" in fm_hdd, fm_hdd)
    q.screendump(f"{SHOTS}/h3-files-hdd.ppm")
    fm_hdr = ocr_at(f"{SHOTS}/h3-files-hdd.ppm", 37, 80, 40)
    fm_list = ocr_strip(f"{SHOTS}/h3-files-hdd.ppm", 37, 102, 44, 4)
    print("  fileman путь:", repr(fm_hdr))
    print("  fileman список:", [l for l in fm_list if l.strip()])
    check("fileman: Tab → FAT32 режим", "FAT32" in fm_hdr or "HDD" in fm_hdr, fm_hdr)
    check("fileman: файл HELLO.TXT с HDD виден",
          any("HELLO" in l or "TXT" in l for l in fm_list), str(fm_list))
    q.cmd("sendkey esc", 0.4)
    time.sleep(1)

print(f"\n=== ИТОГ: {len(PASS)} PASS, {len(FAIL)} FAIL ===")
if FAIL:
    print("Провалены:", FAIL)
sys.exit(1 if FAIL else 0)
