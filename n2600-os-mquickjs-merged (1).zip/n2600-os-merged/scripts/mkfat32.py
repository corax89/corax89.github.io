#!/usr/bin/env python3
"""mkfat32.py — минимальный генератор superfloppy-FAT32 (без MBR):
boot sector (BPB) + 2 FAT + корневой кластер с файлами.

Совместим с fat32.c N2600-OS:
  bps=512, spc=1 (кластер 512 байт — зато кластеров >65525, как требует
  проверка FAT32), rsvd=32, nfats=2, 'FAT32'@82, label@71, 55AA.

Использование: mkfat32.py <img> <размер_МиБ> <label> [файл:имя ...]
  файл:имя — добавить локальный файл как 8.3-имя (HELLO.TXT).
"""
import sys, struct, os


def dir_entry(name83, attr, cluster, size, del_ok=True):
    e = bytearray(32)
    # имя 8.3
    base, _, ext = name83.partition(".")
    base = base.upper().ljust(8)[:8]
    ext = ext.upper().ljust(3)[:3]
    e[0:11] = (base + ext).encode("ascii")
    e[11] = attr
    # времена/даты не важны для чтения — нули
    e[20:22] = struct.pack("<H", cluster >> 16)   # first cluster HI
    e[26:28] = struct.pack("<H", cluster & 0xFFFF)  # first cluster LO
    e[28:32] = struct.pack("<I", size)
    return bytes(e)


def main():
    img_path = sys.argv[1]
    size_mib = int(sys.argv[2])
    label = sys.argv[3][:11].upper().ljust(11)
    files = []          # (local_path, name83)
    for a in sys.argv[4:]:
        lp, _, n83 = a.partition(":")
        files.append((lp, n83))

    total_secs = size_mib * 1024 * 1024 // 512
    spc = 1
    rsvd = 32
    nfats = 2
    # FAT: (кластеров+2) * 4 байта, кластеры ≈ total_secs - rsvd - fats
    # подбор: fsz = ceil((total_secs - rsvd) * 4 / 512 / (1 + 2*4/512)) — просто
    # фиксируем fsz так, чтобы хватило на все кластеры
    fsz = (total_secs * 4 // 512) + 8
    data_start = rsvd + nfats * fsz
    clusters = (total_secs - data_start) // spc
    assert clusters >= 65525, f"мало кластеров: {clusters}"

    img = bytearray(total_secs * 512)

    # ---- boot sector ----
    bs = bytearray(512)
    bs[0:3] = b"\xEB\x58\x90"          # jump
    bs[3:11] = b"MKFSPY  "             # OEM
    bs[11:13] = struct.pack("<H", 512)      # bytes/sector
    bs[13] = spc                            # sectors/cluster
    bs[14:16] = struct.pack("<H", rsvd)     # reserved
    bs[16] = nfats                          # fats
    bs[17:19] = struct.pack("<H", 0)        # root entries (FAT32=0)
    bs[19:21] = struct.pack("<H", 0)        # total16 (FAT32=0)
    bs[21] = 0xF8                           # media HDD
    bs[22:24] = struct.pack("<H", 0)        # fat16 (0)
    bs[24:26] = struct.pack("<H", 63)       # sectors/track
    bs[26:28] = struct.pack("<H", 255)      # heads
    bs[28:32] = struct.pack("<I", 0)        # hidden
    bs[32:36] = struct.pack("<I", total_secs)
    bs[36:40] = struct.pack("<I", fsz)      # fat32 size
    bs[40:42] = struct.pack("<H", 0)        # ext flags
    bs[44:48] = struct.pack("<I", 2)        # root cluster
    bs[48:50] = struct.pack("<H", 1)        # fs info sector
    bs[50:52] = struct.pack("<H", 6)        # backup boot sector
    bs[62:64] = struct.pack("<H", 0x80)     # drive number
    bs[510:512] = b"\x55\xAA"
    bs[71:82] = label.encode("ascii")       # volume label (11)
    bs[82:90] = b"FAT32   "                 # fs type
    img[0:512] = bs

    # ---- FAT ----
    fat = bytearray(fsz * 512)
    fat[0:4] = b"\xF8\xFF\xFF\x0F"          # entry 0
    fat[4:8] = b"\xFF\xFF\xFF\x0F"          # entry 1
    # entry 2 = корневой каталог (EOC)
    fat[8:12] = b"\xFF\xFF\xFF\x0F"
    for i in range(nfats):
        off = (rsvd + i * fsz) * 512
        img[off:off + len(fat)] = fat

    # ---- корневой каталог (кластер 2) ----
    root_off = data_start * 512
    dirb = bytearray(512)
    # метка тома
    lbl = bytearray(32)
    lbl[0:11] = label.encode("ascii")
    lbl[11] = 0x08                          # ATTR_VOLUME_ID
    dirb[0:32] = lbl
    # файлы
    cl = 3
    off = 32
    for (lp, n83) in files:
        data = open(lp, "rb").read()
        ncl = max(1, (len(data) + 511) // 512)
        dirb[off:off + 32] = dir_entry(n83, 0x20, cl, len(data))
        off += 32
        # цепочка FAT + данные
        for k in range(ncl):
            fe = cl + k
            fo = fe * 4
            val = 0x0FFFFFFF if k == ncl - 1 else (fe + 1)
            fat[fo:fo + 4] = struct.pack("<I", val)
            do = (data_start + (fe - 2) * spc) * 512
            chunk = data[k * 512:(k + 1) * 512]
            img[do:do + len(chunk)] = chunk
        cl += ncl
    # обновить обе FAT (файлы добавили записи)
    for i in range(nfats):
        off2 = (rsvd + i * fsz) * 512
        img[off2:off2 + len(fat)] = fat
    img[root_off:root_off + 512] = dirb

    with open(img_path, "wb") as f:
        f.write(img)
    print(f"OK: {img_path} ({size_mib} МиБ, {clusters} кластеров, "
          f"fsz={fsz}, файлов: {len(files)})")


if __name__ == "__main__":
    main()
