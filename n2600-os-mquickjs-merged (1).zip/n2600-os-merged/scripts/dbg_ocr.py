#!/usr/bin/env python3
"""dbg_ocr.py — полный OCR скриншота построчно (терминальная зона шире)."""
import sys
sys.path.insert(0, "/home/z/my-project/work/n2600/proj/scripts")
from qmon import ocr_at, load_glyphs

GL = load_glyphs()
path = sys.argv[1]
x0 = int(sys.argv[2]) if len(sys.argv) > 2 else 21
y0 = int(sys.argv[3]) if len(sys.argv) > 3 else 41
rows = int(sys.argv[4]) if len(sys.argv) > 4 else 24
cols = int(sys.argv[5]) if len(sys.argv) > 5 else 90
for r in range(rows):
    t = ocr_at(path, x0, y0 + r * 16, cols, GL, 400)
    print(f"{r:3d} y={y0 + r*16:4d}: {t}")
