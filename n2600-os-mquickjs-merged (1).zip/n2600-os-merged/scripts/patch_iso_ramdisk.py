#!/usr/bin/env python3
"""patch_iso_ramdisk.py — заменить содержимое /boot/ramdisk в os.iso НА СТАРОМ
МЕСТЕ (внутри существующего слота), не трогая ядро, GRUB и El Torito.

update_iso.py пишет ramdisk в хвост образа; когда хвост мал (ядро выросло),
это падает с 'ramdisk+grub.cfg do not fit into tail'. Этот скрипт использует
СВОБОДНЫЙ СЛОТ старого ramdisk-экстента (между началом ramdisk и grub.cfg):

  1) находит каталог /boot/ramdisk в PVD (ISO9660) и в SVD (Joliet);
  2) определяет слот: [ramdisk_lba, first_sector_of_next_file) — до grub.cfg;
  3) пишет новые файлы последовательно после каталога ramdisk;
  4) пересобирает содержимое каталога ('.', '..', файлы) для обоих томов;
  5) проверяет, что ничего за пределами слота не тронуто.

Использование: python3 scripts/patch_iso_ramdisk.py [путь-к-os.iso]
"""
import os
import struct
import sys

SECT = 2048
HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, ".."))
RAMDISK_SRC = os.path.join(PROJ, "ramdisk")


def dir_records(data, extent, size):
    off = 0
    end = extent * SECT + size
    abs_start = extent * SECT
    while abs_start + off < end:
        rec = abs_start + off
        ln = data[rec]
        if ln == 0:
            nxt = (off // SECT + 1) * SECT
            if nxt >= size:
                return
            off = nxt
            continue
        lba = struct.unpack('<I', data[rec + 2:rec + 6])[0]
        fsize = struct.unpack('<I', data[rec + 10:rec + 14])[0]
        flags = data[rec + 25]
        nlen = data[rec + 32]
        raw = data[rec + 33:rec + 33 + nlen]
        yield rec, lba, fsize, flags, raw
        off += ln


def iso_name(raw, joliet):
    if len(raw) == 1 and raw[0] in (0, 1):
        return chr(raw[0])
    if joliet:
        s = raw.decode('utf-16-be', errors='replace')
    else:
        s = raw.decode('latin1', errors='replace')
    return s.split(';')[0].lower().rstrip()


def walk_tree(data, root_lba, root_size, joliet=False):
    out = {}
    seen = {root_lba}
    stack = [("/", root_lba, root_size)]
    while stack:
        prefix, lb, sz = stack.pop()
        for rec, lba, fsize, flags, raw in dir_records(data, lb, sz):
            nm = iso_name(raw, joliet)
            if nm in ("", "\x00", "\x01"):
                continue
            path = prefix + nm
            out[path] = (lba, fsize, rec)
            if flags & 0x02 and lba not in seen:
                seen.add(lba)
                stack.append((path + "/", lba, fsize))
    return out


def make_dir_record(lba, size, is_dir, name_bytes):
    nm = name_bytes
    n = len(nm)
    total = n + 1 + (34 - 1)
    total = (n + 34) + (n % 2) if False else n + 34 + (n % 2)
    total = n + 34 + (n % 2)  # base record is 33 bytes + 1? см. update_iso: 34 хвостовых
    # как в update_iso.make_dir_record: total = len + even; поля ниже согласованы
    total = 33 + n + (n % 2)
    rec = bytearray(total)
    rec[0] = total
    struct.pack_into('<I', rec, 2, lba)
    struct.pack_into('>I', rec, 6, lba)
    struct.pack_into('<I', rec, 10, size)
    struct.pack_into('>I', rec, 14, size)
    rec[25] = 0x02 if is_dir else 0x00
    struct.pack_into('<H', rec, 28, 1)
    struct.pack_into('>H', rec, 30, 1)
    rec[32] = n
    rec[33:33 + n] = nm
    if n % 2:
        rec[33 + n] = 0
    return bytes(rec)


def collect_files():
    files = []
    for nm in sorted(os.listdir(RAMDISK_SRC)):
        p = os.path.join(RAMDISK_SRC, nm)
        if os.path.isfile(p):
            files.append((nm, open(p, 'rb').read()))
    return files


def build_dirbuf(rd_lba, boot_lba, boot_size, fslots):
    buf = bytearray()
    buf += make_dir_record(rd_lba, SECT, True, b'\x00')
    buf += make_dir_record(boot_lba, boot_size or SECT, True, b'\x01')
    for nm, blob, lba, ln in fslots:
        if not blob:
            continue
        if len(nm) <= 8 and '.' not in nm:
            nm_iso = nm.upper().encode('ascii')
        else:
            base, _, ext = nm.partition('.')
            nm_iso = (base.upper()[:8] + ('.' + ext.upper()[:3] if ext else '')).encode('ascii')
        nm_iso += b';1'
        buf += make_dir_record(lba, ln, False, nm_iso)
    assert len(buf) <= SECT, f"directory too big: {len(buf)}"
    buf += b'\x00' * (SECT - len(buf))
    return bytes(buf)


def build_dirbuf_joliet(rd_lba, boot_lba, boot_size, fslots):
    buf = bytearray()
    buf += make_dir_record(rd_lba, SECT, True, b'\x00')
    buf += make_dir_record(boot_lba, boot_size or SECT, True, b'\x01')
    for nm, blob, lba, ln in fslots:
        if not blob:
            continue
        buf += make_dir_record(lba, ln, False, nm.encode('utf-16-be'))
    assert len(buf) <= SECT, f"joliet dir too big: {len(buf)}"
    buf += b'\x00' * (SECT - len(buf))
    return bytes(buf)


def patch_volume(data, root_lba, root_size, joliet, files, report):
    tree = walk_tree(data, root_lba, root_size, joliet=joliet)
    rd = tree.get('/boot/ramdisk') or tree.get('/boot/ramdisk'.rstrip('/'))
    boot = tree.get('/boot') or tree.get('/boot/')
    if not rd or not boot:
        report.append("  ramdisk/boot не найдены — пропуск тома")
        return False
    rd_lba, rd_size, rd_rec = rd
    boot_lba, boot_size, boot_rec = boot

    # границы слота: от rd_lba до ближайшего экстента ДО ramdisk включительно,
    # затем до grub.cfg/конца. Слот ограничим первым экстентом, лежащим ПОСЛЕ
    # ramdisk (grub.cfg и пр.), найденным по всему дереву.
    # старые файлы ramdisk (из текущего каталога) — они внутри слота
    old_inner = set()
    for rec, lba, fsize, flags, raw in dir_records(data, rd_lba, rd_size):
        if not (len(raw) == 1 and raw[0] in (0, 1)):
            old_inner.add(lba)
    nexts = [lba for (lba, sz, rec) in tree.values()
             if lba > rd_lba and lba not in old_inner]
    slot_end_lba = min(nexts) if nexts else None
    # grub.cfg может лежать ВНУТРИ слота — он уже учтён как 'next'.

    files_sorted = sorted(files)
    # каталог ramdisk: 1 сектор, файлы со следующих секторов
    cursor = (rd_lba + 1) * SECT
    fslots = []
    for nm, blob in files_sorted:
        if not blob:
            fslots.append((nm, blob, None, 0))
            continue
        lba = cursor // SECT
        nsec = (len(blob) + SECT - 1) // SECT
        cursor += nsec * SECT
        fslots.append((nm, blob, lba, len(blob)))
    last_used = cursor // SECT
    if slot_end_lba is not None and last_used > slot_end_lba:
        raise RuntimeError(
            f"ramdisk не влезает в слот [{rd_lba}..{slot_end_lba}): "
            f"нужно {last_used - rd_lba} секторов")

    # 1) очистить слот (кроме сектора каталога — его пишем сразу после)
    if slot_end_lba is not None:
        for l in range(rd_lba + 1, slot_end_lba):
            data[l * SECT:(l + 1) * SECT] = b'\x00' * SECT
    # 2) каталог ramdisk
    if joliet:
        dirbuf = build_dirbuf_joliet(rd_lba, boot_lba, boot_size, fslots)
    else:
        dirbuf = build_dirbuf(rd_lba, boot_lba, boot_size, fslots)
    data[rd_lba * SECT:rd_lba * SECT + SECT] = dirbuf
    # 3) файлы
    for nm, blob, lba, ln in fslots:
        if blob:
            data[lba * SECT:lba * SECT + len(blob)] = blob
    report.append(f"  {'Joliet' if joliet else 'ISO9660'}: ramdisk lba={rd_lba}, "
                  f"файлов={sum(1 for _, b, _, _ in fslots if b)}, "
                  f"занято до lba={last_used - 1}, слот до {slot_end_lba}")
    return True


def main():
    iso_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PROJ, "prebuilt", "os.iso")
    data = bytearray(open(iso_path, 'rb').read())
    files = collect_files()
    report = []

    sec = 16
    patched = 0
    while True:
        vd = data[sec * SECT:(sec + 1) * SECT]
        if vd[1:6] != b"CD001":
            break
        t = vd[0]
        if t in (1, 2):
            root_lba = struct.unpack('<I', vd[156 + 2:156 + 6])[0]
            root_size = struct.unpack('<I', vd[156 + 10:156 + 14])[0]
            if patch_volume(data, root_lba, root_size, t == 2, files, report):
                patched += 1
        if t == 255:
            break
        sec += 1

    for line in report:
        print(line)
    if patched == 0:
        print("ERROR: ни один том не пропатчен")
        return 1
    with open(iso_path, 'wb') as f:
        f.write(data)
    print(f"OK: {iso_path} обновлён (томов: {patched})")
    return 0


if __name__ == '__main__':
    sys.exit(main())
