#!/usr/bin/env python3
"""test_format.py — сессия 12: вкладки Настроек + форматирование FAT32.

Сценарий (QEMU, IDE-диск c NTFS-подобным мусором → формат → FAT32):
  1) диск с НЕподдерживаемой ФС (случайные данные): кнопка [HDD] в
     «Файлах» НЕ показывается (фильтр источников), вкладка «Диски»
     показывает «ФС: не распознана»;
  2) Настройки → Диски → F (формат) → предупреждение → Enter;
  3) прогресс формата доходит до конца; диск перемонтируется FAT32;
  4) «Файлы»: кнопка [HDD] появляется, в serial — [fmt] и fat32 ok;
  5) tabs: клавиша Tab переключает Сеть<->Диски (скриншот).
"""
import sys, time, os, subprocess, json, urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
IMG = "/tmp/s12_fmt.img"
SHOTS = "/tmp/s12shots"
os.makedirs(SHOTS, exist_ok=True)
PASS, FAIL = [], []

def vlm_ask(prompt, *imgs):
    """Спросить VLM про скриншоты (CLI z-ai vision)."""
    args = ["z-ai", "vision", "-p", prompt]
    for i in imgs:
        args += ["-i", i]
    out = "/tmp/s12shots/_vlm.json"
    r = subprocess.run(args + ["-o", out], capture_output=True, text=True, timeout=180)
    try:
        return json.load(open(out))["choices"][0]["message"]["content"]
    except Exception:
        return ""

def ppm2png(ppm):
    from PIL import Image
    png = ppm.replace(".ppm", ".png")
    Image.open(ppm).save(png)
    return png

def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))

def make_junk_disk():
    """диск с мусором (нет 55AA в LBA0 → ФС не распознана)"""
    if os.path.exists(IMG):
        os.unlink(IMG)
    with open(IMG, "wb") as f:
        f.write(b"\x00" * 512 * 2048)          # 1 МиБ нулей
        f.write(os.urandom(512 * 2048))        # + 1 МиБ мусора
        f.truncate(64 * 1024 * 1024)           # 64 МиБ
    return os.path.exists(IMG)

W, H = 800, 600
MENU_BTN = (36, H - 28 + 14)
def menu_item_y(i): return 169 + i * 26 + 13
APP_FILES, APP_SETTINGS = 1, 10

def main():
    print("== подготовка: диск-мусор 64 МиБ ==")
    check("образ создан", make_junk_disk())

    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG},format=raw,if=ide,index=1,media=disk",
        ]) as q:
        time.sleep(16)   # загрузка: диск мусорный — sata/fat32 не смонтируются

        # --- открываем Настройки через терминал (open 10) ---
        q.sendkeys("open 10", delay=0.04)
        q.cmd("sendkey ret", 0.1)
        time.sleep(1.0)
        q.screendump(f"{SHOTS}/set-net-tab.ppm")

        # вкладка «Диски» клавишей Tab (окно в фокусе после открытия)
        q.cmd("sendkey tab", 0.1)
        time.sleep(0.6)
        q.screendump(f"{SHOTS}/set-disk-tab.ppm")
        ser = q.serial()
        check("sata-диск найден (IDE)", "ata: HDD" in ser or "disk: НЖМД" in ser, ser[-200:])

        # вкладка Диски: проверка рендера через VLM (OCR не выравнивается)
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window with two tabs "
            "[1] Сеть [2] Диски. Is the Диски (Disks) tab active? "
            "Does it show a hard disk line (НЖМД) and a filesystem line "
            "(ФС)? Answer briefly: TAB=disks/network, HDD=yes/no, "
            "FS_TEXT=<what it says>.",
            ppm2png(f"{SHOTS}/set-disk-tab.ppm"))
        print("  VLM:", ans[:200])
        check("вкладка Диски: НЖМД показан", "HDD=yes" in ans or "НЖМД" in ans, ans[:150])
        check("вкладка Диски: ФС не распознана", "не распознана" in ans, ans[:150])

        # --- 2) формат: F → подтверждение → Enter ---
        q.cmd("sendkey f", 0.1); time.sleep(0.6)
        q.screendump(f"{SHOTS}/set-fmt-warn.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window. Is there a RED "
            "warning box about formatting deleting all data (ВНИМАНИЕ/ "
            "УДАЛИТ ВСЕ ДАННЫЕ)? Answer: WARN=yes/no.",
            ppm2png(f"{SHOTS}/set-fmt-warn.ppm"))
        print("  VLM:", ans[:200])
        check("предупреждение о потере данных", "WARN=yes" in ans, ans[:150])

        # подтверждение: Enter — начнётся формат (64 МиБ, PIO ~минуты — ждём)
        q.cmd("sendkey ret", 0.1)
        t0 = time.time()
        done = False
        while time.time() - t0 < 240:   # до 4 минут
            time.sleep(5)
            ser = q.serial()
            if "структуры записаны" in ser:
                done = True
                break
        check("формат завершён ([fmt] структуры записаны)", done)
        ser = q.serial()
        check("FAT32 смонтирована после формата",
              "смонтирована после форматирования" in ser, ser[-300:])
        q.screendump(f"{SHOTS}/set-fmt-done.ppm")

        # --- 3) fileman: кнопка [HDD] теперь есть ---
        # закрываем Настройки (Esc), терминал снова в фокусе
        q.cmd("sendkey esc", 0.1)
        time.sleep(0.5)
        q.sendkeys("open 1", delay=0.04)
        q.cmd("sendkey ret", 0.1)
        time.sleep(1.2)
        q.screendump(f"{SHOTS}/fileman-after.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Files (Файлы) window. In the device "
            "button row at the top, which buttons are visible: CD, HDD, "
            "RAM, USB? Answer: BUTTONS=<list>.",
            ppm2png(f"{SHOTS}/fileman-after.ppm"))
        print("  VLM:", ans[:200])
        check("fileman: [HDD] появился", "HDD" in ans, ans[:150])

        # --- 4) вторая копия Файлов? нет — терминал уже открыт под
        # Настройками; проверяем через serial + скриншот fileman выше
        q.screendump(f"{SHOTS}/disks-after.ppm")
        ser = q.serial()

        # --- 5) до формата: [HDD] в Файлах не было? (проверяем по
        # скриншоту fileman ДО — откроем второе окно Files нечем;
        # вместо этого сверяем лог: fat32 not found при старте)
        ser_all = ser
        check("при загрузке FAT32 не найдена (мусор)",
              "not found" in ser_all or "no FAT32" in ser_all or "не найден" in ser_all,
              "")

    print(f"\nИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
    if FAIL:
        print("FAILURES:", FAIL)
    return 1 if FAIL else 0

if __name__ == "__main__":
    sys.exit(main())
