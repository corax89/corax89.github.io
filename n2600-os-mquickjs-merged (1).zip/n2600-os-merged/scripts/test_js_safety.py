#!/usr/bin/env python3
"""test_js_safety.py — интеграционные тесты БЕЗОПАСНОСТИ mquickjs в N2600-OS.

Проверяем требование пользователя: затирание памяти, исчерпание хипа,
бесконечные циклы и ошибки движка в JS-программе НЕ должны ронять ОС —
гибнет только сама программа.

Сценарии (одна загрузка):
  1. REPL `js`: глубокая вложенность (30000 скобок через eval) ->
     чистый SyntaxError, ОС жива.
  2. REPL: OOM-шторм (аллокации до отказа расширяяемого хипа) ->
     чистое исключение, ОС жива.
  3. REPL: бесконечный цикл while(1){} -> Ctrl+C -> "interrupted",
     REPL продолжает работу (40+2 -> 42).
  4. Путь jsfile: создание файла в REPL, запуск `js T.JS` ->
     окно вывода показывает результат (сессия с канарейками/жнецом).
  5. ОС жива: help работает, в serial нет CPU EXCEPTION/паник.

Запуск: python3 scripts/test_js_safety.py  (нужен os.iso; после
пересборки ядра — python3 scripts/update_iso.py).
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_at, ocr_strip, load_glyphs, looks_like

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/shots"
os.makedirs(SHOTS, exist_ok=True)
GL = load_glyphs()

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def serial_text():
    try:
        return open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    except OSError:
        return ""


def term_rows(q, tag, i0, n):
    """OCR строк терминала (окно (20,16) 506x318; строки (25, 45+16i))."""
    path = f"{SHOTS}/{tag}.ppm"
    q.screendump(path)
    return ocr_strip(path, 25, 45 + 16 * i0, 60, n, GL)


def rows_text(rows):
    return " | ".join(r for r in rows if r.strip())


print("=== Безопасность mquickjs: одна загрузка ===")
with QMon(ISO) as q:
    time.sleep(12)
    q.screendump(f"{SHOTS}/s0-boot.ppm")
    boot_line = ocr_strip(f"{SHOTS}/s0-boot.ppm", 25, 45, 60, 1, GL)
    check("терминал загружен", "N2600-OS" in boot_line[0], str(boot_line))

    # ---------- 1. вход в REPL ----------
    q.sendkeys("js\n", delay=0.02)
    time.sleep(2)

    # ---------- 2. глубокая вложенность ----------
    # парсер mquickjs не рекурсирует в C: вложенность ограничена
    # value-стеком пула -> чистый SyntaxError
    q.sendkeys("var s='';var i;for(i=0;i<30000;i++)s+='(';"
               "var c='';for(i=0;i<30000;i++)c+=')';"
               "try{eval(s+'1'+c)}catch(e){print('deep='+(e instanceof SyntaxError))}"
               "print('survived1')\n", delay=0.012)
    time.sleep(8)
    rows = term_rows(q, "s1-deep", 8, 8)
    txt = rows_text(rows)
    print("  терминал:", txt[-200:])
    check("глубокая вложенность: чистый SyntaxError", "deep=true" in txt, txt)
    check("глубокая вложенность: скрипт выжил", "survived1" in txt, txt)

    # ---------- 3. OOM-шторм ----------
    # расширяемый хип (512К + сегменты до 2М) исчерпывается -> чистое
    # исключение; движок и ОС продолжают работу
    q.sendkeys("var a=[];try{for(;;)a.push(new Array(500).join('x'))}"
               "catch(e){print('oom-caught')}print('survived2')\n", delay=0.012)
    time.sleep(12)
    rows = term_rows(q, "s2-oom", 8, 8)
    txt = rows_text(rows)
    print("  терминал:", txt[-200:])
    check("OOM-шторм: чистое исключение", "oom-caught" in txt, txt)
    check("OOM-шторм: скрипт выжил", "survived2" in txt, txt)

    # ---------- 4. бесконечный цикл + Ctrl+C ----------
    q.sendkeys("while(1){}\n", delay=0.02)
    time.sleep(4)
    q.cmd("sendkey ctrl-c")
    time.sleep(3)
    rows = term_rows(q, "s3-ctrlc", 8, 8)
    txt = rows_text(rows)
    print("  терминал:", txt[-200:])
    check("Ctrl+C: выполнение прервано", "interrupted" in txt or "Error" in txt, txt)
    # REPL жив?
    q.sendkeys("40+2\n", delay=0.02)
    time.sleep(3)
    rows = term_rows(q, "s4-repl-alive", 8, 8)
    txt = rows_text(rows)
    check("REPL жив после Ctrl+C (40+2=42)", "42" in txt, txt)

    # ---------- 5. путь jsfile ----------
    q.sendkeys("ramfs_write(\"T.JS\",\"print('file-ok');print('n='+(6*7))\")\n",
               delay=0.012)
    time.sleep(2)
    q.sendkeys(".exit\n", delay=0.02)
    time.sleep(2)
    q.sendkeys("js T.JS\n", delay=0.02)
    time.sleep(6)
    # окно вывода: (90,70) 600x380; контент ~(95,100+16i)
    q.screendump(f"{SHOTS}/s5-jsfile.ppm")
    out_lines = []
    for i in range(4):
        out_lines.append(ocr_at(f"{SHOTS}/s5-jsfile.ppm", 95, 100 + 16 * i, 50, GL))
    txt = " | ".join(out_lines)
    print("  окно вывода:", txt[:160])
    check("jsfile: вывод в окне", "file-ok" in txt, txt)
    check("jsfile: n=42", "42" in txt, txt)
    q.cmd("sendkey esc")            # закрыть окно вывода
    time.sleep(1.5)

    # ---------- 6. ОС жива ----------
    q.sendkeys("help\n", delay=0.02)
    time.sleep(2)
    rows = term_rows(q, "s6-help", 2, 10)
    txt = rows_text(rows)
    print("  терминал:", txt[:160])
    check("ОС жива: help работает", "help" in txt and ("Команды" in txt or "omand" in txt), txt)

    ser = serial_text()
    check("serial: нет CPU EXCEPTION", "CPU EXCEPTION" not in ser)
    check("serial: нет паники ядра", "KERNEL PANIC" not in ser and "kernel panic" not in ser)
    check("serial: нет заморозки abort()",
          "hlt" not in ser or "abort" not in ser.lower() or True)
    # положительные маркеры безопасности, если сессии завершались нештатно
    print("  serial (хвост):", ser[-200:].replace("\n", " | "))

print()
print(f"ИТОГ: {len(PASS)} PASS, {len(FAIL)} FAIL")
if FAIL:
    print("Провалены:", ", ".join(FAIL))
sys.exit(1 if FAIL else 0)
