#!/usr/bin/env python3
"""test_ahci.py — проверка AHCI/SATA-драйвера в QEMU.

Диск подключается через AHCI (-device ahci), как на реальном железе
(Atom N2600/NM10: SATA-контроллер в режиме AHCI). Проверяется:
  1) ОС грузится до рабочего стола;
  2) в serial-логе есть [ahci]-строки обнаружения диска и IDENTIFY;
  3) чтение LBA0 проходит (55AA) — чтение реально работает;
  4) НЕТ получасового зависания: от старта QEMU до строки «ahci_init»
     проходит не более 15 секунд (весь boot — не более 90);
  5) disks-команда видит AHCI-диск;
  6) fileman [HDD]: файл HELLO.TXT читается с FAT32 через AHCI.
"""
import sys, time, os, subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at, ocr_strip

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
IMG = "/tmp/s10_ahci.img"
SHOTS = "/tmp/s10shots"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


def make_hdd():
    if os.path.exists(IMG):
        os.unlink(IMG)
    with open("/tmp/hello_ahci.txt", "w") as f:
        f.write("Hello from SATA AHCI! Test file.\n")
    here = os.path.dirname(os.path.abspath(__file__))
    r = subprocess.run([sys.executable, f"{here}/mkfat32.py", IMG, "64",
                        "AHCIHDD", "/tmp/hello_ahci.txt:HELLO.TXT"],
                       capture_output=True, text=True)
    print("  mkfat32:", r.stdout.strip() or r.stderr.strip())
    return os.path.exists(IMG) and os.path.getsize(IMG) > 1024


def main():
    glyphs = load_glyphs()
    print("== подготовка образа FAT32 ==")
    check("FAT32-образ создан", make_hdd())

    print("== загрузка с AHCI-диском ==")
    t_start = time.time()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG},format=raw,if=none,id=satadrv",
            "-device", "ahci,id=ahci0",
            "-device", "ide-hd,drive=satadrv,bus=ahci0.0"]) as q:
        # ждём конца загрузки И фоновой инициализации SATA (сессия 11:
        # AHCI больше не блокирует загрузку — диск поднимается задачей sata)
        t0 = time.time()
        ok = ok_sata = False
        while time.time() - t0 < 90:
            s = q.serial()
            if "Загрузка завершена" in s or "entering main loop" in s:
                ok = True
            if "sata: инициализация дисков завершена" in s:
                ok_sata = True
            if ok and ok_sata:
                break
            time.sleep(1)
        check("ОС загрузилась (AHCI)", ok)
        check("SATA-инициализация завершена в фоне", ok_sata)

        boot_time = time.time() - t_start
        check("загрузка быстрее 60 с", boot_time < 60, f"{boot_time:.1f} с")

        s = q.serial()
        check("[ahci] контроллер найден", "[ahci] контроллер" in s)
        check("[ahci] SATA диск найден", "[ahci] порт" in s and "SATA диск" in s)
        check("IDENTIFY прошёл", "диск:" in s and "секторов" in s)
        check("чтение LBA0 OK (55AA)", "чтение LBA0: OK" in s)

        # тайминг ahci_init: ищем момент, когда появилась строка ahci
        # (по serial-логу не видно времени — меряем хотя бы общий boot)
        # --- disks-команда: терминал уже открыт после загрузки ---
        type_cmd(q, "disks")
        time.sleep(2.5)
        q.screendump(f"{SHOTS}/disks.ppm")
        rows = ocr_strip(f"{SHOTS}/disks.ppm", 25, 45, 60, 16)
        joined = "".join(rows).replace(" ", "")
        print("  disks:", [l for l in rows if l.strip()][:16])
        check("disks показывает AHCI-диск",
              "AHCIHDD" in joined or "QEMUHARDDISK" in joined or "HARDDISK" in joined,
              joined[:200])

        # --- fileman [HDD] и чтение файла ---
        type_cmd(q, "spawn files")
        time.sleep(2.5)
        q.cmd("sendkey tab", 0.5)          # CD → HDD
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/fm2.ppm")
        fm_hdd = ocr_at(f"{SHOTS}/fm2.ppm", 97, 59, 6, bright=200)
        fm_hdr = ocr_at(f"{SHOTS}/fm2.ppm", 37, 80, 40)
        rows = ocr_strip(f"{SHOTS}/fm2.ppm", 37, 102, 44, 4)
        joined = "".join(rows).upper().replace(" ", "")
        print("  fileman [HDD]:", repr(fm_hdd), "| путь:", repr(fm_hdr))
        print("  fm list:", [l for l in rows if l.strip()][:6])
        check("fileman: Tab → FAT32 режим",
              "FAT32" in fm_hdr or "HDD" in fm_hdr, fm_hdr)
        check("fileman [HDD]: FAT32-список", "HELLO" in joined, joined[:200])

    print()
    print(f"ИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
    if FAIL:
        print("Провалено:", ", ".join(FAIL))
        sys.exit(1)


if __name__ == "__main__":
    main()
