#!/usr/bin/env python3
"""Сессия 53: замена kernel.bin внутри готового os.iso in-place.

update_iso.py (полная перепаковка хвоста с ramdisk) здесь неприменим:
хвост после ядра ~4.7 КиБ, а ramdisk/ занимает десятки КиБ. Но старое и
новое ядро ОДИНАКОВОГО размера (757100), ramdisk/ и grub.cfg не менялись
с фикса 32 — поэтому достаточно:
  1) проверить, что в ISO лежит ядро 757100 @ LBA 2980 (fixed32 base);
  2) убедиться, что ramdisk в ISO побайтно совпадает с деревом ramdisk/;
  3) записать новое ядро в тот же экстент (размер в записях каталогов
     не меняется — поле уже 757100);
  4) верификация dd-эквивалентом: чтение экстента, md5.
Выход: os.iso (корень) + prebuilt/os.iso + prebuilt/kernel.bin.
"""
import os
import struct
import sys
import hashlib

SECT = 2048
PROJ = "/home/z/my-project/work/n2600"
ISO_IN = os.path.join(PROJ, "prebuilt", "os.iso")
ISO_OUT = os.path.join(PROJ, "os.iso")
KERNEL = os.path.join(PROJ, "kernel.bin")
RAMDISK_SRC = os.path.join(PROJ, "ramdisk")

EXPECT_KERNEL_SIZE = 757100
EXPECT_LBA = 2980


def dir_records(data, extent, size):
    off = 0
    end = extent * SECT + size
    abs_start = extent * SECT
    while abs_start + off < end:
        rec = abs_start + off
        ln = data[rec]
        if ln == 0:
            nxt = (off // SECT + 1) * SECT
            if nxt >= size:
                return
            off = nxt
            continue
        lba = struct.unpack('<I', data[rec + 2:rec + 6])[0]
        fsize = struct.unpack('<I', data[rec + 10:rec + 14])[0]
        flags = data[rec + 25]
        nlen = data[rec + 32]
        raw = data[rec + 33:rec + 33 + nlen]
        yield rec, lba, fsize, flags, raw
        off += ln
        if ln == 0:
            return


def iso_name(raw, joliet):
    if len(raw) == 1 and raw[0] in (0, 1):
        return chr(raw[0])
    if joliet:
        s = raw.decode('utf-16-be', errors='replace')
    else:
        s = raw.decode('latin1', errors='replace')
    s = s.split(';')[0]
    return s.lower().rstrip()


def walk_tree(data, root_lba, root_size, joliet=False):
    out = {}
    seen = {root_lba}
    stack = [("/", root_lba, root_size)]
    while stack:
        prefix, lb, sz = stack.pop()
        for rec, lba, fsize, flags, raw in dir_records(data, lb, sz):
            nm = iso_name(raw, joliet)
            if nm in ("", "\x00", "\x01"):
                continue
            path = prefix + nm
            out[path] = (lba, fsize, rec)
            if flags & 0x02 and lba not in seen:
                seen.add(lba)
                stack.append((path + "/", lba, fsize))
    return out


def md5(b):
    return hashlib.md5(b).hexdigest()


def main():
    with open(ISO_IN, "rb") as f:
        data = bytearray(f.read())
    with open(KERNEL, "rb") as f:
        kernel = f.read()

    print(f"ISO:   {ISO_IN} ({len(data)} байт, md5 {md5(bytes(data))})")
    print(f"Ядро:  {len(kernel)} байт (md5 {md5(kernel)})")
    if len(kernel) != EXPECT_KERNEL_SIZE:
        print(f"ERROR: ожидалось ядро {EXPECT_KERNEL_SIZE} байт", file=sys.stderr)
        return 1

    # --- найти /boot/kernel.bin в PVD ---
    root_lba = struct.unpack('<I', data[16 * SECT + 158:16 * SECT + 162])[0]
    root_size = struct.unpack('<I', data[16 * SECT + 166:16 * SECT + 170])[0]
    tree = walk_tree(bytes(data), root_lba, root_size)
    kent = None
    for nm, val in tree.items():
        if nm.rstrip('/').endswith('kernel.bin') and not nm.endswith('/'):
            kent = (nm, val)
            break
    if not kent:
        print("ERROR: kernel.bin не найден в PVD-дереве", file=sys.stderr)
        return 1
    kpath, (k_lba, k_size, k_rec) = kent
    print(f"kernel в ISO: {kpath} LBA {k_lba}, размер {k_size}")
    if k_lba != EXPECT_LBA or k_size != EXPECT_KERNEL_SIZE:
        print("ERROR: база не соответствует фиксу 32 (LBA/размер)", file=sys.stderr)
        return 1

    # --- сверка ramdisk в ISO с деревом ---
    rd_files = {nm: (lba, sz) for nm, (lba, sz, _) in tree.items()
                if '/ramdisk/' in nm}
    src_files = {}
    for nm in sorted(os.listdir(RAMDISK_SRC)):
        p = os.path.join(RAMDISK_SRC, nm)
        if os.path.isfile(p):
            src_files['/boot/ramdisk/' + nm.lower()] = p
    mismatch = []
    for nm, path in src_files.items():
        if nm not in rd_files:
            mismatch.append(f"{nm}: нет в ISO")
            continue
        lba, sz = rd_files[nm]
        blob = open(path, "rb").read()
        in_iso = bytes(data[lba * SECT:lba * SECT + len(blob)])
        if len(blob) != sz or in_iso != blob:
            mismatch.append(f"{nm}: содержимое/размер различаются")
    if mismatch:
        print("ERROR: ramdisk в ISO не совпадает с деревом:")
        for m in mismatch:
            print("  " + m, file=sys.stderr)
        return 1
    print(f"ramdisk: {len(src_files)} файлов совпадают с деревом побайтно")

    # --- замена ядра in-place ---
    start = k_lba * SECT
    data[start:start + len(kernel)] = kernel
    print(f"ядро записано @ {start} ({len(kernel)} байт)")

    # --- выгрузка + синхронизация prebuilt ---
    with open(ISO_OUT, "wb") as f:
        f.write(data)
    with open(ISO_IN, "wb") as f:
        f.write(data)

    # --- независимая верификация (эквивалент dd|md5) ---
    with open(ISO_OUT, "rb") as f:
        f.seek(start)
        back = f.read(len(kernel))
    ok = back == kernel
    print(f"верификация: чтение экстента назад {'OK' if ok else 'FAIL'} "
          f"(md5 {md5(back)})")
    if not ok:
        return 1
    print(f"Готово: {ISO_OUT} и {ISO_IN} синхронизированы")
    return 0


if __name__ == "__main__":
    sys.exit(main())
