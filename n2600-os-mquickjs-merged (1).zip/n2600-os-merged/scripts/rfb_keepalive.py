#!/usr/bin/env python3
"""rfb_keepalive.py — минимальный RFB-клиент для Bochs (display_library: rfb).

Bochs паникует, если за 30 с к rfb-сертеру никто не подключился. Этот
клиент проходит handshake, держит соединение и выгребает все пакеты
(FramebufferUpdate и пр.), пока его не остановят. Опционально сохраняет
RAW-фреймбуферы в PNG-подобные файлы (для отладки глазами).

Использование: rfb_keepalive.py [host] [port] [--dump dir]
"""
import socket, sys, time, struct, os


def run(host="127.0.0.1", port=5900, dump=None, stop_flag="/tmp/rfb.stop"):
    try:
        if os.path.exists(stop_flag):
            os.unlink(stop_flag)   # чистый старт: флаг мог остаться от прошлого прогона
    except OSError:
        pass
    for attempt in range(60):
        try:
            s = socket.create_connection((host, port), timeout=2)
            break
        except OSError:
            time.sleep(0.5)
    else:
        print("rfb_keepalive: не подключился к %s:%d" % (host, port))
        return 1
    s.settimeout(None)

    def rd(n):
        buf = b""
        while len(buf) < n:
            d = s.recv(n - len(buf))
            if not d:
                raise ConnectionError("server closed")
            buf += d
        return buf

    # --- handshake ---
    ver = rd(12)                       # "RFB 003.003\n"
    s.sendall(ver)
    minor = int(ver[8:11]) if ver[:3] == b"RFB" else 3
    if minor >= 7:
        count = rd(1)[0]
        if count == 0:
            rlen = struct.unpack(">I", rd(4))[0]
            rd(rlen)
            raise ConnectionError("server refused (3.7)")
        types = rd(count)
        if 1 not in types:
            raise ConnectionError("no None-auth: %r" % types)
        s.sendall(bytes([1]))           # выбираем None
        if minor >= 8:
            res = struct.unpack(">I", rd(4))[0]
            if res != 0:
                raise ConnectionError("auth failed")
    else:
        sec = struct.unpack(">I", rd(4))[0]   # 3.3: сервер шлёт тип без списка
        if sec != 1:
            raise ConnectionError("unsupported security %d" % sec)
        # 3.3 + None: SecurityResult НЕ присылается — сразу ClientInit
    s.sendall(b"\x01")                  # ClientInit: shared=1
    w, h = struct.unpack(">HH", rd(4))
    pf = rd(16)
    # pf: bpp u8, depth u8, bigend u8, truecolor u8, rmax>2 gmax>2 bmax>2, rsh u8 gsh u8 bsh u8, pad3
    bpp = pf[0]
    rmax, gmax, bmax = struct.unpack(">HHH", pf[4:10])
    rsh, gsh, bsh = pf[10], pf[11], pf[12]
    namelen = struct.unpack(">I", rd(4))[0]
    name = rd(namelen) if namelen else b""
    print("rfb_keepalive: connected %dx%d %r bpp=%d r=%d/%d g=%d/%d b=%d/%d" %
          (w, h, name, bpp, rmax, rsh, gmax, gsh, bmax, bsh))
    bypp = bpp // 8

    # полный фрейм (последний полученный)
    frame = bytearray(w * h * 3)
    have = bytearray(b"\x00" * (w * h))

    if dump:
        os.makedirs(dump, exist_ok=True)

    buf = b""
    nframes = 0
    t0 = time.time()
    last_save = 0
    try:
        while not os.path.exists(stop_flag):
            # выгребаем всё, что прислали; Bochs шлёт сам (10 Гц)
            try:
                s.settimeout(1.0)
                d = s.recv(65536)
                if not d:
                    break
                buf += d
            except socket.timeout:
                pass
            # разбор сообщений сервера: тип u8 (любая ошибка — сбрасываем буфер)
            try:
              while len(buf) >= 4:
                mtype = buf[0]
                if mtype == 0:      # FramebufferUpdate: u1 pad, u16 nrects
                    if len(buf) < 4:
                        break
                    nrects = struct.unpack(">H", buf[2:4])[0]
                    pos = 4
                    ok = True
                    for _ in range(nrects):
                        if len(buf) < pos + 12:
                            ok = False
                            break
                        et, x, y, rw, rh = struct.unpack(">BHHHH", buf[pos:pos + 9])
                        pos += 12
                        if et == 0:  # raw
                            need = rw * rh * bypp
                            if len(buf) < pos + need:
                                ok = False
                                break
                            raw = buf[pos:pos + need]
                            pos += need
                            for row in range(rh):
                                for col in range(rw):
                                    pi = ((y + row) * w + (x + col))
                                    off = (row * rw + col) * bypp
                                    v = int.from_bytes(raw[off:off + bypp], "big")
                                    r = (v >> rsh) & rmax
                                    g = (v >> gsh) & gmax
                                    b = (v >> bsh) & bmax
                                    if rmax:
                                        r = r * 255 // rmax
                                    if gmax:
                                        g = g * 255 // gmax
                                    if bmax:
                                        b = b * 255 // bmax
                                    fo = pi * 3
                                    frame[fo] = r
                                    frame[fo + 1] = g
                                    frame[fo + 2] = b
                                    have[pi] = 1
                        else:
                            pass    # другие кодировки пропускаем
                    if not ok:
                        break
                    buf = buf[pos:]
                    nframes += 1
                    continue
                elif mtype == 1:    # SetColourMapEntries
                    if len(buf) < 5:
                        break
                    n = struct.unpack(">H", buf[3:5])[0]
                    need = 4 + n * 6
                    if len(buf) < need:
                        break
                    buf = buf[need:]
                    continue
                elif mtype == 2:    # Bell
                    buf = buf[1:]
                    continue
                elif mtype == 3:    # ServerCutText
                    if len(buf) < 8:
                        break
                    n = struct.unpack(">I", buf[4:8])[0]
                    if len(buf) < 8 + n:
                        break
                    buf = buf[8 + n:]
                    continue
                else:
                    buf = buf[1:]   # неизвестное — пропускаем байт
                    continue
            except Exception as e:
                print("parse reset:", e)
                buf = b""
            if nframes and time.time() - last_save > 5:
                last_save = time.time()
                nz = sum(1 for i in range(0, len(have), 997) if have[i])
                path = (dump or "/tmp") + "/rfb-last.ppm"
                with open(path, "wb") as f:
                    f.write(b"P6\n%d %d\n255\n" % (w, h))
                    f.write(bytes(frame))
                print("frame #%d: %s (%d/%d sampled)" % (nframes, path, nz, w * h))
    finally:
        s.close()
    print("rfb_keepalive: done, %d updates, %.1f s" % (nframes, time.time() - t0))
    return 0


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dump = None
    for a in sys.argv[1:]:
        if a.startswith("--dump="):
            dump = a.split("=", 1)[1]
    host = args[0] if args else "127.0.0.1"
    port = int(args[1]) if len(args) > 1 else 5900
    sys.exit(run(host, port, dump))
