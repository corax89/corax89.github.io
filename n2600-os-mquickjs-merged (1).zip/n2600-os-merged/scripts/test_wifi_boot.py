#!/usr/bin/env python3
"""test_wifi_boot.py — проверка загрузки ОС с новым ath9k-драйвером.
В QEMU нет Atheros-карты: драйвер должен чисто сообщить «не найден»
и НЕ сломать загрузку."""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))

PASS, FAIL = [], []


def check(name, cond):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


with QMon(ISO) as q:
    t0 = time.time()
    ok = False
    while time.time() - t0 < 90:
        s = q.serial()
        if "Загрузка завершена" in s or "entering main loop" in s:
            ok = True
            break
        time.sleep(1)
    check("ОС загрузилась с новым wifi-драйвером", ok)
    s = q.serial()
    wifi = [l for l in s.splitlines() if "wifi" in l.lower()]
    print("  WiFi-строки serial:")
    for l in wifi[:8]:
        print("    " + l)
    check("wifi_init отработал (есть строки в serial)", len(wifi) >= 1)
    check("wifi: адаптер не найден — штатно", any("найден" in l or "not found" in l.lower() for l in wifi))
    check("нет паники/зависания (нет watchdog-kill)", "kill #" not in s)

print(f"\nИтог: {len(PASS)} PASS, {len(FAIL)} FAIL")
sys.exit(1 if FAIL else 0)
