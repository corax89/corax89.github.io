#!/usr/bin/env python3
"""test_freeze.py — сфокусированный тест заморозки (без кликов):
терминал — единственное окно, точно в фокусе. spinlock -> заморозка -> ожил?"""
import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, load_glyphs, ocr_at, ocr_strip, read_ppm

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
os.makedirs("/tmp/shots", exist_ok=True)


def serial_text():
    try:
        return open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    except FileNotFoundError:
        return ""


def clock_region(path):
    w, h, img = read_ppm(path)
    box = []
    for y in range(574, min(600, h)):
        base = y * w * 3
        for x in range(700, min(796, w)):
            off = base + x * 3
            box.append(img[off:off + 3])
    return b"".join(box)


with QMon(ISO) as q:
    time.sleep(12)
    # терминал — единственное окно, фокус гарантирован
    q.sendkeys("spinlock", delay=0.05)
    time.sleep(0.2)
    q.cmd("sendkey ret", 0.3)
    print("... заморозка: 3 c проверка ...")
    time.sleep(3)
    a = "/tmp/shots/fz-a.ppm"
    b = "/tmp/shots/fz-b.ppm"
    q.screendump(a)
    time.sleep(3)
    q.screendump(b)
    frozen = clock_region(a) == clock_region(b)
    print("заморожен:", frozen)
    print("... ждём восстановления (~20 c от старта) ...")
    t0 = time.time()
    recovered = False
    while time.time() - t0 < 30:
        ser = serial_text()
        if "[sync]" in ser:
            recovered = True
            break
        time.sleep(1)
    print("serial [sync]:", recovered)
    time.sleep(3)
    c = "/tmp/shots/fz-c.ppm"
    d = "/tmp/shots/fz-d.ppm"
    q.screendump(c)
    time.sleep(3)
    q.screendump(d)
    alive = clock_region(c) != clock_region(d)
    print("ожил (часы):", alive)
    # терминал жив? скрин + OCR
    q.screendump("/tmp/shots/fz-final.ppm")
    tt = ocr_at("/tmp/shots/fz-final.ppm", 28, 20, 12)
    rows = ocr_strip("/tmp/shots/fz-final.ppm", 25, 45, 60, 6)
    print("терминал title:", repr(tt))
    print("терминал строки:", [r for r in rows if r.strip()][:6])
    ser = serial_text()
    print("=== watchdog/sync в serial ===")
    for l in ser.splitlines():
        if "watchdog" in l or "sync" in l:
            print("   ", l)
    # теперь kill spinlock
    q.sendkeys("tasks", delay=0.05)
    time.sleep(0.2)
    q.cmd("sendkey ret", 0.3)
    time.sleep(1.5)
    q.screendump("/tmp/shots/fz-tasks.ppm")
    rows = ocr_strip("/tmp/shots/fz-tasks.ppm", 25, 45, 60, 10)
    print("tasks:", [r for r in rows if r.strip()][:10])
