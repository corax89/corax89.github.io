#!/usr/bin/env python3
"""Диагностика: boot → `cc t1.c` → OCR терминала."""
import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_strip, load_glyphs

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/c4dbg"
os.makedirs(SHOTS, exist_ok=True)

with QMon(ISO) as q:
    time.sleep(12)
    q.cmd("sendkey ret", 0.3)   # пустая строка — метка
    q.sendkeys("cc t1.c", delay=0.035)
    time.sleep(0.2)
    q.cmd("sendkey ret", 0.3)
    time.sleep(3)
    q.screendump(f"{SHOTS}/cc.ppm")
    lines = ocr_strip(f"{SHOTS}/cc.ppm", 25, 45, 60, 16)
    print("TERMINAL:")
    for l in lines:
        if l.strip():
            print("  |", l)
    q.sendkeys("run t1.bin", delay=0.035)
    time.sleep(0.2)
    q.cmd("sendkey ret", 0.3)
    time.sleep(3)
    q.screendump(f"{SHOTS}/run.ppm")
    lines = ocr_strip(f"{SHOTS}/run.ppm", 25, 45, 60, 16)
    print("AFTER RUN:")
    for l in lines:
        if l.strip():
            print("  |", l)
