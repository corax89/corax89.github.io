#!/usr/bin/env python3
"""test_s59_loopback.py — сессия 59: воспроизведение порчи кучи при
обращении к localhost (лог пользователя: [tcp] connect dst=7f000001:80 →
[mem] ПОРЧА КУЧИ). Терминальный http и браузер (curl) на 127.0.0.1.
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_strip

ISO = "/home/z/my-project/work/n2600/os.iso"
SHOTS = "/tmp/shots"
os.makedirs(SHOTS, exist_ok=True)

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def wait_serial(substr, timeout=60, logfile="/tmp/os-serial.log"):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = open(logfile, "rb").read().decode("utf-8", "replace")
        except OSError:
            time.sleep(0.3)
            continue
        if substr in s:
            return True
        time.sleep(0.3)
    return False


def serial_tail(n=6000, logfile="/tmp/os-serial.log"):
    try:
        return open(logfile, "rb").read().decode("utf-8", "replace")[-n:]
    except OSError:
        return ""


def term_cmd(q, cmd, settle=1.2):
    q.sendkeys(cmd, delay=0.03)
    q.cmd("sendkey ret", 0.05)
    time.sleep(settle)


open("/tmp/os-serial.log", "w").close()
q = None
try:
    q = QMon(ISO, extra_args=["-netdev", "user,id=net0",
                              "-device", "e1000,netdev=net0,romfile="])
    q.__enter__()
    time.sleep(10)
    ser = serial_tail()
    check("boot: httpd слушает :80", "ttpd] listening" in ser, ser[-300:])

    # 1. терминальный http на loopback
    term_cmd(q, "http 127.0.0.1 /", settle=5)
    q.screendump(f"{SHOTS}/s59-lo-http.ppm")
    lines = ocr_strip(f"{SHOTS}/s59-lo-http.ppm", 25, 45, 78, 16)
    print("  терминал:", [l for l in lines if l.strip()][:10])
    ser = serial_tail(3000)
    corr = "ПОРЧА КУЧИ" in ser or "size=0" in ser
    check("http 127.0.0.1: кучи цела", not corr, ser[-500:])
    ok = any("local httpd" in l or "file server" in l or "200" in l for l in lines)
    check("http 127.0.0.1: страница получена", ok, str(lines[:8]))

    # 2. браузерный путь (curl открывает браузер)
    term_cmd(q, "curl http://127.0.0.1/", settle=6)
    time.sleep(3)
    q.screendump(f"{SHOTS}/s59-lo-curl.ppm")
    ser = serial_tail(3000)
    corr = "ПОРЧА КУЧИ" in ser or "size=0" in ser
    check("curl 127.0.0.1: куча цела", not corr, ser[-600:])
    ok = "[curl] 127.0.0.1:80 ->" in ser
    check("curl 127.0.0.1: ответ получен", ok, ser[-400:])

    # 3. повторные запросы (утечки/переиспользование)
    for i in range(3):
        term_cmd(q, f"http 127.0.0.1 /hello", settle=4)
    time.sleep(2)
    ser = serial_tail(3000)
    corr = "ПОРЧА КУЧИ" in ser or "size=0" in ser
    check("3x http /hello: куча цела", not corr, ser[-600:])

    # 4. файловый сервер: длинный путь (stack-переполнение rampath)
    term_cmd(q, "http 127.0.0.1 /aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/", settle=4)
    time.sleep(2)
    ser = serial_tail(3000)
    corr = "ПОРЧА КУЧИ" in ser or "size=0" in ser
    check("длинный путь /aaa.../: куча цела", not corr, ser[-600:])

    time.sleep(3)
    ser = serial_tail(2000)
    crash = "CPU EXCEPTION" in ser
    check("итог: ядро не упало", not crash, ser[-400:])
finally:
    if q:
        try:
            q.__exit__(None, None, None)
        except Exception:
            pass

print(f"\nИтого: {len(PASS)} PASS, {len(FAIL)} FAIL")
sys.exit(1 if FAIL else 0)
