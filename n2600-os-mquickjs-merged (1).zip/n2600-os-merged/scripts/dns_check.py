#!/usr/bin/env python3
"""dns_check.py — проверка DNS по имени через virtio modern: смотрим ВЫВОД
терминала команды `http example.com /` (OCR), а не только serial."""
import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_strip, load_glyphs

ISO = "/home/z/my-project/work/n2600/proj/os.iso"
GL = load_glyphs()
os.makedirs("/tmp/shots9", exist_ok=True)

q = QMon(ISO, extra_args=["-netdev", "user,id=net0",
                          "-device", "virtio-net-pci-non-transitional,netdev=net0,romfile="])
q.__enter__()
time.sleep(11)
q.sendkeys("http example.com /", delay=0.03)
q.cmd("sendkey ret", 0.05)
time.sleep(10)
q.screendump("/tmp/shots9/dns.ppm")
lines = ocr_strip("/tmp/shots9/dns.ppm", 25, 45, 78, 16)
print("=== терминал ===")
for l in lines:
    print(" ", l)
ser = open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
print("=== serial (последние 700) ===")
print(ser[-700:])
q.__exit__(None, None, None)
