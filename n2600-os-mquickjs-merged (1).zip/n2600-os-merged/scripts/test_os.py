#!/usr/bin/env python3
"""test_os.py — интеграционные тесты N2600-OS в QEMU (таргетированный OCR).

Координаты текста выведены из исходников (см. комментарии к каждому тесту).
"""
import sys, time, os, subprocess, threading, http.server, socketserver

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_at, ocr_strip, load_glyphs, looks_like, norm

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
SHOTS = "/tmp/shots"
os.makedirs(SHOTS, exist_ok=True)
GL = load_glyphs()

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


# ---------------------------------------------------------------- HTTP-сервер
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = (b"<html><head><title>N2600-OS test</title></head>"
                b"<body><h1>Zagolovok testa</h1>"
                b"<p>HTTP works from N2600-OS browser via QEMU user-net.</p>"
                b"<ul><li>item one</li><li>item two</li></ul></body></html>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


socketserver.TCPServer.allow_reuse_address = True
httpd = socketserver.TCPServer(("127.0.0.1", 8081), H)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
print("HTTP-сервер 127.0.0.1:8081; гостю виден как 10.0.2.100:80 (guestfwd)")
EXTRA = ["-netdev", "user,id=net0,guestfwd=tcp:10.0.2.100:80-tcp:127.0.0.1:8081",
         "-device", "e1000,netdev=net0"]


def wait_serial(substr, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
        if substr in s:
            return True
    return False


# Геометрия (из исходников):
#  Экран 800x600, TBAR_H=28, TITLE_H=24.
#  Терминал: окно (20,16) 506x318; контент-оригин (21,41);
#    строки: canvas(4, 4+16i) -> экран (25, 45+16i); приглашение y=301.
#  Таскбар: y=576..596; «Меню» (20,578); кнопки окон с bx=74+140k, текст (78+140k, 578).
#  Таскмгр: окно (100,40) 620x384; контент-оригин (101,65);
#    заголовок окна (108,44); шапка списка canvas(4,23) -> (105,88);
#    строки задач canvas(4,42+16i) -> (105,107+16i); подвал canvas(4,346) -> (105,411).

print("\n=== Тест 1-5: UI (одна загрузка) ===")
with QMon(ISO) as q:
    time.sleep(12)
    q.screendump(f"{SHOTS}/01-boot.ppm")

    # --- Тест 1: терминал ---
    term_lines = ocr_strip(f"{SHOTS}/01-boot.ppm", 25, 45, 60, 3)
    print("  терминал[0:3]:", term_lines)
    check("терминал: приветствие N2600-OS 0.1", "N2600-OS 0.1" in term_lines[0])
    check("терминал: подсказка help", "help" in (term_lines[1] + term_lines[2]))
    title = ocr_at(f"{SHOTS}/01-boot.ppm", 28, 20, 12)
    check("терминал: заголовок окна", looks_like(title, "Терминал"), title)
    menu = ocr_at(f"{SHOTS}/01-boot.ppm", 20, 578, 6)
    check("таскбар: кнопка Меню", looks_like(menu, "Меню"), menu)
    ser = q.serial()
    check("serial: ramdisk seeded (файлы сидинга)",
          "файлов," in ser and any(n in ser for n in ("12 файлов", "10 файлов", "4 файлов")),
          ser[ser.find("RAM disk"):ser.find("RAM disk")+80] if "RAM disk" in ser else "?")
    check("serial: irq on", "irq on" in ser)

    # --- Тест 2: диспетчер задач ---
    q.sendkeys("spawn taskmgr\n")
    time.sleep(3)
    # снять выделение со строки 0 (белая рамка мешает OCR первой строки);
    # с сессии 5 в списке есть задача ramfs — Терминал теперь строка 2,
    # жмём down ×3, чтобы выделение ушло ниже Терминала
    q.cmd("sendkey down")
    q.cmd("sendkey down")
    q.cmd("sendkey down")
    time.sleep(1)
    q.screendump(f"{SHOTS}/02-taskmgr.ppm")
    tm_title = ocr_at(f"{SHOTS}/02-taskmgr.ppm", 108, 44, 20)
    check("taskmgr: заголовок окна", looks_like(tm_title, "Диспетчер задач"), tm_title)
    hdr = ocr_at(f"{SHOTS}/02-taskmgr.ppm", 105, 88, 46)
    print("  шапка списка:", repr(hdr))
    check("taskmgr: колонка Mem в шапке", "Mem" in hdr)
    check("taskmgr: колонки Имя/Uptime/Статус",
          looks_like(hdr, "Имя") and "Uptime" in hdr and
          looks_like(hdr, "Статус"), hdr)
    check("taskmgr: НЕТ битого '%-13s'", "%-13s" not in hdr and "%-12s" not in hdr)
    rows = ocr_strip(f"{SHOTS}/02-taskmgr.ppm", 105, 107, 50, 6)
    print("  строки задач:")
    for r in rows:
        print("   ", repr(r))
    check("taskmgr: строки без '%-12s' и мусора",
          all("%-" not in r for r in rows))
    check("taskmgr: статус RUN виден", any("RUN" in r or "idle" in r for r in rows))
    # Примечание: строка с ВЫДЕЛЕНИЕМ (sel-рамка 0xFFFFFF) OCR не читает
    # (горизонтальные линии рамки ломают матчинг глифов) — это артефакт
    # распознавания, не рендера. Достаточно 2+ читаемых строк.
    readable = [r for r in rows if r.count("?") < 6 and r.strip()]
    check("taskmgr: имя задачи читается",
          len(readable) >= 2 and
          any(looks_like(r, "Термина") or looks_like(r, "netcfg") or
              looks_like(r, "ramfs") or looks_like(r, "main") for r in readable),
          str(rows))
    check("taskmgr: память задачи в КБ",
          any("K" in r and any(c.isdigit() for c in r) for r in rows))
    clean_rows = [r for r in rows if r.count("?") < len(r) // 3]
    check("taskmgr: НЕ случайные символы в статусе",
          len(clean_rows) >= 2 and
          all(not r[40:46].strip().startswith("?") for r in clean_rows if len(r) > 44),
          str(rows))
    foot = ocr_at(f"{SHOTS}/02-taskmgr.ppm", 105, 407, 60)
    print("  подвал:", repr(foot))
    check("taskmgr: куча в подвале", looks_like(foot, "куча"), foot)

    # --- Тест 3: стабильный порядок таскбара ---
    btn1 = ocr_at(f"{SHOTS}/02-taskmgr.ppm", 78, 578, 16)      # Терминал
    btn2 = ocr_at(f"{SHOTS}/02-taskmgr.ppm", 218, 578, 18)     # Диспетчер задач
    print("  таскбар до:", repr(btn1), "|", repr(btn2))
    check("таскбар: слева Терминал", looks_like(btn1, "Терминал"), btn1)
    check("таскбар: справа Диспетчер", looks_like(btn2, "Диспетчер"), btn2)
    # клик по кнопке «Терминал» (74..214, y 576..596)
    q.click_at(74 + 30, 586)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/03-after-click.ppm")
    btn1b = ocr_at(f"{SHOTS}/03-after-click.ppm", 78, 578, 16)
    btn2b = ocr_at(f"{SHOTS}/03-after-click.ppm", 218, 578, 18)
    print("  таскбар после клика:", repr(btn1b), "|", repr(btn2b))
    check("таскбар: Терминал остался на месте", looks_like(btn1b, "Терминал"), btn1b)
    check("таскбар: Диспетчер остался на месте", looks_like(btn2b, "Диспетчер"), btn2b)

    # --- Тест 4: maximize / restore ---
    # терминал в фокусе; его кнопка [□]: x+w-42=484, y+4=20 (18x16)
    q.click_at(484 + 9, 20 + 8)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/04-maximized.ppm")
    mx_title = ocr_at(f"{SHOTS}/04-maximized.ppm", 8, 4, 10)   # окно в (0,0)
    mx_line0 = ocr_at(f"{SHOTS}/04-maximized.ppm", 5, 29, 60)  # контент (1,25)+(4,4)
    print("  max заголовок:", repr(mx_title), " строка:", repr(mx_line0[:40]))
    check("maximize: заголовок на месте", looks_like(mx_title, "Терминал"), mx_title)
    check("maximize: содержимое видно", "N2600-OS 0.1" in mx_line0, mx_line0)
    check("maximize: таскбар жив",
          looks_like(ocr_at(f"{SHOTS}/04-maximized.ppm", 20, 578, 6), "Меню"))
    # растянуто: правая рамка окна (ACCENT 0x3E7DBF) у края экрана (799,300)
    from qmon import read_ppm
    w_, h_, img_ = read_ppm(f"{SHOTS}/04-maximized.ppm")
    off_ = (300 * w_ + 799) * 3
    edge_rgb = tuple(img_[off_:off_ + 3])
    check("maximize: окно во всю ширину (рамка на x=799)",
          abs(edge_rgb[0]-0x3E) < 12 and abs(edge_rgb[1]-0x7D) < 12 and
          abs(edge_rgb[2]-0xBF) < 12, str(edge_rgb))
    # restore: кнопка [□] теперь у окна (0,0): x=800-42=758, y=4
    q.click_at(758 + 9, 4 + 8)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/05-restored.ppm")
    r_title = ocr_at(f"{SHOTS}/05-restored.ppm", 28, 20, 12)
    r_line0 = ocr_at(f"{SHOTS}/05-restored.ppm", 25, 45, 60)
    check("restore: заголовок вернулся", looks_like(r_title, "Терминал"), r_title)
    check("restore: содержимое вернулось", "N2600-OS" in r_line0[:9], r_line0)

    # --- Тест 5: minimize / restore ---
    # [—] у окна терминала: x=20+506-62=464, y=20
    q.click_at(464 + 9, 20 + 8)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/06-minimized.ppm")
    m_line0 = ocr_at(f"{SHOTS}/06-minimized.ppm", 25, 45, 60)
    check("minimize: терминал скрыт", "N2600-OS 0.1" not in m_line0, m_line0)
    check("minimize: таскбар жив",
          looks_like(ocr_at(f"{SHOTS}/06-minimized.ppm", 20, 578, 6), "Меню"))
    # вернуть кликом по кнопке таскбара (Терминал: 74..214)
    q.click_at(74 + 30, 586)
    time.sleep(1.5)
    q.screendump(f"{SHOTS}/07-unminimized.ppm")
    u_line0 = ocr_at(f"{SHOTS}/07-unminimized.ppm", 25, 45, 60)
    check("minimize→restore: терминал вернулся", "N2600-OS" in u_line0[:9], u_line0)

# --- Тест 6: HTTP ---
print("\n=== Тест 6: curl http://10.0.2.2:8081/ (шлюз → хост, TCP-фиксы) ===")
EXTRA_GW = ["-netdev", "user,id=net0",
            "-device", "e1000,netdev=net0,romfile="]
with QMon(ISO, extra_args=EXTRA_GW) as q:
    time.sleep(12)
    open("/tmp/os-serial.log", "wb").close()
    q.sendkeys("curl http://10.0.2.2:8081/\n", delay=0.03)
    ok = wait_serial("[curl] 10.0.2.2:8081 ->", timeout=40)
    ser = open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    print("  serial (хвост):", ser[-200:].replace("\n", " | "))
    check("curl: HTTP-ответ получен", ok, ser[-300:])
    if ok:
        for bad in ("connect timeout", "response timeout", "no ARP",
                    "connection refused", "cannot resolve"):
            check(f"curl: без ошибки '{bad}'", bad not in ser)
    time.sleep(3)
    q.screendump(f"{SHOTS}/08-browser.ppm")
    # браузер: окно (50,16) 700x420 (W/2-350); контент-оригин (51,41);
    # адресная строка: canvas(10,4) -> (61,45); контент: (55,65+16i);
    # статус: canvas(4,382) -> (55,423)
    addr = ocr_at(f"{SHOTS}/08-browser.ppm", 61, 45, 34)
    content = ocr_strip(f"{SHOTS}/08-browser.ppm", 55, 65, 60, 6)
    status = ocr_at(f"{SHOTS}/08-browser.ppm", 55, 423, 70)
    print("  адрес:", repr(addr))
    print("  контент[0:6]:", content)
    print("  статус:", repr(status))
    alltxt = " ".join(content) + " " + addr + " " + status
    check("браузер: страница получена (заголовок/текст)",
          "Zagolovok" in alltxt or "HTTP works" in alltxt or "item" in alltxt,
          alltxt[:200])
    check("браузер: конвертация HTML (нет тегов)",
          "<html>" not in alltxt and "<h1>" not in alltxt)
    check("браузер: адрес в строке", "10.0.2.2:8081" in addr or
          "http://10.0.2.2" in addr, addr)

print("\n================= ИТОГ =================")
print(f"PASS: {len(PASS)}  FAIL: {len(FAIL)}")
for f in FAIL:
    print("  FAILED:", f)
sys.exit(1 if FAIL else 0)
