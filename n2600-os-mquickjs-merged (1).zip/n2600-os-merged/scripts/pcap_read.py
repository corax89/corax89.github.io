#!/usr/bin/env python3
"""Разбор pcap-дампа от QEMU: какие кадры ходили."""
import struct, sys

data = open("/tmp/net.pcap", "rb").read()
magic = struct.unpack("<I", data[:4])[0]
endian = "<" if magic == 0xA1B2C3D4 else ">"
print(f"pcap {len(data)} байт, magic={magic:#x}")

off = 24
pkt_no = 0
while off + 16 <= len(data):
    ts, tus, caplen, origlen = struct.unpack(endian + "IIII", data[off:off + 16])
    off += 16
    frame = data[off:off + caplen]
    off += caplen
    pkt_no += 1
    if len(frame) < 14:
        print(f"#{pkt_no}: короткий кадр {len(frame)}")
        continue
    dst = frame[0:6].hex()
    src = frame[6:12].hex()
    ethertype = (frame[12] << 8) | frame[13]
    desc = f"#{pkt_no}: {src} -> {dst} eth=0x{ethertype:04x}"
    if ethertype == 0x0806:  # ARP
        ar = frame[14:]
        htype = (ar[0] << 8) | ar[1]
        ptype = (ar[2] << 8) | ar[3]
        oper = (ar[6] << 8) | ar[7]
        op = "request" if oper == 1 else ("reply" if oper == 2 else f"?{oper}")
        desc += f" ARP htype=0x{htype:04x} ptype=0x{ptype:04x} {op} " \
                f"spa={'.'.join(str(b) for b in ar[14:18])} tpa={'.'.join(str(b) for b in ar[24:28])}"
    elif ethertype == 0x0800:  # IP
        ip = frame[14:]
        ihl = (ip[0] & 0xF) * 4
        proto = ip[9]
        srcip = ".".join(str(b) for b in ip[12:16])
        dstip = ".".join(str(b) for b in ip[16:20])
        tot = (ip[2] << 8) | ip[3]
        pdesc = f" IP {srcip}->{dstip} proto={proto} totlen={tot}"
        if proto == 6:  # TCP
            tcp = ip[ihl:]
            sport = (tcp[0] << 8) | tcp[1]
            dport = (tcp[2] << 8) | tcp[3]
            flags = tcp[13]
            fl = "".join(n for b, n in [(0x02, "S"), (0x10, "A"), (0x01, "F"),
                                        (0x04, "R"), (0x08, "P")] if flags & b)
            hdrlen = (tcp[12] >> 4) * 4
            # чексумма TCP
            csum = (tcp[16] << 8) | tcp[17]
            pdesc += f" TCP {sport}->{dport} [{fl}] hdrlen={hdrlen} csum=0x{csum:04x}"
        elif proto == 1:
            pdesc += " ICMP"
        desc += pdesc
    print(desc)
