#!/usr/bin/env python3
"""test_net2.py — сессия 7: сеть на ne2000/virtio + loopback + httpd.

Проверяет главные сценарии пользователя:
  A. NE2000 (активный NIC у пользователя): DHCP от slirp, ping gw,
     curl на внешний адрес, HTTP Trace
  B. VirtIO-net: то же самое
  C. Loopback: curl http://127.0.0.1/ , http://localhost/ , ping 127.0.0.1
  D. hostfwd: httpd гостя доступен с хоста (реальный listen-путь)
"""
import sys, time, os, subprocess, threading, http.server, socketserver

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_at, ocr_strip, load_glyphs, looks_like, norm

ISO = "/home/z/my-project/work/n2600/proj/os.iso"
SHOTS = "/tmp/shots"
os.makedirs(SHOTS, exist_ok=True)
GL = load_glyphs()

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def wait_serial(substr, timeout=40, logfile="/tmp/os-serial.log"):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = open(logfile, "rb").read().decode("utf-8", "replace")
        except OSError:
            time.sleep(0.3)
            continue
        if substr in s:
            return True
        time.sleep(0.3)
    return False


def serial_tail(n=4000, logfile="/tmp/os-serial.log"):
    try:
        return open(logfile, "rb").read().decode("utf-8", "replace")[-n:]
    except OSError:
        return ""


# ---- хост-HTTP-сервер (для curl из гостя через guestfwd) ----
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"<html><body><h1>Zagolovok testa</h1><p>NE2000 works.</p></body></html>"
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


socketserver.TCPServer.allow_reuse_address = True
httpd = socketserver.TCPServer(("127.0.0.1", 8081), H)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
print("HTTP-сервер хоста: 127.0.0.1:8081")


def run_boot(tag, extra, ram=512):
    """Загрузить ОС с заданными доп. аргументами QEMU; вернуть QMon."""
    q = QMon(ISO, extra_args=extra, ram=ram)
    q.__enter__()
    time.sleep(10)
    return q


def term_cmd(q, cmd, settle=1.2):
    """Набрать команду в терминале (sendkeys) и подождать вывода."""
    q.sendkeys(cmd, delay=0.03)
    q.cmd("sendkey ret", 0.05)
    time.sleep(settle)


# ============================================================ A. NE2000
print("\n=== A. NE2000 + slirp: DHCP / ping / curl ===")
NE = ["-netdev", "user,id=net0,guestfwd=tcp:10.0.2.100:80-tcp:127.0.0.1:8081",
      "-device", "ne2k_pci,netdev=net0,romfile="]
open("/tmp/os-serial.log", "w").close()
try:
    q = run_boot("ne2000", NE)
    q.screendump(f"{SHOTS}/ne-boot.ppm")
    ser = serial_tail(6000)
    print("  serial:", ser[-600:].replace("\n", " | ")[-600:])
    check("A1 ne2000: драйвер нашёлся", "[ne2000] found:" in ser, ser[-300:])
    check("A2 ne2000: ready", "[ne2000] ready" in ser)
    check("A3 DHCP: OFFER от slirp получен", "[dhcp] sending REQUEST" in ser or "BOUND" in ser,
          ser[-400:])
    check("A4 netcfg: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])

    # ping шлюза
    term_cmd(q, "ping 10.0.2.2")
    time.sleep(4)
    ser = serial_tail(1500)
    # проверка по экрану: reply строки в терминале
    q.screendump(f"{SHOTS}/ne-ping.ppm")
    lines = ocr_strip(f"{SHOTS}/ne-ping.ppm", 25, 45, 78, 12)
    print("  терминал:", lines[:8])
    ok_ping = any("reply" in l and "no reply" not in l for l in lines)
    check("A5 ne2000: ping 10.0.2.2 — есть ответы", ok_ping, str(lines[:6]))

    # curl через guestfwd (внешний адрес 10.0.2.100 — через шлюз!)
    term_cmd(q, "http 10.0.2.100 /", settle=5)
    q.screendump(f"{SHOTS}/ne-curl.ppm")
    lines = ocr_strip(f"{SHOTS}/ne-curl.ppm", 25, 45, 78, 16)
    print("  терминал:", lines[:10])
    ok_curl = any("Zagolovok" in l or "Получено" in l or "Zagolovok" in l for l in lines)
    check("A6 ne2000: http 10.0.2.100 — ответ получен", ok_curl, str(lines[:8]))
    q.__exit__(None, None, None)
except Exception as e:
    check("A: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ B. VirtIO
print("\n=== B. VirtIO-net + slirp ===")
VIO = ["-netdev", "user,id=net0,guestfwd=tcp:10.0.2.100:80-tcp:127.0.0.1:8081",
       "-device", "virtio-net-pci,netdev=net0,romfile="]
open("/tmp/os-serial.log", "w").close()
try:
    q = run_boot("virtio", VIO)
    ser = serial_tail(6000)
    print("  serial:", ser[-400:].replace("\n", " | ")[-400:])
    check("B1 virtio: found", "[virtio] found:" in ser, ser[-300:])
    check("B2 virtio: ready", "[virtio] ready" in ser, ser[-300:])
    check("B3 virtio: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])

    term_cmd(q, "ping 10.0.2.2")
    time.sleep(4)
    q.screendump(f"{SHOTS}/vio-ping.ppm")
    lines = ocr_strip(f"{SHOTS}/vio-ping.ppm", 25, 45, 78, 12)
    ok_ping = any("reply" in l and "no reply" not in l for l in lines)
    check("B4 virtio: ping — ответы", ok_ping, str(lines[:6]))

    term_cmd(q, "http 10.0.2.100 /", settle=5)
    q.screendump(f"{SHOTS}/vio-curl.ppm")
    lines = ocr_strip(f"{SHOTS}/vio-curl.ppm", 25, 45, 78, 16)
    ok_curl = any("Zagolovok" in l or "Получено" in l or "Zagolovok" in l for l in lines)
    check("B5 virtio: http — ответ", ok_curl, str(lines[:8]))
    q.__exit__(None, None, None)
except Exception as e:
    check("B: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ C. Loopback
print("\n=== C. Loopback: http/ping 127.0.0.1, localhost ===")
open("/tmp/os-serial.log", "w").close()
try:
    q = run_boot("loopback", ["-netdev", "user,id=net0", "-device", "e1000,netdev=net0,romfile="])
    ser = serial_tail(4000)
    check("C1 httpd: слушает :80", "[httpd] listening" in ser, ser[-300:])

    term_cmd(q, "http 127.0.0.1 /", settle=4)
    q.screendump(f"{SHOTS}/lo-curl.ppm")
    lines = ocr_strip(f"{SHOTS}/lo-curl.ppm", 25, 45, 78, 16)
    print("  терминал:", [l for l in lines if l.strip()][:10])
    ok_lo = any("local httpd" in l for l in lines)
    check("C2 http 127.0.0.1 / — страница httpd", ok_lo, str(lines[:8]))

    term_cmd(q, "http localhost /hello", settle=4)
    q.screendump(f"{SHOTS}/lo-hello.ppm")
    lines = ocr_strip(f"{SHOTS}/lo-hello.ppm", 25, 45, 78, 16)
    ok_hello = any("Hello from N2600-OS" in l for l in lines)
    check("C3 http localhost /hello", ok_hello, str(lines[:8]))

    term_cmd(q, "ping 127.0.0.1")
    time.sleep(4)
    q.screendump(f"{SHOTS}/lo-ping.ppm")
    lines = ocr_strip(f"{SHOTS}/lo-ping.ppm", 25, 45, 78, 12)
    print("  ping:", [l for l in lines if l.strip()][:8])
    ok_ping = any("reply" in l and "no reply" not in l for l in lines)
    check("C4 ping 127.0.0.1 — мгновенные ответы", ok_ping, str(lines[:8]))

    # connection refused на свободный порт
    term_cmd(q, "tcping 127.0.0.1 9999", settle=5)
    q.screendump(f"{SHOTS}/lo-refused.ppm")
    lines = ocr_strip(f"{SHOTS}/lo-refused.ppm", 25, 45, 78, 20)
    print("  tcping:", [l for l in lines if l.strip()][:8])
    ok_ref = any("CLOSED" in l for l in lines)
    check("C5 tcping 127.0.0.1:9999 — connection refused (CLOSED)", ok_ref, str(lines[:8]))

    # curl (открывает браузер — проверяем по serial, что не зависло)
    term_cmd(q, "curl http://127.0.0.1/", settle=5)
    time.sleep(2)
    ser = serial_tail(2000)
    ok_curl = "[curl] 127.0.0.1:80 ->" in ser
    check("C6 curl http://127.0.0.1/ — ответ, браузер открылся", ok_curl, ser[-300:])
    q.__exit__(None, None, None)
except Exception as e:
    check("C: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ D. hostfwd → гостевой httpd
print("\n=== D. httpd снаружи (hostfwd tcp::8080-:80) ===")
open("/tmp/os-serial.log", "w").close()
try:
    q = run_boot("hostfwd", ["-netdev", "user,id=net0,hostfwd=tcp::8080-:80",
                             "-device", "e1000,netdev=net0,romfile="])
    ser = serial_tail(3000)
    check("D1 httpd слушает", "[httpd] listening" in ser, ser[-200:])
    import urllib.request
    time.sleep(1)
    got = ""
    try:
        r = urllib.request.urlopen("http://127.0.0.1:8080/", timeout=10)
        got = r.read().decode("utf-8", "replace")
    except Exception as e:
        got = f"ERR {e}"
    print("  ответ httpd:", got[:200].replace("\n", " "))
    check("D2 host→гость httpd: страница", "N2600-OS local httpd" in got, got[:150])
    try:
        r = urllib.request.urlopen("http://127.0.0.1:8080/hello", timeout=10)
        got2 = r.read().decode("utf-8", "replace")
    except Exception as e:
        got2 = f"ERR {e}"
    check("D3 host→гость /hello", "Hello from N2600-OS" in got2, got2[:100])
    q.__exit__(None, None, None)
except Exception as e:
    check("D: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

print(f"\n=== ИТОГ: {len(PASS)} PASS / {len(FAIL)} FAIL ===")
for f in FAIL:
    print("  FAIL:", f)
sys.exit(0 if not FAIL else 1)
