#!/usr/bin/env python3
"""repro_exc13.py — воспроизведение ошибки #exc13 (сессия 13).

Сценарий пользователя: «стандартный пример в редакторе c4 запускается и
показывает вывод, но если запустить уже скомпилированный prog.bin с
рамдиска — ошибка #exc13».

prog.c = точный шаблон редактора (apps_editor.c default_template).
Шаги: boot -> `cc prog.c` (native c4_x86 -> prog.bin) -> `run prog.bin`
-> анализ serial: [loader]/[c4out:prog.bin]/app crashed.
"""
import sys, time, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
from qmon import QMon

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))


def serial_text():
    try:
        return open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")
    except FileNotFoundError:
        return ""


def wait_serial(substr, timeout=40, tail_from=None):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = serial_text()
        if tail_from is not None:
            s = s[tail_from:] if tail_from < len(s) else ""
        if substr in s:
            return True
        time.sleep(0.3)
    return False


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.035)
    time.sleep(0.15)
    q.cmd("sendkey ret", 0.25)


def main():
    with QMon(ISO) as q:
        time.sleep(12)
        pos0 = len(serial_text())
        type_cmd(q, "cc prog.c")
        if not wait_serial("native binary saved: prog.bin", 30, pos0):
            print("FAIL: cc prog.c не собрался")
            print(serial_text()[pos0:][-500:])
            return 1
        pos1 = len(serial_text())
        type_cmd(q, "run prog.bin")
        time.sleep(8)
        tail = serial_text()[pos1:]
        print("=== SERIAL после run prog.bin ===")
        print(tail)
        crashed = "app crashed" in tail or "App crashed" in tail
        exited = "[c4out:prog.bin] exit code:" in tail
        print("CRASHED:", crashed, " EXITED:", exited)
        if exited and not crashed:
            print("OUTPUT WINDOW TEXT:")
            i = tail.find("[c4out:prog.bin] ---")
            if i >= 0:
                print(tail[i:i+400])
        return 0


if __name__ == "__main__":
    sys.exit(main())
