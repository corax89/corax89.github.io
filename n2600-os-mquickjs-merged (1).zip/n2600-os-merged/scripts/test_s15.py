#!/usr/bin/env python3
"""test_s15.py — сессия 15: WiFi в фоне, Тема, радиобоксы диалога формата.

Сценарий:
  ЧАСТЬ 1 (serial, без железа WiFi):
    - WiFi отложен в фоновую задачу: «apps_open(terminal)» ДО
      «wifi: фоновая инициализация» (рабочий стол не ждал адаптер);
    - фоновая задача завершилась уже после «irq on» (система жила);
    - сеть по-прежнему поднимается: DHCP BOUND.

  ЧАСТЬ 2 (Настройки → вкладка [3] Тема):
    - вкладка открыта (VLM: 9 полос-шкал, строка «Цвет окон»);
    - клик по полосе «Цвет окон R» на ~80% → фон КОНТЕНТА Настроек
      краснеет (пиксель), после закрытия — фон ТЕРМИНАЛА тоже
      (тема применяется ко ВСЕМ окнам);
    - THEME.CFG сохранён (ramread → OCR: WINBG=);
    - сброс [C] возвращает стандартную тему (пиксель фона терминала).

  ЧАСТЬ 3 (радиобоксы диалога формата, диск-мусор 64 МиБ):
    - Настройки → Диски → [F]: красный бокс с ДВУМЯ радиобоксами;
      выбран «Быстрое» (точка в круге);
    - КЛИК МЫШЬЮ по «Полное (очистка)» → точка переезжает на него,
      строка «Выбрано: ПОЛНОЕ» (событие мыши дошло до виджета);
    - Esc — отмена (не форматируем: экономим минуты PIO-записи).
"""
import sys, time, os, subprocess, json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_at, ocr_strip, load_glyphs, read_ppm

ISO = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "os.iso"))
IMG = "/tmp/s15_fmt.img"
SHOTS = "/tmp/s15shots"
os.makedirs(SHOTS, exist_ok=True)
PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}"
          + (f" — {detail}" if detail and not cond else ""))


def vlm_ask(prompt, *imgs):
    args = ["z-ai", "vision", "-p", prompt]
    for i in imgs:
        args += ["-i", i]
    out = os.path.join(SHOTS, "_vlm.json")
    try:
        r = subprocess.run(args + ["-o", out], capture_output=True, text=True, timeout=180)
        return json.load(open(out))["choices"][0]["message"]["content"]
    except Exception as e:
        return ""


def ppm2png(ppm):
    from PIL import Image
    png = ppm.replace(".ppm", ".png")
    Image.open(ppm).save(png)
    return png


def px(ppm, x, y):
    w, h, img = read_ppm(ppm)
    off = (y * w + x) * 3
    return tuple(img[off:off + 3])


def type_cmd(q, cmd):
    q.sendkeys(cmd, delay=0.04)
    q.cmd("sendkey ret", 0.25)


def make_junk_disk():
    if os.path.exists(IMG):
        os.unlink(IMG)
    with open(IMG, "wb") as f:
        f.write(b"\x00" * 512 * 2048)
        f.write(os.urandom(512 * 2048))
        f.truncate(64 * 1024 * 1024)
    return os.path.exists(IMG)


W, H = 800, 600
# Окно Настроек: (60,40) 544x440; контент-оригин (61,65)
SET_X, SET_Y = 60, 40
C0X, C0Y = SET_X + 1, SET_Y + 24 + 1          # (61, 65) контент-оригин
# Вкладка «Тема»: строки-каналы THEME_ROW0_Y=56 (контентные), шаг 17
def row_screen_y(r): return C0Y + 56 + 17 * r  # верх полосы строки r
BAR_X = C0X + 40                               # полоса x: 101..351
BAR_W = 250
# Радиобоксы диалога формата (диск 64 МиБ, 0 разделов): by=79 контентно
FMT_BY = C0Y + 79
RADIO_QUICK = (C0X + 20, FMT_BY + 42)          # «Быстрое»
RADIO_FULL = (C0X + 300, FMT_BY + 42)          # «Полное»
# Терминал (20,16) 506x318, контент (21,41); фон-точка правее текста
TERM_BG_PX = (490, 60)


def main():
    glyphs = load_glyphs()

    print("== ЧАСТЬ 1: WiFi в фоне, порядок загрузки (serial) ==")
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO) as q:
        t0 = time.time()
        while time.time() - t0 < 60:
            s = q.serial()
            if "entering main loop" in s and "DHCP ok" in s:
                break
            time.sleep(1)
        s = q.serial()
        check("boot: WiFi отложен в фон",
              "wifi: отложено в фоновую задачу" in s, s[-200:])
        i_term = s.find("apps_open(terminal)")
        i_wifi = s.find("wifi: фоновая инициализация")
        i_irq = s.find("irq on, entering main loop")
        i_wfin = s.find("[wifi] адаптер Atheros не найден")
        check("порядок: рабочий стол ДО wifi-init",
              0 <= i_term < i_wifi, f"term={i_term} wifi={i_wifi}")
        check("порядок: wifi-init до main loop", 0 <= i_wifi < i_irq)
        # задача завершается где-то между запуском и первым тактом
        # планировщика — в QEMU (без Atheros) она успевает ДО печати
        # «irq on»: это нормально, т.к. рабочий стол УЖЕ создан
        # (apps_open < wifi-init — главная гарантия отсутствия блока)
        check("фоновая wifi-задача запущена и завершилась",
              i_wfin > i_wifi > 0 and "адаптер Atheros не найден" in s,
              f"wfin={i_wfin} wifi={i_wifi}")
        check("DHCP по-прежнему работает", "netcfg: DHCP ok" in s)

        print("== ЧАСТЬ 2: Тема ==")
        # до: фон терминала стандартный тёмный
        q.screendump(f"{SHOTS}/t0.ppm")
        bg0 = px(f"{SHOTS}/t0.ppm", *TERM_BG_PX)
        check("терминал: стандартный тёмный фон",
              abs(bg0[0]-0x10) < 14 and abs(bg0[1]-0x13) < 14 and
              abs(bg0[2]-0x18) < 14, str(bg0))

        type_cmd(q, "open 10")
        time.sleep(1.2)
        q.cmd("sendkey 3", 0.1)         # вкладка «Тема»
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/theme-tab.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window, tab [3] Тема "
            "(Theme) is active. There should be NINE rows of color "
            "slider bars (Цвет окон R/G/B, Цвет текста R/G/B, "
            "Заголовок R/G/B) with numeric values, a small window "
            "preview on the right, and a reset line. Answer briefly: "
            "ROWS=<number of slider rows>, PREVIEW=yes/no, "
            "FIRST_ROW=<its label>.",
            ppm2png(f"{SHOTS}/theme-tab.ppm"))
        print("  VLM:", ans[:220])
        check("вкладка Тема: 9 полос-шкал", "ROWS=9" in ans, ans[:180])
        check("вкладка Тема: живой предпросмотр", "PREVIEW=yes" in ans, ans[:180])

        # клик по полосе «Цвет окон R» на ~80% ширины → R≈204
        q.click_at(BAR_X + 200, row_screen_y(0) + 5)
        time.sleep(1.0)
        q.screendump(f"{SHOTS}/theme-red.ppm")
        # фон КОНТЕНТА настроек: точка в свободной зоне (x=460, y=C0Y+207)
        bg1 = px(f"{SHOTS}/theme-red.ppm", 460, C0Y + 207)
        check("фон окна сменился на красноватый (R преобладает)",
              bg1[0] > 120 and bg1[0] > bg1[1] + 60 and bg1[0] > bg1[2] + 60,
              str(bg1))
        # заголовок НЕ изменился (цвет окон ≠ заголовок)
        ttl = px(f"{SHOTS}/theme-red.ppm", SET_X + 100, SET_Y + 10)
        check("заголовок окна не изменился (тёмно-синий)",
              abs(ttl[0]-0x1E) < 16 and abs(ttl[2]-0x73) < 20, str(ttl))

        # закрыть Настройки: терминал перерисовался НОВОЙ темой
        q.cmd("sendkey esc", 0.2)
        time.sleep(1.2)
        q.screendump(f"{SHOTS}/theme-term.ppm")
        bgt = px(f"{SHOTS}/theme-term.ppm", *TERM_BG_PX)
        check("тема применилась к ТЕРМИНАЛУ (другому окну)",
              bgt[0] > 120 and bgt[0] > bgt[1] + 60, str(bgt))

        # THEME.CFG сохранён на RAM disk
        type_cmd(q, "ramread THEME.CFG")
        time.sleep(1.5)
        q.screendump(f"{SHOTS}/theme-cfg.ppm")
        rows = ocr_strip(f"{SHOTS}/theme-cfg.ppm", 25, 45, 60, 14)
        joined = "".join(rows).replace(" ", "").upper()
        print("  ramread:", [l for l in rows if l.strip()][:4])
        check("THEME.CFG сохранён (winbg=)", "WINBG=" in joined, joined[:120])

        # сброс: Настройки → 3 → C
        type_cmd(q, "open 10")
        time.sleep(1.0)
        q.cmd("sendkey 3", 0.1)
        time.sleep(0.5)
        q.cmd("sendkey c", 0.1)
        time.sleep(1.0)
        q.cmd("sendkey esc", 0.2)
        time.sleep(1.2)
        q.screendump(f"{SHOTS}/theme-reset.ppm")
        bg2 = px(f"{SHOTS}/theme-reset.ppm", *TERM_BG_PX)
        check("сброс темы: терминал снова тёмный",
              abs(bg2[0]-0x10) < 14 and abs(bg2[2]-0x18) < 14, str(bg2))

    print("== ЧАСТЬ 3: радиобоксы диалога формата ==")
    check("образ диска создан", make_junk_disk())
    open("/tmp/os-serial.log", "w").close()
    with QMon(ISO, extra_args=[
            "-drive", f"file={IMG},format=raw,if=ide,index=1,media=disk",
        ]) as q:
        # дождаться, пока sata-задача увидит диск (фоново)
        t0 = time.time()
        while time.time() - t0 < 45:
            s = q.serial()
            if "disk: НЖМД" in s or "ata: HDD" in s:
                break
            time.sleep(1)
        time.sleep(2)
        type_cmd(q, "open 10")
        time.sleep(1.0)
        q.cmd("sendkey 2", 0.1)         # вкладка «Диски»
        time.sleep(0.6)
        q.cmd("sendkey f", 0.1)         # диалог формата
        time.sleep(0.8)
        q.screendump(f"{SHOTS}/fmt-radios.ppm")
        ans = vlm_ask(
            "Screenshot of a hobby OS Settings window with a RED warning "
            "box about formatting. Inside the box there are TWO radio "
            "buttons (circles): «Быстрое (оглавление)» and «Полное "
            "(очистка)». Which one has a FILLED dot (selected)? Is there "
            "a line starting with «Выбрано:» below? "
            "Answer: QUICK=yes/no, FULL=yes/no (filled), "
            "SELECTED=<quick/full>, CHOICE_LINE=<text>.",
            ppm2png(f"{SHOTS}/fmt-radios.ppm"))
        print("  VLM:", ans[:220])
        check("диалог: радиобоксы видны (кружки)",
              "QUICK=yes" in ans or "FULL=yes" in ans, ans[:180])
        check("диалог: выбрано БЫСТРОЕ по умолчанию",
              "SELECTED=quick" in ans.upper() or "БЫСТРОЕ" in ans.upper(), ans[:180])

        # КЛИК МЫШЬЮ по «Полное (очистка)» — виджет получает событие от WM
        q.click_at(RADIO_FULL[0] + 30, RADIO_FULL[1] + 6)
        time.sleep(1.0)
        q.screendump(f"{SHOTS}/fmt-full.ppm")
        ans2 = vlm_ask(
            "Screenshot of the same dialog. Which radio button is now "
            "selected (filled dot): «Быстрое (оглавление)» (left) or "
            "«Полное (очистка)» (right)? What does the «Выбрано:» line "
            "say? Answer: SELECTED=<left/right>, "
            "CHOICE=<ПОЛНОЕ/БЫСТРОЕ...>.",
            ppm2png(f"{SHOTS}/fmt-full.ppm"))
        print("  VLM:", ans2[:220])
        sel = ans2.upper()
        check("радиобокс «Полное» получил клик мыши (точка у него)",
              "RIGHT" in sel or "ПОЛНОЕ" in sel, ans2[:180])
        check("строка «Выбрано: ПОЛНОЕ» обновилась",
              "ПОЛНОЕ" in sel, ans2[:180])

        # Esc — отмена (форматирование не стартует)
        q.cmd("sendkey esc", 0.2)
        time.sleep(0.8)
        ser = q.serial()
        check("формат НЕ начался (Esc отменил)",
              "структуры записаны" not in ser, ser[-120:])

    print()
    print(f"ИТОГО: {len(PASS)} PASS / {len(FAIL)} FAIL")
    if FAIL:
        print("FAILURES:", FAIL)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
