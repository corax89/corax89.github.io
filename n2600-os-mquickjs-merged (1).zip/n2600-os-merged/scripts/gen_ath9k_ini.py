#!/usr/bin/env python3
"""gen_ath9k_ini.py — извлекает НАСТОЯЩИЕ init-массивы ath9k (Linux, GPL)
из справочных заголовков (work/n2600/ath9k-ref/) в один C-заголовок
для драйвера N2600-OS (src/ath9k_ini_data.h).

Источник: Linux kernel (GPLv2), drivers/net/wireless/ath/ath9k/
  ar9002_initvals.h  — AR9285/AR9287 (owl/kite)
  ar9485_initvals.h  — AR9485 (sowl)
  ar9330_1p1_initvals.h — mac_postamble для AR9485 (алиас ar9331_1p1)
"""
import re
import sys
import os

REF = "/home/z/my-project/work/n2600/ath9k-ref"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "..", "src", "ath9k_ini_data.h")

WANT = [
    # (файл, имя массива, комментарий)
    ("ar9002_initvals.h", "ar9285Modes_9285_1_2",
     "AR9285 modes (HT20 2ГГц = колонка 4) — Linux ath9k ar9285Modes_9285_1_2"),
    ("ar9002_initvals.h", "ar9285Common_9285_1_2",
     "AR9285 common — Linux ath9k ar9285Common_9285_1_2"),
    ("ar9002_initvals.h", "ar9285Modes_original_tx_gain_9285_1_2",
     "AR9285 TX gain (original) — Linux ath9k"),
    ("ar9002_initvals.h", "ar9280PciePhy_clkreq_always_on_L1_9280",
     "PCIe SerDes (owl) — Linux ath9k"),
    ("ar9002_initvals.h", "ar9287Modes_9287_1_1",
     "AR9287 modes — Linux ath9k ar9287Modes_9287_1_1"),
    ("ar9002_initvals.h", "ar9287Common_9287_1_1",
     "AR9287 common — Linux ath9k ar9287Common_9287_1_1"),
    ("ar9002_initvals.h", "ar9287Common_normal_cck_fir_coeff_9287_1_1",
     "AR9287 CCK FIR (обычные каналы) — Linux ath9k"),
    ("ar9002_initvals.h", "ar9287Common_japan_2484_cck_fir_coeff_9287_1_1",
     "AR9287 CCK FIR (канал 14, Япония) — Linux ath9k"),
    ("ar9002_initvals.h", "ar9287Modes_rx_gain_9287_1_1",
     "AR9287 RX gain — Linux ath9k"),
    ("ar9002_initvals.h", "ar9287Modes_tx_gain_9287_1_1",
     "AR9287 TX gain — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1",
     "AR9485 baseband PRE — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_soc_preamble",
     "AR9485 SOC preamble — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_mac_core",
     "AR9485 MAC core — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_baseband_core",
     "AR9485 baseband core — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_baseband_postamble",
     "AR9485 baseband postamble (HT20 2ГГц = колонка 4) — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_radio_core",
     "AR9485 radio core — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_radio_postamble",
     "AR9485 radio postamble — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485Common_wo_xlna_rx_gain_1_1",
     "AR9485 RX gain (без xLNA) — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485Modes_low_ob_db_tx_gain_1_1",
     "AR9485 TX gain (lowest ob/db) — Linux ath9k"),
    ("ar9485_initvals.h", "ar9485_1_1_pcie_phy_clkreq_disable_L1",
     "AR9485 PCIe PHY — Linux ath9k"),
    ("ar9330_1p1_initvals.h", "ar9331_1p1_mac_postamble",
     "MAC postamble для AR9485 (алиас ar9331_1p1 в Linux) — Linux ath9k"),
]

ARR_RE = re.compile(
    r"static\s+const\s+u32\s+(\w+)\s*\[\]\s*\[(\d+)\]\s*=\s*\{(.*?)\}\s*;",
    re.S)

C_COMMENT_RE = re.compile(r"/\*.*?\*/", re.S)


def strip_comments(text):
    text = C_COMMENT_RE.sub(" ", text)
    return text


def main():
    cache = {}
    out = []
    out.append("/* ath9k_ini_data.h — НАСТОЯЩИЕ init-значения Atheros ath9k.\n"
               " *\n"
               " * Извлечены из Linux (GPLv2), drivers/net/wireless/ath/ath9k/:\n"
               " *   ar9002_initvals.h, ar9485_initvals.h, ar9330_1p1_initvals.h\n"
               " * скриптом scripts/gen_ath9k_ini.py. НЕ редактировать вручную:\n"
               " * значения проверены по исходникам эталонного драйвера.\n"
               " *\n"
               " * Формат строк: { reg, val[, col1..col4] }.\n"
               " *   5-колоночные массивы: колонка 4 = 2.4 ГГц HT20 (наш режим).\n"
               " */\n"
               "#ifndef ATH9K_INI_DATA_H\n"
               "#define ATH9K_INI_DATA_H\n\n"
               '#include "types.h"\n\n')

    for fname, arr, comment in WANT:
        if fname not in cache:
            with open(os.path.join(REF, fname)) as f:
                cache[fname] = dict(
                    (m[0], (m[1], m[2])) for m in ARR_RE.findall(f.read()))
        if arr not in cache[fname]:
            print(f"MISS: {fname}:{arr}", file=sys.stderr)
            continue
        cols, body = cache[fname][arr]
        # компактно: числа через пробел, по ncol чисел в строке;
        # фигурные скобки строк — разделители (не часть значений!)
        toks = [t for t in re.split(r"[{},\s]+", strip_comments(body).strip()) if t]
        ncol = int(cols)
        nrow = len(toks) // ncol
        out.append(f"/* {comment} */")
        out.append(f"static const u32 {arr}[][{ncol}] = {{")
        for r in range(nrow):
            row = toks[r * ncol:(r + 1) * ncol]
            out.append("    { " + ", ".join(row) + " },")
        out.append("};\n")
        print(f"{arr}: {nrow} строк x {ncol}")

    out.append("#endif /* ATH9K_INI_DATA_H */\n")
    with open(OUT, "w") as f:
        f.write("\n".join(out))
    print(f"-> {OUT} ({os.path.getsize(OUT)} байт)")


if __name__ == "__main__":
    main()
