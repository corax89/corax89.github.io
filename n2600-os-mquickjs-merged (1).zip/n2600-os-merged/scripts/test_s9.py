#!/usr/bin/env python3
"""test_s9.py — сессия 9: virtio modern (virtio 1.0) транспорт.

Сценарий пользователя: virtio-устройство с ID 0x1040+ (modern/1.0) —
драйвер раньше гнал его по legacy-протоколу: мусорный MAC, мёртвые
очереди, DHCP DISCOVER не покидал гостя (no OFFER), DNS timeout.

Проверяем:
  A. virtio-net-pci-non-transitional (modern-only): драйвер modern,
     DHCP ok, ping, DNS не таймаутится
  B. virtio-net-pci (transitional): тоже modern, DHCP ok, ping
  C. virtio-net-pci,disable-modern=on (legacy-only): DHCP ok
  D. ne2k_pci: DHCP ok (регресс)
  E. e1000: DHCP ok (регресс)
"""
import sys, time, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import QMon, ocr_strip, load_glyphs

ISO = "/home/z/my-project/work/n2600/proj/os.iso"
SHOTS = "/tmp/shots9"
os.makedirs(SHOTS, exist_ok=True)
GL = load_glyphs()

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail and not cond else ""))


def serial_tail(n=4000, logfile="/tmp/os-serial.log"):
    try:
        return open(logfile, "rb").read().decode("utf-8", "replace")[-n:]
    except OSError:
        return ""


def run_boot(extra, ram=512):
    open("/tmp/os-serial.log", "w").close()
    q = QMon(ISO, extra_args=extra, ram=ram)
    q.__enter__()
    time.sleep(11)
    return q


def term_cmd(q, cmd, settle=1.5):
    q.sendkeys(cmd, delay=0.03)
    q.cmd("sendkey ret", 0.05)
    time.sleep(settle)


def ping_check(q, tag):
    term_cmd(q, "ping 10.0.2.2")
    time.sleep(4.5)
    q.screendump(f"{SHOTS}/{tag}-ping.ppm")
    lines = ocr_strip(f"{SHOTS}/{tag}-ping.ppm", 25, 45, 78, 12)
    print("  терминал:", lines[:8])
    ok = any("reply" in l and "no reply" not in l for l in lines)
    return ok, lines


# ============================================================ A. modern-only
print("\n=== A. virtio-net-pci-non-transitional (virtio 1.0, modern-only) ===")
A = ["-netdev", "user,id=net0",
     "-device", "virtio-net-pci-non-transitional,netdev=net0,romfile="]
try:
    q = run_boot(A)
    ser = serial_tail(6000)
    print("  serial:", ser[-500:].replace("\n", " | ")[-500:])
    check("A1 modern: драйвер 1.0 (modern)", "VirtIO-net 1.0 (modern)" in ser, ser[-300:])
    check("A2 modern: корректный MAC (не мусор)", "MAC: 52:54:00:12:34:56" in ser, ser[-300:])
    check("A3 modern: DHCP ok (OFFER+BOUND)", "netcfg: DHCP ok" in ser, ser[-400:])
    ok, lines = ping_check(q, "mod")
    check("A4 modern: ping 10.0.2.2 — ответы", ok, str(lines[:6]))
    # DNS: запрос по имени — не должно быть timeout
    open("/tmp/os-serial.log", "a").close()
    tail0 = len(open("/tmp/os-serial.log", "rb").read())
    term_cmd(q, "http example.com /", settle=8)
    ser2 = open("/tmp/os-serial.log", "rb").read().decode("utf-8", "replace")[tail0:]
    print("  serial(http example.com):", ser2[-300:].replace("\n", " | ")[-300:])
    check("A5 modern: DNS не таймаутится", "[dns] timeout" not in ser2, ser2[-200:])
    check("A6 modern: DNS resolved (нет 'cannot resolve')", "cannot resolve host" not in ser2, ser2[-200:])
    q.__exit__(None, None, None)
except Exception as e:
    check("A: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ B. transitional
print("\n=== B. virtio-net-pci (transitional → modern caps) ===")
B = ["-netdev", "user,id=net0",
     "-device", "virtio-net-pci,netdev=net0,romfile="]
try:
    q = run_boot(B)
    ser = serial_tail(6000)
    check("B1 transitional: выбран modern", "VirtIO-net 1.0 (modern)" in ser, ser[-300:])
    check("B2 transitional: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])
    ok, lines = ping_check(q, "trans")
    check("B3 transitional: ping — ответы", ok, str(lines[:6]))
    q.__exit__(None, None, None)
except Exception as e:
    check("B: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ C. legacy-only
print("\n=== C. virtio-net-pci,disable-modern=on (legacy) ===")
C = ["-netdev", "user,id=net0",
     "-device", "virtio-net-pci,disable-modern=on,netdev=net0,romfile="]
try:
    q = run_boot(C)
    ser = serial_tail(6000)
    check("C1 legacy: драйвер legacy", "VirtIO-net (legacy)" in ser, ser[-300:])
    check("C2 legacy: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])
    q.__exit__(None, None, None)
except Exception as e:
    check("C: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ D. NE2000
print("\n=== D. ne2k_pci (регресс) ===")
D = ["-netdev", "user,id=net0", "-device", "ne2k_pci,netdev=net0,romfile="]
try:
    q = run_boot(D)
    ser = serial_tail(6000)
    check("D1 ne2000: found", "[ne2000] found:" in ser, ser[-300:])
    check("D2 ne2000: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])
    q.__exit__(None, None, None)
except Exception as e:
    check("D: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

# ============================================================ E. e1000
print("\n=== E. e1000 (регресс) ===")
E = ["-netdev", "user,id=net0", "-device", "e1000,netdev=net0,romfile="]
try:
    q = run_boot(E)
    ser = serial_tail(6000)
    check("E1 e1000: found", "[e1000] found" in ser or "e1000] init" in ser, ser[-300:])
    check("E2 e1000: DHCP ok", "netcfg: DHCP ok" in ser, ser[-400:])
    q.__exit__(None, None, None)
except Exception as e:
    check("E: исключение", False, str(e))
    try:
        q.__exit__(None, None, None)
    except Exception:
        pass

print(f"\n=== ИТОГ: {len(PASS)} PASS / {len(FAIL)} FAIL ===")
for f in FAIL:
    print("  FAIL:", f)
sys.exit(0 if not FAIL else 1)
