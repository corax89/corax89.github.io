#!/usr/bin/env python3
"""diag_s5.py — разобрать скриншоты теста сессии 5: что реально на экране"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qmon import load_glyphs, ocr_at, ocr_strip, read_ppm

SHOTS = "/tmp/s5shots"
G = load_glyphs()


def region_desc(path, x, y, cols, rows, bright=400):
    try:
        return ocr_strip(path, x, y, cols, rows, G, bright=bright)
    except Exception as e:
        return [f"<err {e}>"]


def title_bars(path):
    """OCR заголовков всех видимых окон: сканируем полосы на y=20..90"""
    out = []
    for y in range(18, 100, 1):
        # ищем непустую полосу
        pass
    return out


for name in sys.argv[1:]:
    p = f"{SHOTS}/{name}"
    if not os.path.exists(p):
        print(f"--- {name}: НЕТ ФАЙЛА")
        continue
    w, h, img = read_ppm(p)
    print(f"--- {name} ({w}x{h}) ---")
    # заголовок терминала (20,16..40) и строки 45+
    print("  терминал title:", repr(ocr_at(p, 28, 20, 14, G, bright=300)))
    print("  терминал строки:", [l for l in region_desc(p, 25, 45, 60, 4, 300) if l.strip()][:4])
    # область нетрейса (60,60): заголовок и первые строки
    print("  nettrace title:", repr(ocr_at(p, 68, 64, 16, G, bright=300)))
    print("  nettrace 105..:", [l for l in region_desc(p, 65, 105, 60, 6, 150) if l.strip()][:6])
    # fileman (30,30)
    print("  files title:", repr(ocr_at(p, 38, 34, 10, G, bright=300)))
    print("  files devbar:", repr(ocr_at(p, 43, 59, 40, G, bright=150)))
    print("  files header:", repr(ocr_at(p, 37, 80, 40, G, bright=150)))
    print("  files список:", [l for l in region_desc(p, 37, 100, 50, 5, 150) if l.strip()][:5])
    # общая полоса y=42..44 (заголовки окон в стеке)
    for yy, tag in [(20, "y20"), (34, "y34"), (64, "y64")]:
        row = ocr_strip(p, 20, yy, 95, 1, G, bright=300)
        if row and row[0].strip():
            print(f"  полоса {tag}:", repr(row[0][:90]))
