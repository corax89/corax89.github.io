#!/bin/bash
# run_bochs.sh — запуск N2600-OS в Bochs (точная эмуляция сегментов) для
# воспроизведения #exc13 в песочнице native-программ.
# Использование: run_bochs.sh <секунд_прогона> [аргументы bochs-bin]
set -e
cd "$(dirname "$0")/.."
SECS=${1:-90}
shift 2>/dev/null || true

export LD_LIBRARY_PATH=/home/z/bochs-root/usr/lib/x86_64-linux-gnu:/home/z/qemu-root/usr/lib/x86_64-linux-gnu
export LTDL_LIBRARY_PATH=/home/z/bochs-root/usr/lib/x86_64-linux-gnu/bochs/plugins
export BXSHARE=/home/z/bochs-root/usr/share/bochs
rm -f /tmp/bochs-serial.log /tmp/rfb.stop /tmp/bochs-stderr.txt

pkill -f bochs-bin 2>/dev/null || true
setsid /home/z/bochs-root/usr/bin/bochs-bin -q -f scripts/bochsrc.txt "$@" \
    > /tmp/bochs-stderr.txt 2>&1 &
BOCHS_PID=$!

# держим rfb-сертер живым (иначе паника через 30 с)
setsid python3 scripts/rfb_keepalive.py 127.0.0.1 5900 > /tmp/rfb.log 2>&1 &
RFB_PID=$!

sleep "$SECS"
touch /tmp/rfb.stop
kill $RFB_PID 2>/dev/null || true
kill $BOCHS_PID 2>/dev/null || true
sleep 1
pkill -f bochs-bin 2>/dev/null || true
echo "=== bochs done, serial: ==="
wc -c /tmp/bochs-serial.log 2>/dev/null || echo "(serial пуст)"
