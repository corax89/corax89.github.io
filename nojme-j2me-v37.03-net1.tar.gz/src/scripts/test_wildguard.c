/*
 * test_wildguard.c — [WILDGUARD] v36.50 unit test.
 * 1. nojme_wg_bad: garbage ASCII pairs / pattern poison caught; NULL,
 *    small ints, stack/heap pointers pass (zero false positives by
 *    construction).
 * 2. Defusing behavior: switch_font_draw_text / switch_font_text_width
 *    with a garbage text pointer return early (empty render), do NOT
 *    crash; with a valid string render normally (byte count of the
 *    return differs).
 * 3. Report path: a strong local nojme_wg_report counts calls; the
 *    header's weak declaration must resolve to this definition.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "switch/switch_font.h"

/* strong local definition — overrides the weak one (weak decl in the
 * header + strong def in this TU = this definition wins) */
static int g_reports = 0;
static char g_last_site[32] = "";
static uint64_t g_last_val = 0;
void nojme_wg_report(const char* site, const void* val) {
    g_reports++;
    snprintf(g_last_site, sizeof(g_last_site), "%s", site ? site : "?");
    g_last_val = (uint64_t)(uintptr_t)val;
}

#include "wildguard.h"  /* AFTER the definition: exercises the weak-decl path */

static int fails = 0;
#define CHECK(cond, msg) do { \
    if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
    else { printf("ok: %s\n", msg); } \
} while (0)

int main(void) {
    /* --- 1. threshold --- */
    CHECK(nojme_wg_bad((const void*)0x20697465592F7365ULL) == 1, "es/Yeti  garbage caught");
    CHECK(nojme_wg_bad((const void*)0x636E756F422F7365ULL) == 1, "es/Bounc garbage caught");
    CHECK(nojme_wg_bad((const void*)0x6E692E73676E6974ULL) == 1, "tings.in garbage caught");
    CHECK(nojme_wg_bad((const void*)0xFEFEFEFEFEFEFEFEULL) == 1, "pattern-init poison caught");
    CHECK(nojme_wg_bad((const void*)0x5A5A5A5A5A5A5A5AULL) == 1, "malloc-perturb poison caught");
    CHECK(nojme_wg_bad(NULL) == 0, "NULL passes");
    CHECK(nojme_wg_bad((const void*)0x7FUL) == 0, "small int passes");
    CHECK(nojme_wg_bad((const void*)0x7FFFFFFFULL) == 0, "32-bit value passes");
    CHECK(nojme_wg_bad((const void*)0x00007FFFFFFFFFFFULL) == 0, "top user VA (2^47-1) passes");
    CHECK(nojme_wg_bad((const void*)(uintptr_t)main) == 0, "code pointer passes");
    CHECK(nojme_wg_bad((const void*)&fails) == 0, "stack pointer passes");
    void* heap = malloc(64);
    CHECK(nojme_wg_bad(heap) == 0, "heap pointer passes");
    free(heap);

    /* --- 2. defusing: font draw with garbage text --- */
    static uint32_t canvas[64 * 64];
    memset(canvas, 0, sizeof(canvas));
    int r_ok = switch_font_draw_text(canvas, 64, 64, 0, 0, "AB",
                                     0xFFFFFFFFu, 0, 1);
    int r_bad = switch_font_draw_text(canvas, 64, 64, 0, 0,
                                      (const char*)0x20697465592F7365ULL,
                                      0xFFFFFFFFu, 0, 1);
    CHECK(r_ok > 0, "valid text renders (advances)");
    CHECK(r_bad == 0, "garbage text -> empty render, no crash");
    CHECK(g_reports >= 1 && strcmp(g_last_site, "font:text") == 0,
          "font:text report fired with site name");
    CHECK(g_last_val == 0x20697465592F7365ULL, "report carries the raw value");

    int reports_before = g_reports;
    int w_bad = switch_font_text_width((const char*)0x636E756F422F7365ULL, 1);
    CHECK(w_bad == 0, "garbage width -> 0, no crash");
    CHECK(g_reports == reports_before + 1 &&
          strcmp(g_last_site, "font:width") == 0, "font:width report fired");

    int w_ok = switch_font_text_width("AB", 1);
    CHECK(w_ok > 0, "valid width still computed");

    /* --- 3. macro forms --- */
    WILDGUARD((void*)0x6E692E73676E6974ULL, "unit:report-only");
    CHECK(g_reports == reports_before + 2 &&
          strcmp(g_last_site, "unit:report-only") == 0, "WILDGUARD report-only form");
    CHECK(WILDGUARD_SKIP((void*)0x123, "unit:skip-ok") == 0, "SKIP returns 0 on valid");
    CHECK(WILDGUARD_SKIP((void*)0x6E692E73676E6974ULL, "unit:skip-bad") == 1,
          "SKIP returns 1 on garbage");

    printf(fails ? "WILDGUARD TEST: FAILED (%d)\n" : "WILDGUARD TEST: ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
