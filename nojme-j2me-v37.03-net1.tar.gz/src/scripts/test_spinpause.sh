#!/bin/bash
# v36.63 [SPIN-BREAK-PAUSE-FRESH] e2e: SpinPauseTest.jar на switchui-verify.
# Сценарий: игра 8 с (repaint-цикл из paint), MINUS (пауза меню 2.5 с —
# ДЛИННЕЕ порога NOJME_SPIN_BREAK_MS=1500), B (продолжить), A (нажатие
# в игру — маркер SP:key). PASS:
#   - pause: open/close по паре (меню отработало)
#   - НИ ОДНОГО [SPIN-BREAK] / SP:SPINBREAK-CAUGHT (до фикса ложный выстрел
#     прилетал в первый же slow-check paint по закрытии меню)
#   - кадры живы ПОСЛЕ закрытия: SP:PAINTED-N строки идут ПОСЛЕ SP:key
#     (игра продолжила выполнение после выхода из меню)
#   - t2 sleep-цикл жив (SP:thread-start)
# Негатив-контроль v36.62 (worktree e633c62, прогон этого же раннера):
#   SPIN-BREAK x4, НИ ОДНОГО SP:PAINTED после SP:key (последний кадр ДО
#   нажатия) — цикл краски убит выстрелом в преамбуле paint (исключение
#   unwind-ится выше try), т.е. ровно «игра не продолжает выполнение».
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tsp
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/spinpause/SpinPauseTest.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_KEYS="A:400,A:600,EXIT:30000"
export NOJME_FRONT_KEYS="MINUS:8000,B:2500,A:4000"
timeout -k 5 40 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

ok=1
SYS="$D/err.log"
LOG="$D/sdmc:/switch/j2me/log.txt"
[ -s "$LOG" ] || LOG="$D/log.txt"

# 1) пауза открылась и закрылась
opens=$(grep -acE "^[0-9]+ pause: open" "$LOG" 2>/dev/null || true)
closes=$(grep -acE "^[0-9]+ pause: close" "$LOG" 2>/dev/null || true)
[ "${opens:-0}" -ge 1 ] || { echo "FAIL: пауза не открывалась"; ok=0; }
[ "${closes:-0}" -ge 1 ] || { echo "FAIL: пауза не закрывалась"; ok=0; }

# 2) НИ ОДНОГО ложного спин-брейка
sb=$(grep -ac "SPIN-BREAK\]" "$SYS" 2>/dev/null || true)
sb2=$(grep -ac "SPIN-BREAK\]" "$LOG" 2>/dev/null || true)
caught=$(grep -ac "SP:SPINBREAK-CAUGHT" "$SYS" 2>/dev/null || true)
[ "${sb:-0}" -eq 0 ] && [ "${sb2:-0}" -eq 0 ] || { echo "FAIL: SPIN-BREAK сработал (sb=$sb log=$sb2) — ложный возраст после меню"; ok=0; }
[ "${caught:-0}" -eq 0 ] || { echo "FAIL: paint словил спин-брейк исключение ($caught раз)"; ok=0; }

# 3) t2 жив и стартовал
grep -aq "SP:thread-start" "$SYS" || { echo "FAIL: фоновый поток не стартовал"; ok=0; }

# 4) КЛЮЧЕВОЕ: кадры продолжаются ПОСЛЕ нажатия A (которое после close)
lastkey_line=$(grep -an "SP:key " "$SYS" | tail -1 | cut -d: -f1)
lastpainted_line=$(grep -an "SP:PAINTED-" "$SYS" | tail -1 | cut -d: -f1)
if [ -n "$lastkey_line" ] && [ -n "$lastpainted_line" ]; then
    if [ "$lastpainted_line" -le "$lastkey_line" ]; then
        echo "FAIL: после нажатия A (строка $lastkey_line) нет ни одного PAINTED (последний на $lastpainted_line) — игра не продолжила выполнение"
        ok=0
    fi
else
    echo "FAIL: нет маркеров SP:key/SP:PAINTED (key=$lastkey_line painted=$lastpainted_line)"
    ok=0
fi

frames=$(grep -ao "SP:PAINTED-[0-9]*" "$SYS" | tail -1 | sed 's/SP:PAINTED-//')
echo "pause open/close: $opens/$closes; SPIN-BREAK: $sb; CAUGHT: $caught; кадров всего: ${frames:-0}; key-маркер: строка ${lastkey_line:-нет}, последний PAINTED: ${lastpainted_line:-нет}"
[ $ok -eq 1 ] && echo "SPINPAUSE E2E: ALL CHECKS PASSED" || echo "SPINPAUSE E2E: FAILED"
exit $((1-ok))
