#!/bin/bash
# v36.61 [NO-DIRICON] автотест: в браузере НЕТ синих квадратов поверх папок.
# Жалоба: «поверх папок в списке файлов видны синие квадраты — возможно
# иконки папок, не нужны, убери». Корень: v36.58 рисовал контур значка-
# папки (5 fill_rect COL_ACCENT2 0xFF1B4FA8) в колонке x=40..80, но текст
# папок не сдвигался — контур ложился ПОВЕРХ имени «[папка]».
# Проверки:
#   1) браузер реально открыт (tag=browse-scan в log.txt) и не крашится;
#   2) ВО ВСЕХ дампах канвы 0 пикселей цвета (0x1B,0x4F,0xA8) — сам
#      значок исчез (цвет до фикса использовался ТОЛЬКО им);
#   3) positive-сигнал: строки списка с правой колонкой значений
#      («каталог»/«JAR») нарисованы — мы смотрим на живой браузер,
#      а не на пустой экран;
#   4) jar-иконки не задеты: в колонке иконок jar-строк ЛИБО пикселей
#      иконки, ЛИБО пусто (никаких синих заглушек).
# Негатив-контроль: на дереве ДО фикса (git worktree bfbc2e5) тест
# обязан ПАДАТЬ на проверке 2 — на каждой папке контур из ~5 линий.
set -e
cd "$(dirname "$0")/.." || exit 1
T=$(pwd)
BIN="$T/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (scripts/build_verify_host.sh)"; exit 1; }

D=/tmp/sw_nodiricon
rm -rf "$D"; mkdir -p "$D/dump"
W=$(mktemp -d "/tmp/nodiricon_run.XXXX")
mkdir -p "$W/sdmc:/switch/j2me/games/Ещё игры" \
         "$W/sdmc:/switch/j2me/games/saves_backup" \
         "$W/sdmc:/switch/j2me/games/zz_diricon_test" \
         "$W/sdmc:/switch/j2me/saves"
cp "$T/games/TestKeys.jar" "$W/sdmc:/switch/j2me/games/" 2>/dev/null || true

(
    cd "$W" || exit 1
    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
    export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
    export NOJME_UI_DUMP_DIR="$D/dump"
    export NOJME_UI_DUMP_MAX=60
    # меню (A = Открыть игру) -> браузер: 3 папки + jar, полоса выделения
    # на первой строке; DOWN x2 — выделение уходит с папки (в кадрах без
    # полосы синий виднее); 6 с дампов -> EXIT.
    export NOJME_SWITCH_KEYS="A:700,DOWN:400,DOWN:400,EXIT:6000"
    timeout -k 10 60 "$BIN" >/dev/null 2>&1 || true
)

LOG="$W/sdmc:/switch/j2me/log.txt"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }
N=$(ls "$D/dump"/ui_*.ppm 2>/dev/null | wc -l)
echo "dumps: $N  log: $(wc -l < "$LOG") строк"
[ "$N" -ge 2 ] || { echo "FAIL: мало дампов ($N)"; exit 1; }
grep -q "tag=browse-scan" "$LOG" || { echo "FAIL: браузер не открывался (нет browse-scan)"; exit 1; }
grep -qi "segfault\|SIGSEGV" "$LOG" && { echo "FAIL: краш"; exit 1; }

python3 scripts/test_switch_nodiricon_check.py "$D/dump" "$N"
