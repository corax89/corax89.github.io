#!/bin/bash
# Воспроизведение фриза Gravity Defied [240x320] на хостовой verify-сборке.
# NOJME_SWITCH_KEYS ведёт меню (браузер), NOJME_FRONT_KEYS — игровые кнопки
# (реальные SWJB-биты, [KEYIN] dispatch как на устройстве).
# Аргументы: $1 = суффикс прогона; RUN_SECONDS, NOJME_SPIN_BREAK_MS,
# NOJME_PAINT_LOCK_MS — снаружи.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/gd_repro_${1:-base}
rm -rf "$D"; mkdir -p "$D/roms"
cp "/home/z/my-project/gd/Gravity Defied[240x320].jar" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
# Меню: A (браузер), A (запуск jar)
export NOJME_SWITCH_KEYS="A:400,A:600"
# Игра (от старта процесса ~2с + GD-инициация/сплэши ~8с):
# A,A — пропуски сплэшей; A — выбор уровня/старт; далее газ/тормоз флипы.
RIDE="UP:1400,DOWN:500"
RIDE_REPEAT=12
FRONT="A:4500,A:3000,A:2600"
for i in $(seq $RIDE_REPEAT); do FRONT="$FRONT,$RIDE"; done
FRONT="$FRONT,UP:3000,DOWN:3000,UP:3000,DOWN:3000"
export NOJME_FRONT_KEYS="$FRONT"

RUN_SECONDS=${RUN_SECONDS:-110}
timeout -k 5 "$RUN_SECONDS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
rc=$?
echo "exit=$rc"
echo "===delivery==="
grep -aE "KEYIN.*dispatch|FRONTKEYS|autotest key" "$D/err.log" | head -50
echo "=== freeze signatures ==="
grep -an "SPIN-BREAK\|PAINT-BUDGET\|MON-WAIT\|MON-STEAL\|STUCK:\|SLOWLOGIC\|T-STALL\|MIDLET-STUCK\|THREAD-EXIT" "$D/err.log" | head -30
echo "=== session ==="
grep -an "game: begin\|game: session end\|Crashed\|session complete" "$D/err.log" | head -8
echo "=== лог: $D/err.log ==="
