#!/bin/bash
# v36.81 [SLOW-WEDGE]+[STAGE-SW] автотест: полная лестница лечения клина.
# (v36.82 [SW-ONLY]: стадия 2 больше не «уход на software» — рендерер
# ПОСТОЯННО программный; стадия 2 = полный ребилд рендерера и всех
# текстур software->software. Залипание render=software в pergame ini
# удалено вместе с настройкой «Рендер».)
# Сценарий (TTRepro.jar — клон архитектуры Treasure Towers, непрерывная
# анимация; фильтр scale2x, чтобы работал 2x-путь):
#   NOJME_WEDGE_SIM=2 — «отравлен» сайт s2x навсегда (аплоад 2x-текстуры
#   тихо пропускается с 100-го present) — точная имитация полевого
#   потекстурного клина: рект композита замер при живом источнике.
#   Ожидание (проба раз в 1 с, эскалация каждые 6 плохих проб):
#     [WEDGE] frozen... -> стадия 1 (текстуры; клин s2x не лечится)
#     -> ещё 6 с -> стадия 2 ПОЛНЫЙ РЕБИЛД (раньше — переход на software)
#     -> ещё 6 с -> стадия 3 байпас Scale2x -> выздоровление
#     -> "[WEDGE] picture resumed" + chg>=1 в поздних diag.
# Проверки:
#   1) лестница 1->2->3 в логе; стадия 2 = полный ребилд ([RND-SWITCH])
#   2) picture resumed после стадии 3; поздние diag: chg>=1
#   3) монотонность: стадия не откатывается при кратком оживании
#   4) [TEX] строка присутствует с live-адресами; 0 STUCK; rc по EXIT
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="$PWD/scripts/ttrepro/TTRepro.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/sw_wedgeladder
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/AAATTRepro.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=scale2x
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:600"
export NOJME_FRONT_KEYS="LEFTON:40000,LEFTOFF:800,MINUS:1500,DOWN:400,DOWN:400,DOWN:400,A:900"
export NOJME_WEDGE_SIM=2
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (сначала scripts/build_verify_host.sh)"; exit 1; }
( cd "$D" && timeout -k 10 70 "$BIN" > out.log 2> err.log )
rc=$?
echo "exit code: $rc (want 0)"
LOG="$D/sdmc:/switch/j2me/log.txt"
ok=1
[ "$rc" = "0" ] || { echo "FAIL: ненулевой rc"; ok=0; }

echo "--- лестница лечения:"
grep -E "scheduling recovery stage|WEDGE-RECOVER|picture resumed" "$LOG" 2>/dev/null | head -12

for st in 1 2 3; do
    grep -q "scheduling recovery stage $st" "$LOG" 2>/dev/null \
        || { ok=0; echo "FAIL: стадия $st не проведена"; }
done
# v36.82 [SW-ONLY]: стадия 2 — полный ребилд (режим один: программный)
grep -q "stage 2: full renderer+textures rebuild" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: стадия 2 не ребилд"; }
grep -qE "\[RND-SWITCH\].*wedge stage 2 \(full rebuild\)" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: [RND-SWITCH] стадии 2 нет"; }
# v36.82: пер-гейм render= больше не пишется — убедимся, что его НЕТ
if [ -f "$D/sdmc:/switch/j2me/pergame/AAATTRepro.jar.ini" ] && \
   grep -q "^render=" "$D/sdmc:/switch/j2me/pergame/AAATTRepro.jar.ini" 2>/dev/null; then
    ok=0; echo "FAIL: render= записан в pergame ini (ключ удалён в v36.82)"
fi
grep -q "picture resumed" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: выздоровления не было"; }
grep -q "stage 3: textures + Scale2x bypass" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: байпас стадии 3 не проведён"; }

# монотонность: после стадии N НЕ должно быть стадии < N (кроме повтора 4)
STAGES=$(grep -oE "scheduling recovery stage [0-9]" "$LOG" 2>/dev/null | awk '{print $4}' | tr '\n' ' ')
echo "последовательность стадий: $STAGES (want неубывающая)"
prev=0
for s in $STAGES; do
    if [ "$s" -lt "$prev" ]; then ok=0; echo "FAIL: лестница откатилась ($prev -> $s)"; fi
    prev=$s
done

# выздоровление видно в diag: последняя diag-строка сессии chg>=1
LASTCHG=$(awk '/^[0-9]+ diag:/ { if (match($0, /chg=[0-9]+ chb=/)) chg = substr($0, RSTART+4, RLENGTH-4); sub(/ chb.*/, "", chg); c = chg + 0 }
              /game: session end/ { print c + 0; exit }' "$LOG" 2>/dev/null)
echo "chg= последней diag до session end: $LASTCHG (want >=1)"
[ "$LASTCHG" -ge 1 ] || { ok=0; echo "FAIL: экран не ожил после лечения (chg=0)"; }

# [TEX] строка с live-адресами
grep -qE "\[TEX\] ui=1280x720 ptr=0x" "$LOG" 2>/dev/null \
    || { ok=0; echo "FAIL: [TEX] строка отсутствует"; }

STUCK=$(grep -ac "STUCK" "$LOG" 2>/dev/null || true)
[ "$STUCK" = "0" ] || { ok=0; echo "FAIL: STUCK-строки ($STUCK)"; }

if [ "$ok" = "1" ]; then echo "ALL PASSED"; else echo "FAILED"; exit 1; fi
