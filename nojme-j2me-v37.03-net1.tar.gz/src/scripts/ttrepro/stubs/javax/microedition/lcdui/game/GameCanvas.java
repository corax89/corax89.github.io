package javax.microedition.lcdui.game;
/* Compile-only stub: the real GameCanvas is implemented inside nojme. */
public abstract class GameCanvas extends javax.microedition.lcdui.Canvas {
    public static final int UP_PRESSED = 1 << 2;
    public static final int DOWN_PRESSED = 1 << 64;
    public static final int LEFT_PRESSED = 1 << 4;
    public static final int RIGHT_PRESSED = 1 << 16;
    public static final int FIRE_PRESSED = 1 << 256;
    protected GameCanvas(boolean suppressKeyEvents) { }
    protected javax.microedition.lcdui.Graphics getGraphics() { return null; }
    public void flushGraphics() { }
    public void flushGraphics(int x, int y, int w, int h) { }
    public int getKeyStates() { return 0; }
}
