#!/bin/bash
# test_wedge_guard.sh — v36.76 [WEDGE-GUARD]: детерминированная проверка
# детекции клина, эскалации лечения и выздоровления на хосте.
#   режим 1: клин «по указателям» → лечится стадией 1 (пересоздание текстур)
#   режим 2: клин «по месту» (2x-путь) → стадия 1 бессильна, лечит стадия 2
#             (байпас Scale2x — вывод 1x-текстурой)
# Ожидаемое в log.txt:
#   [WEDGE-SIM] активация → [WEDGE] frozen ... → [WEDGE] scheduling recovery
#   stage N → [WEDGE-RECOVER] stage N → (выздоровление) → [WEDGE] picture
#   resumed → diag chg=1 в поздних окнах.
set -u
cd "$(dirname "$0")/../.." || exit 1
JAR="$PWD/scripts/ttrepro/TTRepro.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }
MODE="${1:-1}"

D=/tmp/wedgeguard
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/AAATTRepro.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=$([ "$MODE" = "2" ] && echo scale2x || echo nearest)
audio=on
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:600,A:800"
# без удержаний: клин симулируется сам, ввод не нужен
export NOJME_FRONT_KEYS=""
export NOJME_WEDGE_SIM="$MODE"
( cd "$D" && timeout -k 10 75 "$BIN" > out.log 2> err.log ) || true
LOG="$D/sdmc:/switch/j2me/log.txt"
[ -s "$LOG" ] || { echo "FAIL: log.txt пуст/отсутствует"; exit 1; }

echo "== [WEDGE-SIM]/[WEDGE]/[WEDGE-RECOVER] =="
grep -E "WEDGE" "$LOG" | head -20
echo
echo "== chg по окнам (до/после лечения) =="
grep -oE "chg=[0-9]+ chb=[0-9]+" "$LOG" | head -14 | cat -n
echo
FAIL=0
grep -q "\[WEDGE\] #[0-9]* frozen" "$LOG" || { echo "FAIL: нет [WEDGE] frozen"; FAIL=1; }
grep -q "scheduling recovery stage" "$LOG" || { echo "FAIL: нет scheduling recovery"; FAIL=1; }
if [ "$MODE" = "1" ]; then
    grep -q "\[WEDGE-RECOVER\] stage 1" "$LOG" || { echo "FAIL(m1): нет stage 1"; FAIL=1; }
    # выздоровление: после stage 1 картинка должна ожить — поздние окна chg=1
    LATE=$(grep -oE "chg=[0-9]+ chb=[0-9]+" "$LOG" | tail -3 | grep -c "chg=1")
    [ "$LATE" -ge 2 ] || { echo "FAIL(m1): поздние окна без chg=1 (не выздоровело)"; FAIL=1; }
    grep -q "picture resumed" "$LOG" || { echo "FAIL(m1): нет picture resumed"; FAIL=1; }
else
    grep -q "\[WEDGE-RECOVER\] stage 1" "$LOG" || { echo "FAIL(m2): нет stage 1"; FAIL=1; }
    grep -q "\[WEDGE-RECOVER\] stage 2" "$LOG" || { echo "FAIL(m2): нет stage 2 (эскалация не работает)"; FAIL=1; }
    LATE=$(grep -oE "chg=[0-9]+ chb=[0-9]+" "$LOG" | tail -3 | grep -c "chg=1")
    [ "$LATE" -ge 2 ] || { echo "FAIL(m2): поздние окна без chg=1 (байпас не оживил)"; FAIL=1; }
fi
# никаких сбоев подачи
grep -q "PRESENT-FAIL" "$LOG" && { echo "FAIL: PRESENT-FAIL при симуляции (не должно расти utf)"; FAIL=1; }
echo
if [ "$FAIL" = "0" ]; then echo "WEDGE-GUARD MODE $MODE: ALL PASSED"; else echo "WEDGE-GUARD MODE $MODE: FAILED"; exit 1; fi
