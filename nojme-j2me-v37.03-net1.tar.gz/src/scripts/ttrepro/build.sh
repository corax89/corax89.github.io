#!/bin/bash
# Build TTRepro.jar — синтетический клон архитектуры Treasure Towers
# (GameCanvas + t2-рендер-поток + flushGraphics + пустой paint).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
ECJ="$SRC/scripts/ecj.jar"
STUBS="$D/stubs"
KEYSTUBS="$SRC/scripts/keysjar/stubs"
OUT="$D/out"
[ -f "$ECJ" ] || { echo "ecj.jar not found"; exit 1; }
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/TTRepro.java" \
    "$STUBS/javax/microedition/lcdui/game/"*.java \
    "$KEYSTUBS/javax/microedition/midlet/"*.java \
    "$KEYSTUBS/javax/microedition/lcdui/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TT, , TTRepro\r\nMIDlet-Name: TTRepro\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TTRepro*.class "$PKG/"
cp "$OUT"/TTCv*.class "$PKG/" 2>/dev/null || true
( cd "$PKG" && zip -q -r "$D/TTRepro.jar" META-INF && zip -q "$D/TTRepro.jar" *.class )
echo "built: $D/TTRepro.jar ($(stat -c%s "$D/TTRepro.jar") bytes)"
