#!/bin/bash
# TT-FREEZE repro: синтетический TTRepro.jar (архитектура Treasure Towers)
# + удержания ВЛЕВО из поля — ловим «chg=0 при fl/lvc/swh>0»
# (замершая картинка в игровом ректе при живом конвейере).
# Дампы: game_*.ppm (канва игры) + comp_*.ppm (итоговый композит) 1/с.
set -u
cd "$(dirname "$0")/../.." || exit 1
JAR="$PWD/scripts/ttrepro/TTRepro.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/ttfreeze
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame" \
         "$D/gamedump" "$D/compdump"
cp "$JAR" "$D/sdmc:/switch/j2me/games/AAATTRepro.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=on
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_TD_DEEP=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
# меню: открыть браузер + запустить первую (единственную) игру
export NOJME_SWITCH_KEYS="A:600,A:800"
# полевой паттерн: игра идёт, затем ДОЛГОЕ удержание ВЛЕВО (btn=12!),
# отпускание, тапы ВВЕРХ, снова удержание... (KEYON/KEYOFF = зажатая кнопка)
export NOJME_FRONT_KEYS="LEFTON:9000,LEFTOFF:9000,UP:500,UP:600,UP:600,LEFTON:4000,LEFTOFF:9000,UP:500,UP:600,LEFTON:6000,LEFTOFF:9000,UP:500,UP:600,LEFTON:5000,LEFTOFF:9000"
export NOJME_GAME_DUMP_DIR="$D/gamedump"
export NOJME_GAME_DUMP_MAX=120
export NOJME_COMPOSITE_DUMP_DIR="$D/compdump"
export NOJME_COMPOSITE_DUMP_MAX=120
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }
( cd "$D" && timeout -k 10 100 "$BIN" > out.log 2> err.log ) || true
LOG="$D/sdmc:/switch/j2me/log.txt"
echo "== диаграмма: chg/chb/fl/lvc/swh по окнам =="
grep -oE "^[0-9]+ diag:.*chg=[0-9]+ chb=[0-9]+" "$LOG" 2>/dev/null | \
  sed -E 's/^([0-9]+) diag:.* fl=([0-9]+).* lvc=([0-9]+).*swh=([0-9]+).*chg=([0-9]+) chb=([0-9]+)/t=\1 fl=\2 lvc=\3 swh=\4 CHG=\5 chb=\6/' || true
grep -E "diag:" "$LOG" 2>/dev/null | head -20
echo "== SYSOUT (что печатает репро) =="
grep -E "SYSOUT" "$LOG" 2>/dev/null | head -10
echo "== PRESENT-FAIL / PRESENT-SLOW / SPIN-BREAK =="
grep -E "PRESENT-FAIL|PRESENT-SLOW|SPIN-BREAK" "$LOG" 2>/dev/null | head -10
echo "== дампы: gamedump=$(ls "$D/gamedump" 2>/dev/null | wc -l) compdump=$(ls "$D/compdump" 2>/dev/null | wc -l) =="
echo "== err.log tail =="
tail -3 "$D/err.log" 2>/dev/null
