/* TTRepro — синтетический клон архитектуры Treasure Towers для поимки
 * полевого фриза v36.74/v36.75 «картинка замерла при живой игре»
 * (chg=0 при fl/lvc/swh>0, onset при удержании ВЛЕВО).
 *
 * Архитектура — ровно как в полевом логе TT:
 *   - поток 1 (AMS/m): startApp создаёт канву, стартует поток 2 и
 *     УХОДИТ В БЕСКОНЕЧНЫЙ IDLE (println-призрак: ни одного натива
 *     после старта — как td m age=17-42 с в поле);
 *   - поток 2 (t2): игровой цикл — поллинг getKeyStates(), шаг мира,
 *     полноэкранный рендер в offscreen канвы, flushGraphics(),
 *     Thread.sleep(20) — td t2 показывал sleep/renderFigure;
 *   - paint() ПУСТОЙ (MWIN #5: javax/microedition/lcdui/gam.paint len=1);
 *   - keyPressed/keyReleased/keyRepeated с РЕАЛЬНЫМИ телами
 *     (len 46-475 у TT; b.keyPressed(-2) исполнялся на m).
 *
 * Поведение: удержание ВЛЕВО (getKeyStates & LEFT или флаг из keyPressed)
 * панорамирует камеру — КАЖДЫЙ кадр меняется ВСЯ канва; тапы ВВЕРХ
 * двигают героя. HUD-полоска сверху меняется каждый кадр даже без ввода.
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

public class TTRepro extends MIDlet {
    public static TTCv cv;

    public void startApp() {
        System.out.println("TTREPRO startApp");
        cv = new TTCv();
        Display.getDisplay(this).setCurrent(cv);
        Thread t2 = new Thread(cv);
        t2.start();
        /* Как TT: главный поток после startApp в чисто-Java idle —
         * ни keyPressed-нативов, ни сна: age растёт (призрак v36.75). */
        Object lock = new Object();
        while (!cv.stop) {
            /* чисто-Java ожидание (без wait/sleep — без нативов) */
            for (int i = 0; i < 100000 && !cv.stop; i++) { }
        }
        System.out.println("TTREPRO main loop end");
    }

    public void pauseApp() { }
    public void destroyApp(boolean u) { if (cv != null) cv.stop = true; }
}

class TTCv extends GameCanvas implements Runnable {
    volatile boolean stop;
    volatile int evHeld;      /* флаги из keyPressed/keyReleased (как у TT) */
    int camX;                /* камера: удержание ВЛЕВО двигает её */
    int heroY;
    int frame;

    TTCv() {
        super(false);        /* key events НЕ подавлены — как у TT */
        setFullScreenMode(true);
    }

    public void run() {
        System.out.println("TTREPRO t2 begin");
        while (!stop) {
            frame++;
            /* 1) поллинг состояния клавиш (нативgetKeyStates — как t2 TT) */
            int ks = getKeyStates();
            /* 2) шаг мира: удержание ВЛЕВО — панорама (полный кадр меняется) */
            if ((ks & LEFT_PRESSED) != 0 || (evHeld & 1) != 0) camX += 4;
            if ((ks & UP_PRESSED) != 0 || (evHeld & 2) != 0) heroY = (heroY + 6) % 280;
            /* 3) полноэкранный рендер в offscreen канвы */
            Graphics g = getGraphics();
            if (g != null) render(g);
            /* 4) кадр готов — блит на экран + сеттл (путь flushGraphics) */
            flushGraphics();
            /* 5) темп как у t2 TT */
            try { Thread.sleep(20); } catch (InterruptedException e) { break; }
        }
        System.out.println("TTREPRO t2 end frames=" + frame);
    }

    private void render(Graphics g) {
        /* фон: 14 вертикальных полос, сдвигаемых камерой и кадром —
         * при живом мире меняется ВЕСЬ кадр (проверка chg) */
        for (int i = 0; i < 14; i++) {
            int x = ((i * 34 + camX * 5 + frame * 2) % 280) - 20;
            g.setColor((i * 18 + frame) & 0xff, (camX + i * 11) & 0xff,
                       (frame * 5 + i * 3) & 0xff);
            g.fillRect(x, 0, 24, 320);
        }
        /* герой */
        g.setColor(255, 255, 60);
        g.fillRect(108, 24 + heroY, 24, 24);
        /* HUD-полоска сверху: меняется каждый кадр даже без ввода —
         * трипгер swh при замершем мире (как в поле) */
        g.setColor(frame & 0xff, 0, 0);
        g.fillRect(0, 0, 46, 8);
    }

    public void paint(Graphics g) { /* ПУСТО — как TT len=1 */ }

    public void keyPressed(int k) {
        if (k == -3) evHeld |= 1;
        else if (k == -1) evHeld |= 2;
        else if (k == -5 || k == 53) evHeld |= 4;
    }
    public void keyReleased(int k) {
        if (k == -3) evHeld &= ~1;
        else if (k == -1) evHeld &= ~2;
        else if (k == -5 || k == 53) evHeld &= ~4;
    }
    public void keyRepeated(int k) { /* тело как у TT len=46: просто живой вызов */ }
}
