#!/bin/bash
# BT-STALL + gdb: берём все backtrace'ы в момент зависания m.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="games/Bounce Tales (240x320).jar"
D=/tmp/tbtgdb
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/bt.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
export NOJME_SWITCH_KEYS="A:3000"
BIN="$PWD/bin/switchui-verify"
( cd "$D" && "$BIN" > out.log 2> err.log ) &
MAINPID=$!
sleep 30
echo "== process tree =="
ps -eLf | grep -E "switchui-verify" | grep -v grep
echo "== gdb attach =="
gdb -p $MAINPID -batch \
  -ex "set pagination off" \
  -ex "thread apply all bt" 2>/dev/null | grep -vE "^\[|^\s*$|Reading symbols|done\.$|Downloading|attaching" | head -150
kill $MAINPID 2>/dev/null; sleep 1; kill -9 $MAINPID 2>/dev/null
