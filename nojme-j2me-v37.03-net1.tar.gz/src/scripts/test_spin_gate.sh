#!/bin/bash
# v36.88 [SPIN-BREAK-ICOUNT] e2e: SpinGateTest.jar на switchui-verify.
# Три прогона с NOJME_SPIN_BREAK_MS=1 (порог возраста 1 мс — «высокий
# возраст при малой работе» достигается коротким чисто-Java участком,
# ровно как после сна консоли по HOME):
#
#  ПРОГОН 1 (гейт ВКЛ, порог 1000000 команд — выше работы фазы A ~380k;
#   дефолт 200k упражняется регрессионным test_spinbreak при дефолтном
#   NOJME_SPIN_BREAK_MS=1500 — на скорости хоста-verify ~200M команд/с
#   фаза A перешла бы дефолтный порог быстрее, чем пересечёт 1 мс возраста):
#   - SG:A-OK: короткий участок (фаза A, ~380k команд) НЕ расстрелян —
#     гейт подавил ложный выстрел ([SPIN-GATE] в логе);
#   - SG:B-CAUGHT: настоящий спин (фаза B, миллионы команд) ПЕРЕСЁК порог
#     и расстрелян ПО МЕСТУ (сайт phaseB_spin);
#   - НИ ОДНОГО [SPIN-BREAK] с сайтом phaseA.
#  ПРОГОН 2 (NOJME_SPIN_BREAK_INSTR=0 — гейт выкл, поведение v36.87):
#   - SG:A-CAUGHT >= 1: тот же короткий участок расстрелян — негатив-
#     контроль, детектор доказанно ловит класс бага «возраст без работы»;
#   - >= 1 [SPIN-BREAK] с сайтом phaseA;
#   - НОЛЬ строк [SPIN-GATE].
#  ПРОГОН 3 (NOJME_SPIN_BREAK_INSTR=200000000 — гигантский порог):
#   - НИ ОДНОГО [SPIN-BREAK] за весь прогон (спин фазы B задавлен порогом
#     всё время прогона) — ручка порога читается и применяется;
#   - SG:A-OK.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tsg
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/spingate/SpinGateTest.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SPIN_BREAK_MS=1

run_case() { # $1=name $2=EXIT-ms $3=INSTR-env(опц.)
    rm -rf "$D/$1"; mkdir -p "$D/$1"
    export NOJME_SWITCH_UI_DIR="$D/$1"
    if [ -n "${3:-}" ]; then export NOJME_SPIN_BREAK_INSTR="$3"; else unset NOJME_SPIN_BREAK_INSTR; fi
    export NOJME_SWITCH_KEYS="A:400,A:600,EXIT:$2"
    timeout -k 5 60 ./bin/switchui-verify > "$D/$1/out.log" 2> "$D/$1/err.log" || true
    LOG="$D/$1/sdmc:/switch/j2me/log.txt"
    [ -s "$LOG" ] || LOG="$D/$1/log.txt"
    SYS="$D/$1/err.log"
}

ok=1
count() { local n; n=$(grep -ac -- "$1" "$2" 2>/dev/null | head -n1); echo "${n:-0}"; }

echo "== ПРОГОН 1: гейт ВКЛ (INSTR=1000000) =="
run_case r1 8000 1000000
aok=$(count "SG:A-OK" "$SYS"); acaught=$(count "SG:A-CAUGHT" "$SYS")
bcaught=$(count "SG:B-CAUGHT" "$SYS")
sbA=$(( $(grep -ac "SPIN-BREAK\]" "$SYS" "$LOG" 2>/dev/null | awk -F: '{s+=$NF} END{print s+0}') ))
sbA_site=$(( $(grep -ahc "SPIN-BREAK\].*phaseA" "$SYS" "$LOG" 2>/dev/null | awk '{s+=$1} END{print s+0}') ))
gate=$(( $(grep -ahc "SPIN-GATE\]" "$SYS" "$LOG" 2>/dev/null | awk '{s+=$1} END{print s+0}') ))
[ "$aok" -ge 1 ] 2>/dev/null || { echo "FAIL: нет SG:A-OK (aok=$aok) — короткий участок расстрелян или не дошёл"; ok=0; }
[ "$acaught" -eq 0 ] 2>/dev/null || { echo "FAIL: SG:A-CAUGHT x$acaught — гейт не подавил ложный выстрел"; ok=0; }
[ "$bcaught" -ge 1 ] 2>/dev/null || { echo "FAIL: нет SG:B-CAUGHT (bcaught=$bcaught) — реальный спин не пробил гейт"; ok=0; }
[ "$sbA_site" -eq 0 ] 2>/dev/null || { echo "FAIL: [SPIN-BREAK] с сайтом phaseA x$sbA_site"; ok=0; }
[ "$gate" -ge 1 ] 2>/dev/null || { echo "FAIL: нет [SPIN-GATE] — гейт не сработал ни разу (проверить фикс)"; ok=0; }
echo "   A-OK=$aok A-CAUGHT=$acaught B-CAUGHT=$bcaught SPIN-BREAK(phaseA)=$sbA_site SPIN-GATE=$gate"
[ "$ok" -eq 1 ] && echo "   прогон 1: OK" || true

echo "== ПРОГОН 2: гейт ВЫКЛ (INSTR=0, поведение v36.87) — негатив-контроль =="
run_case r2 8000 0
acaught=$(count "SG:A-CAUGHT" "$SYS")
sbA_site=$(( $(grep -ahc "SPIN-BREAK\].*phaseA" "$SYS" "$LOG" 2>/dev/null | awk '{s+=$1} END{print s+0}') ))
gate=$(( $(grep -ahc "SPIN-GATE\]" "$SYS" "$LOG" 2>/dev/null | awk '{s+=$1} END{print s+0}') ))
[ "$acaught" -ge 1 ] 2>/dev/null || { echo "FAIL: нет SG:A-CAUGHT (acaught=$acaught) — негатив-контроль не воспроизвёл баг v36.87 (порог MS=1 не пересечён? проверить участок A)"; ok=0; }
[ "$sbA_site" -ge 1 ] 2>/dev/null || { echo "FAIL: нет [SPIN-BREAK] с сайтом phaseA (sbA_site=$sbA_site)"; ok=0; }
[ "$gate" -eq 0 ] 2>/dev/null || { echo "FAIL: [SPIN-GATE] x$gate при INSTR=0 — ручка выключения не работает"; ok=0; }
echo "   A-CAUGHT=$acaught SPIN-BREAK(phaseA)=$sbA_site SPIN-GATE=$gate"
[ "$ok" -eq 1 ] && echo "   прогон 2: OK (негатив ловится)" || true

echo "== ПРОГОН 3: порог 200000000 (задавить даже фазу B) =="
run_case r3 12000 200000000
sb=$(( $(grep -ahc "SPIN-BREAK\]" "$SYS" "$LOG" 2>/dev/null | awk '{s+=$1} END{print s+0}') ))
aok=$(count "SG:A-OK" "$SYS")
anycaught=$(count "SG:.-CAUGHT" "$SYS")
[ "$sb" -eq 0 ] 2>/dev/null || { echo "FAIL: [SPIN-BREAK] x$sb при пороге 200M — ручка не применяется"; ok=0; }
[ "$aok" -ge 1 ] 2>/dev/null || { echo "FAIL: нет SG:A-OK в прогоне 3"; ok=0; }
[ "$anycaught" -eq 0 ] 2>/dev/null || { echo "FAIL: перехваченные выстрелы x$anycaught при пороге 200M"; ok=0; }
echo "   SPIN-BREAK=$sb A-OK=$aok CAUGHT=$anycaught"
[ "$ok" -eq 1 ] && echo "   прогон 3: OK" || true

if [ "$ok" -eq 1 ]; then
    echo "SPINGATE: ALL PASSED"
else
    echo "SPINGATE: FAILED"
    exit 1
fi
