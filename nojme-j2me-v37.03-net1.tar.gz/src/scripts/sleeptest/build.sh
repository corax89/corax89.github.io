#!/bin/bash
# Build SleepTest.jar — v36.74 sleep-timing/skipBytes selftest.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="$D/../ecj.jar"
STUBS="$D/../keysjar/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/SleepTest.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: ST, , SleepTest\r\nMIDlet-Name: SleepTest\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/SleepTest*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/SleepTest.jar" META-INF && zip -q "$D/SleepTest.jar" *.class )
echo "built: $D/SleepTest.jar"
