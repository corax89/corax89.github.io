public class SleepTest extends javax.microedition.midlet.MIDlet {
    public void startApp() {
        System.out.println("SLEEP-TEST begin");
        /* 1) sleep(1) x100 — должно быть ~100-300 мс */
        long t0 = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            try { Thread.sleep(1); } catch (InterruptedException e) { break; }
        }
        long d1 = System.currentTimeMillis() - t0;
        System.out.println("SLEEP 100x sleep(1) = " + d1 + " ms");

        /* 2) sleep(10) x20 — должно быть ~200-400 мс */
        t0 = System.currentTimeMillis();
        for (int i = 0; i < 20; i++) {
            try { Thread.sleep(10); } catch (InterruptedException e) { break; }
        }
        System.out.println("SLEEP 20x sleep(10) = " + (System.currentTimeMillis() - t0) + " ms");

        /* 3) skipBytes точность: BAIS 1000 байт, скип 300, должно вернуть 300 */
        try {
            byte[] buf = new byte[1000];
            for (int i = 0; i < 1000; i++) buf[i] = (byte) i;
            java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(buf);
            java.io.DataInputStream dis = new java.io.DataInputStream(bais);
            int n1 = dis.skipBytes(300);
            int b = dis.readByte();
            java.io.ByteArrayInputStream bais2 = new java.io.ByteArrayInputStream(buf);
            java.io.DataInputStream dis2 = new java.io.DataInputStream(bais2);
            int n2 = dis2.skipBytes(500);
            int rd = dis2.readByte();
            System.out.println("SKIP n1=" + n1 + " next=" + b + " byte300="
                + ((byte) 300) + " seek500=" + n2 + " rd=" + rd);
        } catch (Exception e) {
            System.out.println("SKIP EX: " + e);
        }
        System.out.println("SLEEP-TEST end");
        notifyDestroyed();
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
