#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Пиксельные проверки CovStageTest (test_m3g_covstage.sh), BMP-дампы
releaseTarget (M3G_CAPTURE) — точная канва 240x320, без масштабирования.

Нумерация дампов = счётчик releaseTarget (+возможный сдвиг ~6 системных
пейнтов до цикла мидлета — как в BindStageTest 1206/1200), поэтому
проверяем ОКНА дампов, целиком лежащие внутри фаз.

mode=default (v36.55 семантика, дефолт):
  A) окно 15..45 (фаза 1): каждый дамп ЦЕЛИКОМ 0x203040 — непрозрачный
     fillRect-фон сеется и переживает bind (класс v25);
  B) окно 100..160 (фаза 2): белый блок (140..204, 40..104) = белый
     (kept), красный регион (40..104, 40..104) = ЧЁРНЫЙ (не сеется —
     полупрозрачный оверлей базу не детерминирует), вне блоков чёрный;
  C) окно 215..245 (фаза 3): каждый дамп ЦЕЛИКОМ чёрный — полная свежая
     очистка (финальный framebuffer 0/76800).

mode=ab_opaque (NOJME_M3G_COV_OPAQUE=0 — прямоугольная отметка v36.54):
  B2) окно 100..160: красный регион НЕ чёрный (сеется вчерашним красным,
      ползучесть яркости — сигнатура ореолов v36.54, ловится тестом).
"""
import glob
import os
import sys

from PIL import Image

BG = (0x20, 0x30, 0x40)
TOL = 2


def near(p, ref, tol=TOL):
    return all(abs(p[i] - ref[i]) <= tol for i in range(3))


def load(n):
    return Image.open("/home/z/my-project/download/m3g_rt_%05d.bmp" % n).convert("RGB")


def all_is(n, ref):
    im = load(n)
    if im.size != (240, 320):
        print("FAIL: дамп #%d размер %s (ожидался 240x320)" % (n, im.size))
        return False
    px = im.load()
    for y in range(0, 320, 3):
        for x in range(0, 240, 3):
            if not near(px[x, y], ref):
                print("FAIL: дамп #%d: (%d,%d)=%s != %s" % (n, x, y, px[x, y], ref))
                return False
    return True


def block_stat(n, box):
    im = load(n)
    px = im.load()
    x0, y0, x1, y1 = box
    rs, ns = 0, 0
    black = 0
    for y in range(y0, y1, 4):
        for x in range(x0, x1, 4):
            p = px[x, y]
            rs += p[0]
            ns += 1
            if near(p, (0, 0, 0)):
                black += 1
    return (rs // ns if ns else 0), (black * 100 // ns if ns else 0)


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "default"
    files = glob.glob("/home/z/my-project/download/m3g_rt_*.bmp")
    if len(files) < 220:
        print("FAIL: мало дампов (%d)" % len(files))
        return 1

    if mode == "default":
        okA = all(all_is(n, BG) for n in range(15, 46, 5))
        print("A) фаза 1 фон 0x203040 (окно 15..45): %s" % ("ok" if okA else "FAIL"))
        okB = True
        for n in range(100, 161, 10):
            wm, wb = block_stat(n, (140, 40, 204, 104))
            rm, rb = block_stat(n, (40, 40, 104, 104))
            om, ob = block_stat(n, (10, 200, 230, 300))
            if not (wm >= 253 and wb <= 1 and rm <= 2 and rb >= 99 and om <= 2 and ob >= 99):
                print("FAIL: дамп #%d: white(mean=%d,%%blk=%d) red(mean=%d,%%blk=%d) outside(mean=%d,%%blk=%d)"
                      % (n, wm, wb, rm, rb, om, ob))
                okB = False
        print("B) фаза 2: белый kept, красный регион ЧЁРНЫЙ (не сеется), фон чёрный: %s"
              % ("ok" if okB else "FAIL"))
        okC = all(all_is(n, (0, 0, 0)) for n in range(215, 246, 5))
        print("C) фаза 3 целиком чёрная (окно 215..245): %s" % ("ok" if okC else "FAIL"))
        if not (okA and okB and okC):
            return 1
    elif mode == "ab_opaque":
        ok = True
        for n in range(100, 161, 10):
            rm, rb = block_stat(n, (40, 40, 104, 104))
            if rm < 50 or rb > 50:
                print("FAIL: дамп #%d: красный регион mean=%d %%blk=%d (ожидание: яркий НЕ-чёрный — v36.54-сеяние)"
                      % (n, rm, rb))
                ok = False
        print("B2) A/B COV_OPAQUE=0: красный регион сеется (ползучесть): %s" % ("ok" if ok else "FAIL"))
        if not ok:
            return 1
    else:
        print("FAIL: неизвестный режим %s" % mode)
        return 1

    print("COVSTAGE PIXEL CHECKS (%s): ALL PASSED" % mode)
    return 0


if __name__ == "__main__":
    sys.exit(main())
