#!/bin/bash
# v36.99 [PSC-TURBO-SMALL] e2e: TestPsSleep.jar на switchui-verify.
# paint() содержит мелкие сны (3/5/7 мс). В турбо (дефолт) они должны
# укорачиваться до 1 мс (diag pss= > 0), paint проходит без исключений.
# Второй прогон — NOJME_PAINT_SLEEP_TURBO_SMALL=0: кламп выключен,
# pss= должен быть 0 (проверка рубильника).
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/tpss
run_pass() {
    local pass="$1"
    rm -rf "$D"; mkdir -p "$D/roms"
    cp scripts/pssleep/TestPsSleep.jar "$D/roms/"
    export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
    export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
    export NOJME_LOG=1 NOJME_LOGGING=1
    export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
    export NOJME_SWITCH_AUTOTEST_SESSIONS=1
    export NOJME_SWITCH_KEYS="A:400,A:800,EXIT:22000"
    if [ "$pass" = "off" ]; then
        export NOJME_PAINT_SLEEP_TURBO_SMALL=0
    else
        unset NOJME_PAINT_SLEEP_TURBO_SMALL
    fi
    timeout -k 5 35 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

    local painted=$(grep -ac "PSS:PAINTED-" "$D/err.log")
    local stuck=$(grep -ac "STUCK:" "$D/err.log")
    local pss=$(grep -ao "pss=[0-9]*" "$D/err.log" | cut -d= -f2 | awk '{s+=$1} END{print s+0}')
    echo "[$pass] painted=$painted stuck=$stuck pss_sum=$pss"
    if [ "$painted" -lt 2 ]; then echo "[$pass] FAIL: мало PAINTED"; return 1; fi
    if [ "$stuck" -ne 0 ]; then echo "[$pass] FAIL: STUCK есть"; return 1; fi
    if [ "$pass" = "on" ] && [ "$pss" -lt 1 ]; then echo "[$pass] FAIL: pss=0 (кламп не сработал)"; return 1; fi
    if [ "$pass" = "off" ] && [ "$pss" -ne 0 ]; then echo "[$pass] FAIL: pss!=0 при выключенном клампе"; return 1; fi
    echo "[$pass] PSSLEEP E2E: PASSED"
    return 0
}

ok=1
run_pass on  || ok=0
run_pass off || ok=0
[ $ok -eq 1 ] && echo "PSSLEEP E2E: ALL CHECKS PASSED" || echo "PSSLEEP E2E: FAILED"
exit $((1-ok))
