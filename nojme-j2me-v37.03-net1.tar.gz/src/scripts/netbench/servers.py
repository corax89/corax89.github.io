#!/usr/bin/env python3
"""v37.03 [NET]: локальные серверы для scripts/netbench/test_netbench.sh.
HTTP (GET /hello, POST /echo, GET /chunked, 404) + TCP-эхо.
Порты выбираются свободными и печатаются в stdout: 'HTTP <p> TCP <p> UDP <p>'.
UDP не нужен отдельным сервером — мидлет шлёт сам себе."""
import socket, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _send(self, code, body, hdrs=None, chunked=False):
        self.send_response(code)
        if chunked:
            self.send_header("Transfer-Encoding", "chunked")
        else:
            self.send_header("Content-Length", str(len(body)))
        for k, v in (hdrs or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if chunked:
            for part in (body[:9], body[9:]):
                if part:
                    self.wfile.write(b"%x\r\n%s\r\n" % (len(part), part.encode()))
            self.wfile.write(b"0\r\n\r\n")
        else:
            self.wfile.write(body.encode() if isinstance(body, str) else body)
    def do_GET(self):
        if self.path == "/hello":
            self._send(200, "HELLO-NOJME", {
                "Content-Type": "text/plain",
                "X-Echo": self.headers.get("X-Test", ""),
            })
        elif self.path == "/chunked":
            self._send(200, "CHUNKED-OK-1234567890", chunked=True)
        else:
            self._send(404, "no such page")
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(n).decode("utf-8", "replace")
        self._send(200, body, {"Content-Type": "text/plain"})

def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p

http_p, tcp_p, udp_p = free_port(), free_port(), free_port()
http = ThreadingHTTPServer(("127.0.0.1", http_p), H)

tcp = socket.socket()
tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
tcp.bind(("127.0.0.1", tcp_p))
tcp.listen(4)
def tcp_loop():
    while True:
        try:
            c, _ = tcp.accept()
        except OSError:
            return
        def one(c):
            try:
                while True:
                    d = c.recv(4096)
                    if not d: break
                    c.sendall(d)
            except OSError:
                pass
            finally:
                c.close()
        threading.Thread(target=one, args=(c,), daemon=True).start()
threading.Thread(target=tcp_loop, daemon=True).start()

print("HTTP %d TCP %d UDP %d" % (http_p, tcp_p, udp_p), flush=True)
sys.stdout.flush()
http.serve_forever()
