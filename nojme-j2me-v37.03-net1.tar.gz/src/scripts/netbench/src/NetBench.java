import javax.microedition.midlet.MIDlet;
import javax.microedition.io.*;
import javax.wireless.messaging.*;
import java.io.*;
/* v37.03 [NET]: функциональный тест GCF-сети nojme (net.c).
 * Проверяет против ЛОКАЛЬНЫХ python-серверов (servers.py):
 *   T1 http GET      — статус, тело, заголовки (X-Echo), getLength/getType
 *   T2 http POST     — тело запроса, эхо-ответ, getRequestMethod
 *   T3 http chunked  — Transfer-Encoding: chunked (де-chunker)
 *   T4 http 404      — код ошибки + статус-сообщение
 *   T5 socket        — эхо-раундтрип, опции, адреса/порты
 *   T6 serversocket  — acceptAndOpen из другого потока + эхо
 *   T7 udp           — send/receive датаграмм, адрес отправителя
 *   T8 WMA           — newMessage(text)/send/numberOfSegments
 *   T9 openDataInputStream — статик-хелпер Connector + DataInputStream
 *   T10 ошибки       — connect refused → IOException; comm:// →
 *                      ConnectionNotFoundException; https → IOException
 * Порт читается из JAD/манифеста (TestHttpPort/TestTcpPort/TestUdpPort),
 * чтобы тест не зависел от занятых фиксированных портов.
 * Итог: строки "NET Tn=PASS/FAIL ..." + "NETBENCH PASS x/y". */
public class NetBench extends MIDlet {
    int pass = 0, total = 0;
    StringBuffer sb = new StringBuffer();

    void report(String id, boolean ok, String note) {
        total++;
        if (ok) pass++;
        String line = "NET " + id + "=" + (ok ? "PASS" : "FAIL") +
                      (note != null ? " " + note : "");
        System.out.println(line);
        sb.append(line).append('\n');
    }

    String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[512];
        int n;
        while ((n = is.read(buf)) >= 0) bos.write(buf, 0, n);
        return new String(bos.toByteArray());
    }

    /* Datagram-хелперы (J2ME Datagram — только setData/getData/setLength) */
    static void setPayload(Datagram dg, String s) throws IOException {
        byte[] b = s.getBytes();
        dg.setData(b);
        dg.setLength(b.length);
    }
    static String getPayload(Datagram dg) {
        byte[] b = dg.getData();
        int n = dg.getLength();
        return new String(b, 0, n);
    }

    public void startApp() {
        String hp = getAppProperty("TestHttpPort");
        String tp = getAppProperty("TestTcpPort");
        String up = getAppProperty("TestUdpPort");
        int httpPort = Integer.parseInt(hp == null ? "18081" : hp);
        int tcpPort  = Integer.parseInt(tp == null ? "18082" : tp);
        int udpPort  = Integer.parseInt(up == null ? "18083" : up);

        /* ---- T1: HTTP GET ---- */
        try {
            HttpConnection c = (HttpConnection)
                Connector.open("http://127.0.0.1:" + httpPort + "/hello");
            c.setRequestMethod("GET");
            c.setRequestProperty("X-Test", "nojme");
            int rc = c.getResponseCode();
            String ct = c.getType();
            long len = c.getLength();
            String echo = c.getHeaderField("X-Echo");
            String body = readAll(c.openInputStream());
            boolean ok = rc == 200 &&
                "HELLO-NOJME".equals(body) &&
                ct != null && ct.indexOf("text/plain") >= 0 &&
                len == 11 && "nojme".equals(echo);
            report("T1", ok, "rc=" + rc + " len=" + len + " ct=" + ct +
                          " echo=" + echo + " body=" + body);
            c.close();
        } catch (Exception e) {
            report("T1", false, "EX " + e);
        }

        /* ---- T2: HTTP POST ---- */
        try {
            HttpConnection c = (HttpConnection)
                Connector.open("http://127.0.0.1:" + httpPort + "/echo");
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "text/plain");
            OutputStream os = c.openOutputStream();
            byte[] payload = "PING-BODY-42".getBytes();
            os.write(payload);
            os.close(); /* спека: закрытие выхода отправляет запрос */
            int rc = c.getResponseCode();
            String body = readAll(c.openInputStream());
            boolean ok = rc == 200 && "PING-BODY-42".equals(body) &&
                "POST".equals(c.getRequestMethod());
            report("T2", ok, "rc=" + rc + " body=" + body);
            c.close();
        } catch (Exception e) {
            report("T2", false, "EX " + e);
        }

        /* ---- T3: chunked ---- */
        try {
            HttpConnection c = (HttpConnection)
                Connector.open("http://127.0.0.1:" + httpPort + "/chunked");
            int rc = c.getResponseCode();
            String body = readAll(c.openInputStream());
            report("T3", rc == 200 && "CHUNKED-OK-1234567890".equals(body),
                   "rc=" + rc + " body=" + body);
            c.close();
        } catch (Exception e) {
            report("T3", false, "EX " + e);
        }

        /* ---- T4: 404 ---- */
        try {
            HttpConnection c = (HttpConnection)
                Connector.open("http://127.0.0.1:" + httpPort + "/missing");
            int rc = c.getResponseCode();
            String msg = c.getResponseMessage();
            report("T4", rc == 404 && msg != null && msg.indexOf("Not Found") >= 0,
                   "rc=" + rc + " msg=" + msg);
            c.close();
        } catch (Exception e) {
            report("T4", false, "EX " + e);
        }

        /* ---- T5: socket эхо ---- */
        try {
            SocketConnection sc = (SocketConnection)
                Connector.open("socket://127.0.0.1:" + tcpPort);
            sc.setSocketOption(SocketConnection.DELAY, 1);
            String addr = sc.getAddress();
            int port = sc.getPort();
            int lport = sc.getLocalPort();
            String laddr = sc.getLocalAddress();
            OutputStream os = sc.openOutputStream();
            os.write("PING\n".getBytes());
            os.flush();
            InputStream is = sc.openInputStream();
            byte[] buf = new byte[64];
            int n = is.read(buf);
            String echo = new String(buf, 0, n);
            report("T5", "PING\n".equals(echo) && "127.0.0.1".equals(addr) &&
                         port == tcpPort && lport > 0 && laddr != null,
                   "echo=" + echo.trim() + " port=" + port + " lport=" + lport);
            sc.close();
        } catch (Exception e) {
            report("T5", false, "EX " + e);
        }

        /* ---- T6: serversocket + accept из другого потока ---- */
        try {
            final ServerSocketConnection ssc = (ServerSocketConnection)
                Connector.open("serversocket://:" + 0 /* авто-порт */);
            final int sp = ssc.getLocalPort();
            Thread t = new Thread(new Runnable() {
                public void run() {
                    try {
                        StreamConnectionNotifier not = (StreamConnectionNotifier) ssc;
                        StreamConnection client = not.acceptAndOpen();
                        InputStream is = client.openInputStream();
                        OutputStream os = client.openOutputStream();
                        byte[] buf = new byte[64];
                        int n = is.read(buf);
                        os.write(buf, 0, n);
                        os.flush();
                        client.close();
                    } catch (Exception e) {
                        System.out.println("NET T6 thread EX " + e);
                    }
                }
            });
            t.start();
            /* маленькая пауза, чтобы сервер успел слушать */
            Thread.sleep(300);
            StreamConnection c = (StreamConnection)
                Connector.open("socket://127.0.0.1:" + sp);
            OutputStream os = c.openOutputStream();
            os.write("SRV-ECHO".getBytes());
            InputStream is = c.openInputStream();
            byte[] buf = new byte[64];
            int n = is.read(buf);
            String echo = new String(buf, 0, n);
            t.join(5000);
            report("T6", "SRV-ECHO".equals(echo) && sp > 0,
                   "echo=" + echo + " port=" + sp);
            c.close();
            ssc.close();
        } catch (Exception e) {
            report("T6", false, "EX " + e);
        }

        /* ---- T7: UDP ---- */
        try {
            UDPDatagramConnection server = (UDPDatagramConnection)
                Connector.open("udp://:" + udpPort);
            UDPDatagramConnection client = (UDPDatagramConnection)
                Connector.open("udp://127.0.0.1:" + udpPort);
            Datagram dg = client.newDatagram(128);
            setPayload(dg, "UDP-PING");
            client.send(dg);
            Datagram rd = server.newDatagram(128);
            server.receive(rd);
            String got = getPayload(rd);
            String from = rd.getAddress();
            /* ответ назад по адресу отправителя */
            Datagram rep = server.newDatagram(128);
            rep.setAddress(from);
            setPayload(rep, "UDP-PONG");
            server.send(rep);
            Datagram cr = client.newDatagram(128);
            client.receive(cr);
            String pong = getPayload(cr);
            report("T7", "UDP-PING".equals(got) && "UDP-PONG".equals(pong) &&
                         from != null && from.indexOf("127.0.0.1") >= 0,
                   "got=" + got + " pong=" + pong + " from=" + from);
            client.close();
            server.close();
        } catch (Exception e) {
            report("T7", false, "EX " + e);
        }

        /* ---- T8: WMA ---- */
        try {
            MessageConnection mc = (MessageConnection)
                Connector.open("sms://+79990001122", Connector.WRITE);
            TextMessage tm = (TextMessage) mc.newMessage(MessageConnection.TEXT_MESSAGE);
            tm.setPayloadText("SCORE=424242");
            tm.setAddress("sms://+79990001122");
            int seg = mc.numberOfSegments(tm);
            mc.send(tm);
            MessageConnection mc2 = (MessageConnection)
                Connector.open("mms://+79990001122", Connector.WRITE);
            report("T8", seg >= 1 && "SCORE=424242".equals(tm.getPayloadText()),
                   "segments=" + seg);
            mc.close();
            mc2.close();
        } catch (Exception e) {
            report("T8", false, "EX " + e);
        }

        /* ---- T9: Connector.openDataInputStream ---- */
        try {
            DataInputStream dis = Connector.openDataInputStream(
                "http://127.0.0.1:" + httpPort + "/hello");
            String body = readAll(dis);
            dis.close();
            report("T9", "HELLO-NOJME".equals(body), "body=" + body);
        } catch (Exception e) {
            report("T9", false, "EX " + e);
        }

        /* ---- T10: ошибки ---- */
        boolean refused = false, cnf = false, tls = false;
        try {
            HttpConnection c = (HttpConnection)
                Connector.open("http://127.0.0.1:1/refused");
            int rc = c.getResponseCode();
            if (rc != 200) refused = true; /* 503-подобное тоже ошибка, но IOException правильнее */
        } catch (IOException e) { refused = true; }
        try {
            Connector.open("comm://COM1");
        } catch (ConnectionNotFoundException e) { cnf = true; }
        catch (IOException e) { cnf = true; }
        try {
            Connector.open("https://127.0.0.1/tls");
        } catch (IOException e) { tls = true; }
        report("T10", refused && cnf && tls,
               "refused=" + refused + " cnf=" + cnf + " tls=" + tls);

        /* ---- T11: GC-sweep открытых без close соединений ---- */
        try {
            /* 20 соединений без close (таблица слотов — 24) */
            for (int i = 0; i < 20; i++) {
                HttpConnection hc = (HttpConnection)
                    Connector.open("http://127.0.0.1:" + httpPort + "/hello");
                hc = null; /* ссылка выброшена без close */
            }
            /* System.gc() из натива не запускает STW (v36.03 GC-DEFER-IN-
             * NATIVE) — форсируем ПЕРИОДИЧЕСКИЙ GC аллокациями из
             * интерпретатора (бюджет 4 МБ) — sweep должен освободить
             * слоты умерших владельцев ([NET-PEER-SWEEP] в логе). */
            long sink = 0;
            for (int i = 0; i < 500; i++) {
                byte[] trash = new byte[16384];
                trash[0] = (byte) i;
                sink += trash[0];
            }
            /* слоты должны быть свободны — новые открываются и работают */
            int okCnt = 0;
            for (int i = 0; i < 10; i++) {
                HttpConnection hc = (HttpConnection)
                    Connector.open("http://127.0.0.1:" + httpPort + "/hello");
                if (hc.getResponseCode() == 200) okCnt++;
                hc.close();
            }
            report("T11", okCnt == 10, "after-gc ok=" + okCnt + "/10 sink=" + sink);
        } catch (Exception e) {
            report("T11", false, "EX " + e);
        }

        /* ---- T12: заблокированный WMA receive + завершение ----
         * поток висит в receive() (NOJME_WMA_RECV_MS), main завершает
         * мидлет: teardown обязан поднять эпоху и освободить поток
         * (чистый выход = сам тест; [JVM-DESTROY]-строк в логе быть
         * не должно). */
        try {
            final MessageConnection mc = (MessageConnection)
                Connector.open("sms://+70000000000", Connector.READ);
            Thread t = new Thread(new Runnable() {
                public void run() {
                    try { mc.receive(); }
                    catch (Exception e) { /*InterruptedIOException ожидаем*/ }
                }
            });
            t.start();
            Thread.sleep(250); /* поток успевает уйти в блок */
            report("T12", true, "blocked receive thread started");
            mc.close();
        } catch (Exception e) {
            report("T12", false, "EX " + e);
        }

        System.out.println("NETBENCH " + (pass == total ? "PASS" : "FAIL") +
                           " " + pass + "/" + total);
        notifyDestroyed();
    }

    public void pauseApp() { }
    public void destroyApp(boolean unconditional) { }
}
