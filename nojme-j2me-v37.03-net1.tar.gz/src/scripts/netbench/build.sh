#!/bin/bash
# v37.03 [NET]: build NetBench.jar. Порты серверов кладутся в манифест
# (getAppProperty TestHttpPort/TestTcpPort/TestUdpPort).
# Использование: build.sh <http_port> <tcp_port> <udp_port>
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/stubs"
HTTP_PORT="${1:-18081}"
TCP_PORT="${2:-18082}"
UDP_PORT="${3:-18083}"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/NetBench.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java \
    "$STUBS/javax/microedition/io/"*.java \
    "$STUBS/javax/wireless/messaging/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: NTB, , NetBench\r\nMIDlet-Name: NetBench\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\nTestHttpPort: %s\r\nTestTcpPort: %s\r\nTestUdpPort: %s\r\n' \
    "$HTTP_PORT" "$TCP_PORT" "$UDP_PORT" \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/NetBench*.class "$PKG/"
cp "$OUT"/javax/wireless/messaging/*.class "$PKG/javax/wireless/messaging/" 2>/dev/null || true
( cd "$PKG" && zip -q -r "$D/NetBench.jar" META-INF javax && zip -q "$D/NetBench.jar" *.class )
echo "built: $D/NetBench.jar (ports http=$HTTP_PORT tcp=$TCP_PORT udp=$UDP_PORT)"
