#!/bin/bash
# v37.03 [NET]: функциональный тест GCF-сети (net.c) — scripts/netbench.
# Поднимает локальные HTTP/TCP-серверы (python3), собирает NetBench.jar
# с их портами в манифесте, прогоняет мидлет в headless switchui-verify
# и разбирает строки NET Tn=PASS/FAIL + итог NETBENCH PASS x/y.
set -u
cd "$(dirname "$0")/../.." || exit 1
D=/tmp/znet
PY=python3

rm -rf "$D"; mkdir -p "$D/roms"

# --- 1. серверы ---
$PY scripts/netbench/servers.py > "$D/ports.txt" 2> "$D/servers.err" &
SRV=$!
for i in $(seq 1 50); do
    [ -s "$D/ports.txt" ] && break
    sleep 0.1
done
if [ ! -s "$D/ports.txt" ]; then
    echo "NETBENCH: FAILED (servers did not start; see $D/servers.err)"
    kill $SRV 2>/dev/null
    exit 1
fi
read -r _ HTTP_PORT _ TCP_PORT _ UDP_PORT < "$D/ports.txt"
echo "servers: http=$HTTP_PORT tcp=$TCP_PORT udp=$UDP_PORT (pid $SRV)"

# --- 2. jar с портами ---
bash scripts/netbench/build.sh "$HTTP_PORT" "$TCP_PORT" "$UDP_PORT" > "$D/build.log" 2>&1 || {
    echo "NETBENCH: FAILED (jar build)"; cat "$D/build.log"; kill $SRV 2>/dev/null; exit 1; }
cp scripts/netbench/NetBench.jar "$D/roms/"

# --- 3. прогон в headless verify-бинарнике ---
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-} \
NOJME_LOG=1 NOJME_LOGGING=1 \
NOJME_WMA_RECV_MS=500 \
NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D" \
NOJME_SWITCH_AUTOTEST_SESSIONS=1 NOJME_SWITCH_KEYS="A:600,A:1400,EXIT:40000" \
timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

kill $SRV 2>/dev/null || true
wait $SRV 2>/dev/null || true

# --- 4. разбор результатов ---
PASSED=$(grep -ao "NET T[0-9]*=PASS" "$D/err.log" | sort -u | wc -l)
FAILED=$(grep -ao "NET T[0-9]*=FAIL" "$D/err.log" | sort -u | wc -l)
VERDICT=$(grep -ao "NETBENCH PASS [0-9]*/[0-9]*" "$D/err.log" | tail -1)

echo "---- game output ----"
grep -a "NET " "$D/err.log" | grep -a "T[0-9]*=" | sort -u | head -20
echo "---------------------"
echo "NETBENCH: passed=$PASSED failed=$FAILED verdict='$VERDICT'"

# трассировки сети должны засветиться (регистрация + хотя бы один open)
grep -aq "nojme GCF networking registered" "$D/err.log" && echo "NETBENCH: [NET] registration trace OK" \
    || echo "NETBENCH: WARN - no registration trace"
grep -aq "\[NET-OPEN\] http://" "$D/err.log" && echo "NETBENCH: [NET-OPEN] trace OK" \
    || echo "NETBENCH: WARN - no [NET-OPEN] trace"

if [ "$FAILED" = "0" ] && [ -n "$VERDICT" ] && echo "$VERDICT" | grep -q "PASS 12/12"; then
    echo "NETBENCH: ALL PASS"
    exit 0
fi
echo "NETBENCH: FAIL"
exit 1
