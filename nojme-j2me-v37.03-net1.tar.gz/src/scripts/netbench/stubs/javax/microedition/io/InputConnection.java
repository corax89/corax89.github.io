package javax.microedition.io;
public interface InputConnection extends Connection {
    public java.io.InputStream openInputStream() throws java.io.IOException;
    public java.io.DataInputStream openDataInputStream() throws java.io.IOException;
}
