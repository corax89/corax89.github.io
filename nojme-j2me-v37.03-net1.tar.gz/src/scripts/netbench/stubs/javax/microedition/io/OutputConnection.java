package javax.microedition.io;
public interface OutputConnection extends Connection {
    public java.io.OutputStream openOutputStream() throws java.io.IOException;
    public java.io.DataOutputStream openDataOutputStream() throws java.io.IOException;
}
