package javax.microedition.io;
public interface HttpConnection extends ContentConnection {
    public static final String GET = "GET"; public static final String POST = "POST";
    public static final String HEAD = "HEAD";
    String getURL(); String getProtocol(); String getHost(); String getFile();
    String getRef(); String getQuery(); int getPort();
    String getRequestMethod();
    void setRequestMethod(String method) throws java.io.IOException;
    void setRequestProperty(String key, String value) throws java.io.IOException;
    String getRequestProperty(String key);
    int getResponseCode() throws java.io.IOException;
    String getResponseMessage() throws java.io.IOException;
    String getHeaderField(String name) throws java.io.IOException;
    String getHeaderField(int n) throws java.io.IOException;
    String getHeaderFieldKey(int n) throws java.io.IOException;
    long getExpiration() throws java.io.IOException;
    long getDate() throws java.io.IOException;
    long getLastModified() throws java.io.IOException;
}
