package javax.microedition.io;
public interface SocketConnection extends StreamConnection {
    public static final byte DELAY = 0, LINGER = 1, KEEPALIVE = 2, RCVBUF = 3, SNDBUF = 4;
    void setSocketOption(byte option, int value) throws java.io.IOException;
    int getSocketOption(byte option) throws java.io.IOException;
    String getAddress(); String getLocalAddress(); int getPort(); int getLocalPort();
}
