package javax.microedition.io;
public class Connector {
    public static final int READ = 1, WRITE = 2, READ_WRITE = 3;
    public static Connection open(String name) throws java.io.IOException { return null; }
    public static Connection open(String name, int mode) throws java.io.IOException { return null; }
    public static Connection open(String name, int mode, boolean timeouts) throws java.io.IOException { return null; }
    public static java.io.DataInputStream openDataInputStream(String name) throws java.io.IOException { return null; }
    public static java.io.DataOutputStream openDataOutputStream(String name) throws java.io.IOException { return null; }
    public static void close(java.io.InputStream is) throws java.io.IOException { }
    public static void close(java.io.OutputStream os) throws java.io.IOException { }
}
