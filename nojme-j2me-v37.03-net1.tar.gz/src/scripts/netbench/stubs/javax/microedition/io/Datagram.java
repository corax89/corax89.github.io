package javax.microedition.io;
public interface Datagram {
    String getAddress(); void setAddress(String addr) throws java.io.IOException;
    void setAddress(Datagram reference);
    byte[] getData(); void setData(byte[] buffer);
    int getLength(); void setLength(int length);
    void reset();
}
