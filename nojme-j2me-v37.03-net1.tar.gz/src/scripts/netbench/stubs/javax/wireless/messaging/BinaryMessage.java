package javax.wireless.messaging;
public interface BinaryMessage extends Message {
    void setPayloadData(byte[] data); byte[] getPayloadData();
}
