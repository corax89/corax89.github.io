package javax.wireless.messaging;
import javax.microedition.io.Connection;
public interface MessageConnection extends Connection {
    public static final String TEXT_MESSAGE = "text";
    public static final String BINARY_MESSAGE = "binary";
    Message newMessage(String type);
    Message newMessage(String type, String address);
    void send(Message msg) throws java.io.IOException, java.io.InterruptedIOException;
    Message receive() throws java.io.IOException, java.io.InterruptedIOException;
    void setMessageListener(MessageListener l) throws java.io.IOException;
    int numberOfSegments(Message msg);
}
