#!/bin/bash
# Zombie Infection repro — ПОВТОРНОЕ использование каталога $D (сейвы RMS
# сохраняются между прогонами) — второй прогон идёт путём «возвращающегося
# игрока» (как на устройстве): скриптовая интро → g.H case-117 busy-wait.
# Использование: zombie_repro_keep.sh <суффикс> [RUN_SECONDS]
set -u
cd "$(dirname "$0")/.." || exit 1
SUF=${1:-keep}
D=/tmp/zombie_keep_$SUF
RUN_SECONDS=${2:-90}
mkdir -p "$D/roms"
cp "/home/z/my-project/zi/zombie_ext/Zombie Infection [240x320] (SonyEricsson K800i [1MB]) (andrew-lviv.net).jar" "$D/roms/" 2>/dev/null || true

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SCHED_TRACE=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:600"
FRONT="A:2000,TAP:100,360:600,A:5500,TAP:100,360:1700,TAP:100,360:1000,TAP:100,360:900,TAP:1150,360:3700"
for i in $(seq 1 24); do FRONT="$FRONT,A:1500"; done
export NOJME_FRONT_KEYS="$FRONT"

echo "saves before: $(ls "$D/saves" 2>/dev/null | wc -l) files"
timeout -k 5 "$RUN_SECONDS" ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
echo "exit=$?"
echo "saves after: $(ls "$D/saves" 2>/dev/null | wc -l) files"
echo "=== freeze signatures ==="
grep -an "SPIN-BREAK\|PAINT-BUDGET\|MON-WAIT\|STUCK:\|MIDLET-STUCK" "$D/err.log" | head -10
echo "=== H-frame check (script busy-wait path) ==="
grep -ac "SELFSTACK.*g.H pc" "$D/err.log" 2>/dev/null || echo "no SELFSTACK in log"
echo "=== last resources ==="
grep -aE "TRACE.*RESOURCE" "$D/err.log" | tail -6
echo "=== лог: $D/err.log ==="
