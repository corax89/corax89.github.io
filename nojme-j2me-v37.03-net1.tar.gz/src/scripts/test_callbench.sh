#!/bin/bash
# v36.101 [CALL-TAX]: interpreter rate on the call-heavy workload.
# Prints the true emulator-measured vi= (VM-PERF) for the workload phase
# plus CallBench's own estimate. Compare against test_bench.sh (pure loops).
# Usage: test_callbench.sh [метка]
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/zcallbench
rm -rf "$D"; mkdir -p "$D/roms"
cp scripts/callbench/CallBench.jar "$D/roms/"
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms" NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export NOJME_SWITCH_KEYS="A:400,A:800,EXIT:34000"
timeout -k 5 50 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

vals=$(grep -a "est_instr/s=" "$D/err.log" | tail -9 | cut -d= -f2 | awk 'NF')
n=$(echo "$vals" | awk 'NF' | wc -l)
if [ "$n" -lt 3 ]; then
    echo "CALLBENCH[$1]: FAILED — строк CALLBENCH: $n"
    grep -a "CALLBENCH\|start" "$D/err.log" | head -5
    exit 1
fi
med=$(echo "$vals" | sort -n | awk '{a[NR]=$1} END{print (a[int((NR+1)/2)]+a[int(NR/2)+1])/2}')

# true emulator rate: vi= from VM-PERF while the worker was hot
vis=$(grep -a "VM-PERF" "$D/err.log" | grep -o "vi=[0-9]*K/s" | cut -d= -f1 | sed 's/K\/s//' | awk '$1>500' | sort -n)
nv=$(echo "$vis" | awk 'NF' | wc -l)
vimed=$(echo "$vis" | awk '{a[NR]=$1} END{if(NR>0) print (a[int((NR+1)/2)]+a[int(NR/2)+1])/2; else print 0}')

echo "CALLBENCH[$1]: n=$n est_median=${med} | VM vi_median=${vimed}K/s (n=${nv})"
echo "$vals" | head -6
