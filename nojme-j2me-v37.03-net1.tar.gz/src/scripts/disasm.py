#!/usr/bin/env python3
"""JVM classfile disassembler: dump methods with PC offsets and resolved CP refs."""
import struct, sys

OPS = {
0x00:'nop',0x01:'aconst_null',0x02:'iconst_m1',0x03:'iconst_0',0x04:'iconst_1',0x05:'iconst_2',0x06:'iconst_3',
0x07:'iconst_4',0x08:'iconst_5',0x09:'lconst_0',0x0a:'lconst_1',0x0b:'fconst_0',0x0c:'fconst_1',0x0d:'fconst_2',
0x0e:'dconst_0',0x0f:'dconst_1',0x10:'bipush',0x11:'sipush',0x12:'ldc',0x13:'ldc_w',0x14:'ldc2_w',
0x15:'iload',0x16:'lload',0x17:'fload',0x18:'dload',0x19:'aload',0x1a:'iload_0',0x1b:'iload_1',0x1c:'iload_2',
0x1d:'iload_3',0x1e:'lload_0',0x1f:'lload_1',0x20:'lload_2',0x21:'lload_3',0x22:'fload_0',0x23:'fload_1',
0x24:'fload_2',0x25:'fload_3',0x26:'dload_0',0x27:'dload_1',0x28:'dload_2',0x29:'dload_3',0x2a:'aload_0',
0x2b:'aload_1',0x2c:'aload_2',0x2d:'aload_3',0x2e:'iaload',0x2f:'laload',0x30:'faload',0x31:'daload',
0x32:'aaload',0x33:'baload',0x34:'caload',0x35:'saload',0x36:'istore',0x37:'lstore',0x38:'fstore',
0x39:'dstore',0x3a:'astore',0x3b:'istore_0',0x3c:'istore_1',0x3d:'istore_2',0x3e:'istore_3',0x3f:'lstore_0',
0x40:'lstore_1',0x41:'lstore_2',0x42:'lstore_3',0x43:'fstore_0',0x44:'fstore_1',0x45:'fstore_2',0x46:'fstore_3',
0x47:'dstore_0',0x48:'dstore_1',0x49:'dstore_2',0x4a:'dstore_3',0x4b:'astore_0',0x4c:'astore_1',0x4d:'astore_2',
0x4e:'astore_3',0x4f:'iastore',0x50:'lastore',0x51:'fastore',0x52:'dastore',0x53:'aastore',0x54:'bastore',
0x55:'castore',0x56:'sastore',0x57:'pop',0x58:'pop2',0x59:'dup',0x5a:'dup_x1',0x5b:'dup_x2',0x5c:'dup2',
0x5d:'dup2_x1',0x5e:'dup2_x2',0x5f:'swap',0x60:'iadd',0x61:'ladd',0x62:'fadd',0x63:'dadd',0x64:'isub',
0x65:'lsub',0x66:'fsub',0x67:'dsub',0x68:'imul',0x69:'lmul',0x6a:'fmul',0x6b:'dmul',0x6c:'idiv',0x6d:'ldiv',
0x6e:'fdiv',0x6f:'ddiv',0x70:'irem',0x71:'lrem',0x72:'frem',0x73:'drem',0x74:'ineg',0x75:'lneg',0x76:'fneg',
0x77:'dneg',0x78:'ishl',0x79:'lshl',0x7a:'ishr',0x7b:'lshr',0x7c:'iushr',0x7d:'lushr',0x7e:'iand',0x7f:'land',
0x80:'ior',0x81:'lor',0x82:'ixor',0x83:'lxor',0x84:'iinc',0x85:'i2l',0x86:'i2f',0x87:'i2d',0x88:'l2i',
0x89:'l2f',0x8a:'l2d',0x8b:'f2i',0x8c:'f2l',0x8d:'f2d',0x8e:'d2i',0x8f:'d2l',0x90:'d2f',0x91:'i2b',
0x92:'i2c',0x93:'i2s',0x94:'lcmp',0x95:'fcmpl',0x96:'fcmpg',0x97:'dcmpl',0x98:'dcmpg',
0x99:'ifeq',0x9a:'ifne',0x9b:'iflt',0x9c:'ifge',0x9d:'ifgt',0x9e:'ifle',
0x9f:'if_icmpeq',0xa0:'if_icmpne',0xa1:'if_icmplt',0xa2:'if_icmpge',0xa3:'if_icmpgt',0xa4:'if_icmple',
0xa5:'if_acmpeq',0xa6:'if_acmpne',0xa7:'goto',0xa8:'jsr',0xa9:'ret',0xaa:'tableswitch',0xab:'lookupswitch',
0xac:'ireturn',0xad:'lreturn',0xae:'freturn',0xaf:'dreturn',0xb0:'areturn',0xb1:'return',
0xb2:'getstatic',0xb3:'putstatic',0xb4:'getfield',0xb5:'putfield',0xb6:'invokevirtual',0xb7:'invokespecial',
0xb8:'invokestatic',0xb9:'invokeinterface',0xba:'invokedynamic',0xbb:'new',0xbc:'newarray',0xbd:'anewarray',
0xbe:'arraylength',0xbf:'athrow',0xc0:'checkcast',0xc1:'instanceof',0xc2:'monitorenter',0xc3:'monitorexit',
0xc4:'wide',0xc5:'multianewarray',0xc6:'ifnull',0xc7:'ifnonnull',0xc8:'goto_w',0xc9:'jsr_w',
}

def parse_cp(data):
    pos = 8
    cpc = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
    cp = [None]*(cpc+1)
    i = 1
    while i < cpc:
        tag = data[pos]; pos += 1
        if tag == 1:
            ln = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
            cp[i] = ('utf8', data[pos:pos+ln].decode('utf-8','replace')); pos += ln
        elif tag in (7,8,16,19,20):
            cp[i] = ('ref', struct.unpack('>H', data[pos:pos+2])[0]); pos += 2
        elif tag == 15:
            cp[i] = ('mh', data[pos:pos+3]); pos += 3
        elif tag in (3,4):
            cp[i] = ('num', data[pos:pos+4]); pos += 4
        elif tag in (5,6):
            cp[i] = ('num8', data[pos:pos+8]); pos += 8; i += 1
        elif tag in (9,10,11,12,17,18):
            cp[i] = ('member', struct.unpack('>HH', data[pos:pos+4])); pos += 4
        elif tag == 0:
            break
        else:
            raise ValueError(f'tag {tag} @ {pos}')
        i += 1
    return cp

def main(path, only_methods=None, around=None):
    data = open(path,'rb').read()
    cp = parse_cp(data)
    def utf(i): return cp[i][1] if cp[i] and cp[i][0]=='utf8' else '?'
    def cls(i): return utf(cp[i][1]) if cp[i] and cp[i][0]=='ref' else '?'
    def member(i):
        if cp[i] and cp[i][0]=='member':
            ci, nti = cp[i][1]; ni, di = cp[nti][1]
            return f'{cls(ci)}.{utf(ni)}:{utf(di)}'
        return '?'
    def ldc(i):
        if cp[i] is None: return '?'
        t, v = cp[i][0], cp[i][1]
        if t=='utf8': return repr(v[:60])
        if t=='num': return str(struct.unpack('>i', v)[0])
        if t=='num8': return str(struct.unpack('>q', v)[0])
        if t=='ref': return f'-> {utf(v)}'
        return f'{t}'

    pos = 8
    cpc = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
    # skip cp
    i = 1
    while i < cpc:
        tag = data[pos]; pos += 1
        if tag == 1: pos += 2 + struct.unpack('>H',data[pos:pos+2])[0]
        elif tag in (7,8,16,19,20): pos += 2
        elif tag == 15: pos += 3
        elif tag in (3,4): pos += 4
        elif tag in (5,6): pos += 8; i += 1
        elif tag in (9,10,11,12,17,18): pos += 4
        elif tag == 0: break
        i += 1
    pos += 6  # access,this,super
    ici = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2 + ici*2
    fci = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
    for _ in range(fci):
        pos += 6
        ac = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2 + ac*2
    mci = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
    print(f'== {path} ({mci} methods)')
    for _m in range(mci):
        acc, ni, di = struct.unpack('>HHH', data[pos:pos+6]); pos += 6
        ac = struct.unpack('>H', data[pos:pos+2])[0]; pos += 2
        attrs = {}
        for _a in range(ac):
            an = utf(struct.unpack('>H', data[pos:pos+2])[0]); pos += 2
            alen = struct.unpack('>I', data[pos:pos+4])[0]; pos += 4
            attrs.setdefault(an, b'')
            attrs[an] += data[pos:pos+alen]
            pos += alen
        mname, mdesc = utf(ni), utf(di)
        if 'Code' not in attrs: continue
        if only_methods and mname not in only_methods: continue
        code = attrs['Code']
        max_stack, max_locals, clen = struct.unpack('>HHI', code[0:8])
        body = code[8:8+clen]
        print(f'\n-- {mname}{mdesc}  stack={max_stack} locals={max_locals} len={clen}')
        j = 0
        while j < len(body):
            pc = j
            op = body[j]
            name = OPS.get(op, f'0x{op:02x}?')
            arg = ''
            sz = 1
            if op in (0x10,): arg=f' {struct.unpack(">b",body[j+1:j+2])[0]}'; sz=2
            elif op in (0x11,): arg=f' {struct.unpack(">h",body[j+1:j+3])[0]}'; sz=3
            elif op == 0x12: arg=f' #{body[j+1]} = {ldc(body[j+1])}'; sz=2
            elif op in (0x13,0x14): idx=struct.unpack('>H',body[j+1:j+3])[0]; arg=f' #{idx} = {ldc(idx)}'; sz=3
            elif op in (0x15,0x16,0x17,0x18,0x19,0x36,0x37,0x38,0x39,0x3a,0xa9): arg=f' {body[j+1]}'; sz=2
            elif op == 0x84: arg=f' {body[j+1]} by {struct.unpack(">b",body[j+2:j+3])[0]}'; sz=3
            elif op in (0x99,0x9a,0x9b,0x9c,0x9d,0x9e,0x9f,0xa0,0xa1,0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xc6,0xc7):
                off = struct.unpack('>h', body[j+1:j+3])[0]; arg=f' -> {pc+off}'; sz=3
            elif op in (0xc8,0xc9):
                off = struct.unpack('>i', body[j+1:j+5])[0]; arg=f' -> {pc+off}'; sz=5
            elif op in (0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8,0xbb,0xbd,0xc0,0xc1):
                idx = struct.unpack('>H', body[j+1:j+3])[0]
                v = member(idx) if op in (0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8) else cls(idx)
                arg = f' #{idx} {v}'; sz=3
            elif op == 0xb9:
                idx = struct.unpack('>H', body[j+1:j+3])[0]; arg=f' #{idx} {member(idx)}'; sz=5
            elif op == 0xba: sz=5
            elif op == 0xbc: arg=f' {body[j+1]}'; sz=2
            elif op == 0xc5: arg=f' #{struct.unpack(">H",body[j+1:j+3])[0]} dims={body[j+3]}'; sz=4
            elif op == 0xaa:  # tableswitch
                pad = (4 - ((j+1) % 4)) % 4
                p = j+1+pad
                df, lo, hi = struct.unpack('>iii', body[p:p+12]); p += 12
                n = hi-lo+1
                offs = struct.unpack(f'>{n}i', body[p:p+4*n]); p += 4*n
                arg = f' lo={lo} hi={hi} default->{pc+df} ' + ' '.join(f'{lo+k}->{pc+o}' for k,o in enumerate(offs))
                sz = (p - j)
            elif op == 0xab:  # lookupswitch
                pad = (4 - ((j+1) % 4)) % 4
                p = j+1+pad
                df, n = struct.unpack('>ii', body[p:p+8]); p += 8
                pairs = struct.unpack(f'>{2*n}i', body[p:p+8*n]); p += 8*n
                arg = f' default->{pc+df} ' + ' '.join(f'{pairs[2*k]}->{pc+pairs[2*k+1]}' for k in range(n))
                sz = (p - j)
            elif op == 0xc4:  # wide
                wop = body[j+1]
                if wop == 0x84:
                    arg=f' {OPS.get(wop)} {struct.unpack(">H",body[j+2:j+4])[0]} by {struct.unpack(">h",body[j+4:j+6])[0]}'; sz=6
                else:
                    arg=f' {OPS.get(wop)} {struct.unpack(">H",body[j+2:j+4])[0]}'; sz=4
            print(f'{pc:5d}: {name}{arg}')
            j += sz
        # exception table
        elen = struct.unpack('>H', code[8+clen:10+clen])[0]
        if elen:
            print('  exceptions:')
            p = 10+clen
            for _e in range(elen):
                s,e,h,ci = struct.unpack('>HHHH', body if False else code[p:p+8]); p += 8
                print(f'    [{s},{e}) -> {h} type={cls(ci) if ci else "<any>"}')

if __name__ == '__main__':
    path = sys.argv[1]
    methods = sys.argv[2].split(',') if len(sys.argv) > 2 else None
    main(path, methods)
