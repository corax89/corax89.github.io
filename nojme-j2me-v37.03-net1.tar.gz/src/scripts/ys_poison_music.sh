#!/bin/bash
# [POISON-MUSIC] (Task 14) — музыкальный прогон poison-сборки: тайминги
# ДОСЛОВНО из ys_asan_loop.sh фазы 2 (Task 12, sb рос до 12868 — музыка
# гарантированно играла), чтобы прогнать [WILDGUARD]-гварды микшера
# (mix:midi/mix:seq/mix:wav/mix:tone/audio:queue) с ЖИВЫМИ плеерами.
# Критерий: 0 SEGV, 0 ложных [WILDGUARD], sb>0 в diag (музыка играла).
set -u
cd "$(dirname "$0")/.." || exit 1

YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"
[ -f "$YS" ] || { echo "FAIL: нет JAR: $YS"; exit 1; }

W=/tmp/pm_work
rm -rf "$W"
mkdir -p "$W/ui" "$W/games" "$W/saves"
cp "$YS" "$W/games/"

cat > "$W/ui/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=on
vm_speed=normal
logging=on
battery=off
keyhint=off
saves_dir=$W/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_BROWSE_ROOT="$W/games"
export NOJME_SWITCH_UI_DIR="$W/ui"
export XDG_DATA_HOME="$W/ui/xdg"
export MALLOC_PERTURB_=165
export LD_PRELOAD=/home/z/my-project/scripts/segvtrace.so

BIN=./bin-poison/switchui-verify
[ -x "$BIN" ] || { echo "FAIL: нет $BIN"; exit 1; }

echo "=== ФАЗА 1: создание RMS-состояния (язык English через X, как Task 12) ==="
( cd "$W" && env NOJME_SWITCH_KEYS="A:1200,A:500,X:16000,EXIT:42000" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 \
    timeout -k 5 50 "$OLDPWD/$BIN" > /tmp/pm_p1_out.log 2> /tmp/pm_p1_err.log )
echo "rc=$? (создание состояния)"
ls "$W/saves"/*/ 2>/dev/null || echo "(RMS пуст — фаза 1 могла не создать)"

echo
echo "=== ФАЗА 2: диалог X -> сплэш '5' -> 100 c в меню с музыкой -> выход ==="
( cd "$W" && env \
    NOJME_SWITCH_KEYS="A:1200,A:500" \
    NOJME_SWITCH_AUTOTEST_SESSIONS=1 \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=15000 \
    NOJME_GAME_KEYS="W:12000,-6:400,W:5000,53:300,W:100000" \
    NOJME_FRONT_KEYS="PLUS:120000,DOWN:121000,DOWN:122000,DOWN:122500,A:123000" \
    timeout -k 5 150 "$OLDPWD/$BIN" > /tmp/pm_p2_out.log 2> /tmp/pm_p2_err.log )
echo "rc=$?"

echo
echo "=== Вердикт ==="
if rg -q "SEGVTRACE" /tmp/pm_p1_err.log /tmp/pm_p2_err.log; then
    echo "SEGV!!!:"; rg -A20 "SEGVTRACE" /tmp/pm_p1_err.log /tmp/pm_p2_err.log | head -40
    exit 2
fi
WG=$(cat /tmp/pm_p1_err.log /tmp/pm_p2_err.log | rg -c "WILDGUARD" || true)
echo "SEGV: нет; ложных [WILDGUARD]: ${WG:-0} (ждём 0)"
echo "--- музыка (sb в diag, последние 4) ---"
rg -a "diag:" /tmp/pm_p2_err.log | rg -o "sb=[0-9]+" | tail -4
echo "--- медиа-события ---"
rg -a "\[MEDIA\]|addPlayerListener" /tmp/pm_p2_err.log | head -8
if [ "${WG:-0}" != "0" ]; then exit 3; fi
echo "POISON-MUSIC: ALL PASSED (микшер с живыми плеерами прогнан, гварды молчат)"
