#!/bin/bash
# Build TestPU.jar — [PLAYERUPDATE-HAMMER] v36.48: MIDlet, молотящий доставку
# PlayerListener.playerUpdate (30 циклов start/stop + play-out). Драйвер:
# scripts/test_playerupdate.sh (ASan-сборка switchui-verify).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestPU.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/media/"*.java \
    "$D/stubs/java/io/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: PU, , TestPU\r\nMIDlet-Name: TestPU\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestPU*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestPU.jar" META-INF && zip -q "$D/TestPU.jar" *.class )

echo "built: $D/TestPU.jar"
