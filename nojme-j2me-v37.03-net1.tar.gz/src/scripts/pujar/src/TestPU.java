import javax.microedition.midlet.*;
import javax.microedition.media.*;
import java.io.ByteArrayInputStream;

/**
 * [PLAYERUPDATE-HAMMER] v36.48 selftest: молотит доставку
 * PlayerListener.playerUpdate(Player, String, Object) — путь, который до
 * v36.47 читал args[3] за границей стека (Ryujinx InvalidAccess
 * 0x20697465592F7365 "es/Yeti "). Циклы start/stop + play-out (END_OF_MEDIA):
 * каждая доставка обязана пройти через исправленный код и не уронить ASan.
 */
public class TestPU extends MIDlet implements PlayerListener, Runnable {
    private int delivered = 0;
    private int nStarted = 0, nStopped = 0, nEom = 0, nOther = 0;
    private int nCreated = 0;
    private String fail = null;

    public void startApp() {
        Thread t = new Thread(this);
        t.start();
    }

    private byte[] tone() {
        return new byte[] {
            (byte) -2, 1,          // VERSION 1
            (byte) -3, 60,         // TEMPO 60
            (byte) -4, 32,         // RESOLUTION 32
            60, 2, 62, 2, 64, 2, 65, 2, 67, 2,   // короткая мелодия
            (byte) -1, 2           // BLOCK_END
        };
    }

    /** Занятый спин по wall-clock: держит ИНТЕРПРЕТАТОР этого потока
     * работающим (poll событий media дёргается из yield-хука интерпретатора —
     * Thread.sleep его останавливает, и доставки копятся в очереди). */
    private void spinMs(int ms) {
        long acc = 0;
        long t0 = System.currentTimeMillis();
        while (System.currentTimeMillis() - t0 < ms) {
            for (int i = 0; i < 20000; i++) acc += i;
        }
        if (acc == 1) System.out.println("PU-SPIN");
    }

    public void run() {
        try {
            for (int i = 0; i < 30; i++) {
                // (a) start -> STOP -> close: две доставки за цикл
                Player p = Manager.createPlayer(
                        new ByteArrayInputStream(tone()), "audio/x-tone-seq");
                nCreated++;
                p.addPlayerListener(this);
                p.start();                      // -> started
                spinMs(120);
                p.stop();                       // -> stopped
                spinMs(120);
                p.close();

                // (b) play-out: короткий тон доигрывает сам -> endOfMedia
                Player q = Manager.createPlayer(
                        new ByteArrayInputStream(tone()), "audio/x-tone-seq");
                nCreated++;
                q.addPlayerListener(this);
                q.start();                      // -> started (+ eom на исходе)
                spinMs(700);
                q.close();
            }
            spinMs(500);                        // дренаж хвоста очереди
        } catch (Throwable t) {
            fail = "EXC " + t;
        }
        System.out.println("PU-RESULT created=" + nCreated
                + " delivered=" + delivered
                + " started=" + nStarted + " stopped=" + nStopped
                + " eom=" + nEom + " other=" + nOther
                + (fail != null ? " " + fail : ""));
        notifyDestroyed();
    }

    public void playerUpdate(Player p, String event, Object eventData) {
        delivered++;
        if ("started".equals(event)) nStarted++;
        else if ("stopped".equals(event)) nStopped++;
        else if ("endOfMedia".equals(event)) nEom++;
        else nOther++;
        if (delivered <= 3 || (delivered % 20) == 0) {
            System.out.println("PU " + delivered + " " + event);
        }
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}
}
