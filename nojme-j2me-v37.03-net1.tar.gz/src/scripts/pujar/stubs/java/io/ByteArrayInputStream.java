package java.io;

public class ByteArrayInputStream extends InputStream {
    protected byte[] buf;
    protected int pos;
    protected int count;
    public ByteArrayInputStream(byte[] b) { this.buf = b; this.pos = 0; this.count = b.length; }
    public int read() { return pos < count ? (buf[pos++] & 0xff) : -1; }
}
