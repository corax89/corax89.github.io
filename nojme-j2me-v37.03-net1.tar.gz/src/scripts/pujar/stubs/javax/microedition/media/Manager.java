package javax.microedition.media;

import java.io.InputStream;

public class Manager {
    public static Player createPlayer(String locator) throws MediaException, java.io.IOException { return null; }
    public static Player createPlayer(InputStream stream, String type) throws MediaException, java.io.IOException { return null; }
    public static void playTone(int note, int duration, int volume) throws MediaException { }
    public static String[] getSupportedContentTypes(String protocol) { return null; }
    public static String[] getSupportedProtocols(String content_type) { return null; }
}
