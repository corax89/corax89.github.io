package javax.microedition.media;

public interface Player {
    void realize() throws MediaException;
    void prefetch() throws MediaException;
    void start() throws MediaException;
    void stop() throws MediaException;
    void deallocate();
    void close();
    void setLoopCount(int count);
    long getDuration();
    long getMediaTime();
    long setMediaTime(long now);
    int getState();
    String getContentType();
    String getLocator();
    void addPlayerListener(PlayerListener listener) throws MediaException;
    void removePlayerListener(PlayerListener listener);
}
