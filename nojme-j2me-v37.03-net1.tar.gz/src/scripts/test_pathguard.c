/*
 * test_pathguard.c — [PATHGUARD] v36.51 unit test.
 * Компилируется с -DNOJME_SWITCH_TRACE против РЕАЛЬНОГО pathguard.c
 * (тот же код, что в NRO): иглы трёх полевых адресов, slab-обёртка
 * fopen, [FILEOP]-бейдж с n21, [PTRSCAN] SLOT-детект (ядовитая копия
 * байт в позиции указателя) vs str-in-place (безобидное хранилище
 * строки) в стеке и BSS, канал отчёта через хук.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "switch/pathguard.h"

/* стаб sw_trace_force: pathguard.c ссылается на него при гейте
 * NOJME_SWITCH_TRACE (switch_trace.c в тест не линкуется) */
void sw_trace(const char* fmt, ...) { (void)fmt; }
void sw_trace_force(const char* fmt, ...) { (void)fmt; }

static int fails = 0;
#define CHECK(cond, msg) do { \
    if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
    else { printf("ok: %s\n", msg); } \
} while (0)

/* ---- канал отчёта: копим строки ---- */
#define CAP_LINES 64
static char g_lines[CAP_LINES][400];
static int g_nlines = 0;
static void test_report(const char* line) {
    if (g_nlines < CAP_LINES)
        snprintf(g_lines[g_nlines++], sizeof(g_lines[0]), "%s", line);
}
static void lines_reset(void) { g_nlines = 0; }
static int lines_contains(const char* sub) {
    for (int i = 0; i < g_nlines; i++)
        if (strstr(g_lines[i], sub)) return 1;
    return 0;
}

/* Три полевых пути-эталона (логи Ryu пользователя). */
static const char* P_INI  = "sdmc:/switch/j2me/settings.ini";
static const char* P_DIR  = "sdmc:/switch/j2me/games";
static const char* P_JAR  =
    "sdmc:/switch/j2me/games/Yeti Sports (00.02.51)[240x320].jar";

/* Ядовитый слот в СТАТИКЕ (bss): голые байты 21..28 пути-эталона. */
static char g_bss_poison[64];

/* Функция-рамка: буферы в ЕЁ кадре оказываются НАД кадром
 * nojme_pg_ptrscan => попадают в стековый регион скана. */
__attribute__((noinline))
static void stack_poison_and_scan(const char* path, unsigned long long needle) {
    char poison[64];   /* голая игла — СЛОТ */
    char benign[256];  /* полная копия пути — строка-на-месте */
    static char* volatile s_sink;
    memset(poison, 0, sizeof(poison));
    memset(benign, 0, sizeof(benign));
    memcpy(poison, &needle, 8);
    memcpy(benign, path, strlen(path) + 1);
    /* не даём компилятору убрать буферы: volatile-раковина */
    s_sink = poison;
    s_sink = benign;
    (void)!s_sink;
    nojme_pg_ptrscan("unit-stack", path);
}

/* анти-оптимизация выше больше не нужна отдельной функцией */

/* v36.52 [WATCH-CLAMP] регрессия: регистрируем WATCH-буфер в ГЛУБОКО
 * умирающем кадре (12+ КБ под main — заведомо ниже пола любого скана
 * из main). Без клампа прибор читал бы мёртвый буфер и репортил
 * ложный SLOT «region=unit:stale» (полевой класс yetifix8:
 * rms:tmppath+0x8 поверх кадров сканера). */
__attribute__((noinline)) static void stale_leaf(void) {
    char buf[64];
    memset(buf, 0, sizeof(buf));
    unsigned long long n = 0x20697465592F7365ULL; /* "es/Yeti " */
    memcpy(buf + 8, &n, 8);
    nojme_pg_watch("unit:stale", buf, sizeof(buf));
}
__attribute__((noinline)) static void stale_l3(void) {
    volatile char p[4096]; memset((void*)p, 0, sizeof(p)); stale_leaf();
}
__attribute__((noinline)) static void stale_l2(void) {
    volatile char p[4096]; memset((void*)p, 0, sizeof(p)); stale_l3();
}
__attribute__((noinline)) static void stale_l1(void) {
    volatile char p[4096]; memset((void*)p, 0, sizeof(p)); stale_l2();
}

int main(void) {
    nojme_pg_set_report_hook(test_report);

    /* Потолок стека: фиксируем САМЫЙ МЕЛКИЙ кадр (прямо из main) —
     * все последующие сканы идут в пределах [текущая проба .. он]. */
    lines_reset();
    nojme_pg_ptrscan("unit-ceiling", P_DIR);

    /* --- 1. иглы трёх полевых адресов --- */
    CHECK(nojme_pg_needle(P_INI) == 0x6E692E73676E6974ULL,
          "needle settings.ini = 0x6E692E73676E6974 (\"tings.in\")");
    CHECK(nojme_pg_needle(P_DIR) == 0x0000000000007365ULL,
          "needle games dir = 0x7365 (\"es\")");
    CHECK(nojme_pg_needle(P_JAR) == 0x20697465592F7365ULL,
          "needle Yeti jar = 0x20697465592F7365 (\"es/Yeti \")");
    CHECK(nojme_pg_needle(NULL) == 0, "needle(NULL) = 0");
    CHECK(nojme_pg_needle("short") == 0, "needle короткого пути = 0");

    /* --- 2. slab-обёртка fopen + бейдж --- */
    const char* tf = "/tmp/pg_unit_test.ini";
    FILE* w = fopen(tf, "w");
    if (w) { fputs("hello=pathguard\n", w); fclose(w); }
    lines_reset();
    FILE* r = nojme_pg_fopen("unit-open", tf, "r");
    CHECK(r != NULL, "pg_fopen открывает реальный файл");
    char buf[128] = "";
    if (r) { if (fgets(buf, sizeof(buf), r)) fclose(r); else fclose(r); }
    CHECK(strcmp(buf, "hello=pathguard\n") == 0, "pg_fopen читает содержимое");
    CHECK(lines_contains("[PATHGUARD] build="), "бейдж сборки на первой операции");
    {
        char pat[96];
        snprintf(pat, sizeof(pat), "n21=0x%016llx",
                 (unsigned long long)nojme_pg_needle(tf));
        CHECK(lines_contains("[FILEOP]") && lines_contains("tag=unit-open") &&
              lines_contains(pat), "[FILEOP]-бейдж с tag/op/n21");
    }

    /* --- 3. SLOT-детект в стеке + benign классификация --- */
    lines_reset();
    stack_poison_and_scan(P_JAR, 0x20697465592F7365ULL);
    CHECK(lines_contains("SLOT"), "[PTRSCAN] находит ЯДОВИТЫЙ СЛОТ (стек)");
    CHECK(lines_contains("region=stack"), "слот локализован в стеке");
    CHECK(lines_contains("str-in-place"), "полная копия пути = str-in-place (benign)");
    CHECK(lines_contains("ctx="), "SLOT-строка несёт hex-контекст (ctx=)");

    /* --- 4. SLOT-детект в BSS --- */
    lines_reset();
    memset(g_bss_poison, 0, sizeof(g_bss_poison));
    {
        unsigned long long n = 0x6E692E73676E6974ULL; /* "tings.in" */
        memcpy(g_bss_poison, &n, 8);
    }
    nojme_pg_ptrscan("unit-bss", P_INI);
    CHECK(lines_contains("SLOT") && lines_contains("region=bss"),
          "[PTRSCAN] находит слот в BSS");

    /* --- 5. чистая версия: слота нет — нет и SLOT-строк --- */
    lines_reset();
    memset(g_bss_poison, 0, sizeof(g_bss_poison));
    nojme_pg_ptrscan("unit-clean", P_DIR);
    CHECK(!lines_contains("SLOT"), "без яда SLOT-строк нет (0 ложных)");

    /* --- 6. [WATCH]: произвольный буфер (куча) как регион скана --- */
    {
        char* heap = (char*)malloc(64);
        memset(heap, 0, 64);
        unsigned long long n = 0x20697465592F7365ULL;
        memcpy(heap + 8, &n, 8);
        nojme_pg_watch("unit:watch", heap, 64);
        lines_reset();
        nojme_pg_ptrscan("unit-watch", P_JAR);
        CHECK(lines_contains("SLOT") && lines_contains("region=unit:watch"),
              "[PTRSCAN] сканирует [WATCH]-регион");
        free(heap);
    }

    /* --- 7. slab-реюз: повторный вызов с тем же (tag,path) --- */
    {
        /* создаём 2 слэба: два разных пути */
        nojme_pg_fopen("unit-a", P_DIR, "r");  /* ENOENT — не важно */
        nojme_pg_fopen("unit-b", P_JAR, "r");
        /* те же пути снова — новых аллокаций быть не должно, но хотя бы
         * не падаем и бейджи идут */
        nojme_pg_fopen("unit-a", P_DIR, "r");
        nojme_pg_fopen("unit-b", P_JAR, "r");
        CHECK(1, "slab-реюз по (tag,path) без падения");
    }

    /* --- 8. дедупликация: уникальная точка — один раз за сессию ---
     * Игла 0x7365 (P_DIR) в BSS по СТАБИЛЬНОМУ адресу (g_bss_poison).
     * ВАЖНО: игла/регион/смещение не должны встречаться раньше теста —
     * до этого P_DIR сканировался только с чистым g_bss_poison. */
    {
        memset(g_bss_poison, 0, sizeof(g_bss_poison));
        unsigned long long n = 0x7365ULL; /* "es" */
        memcpy(g_bss_poison, &n, 8);
        lines_reset();
        nojme_pg_ptrscan("unit-dd1", P_DIR);
        CHECK(lines_contains("SLOT") && lines_contains("region=bss"),
              "дедуп-тест: первый скан находит SLOT в BSS");
        lines_reset();
        nojme_pg_ptrscan("unit-dd2", P_DIR); /* тот же место, другой tag */
        CHECK(!lines_contains("SLOT"),
              "повтор того же места подавлен (дедуп)");
        nojme_pg_set_dedup(0);
        lines_reset();
        nojme_pg_ptrscan("unit-dd3", P_DIR);
        CHECK(lines_contains("SLOT"),
              "nojme_pg_set_dedup(0): репорт снова идёт");
        nojme_pg_set_dedup(1);
        memset(g_bss_poison, 0, sizeof(g_bss_poison));
    }

    /* --- 9. v36.52 [STR-RAW]: копия без «sdmc:» — не слот --- */
    {
        char* raw = (char*)malloc(128);
        memset(raw, 0, 128);
        /* сырая копия = P_JAR без префикса устройства (fsdev срезает
         * «sdmc:»): игла стоит на raw+16, а не raw+21 */
        memcpy(raw, P_JAR + 5, strlen(P_JAR) - 5 + 1);
        nojme_pg_watch("unit:raw", raw, 128);
        lines_reset();
        nojme_pg_ptrscan("unit-raw", P_JAR);
        CHECK(lines_contains("str-raw") && lines_contains("region=unit:raw"),
              "сырая копия (без префикса устройства) = str-raw");
        CHECK(!lines_contains("region=unit:raw SLOT"),
              "в регионе unit:raw нет SLOT (сырая копия — не слот)");
        free(raw);
    }

    /* --- 10. v36.52 [WATCH-CLAMP]: регион ниже пола скана не читается --- */
    {
        stale_l1(); /* буфер зарегистрирован и кадр умер */
        lines_reset();
        nojme_pg_ptrscan("unit-stale", P_JAR);
        CHECK(!lines_contains("unit:stale"),
              "stale WATCH ниже пола скана подавлен (дедуп вкл)");
        nojme_pg_set_dedup(0);
        lines_reset();
        nojme_pg_ptrscan("unit-stale2", P_JAR);
        CHECK(!lines_contains("unit:stale"),
              "stale WATCH ниже пола скана подавлен (дедуп выкл)");
        nojme_pg_set_dedup(1);
    }

    /* --- 11. v36.52: отказ rename сопровождается rename-why --- */
    {
        lines_reset();
        int r = nojme_pg_rename("unit-ren",
                                "/tmp/pg_no_such_old_file", "/tmp/pg_unit_dst");
        CHECK(r != 0, "rename несуществующего источника = ошибка");
        CHECK(lines_contains("op=rename-why errno="),
              "rename-why errno= при отказе rename");
        CHECK(lines_contains("old=/tmp/pg_no_such_old_file"),
              "rename-why печатает оба пути (old=)");
    }

    nojme_pg_set_report_hook(NULL);
    unlink(tf);

    if (fails) { printf("PATHGUARD UNIT: %d FAIL(S)\n", fails); return 1; }
    printf("PATHGUARD UNIT: ALL PASSED\n");
    return 0;
}
