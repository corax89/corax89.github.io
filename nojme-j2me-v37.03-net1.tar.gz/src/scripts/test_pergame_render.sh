#!/bin/bash
# v36.82 [SW-ONLY] автотест: программный рендерер — ЕДИНСТВЕННЫЙ режим.
# (Прежний v36.81 [PERGAME-RENDER] тест строки «Рендер (со след. запуска)»
# упразднён вместе с самой строкой: рендерер всегда программный.)
# Прогон 1 (SpinPauseTest.jar):
#   запуск игры -> MINUS (пауза) -> DOWN (Настройки игры) -> A (экран
#   настроек; теперь 8 строк) -> A (переключить строку 0 «Разрешение» —
#   проверка, что сейв pergame ini работает) -> B (назад в паузу) -> B
#   (резюм) -> пауза -> DOWN,DOWN,A (Выйти) -> EXIT (меню).
#   Проверки: pgset open/close; [RND] renderer=software (программный —
#   единственный режим); ini появился БЕЗ ключа render= (+ старые ключи
#   не потерялись: res=/scale=/filter=...); в логе НЕТ строк переключения
#   рендерера при старте игры (pergame render=... switching).
# Прогон 2 (тот же $D — ini сохраняется между запусками бинарника):
#   запуск ТОЙ ЖЕ игры (в ini остался res= от прогона 1; render= нет и
#   быть не должно) -> игра жива, рендерер по-прежнему software,
#   переключений нет -> выход.
#   Проверки: игра жива (fl>=1), НЕТ "RND-SWITCH" за сессию, ini без
#   render=.
set -u
cd "$(dirname "$0")/.." || exit 1
JAR="$PWD/scripts/spinpause/SpinPauseTest.jar"
[ -f "$JAR" ] || { echo "SKIP: нет $JAR"; exit 0; }
D=/tmp/sw_pergame_render
rm -rf "$D"
mkdir -p "$D/sdmc:/switch/j2me/games" "$D/sdmc:/switch/j2me/saves" "$D/sdmc:/switch/j2me/pergame"
cp "$JAR" "$D/sdmc:/switch/j2me/games/SpinPauseTest.jar"
cat > "$D/sdmc:/switch/j2me/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=off
logging=on
EOF
export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
BIN="$PWD/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (сначала scripts/build_verify_host.sh)"; exit 1; }
LOG="$D/sdmc:/switch/j2me/log.txt"
INI="$D/sdmc:/switch/j2me/pergame/SpinPauseTest.jar.ini"
ok=1

echo "===== ПРОГОН 1: pergame-настройки (8 строк), программный рендерер"
export NOJME_SWITCH_KEYS="A:600,A:800,EXIT:600"
export NOJME_FRONT_KEYS="MINUS:1500,DOWN:400,A:900,A:500,B:600,B:600,MINUS:1200,DOWN:400,DOWN:400,DOWN:400,A:900"
( cd "$D" && timeout -k 10 60 "$BIN" > out1.log 2> err1.log )
rc1=$?
echo "exit code: $rc1 (want 0)"
[ "$rc1" = "0" ] || { ok=0; echo "FAIL: прогон 1 rc"; }

PG_OPEN=$(grep -ac "pgset: open" "$LOG" 2>/dev/null || true)
PG_CLOSE=$(grep -ac "pgset: close" "$LOG" 2>/dev/null || true)
echo "pgset open/close: $PG_OPEN/$PG_CLOSE (want 1/1)"
[ "$PG_OPEN" = "1" ] && [ "$PG_CLOSE" = "1" ] || { ok=0; echo "FAIL: экран per-game настроек не открылся/не закрылся"; }

# v36.82 [SW-ONLY]: рендерер — программный, единственный режим
RND_NAME=$(grep -aoE "\[RND\] renderer=[a-zA-Z0-9_-]+" "$LOG" 2>/dev/null | head -1 | sed 's/.*renderer=//')
echo "[RND] renderer: $RND_NAME (want software)"
[ "$RND_NAME" = "software" ] || { ok=0; echo "FAIL: рендерер не software (или строка не напечатана)"; }

# переключений рендерера по pergame быть не должно (логика удалена)
grep -q "pergame render" "$LOG" 2>/dev/null \
    && { ok=0; echo "FAIL: остались строки pergame render= (логика удалена в v36.82)"; }

if [ -f "$INI" ]; then
    echo "--- ini после прогона 1:"; cat "$INI"
    grep -q "^render=" "$INI" && { ok=0; echo "FAIL: render= записан в ini (ключ удалён в v36.82)"; }
    grep -q "^res=" "$INI" || { ok=0; echo "FAIL: остальные ключи потерялись"; }
else
    ok=0; echo "FAIL: pergame ini не создан"
fi

echo "===== ПРОГОН 2: тот же jar, программный рендерер в силе, переключений нет"
rm -f "$LOG"
# 8 с игры (диаг-период 5 с успеет напечатать fl=), затем пауза+выход
export NOJME_FRONT_KEYS="MINUS:8000,DOWN:400,DOWN:400,DOWN:400,A:900"
( cd "$D" && timeout -k 10 60 "$BIN" > out2.log 2> err2.log )
rc2=$?
echo "exit code: $rc2 (want 0)"
[ "$rc2" = "0" ] || { ok=0; echo "FAIL: прогон 2 rc"; }

grep -q "RND-SWITCH" "$LOG" 2>/dev/null \
    && { ok=0; echo "FAIL: rnd-switch в чистой сессии (клина не было)"; }
grep -q "pergame render" "$LOG" 2>/dev/null \
    && { ok=0; echo "FAIL: остались строки pergame render= (логика удалена в v36.82)"; }
LASTFL=$(awk '/^[0-9]+ diag:/ { if (match($0, /fl=[0-9]+/)) fl = substr($0, RSTART+3, RLENGTH-3) + 0 }
              /game: session end/ { print fl + 0; exit }' "$LOG" 2>/dev/null)
echo "fl= последней diag до session end: $LASTFL (want >=1)"
[ "$LASTFL" -ge 1 ] || { ok=0; echo "FAIL: игра на программном рендерере не рисует"; }
grep -q "^render=" "$INI" 2>/dev/null && { ok=0; echo "FAIL: render= появился в ini"; }

if [ "$ok" = "1" ]; then echo "ALL PASSED"; else echo "FAILED"; exit 1; fi
