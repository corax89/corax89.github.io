#!/bin/bash
# [CRASH-SOAK] v36.85 расследование: вылет после нескольких открытий/закрытий
# игр на Switch (дамп: Data Abort @0x8, "Out of memory" в регистрах, SDL
# window-путь). Мультисессионный soak РЕАЛЬНОЙ игры (Zombie Infection) в
# одном процессе под ASan/LSan: каждый блок FRONT-цепочки = 15 с игры ->
# MINUS (пауза) -> DOWN,DOWN,A (Выйти) -> teardown -> меню -> следующий
# запуск (NOJME_SWITCH_AUTOTEST_SESSIONS рестартует меню-скрипт).
#
# Использование: scripts/test_crash_soak.sh [sessions] [game_seconds]
# Выход: PASS/FAIL + отчёт LSan (если утечки найдены) + кривая mem: sess=N.
set -u
cd "$(dirname "$0")/.." || exit 1

SESS=${1:-6}
GSEC=${2:-15}
BIN=${BIN:-./bin-asan/switchui-verify}
D=/tmp/crash_soak
rm -rf "$D"; mkdir -p "$D/roms"
ZJAR="/home/z/my-project/zi/zombie_ext/Zombie Infection [240x320] (SonyEricsson K800i [1MB]) (andrew-lviv.net).jar"
[ -f "$ZJAR" ] || { echo "FAIL: zombie jar not found"; exit 1; }
cp "$ZJAR" "$D/roms/"

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
# меню: A = открыть браузер, A = запустить jar (рестарт на каждую сессию)
export NOJME_SWITCH_KEYS="A:400,A:800"
export NOJME_SWITCH_AUTOTEST_SESSIONS=$SESS
export NOJME_SWITCH_AUTOTEST_EXIT_MS=4000
# игра: одна длинная цепочка на процесс: (GSEC игры, MINUS, DOWN, DOWN, DOWN, A) x N
# (v36.87 [PG-CONTROLS]: «Выйти» — 4-й пункт меню паузы, нужно три DOWN)
FRONT=""
for i in $(seq 1 $SESS); do
  FRONT="${FRONT}MINUS:$((GSEC*1000)),"
  FRONT="${FRONT}DOWN:800,"
  FRONT="${FRONT}DOWN:500,"
  FRONT="${FRONT}DOWN:500,"
  FRONT="${FRONT}A:600,"
done
export NOJME_FRONT_KEYS="${FRONT%,}"

# бюджет сессии: игра+teardown ~ GSEC+10 c; выход из меню ещё 5 с
TOTAL=$(( SESS * (GSEC + 12) + 20 ))
export ASAN_OPTIONS=detect_leaks=1:abort_on_error=0:halt_on_error=1:malloc_context_size=30
echo "soak: $SESS sessions x ${GSEC}s, timeout ${TOTAL}s"
timeout -k 10 "$TOTAL" "$BIN" > "$D/out.log" 2> "$D/err.log"; rc=$?
echo "exit code: $rc"

echo "=== session markers ==="
grep -ac "game: begin" "$D/err.log" | sed 's/^/game_begin: /'
grep -ac "game: session end" "$D/err.log" | sed 's/^/session_end: /'
grep -ac "session complete" "$D/err.log" | sed 's/^/complete: /'
grep -a "menu exit" "$D/err.log" | head -2
echo "=== mem curve ==="
grep -a "mem: sess=" "$D/err.log" | sed 's/.*mem: /mem: /'
grep -a "mem-T" "$D/err.log" | tail -8
echo "=== errors ==="
grep -an "FATAL\|OPCODE FAIL\|SIGSEGV\|Segmentation\|AddressSanitizer\|SEGV\|LeakSanitizer" "$D/err.log" | head -20
echo "=== leak summary (top) ==="
if grep -aq "SUMMARY: AddressSanitizer" "$D/err.log"; then
  grep -a "SUMMARY: AddressSanitizer" "$D/err.log" | head -3
  grep -a "Direct leak\|Indirect leak" "$D/err.log" | head -20
fi
echo "=== log: $D/err.log ==="
