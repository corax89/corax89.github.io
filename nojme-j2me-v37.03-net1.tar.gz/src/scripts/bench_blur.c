/* bench_blur.c — цена blur_bg: NEON vs скаляр (v36.86 [BLUR-NEON]). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "switch/switch_scaling.h"

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

int main(void) {
    enum { SW = 240, SH = 320, BW = 30, BH = 40, N = 300 };
    uint32_t* src = malloc((size_t)SW * SH * 4);
    uint32_t* bg = malloc((size_t)BW * BH * 4);
    unsigned rng = 1;
    for (int i = 0; i < SW * SH; i++) {
        rng = rng * 1664525u + 1013904223u;
        src[i] = 0xFF000000u | (rng >> 8);
    }
    /* прогрев */
    switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 2);
    switch_scaling_blur_bg_scalar(src, SW, SH, bg, BW, BH, 2);

    double t0 = now_ms();
    for (int i = 0; i < N; i++) switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 2);
    double t_kernel = (now_ms() - t0) / N;

    t0 = now_ms();
    for (int i = 0; i < N; i++) switch_scaling_blur_bg_scalar(src, SW, SH, bg, BW, BH, 2);
    double t_scalar = (now_ms() - t0) / N;

    printf("blur 240x320->30x40 passes=2: kernel=%.4f ms  scalar=%.4f ms  speedup=%.2fx\n",
           t_kernel, t_scalar, t_scalar / t_kernel);
    return 0;
}
