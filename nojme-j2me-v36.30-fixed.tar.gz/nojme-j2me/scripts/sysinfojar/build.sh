#!/bin/bash
# Build TestSysInfo.jar — v36.30 selftest MIDlet mimicking "Sys Info (MH)"
# (Form full of property lines + 3 soft-key commands + RMS save on exit).
# Driven by scripts/test_switch_sysinfo.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestSysInfo.java" \
    "$D/src/TestSysInfoItems.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java \
    "$D/stubs/javax/microedition/rms/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TestSysInfo, , TestSysInfo\r\nMIDlet-Name: TestSysInfo\r\nMIDlet-Version: 1.1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestSysInfo*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestSysInfo.jar" META-INF && zip -q "$D/TestSysInfo.jar" *.class )

# Second midlet: item-commands-only variant (no form-level commands)
PKG2="$OUT/pkg2"
rm -rf "$PKG2"; mkdir -p "$PKG2/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TestSysInfoItems, , TestSysInfoItems\r\nMIDlet-Name: TestSysInfoItems\r\nMIDlet-Version: 1.1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG2/META-INF/MANIFEST.MF"
cp "$OUT"/TestSysInfoItems*.class "$PKG2/"
( cd "$PKG2" && zip -q -r "$D/TestSysInfoItems.jar" META-INF && zip -q "$D/TestSysInfoItems.jar" *.class )

echo "built: $D/TestSysInfo.jar $D/TestSysInfoItems.jar"
