/*
 * v36.27 TEMPO PROOF HARNESS (report: «музыка в Asphalt 3 3D замедлена»).
 *
 * Доказывает на уровне публичного API midi.c (тот же код, что крутит
 * mix_midi_player в media.c):
 *
 *  [T1] ДЕТЕРМИНИЗМ ОТ ПЕЙСИНГА: одинаковые чанки рендера (221 сэмпл) с
 *       РАЗНЫМИ задержками между вызовами (0 мс vs 40 мс каждый 3-й чанк)
 *       обязаны дать ПОБАЙТОВО одинаковый PCM. Wall-clock advance
 *       (до v36.27) это нарушал — song time набегал по стеновым
 *       промежуткам, а не по рендеру, и музыка звучала растянутой
 *       (продюсер v34.94 пейсится очередью, промежутки != 5 мс).
 *  [T2] ТЕМП: синтетический MIDI (120 BPM, доля = 312.5 мс) — детект
 *       onset'ов по PCM: 16 нот, первое наступание 250.0 мс, шаг
 *       312.5 мс, суммарный дрейф < 30 мс за ~4.7 с (т.е. < 0.7%).
 *  [T3] RUNNING STATUS ПОСЛЕ META: в синтетическом файле ноты идут
 *       running-status-байтами ПОСЛЕ meta-событий (FF 51 темп, FF 58,
 *       FF 03 и FF 01 в середине). До v36.27 running_status затирался
 *       0xFF и поток рассинхронизировался (часть нот терялась — «играют
 *       не все инструменты»). Сейчас все 16 onset'ов обязаны прозвучать.
 *  [T4] РЕАЛЬНЫЙ ФАЙЛ: m1.mid из пака sound Asphalt 3 3D — длительность
 *       (end-tick scan) 57243 мс (was: байтовая длина трека как тики —
 *       мусор), позиция после 1.000 с рендера = ~1000 мс, PCM не
 *       silence, детерминизм от пейсинга — как [T1].
 *  [T5] ТОЧНАЯ ПОСЛЕДОВАТЕЛЬНОСТЬ ИГРЫ (v36.28, «на главном экране
 *       Asphalt 3 3D тихо»): load → setMediaTime(0) → start → render.
 *       Прежний midi_set_position_ms сбрасывал track->position=0, НЕ
 *       перечитывая первую дельту и running_status — парсер уходил в
 *       байты ЗАГОЛОВКА «MTrk», delta_time становился мусорным (7+ тыс.
 *       тиков), ноты не наступали НИКОГДА (diag: ev=7, notes=0, peak=0).
 *       Теперь PCM обязан быть не-тишиной и события/ноты — идти.
 *  [T6] РЕСТАРТ В СЕРЕДИНЕ: игра на повторном входе в меню зовёт
 *       setMediaTime(0) на ИГРАЮЩЕЙ песне — позиция обязана сброситься
 *       и музыка обязана продолжиться с начала (не тишина).
 *
 * Сборка/запуск: scripts/test_switch_miditempo.sh
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>

#include "midi.h"

#define SR 44100
#define CHUNK 221                       /* как samples_per_cycle в media.c */
#define CHUNK_US ((uint64_t)CHUNK * 1000000ULL / (uint64_t)SR)
#define SECONDS 6   /* 16 нот: последняя on-set на 4937 мс + хвост */
#define NCHUNKS (SECONDS * SR / CHUNK)

static int16_t pcmA[(size_t)NCHUNKS * CHUNK * 2];
static int16_t pcmB[(size_t)NCHUNKS * CHUNK * 2];

/* ---------- synthetic MIDI: 120 BPM, running status после meta ---------- */
static uint8_t syn[512];
static int syn_len;

static void syn_put(uint8_t b) { syn[syn_len++] = b; }
static void syn_delta(int t) {
    /* t <= 16384: два байта varlen максимум */
    if (t >= 128) { syn_put(0x80 | (t >> 7)); syn_put(t & 0x7F); }
    else syn_put((uint8_t)t);
}

static void build_synthetic(void) {
    syn_len = 0;
    /* MThd: format 0, 1 track, division 480 */
    memcpy(syn + syn_len, "MThd", 4); syn_len += 4;
    syn_put(0); syn_put(0); syn_put(0); syn_put(6);
    syn_put(0); syn_put(0);            /* format 0 */
    syn_put(0); syn_put(1);            /* 1 track */
    syn_put(0x01); syn_put(0xE0);      /* 480 ticks/beat */

    /* MTrk */
    memcpy(syn + syn_len, "MTrk", 4); syn_len += 4;
    syn_put(0); syn_put(0); syn_put(0x30); syn_put(0x40); /* длина — фикс ниже (запас) */
    int trk_len_at = syn_len - 4;

    int trk_start = syn_len;
    /* tempo 500000 us/beat (120 BPM) */
    syn_delta(0); syn_put(0xFF); syn_put(0x51); syn_put(3);
    syn_put(0x07); syn_put(0xA1); syn_put(0x20);
    /* time signature meta */
    syn_delta(0); syn_put(0xFF); syn_put(0x58); syn_put(4);
    syn_put(4); syn_put(2); syn_put(24); syn_put(8);
    /* track name meta "T" */
    syn_delta(0); syn_put(0xFF); syn_put(0x03); syn_put(1); syn_put('T');

    /* программа — явный статус (channel 0) */
    syn_delta(0); syn_put(0xC0); syn_put(0);
    /* реверб/хорус выключены (CC91=0, CC93=0): хвост эффектов не должен
     * маскировать паузы между нотами в onset-детекторе */
    syn_delta(0); syn_put(0xB0); syn_put(91); syn_put(0);
    syn_delta(0); syn_put(93); syn_put(0);            /* running CC */

    /* первая нота — ЯВНЫЙ статус, дальше всё running status */
    int cur = 60;
    syn_delta(240); syn_put(0x90); syn_put(cur); syn_put(100);
    for (int i = 0; i < 16; i++) {
        syn_delta(60); syn_put(cur); syn_put(0);          /* running OFF (та же нота!) */
        if (i == 15) break;
        cur = 60 + ((i + 1) % 2) * 5;
        if (i == 7) {
            /* meta В СЕРЕДИНЕ, сразу после неё running-status note-on:
             * убийственный для старого парсера паттерн */
            syn_delta(0); syn_put(0xFF); syn_put(0x01); syn_put(2);
            syn_put('o'); syn_put('k');
            syn_delta(240); syn_put(cur); syn_put(100); /* running ON */
        } else {
            syn_delta(240); syn_put(cur); syn_put(100); /* running ON */
        }
    }
    /* EOT */
    syn_delta(60); syn_put(0xFF); syn_put(0x2F); syn_put(0);
    int trk_end = syn_len;
    /* пропатчить длину трека */
    int tl = trk_end - trk_start;
    syn[trk_len_at]     = (uint8_t)(tl >> 24);
    syn[trk_len_at + 1] = (uint8_t)(tl >> 16);
    syn[trk_len_at + 2] = (uint8_t)(tl >> 8);
    syn[trk_len_at + 3] = (uint8_t)(tl);
}

/* ---------- render helpers ---------- */
static int render(MidiFile* m, int16_t* out, int burst_sleep_ms) {
    int total = 0;
    for (int c = 0; c < NCHUNKS; c++) {
        midi_advance_time(m, CHUNK_US);   /* v36.27: ровно по рендеренным сэмплам */
        midi_generate_samples(m, out + (size_t)total * 2, CHUNK);
        total += CHUNK;
        if (burst_sleep_ms && (c % 3) == 2) {
            struct timespec ts = { 0, (long)burst_sleep_ms * 1000000L };
            nanosleep(&ts, NULL);
        }
    }
    return total;
}

/* onset detection: всплеск |L|+|R| > 6000, отстоящий от предыдущего
 * всплеска >150 мс (у тона e колеблется — критерий «громких пробелов»,
 * а не переходов через пол; атака ноты не должна доедать счётчик тишины). */
static int detect_onsets(const int16_t* pcm, int n, int* out_ms, int max_onsets) {
    int count = 0;
    int last_loud = -10000000;
    for (int i = 1; i < n; i++) {
        int e = abs((int)pcm[i * 2]) + abs((int)pcm[i * 2 + 1]);
        if (e > 6000) {
            if (i - last_loud > (150 * SR / 1000) && count < max_onsets)
                out_ms[count++] = (int)((int64_t)i * 1000 / SR);
            last_loud = i;
        }
    }
    return count;
}

static int failures = 0;
static void check(int ok, const char* name) {
    printf("  %s %s\n", ok ? "OK  " : "FAIL", name);
    if (!ok) failures++;
}

int main(int argc, char** argv) {
    midi_init(SR);
    build_synthetic();
    printf("[T] synthetic midi: %d bytes\n", syn_len);

    /* [T2]/[T3]: run A (steady) */
    MidiFile* a = midi_load(syn, (uint32_t)syn_len);
    if (!a) { printf("FAIL synthetic load\n"); return 1; }
    midi_play(a);
    render(a, pcmA, 0);
    midi_free(a);

    /* run B (bursty pacing, same chunks) -> must be byte-identical */
    MidiFile* b = midi_load(syn, (uint32_t)syn_len);
    if (!b) { printf("FAIL synthetic load B\n"); return 1; }
    midi_play(b);
    render(b, pcmB, 40);
    midi_free(b);

    {
        int peak = 0;
        for (size_t i = 0; i < sizeof(pcmA) / 2; i += 13)
            if (abs((int)((int16_t*)pcmA)[i]) > peak) peak = abs((int)((int16_t*)pcmA)[i]);
        printf("  synthetic peak=%d (want >5000)\n", peak);
        check(peak > 5000, "[T0] synthetic renders non-silence");
    }
    check(memcmp(pcmA, pcmB, sizeof(pcmA)) == 0, "[T1] pacing-independence: PCM identical (0ms vs 40ms stalls)");

    int onA[32], onB[32];
    int nA = detect_onsets(pcmA, NCHUNKS * CHUNK, onA, 32);
    int nB = detect_onsets(pcmB, NCHUNKS * CHUNK, onB, 32);
    printf("  onsets: A=%d B=%d (want 16)\n", nA, nB);
    check(nA == 16 && nB == 16, "[T3] all 16 notes sound (running status after meta)");

    if (nA == 16) {
        int first = onA[0];
        long long spac = 0;
        for (int i = 1; i < nA; i++) spac += onA[i] - onA[i - 1];
        int med = (int)(spac / (nA - 1));
        int drift = onA[nA - 1] - onA[0] - 15 * 312;
        printf("  first=%dms (want 250) median_step=%dms (want 312) drift=%dms (want |d|<30)\n",
               first, med, drift);
        check(abs(first - 250) <= 15, "[T2] first onset at 250ms");
        check(abs(med - 312) <= 8, "[T2] median step 312.5ms (120 BPM)");
        check(abs(drift) <= 30, "[T2] total drift < 30ms over 4.7s (<0.7%)");
    }

    /* [T4]: real Asphalt 3 MIDI (path from argv) */
    if (argc > 1) {
        FILE* f = fopen(argv[1], "rb");
        if (f) {
            static uint8_t m1[256 * 1024];
            size_t m1len = fread(m1, 1, sizeof(m1), f);
            fclose(f);
            MidiFile* r = midi_load(m1, (uint32_t)m1len);
            if (r) {
                uint32_t dur = midi_get_duration_ms(r);
                printf("  m1 duration=%u ms (want ~57243)\n", dur);
                check(dur > 57000 && dur < 57500, "[T4] m1 end-tick duration ~57243ms");

                midi_play(r);
                int total = render(r, pcmA, 0);
                int rms = 0;
                for (int i = 0; i < total * 2; i += 97) rms += abs((int)pcmA[i]);
                check(rms > 10000, "[T4] m1 renders non-silence");

                uint32_t pos = midi_get_position_ms(r);
                printf("  m1 position after ~6.0s render = %u ms\n", pos);
                check(pos >= 5980 && pos <= 6012, "[T4] sequencer tracks rendered samples (~6.0s)");

                /* pacing determinism on the real file */
                MidiFile* r2 = midi_load(m1, (uint32_t)m1len);
                midi_play(r2);
                render(r2, pcmB, 40);
                midi_free(r2);
                check(memcmp(pcmA, pcmB, sizeof(pcmA)) == 0, "[T4] m1 pacing-independence: PCM identical");

                /* [T5]: EXACT game sequence (b(n,n2)): setMediaTime(0)
                 * BEFORE start — v36.28 seek fix regression. */
                {
                    MidiFile* g = midi_load(m1, (uint32_t)m1len);
                    if (g) {
                        midi_set_position_ms(g, 0);   /* the game always does this */
                        midi_play(g);                 /* start() */
                        int total = render(g, pcmA, 0);
                        int rms = 0;
                        for (int i = 0; i < total * 2; i += 97) rms += abs((int)pcmA[i]);
                        uint32_t gpos = midi_get_position_ms(g);
                        printf("  [T5] after game-seq: rms=%d pos=%u ms ev=%u notes=%u\n",
                               rms, gpos, g->sequencer->diag_events, g->sequencer->diag_notes);
                        check(rms > 10000, "[T5] setMediaTime(0)+start renders non-silence (menu melody)");
                        check(g->sequencer->diag_notes > 20, "[T5] notes actually started (seek re-armed tracks)");
                        check(gpos >= 5980 && gpos <= 6012, "[T5] position tracks rendered samples");
                        midi_free(g);
                    } else {
                        check(0, "[T5] m1 reloads");
                    }
                }

                /* [T6]: restart in the MIDDLE of a playing song */
                {
                    MidiFile* g = midi_load(m1, (uint32_t)m1len);
                    if (g) {
                        midi_play(g);
                        /* render ~3 s */
                        for (int c = 0; c < (3 * SR / CHUNK); c++) {
                            midi_advance_time(g, CHUNK_US);
                            midi_generate_samples(g, pcmA, CHUNK);
                        }
                        uint32_t pre = midi_get_position_ms(g);
                        midi_set_position_ms(g, 0);   /* the game re-enters the menu */
                        uint32_t post = midi_get_position_ms(g);
                        check(pre >= 2980 && post == 0, "[T6] mid-song setMediaTime(0) resets position");
                        int total = render(g, pcmA, 0);
                        int rms = 0;
                        for (int i = 0; i < total * 2; i += 97) rms += abs((int)pcmA[i]);
                        check(rms > 10000, "[T6] melody plays again after restart (not silence)");
                        midi_free(g);
                    } else {
                        check(0, "[T6] m1 reloads");
                    }
                }

                midi_free(r);
            } else {
                check(0, "[T4] m1 loads");
            }
        } else {
            printf("  (m1.mid not provided: %s — skipped)\n", argv[1]);
        }
    }

    printf("[T] failures=%d\n", failures);
    return failures ? 1 : 0;
}
