/*
 * v36.28 DIAG: chunk-size A/B for the sandbox MIDI silence.
 * Renders the same file with mixer-sized chunks (221 samples = 5 ms, as the
 * audio thread does) vs big chunks (4410 = 100 ms) and with the 4-player
 * preload sequence the game uses.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "midi.h"

static int render_file(const char* path, int chunk, int seconds, int preload_others) {
    FILE* f = fopen(path, "rb");
    if (!f) return -1;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t* data = (uint8_t*)malloc((size_t)size);
    if (fread(data, 1, (size_t)size, f) != (size_t)size) { fclose(f); free(data); return -1; }
    fclose(f);

    MidiFile* midi = midi_load(data, (uint32_t)size);
    if (!midi) { free(data); return -1; }

    /* preload: the game creates 3 more players before start */
    MidiFile* others[3] = {0, 0, 0};
    if (preload_others) {
        const char* oth[] = {"/tmp/miditempo_m0/m7.mid", "/tmp/miditempo_m0/m8.mid",
                             "/tmp/miditempo_m0/m10.mid"};
        for (int k = 0; k < 3; k++) {
            FILE* g = fopen(oth[k], "rb");
            if (!g) continue;
            fseek(g, 0, SEEK_END);
            long sz = ftell(g);
            fseek(g, 0, SEEK_SET);
            uint8_t* d2 = (uint8_t*)malloc((size_t)sz);
            if (fread(d2, 1, (size_t)sz, g) == (size_t)sz) others[k] = midi_load(d2, (uint32_t)sz);
            free(d2);
            fclose(g);
        }
    }

    midi_set_loop(midi, false);
    /* v36.28: replicate the exact game sequence b(n,n2): setLoopCount, then
     * setMediaTime(0), then start() — setMediaTime resets track positions
     * WITHOUT re-reading the first delta (see midi_set_position_ms). */
    if (getenv("M0_SET_MEDIA_TIME"))
        midi_set_position_ms(midi, 0);
    midi_play(midi);

    int total_peak = 0;
    int16_t* buf = (int16_t*)malloc((size_t)chunk * 2 * sizeof(int16_t));
    int chunks_per_sec = 44100 / chunk;
    for (int sec = 0; sec < seconds; sec++) {
        for (int c = 0; c < chunks_per_sec; c++) {
            memset(buf, 0, (size_t)chunk * 2 * sizeof(int16_t));
            midi_advance_time(midi, (uint64_t)chunk * 1000000ULL / 44100);
            midi_generate_samples(midi, buf, chunk);
            for (int i = 0; i < chunk * 2; i++) {
                int a = buf[i] < 0 ? -buf[i] : buf[i];
                if (a > total_peak) total_peak = a;
            }
        }
    }
    fprintf(stderr, "%-28s chunk=%5d preload=%d smt=%d -> peak=%d active=%d pos=%u ev=%u notes=%u delta0=%u tpos0=%u\n",
            path, chunk, preload_others, getenv("M0_SET_MEDIA_TIME") ? 1 : 0,
            total_peak,
            midi->sequencer->active_note_count, midi_get_position_ms(midi),
            midi->sequencer->diag_events, midi->sequencer->diag_notes,
            midi->sequencer->tracks[0].delta_time,
            midi->sequencer->tracks[0].position);

    midi_free(midi);
    for (int k = 0; k < 3; k++) if (others[k]) midi_free(others[k]);
    free(buf);
    free(data);
    return total_peak;
}

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    if (midi_init(44100) != 0) return 2;

    render_file("/tmp/miditempo_m0/m0.mid", 4410, 10, 0);
    render_file("/tmp/miditempo_m0/m0.mid", 221, 10, 0);
    render_file("/tmp/miditempo_m0/m0.mid", 221, 10, 1);
    render_file("/tmp/miditempo_m0/m0.mid", 1, 3, 0);
    return 0;
}
