/*
 * v36.28 DIAG: render pack entry 0 (Asphalt 3 3D main-menu melody) through
 * the midi.c synth and report peak per second — localizes "menu screen is
 * silent" (player starts, position advances, peak=0 in the sandbox).
 *
 * Usage: test_m0_peak <file.mid> [seconds]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "midi.h"

int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <file.mid> [seconds]\n", argv[0]);
        return 2;
    }
    int seconds = argc >= 3 ? atoi(argv[2]) : 45;
    if (seconds <= 0) seconds = 45;

    FILE* f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "cannot open %s\n", argv[1]);
        return 2;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t* data = (uint8_t*)malloc((size_t)size);
    if (!data || fread(data, 1, (size_t)size, f) != (size_t)size) {
        fprintf(stderr, "read failed\n");
        fclose(f);
        free(data);
        return 2;
    }
    fclose(f);

    fprintf(stderr, "loaded %ld bytes, head %02X%02X%02X%02X\n",
            size, data[0], data[1], data[2], data[3]);

    if (midi_init(44100) != 0) {
        fprintf(stderr, "midi_init failed\n");
        free(data);
        return 2;
    }

    MidiFile* midi = midi_load(data, (uint32_t)size);
    if (!midi) {
        fprintf(stderr, "midi_load FAILED\n");
        free(data);
        return 2;
    }
    fprintf(stderr, "duration: %u ms (total_time_us=%llu)\n",
            midi_get_duration_ms(midi),
            (unsigned long long)midi->sequencer->total_time_us);

    midi_set_loop(midi, false);
    midi_play(midi);

    const int SR = 44100;
    const int chunk = SR / 10; /* 100 ms */
    int16_t* buf = (int16_t*)malloc((size_t)chunk * 2 * sizeof(int16_t));

    /* 10 chunks = 1 s */
    for (int sec = 0; sec < seconds; sec++) {
        int peak = 0;
        int nonzero = 0;
        for (int c = 0; c < 10; c++) {
            memset(buf, 0, (size_t)chunk * 2 * sizeof(int16_t));
            /* v36.27 semantics: the sequencer advances on RENDERED SAMPLES */
            midi_advance_time(midi, (uint64_t)chunk * 1000000ULL / SR);
            midi_generate_samples(midi, buf, chunk);
            for (int i = 0; i < chunk * 2; i++) {
                int a = buf[i] < 0 ? -buf[i] : buf[i];
                if (a > 2) nonzero++;
                if (a > peak) peak = a;
            }
        }
        fprintf(stderr, "sec %3d: pos=%7u ms peak=%6d nonzero=%6d/%d active=%d\n",
                sec, midi_get_position_ms(midi), peak, nonzero,
                chunk * 20, midi->sequencer->active_note_count);
        if (!midi->sequencer->playing) {
            fprintf(stderr, "sequencer STOPPED at sec %d\n", sec);
            break;
        }
    }

    midi_stop(midi);
    midi_free(midi);
    free(buf);
    free(data);
    return 0;
}
