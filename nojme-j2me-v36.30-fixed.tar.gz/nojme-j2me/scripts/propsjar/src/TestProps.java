import javax.microedition.midlet.MIDlet;

/**
 * v36.25 TestProps — E2E proof of [SYSPROPS] (java.name/java.version/
 * java.vm.name/device.vendor/device.imei/java.heap.size/java.heap.free/
 * java.stack.size и подобные) и locale-привязки (microedition.locale = код
 * языка интерфейса эмулятора: ru/en).
 *
 * Печатает все ключи одной строкой "[TP] key=value" (null печатается как
 * "<null>" — grep его ловит), затем notifyDestroyed() — чистое завершение
 * сессии. Запускается ДВАЖДЫ одним процессом: до и после MINUS-тоггла языка
 * в меню — вторая сессия обязана увидеть ДРУГОЙ locale.
 *
 * Driven by scripts/test_switch_props.sh.
 */
public class TestProps extends MIDlet {

    static final String[] KEYS = {
        "microedition.locale",
        "microedition.platform",
        "microedition.profiles",
        "microedition.configuration",
        "java.name",
        "java.version",
        "java.vendor",
        "java.vm.name",
        "java.vm.vendor",
        "java.vm.version",
        "device.vendor",
        "device.model",
        "device.imei",
        "java.heap.size",
        "java.heap.free",
        "java.stack.size"
    };

    protected void startApp() {
        System.out.println("[TP] start");
        for (int i = 0; i < KEYS.length; i++) {
            String v = null;
            try {
                v = System.getProperty(KEYS[i]);
            } catch (Throwable t) {
                System.out.println("[TP] " + KEYS[i] + "=<throw " + t + ">");
                continue;
            }
            System.out.println("[TP] " + KEYS[i] + "=" + (v == null ? "<null>" : v));
        }
        try {
            Runtime rt = Runtime.getRuntime();
            System.out.println("[TP] rt.totalMemory=" + rt.totalMemory());
            System.out.println("[TP] rt.freeMemory=" + rt.freeMemory());
        } catch (Throwable t) {
            System.out.println("[TP] rt=<throw " + t + ">");
        }
        System.out.println("[TP] done");
        notifyDestroyed();
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) {}
}
