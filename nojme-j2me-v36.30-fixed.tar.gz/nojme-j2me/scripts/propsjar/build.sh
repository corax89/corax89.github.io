#!/bin/bash
# Build TestProps.jar — v36.25 [SYSPROPS] selftest: a MIDlet that prints the
# compatibility system properties (java.name/java.version/java.vm.name/
# device.vendor/device.imei/java.heap.size/java.heap.free/java.stack.size,
 # microedition.locale ...) and exits via notifyDestroyed().
# Driven by scripts/test_switch_props.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestProps.java" \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TP, , TestProps\r\nMIDlet-Name: TestProps\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestProps*.class "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestProps.jar" META-INF && zip -q "$D/TestProps.jar" *.class )

echo "built: $D/TestProps.jar"
