NOJME — J2ME-эмулятор для Nintendo Switch (NRO / hbloader)
Версия: v36.25-2026-09-25

ЧТО НОВОГО В v36.25 (по сравнению с v36.24)
============================================

1) microedition.locale теперь зависит от настройки языка консоли/эмулятора
   Прежде игра всегда видела "en". Теперь:
   - язык интерфейса RU -> мидлет видит locale = "ru";
   - язык интерфейса EN -> мидлет видит locale = "en";
   - работает в обоих путях: System.getProperty() и System.getProperties().
   ПОПРАВКА СОВМЕСТИМОСТИ: если в манифесте/JAD игры заявлен список
   MIDlet-Languages и вашего языка в нём нет, игра получает "en" (или
   первый язык из списка). Причина: Treasure Towers (MIDlet-Languages:
   en,es,fr,de,it) при неподерживаемой локали пропускает собственную
   языковую инициализацию и зависает на загрузке. Игры, в которых "ru"
   заявлен, по-прежнему получают "ru".

2) Индикатор языка в левом верхнем углу сокращён
   Вместо длинной строки «Язык: Русский   минус = English» теперь только
   нарисованная SDL-кнопка MINUS (рамка + минус-полоса) и короткий код
   текущего языка («ru» / «en»). Показывается во всех экранах меню
   (главное, настройки, браузер, управление) и в меню паузы.

3) Настройка языка продублирована в общих настройках
   Меню -> Настройки -> строка «Язык интерфейса» (перед «Сохранить и
   выйти»). A / влево / вправо — переключение Русский <-> English,
   применяется сразу и сохраняется в settings.ini. Кнопка MINUS по-прежнему
   переключает язык в любом экране.

4) Установлены отсутствовавшие системные свойства (совместимость)
   Раньше ряд ключей возвращал null (а java.* вообще прятался drm-режимом
   «скрыть эмуляцию», включённым по умолчанию). Теперь ключи отдает и
   System.getProperty(), и System.getProperties():
   - java.name                = Java Platform, Micro Edition
   - java.version             = 1.4.2
   - java.vendor              = Nokia
   - java.vm.name             = CLDC-HI
   - java.vm.vendor           = Sun Microsystems Inc.
   - java.vm.version          = 1.1
   - java.vm.specification.*  = CLDC / 1.1
   - java.specification.name  = Java Platform, Micro Edition
   - java.specification.version = CLDC-1.1
   - java.stack.size          = 262144 (256 КБ на поток Java)
   - device.vendor            = Nokia
   - device.model             = Nokia N73 (drm-спуф, как прежде)
   - device.imei / phone.imei / com.nokia.mid.imei / com.nokia.mid.imsi
                             = 000000000000000 (перезаписывается drm-
                               конфигом с imei=..., как прежде)
   - java.heap.size / java.heap.free — ФАКТИЧЕСКИЙ размер/свойбодный объём
     кучи ВМ (бывшие константы-фейки totalMemory/freeMemory=1048576/524288
     заменены реальными числами; до инициализации кучи — 64 МБ)
   Прочее выровнено между путями (platform=NokiaN73-1, profiles=MIDP-2.0,
   supports.audio.capture/video.capture/recording=false — честно, как и
   было в игровом пути). Из списка скрытия убран только префикс "java.":
   значения теперь неотличимы от реального телефона. "os.", "sun.",
   "kemnn.", "emulator." и прочие детекторы скрыты по-прежнему.

СБОРКА
=======
Требуется devkitPro / devkitA64:
  make switchui
Готовый NRO: bin/nojme.nro -> скопировать в sdmc:/switch/j2me/.

СТРУКТУРА НА КАРТЕ
==================
  sdmc:/switch/j2me/nojme.nro
  sdmc:/switch/j2me/games/     (JAR/JAD)
  sdmc:/switch/j2me/settings.ini

УПРАВЛЕНИЕ (главное меню)
=========================
  A - выбрать, HOME - выход, MINUS - сменить язык (RU/EN)
  Настройки: A - изменить, B - назад.

ТЕСТЫ СОСТОЯНИЯ СБОРКИ (в песочнице, все PASSED)
=================================================
  props (новый: locale ru->en между сессиями, все ключи не-null),
  ttrelaunch, keystuck, e2e, pausemenu, rotation, ui3617, s2x, excreset,
  audiomix, badlaunch, bb3d, switch-input, soak_close 5x8с (leakv=0),
  make check (29 файлов).

ИСТОРИЯ ИЗМЕНЕНИЙ
=================
  Полная история — FIXES.txt внутри архива (СЕССИЯ 68 = v36.25).
