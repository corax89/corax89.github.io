/*
 * switch_common.h — shared settings model for the Nintendo Switch frontend.
 *
 * The Switch port (Makefile: platform=switch) is an SDL2 app: the same
 * core drives a 1280x720 window with an in-app menu system (game browser +
 * settings) implemented in src/switch/switch_ui.c. Settings persist to
 * <sdmc:/switch/j2me/settings.ini> on real hardware (plain file next to
 * the binary in non-Switch verification builds).
 */
#ifndef SWITCH_COMMON_H
#define SWITCH_COMMON_H

#include <stddef.h>

/* ---- Display scaling modes (settings item "Масштаб") ---- */
#define NOJME_SCALE_STRETCH   0  /* растянуть на весь экран (игнор пропорций) */
#define NOJME_SCALE_FIT_BLACK 1  /* пропорции сохранены, чёрный бордюр */
#define NOJME_SCALE_FIT_BLUR  2  /* пропорции сохранены, размытый фон вместо бордюра */
#define NOJME_SCALE_MODE_COUNT 3

/* ---- Game canvas filtering (settings item "Фильтр") ---- */
#define NOJME_FILTER_NEAREST 0  /* пиксельный (retro) */
#define NOJME_FILTER_LINEAR  1  /* сглаженный */
#define NOJME_FILTER_COUNT   2

/* ---- VM speed presets (settings item "Скорость VM") ----
 * Mirrors the libretro j2me_vm_speed option semantics: the value maps to
 * g_jvm_thread_budget (game-thread instruction budget per 16.6 ms slice):
 * original = 15000 (~0.9M instr/s, «телефонный» темп), fast = 90000
 * (default, ~5.4M instr/s), turbo = 0 (бюджет снят, потоки свободны). */
#define NOJME_VM_SPEED_ORIGINAL 0
#define NOJME_VM_SPEED_FAST     1
#define NOJME_VM_SPEED_TURBO    2
#define NOJME_VM_SPEED_COUNT    3

/* ---- v35.03 3D facing flip ("global flip") ----
 * Controls the M3G rasterizer facing decision. Field report: the v34.88
 * self-heal (per-PolygonMode facing inversion after sustained 100%
 * back-facing renders) is REQUIRED by some games and BREAKS the 3D of
 * others, so it is now a user setting:
 *   OFF  - never invert (self-heal disabled entirely);
 *   AUTO - v34.88 behavior: self-heal detector per PolygonMode;
 *   ON   - force-invert EVERY facing decision (for games the detector
 *          misses); the detector does not run.
 * NOJME_CULL_HEAL=0 (env) still forces OFF on desktop verification builds. */
#define NOJME_FLIP_OFF  0
#define NOJME_FLIP_AUTO 1
#define NOJME_FLIP_ON   2

/* ---- UI language (v34.90): MINUS toggles RU/EN in every frontend screen.
 * Persisted as lang=ru|en in settings.ini; NOJME_SWITCH_LANG env overrides
 * for host verification builds. ---- */
#define NOJME_LANG_RU 0
#define NOJME_LANG_EN 1

/* ---- v34.92 logging toggle (settings item "Лог") ----
 * Trace logging to sdmc:/switch/j2me/log.txt is OFF by default; the
 * settings row enables it. The enable/disable event itself always reaches
 * the log (so "logging enabled" in the log proves WHEN it was turned on). */
#define NOJME_LOGGING_DEFAULT 0

/* ---- v35.07 frame-counter overlay (settings item "Счётчик кадров") ----
 * Draws the settled-frame sequence number + its age INTO the presented
 * frame (the game texture AND the blurred fill are fed from that one
 * buffer, so the same token appears in both). Purpose: an on-device,
 * eye-decisive instrument for the "blur updates more often than the main
 * screen" reports — the counter ticks exactly when the content changes,
 * identically in the sharp image and in the blurred backdrop. */
#define NOJME_FRAME_COUNTER_DEFAULT 0

/* ---- v34.94 per-game settings (PLUS in game) ----
 * Stored per JAR in <settings_base>/pergame/<jar name>.ini. The resolution
 * override replaces the manifest hint for the canvas size; it is applied on
 * the NEXT launch of that game (the canvas is created at session start). */
typedef struct {
    int valid;               /* file existed / values loaded */
    int res_mode;            /* 0 = auto (manifest), 1 = explicit WxH */
    int res_w, res_h;        /* explicit canvas size when res_mode == 1 */
    int scale_mode;          /* -1 = inherit global setting */
    int filter;              /* -1 = inherit global setting */
    int flip_mode;           /* v35.03: -1 = inherit, else NOJME_FLIP_* */
    int vm_speed;            /* v35.09: -1 = inherit, else NOJME_VM_SPEED_*.
                              * Escape hatch for VM-budget-bound 3D games
                              * (asia rally raced at ~1 fps on "fast": the
                              * game's bytecode-side 3D math demands more
                              * instructions/s than the old fast ceiling
                              * allowed; turbo lifts the pacer entirely). */
} SwitchPerGameSettings;

#define NOJME_PERGAME_DIR "pergame"

/* ---- Switch frontend screen geometry ---- */
#define SWITCH_UI_WIDTH  1280
#define SWITCH_UI_HEIGHT 720

typedef struct {
    int scale_mode;          /* NOJME_SCALE_* */
    int filter;              /* NOJME_FILTER_* */
    int audio_enabled;       /* 1 = звук включён */
    int vm_speed;            /* NOJME_VM_SPEED_* */
    int lang;                /* NOJME_LANG_RU / NOJME_LANG_EN */
    char games_dir[512];     /* стартовая папка браузера ("" = корень SD) */
    int logging;             /* v34.92: 1 = писать log.txt (по умолч. выкл) */
    char saves_dir[512];     /* v34.92: база RMS-сохранений ("" = умолчание) */
    int flip_mode;           /* v35.03: NOJME_FLIP_* (default AUTO) */
    int frame_counter;       /* v35.07: счётчик кадров поверх кадра (по умолч. выкл) */
} SwitchSettings;

/* Defaults: fit-with-black-borders, pixel filtering, audio on, fast VM. */
void switch_settings_defaults(SwitchSettings* s);

/* Singleton: loads settings.ini on first call. NULL-safe (returns defaults
 * if the file is missing/corrupt). */
const SwitchSettings* switch_settings_get(void);

/* Update the singleton (call switch_settings_save right after to persist). */
void switch_settings_set(const SwitchSettings* s);

/* Persist to settings.ini. Returns 0 on success. */
int switch_settings_save(const SwitchSettings* s);

/* Human-readable value names for the settings UI. */
const char* switch_scale_mode_name(int mode);
const char* switch_filter_name(int filter);
const char* switch_vm_speed_name(int speed);
const char* switch_flip_mode_name(int mode); /* v35.03 */

/* v34.92: trace-logging flag for the diag gate (0/1). */
int switch_settings_logging_flag(void);

/* v34.92: base directory that hosts settings.ini (for pergame/ + log.txt).
 * Returns "" when unknown. */
const char* switch_settings_base_dir(void);

/* v34.94 per-game settings: load (or defaults when absent) for one JAR.
 * jar_path may be absolute; only the file name is used (sanitized). */
void switch_pergame_load(const char* jar_path, SwitchPerGameSettings* out);

/* v34.94 per-game settings: persist. Returns 0 on success. */
int switch_pergame_save(const char* jar_path, const SwitchPerGameSettings* s);

/* ================= v34.90 UI language (RU/EN) ================= */

/* Current language (NOJME_LANG_*). Loads with the settings singleton. */
int switch_lang(void);

/* Toggle RU <-> EN, persist to settings.ini, return the NEW value. */
int switch_lang_toggle(void);

/* "Русский" / "English" — the language's own name. */
const char* switch_lang_name(int lang);

/* Localized UI string by id (enum SwitchTextId below). */
const char* switch_text(int id);

/* One-line top-left badge: current language + the MINUS hint, e.g.
 * "Язык: Русский   минус = English". Composed in the ACTIVE language. */
const char* switch_lang_badge_text(void);

/* String ids for every user-visible frontend string (RU + EN table in
 * switch_ui.c). Drawn with the embedded 8x16 font: ASCII + Cyrillic only
 * (no em-dash/ellipsis — those glyphs are not in the font). */
enum {
    ST_APP_TITLE = 0,
    ST_MENU_OPEN,
    ST_MENU_SETTINGS,
    ST_MENU_EXIT,
    ST_MENU_TAGLINE,
    ST_FOOTER_MAIN,
    ST_BROWSER_TITLE,
    ST_BROWSER_EMPTY,
    ST_BROWSER_TRUNC,
    ST_BROWSER_DIR,
    ST_FOOTER_BROWSER,      /* counts appended with %d/%d */
    ST_SETTINGS_TITLE,
    ST_SET_SCALE,
    ST_SET_FILTER,
    ST_SET_AUDIO,
    ST_SET_VM_SPEED,
    ST_SET_GAMES_DIR,
    ST_SET_LOG,
    ST_SET_SAVE,
    ST_VAL_ON,
    ST_VAL_OFF,
    ST_PREVIEW_LABEL,
    ST_FOOTER_SETTINGS,
    ST_DIRPICKER_TITLE,
    ST_DIRPICKER_THIS,
    ST_DIRPICKER_MAKE,
    ST_FOOTER_DIRPICKER,
    ST_PAUSE_TITLE,
    ST_PAUSE_RESUME,
    ST_PAUSE_EXIT,
    ST_PG_TITLE,
    ST_PG_RES,
    ST_PG_SCALE,
    ST_PG_FILTER,
    ST_PG_SAVED,
    ST_PG_FOOTER,
    ST_RES_AUTO,
    ST_SCALE_INHERIT,
    ST_FILTER_INHERIT,
    ST_SCALE_STRETCH,
    ST_SCALE_FIT_BLACK,
    ST_SCALE_FIT_BLUR,
    ST_FILTER_LINEAR,
    ST_FILTER_NEAREST,
    ST_VM_ORIGINAL,
    ST_VM_FAST,
    ST_VM_TURBO,
    ST_SET_FLIP,
    ST_FLIP_AUTO,
    ST_PG_FLIP,
    ST_SET_FCNT,
    ST_PG_VMSPEED,
    ST_TEXT_COUNT
};

#endif /* SWITCH_COMMON_H */
