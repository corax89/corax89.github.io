/* v35.12 logic test for switch_migrate_legacy_root() — compiles the exact
 * function from switch_ui.c with sdmc: paths rewritten to a temp dir. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define LEGACY "LEGACYROOT"
#define NEWROOT "NEWROOT"

static int ui_dir_exists(const char* path) {
    DIR* d = opendir(path);
    if (!d) return 0;
    closedir(d);
    return 1;
}
static int ui_dir_entry_count(const char* path) {
    DIR* d = opendir(path);
    if (!d) return -1;
    int n = 0;
    struct dirent* de;
    while ((de = readdir(d)) != NULL) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
        n++;
    }
    closedir(d);
    return n;
}
static void mkdir_p(const char* p) { mkdir(p, 0777); }
static void touch(const char* p) { FILE* f = fopen(p, "w"); if (f) { fputs("x", f); fclose(f); } }

/* === the migration body (paths renamed, mkdir("sdmc:/switch") -> mkdir_p(NEWROOT)) === */
static int migrated = 0;
#define sw_trace(...) do { migrated = 1; } while (0)
static const char* const legacy_root = LEGACY;
static const char* const new_root    = NEWROOT;

void migrate(void) {
    static const char* const subs[] = { "games", "saves" };
    if (!ui_dir_exists(legacy_root)) return;

    mkdir_p("sdmc_parent"); /* placeholder for mkdir("sdmc:/switch") */
    if (!ui_dir_exists(new_root)) {
        if (rename(legacy_root, new_root) == 0) {
            sw_trace("migrate: whole tree");
            return;
        }
        sw_trace("migrate: whole-tree rename failed, trying subfolders");
    }
    for (size_t i = 0; i < sizeof(subs) / sizeof(subs[0]); i++) {
        char src[512], dst[512];
        snprintf(src, sizeof(src), "%s/%s", legacy_root, subs[i]);
        snprintf(dst, sizeof(dst), "%s/%s", new_root, subs[i]);
        if (!ui_dir_exists(src)) continue;
        int dst_n = ui_dir_entry_count(dst);      /* -1 = dst missing */
        if (dst_n > 0) continue;                  /* populated dst: never overwrite */
        if (rename(src, dst) == 0) {
            sw_trace("migrate: %s -> %s", src, dst);
        } else {
            sw_trace("migrate: FAILED %s -> %s", src, dst);
        }
    }
    {
        char src[512], dst[512];
        snprintf(src, sizeof(src), "%s/settings.ini", legacy_root);
        snprintf(dst, sizeof(dst), "%s/settings.ini", new_root);
        FILE* s = fopen(src, "r");
        if (s) {
            fclose(s);
            if (access(dst, F_OK) != 0 && rename(src, dst) == 0) {
                sw_trace("migrate: settings.ini");
            }
        }
    }
    rmdir(legacy_root);
}

static int fails = 0;
static void chk(int cond, const char* what) {
    if (!cond) { printf("FAIL: %s\n", what); fails++; }
    else printf("ok: %s\n", what);
}

int main(void) {
    system("rm -rf /tmp/mig_test && mkdir -p /tmp/mig_test && cd /tmp/mig_test && mkdir -p LEGACYROOT/games LEGACYROOT/saves/Store1 NEWROOT");
    if (chdir("/tmp/mig_test") != 0) return 2;
    touch("LEGACYROOT/games/a.jar");
    touch("LEGACYROOT/saves/Store1/db");
    touch("LEGACYROOT/settings.ini");

    /* case 1: no new root -> whole tree rename (well: new root EXISTS here,
     * so this exercises case 2: both roots, empty/missing dst) */
    migrate();
    chk(ui_dir_entry_count("NEWROOT/games") == 1, "games moved into new root");
    chk(ui_dir_entry_count("NEWROOT/saves") == 1, "saves moved into new root");
    chk(access("NEWROOT/settings.ini", F_OK) == 0, "settings.ini moved");
    chk(ui_dir_entry_count("LEGACYROOT") <= 0, "legacy root gone/empty");

    /* case 3: legacy games repopulated, dst populated -> no overwrite */
    system("mkdir -p LEGACYROOT/games && touch LEGACYROOT/games/b.jar");
    migrate();
    chk(ui_dir_entry_count("NEWROOT/games") == 1, "populated dst NOT overwritten");
    chk(ui_dir_entry_count("LEGACYROOT/games") == 1, "legacy folder kept");

    /* case 1 for real: no new root at all -> whole tree rename */
    system("rm -rf NEWROOT LEGACYROOT && mkdir -p LEGACYROOT/games LEGACYROOT/saves && touch LEGACYROOT/games/c.jar LEGACYROOT/settings.ini");
    migrated = 0;
    migrate();
    chk(ui_dir_entry_count("NEWROOT/games") == 1, "whole-tree rename: games");
    chk(access("NEWROOT/settings.ini", F_OK) == 0, "whole-tree rename: ini");
    chk(!ui_dir_exists("LEGACYROOT"), "whole-tree rename: legacy gone");

    printf(fails ? "\nMIGRATE: %d FAILURES\n" : "\nMIGRATE: ALL PASSED\n", fails);
    return fails ? 1 : 0;
}
