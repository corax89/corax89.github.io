#ifndef CORE_VERSION_H
#define CORE_VERSION_H

/* Bumped with every delivered source drop. Printed at startup so the log
 * PROVES which build is actually loaded — defends against stale DLL/EXE
 * copies silently running old code (seen in user debugging sessions). */
#define CORE_BUILD_ID "v35.12-2026-09-22"

#endif /* CORE_VERSION_H */
