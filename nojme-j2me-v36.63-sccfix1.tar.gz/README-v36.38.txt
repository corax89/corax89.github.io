NOJME (J2ME-эмулятор для Switch) — v36.38-Corax89
==================================================

ЭТА ВЕРСИЯ: ИСПРАВЛЕНА СБОРКА ПОД WINDOWS (MINGW32) + 2 ПРЕДУПРЕЖДЕНИЯ
----------------------------------------------------------------------
1. fatal error: cp_caches.h: No such file or directory (execute.c) — ГОТОВО
2. warning: is_heap_ptr discards 'const' qualifier (heap.c) — ГОТОВО
3. warning: null format string [-Wformat-overflow=] (debug_var.c) — ГОТОВО
Функциональных изменений НЕТ: игра/эмулятор ведут себя бит-в-бит как
v36.37 (контрольная проверка: счётчик инструкций ВМ на тесте fmx совпал
до единицы — 13 334 612).

1. «CP_CACHES.H: NO SUCH FILE OR DIRECTORY» — ПРИЧИНА И ФИКС
------------------------------------------------------------
Что случилось: сборка libretro-ядра под Windows падала на первом же
объекте с новым заголовком v36.37 — obj/libretro/jvm/execute.o, при этом
соседние файлы (heap.c, debug_var.c) собирались. Значит ключи -I из
Makefile работали, а в дереве сборки просто ОТСУТСТВОВАЛ файл
include/cp_caches.h: свежие src/ v36.37 легли поверх старого include/ от
v36.36 (либо экстрактор/антивирус потерял один файл).

Что сделано: заголовок перенесён в src/jvm/cp_caches.h — в каталог
единственных потребителей (execute.c, opcodes.c). Директива
#include "cp_caches.h" ищет файл сначала в каталоге самого .c, поэтому
ядро собирается ДАЖЕ если -I-пути потеряны или include/ рассинхронизирован.
Такая ошибка больше невоспроизводима в принципе. Никакие тексты
#include не менялись.

ВАЖНО ДЛЯ ОБНОВЛЕНИЯ: распаковывайте tarball ЦЕЛИКОМ в чистый каталог
(или удалите старое дерево). Не смешивайте src/ новой версии с include/
старой — это и было причиной.

2. HEAP.C: CONST-ПРЕДУПРЕЖДЕНИЕ
--------------------------------
is_heap_ptr теперь принимает const void* (раньше — void*, и вызов с
const-указателем из трассировки [STR-CHARS-NULL] «отбрасывал» const).
Семантика не изменилась: те же сравнения адресов с границами кучи.

3. DEBUG_VAR.C: «NULL FORMAT STRING» (ТОЛЬКО WINDOWS)
------------------------------------------------------
Функция перевода форматов для старого msvcrt (win_fmt_translate,
_WIN32-ветка) при NULL-формате возвращала NULL — а он уходил прямо в
vfprintf как строка формата (неопределённое поведение). Теперь функция
НИКОГДА не возвращает NULL: при NULL-формате печатается пустая строка,
плюс аннотация returns_nonnull сообщила об этом компилятору — все 4
места вызова чистые. На Linux/Switch эта ветка не активна (там макрос
WIN_FMT — passthrough), поведение не изменилось.

ЧТО НЕ ИЗМЕНИЛОСЬ (всё на месте из v36.37)
-------------------------------------------
- Раскладка: СТИК — цифры 2/4/6/8, КРЕСТОВИНА — стрелки; настройка
  «Поменять местами стик и D-pad» инвертирует их мгновенно;
- «Мёртвая зона стика» 0..90% (по умолчанию 50%) — обход дрейфа;
- Скроллящийся список настроек (10 строк, справка ниже списка);
- Версия вида «v36.38-Corax89» в меню/баннере/libretro-логе;
- ~40 инлайновых опкодов интерпретатора (ускорение Alien Shooter 3D и
  других софт-3D мидлетов), mp3 (minimp3), R2 = «0», звук Вкл / FPS Выкл.

КАК ПРОВЕРИТЬ
-------------
- make (под MSYS2/MinGW) — сборка доходит до bin/nojme_libretro.dll без
  fatal error; предупреждений из heap.c/debug_var.c больше нет.
- Версия в главном меню: core v36.38-Corax89.

СОСТАВ ПАКЕТА
-------------
- src/, include/, Makefile — исходники (CORE_BUILD_ID v36.38-Corax89);
- FIXES.txt — полная инженерная запись СЕССИЯ 80 (+ вся история);
- scripts/ — регресс-набор, заглушка winstub/windows.h и
  test_winfmt_extract.sh (проверка _WIN32-ветки на Linux-хосте);
- README-v36.38.txt — этот файл.

СБОРКА
------
Windows (MSYS2/MinGW, дефолт):
  make                  # bin/nojme_libretro.dll (+ import-lib)
Switch (devkitPro):
  make switch           # NRO: nojme.nro -> sdmc:/switch/j2me/
Проверочные хост-сборки:
  make headless         # bin/j2me-headless (автотесты)
  make platform=linux   # libretro-ядро (.so)

РЕГРЕСС (все зелёные в этой сборке)
-----------------------------------
reg_chunk1 (TestFinish пиксельный, TestBack, TestAudio спектр x6+MIDI+tone,
self-heal), reg_chunk2 (TestRMS 33/33, TestAnim 18/18, frame-limit 30->60,
headless-smoke 10 игр), reg_chunk3 (test49/test58 IDENTICAL, Nescube
ChoiceGroup+RMS), reg_chunk4 (Asphalt 900 кадров FRAMEDIFF, fmx A/B
инструкции 13334612==13334612), reg_chunk5 (gc_stress, AMR selfcheck
бит-в-бит, sweep маркеров 0); make check 30 файлов. Полная батарея
предыдущих сессий (e2e, metests, dpad, keystuck, touch, pausemenu,
rotation, hotrot, flipfps, badlaunch, excreset, props, sysinfo, fpsstrip,
s2x, fontform, ui3617, bb3d, ttrelaunch, zuma, miditempo, audiomix,
two_sessions, input, games3) — без изменений кода, затрагивающего её
поверхность.

ИЗВЕСТНОЕ (без изменений)
-------------------------
- Temple Rush session-2 OOM — не воспроизводится, мониторим;
- «4 FPS» в тяжёлых софт-3D играх на Switch — лимит CPU A57 при
  Java-растеризации (см. README-v36.37, раздел 6); Турбо снимает
  троттлинг песочницы, дальнейшее ускорение — стоимость опкода на ARM.
