#!/bin/bash
# v36.55/v36.62 [M3G-COV-OPAQUE] автотест CovStageTest (scripts/covstage/):
# 3 фазы на канве 240x320 через фронтенд switchui-verify (как BindStageTest
# исторически). Проверки:
#   A) дефолт: лог-строки [M3G-VIEWPORT-FRESH] трёх фаз («0/76800»,
#      «72704/4096», «76800/0»), COVSTAGE:DONE, 0 EXC + пиксельные окна
#      BMP-дампов (фон фазы 1 / белый-kept + чёрный красный регион фазы 2 /
#      целиком чёрная фаза 3);
#   B) A/B NOJME_M3G_COV_OPAQUE=0 (прямая v36.54): лог «68608/8192» +
#      красный регион в дампах НЕ чёрный (ползучесть яркости — ореолы);
#   C) A/B NOJME_M3G_BIND_FRESH=0: строк [M3G-VIEWPORT-FRESH] нет вовсе.
# Дампы M3G_CAPTURE пишутся в /home/z/my-project/download/m3g_rt_*.bmp —
# чистим до и после.
set -e
cd "$(dirname "$0")/.." || exit 1
T=$(pwd)
BIN="$T/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (scripts/build_verify_host.sh)"; exit 1; }
JAR="$T/scripts/covstage/CovStageTest.jar"
[ -f "$JAR" ] || bash "$T/scripts/covstage/build.sh" >/dev/null

run_case() { # $1 = имя, $2.. = доп. env
    local name="$1"; shift
    local W
    W=$(mktemp -d "/tmp/covstage_${name}.XXXX")
    mkdir -p "$W/sdmc:/switch/j2me/games"
    cp "$JAR" "$W/sdmc:/switch/j2me/games/"
    rm -f /home/z/my-project/download/m3g_rt_*.bmp
    (
        cd "$W" || exit 1
        export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
        export NOJME_LOG=1 NOJME_LOGGING=1
        export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
        export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
        # A (браузер) -> A (запуск CovStageTest) -> 240 кадров (12-18 c) ->
        # меню -> EXIT. Если EXIT проглочен игрой — таймаут снимет процесс.
        export NOJME_SWITCH_KEYS="A:500,A:500,EXIT:30000"
        export M3G_CAPTURE=250
        env "$@" timeout -k 5 55 "$BIN" > out.log 2>&1 || true
    )
    cp "$W/out.log" "/tmp/covstage_${name}.log"
    rm -rf "$W"
}

echo "=== A) дефолт (v36.55 opaque-семантика) ==="
run_case default
L=/tmp/covstage_default.log
grep -q "COVSTAGE:DONE n=239 PASSED" "$L" || { echo "FAIL: нет COVSTAGE:DONE PASSED"; grep "COVSTAGE" "$L" | tail -5; exit 1; }
grep -q "COVSTAGE: EXC" "$L" && { echo "FAIL: исключения в тесте"; exit 1; }
grep -q "0 px fresh-black, 76800 kept" "$L" || { echo "FAIL: фаза 1 не дала 0/76800 kept"; exit 1; }
grep -q "72704 px fresh-black, 4096 kept" "$L" || { echo "FAIL: фаза 2 не дала 72704/4096 (сеётся только непрозрачный блок)"; grep "VIEWPORT-FRESH" "$L" | tail -6; exit 1; }
grep -q "76800 px fresh-black, 0 kept" "$L" || { echo "FAIL: фаза 3 не дала 76800/0"; exit 1; }
echo "  лог-фазы: ok ($(grep -c 'M3G-VIEWPORT-FRESH' "$L") строк)"
python3 "$T/scripts/test_m3g_covstage_check.py" default || exit 1

echo "=== B) A/B: NOJME_M3G_COV_OPAQUE=0 (прямоугольная v36.54) ==="
run_case ab NOJME_M3G_COV_OPAQUE=0
L=/tmp/covstage_ab.log
grep -q "COVSTAGE:DONE n=239 PASSED" "$L" || { echo "FAIL: нет COVSTAGE:DONE PASSED (B)"; exit 1; }
grep -q "68608 px fresh-black, 8192 kept" "$L" || { echo "FAIL: A/B не воспроизвёл v36.54 (68608/8192)"; grep "VIEWPORT-FRESH" "$L" | tail -6; exit 1; }
grep -q "72704 px fresh-black, 4096 kept" "$L" && { echo "FAIL: в A/B просочилась дефолтная семантика"; exit 1; }
echo "  лог-фазы A/B: ok (68608/8192 — оба блока сеются)"
python3 "$T/scripts/test_m3g_covstage_check.py" ab_opaque || exit 1

echo "=== C) A/B: NOJME_M3G_BIND_FRESH=0 (весь свежий посев выкл) ==="
run_case bf NOJME_M3G_BIND_FRESH=0
L=/tmp/covstage_bf.log
N=$(grep -c "M3G-VIEWPORT-FRESH" "$L" || true)
[ "$N" = "0" ] || { echo "FAIL: BIND_FRESH=0 дал $N строк свежего посева"; exit 1; }
grep -q "COVSTAGE:DONE n=239 PASSED" "$L" || { echo "FAIL: нет COVSTAGE:DONE PASSED (C)"; exit 1; }
echo "  строк свежего посева: 0 (как ожидалось)"

rm -f /home/z/my-project/download/m3g_rt_*.bmp
echo "COVSTAGE: ALL CHECKS PASSED"
