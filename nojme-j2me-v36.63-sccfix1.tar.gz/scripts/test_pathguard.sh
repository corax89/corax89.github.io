#!/bin/bash
# [PATHGUARD] v36.52 unit test — см. test_pathguard.c. Компилируется с
# -DNOJME_SWITCH_TRACE против РЕАЛЬНОГО pathguard.c дерева (тот же код,
# что в NRO): иглы полевых адресов, slab+fopen, [FILEOP] n21, [PTRSCAN]
# SLOT/benign/str-raw в стеке, BSS и WATCH-регионах, кламп stale-WATCH
# ниже пола скана, rename-why при отказе rename. Отдельно: pathguard.h
# БЕЗ гейта даёт макро-пасс-through (общие исходники main.c/rms.c линкуются
# без pathguard.c). И символы прибора в verify-бинарнике.
set -e
cd "$(dirname "$0")/.." || exit 1
T=/tmp/pg_test
mkdir -p "$T"

echo "--- 1. unit: pathguard.c с гейтом (реальный прибор) ---"
# v36.60 [PSCAN-FLAG]: сканер опционален (env NOJME_PG_SCAN / файл-флаг
# pg.flag). Юнит-тест проверяет ПОВЕДЕНИЕ сканера — запускаем с включённым
# режимом; отдельная секция 1b проверяет гейт по умолчанию.
gcc -std=c11 -Wall -Wextra -g -O1 -DNOJME_SWITCH_TRACE \
    -Isrc -Isrc/include -Iinclude \
    -o "$T/test_pathguard" scripts/test_pathguard.c src/switch/pathguard.c -lpthread
NOJME_PG_SCAN=1 "$T/test_pathguard"

echo "--- 1b. v36.60 [PSCAN-FLAG]: гейт сканера по умолчанию ВЫКЛ ---"
cat > "$T/gate.c" << 'EOF'
/* Гейт-тест v36.60: БЕЗ env NOJME_PG_SCAN сканер спит, бейджи живут.
 * С env — сканер просыпается. Вывод прибора капчурится хуком. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "switch/pathguard.h"

/* стаб sw_trace_force — как в test_pathguard.c */
void sw_trace_force(const char* fmt, ...) { (void)fmt; }

static char g_out[8192];
static void hook(const char* line) {
    if (strlen(g_out) < sizeof(g_out) - 256)
        snprintf(g_out + strlen(g_out), 256, "%s\n", line);
}
int main(void) {
    const char* tf = "/tmp/pg_gate_test.ini";
    FILE* w = fopen(tf, "w");
    if (w) { fputs("gate=1\n", w); fclose(w); }

    nojme_pg_set_report_hook(hook);

    /* слот-яд в куче + WATCH: без гейта это дало бы [PTRSCAN] SLOT */
    unsigned long long needle = nojme_pg_needle(
        "sdmc:/switch/j2me/games/Yeti Sports (240x320).jar");
    unsigned char watched[256];
    memset(watched, 0, sizeof(watched));
    memcpy(watched + 64, &needle, 8);
    nojme_pg_watch("gate:watch", watched, sizeof(watched));

    int scan_on = nojme_pg_scan_enabled();
    FILE* r = nojme_pg_fopen("gate-open", tf, "r");
    if (r) fclose(r);
    nojme_pg_ptrscan("gate-scan",
                     "sdmc:/switch/j2me/games/Yeti Sports (240x320).jar");
    nojme_pg_set_report_hook(NULL);

    const char* env = getenv("NOJME_PG_SCAN");
    int env_on = (env && env[0] && env[0] != '0');
    if (env_on != scan_on) {
        printf("FAIL: scan_enabled=%d при env=%d\n", scan_on, env_on);
        return 1;
    }
    int has_ptrscan = strstr(g_out, "[PTRSCAN]") != NULL;
    if (has_ptrscan != env_on) {
        printf("FAIL: [PTRSCAN]=%d при env=%d\n", has_ptrscan, env_on);
        return 1;
    }
    if (!strstr(g_out, "[FILEOP]")) {
        printf("FAIL: [FILEOP]-бейдж должен печататься ВСЕГДА\n");
        return 1;
    }
    printf("GATE %s: scan_enabled=%d, [PTRSCAN]=%d, [FILEOP]=on — OK\n",
           env_on ? "ON " : "OFF", scan_on, has_ptrscan);
    return 0;
}
EOF
gcc -std=c11 -Wall -Wextra -g -O1 -DNOJME_SWITCH_TRACE \
    -Isrc -Isrc/include -Iinclude \
    -o "$T/gate" "$T/gate.c" src/switch/pathguard.c -lpthread
env -u NOJME_PG_SCAN "$T/gate" || { echo "FAIL: гейт ВЫКЛ по умолчанию"; exit 1; }
NOJME_PG_SCAN=1 "$T/gate" || { echo "FAIL: гейт ВКЛ по env"; exit 1; }

echo "--- 2. pass-through: pathguard.h без гейта (макро) ---"
cat > "$T/passthrough.c" <<'EOF'
#include <stdio.h>
#include <sys/stat.h>
#include "switch/pathguard.h"
int main(void) {
    /* все обёртки обязаны разворачиваться в прямые вызовы libc —
     * этот TU линкуется БЕЗ pathguard.c */
    FILE* f = nojme_pg_fopen("x", "/etc/hostname", "r");
    int ok = (f != NULL);
    if (f) fclose(f);
    struct stat st;
    nojme_pg_stat("x", "/tmp", &st);
    return ok ? 0 : 1;
}
EOF
gcc -std=c11 -Wall -Wextra -O1 -Isrc -Isrc/include -Iinclude \
    -o "$T/passthrough" "$T/passthrough.c"
"$T/passthrough" && echo "PATHGUARD PASSTHROUGH: OK" \
    || { echo "FAIL: pass-through"; exit 1; }

echo "--- 3. сильные символы прибора в verify-бинарнике ---"
nm bin/switchui-verify | grep -q "nojme_pg_fopen" \
    || { echo "FAIL: нет nojme_pg_fopen в bin/switchui-verify"; exit 1; }
nm bin/switchui-verify | grep -q "nojme_pg_ptrscan" \
    || { echo "FAIL: нет nojme_pg_ptrscan в bin/switchui-verify"; exit 1; }
echo "PATHGUARD E2E SYMBOLS: OK"
