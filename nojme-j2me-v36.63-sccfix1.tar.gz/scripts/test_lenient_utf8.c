/*
 * test_lenient_utf8.c — [LENIENT-UTF8] v36.53 (восстановлен в v36.62)
 * unit test: компилируется против РЕАЛЬНОГО src/jvm/charset.c.
 *
 * Семантика KVM телефонов (2005 г.), на которой построены побайтовые
 * шифры-заменители переводов (Doom RPG [Rus] Corax89):
 *   - осиротевший lead-байт (2/3/4-байтовый, continuation нет),
 *     одиночный continuation-байт (0x80-0xBF) и lead 0xF8-0xFF
 *     проходят НАСКВОЗЬ как (char)b — byte-to-char widening;
 *   - валидные 2/3/4-байтовые последовательности и CESU-8 сурогаты —
 *     декодируются как раньше (в т.ч. 4-байтовые -> сурогатная пара);
 *   - C0 80 -> U+0000 (modified UTF-8);
 *   - overlong-формы (валидная форма, кривой payload) -> U+FFFD;
 *   - max_units-инвариант: out <= nbytes для UTF-8 (пасстрю не
 *     превышает worst case 1 unit/byte);
 *   - ISO-8859-1 нетронут (1:1 widening, как всегда).
 */
#include <stdio.h>
#include <string.h>

#include "jvm.h"          /* jchar/jint базовые типы */
#include "charset.h"      /* JCharsetId, jcharset_* */

static int fails = 0;
static int checks = 0;
#define CHECK(cond, msg) do { \
    checks++; \
    if (!(cond)) { printf("FAIL: %s\n", msg); fails++; } \
    else { printf("ok: %s\n", msg); } \
} while (0)

/* Декодировать и сверить с ожидаемой строкой char'ов. */
static int dec_eq(JCharsetId cs, const uint8_t* src, int n,
                  const jchar* expect, int en, const char* msg) {
    jchar out[64];
    int cap = (int)(sizeof(out) / sizeof(out[0]));
    int nout = (int)jcharset_decode(cs, src, n, out, cap);
    if (nout != en) {
        printf("FAIL: %s (len %d != %d)\n", msg, nout, en);
        checks++; fails++;
        return 0;
    }
    for (int i = 0; i < en; i++) {
        if (out[i] != expect[i]) {
            printf("FAIL: %s (unit %d: %04X != %04X)\n",
                   msg, i, (unsigned)out[i], (unsigned)expect[i]);
            checks++; fails++;
            return 0;
        }
    }
    printf("ok: %s\n", msg);
    checks++;
    return 1;
}

int main(void) {
    /* --- 1..5: пасстрю malformed-входа (ядро фикса) --- */
    {   /* 1: осиротевший 2-байтовый lead — байт шифра 0xC0 перед 'A'
         * (Doom RPG: 0xC0 = «В»; continuation-байтов в шифре НЕТ) */
        static const uint8_t b[] = { 0xC0, 0x41 };
        static const jchar e[] = { 0x00C0, 0x0041 };
        dec_eq(JCS_UTF8, b, 2, e, 2, "1: orphan 2-byte lead passthrough");
    }
    {   /* 2: осиротевший 3-байтовый lead (0xE0..0xEF без continuation) */
        static const uint8_t b[] = { 0xE7, 0x41 };
        static const jchar e[] = { 0x00E7, 0x0041 };
        dec_eq(JCS_UTF8, b, 2, e, 2, "2: orphan 3-byte lead passthrough");
    }
    {   /* 3: осиротевший 4-байтовый lead (0xF0..0xF7 без continuation) */
        static const uint8_t b[] = { 0xF4, 0x41, 0x42 };
        static const jchar e[] = { 0x00F4, 0x0041, 0x0042 };
        dec_eq(JCS_UTF8, b, 3, e, 3, "3: orphan 4-byte lead passthrough");
    }
    {   /* 4: одиночный continuation-байт 0x80-0xBF */
        static const uint8_t b[] = { 0x80, 0xBF, 0x00 };
        static const jchar e[] = { 0x0080, 0x00BF, 0x0000 };
        dec_eq(JCS_UTF8, b, 3, e, 3, "4: lone continuation passthrough");
    }
    {   /* 5: lead 0xF8-0xFF (за пределами UTF-8) */
        static const uint8_t b[] = { 0xF8, 0xFF, 0x41 };
        static const jchar e[] = { 0x00F8, 0x00FF, 0x0041 };
        dec_eq(JCS_UTF8, b, 3, e, 3, "5: lead F8-FF passthrough");
    }

    /* --- 6..9: валидные последовательности НЕ ИЗМЕНЕНЫ --- */
    {   /* 6: валидный 2-байтовый: D0 BF = U+043F («п») */
        static const uint8_t b[] = { 0xD0, 0xBF };
        static const jchar e[] = { 0x043F };
        dec_eq(JCS_UTF8, b, 2, e, 1, "6: valid 2-byte U+043F");
    }
    {   /* 7: валидный 3-байтовый: E4 B8 AD = U+4E2D */
        static const uint8_t b[] = { 0xE4, 0xB8, 0xAD };
        static const jchar e[] = { 0x4E2D };
        dec_eq(JCS_UTF8, b, 3, e, 1, "7: valid 3-byte U+4E2D");
    }
    {   /* 8: русская фраза «Привет» (12 байт -> 6 char) */
        static const uint8_t b[] = {
            0xD0,0x9F, 0xD1,0x80, 0xD0,0xB8, 0xD0,0xB2, 0xD0,0xB5, 0xD1,0x82
        };
        static const jchar e[] = { 0x041F,0x0440,0x0438,0x0432,0x0435,0x0442 };
        dec_eq(JCS_UTF8, b, 12, e, 6, "8: valid UTF-8 russian phrase");
    }
    {   /* 9: валидный 4-байтовый: U+1F600 -> сурогатная пара D83D DE00 */
        static const uint8_t b[] = { 0xF0, 0x9F, 0x98, 0x80 };
        static const jchar e[] = { 0xD83D, 0xDE00 };
        dec_eq(JCS_UTF8, b, 4, e, 2, "9: valid 4-byte -> surrogate pair");
    }

    /* --- 10..12: границы leniency --- */
    {   /* 10: C0 80 -> U+0000 (modified UTF-8), не пасстрю и не FFFD */
        static const uint8_t b[] = { 0xC0, 0x80 };
        static const jchar e[] = { 0x0000 };
        dec_eq(JCS_UTF8, b, 2, e, 1, "10: C0 80 -> U+0000");
    }
    {   /* 11: overlong-формы -> U+FFFD (форма валидна, payload кривой):
         * C1 8F (cp=0x0F < 0x80), E0 80 80 (cp=0 < 0x800),
         * F0 80 80 80 (cp=0 < 0x10000) */
        static const uint8_t b1[] = { 0xC1, 0x8F, 0x41 };
        static const jchar e1[] = { 0xFFFD, 0x0041 };
        dec_eq(JCS_UTF8, b1, 3, e1, 2, "11a: overlong 2-byte -> FFFD");
        static const uint8_t b2[] = { 0xE0, 0x80, 0x80 };
        static const jchar e2[] = { 0xFFFD };
        dec_eq(JCS_UTF8, b2, 3, e2, 1, "11b: overlong 3-byte -> FFFD");
        static const uint8_t b3[] = { 0xF0, 0x80, 0x80, 0x80 };
        static const jchar e3[] = { 0xFFFD };
        dec_eq(JCS_UTF8, b3, 4, e3, 1, "11c: overlong 4-byte -> FFFD");
    }
    {   /* 12: обрезанный хвост: валидный lead в самом конце буфера —
         * пасстрю (осиротевший), НЕ FFFD */
        static const uint8_t b[] = { 0x41, 0xD0 };
        static const jchar e[] = { 0x0041, 0x00D0 };
        dec_eq(JCS_UTF8, b, 2, e, 2, "12: truncated tail passthrough");
    }

    /* --- 13..14: CESU-8 и шифр Doom RPG целиком --- */
    {   /* 13: CESU-8 сурогат: ED A0 BD -> D83D (3-байтовый путь
         * пропускает cp >= 0x800, включая сурогаты) */
        static const uint8_t b[] = { 0xED, 0xA0, 0xBD };
        static const jchar e[] = { 0xD83D };
        dec_eq(JCS_UTF8, b, 3, e, 1, "13: CESU-8 surrogate passthrough");
    }
    {   /* 14: паттерн шифра Doom RPG [Rus]: смесь ASCII-двойников и
         * одиночных байтов 0xC0-0xFC — длина 1:1, каждый байт -> char.
         * «го о о омки» больше не появляется. */
        static const uint8_t b[] = { 'g','o','l','o','v','o',0xEB,'o','m','k','i' };
        static const jchar e[] = { 'g','o','l','o','v','o',0x00EB,'o','m','k','i' };
        dec_eq(JCS_UTF8, b, 11, e, 11, "14: DoomRPG cipher bytes 1:1 widening");
    }

    /* --- 15: max_units-инвариант (пасстрю не превышает worst case) --- */
    {
        static const uint8_t b[300]; /* все нули -> валидный ASCII */
        jchar out[300];
        for (int i = 0; i < 300; i++) out[i] = (jchar)0xAAAA;
        int n = (int)jcharset_decode(JCS_UTF8, b, 300, out, 300);
        CHECK(n == 300, "15: max_units invariant (all-ASCII)");
        /* весь буфер из осиротевших lead'ов: каждый байт -> ровно 1 unit */
        uint8_t bad[64];
        for (int i = 0; i < 64; i++) bad[i] = (uint8_t)(0xC0 + (i & 0x3F));
        n = (int)jcharset_decode(JCS_UTF8, bad, 64, out, 64);
        CHECK(n == 64, "15b: max_units invariant (all-malformed passthrough)");
    }

    /* --- 16: ISO-8859-1 нетронут: 1:1 widening как всегда --- */
    {
        static const uint8_t b[] = { 0x41, 0xB2, 0xFF, 0x80 };
        static const jchar e[] = { 0x0041, 0x00B2, 0x00FF, 0x0080 };
        dec_eq(JCS_ISO8859_1, b, 4, e, 4, "16: ISO-8859-1 1:1 untouched");
    }

    /* --- 17: энкодер UTF-8 нетронут (round-trip widening не влияет) --- */
    {
        static const jchar s[] = { 0x041F, 0x0440, 0x0041 };
        uint8_t out[16];
        int n = (int)jcharset_encode(JCS_UTF8, s, 3, out, sizeof(out));
        static const uint8_t e[] = { 0xD0,0x9F, 0xD1,0x80, 0x41 };
        CHECK(n == 5 && memcmp(out, e, 5) == 0, "17: UTF-8 encoder untouched");
    }

    printf("lenient-utf8 unit: %d checks, %d failures\n", checks, fails);
    return fails ? 1 : 0;
}
