#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Пиксельные проверки [NO-DIRICON] v36.61 (test_switch_nodiricon.sh).

  2) 0 пикселей COL_ACCENT2 (0x1B,0x4F,0xA8) во ВСЕХ дампах — синий
     контур значка-папки исчез (до фикса — 5 линий на каждую папку);
  3) positive-сигнал: в КАКОМ-ТО дампе есть БЕЛЫЙ value-текст выделенной
     строки в правой зоне (x 1000..1240): «каталог»/«JAR» рисуется
     COL_SEL_FG на полосе выделения; главное меню value не рисует
     вовсе — значит это точно строки браузера;
  4) папки не «пропали целиком»: белые пиксели текста COL_TEXT в зоне
     меток строк (x 40..600, y 130..660) есть в том же дампе.
"""
import glob
import sys

from PIL import Image

COL_ACCENT2 = (0x1B, 0x4F, 0xA8)   # синий контур значка-папки (удалён)
COL_SEL_FG  = (0xFF, 0xFF, 0xFF)   # value выделенной строки («каталог»)
COL_TEXT    = (0xE8, 0xEC, 0xF4)   # метки строк
TOL = 6


def near(p, ref):
    return all(abs(p[i] - ref[i]) <= TOL for i in range(3))


def count_in(im, box, ref):
    x0, y0, x1, y1 = box
    px = im.load()
    n = 0
    for y in range(y0, y1):
        for x in range(x0, x1):
            if near(px[x, y], ref):
                n += 1
    return n


def main():
    dump_dir, n_expect = sys.argv[1], int(sys.argv[2])
    files = sorted(glob.glob(dump_dir + "/ui_*.ppm"))
    if len(files) < 2:
        print("FAIL: мало дампов (%d)" % len(files))
        return 1

    # --- 2) синего 0xFF1B4FA8 нигде ---
    blue_total = 0
    for f in files:
        im = Image.open(f).convert("RGB")
        if im.size != (1280, 720):
            print("FAIL: размер дампа %s = %s (ожидался 1280x720)" % (f, im.size))
            return 1
        blue_total += count_in(im, (0, 0, 1280, 720), COL_ACCENT2)
    print("пикселей COL_ACCENT2 во всех дампах: %d" % blue_total)
    if blue_total != 0:
        print("FAIL: синий контур значка-папки всё ещё рисуется")
        return 1

    # --- 3)+4) браузер живой: value выделенной строки и метки строк ---
    value_ok = label_ok = False
    for f in files:
        im = Image.open(f).convert("RGB")
        if count_in(im, (1000, 130, 1240, 660), COL_SEL_FG) > 40:
            value_ok = True
            if count_in(im, (40, 130, 600, 660), COL_TEXT) > 40:
                label_ok = True
    if not value_ok:
        print("FAIL: ни в одном дампе нет белого value выделенной строки — браузер не отрисован?")
        return 1
    if not label_ok:
        print("FAIL: ни в одном дампе нет текста строк списка")
        return 1

    print("ALL PASSED: значок-папка исчез (%d синих пикселей), строки браузера и value выделенной строки на месте"
          % blue_total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
