#!/bin/bash
# [BATFIX] v36.41 E2E: J2ME battery APIs + правый-верхний-угол индикатор.
#
# Запрос пользователя: «добавь настройку с показом заряда аккумулятора,
# с вариантами: не показывать, значек, цифра и реализуй показ заряда в
# правом верхнем углу. Так же реализуй возможность чтения заряда внутри
# j2me через один или несколько АПИ.»
#
# Проверяет ТРИ среза:
#  1) J2ME API: TestBattery.jar (scripts/battjar) читает System.getProperty
#     (batterylevel / com.nokia.mid.batterylevel / nojme.batterylevel /
#     nojme.battery.charging) и класс nojme.device.Battery (getLevel() /
#     isCharging()). Хост-мок NOJME_BATTERY_MOCK=63:c => все строки обязаны
#     вернуть 63 / 1 / true.
#  2) Оверлей ИГРОВОГО кадра: trace «battery: overlay number 63% ...» в
#     log.txt (ini battery=number) — proves путь present_game.
#  3) Бейдж МЕНЮ: NOJME_UI_DUMP_DIR захватывает канву меню — пиксель-тест
#     правого верхнего угла (плашка + жёлто-зелёный текст + молния
#     зарядки) на ДВУХ режимах (number здесь, icon — в setexit-тесте).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/sw_batt
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/uidump"
cp scripts/battjar/TestBattery.jar "$D/roms/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_black
filter=nearest
audio=on
vm_speed=turbo
logging=on
battery=number
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_BATTERY_MOCK=63:c
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_UI_DUMP_DIR="$D/uidump"
export NOJME_UI_DUMP_MAX=60
export XDG_DATA_HOME="$D/xdg"
# A@1200 (браузер), A@1700 (запуск TestBattery), EXIT@11700
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:10000"

timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
rc=$?
echo "exit code: $rc (0 — чистый выход; 124 — таймаут, см. логи)"
ok=1

ALL="$D/log.txt $D/err.log $D/out.log"

# --- 1) сессия TestBattery чисто прошла все пути чтения заряда ---
N_START=$(grep -ahc "TB] start" $ALL | awk '{s+=$1} END {print s+0}')
[ "$N_START" = "1" ] || { echo "FAIL: ожидалась 1 сессия TestBattery, в логе $N_START"; ok=0; }
N_DONE=$(grep -ahc "TB] done" $ALL | awk '{s+=$1} END {print s+0}')
[ "$N_DONE" = "1" ] || { echo "FAIL: сессия не дошла до [TB] done"; ok=0; }

grep -ahq "TB] batterylevel=63" $ALL || { echo "FAIL: System.getProperty(batterylevel) != 63"; ok=0; }
grep -ahq "TB] com.nokia.mid.batterylevel=63" $ALL || { echo "FAIL: com.nokia.mid.batterylevel != 63"; ok=0; }
grep -ahq "TB] nojme.batterylevel=63" $ALL || { echo "FAIL: nojme.batterylevel != 63"; ok=0; }
grep -ahq "TB] nojme.battery.charging=1" $ALL || { echo "FAIL: nojme.battery.charging != 1"; ok=0; }
grep -ahq "TB] Battery.getLevel()=63" $ALL || { echo "FAIL: nojme.device.Battery.getLevel() != 63"; ok=0; }
grep -ahq "TB] Battery.isCharging()=true" $ALL || { echo "FAIL: nojme.device.Battery.isCharging() != true"; ok=0; }
if grep -ahq "TB].*<null>\|TB].*<throw" $ALL; then
  echo "FAIL: null/throw среди строк [TB]:"; grep -ah "TB].*<null>\|TB].*<throw" $ALL | sed 's/^/    /'; ok=0
fi

# --- 2) оверлей игрового кадра включился и виден в трассе ---
grep -ahq "battery: overlay number 63% charging=1 src=env" "$D/log.txt" || {
  echo "FAIL: нет трассы «battery: overlay number 63% charging=1 src=env» в log.txt"; ok=0; }

# --- 3) бейдж меню: пиксель-тест правого верхнего угла (режим «цифра») ---
# v36.43 [BATT-DEBOLT]: молнии больше нет; advance глифа 9px => «63%»
# scale2 = 54px; плашка = 54 + 2*12(поля) = 78, px = 1280-78-16 = 1186, py = 8.
# Текст «63%» начинается на cx = px+12 = 1198 (63% > 40 => зелёный 0x3DDC84).
python3 - "$D/uidump" <<'PYEOF'
import sys, glob, os
d = sys.argv[1]
files = sorted(glob.glob(os.path.join(d, "ui_*.ppm")))
if not files:
    print("FAIL: нет дампов канвы меню (NOJME_UI_DUMP_DIR)")
    sys.exit(1)
f = files[0]
with open(f, "rb") as fh:
    data = fh.read()
# P6 header: "P6\n1280 720\n255\n"
parts = data.split(b"\n", 3)
w, h = map(int, parts[1].split())
assert (w, h) == (1280, 720), (w, h)
px_data = parts[3]

def pix(x, y):
    o = (y * w + x) * 3
    return (px_data[o], px_data[o+1], px_data[o+2])

PX, PY, PW, PH = 1186, 8, 78, 44
ok = True
# рамка плашки
if pix(PX, PY) != (42, 48, 64):
    print("FAIL: рамка плашки не на (%d,%d): %s" % (PX, PY, pix(PX, PY))); ok = False
# тёмная подложка
if pix(PX + 2, PY + 20) != (16, 19, 26):
    print("FAIL: подложка плашки не тёмная: %s" % (pix(PX + 2, PY + 20),)); ok = False
# зелёный текст «63%» где-то в плашке (63% > 40 => зелёный 0x3DDC84)
green = any(pix(x, y) == (61, 220, 132)
            for x in range(PX + 12, PX + PW - 4) for y in range(PY + 6, PY + PH - 6))
if not green:
    print("FAIL: в плашке нет зелёных пикселей текста «63%»"); ok = False
# v36.43 [BATT-DEBOLT]: БЕЛЫХ пикселей в плашке быть НЕ должно (молния
# удалена; зелёный текст — единственный светлый элемент)
white = any(pix(x, y) == (255, 255, 255)
            for x in range(PX + 1, PX + PW - 1) for y in range(PY + 1, PY + PH - 1))
if white:
    print("FAIL: в плашке есть белые пиксели — молния не удалена? [BATT-DEBOLT]"); ok = False
# левее плашки рамки нет (плашка не шире расчётной)
if pix(PX - 1, PY + 20) == (42, 48, 64):
    print("FAIL: рамка плашки шире расчётной"); ok = False
print(("badge pixels: OK (%s)" % os.path.basename(f)) if ok else "badge pixels: FAIL")
sys.exit(0 if ok else 1)
PYEOF
[ $? -eq 0 ] || ok=0

grep -ahqi "segfault\|SIGSEGV" $ALL && { echo "FAIL: краш"; ok=0; }

echo ""
if [ "$ok" = "1" ]; then
  echo "=== BATTERY E2E: ALL PASSED ==="
else
  echo "=== BATTERY E2E: FAILURES (см. выше) ==="
  exit 1
fi
