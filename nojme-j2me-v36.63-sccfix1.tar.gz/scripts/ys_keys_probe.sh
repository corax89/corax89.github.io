#!/bin/bash
# [YS-KEYS-PROBE] (yetifix2 session) Эмпирика по Yeti Sports (00.02.51):
#  фаза 1 — создаём RMS-состояние как на устройстве (выбор English -> opt 144б);
#  фаза 2 — три прогона по ~45с с дампами композита 1/с:
#    A (control) — БЕЗ нажатий: таймлайн экранов (диалог тикает -> сплэш статику ->
#                  меню анимируется) через пиксель-дифы соседних дампов;
#    B (dialog-5) — инъекция '5' (53) в середине диалога: пропускает ли диалог;
#    C (splash-5) — инъекция '5' (53) в середине сплэша: пропускает ли сплэш.
# Управление:  NOJME_GAME_KEYS="53:300" (raw MIDP keycode через ту же очередь,
#              что и реальные кнопки), NOJME_FRONT_KEYS не нужен.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_keys
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/saves" "$D/cdA" "$D/cdB" "$D/cdC"
cp "${YS_JAR:-/home/z/my-project/ys/ys_game.jar}" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=icon
saves_dir=/tmp/ys_keys/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"

echo "=== ФАЗА 1: выбор языка (X = левая софт) ==="
unset NOJME_GAME_KEYS NOJME_COMPOSITE_DUMP_DIR NOJME_COMPOSITE_DUMP_MAX
export NOJME_SWITCH_KEYS="A:1200,A:500,X:16000,EXIT:42000"
timeout -k 5 50 ./bin/switchui-verify > "$D/out1.log" 2> "$D/err1.log" || true
ls "$D/saves"/*/ 2>/dev/null || echo "SAVES EMPTY!"

run2 () {  # run2 <tag> <dumpdir> <gamekeys>
  local tag="$1" dd="$2" gk="$3"
  echo
  echo "=== ФАЗА 2-$tag: game keys: ${gk:-none} ==="
  rm -rf "$dd"; mkdir -p "$dd"
  export NOJME_COMPOSITE_DUMP_DIR="$dd" NOJME_COMPOSITE_DUMP_MAX=60
  if [ -n "$gk" ]; then export NOJME_GAME_KEYS="$gk"; else unset NOJME_GAME_KEYS; fi
  export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:46000"
  timeout -k 5 55 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log" || true
  echo "дампов: $(ls "$dd" | wc -l)"
  grep -aE "GAMEKEYS" "$D/log.txt" | tail -8 || true
}

run2 A "$D/cdA" ""
run2 B "$D/cdB" "W:9000,53:300"
run2 C "$D/cdC" "W:22000,53:300"
echo
echo "=== таймлайны (пиксель-диф соседних секундных дампов, порог 0.4%) ==="
python3 - <<'PY'
import numpy as np, glob, os
def arr(p):
    with open(p,'rb') as f:
        assert f.readline().strip()==b'P6'
        w,h = map(int, f.readline().split()); f.readline()
        return np.frombuffer(f.read(), dtype=np.uint8).reshape(h,w,3).astype(np.int16)

def timeline(dd):
    fs = sorted(glob.glob(os.path.join(dd, 'comp_*.ppm')))
    out = []
    for i in range(1, len(fs)):
        A,B = arr(fs[i-1]), arr(fs[i])
        d = (np.abs(A-B).sum(axis=2) > 24).mean()
        out.append((os.path.basename(fs[i]), round(float(d)*100,2)))
    return out
for tag in ('A','B','C'):
    tl = timeline(f'/tmp/ys_keys/cd{tag}')
    print(f'-- run {tag}: ' + ' '.join(f'{n[5:9]}:{p}' for n,p in tl))
PY
