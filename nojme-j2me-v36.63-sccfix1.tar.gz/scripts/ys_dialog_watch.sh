#!/bin/bash
# [YS-DIALOG-WATCH] Наблюдение за звуковым диалогом Yeti Sports на хостовом
# switchui-verify: появляется ли, тикает ли обратный отсчёт (по дампам
# композита), истекает ли сам за ~11 с, и что показывают fl/lvc/ch.
# Контекст: полевой фриз v36.42/v36.43 — «диалог включения звука с таймером,
# не реагирует на кнопки; за 5 сек до конца экран перестаёт обновляться,
# в блюр-области обновление продолжается». На хосте (software-рендерер)
# репро не ловился; здесь проверяем ИГРОВУЮ механику диалога.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_dialog
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/cdump" "$D/saves"
cp "${YS_JAR:-/home/z/my-project/ys/ys_game.jar}" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=icon
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_COMPOSITE_DUMP_DIR="$D/cdump"
export NOJME_COMPOSITE_DUMP_MAX=90
export XDG_DATA_HOME="$D/xdg"
# A@1200 (выбор в браузере), A@500 (запуск игры), далее 50с БЕЗ нажатий,
# затем EXIT.
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:54000"

timeout -k 5 62 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

echo "=== ключевые строки лога ==="
grep -aE "game: begin|frame: first|RMS|battery: overlay|load-screen|diag: loop|PRESENT-FAIL|MIDLET-STUCK|NO-FRAME" "$D/log.txt" | head -40
echo
echo "=== число композит-дампов: $(ls "$D/cdump" | wc -l) ==="
