#!/bin/bash
# [YS-KEYS-E2E] (yetifix2) Решающий E2E для двух фиксов:
#  1) [KEY-A-PHONE]: кнопка A (фронтенд-путь SWJB_A -> SDLK_5 -> midp '5')
#     в середине сплэша «press '5'» ДОЛЖНА пролистать сплэш мгновенно
#     (устройственный путь 1:1: [KEYIN] dispatch btn=0 -> key=53 midp=53);
#  2) [KEY-HINT]: панель «Кнопки в игре» видна в первых секундах игры
#     (пиксель-тест: рамка 0x4A5A6A внизу по центру) и исчезает после
#     8 с / первого нажатия.
# Состояние = устройство: saves/YetiSports_opt.rms 144 б (диалог звука).
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_e2e_a
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/saves" "$D/cd"
cp "${YS_JAR:-/home/z/my-project/ys/ys_game.jar}" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"

# RMS-состояние как на устройстве (opt 144 б создаёт прогон B из ys_keys_probe;
# если его нет — прогон-заготовка через выбор языка клавишей '5')
YSAVE="/tmp/ys_keys/saves/Yeti Sports (00.02.51)[240x320]"
if [ ! -f "$YSAVE/YetiSports_opt.rms" ]; then
    echo "НЕТ $YSAVE/YetiSports_opt.rms — сначала ys_keys_probe.sh"; exit 2
fi
mkdir -p "$D/saves/Yeti Sports (00.02.51)[240x320]"
cp "$YSAVE"/*.rms "$D/saves/Yeti Sports (00.02.51)[240x320]/"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=off
saves_dir=/tmp/ys_e2e_a/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_COMPOSITE_DUMP_DIR="$D/cd" NOJME_COMPOSITE_DUMP_MAX=60
# A на 26-й секунде: диалог истекает ~20 с, сплэш 20..30 с — A внутри сплэша
export NOJME_FRONT_KEYS="A:26000"
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:46000"

timeout -k 5 55 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true

echo "=== цепочка доставки A ==="
grep -aE "KEYIN.*btn=0|keyhint" "$D/err.log" | head -6
echo
echo "=== таймлайн ==="
python3 - <<'PY'
import numpy as np, glob, os
def arr(p):
    with open(p,'rb') as f:
        assert f.readline().strip()==b'P6'
        w,h = map(int, f.readline().split()); f.readline()
        return np.frombuffer(f.read(), dtype=np.uint8).reshape(h,w,3).astype(np.int16)
fs = sorted(glob.glob('/tmp/ys_e2e_a/cd/comp_*.ppm'))
prev=None; tl=[]
for p in fs:
    A=arr(p)
    if prev is not None:
        d=(np.abs(A-prev).sum(axis=2)>24).mean()
        tl.append((os.path.basename(p), round(float(d)*100,2)))
    # key-hint panel detection: border rgb(74,90,106) in bottom strip y>=560
    strip=A[560:720,:,:]
    m=(np.abs(strip-np.array([74,90,106])).max(axis=2)<=12).sum()
    prev=A
    n=os.path.basename(p)
    print(f"{n}: hint_border_px={m}")
print()
print(' '.join(f'{n[5:9]}:{p}' for n,p in tl))
PY
