#!/bin/bash
# v36.60 [PUMP-GAP] проверка срабатывания: verify-сборка + диагностические
# PTRSCAN-сканы (NOJME_PG_SCAN=1) на ОДНОМ ядре с 3 CPU-балластами —
# сканы после каждой файловой операции обязаны дать слепые окна >250 мс,
# которые сторож обязан репортить. Печатает количество [PUMP-GAP] строк.
set -u
cd "$(dirname "$0")/.." || exit 1
T=$PWD
export LD_LIBRARY_PATH=/home/z/my-project/ys/sdl2dev/lib:${LD_LIBRARY_PATH:-}
W=$(mktemp -d /tmp/pgap.XXXX)
mkdir -p "$W/sdmc:/switch/j2me/games" "$W/sdmc:/switch/j2me/saves"
cp "$T/Bounce Tales (240x320).jar" "$W/sdmc:/switch/j2me/games/"

# балласт на ядре 3
for i in 1 2 3; do taskset -c 1 bash -c 'while :; do :; done' & done
BURNERS=$(jobs -p)

cd "$W" || exit 1
SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
NOJME_LOG=1 NOJME_LOGGING=1 \
NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me" \
NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games" \
NOJME_PG_SCAN=1 \
NOJME_SWITCH_KEYS="A:400,A:400,UP:25000,MINUS:400,DOWN:300,DOWN:300,A:400,EXIT:6000" \
timeout -k 10 120 nice -n 19 taskset -c 1 "$T/bin/switchui-verify" >/dev/null 2>&1

kill $BURNERS 2>/dev/null
LOG="$W/sdmc:/switch/j2me/log.txt"
n=$(grep -ac "PUMP-GAP" "$LOG" 2>/dev/null); n=${n:-0}
echo "[PUMP-GAP] строк: $n"
grep -a "PUMP-GAP" "$LOG" 2>/dev/null | head -3
if [ "${n:-0}" -ge 1 ]; then echo "PUMP-GAP WATCHDOG: FIRES (OK)"; else echo "PUMP-GAP WATCHDOG: NOT FIRED (недостаточный стопор на хосте)"; fi
