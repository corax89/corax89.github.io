import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/* v36.37 diag: raw interpreter throughput probe.
 * Burns a classic int-arithmetic + array inner loop on a worker thread and
 * prints instructions/s (iterations x ~9 bytecodes) once a second, plus a
 * textured-rasterizer-like mixed loop (int[] writes + shifts) to model the
 * NET Lizard 3D inner loops. */
public class Bench extends MIDlet {
    static volatile boolean done = false;
    static volatile boolean stop = false;

    static long burn(long acc) {
        for (int i = 0; i < 10000; i++) {
            acc += i * 3 + 7;
            acc ^= acc << 1;
        }
        return acc;
    }

    /* ~24 bytecodes/iter: array stores, shifts, masks, adds */
    static int raster(int[] fb, short[] tex, int acc) {
        int n = fb.length;
        for (int i = 0; i < n; i++) {
            int t = tex[i & 255] & 0xFFFF;
            int c = (t >> 8) & 0xF8;
            c |= (t & 0xFC00) >> 5;
            c |= (t & 0x1F) << 3;
            fb[i] = c + (acc & 15);
            acc = acc * 7 + i;
        }
        return acc;
    }

    static class W extends Thread {
        int[] fb = new int[16384];
        short[] tex = new short[256];
        public void run() {
            for (int i = 0; i < 256; i++) tex[i] = (short)(i * 7);
            long t0 = System.currentTimeMillis();
            long next = t0 + 1000;
            long iters = 0; int acc = 0;
            long phase = 0;
            while (!stop) {
                acc = (int)burn(acc);
                acc = raster(fb, tex, acc);
                iters++;
                long now = System.currentTimeMillis();
                if (now >= next) {
                    long ms = now - t0;
                    long bps = iters * 34000L / (ms + 1);
                    System.out.println("BENCH " + phase + " iters=" + iters
                            + " approx_instr/s=" + bps);
                    next = now + 1000;
                    phase++;
                    if (phase == 10) { done = true; break; }
                }
            }
        }
    }

    public void startApp() {
        System.out.println("BENCH start");
        new W().start();
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
