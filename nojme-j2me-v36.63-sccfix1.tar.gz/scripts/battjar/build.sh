#!/bin/bash
# Build TestBattery.jar — [BATFIX] v36.41 selftest: a MIDlet that reads the
# J2ME battery APIs (System.getProperty keys + the nojme.device.Battery
# class) and exits via notifyDestroyed(). Driven by
# scripts/test_switch_battery.sh.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestBattery.java" \
    "$D/src/nojme/device/Battery.java" \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TB, , TestBattery\r\nMIDlet-Name: TestBattery\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestBattery.class "$PKG/"
mkdir -p "$PKG/nojme/device"
cp "$OUT"/nojme/device/Battery.class "$PKG/nojme/device/"

( cd "$PKG" && zip -q -r "$D/TestBattery.jar" META-INF nojme *.class )

echo "built: $D/TestBattery.jar"
