package nojme.device;

/**
 * [BATFIX] v36.41 — публичный контракт API заряда эмулятора nojme.
 *
 * Этот класс кладётся в jar ИГРОЙ (или любым мидлетом), которой нужен
 * уровень заряда: методы объявлены native и резолвятся эмулятором в его
 * реестре нативов (инициализация init_nojme_battery в src/jvm/native.c).
 * На случай запуска jar на ДРУГОЙ платформе (не nojme) загрузка класса
 * упадёт — вызовы стоит оборачивать в try/catch (как это делает и сам
 * TestBattery).
 */
public class Battery {
    /** Заряд в процентах 0..100; -1 = неизвестно. */
    public static native int getLevel();
    /** true — зарядное устройство подключено. */
    public static native boolean isCharging();

    private Battery() {}
}
