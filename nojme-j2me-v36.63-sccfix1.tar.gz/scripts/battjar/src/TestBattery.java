import javax.microedition.midlet.MIDlet;

/**
 * [BATFIX] v36.41 TestBattery — E2E proof of the J2ME battery APIs.
 *
 * ДВА пути чтения заряда (запрос пользователя: «реализуй возможность
 * чтения заряда внутри j2me через один или несколько АПИ»):
 *
 *  1) System.getProperty: batterylevel (Motorola-ключ),
 *     com.nokia.mid.batterylevel (Nokia-ключ), nojme.batterylevel (наш),
 *     nojme.battery.charging (статус зарядки).
 *  2) Собственный класс nojme.device.Battery:
 *     public static native int getLevel();    // 0..100, -1 = неизвестно
 *     public static native boolean isCharging();
 *     (класс в jar объявляет методы native — рантайм резолвит их в своём
 *     реестре; прямой путь invokestatic, как это сделала бы реальная игра)
 *
 * Печать: «[TB] key=value» / «[TB] Battery.getLevel()=37» с последним
 * notifyDestroyed() — чистое завершение сессии. Хост-ран включается с
 * NOJME_BATTERY_MOCK=37:c (37 %, зарядное подключено) — все шесть строк
 * обязаны совпасть побуквенно.
 *
 * Driven by scripts/test_switch_battery.sh.
 */
public class TestBattery extends MIDlet {

    static final String[] KEYS = {
        "batterylevel",
        "com.nokia.mid.batterylevel",
        "nojme.batterylevel",
        "nojme.battery.charging",
    };

    protected void startApp() {
        System.out.println("[TB] start");
        for (int i = 0; i < KEYS.length; i++) {
            String v = null;
            try {
                v = System.getProperty(KEYS[i]);
            } catch (Throwable t) {
                System.out.println("[TB] " + KEYS[i] + "=<throw " + t + ">");
                continue;
            }
            System.out.println("[TB] " + KEYS[i] + "="
                               + (v == null ? "<null>" : v));
        }
        try {
            System.out.println("[TB] Battery.getLevel()="
                               + nojme.device.Battery.getLevel());
            System.out.println("[TB] Battery.isCharging()="
                               + nojme.device.Battery.isCharging());
        } catch (Throwable t) {
            System.out.println("[TB] BatteryAPI=<throw " + t + ">");
        }
        System.out.println("[TB] done");
        /* Держим сессию ~4 c ЖИВЫМ Java-потоком: пока VM не уничтожена,
         * кадровый насос качает present (оверлей заряда в кадре игры).
         * Спать в ГЛАВНОМ потоке нельзя — startApp исполняется целиком
         * внутри jvm_run_midlet ДО входа в насос, и сессия умирала бы в
         * ветке «MIDlet finished» ни разу не дойдя до present_game. */
        new Thread(new Runnable() {
            public void run() {
                try { Thread.sleep(4000L); } catch (InterruptedException e) {}
                notifyDestroyed();
            }
        }).start();
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) {}
}
