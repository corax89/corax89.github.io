#!/bin/bash
# [YS-DIALOG-SOFT] Фокус: работает ли софт-клавиша на диалоге звука (экран 20)?
# Состояние: opt.rms существует (после выбора языка) => показывается диалог
# "Current sound setting / Game will start in N second(s)" с софтами On/Off.
# Три прогона: A) без нажатий (контроль отсчёта), B) LSK (-6) на 5-й секунде,
# C) RSK (-7) на 5-й секунде. Каждый — с дампами композита; вердикт по
# пиксель-дифам: остановился ли отсчёт / сменился ли экран раньше контрольного.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_dlgsoft
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/saves"
YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"
cp "$YS" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"
# состояние с opt (от ys_nameflow): диалог при каждом запуске
cp -r /tmp/ys_nameflow/saves/* "$D/saves/" 2>/dev/null || { echo "нет состояния opt"; exit 1; }

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=off
keyhint=off
saves_dir=/tmp/ys_dlgsoft/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"
export NOJME_SOFTKEY_TRACE=1

run () {  # run <tag> <gamekeys>
  local tag="$1" gk="$2"
  echo "=== $tag: game keys: ${gk:-none} ==="
  mkdir -p "$D/cd_$tag"
  export NOJME_COMPOSITE_DUMP_DIR="$D/cd_$tag" NOJME_COMPOSITE_DUMP_MAX=40
  if [ -n "$gk" ]; then export NOJME_GAME_KEYS="$gk"; else unset NOJME_GAME_KEYS; fi
  export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:30000"
  timeout -k 5 34 ./bin/switchui-verify > "$D/out_$tag.log" 2> "$D/err_$tag.log" || true
  echo "  дампов: $(ls "$D/cd_$tag" | wc -l)"
  grep -aE "SOFTKEY" "$D/err_$tag.log" | head -6
  cp "$D/log.txt" "$D/log_$tag.txt"
}

run A ""
run B "W:12000,-6:400"
run C "W:12000,-7:400"

echo
echo "=== Пиксель-таймлайны (когда экран меняется) ==="
python3 - <<'PY'
import numpy as np, glob, os
def arr(p):
    with open(p,'rb') as f:
        assert f.readline().strip()==b'P6'
        f.readline()
        w,h = map(int, f.readline().split())
        return np.frombuffer(f.read(w*h*3), np.uint8).reshape(h,w,3).astype(int)
for tag in "A B C".split():
    fs = sorted(glob.glob(f"/tmp/ys_dlgsoft/cd_{tag}/comp_*.ppm"))
    prev = None; line=[]
    for f in fs:
        a = arr(f)
        # игровая зона: canvas 240x320 в rect 370,0 540x720 (scale 2)
        zone = a[0:720, 370:910]
        d = 0 if prev is None else float(np.mean(np.abs(zone-prev)))/255*100
        t = int(os.path.basename(f)[5:9])
        line.append(f"t={t}:{d:.2f}%")
        prev = zone
    print(tag, " ".join(line))
PY
