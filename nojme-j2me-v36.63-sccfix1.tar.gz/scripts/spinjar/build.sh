#!/bin/bash
# Build TestSpinBreak.jar — v36.57 [SPIN-BREAK] selftest.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
STUBS="$D/../keysjar/stubs"
rm -rf "$OUT"; mkdir -p "$OUT"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestSpinBreak.java" \
    "$STUBS/javax/microedition/midlet/"*.java \
    "$STUBS/javax/microedition/lcdui/"*.java
PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TS, , TestSpinBreak\r\nMIDlet-Name: TestSpinBreak\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestSpinBreak*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestSpinBreak.jar" META-INF && zip -q "$D/TestSpinBreak.jar" *.class )
echo "built: $D/TestSpinBreak.jar"
