/* v36.57 [SPIN-BREAK] selftest: игровой поток крутится в ЧИСТОМ байткоде
 * внутри synchronized-блока (имитация депенетрации Gravity Defied),
 * paint() канвы берёт ТОТ ЖЕ монитор (имитация i.a(Graphics):synchronized(oc)).
 * Ожидания с фиксом: [SPIN-BREAK] <= NOJME_SPIN_BREAK_MS, исключение ловится
 * catch'ем, поток живёт ("SURVIVED"), кадры продолжаются (монитор не утёк),
 * фронтенд жив (PAINT-BUDGET прерывает зависший paint). */
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TestSpinBreak extends MIDlet {
    static final Object lock = new Object();
    static int frames = 0;
    static Canvas c;
    static Thread t;

    public TestSpinBreak() { System.out.println("TS:ctor"); }

    public void startApp() {
        final TestSpinBreak self = this;
        c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 0);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(80, 255, 80);
                synchronized (lock) {
                    frames++;
                    g.drawString("frame " + frames, 10, 10, 0);
                }
            }
            protected void keyPressed(int k) { System.out.println("TS:key " + k); }
        };
        Display.getDisplay(this).setCurrent(c);
        t = new Thread(new Runnable() {
            public void run() {
                System.out.println("TS:thread-start");
                for (int round = 1; round <= 3; round++) {
                    /* фаза А: 700 мс обычной жизни */
                    try { Thread.sleep(700); } catch (Exception e) {}
                    c.repaint();
                    /* фаза Б: чисто-Java спин 8 с ВНУТРИ монитора (без
                     * единого натива — как b.u депенетрации GD) */
                    long sink = 1;
                    try {
                        synchronized (lock) {
                            for (long i = 0; i < 400000000L; i++) {
                                sink = sink * 1103515245L + 12345L;
                            }
                        }
                        System.out.println("TS:round" + round + " SPIN-COMPLETED-NATIVELY sink=" + sink);
                    } catch (RuntimeException e) {
                        System.out.println("TS:round" + round + " CAUGHT-SPIN-BREAK: " + e.getMessage());
                    } catch (Exception e) {
                        System.out.println("TS:round" + round + " CAUGHT-OTHER: " + e);
                    }
                    c.repaint();
                    try { Thread.sleep(300); } catch (Exception e) {}
                }
                System.out.println("TS:SURVIVED-ALL frames=" + frames);
            }
        });
        t.start();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
