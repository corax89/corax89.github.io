#!/bin/bash
# v36.60 [LAGFIX1] journey — полевая задача «после выхода из мидлета меню
# сильно тормозит и пропускает нажатия».
#
# Полный user journey на switchui-verify: меню → браузер → запуск игры
# (Bounce Tales) → 8 с игры → MINUS-пауза → Выйти → меню → настройки
# (скролл) → выход без сохранения → EXIT. После — АУДИТ log.txt:
#   A) БЕЗ env NOJME_PG_SCAN (новый дефолт):
#      - [PTRSCAN]-строк НЕТ (гейт [PSCAN-FLAG] — лаг меню и спам убраны);
#      - [PUMP-GAP]-стопоров НЕТ (сторож молчит в здоровом цикле);
#      - alive-строки только в паузах >10 с ([ALIVE-IDLE]) — при живом
#        потоке лога их нет;
#      - [FILEOP]-бейджи живут (прибор доступен без сканов).
#   B) С env NOJME_PG_SCAN=1 (диагностический режим, эквивалент старого
#      поведения): [PTRSCAN]-строки ЕСТЬ — прибор по-прежнему работает.
set -u
T=$(cd "$(dirname "$0")/.." && pwd)
BIN="$T/bin/switchui-verify"
[ -x "$BIN" ] || { echo "FAIL: нет $BIN (make switchui-verify)"; exit 1; }

run_journey() { # $1 = имя прогона, $2.. = доп. env
    local name="$1"; shift
    local W
    W=$(mktemp -d "/tmp/lagfix_${name}.XXXX")
    mkdir -p "$W/sdmc:/switch/j2me/games" "$W/sdmc:/switch/j2me/saves"
    cp "$T/Bounce Tales (240x320).jar" "$W/sdmc:/switch/j2me/games/" 2>/dev/null
    cp "$T/games/TestKeys.jar" "$W/sdmc:/switch/j2me/games/" 2>/dev/null
    (
        cd "$W" || exit 1
        export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
        export NOJME_LOG=1 NOJME_LOGGING=1
        export NOJME_SWITCH_UI_DIR="sdmc:/switch/j2me"
        export NOJME_SWITCH_BROWSE_ROOT="sdmc:/switch/j2me/games"
        # БЕЗ NOJME_SWITCH_AUTOTEST_SESSIONS: позиция скрипта ПЕРЕЖИВАЕТ
        # сессии (дефолт) — после выхода из игры токены продолжаются,
        # фаза настроек тоже отрабатывает.
        # меню (A=Открыть игру) → браузер (A=первый jar=запуск) → игра 8 с
        # (держим UP) → MINUS (пауза) → вниз-вниз-A (Выйти) → меню →
        # DOWN (Настройки) A (вход) → скролл → B (без сохранения) → EXIT.
        export NOJME_SWITCH_KEYS="A:400,A:400,UP:8000,MINUS:400,DOWN:300,DOWN:300,A:400,DOWN:300,A:400,DOWN:300,DOWN:300,DOWN:300,DOWN:300,DOWN:300,UP:300,UP:300,B:400,EXIT:6000"
        env "$@" timeout -k 10 150 "$BIN" >/dev/null 2>&1
    )
    LOG="$W/sdmc:/switch/j2me/log.txt"
    if [ ! -s "$LOG" ]; then
        echo "FAIL ($name): log.txt пуст/отсутствует"; return 1
    fi
    echo "$LOG"
}

echo "=== A) дефолт: гейт сканера ВЫКЛ ==="
LOG_A=$(run_journey off) || exit 1
ptrscan_a=$(grep -ac "PTRSCAN" "$LOG_A")
pumpgap_a=$(grep -ac "PUMP-GAP" "$LOG_A")
alive_a=$(grep -ac " alive: " "$LOG_A")
fileop_a=$(grep -ac "FILEOP" "$LOG_A")
sess_a=$(grep -ac "game: begin" "$LOG_A")
menu_a=$(grep -ac "menu: session start" "$LOG_A")
echo "  строк в log.txt:        $(wc -l < "$LOG_A")"
echo "  [PTRSCAN] (ожидание 0): $ptrscan_a"
echo "  [PUMP-GAP]  (ожидание 0): $pumpgap_a"
echo "  alive (ожидание мало):   $alive_a"
echo "  [FILEOP] (ожидание >0):  $fileop_a"
echo "  game: begin:             $sess_a; menu: session start: $menu_a"
[ "$ptrscan_a" -eq 0 ] || { echo "FAIL: PTRSCAN при выключенном гейте"; exit 1; }
[ "$pumpgap_a" -eq 0 ] || { echo "FAIL: PUMP-GAP в здоровом джорнее"; exit 1; }
[ "$fileop_a" -gt 0 ] || { echo "FAIL: [FILEOP]-бейджи пропали"; exit 1; }
[ "$sess_a" -ge 1 ]   || { echo "FAIL: игровая сессия не запустилась"; exit 1; }
[ "$menu_a" -ge 2 ]   || { echo "FAIL: меню после игры не перезапустилось"; exit 1; }

echo "=== B) диагностический режим: NOJME_PG_SCAN=1 ==="
LOG_B=$(run_journey on NOJME_PG_SCAN=1) || exit 1
ptrscan_b=$(grep -ac "PTRSCAN" "$LOG_B")
pumpgap_b=$(grep -ac "PUMP-GAP" "$LOG_B")
echo "  [PTRSCAN] (ожидание >0): $ptrscan_b"
echo "  [PUMP-GAP]:              $pumpgap_b (хост быстрый — может быть 0)"
[ "$ptrscan_b" -gt 0 ] || { echo "FAIL: с NOJME_PG_SCAN=1 сканер не проснулся"; exit 1; }

echo "=== C) компактность: доля alive в живом меню ==="
# в старом поведании alive шёл каждые 2 с ВЕЗДЕ; теперь — только после
# 10 с тишины. Джорней A идёт ~25 с с паузами ≤8 с → ожидаем 0-2 строки.
echo "  alive в джорнее A: $alive_a (было бы ~12 при каденсе 2 с)"
echo "LAGFIX JOURNEY: ALL CHECKS PASSED"
