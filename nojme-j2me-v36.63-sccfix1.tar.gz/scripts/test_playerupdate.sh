#!/bin/bash
# [PLAYERUPDATE-HAMMER] v36.48 — драйвер TestPU.jar: 30 циклов
# start/stop/play-out через PlayerListener. Каждая доставка идёт по коду
# [PLAYERUPDATE-ARGS] (v36.47). Прогон под ASan-сборкой: любая порча стека
# (как в старом баге «es/Yeti » 0x20697465592F7365) обязана всплыть.
# Также считает доставки по категориям и требует PU-RESULT с delivered>=60.
set -u
cd "$(dirname "$0")/.." || exit 1
D=/tmp/pu_hammer
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/saves"
cp scripts/pujar/TestPU.jar "$D/roms/TestPU.jar" 2>/dev/null || { echo "FAIL: нет TestPU.jar (bash scripts/pujar/build.sh)"; exit 1; }

cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=on
vm_speed=normal
logging=on
battery=off
keyhint=off
saves_dir=$D/saves
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1 NOJME_MEDIA_DEBUG=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export NOJME_SWITCH_AUTOTEST_SESSIONS=1
export XDG_DATA_HOME="$D/xdg"
export NOJME_SWITCH_KEYS="A:1200,A:500"
export ASAN_OPTIONS=detect_leaks=0:abort_on_error=0:halt_on_error=1

BIN=${BIN:-./bin-asan/switchui-verify}
[ -x "$BIN" ] || BIN=./bin/switchui-verify
[ -x "$BIN" ] || { echo "FAIL: нет бинарника switchui-verify"; exit 1; }

timeout -k 5 78 "$BIN" > "$D/out.log" 2> "$D/err.log"
RC=$?

ok=1
echo "=== stdout мидлета (out.log + log.txt) ==="
grep -ahE "PU-RESULT|PU [0-9]" "$D/out.log" "$D/log.txt" "$D/err.log" 2>/dev/null | head -8

N_ASAN=$(grep -acE "ERROR: AddressSanitizer" "$D/err.log" 2>/dev/null); N_ASAN=${N_ASAN:-0}
[ "$N_ASAN" = "0" ] || { echo "FAIL: ASan-ошибок $N_ASAN"; ok=0; }

RES=$(grep -ah "PU-RESULT" "$D/out.log" "$D/log.txt" "$D/err.log" 2>/dev/null | head -1)
[ -n "$RES" ] || { echo "FAIL: PU-RESULT не найден (мидлет не завершился?)"; ok=0; }
echo "результат: $RES"

DELIV=$(echo "$RES" | sed -n 's/.*delivered=\([0-9]*\).*/\1/p')
STARTED=$(echo "$RES" | sed -n 's/.*started=\([0-9]*\).*/\1/p')
EOM=$(echo "$RES" | sed -n 's/.*eom=\([0-9]*\).*/\1/p')
[ -n "$DELIV" ] && [ "$DELIV" -ge 60 ] 2>/dev/null || { echo "FAIL: доставок $DELIV < 60"; ok=0; }
[ -n "$STARTED" ] && [ "$STARTED" -ge 55 ] 2>/dev/null || { echo "FAIL: started $STARTED < 55"; ok=0; }

echo "=== [MEDIA] Player.start (ожидаем >=60) ==="
N_START=$(grep -ahc "Player.start" "$D/err.log" "$D/log.txt" 2>/dev/null | awk '{s+=$1} END{print s+0}')
echo "Player.start: $N_START; ASan: $N_ASAN; rc=$RC"
echo "=== session end (чистый teardown) ==="
grep -ah "game: session end\|media session reset" "$D/log.txt" "$D/err.log" 2>/dev/null | head -3

if [ "$ok" = "1" ]; then
    echo "ALL PASSED (delivered=$DELIV started=$STARTED eom=$EOM, ASan=$N_ASAN)"
else
    echo "FAILED"; exit 1
fi
