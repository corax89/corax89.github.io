#!/bin/bash
# [YS-ASAN-JOURNEY] (yetifix4) Охота за порчей памяти "es/Yeti " (Ryujinx:
# Invalid memory access at 0x20697465592F7365) на ХОСТЕ под AddressSanitizer.
# Девайс-точные ДЛИНЫ путей (важно: смещение "es/Yeti " = 21 от начала строки):
#   устройства                              хост (та же длина)
#   sdmc:/switch/j2me          (17)  ->  /tmp/ysfix4ui12345      (17) base/ui
#   sdmc:/switch/j2me/games    (23)  ->  /tmp/ysfix4games1234567 (23) каталог игр
#   sdmc:/switch/j2me/saves    (23)  ->  /tmp/ysfix4saves1234567 (23) каталог RMS
#   .../games/Yeti Sports (00.02.51)[240x320].jar        (59) полный путь JAR
#   .../saves/Yeti Sports (00.02.51)[240x320]/YetiSports_opt.rms (78) путь RMS
# Джорней: меню -> запуск -> '5' в диалоге -> X(-6) подтвердить -> '5' сплэш ->
# меню ('5'-спам) -> B(-7) -> пауза#1(B) -> пауза#2(pgset: DOWN,A / B,B) ->
# пауза#3(DOWN,DOWN,A=выход) -> меню -> ПОВТОРНЫЙ запуск -> '5' спам -> пауза ->
# выход. ASan ловит запись пути на чужую память в ЛЮБОМ месте.
set -u
cd "$(dirname "$0")/../nojme/nojme-j2me" || exit 1

UI=/tmp/ysfix4ui1234
GAMES=/tmp/ysfix4games1234567
SAVES=/tmp/ysfix4saves1234567
YS="${YS_JAR:-/home/z/my-project/ys/yeti_ext/Yeti Sports (00.02.51)[240x320].jar}"

# контроль длин (побайтово как на устройстве)
[ "${#UI}" -eq 17 ]   || { echo "FAIL: UI len ${#UI} != 17"; exit 1; }
[ "${#GAMES}" -eq 23 ] || { echo "FAIL: GAMES len ${#GAMES} != 23"; exit 1; }
[ "${#SAVES}" -eq 23 ] || { echo "FAIL: SAVES len ${#SAVES} != 23"; exit 1; }

rm -rf "$UI" "$GAMES" "$SAVES"
mkdir -p "$UI" "$GAMES" "$SAVES/Yeti Sports (00.02.51)[240x320]"
cp "$YS" "$GAMES/Yeti Sports (00.02.51)[240x320].jar" || exit 1
# устройство-состояние RMS (opt 144 б -> диалог звука, his 185 б)
cp /tmp/ys_nameflow/saves/"Yeti Sports (00.02.51)[240x320]"/*.rms \
   "$SAVES/Yeti Sports (00.02.51)[240x320]/" 2>/dev/null || echo "ВНИМАНИЕ: нет RMS-состояния"

cat > "$UI/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_blur
filter=linear
audio=off
vm_speed=normal
logging=on
battery=off
keyhint=on
saves_dir=$SAVES
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$GAMES"
export NOJME_SWITCH_UI_DIR="$UI"
export XDG_DATA_HOME="$UI/xdg"
export ASAN_OPTIONS=detect_leaks=0:abort_on_error=0:halt_on_error=1

# --- джорней (все тайминги ОТ СТАРТА ПРОЦЕССА) ---
# меню-сессии (перезапускаются на каждую): A=Открыть игру, A=запуск Yeti
export NOJME_SWITCH_KEYS="A:1200,A:500"
# игровые клавиши: '5'=53 (A), -6 (X LSK), -7 (B RSK) — как на устройстве
export NOJME_GAME_KEYS="W:7000,53:400,W:1500,53:300,W:700,53:300,W:3000,-6:400,W:11000,53:300,W:2000,53:300,W:1000,53:300,W:1000,53:300,W:2000,53:300,W:2000,53:300,W:2000,53:300,W:3000,53:300,W:3000,53:300,W:2000,53:300,W:3000,-7:400,W:8000,53:300,W:2500,53:300,W:2500,53:300"
# фронтенд-кнопки: PLUS=пауза, DOWN/A — навигация меню паузы/pgset, B=назад
export NOJME_FRONT_KEYS="PLUS:30500,B:32000,PLUS:34500,DOWN:35500,A:36500,B:41000,B:42500,PLUS:44500,DOWN:45500,DOWN:46500,A:47500,PLUS:65000,DOWN:66000,DOWN:67000,A:68000"

echo "=== запуск ASan-бинарника (таймаут 80с) ==="
timeout -k 5 82 ./bin-asan/switchui-verify > /tmp/ys_asan_out.log 2> /tmp/ys_asan_err.log
RC=$?
echo "rc=$RC"
echo "=== ASan-ошибки ==="
grep -aE "ERROR: AddressSanitizer|SUMMARY: AddressSanitizer" /tmp/ys_asan_err.log | head -10 || echo "нет"
echo "=== ключевые события log.txt ==="
grep -aE "game: |menu: |pause: |pgset: |diag: |RMS\] open" "$UI/log.txt" 2>/dev/null | head -40
echo "=== хвост stderr ==="
tail -5 /tmp/ys_asan_err.log
