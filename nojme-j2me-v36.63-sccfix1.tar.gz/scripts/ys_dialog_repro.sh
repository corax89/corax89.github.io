#!/bin/bash
# [YS-DIALOG-REPRO] Двухфазный прогон:
#  фаза 1 — первый запуск: софт-клавиша -6 выбирает English на экране языка,
#           игра сохраняет опции (создаётся YetiSports_opt), выход;
#  фаза 2 — второй запуск (состояние = как на устройстве): наблюдаем
#           ЗВУКОВОЙ ДИАЛОГ — тикает ли отсчёт (композит-дампы 1/с),
#           истекает ли сам, что в diag.
set -e
cd "$(dirname "$0")/.." || exit 1
D=/tmp/ys_repro2
rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg" "$D/cd1" "$D/cd2" "$D/saves"
cp "${YS_JAR:-/home/z/my-project/ys/ys_game.jar}" "$D/roms/Yeti Sports (00.02.51)[240x320].jar"

cat > "$D/switchui_settings.ini" <<'EOF'
settings_version=4
scale=fit_blur
filter=nearest
audio=off
vm_speed=normal
logging=on
battery=icon
EOF

export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
export NOJME_LOG=1 NOJME_LOGGING=1
export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
export NOJME_SWITCH_UI_DIR="$D"
export XDG_DATA_HOME="$D/xdg"

echo "=== ФАЗА 1: выбор языка (X = левая софт) ==="
export NOJME_COMPOSITE_DUMP_DIR="$D/cd1" NOJME_COMPOSITE_DUMP_MAX=40
export NOJME_SWITCH_KEYS="A:1200,A:500,X:16000,EXIT:42000"
timeout -k 5 50 ./bin/switchui-verify > "$D/out1.log" 2> "$D/err1.log" || true
grep -aE "RMS.*(setRecord|addRecord|open|load)" "$D/log.txt" | head -12
ls "$D/saves"/*/ 2>/dev/null

echo
echo "=== ФАЗА 2: второй запуск — ждём звуковой диалог ==="
export NOJME_COMPOSITE_DUMP_DIR="$D/cd2" NOJME_COMPOSITE_DUMP_MAX=45
export NOJME_SWITCH_KEYS="A:1200,A:500,EXIT:46000"
timeout -k 5 55 ./bin/switchui-verify > "$D/out2.log" 2> "$D/err2.log" || true
grep -aE "game: begin|RMS" "$D/log.txt" | head -10
echo "дампов фазы 2: $(ls "$D/cd2" | wc -l)"
