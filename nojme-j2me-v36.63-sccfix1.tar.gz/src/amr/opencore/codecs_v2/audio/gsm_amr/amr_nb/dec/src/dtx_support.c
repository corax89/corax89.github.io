/* ==================================================================
 * dtx_support.c - merged AMR-NB decoder implementation file.
 *
 * Merged from the following per-function sources of the vendored
 * opencore-amrnb decoder (converted from C++ to plain C):
 *   opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/b_cn_cod.c
 *   opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/bgnscd.c
 *   opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/c_g_aver.c
 *
 * Every section keeps its original content verbatim; the module
 * headers (.h) and all function signatures are unchanged.
 * ==================================================================
 */



/* ==================================================================
 * Section: opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/b_cn_cod.c
 * ==================================================================
 */

/* ------------------------------------------------------------------
 * Copyright (C) 1998-2009 PacketVideo
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 * -------------------------------------------------------------------
 */
/****************************************************************************************
Portions of this file are derived from the following 3GPP standard:

    3GPP TS 26.073
    ANSI-C code for the Adaptive Multi-Rate (AMR) speech codec
    Available from http://www.3gpp.org

(C) 2004, 3GPP Organizational Partners (ARIB, ATIS, CCSA, ETSI, TTA, TTC)
Permission to distribute, modify and use this file under the standard license
terms listed above has been obtained from the copyright holder.
****************************************************************************************/
/*
------------------------------------------------------------------------------



 Filename: b_cn_cod.c
 Functions: pseudonoise
            build_CN_code
            build_CN_param

------------------------------------------------------------------------------
 MODULE DESCRIPTION

 This module contains functions for comfort noise(CN) generation.

------------------------------------------------------------------------------
*/


/*----------------------------------------------------------------------------
; INCLUDES
----------------------------------------------------------------------------*/
#include "b_cn_cod.h"
#include "basic_op.h"
#include "cnst.h"

/*----------------------------------------------------------------------------
; MACROS
; [Define module specific macros here]
----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------
; DEFINES
; [Include all pre-processor statements here. Include conditional
; compile variables also.]
----------------------------------------------------------------------------*/
#define  NB_PULSE 10        /* number of random pulses in DTX operation   */

/*----------------------------------------------------------------------------
; LOCAL FUNCTION DEFINITIONS
; [List function prototypes here]
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
; LOCAL VARIABLE DEFINITIONS
; [Variable declaration - defined here and used outside this module]
----------------------------------------------------------------------------*/

/*
------------------------------------------------------------------------------
 FUNCTION NAME: pseudonoise
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    pShift_reg = pointer to Old CN generator shift register state (Word32)
    no_bits = Number of bits (Word16)

 Outputs:
    pShift_reg -> Updated CN generator shift register state

 Returns:
    noise_bits = Generated random integer value (Word16)

 Global Variables Used:
    None

 Local Variables Needed:
    None

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

 Generate a random integer value to use in comfort noise generation. The
 algorithm uses polynomial x^31 + x^3 + 1. Length of the PN sequence
 is 2^31 - 1

------------------------------------------------------------------------------
 REQUIREMENTS

 None

------------------------------------------------------------------------------
 REFERENCES

 b_cn_cod.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

Word16 pseudonoise (
    Word32 *shift_reg, // i/o : Old CN generator shift register state
    Word16 no_bits     // i   : Number of bits
)
{
   Word16 noise_bits, Sn, i;

   noise_bits = 0;
   for (i = 0; i < no_bits; i++)
   {
      // State n == 31
      if ((*shift_reg & 0x00000001L) != 0)
      {
         Sn = 1;
      }
      else
      {
         Sn = 0;
      }

      // State n == 3
      if ((*shift_reg & 0x10000000L) != 0)
      {
         Sn = Sn ^ 1;
      }
      else
      {
         Sn = Sn ^ 0;
      }

      noise_bits = shl (noise_bits, 1);
      noise_bits = noise_bits | (extract_l (*shift_reg) & 1);

      *shift_reg = L_shr (*shift_reg, 1);
      if (Sn & 1)
      {
         *shift_reg = *shift_reg | 0x40000000L;
      }
   }
   return noise_bits;
}

------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

/*----------------------------------------------------------------------------
; FUNCTION CODE
----------------------------------------------------------------------------*/

Word16 pseudonoise(
    Word32 *pShift_reg,     /* i/o : Old CN generator shift register state */
    Word16 no_bits          /* i   : Number of bits                        */
)
{
    Word16 noise_bits;
    Word16 Sn;
    Word16 i;
    Word16 temp;

    noise_bits = 0;

    for (i = 0; i < no_bits; i++)
    {
        /* State n == 31 */
        if ((*pShift_reg & 0x00000001L) != 0)
        {
            Sn = 1;
        }
        else
        {
            Sn = 0;
        }

        /* State n == 3 */
        if ((*pShift_reg & 0x10000000L) != 0)
        {
            Sn ^= 1;
        }
        else
        {
            Sn ^= 0;
        }

        noise_bits <<= 1;

        temp = (Word16)((*pShift_reg) & 1);
        noise_bits |= temp;

        *pShift_reg >>= 1;
        if (Sn & 1)
        {
            *pShift_reg |= 0x40000000L;
        }
    }
    return noise_bits;
}

/*
------------------------------------------------------------------------------
 FUNCTION NAME: build_CN_code
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    pSeed = pointer to the Old CN generator shift register state (Word32)
    cod[] = array to hold the generated CN fixed code vector (Word16)
    pOverflow = pointer to overflow flag (Flag)

 Outputs:
    cod[] = generated CN fixed code vector (Word16)
    pSeed = Updated CN generator shift register state (Word16)
    pOverflow -> 1 if overflow occured

 Returns:
    None

 Global Variables Used:
    None

 Local Variables Needed:
    None

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

This function computes the comfort noise fixed codebook excitation. The gains
of the pulses are always +/-1.

------------------------------------------------------------------------------
 REQUIREMENTS

 None

------------------------------------------------------------------------------
 REFERENCES

 b_cn_cod.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

void build_CN_code (
    Word32 *seed,         // i/o : Old CN generator shift register state
    Word16 cod[]          // o   : Generated CN fixed codebook vector
)
{
   Word16 i, j, k;

   for (i = 0; i < L_SUBFR; i++)
   {
      cod[i] = 0;
   }

// The reference ETSI code uses a global flag for Overflow. However in the
// actual implementation a pointer to the overflow flag is passed into the
// function so that it can be passed into the basic math functions L_mult()
// and add()

   for (k = 0; k < NB_PULSE; k++)
   {
      i = pseudonoise (seed, 2);      // generate pulse position
      i = shr (extract_l (L_mult (i, 10)), 1);
      i = add (i, k);

      j = pseudonoise (seed, 1);      // generate sign

      if (j > 0)
      {
         cod[i] = 4096;
      }
      else
      {
         cod[i] = -4096;
      }
   }

   return;
}
------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

/*----------------------------------------------------------------------------
; FUNCTION CODE
----------------------------------------------------------------------------*/
void build_CN_code(
    Word32 *pSeed,          /* i/o : Old CN generator shift register state  */
    Word16 cod[],           /* o   : Generated CN fixed codebook vector     */
    Flag   *pOverflow       /* i/o : Overflow flag                          */
)
{
    Word16 i, j, k;
    Word16 temp;

    for (i = 0; i < L_SUBFR; i++)
    {
        cod[i] = 0;
    }

    for (k = 0; k < NB_PULSE; k++)
    {
        i = pseudonoise(pSeed, 2);       /* generate pulse position */

        temp = (Word16)(L_mult(i, 10, pOverflow));
        i = temp >> 1;
        i = add_16(i, k, pOverflow);

        j = pseudonoise(pSeed, 1);       /* generate sign */

        if (j > 0)
        {
            cod[i] = 4096;
        }
        else
        {
            cod[i] = -4096;
        }
    }

    return;
}

/*
------------------------------------------------------------------------------
 FUNCTION NAME: build_CN_param
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    pSeed = pointer to the Old CN generator shift register state (Word32)
    n_param = Number of parameters to randomize (Word16)
    param_size_table = table holding paameter sizes (Word16)
    param[] = array to hold CN generated paramters (Word16)
    pOverflow = pointer to overflow flag (Flag)

 Outputs:
    param[] = CN generated parameters (Word16)
    pSeed = Updated CN generator shift register state (Word16)
    pOverflow -> 1 if overflow occured

 Returns:
    None

 Global Variables Used:
    None

 Local Variables Needed:
    None

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

This function randomizes the speech parameters, so that they do not produce
tonal artifacts if used by ECU.

------------------------------------------------------------------------------
 REQUIREMENTS

 None

------------------------------------------------------------------------------
 REFERENCES

 b_cn_cod.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE
void build_CN_param (
    Word16 *seed,             // i/o : Old CN generator shift register state
    const Word16 n_param,           // i  : number of params
    const Word16 param_size_table[],// i : size of params
    Word16 parm[]                   // o : CN Generated params
    )
{
   Word16 i;
   const Word16 *p;

// The reference ETSI code uses a global flag for Overflow. However in the
// actual implementation a pointer to the overflow flag is passed into the
// function so that it can be passed into the basic math functions L_add()
// and L_mult()

   *seed = extract_l(L_add(L_shr(L_mult(*seed, 31821), 1), 13849L));

   p = &window_200_40[*seed & 0x7F];
   for(i=0; i< n_param;i++){
     parm[i] = *p++ & ~(0xFFFF<<param_size_table[i]);
   }
}


------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

/*----------------------------------------------------------------------------
; FUNCTION CODE
----------------------------------------------------------------------------*/
void build_CN_param(
    Word16 *pSeed,          /* i/o : Old CN generator shift register state  */
    const Word16 n_param,           /* i  : number of params                */
    const Word16 param_size_table[],/* i : size of params                   */
    Word16 parm[],                  /* o : CN Generated params              */
    const Word16* window_200_40_ptr, /* i : ptr to read-only table          */
    Flag  *pOverflow                /* i/o : Overflow Flag                  */
)

{
    Word16 i;
    const Word16 *pTemp;
    Word32 L_temp;
    Word16 temp;

    L_temp = L_mult(*pSeed, 31821, pOverflow);
    L_temp >>= 1;

    *pSeed = (Word16)(L_add(L_temp, 13849L, pOverflow));

    pTemp = &window_200_40_ptr[*pSeed & 0x7F];

    for (i = 0; i < n_param; i++)
    {
        temp = ~(0xFFFF << param_size_table[i]);
        parm[i] = *pTemp++ & temp;
    }
}


/* ==================================================================
 * Section: opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/bgnscd.c
 * ==================================================================
 */

/* ------------------------------------------------------------------
 * Copyright (C) 1998-2009 PacketVideo
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 * -------------------------------------------------------------------
 */
/****************************************************************************************
Portions of this file are derived from the following 3GPP standard:

    3GPP TS 26.073
    ANSI-C code for the Adaptive Multi-Rate (AMR) speech codec
    Available from http://www.3gpp.org

(C) 2004, 3GPP Organizational Partners (ARIB, ATIS, CCSA, ETSI, TTA, TTC)
Permission to distribute, modify and use this file under the standard license
terms listed above has been obtained from the copyright holder.
****************************************************************************************/
/*
------------------------------------------------------------------------------

 Filename: bgnscd.c
 Functions:
           Bgn_scd_reset
           Bgn_scd

------------------------------------------------------------------------------
 MODULE DESCRIPTION

 Background noise source characteristic detector (SCD)

------------------------------------------------------------------------------
*/


/*----------------------------------------------------------------------------
; INCLUDES
----------------------------------------------------------------------------*/
#include    "bgnscd.h"
#include    "typedef.h"
#include    "basic_op.h"
#include    "cnst.h"
#include    "gmed_n.h"
#include    "sqrt_l.h"
#include    "oscl_mem.h"

/*----------------------------------------------------------------------------
; MACROS
; Define module specific macros here
----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------
; DEFINES
; Include all pre-processor statements here. Include conditional
; compile variables also.
----------------------------------------------------------------------------*/
#define TRUE  1
#define FALSE 0

/*----------------------------------------------------------------------------
; LOCAL FUNCTION DEFINITIONS
; Function Prototype declaration
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
; LOCAL VARIABLE DEFINITIONS
; Variable declaration - defined here and used outside this module
----------------------------------------------------------------------------*/


/*
------------------------------------------------------------------------------
 FUNCTION NAME: Bgn_scd_reset
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    state = points to memory of type Bgn_scdState.

 Outputs:
    The memory of type Bgn_scdState pointed to by state is set to all
        zeros.

 Returns:
    Returns 0 if memory was successfully initialized,
        otherwise returns -1.

 Global Variables Used:
    None.

 Local Variables Needed:
    None.

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

 Resets state memory.

------------------------------------------------------------------------------
 REQUIREMENTS

 None

------------------------------------------------------------------------------
 REFERENCES

 bgnscd.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

Word16 Bgn_scd_reset (Bgn_scdState *state)
{
   if (state == (Bgn_scdState *) NULL){
      fprintf(stderr, "Bgn_scd_reset: invalid parameter\n");
      return -1;
   }

   // Static vectors to zero
   Set_zero (state->frameEnergyHist, L_ENERGYHIST);

   // Initialize hangover handling
   state->bgHangover = 0;

   return 0;
}

------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

Word16  Bgn_scd_reset(Bgn_scdState *state)
{
    if (state == (Bgn_scdState *) NULL)
    {
        /* fprintf(stderr, "Bgn_scd_reset: invalid parameter\n");  */
        return(-1);
    }

    /* Static vectors to zero */
    oscl_memset(state->frameEnergyHist, 0, L_ENERGYHIST*sizeof(Word16));

    /* Initialize hangover handling */
    state->bgHangover = 0;

    return(0);
}

/****************************************************************************/

/*
------------------------------------------------------------------------------
 FUNCTION NAME: Bgn_scd
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    st = pointer to state variables of type Bgn_scdState
    ltpGainHist[] = LTP gain history (Word16)
    speech[] = synthesis speech frame (Word16)
    voicedHangover = pointer to # of frames after last voiced frame (Word16)
    pOverflow      = pointer to overflow indicator (Flag)

 Outputs:
    st = function updates the state variables of type Bgn_scdState
        pointed to by st.
    voicedHangover = function updates the # of frames after last voiced
        frame pointed to by voicedHangover.
    pOverflow = 1 if the basic math function L_add() results in saturation.
                  else pOverflow is zero.

 Returns:
    inbgNoise = flag if background noise is present (Word16)

 Global Variables Used:
    None.

 Local Variables Needed:
    None.

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

 Characterize synthesis speech and detect background noise.

------------------------------------------------------------------------------
 REQUIREMENTS

 None

------------------------------------------------------------------------------
 REFERENCES

 bgnscd.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

Word16 Bgn_scd (Bgn_scdState *st,      // i : State variables for bgn SCD
                Word16 ltpGainHist[],  // i : LTP gain history
                Word16 speech[],       // o : synthesis speech frame
                Word16 *voicedHangover // o : # of frames after last
                                              voiced frame
                )
{
   Word16 i;
   Word16 prevVoiced, inbgNoise;
   Word16 temp;
   Word16 ltpLimit, frameEnergyMin;
   Word16 currEnergy, noiseFloor, maxEnergy, maxEnergyLastPart;
   Word32 s;

   // Update the inBackgroundNoise flag (valid for use in next frame if BFI)
   // it now works as a energy detector floating on top
   // not as good as a VAD.

   currEnergy = 0;
   s = (Word32) 0;

   for (i = 0; i < L_FRAME; i++)
   {
       s = L_mac (s, speech[i], speech[i]);
   }

   s = L_shl(s, 2);

   currEnergy = extract_h (s);

   frameEnergyMin = 32767;

   for (i = 0; i < L_ENERGYHIST; i++)
   {
      if (sub(st->frameEnergyHist[i], frameEnergyMin) < 0)
         frameEnergyMin = st->frameEnergyHist[i];
   }

   noiseFloor = shl (frameEnergyMin, 4); // Frame Energy Margin of 16

   maxEnergy = st->frameEnergyHist[0];
   for (i = 1; i < L_ENERGYHIST-4; i++)
   {
      if ( sub (maxEnergy, st->frameEnergyHist[i]) < 0)
      {
         maxEnergy = st->frameEnergyHist[i];
      }
   }

   maxEnergyLastPart = st->frameEnergyHist[2*L_ENERGYHIST/3];
   for (i = 2*L_ENERGYHIST/3+1; i < L_ENERGYHIST; i++)
   {
      if ( sub (maxEnergyLastPart, st->frameEnergyHist[i] ) < 0)
      {
         maxEnergyLastPart = st->frameEnergyHist[i];
      }
   }

   inbgNoise = 0;        // false

   // Do not consider silence as noise
   // Do not consider continuous high volume as noise
   // Or if the current noise level is very low
   // Mark as noise if under current noise limit
   // OR if the maximum energy is below the upper limit

   if ( (sub(maxEnergy, LOWERNOISELIMIT) > 0) &&
        (sub(currEnergy, FRAMEENERGYLIMIT) < 0) &&
        (sub(currEnergy, LOWERNOISELIMIT) > 0) &&
        ( (sub(currEnergy, noiseFloor) < 0) ||
          (sub(maxEnergyLastPart, UPPERNOISELIMIT) < 0)))
   {
      if (sub(add(st->bgHangover, 1), 30) > 0)
      {
         st->bgHangover = 30;
      } else
      {
         st->bgHangover = add(st->bgHangover, 1);
      }
   }
   else
   {
      st->bgHangover = 0;
   }

   // make final decision about frame state , act somewhat cautiosly
   if (sub(st->bgHangover,1) > 0)
      inbgNoise = 1;       // true

   for (i = 0; i < L_ENERGYHIST-1; i++)
   {
      st->frameEnergyHist[i] = st->frameEnergyHist[i+1];
   }
   st->frameEnergyHist[L_ENERGYHIST-1] = currEnergy;

   // prepare for voicing decision; tighten the threshold after some
      time in noise
   ltpLimit = 13926;             // 0.85  Q14
   if (sub(st->bgHangover, 8) > 0)
   {
      ltpLimit = 15565;          // 0.95  Q14
   }
   if (sub(st->bgHangover, 15) > 0)
   {
      ltpLimit = 16383;          // 1.00  Q14
   }

   // weak sort of voicing indication.
   prevVoiced = 0;        // false

   if (sub(gmed_n(&ltpGainHist[4], 5), ltpLimit) > 0)
   {
      prevVoiced = 1;     // true
   }
   if (sub(st->bgHangover, 20) > 0) {
      if (sub(gmed_n(ltpGainHist, 9), ltpLimit) > 0)
      {
         prevVoiced = 1;  // true
      }
      else
      {
         prevVoiced = 0;  // false
      }
   }

   if (prevVoiced)
   {
      *voicedHangover = 0;
   }
   else
   {
      temp = add(*voicedHangover, 1);
      if (sub(temp, 10) > 0)
      {
         *voicedHangover = 10;
      }
      else
      {
         *voicedHangover = temp;
      }
   }

   return inbgNoise;
}

------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

Word16  Bgn_scd(Bgn_scdState *st,       /* i : State variables for bgn SCD  */
                Word16 ltpGainHist[],  /* i : LTP gain history             */
                Word16 speech[],       /* o : synthesis speech frame       */
                Word16 *voicedHangover,/* o : # of frames after last
                                               voiced frame                 */
                Flag   *pOverflow
               )
{
    Word16  i;
    Word16  prevVoiced, inbgNoise;
    Word16  temp;
    Word16  ltpLimit, frameEnergyMin;
    Word16  currEnergy, noiseFloor, maxEnergy, maxEnergyLastPart;
    Word32  s, L_temp;


    /* Update the inBackgroundNoise flag (valid for use in next frame if BFI)   */
    /* it now works as a energy detector floating on top                        */
    /* not as good as a VAD.                                                    */

    s = (Word32) 0;

    for (i = L_FRAME - 1; i >= 0; i--)
    {
        L_temp = ((Word32) speech[i]) * speech[i];
        if (L_temp != (Word32) 0x40000000L)
        {
            L_temp = L_temp << 1;
        }
        else
        {
            L_temp = MAX_32;
        }
        s = L_add(s, L_temp, pOverflow);
    }

    /* s is a sum of squares, so don't need to check for neg overflow */
    if (s > (Word32)0x1fffffffL)
    {
        currEnergy = MAX_16;
    }
    else
    {
        currEnergy = (Word16)(s >> 14);
    }

    frameEnergyMin = 32767;
    for (i = L_ENERGYHIST - 1; i >= 0; i--)
    {
        if (st->frameEnergyHist[i] < frameEnergyMin)
        {
            frameEnergyMin = st->frameEnergyHist[i];
        }
    }

    /* Frame Energy Margin of 16 */
    L_temp = (Word32)frameEnergyMin << 4;
    if (L_temp != (Word32)((Word16) L_temp))
    {
        if (L_temp > 0)
        {
            noiseFloor = MAX_16;
        }
        else
        {
            noiseFloor = MIN_16;
        }
    }
    else
    {
        noiseFloor = (Word16)(L_temp);
    }

    maxEnergy = st->frameEnergyHist[0];
    for (i = L_ENERGYHIST - 5; i >= 1; i--)
    {
        if (maxEnergy < st->frameEnergyHist[i])
        {
            maxEnergy = st->frameEnergyHist[i];
        }
    }

    maxEnergyLastPart = st->frameEnergyHist[2*L_ENERGYHIST/3];
    for (i = 2 * L_ENERGYHIST / 3 + 1; i < L_ENERGYHIST; i++)
    {
        if (maxEnergyLastPart < st->frameEnergyHist[i])
        {
            maxEnergyLastPart = st->frameEnergyHist[i];
        }
    }

    /* Do not consider silence as noise */
    /* Do not consider continuous high volume as noise */
    /* Or if the current noise level is very low */
    /* Mark as noise if under current noise limit */
    /* OR if the maximum energy is below the upper limit */

    if ((maxEnergy > LOWERNOISELIMIT) &&
            (currEnergy < FRAMEENERGYLIMIT) &&
            (currEnergy > LOWERNOISELIMIT) &&
            ((currEnergy < noiseFloor) ||
             (maxEnergyLastPart < UPPERNOISELIMIT)))
    {
        if ((st->bgHangover + 1) > 30)
        {
            st->bgHangover = 30;
        }
        else
        {
            st->bgHangover += 1;
        }
    }
    else
    {
        st->bgHangover = 0;
    }

    /* make final decision about frame state , act somewhat cautiosly */

    if (st->bgHangover > 1)
    {
        inbgNoise = TRUE;
    }
    else
    {
        inbgNoise = FALSE;
    }

    for (i = 0; i < L_ENERGYHIST - 1; i++)
    {
        st->frameEnergyHist[i] = st->frameEnergyHist[i+1];
    }
    st->frameEnergyHist[L_ENERGYHIST-1] = currEnergy;

    /* prepare for voicing decision; tighten the threshold after some
       time in noise */

    if (st->bgHangover > 15)
    {
        ltpLimit = 16383;       /* 1.00  Q14 */
    }
    else if (st->bgHangover > 8)
    {
        ltpLimit = 15565;       /* 0.95  Q14 */
    }
    else
    {
        ltpLimit = 13926;       /* 0.85  Q14 */
    }

    /* weak sort of voicing indication. */
    prevVoiced = FALSE;

    if (gmed_n(&ltpGainHist[4], 5) > ltpLimit)
    {
        prevVoiced = TRUE;
    }

    if (st->bgHangover > 20)
    {
        if (gmed_n(ltpGainHist, 9) > ltpLimit)
        {
            prevVoiced = TRUE;
        }
        else
        {
            prevVoiced = FALSE;
        }
    }


    if (prevVoiced)
    {
        *voicedHangover = 0;
    }
    else
    {
        temp = *voicedHangover + 1;

        if (temp > 10)
        {
            *voicedHangover = 10;
        }
        else
        {
            *voicedHangover = temp;
        }
    }

    return(inbgNoise);
}


/* ==================================================================
 * Section: opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/c_g_aver.c
 * ==================================================================
 */

/* ------------------------------------------------------------------
 * Copyright (C) 1998-2009 PacketVideo
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 * -------------------------------------------------------------------
 */
/****************************************************************************************
Portions of this file are derived from the following 3GPP standard:

    3GPP TS 26.073
    ANSI-C code for the Adaptive Multi-Rate (AMR) speech codec
    Available from http://www.3gpp.org

(C) 2004, 3GPP Organizational Partners (ARIB, ATIS, CCSA, ETSI, TTA, TTC)
Permission to distribute, modify and use this file under the standard license
terms listed above has been obtained from the copyright holder.
****************************************************************************************/
/*
------------------------------------------------------------------------------



 Filename: c_g_aver.c
 Functions:
            Cb_gain_average_reset
            Cb_gain_average

------------------------------------------------------------------------------
 MODULE DESCRIPTION

 This file contains functions that reset and perform
 codebook gain calculations.

------------------------------------------------------------------------------
*/


/*----------------------------------------------------------------------------
; INCLUDES
----------------------------------------------------------------------------*/
#include    "c_g_aver.h"
#include    "typedef.h"
#include    "mode.h"
#include    "cnst.h"

#include    "basic_op.h"
#include    "oscl_mem.h"

/*----------------------------------------------------------------------------
; MACROS
; Define module specific macros here
----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------
; DEFINES
; Include all pre-processor statements here. Include conditional
; compile variables also.
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
; LOCAL FUNCTION DEFINITIONS
; Function Prototype declaration
----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
; LOCAL VARIABLE DEFINITIONS
; Variable declaration - defined here and used outside this module
----------------------------------------------------------------------------*/

/*
------------------------------------------------------------------------------
 FUNCTION NAME: Cb_gain_average_reset
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    state = pointer to a structure of type Cb_gain_averageState

 Outputs:
    Structure pointed to by state is initialized to zeros

 Returns:
    Returns 0 if memory was successfully initialized,
        otherwise returns -1.

 Global Variables Used:
    None.

 Local Variables Needed:
    None.

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

 Resets state memory

------------------------------------------------------------------------------
 REQUIREMENTS

 None.

------------------------------------------------------------------------------
 REFERENCES

 c_g_aver.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

Word16 Cb_gain_average_reset (Cb_gain_averageState *state)
{
   if (state == (Cb_gain_averageState *) NULL){
      fprintf(stderr, "Cb_gain_average_reset: invalid parameter\n");
      return -1;
   }

   // Static vectors to zero
   Set_zero (state->cbGainHistory, L_CBGAINHIST);

   // Initialize hangover handling
   state->hangVar = 0;
   state->hangCount= 0;

   return 0;
}

------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

Word16  Cb_gain_average_reset(Cb_gain_averageState *state)
{
    if (state == (Cb_gain_averageState *) NULL)
    {
        /* fprint(stderr, "Cb_gain_average_reset: invalid parameter\n");  */
        return(-1);
    }

    /* Static vectors to zero */
    oscl_memset(state->cbGainHistory, 0, L_CBGAINHIST*sizeof(Word16));

    /* Initialize hangover handling */
    state->hangVar = 0;
    state->hangCount = 0;

    return(0);
}

/****************************************************************************/

/*
------------------------------------------------------------------------------
 FUNCTION NAME: Cb_gain_average
------------------------------------------------------------------------------
 INPUT AND OUTPUT DEFINITIONS

 Inputs:
    st = pointer to structure of type Cb_gain_averageState
    mode = AMR mode (enum Mode)
    gain_code = CB gain (Word16)
    lsp = the LSP for the current frame (Word16)
    lspAver = the average of LSP for 8 frames (Word16)
    bfi = bad frame indication flag (Word16)
    prev_bf = previous bad frame indication flag (Word16)
    pdfi = potential degraded bad frame ind flag (Word16)
    prev_pdf = prev pot. degraded bad frame ind flag (Word16)
    inBackgroundNoise = background noise decision (Word16)
    voicedHangover = # of frames after last voiced frame (Word16)
    pOverflow = address of overflow (Flag)

 Returns:
    cbGainMix = codebook gain (Word16)

 Outputs:
    None.

 Global Variables Used:
    None.

 Local Variables Needed:
    None.

------------------------------------------------------------------------------
 FUNCTION DESCRIPTION

 The mix cb gains for MR475, MR515, MR59, MR67, MR102; gain_code other modes

------------------------------------------------------------------------------
 REQUIREMENTS

 None.

------------------------------------------------------------------------------
 REFERENCES

 c_g_aver.c, UMTS GSM AMR speech codec, R99 - Version 3.2.0, March 2, 2001

------------------------------------------------------------------------------
 PSEUDO-CODE

Word16 Cb_gain_average (
   Cb_gain_averageState *st, // i/o : State variables for CB gain avergeing
   enum Mode mode,           // i   : AMR mode
   Word16 gain_code,         // i   : CB gain                              Q1
   Word16 lsp[],             // i   : The LSP for the current frame       Q15
   Word16 lspAver[],         // i   : The average of LSP for 8 frames     Q15
   Word16 bfi,               // i   : bad frame indication flag
   Word16 prev_bf,           // i   : previous bad frame indication flag
   Word16 pdfi,              // i   : potential degraded bad frame ind flag
   Word16 prev_pdf,          // i   : prev pot. degraded bad frame ind flag
   Word16 inBackgroundNoise, // i   : background noise decision
   Word16 voicedHangover     // i   : # of frames after last voiced frame
   )
{
   //---------------------------------------------------------*
    * Compute mixed cb gain, used to make cb gain more        *
    * smooth in background noise for modes 5.15, 5.9 and 6.7  *
    * states that needs to be updated by all                  *
    *---------------------------------------------------------
   Word16 i;
   Word16 cbGainMix, diff, tmp_diff, bgMix, cbGainMean;
   Word32 L_sum;
   Word16 tmp[M], tmp1, tmp2, shift1, shift2, shift;

   // set correct cbGainMix for MR74, MR795, MR122
   cbGainMix = gain_code;

    *-------------------------------------------------------*
    *   Store list of CB gain needed in the CB gain         *
    *   averaging                                           *
    *-------------------------------------------------------*
   for (i = 0; i < (L_CBGAINHIST-1); i++)
   {
      st->cbGainHistory[i] = st->cbGainHistory[i+1];
   }
   st->cbGainHistory[L_CBGAINHIST-1] = gain_code;

   // compute lsp difference
   for (i = 0; i < M; i++) {
      tmp1 = abs_s(sub(lspAver[i], lsp[i]));  // Q15
      shift1 = sub(norm_s(tmp1), 1);          // Qn
      tmp1 = shl(tmp1, shift1);               // Q15+Qn
      shift2 = norm_s(lspAver[i]);            // Qm
      tmp2 = shl(lspAver[i], shift2);         // Q15+Qm
      tmp[i] = div_s(tmp1, tmp2);             // Q15+(Q15+Qn)-(Q15+Qm)
      shift = sub(add(2, shift1), shift2);
      if (shift >= 0)
      {
         tmp[i] = shr(tmp[i], shift); // Q15+Qn-Qm-Qx=Q13
      }
      else
      {
         tmp[i] = shl(tmp[i], negate(shift)); // Q15+Qn-Qm-Qx=Q13
      }
   }

   diff = tmp[0];
   for (i = 1; i < M; i++) {
      diff = add(diff, tmp[i]);       // Q13
   }

   // Compute hangover
   if (sub(diff, 5325) > 0)  // 0.65 in Q11
   {
      st->hangVar = add(st->hangVar, 1);
   }
   else
   {
      st->hangVar = 0;
   }

   if (sub(st->hangVar, 10) > 0)
   {
      st->hangCount = 0;  // Speech period, reset hangover variable
   }

   // Compute mix constant (bgMix)
   bgMix = 8192;    // 1 in Q13
   if ((sub(mode, MR67) <= 0) || (sub(mode, MR102) == 0))
      // MR475, MR515, MR59, MR67, MR102
   {
      // if errors and presumed noise make smoothing probability stronger
      if (((((pdfi != 0) && (prev_pdf != 0)) || (bfi != 0) || (prev_bf != 0)) &&
          (sub(voicedHangover, 1) > 0) && (inBackgroundNoise != 0) &&
          ((sub(mode, MR475) == 0) ||
           (sub(mode, MR515) == 0) ||
           (sub(mode, MR59) == 0)) ))
      {
         // bgMix = min(0.25, max(0.0, diff-0.55)) / 0.25;
         tmp_diff = sub(diff, 4506);   // 0.55 in Q13

         // max(0.0, diff-0.55)
         if (tmp_diff > 0)
         {
            tmp1 = tmp_diff;
         }
         else
         {
            tmp1 = 0;
         }

         // min(0.25, tmp1)
         if (sub(2048, tmp1) < 0)
         {
            bgMix = 8192;
         }
         else
         {
            bgMix = shl(tmp1, 2);
         }
      }
      else
      {
         // bgMix = min(0.25, max(0.0, diff-0.40)) / 0.25;
         tmp_diff = sub(diff, 3277); // 0.4 in Q13

         // max(0.0, diff-0.40)
         if (tmp_diff > 0)
         {
            tmp1 = tmp_diff;
         }
         else
         {
            tmp1 = 0;
         }

         // min(0.25, tmp1)
         if (sub(2048, tmp1) < 0)
         {
            bgMix = 8192;
         }
         else
         {
            bgMix = shl(tmp1, 2);
         }
      }

      if ((sub(st->hangCount, 40) < 0) || (sub(diff, 5325) > 0)) // 0.65 in Q13
      {
         bgMix = 8192;  // disable mix if too short time since
      }

      // Smoothen the cb gain trajectory
      // smoothing depends on mix constant bgMix
      L_sum = L_mult(6554, st->cbGainHistory[2]); // 0.2 in Q15; L_sum in Q17
      for (i = 3; i < L_CBGAINHIST; i++)
      {
         L_sum = L_mac(L_sum, 6554, st->cbGainHistory[i]);
      }
      cbGainMean = pv_round(L_sum);                      // Q1

      // more smoothing in error and bg noise (NB no DFI used  here)
      if (((bfi != 0) || (prev_bf != 0)) && (inBackgroundNoise != 0) &&
          ((sub(mode, MR475) == 0) ||
           (sub(mode, MR515) == 0) ||
           (sub(mode, MR59) == 0)) )
      {
         L_sum = L_mult(4681, st->cbGainHistory[0]); // 0.143 in Q15; L_sum in Q17
         for (i = 1; i < L_CBGAINHIST; i++)
         {
            L_sum = L_mac(L_sum, 4681, st->cbGainHistory[i]);
         }
         cbGainMean = pv_round(L_sum);                   // Q1
      }

      // cbGainMix = bgMix*cbGainMix + (1-bgMix)*cbGainMean;
      L_sum = L_mult(bgMix, cbGainMix);               // L_sum in Q15
      L_sum = L_mac(L_sum, 8192, cbGainMean);
      L_sum = L_msu(L_sum, bgMix, cbGainMean);
      cbGainMix = pv_round(L_shl(L_sum, 2));             // Q1
   }

   st->hangCount = add(st->hangCount, 1);
   return cbGainMix;
}

------------------------------------------------------------------------------
 CAUTION [optional]
 [State any special notes, constraints or cautions for users of this function]

------------------------------------------------------------------------------
*/

Word16 Cb_gain_average(
    Cb_gain_averageState *st, /* i/o : State variables for CB gain averaging */
    enum Mode mode,           /* i   : AMR mode                              */
    Word16 gain_code,         /* i   : CB gain                            Q1 */
    Word16 lsp[],             /* i   : The LSP for the current frame     Q15 */
    Word16 lspAver[],         /* i   : The average of LSP for 8 frames   Q15 */
    Word16 bfi,               /* i   : bad frame indication flag             */
    Word16 prev_bf,           /* i   : previous bad frame indication flag    */
    Word16 pdfi,              /* i   : potential degraded bad frame ind flag */
    Word16 prev_pdf,          /* i   : prev pot. degraded bad frame ind flag */
    Word16 inBackgroundNoise, /* i   : background noise decision             */
    Word16 voicedHangover,    /* i   : # of frames after last voiced frame   */
    Flag   *pOverflow
)
{
    Word16 i;
    Word16 cbGainMix;
    Word16 diff;
    Word16 tmp_diff;
    Word16 bgMix;
    Word16 cbGainMean;
    Word32 L_sum;
    Word16 tmp[M];
    Word16 tmp1;
    Word16 tmp2;
    Word16 shift1;
    Word16 shift2;
    Word16 shift;

    /*---------------------------------------------------------*
     * Compute mixed cb gain, used to make cb gain more        *
     * smooth in background noise for modes 5.15, 5.9 and 6.7  *
     * states that needs to be updated by all                  *
     *---------------------------------------------------------*/

    /* set correct cbGainMix for MR74, MR795, MR122 */
    cbGainMix = gain_code;

    /*-------------------------------------------------------*
     *   Store list of CB gain needed in the CB gain         *
     *   averaging                                           *
     *-------------------------------------------------------*/
    for (i = 0; i < (L_CBGAINHIST - 1); i++)
    {
        st->cbGainHistory[i] = st->cbGainHistory[i+1];
    }
    st->cbGainHistory[L_CBGAINHIST-1] = gain_code;

    diff = 0;

    /* compute lsp difference */
    for (i = 0; i < M; i++)
    {
        tmp1 = abs_s(sub(*(lspAver + i), *(lsp + i), pOverflow));
        /* Q15      */
        shift1 = norm_s(tmp1) - 1 ;                     /* Qn       */
        tmp1 = shl(tmp1, shift1, pOverflow);            /* Q15+Qn   */
        shift2 = norm_s(*(lspAver + i));                /* Qm       */
        tmp2 = shl(*(lspAver + i), shift2, pOverflow);  /* Q15+Qm   */
        tmp[i] = div_s(tmp1, tmp2);        /* Q15+(Q15+Qn)-(Q15+Qm) */

        shift = 2 + shift1 - shift2;

        if (shift >= 0)
        {
            *(tmp + i) = shr(*(tmp + i), shift, pOverflow);
            /* Q15+Qn-Qm-Qx=Q13 */
        }
        else
        {
            *(tmp + i) = shl(*(tmp + i), negate(shift), pOverflow);
            /* Q15+Qn-Qm-Qx=Q13 */
        }

        diff = add_16(diff, *(tmp + i), pOverflow);           /* Q13 */
    }

    /* Compute hangover */

    if (diff > 5325)                /* 0.65 in Q11 */
    {
        st->hangVar += 1;
    }
    else
    {
        st->hangVar = 0;
    }


    if (st->hangVar > 10)
    {
        /* Speech period, reset hangover variable */
        st->hangCount = 0;
    }

    /* Compute mix constant (bgMix) */
    bgMix = 8192;    /* 1 in Q13 */

    if ((mode <= MR67) || (mode == MR102))
        /* MR475, MR515, MR59, MR67, MR102 */
    {
        /* if errors and presumed noise make smoothing probability stronger */

        if (((((pdfi != 0) && (prev_pdf != 0)) || (bfi != 0) ||
                (prev_bf != 0))
                && (voicedHangover > 1)
                && (inBackgroundNoise != 0)
                && ((mode == MR475) || (mode == MR515) ||
                    (mode == MR59))))
        {
            /* bgMix = min(0.25, max(0.0, diff-0.55)) / 0.25; */
            tmp_diff = diff - 4506;   /* 0.55 in Q13 */
        }
        else
        {
            /* bgMix = min(0.25, max(0.0, diff-0.40)) / 0.25; */
            tmp_diff = diff - 3277; /* 0.4 in Q13 */
        }

        /* max(0.0, diff-0.55)  or  */
        /* max(0.0, diff-0.40) */
        if (tmp_diff > 0)
        {
            tmp1 = tmp_diff;
        }
        else
        {
            tmp1 = 0;
        }

        /* min(0.25, tmp1) */
        if (2048 < tmp1)
        {
            bgMix = 8192;
        }
        else
        {
            bgMix = shl(tmp1, 2, pOverflow);
        }

        if ((st->hangCount < 40) || (diff > 5325)) /* 0.65 in Q13 */
        {
            /* disable mix if too short time since */
            bgMix = 8192;
        }

        /* Smoothen the cb gain trajectory  */
        /* smoothing depends on mix constant bgMix */
        L_sum = L_mult(6554, st->cbGainHistory[2], pOverflow);
        /* 0.2 in Q15; L_sum in Q17 */

        for (i = 3; i < L_CBGAINHIST; i++)
        {
            L_sum = L_mac(L_sum, 6554, st->cbGainHistory[i], pOverflow);
        }
        cbGainMean = pv_round(L_sum, pOverflow);               /* Q1 */

        /* more smoothing in error and bg noise (NB no DFI used here) */

        if (((bfi != 0) || (prev_bf != 0)) && (inBackgroundNoise != 0)
                && ((mode == MR475) || (mode == MR515)
                    || (mode == MR59)))
        {
            /* 0.143 in Q15; L_sum in Q17    */
            L_sum = L_mult(4681, st->cbGainHistory[0], pOverflow);
            for (i = 1; i < L_CBGAINHIST; i++)
            {
                L_sum =
                    L_mac(L_sum, 4681, st->cbGainHistory[i], pOverflow);
            }
            cbGainMean = pv_round(L_sum, pOverflow);              /* Q1 */
        }

        /* cbGainMix = bgMix*cbGainMix + (1-bgMix)*cbGainMean; */
        /* L_sum in Q15 */
        L_sum = L_mult(bgMix, cbGainMix, pOverflow);
        L_sum = L_mac(L_sum, 8192, cbGainMean, pOverflow);
        L_sum = L_msu(L_sum, bgMix, cbGainMean, pOverflow);
        cbGainMix = pv_round(L_shl(L_sum, 2, pOverflow), pOverflow);  /* Q1 */
    }

    st->hangCount += 1;

    return (cbGainMix);
}
