NOJME v36.33-fixed — что нового и как проверять
================================================

СБОРКА
  Распаковать tarball, в devkitPro-окружении:
      make switchui
  Результат: нетром nojme.nro (или как в вашей обвязке). Якорь версии:
  include/core_version.h -> CORE_BUILD_ID "v36.33-2026-09-26" (баннер
  печатается при старте — сверьте в логе, что работает именно эта сборка).

ЭТА ВЕРСИЯ ЗАКРЫВАЕТ
  1) Краш «Invalid memory access 0x736D722E65726F74» ("tore.rms") и
     прежний 0x745364726F636572 ("recordSt") — это ОДНА строка
     "recordStore.rms" (имя RMS-стора Temple Rush 3D 2), прочитанная
     с разных смещений из переиспользованной освобождённой памяти.
     Корень: нативные пиры java.util.Hashtable переживали сброс кучи
     между сессиями; повторный запуск игры (особенно после выхода с
     ошибкой) получал Hashtable с ключами мёртвой сессии и падал при
     первом обращении. Исправлено в трёх слоях:
       - [HT-PEER-SESSION-RESET] все пиры освобождаются на границе
         сессии (лог: "[HT-PEERS] session reset: freed N hashtable
         peer(s)");
       - [HT-PEER-SWEEP] GC больше не освобождает чужой пир по
         случайному значению поля "threshold" — только по точному
         совпадению объекта-владельца;
       - [HT-KEY-VALIDATE] протухшие ключи/значения чистятся на месте
         (краш невозможен даже при остаточной протухости).
  2) Jewel Adventure [480x800] — «закрывается не показывая ничего»:
     а) StringBuffer.insert(IC)/(II)/(IJ)/(IZ)/(I[C) НЕ БЫЛО в стабах —
        цифры имён пакета ресурсов молча терялись, игра запрашивала
        «RP.rp» вместо «/RP6.rp» и умирала в startApp. Добавлены все
        оверлоады;
     б) у java.lang.Long не было инстансного toString() — вместо числа
        игра получала «java.lang.Long@<hash>» и падала при парсинге;
     в) куча поднята 64 -> 96 MB — игра перечитывает пак 1.9 MB каждые
        ~150 мс, на 64 MB поймала OOM в загрузчике (чёрный экран).
  3) Speedx 3D [240x320] — не было javax.xml.parsers/org.xml.sax вовсе:
    .newInstance() давал null, шрифты (font_*.xml) не парсились, текста
     в игре нет. Реализован минимальный SAX (новый файл src/jvm/sax.c):
     SAXParserFactory/SAXParser.parse (в т.ч. через InputSource),
     DefaultHandler, AttributesImpl, InputSource; внутри компактный
     XML-сканер (атрибуты, entities, CDATA, комментарии). Шрифты парсятся,
     текст рендерится.
  4) Image.createImage("/file.png") / getResourceAsStream("/file.png")
     с ВЕДУЩИМ СЛЭШЕМ не находили ресурс в jar (Speedx: IOException на
     «/font_button.png» при живом файле). jar_read_file теперь срезает
     ведущие '/'. Это чинит ЦЕЛЫЙ КЛАСС игр с абсолютными путями.
  5) Сохранения: RMS-цепочка не тронута (фиксы v36.31/32 в силе),
     test_switch_zuma.sh: 3 стора пишутся, вторая сессия читает с диска.

ПРО ZUMA X [640x480] И «DRM» — короткий ответ: НЕТ, это не DRM.
  Публичный zip — неполный дистрибутив: в jar НЕТ контента уровней
  (*.cfg), НЕТ класса w.class, а лежащие l0dr*.jpg — ассеты другого
  разрешения (игра запрашивает «/l64dr<n>.png» — вариант 640x480).
  Лог подтверждает: [JAR-READ] FAILED: 'l64dr1.png' -> каскад NPE ->
  игра САМА выходит (notifyDestroyed) -> чёрный экран -> меню.
  GlomoReg-DRM-классов в jar нет; glomo.cfg читается самой игрой как
  таблица ресурсов. ЧТО НУЖНО: полный jar 640x480 (контент-пак l64*/
  cfg/w.class) — на текущем ядре он пойдёт без доп. фиксов.
  P.S. Temple Rush 3D 2 в логе сыплет com.nokia.payment NPayException —
  это собственный платёжный модуль игры, не эмулятор; игра продолжает
  работать.

КАК ПРОВЕРИТЬ ФИКСЫ НА УСТРОЙСТВЕ
  - Включите лог (Настройки -> Лог) и погоните Temple Rush 3D 2:
    запуск -> выход через паузу -> повторный запуск. В логе при каждом
    завершении сессии должна появиться строка
    «[HT-PEERS] session reset: freed N hashtable peer(s)» (N>0 после
    игры, которая пользовалась Hashtable) — и НИКАКИХ
    «Invalid memory access 0x736D722E65726F74/0x745364726F636572».
  - Speedx 3D: в меню/игре появился текст (битмап-шрифты из font_*.xml).
  - Jewel Adventure: игра доходит до геймплея, повторный запуск чист.
  - Если что-то падает — пришлите хвост trace-лога за ~30 c до падения
    (не обрывайте запись): строки [HT-PEERS]/[HEAP-OOM]/[SAX]/[JAR-READ]
    сразу назовут сайт.

ТЕСТЫ (все прогнаны на этой сборке)
  games3 (Speedx/Jewel/Temple, 2 сессии с выходами) ALL PASSED;
  metests (MicroEmulator-сьют), sysinfo, e2e, badlaunch, excreset,
  ttrelaunch, pausemenu, keystuck, props, touch, fontform, s2x, fpsstrip,
  flipfps, rotation, ui3617, hotrot, audiomix, miditempo, switch-input,
  zuma, soak_close (AsiaRally3D 3x40 c), make check (30 файлов) — ALL
  PASSED; ASAN-прогон games3+Temple+metests — 0 отчётов (до фикса —
  Segmentation fault на каждом прогоне Temple).

ФАЙЛЫ
  nojme-j2me-v36.33-fixed.tar.gz — исходники (собирать `make switchui`).
  Этот README — краткая памятка по проверке; полная техдетализация —
  FIXES.txt, сессия 76.
