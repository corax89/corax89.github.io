@echo off
set SDK_HOME=C:\Java_ME_platform_SDK_3.0
set APP_DIR=%SDK_HOME%\apps\test

echo ========================================
echo Building ArrayTest for J2ME (Java 1.3)
echo ========================================
echo.

echo [1/4] Cleaning old files...
if exist %APP_DIR%\classes\*.class del %APP_DIR%\classes\*.class
if exist %APP_DIR%\bin\*.jar del %APP_DIR%\bin\*.jar
if exist %APP_DIR%\bin\MANIFEST.MF del %APP_DIR%\bin\MANIFEST.MF

echo [2/4] Compiling with source/target 1.3...
javac -source 1.3 -target 1.3 -bootclasspath "%SDK_HOME%\lib\cldc_1.1.jar;%SDK_HOME%\lib\midp_2.0.jar" -d %APP_DIR%\classes %APP_DIR%\src\ArrayTestMidlet.java
if errorlevel 1 goto error

echo [3/4] Preverifying...
%SDK_HOME%\bin\preverify -classpath "%SDK_HOME%\lib\cldc_1.1.jar;%SDK_HOME%\lib\midp_2.0.jar" -d %APP_DIR%\classes %APP_DIR%\classes
if errorlevel 1 goto error

echo [4/4] Creating JAR...
echo MIDlet-Name: ArrayTest > %APP_DIR%\bin\MANIFEST.MF
echo MIDlet-Vendor: Test >> %APP_DIR%\bin\MANIFEST.MF
echo MIDlet-Version: 1.0 >> %APP_DIR%\bin\MANIFEST.MF
echo MIDlet-1: ArrayTest,,ArrayTestMidlet >> %APP_DIR%\bin\MANIFEST.MF
echo MicroEdition-Configuration: CLDC-1.1 >> %APP_DIR%\bin\MANIFEST.MF
echo MicroEdition-Profile: MIDP-2.0 >> %APP_DIR%\bin\MANIFEST.MF
echo. >> %APP_DIR%\bin\MANIFEST.MF

cd %APP_DIR%\classes
jar cfm %APP_DIR%\bin\ArrayTest.jar %APP_DIR%\bin\MANIFEST.MF *.class
cd %APP_DIR%

echo.
echo ========================================
echo Build successful!
echo ========================================
echo JAR created: %APP_DIR%\bin\ArrayTest.jar
echo.
echo Class version should be 47.0 (Java 1.3)
echo.
dir %APP_DIR%\bin\ArrayTest.jar
echo.
pause
goto end

:error
echo.
echo ========================================
echo BUILD FAILED!
echo ========================================
pause

:end