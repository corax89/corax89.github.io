import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class ArrayTestMidlet extends MIDlet {
    private Display display;
    private TestCanvas canvas;
    
    public ArrayTestMidlet() {
        display = Display.getDisplay(this);
        canvas = new TestCanvas(this);
    }
    
    public void startApp() {
        display.setCurrent(canvas);
        canvas.startTests();
    }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }
}

class TestCanvas extends Canvas {
    private MIDlet midlet;
    private String[] results;
    private String[] testNames;
    private boolean testsRunning = true;
    private int currentTest = 0;
    private String[] log = new String[10];
    private int logIndex = 0;
    
    public TestCanvas(MIDlet m) {
        this.midlet = m;
        
        testNames = new String[] {
            "1 + 1 = 2",
            "5 * 3 = 15", 
            "10 / 2 = 5",
            "Create int[3]",
            "Array set/get",
            "Array loop sum"
        };
        results = new String[testNames.length];
        for (int i = 0; i < results.length; i++) {
            results[i] = "?";
        }
        
        // ������� ���
        for (int i = 0; i < log.length; i++) {
            log[i] = "";
        }
    }
    
    private void addLog(String msg) {
        log[logIndex % log.length] = msg;
        logIndex++;
        repaint();
    }
    
    public void startTests() {
        new Thread() {
            public void run() {
                runTests();
                testsRunning = false;
                repaint();
            }
        }.start();
    }
    
    private void runTests() {
        // ���� 1: 1 + 1 = 2
        currentTest = 0;
        int r1 = 1 + 1;
        results[0] = (r1 == 2) ? "PASS" : "FAIL";
        addLog("Test 1: 1+1=" + r1 + " " + results[0]);
        sleep(500);
        
        // ���� 2: 5 * 3 = 15
        currentTest = 1;
        int r2 = 5 * 3;
        results[1] = (r2 == 15) ? "PASS" : "FAIL";
        addLog("Test 2: 5*3=" + r2 + " " + results[1]);
        sleep(500);
        
        // ���� 3: 10 / 2 = 5
        currentTest = 2;
        int r3 = 10 / 2;
        results[2] = (r3 == 5) ? "PASS" : "FAIL";
        addLog("Test 3: 10/2=" + r3 + " " + results[2]);
        sleep(500);
        
        // ���� 4: ������� ������ int[3]
        currentTest = 3;
        try {
            int[] arr = new int[3];
            results[3] = (arr != null && arr.length == 3) ? "PASS" : "FAIL";
            addLog("Test 4: new int[3] length=" + arr.length + " " + results[3]);
        } catch (Exception e) {
            results[3] = "FAIL";
            addLog("Test 4: ERROR - " + e.getClass().getName());
        }
        sleep(500);
        
        // ���� 5: ������ � ������ �� �������
        currentTest = 4;
        try {
            int[] arr = new int[3];
            arr[0] = 42;
            arr[1] = 100;
            arr[2] = 255;
            
            boolean ok = (arr[0] == 42 && arr[1] == 100 && arr[2] == 255);
            results[4] = ok ? "PASS" : "FAIL";
            addLog("Test 5: arr[0]=" + arr[0] + " arr[1]=" + arr[1] + " arr[2]=" + arr[2] + " " + results[4]);
        } catch (Exception e) {
            results[4] = "FAIL";
            addLog("Test 5: ERROR - " + e.getClass().getName());
        }
        sleep(500);
        
        // ���� 6: ����� ��������� �������
        currentTest = 5;
        try {
            int[] arr = new int[4];
            arr[0] = 1;
            arr[1] = 2;
            arr[2] = 3;
            arr[3] = 4;
            
            int sum = 0;
            for (int i = 0; i < arr.length; i++) {
                sum += arr[i];
            }
            
            results[5] = (sum == 10) ? "PASS" : "FAIL";
            addLog("Test 6: sum=" + sum + " " + results[5]);
        } catch (Exception e) {
            results[5] = "FAIL";
            addLog("Test 6: ERROR - " + e.getClass().getName());
        }
        
        addLog("=== ALL TESTS COMPLETED ===");
    }
    
    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (Exception e) {}
    }
    
    protected void paint(Graphics g) {
        // ������� �����
        g.setColor(255, 255, 255);
        g.fillRect(0, 0, getWidth(), getHeight());
        
        int y = 15;
        int width = getWidth();
        
        // ���������
        g.setColor(0, 0, 0);
        g.drawString("Simple Tests", width/2, y, Graphics.TOP | Graphics.HCENTER);
        y += 20;
        
        if (testsRunning) {
            // ���������� ������� ����
            g.setColor(0, 0, 150);
            g.drawString("Running test " + (currentTest + 1) + "/" + testNames.length, 
                        5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            g.drawString(testNames[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            g.drawString("Result: " + results[currentTest], 5, y, Graphics.TOP | Graphics.LEFT);
            y += 25;
            
            // ��� ����������
            g.setColor(100, 100, 100);
            g.drawString("--- Log ---", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 15;
            
            for (int i = 0; i < log.length; i++) {
                int idx = (logIndex - log.length + i + log.length) % log.length;
                if (log[idx].length() > 0) {
                    g.drawString(log[idx], 10, y, Graphics.TOP | Graphics.LEFT);
                    y += 15;
                }
            }
            
            // ��������-���
            y = getHeight() - 30;
            int progressWidth = (width - 40) * (currentTest + 1) / testNames.length;
            g.setColor(0, 150, 0);
            g.fillRect(20, y, progressWidth, 15);
            g.setColor(200, 200, 200);
            g.fillRect(20 + progressWidth, y, (width - 40) - progressWidth, 15);
            
        } else {
            // ���������� ��� ����������
            g.setColor(0, 0, 0);
            g.drawString("RESULTS:", 5, y, Graphics.TOP | Graphics.LEFT);
            y += 20;
            
            for (int i = 0; i < testNames.length; i++) {
                if (results[i].equals("PASS")) {
                    g.setColor(0, 150, 0);
                } else {
                    g.setColor(200, 0, 0);
                }
                g.drawString(results[i] + " - " + testNames[i], 5, y, Graphics.TOP | Graphics.LEFT);
                y += 20;
            }
            
            y += 10;
            g.setColor(0, 0, 150);
            g.drawString("Press any key to exit", width/2, getHeight() - 20, 
                        Graphics.BOTTOM | Graphics.HCENTER);
        }
    }
    
    protected void keyPressed(int keyCode) {
        if (!testsRunning) {
            midlet.notifyDestroyed();
        }
    }
}