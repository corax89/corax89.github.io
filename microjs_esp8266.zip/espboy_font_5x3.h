/* espboy_font_5x3.h — compact 5-pixel-high variable-width font.
 * Adapted from StackerFont by AdaaamB (https://github.com/AdaaamB/Stacker).
 * Each entry: {width, col0, col1, col2, col3, col4}
 * col bits: bit0=top, bit4=bottom (5 rows).
 * Index = char - 32 (space=0, A=33, etc.)
 * Maximum char width: 5px, height: 5px.  Much more compact than
 * the 5x7 font, allowing more text on the 64x64 screen.
 */
#ifndef ESPBOY_FONT_5X3_H
#define ESPBOY_FONT_5X3_H

static const uint8_t g_font_5x3[96][6] PROGMEM = {
  {2, 0, 0, 0, 0, 0},  // 32 ' '
  {4, 16, 16, 0, 16, 0},  // 33 '!'
  {3, 3, 0, 3, 0, 0},  // 34 '"'
  {3, 31, 10, 31, 0, 0},  // 35 '#'
  {3, 22, 31, 13, 0, 0},  // 36 '$'
  {3, 9, 4, 18, 0, 0},  // 37 '%'
  {3, 10, 21, 26, 0, 0},  // 38 '&'
  {1, 3, 0, 0, 0, 0},  // 39 "'"
  {2, 14, 17, 0, 0, 0},  // 40 '('
  {2, 17, 14, 0, 0, 0},  // 41 ')'
  {3, 10, 4, 10, 0, 0},  // 42 '*'
  {3, 4, 14, 4, 0, 0},  // 43 '+'
  {2, 16, 8, 0, 0, 0},  // 44 ','
  {3, 4, 4, 4, 0, 0},  // 45 '-'
  {1, 16, 0, 0, 0, 0},  // 46 '.'
  {3, 8, 4, 2, 0, 0},  // 47 '/'
  {3, 31, 17, 31, 0, 0},  // 48 '0'
  {2, 0, 31, 0, 0, 0},  // 49 '1'
  {3, 29, 21, 23, 0, 0},  // 50 '2'
  {3, 17, 21, 31, 0, 0},  // 51 '3'
  {3, 7, 4, 31, 0, 0},  // 52 '4'
  {3, 23, 21, 29, 0, 0},  // 53 '5'
  {3, 31, 21, 29, 0, 0},  // 54 '6'
  {3, 1, 1, 31, 0, 0},  // 55 '7'
  {3, 31, 21, 31, 0, 0},  // 56 '8'
  {3, 23, 21, 31, 0, 0},  // 57 '9'
  {1, 10, 0, 0, 0, 0},  // 58 ':'
  {2, 16, 10, 0, 0, 0},  // 59 ';'
  {3, 4, 10, 17, 0, 0},  // 60 '<'
  {3, 10, 10, 10, 0, 0},  // 61 '='
  {3, 17, 10, 4, 0, 0},  // 62 '>'
  {3, 1, 21, 3, 0, 0},  // 63 '?'
  {3, 14, 21, 22, 0, 0},  // 64 '@'
  {5, 8, 20, 28, 20, 20},  // 65 'A'
  {5, 24, 20, 24, 20, 24},  // 66 'B'
  {4, 12, 16, 16, 12, 0},  // 67 'C'
  {4, 24, 20, 20, 24, 0},  // 68 'D'
  {5, 28, 16, 24, 16, 28},  // 69 'E'
  {5, 28, 16, 28, 16, 16},  // 70 'F'
  {5, 12, 16, 20, 20, 12},  // 71 'G'
  {5, 20, 20, 28, 20, 20},  // 72 'H'
  {4, 28, 8, 8, 28, 0},  // 73 'I'
  {5, 28, 8, 8, 40, 16},  // 74 'J'
  {5, 20, 20, 24, 20, 20},  // 75 'K'
  {4, 16, 16, 16, 28, 0},  // 76 'L'
  {4, 34, 54, 42, 34, 0},  // 77 'M'
  {4, 36, 52, 44, 36, 0},  // 78 'N'
  {4, 8, 20, 20, 8, 0},  // 79 'O'
  {5, 28, 20, 28, 16, 16},  // 80 'P'
  {5, 8, 20, 20, 8, 4},  // 81 'Q'
  {5, 28, 20, 24, 20, 20},  // 82 'R'
  {5, 12, 16, 8, 4, 24},  // 83 'S'
  {4, 28, 8, 8, 8, 0},  // 84 'T'
  {4, 20, 20, 20, 28, 0},  // 85 'U'
  {4, 20, 20, 20, 8, 0},  // 86 'V'
  {4, 34, 34, 42, 54, 0},  // 87 'W'
  {4, 36, 24, 24, 36, 0},  // 88 'X'
  {5, 20, 20, 8, 8, 8},  // 89 'Y'
  {5, 28, 4, 8, 16, 28},  // 90 'Z'
  {2, 31, 17, 0, 0, 0},  // 91 '['
  {3, 2, 4, 8, 0, 0},  // 92 '\\'
  {2, 17, 31, 0, 0, 0},  // 93 ']'
  {3, 2, 1, 2, 0, 0},  // 94 '^'
  {3, 16, 16, 16, 0, 0},  // 95 '_'
  {2, 1, 2, 0, 0, 0},  // 96 '`'
  {5, 24, 4, 28, 20, 12},  // 97 'a'
  {5, 16, 16, 28, 20, 28},  // 98 'b'
  {4, 12, 16, 16, 12, 0},  // 99 'c'
  {5, 4, 4, 28, 20, 28},  // 100 'd'
  {4, 8, 20, 24, 12, 0},  // 101 'e'
  {5, 12, 16, 24, 16, 16},  // 102 'f'
  {5, 8, 20, 28, 4, 24},  // 103 'g'
  {5, 16, 16, 28, 20, 20},  // 104 'h'
  {4, 16, 0, 16, 16, 0},  // 105 'i'
  {5, 4, 0, 4, 20, 8},  // 106 'j'
  {5, 16, 16, 20, 24, 20},  // 107 'k'
  {4, 16, 16, 16, 12, 0},  // 108 'l'
  {4, 24, 60, 36, 36, 0},  // 109 'm'
  {4, 8, 20, 20, 20, 0},  // 110 'n'
  {4, 8, 20, 20, 8, 0},  // 111 'o'
  {5, 24, 20, 24, 16, 16},  // 112 'p'
  {5, 12, 20, 12, 4, 4},  // 113 'q'
  {4, 12, 16, 16, 16, 0},  // 114 'r'
  {5, 12, 16, 8, 4, 24},  // 115 's'
  {5, 16, 16, 28, 16, 12},  // 116 't'
  {4, 20, 20, 20, 28, 0},  // 117 'u'
  {4, 20, 20, 20, 8, 0},  // 118 'v'
  {4, 36, 36, 60, 24, 0},  // 119 'w'
  {3, 20, 8, 20, 0, 0},  // 120 'x'
  {4, 20, 20, 8, 16, 0},  // 121 'y'
  {5, 28, 4, 8, 16, 28},  // 122 'z'
  {3, 4, 27, 17, 0, 0},  // 123 '{'
  {1, 27, 0, 0, 0, 0},  // 124 '|'
  {3, 17, 27, 4, 0, 0},  // 125 '}'
  {3, 6, 2, 3, 0, 0},  // 126 '~'
  {3, 31, 31, 31, 0, 0},  // 127 '\x7f'
};

/* Draw text using the compact 5x3 font.
 * The font was designed for a rotated LED matrix (MD_MAX72XX).
 * Data format: {width, col0, col1, ...} where each col is 5 bits
 * (bit0=top row).  The character is rotated 90° CW in the original
 * data.  We rotate 90° CCW at draw time to display correctly.
 *
 * After rotation:
 * - Original width becomes new height
 * - Original 5 rows become new width (always 5)
 * - new_pixel(new_col, new_row) = old_pixel(old_col=4-new_row, old_row=new_col)
 *
 * x, y: top-left pixel position.
 * s: null-terminated string.
 * c: palette color index.
 * scale: pixel scaling factor (1=normal). */
static void fb_text_small(int x, int y, const char *s, uint8_t c, int scale) {
    while (*s) {
        uint8_t ch = (uint8_t)*s;
        if (ch < 32 || ch > 127) ch = 32;
        const uint8_t *entry = g_font_5x3[ch - 32];
        uint8_t origW = pgm_read_byte(&entry[0]);  /* original width = num columns */
        /* After 90° CCW rotation: new width = 5 (original height),
         * new height = origW (original width). */
        uint8_t newW = 5;   /* always 5 pixels wide after rotation */
        uint8_t newH = origW;  /* height = original width */
        for (uint8_t ny = 0; ny < newH; ny++) {      /* new rows */
            for (uint8_t nx = 0; nx < newW; nx++) {   /* new cols */
                /* 90° CCW: new[nx][ny] = old[ny][origH-1-nx]
                 * old col = ny, old row = 4 - nx
                 * old pixel = col_data & (1 << row) */
                uint8_t oldCol = ny;
                uint8_t oldRow = 4 - nx;
                uint8_t colData = pgm_read_byte(&entry[1 + oldCol]);
                if (colData & (1 << oldRow)) {
                    int px = x + (int)nx * scale;
                    int py = y + (int)ny * scale;
                    for (int sy = 0; sy < scale; sy++)
                        for (int sx = 0; sx < scale; sx++)
                            if (px + sx >= 0 && px + sx < FB_W && py + sy >= 0 && py + sy < FB_H)
                                g_framebuffer[(py + sy) * FB_W + (px + sx)] = c;
                }
            }
        }
        /* Advance x by the visible width of the rotated char.
         * Most chars don't use all 5 columns. Find actual width. */
        uint8_t visW = 0;
        for (uint8_t ny = 0; ny < newH; ny++) {
            uint8_t colData = pgm_read_byte(&entry[1 + ny]);
            for (uint8_t b = 0; b < 5; b++) {
                if (colData & (1 << b)) {
                    uint8_t nx = 4 - b;  /* rotated position */
                    if (nx + 1 > visW) visW = nx + 1;
                }
            }
        }
        if (visW == 0) visW = 3;  /* space and similar */
        x += (visW + 1) * scale;
        s++;
    }
}

#endif
