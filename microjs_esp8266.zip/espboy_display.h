/*
 * espboy_display.h — framebuffer + palette + dirty-row flush for ESPboy
 * =====================================================================
 *
 * ARCHITECTURE
 * ------------
 *   1. Framebuffer:   64×64 bytes in RAM.  Each byte = palette index 0..255.
 *                     Total = 4096 bytes (4 KB) of static BSS.
 *
 *   2. Palette:       256 RGB565 entries in PROGMEM (flash).  Immutable.
 *                     Layout matches xterm-256: 0..15 = standard CGA/VGA,
 *                     16..231 = 6×6×6 color cube, 232..255 = grayscale ramp.
 *
 *   3. Dirty tracking: 64-bit bitmask `g_fb_dirty_rows`.  Bit i set means
 *                     framebuffer row i changed since last flush and must
 *                     be re-pushed to the TFT.
 *
 *   4. Display flush: display_flush_dirty_rows() walks the dirty bitmask.
 *                     For each dirty row it composes a 2×-scaled 256-pixel
 *                     strip (64 source bytes → 128 dest pixels) and pushes
 *                     it to the TFT via tft.pushRect(x=0, y=2*row, w=128,
 *                     h=2).  After flushing, the bit is cleared.
 *
 *   5. Frame rate:    loop() calls display_tick() which throttle-flushes
 *                     at ≤15 FPS (one frame per ~66 ms).  display_tick()
 *                     is a no-op if no rows are dirty or if the throttle
 *                     interval has not yet elapsed.
 *
 *   6. JS API:        tft.flip()  → marks ALL 64 rows dirty (forces next
 *                                display_tick() to push the whole FB).
 *                     All tft.* primitives auto-mark the rows they touch.
 *
 * MEMORY BUDGET (ESP8266 ~50 KB DRAM)
 * -----------------------------------
 *   - g_framebuffer:        4096 B  (BSS)
 *   - g_fb_dirty_rows:         8 B  (BSS)
 *   - g_scanline_buf:       512 B  (BSS, scratch for pushRect)
 *   - g_palette (PROGMEM):  512 B  (flash, NOT RAM)
 *   Total added BSS:       ~4.6 KB
 *
 * SCALING 64×64 → 128×128
 * ------------------------
 *   Each source pixel (x, y) becomes a 2×2 block at screen pixel (2x, 2y)
 *   through (2x+1, 2y+1).  When pushing row y we read g_framebuffer[y*64..y*64+63]
 *   and write g_scanline_buf[0..255] (each source pixel duplicated twice
 *   horizontally), then push that 256-byte (128-pixel) strip twice
 *   (rows 2y and 2y+1) to the TFT.
 *
 * PUBLIC API
 * ----------
 *   void  display_init();                // clear FB, clear dirty, push black
 *   void  display_clear(uint8_t pal_idx);// fill FB with pal_idx, mark all dirty
 *   void  display_put_pixel(int x, int y, uint8_t pal_idx);
 *   uint8_t display_get_pixel(int x, int y);
 *   void  display_mark_dirty_rows(int y0, int y1); // mark rows y0..y1 inclusive
 *   void  display_mark_all_dirty();
 *   void  display_flush_dirty_rows();    // push dirty rows to TFT, clear bits
 *   void  display_tick();                // throttle-flush at 15 FPS
 *   uint16_t palette_get(uint8_t idx);   // PROGMEM read → RGB565
 *
 *   Constants:  FB_W = 64, FB_H = 64, FB_SIZE = 4096
 *
 * DEPENDENCIES
 * ------------
 *   - TFT_eSPI library (already in the .ino)
 *   - <Arduino.h> for PROGMEM / pgm_read_word
 *
 * USAGE FROM .ino
 * ---------------
 *   #include "espboy_display.h"
 *   void setup() {
 *       tft.begin();
 *       display_init();          // clear FB + push initial black
 *   }
 *   void loop() {
 *       display_tick();          // 15 FPS flush
 *       ... (HTTP, serial, etc.)
 *   }
 *   // From JS native callbacks:
 *       display_put_pixel(x, y, color_idx);
 *       // dirty rows are auto-marked by display_put_pixel
 *
 * INCLUDED ONCE FROM THE .INO
 * ---------------------------
 *   This header is a single-file implementation.  The .ino #includes it
 *   directly (no separate .cpp).  All functions are `static inline` to
 *   avoid linker conflicts if it were included from multiple TUs (which
 *   doesn't happen, but it's a safe default).
 * ====================================================================
 */
#ifndef ESPBOY_DISPLAY_H
#define ESPBOY_DISPLAY_H

#include <Arduino.h>

/* ====================================================================
 * DISPLAY BACKEND SELECTION
 * ====================================================================
 * Set one of these in your build config (or at top of .ino before
 * #include "espboy_display.h"):
 *
 *   #define DISPLAY_BACKEND_TFT_ESPI   (default)
 *   #define DISPLAY_BACKEND_ADAFRUIT
 *   #define DISPLAY_BACKEND_NONE       (headless — no screen)
 *
 * When NONE, all display functions are stubs (no-ops).
 * tft.* JS functions still work (no-ops) but help panel hides tft section.
 * ==================================================================== */

#if !defined(DISPLAY_BACKEND_TFT_ESPI) && !defined(DISPLAY_BACKEND_ADAFRUIT) && !defined(DISPLAY_BACKEND_NONE)
#define DISPLAY_BACKEND_TFT_ESPI
#endif

#if defined(DISPLAY_BACKEND_TFT_ESPI)
  #include <TFT_eSPI.h>
  extern TFT_eSPI tft;
  #define DISPLAY_ACTIVE 1
#elif defined(DISPLAY_BACKEND_ADAFRUIT)
  #include <Adafruit_GFX.h>
  #include <Adafruit_ST7735.h>
  extern Adafruit_ST7735 tft;
  #define DISPLAY_ACTIVE 1
#elif defined(DISPLAY_BACKEND_NONE)
  #define DISPLAY_ACTIVE 0
#endif

/* ====================================================================
 * Display backend abstraction
 * ==================================================================== */
#if defined(DISPLAY_BACKEND_TFT_ESPI)
  static inline void display_backend_init() { tft.begin(); tft.setSwapBytes(true); }
  static inline void display_backend_fillScreen(uint16_t c) { tft.fillScreen(c); }
  static inline void display_backend_pushRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t *data) {
      tft.pushRect(x, y, w, h, data);
  }
#elif defined(DISPLAY_BACKEND_ADAFRUIT)
  /* For Adafruit, use drawRGBBitmap which is the equivalent of pushRect. */
  static inline void display_backend_init() { tft.initR(INITR_BLACKTAB); tft.setRotation(0); }
  static inline void display_backend_fillScreen(uint16_t c) { tft.fillScreen(c); }
  static inline void display_backend_pushRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t *data) {
      tft.startWrite();
      tft.drawRGBBitmap(x, y, data, w, h);
      tft.endWrite();
  }
#elif defined(DISPLAY_BACKEND_NONE)
  /* Headless mode — all display functions are no-ops. */
  static inline void display_backend_init() {}
  static inline void display_backend_fillScreen(uint16_t c) {}
  static inline void display_backend_pushRect(int32_t x, int32_t y, int32_t w, int32_t h, uint16_t *data) {}
#endif

/* ====================================================================
 * Constants — framebuffer size depends on platform.
 * ESP8266/ESPboy: 64x64 (128x128 scaled 2x, ST7735)
 * ESP32 with 320x240: 160x120 (320x240 scaled 2x, ILI9341)
 * Override with -DFB_WIDTH=N -DFB_HEIGHT=N at compile time.
 * ==================================================================== */
#if defined(ESP32) && !defined(FB_WIDTH)
  /* ESP32 default: 120x160 framebuffer, scaled 2x → 240x320 (portrait ILI9341).
   * T51-fix: Screen is in PORTRAIT orientation (240 wide × 320 tall).
   * With FB_SCALE=2: 120*2=240 (width OK), 160*2=320 (height OK).
   * Both dimensions fit perfectly on the portrait display. */
  #define FB_W       120
  #define FB_H       160
  #define FB_SCALE  2
#elif defined(ESP8266) && !defined(FB_WIDTH)
  /* ESP8266/ESPboy: 64x64 framebuffer, scaled 2x → 128x128. */
  #define FB_W       64
  #define FB_H       64
  #define FB_SCALE  2
#else
  /* User-defined via -DFB_WIDTH -DFB_HEIGHT -DFB_SCALE */
  #ifndef FB_W
    #define FB_W 64
    #define FB_H 64
    #define FB_SCALE 2
  #endif
#endif
#define FB_SIZE    (FB_W * FB_H)
#define FB_ROW_BYTES  FB_W

/* Display throttle: 15 FPS = 1 frame per ~66 ms. */
#define DISPLAY_FRAME_INTERVAL_MS  66

/* ====================================================================
 * Immutable palette (PROGMEM, 256 × uint16_t = 512 bytes in flash)
 *
 * Layout matches xterm-256 so anyone familiar with Linux terminal
 * colors knows the indices:
 *    0..15    = standard 16 (CGA/VGA)
 *    16..231  = 6×6×6 color cube (idx = 16 + 36*r + 6*g + b,
 *               r/g/b in 0..5 → {0, 95, 135, 175, 215, 255})
 *   232..255  = 24-step grayscale ramp (v = 8 + 10*level, 8..238)
 *
 * We pre-compute this at compile time so it lives entirely in flash
 * (PROGMEM) and never touches RAM.  Strings ('red' etc.) are gone —
 * only numbers 0..255 are accepted as color arguments.
 * ==================================================================== */

/* Helper used only at compile time to build the palette array.
 * T51: Channel rotation — the ST7735 on this ESPboy rotates RGB channels:
 * output_R=input_G, output_G=input_B, output_B=input_R.
 * We pre-rotate by storing B in R-position, R in G-position, G in B-position.
 * Combined with setSwapBytes(true) for SPI byte order, all colors display correctly.
 * Verified: red→red, green→green, blue→blue, yellow→yellow, cyan→cyan, magenta→magenta. */
#define RGB565(r,g,b)  \
    (uint16_t)((((uint16_t)(b) & 0xF8) << 8) | \
               (((uint16_t)(r) & 0xFC) << 3) | \
               (((uint16_t)(g)) >> 3))

/* Standard 16 colors (CGA/VGA-like, matches what the old parseColor()
 * understood: 0=black, 1=red, 2=green, 3=yellow, 4=blue, 5=magenta,
 * 6=cyan, 7=white, then "bright" variants). */
#define P_BLACK    RGB565(  0,   0,   0)
#define P_RED      RGB565(255,   0,   0)
#define P_GREEN    RGB565(  0, 255,   0)
#define P_YELLOW   RGB565(255, 255,   0)
#define P_BLUE     RGB565(  0,   0, 255)
#define P_MAGENTA  RGB565(255,   0, 255)
#define P_CYAN     RGB565(  0, 255, 255)
#define P_WHITE    RGB565(255, 255, 255)
#define P_DGREY    RGB565( 64,  64,  64)
#define P_ORANGE   RGB565(255, 128,   0)
#define P_LGREY    RGB565(192, 192, 192)

/* 6×6×6 color cube levels (same as xterm-256). */
static const uint8_t CUBE_LEVELS[6] = {0, 95, 135, 175, 215, 255};

/* Generate the PROGMEM palette at compile time using a generator
 * function called once in setup().  We can't easily build a 256-entry
 * PROGMEM initializer with macros (the cube + ramp needs arithmetic),
 * so we use a small init function that writes into a static RAM array
 * ONCE — but actually we want it in PROGMEM, so we use a different
 * approach: build the table at setup() time into RAM, then never
 * modify it again.
 *
 * Wait — the user said "palette lives in PROGMEM and is immutable".
 * The cleanest way is to pre-build the table at compile time.  Let's
 * do that with a Python-generated constant array, OR we can use a
 * constexpr-style generator.  Since C++11 constexpr is awkward for
 * 256 entries, we'll use a small trick: define the PROGMEM array
 * with explicit values for slots 0..15, then a build-time generator
 * for 16..231 and 232..255 using template-metaprogramming.
 *
 * Actually, the simplest robust approach: just put the palette in
 * RAM (512 B) and initialize it once in display_init().  512 B of
 * RAM is acceptable on ESP8266 (~50 KB DRAM).  The user said "palette
 * in PROGMEM" — but the practical benefit of PROGMEM is saving RAM.
 * 512 B is small enough that the simplicity wins.  However, to honor
 * the request, we'll ALSO provide a PROGMEM copy and read it via
 * pgm_read_word().  The RAM copy is eliminated.
 *
 * Below is the PROGMEM palette.  We build it via a Python-generated
 * initializer to avoid C++ template gymnastics.  The values are
 * deterministic — see scripts/gen_palette.py to regenerate.
 * ==================================================================== */

/* Generated palette: 256 × uint16_t in PROGMEM.
 *   [  0..15 ]   standard 16 colors
 *   [ 16..231]   6×6×6 color cube:  idx = 16 + 36*r + 6*g + b,
 *                r,g,b ∈ {0,95,135,175,215,255}
 *   [232..255]   24-step grayscale: v = 8 + 10*(idx-232), 8..238
 */
static const uint16_t g_palette[256] PROGMEM = {
    /* 0..15: standard CGA/VGA */
    P_BLACK,  P_RED,    P_GREEN,  P_YELLOW, P_BLUE,   P_MAGENTA, P_CYAN,   P_WHITE,
    P_DGREY,  P_ORANGE, P_GREEN,  P_YELLOW, P_BLUE,   P_MAGENTA, P_CYAN,   P_WHITE,
    /* 16..231: 6×6×6 color cube (6*6*6 = 216 entries) */
    RGB565(  0,   0,   0), RGB565(  0,   0,  95), RGB565(  0,   0, 135), RGB565(  0,   0, 175), RGB565(  0,   0, 215), RGB565(  0,   0, 255),
    RGB565(  0,  95,   0), RGB565(  0,  95,  95), RGB565(  0,  95, 135), RGB565(  0,  95, 175), RGB565(  0,  95, 215), RGB565(  0,  95, 255),
    RGB565(  0, 135,   0), RGB565(  0, 135,  95), RGB565(  0, 135, 135), RGB565(  0, 135, 175), RGB565(  0, 135, 215), RGB565(  0, 135, 255),
    RGB565(  0, 175,   0), RGB565(  0, 175,  95), RGB565(  0, 175, 135), RGB565(  0, 175, 175), RGB565(  0, 175, 215), RGB565(  0, 175, 255),
    RGB565(  0, 215,   0), RGB565(  0, 215,  95), RGB565(  0, 215, 135), RGB565(  0, 215, 175), RGB565(  0, 215, 215), RGB565(  0, 215, 255),
    RGB565(  0, 255,   0), RGB565(  0, 255,  95), RGB565(  0, 255, 135), RGB565(  0, 255, 175), RGB565(  0, 255, 215), RGB565(  0, 255, 255),
    RGB565( 95,   0,   0), RGB565( 95,   0,  95), RGB565( 95,   0, 135), RGB565( 95,   0, 175), RGB565( 95,   0, 215), RGB565( 95,   0, 255),
    RGB565( 95,  95,   0), RGB565( 95,  95,  95), RGB565( 95,  95, 135), RGB565( 95,  95, 175), RGB565( 95,  95, 215), RGB565( 95,  95, 255),
    RGB565( 95, 135,   0), RGB565( 95, 135,  95), RGB565( 95, 135, 135), RGB565( 95, 135, 175), RGB565( 95, 135, 215), RGB565( 95, 135, 255),
    RGB565( 95, 175,   0), RGB565( 95, 175,  95), RGB565( 95, 175, 135), RGB565( 95, 175, 175), RGB565( 95, 175, 215), RGB565( 95, 175, 255),
    RGB565( 95, 215,   0), RGB565( 95, 215,  95), RGB565( 95, 215, 135), RGB565( 95, 215, 175), RGB565( 95, 215, 215), RGB565( 95, 215, 255),
    RGB565( 95, 255,   0), RGB565( 95, 255,  95), RGB565( 95, 255, 135), RGB565( 95, 255, 175), RGB565( 95, 255, 215), RGB565( 95, 255, 255),
    RGB565(135,   0,   0), RGB565(135,   0,  95), RGB565(135,   0, 135), RGB565(135,   0, 175), RGB565(135,   0, 215), RGB565(135,   0, 255),
    RGB565(135,  95,   0), RGB565(135,  95,  95), RGB565(135,  95, 135), RGB565(135,  95, 175), RGB565(135,  95, 215), RGB565(135,  95, 255),
    RGB565(135, 135,   0), RGB565(135, 135,  95), RGB565(135, 135, 135), RGB565(135, 135, 175), RGB565(135, 135, 215), RGB565(135, 135, 255),
    RGB565(135, 175,   0), RGB565(135, 175,  95), RGB565(135, 175, 135), RGB565(135, 175, 175), RGB565(135, 175, 215), RGB565(135, 175, 255),
    RGB565(135, 215,   0), RGB565(135, 215,  95), RGB565(135, 215, 135), RGB565(135, 215, 175), RGB565(135, 215, 215), RGB565(135, 215, 255),
    RGB565(135, 255,   0), RGB565(135, 255,  95), RGB565(135, 255, 135), RGB565(135, 255, 175), RGB565(135, 255, 215), RGB565(135, 255, 255),
    RGB565(175,   0,   0), RGB565(175,   0,  95), RGB565(175,   0, 135), RGB565(175,   0, 175), RGB565(175,   0, 215), RGB565(175,   0, 255),
    RGB565(175,  95,   0), RGB565(175,  95,  95), RGB565(175,  95, 135), RGB565(175,  95, 175), RGB565(175,  95, 215), RGB565(175,  95, 255),
    RGB565(175, 135,   0), RGB565(175, 135,  95), RGB565(175, 135, 135), RGB565(175, 135, 175), RGB565(175, 135, 215), RGB565(175, 135, 255),
    RGB565(175, 175,   0), RGB565(175, 175,  95), RGB565(175, 175, 135), RGB565(175, 175, 175), RGB565(175, 175, 215), RGB565(175, 175, 255),
    RGB565(175, 215,   0), RGB565(175, 215,  95), RGB565(175, 215, 135), RGB565(175, 215, 175), RGB565(175, 215, 215), RGB565(175, 215, 255),
    RGB565(175, 255,   0), RGB565(175, 255,  95), RGB565(175, 255, 135), RGB565(175, 255, 175), RGB565(175, 255, 215), RGB565(175, 255, 255),
    RGB565(215,   0,   0), RGB565(215,   0,  95), RGB565(215,   0, 135), RGB565(215,   0, 175), RGB565(215,   0, 215), RGB565(215,   0, 255),
    RGB565(215,  95,   0), RGB565(215,  95,  95), RGB565(215,  95, 135), RGB565(215,  95, 175), RGB565(215,  95, 215), RGB565(215,  95, 255),
    RGB565(215, 135,   0), RGB565(215, 135,  95), RGB565(215, 135, 135), RGB565(215, 135, 175), RGB565(215, 135, 215), RGB565(215, 135, 255),
    RGB565(215, 175,   0), RGB565(215, 175,  95), RGB565(215, 175, 135), RGB565(215, 175, 175), RGB565(215, 175, 215), RGB565(215, 175, 255),
    RGB565(215, 215,   0), RGB565(215, 215,  95), RGB565(215, 215, 135), RGB565(215, 215, 175), RGB565(215, 215, 215), RGB565(215, 215, 255),
    RGB565(215, 255,   0), RGB565(215, 255,  95), RGB565(215, 255, 135), RGB565(215, 255, 175), RGB565(215, 255, 215), RGB565(215, 255, 255),
    RGB565(255,   0,   0), RGB565(255,   0,  95), RGB565(255,   0, 135), RGB565(255,   0, 175), RGB565(255,   0, 215), RGB565(255,   0, 255),
    RGB565(255,  95,   0), RGB565(255,  95,  95), RGB565(255,  95, 135), RGB565(255,  95, 175), RGB565(255,  95, 215), RGB565(255,  95, 255),
    RGB565(255, 135,   0), RGB565(255, 135,  95), RGB565(255, 135, 135), RGB565(255, 135, 175), RGB565(255, 135, 215), RGB565(255, 135, 255),
    RGB565(255, 175,   0), RGB565(255, 175,  95), RGB565(255, 175, 135), RGB565(255, 175, 175), RGB565(255, 175, 215), RGB565(255, 175, 255),
    RGB565(255, 215,   0), RGB565(255, 215,  95), RGB565(255, 215, 135), RGB565(255, 215, 175), RGB565(255, 215, 215), RGB565(255, 215, 255),
    RGB565(255, 255,   0), RGB565(255, 255,  95), RGB565(255, 255, 135), RGB565(255, 255, 175), RGB565(255, 255, 215), RGB565(255, 255, 255),
    /* 232..255: 24-step grayscale ramp (v = 8 + 10*(idx-232), 8..238) */
    RGB565(  8,   8,   8),  RGB565( 18,  18,  18),  RGB565( 28,  28,  28),  RGB565( 38,  38,  38),
    RGB565( 48,  48,  48),  RGB565( 58,  58,  58),  RGB565( 68,  68,  68),  RGB565( 78,  78,  78),
    RGB565( 88,  88,  88),  RGB565( 98,  98,  98),  RGB565(108, 108, 108),  RGB565(118, 118, 118),
    RGB565(128, 128, 128),  RGB565(138, 138, 138),  RGB565(148, 148, 148),  RGB565(158, 158, 158),
    RGB565(168, 168, 168),  RGB565(178, 178, 178),  RGB565(188, 188, 188),  RGB565(198, 198, 198),
    RGB565(208, 208, 208),  RGB565(218, 218, 218),  RGB565(228, 228, 228),  RGB565(238, 238, 238),
};

/* ====================================================================
 * Framebuffer + dirty-row tracking (RAM, mutable)
 * ==================================================================== */
static uint8_t  g_framebuffer[FB_SIZE];           /* 4096 B BSS */
/* T51: Dirty row tracking — support up to 256 rows (32 bytes).
 * ESP8266: 64 rows (1 uint64_t).  ESP32: 120 rows (2 uint64_t). */
#define FB_DIRTY_WORDS  ((FB_H + 63) / 64)
static uint64_t g_fb_dirty_rows[FB_DIRTY_WORDS];   /* bit i = row i dirty */
static uint16_t g_scanline_buf[FB_SCALE * FB_W];     /* scaled row */
static uint32_t g_last_frame_ms = 0;              /* throttle: last flush time */

/* Read a palette entry from PROGMEM. */
static inline uint16_t palette_get(uint8_t idx) {
    return (uint16_t)pgm_read_word(&g_palette[idx]);
}

/* Read a pixel from the framebuffer.  Out-of-range → 0 (palette[0] = black). */
static inline uint8_t display_get_pixel(int x, int y) {
    if ((unsigned)x >= FB_W || (unsigned)y >= FB_H) return 0;
    return g_framebuffer[y * FB_W + x];
}

/* Write a pixel to the framebuffer and mark the row dirty.
 * Out-of-range writes are silently dropped. */
static inline void display_put_pixel(int x, int y, uint8_t pal_idx) {
    if ((unsigned)x >= FB_W || (unsigned)y >= FB_H) return;
    g_framebuffer[y * FB_W + x] = pal_idx;
    g_fb_dirty_rows[y >> 6] |= ((uint64_t)1 << (y & 63));
}

/* Mark rows y0..y1 (inclusive) dirty. */
static inline void display_mark_dirty_rows(int y0, int y1) {
    if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
    if (y0 < 0) y0 = 0;
    if (y1 >= FB_H) y1 = FB_H - 1;
    if (y0 > y1) return;
    for (int y = y0; y <= y1; y++) {
        g_fb_dirty_rows[y >> 6] |= ((uint64_t)1 << (y & 63));
    }
}

/* Mark all rows dirty.  Called by tft.flip() and display_clear(). */
static inline void display_mark_all_dirty(void) {
    for (int i = 0; i < FB_DIRTY_WORDS; i++) g_fb_dirty_rows[i] = (uint64_t)-1;
}

/* Fill the framebuffer with a single palette index and mark all dirty. */
static inline void display_clear(uint8_t pal_idx) {
    memset(g_framebuffer, pal_idx, FB_SIZE);
    display_mark_all_dirty();
}

/* Push all dirty rows to the TFT, then clear the dirty mask.
 *
 * For each dirty row y, we:
 *   1. Read g_framebuffer[y*64 .. y*64+63] (64 bytes)
 *   2. For each byte, look up palette[idx] → uint16_t RGB565
 *   3. Write the 64 RGB565 values into g_scanline_buf[0..63],
 *      duplicated into [64..127] (so each FB pixel becomes a 2×2 block
 *      when we push the scanline twice).
 *   4. tft.pushRect(0, 2*y, 128, 1, g_scanline_buf)        // top half
 *      tft.pushRect(0, 2*y+1, 128, 1, g_scanline_buf+64)   // bottom half
 *
 * Wait — pushRect takes (x, y, w, h, data) where data is w*h uint16_t.
 * For w=128, h=1 that's 128 uint16_t = 256 bytes.  Our g_scanline_buf
 * is sized 256 uint16_t = 512 bytes — enough.
 *
 * To make each source pixel become a 2×2 block, we duplicate each
 * pixel horizontally (so scanline = [p0,p0,p1,p1,...,p63,p63] = 128
 * pixels = 256 bytes), then push that 128-pixel row twice (rows 2y
 * and 2y+1).
 */
static void display_flush_dirty_rows(void) {
    bool any_dirty = false;
    for (int i = 0; i < FB_DIRTY_WORDS; i++) {
        if (g_fb_dirty_rows[i]) { any_dirty = true; break; }
    }
    if (!any_dirty) return;

    for (int word = 0; word < FB_DIRTY_WORDS; word++) {
        uint64_t mask = g_fb_dirty_rows[word];
        while (mask) {
            int y = __builtin_ctzll(mask);
            mask &= mask - 1;
            int row = word * 64 + y;
            if (row >= FB_H) break;

            const uint8_t *src = &g_framebuffer[row * FB_W];
            for (int x = 0; x < FB_W; x++) {
                uint16_t c = palette_get(src[x]);
                for (int s = 0; s < FB_SCALE; s++) {
                    g_scanline_buf[x * FB_SCALE + s] = c;
                }
            }
            int screen_w = FB_SCALE * FB_W;
            for (int s = 0; s < FB_SCALE; s++) {
                display_backend_pushRect(0, FB_SCALE * row + s, screen_w, 1, g_scanline_buf);
            }
        }
    }

    for (int i = 0; i < FB_DIRTY_WORDS; i++) g_fb_dirty_rows[i] = 0;
    g_last_frame_ms = millis();
}

/* Throttle-flush at ≤15 FPS.  Called from loop().  If the throttle
 * interval has NOT elapsed since the last flush, this is a no-op.
 * If no rows are dirty, this is also a no-op. */
static inline void display_tick(void) {
    bool any_dirty = false;
    for (int i = 0; i < FB_DIRTY_WORDS; i++) {
        if (g_fb_dirty_rows[i]) { any_dirty = true; break; }
    }
    if (!any_dirty) return;
    uint32_t now = millis();
    if (now - g_last_frame_ms < DISPLAY_FRAME_INTERVAL_MS) return;
    display_flush_dirty_rows();
}

/* Force an immediate flush (bypass throttle).  Useful during setup()
 * for splash screens where we want the frame on screen immediately. */
static inline void display_flush_now(void) {
    display_flush_dirty_rows();
}

/* Initialize the display subsystem: clear framebuffer to palette[0]
 * (black), clear the dirty mask, and push a single black frame to
 * the TFT so the screen starts in a known state. */
static inline void display_init(void) {
    memset(g_framebuffer, 0, FB_SIZE);
    for (int i = 0; i < FB_DIRTY_WORDS; i++) g_fb_dirty_rows[i] = 0;
    g_last_frame_ms = 0;
    /* Push initial black frame synchronously (no throttle during setup). */
    display_backend_fillScreen(0x0000);  /* black */
}

#endif /* ESPBOY_DISPLAY_H */
