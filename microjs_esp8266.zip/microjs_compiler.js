/* microjs_compiler.js — JS-to-bytecode compiler that runs in the browser.
 *
 * Compiles a JavaScript subset to the MJSB bytecode format consumed by
 * microjs_vm.h on the ESP8266.  All compilation happens client-side;
 * the device only receives the resulting bytecode blob.
 *
 * API:
 *   const c = new MicroJSCompiler();
 *   const result = c.compile(source);
 *   if (result.error) {
 *     // result = { error, line, col, token, src_line }
 *   } else {
 *     // result.bytecode is a Uint8Array ready to POST to /run
 *   }
 *
 * Supported syntax (JS-36-fix / JS-37-fix: documentation was stale):
 *   - var/let/const declarations (NOTE: let/const are function-scoped,
 *     NOT block-scoped - JS-19/20/21 known limitation)
 *   - Integer arithmetic, bitwise, comparison
 *   - if/else, while, for, do/while, return, break, continue
 *   - Function declarations + expressions (NOTE: no hoisting - JS-12)
 *   - Array literals, object literals, property/index access
 *   - String literals (basic escapes)
 *   - Assignment: = += -= *= /= %=
 *   - try/catch/throw (T51: OP_PUSH_TRY / OP_POP_TRY / OP_THROW)
 *   - new Constructor(args) (T51: OP_NEW)
 *   - instanceof (T51: OP_INSTANCEOF, walks __proto__ chain)
 *   - typeof (T51: OP_TYPEOF; typeof undeclared_var returns "undefined")
 *   - === and !== (T30: OP_STRICT_EQ / OP_STRICT_NE)
 *   - Arrow functions (params) => expr  or  param => expr
 *     (NOTE: lexical `this` NOT supported - JS-22 known limitation)
 *   - Template literals with tagged templates
 *   - Destructuring: var [a,b] = arr, var {x,y} = obj
 *   - Optional chaining (?.) and nullish coalescing (??)
 *   - for-in / for-of iteration
 *   - Get/set accessors via Object.defineProperty
 *
 * Not supported (intentionally omitted for size / known limitations):
 *   - Float literals (parsed as int30 fixed24.8, precision lost)
 *   - TypedArray / RegExp / Date / Map / Set / Promise
 *   - var/function hoisting (JS-12 - declare before use)
 *   - let/const block scoping (JS-19/20/21 - treated like var)
 *   - Arrow function lexical `this` (JS-22 - arrows use call-site this)
 *   - Sparse arrays [1,,3] (JS-34 - elision is a syntax error)
 *   - Postfix arr[i]++ (JS-33 - use arr[i] += 1 instead)
 *
 * SPDX-License-Identifier: MIT
 */

/* Opcode constants — must match microjs_vm.h. */
const OP = {
    NOP: 0x00, UNDEF: 0x01, NULL: 0x02, TRUE: 0x03, FALSE: 0x04,
    INT8: 0x05, INT16: 0x06, INT24: 0x07, CONST: 0x08,
    LOAD_LOCAL: 0x09, STORE_LOCAL: 0x0A, LOAD_GLOBAL: 0x0B, STORE_GLOBAL: 0x0C,
    POP: 0x0D, DUP: 0x0E, SWAP: 0x0F,
    LOAD_PROP: 0x10, STORE_PROP: 0x11, LOAD_INDEX: 0x12, STORE_INDEX: 0x13,
    NEW_OBJECT: 0x14, NEW_ARRAY: 0x15,
    ADD: 0x18, SUB: 0x19, MUL: 0x1A, DIV: 0x1B, MOD: 0x1C,
    NEG: 0x1D, INC: 0x1E, DEC: 0x1F,
    AND: 0x20, OR: 0x21, XOR: 0x22, SHL: 0x23, SHR: 0x24, USHR: 0x25,
    BNOT: 0x26, LNOT: 0x27,
    EQ: 0x28, NE: 0x29, LT: 0x2A, LE: 0x2B, GT: 0x2C, GE: 0x2D,
    JMP: 0x30, JZ: 0x31, JNZ: 0x32,
    CALL: 0x33, CALL_METHOD: 0x34, RET: 0x35, RET_UNDEF: 0x36, HALT: 0x37,
    FUNCTION: 0x38,
    /* T30 additions */
    STRICT_EQ: 0x39, STRICT_NE: 0x3A, TYPEOF: 0x3B, INSTANCEOF: 0x3C,
    FOR_IN_NEXT: 0x3D, FOR_OF_NEXT: 0x3E,
    DEFINE_ACCESSOR: 0x3F,
    /* T51: try/catch/throw */
    PUSH_TRY: 0x40,
    POP_TRY: 0x41,
    THROW: 0x42,
    NEW: 0x43,         /* T51: new Constructor(args) */
    THIS: 0x44,        /* T51: push `this` */
    CALL_WITH_THIS: 0x45, /* T51: call method with this=obj */
    NATIVE_CALL: 0x46,    /* T51: inline native call — 1 byte native_id */
    NEW_ARRAY_U8: 0x47,  /* T51: compact u8 array — count, then raw bytes */
    NEW_ARRAY_U16: 0x48, /* T51: compact u16 array — count, then raw u16s */
    NEW_ARRAY16: 0x49,   /* T51: array with 16-bit count (for > 255 elements) */
    TO_NUMBER: 0x4A,     /* JS-10-fix: unary plus +x - ToNumber coercion */
    LAST: 0x4B,
};

/* Token kinds. */
const TK = {
    EOF: 0, IDENT: 1, INT: 2, STRING: 3,
    LPAREN: 4, RPAREN: 5, LBRACE: 6, RBRACE: 7, LBRACKET: 8, RBRACKET: 9,
    SEMI: 10, COMMA: 11, DOT: 12, COLON: 13, QUESTION: 14,
    ASSIGN: 15, PLUS: 16, MINUS: 17, STAR: 18, SLASH: 19, PERCENT: 20,
    INC: 21, DEC: 22,
    EQ: 23, NE: 24, LT: 25, LE: 26, GT: 27, GE: 28,
    AND: 29, OR: 30, BNOT: 31, LNOT: 32,
    BAND: 33, BOR: 34, XOR: 35, SHL: 36, SHR: 37, USHR: 38,
    PLUSEQ: 39, MINUSEQ: 40, STAREQ: 41, SLASHEQ: 42, PERCENTEQ: 43,
    ANDEQ: 44, OREQ: 45, XOREQ: 46, SHLEQ: 47, SHREQ: 48, USHREQ: 49,
    AMPAMP: 50, PIPEPIPE: 51,
    VAR: 52, LET: 53, CONST: 54, FUNCTION: 55, RETURN: 56,
    IF: 57, ELSE: 58, WHILE: 59, DO: 60, FOR: 61,
    BREAK: 62, CONTINUE: 63, NEW: 64, IN: 65,
    TRUE: 66, FALSE: 67, NULL: 68, UNDEFINED: 69,
    TYPEOF: 70, INSTANCEOF: 71, DELETE: 72, VOID: 73,
    STRICT_EQ: 74,  /* === */
    STRICT_NE: 75,  /* !== */
    OF: 76,          /* for...of */
    SWITCH: 77, CASE: 78, DEFAULT: 79,
    TRY: 80, CATCH: 81, THROW: 82, FINALLY: 83,
    THIS: 84,
    ARROW: 85,        /* => */
    TEMPLATE: 86,     /* `...` template literal (sval = raw content) */
    OPTCHAIN: 87,     /* ?. optional chaining */
    NULLISH: 88,      /* ?? nullish coalescing */
};

const KEYWORDS = {
    var: TK.VAR, let: TK.LET, const: TK.CONST,
    function: TK.FUNCTION, return: TK.RETURN,
    if: TK.IF, else: TK.ELSE,
    while: TK.WHILE, do: TK.DO, for: TK.FOR,
    break: TK.BREAK, continue: TK.CONTINUE,
    new: TK.NEW, in: TK.IN, of: TK.OF,
    true: TK.TRUE, false: TK.FALSE,
    null: TK.NULL, undefined: TK.UNDEFINED,
    typeof: TK.TYPEOF, instanceof: TK.INSTANCEOF,
    delete: TK.DELETE, void: TK.VOID,
    switch: TK.SWITCH, case: TK.CASE, default: TK.DEFAULT,
    try: TK.TRY, catch: TK.CATCH, throw: TK.THROW, finally: TK.FINALLY,
    this: TK.THIS,
};

class CompileError extends Error {
    constructor(msg, line, col, token, src_line) {
        super(msg);
        this.name = 'CompileError';
        this.line = line;
        this.col = col;
        this.token = token;
        this.src_line = src_line;
    }
}

class MicroJSCompiler {
    constructor() {
        this.atoms = [];        /* array of strings */
        this.atomMap = {};      /* string -> atom id (1-based) */
        this.consts = [];       /* array of {type, value} */
        this.constMap = {};     /* key -> const idx */
        this.funcs = [];        /* array of {pc, argc, nlocals, bodySize} */
        this.bc = [];           /* top-level bytecode (array of bytes) */
        this.body = [];         /* function body bytecode (array of bytes) */
        this.src = '';
        this.srcLines = [];
        /* T49: pc→line map for top-level bytecode, used by the webui
         * to highlight the source line when a runtime error reports a pc.
         * Entries are {pc, line}, recorded on line changes during emit. */
        this.lineMap = [];
        this.curLine = 0;
        /* T50: Set of known device-registered globals.  When an identifier
         * is used but not declared as a local and not in this set, the
         * compiler throws "undefined variable 'X'" — matching JS
         * ReferenceError behavior.  This catches typos like `arrayCopy`
         * when the user meant `arr`.
         *
         * T51: The list is now fetched dynamically from the device via
         * GET /globals (see http_globals() in the .ino).  The web UI
         * calls compiler.setKnownGlobals(arr) after fetching.  This
         * fallback list is kept for offline use / direct compiler
         * invocation without a device.  To add a new native, register
         * it in register_natives() in the .ino AND add its name to
         * NATIVE_GLOBAL_NAMES — the compiler will pick it up
         * automatically on next page load. */
        /* T55: Synced with NATIVE_GLOBAL_NAMES[] in microjs_esp8266.ino so that
         * the fallback list exactly matches what the device actually registers
         * via mjs_register_global() and mjs_set_global_value().  When the
         * device is unreachable (fetch('/globals') fails), the compiler now
         * behaves identically to the online case — references like isNaN(...),
         * seconds(), http.get(...), i2c.write(...) all compile, instead of
         * producing "undefined variable" errors that only appear offline. */
        this.knownGlobals = new Set([
            /* Native functions (registered via mjs_register_global) */
            'print', 'millis', 'seconds', 'centis', 'delay', 'mem', 'jsmem', 'gc', 'reset',
            'fetch', 'jsonSelect', 'jsonStream',
            'parseInt', 'isNaN', 'getIP', 'beep', 'gcDebug', 'gcRoots',
            'keys', 'keysPressed', 'keysReleased',
            'backlight', 'rand', 'hexToColor', 'colorToHex',
            'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
            /* Global objects (registered via mjs_set_global_value) */
            'console', 'Math', 'Array', 'Object', 'String', 'RegExp', 'JSON',
            'tft',
            'http', 'files', 'i2c', 'spi',
            /* Global constants */
            'PI', 'NaN',
            /* Button constants */
            'LEFT', 'UP', 'DOWN', 'RIGHT', 'A', 'B', 'RGT',
            /* JS built-in literals (keywords handle these, but just in case) */
            'undefined', 'Infinity',
        ]);
        /* T51: Merge with any device-provided globals.  setKnownGlobals()
         * replaces the fallback list with the device's actual list. */
    }

    /* T51: Replace knownGlobals with a device-provided list.
     * Called by the web UI after fetching GET /globals.
     * `arr` is an array of identifier name strings.
     * Always includes 'undefined', 'NaN', 'Infinity' for safety since
     * the compiler may emit references to them internally. */
    setKnownGlobals(arr) {
        const merged = new Set(arr || []);
        /* Always include JS built-in literals — the compiler emits
         * these internally (e.g. OP_UNDEF pushes 'undefined'). */
        merged.add('undefined');
        merged.add('NaN');
        merged.add('Infinity');
        this.knownGlobals = merged;
    }

    /* T50: Top-level declarations (var/let/const/function) collected
     * during a pre-scan so forward references work (hoisting). */
    /* (topLevelDecls is reset at the start of parse()) */

    /* ---------- Atom interning ---------- */
    atom(s) {
        if (this.atomMap[s] !== undefined) return this.atomMap[s];
        if (this.atoms.length >= 255) throw new CompileError("too many atoms", 0, 0, s, "");
        const id = this.atoms.length + 1;  /* 1-based, atom 0 reserved */
        this.atoms.push(s);
        this.atomMap[s] = id;
        return id;
    }

    /* ---------- Constant interning ---------- */
    addConstNum(v) {
        /* v is a raw fixed24.8 value.  Stored as const type 0. */
        const key = 'n' + v;
        if (this.constMap[key] !== undefined) return this.constMap[key];
        if (this.consts.length >= 255) throw new CompileError("too many consts", 0, 0, "", "");
        const idx = this.consts.length;
        this.consts.push({type: 0, value: v});
        this.constMap[key] = idx;
        return idx;
    }
    addConstString(s) {
        const key = 's' + s;
        if (this.constMap[key] !== undefined) return this.constMap[key];
        if (this.consts.length >= 255) throw new CompileError("too many consts", 0, 0, "", "");
        const idx = this.consts.length;
        this.consts.push({type: 1, value: s});
        this.constMap[key] = idx;
        return idx;
    }

    /* ---------- Lexer ---------- */
    tokenize(src) {
        this.src = src;
        this.srcLines = src.split('\n');
        const tokens = [];
        let pos = 0, line = 1;
        const isIdentStart = c => /[A-Za-z_$]/.test(c);
        const isIdent = c => /[A-Za-z0-9_$]/.test(c);
        const isDigit = c => c >= '0' && c <= '9';

        while (pos < src.length) {
            const c = src[pos];
            /* whitespace */
            if (c === ' ' || c === '\t' || c === '\r') { pos++; continue; }
            if (c === '\n') { pos++; line++; continue; }
            /* comments */
            if (c === '/' && src[pos+1] === '/') {
                while (pos < src.length && src[pos] !== '\n') pos++;
                continue;
            }
            if (c === '/' && src[pos+1] === '*') {
                pos += 2;
                while (pos + 1 < src.length && !(src[pos] === '*' && src[pos+1] === '/')) {
                    if (src[pos] === '\n') line++;
                    pos++;
                }
                if (pos + 1 < src.length) pos += 2;
                continue;
            }
            /* identifier / keyword */
            if (isIdentStart(c)) {
                let start = pos;
                while (pos < src.length && isIdent(src[pos])) pos++;
                const word = src.slice(start, pos);
                if (KEYWORDS[word] !== undefined) {
                    tokens.push({kind: KEYWORDS[word], sval: word, line});
                } else {
                    tokens.push({kind: TK.IDENT, sval: word, line});
                }
                continue;
            }
            /* number */
            if (isDigit(c)) {
                let start = pos;
                let n = 0;
                let isFloat = false;
                let fixedVal = 0;  /* fixed24.8 value for fractional numbers */
                if (c === '0' && (src[pos+1] === 'x' || src[pos+1] === 'X')) {
                    pos += 2;
                    while (pos < src.length && /[0-9a-fA-F]/.test(src[pos])) {
                        n = (n << 4) | parseInt(src[pos], 16);
                        pos++;
                    }
                } else {
                    while (pos < src.length && isDigit(src[pos])) {
                        n = n * 10 + (src.charCodeAt(pos) - 48);
                        pos++;
                    }
                    if (src[pos] === '.') {
                        isFloat = true;
                        pos++;
                        let frac = 0;
                        let divisor = 1;
                        while (pos < src.length && isDigit(src[pos])) {
                            frac = frac * 10 + (src.charCodeAt(pos) - 48);
                            divisor *= 10;
                            pos++;
                        }
                        /* Compute fixed24.8: integer part << 8 + round(frac * 256 / divisor) */
                        fixedVal = (n << 8) + Math.round(frac * 256 / divisor);
                    }
                    /* Skip exponent (not supported, but consume tokens) */
                    if (src[pos] === 'e' || src[pos] === 'E') {
                        pos++;
                        if (src[pos] === '+' || src[pos] === '-') pos++;
                        while (pos < src.length && isDigit(src[pos])) pos++;
                    }
                }
                tokens.push({kind: TK.INT, ival: n, fval: fixedVal, isFloat: isFloat, line});
                continue;
            }
            /* string literal */
            if (c === '"' || c === "'") {
                const quote = c;
                pos++;
                let start = pos;
                let out = '';
                while (pos < src.length && src[pos] !== quote) {
                    if (src[pos] === '\\' && pos + 1 < src.length) {
                        const e = src[pos+1];
                        const map = {n:'\n', t:'\t', r:'\r', '\\':'\\', "'":"'", '"':'"', '0':'\0'};
                        out += map[e] !== undefined ? map[e] : e;
                        pos += 2;
                    } else {
                        if (src[pos] === '\n') line++;
                        out += src[pos];
                        pos++;
                    }
                }
                if (pos < src.length) pos++;
                tokens.push({kind: TK.STRING, sval: out, line});
                continue;
            }
            /* T51: Template literal `...${expr}...` — tokenize into
             * TEMPLATE + STRING + expr tokens + STRING segments.
             * We store the raw content in sval and let the parser
             * split it.  Simpler approach: tokenize `...` as a single
             * TEMPLATE token with sval = raw content, then parse
             * at compile time. */
            if (c === '`') {
                pos++;
                let out = '';
                while (pos < src.length && src[pos] !== '`') {
                    if (src[pos] === '\\' && pos + 1 < src.length) {
                        const e = src[pos+1];
                        const map = {n:'\n', t:'\t', r:'\r', '\\':'\\', '`':'`', '$':'$'};
                        out += map[e] !== undefined ? map[e] : e;
                        pos += 2;
                    } else {
                        if (src[pos] === '\n') line++;
                        out += src[pos];
                        pos++;
                    }
                }
                if (pos < src.length) pos++;
                tokens.push({kind: TK.TEMPLATE, sval: out, line});
                continue;
            }
            /* operators + punctuation */
            pos++;
            const two = c + (src[pos] || '');
            const three = two + (src[pos+1] || '');
            if (three === '===' ) { tokens.push({kind: TK.STRICT_EQ, line}); pos += 2; continue; }
            if (three === '!==' ) { tokens.push({kind: TK.STRICT_NE, line}); pos += 2; continue; }
            if (three === '>>>') { tokens.push({kind: TK.USHR, line}); pos += 2; continue; }
            if (three === '>>>=') { tokens.push({kind: TK.USHREQ, line}); pos += 3; continue; }
            const twoMap = {
                '==': TK.EQ, '!=': TK.NE, '<=': TK.LE, '>=': TK.GE,
                '&&': TK.AMPAMP, '||': TK.PIPEPIPE,
                '++': TK.INC, '--': TK.DEC,
                '<<': TK.SHL, '>>': TK.SHR,
                '+=': TK.PLUSEQ, '-=': TK.MINUSEQ, '*=': TK.STAREQ,
                '/=': TK.SLASHEQ, '%=': TK.PERCENTEQ,
                '&=': TK.ANDEQ, '|=': TK.OREQ, '^=': TK.XOREQ,
                '<<=': TK.SHLEQ, '>>=': TK.SHREQ,
                '=>': TK.ARROW, '?.': TK.OPTCHAIN, '??': TK.NULLISH,
            };
            if (twoMap[two] !== undefined && (two !== '==' && two !== '!=')) {
                tokens.push({kind: twoMap[two], line});
                pos++;
                continue;
            }
            if (two === '==') { tokens.push({kind: TK.EQ, line}); pos++; continue; }
            if (two === '!=') { tokens.push({kind: TK.NE, line}); pos++; continue; }
            const oneMap = {
                '(': TK.LPAREN, ')': TK.RPAREN, '{': TK.LBRACE, '}': TK.RBRACE,
                '[': TK.LBRACKET, ']': TK.RBRACKET,
                ';': TK.SEMI, ',': TK.COMMA, '.': TK.DOT, ':': TK.COLON, '?': TK.QUESTION,
                '=': TK.ASSIGN, '+': TK.PLUS, '-': TK.MINUS, '*': TK.STAR, '/': TK.SLASH, '%': TK.PERCENT,
                '<': TK.LT, '>': TK.GT, '~': TK.BNOT, '!': TK.LNOT,
                '&': TK.BAND, '|': TK.BOR, '^': TK.XOR,
            };
            if (oneMap[c] !== undefined) {
                tokens.push({kind: oneMap[c], line});
                continue;
            }
            throw new CompileError(`unexpected character '${c}'`, line, pos, c, this.srcLines[line-1] || '');
        }
        tokens.push({kind: TK.EOF, line});
        return tokens;
    }

    /* T51: Inline caching for tft.* methods (IDs 0-14).
     * i2c/spi use normal method call — they're I/O-bound, not CPU-bound. */
    getNativeCallId(objName, methodName) {
        if (objName === 'tft') {
            const map = {
                'pixel': 0, 'rect': 1, 'fillRect': 2, 'cls': 3, 'fill': 4,
                'line': 5, 'circle': 6, 'disc': 7, 'text': 8, 'flip': 9,
                'sprite': 10, 'spriteMask': 11, 'width': 12, 'height': 13,
                'getpixel': 14,
            };
            return map[methodName] !== undefined ? map[methodName] : -1;
        }
        return -1;
    }

    /* ---------- Emitter helpers ---------- */
    emitByte(b, target = this.bc) {
        if (b < 0 || b > 255) throw new Error(`bad byte ${b}`);
        /* T49: record pc→line for top-level bytecode.  We snapshot the
         * current token's line whenever it changes, so the webui can
         * map a runtime-error pc back to a source line. */
        if (target === this.bc && this.cur && this.cur.line !== this.curLine) {
            this.curLine = this.cur.line;
            this.lineMap.push({pc: target.length, line: this.curLine});
        }
        target.push(b);
    }
    emitU16(v, target = this.bc) {
        this.emitByte(v & 0xFF, target);
        this.emitByte((v >> 8) & 0xFF, target);
    }
    emitI16(v, target = this.bc) {
        this.emitU16(v & 0xFFFF, target);
    }
    emitInt(v) {
        if (v >= 0 && v <= 255) { this.emitByte(OP.INT8); this.emitByte(v); }
        else if (v >= -32768 && v <= 32767) { this.emitByte(OP.INT16); this.emitI16(v); }
        else { this.emitByte(OP.INT24); this.emitByte(v & 0xFF); this.emitByte((v >> 8) & 0xFF); this.emitByte((v >> 16) & 0xFF); }
    }
    emitPlaceholder(target = this.bc) {
        const off = target.length;
        target.push(0, 0);
        return off;
    }
    patchJump(at, to, target = this.bc) {
        const delta = to - (at + 2);
        target[at] = delta & 0xFF;
        target[at+1] = (delta >> 8) & 0xFF;
    }

    /* ---------- Parser ---------- */

    /* T51: Removed prescanTopLevelDecls — the compiler now registers
     * declarations in topLevelDecls as it encounters them during normal
     * parsing (in parseVar and parseFunction).  This is simpler and
     * more robust — no separate pass that could get out of sync with
     * the actual parse logic.
     *
     * Trade-off: forward references (JS hoisting) are NOT supported.
     * Functions and variables must be declared before use.  This is
     * standard practice and matches how most embedded code is written.
     * If a forward reference is detected, the user gets a clear
     * "undefined variable" compile error pointing to the line. */

    parse(src) {
        this.tokens = this.tokenize(src);
        this.tokIdx = 0;
        this.cur = this.tokens[0];

        /* Reset all state — compile() may be called multiple times. */
        this.nlocals = 0;
        this.locals = [];
        this.breakStack = [];
        this.continueStack = [];
        this.bc = [];
        this.body = [];
        this.atoms = [];
        this.atomMap = {};
        this.consts = [];
        this.constMap = {};
        this.funcs = [];
        this.topLevelConsts = {};  /* T48: track top-level const names */
        this.lineMap = [];          /* T49: pc→line map */
        this.curLine = 0;
        this.topLevelDecls = new Set();  /* T51: built incrementally during parse */
        this.inTypeof = false;  /* JS-11-fix: set by parseUnary TK.TYPEOF, used by parsePrimary IDENT */

        /* T51: Reserved names — cannot be used as variable names at top level.
         * These are system globals/functions that would be shadowed. */
        this.reservedNames = new Set([
            'print','millis','delay','mem','jsmem','gc','reset',
            'parseInt','gcDebug','gcRoots','beep','fetch','jsonSelect','jsonStream',
            'keys','keysPressed','keysReleased',
            'backlight','rand','hexToColor','colorToHex',
            'setTimeout','setInterval','clearTimeout','clearInterval',
            'console','Math','Array','String','Object','RegExp','tft','JSON','http','files',
            'PI','NaN','LEFT','UP','DOWN','RIGHT','A','B','RGT',
        ]);

        /* T41: pre-register standard library atoms so that VM's
         * LOAD_PROP can find Array/String/console/Math globals even
         * if the script doesn't explicitly reference them by name.
         * Without this, "Array" might not be in the atom table and
         * arr.push() fails with "not a function (undefined)". */
        this.atom('Array');
        this.atom('String');
        this.atom('console');
        this.atom('Math');
        this.atom('push');
        this.atom('slice');
        this.atom('forEach');
        this.atom('isArray');
        this.atom('length');
        this.atom('charAt');
        this.atom('indexOf');
        this.atom('substring');
        this.atom('toUpperCase');
        this.atom('toLowerCase');
        this.atom('split');     /* T51 */
        this.atom('replace');   /* T51 */
        this.atom('match');     /* T51: regex match */
        this.atom('test');      /* T51: regex test */
        this.atom('floor');
        this.atom('round');
        this.atom('abs');
        this.atom('min');
        this.atom('max');
        this.atom('random');
        this.atom('pow');       /* T51 */
        this.atom('sqrt');      /* T51 */
        this.atom('sin');       /* T51 */
        this.atom('cos');       /* T51 */
        this.atom('tan');       /* T51 */
        this.atom('atan2');     /* T51 */
        this.atom('log');
        this.atom('warn');
        this.atom('error');
        this.atom('info');
        this.atom('PI');

        while (this.cur.kind !== TK.EOF) {
            this.parseStmt();
        }
        this.emitByte(OP.HALT);
    }

    /* Token helpers */
    peek(off = 0) { return this.tokens[this.tokIdx + off] || this.tokens[this.tokens.length - 1]; }
    advance() {
        const t = this.cur;
        this.tokIdx++;
        this.cur = this.tokens[this.tokIdx] || this.tokens[this.tokens.length - 1];
        return t;
    }
    accept(k) {
        if (this.cur.kind === k) { this.advance(); return true; }
        return false;
    }
    /* T42: ASI (Automatic Semicolon Insertion) — accept ; or newline. */
    acceptSemi() {
        if (this.accept(TK.SEMI)) return true;
        /* No semicolon — check if we're at end of line.
         * If the previous token was on a different line, treat as ;. */
        if (this.tokIdx > 0) {
            var prevTok = this.tokens[this.tokIdx - 1];
            if (prevTok && this.cur.line > prevTok.line) return true;
        }
        /* Also accept at EOF, }, or start of new statement keyword. */
        if (this.cur.kind === TK.EOF || this.cur.kind === TK.RBRACE) return true;
        return false;
    }
    expect(k, what) {
        if (this.cur.kind !== k) {
            throw new CompileError(`expected ${what}`, this.cur.line, this.tokIdx,
                this.cur.sval || '', this.srcLines[this.cur.line - 1] || '');
        }
        return this.advance();
    }
    err(msg) {
        throw new CompileError(msg, this.cur.line, this.tokIdx,
            this.cur.sval || '', this.srcLines[this.cur.line - 1] || '');
    }

    /* Local variable tracking — T45: added isConst flag. */
    localFind(name) {
        for (let i = this.locals.length - 1; i >= 0; i--) {
            if (this.locals[i].name === name) return this.locals[i].slot;
        }
        return -1;
    }
    localFindConst(name) {
        for (let i = this.locals.length - 1; i >= 0; i--) {
            if (this.locals[i].name === name) return this.locals[i].isConst;
        }
        /* T48: check top-level const globals. */
        if (this.topLevelConsts && this.topLevelConsts[name]) return true;
        return false;
    }
    localAdd(name, isConst) {
        if (this.locals.length >= 63) this.err("too many locals in one function");
        const slot = this.locals.length;
        this.locals.push({name, slot, isConst: !!isConst});
        return slot;
    }

    /* ---------- Statements ---------- */
    parseStmt() {
        const t = this.cur;
        switch (t.kind) {
            case TK.LBRACE: return this.parseBlock();
            case TK.VAR:
            case TK.LET:
            case TK.CONST: return this.parseVar();
            case TK.IF: return this.parseIf();
            case TK.WHILE: return this.parseWhile();
            case TK.FOR: return this.parseFor();
            case TK.DO: return this.parseDo();
            case TK.RETURN: return this.parseReturn();
            case TK.SWITCH: return this.parseSwitch();
            /* T51: try/catch/throw */
            case TK.TRY: return this.parseTry();
            case TK.THROW: {
                this.advance();
                this.parseExpr();
                this.emitByte(OP.THROW);
                this.acceptSemi();
                return;
            }
            case TK.BREAK: {
                this.advance();
                if (this.breakStack.length === 0) this.err("break outside loop or switch");
                this.emitByte(OP.JMP);
                const ph = this.emitPlaceholder();
                this.breakStack[this.breakStack.length - 1].push(ph);
                this.acceptSemi();
                return;
            }
            case TK.CONTINUE: {
                this.advance();
                if (this.continueStack.length === 0) this.err("continue outside loop");
                this.emitByte(OP.JMP);
                const ph = this.emitPlaceholder();
                this.continueStack[this.continueStack.length - 1].push(ph);
                this.acceptSemi();
                return;
            }
            case TK.SEMI: this.advance(); return;
            case TK.FUNCTION: {
                this.advance();
                if (this.cur.kind !== TK.IDENT) this.err("expected function name");
                const name = this.advance().sval;
                this.parseFunction(name);
                return;
            }
            case TK.EOF: return;
            default: {
                this.parseExpr();
                this.emitByte(OP.POP);
                this.acceptSemi();
                return;
            }
        }
    }

    parseBlock() {
        this.expect(TK.LBRACE, "'{'");
        while (this.cur.kind !== TK.RBRACE && this.cur.kind !== TK.EOF) {
            this.parseStmt();
        }
        this.expect(TK.RBRACE, "'}'");
    }

    parseVar() {
        const declKind = this.cur.kind;  /* VAR, LET, or CONST */
        this.advance();  /* var/let/const */
        /* T48: top-level var/let/const should use STORE_GLOBAL so they're
         * accessible from nested functions.  We detect top-level by
         * checking if this.locals is empty (no enclosing function). */
        const isTopLevel = (this.locals.length === 0);
        for (;;) {
            /* T51: Array destructuring: var [a, b] = arr */
            if (this.cur.kind === TK.LBRACKET) {
                this.advance();  /* consume '[' */
                /* Collect names.  Support skips: [a, , c] and rest not supported. */
                let names = [];
                while (this.cur.kind !== TK.RBRACKET) {
                    if (this.cur.kind === TK.COMMA) { names.push(null); this.advance(); continue; }
                    if (this.cur.kind !== TK.IDENT) this.err("expected identifier in array destructuring");
                    names.push(this.advance().sval);
                    if (this.cur.kind === TK.COMMA) this.advance();
                }
                this.expect(TK.RBRACKET, "']'");
                this.expect(TK.ASSIGN, "'='");
                this.parseExpr();  /* leaves RHS on stack */
                /* Emit: for each name, LOAD_INDEX i, STORE name, POP (except last). */
                for (let i = 0; i < names.length; i++) {
                    if (names[i] === null) continue;
                    if (i < names.length - 1) this.emitByte(OP.DUP);
                    this.emitByte(OP.INT8); this.emitByte(i);
                    this.emitByte(OP.LOAD_INDEX);
                    if (isTopLevel) {
                        this.emitByte(OP.STORE_GLOBAL); this.emitByte(this.atom(names[i]));
                        this.topLevelDecls.add(names[i]);
                    } else {
                        const s = this.localAdd(names[i], declKind === TK.CONST);
                        this.emitByte(OP.STORE_LOCAL); this.emitByte(s);
                    }
                    if (i < names.length - 1) this.emitByte(OP.POP);
                }
                this.emitByte(OP.POP);  /* pop the RHS */
                if (!this.accept(TK.COMMA)) break;
                continue;
            }
            /* T51: Object destructuring: var {x, y} = obj */
            if (this.cur.kind === TK.LBRACE) {
                this.advance();  /* consume '{' */
                let pairs = [];  /* {name, alias} */
                while (this.cur.kind !== TK.RBRACE) {
                    if (this.cur.kind !== TK.IDENT) this.err("expected identifier in object destructuring");
                    const key = this.advance().sval;
                    let alias = key;
                    /* Support {key: alias} syntax */
                    if (this.cur.kind === TK.COLON) {
                        this.advance();
                        if (this.cur.kind !== TK.IDENT) this.err("expected identifier after ':'");
                        alias = this.advance().sval;
                    }
                    pairs.push({key, alias});
                    if (this.cur.kind === TK.COMMA) this.advance();
                }
                this.expect(TK.RBRACE, "'}'");
                this.expect(TK.ASSIGN, "'='");
                this.parseExpr();  /* leaves RHS on stack */
                for (let i = 0; i < pairs.length; i++) {
                    if (i < pairs.length - 1) this.emitByte(OP.DUP);
                    this.emitByte(OP.LOAD_PROP); this.emitByte(this.atom(pairs[i].key));
                    if (isTopLevel) {
                        this.emitByte(OP.STORE_GLOBAL); this.emitByte(this.atom(pairs[i].alias));
                        this.topLevelDecls.add(pairs[i].alias);
                    } else {
                        const s = this.localAdd(pairs[i].alias, declKind === TK.CONST);
                        this.emitByte(OP.STORE_LOCAL); this.emitByte(s);
                    }
                    if (i < pairs.length - 1) this.emitByte(OP.POP);
                }
                this.emitByte(OP.POP);  /* pop the RHS */
                if (!this.accept(TK.COMMA)) break;
                continue;
            }
            if (this.cur.kind !== TK.IDENT) this.err("expected identifier in var");
            const name = this.advance().sval;
            /* T51: Prevent shadowing system globals at top level. */
            if (isTopLevel && this.reservedNames.has(name)) {
                this.err(`'${name}' is a reserved system name — cannot be used as a variable`);
            }
            /* At top level, always use globals. Inside functions, use locals. */
            let slot;
            let useGlobal = isTopLevel;
            if (useGlobal) {
                /* Register as a global — no local slot needed. */
                slot = -1;
                /* T48: track top-level const for reassignment check. */
                if (declKind === TK.CONST) this.topLevelConsts[name] = true;
                /* T51: register in topLevelDecls immediately — no prescan needed.
                 * The compiler processes declarations in source order, so by
                 * the time a variable is used, it's already been declared
                 * (assuming declare-before-use, which is standard practice).
                 * This replaces the separate prescanTopLevelDecls pass. */
                this.topLevelDecls.add(name);
            } else {
                slot = this.localAdd(name, declKind === TK.CONST);
            }
            if (this.accept(TK.ASSIGN)) {
                this.parseExpr();
                if (useGlobal) {
                    this.emitByte(OP.STORE_GLOBAL);
                    this.emitByte(this.atom(name));
                } else {
                    this.emitByte(OP.STORE_LOCAL); this.emitByte(slot);
                }
                this.emitByte(OP.POP);
            } else {
                this.emitByte(OP.UNDEF);
                if (useGlobal) {
                    this.emitByte(OP.STORE_GLOBAL);
                    this.emitByte(this.atom(name));
                } else {
                    this.emitByte(OP.STORE_LOCAL); this.emitByte(slot);
                }
                this.emitByte(OP.POP);
            }
            if (!this.accept(TK.COMMA)) break;
        }
        this.acceptSemi();
    }

    parseIf() {
        this.advance();
        this.expect(TK.LPAREN, "'('");
        this.parseExpr();
        this.expect(TK.RPAREN, "')'");
        this.emitByte(OP.JZ);
        const jmpElse = this.emitPlaceholder();
        this.parseStmt();
        if (this.accept(TK.ELSE)) {
            this.emitByte(OP.JMP);
            const jmpEnd = this.emitPlaceholder();
            const elsePos = this.bc.length;
            this.patchJump(jmpElse, elsePos);
            this.parseStmt();
            const endPos = this.bc.length;
            this.patchJump(jmpEnd, endPos);
        } else {
            const endPos = this.bc.length;
            this.patchJump(jmpElse, endPos);
        }
    }

    parseWhile() {
        this.advance();
        this.expect(TK.LPAREN, "'('");
        const loopStart = this.bc.length;
        this.parseExpr();
        this.expect(TK.RPAREN, "')'");
        this.emitByte(OP.JZ);
        const jmpEnd = this.emitPlaceholder();
        /* Push break/continue stacks. */
        this.breakStack.push([]);
        this.continueStack.push([]);
        this.parseStmt();
        /* Continue jumps to here (loop condition). */
        const continueTarget = this.bc.length + 3;
        this.emitByte(OP.JMP);
        const back = loopStart - (this.bc.length + 2);
        this.emitI16(back);
        const endPos = this.bc.length;
        this.patchJump(jmpEnd, endPos);
        /* Patch break/continue. */
        for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
        for (const ph of this.continueStack.pop()) this.patchJump(ph, continueTarget);
    }

    parseDo() {
        this.advance();
        const loopStart = this.bc.length;
        this.breakStack.push([]);
        this.continueStack.push([]);
        this.parseStmt();
        const continueTarget = this.bc.length;
        this.expect(TK.WHILE, "'while'");
        this.expect(TK.LPAREN, "'('");
        this.parseExpr();
        this.expect(TK.RPAREN, "')'");
        this.emitByte(OP.JNZ);
        const back = loopStart - (this.bc.length + 2);
        this.emitI16(back);
        const endPos = this.bc.length;
        for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
        for (const ph of this.continueStack.pop()) this.patchJump(ph, continueTarget);
        this.acceptSemi();
    }

    parseFor() {
        this.advance();  /* consume 'for' */
        this.expect(TK.LPAREN, "'('");

        /* Check for for...in / for...of: `for (var k in obj)` or `for (var v of arr)`. */
        if (this.cur.kind === TK.VAR || this.cur.kind === TK.LET || this.cur.kind === TK.CONST) {
            /* Save position to roll back if this turns out to be a
             * classic for-loop (var i = 0; ...). */
            const saveIdx = this.tokIdx;
            const saveTok = this.cur;
            this.advance();  /* consume var/let/const */
            if (this.cur.kind === TK.IDENT) {
                const varName = this.cur.sval;
                this.advance();
                if (this.cur.kind === TK.IN) {
                    /* for (var k in obj) */
                    this.advance();  /* consume 'in' */
                    this.parseExpr();  /* the object */
                    this.expect(TK.RPAREN, "')'");
                    /* T51: Bug 1 fix — at top level, use globals instead of locals.
                     * This ensures the loop variable is accessible from nested functions. */
                    const isTopLevel = (this.locals.length === 0);
                    let slot = -1, idxSlot = -1, objSlot = -1;
                    let idxAtom = 0, objAtom = 0, varAtom = 0;
                    if (isTopLevel) {
                        varAtom = this.atom(varName);
                        idxAtom = this.atom('__for_in_idx');
                        objAtom = this.atom('__for_in_obj');
                        this.topLevelDecls.add(varName);
                    } else {
                        slot = this.localAdd(varName);
                        idxSlot = this.localAdd('__for_in_idx');
                        objSlot = this.localAdd('__for_in_obj');
                    }
                    const emitStore = (s, a) => { if (isTopLevel) { this.emitByte(OP.STORE_GLOBAL); this.emitByte(a); } else { this.emitByte(OP.STORE_LOCAL); this.emitByte(s); } };
                    const emitLoad = (s, a) => { if (isTopLevel) { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(a); } else { this.emitByte(OP.LOAD_LOCAL); this.emitByte(s); } };
                    /* Store obj first (it's on top of stack now). */
                    emitStore(objSlot, objAtom);
                    this.emitByte(OP.POP);  /* discard (STORE leaves value) */
                    /* Initialize idx = 0. */
                    this.emitByte(OP.INT8); this.emitByte(0);
                    emitStore(idxSlot, idxAtom);
                    this.emitByte(OP.POP);  /* discard */
                    const loopStart = this.bc.length;
                    /* Load obj, load idx, FOR_IN_NEXT. */
                    emitLoad(objSlot, objAtom);
                    emitLoad(idxSlot, idxAtom);
                    this.emitByte(OP.FOR_IN_NEXT);
                    /* Stack: [key, idx].  Store idx (top), pop, leaving key. */
                    emitStore(idxSlot, idxAtom);
                    this.emitByte(OP.POP);    /* discard idx, leaving [key] */
                    /* T49: check key === undefined (not falsiness). */
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.UNDEF);
                    this.emitByte(OP.STRICT_EQ);
                    this.emitByte(OP.JNZ);
                    const jmpEnd = this.emitPlaceholder();
                    /* Store key into k, then POP. */
                    emitStore(slot, varAtom);
                    this.emitByte(OP.POP);
                    /* Parse body. */
                    this.breakStack.push([]);
                    this.continueStack.push([]);
                    this.parseStmt();
                    /* JMP back to loopStart. */
                    this.emitByte(OP.JMP);
                    const back = loopStart - (this.bc.length + 2);
                    this.emitI16(back);
                    const endPos = this.bc.length;
                    this.patchJump(jmpEnd, endPos);
                    for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
                    for (const ph of this.continueStack.pop()) this.patchJump(ph, loopStart);
                    return;
                }
                if (this.cur.kind === TK.OF) {
                    /* for (var v of arr) — iterate array values. */
                    this.advance();  /* consume 'of' */
                    this.parseExpr();  /* the array */
                    this.expect(TK.RPAREN, "')'");
                    /* T51: Bug 1 fix — at top level, use globals instead of locals. */
                    const isTopLevel = (this.locals.length === 0);
                    let slot = -1, idxSlot = -1, arrSlot = -1;
                    let idxAtom = 0, arrAtom = 0, varAtom = 0;
                    if (isTopLevel) {
                        varAtom = this.atom(varName);
                        idxAtom = this.atom('__for_of_idx');
                        arrAtom = this.atom('__for_of_arr');
                        this.topLevelDecls.add(varName);
                    } else {
                        slot = this.localAdd(varName);
                        idxSlot = this.localAdd('__for_of_idx');
                        arrSlot = this.localAdd('__for_of_arr');
                    }
                    const emitStore = (s, a) => { if (isTopLevel) { this.emitByte(OP.STORE_GLOBAL); this.emitByte(a); } else { this.emitByte(OP.STORE_LOCAL); this.emitByte(s); } };
                    const emitLoad = (s, a) => { if (isTopLevel) { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(a); } else { this.emitByte(OP.LOAD_LOCAL); this.emitByte(s); } };
                    /* Store array first. */
                    emitStore(arrSlot, arrAtom);
                    this.emitByte(OP.POP);  /* discard */
                    /* idx = 0. */
                    this.emitByte(OP.INT8); this.emitByte(0);
                    emitStore(idxSlot, idxAtom);
                    this.emitByte(OP.POP);  /* discard */
                    const loopStart = this.bc.length;
                    /* Load arr, idx, FOR_OF_NEXT. */
                    emitLoad(arrSlot, arrAtom);
                    emitLoad(idxSlot, idxAtom);
                    this.emitByte(OP.FOR_OF_NEXT);
                    /* Stack: [value, idx].  Store idx (top), pop, leaving value. */
                    emitStore(idxSlot, idxAtom);
                    this.emitByte(OP.POP);    /* discard idx */
                    /* T49: check value === undefined (not falsiness). */
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.UNDEF);
                    this.emitByte(OP.STRICT_EQ);
                    this.emitByte(OP.JNZ);
                    const jmpEnd = this.emitPlaceholder();
                    emitStore(slot, varAtom);
                    this.emitByte(OP.POP);  /* discard stored value */
                    this.breakStack.push([]);
                    this.continueStack.push([]);
                    this.parseStmt();
                    this.emitByte(OP.JMP);
                    const back = loopStart - (this.bc.length + 2);
                    this.emitI16(back);
                    const endPos = this.bc.length;
                    this.patchJump(jmpEnd, endPos);
                    for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
                    for (const ph of this.continueStack.pop()) this.patchJump(ph, loopStart);
                    return;
                }
            }
            /* Not for...in/of — roll back and parse as classic for. */
            this.tokIdx = saveIdx;
            this.cur = saveTok;
        }

        /* ---- classic for: init ; cond ; post ) body ---- */
        if (this.cur.kind === TK.VAR || this.cur.kind === TK.LET || this.cur.kind === TK.CONST) {
            this.parseVar();  /* parseVar consumes the trailing ; */
        } else {
            if (this.cur.kind !== TK.SEMI) {
                this.parseExpr();
                this.emitByte(OP.POP);
            }
            this.expect(TK.SEMI, "';'");
        }

        /* ---- cond: parse the condition expression (if any) ----
         * Bytecode layout (classic structure):
         *   loopStart: <cond> JZ end
         *   <body>
         *   postStart: <post> POP
         *   JMP loopStart
         *   end:
         * (continue jumps to postStart, break jumps to end)
         */
        let jmpEnd = -1;
        const loopStart = this.bc.length;
        if (this.cur.kind !== TK.SEMI) {
            this.parseExpr();
            this.emitByte(OP.JZ);
            jmpEnd = this.emitPlaceholder();
        }
        this.expect(TK.SEMI, "';'");

        /* ---- post: parse it now to discover its token range, but
         * DON'T emit bytecode yet — we'll re-emit it after the body.
         * Save the bc length BEFORE the throwaway post parse so we
         * can truncate back to it. */
        const bcLenBeforePost = this.bc.length;
        const postStartTok = this.tokIdx;
        if (this.cur.kind !== TK.RPAREN) {
            this.parseExpr();  /* advances lexer; bytecode discarded below */
        }
        const postEndTok = this.tokIdx;
        /* Discard any bytecode the throwaway post parse emitted. */
        this.bc.length = bcLenBeforePost;
        /* Don't rewind the lexer yet — we need to consume ')' first,
         * then parse the body (which is AFTER ')' in the source).
         * After the body, we'll rewind to postStartTok to emit post. */

        /* Consume ')' */
        this.expect(TK.RPAREN, "')'");

        /* ---- body ---- */
        this.breakStack.push([]);
        this.continueStack.push([]);
        this.parseStmt();

        /* T50: Save the lexer position AFTER the body was parsed.
         * We need this because the post-expression re-parse below
         * rewinds the lexer to inside the for(...) header, and after
         * re-parsing it lands on '{' (the body) — but the body was
         * already parsed!  Without restoring, the main parse loop
         * re-parses the body as a new statement, causing the loop
         * body to execute one extra time after the loop exits.
         * This was the root cause of QuickSort's infinite recursion:
         * partition() was called once extra after the loop, returning
         * a wrong pi, leading to infinite recursion. */
        const afterBodyTokIdx = this.tokIdx;
        const afterBodyTok = this.cur;

        /* ---- post: rewind lexer to the post expression and emit it ---- */
        const postStart = this.bc.length;  /* continue jumps here */
        if (postEndTok > postStartTok) {
            this.tokIdx = postStartTok;
            this.cur = this.tokens[this.tokIdx];
            this.parseExpr();
            this.emitByte(OP.POP);
            /* After re-parsing the post, the lexer is positioned at
             * the ')' that we already consumed earlier (before body).
             * We must consume it again to keep the lexer in sync. */
            if (this.cur.kind === TK.RPAREN) {
                this.advance();
            }
        }

        /* T50: Restore lexer to AFTER the body — without this, the
         * main parse loop re-parses the body as a new statement. */
        this.tokIdx = afterBodyTokIdx;
        this.cur = afterBodyTok;

        /* ---- jump back to condition ---- */
        this.emitByte(OP.JMP);
        const back = loopStart - (this.bc.length + 2);
        this.emitI16(back);

        /* ---- patch JZ to land here (after the back-jump) ---- */
        const endPos = this.bc.length;
        if (jmpEnd >= 0) this.patchJump(jmpEnd, endPos);

        /* ---- patch break -> endPos, continue -> postStart ---- */
        for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
        for (const ph of this.continueStack.pop()) this.patchJump(ph, postStart);
    }

    parseReturn() {
        this.advance();
        if (this.cur.kind === TK.SEMI || this.cur.kind === TK.RBRACE || this.cur.kind === TK.EOF) {
            this.emitByte(OP.RET_UNDEF);
            this.acceptSemi();
            return;
        }
        this.parseExpr();
        this.emitByte(OP.RET);
        this.acceptSemi();
    }

    /* T51: try { body } catch (e) { handler }
     * Emits: PUSH_TRY catch_pc, <body>, POP_TRY, JMP end, catch: <handler>, end:
     * The VM maintains a try-stack.  When an error occurs (ERR or THROW),
     * the VM unwinds to the nearest try handler and jumps to catch_pc.
     * The error message (as a string) is pushed onto the stack before
     * entering the catch block. */
    parseTry() {
        this.advance();  /* consume 'try' */
        this.expect(TK.LBRACE, "'{' after try");
        /* Emit PUSH_TRY with placeholder for catch_pc */
        this.emitByte(OP.PUSH_TRY);
        const catchPcPlaceholder = this.emitPlaceholder();
        /* Parse try body */
        while (this.cur.kind !== TK.RBRACE && this.cur.kind !== TK.EOF) {
            this.parseStmt();
        }
        this.expect(TK.RBRACE, "'}'");
        /* try body completed normally — pop try handler, jump past catch */
        this.emitByte(OP.POP_TRY);
        this.emitByte(OP.JMP);
        const endJmp = this.emitPlaceholder();
        /* catch: — patch the PUSH_TRY to point here */
        const catchPc = this.bc.length;
        this.patchJump(catchPcPlaceholder, catchPc);
        /* Expect catch (e) { handler } */
        this.expect(TK.CATCH, "'catch'");
        this.expect(TK.LPAREN, "'(' after catch");
        if (this.cur.kind !== TK.IDENT) this.err("expected catch variable name");
        const errVar = this.cur.sval;
        this.advance();
        this.expect(TK.RPAREN, "')'");
        this.expect(TK.LBRACE, "'{' after catch");
        /* The error string is on the stack.  Store it in errVar. */
        const isTopLevel = (this.locals.length === 0);
        if (isTopLevel) {
            const atom = this.atom(errVar);
            this.topLevelDecls.add(errVar);
            this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom);
        } else {
            const slot = this.localAdd(errVar);
            this.emitByte(OP.STORE_LOCAL); this.emitByte(slot);
        }
        this.emitByte(OP.POP);  /* STORE leaves value on stack */
        /* Parse catch body */
        while (this.cur.kind !== TK.RBRACE && this.cur.kind !== TK.EOF) {
            this.parseStmt();
        }
        this.expect(TK.RBRACE, "'}'");
        /* end: — patch the JMP past catch */
        const endPc = this.bc.length;
        this.patchJump(endJmp, endPc);
    }

    /* switch (expr) { case v1: stmts; case v2: stmts; default: stmts; }
     * T42: NO fallthrough — each case body auto-inserts JMP end.
     * Switch value is kept on stack; each case: DUP, compare, JZ next,
     * POP (drop dup), body, JMP end.  At end: POP (drop switch val).
     * This avoids the bug where fallthrough tries to DUP after the
     * value was already POPed. */
    parseSwitch() {
        this.advance();  /* consume 'switch' */
        this.expect(TK.LPAREN, "'('");
        this.parseExpr();  /* the switch value */
        this.expect(TK.RPAREN, "')'");
        this.expect(TK.LBRACE, "'{'");

        this.breakStack.push([]);

        while (this.cur.kind !== TK.RBRACE && this.cur.kind !== TK.EOF) {
            if (this.cur.kind === TK.CASE) {
                this.advance();
                /* DUP switch value, push case value, STRICT_EQ, JZ next. */
                this.emitByte(OP.DUP);
                this.parseExpr();
                this.emitByte(OP.STRICT_EQ);
                this.emitByte(OP.JZ);
                const jmpNext = this.emitPlaceholder();
                /* POP the dup (we matched). */
                this.emitByte(OP.POP);
                this.expect(TK.COLON, "':'");
                /* Parse case body. */
                while (this.cur.kind !== TK.CASE &&
                       this.cur.kind !== TK.DEFAULT &&
                       this.cur.kind !== TK.RBRACE &&
                       this.cur.kind !== TK.EOF) {
                    this.parseStmt();
                }
                /* T42: auto-insert JMP end (no fallthrough). */
                this.emitByte(OP.JMP);
                const jmpEnd = this.emitPlaceholder();
                this.breakStack[this.breakStack.length - 1].push(jmpEnd);
                /* Patch JZ to here (next case). */
                this.patchJump(jmpNext, this.bc.length);
            } else if (this.cur.kind === TK.DEFAULT) {
                this.advance();
                this.expect(TK.COLON, "':'");
                while (this.cur.kind !== TK.CASE &&
                       this.cur.kind !== TK.DEFAULT &&
                       this.cur.kind !== TK.RBRACE &&
                       this.cur.kind !== TK.EOF) {
                    this.parseStmt();
                }
                /* Auto-insert JMP end. */
                this.emitByte(OP.JMP);
                const jmpEnd = this.emitPlaceholder();
                this.breakStack[this.breakStack.length - 1].push(jmpEnd);
            } else {
                this.err("expected 'case' or 'default' in switch");
            }
        }
        this.expect(TK.RBRACE, "'}'");
        /* POP the switch value. */
        this.emitByte(OP.POP);
        /* Patch all break/jmpEnd to here. */
        const endPos = this.bc.length;
        for (const ph of this.breakStack.pop()) this.patchJump(ph, endPos);
    }

    parseFunction(name) {
        /* T51: register the function name in topLevelDecls BEFORE parsing
         * the body, so recursive calls inside the body resolve correctly.
         * This replaces the prescan approach — the compiler processes
         * declarations in source order, so forward references (hoisting)
         * are not supported.  Declare functions before calling them. */
        if (name && this.locals.length === 0) {
            if (this.reservedNames.has(name)) {
                this.err(`'${name}' is a reserved system name — cannot be used as a function name`);
            }
            this.topLevelDecls.add(name);
        }
        this.expect(TK.LPAREN, "'(' after function name");
        /* Save enclosing scope. */
        const savedLocals = this.locals;
        const savedNlocals = this.nlocals;
        this.locals = [];
        /* Parse parameter list. T51: Support default params: a = 10. */
        let argc = 0;
        let defaultInits = [];  /* {slot, expr_tokens} for params with defaults */
        while (this.cur.kind !== TK.RPAREN) {
            if (this.cur.kind !== TK.IDENT) this.err("expected parameter name");
            const pname = this.advance().sval;
            const slot = this.localAdd(pname);
            argc++;
            /* T51: Default parameter: param = expr */
            if (this.cur.kind === TK.ASSIGN) {
                this.advance();  /* consume '=' */
                /* Save token range for the default expression — we'll
                 * emit it at the start of the function body.
                 * IMPORTANT: Don't emit bytecode here!  We're still in
                 * the top-level bc context.  Suppress emission by
                 * temporarily swapping bc to a throwaway array. */
                const exprStart = this.tokIdx;
                const savedBc = this.bc;
                this.bc = [];  /* throwaway — discard emitted bytes */
                this.parseExpr();
                this.bc = savedBc;  /* restore */
                const exprEnd = this.tokIdx;
                defaultInits.push({slot, exprStart, exprEnd});
            }
            if (!this.accept(TK.COMMA)) break;
        }
        this.expect(TK.RPAREN, "')'");

        /* Allocate a function entry. */
        if (this.funcs.length >= 63) this.err("too many functions");
        const funcIdx = this.funcs.length;
        const funcEntry = {pc: 0, argc, nlocals: 0, bodySize: 0};
        this.funcs.push(funcEntry);

        /* Parse body into this.body. */
        const savedBc = this.bc;
        this.bc = this.body;
        funcEntry.pc = this.bc.length;
        /* T51: Emit default parameter initializers at function start.
         * For each param with default: if param === undefined, set it. */
        for (const di of defaultInits) {
            /* LOAD_LOCAL slot, DUP, UNDEF, STRICT_EQ, JNZ skip, POP, <expr>, STORE_LOCAL slot, skip: */
            this.emitByte(OP.LOAD_LOCAL); this.emitByte(di.slot);
            this.emitByte(OP.DUP);
            this.emitByte(OP.UNDEF);
            this.emitByte(OP.STRICT_EQ);
            this.emitByte(OP.JNZ);
            const jmp = this.emitPlaceholder();
            this.emitByte(OP.POP);
            /* Re-emit the default expression.  Save/restore token state. */
            const savedTI = this.tokIdx;
            const savedCur = this.cur;
            this.tokIdx = di.exprStart;
            this.cur = this.tokens[this.tokIdx];
            this.parseExpr();
            this.tokIdx = savedTI;
            this.cur = savedCur;
            this.emitByte(OP.STORE_LOCAL); this.emitByte(di.slot);
            this.patchJump(jmp, this.bc.length);
        }
        this.parseBlock();
        this.emitByte(OP.RET_UNDEF);
        funcEntry.nlocals = this.locals.length;
        funcEntry.bodySize = this.bc.length - funcEntry.pc;
        this.bc = savedBc;

        /* Restore enclosing scope. */
        this.locals = savedLocals;
        this.nlocals = savedNlocals;

        /* Emit OP_FUNCTION in the enclosing (top-level or body) scope. */
        this.emitByte(OP.FUNCTION);
        this.emitByte(funcIdx);

        /* Store the function under its name. */
        if (name) {
            const atom = this.atom(name);
            const slot = this.localFind(name);
            if (slot >= 0) {
                this.emitByte(OP.STORE_LOCAL); this.emitByte(slot);
            } else {
                this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom);
            }
        }
    }

    /* ---------- Expressions ---------- */
    parseExpr() {
        /* Parse assignment first, then check for ternary ?:.
         * In JS, ternary has lower precedence than || but higher than =.
         * For our purposes, putting it here (above assignment) works
         * for the common cases like `x = a ? 1 : 2` and `a ? b : c`. */
        this.parseTernary();
    }

    parseTernary() {
        this.parseAssignment();
        if (this.cur.kind === TK.QUESTION) {
            /* Stack: [cond].  Emit JZ to else branch. */
            this.advance();
            this.emitByte(OP.JZ);
            const jmpElse = this.emitPlaceholder();
            /* Parse true branch — assignment-expression (no comma).
             * T51-fix: was parseAssignment() but that doesn't allow
             * nested ternary in the true branch.  Use parseTernary
             * so `a ? b ? c : d : e` works (true branch is itself
             * a ternary).  Ternary is right-associative in JS. */
            this.parseTernary();
            /* JMP to end. */
            this.emitByte(OP.JMP);
            const jmpEnd = this.emitPlaceholder();
            /* Patch JZ to here (false branch). */
            this.patchJump(jmpElse, this.bc.length);
            this.expect(TK.COLON, "':'");
            /* Parse false branch — must be parseTernary (not
             * parseAssignment) so `a ? b : c ? d : e` nests correctly:
             * the false branch can itself be a ternary. */
            this.parseTernary();
            /* Patch JMP to here. */
            this.patchJump(jmpEnd, this.bc.length);
        }
    }

    parseAssignment() {
        /* Lvalue check: IDENT [.prop | [idx]]* = rhs
         * T51: Also handle `this` as lvalue base: this.prop = val, this[idx] = val. */
        if (this.cur.kind === TK.THIS) {
            /* Lookahead: this [.prop | [idx]]+ = rhs */
            const saveIdx = this.tokIdx;
            const saveTok = this.cur;
            this.advance();  /* consume 'this' */
            /* Must be followed by . or [ — otherwise it's just `this` as expression. */
            if (this.cur.kind !== TK.DOT && this.cur.kind !== TK.LBRACKET) {
                /* Not an assignment — roll back, parse as expression. */
                this.tokIdx = saveIdx; this.cur = saveTok;
                return this.parseBinary(-100);
            }
            /* Build chain — `this` is a synthetic base, emit OP_THIS. */
            let chain = [];
            let chainDepth = 0;
            let rollback = false;
            while (this.cur.kind === TK.DOT || this.cur.kind === TK.LBRACKET) {
                if (this.cur.kind === TK.DOT) {
                    this.advance();
                    if (this.cur.kind !== TK.IDENT) {
                        this.tokIdx = saveIdx; this.cur = saveTok;
                        rollback = true; break;
                    }
                    const a = this.atom(this.advance().sval);
                    chain.push({type:'prop', atom: a});
                    chainDepth++;
                } else {
                    const ist = this.tokIdx + 1;
                    this.advance();
                    let depth = 1;
                    while (depth > 0 && this.cur.kind !== TK.EOF) {
                        if (this.cur.kind === TK.LBRACKET) depth++;
                        else if (this.cur.kind === TK.RBRACKET) depth--;
                        if (depth > 0) this.advance();
                    }
                    if (this.cur.kind !== TK.RBRACKET) {
                        this.tokIdx = saveIdx; this.cur = saveTok;
                        break;
                    }
                    const iet = this.tokIdx;
                    this.advance();
                    chain.push({type:'index', tokStart: ist, tokEnd: iet});
                    chainDepth++;
                }
            }
            if (rollback) return this.parseBinary(-100);
            if (this.cur.kind !== TK.ASSIGN && this.cur.kind !== TK.PLUSEQ &&
                this.cur.kind !== TK.MINUSEQ && this.cur.kind !== TK.STAREQ &&
                this.cur.kind !== TK.SLASHEQ && this.cur.kind !== TK.PERCENTEQ) {
                this.tokIdx = saveIdx; this.cur = saveTok;
                return this.parseBinary(-100);
            }
            const opKind = this.cur.kind;
            this.advance();
            /* Emit OP_THIS as base. */
            this.emitByte(OP.THIS);
            const rhsTokIdx = this.tokIdx;
            /* Navigate all steps except the last. */
            for (let ci = 0; ci < chain.length - 1; ci++) {
                const step = chain[ci];
                if (step.type === 'prop') {
                    this.emitByte(OP.LOAD_PROP); this.emitByte(step.atom);
                } else {
                    this.tokIdx = step.tokStart;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.emitByte(OP.LOAD_INDEX);
                }
            }
            const last = chain[chain.length - 1];
            if (last.type === 'prop') {
                if (opKind === TK.ASSIGN) {
                    this.tokIdx = rhsTokIdx; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitByte(OP.STORE_PROP); this.emitByte(last.atom);
                } else {
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.LOAD_PROP); this.emitByte(last.atom);
                    this.tokIdx = rhsTokIdx; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitOpForCompound(opKind);
                    this.emitByte(OP.STORE_PROP); this.emitByte(last.atom);
                }
            } else {
                if (opKind === TK.ASSIGN) {
                    this.tokIdx = last.tokStart; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.tokIdx = rhsTokIdx; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitByte(OP.STORE_INDEX);
                } else {
                    const tempIdxSlot = this.localAdd('__compound_idx');
                    this.tokIdx = last.tokStart; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.emitByte(OP.STORE_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.POP);
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.LOAD_INDEX);
                    this.tokIdx = rhsTokIdx; this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitOpForCompound(opKind);
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.SWAP);
                    this.emitByte(OP.STORE_INDEX);
                }
            }
            return;
        }
        /* Lvalue check: IDENT [.prop | [idx]]* = rhs */
        if (this.cur.kind === TK.IDENT) {
            /* Save position. */
            const saveIdx = this.tokIdx;
            const saveTok = this.cur;
            /* Lookahead: parse IDENT, optional .prop/[idx], check for assign. */
            this.advance();
            let isLocal = false, slot = -1, atom = 0;
            const name = saveTok.sval;
            slot = this.localFind(name);
            if (slot >= 0) isLocal = true;
            else atom = this.atom(name);

            let chainDepth = 0, hasIndex = false;
            let propAtoms = [];
            let idxStartTok = -1, idxEndTok = -1;  /* for [idx] case */
            let rollback = false;
            /* T51-fix: unified chain — collect ALL steps in order so
             * mixed chains like `arr[0].score = 92` work correctly.
             * chain = [{type:'prop', atom}, {type:'index', tokStart, tokEnd}, ...]
             * The LAST step is the store target; all before are "navigate"
             * (LOAD_PROP / LOAD_INDEX). */
            let chain = [];
            while (this.cur.kind === TK.DOT || this.cur.kind === TK.LBRACKET) {
                if (this.cur.kind === TK.DOT) {
                    this.advance();
                    if (this.cur.kind !== TK.IDENT) {
                        this.tokIdx = saveIdx; this.cur = saveTok;
                        rollback = true; break;
                    }
                    const a = this.atom(this.advance().sval);
                    propAtoms.push(a);
                    chain.push({type:'prop', atom: a});
                    chainDepth++;
                } else {
                    /* T51-fix: removed the `if (chainDepth > 0) break`
                     * that prevented mixed chains like arr[0].prop[1].
                     * Now [idx] can appear anywhere in the chain. */
                    const ist = this.tokIdx + 1;
                    this.advance();  /* consume '[' */
                    let depth = 1;
                    while (depth > 0 && this.cur.kind !== TK.EOF) {
                        if (this.cur.kind === TK.LBRACKET) depth++;
                        else if (this.cur.kind === TK.RBRACKET) depth--;
                        if (depth > 0) this.advance();
                    }
                    if (this.cur.kind !== TK.RBRACKET) {
                        this.tokIdx = saveIdx; this.cur = saveTok;
                        break;
                    }
                    const iet = this.tokIdx;
                    this.advance();  /* consume ']' */
                    idxStartTok = ist; idxEndTok = iet;
                    hasIndex = true; chainDepth++;
                    chain.push({type:'index', tokStart: ist, tokEnd: iet});
                }
            }
            /* T51: if rollback was triggered (e.g. `obj.` not followed by IDENT),
             * parse as expression instead of assignment. */
            if (rollback) {
                return this.parseBinary(-100);
            }
            if (this.cur.kind !== TK.ASSIGN && this.cur.kind !== TK.PLUSEQ &&
                this.cur.kind !== TK.MINUSEQ && this.cur.kind !== TK.STAREQ &&
                this.cur.kind !== TK.SLASHEQ && this.cur.kind !== TK.PERCENTEQ) {
                /* Not an assignment — roll back and parse as expression. */
                this.tokIdx = saveIdx; this.cur = saveTok;
                return this.parseBinary(-100);
            }
            const opKind = this.cur.kind;
            this.advance();

            if (chainDepth === 0) {
                /* Simple lvalue: local or global. */
                if (isLocal && this.localFindConst(name)) {
                    this.err("assignment to constant '" + name + "'");
                }
                if (!isLocal && this.topLevelConsts && this.topLevelConsts[name]) {
                    this.err("assignment to constant '" + name + "'");
                }
                if (!isLocal && !this.knownGlobals.has(name) && !this.topLevelDecls.has(name)) {
                    this.err("undefined variable '" + name + "'");
                }
                this.parseExpr();  /* RHS */
                if (opKind === TK.ASSIGN) {
                    if (isLocal) { this.emitByte(OP.STORE_LOCAL); this.emitByte(slot); }
                    else         { this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom); }
                } else {
                    if (isLocal && this.localFindConst(name)) {
                        this.err("assignment to constant '" + name + "'");
                    }
                    if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                    else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                    this.emitOpForCompound(opKind);
                    if (isLocal) { this.emitByte(OP.STORE_LOCAL); this.emitByte(slot); }
                    else         { this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom); }
                }
                return;
            }
            /* T51-fix: Unified chain assignment — handles arbitrary
             * combinations of .prop and [idx], e.g.:
             *   obj.a.b = 20          → LOAD obj, LOAD_PROP a, parse 20, STORE_PROP b
             *   arr[0] = 99           → LOAD arr, parse 0, parse 99, STORE_INDEX
             *   arr[0].score = 92     → LOAD arr, parse 0, LOAD_INDEX, parse 92, STORE_PROP score
             *   obj.a[0] = 5          → LOAD obj, LOAD_PROP a, parse 0, parse 5, STORE_INDEX
             *   a.b.c.d[0].e = 1      → full chain navigation
             *
             * Strategy:
             *   1. LOAD base (global/local)
             *   2. For each step EXCEPT the last:
             *      - 'prop'  → LOAD_PROP atom   (navigate, leaves parent on stack)
             *      - 'index' → parse idx, LOAD_INDEX  (navigate, leaves element on stack)
             *   3. For the LAST step (store target):
             *      - 'prop'  → parse RHS, STORE_PROP atom
             *      - 'index' → parse idx, parse RHS, STORE_INDEX
             *
             * For compound (+= etc.):
             *   3. For the LAST step:
             *      - 'prop'  → DUP, LOAD_PROP atom, parse RHS, op, STORE_PROP atom
             *      - 'index' → (complex — uses temp local for idx) */
            if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
            else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
            const rhsTokIdx = this.tokIdx;
            /* Navigate all steps except the last */
            for (let ci = 0; ci < chain.length - 1; ci++) {
                const step = chain[ci];
                if (step.type === 'prop') {
                    this.emitByte(OP.LOAD_PROP); this.emitByte(step.atom);
                } else {
                    /* index: re-parse the idx expression from saved tokens */
                    this.tokIdx = step.tokStart;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.emitByte(OP.LOAD_INDEX);
                }
            }
            /* Last step = store target */
            const last = chain[chain.length - 1];
            if (last.type === 'prop') {
                if (opKind === TK.ASSIGN) {
                    this.tokIdx = rhsTokIdx;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();  /* RHS */
                    this.emitByte(OP.STORE_PROP); this.emitByte(last.atom);
                } else {
                    /* Compound: DUP, LOAD_PROP, parse RHS, op, STORE_PROP */
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.LOAD_PROP); this.emitByte(last.atom);
                    this.tokIdx = rhsTokIdx;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitOpForCompound(opKind);
                    this.emitByte(OP.STORE_PROP); this.emitByte(last.atom);
                }
            } else {
                /* index: the last step is [idx] */
                if (opKind === TK.ASSIGN) {
                    /* Simple: parse idx, parse RHS, STORE_INDEX */
                    this.tokIdx = last.tokStart;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.tokIdx = rhsTokIdx;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();  /* RHS */
                    this.emitByte(OP.STORE_INDEX);
                } else {
                    /* Compound: obj[idx] OP= rhs
                     *   parse idx → [parent, idx]
                     *   STORE temp_idx, POP → [parent]
                     *   LOAD parent (re-load via DUP before), LOAD temp, LOAD_INDEX → [parent, arr[idx]]
                     *   parse RHS → [parent, arr[idx], rhs]
                     *   op → [parent, result]
                     *   LOAD temp → [parent, result, idx]
                     *   SWAP → [parent, idx, result]
                     *   STORE_INDEX → [result]
                     * But we need to re-load parent.  Simplest: DUP before parsing idx. */
                    const tempIdxSlot = this.localAdd('__compound_idx');
                    this.tokIdx = last.tokStart;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();  /* idx */
                    this.expect(TK.RBRACKET, "']'");
                    /* [parent, idx] → store idx, pop → [parent] */
                    this.emitByte(OP.STORE_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.POP);
                    /* [parent] → DUP, LOAD temp, LOAD_INDEX → [parent, arr[idx]] */
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.LOAD_INDEX);
                    /* [parent, arr[idx]] → parse RHS → [parent, arr[idx], rhs] */
                    this.tokIdx = rhsTokIdx;
                    this.cur = this.tokens[this.tokIdx];
                    this.parseExpr();
                    this.emitOpForCompound(opKind);  /* [parent, result] */
                    /* [parent, result] → LOAD temp → [parent, result, idx] → SWAP → [parent, idx, result] */
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);
                    this.emitByte(OP.SWAP);
                    this.emitByte(OP.STORE_INDEX);
                }
            }
            return;
        }
        return this.parseBinary(-100);
    }

    emitOpForCompound(opKind) {
        const m = {
            [TK.PLUSEQ]: OP.ADD, [TK.MINUSEQ]: OP.SUB, [TK.STAREQ]: OP.MUL,
            [TK.SLASHEQ]: OP.DIV, [TK.PERCENTEQ]: OP.MOD,
            [TK.ANDEQ]: OP.AND, [TK.OREQ]: OP.OR, [TK.XOREQ]: OP.XOR,
            [TK.SHLEQ]: OP.SHL, [TK.SHREQ]: OP.SHR, [TK.USHREQ]: OP.USHR,
        };
        if (m[opKind] === undefined) this.err("unsupported compound op");
        this.emitByte(m[opKind]);
    }

    binopPrec(k) {
        switch (k) {
            case TK.STAR: case TK.SLASH: case TK.PERCENT: return 5;
            case TK.PLUS: case TK.MINUS: return 4;
            case TK.SHL: case TK.SHR: case TK.USHR: case TK.BAND: case TK.BOR: case TK.XOR: return 3;
            case TK.LT: case TK.LE: case TK.GT: case TK.GE: case TK.IN: case TK.INSTANCEOF: return 2;
            case TK.EQ: case TK.NE: case TK.STRICT_EQ: case TK.STRICT_NE: return 1;
            case TK.AMPAMP: return 0;
            case TK.PIPEPIPE: return -1;
            case TK.NULLISH: return -2;  /* ?? — lower than || */
            default: return -1000;
        }
    }

    emitBinop(k) {
        const m = {
            [TK.PLUS]: OP.ADD, [TK.MINUS]: OP.SUB, [TK.STAR]: OP.MUL,
            [TK.SLASH]: OP.DIV, [TK.PERCENT]: OP.MOD,
            [TK.SHL]: OP.SHL, [TK.SHR]: OP.SHR, [TK.USHR]: OP.USHR,
            [TK.BAND]: OP.AND, [TK.BOR]: OP.OR, [TK.XOR]: OP.XOR,
            [TK.LT]: OP.LT, [TK.LE]: OP.LE, [TK.GT]: OP.GT, [TK.GE]: OP.GE,
            [TK.EQ]: OP.EQ, [TK.NE]: OP.NE,
            [TK.STRICT_EQ]: OP.STRICT_EQ, [TK.STRICT_NE]: OP.STRICT_NE,
            [TK.INSTANCEOF]: OP.INSTANCEOF,
        };
        /* T51: Bug 5 — 'in' operator only valid in for...in, not in expressions. */
        if (k === TK.IN) this.err("'in' is only valid in for...in loops");
        if (m[k] === undefined) this.err("unsupported operator");
        this.emitByte(m[k]);
    }

    parseBinary(minPrec) {
        this.parseUnary();
        for (;;) {
            const k = this.cur.kind;
            if (k === TK.AMPAMP || k === TK.PIPEPIPE) {
                if (minPrec > -1) return;
                this.advance();
                /* T51: Short-circuit evaluation for && and ||. */
                this.emitByte(OP.DUP);
                this.emitByte(k === TK.AMPAMP ? OP.JZ : OP.JNZ);
                const jmp = this.emitPlaceholder();
                this.emitByte(OP.POP);
                this.parseBinary(minPrec);
                this.patchJump(jmp, this.bc.length);
                continue;
            }
            /* T51: Nullish coalescing ?? — short-circuits on null OR undefined. */
            if (k === TK.NULLISH) {
                if (minPrec > -2) return;
                this.advance();
                /* DUP a, UNDEF, STRICT_EQ, JNZ use_b,
                 * DUP a, NULL, STRICT_EQ, JNZ use_b,
                 * JMP end,
                 * use_b: POP, push b,
                 * end: */
                this.emitByte(OP.DUP);          /* [a, a] */
                this.emitByte(OP.UNDEF);        /* [a, a, undef] */
                this.emitByte(OP.STRICT_EQ);    /* [a, eq1] */
                this.emitByte(OP.JNZ);          /* if eq1, [a] → use_b */
                const jmp1 = this.emitPlaceholder();
                this.emitByte(OP.DUP);          /* [a, a] */
                this.emitByte(OP.NULL);         /* [a, a, null] */
                this.emitByte(OP.STRICT_EQ);    /* [a, eq2] */
                this.emitByte(OP.JNZ);          /* if eq2, [a] → use_b */
                const jmp2 = this.emitPlaceholder();
                this.emitByte(OP.JMP);          /* a is not null/undef → keep a */
                const jmpEnd = this.emitPlaceholder();
                this.patchJump(jmp1, this.bc.length);  /* use_b: */
                this.patchJump(jmp2, this.bc.length);
                this.emitByte(OP.POP);          /* remove a */
                this.parseBinary(minPrec);      /* push b */
                this.patchJump(jmpEnd, this.bc.length);  /* end: */
                continue;
            }
            const p = this.binopPrec(k);
            if (p === -1000 || p < minPrec) break;
            this.advance();
            this.parseBinary(p + 1);
            this.emitBinop(k);
        }
    }

    parseUnary() {
        switch (this.cur.kind) {
            case TK.MINUS: this.advance(); this.parseUnary(); this.emitByte(OP.NEG); return;
            case TK.PLUS: this.advance(); this.parseUnary(); this.emitByte(OP.TO_NUMBER); return;  /* JS-10-fix: +x = ToNumber(x) */
            case TK.LNOT: this.advance(); this.parseUnary(); this.emitByte(OP.LNOT); return;
            case TK.BNOT: this.advance(); this.parseUnary(); this.emitByte(OP.BNOT); return;
            case TK.INC: this.advance(); this.parseIncrement(true, true); return;  /* ++i */
            case TK.DEC: this.advance(); this.parseIncrement(true, false); return; /* --i */
            case TK.TYPEOF: {
                this.advance();
                /* JS-11-fix: set inTypeof so parsePrimary IDENT doesn't throw
                 * on undeclared variables (typeof someBuiltinThatIsntRegistered
                 * should return "undefined", not throw ReferenceError). */
                const savedInTypeof = this.inTypeof;
                this.inTypeof = true;
                this.parseUnary();
                this.inTypeof = savedInTypeof;
                this.emitByte(OP.TYPEOF);
                return;
            }
            case TK.VOID: this.advance(); this.parseUnary(); this.emitByte(OP.POP); this.emitByte(OP.UNDEF); return;
            /* T51: new Object() / new Array(n) — creates built-in types.
             * For Object/Array, emits OP_NEW_OBJECT/OP_NEW_ARRAY directly.
             * For other constructors, parses as normal function call. */
            case TK.NEW: {
                this.advance();  /* consume 'new' */
                if (this.cur.kind === TK.IDENT) {
                    const name = this.cur.sval;
                    /* Peek ahead to see if next is ( for args */
                    const nextIsParen = this.peek(1).kind === TK.LPAREN;
                    if (name === 'Object' && nextIsParen) {
                        this.advance();  /* consume Object */
                        this.advance();  /* consume ( */
                        /* Skip args (Object() takes no args) */
                        while (this.cur.kind !== TK.RPAREN) this.advance();
                        this.advance();  /* consume ) */
                        this.emitByte(OP.NEW_OBJECT);
                        return;
                    }
                    if (name === 'Array' && nextIsParen) {
                        this.advance();  /* consume Array */
                        this.advance();  /* consume ( */
                        /* Parse optional length arg */
                        if (this.cur.kind !== TK.RPAREN) {
                            this.parseExpr();
                            /* new Array(n) — create array of length n */
                            this.emitByte(OP.NEW_ARRAY); this.emitByte(1);
                        } else {
                            this.emitByte(OP.NEW_ARRAY); this.emitByte(0);
                        }
                        this.expect(TK.RPAREN, "')'");
                        return;
                    }
                }
                /* T51: General constructor call — new Constructor(args).
                 * Parse the constructor expression (IDENT only — don't
                 * let parsePostfix consume the args as a function call),
                 * then parse args and emit OP_NEW.  The VM creates a new
                 * object, sets __proto__ = Constructor.prototype, and
                 * calls the ctor. */
                this.parsePrimary();  /* leaves constructor on stack */
                if (this.cur.kind === TK.LPAREN) {
                    this.advance();
                    let argc = 0;
                    while (this.cur.kind !== TK.RPAREN && this.cur.kind !== TK.EOF) {
                        this.parseExpr();
                        argc++;
                        if (!this.accept(TK.COMMA)) break;
                    }
                    this.expect(TK.RPAREN, "')'");
                    this.emitByte(OP.NEW); this.emitByte(argc);
                } else {
                    /* new Constructor without args = new Constructor() */
                    this.emitByte(OP.NEW); this.emitByte(0);
                }
                return;
            }
            /* T51: Arrow function — (params) => expr  or  param => expr */
            case TK.LPAREN: {
                /* Try to parse as arrow function.  Save position to
                 * roll back if it turns out to be a parenthesized expr. */
                const saveIdx = this.tokIdx;
                const saveTok = this.cur;
                /* Try parsing parameter list: (ident, ident, ...) */
                this.advance();  /* consume '(' */
                let params = [];
                let isArrow = true;
                if (this.cur.kind !== TK.RPAREN) {
                    while (true) {
                        if (this.cur.kind !== TK.IDENT) { isArrow = false; break; }
                        params.push(this.cur.sval);
                        this.advance();
                        if (this.cur.kind === TK.COMMA) { this.advance(); continue; }
                        break;
                    }
                }
                if (isArrow && this.cur.kind === TK.RPAREN) {
                    this.advance();  /* consume ')' */
                    if (this.cur.kind === TK.ARROW) {
                        this.advance();  /* consume '=>' */
                        this.parseArrowFunction(params);
                        return;
                    }
                    isArrow = false;
                }
                /* Not an arrow function — roll back and parse as expression */
                this.tokIdx = saveIdx;
                this.cur = saveTok;
                return this.parsePostfix();
            }
            /* T51: Single-param arrow: x => expr (no parens needed) */
            case TK.IDENT: {
                if (this.peek(1).kind === TK.ARROW) {
                    const param = this.cur.sval;
                    this.advance();  /* consume ident */
                    this.advance();  /* consume '=>' */
                    this.parseArrowFunction([param]);
                    return;
                }
                return this.parsePostfix();
            }
            default: return this.parsePostfix();
        }
    }

    /* T51: Parse arrow function body and emit as a regular function.
     * Arrow functions are desugared to `function(params) { return body; }`.
     * `this` is NOT lexically bound (simplified for embedded use). */
    parseArrowFunction(params) {
        /* Create a function entry. */
        if (this.funcs.length >= 63) this.err("too many functions");
        const funcIdx = this.funcs.length;
        const savedBc = this.bc;
        const savedLocals = this.locals;
        const savedNlocals = this.nlocals;
        this.bc = this.body;
        this.locals = [];
        for (const p of params) this.localAdd(p);
        const funcEntry = {pc: this.bc.length, argc: params.length, nlocals: 0, bodySize: 0};
        this.funcs.push(funcEntry);
        /* Body: either { ... } block or single expression. */
        if (this.cur.kind === TK.LBRACE) {
            this.parseBlock();
            this.emitByte(OP.RET_UNDEF);
        } else {
            /* Expression body — implicit return. */
            this.parseExpr();
            this.emitByte(OP.RET);
        }
        funcEntry.nlocals = this.locals.length;
        funcEntry.bodySize = this.bc.length - funcEntry.pc;
        this.bc = savedBc;
        this.locals = savedLocals;
        this.nlocals = savedNlocals;
        /* Emit OP_FUNCTION to push the function object. */
        this.emitByte(OP.FUNCTION);
        this.emitByte(funcIdx);
    }

    /* T51: Parse template literal content and emit as string concat.
     * `Score: ${x}, Name: ${y}` → CONST "Score: ", LOAD x, ADD,
     * CONST ", Name: ", LOAD y, ADD.
     * Handles nested ${} by re-entering the expression parser. */
    parseTemplateLiteral(raw) {
        /* Split raw into segments: literal parts and ${...} expressions.
         * We scan for ${ and } to find expression boundaries. */
        let parts = [];
        let i = 0;
        while (i < raw.length) {
            if (raw[i] === '$' && raw[i+1] === '{') {
                /* Find matching } — simple scan (no nesting support). */
                let j = i + 2;
                let depth = 1;
                while (j < raw.length && depth > 0) {
                    if (raw[j] === '{') depth++;
                    else if (raw[j] === '}') depth--;
                    if (depth > 0) j++;
                }
                if (depth === 0) {
                    parts.push({type: 'expr', code: raw.substring(i + 2, j)});
                    i = j + 1;
                    continue;
                }
            }
            /* Literal text — accumulate until next ${ */
            let text = '';
            while (i < raw.length) {
                if (raw[i] === '$' && raw[i+1] === '{') break;
                text += raw[i];
                i++;
            }
            if (text.length > 0) parts.push({type: 'text', text});
        }
        /* Emit: push first part, then ADD each subsequent part. */
        if (parts.length === 0) {
            this.emitByte(OP.UNDEF);
            return;
        }
        let first = true;
        for (const part of parts) {
            if (part.type === 'text') {
                const idx = this.addConstString(part.text);
                this.emitByte(OP.CONST); this.emitByte(idx);
            } else {
                /* Parse the expression code.  We tokenize and parse
                 * it as a sub-expression by saving/restoring state. */
                const savedTokens = this.tokens;
                const savedTokIdx = this.tokIdx;
                const savedCur = this.cur;
                const subTokens = this.tokenize(part.code);
                this.tokens = subTokens;
                this.tokIdx = 0;
                this.cur = this.tokens[0];
                this.parseExpr();
                this.tokens = savedTokens;
                this.tokIdx = savedTokIdx;
                this.cur = savedCur;
            }
            if (!first) this.emitByte(OP.ADD);
            first = false;
        }
    }

    /* Parse `i++`, `i--`, `++i`, `--i` — the operand must be an lvalue
     * (IDENT, IDENT.prop, or IDENT[idx]).  Emits:
     *   prefix  ++i : LOAD i, INC, STORE i  (leaves new value)
     *   postfix i++ : LOAD i, DUP, INC, STORE i, SWAP, POP  (leaves old value)
     * For statement context the caller emits an extra POP to discard.
     *
     * T51: Now supports obj.prop++ and arr[i]++ via compound assignment
     * emulation.  For simple variables, uses efficient INC/DEC.
     * For property/index, uses LOAD + DUP/INC + STORE pattern. */
    parseIncrement(isPrefix, isInc) {
        if (this.cur.kind !== TK.IDENT) {
            this.err("++/-- requires an identifier operand");
        }
        const name = this.cur.sval;
        this.advance();  /* consume IDENT */

        /* T51: Check for property or index access after the IDENT.
         * obj.prop++ or arr[i]++ — handle via compound-assignment pattern. */
        if (this.cur.kind === TK.DOT || this.cur.kind === TK.LBRACKET) {
            /* We need to build the lvalue chain, then apply ++/--.
             * For prefix ++obj.prop:
             *   LOAD obj, DUP, LOAD_PROP → [obj, val]
             *   INC → [obj, newval]
             *   STORE_PROP → [newval]
             * For postfix obj.prop++:
             *   LOAD obj, DUP, LOAD_PROP → [obj, val]
             *   DUP → [obj, val, val]
             *   INC → [obj, val, newval]
             *   SWAP → [obj, newval, val]
             *   STORE_PROP → [val]  (store pops obj+newval, leaves newval... wait)
             * Actually STORE_PROP: [obj, val] → [val]. So:
             *   LOAD obj, DUP → [obj, obj]
             *   LOAD_PROP → [obj, val]
             *   For prefix: INC → [obj, newval], STORE_PROP → [newval]
             *   For postfix: DUP → [obj, val, val], INC → [obj, val, newval],
             *     need [obj, newval] for STORE_PROP, but we have [obj, val, newval]
             *     SWAP → [obj, newval, val], POP → [obj, newval], STORE_PROP → [newval]
             *     But we need to return OLD val, not newval.
             *     So: after STORE_PROP we have [newval], but need [oldval].
             *     Better: save old value before STORE.
             *   Postfix: LOAD obj, DUP, LOAD_PROP → [obj, val]
             *     DUP → [obj, val, val]
             *     INC → [obj, val, newval]
             *     SWAP → [obj, newval, val]
             *     STORE_PROP pops obj+newval, pushes newval → [val, newval]
             *     POP → [val]  (old value) ✓
             */

            /* Parse the .prop or [idx] chain.
             * T51: For postfix, the ++ / -- is AFTER the property/index,
             * so we parse the chain first, then consume ++ / -- at the end. */
            const slot = this.localFind(name);
            const isLocal = (slot >= 0);
            const atom = isLocal ? 0 : this.atom(name);

            if (this.cur.kind === TK.DOT) {
                this.advance();  /* consume . */
                if (this.cur.kind !== TK.IDENT) this.err("expected property name after '.'");
                const propAtom = this.atom(this.advance().sval);

                /* LOAD obj */
                if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                /* DUP, LOAD_PROP → [obj, val] */
                this.emitByte(OP.DUP);
                this.emitByte(OP.LOAD_PROP); this.emitByte(propAtom);

                /* Now consume ++ / -- for postfix */
                if (!isPrefix) {
                    if (this.cur.kind !== TK.INC && this.cur.kind !== TK.DEC)
                        this.err("expected ++ or --");
                    this.advance();
                }

                if (isPrefix) {
                    /* ++obj.prop: [obj, val] → INC → [obj, newval] → STORE_PROP → [newval] */
                    this.emitByte(isInc ? OP.INC : OP.DEC);
                    this.emitByte(OP.STORE_PROP); this.emitByte(propAtom);
                } else {
                    /* obj.prop++: [obj, val]
                     *   DUP → [obj, val, val]
                     *   INC → [obj, val, newval]
                     *   SWAP → [obj, newval, val]
                     *   STORE_PROP pops obj+newval, pushes newval → [val, newval]
                     *   POP → [val] (old value) ✓
                     * Wait — STORE_PROP takes TOP=val, sp[1]=newval.  It sets
                     * obj=newval.prop=val — WRONG!  We need TOP=newval, sp[1]=obj.
                     * So we need [obj, newval] on top, not [newval, val].
                     * Fix: save old val to temp, then STORE_PROP, then restore.
                     *   [obj, val] → STORE temp, POP → [obj]
                     *   LOAD obj, LOAD_PROP → [obj, val]  (redundant... )
                     * Better: [obj, val] → DUP → [obj, val, val]
                     *   SWAP → [val, obj, val]  -- no, SWAP swaps top 2 only.
                     * Simplest correct: use temp local for old value.
                     *   [obj, val] → STORE temp, POP → [obj]
                     *   LOAD obj, LOAD_PROP, INC → [obj, newval]  (re-read+inc)
                     *   STORE_PROP → [newval]
                     *   LOAD temp → [newval, oldval]
                     *   SWAP → [oldval, newval]
                     *   POP → [oldval] ✓
                     * But re-reading obj.prop is a side effect if prop is a getter.
                     * For microjs (no getters), this is fine. */
                    const tempSlot = this.localAdd('__inc_old');
                    this.emitByte(OP.STORE_LOCAL); this.emitByte(tempSlot);  /* [obj] */
                    this.emitByte(OP.POP);  /* [] */
                    /* Re-load obj, re-read prop, inc */
                    if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                    else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                    this.emitByte(OP.LOAD_PROP); this.emitByte(propAtom);  /* [val] */
                    this.emitByte(isInc ? OP.INC : OP.DEC);  /* [newval] */
                    /* Need [obj, newval] for STORE_PROP */
                    if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                    else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                    this.emitByte(OP.SWAP);  /* [newval, obj] → [obj, newval] */
                    this.emitByte(OP.STORE_PROP); this.emitByte(propAtom);  /* [newval] */
                    /* Now push old value, swap, pop to leave old value */
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempSlot);  /* [newval, oldval] */
                    this.emitByte(OP.SWAP);  /* [oldval, newval] */
                    this.emitByte(OP.POP);  /* [oldval] ✓ */
                }
            } else if (this.cur.kind === TK.LBRACKET) {
                /* JS-33-fix: arr[i]++ / arr[i]-- support.
                 * Bytecode pattern (re-evaluates arr; safe for simple identifiers):
                 *   Stack: [arr, idx]  (after parsing base + index)
                 *   STORE_LOCAL temp_idx, POP, POP -> []
                 *   Re-load arr -> [arr]
                 *   LOAD_LOCAL temp_idx -> [arr, idx]
                 *   LOAD_INDEX -> [oldval]
                 *   (prefix): INC/DEC -> [newval]
                 *   (postfix): STORE_LOCAL temp_old, POP -> []
                 *              LOAD_LOCAL temp_old, INC/DEC -> [newval]
                 *              STORE_LOCAL temp_new, POP -> []
                 *              LOAD_LOCAL temp_old stays for later
                 *   Common: STORE_LOCAL temp_new, POP -> []
                 *   Re-load arr -> [arr]
                 *   LOAD_LOCAL temp_idx -> [arr, idx]
                 *   LOAD_LOCAL temp_new -> [arr, idx, newval]
                 *   STORE_INDEX -> [newval]  (consumes arr+idx+val, pushes val)
                 *   (postfix): POP, LOAD_LOCAL temp_old -> [oldval]
                 */
                this.advance();  /* consume '[' */
                this.parseExpr();  /* parse idx */
                this.expect(TK.RBRACKET, "']'");
                /* Stack: [arr, idx] */
                const tempIdxSlot = this.localAdd('__inc_idx');
                this.emitByte(OP.STORE_LOCAL); this.emitByte(tempIdxSlot);  /* [arr] */
                this.emitByte(OP.POP);  /* [] */
                /* Re-load arr + idx, LOAD_INDEX */
                if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);  /* [arr, idx] */
                this.emitByte(OP.LOAD_INDEX);  /* [oldval] */
                /* Compute new value, save to temp */
                const tempOldSlot = this.localAdd('__inc_old');
                const tempNewSlot = this.localAdd('__inc_new');
                this.emitByte(OP.STORE_LOCAL); this.emitByte(tempOldSlot);  /* [oldval] (stores to local + leaves on stack) */
                this.emitByte(OP.POP);  /* [] */
                this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempOldSlot);  /* [oldval] */
                this.emitByte(isInc ? OP.INC : OP.DEC);  /* [newval] */
                this.emitByte(OP.STORE_LOCAL); this.emitByte(tempNewSlot);  /* [newval] */
                this.emitByte(OP.POP);  /* [] */
                /* Store back: arr[idx] = newval */
                if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
                else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
                this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempIdxSlot);
                this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempNewSlot);  /* [arr, idx, newval] */
                this.emitByte(OP.STORE_INDEX);  /* [newval] */
                /* For postfix, replace top with oldval */
                if (!isPrefix) {
                    this.emitByte(OP.POP);  /* [] */
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(tempOldSlot);  /* [oldval] */
                }
            }
            return;
        }

        /* Simple variable ++/-- (original code) */
        /* For postfix, the next token is ++ or -- (already determined
         * by the caller).  Consume it here.  For prefix, the ++ / --
         * was already consumed by parseUnary before calling us. */
        if (!isPrefix) {
            this.advance();  /* consume ++ or -- */
        }
        const slot = this.localFind(name);
        const isLocal = (slot >= 0);
        const atom = isLocal ? 0 : this.atom(name);

        /* T45: check const — error on ++/-- for constants. */
        if (isLocal && this.localFindConst(name)) {
            this.err("assignment to constant '" + name + "'");
        }
        /* T50: error on ++/-- for undeclared globals. */
        if (!isLocal && !this.knownGlobals.has(name) && !this.topLevelDecls.has(name)) {
            this.err("undefined variable '" + name + "'");
        }

        if (isPrefix) {
            /* ++i : load, inc, store (leaves new value) */
            if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
            else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
            this.emitByte(isInc ? OP.INC : OP.DEC);
            if (isLocal) { this.emitByte(OP.STORE_LOCAL); this.emitByte(slot); }
            else         { this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom); }
        } else {
            /* i++ : load, dup, inc, store, swap, pop (leaves old value) */
            if (isLocal) { this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot); }
            else         { this.emitByte(OP.LOAD_GLOBAL); this.emitByte(atom); }
            this.emitByte(OP.DUP);                       /* [old, old] */
            this.emitByte(isInc ? OP.INC : OP.DEC);      /* [old, new] */
            if (isLocal) { this.emitByte(OP.STORE_LOCAL); this.emitByte(slot); }
            else         { this.emitByte(OP.STORE_GLOBAL); this.emitByte(atom); }
            /* After STORE: [old, new] (store leaves value on stack) */
            this.emitByte(OP.SWAP);                       /* [new, old] */
            this.emitByte(OP.POP);                        /* [old] */
        }
    }

    parsePostfix() {
        /* T51: Postfix i++ / i-- / obj.prop++ / arr[i]++
         * Scan ahead from IDENT to see if the chain ends with ++ or --.
         * If so, delegate to parseIncrement which handles the lvalue. */
        if (this.cur.kind === TK.IDENT) {
            /* Try to find ++ / -- at the end of a property/index chain */
            let lookIdx = 1;
            let depth = 0;
            let foundIncDec = false;
            while (lookIdx < 20) {  /* limit lookahead to prevent infinite loops */
                const t = this.peek(lookIdx);
                if (!t) break;
                if (t.kind === TK.DOT) { lookIdx += 2; continue; }
                if (t.kind === TK.LBRACKET) {
                    /* Skip to matching ] */
                    lookIdx++;
                    depth = 1;
                    while (depth > 0 && lookIdx < 20) {
                        const tt = this.peek(lookIdx);
                        if (!tt) break;
                        if (tt.kind === TK.LBRACKET) depth++;
                        else if (tt.kind === TK.RBRACKET) depth--;
                        lookIdx++;
                    }
                    continue;
                }
                if (depth === 0 && (t.kind === TK.INC || t.kind === TK.DEC)) {
                    foundIncDec = true;
                    break;
                }
                break;
            }
            if (foundIncDec) {
                const isInc = (this.peek(lookIdx).kind === TK.INC);
                this.parseIncrement(false, isInc);
                return;
            }
            /* Simple IDENT++ case */
            if (this.peek(1).kind === TK.INC || this.peek(1).kind === TK.DEC) {
                const isInc = (this.peek(1).kind === TK.INC);
                this.parseIncrement(false, isInc);
                return;
            }
        }
        this.parsePrimary();
        /* T51: Track the last loaded global name for inline caching.
         * parsePrimary sets this.lastGlobalName when it emits LOAD_GLOBAL. */
        var lastObj = this.lastGlobalName || '';
        for (;;) {
            switch (this.cur.kind) {
                case TK.DOT: {
                    this.advance();
                    if (this.cur.kind !== TK.IDENT) this.err("expected property name after '.'");
                    const methodName = this.advance().sval;
                    /* T51: Combine object + method name for inline caching. */
                    const a = this.atom(methodName);
                    /* T51: If next token is '(', this is a method call. */
                    if (this.cur.kind === TK.LPAREN) {
                        /* T51: Inline caching for tft/i2c/spi methods.
                         * Check if objName.methodName is a known native. */
                        const nativeId = this.getNativeCallId(lastObj, methodName);
                        if (nativeId >= 0) {
                            /* Pop the tft object — OP_NATIVE_CALL doesn't need it. */
                            this.emitByte(OP.POP);
                            this.advance();  /* consume '(' */
                            let argc = 0;
                            while (this.cur.kind !== TK.RPAREN) {
                                this.parseExpr();
                                argc++;
                                if (!this.accept(TK.COMMA)) break;
                            }
                            this.expect(TK.RPAREN, "')'");
                            /* Encode: (argc << 4) | native_fn_id */
                            this.emitByte(OP.NATIVE_CALL);
                            this.emitByte((argc << 4) | nativeId);
                        } else {
                            /* Normal method call: DUP, LOAD_PROP, CALL_WITH_THIS */
                            this.emitByte(OP.DUP);
                            this.emitByte(OP.LOAD_PROP); this.emitByte(a);
                            this.advance();  /* consume '(' */
                            let argc = 0;
                            while (this.cur.kind !== TK.RPAREN) {
                                this.parseExpr();
                                argc++;
                                if (!this.accept(TK.COMMA)) break;
                            }
                            this.expect(TK.RPAREN, "')'");
                            this.emitByte(OP.CALL_WITH_THIS); this.emitByte(argc);
                        }
                    } else {
                        this.emitByte(OP.LOAD_PROP); this.emitByte(a);
                    }
                    continue;
                }
                case TK.LBRACKET: {
                    this.advance();
                    this.parseExpr();
                    this.expect(TK.RBRACKET, "']'");
                    this.emitByte(OP.LOAD_INDEX);
                    continue;
                }
                case TK.LPAREN: {
                    this.advance();
                    let argc = 0;
                    while (this.cur.kind !== TK.RPAREN) {
                        this.parseExpr();
                        argc++;
                        if (!this.accept(TK.COMMA)) break;
                    }
                    this.expect(TK.RPAREN, "')'");
                    this.emitByte(OP.CALL); this.emitByte(argc);
                    continue;
                }
                /* T51: Optional chaining ?. — like . but returns undefined
                 * if obj is null/undefined instead of throwing. */
                case TK.OPTCHAIN: {
                    this.advance();
                    if (this.cur.kind !== TK.IDENT) this.err("expected property name after '?.'");
                    const a = this.atom(this.advance().sval);
                    /* DUP obj, DUP, UNDEF, STRICT_EQ, JNZ skip, POP, LOAD_PROP, JMP end, skip: POP, UNDEF, end: */
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.DUP);
                    this.emitByte(OP.UNDEF);
                    this.emitByte(OP.STRICT_EQ);
                    this.emitByte(OP.JNZ);
                    const skipProp = this.emitPlaceholder();
                    this.emitByte(OP.POP);  /* remove the DUP'd obj for STRICT_EQ */
                    this.emitByte(OP.LOAD_PROP); this.emitByte(a);
                    this.emitByte(OP.JMP);
                    const endOpt = this.emitPlaceholder();
                    this.patchJump(skipProp, this.bc.length);
                    this.emitByte(OP.POP);  /* remove the extra DUP */
                    this.patchJump(endOpt, this.bc.length);
                    continue;
                }
                default: return;
            }
        }
    }

    parsePrimary() {
        const t = this.cur;
        switch (t.kind) {
            case TK.INT: {
                if (t.isFloat) {
                    /* Fractional number — store as const (fixed24.8 value) */
                    const idx = this.addConstNum(t.fval);
                    this.advance();
                    this.emitByte(OP.CONST); this.emitByte(idx);
                } else {
                    /* Integer — emit INT8/INT16/INT24 (VM shifts to fixed24.8) */
                    const v = t.ival;
                    this.advance();
                    this.emitInt(v);
                }
                return;
            }
            case TK.STRING: {
                const idx = this.addConstString(t.sval);
                this.advance();
                this.emitByte(OP.CONST); this.emitByte(idx);
                return;
            }
            /* T51: Template literal `...${expr}...` — compiled to
             * string concatenation chain using OP.ADD.
             * `Score: ${x}` → CONST "Score: ", LOAD x, ADD. */
            case TK.TEMPLATE: {
                this.advance();
                this.parseTemplateLiteral(t.sval);
                return;
            }
            case TK.TRUE: this.advance(); this.emitByte(OP.TRUE); return;
            case TK.FALSE: this.advance(); this.emitByte(OP.FALSE); return;
            case TK.NULL: this.advance(); this.emitByte(OP.NULL); return;
            case TK.UNDEFINED: this.advance(); this.emitByte(OP.UNDEF); return;
            case TK.THIS: this.advance(); this.emitByte(OP.THIS); return;
            case TK.IDENT: {
                const name = t.sval;
                const a = this.atom(name);
                this.advance();
                const slot = this.localFind(name);
                if (slot >= 0) {
                    this.emitByte(OP.LOAD_LOCAL); this.emitByte(slot);
                } else {
                    /* T50: Check for undefined variables — throw a
                     * compile-time error instead of silently returning
                     * undefined at runtime.  Matches JS ReferenceError.
                     * JS-11-fix: typeof undeclared_var is the ONLY case
                     * where JS allows referencing an undeclared binding.
                     * The compiler tracks `inTypeof` flag (set by parseUnary
                     * when it consumes `typeof`); when true, don't throw. */
                    if (!this.knownGlobals.has(name) && !this.topLevelDecls.has(name)) {
                        if (this.inTypeof) {
                            /* typeof undeclared_var — emit UNDEF, OP_TYPEOF
                             * will convert it to "undefined" string. */
                            this.emitByte(OP.UNDEF);
                            this.lastGlobalName = null;
                            return;
                        }
                        this.err("undefined variable '" + name + "'");
                    }
                    this.emitByte(OP.LOAD_GLOBAL); this.emitByte(a);
                    this.lastGlobalName = name;  /* T51: track for inline caching */
                }
                this.lastGlobalName = null;  /* not a global — reset */
                return;
            }
            case TK.LPAREN: {
                this.advance();
                this.parseExpr();
                this.expect(TK.RPAREN, "')'");
                return;
            }
            case TK.LBRACKET: {
                this.advance();
                /* T51: Compact array optimization.
                 * Scan ahead to see if ALL elements are pure integer
                 * literals (no expressions, no nested arrays).  If so,
                 * emit OP_NEW_ARRAY_U8 or OP_NEW_ARRAY_U16 instead of
                 * pushing each value with INT8 + NEW_ARRAY.
                 * This saves ~50% bytecode for integer arrays.
                 *
                 * [1,2,3] → OLD: INT8 1, INT8 2, INT8 3, NEW_ARRAY 3 (8 bytes)
                 *           NEW: NEW_ARRAY_U8 3, 1, 2, 3 (5 bytes) */
                let peekIdx = 0;
                let allInts = true;
                let intVals = [];
                let peekCount = 0;
                while (true) {
                    const t = this.peek(peekIdx);
                    if (!t || t.kind === TK.RBRACKET) break;
                    if (t.kind === TK.COMMA) { peekIdx++; continue; }
                    /* Must be an integer literal (not float, not expression). */
                    if (t.kind !== TK.INT || t.isFloat) { allInts = false; break; }
                    /* Check next token is comma or ] (no trailing expression). */
                    const next = this.peek(peekIdx + 1);
                    if (!next || (next.kind !== TK.COMMA && next.kind !== TK.RBRACKET)) {
                        allInts = false; break;
                    }
                    intVals.push(t.ival);
                    peekCount++;
                    peekIdx++;
                }
                if (allInts && peekCount > 0 && peekCount <= 255) {
                    /* Check if all values fit in u8 or u16. */
                    let allU8 = true, allU16 = true;
                    for (const v of intVals) {
                        if (v < 0 || v > 255) allU8 = false;
                        if (v < 0 || v > 65535) allU16 = false;
                    }
                    if (allU8 || allU16) {
                        /* Consume all tokens: INT, COMMA, INT, COMMA, ..., INT
                         * That's peekCount INTs + (peekCount-1) COMMA = peekCount*2 - 1 */
                        const totalToSkip = peekCount * 2 - 1;
                        for (let i = 0; i < totalToSkip; i++) this.advance();
                        this.expect(TK.RBRACKET, "']'");
                        if (allU8) {
                            this.emitByte(OP.NEW_ARRAY_U8);
                            this.emitByte(peekCount);
                            for (const v of intVals) this.emitByte(v & 0xFF);
                        } else {
                            this.emitByte(OP.NEW_ARRAY_U16);
                            this.emitByte(peekCount);
                            for (const v of intVals) {
                                this.emitByte(v & 0xFF);
                                this.emitByte((v >> 8) & 0xFF);
                            }
                        }
                        return;
                    }
                }
                /* T51-fix: If peekCount > 255, the compact path can't be used
                 * (count is a single byte).  Fall through to normal path.
                 * The normal path re-parses from this.cur, which is still
                 * at the first element (we only peeked, didn't advance).
                 * This correctly handles arrays with 256+ elements. */
                {
                    /* Normal path: parse each element as expression. */
                    let count = 0;
                    while (this.cur.kind !== TK.RBRACKET) {
                        this.parseExpr();
                        count++;
                        if (!this.accept(TK.COMMA)) break;
                    }
                    this.expect(TK.RBRACKET, "']'");
                    /* T51-fix: OP_NEW_ARRAY uses a single byte for count.
                     * For arrays > 255 elements, use OP_NEW_ARRAY16 which
                     * reads a 2-byte count (little-endian). */
                    if (count > 255) {
                        this.emitByte(OP.NEW_ARRAY16);
                        this.emitByte(count & 0xFF);
                        this.emitByte((count >> 8) & 0xFF);
                    } else {
                        this.emitByte(OP.NEW_ARRAY); this.emitByte(count);
                    }
                }
                return;
            }
            case TK.LBRACE: {
                this.advance();
                this.emitByte(OP.NEW_OBJECT);
                while (this.cur.kind !== TK.RBRACE) {
                    if (this.cur.kind !== TK.IDENT && this.cur.kind !== TK.STRING &&
                        this.cur.kind !== TK.INT) {
                        this.err("expected property name");
                    }
                    /* T51: Support get/set in object literals:
                     *   { get prop() { ... }, set prop(v) { ... } } */
                    if (this.cur.kind === TK.IDENT &&
                        (this.cur.sval === 'get' || this.cur.sval === 'set') &&
                        this.peek(1).kind === TK.IDENT) {
                        const isGetter = (this.cur.sval === 'get');
                        this.advance();  /* consume get/set */
                        const propName = this.cur.sval;
                        const propAtom = this.atom(propName);
                        this.advance();  /* consume property name */
                        /* Parse function (params + body) */
                        this.expect(TK.LPAREN, "'('");
                        let params = [];
                        while (this.cur.kind !== TK.RPAREN) {
                            if (this.cur.kind !== TK.IDENT) this.err("expected parameter");
                            params.push(this.cur.sval);
                            this.advance();
                            if (!this.accept(TK.COMMA)) break;
                        }
                        this.expect(TK.RPAREN, "')'");
                        /* Parse function body into this.body */
                        const savedBc = this.bc;
                        const savedLocals = this.locals;
                        const savedNlocals = this.nlocals;
                        this.bc = this.body;
                        this.locals = [];
                        for (const p of params) this.localAdd(p);
                        const funcEntry = {pc: this.bc.length, argc: params.length,
                                           nlocals: 0, bodySize: 0};
                        if (this.funcs.length >= 63) this.err("too many functions");
                        this.funcs.push(funcEntry);
                        this.parseBlock();
                        this.emitByte(OP.RET_UNDEF);
                        funcEntry.nlocals = this.locals.length;
                        funcEntry.bodySize = this.bc.length - funcEntry.pc;
                        this.bc = savedBc;
                        this.locals = savedLocals;
                        this.nlocals = savedNlocals;
                        /* Emit: FUNCTION idx → [obj, fn]
                         * then OP_DEFINE_ACCESSOR atom is_get → [obj] */
                        const funcIdx = this.funcs.length - 1;
                        this.emitByte(OP.FUNCTION); this.emitByte(funcIdx);
                        this.emitByte(OP.DEFINE_ACCESSOR);
                        this.emitByte(propAtom);
                        this.emitByte(isGetter ? 1 : 0);
                    } else {
                        /* T51: Support numeric keys in object literals:
                         *   { 0: value, 45: value } — convert number to string atom. */
                        let keyStr;
                        if (this.cur.kind === TK.INT) {
                            keyStr = String(this.cur.ival);
                        } else {
                            keyStr = this.cur.sval;
                        }
                        const ka = this.atom(keyStr);
                        this.advance();
                        this.expect(TK.COLON, "':'");
                        this.emitByte(OP.DUP);
                        this.parseExpr();
                        this.emitByte(OP.STORE_PROP); this.emitByte(ka);
                        this.emitByte(OP.POP);
                    }
                    if (!this.accept(TK.COMMA)) break;
                }
                this.expect(TK.RBRACE, "'}'");
                return;
            }
            case TK.FUNCTION: {
                this.advance();
                let name = null;
                if (this.cur.kind === TK.IDENT) name = this.advance().sval;
                this.parseFunction(name);
                return;
            }
            default:
                this.err("unexpected token in expression");
        }
    }

    /* ---------- Serialization ---------- */

    /* Encode fixed24.8 as 4 bytes LE with INT tag (matches MJS_MAKE_INT). */
    encodeFixed(v) {
        const u = ((v & 0x3FFFFFFF) << 2) | 1;
        return [u & 0xFF, (u >> 8) & 0xFF, (u >> 16) & 0xFF, (u >> 24) & 0xFF];
    }

    /* T50: Encode a JS string as CP1251 (single-byte Windows-1251).
     * The device font (espboy_font_a.h) is CP1251-mapped: Cyrillic
     * А-Я at 0xC0-0xDF, а-я at 0xE0-0xFF, Ё at 0xA8, ё at 0xB8.
     * Single-byte encoding means .length returns the character count
     * (not byte count), charAt(i) works by index, and strings are
     * half the size of UTF-8 for Cyrillic text.
     * Characters outside CP1251 range fall back to '?' (0x3F). */
    cp1251Encode(s) {
        const bytes = [];
        for (let i = 0; i < s.length; i++) {
            let c = s.charCodeAt(i);
            if (c < 0x80) {
                /* ASCII — same in CP1251 */
                bytes.push(c);
            } else if (c >= 0x0410 && c <= 0x044F) {
                /* Cyrillic А-Яа-я: U+0410→0xC0, U+044F→0xFF */
                bytes.push(c - 0x350);
            } else if (c === 0x0401) {
                /* Ё → 0xA8 */
                bytes.push(0xA8);
            } else if (c === 0x0451) {
                /* ё → 0xB8 */
                bytes.push(0xB8);
            } else if (c >= 0xA0 && c <= 0xFF) {
                /* CP1251 extended Latin/symbols (0xA0-0xFF mostly match) */
                bytes.push(c);
            } else {
                /* Character not representable in CP1251 — replace with '?' */
                bytes.push(0x3F);
            }
        }
        return bytes;
    }

    /* Build the MJSB bytecode blob. */
    serialize() {
        /* Compute body offset: top-level bc comes first, then body.
         * Funcs[].pc are currently offsets into the body region —
         * we need to convert them to absolute offsets in the final
         * bytecode by adding the top-level size. */
        const topLevelSize = this.bc.length;
        const bodyOffset = topLevelSize;
        for (const f of this.funcs) {
            f.pcAbsolute = bodyOffset + f.pc;
        }
        /* Concatenated bytecode: top-level + body. */
        const allBc = this.bc.concat(this.body);

        /* Build the blob. */
        const parts = [];
        /* Header. */
        parts.push([0x4D, 0x4A, 0x53, 0x42]);  /* "MJSB" */
        parts.push([1]);  /* version */
        parts.push([0]);  /* flags */
        /* Atom count + atoms. */
        const atomCount = this.atoms.length;
        parts.push([atomCount & 0xFF, (atomCount >> 8) & 0xFF]);
        for (const s of this.atoms) {
            const bytes = this.cp1251Encode(s);  /* T50: CP1251 single-byte Cyrillic */
            const len = bytes.length;
            parts.push([len & 0xFF, (len >> 8) & 0xFF]);
            parts.push(bytes);
            parts.push([0]);  /* NUL terminator */
        }
        /* Const count + consts. */
        const constCount = this.consts.length;
        parts.push([constCount & 0xFF, (constCount >> 8) & 0xFF]);
        for (const c of this.consts) {
            if (c.type === 0) {
                parts.push([0]);  /* int30 */
                parts.push(this.encodeFixed(c.value));
            } else {
                parts.push([1]);  /* string */
                const bytes = this.cp1251Encode(c.value);  /* T50: CP1251 single-byte Cyrillic */
                const len = bytes.length;
                parts.push([len & 0xFF, (len >> 8) & 0xFF]);
                parts.push(bytes);
                parts.push([0]);
            }
        }
        /* Func count + funcs. */
        const funcCount = this.funcs.length;
        parts.push([funcCount & 0xFF, (funcCount >> 8) & 0xFF]);
        for (const f of this.funcs) {
            parts.push([f.argc, f.nlocals,
                f.pcAbsolute & 0xFF, (f.pcAbsolute >> 8) & 0xFF,
                f.bodySize & 0xFF, (f.bodySize >> 8) & 0xFF]);
        }
        /* Bytecode. */
        parts.push(allBc);

        /* Flatten. */
        let total = 0;
        for (const p of parts) total += p.length;
        const out = new Uint8Array(total);
        let off = 0;
        for (const p of parts) {
            out.set(p, off);
            off += p.length;
        }
        return out;
    }

    /* ---------- Public entry point ---------- */
    /* T51: Optimize bytecode — runs after parse, before serialize.
     * Currently implements:
     *   - NOP elimination with jump target re-patching
     *
     * Constant folding is intentionally NOT enabled because it changes
     * bytecode size, which shifts jump targets.  A safe implementation
     * would need to track all jump sources and re-patch them after
     * size changes — complex and error-prone for the small gain
     * (~5% bytecode reduction).  NOP elimination alone saves ~2-5%.
     *
     * The optimizer works on this.bc (top-level) and this.body separately.
     * Jump targets are re-patched using a pc-remap table. */
    optimize() {
        const optimizeRegion = (bc) => {
            if (bc.length === 0) return;
            /* Pass: NOP elimination with jump re-patching.
             * 1. Build a map: old_pc → new_pc by scanning and skipping NOPs.
             * 2. Build new bytecode, copying non-NOP bytes.
             * 3. Re-patch all JMP/JZ/JNZ targets using the map. */
            const opHasU8Arg = (op) => op === OP.INT8 || op === OP.LOAD_LOCAL ||
                op === OP.STORE_LOCAL || op === OP.LOAD_GLOBAL || op === OP.STORE_GLOBAL ||
                op === OP.LOAD_PROP || op === OP.STORE_PROP || op === OP.NEW_ARRAY ||
                op === OP.CALL || op === OP.FUNCTION || op === OP.CONST ||
                op === OP.NEW || op === OP.CALL_WITH_THIS || op === OP.DEFINE_ACCESSOR ||
                op === OP.NATIVE_CALL;
            const opIsJump = (op) => op === OP.JMP || op === OP.JZ || op === OP.JNZ || op === OP.PUSH_TRY;
            /* T51: Variable-length opcodes (compact arrays) — need special
             * handling in optimizer.  Count byte determines total size. */
            const opIsVarLen = (op) => op === OP.NEW_ARRAY_U8 || op === OP.NEW_ARRAY_U16;
            const varLenSize = (bc, i) => {
                const count = bc[i + 1];
                if (bc[i] === OP.NEW_ARRAY_U8) return 2 + count;
                if (bc[i] === OP.NEW_ARRAY_U16) return 2 + count * 2;
                return 2;
            };

            /* Step 1: build old→new pc map. */
            const pcMap = new Array(bc.length + 1);
            let newPc = 0;
            let i = 0;
            while (i < bc.length) {
                const op = bc[i];
                pcMap[i] = newPc;
                if (op === OP.NOP) {
                    i++;
                } else if (opIsVarLen(op)) {
                    const sz = varLenSize(bc, i);
                    newPc += sz; i += sz;
                } else if (opIsJump(op)) {
                    newPc += 3; i += 3;
                } else if (opHasU8Arg(op)) {
                    newPc += 2; i += 2;
                } else if (op === OP.INT16) {
                    newPc += 3; i += 3;
                } else if (op === OP.INT24) {
                    newPc += 4; i += 4;
                } else {
                    newPc += 1; i += 1;
                }
            }
            pcMap[bc.length] = newPc;

            /* Step 2: build new bytecode with re-patched jumps. */
            const out = [];
            i = 0;
            while (i < bc.length) {
                const op = bc[i];
                if (op === OP.NOP) {
                    i++;
                    continue;
                }
                if (opIsVarLen(op)) {
                    const sz = varLenSize(bc, i);
                    for (let j = 0; j < sz; j++) out.push(bc[i + j]);
                    i += sz;
                } else if (opIsJump(op)) {
                    /* Jump target = old_pc + 3 + offset (signed 16-bit). */
                    const off = bc[i+1] | (bc[i+2] << 8);
                    const signed = off > 32767 ? off - 65536 : off;
                    const oldTarget = i + 3 + signed;
                    const newTarget = pcMap[oldTarget] !== undefined ? pcMap[oldTarget] : newPc;
                    const newOff = newTarget - (out.length + 3);
                    out.push(op, newOff & 0xFF, (newOff >> 8) & 0xFF);
                    i += 3;
                } else if (opHasU8Arg(op)) {
                    out.push(bc[i], bc[i+1]);
                    i += 2;
                } else if (op === OP.INT16) {
                    out.push(bc[i], bc[i+1], bc[i+2]);
                    i += 3;
                } else if (op === OP.INT24) {
                    out.push(bc[i], bc[i+1], bc[i+2], bc[i+3]);
                    i += 4;
                } else {
                    out.push(bc[i]);
                    i++;
                }
            }
            /* Replace bc with optimized output. */
            bc.length = 0;
            for (const b of out) bc.push(b);

            /* Also update lineMap (pc→line) for top-level bytecode. */
            if (bc === this.bc && this.lineMap.length > 0) {
                for (const e of this.lineMap) {
                    e.pc = pcMap[e.pc] !== undefined ? pcMap[e.pc] : e.pc;
                }
            }
        };

        optimizeRegion(this.bc);
        optimizeRegion(this.body);

        /* Recompute func pcAbsolute (body offset may have changed). */
        const topLevelSize = this.bc.length;
        for (const f of this.funcs) {
            f.pcAbsolute = topLevelSize + f.pc;
        }
    }

    compile(source) {
        try {
            this.parse(source);
            this.optimize();  /* T51: NOP elimination with jump re-patching */
            const bc = this.serialize();
            return { bytecode: bc, atoms: this.atoms.length,
                     consts: this.consts.length, funcs: this.funcs.length,
                     bcSize: this.bc.length, bodySize: this.body.length,
                     lineMap: this.lineMap };  /* T49: pc→line for runtime errors */
        } catch (e) {
            if (e instanceof CompileError) {
                return { error: e.message, line: e.line, col: e.col,
                         token: e.token, src_line: e.src_line };
            }
            return { error: 'internal: ' + e.message, line: 0, col: 0,
                     token: '', src_line: '' };
        }
    }
}

/* Export for both Node.js and browser. */
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MicroJSCompiler, OP, TK, CompileError };
}
if (typeof window !== 'undefined') {
    window.MicroJSCompiler = MicroJSCompiler;
    window.MJS_OP = OP;
    window.MJS_TK = TK;
}
