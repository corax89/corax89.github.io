/*
 * ============================================================================
 *  QuickJS-ESPboy T26 — microjs (browser-compiled bytecode VM)
 * ============================================================================
 *
 *  T26 ARCHITECTURE — compiler/VM split:
 *    - Browser compiles JS source → MJSB bytecode (via /compiler.js).
 *    - Device receives bytecode via POST /run, executes with microjs_vm.h.
 *    - No lexer, no parser, no AST on the device → huge RAM/ROM savings.
 *    - Serial REPL removed (compiler is in the browser now).
 *
 *  Files required in the sketch folder:
 *    microjs_vm.h         — bytecode VM (this file includes it)
 *    microjs_webui.h      — HTML for / endpoint
 *    microjs_compiler.js  — JS compiler, served at /compiler.js
 *    espboy_display.h     — 64×64 framebuffer + PROGMEM palette
 *    espboy_font_a.h      — 5×7 font (CP1251 + Russian)
 *
 *  Old T1-T25 files (mquickjs, espboy_stdlib.*, quickjs_esp.h, libm.c,
 *  dtoa.c, etc) are NO LONGER NEEDED — keep them out of the build folder
 *  to avoid linker conflicts.
 *
 *  JS API (subset of T25 — extend as needed):
 *    print(...), millis(), delay(ms), mem(), gc() [stub], keys(),
 *    backlight(v), rand()
 *    tft.cls(), tft.fill(c), tft.pixel(x,y,c), tft.rect(x,y,w,h,c),
 *    tft.fillRect(x,y,w,h,c), tft.line(x0,y0,x1,y1,c),
 *    tft.circle(cx,cy,r,c), tft.disc(cx,cy,r,c),
 *    tft.text(x,y,str,c,size), tft.width(), tft.height(),
 *    tft.getpixel(x,y), tft.flip()
 *
 *  Build:
 *    Board: Generic ESP8266 / NodeMCU 1.0
 *    Flash: 4MB (FS:2MB OTA:~1MB)
 *    No special build flags needed (no softfloat — int30 only).
 *
 *  HTTP API:
 *    GET  /              — HTML page (loads /compiler.js)
 *    GET  /compiler.js   — microjs_compiler.js (browser-side compiler)
 *    POST /run           — body is MJSB bytecode, response is JSON
 *    POST /save          — body is JSON {source, bytecode[]}, saves both
 *    GET  /load          — returns JSON {source, bytecode_count}
 *    POST /clear         — deletes saved boot files
 *    GET  /mem           — JSON with free_heap, etc.
 * ============================================================================
 */

/* ====================================================================
 * T51: Forward-declare MJSValue and MJSContext at the VERY TOP of the
 * .ino, before any other #include.  Arduino IDE's auto-prototype
 * generator scans the .ino for function definitions and emits
 * prototypes into a generated header it #includes near the top of the
 * preprocessed .cpp.  If those prototypes use MJSValue but the typedef
 * hasn't been seen yet (because microjs_vm.h is included further down),
 * the compile fails with "'MJSValue' does not name a type".  By
 * forward-typedef'ing at line 1, the typedef is always in scope before
 * any auto-generated prototype, regardless of where the IDE splices it.
 * (On 32-bit ESP8266/ESP32 this matches the typedef in microjs_vm.h,
 *  which uses the same uint32_t — no conflict under C++11 rules.)
 * ==================================================================== */
#include <stdint.h>
#include <stddef.h>
#if !defined(__x86_64__) && !defined(__aarch64__) && !defined(__LP64__) && !defined(_LP64)
typedef uint32_t MJSValue;
typedef struct MJSContext MJSContext;
#endif

#include <Arduino.h>
#include <math.h>

/* ============================================================
 * PLATFORM: ESP8266 or ESP32
 * ------------------------------------------------------------
 * ESP8266 uses LittleFS (built into the core).
 * ESP32 core 1.0.4 ships SPIFFS.h with the core libraries.
 * SPIFFS.h is preferred over FFat.h because:
 *   - SPIFFS has both totalBytes() and usedBytes() (FFat in 1.0.4
 *     is missing usedBytes()).
 *   - SPIFFS works with the DEFAULT partition table — no need to
 *     switch to a custom partition scheme with an "ffat" entry.
 *   - SPIFFS.h's API matches LittleFS for the basic ops
 *     (exists/open/remove) and uses the same File-readdir pattern
 *     as FFat for directory iteration.
 * ------------------------------------------------------------
 * FS API differences between LittleFS (ESP8266) and SPIFFS (ESP32):
 *   - openDir() exists only on ESP8266.  SPIFFS uses
 *       File root = SPIFFS.open("/"); entry = root.openNextFile();
 *     handled by fs_list_root_files() below.
 *   - info(FSInfo&) is ESP8266-only.  SPIFFS exposes totalBytes()
 *     and usedBytes() directly, wrapped by fs_total_bytes() /
 *     fs_used_bytes() below.
 *   - begin() / format() exist on both with compatible signatures;
 *     wrapped in setup() with #if defined.
 *   - exists(path), open(path, mode), remove(path) work identically
 *     on both — we just alias `LittleFS` to `SPIFFS` on ESP32 so the
 *     existing call sites compile unchanged.
 * ============================================================ */
#if defined(ESP8266)
  /* ---- ESP8266 ---- */
  #include <ESP8266WiFi.h>
  #include <WiFiClient.h>
  #include <ESP8266WebServer.h>
  #include <Wire.h>
  #include <SPI.h>
  #include <LittleFS.h>
  #define WEB_SERVER_TYPE ESP8266WebServer
  #define FS_FILE File
  #define yield_ yield
  /* ESP8266 has a real ESP.getChipId(). */
  #define ESP_CHIP_ID()  ((uint32_t)ESP.getChipId())
#elif defined(ESP32)
  /* ---- ESP32 ---- */
  #include <WiFi.h>
  #include <WiFiClient.h>
  #include <WiFiClientSecure.h>
  #include <WebServer.h>
  #include <Wire.h>
  #include <SPI.h>
  #include <SPIFFS.h>
  #define WEB_SERVER_TYPE WebServer
  #define FS_FILE File
  #define yield_ yield
  /* ESP32 core 1.0.4 has no LittleFS.h — alias SPIFFS as LittleFS so all
   * existing `LittleFS.exists/open/remove` call sites compile. */
  #define LittleFS SPIFFS
  /* ESP32 has no ESP.getChipId() — use the factory-burned MAC. */
  #define ESP_CHIP_ID()  ((uint32_t)ESP.getEfuseMac())
#endif

/* ====================================================================
 * T51: Cross-platform filesystem helpers.
 * Hides the ESP8266 LittleFS Dir-iterator vs ESP32 SPIFFS File-readdir
 * difference behind one shared helper.  Returns the names WITHOUT a
 * leading "/" so JS code can pass them directly to files.load() etc.
 * ==================================================================== */
struct DirEntry {
    String name;
    size_t size;
};

static int fs_list_root_files(DirEntry *out, int max_count) {
    int count = 0;
    if (!out || max_count <= 0) return 0;
#if defined(ESP8266)
    Dir d = LittleFS.openDir("/");
    while (d.next() && count < max_count) {
        String nm = d.fileName();
        /* ESP8266 LittleFS openDir("/") returns names like "file.js"
         * (no leading slash) — keep as-is. */
        out[count].name  = nm;
        out[count].size  = d.fileSize();
        count++;
    }
#elif defined(ESP32)
    /* T51: ESP32 SPIFFS directory iteration.  SPIFFS doesn't have real
     * directories — SPIFFS.open("/") returns a virtual root File that
     * supports openNextFile() for iterating all files. */
    File root = SPIFFS.open("/");
    if (!root) {
        Serial.println(F("[fs] SPIFFS.open(\"/\") FAILED"));
        return 0;
    }
    Serial.printf_P(PSTR("[fs] root opened: isDir=%d\n"),
                    (int)(root.isDirectory()));
    File entry = root.openNextFile();
    while (entry && count < max_count) {
        String nm = entry.name();
        size_t sz = entry.size();
        bool isDir = entry.isDirectory();
        Serial.printf_P(PSTR("[fs] entry: name=%s size=%u isDir=%d\n"),
                        nm.c_str(), (unsigned)sz, (int)isDir);
        if (!isDir) {
            /* SPIFFS returns names WITH a leading "/" — strip it for
             * ESP8266 API compatibility (and so JS sees "file.js"
             * rather than "/file.js"). */
            if (nm.startsWith("/")) nm = nm.substring(1);
            out[count].name = nm;
            out[count].size = sz;
            count++;
        }
        entry = root.openNextFile();
    }
    Serial.printf_P(PSTR("[fs] listed %d files\n"), count);
#endif
    return count;
}

static inline size_t fs_total_bytes() {
#if defined(ESP8266)
    FSInfo i;
    LittleFS.info(i);
    return i.totalBytes;
#elif defined(ESP32)
    return SPIFFS.totalBytes();
#endif
}

static inline size_t fs_used_bytes() {
#if defined(ESP8266)
    FSInfo i;
    LittleFS.info(i);
    return i.usedBytes;
#elif defined(ESP32)
    return SPIFFS.usedBytes();
#endif
}

/* T51: Display backend — must be set before including espboy_display.h.
 * Options: DISPLAY_BACKEND_TFT_ESPI (default), DISPLAY_BACKEND_ADAFRUIT,
 *          DISPLAY_BACKEND_NONE (headless). */
#if defined(DISPLAY_BACKEND_TFT_ESPI) || defined(ESP32)
  #include <TFT_eSPI.h>
#elif defined(DISPLAY_BACKEND_ADAFRUIT)
  #include <Adafruit_GFX.h>
  #include <Adafruit_ST7735.h>
  #include <Adafruit_ILI9341.h>
#endif

#include "espboy_display.h"
#include "espboy_font_tiny5.h"  /* T51: compact 5px variable-width font */

#define MJS_VM_IMPLEMENTATION
#include "microjs_vm.h"
#include "microjs_regex.h"
#define MICROJS_REPL_IMPLEMENTATION
#include "microjs_repl.h"
#include "tiny-json.h"
#include "microjs_json.h"
#include "microjs_webui.h"

/* ---- Hardware pins / I2C addresses ---- */
#define MCP23017_ADDR   0x20
#define MCP4725_ADDR    0x60
#define CSTFT_PIN       8      /* MCP23017 GPB0  -> TFT CS */
#define LEDLOCK_PIN     9      /* MCP23017 GPB1  -> WS2812B data latch */

#define AP_SSID         "MicroJS-AP"
#define AP_PASS         ""
#define AP_MAX_CLIENTS  1
#define HTTP_PORT       80

/* T51: Debug logging toggle.  Uncomment to enable verbose fetch/run/file logs. */
// #define FETCH_DEBUG
#ifdef FETCH_DEBUG
  #define DBG_PRINT(...)  Serial.printf_P(__VA_ARGS__)
  #define DBG_PRINTLN(s)  Serial.println(F(s))
#else
  #define DBG_PRINT(...)
  #define DBG_PRINTLN(s)
#endif

/* T51: JS heap size — platform-dependent.
 * ESP8266: 20KB (limited by 80KB total DRAM, need system heap for WiFi).
 * ESP32:   48KB.  ESP32 dram0_0_seg is ~128KB after system reservation.
 *   - WiFi stack BSS:        ~50 KB
 *   - TFT_eSPI + SPIFFS BSS: ~10 KB
 *   - g_framebuffer (160x120): 19.2 KB
 *   - g_js_heap (this):       48 KB
 *   - Other globals:           ~2 KB
 *   Total: ~129 KB — fits with ~13 KB headroom.
 * Bump up to 56 KB only if you don't use BT and can drop TFT_eSPI's
 * default font from User_Setup.h. */
#if defined(ESP8266)
  #define JS_HEAP_SIZE    (20 * 1024)
#elif defined(ESP32)
  #define JS_HEAP_SIZE    (48 * 1024)
#endif

/* T51: Display backend instance. */
#if defined(DISPLAY_BACKEND_TFT_ESPI) || defined(ESP32)
TFT_eSPI tft;
#elif defined(DISPLAY_BACKEND_ADAFRUIT)
  #if defined(ESP32)
  Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);
  #else
  Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);
  #endif
#endif

WEB_SERVER_TYPE server(HTTP_PORT);

static MJSContext *g_ctx = NULL;
static uint8_t g_js_heap[JS_HEAP_SIZE] __attribute__((aligned(8)));

/* T51: JS HTTP server state — when JS calls http.onRequest(callback),
 * g_js_http_active becomes true and g_js_http_handler holds the callback.
 * After that, requests to "/" go to the JS callback instead of redirecting
 * to /edit.  /edit always serves the web editor regardless of this state.
 *
 * Response buffering: http.respond() stores status/contentType/body in
 * g_http_resp_* globals.  After mjs_call_value returns, http_root() sends
 * the buffered response via server.send().  This avoids calling server.send()
 * from inside nested mjs_run() which could corrupt ESP8266WebServer state. */
static bool g_js_http_active = false;

/* T51: Set by http_run when a new script is uploaded while another is
 * running (via button/boot).  mjs_run checks this during yield() and
 * aborts the current script so the new one can take over. */
static volatile bool g_script_abort = false;
static MJSValue g_js_http_handler = MJS_UNDEF_V;
static int g_http_resp_status = 0;
static String g_http_resp_type;
static String g_http_resp_body;
static bool g_http_resp_pending = false;

/* T51: Native function table for OP_NATIVE_CALL inline caching.
 * Indexed by native_fn ID (0-15).  Filled in register_natives().
 * When the compiler detects `tft.pixel(x,y,c)`, it emits
 * OP_NATIVE_CALL with encoded id instead of LOAD_PROP + CALL,
 * skipping hash lookup and object property access. */
#define NATIVE_TFT_PIXEL   0
#define NATIVE_TFT_RECT    1
#define NATIVE_TFT_FRECT   2
#define NATIVE_TFT_CLS     3
#define NATIVE_TFT_FILL    4
#define NATIVE_TFT_LINE    5
#define NATIVE_TFT_CIRCLE  6
#define NATIVE_TFT_DISC    7
#define NATIVE_TFT_TEXT    8
#define NATIVE_TFT_FLIP    9
#define NATIVE_TFT_SPRITE  10
#define NATIVE_TFT_SPRITEMASK 11
#define NATIVE_TFT_WIDTH   12
#define NATIVE_TFT_HEIGHT  13
#define NATIVE_TFT_GETPIXEL 14
#define NATIVE_TFT_MAX     15

MJSCFunction g_native_fns[16] = { NULL };

/* Saved boot-script state (T23-style: no RAM mirror). */
static bool   saved_code_exists = false;
static size_t saved_code_size   = 0;
/* T50: g_boot_blob — declared early (before http_run) so /run can free
 * it when re-initializing the JS context.  Holds the loaded boot script
 * bytecode; const strings in the VM point into this buffer, so it must
 * outlive g_ctx.  Freed on /run, on next boot-script run, or never
 * (if user only ever uses /run). */
static uint8_t *g_boot_blob = NULL;

/* ---- Captured stdout buffer ---- */
#define OUT_BUF_SIZE 512
static char g_out_buf[OUT_BUF_SIZE];
static size_t g_out_len = 0;
static bool  g_capture_active = false;
static bool  g_out_truncated = false;  /* T50: signal truncation to UI */

static void out_reset() { g_out_len = 0; g_out_buf[0] = '\0'; g_out_truncated = false; }
static void out_append(const char *s, size_t len) {
    if (!g_capture_active) return;
    size_t avail = OUT_BUF_SIZE - 1 - g_out_len;
    if (len > avail) {
        /* T50: mark truncated so the UI can warn the user that output
         * was cut off.  Without this, silent truncation hides bugs. */
        g_out_truncated = true;
        len = avail;
    }
    if (len == 0) return;
    memcpy(g_out_buf + g_out_len, s, len);
    g_out_len += len;
    g_out_buf[g_out_len] = '\0';
}

/* ============================================================
 * MCP23017 / MCP4725 helpers (verbatim from old .ino)
 * ============================================================ */
static void mcp_writeReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(MCP23017_ADDR);
    Wire.write(reg); Wire.write(val);
    Wire.endTransmission();
}
static uint8_t mcp_readReg(uint8_t reg) {
    Wire.beginTransmission(MCP23017_ADDR);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom((uint8_t)MCP23017_ADDR, (uint8_t)1);
    return Wire.read();
}
static void mcp_pinMode(uint8_t pin, uint8_t mode) {
    uint8_t reg = (pin < 8) ? 0x00 : 0x01;
    uint8_t bit = pin % 8;
    uint8_t v = mcp_readReg(reg);
    bitWrite(v, bit, (mode == INPUT) ? 1 : 0);
    mcp_writeReg(reg, v);
}
static void mcp_pullUp(uint8_t pin, uint8_t val) {
    uint8_t reg = (pin < 8) ? 0x0C : 0x0D;
    uint8_t bit = pin % 8;
    uint8_t v = mcp_readReg(reg);
    bitWrite(v, bit, val);
    mcp_writeReg(reg, v);
}
static void mcp_digitalWrite(uint8_t pin, uint8_t val) {
    uint8_t bit = pin % 8;
    uint8_t v = mcp_readReg((pin < 8) ? 0x14 : 0x15);
    bitWrite(v, bit, val);
    mcp_writeReg((pin < 8) ? 0x12 : 0x13, v);
}
static void dac_write(uint16_t v, bool detect) {
    Wire.beginTransmission(MCP4725_ADDR);
    Wire.write(0x40);
    Wire.write((v >> 4) & 0xFF);
    Wire.write((v << 4) & 0xF0);
    Wire.endTransmission();
    (void)detect;
}

/* ============================================================
 * ESPboy native JS functions
 * ============================================================ */

/* T51-fix: Append a length-bounded char buffer to a String.
 * On ESP8266, WString::concat(const char*, unsigned int) is PUBLIC.
 * On ESP32 (arduino-esp32 1.0.4), WString::concat(const char*, unsigned int)
 * is PROTECTED — only callable from inside WString itself.  So we can't
 * use the two-arg concat() form from .ino code on ESP32.
 *
 * This helper works on BOTH platforms: ESP8266 uses the public two-arg
 * concat() (fast path), ESP32 falls back to single-char concat() in a
 * loop (the only public API that lets us append a known-length buffer
 * that may contain embedded NUL bytes — `String += buf` would stop at
 * the first NUL). */
static inline void str_append_len(String &dest, const char *s, size_t l) {
#if defined(ESP8266)
    dest.concat(s, (unsigned int)l);
#elif defined(ESP32)
    dest.reserve(dest.length() + l);
    for (size_t i = 0; i < l; i++) dest.concat(s[i]);
#endif
}

static MJSValue js_print(MJSContext *ctx, int argc, MJSValue *argv) {
    String line;
    for (int i = 0; i < argc; i++) {
        if (i) line += ' ';
        if (MJS_IS_INT(argv[i])) {
            /* T50: print negative fixed24.8 correctly.
             * Old code did `val >> 8` on a negative raw value, which
             * gives the floor (e.g. -1.5 → -2).  We need truncation
             * toward zero (-1.5 → -1), so we negate, print, re-negate. */
            int32_t raw = MJS_GET_INT(argv[i]);
            bool neg = raw < 0;
            if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;  /* T51: Bug 4 — UB guard */
            int32_t ip = raw >> 8;
            int32_t fp = (raw & 0xFF) * 100 / 256;
            if (neg && (ip > 0 || fp > 0)) line += '-';
            line += String((int)ip);
            if (fp > 0) { char buf[8]; snprintf(buf,sizeof(buf),".%02d",(int)fp); line += buf; }
        } else if (mjs_is_string(ctx, argv[i])) {
            size_t l; const char *s = mjs_to_cstr(ctx, argv[i], &l);
            /* T51-fix: use length-based concat instead of String(s)
             * which uses strlen().  ESP8266 Arduino's String class
             * doesn't have a (const char*, size_t) constructor, but
             * String::concat(const char*, unsigned int) exists.
             * This correctly handles strings containing \n, \t, \0,
             * and other non-NUL chars that could be truncated by
             * strlen() if the string data isn't NUL-terminated. */
            str_append_len(line, s, l);
        } else if (argv[i] == MJS_TRUE_V)  line += "true";
        else if (argv[i] == MJS_FALSE_V) line += "false";
        else if (argv[i] == MJS_NULL_V)   line += "null";
        else if (argv[i] == MJS_UNDEF_V)  line += "undefined";
        else if (argv[i] == MJS_NAN_V)    line += "NaN";
        else if (MJS_IS_PTR(argv[i])) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[i]);
            if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) {
                MJSArray *a = (MJSArray*)h;
                line += "[";
                for (int j = 0; j < a->length; j++) {
                    if (j) line += ", ";
                    MJSValue elem = mjs_get_index(ctx, argv[i], j);
                    if (MJS_IS_INT(elem)) { int32_t v=MJS_GET_INT(elem); line += String((int)(v>>8)); }
                    else if (mjs_is_string(ctx, elem)) { size_t l; const char *s=mjs_to_cstr(ctx,elem,&l); line += "\""; str_append_len(line, s, l); line += "\""; }
                    else line += "?";
                }
                line += "]";
            } else if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) {
                MJSObject *o = (MJSObject*)h;
                line += "{";
                int first = 1;
                /* T51-fix: slots are now separately allocated and o->slots
                 * points to the slot data (past the MJSHeader).  Was
                 * `(MJSSlot*)(o + 1)` which assumed slots were inline
                 * right after the MJSObject struct — that was the OLD
                 * pre-T51 layout.  Reading from (o+1) read random
                 * memory after the object header. */
                MJSSlot *slots = o->slots;
                for (int j = 0; j < o->capacity && first <= 4; j++) {
                    if (slots[j].atom != 0 && slots[j].atom != 0xFFFFu) {
                        if (!first) line += ", ";
                        first = 0;
                        if (slots[j].atom <= ctx->atom_count) line += String(ctx->atoms[slots[j].atom - 1]);
                        line += ": ";
                        MJSValue v = slots[j].val;
                        if (MJS_IS_INT(v)) line += String((int)(MJS_GET_INT(v)>>8));
                        else if (mjs_is_string(ctx, v)) { size_t l; const char *s=mjs_to_cstr(ctx,v,&l); line += "\""; str_append_len(line, s, l); line += "\""; }
                        else line += "?";
                    }
                }
                if (o->count > 4) line += ", ...";
                line += "}";
            } else if (MJS_HDR_TYPE(h) == MJS_T_CFUNC || MJS_HDR_TYPE(h) == MJS_T_FUNC) {
                line += "[function]";
            } else line += "[obj]";
        }
        else line += "?";
    }
    Serial.println(line);
    String nl = line + "\n";
    out_append(nl.c_str(), nl.length());
    return MJS_UNDEF_V;
}

/* T51: millis() — returns milliseconds since boot, wraps at 999.
 * This cycles 0..999 repeatedly, so it's only useful for short intervals
 * (up to 1 second).  For longer timing, use seconds() or centis().
 * The wrap avoids int30 overflow (int30 max ~2,097,151). */
static MJSValue js_millis(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    yield();
    timers_tick();
    return mjs_int((int32_t)(millis() % 1000));
}

/* T51: seconds() — returns seconds since boot (0..~2,097,151 = ~24 days).
 * Uses the full millis() counter divided by 1000.
 * For intervals > 24 days, centis() extends to ~49 days. */
static MJSValue js_seconds(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    yield();
    timers_tick();
    return mjs_int((int32_t)(millis() / 1000));
}

/* T51: centis() — returns centiseconds (1/100 s) since boot (0..~2,097,151 = ~24 days).
 * Same as millis() / 10 but without the 999 wrap.
 * Useful for precise timing over long periods. */
static MJSValue js_centis(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    yield();
    timers_tick();
    return mjs_int((int32_t)(millis() / 10));
}
static MJSValue js_delay(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 1) return MJS_UNDEF_V;
    int32_t ms = mjs_to_int(ctx, argv[0]);
    if (ms > 0) {
        uint32_t start = millis();
        while ((uint32_t)(millis() - start) < (uint32_t)ms) {
            delay(1); yield();
        }
    }
    return MJS_UNDEF_V;
}
static MJSValue js_mem(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    return mjs_int((int32_t)ESP.getFreeHeap());
}
static MJSValue js_jsmem(MJSContext *ctx, int argc, MJSValue *argv) {
    /* T51: Without args → free JS heap. With arg → object/array memory usage. */
    if (argc < 1 || !MJS_IS_PTR(argv[0])) {
        return mjs_int((int32_t)mjs_free_mem(ctx));
    }
    /* Calculate memory used by a heap object (including sub-allocations). */
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
    uint32_t total = mjs_hdr_size(h);  /* main block size */
    if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) {
        MJSObject *o = (MJSObject*)h;
        if (o->slots) {
            total += mjs_hdr_size((MJSHeader*)o->slots);  /* slot array */
        }
    } else if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) {
        MJSArray *a = (MJSArray*)h;
        /* Array data is inline: already in mjs_hdr_size(h) */
        (void)a;
    } else if (MJS_HDR_TYPE(h) == MJS_T_STRING) {
        /* String data is inline: already in mjs_hdr_size(h) */
    }
    return mjs_int((int32_t)total);
}

/* T51-debug: timer definitions needed by js_gc's logging.
 * Moved here from below so js_gc can reference them. */
#define MJS_MAX_TIMERS 8
struct MJSTimer {
    MJSValue cb;
    uint32_t due;
    uint32_t interval;
    uint8_t  active;
};
static MJSTimer g_timers[MJS_MAX_TIMERS];

/* T51-debug: Called from GC sweep phase when an interesting block
 * (array/object/func) is about to be freed.  Logs it to Serial. */
void mjs_gc_sweep_log(uint8_t type, uint16_t size, void *ptr) {
    const char *tn = "?";
    if (type == MJS_T_ARRAY) tn = "ARRAY";
    else if (type == MJS_T_OBJECT) tn = "OBJECT";
    else if (type == MJS_T_FUNC) tn = "FUNC";
    else if (type == MJS_T_SLOTS) tn = "SLOTS";
    Serial.printf("[gc SWEEP] %s@%p sz=%u\n", tn, ptr, (unsigned)size);
}

static MJSValue js_gc(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    /* T51-debug: GC logging disabled — uncomment to re-enable.
     * The logging below dumps all globals before/after GC and logs
     * every swept block.  Useful for debugging GC issues but too
     * verbose for normal operation. */
#if 0
    /* T51-fix: Before GC, dump all globals that are pointers (to detect
     * if GC frees something that's still referenced). */
    Serial.println(F("[gc] === BEFORE GC ==="));
    for (uint16_t i = 0; i < ctx->global_count; i++) {
        MJSValue v = ctx->global_vals[i];
        if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            uint8_t *p = (uint8_t*)h;
            const char *name = (ctx->global_atoms[i] > 0 && ctx->global_atoms[i] <= ctx->atom_count)
                ? ctx->atoms[ctx->global_atoms[i] - 1] : "?";
            const char *desc = "unknown";
            if (p >= ctx->heap_start && p < ctx->heap_ptr) {
                uint8_t t = MJS_HDR_TYPE(h);
                if (t == MJS_T_ARRAY) {
                    MJSArray *a = (MJSArray*)h;
                    Serial.printf("  [%s] ARRAY@%p len=%d cap=%d\n", name, h, a->length, a->capacity);
                    continue;
                } else if (t == MJS_T_OBJECT) desc = "OBJECT";
                else if (t == MJS_T_STRING) desc = "STRING";
                else if (t == MJS_T_FUNC) desc = "FUNC";
                else if (t == MJS_T_CFUNC) desc = "CFUNC";
                else if (t == 0) desc = "FREED(type=0)!";
                Serial.printf("  [%s] %s@%p\n", name, desc, h);
            } else {
                Serial.printf("  [%s] PTR OUT OF HEAP @%p!\n", name, h);
            }
        }
    }
    Serial.println(F("[gc] locals:"));
    int max_locals = ctx->local_base + MJS_LOCALS_PER_FRAME;
    if (max_locals > MJS_LOCALS_MAX) max_locals = MJS_LOCALS_MAX;
    for (int i = 0; i < max_locals; i++) {
        MJSValue v = ctx->locals[i];
        if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            uint8_t *p = (uint8_t*)h;
            if (p >= ctx->heap_start && p < ctx->heap_ptr) {
                if (MJS_HDR_TYPE(h) == 0)
                    Serial.printf("  local[%d] FREED(type=0)@%p!\n", i, h);
            }
        }
    }
    Serial.println(F("[gc] timers:"));
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (g_timers[i].active) {
            MJSValue cb = g_timers[i].cb;
            if (MJS_IS_PTR(cb)) {
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(cb);
                uint8_t *p = (uint8_t*)h;
                if (p >= ctx->heap_start && p < ctx->heap_ptr)
                    Serial.printf("  timer[%d] type=%d@%p\n", i, MJS_HDR_TYPE(h), h);
                else
                    Serial.printf("  timer[%d] PTR OUT OF HEAP!\n", i);
            }
        }
    }
    Serial.println(F("[gc] stack:"));
    MJSValue *stack_top = (MJSValue*)ctx->buf_end;
    int scount = 0;
    for (MJSValue *p = ctx->sp; p < stack_top && scount < 20; p++, scount++) {
        if (MJS_IS_PTR(*p)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(*p);
            uint8_t *pp = (uint8_t*)h;
            if (pp >= ctx->heap_start && pp < ctx->heap_ptr)
                Serial.printf("  sp[%d] type=%d@%p\n", scount, MJS_HDR_TYPE(h), h);
        }
    }
#endif
    mjs_gc(ctx);
#if 0
    /* After GC: validate all globals still point to valid blocks */
    Serial.println(F("[gc] === AFTER GC ==="));
    for (uint16_t i = 0; i < ctx->global_count; i++) {
        MJSValue v = ctx->global_vals[i];
        if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            uint8_t *p = (uint8_t*)h;
            const char *name = (ctx->global_atoms[i] > 0 && ctx->global_atoms[i] <= ctx->atom_count)
                ? ctx->atoms[ctx->global_atoms[i] - 1] : "?";
            if (p < ctx->heap_start || p >= ctx->heap_ptr) {
                Serial.printf("  [gc BUG] global '%s' OUT OF HEAP after GC!\n", name);
            } else if (MJS_HDR_TYPE(h) == 0) {
                Serial.printf("  [gc BUG] global '%s' FREED after GC!\n", name);
            } else {
                uint8_t t = MJS_HDR_TYPE(h);
                if (t == MJS_T_ARRAY) {
                    MJSArray *a = (MJSArray*)h;
                    Serial.printf("  [%s] ARRAY@%p len=%d cap=%d OK\n", name, h, a->length, a->capacity);
                } else if (t == MJS_T_OBJECT) {
                    MJSObject *o = (MJSObject*)h;
                    if (o->slots) {
                        MJSHeader *sh = (MJSHeader*)((uint8_t*)o->slots - sizeof(MJSHeader));
                        uint8_t *sp = (uint8_t*)sh;
                        if (sp < ctx->heap_start || sp >= ctx->heap_ptr)
                            Serial.printf("  [gc BUG] global '%s' OBJECT@%p slots OUT OF HEAP!\n", name, h);
                        else if (MJS_HDR_TYPE(sh) == 0)
                            Serial.printf("  [gc BUG] global '%s' OBJECT@%p slots FREED!\n", name, h);
                        else
                            Serial.printf("  [%s] OBJECT@%p cap=%d slots=%p OK\n", name, h, o->capacity, (void*)sh);
                    } else {
                        Serial.printf("  [%s] OBJECT@%p cap=%d slots=NULL OK\n", name, h, o->capacity);
                    }
                } else if (t == MJS_T_STRING) {
                    MJSString *s = (MJSString*)h;
                    Serial.printf("  [%s] STRING@%p len=%d OK\n", name, h, s->len);
                } else if (t == MJS_T_FUNC) {
                    Serial.printf("  [%s] FUNC@%p OK\n", name, h);
                } else if (t == MJS_T_CFUNC) {
                    Serial.printf("  [%s] CFUNC@%p OK\n", name, h);
                } else {
                    Serial.printf("  [%s] type=%d@%p OK\n", name, t, h);
                }
            }
        }
    }
    Serial.printf_P(PSTR("[gc] free=%u\n"), (unsigned)mjs_free_mem(ctx));
#endif
    return mjs_int((int32_t)mjs_free_mem(ctx));
}
/* T51-debug: gcDebug() — runs GC then prints block stats to Serial.
 * Counts: total blocks, type-0 (bytecode), type-1 (object), type-3 (string),
 * type-4 (cfunc), type-5 (func), type-6 (slots), and freelist blocks.
 * Also prints total used, total free (bump + freelist). */
static MJSValue js_gcDebug(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    mjs_gc(ctx);
    int total = 0, by_type[8] = {0};
    uint32_t used_bytes = 0;
    uint8_t *p = ctx->heap_start;
    while (p < ctx->heap_ptr) {
        MJSHeader *h = (MJSHeader*)p;
        uint16_t sz = mjs_hdr_size(h);
        if (sz == 0) break;
        uint8_t t = MJS_HDR_TYPE(h);
        if (t < 8) by_type[t]++;
        total++;
        used_bytes += sz;
        p += sz;
    }
    int fl_count = 0;
    size_t fl_bytes = 0;
    uint32_t off = ctx->free_list;
    while (off) {
        MJSHeader *h = (MJSHeader*)(ctx->buf_start + off);
        fl_count++;
        fl_bytes += mjs_hdr_size(h);
        off = mjs_hdr_next(h);
    }
    Serial.printf_P(PSTR("[gcDebug] blocks=%d (type0=%d type1=%d type2=%d type3=%d type4=%d type5=%d type6=%d) "
                  "used=%u free=%u (bump=%u fl=%u fl_count=%d) globals=%d "
                  "GC: marked=%d swept=%d bytecode=%d\n"),
                  total, by_type[0], by_type[1], by_type[2], by_type[3], by_type[4], by_type[5], by_type[6],
                  (unsigned)used_bytes, (unsigned)mjs_free_mem(ctx),
                  (unsigned)(ctx->heap_limit - ctx->heap_ptr), (unsigned)fl_bytes, fl_count,
                  ctx->global_count, ctx->_gc_marked, ctx->_gc_swept, ctx->_gc_bytecode);
    return mjs_int((int32_t)mjs_free_mem(ctx));
}
/* T51-debug: gcRoots() — dump all GC roots (globals, stack, locals)
 * to Serial.  For each root that is a pointer, prints the block offset
 * and type.  Use this to find which root is keeping objects alive. */
static const char *block_type_name(uint8_t t) {
    switch (t) {
        case 0: return "bytecode";
        case 1: return "object";
        case 2: return "array";
        case 3: return "string";
        case 4: return "cfunc";
        case 5: return "func";
        case 6: return "slots";
        case 7: return "accessor";
        default: return "?";
    }
}
static MJSValue js_gcRoots(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    Serial.println(F("[gcRoots] === Globals ==="));
    for (uint16_t i = 0; i < ctx->global_count; i++) {
        uint16_t a = ctx->global_atoms[i];
        MJSValue v = ctx->global_vals[i];
        const char *aname = (a > 0 && a <= ctx->atom_count) ? ctx->atoms[a - 1] : "?";
        if (MJS_IS_INT(v)) {
            Serial.printf_P(PSTR("  [%u] %s = int(%d)\n"), i, aname, (int)(MJS_GET_INT(v) >> 8));
        } else if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            uint32_t off = (uint32_t)((uint8_t*)h - ctx->buf_start);
            Serial.printf_P(PSTR("  [%u] %s = ptr(off=%u type=%s)\n"), i, aname, off, block_type_name(MJS_HDR_TYPE(h)));
        } else {
            Serial.printf_P(PSTR("  [%u] %s = special(%u)\n"), i, aname, (unsigned)(v & 0xFF));
        }
    }
    Serial.println(F("[gcRoots] === Value stack [sp, buf_end) ==="));
    MJSValue *stack_top = (MJSValue*)ctx->buf_end;
    int n = 0;
    for (MJSValue *p = ctx->sp; p < stack_top; p++) {
        MJSValue v = *p;
        if (v == 0) { n++; continue; }  /* zero */
        if (MJS_IS_INT(v)) {
            Serial.printf_P(PSTR("  sp+%d: int(%d)\n"), n, (int)(MJS_GET_INT(v) >> 8));
        } else if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            if (h) {
                uint32_t off = (uint32_t)((uint8_t*)h - ctx->buf_start);
                Serial.printf_P(PSTR("  sp+%d: ptr(off=%u type=%s)\n"), n, off, block_type_name(MJS_HDR_TYPE(h)));
            }
        } else if (v != MJS_UNDEF_V) {
            Serial.printf_P(PSTR("  sp+%d: special(%u)\n"), n, (unsigned)(v & 0xFF));
        }
        n++;
    }
    if (n == 0) Serial.println(F("  (empty)"));
    Serial.println(F("[gcRoots] === Locals [0, local_base+PER_FRAME) ==="));
    int max_l = ctx->local_base + MJS_LOCALS_PER_FRAME;
    if (max_l > MJS_LOCALS_MAX) max_l = MJS_LOCALS_MAX;
    for (int i = 0; i < max_l; i++) {
        MJSValue v = ctx->locals[i];
        if (v == 0) {
            /* Zero-initialized, never written — not MJS_UNDEF_V but literal 0.
             * GC treats this as NULL pointer (TAG_PTR, ptr=NULL) — safe. */
            continue;
        }
        if (MJS_IS_INT(v)) {
            Serial.printf_P(PSTR("  local[%d]: int(%d)\n"), i, (int)(MJS_GET_INT(v) >> 8));
        } else if (MJS_IS_PTR(v)) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            if (!h) continue;  /* NULL pointer — skip */
            uint32_t off = (uint32_t)((uint8_t*)h - ctx->buf_start);
            Serial.printf_P(PSTR("  local[%d]: ptr(off=%u type=%s)\n"), i, off, block_type_name(MJS_HDR_TYPE(h)));
        } else if (v != MJS_UNDEF_V) {
            Serial.printf_P(PSTR("  local[%d]: special(%u)\n"), i, (unsigned)(v & 0xFF));
        }
    }
    /* Also check locals ABOVE the active frame — these might be stale */
    Serial.println(F("[gcRoots] === Locals ABOVE active frame (stale check) ==="));
    int stale_count = 0;
    for (int i = max_l; i < MJS_LOCALS_MAX; i++) {
        MJSValue v = ctx->locals[i];
        if (v == 0) continue;  /* zero-initialized */
        if (MJS_IS_PTR(v) && v != 0) {
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
            if (!h) continue;
            uint32_t off = (uint32_t)((uint8_t*)h - ctx->buf_start);
            Serial.printf_P(PSTR("  local[%d]: STALE ptr(off=%u type=%s)\n"), i, off, block_type_name(MJS_HDR_TYPE(h)));
            stale_count++;
        }
    }
    if (stale_count == 0) Serial.println(F("  (none — all clear)"));
    Serial.printf_P(PSTR("[gcRoots] sp=%p stack_bottom=%p buf_end=%p local_base=%d frame_depth=%d\n"),
                  (void*)ctx->sp, (void*)ctx->stack_bottom, (void*)ctx->buf_end,
                  ctx->local_base, ctx->frame_depth);
    /* T51-debug: dump ALL heap blocks with mark status, BEFORE and AFTER GC.
     * This shows exactly which blocks get freed and which stay. */
    Serial.println(F("[gcRoots] === All heap blocks (BEFORE gc) ==="));
    {
        uint8_t *p = ctx->heap_start;
        int n = 0;
        while (p < ctx->heap_ptr && n < 400) {
            MJSHeader *h = (MJSHeader*)p;
            uint16_t sz = mjs_hdr_size(h);
            if (sz == 0) { Serial.println(F("  [BAD sz=0]")); break; }
            uint8_t t = MJS_HDR_TYPE(h);
            uint8_t m = MJS_HDR_MARK(h);
            /* For objects, show slot contents briefly */
            char extra[80] = "";
            if (t == 1) {  /* object */
                MJSObject *o = (MJSObject*)h;
                uint32_t proto_off = 0;
                if (o->proto != MJS_NULL_V && MJS_IS_PTR(o->proto)) {
                    proto_off = (uint32_t)((uint8_t*)MJS_GET_PTR(o->proto) - ctx->buf_start);
                }
                snprintf(extra, sizeof(extra), " cap=%u cnt=%u slots_off=%u proto=%u",
                         o->capacity, o->count,
                         o->slots ? (uint32_t)((uint8_t*)o->slots - sizeof(MJSHeader) - ctx->buf_start) : 0,
                         proto_off);
            }
            Serial.printf_P(PSTR("  [off=%u] type=%s mark=%d size=%u%s\n"),
                          (unsigned)(p - ctx->buf_start), block_type_name(t), m, sz, extra);
            p += sz;
            n++;
        }
    }
    /* Now run GC and show which blocks got freed (added to freelist) */
    Serial.println(F("[gcRoots] === Running GC ==="));
    mjs_gc(ctx);
    Serial.println(F("[gcRoots] === Freelist after GC (freed blocks) ==="));
    {
        uint32_t off = ctx->free_list;
        int n = 0;
        while (off && n < 50) {
            MJSHeader *h = (MJSHeader*)(ctx->buf_start + off);
            Serial.printf_P(PSTR("  [off=%u] type=%s size=%u\n"),
                          off, block_type_name(MJS_HDR_TYPE(h)), mjs_hdr_size(h));
            off = mjs_hdr_next(h);
            n++;
        }
        Serial.printf_P(PSTR("  (total in freelist: %d blocks)\n"), n);
    }
    return mjs_int((int32_t)mjs_free_mem(ctx));
}
/* T51: reset() — reboot the ESP8266.  Useful for recovering from
 * JS runtime errors or for restarting a game after it ends.  The
 * `ESP.restart()` call performs a soft reboot: program execution
 * restarts from setup(), WiFi re-initializes, LittleFS remounts.
 * Sketch and saved files in flash are preserved. */
static MJSValue js_reset(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    Serial.println(F("[reset] rebooting..."));
    Serial.flush();
    delay(50);
    ESP.restart();
    return MJS_UNDEF_V;
}
/* T51: fetch(url [, options] [, callback]) — unified HTTP client.
 *
 * Supports multiple calling conventions:
 *
 *   // 1. Simple GET — returns body as string
 *   fetch("http://example.com/api")
 *
 *   // 2. Modern options object — browser-style API
 *   fetch("http://example.com/api", {
 *       method: "POST",                  // or "PUT", "DELETE" (default "GET")
 *       headers: {                        // object form
 *           "Content-Type": "application/json"
 *       },
 *       body: JSON.stringify({x: 1})
 *   })
 *
 *   // 3. Streaming with callback — chunked delivery
 *   fetch("http://example.com/big.json", function(chunk, totalBytes) {
 *       // chunk: ~256-byte string segment
 *       // totalBytes: bytes received so far
 *       // return false to abort; any other value (or undefined) to continue
 *   })
 *
 *   // 4. Streaming with options + callback
 *   fetch("http://example.com/api", { method: "POST", body: "..." },
 *         function(chunk, total) { ... })
 *
 *   // 5. Legacy positional form (backward compat)
 *   fetch("http://example.com/api", "POST", "body", "Content-Type: application/json")
 *   // headers arg is a newline-separated string of "Key: Value" lines
 *
 * Returns:
 *   - Without callback: body as string (or "ERROR: ..." string on failure)
 *   - With callback:    total bytes received as int (0 on error)
 *
 * HTTP ONLY — TLS needs ~15KB free heap, JS VM owns 24KB BSS leaving ~8KB.
 * Auto-follows up to 3 http→http redirects (301/302/303/307/308).
 * For 303 or 301/302 on POST, switches to GET (browser behavior).
 *
 * Selective JSON parsing: when streaming, the callback can scan chunks
 * for specific patterns and skip/extract only what's needed.  See
 * jsonSelect() helper for a convenient wrapper.
 *
 * Note: BLOCKING call — up to ~10s without callback, ~30s with callback.
 */

/* Helper: read HTTP response (status + headers + body) from an
 * ALREADY-CONNECTED client.  Used by both fetch_one (HTTP path that
 * does its own DNS+connect) and the TLS branch in js_fetch (which
 * does the TLS handshake separately so SNI can be sent by hostname).
 *
 * On entry: client is already connected (TCP or TLS), request has NOT
 * been sent yet.  host/port are passed for diagnostic logging only.
 * On exit: *httpCode, *location, *bodyLen filled.
 * Returns true on success (got at least the status line). */
static bool fetch_read_response(WiFiClient &client,
                                const String &request,
                                int *httpCode, String *location,
                                char *bodyBuf, int maxBody, int *bodyLen) {
    /* T51-fix: Set explicit read timeout.  Without this, WiFiClient uses
     * the default Stream _timeout which on ESP32 1.0.4 is 0 = block forever. */
    client.setTimeout(5000);
    DBG_PRINT(PSTR("[fetch] sending request (%u bytes)...\n"),
                    (unsigned)request.length());
    client.print(request);
    client.flush();
    DBG_PRINTLN("[fetch] request sent, waiting for response...");
    /* Read status line: "HTTP/1.1 200 OK\r\n" */
    uint32_t statusT0 = millis();
    String status = client.readStringUntil('\n');
    DBG_PRINT(PSTR("[fetch] status line received in %lums (%u bytes)\n"),
                    (unsigned long)(millis() - statusT0),
                    (unsigned)status.length());
    int sp1 = status.indexOf(' ');
    if (sp1 > 0) {
        int sp2 = status.indexOf(' ', sp1 + 1);
        String codeStr = (sp2 > 0) ? status.substring(sp1 + 1, sp2)
                                   : status.substring(sp1 + 1);
        codeStr.trim();
        *httpCode = codeStr.toInt();
    }
    DBG_PRINT(PSTR("[fetch] parsed httpCode=%d\n"), *httpCode);

    /* Read headers — capture Location: for redirects. */
    DBG_PRINTLN("[fetch] reading headers...");
    uint32_t hdrDeadline = millis() + 4000;
    int hdrCount = 0;
    while (client.connected() || client.available()) {
        if (millis() > hdrDeadline) {
            DBG_PRINT(PSTR("[fetch] header deadline reached after %d headers\n"),
                            hdrCount);
            break;
        }
        String line = client.readStringUntil('\n');
        if (line.length() == 0 || line == "\r" || line == "\n" ||
            line == "\r\n") {
            DBG_PRINT(PSTR("[fetch] end of headers (after %d lines)\n"),
                            hdrCount);
            break;
        }
        if (line.length() >= 9 &&
            (line.startsWith("Location:") || line.startsWith("location:"))) {
            String val = line.substring(9);
            val.trim();
            *location = val;
            DBG_PRINT(PSTR("[fetch] Location: %s\n"), val.c_str());
        }
        hdrCount++;
        if (!client.available() && !client.connected()) {
            DBG_PRINTLN("[fetch] client disconnected mid-headers");
            break;
        }
        yield();
    }
    DBG_PRINT(PSTR("[fetch] headers done, total %d headers\n"), hdrCount);

    /* For redirects (3xx), drain & exit — no body needed. */
    if (*httpCode >= 300 && *httpCode < 400) {
        DBG_PRINTLN("[fetch] 3xx redirect — draining and returning");
        client.stop();
        return true;
    }

    /* Non-streaming: read body into buffer until socket closes or full. */
    if (bodyBuf && maxBody > 0) {
        DBG_PRINT(PSTR("[fetch] reading body (max %d bytes)...\n"), maxBody);
        /* T51-fix: HARD total deadline of 10 seconds.  The soft "no-data"
         * deadline gets reset every time data is received, which can cause
         * infinite loops if the server sends a byte every <3s (e.g., HTTP/1.1
         * chunked transfer encoding with slow chunks).  The hard deadline
         * caps the total body read time. */
        uint32_t bodyDeadline = millis() + 5000;       /* soft: 5s no-data */
        uint32_t totalDeadline = millis() + 10000;      /* HARD: 10s total */
        int loopCount = 0;
        while (*bodyLen < maxBody && (client.available() || client.connected())) {
            loopCount++;
            if ((loopCount % 500) == 0) {
                DBG_PRINT(PSTR("[fetch] body loop hb: iters=%d bodyLen=%u avail=%d conn=%d\n"),
                                loopCount, (unsigned)*bodyLen,
                                (int)client.available(), (int)client.connected());
            }
            if (millis() > totalDeadline) {
                DBG_PRINT(PSTR("[fetch] HARD total deadline (10s) — bodyLen=%u\n"),
                                (unsigned)*bodyLen);
                break;
            }
            if (client.available()) {
                /* Use client.read() directly (WiFiClient's non-blocking
                 * impl) instead of Stream's readBytes() wrapper which
                 * can block on some ESP32 1.0.4 builds. */
                int avail = client.available();
                int toRead = (avail < (maxBody - *bodyLen)) ? avail : (maxBody - *bodyLen);
                int got = client.read((uint8_t*)(bodyBuf + *bodyLen), toRead);
                if (got > 0) {
                    *bodyLen += got;
                    bodyDeadline = millis() + 3000;
                } else if (got == 0) {
                    delay(1);
                    continue;
                } else {
                    DBG_PRINTLN("[fetch] body read returned error, stopping");
                    break;
                }
            } else {
                if (millis() > bodyDeadline) {
                    DBG_PRINT(PSTR("[fetch] soft no-data deadline (3s) — bodyLen=%u\n"),
                                    (unsigned)*bodyLen);
                    break;
                }
                delay(1);
                yield();
            }
        }
        DBG_PRINT(PSTR("[fetch] body done, %u bytes (after %d iters)\n"),
                        (unsigned)*bodyLen, loopCount);
        client.stop();
        return true;
    }

    /* Streaming mode (bodyBuf == NULL): leave client open for the caller
     * to read chunks via mjs_call_value(callback, ...).  Do NOT stop here. */
    DBG_PRINTLN("[fetch] streaming mode — leaving client open for chunks");
    return true;
}

/* Helper: do one HTTP round-trip on a caller-provided WiFiClient.
 * On entry: client is already configured (timeout, TLS settings, etc.)
 * and NOT yet connected.  host/port/request are prepared.
 * On exit: *httpCode, *location, *bodyLen filled (bodyBuf may be NULL
 * for streaming mode — caller handles chunks separately).
 * Returns true on TCP success (got at least a status line). */
static bool fetch_one(WiFiClient &client, const String &host, uint16_t port,
                      const String &request,
                      int *httpCode, String *location,
                      char *bodyBuf, int maxBody, int *bodyLen) {
    /* T51: Detailed DNS + TCP connect diagnostics for ESP32.
     * On ESP32 1.0.4, WiFiClient.connect(host, port) does DNS + TCP in one
     * call.  If it fails, we don't know which step failed.  Pre-resolve DNS
     * manually so we can log the failure reason. */
    IPAddress addr;
    DBG_PRINT(PSTR("[fetch] DNS resolving %s (free=%u)...\n"),
                    host.c_str(), (unsigned)ESP.getFreeHeap());
    uint32_t dnsT0 = millis();
    bool dnsOk = WiFi.hostByName(host.c_str(), addr);
    uint32_t dnsMs = millis() - dnsT0;
    if (!dnsOk) {
        DBG_PRINT(PSTR("[fetch] DNS FAILED for %s after %lums (free=%u)\n"),
                        host.c_str(), (unsigned long)dnsMs,
                        (unsigned)ESP.getFreeHeap());
        return false;
    }
    DBG_PRINT(PSTR("[fetch] DNS OK: %s -> %s in %lums\n"),
                    host.c_str(), addr.toString().c_str(), (unsigned long)dnsMs);
    DBG_PRINT(PSTR("[fetch] TCP connecting to %s:%u...\n"),
                    addr.toString().c_str(), port);
    /* T51-fix: Set explicit connect timeout.  Default WiFiClient connect
     * timeout on ESP32 1.0.4 is 30s (way too long for failed connects).
     * 5s is enough — if the server doesn't SYN-ACK by then, it's blocked. */
    client.setTimeout(5000);
    uint32_t t0 = millis();
    bool connected = client.connect(addr, port);
    uint32_t connectMs = millis() - t0;
    if (!connected) {
        DBG_PRINT(PSTR("[fetch] TCP connect FAILED after %lums (free=%u)\n"),
                        (unsigned long)connectMs, (unsigned)ESP.getFreeHeap());
        return false;
    }
    DBG_PRINT(PSTR("[fetch] TCP connected in %lums\n"),
                    (unsigned long)connectMs);
    /* Delegate response reading to fetch_read_response (shared with TLS path). */
    return fetch_read_response(client, request, httpCode, location,
                               bodyBuf, maxBody, bodyLen);
}

/* Helper: streaming variant — opens connection, parses status + headers,
 * then leaves client open for chunked reads.  Caller invokes callback
 * per chunk and calls client.stop() when done. */
static bool fetch_one_stream(WiFiClient &client,
                             const String &host, uint16_t port,
                             const String &request,
                             int *httpCode, String *location) {
    client.setTimeout(3000);  /* T51: 3s connect timeout (was 8s — too slow) */
    /* T51: Pre-resolve DNS so we can log the failure reason. */
    IPAddress addr;
    DBG_PRINT(PSTR("[fetch] DNS resolving %s (stream)...\n"), host.c_str());
    uint32_t dnsT0 = millis();
    bool dnsOk = WiFi.hostByName(host.c_str(), addr);
    uint32_t dnsMs = millis() - dnsT0;
    if (!dnsOk) {
        DBG_PRINT(PSTR("[fetch] DNS FAILED for %s after %lums (stream)\n"),
                        host.c_str(), (unsigned long)dnsMs);
        return false;
    }
    DBG_PRINT(PSTR("[fetch] DNS OK: %s -> %s in %lums (stream)\n"),
                    host.c_str(), addr.toString().c_str(), (unsigned long)dnsMs);
    uint32_t t0 = millis();
    bool connected = client.connect(addr, port);
    uint32_t connectMs = millis() - t0;
    if (!connected) {
        DBG_PRINT(PSTR("[fetch] TCP connect FAILED after %lums (stream)\n"),
                        (unsigned long)connectMs);
        return false;
    }
    DBG_PRINT(PSTR("[fetch] TCP connected in %lums (stream)\n"),
                    (unsigned long)connectMs);
    /* T51-fix: explicit read timeout (default 0 = block forever on ESP32 1.0.4). */
    client.setTimeout(5000);
    DBG_PRINT(PSTR("[fetch] sending request (%u bytes, stream)...\n"),
                    (unsigned)request.length());
    client.print(request);
    client.flush();
    DBG_PRINTLN("[fetch] request sent (stream), waiting for response...");
    uint32_t statusT0 = millis();
    String status = client.readStringUntil('\n');
    DBG_PRINT(PSTR("[fetch] status received in %lums (%u bytes, stream)\n"),
                    (unsigned long)(millis() - statusT0),
                    (unsigned)status.length());

    int sp1 = status.indexOf(' ');
    if (sp1 > 0) {
        int sp2 = status.indexOf(' ', sp1 + 1);
        String codeStr = (sp2 > 0) ? status.substring(sp1 + 1, sp2)
                                   : status.substring(sp1 + 1);
        codeStr.trim();
        *httpCode = codeStr.toInt();
    }

    uint32_t hdrDeadline = millis() + 4000;
    while (client.connected() || client.available()) {
        if (millis() > hdrDeadline) break;
        String line = client.readStringUntil('\n');
        if (line.length() == 0 || line == "\r" || line == "\n" ||
            line == "\r\n") break;
        if (line.length() >= 9 &&
            (line.startsWith("Location:") || line.startsWith("location:"))) {
            String val = line.substring(9);
            val.trim();
            *location = val;
        }
        if (!client.available() && !client.connected()) break;
        yield();
    }
    return true;
}

/* Helper: extract method/headers/body from options object.
 * Recognizes: method (string), headers (object or string), body (string). */
static void parse_options(MJSContext *ctx, MJSValue opts,
                          String &method, String &headers, String &body) {
    if (!MJS_IS_PTR(opts)) return;
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(opts);
    if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) return;
    MJSObject *o = (MJSObject*)h;
    MJSSlot *slots = o->slots;
    if (!slots) return;
    for (uint16_t i = 0; i < o->capacity; i++) {
        uint16_t atom = slots[i].atom;
        if (atom == 0 || atom == 0xFFFFu) continue;
        const char *key = ctx->atoms[atom - 1];
        if (!key) continue;
        MJSValue val = slots[i].val;
        if (strcmp(key, "method") == 0 && mjs_is_string(ctx, val)) {
            size_t ml; const char *m = mjs_to_cstr(ctx, val, &ml);
            method = String(m).substring(0, ml);
            method.toUpperCase();
        } else if (strcmp(key, "body") == 0 && mjs_is_string(ctx, val)) {
            size_t bl; const char *b = mjs_to_cstr(ctx, val, &bl);
            body = String(b).substring(0, bl);
        } else if (strcmp(key, "headers") == 0) {
            if (mjs_is_string(ctx, val)) {
                /* String form: newline-separated "Key: Value" lines. */
                size_t hl; const char *s = mjs_to_cstr(ctx, val, &hl);
                headers = String(s).substring(0, hl);
            } else if (MJS_IS_PTR(val)) {
                /* Object form: { "Key": "Value", ... } */
                MJSHeader *hh = (MJSHeader*)MJS_GET_PTR(val);
                if (MJS_HDR_TYPE(hh) == MJS_T_OBJECT) {
                    MJSObject *ho = (MJSObject*)hh;
                    MJSSlot *hslots = ho->slots;
                    if (hslots) {
                        for (uint16_t j = 0; j < ho->capacity; j++) {
                            uint16_t hatom = hslots[j].atom;
                            if (hatom == 0 || hatom == 0xFFFFu) continue;
                            const char *hk = ctx->atoms[hatom - 1];
                            if (!hk) continue;
                            MJSValue hv = hslots[j].val;
                            if (mjs_is_string(ctx, hv)) {
                                size_t vl; const char *v = mjs_to_cstr(ctx, hv, &vl);
                                headers += String(hk) + ": " +
                                           String(v).substring(0, vl) + "\n";
                            }
                        }
                    }
                }
            }
        }
    }
}

static MJSValue js_fetch(MJSContext *ctx, int argc, MJSValue *argv) {
    DBG_PRINT(PSTR("[fetch] ENTER js_fetch (argc=%d, free=%u)\n"),
                    argc, (unsigned)ESP.getFreeHeap());
    if (argc < 1 || !mjs_is_string(ctx, argv[0])) {
        DBG_PRINTLN("[fetch] missing URL arg");
        return mjs_new_string(ctx, "ERROR: missing URL", 19);
    }
    size_t urlLen;
    const char *url = mjs_to_cstr(ctx, argv[0], &urlLen);
    DBG_PRINT(PSTR("[fetch] URL len=%u: %.40s\n"),
                    (unsigned)urlLen, url);
    if (urlLen == 0 || urlLen > 512) {
        DBG_PRINTLN("[fetch] bad URL length");
        return mjs_new_string(ctx, "ERROR: bad URL", 14);
    }

    /* Parse arguments — support 5 calling conventions (see docstring). */
    String method = "GET";
    String body = "";
    String headers = "";
    MJSValue callback = MJS_UNDEF_V;
    bool hasCallback = false;

    if (argc >= 2) {
        if (mjs_is_function(ctx, argv[1])) {
            /* Form 3: fetch(url, callback) */
            callback = argv[1];
            hasCallback = true;
        } else if (MJS_IS_PTR(argv[1]) &&
                   MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(argv[1])) == MJS_T_OBJECT) {
            /* Form 2/4: fetch(url, options [, callback]) */
            parse_options(ctx, argv[1], method, headers, body);
            if (argc >= 3 && mjs_is_function(ctx, argv[2])) {
                callback = argv[2];
                hasCallback = true;
            }
        } else if (mjs_is_string(ctx, argv[1])) {
            /* Form 5: legacy positional — fetch(url, method, body, headers) */
            size_t ml; const char *m = mjs_to_cstr(ctx, argv[1], &ml);
            method = String(m).substring(0, ml);
            method.toUpperCase();
            if (argc >= 3 && mjs_is_string(ctx, argv[2])) {
                size_t bl; const char *b = mjs_to_cstr(ctx, argv[2], &bl);
                body = String(b).substring(0, bl);
            }
            if (argc >= 4 && mjs_is_string(ctx, argv[3])) {
                size_t hl; const char *h = mjs_to_cstr(ctx, argv[3], &hl);
                headers = String(h).substring(0, hl);
            }
        }
    }

    if (method != "GET" && method != "POST" && method != "PUT" && method != "DELETE") {
        return mjs_new_string(ctx, "ERROR: unsupported method", 25);
    }

    if (WiFi.status() != WL_CONNECTED) {
        return mjs_new_string(ctx, "ERROR: WiFi not connected", 24);
    }

    /* T51: HTTPS support for ESP32.
     * ESP8266 doesn't have enough heap for BearSSL (~11KB needed, only
     * 8-9KB free with JS VM resident).  ESP32 has 215KB+ free, so TLS
     * is feasible.  We use WiFiClientSecure with setInsecure() to skip
     * certificate validation (pragmatic for embedded devices fetching
     * public APIs — NTP/cert store isn't worth the flash/heap cost). */
    String urlS = String(url).substring(0, urlLen);
    bool useTLS = false;
    if (urlS.startsWith("https://")) {
#if defined(ESP32)
        useTLS = true;
#else
        return mjs_new_string(
            ctx,
            "ERROR: HTTPS not supported on ESP8266 (need ~11KB heap). Use http:// URL.",
            84);
#endif
    } else if (!urlS.startsWith("http://")) {
        return mjs_new_string(ctx, "ERROR: URL must start with http:// or https://", 48);
    }

    /* T51: WiFi sleep is now disabled permanently in setup() — modem sleep
     * was causing TCP connect failures on first request after wake. */

    /* Streaming mode uses a small 256-byte chunk buffer. */
    const int CHUNK_SIZE = 256;
    /* Non-streaming uses a 4KB body buffer (was 3KB; increased after
     * RODATA savings from F() macro freed up ~2KB headroom). */
    const int MAX_BODY = 4096;

    char *bodyBuf = NULL;
    char *chunkBuf = NULL;
    if (hasCallback) {
        chunkBuf = (char*)malloc(CHUNK_SIZE + 1);
        if (!chunkBuf) {
            return mjs_int(0);
        }
    } else {
        bodyBuf = (char*)malloc(MAX_BODY + 1);
        if (!bodyBuf) {
            return mjs_new_string(ctx, "ERROR: out of memory", 20);
        }
    }

    String currentURL = urlS;
    MJSValue result = MJS_UNDEF_V;
    int redirects = 0;
    const int MAX_REDIRECTS = 3;
    bool abort = false;
    int totalReceived = 0;
    int finalHttpCode = 0;

    while (redirects <= MAX_REDIRECTS && !abort) {
        /* Parse current URL: http://host:port/path or https://host:port/path */
        String rest;
        bool urlUseTLS = false;
        if (currentURL.startsWith("https://")) {
            urlUseTLS = true;
            rest = currentURL.substring(8);
        } else if (currentURL.startsWith("http://")) {
            rest = currentURL.substring(7);
        } else {
            result = mjs_new_string(ctx, "ERROR: bad URL scheme", 21);
            break;
        }
        int slash = rest.indexOf('/');
        String hostPort = (slash < 0) ? rest : rest.substring(0, slash);
        String path     = (slash < 0) ? "/" : rest.substring(slash);
        String host;
        uint16_t port = urlUseTLS ? 443 : 80;
        int colon = hostPort.indexOf(':');
        if (colon > 0) {
            host = hostPort.substring(0, colon);
            port = (uint16_t)hostPort.substring(colon + 1).toInt();
        } else {
            host = hostPort;
        }
        if (host.length() == 0) {
            result = mjs_new_string(ctx, "ERROR: bad URL (no host)", 22);
            break;
        }

        DBG_PRINT(PSTR("[fetch] %s %s://%s:%u%s  (rssi=%d, free=%u, hop=%d, %s)\n"),
                        method.c_str(), urlUseTLS ? "https" : "http",
                        host.c_str(), port, path.c_str(),
                        (int)WiFi.RSSI(), (unsigned)ESP.getFreeHeap(), redirects,
                        hasCallback ? "stream" : "buffered");
        uint32_t fetchStart = millis();  /* T51: track fetch time */

        /* Build HTTP/1.1 request. */
        String request = method + " " + path + " HTTP/1.1\r\n" +
                         "Host: " + host + "\r\n" +
                         "User-Agent: ESPboy-MicroJS/1.0\r\n" +
                         "Accept: */*\r\n" +
                         "Connection: close\r\n";
        if ((method == "POST" || method == "PUT") && body.length() > 0) {
            request += "Content-Length: " + String(body.length()) + "\r\n";
        }
        if (method == "POST" &&
            headers.indexOf("Content-Type") < 0 &&
            headers.indexOf("content-type") < 0) {
            request += "Content-Type: application/x-www-form-urlencoded\r\n";
        }
        if (headers.length() > 0) {
            int start = 0;
            while (start < (int)headers.length()) {
                int nl = headers.indexOf('\n', start);
                String line = (nl < 0) ? headers.substring(start)
                                       : headers.substring(start, nl);
                line.trim();
                if (line.length() > 0) request += line + "\r\n";
                if (nl < 0) break;
                start = nl + 1;
            }
        }
        request += "\r\n";
        if (body.length() > 0) request += body;

        int httpCode = 0;
        String location;

#if defined(ESP32)
        /* ESP32: instantiate either WiFiClient (HTTP) or WiFiClientSecure (HTTPS).
         * WiFiClientSecure inherits from WiFiClient, so fetch_one / fetch_one_stream
         * (which take WiFiClient&) work for both.  We skip certificate validation
         * (pragmatic for an embedded device fetching public APIs — avoids needing
         * a cert store + NTP for time).
         *
         * Version-specific TLS API:
         *   - arduino-esp32 1.0.x (axTLS):       setCACert(NULL) disables CA verification
         *   - arduino-esp32 2.0+   (mbedTLS):    setInsecure() skips all cert verification
         *
         * T51-fix: For HTTPS, connect by HOSTNAME (not IP) so SNI is sent during
         * the TLS handshake.  Cloudflare and other multi-tenant TLS servers
         * REJECT connections without SNI — the previous code did DNS pre-resolution
         * then connect-by-IP, which dropped SNI, causing "TLS connect failed in 103ms"
         * (fast failure because the server immediately closed the connection). */
        if (urlUseTLS) {
            WiFiClientSecure tlsClient;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 2
            tlsClient.setInsecure();
#else
            /* axTLS-based (arduino-esp32 1.0.4) — setCACert(NULL) sets _use_ca_cert = false,
             * which makes the SSL handshake skip CA verification. */
            tlsClient.setCACert(NULL);
#endif
            tlsClient.setTimeout(10000);  /* TLS handshake can take 5-10s */
            DBG_PRINT(PSTR("[fetch] TLS connecting to %s:%u (by hostname for SNI)...\n"),
                            host.c_str(), port);
            uint32_t tlsT0 = millis();
            bool tlsOk = tlsClient.connect(host.c_str(), port);  /* by hostname, not IP! */
            uint32_t tlsMs = millis() - tlsT0;
            if (!tlsOk) {
                DBG_PRINT(PSTR("[fetch] TLS connect FAILED after %lums (free=%u)\n"),
                                (unsigned long)tlsMs, (unsigned)ESP.getFreeHeap());
                char buf[96];
                snprintf(buf, sizeof(buf),
                         "ERROR: TLS connect failed (https://%s:%u rssi=%d free=%u after %lums)",
                         host.c_str(), port,
                         (int)WiFi.RSSI(), (unsigned)ESP.getFreeHeap(),
                         (unsigned long)tlsMs);
                result = mjs_new_string(ctx, buf, strlen(buf));
                break;
            }
            DBG_PRINT(PSTR("[fetch] TLS connected in %lums (free=%u)\n"),
                            (unsigned long)tlsMs, (unsigned)ESP.getFreeHeap());
            int bodyLen = 0;
            /* T51-fix: For streaming mode (hasCallback), pass NULL bodyBuf to
             * fetch_read_response so it leaves the client open after headers.
             * For buffered mode, pass bodyBuf so it reads the body. */
            char *respBodyBuf = hasCallback ? NULL : bodyBuf;
            int  respMaxBody = hasCallback ? 0    : MAX_BODY;
            bool ok = fetch_read_response(tlsClient, request,
                                           &httpCode, &location,
                                           respBodyBuf, respMaxBody, &bodyLen);
            if (!ok) {
                char buf[96];
                snprintf(buf, sizeof(buf),
                         "ERROR: TLS connect failed (https://%s:%u rssi=%d free=%u)",
                         host.c_str(), port,
                         (int)WiFi.RSSI(), (unsigned)ESP.getFreeHeap());
                result = mjs_new_string(ctx, buf, strlen(buf));
                break;
            }
            finalHttpCode = httpCode;
            /* Redirect? (3xx with Location header) */
            if (httpCode >= 300 && httpCode < 400 && location.length() > 0) {
                redirects++;
                if (redirects > MAX_REDIRECTS) {
                    result = mjs_new_string(ctx, "ERROR: too many redirects", 25);
                    break;
                }
                if (location.startsWith("http://") || location.startsWith("https://")) {
                    currentURL = location;
                } else if (location.startsWith("/")) {
                    currentURL = (String("https://") + host +
                                 (port == 443 ? "" : ":" + String(port)) + location);
                } else {
                    String base = (String("https://") + host +
                                   (port == 443 ? "" : ":" + String(port)));
                    int lastSlash = path.lastIndexOf('/');
                    if (lastSlash >= 0) base += path.substring(0, lastSlash + 1);
                    else base += "/";
                    currentURL = base + location;
                }
                DBG_PRINT(PSTR("[fetch] redirect -> %s\n"), currentURL.c_str());
                if (httpCode == 303 || ((httpCode == 301 || httpCode == 302) && method == "POST")) {
                    method = "GET"; body = "";
                }
                tlsClient.stop();
                continue;
            }
            /* Not a redirect — process the response body. */
            if (hasCallback) {
                DBG_PRINT(PSTR("[fetch] HTTPS %d (streaming)\n"), httpCode);
                /* T51-fix: Same hardening as HTTP streaming path:
                 *   - HARD 30s total deadline
                 *   - Use client.read() instead of readBytes() (non-blocking)
                 *   - Heartbeat log every 500 iterations */
                uint32_t bodyDeadline = millis() + 10000;       /* soft: 10s no-data */
                uint32_t totalDeadline = millis() + 30000;      /* HARD: 30s total */
                int chunkLen = 0;
                int streamIters = 0;
                while ((tlsClient.available() || tlsClient.connected()) && !abort) {
                    streamIters++;
                    if ((streamIters % 500) == 0) {
                        DBG_PRINT(PSTR("[fetch] TLS stream hb: iters=%d total=%u chunkLen=%u avail=%d conn=%d\n"),
                                        streamIters, (unsigned)totalReceived,
                                        (unsigned)chunkLen,
                                        (int)tlsClient.available(),
                                        (int)tlsClient.connected());
                    }
                    if (millis() > totalDeadline) {
                        DBG_PRINT(PSTR("[fetch] HARD TLS stream deadline (30s) — total=%u\n"),
                                        (unsigned)totalReceived);
                        break;
                    }
                    if (tlsClient.available()) {
                        int avail = tlsClient.available();
                        int toRead = (avail < (CHUNK_SIZE - chunkLen)) ? avail : (CHUNK_SIZE - chunkLen);
                        int got = tlsClient.read((uint8_t*)(chunkBuf + chunkLen), toRead);
                        if (got > 0) {
                            chunkLen += got;
                            totalReceived += got;
                            bodyDeadline = millis() + 5000;
                            if (chunkLen >= CHUNK_SIZE) {
                                MJSValue args[2];
                                args[0] = mjs_new_string(ctx, chunkBuf, chunkLen);
                                args[1] = mjs_int((int32_t)totalReceived);
                                MJSValue rv = mjs_call_value(ctx, callback, 2, args);
                                if (MJS_IS_INT(rv)) {
                                    int32_t v = (int32_t)(MJS_GET_INT(rv) >> 8);
                                    if (v == 0) abort = true;
                                }
                                chunkLen = 0;
                            }
                        } else if (got == 0) {
                            delay(1);
                            continue;
                        } else {
                            DBG_PRINTLN("[fetch] TLS stream read error, stopping");
                            break;
                        }
                    } else {
                        if (millis() > bodyDeadline) {
                            DBG_PRINT(PSTR("[fetch] TLS stream no-data deadline (5s) — total=%u\n"),
                                            (unsigned)totalReceived);
                            break;
                        }
                        delay(1);
                        yield();
                    }
                }
                DBG_PRINT(PSTR("[fetch] TLS stream done, total=%u bytes (after %d iters)\n"),
                                (unsigned)totalReceived, streamIters);
                /* Flush remaining bytes. */
                if (chunkLen > 0 && !abort) {
                    MJSValue args[2];
                    args[0] = mjs_new_string(ctx, chunkBuf, chunkLen);
                    args[1] = mjs_int((int32_t)totalReceived);
                    mjs_call_value(ctx, callback, 2, args);
                }
            } else {
                DBG_PRINT(PSTR("[fetch] HTTPS %d, %d bytes in %lums (free=%u)\n"),
                                httpCode, bodyLen, (unsigned long)(millis() - fetchStart),
                                (unsigned)ESP.getFreeHeap());
                if (httpCode == 0) {
                    result = mjs_new_string(ctx, "ERROR: no HTTP response", 22);
                } else {
                    result = mjs_new_string(ctx, bodyBuf, bodyLen);
                }
            }
            tlsClient.stop();
            break;
        } else
#endif
        if (hasCallback) {
            /* Streaming mode — use fetch_one_stream, leave client open. */
            WiFiClient client;
            client.setTimeout(3000);  /* T51: 3s connect timeout (was 8s — too slow) */
            bool ok = fetch_one_stream(client, host, port, request,
                                       &httpCode, &location);
            if (!ok) {
                char buf[96];
                snprintf(buf, sizeof(buf),
                         "ERROR: TCP connect failed (http://%s:%u rssi=%d free=%u)",
                         host.c_str(), port,
                         (int)WiFi.RSSI(), (unsigned)ESP.getFreeHeap());
                if (finalHttpCode == 0) {
                    /* If no prior successful response, return error as
                     * string-equivalent int 0 (streaming contract). */
                }
                break;
            }

            finalHttpCode = httpCode;
            DBG_PRINT(PSTR("[fetch] HTTP %d (streaming)\n"), httpCode);

            /* Redirect? */
            if (httpCode >= 300 && httpCode < 400 && location.length() > 0) {
                redirects++;
                if (redirects > MAX_REDIRECTS) break;
                if (location.startsWith("http://") || location.startsWith("https://")) {
                    currentURL = location;
                } else if (location.startsWith("/")) {
                    currentURL = "http://" + host + (port == 80 ? "" : ":" + String(port)) + location;
                } else {
                    String base = "http://" + host + (port == 80 ? "" : ":" + String(port));
                    int lastSlash = path.lastIndexOf('/');
                    if (lastSlash >= 0) base += path.substring(0, lastSlash + 1);
                    else base += "/";
                    currentURL = base + location;
                }
                client.stop();
                if (httpCode == 303 || ((httpCode == 301 || httpCode == 302) && method == "POST")) {
                    method = "GET"; body = "";
                }
                continue;
            }

            /* Stream body in CHUNK_SIZE pieces.
             * T51-fix: Same hardening as fetch_read_response:
             *   - HARD 30s total deadline (caps the whole stream)
             *   - Use client.read() instead of readBytes() (non-blocking)
             *   - Heartbeat log every 500 iterations */
            int chunkLen = 0;
            uint32_t bodyDeadline = millis() + 10000;       /* soft: 10s no-data */
            uint32_t totalDeadline = millis() + 30000;      /* HARD: 30s total */
            int streamIters = 0;
            while ((client.available() || client.connected()) && !abort) {
                streamIters++;
                if ((streamIters % 500) == 0) {
                    DBG_PRINT(PSTR("[fetch] stream hb: iters=%d total=%u chunkLen=%u avail=%d conn=%d\n"),
                                    streamIters, (unsigned)totalReceived,
                                    (unsigned)chunkLen,
                                    (int)client.available(), (int)client.connected());
                }
                if (millis() > totalDeadline) {
                    DBG_PRINT(PSTR("[fetch] HARD stream deadline (30s) — total=%u\n"),
                                    (unsigned)totalReceived);
                    break;
                }
                if (client.available()) {
                    int avail = client.available();
                    int toRead = (avail < (CHUNK_SIZE - chunkLen)) ? avail : (CHUNK_SIZE - chunkLen);
                    int got = client.read((uint8_t*)(chunkBuf + chunkLen), toRead);
                    if (got > 0) {
                        chunkLen += got;
                        totalReceived += got;
                        bodyDeadline = millis() + 5000;
                        if (chunkLen >= CHUNK_SIZE) {
                            MJSValue args[2];
                            args[0] = mjs_new_string(ctx, chunkBuf, chunkLen);
                            args[1] = mjs_int((int32_t)totalReceived);
                            MJSValue rv = mjs_call_value(ctx, callback, 2, args);
                            if (MJS_IS_INT(rv)) {
                                int32_t v = (int32_t)(MJS_GET_INT(rv) >> 8);
                                if (v == 0) abort = true;
                            }
                            chunkLen = 0;
                        }
                    } else if (got == 0) {
                        /* available() said >0 but read() returned 0 — race, retry */
                        delay(1);
                        continue;
                    } else {
                        DBG_PRINTLN("[fetch] stream read returned error, stopping");
                        break;
                    }
                } else {
                    if (millis() > bodyDeadline) {
                        DBG_PRINT(PSTR("[fetch] stream no-data deadline (5s) — total=%u\n"),
                                        (unsigned)totalReceived);
                        break;
                    }
                    delay(1);
                    yield();
                }
            }
            DBG_PRINT(PSTR("[fetch] stream done, total=%u bytes (after %d iters)\n"),
                            (unsigned)totalReceived, streamIters);
            /* Flush remaining bytes. */
            if (chunkLen > 0 && !abort) {
                MJSValue args[2];
                args[0] = mjs_new_string(ctx, chunkBuf, chunkLen);
                args[1] = mjs_int((int32_t)totalReceived);
                mjs_call_value(ctx, callback, 2, args);
            }
            client.stop();
            break;
        } else {
            /* Buffered mode — use fetch_one with body buffer. */
            WiFiClient client;
            client.setTimeout(3000);  /* T51: 3s connect timeout */
            int bodyLen = 0;
            bool ok = fetch_one(client, host, port, request,
                                &httpCode, &location,
                                bodyBuf, MAX_BODY, &bodyLen);
            if (!ok) {
                char buf[96];
                snprintf(buf, sizeof(buf),
                         "ERROR: TCP connect failed (http://%s:%u rssi=%d free=%u)",
                         host.c_str(), port,
                         (int)WiFi.RSSI(), (unsigned)ESP.getFreeHeap());
                result = mjs_new_string(ctx, buf, strlen(buf));
                break;
            }

            finalHttpCode = httpCode;
            DBG_PRINT(PSTR("[fetch] HTTP %d, %d bytes in %lums (free=%u)\n"),
                            httpCode, bodyLen, (unsigned long)(millis() - fetchStart),
                            (unsigned)ESP.getFreeHeap());

            /* Redirect? */
            if (httpCode >= 300 && httpCode < 400 && location.length() > 0) {
                redirects++;
                if (redirects > MAX_REDIRECTS) {
                    result = mjs_new_string(ctx, "ERROR: too many redirects", 25);
                    break;
                }
#if !defined(ESP32)
                /* ESP8266 can't follow https:// redirects (no heap for TLS).
                 * ESP32 CAN follow them — handled below by accepting the
                 * https:// location and letting the next loop iteration
                 * parse it and instantiate WiFiClientSecure. */
                if (location.startsWith("https://")) {
                    String msg = "ERROR: server redirects to HTTPS (" +
                                 location + "). HTTPS not supported on ESP8266.";
                    result = mjs_new_string(ctx, msg.c_str(), msg.length());
                    break;
                }
#endif
                if (location.startsWith("http://") || location.startsWith("https://")) {
                    currentURL = location;
                } else if (location.startsWith("/")) {
                    currentURL = "http://" + host + (port == 80 ? "" : ":" + String(port)) + location;
                } else {
                    String base = "http://" + host + (port == 80 ? "" : ":" + String(port));
                    int lastSlash = path.lastIndexOf('/');
                    if (lastSlash >= 0) base += path.substring(0, lastSlash + 1);
                    else base += "/";
                    currentURL = base + location;
                }
                DBG_PRINT(PSTR("[fetch] redirect -> %s\n"), currentURL.c_str());
                if (httpCode == 303 || ((httpCode == 301 || httpCode == 302) && method == "POST")) {
                    method = "GET"; body = "";
                }
                continue;
            }

            /* Non-redirect response. */
            if (httpCode == 0) {
                result = mjs_new_string(ctx, "ERROR: no HTTP response", 22);
            } else {
                result = mjs_new_string(ctx, bodyBuf, bodyLen);
            }
            break;
        }
    }

    free(bodyBuf);
    free(chunkBuf);

    if (hasCallback) {
        return mjs_int((int32_t)totalReceived);
    }
    return result;
}
/* T51: jsonSelect(jsonString, path) — extract a value from a JSON string
 * without parsing the whole thing.  Useful for large JSON responses
 * where you only need one or two fields.
 *
 *   jsonSelect('{"user":{"name":"Mikl","age":42}}', "user.name")    → "Mikl"
 *   jsonSelect('{"user":{"name":"Mikl","age":42}}', "user.age")     → 42
 *   jsonSelect('[10,20,30]', "1")                                   → 20
 *   jsonSelect('{"items":[{"id":5}]}', "items.0.id")                → 5
 *
 * Path syntax: dot-separated keys, integer indices for arrays.
 * Returns the value as a string (numbers, strings, booleans, null
 * are all returned as their JSON representation).  Returns the
 * string "<not found>" if the path doesn't exist.
 *
 * Implementation: scans the JSON string looking for the next key or
 * array index, skipping over nested objects/arrays.  This is much
 * faster than JSON.parse for large inputs when you only need one
 * field — it doesn't allocate any heap on the JS side until the
 * final value is extracted. */
static MJSValue js_json_select(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2 || !mjs_is_string(ctx, argv[0]) || !mjs_is_string(ctx, argv[1])) {
        return mjs_new_string(ctx, "<not found>", 11);
    }
    size_t jsonLen, pathLen;
    const char *json = mjs_to_cstr(ctx, argv[0], &jsonLen);
    const char *path = mjs_to_cstr(ctx, argv[1], &pathLen);
    if (jsonLen == 0 || pathLen == 0) {
        return mjs_new_string(ctx, "<not found>", 11);
    }

    /* Parse path into segments.  Limited to 16 segments. */
    String segments[16];
    int nseg = 0;
    int start = 0;
    for (size_t i = 0; i < pathLen && nseg < 16; i++) {
        if (path[i] == '.') {
            if (i > start) segments[nseg++] = String(path).substring(start, i);
            start = i + 1;
        }
    }
    if (start < (int)pathLen) {
        segments[nseg++] = String(path).substring(start);
    }
    if (nseg == 0) return mjs_new_string(ctx, "<not found>", 11);

    /* Walk JSON looking for each segment. */
    int pos = 0;
    /* Skip leading whitespace. */
    while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == '\t' ||
                                   json[pos] == '\n' || json[pos] == '\r')) pos++;

    for (int s = 0; s < nseg; s++) {
        if (pos >= (int)jsonLen) return mjs_new_string(ctx, "<not found>", 11);
        char c = json[pos];
        if (c == '{') {
            /* Object — find the key. */
            bool found = false;
            pos++;  /* skip { */
            while (pos < (int)jsonLen && json[pos] != '}') {
                /* Skip whitespace. */
                while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == ',' ||
                                               json[pos] == '\t' || json[pos] == '\n' ||
                                               json[pos] == '\r')) pos++;
                if (pos >= (int)jsonLen || json[pos] == '}') break;
                /* Read key (must be a quoted string). */
                if (json[pos] != '"') {
                    /* Malformed — skip to next comma or }. */
                    while (pos < (int)jsonLen && json[pos] != ',' && json[pos] != '}') pos++;
                    continue;
                }
                pos++;  /* skip opening quote */
                int keyStart = pos;
                while (pos < (int)jsonLen && json[pos] != '"') {
                    if (json[pos] == '\\' && pos + 1 < (int)jsonLen) pos++;
                    pos++;
                }
                int keyLen = pos - keyStart;
                pos++;  /* skip closing quote */
                /* Skip whitespace + colon + whitespace (handles newlines
                 * in pretty-printed JSON, e.g. httpbin.org output). */
                while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == ':' ||
                                               json[pos] == '\t' ||
                                               json[pos] == '\n' ||
                                               json[pos] == '\r')) pos++;
                /* Compare key directly against segment — no String alloc. */
                if ((int)segments[s].length() == keyLen &&
                    memcmp(json + keyStart, segments[s].c_str(), keyLen) == 0) {
                    found = true;
                    break;  /* pos now points at the value */
                } else {
                    /* Skip the value. */
                    int depth = 0;
                    bool inStr = false;
                    while (pos < (int)jsonLen) {
                        char ch = json[pos];
                        if (inStr) {
                            if (ch == '\\' && pos + 1 < (int)jsonLen) { pos += 2; continue; }
                            if (ch == '"') inStr = false;
                        } else {
                            if (ch == '"') inStr = true;
                            else if (ch == '{' || ch == '[') depth++;
                            else if (ch == '}' || ch == ']') depth--;
                            else if (ch == ',' && depth == 0) break;
                        }
                        pos++;
                    }
                }
            }
            if (!found) return mjs_new_string(ctx, "<not found>", 11);
            /* pos points at the value for this segment. */
        } else if (c == '[') {
            /* Array — find the index. */
            int idx = segments[s].toInt();
            if (idx < 0) return mjs_new_string(ctx, "<not found>", 11);
            pos++;  /* skip [ */
            int cur = 0;
            while (pos < (int)jsonLen && json[pos] != ']') {
                while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == ',' ||
                                               json[pos] == '\t' || json[pos] == '\n' ||
                                               json[pos] == '\r')) pos++;
                if (pos >= (int)jsonLen || json[pos] == ']') break;
                if (cur == idx) break;
                /* Skip this element. */
                int depth = 0;
                bool inStr = false;
                while (pos < (int)jsonLen) {
                    char ch = json[pos];
                    if (inStr) {
                        if (ch == '\\' && pos + 1 < (int)jsonLen) { pos += 2; continue; }
                        if (ch == '"') inStr = false;
                    } else {
                        if (ch == '"') inStr = true;
                        else if (ch == '{' || ch == '[') depth++;
                        else if (ch == '}' || ch == ']') {
                            if (depth == 0) break;
                            depth--;
                        }
                        else if (ch == ',' && depth == 0) break;
                    }
                    pos++;
                }
                cur++;
            }
            if (json[pos] == ']') return mjs_new_string(ctx, "<not found>", 11);
            /* pos points at the element. */
        } else {
            return mjs_new_string(ctx, "<not found>", 11);
        }
        /* Skip whitespace before next segment. */
        while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == '\t' ||
                                       json[pos] == '\n' || json[pos] == '\r')) pos++;
    }

    /* pos points at the final value.  Extract it as a string. */
    while (pos < (int)jsonLen && (json[pos] == ' ' || json[pos] == '\t' ||
                                   json[pos] == '\n' || json[pos] == '\r')) pos++;
    if (pos >= (int)jsonLen) return mjs_new_string(ctx, "<not found>", 11);

    int valStart = pos;
    char c = json[pos];
    if (c == '"') {
        /* String value — include the quotes. */
        pos++;
        while (pos < (int)jsonLen && json[pos] != '"') {
            if (json[pos] == '\\' && pos + 1 < (int)jsonLen) pos++;
            pos++;
        }
        pos++;  /* include closing quote */
    } else if (c == '{' || c == '[') {
        /* Object/array — find matching close. */
        int depth = 0;
        while (pos < (int)jsonLen) {
            char ch = json[pos];
            if (ch == '{' || ch == '[') depth++;
            else if (ch == '}' || ch == ']') {
                depth--;
                if (depth == 0) { pos++; break; }
            }
            pos++;
        }
    } else {
        /* Number, boolean, or null — read until comma/brace/bracket/whitespace. */
        while (pos < (int)jsonLen) {
            char ch = json[pos];
            if (ch == ',' || ch == '}' || ch == ']' || ch == '\n' ||
                ch == '\r' || ch == ' ' || ch == '\t') break;
            pos++;
        }
    }
    int valLen = pos - valStart;
    /* T51: Work directly on the char buffer — avoid String allocation
     * which can fail/truncate when system heap is low (~4KB free).
     * Strip surrounding quotes for string values. */
    const char *valPtr = json + valStart;
    int valLenOut = valLen;
    if (valLen >= 2 && valPtr[0] == '"' && valPtr[valLen - 1] == '"') {
        valPtr++;          /* skip opening quote */
        valLenOut -= 2;    /* remove both quotes */
    }
    return mjs_new_string(ctx, valPtr, valLenOut);
}

/* ============================================================
 * T51: Lightweight JSON SAX parser (streaming, callback-based).
 *
 * Inspired by JsonStreamingParser (https://github.com/AT42/JsonStreamingParser)
 * but reimplemented inline to avoid external library dependency.
 *
 * Features:
 *   - Zero heap allocation during parsing (uses small stack buffer)
 *   - Handles arbitrary-length JSON (no full buffering)
 *   - Callback-based: invokes user callback for each value matching a path
 *   - Handles escaped strings, nested objects/arrays, all JSON value types
 *
 * Usage:
 *   JsonSaxParser p;
 *   p.begin(ctx, path, callback);
 *   p.feed(chunk, len);   // call repeatedly with input chunks
 *   p.end();              // finalize
 *
 * Path syntax (dot-separated, like jsonSelect):
 *   "title"            → top-level "title" field value
 *   "items.title"      → every "title" inside "items" array elements
 *   "items.0.title"    → "title" of first item (index 0)
 *   "*"                → every value at any depth (debug)
 *
 * When a value at the matching path is found, callback(valueStr) is called.
 * valueStr is passed as const char* + length (no String allocation).
 * ============================================================ */

#define JSON_SAX_MAX_DEPTH  16
#define JSON_SAX_MAX_KEY    64
#define JSON_SAX_MAX_PATH   8

class JsonSaxParser {
public:
    /* Callback type: receives matched value as (ptr, len). */
    typedef void (*MatchCallback)(const char *val, int len, void *userdata);

    void begin(const char *path, MatchCallback cb, void *ud) {
        /* Parse path into segments. */
        m_nseg = 0;
        int start = 0;
        for (int i = 0; path[i] && m_nseg < JSON_SAX_MAX_PATH; i++) {
            if (path[i] == '.') {
                if (i > start) {
                    int sl = i - start;
                    if (sl > JSON_SAX_MAX_KEY - 1) sl = JSON_SAX_MAX_KEY - 1;
                    memcpy(m_seg[m_nseg], path + start, sl);
                    m_seg[m_nseg][sl] = 0;
                    m_segWild[m_nseg] = (sl == 1 && m_seg[m_nseg][0] == '*');
                    m_nseg++;
                }
                start = i + 1;
            }
        }
        if (path[start] && m_nseg < JSON_SAX_MAX_PATH) {
            int sl = strlen(path + start);
            if (sl > JSON_SAX_MAX_KEY - 1) sl = JSON_SAX_MAX_KEY - 1;
            memcpy(m_seg[m_nseg], path + start, sl);
            m_seg[m_nseg][sl] = 0;
            m_segWild[m_nseg] = (sl == 1 && m_seg[m_nseg][0] == '*');
            m_nseg++;
        }
        m_cb = cb;
        m_userdata = ud;
        /* States:
         *   0 = expecting value or structure
         *   1 = inside string value
         *   2 = expecting key opening quote (after { or ,)
         *   3 = after key, expecting :
         *   4 = inside key string (after opening ")
         */
        m_state = 0;
        m_depth = 0;
        m_inEscape = false;
        m_keyLen = 0;
        m_keyBuf[0] = 0;
        m_valStr[0] = 0;
        m_valStrLen = 0;
        m_numLen = 0;
        /* Track container type at each depth: true=object, false=array. */
        m_isObj[0] = false;  /* root — treated as array context */
        for (int i = 0; i < JSON_SAX_MAX_DEPTH; i++) {
            m_pathMatch[i] = 0;
        }
        m_matchDepth = -1;
    }

    void feed(const char *data, int len) {
        for (int i = 0; i < len; i++) {
            char c = data[i];
            if (m_inEscape) {
                m_inEscape = false;
                if (m_state == 1) appendValChar(c);
                else if (m_state == 4) appendKeyChar(c);
                continue;
            }
            switch (m_state) {
                case 0:  /* expecting value or structure */
                    handleValueChar(c);
                    break;
                case 1:  /* inside string value */
                    if (c == '\\') { m_inEscape = true; break; }
                    if (c == '"') {
                        m_state = 0;
                        if (m_matchDepth >= 0 && m_depth == m_matchDepth) {
                            emitValue(m_valStr, m_valStrLen);
                        }
                        m_valStrLen = 0;
                        m_matchDepth = -1;
                    } else {
                        appendValChar(c);
                    }
                    break;
                case 2:  /* expecting key opening quote (after { or ,) */
                    if (c == ' ' || c == '\t' || c == '\n' || c == '\r') break;
                    if (c == '"') {
                        m_state = 4;  /* now inside key string */
                        m_keyLen = 0;
                    } else if (c == '}') {
                        if (m_depth > 0) m_depth--;
                        m_state = 0;
                    }
                    break;
                case 3:  /* after key, expecting : */
                    if (c == ':') m_state = 0;
                    break;
                case 4:  /* inside key string */
                    if (c == '\\') { m_inEscape = true; break; }
                    if (c == '"') {
                        m_state = 3;
                        m_keyBuf[m_keyLen] = 0;
                        checkKeyMatch();
                    } else {
                        appendKeyChar(c);
                    }
                    break;
            }
        }
    }

    void end() {
        /* Flush any pending number/keyword value. */
        flushNumber();
    }

private:
    MatchCallback m_cb;
    void *m_userdata;
    int m_state;
    int m_depth;
    bool m_inEscape;
    char m_keyBuf[JSON_SAX_MAX_KEY];
    int m_keyLen;
    char m_valStr[256];
    int m_valStrLen;
    int m_numLen;
    int m_matchDepth;
    int m_pathMatch[JSON_SAX_MAX_DEPTH];
    bool m_isObj[JSON_SAX_MAX_DEPTH];
    char m_seg[JSON_SAX_MAX_PATH][JSON_SAX_MAX_KEY];
    bool m_segWild[JSON_SAX_MAX_PATH];
    int m_nseg;

    void appendValChar(char c) {
        if (m_valStrLen < (int)sizeof(m_valStr) - 1)
            m_valStr[m_valStrLen++] = c;
    }

    void appendKeyChar(char c) {
        if (m_keyLen < JSON_SAX_MAX_KEY - 1)
            m_keyBuf[m_keyLen++] = c;
    }

    void handleValueChar(char c) {
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') return;
        if (c == '{') {
            /* If we were accumulating a number, emit it first. */
            flushNumber();
            m_depth++;
            m_isObj[m_depth] = true;
            m_state = 2;  /* expecting key opening quote */
            m_keyLen = 0;
            return;
        }
        if (c == '[') {
            flushNumber();
            m_depth++;
            m_isObj[m_depth] = false;
            checkArrayMatch();
            m_state = 0;
            return;
        }
        if (c == '}' || c == ']') {
            flushNumber();
            if (m_depth > 0) m_depth--;
            m_state = 0;
            return;
        }
        if (c == ',') {
            flushNumber();
            if (m_depth >= 0 && m_isObj[m_depth]) {
                m_state = 2;  /* expecting key */
            } else {
                m_state = 0;  /* expecting value */
            }
            return;
        }
        if (c == '"') {
            flushNumber();
            m_state = 1;
            m_valStrLen = 0;
            return;
        }
        if (c == '-' || (c >= '0' && c <= '9') || c == 't' || c == 'f' ||
            c == 'n' || c == '.') {
            if (m_valStrLen < (int)sizeof(m_valStr) - 1)
                m_valStr[m_valStrLen++] = c;
            m_numLen = m_valStrLen;
            return;
        }
    }

    void flushNumber() {
        /* Only flush and reset if we were actually accumulating a number.
         * If m_numLen == 0, we're between values (e.g. about to start
         * a string value after a matched key) — DON'T reset m_matchDepth,
         * otherwise the upcoming string value won't be emitted! */
        if (m_numLen > 0) {
            if (m_matchDepth >= 0 && m_depth == m_matchDepth) {
                emitValue(m_valStr, m_numLen);
            }
            m_valStrLen = 0;
            m_numLen = 0;
            m_matchDepth = -1;
        }
    }

    void checkKeyMatch() {
        /* Find which path segment we're at. */
        int curMatch = 0;
        if (m_depth > 0) curMatch = m_pathMatch[m_depth - 1];
        if (curMatch >= m_nseg) return;
        /* Check if key matches next segment (or wildcard). */
        if (m_segWild[curMatch] ||
            strcmp(m_keyBuf, m_seg[curMatch]) == 0) {
            int next = curMatch + 1;
            m_pathMatch[m_depth] = next;
            if (next == m_nseg) {
                /* Full path matched — next value is the target. */
                m_matchDepth = m_depth;
            }
        } else {
            /* No match — keep parent's match level. */
            m_pathMatch[m_depth] = curMatch;
        }
    }

    void checkArrayMatch() {
        int curMatch = 0;
        if (m_depth > 1) curMatch = m_pathMatch[m_depth - 1];
        /* For arrays, if next segment is a number, we'd need to track index.
         * For simplicity, treat any number segment as wildcard (match all). */
        if (curMatch < m_nseg) {
            /* Check if segment is numeric (index) or wildcard. */
            bool isIndex = true;
            for (int i = 0; m_seg[curMatch][i]; i++) {
                if (m_seg[curMatch][i] < '0' || m_seg[curMatch][i] > '9') {
                    isIndex = false; break;
                }
            }
            if (m_segWild[curMatch] || isIndex) {
                int next = curMatch + 1;
                m_pathMatch[m_depth] = next;
                if (next == m_nseg) m_matchDepth = m_depth;
            } else {
                m_pathMatch[m_depth] = curMatch;
            }
        }
    }

    void emitValue(const char *val, int len) {
        if (m_cb) m_cb(val, len, m_userdata);
    }
};

/* ============================================================
 * T51: jsonStream(url, path, callback) — streaming JSON fetch.
 *
 * Fetches URL via HTTP, feeds response chunks through JsonSaxParser,
 * invokes JS callback(value) for each value matching the path.
 *
 *   jsonStream("http://api.example.com/items",
 *              "title",            // path: top-level "title"
 *              function(v) { print("title: " + v); });
 *
 *   jsonStream(url, "items.title", function(v) {
 *       print("  - " + v);
 *   });
 *
 * Returns: number of matched values (int).
 *
 * Memory: parser uses ~200 bytes stack, no heap.  Handles arbitrarily
 * large JSON (response is processed in 256-byte chunks).
 * ============================================================ */

/* Bridge: JsonSaxParser callback → JS callback via mjs_call_value. */
struct JsonStreamCtx {
    MJSContext *ctx;
    MJSValue callback;
    int count;
};

static void jsonStreamBridge(const char *val, int len, void *ud) {
    JsonStreamCtx *sc = (JsonStreamCtx*)ud;
    MJSValue args[1];
    args[0] = mjs_new_string(sc->ctx, val, len);
    mjs_call_value(sc->ctx, sc->callback, 1, args);
    sc->count++;
}

static MJSValue js_json_stream(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 3 || !mjs_is_string(ctx, argv[0]) ||
        !mjs_is_string(ctx, argv[1]) || !mjs_is_function(ctx, argv[2])) {
        return mjs_int(0);
    }
    size_t urlLen, pathLen;
    const char *url = mjs_to_cstr(ctx, argv[0], &urlLen);
    const char *path = mjs_to_cstr(ctx, argv[1], &pathLen);
    if (urlLen == 0 || pathLen == 0) return mjs_int(0);

    if (WiFi.status() != WL_CONNECTED) return mjs_int(0);
    if (!strncmp(url, "https://", 8)) return mjs_int(0);
    if (strncmp(url, "http://", 7)) return mjs_int(0);

    JsonStreamCtx sc;
    sc.ctx = ctx;
    sc.callback = argv[2];
    sc.count = 0;

    JsonSaxParser parser;
    parser.begin(path, jsonStreamBridge, &sc);

    /* Reuse fetch streaming logic but feed to parser instead of callback. */
    String urlS = String(url).substring(0, urlLen);
    String currentURL = urlS;
    int redirects = 0;
    const int MAX_REDIRECTS = 3;

    while (redirects <= MAX_REDIRECTS) {
        String rest = currentURL.substring(7);
        int slash = rest.indexOf('/');
        String hostPort = (slash < 0) ? rest : rest.substring(0, slash);
        String pathStr = (slash < 0) ? "/" : rest.substring(slash);
        String host;
        uint16_t port = 80;
        int colon = hostPort.indexOf(':');
        if (colon > 0) {
            host = hostPort.substring(0, colon);
            port = (uint16_t)hostPort.substring(colon + 1).toInt();
        } else {
            host = hostPort;
        }
        if (host.length() == 0) break;

        Serial.printf_P(PSTR("[jsonStream] http://%s:%u%s  path=\"%s\"\n"),
                        host.c_str(), port, pathStr.c_str(), path);

        String request = String("GET ") + pathStr + " HTTP/1.1\r\n" +
                         "Host: " + host + "\r\n" +
                         "User-Agent: ESPboy-MicroJS/1.0\r\n" +
                         "Accept: */*\r\n" +
                         "Connection: close\r\n\r\n";

        WiFiClient client;
        client.setTimeout(3000);  /* T51: 3s connect timeout (was 8s — too slow) */
        if (!client.connect(host.c_str(), port)) {
            DBG_PRINTLN("[jsonStream] TCP connect failed");
            break;
        }
        client.print(request);

        /* Read status line. */
        String status = client.readStringUntil('\n');
        int httpCode = 0;
        int sp1 = status.indexOf(' ');
        if (sp1 > 0) {
            int sp2 = status.indexOf(' ', sp1 + 1);
            String codeStr = (sp2 > 0) ? status.substring(sp1 + 1, sp2)
                                       : status.substring(sp1 + 1);
            codeStr.trim();
            httpCode = codeStr.toInt();
        }

        /* Read headers — capture Location for redirects. */
        String location;
        uint32_t hdrDeadline = millis() + 4000;
        while (client.connected() || client.available()) {
            if (millis() > hdrDeadline) break;
            String line = client.readStringUntil('\n');
            if (line.length() == 0 || line == "\r" || line == "\n" ||
                line == "\r\n") break;
            if (line.length() >= 9 &&
                (line.startsWith("Location:") || line.startsWith("location:"))) {
                location = line.substring(9);
                location.trim();
            }
            if (!client.available() && !client.connected()) break;
            yield();
        }

        /* Redirect? */
        if (httpCode >= 300 && httpCode < 400 && location.length() > 0) {
            redirects++;
            if (redirects > MAX_REDIRECTS) break;
            if (location.startsWith("https://")) break;
            if (location.startsWith("http://")) {
                currentURL = location;
            } else if (location.startsWith("/")) {
                currentURL = "http://" + host + (port == 80 ? "" : ":" + String(port)) + location;
            } else {
                String base = "http://" + host + (port == 80 ? "" : ":" + String(port));
                int lastSlash = pathStr.lastIndexOf('/');
                if (lastSlash >= 0) base += pathStr.substring(0, lastSlash + 1);
                else base += "/";
                currentURL = base + location;
            }
            client.stop();
            continue;
        }

        /* Stream body through SAX parser. */
        char buf[256];
        uint32_t bodyDeadline = millis() + 10000;
        while (client.available() || client.connected()) {
            if (client.available()) {
                int got = client.readBytes(buf, sizeof(buf));
                if (got > 0) {
                    parser.feed(buf, got);
                    bodyDeadline = millis() + 5000;
                } else break;
            } else {
                if (millis() > bodyDeadline) break;
                delay(1);
                yield();
            }
        }
        client.stop();
        break;
    }

    parser.end();

    Serial.printf_P(PSTR("[jsonStream] matched %d values\n"), sc.count);
    return mjs_int((int32_t)sc.count);
}

/* T51: beep(freq, duration) — generate a square wave tone on the
 * ESPboy speaker.  ESPboy uses the MCP4725 DAC for audio — we
 * generate a square wave by toggling the DAC between 0 and max.
 * For higher frequencies, this is limited by I2C speed (~400kHz).
 * Alternatively, if a dedicated buzzer pin exists, use tone().
 *
 * On ESPboy v1, the speaker is connected through the DAC, same as
 * backlight.  So we briefly hijack the DAC to produce sound, then
 * restore backlight.  This is a simple beep, not high-quality audio.
 *
 * freq: frequency in Hz (100-5000 reasonable range)
 * duration: milliseconds */
static MJSValue js_beep(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 2) return MJS_UNDEF_V;
    int32_t freq = mjs_to_int(ctx, argv[0]);
    int32_t duration = mjs_to_int(ctx, argv[1]);
    if (freq < 50) freq = 50;
    if (freq > 10000) freq = 10000;
    if (duration < 1) duration = 1;
    if (duration > 5000) duration = 5000;
    /* Save current backlight level to restore after beep. */
    uint16_t saved_bl = 4095;  /* default full brightness */
    /* Generate square wave via DAC toggling. */
    uint32_t halfPeriod = 500000 / freq;  /* microseconds per half cycle */
    uint32_t start = millis();
    while ((int32_t)(millis() - start) < duration) {
        dac_write(2048, false);  /* mid-level (speaker clicks) */
        delayMicroseconds(halfPeriod);
        dac_write(0, false);     /* low */
        delayMicroseconds(halfPeriod);
        yield();
    }
    /* Restore backlight. */
    dac_write(saved_bl, false);
    return MJS_UNDEF_V;
}
/* T51: parseInt(s, radix) — parse integer from a string or number.
 * - If arg is a string: parses leading integer (with optional sign).
 *   Stops at first non-digit (in given radix).  Returns 0 if no
 *   digits found.  Supports radix 2-36.  If radix omitted or 0:
 *     - "0x" prefix → base 16
 *     - "0b" prefix → base 2
 *     - "0" prefix (followed by digits) → base 10 (JS spec says 8, but
 *       modern engines use 10; we follow modern behavior)
 *     - otherwise → base 10
 * - If arg is a number: truncates toward zero (clears fractional bits).
 * Returns 0 on missing/invalid argument. */
/* T51: files.list() — returns array of saved .js file names.
 * files.load(name) — returns file content as string (or "" if not found).
 * files.save(name, content) — saves .js file to LittleFS (returns 1 on success).
 * files.delete(name) — deletes a file (returns 1 on success). */
static MJSValue js_files_list(MJSContext *ctx, int argc, MJSValue *argv) {
    MJSValue arr = mjs_new_array(ctx, 0);
    DirEntry entries[64];
    int n = fs_list_root_files(entries, 64);
    int idx = 0;
    for (int i = 0; i < n; i++) {
        if (!entries[i].name.endsWith(".js")) continue;
        const String &name = entries[i].name;
        MJSValue sv = mjs_new_string(ctx, name.c_str(), name.length());
        mjs_set_index(ctx, arr, idx, sv);
        idx++;
    }
    return arr;
}

static MJSValue js_files_load(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !mjs_is_string(ctx, argv[0])) return mjs_new_string(ctx, "", 0);
    size_t nl; const char *n = mjs_to_cstr(ctx, argv[0], &nl);
    String path = "/" + String(n).substring(0, nl);
    if (!LittleFS.exists(path)) return mjs_new_string(ctx, "", 0);
    File f = LittleFS.open(path, "r");
    String content = f.readString();
    f.close();
    return mjs_new_string(ctx, content.c_str(), content.length());
}

static MJSValue js_files_save(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2 || !mjs_is_string(ctx, argv[0]) || !mjs_is_string(ctx, argv[1]))
        return mjs_int(0);
    size_t nl; const char *n = mjs_to_cstr(ctx, argv[0], &nl);
    size_t cl; const char *c = mjs_to_cstr(ctx, argv[1], &cl);
    String path = "/" + String(n).substring(0, nl);
    File f = LittleFS.open(path, "w");
    if (!f) return mjs_int(0);
    f.write((const uint8_t*)c, cl);
    f.close();
    return mjs_int(1);
}

static MJSValue js_files_delete(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !mjs_is_string(ctx, argv[0])) return mjs_int(0);
    size_t nl; const char *n = mjs_to_cstr(ctx, argv[0], &nl);
    String path = "/" + String(n).substring(0, nl);
    return mjs_int(LittleFS.remove(path) ? 1 : 0);
}

/* ============================================================
 * T51: I2C API — i2c.write(addr, data), i2c.read(addr, len), i2c.scan()
 * SPI API — spi.transfer(byte), spi.transferArray(arr)
 * ============================================================ */

/* I2C: write data to device at address.
 * i2c.write(addr, data)        — data is array of bytes or single int
 * i2c.write(addr, [0x10, 0x20]) — write two bytes
 * Returns: 1 on success, 0 on error. */
static MJSValue js_i2c_write(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2 || !MJS_IS_INT(argv[0])) return mjs_int(0);
    int addr = (int)(MJS_GET_INT(argv[0]) >> 8);
    Wire.beginTransmission(addr);
    if (MJS_IS_INT(argv[1])) {
        Wire.write((uint8_t)(MJS_GET_INT(argv[1]) >> 8));
    } else if (mjs_is_array(ctx, argv[1])) {
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[1]);
        MJSArray *a = (MJSArray*)h;
        for (int i = 0; i < a->length; i++) {
            MJSValue ev = mjs_get_index(ctx, argv[1], i);
            if (MJS_IS_INT(ev)) Wire.write((uint8_t)(MJS_GET_INT(ev) >> 8));
        }
    }
    int err = Wire.endTransmission();
    return mjs_int(err == 0 ? 1 : 0);
}

/* I2C: read len bytes from device at address.
 * i2c.read(addr, len) → array of integers
 * Returns: array of bytes, or empty array on error. */
static MJSValue js_i2c_read(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2 || !MJS_IS_INT(argv[0]) || !MJS_IS_INT(argv[1])) {
        MJSValue arr = mjs_new_array(ctx, 0);
        return arr;
    }
    int addr = (int)(MJS_GET_INT(argv[0]) >> 8);
    int len = (int)(MJS_GET_INT(argv[1]) >> 8);
    if (len < 1) len = 1;
    if (len > 32) len = 32;
    Wire.requestFrom((uint8_t)addr, (uint8_t)len);
    MJSValue arr = mjs_new_array(ctx, len);
    for (int i = 0; i < len && Wire.available(); i++) {
        uint8_t b = Wire.read();
        mjs_set_index(ctx, arr, i, mjs_int((int32_t)b));
    }
    return arr;
}

/* I2C: scan bus for devices. Returns array of addresses. */
static MJSValue js_i2c_scan(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    MJSValue arr = mjs_new_array(ctx, 0);
    int idx = 0;
    for (int addr = 1; addr < 127; addr++) {
        Wire.beginTransmission(addr);
        if (Wire.endTransmission() == 0) {
            mjs_set_index(ctx, arr, idx, mjs_int((int32_t)addr));
            idx++;
        }
        delay(1);
        yield();
    }
    return arr;
}

/* SPI: transfer a single byte. Returns the byte received. */
static MJSValue js_spi_transfer(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !MJS_IS_INT(argv[0])) return mjs_int(0);
    uint8_t out = (uint8_t)(MJS_GET_INT(argv[0]) >> 8);
    /* T51: Use Software SPI on GPIO14 (SCK), GPIO13 (MOSI), GPIO12 (MISO).
     * ESPboy doesn't have hardware SPI exposed, so we bit-bang.
     * For simplicity, use SPI library if available, otherwise bit-bang.
     * Most ESPboy setups use TFT_eSPI which already configures SPI.
     * We just use SPI.transfer() directly. */
    SPI.begin();
    uint8_t in = SPI.transfer(out);
    return mjs_int((int32_t)in);
}

/* SPI: transfer array of bytes. Returns array of received bytes. */
static MJSValue js_spi_transfer_array(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !mjs_is_array(ctx, argv[0])) {
        return mjs_new_array(ctx, 0);
    }
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
    MJSArray *a = (MJSArray*)h;
    int len = a->length;
    MJSValue result = mjs_new_array(ctx, len);
    SPI.begin();
    for (int i = 0; i < len; i++) {
        MJSValue ev = mjs_get_index(ctx, argv[0], i);
        uint8_t out = MJS_IS_INT(ev) ? (uint8_t)(MJS_GET_INT(ev) >> 8) : 0;
        uint8_t in = SPI.transfer(out);
        mjs_set_index(ctx, result, i, mjs_int((int32_t)in));
    }
    return result;
}

/* T51: isNaN(value) — returns true if value is NaN.
 * In microjs, NaN is a special value (MJS_NAN_V).  This checks if the
 * argument equals MJS_NAN_V.  Also returns true for undefined (since
 * parseInt(undefined) returns NaN in standard JS). */
static MJSValue js_isNaN(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1) return MJS_TRUE_V;
    MJSValue v = argv[0];
    /* Direct NaN check */
    if (v == MJS_NAN_V) return MJS_TRUE_V;
    /* undefined → NaN */
    if (v == MJS_UNDEF_V) return MJS_TRUE_V;
    /* Try parseInt — if it returns 0 but the string isn't "0", it's NaN */
    if (mjs_is_string(ctx, v)) {
        size_t l; const char *s = mjs_to_cstr(ctx, v, &l);
        /* Skip whitespace */
        size_t i = 0;
        while (i < l && (s[i] == ' ' || s[i] == '\t')) i++;
        /* If empty or doesn't start with digit/sign → NaN */
        if (i >= l) return MJS_TRUE_V;
        if (s[i] < '0' || s[i] > '9') {
            if (s[i] != '-' && s[i] != '+') return MJS_TRUE_V;
            if (i + 1 >= l || s[i+1] < '0' || s[i+1] > '9') return MJS_TRUE_V;
        }
    }
    return MJS_FALSE_V;
}

/* T51: getIP() — returns current IP address as string.
 * Returns STA IP if connected to WiFi, or AP IP (192.168.4.1) if in AP mode. */
static MJSValue js_getIP(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    IPAddress ip;
    if (WiFi.getMode() == WIFI_STA) {
        ip = WiFi.localIP();
    } else {
        ip = WiFi.softAPIP();
    }
    String ipStr = ip.toString();
    return mjs_new_string(ctx, ipStr.c_str(), ipStr.length());
}

static MJSValue js_parseInt(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1) return MJS_MAKE_INT(0);
    MJSValue v = argv[0];
    /* If argument is already a number, truncate fractional part. */
    if (MJS_IS_INT(v)) {
        int32_t raw = MJS_GET_INT(v);
        return MJS_MAKE_INT(raw & ~0xFF);  /* clear low 8 bits */
    }
    if (!mjs_is_string(ctx, v)) return MJS_MAKE_INT(0);

    size_t l; const char *s = mjs_to_cstr(ctx, v, &l);
    if (l == 0) return MJS_MAKE_INT(0);

    /* Determine radix: argv[1] if provided, else 0 (auto-detect). */
    int radix = 0;
    if (argc >= 2 && MJS_IS_INT(argv[1])) {
        radix = MJS_GET_INT(argv[1]) >> 8;  /* fixed24.8 → int */
        if (radix < 0) radix = -radix;
        if (radix != 0 && (radix < 2 || radix > 36)) return MJS_MAKE_INT(0);
    }

    size_t i = 0;
    /* skip leading whitespace */
    while (i < l && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r')) i++;
    if (i >= l) return MJS_MAKE_INT(0);

    /* sign */
    int sign = 1;
    if (s[i] == '-') { sign = -1; i++; }
    else if (s[i] == '+') { i++; }
    if (i >= l) return MJS_MAKE_INT(0);

    /* Auto-detect radix if not specified. */
    if (radix == 0) {
        if (i + 1 < l && s[i] == '0' && (s[i+1] == 'x' || s[i+1] == 'X')) {
            radix = 16; i += 2;
        } else if (i + 1 < l && s[i] == '0' && (s[i+1] == 'b' || s[i+1] == 'B')) {
            radix = 2; i += 2;
        } else if (i + 1 < l && s[i] == '0' && s[i+1] >= '0' && s[i+1] <= '9') {
            /* Leading 0 followed by digits — modern JS treats as base 10. */
            radix = 10;
        } else {
            radix = 10;
        }
    } else {
        /* If radix is 16 and string has "0x" prefix, skip it. */
        if (radix == 16 && i + 1 < l && s[i] == '0' && (s[i+1] == 'x' || s[i+1] == 'X')) {
            i += 2;
        }
    }
    if (i >= l) return MJS_MAKE_INT(0);

    /* Parse digits in given radix. */
    int32_t v32 = 0;
    int got_digit = 0;
    while (i < l) {
        char c = s[i];
        int dv;
        if (c >= '0' && c <= '9') dv = c - '0';
        else if (c >= 'a' && c <= 'z') dv = c - 'a' + 10;
        else if (c >= 'A' && c <= 'Z') dv = c - 'A' + 10;
        else break;
        if (dv >= radix) break;
        v32 = v32 * radix + dv;
        got_digit = 1;
        i++;
    }
    if (!got_digit) return MJS_MAKE_INT(0);
    /* T51-fix: clamp to fixed24.8's representable integer range
     * [-2097152, 2097151] before the <<8 shift — otherwise values
     * above 2097151 land with their sign bit in the int30 tag region
     * and decode back as negative (parseInt("9999999") → -1). */
    {
        int32_t scaled = sign * v32;
        if (scaled > 2097151) scaled = 2097151;
        if (scaled < -2097152) scaled = -2097152;
        return MJS_MAKE_INT(scaled << 8);  /* shift to fixed24.8 */
    }
}
static MJSValue js_keys(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    /* Buttons active LOW (pull-up).  Return bit=1 when pressed. */
    uint8_t v = mcp_readReg(0x12);  /* GPIOA */
    return mjs_int((int32_t)(~v & 0xFF));
}
/* T50: edge-detecting button reads for games.
 *   keys()         → current state (level)
 *   keysPressed()  → bits that went 0→1 since last call (rising edge / just pressed)
 *   keysReleased() → bits that went 1→0 since last call (falling edge / just released)
 * Each call updates the saved previous state, so call exactly once per frame. */
static uint8_t g_prev_keys = 0;
static MJSValue js_keys_pressed(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    uint8_t cur = ~mcp_readReg(0x12) & 0xFF;
    uint8_t pressed = cur & ~g_prev_keys;  /* 0→1 transitions */
    g_prev_keys = cur;
    return mjs_int((int32_t)pressed);
}
static MJSValue js_keys_released(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    uint8_t cur = ~mcp_readReg(0x12) & 0xFF;
    uint8_t released = g_prev_keys & ~cur;  /* 1→0 transitions */
    g_prev_keys = cur;
    return mjs_int((int32_t)released);
}
static MJSValue js_backlight(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 1) return MJS_UNDEF_V;
    int32_t v = mjs_to_int(ctx, argv[0]);
    if (v < 0) v = 0; if (v > 4095) v = 4095;
    dac_write((uint16_t)v, false);
    return MJS_UNDEF_V;
}

/* xorshift64* — same as T25 */
static uint64_t g_rng = 1;
static MJSValue js_rand(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    uint64_t x = g_rng;
    x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
    g_rng = x;
    uint64_t v = x * 0x2545F4914F6CDD1DULL;
    /* T51-fix: Return int in [0, 2^29).
     * Old code masked with 0x3FFFFFFF (30 bits) and called mjs_int — but
     * mjs_int stores the value in int30 (signed 30-bit), where values
     * >= 2^29 alias with negative numbers (since the sign bit is bit 29).
     * Concretely: rand() returned 0..2^30-1, but values in
     * [2^29, 2^30-1] were decoded back as negative integers
     * (e.g. `rand() % 10` could yield -1..-9 instead of 0..9).
     * Masking to 0x1FFFFFFF (29 bits) guarantees a non-negative int30. */
    return mjs_int((int32_t)((v >> 34) & 0x1FFFFFFF));
}

/* T51: hexToColor(hex) — convert hex color string to nearest palette index.
 * hex is like "#FF8800" or "FF8800".  Returns palette index 0-255. */
static MJSValue js_hexToColor(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !mjs_is_string(ctx, argv[0])) return mjs_int(0);
    size_t len; const char *s = mjs_to_cstr(ctx, argv[0], &len);
    /* Parse hex — skip leading # */
    const char *hex = s;
    if (len > 0 && hex[0] == '#') { hex++; len--; }
    if (len < 6) return mjs_int(0);
    auto h2 = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return 0;
    };
    int r = h2(hex[0]) * 16 + h2(hex[1]);
    int g = h2(hex[2]) * 16 + h2(hex[3]);
    int b = h2(hex[4]) * 16 + h2(hex[5]);
    /* Find nearest palette entry.  Use palette_get to read RGB565 from PROGMEM,
     * convert back to RGB, compute distance. */
    int bestIdx = 0, bestDist = 0x7FFFFFFF;
    for (int i = 0; i < 256; i++) {
        uint16_t c = palette_get((uint8_t)i);
        /* Unpack RGB565 (note: stored with channel rotation, but for
         * nearest-match we compare raw values — rotation doesn't affect
         * distance ordering since all entries use the same rotation) */
        int pr = (c >> 11) & 0x1F;
        int pg = (c >> 5) & 0x3F;
        int pb = c & 0x1F;
        /* Expand to 8-bit */
        pr = (pr << 3) | (pr >> 2);
        pg = (pg << 2) | (pg >> 4);
        pb = (pb << 3) | (pb >> 2);
        int dr = pr - r, dg = pg - g, db = pb - b;
        int dist = dr*dr + dg*dg + db*db;
        if (dist < bestDist) { bestDist = dist; bestIdx = i; }
    }
    return mjs_int(bestIdx);
}

/* T51: colorToHex(idx) — convert palette index to hex string "#RRGGBB". */
static MJSValue js_colorToHex(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1) return mjs_new_string(ctx, "#000000", 7);
    int idx = mjs_to_int(ctx, argv[0]) & 0xFF;
    uint16_t c = palette_get((uint8_t)idx);
    /* Unpack RGB565 (stored with channel rotation macro, but palette_get
     * returns the raw value — we unpack as standard RGB565) */
    int r = (c >> 11) & 0x1F;
    int g = (c >> 5) & 0x3F;
    int b = c & 0x1F;
    /* Expand to 8-bit */
    r = (r << 3) | (r >> 2);
    g = (g << 2) | (g >> 4);
    b = (b << 3) | (b >> 2);
    char buf[8];
    snprintf(buf, sizeof(buf), "#%02X%02X%02X", r, g, b);
    return mjs_new_string(ctx, buf, 7);
}

/* ---- tft.* methods ---- */
/* These write directly to g_framebuffer (defined in espboy_display.h)
 * and mark the affected rows dirty for the next display_tick(). */

static uint8_t jsColorVal(MJSContext *ctx, MJSValue v) {
    return (uint8_t)(mjs_to_int(ctx, v) & 0xFF);
}
static int32_t jsInt(MJSContext *ctx, MJSValue v) {
    return mjs_to_int(ctx, v);
}

static void fb_cls() {
    memset(g_framebuffer, 0, FB_SIZE);
    display_mark_all_dirty();
}
static void fb_fill(uint8_t c) {
    memset(g_framebuffer, c, FB_SIZE);
    display_mark_all_dirty();
}
static inline void fb_pixel(int x, int y, uint8_t c) {
    if ((unsigned)x >= FB_W || (unsigned)y >= FB_H) return;
    g_framebuffer[y * FB_W + x] = c;
    display_mark_dirty_rows(y, y);
}
static uint8_t fb_getpixel(int x, int y) {
    if ((unsigned)x >= FB_W || (unsigned)y >= FB_H) return 0;
    return g_framebuffer[y * FB_W + x];
}
static void fb_rect(int x, int y, int w, int h, uint8_t c) {
    if (w <= 0 || h <= 0) return;
    int x1 = x + w - 1, y1 = y + h - 1;
    for (int xi = x; xi <= x1; xi++) { fb_pixel(xi, y, c); fb_pixel(xi, y1, c); }
    for (int yi = y; yi <= y1; yi++) { fb_pixel(x, yi, c); fb_pixel(x1, yi, c); }
}
static void fb_fill_rect(int x, int y, int w, int h, uint8_t c) {
    if (w <= 0 || h <= 0) return;
    int x1 = x + w - 1, y1 = y + h - 1;
    if (x < 0) x = 0; if (y < 0) y = 0;
    if (x1 >= FB_W) x1 = FB_W - 1; if (y1 >= FB_H) y1 = FB_H - 1;
    for (int yi = y; yi <= y1; yi++) {
        memset(&g_framebuffer[yi * FB_W + x], c, x1 - x + 1);
    }
    display_mark_dirty_rows(y, y1);
}
static void fb_line(int x0, int y0, int x1, int y1, uint8_t c) {
    /* Bresenham. */
    int dx = abs(x1 - x0), dy = -abs(y1 - y0);
    int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        fb_pixel(x0, y0, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}
static void fb_circle(int cx, int cy, int r, uint8_t c) {
    if (r <= 0) { fb_pixel(cx, cy, c); return; }
    int x = r, y = 0, err = 1 - r;
    while (x >= y) {
        fb_pixel(cx + x, cy + y, c); fb_pixel(cx - x, cy + y, c);
        fb_pixel(cx + x, cy - y, c); fb_pixel(cx - x, cy - y, c);
        fb_pixel(cx + y, cy + x, c); fb_pixel(cx - y, cy + x, c);
        fb_pixel(cx + y, cy - x, c); fb_pixel(cx - y, cy - x, c);
        y++; if (err < 0) err += 2 * y + 1;
        else { x--; err += 2 * (y - x) + 1; }
    }
}
static void fb_disc(int cx, int cy, int r, uint8_t c) {
    if (r <= 0) { fb_pixel(cx, cy, c); return; }
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        int y = cy + dy;
        if ((unsigned)y >= FB_H) continue;
        int x0 = cx - dx, x1 = cx + dx;
        if (x0 < 0) x0 = 0; if (x1 >= FB_W) x1 = FB_W - 1;
        if (x0 <= x1) {
            memset(&g_framebuffer[y * FB_W + x0], c, x1 - x0 + 1);
        }
    }
    int y0 = cy - r, y1 = cy + r;
    if (y0 < 0) y0 = 0; if (y1 >= FB_H) y1 = FB_H - 1;
    display_mark_dirty_rows(y0, y1);
}

/* Simple 5x7 text renderer using the font in espboy_font_a.h. */
#include "espboy_font_a.h"
static void fb_text(int x, int y, const char *s, size_t len, uint8_t c, int scale) {
    if (scale < 1) scale = 1; if (scale > 4) scale = 4;
    int cx = x;
    for (size_t i = 0; i < len; i++) {
        /* T50: early exit once we're past the right edge — without this,
         * long strings still iterate every glyph and call fb_pixel
         * (which no-ops) burning CPU.  Matters for tight game loops. */
        if (cx >= FB_W) break;
        unsigned char ch = (unsigned char)s[i];
        for (int gx = 0; gx < 5; gx++) {
            uint8_t col = pgm_read_byte(&g_font_a[ch][gx]);
            for (int gy = 0; gy < 7; gy++) {
                if (col & (1 << gy)) {
                    int px = cx + gx * scale;
                    int py = y + gy * scale;
                    for (int sy = 0; sy < scale; sy++)
                        for (int sx = 0; sx < scale; sx++)
                            fb_pixel(px + sx, py + sy, c);
                }
            }
        }
        cx += 6 * scale;
    }
}
/* Convenience overload: NUL-terminated C string. */
static inline void fb_text(int x, int y, const char *s, uint8_t c, int scale) {
    fb_text(x, y, s, strlen(s), c, scale);
}

static MJSValue js_tft_cls(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    fb_cls();
    return MJS_UNDEF_V;
}
static MJSValue js_tft_fill(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1) return MJS_UNDEF_V;
    fb_fill(jsColorVal(ctx, argv[0]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_pixel(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 3) return MJS_UNDEF_V;
    fb_pixel(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
             jsColorVal(ctx, argv[2]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_rect(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 5) return MJS_UNDEF_V;
    fb_rect(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
            jsInt(ctx, argv[2]), jsInt(ctx, argv[3]),
            jsColorVal(ctx, argv[4]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_fillRect(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 5) return MJS_UNDEF_V;
    fb_fill_rect(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
                 jsInt(ctx, argv[2]), jsInt(ctx, argv[3]),
                 jsColorVal(ctx, argv[4]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_line(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 5) return MJS_UNDEF_V;
    fb_line(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
            jsInt(ctx, argv[2]), jsInt(ctx, argv[3]),
            jsColorVal(ctx, argv[4]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_circle(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 4) return MJS_UNDEF_V;
    fb_circle(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
              jsInt(ctx, argv[2]), jsColorVal(ctx, argv[3]));
    return MJS_UNDEF_V;
}
static MJSValue js_tft_disc(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 4) return MJS_UNDEF_V;
    fb_disc(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
            jsInt(ctx, argv[2]), jsColorVal(ctx, argv[3]));
    return MJS_UNDEF_V;
}
/* T51: Current font for tft.text — 0=5x7 (default), 1=Tiny5 (compact). */
static uint8_t g_tft_font = 0;

static MJSValue js_tft_text(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 4) return MJS_UNDEF_V;
    size_t len;
    const char *s = mjs_to_cstr(ctx, argv[2], &len);
    int32_t size = argc >= 5 ? jsInt(ctx, argv[4]) : 1;
    if (g_tft_font == 1) {
        /* Tiny5 compact font. */
        fb_text_small(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
                      s, jsColorVal(ctx, argv[3]), (int)size);
    } else {
        /* Default 5x7 font. */
        fb_text(jsInt(ctx, argv[0]), jsInt(ctx, argv[1]),
                s, (uint16_t)len, jsColorVal(ctx, argv[3]), (int)size);
    }
    return MJS_UNDEF_V;
}
/* T51: tft.setFont(fontId) — 0=5x7 default, 1=Tiny5 compact. */
static MJSValue js_tft_setFont(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 1) return MJS_UNDEF_V;
    g_tft_font = (uint8_t)jsInt(ctx, argv[0]);
    return MJS_UNDEF_V;
}
static MJSValue js_tft_width(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    return mjs_int((int32_t)FB_W);
}
static MJSValue js_tft_height(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    return mjs_int((int32_t)FB_H);
}
static MJSValue js_tft_getpixel(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 2) return mjs_int(0);
    return mjs_int((int32_t)fb_getpixel(jsInt(ctx, argv[0]),
                                        jsInt(ctx, argv[1])));
}
static MJSValue js_tft_flip(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx; (void)argc; (void)argv;
    display_mark_all_dirty();
    return MJS_UNDEF_V;
}

/* tft.sprite(x, y, w, h, colors) — blit palette indices to framebuffer.
 * colors is an array of w*h palette indices (0..255). */
static MJSValue js_tft_sprite(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 5) return MJS_UNDEF_V;
    int32_t x = mjs_to_int(ctx, argv[0]);
    int32_t y = mjs_to_int(ctx, argv[1]);
    int32_t w = mjs_to_int(ctx, argv[2]);
    int32_t h = mjs_to_int(ctx, argv[3]);
    if (w <= 0 || h <= 0) return MJS_UNDEF_V;
    int32_t y_min = y, y_max = y + h - 1;
    int32_t i = 0;
    for (int32_t row = 0; row < h; row++) {
        int py = y + row;
        for (int32_t col = 0; col < w; col++) {
            MJSValue elem = mjs_get_index(ctx, argv[4], (int)i++);
            uint8_t c = (uint8_t)(mjs_to_int(ctx, elem) & 0xFF);
            fb_pixel(x + col, py, c);
        }
    }
    if (y_min < 0) y_min = 0;
    if (y_max >= FB_H) y_max = FB_H - 1;
    display_mark_dirty_rows(y_min, y_max);
    return MJS_UNDEF_V;
}

/* tft.spriteMask(x, y, w, h, colors, mask) — like sprite but skip pixels
 * where color == mask. */
static MJSValue js_tft_spriteMask(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 6) return MJS_UNDEF_V;
    int32_t x = mjs_to_int(ctx, argv[0]);
    int32_t y = mjs_to_int(ctx, argv[1]);
    int32_t w = mjs_to_int(ctx, argv[2]);
    int32_t h = mjs_to_int(ctx, argv[3]);
    if (w <= 0 || h <= 0) return MJS_UNDEF_V;
    uint8_t mask = (uint8_t)(mjs_to_int(ctx, argv[5]) & 0xFF);
    int32_t y_min = y, y_max = y + h - 1;
    int32_t i = 0;
    for (int32_t row = 0; row < h; row++) {
        int py = y + row;
        for (int32_t col = 0; col < w; col++) {
            MJSValue elem = mjs_get_index(ctx, argv[4], (int)i++);
            uint8_t c = (uint8_t)(mjs_to_int(ctx, elem) & 0xFF);
            if (c != mask) fb_pixel(x + col, py, c);
        }
    }
    if (y_min < 0) y_min = 0;
    if (y_max >= FB_H) y_max = FB_H - 1;
    display_mark_dirty_rows(y_min, y_max);
    return MJS_UNDEF_V;
}

/* ============================================================
 * Timer wheel — setTimeout / setInterval / clearTimeout
 * ============================================================
 *
 * Up to MJS_MAX_TIMERS concurrent timers.  Each holds a JS callback
 * (MJSValue pointing to a MJSFuncObj) that survives across loop()
 * iterations.  The timers are checked in loop() after mjs_run()
 * returns.  When a timer fires, we call mjs_call_value() to invoke
 * the JS callback.
 *
 * IMPORTANT: timers are bound to the g_ctx that was active when they
 * were registered.  When /run re-inits g_ctx, all timers are cleared
 * (because the old MJSFuncObj pointers are no longer valid).
 */

/* T51: MJS_MAX_TIMERS, MJSTimer, and g_timers[] are now defined
 * earlier in the file (before js_gc) so that js_gc's diagnostic
 * logging can reference them.  See line ~554. */

/* T50: GC root walker — marks all active timer callbacks as reachable
 * so a manual gc() or OOM-triggered sweep doesn't free a MJSFuncObj
 * that's still in g_timers[].  Without this, the timer would fire
 * after the callback was freed, causing use-after-free / hard fault.
 *
 * T51: Also marks g_js_http_handler so the HTTP request callback
 * survives GC between http.onRequest() and the actual HTTP request. */
static void gc_walk_timers(MJSContext *ctx, void *user_data) {
    (void)user_data;
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (g_timers[i].active) {
            mjs_mark_value(ctx, g_timers[i].cb);
        }
    }
    /* T51: Mark JS HTTP handler as GC root. */
    if (g_js_http_active && g_js_http_handler != MJS_UNDEF_V) {
        mjs_mark_value(ctx, g_js_http_handler);
    }
}

static void timers_clear_all() {
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        g_timers[i].active = 0;
        g_timers[i].cb = MJS_UNDEF_V;
    }
}

static int timers_has_pending() {
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (g_timers[i].active) return 1;
    }
    return 0;
}

/* T51: Re-entrancy guard — prevents timers_tick() from being called
 * recursively when a timer callback itself calls millis() (which calls
 * timers_tick()).  Without this, deep recursion can corrupt VM state. */
static bool g_timers_firing = false;

/* Fire any due timers.  Returns the number of timers fired. */
static int timers_tick() {
    if (!g_ctx) return 0;
    if (g_timers_firing) return 0;  /* don't re-enter */
    g_timers_firing = true;
    uint32_t now = millis();
    int fired = 0;
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (!g_timers[i].active) continue;
        int32_t diff = (int32_t)(g_timers[i].due - now);
        if (diff > 0) continue;
        /* Timer is due — fire it. */
        MJSValue cb = g_timers[i].cb;
        if (g_timers[i].interval == 0) {
            /* one-shot — deactivate before callback (so callback can
             * register a new timer in this slot if it wants) */
            g_timers[i].active = 0;
        } else {
            /* repeating — schedule next fire */
            g_timers[i].due = now + g_timers[i].interval;
        }
        /* Invoke the JS callback.  Ignore return value. */
        mjs_call_value(g_ctx, cb, 0, NULL);
        fired++;
        /* T51: If the callback halted with an error, report it to Serial
         * and output buffer (so it appears in the web UI), then stop. */
        if (g_ctx->has_error) {
            const char *err = mjs_last_error(g_ctx);
            Serial.print(F("[timer error] "));
            Serial.println(err);
            /* Also append to output buffer so web UI shows it. */
            String msg = "[timer error] ";
            msg += err;
            msg += "\n";
            out_append(msg.c_str(), msg.length());
            break;
        }
    }
    g_timers_firing = false;
    return fired;
}

static MJSValue js_setTimeout(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2) return MJS_UNDEF_V;
    int32_t ms = mjs_to_int(ctx, argv[1]);
    if (ms < 0) ms = 0;
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (!g_timers[i].active) {
            g_timers[i].cb = argv[0];
            g_timers[i].due = millis() + (uint32_t)ms;
            g_timers[i].interval = 0;
            g_timers[i].active = 1;
            return mjs_int(i + 1);  /* timer id 1..N */
        }
    }
    return MJS_UNDEF_V;  /* no free slot */
}

static MJSValue js_setInterval(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 2) return MJS_UNDEF_V;
    int32_t ms = mjs_to_int(ctx, argv[1]);
    if (ms < 0) ms = 0;
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        if (!g_timers[i].active) {
            g_timers[i].cb = argv[0];
            g_timers[i].due = millis() + (uint32_t)ms;
            g_timers[i].interval = (uint32_t)ms;
            g_timers[i].active = 1;
            return mjs_int(i + 1);
        }
    }
    return MJS_UNDEF_V;
}

static MJSValue js_clearTimer(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)ctx;
    if (argc < 1) return MJS_UNDEF_V;
    int32_t id = mjs_to_int(ctx, argv[0]);
    if (id < 1 || id > MJS_MAX_TIMERS) return MJS_UNDEF_V;
    g_timers[id - 1].active = 0;
    return MJS_UNDEF_V;
}

/* ---- Register all natives + tft object ---- */
static void register_natives() {
    MJSContext *ctx = g_ctx;
    mjs_register_global(ctx, "print",        js_print);
    mjs_register_global(ctx, "millis",       js_millis);
    mjs_register_global(ctx, "seconds",      js_seconds);
    mjs_register_global(ctx, "centis",       js_centis);
    mjs_register_global(ctx, "delay",        js_delay);
    mjs_register_global(ctx, "mem",          js_mem);
    mjs_register_global(ctx, "jsmem",        js_jsmem);
    mjs_register_global(ctx, "gc",           js_gc);
    mjs_register_global(ctx, "reset",        js_reset);   /* T51: reboot ESP */
    mjs_register_global(ctx, "fetch",        js_fetch);         /* T51: HTTP client (buffered + streaming) */
    mjs_register_global(ctx, "jsonSelect",   js_json_select);   /* T51: selective JSON field extractor */
    mjs_register_global(ctx, "jsonStream",   js_json_stream);   /* T51: streaming JSON SAX parser */
    mjs_register_global(ctx, "parseInt",     js_parseInt); /* T51: parseInt(s) */
    mjs_register_global(ctx, "isNaN",        js_isNaN);   /* T51: isNaN(v) */
    mjs_register_global(ctx, "getIP",        js_getIP);   /* T51: getIP() → "192.168.x.x" */
    mjs_register_global(ctx, "beep",         js_beep);     /* T51: beep(freq, duration) */
    mjs_register_global(ctx, "gcDebug",      js_gcDebug);  /* T51-debug: GC stats */
    mjs_register_global(ctx, "gcRoots",      js_gcRoots);  /* T51-debug: GC roots dump */
    mjs_register_global(ctx, "keys",         js_keys);
    mjs_register_global(ctx, "keysPressed",  js_keys_pressed);   /* T50: edge detect */
    mjs_register_global(ctx, "keysReleased", js_keys_released);  /* T50: edge detect */
    mjs_register_global(ctx, "backlight",    js_backlight);
    mjs_register_global(ctx, "rand",         js_rand);
    mjs_register_global(ctx, "hexToColor",   js_hexToColor);   /* T51: hex→palette idx */
    mjs_register_global(ctx, "colorToHex",   js_colorToHex);   /* T51: palette idx→hex */
    mjs_register_global(ctx, "setTimeout",   js_setTimeout);
    mjs_register_global(ctx, "setInterval",  js_setInterval);
    mjs_register_global(ctx, "clearTimeout", js_clearTimer);
    mjs_register_global(ctx, "clearInterval", js_clearTimer);

    /* T51: global PI constant (same value as Math.PI for convenience).
     * MJS_MAKE_INT(804) stores raw fixed24.8 value 804 = 3.140625 ≈ π.
     * Note: mjs_set_global_value requires the atom "PI" to exist in the
     * bytecode — it will be created automatically if the JS code uses PI.
     * If a script doesn't reference PI, the global won't be set (which
     * is fine — JS would return undefined for missing globals anyway). */
    mjs_set_global_value(ctx, "PI", MJS_MAKE_INT(804));

    /* console.log = print */
    MJSValue console_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, console_obj, "log",   mjs_new_cfunction(ctx, js_print, "log"));
    mjs_set_property(ctx, console_obj, "warn",  mjs_new_cfunction(ctx, js_print, "warn"));
    mjs_set_property(ctx, console_obj, "error", mjs_new_cfunction(ctx, js_print, "error"));
    mjs_set_property(ctx, console_obj, "info",  mjs_new_cfunction(ctx, js_print, "info"));
    mjs_set_global_value(ctx, "console", console_obj);

    /* Math object — common functions using fixed24.8 */
    MJSValue math_obj = mjs_new_object(ctx);
    /* T50: Math.PI as proper fixed24.8 (3.140625 ≈ 3.14159).
     * 804 = (3 << 8) + round(0.14159 * 256) = 768 + 36 = 804.
     * MJS_MAKE_INT(i) = (i << 2) | TAG_INT, so passing 804 stores
     * the raw fixed value 804 which the VM interprets as 3.14. */
    mjs_set_property(ctx, math_obj, "PI", MJS_MAKE_INT(804));
    /* Math.E ≈ 2.71828 → (2 << 8) + round(0.71828 * 256) = 512 + 184 = 696 */
    mjs_set_property(ctx, math_obj, "E",  MJS_MAKE_INT(696));
    /* Math.floor — extract integer part: val >> 8 << 8 (clear fractional) */
    mjs_set_property(ctx, math_obj, "floor",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t v = MJS_GET_INT(argv[0]);
            v = v & ~0xFF;  /* clear fractional part */
            return MJS_MAKE_INT(v);
        }, "floor"));
    /* Math.round — round to nearest integer */
    mjs_set_property(ctx, math_obj, "round",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t v = MJS_GET_INT(argv[0]);
            v = (v + 128) & ~0xFF;  /* round +0.5 then truncate */
            return MJS_MAKE_INT(v);
        }, "round"));
    /* Math.abs */
    mjs_set_property(ctx, math_obj, "abs",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t v = MJS_GET_INT(argv[0]);
            return MJS_MAKE_INT(v < 0 ? -v : v);
        }, "abs"));
    /* Math.min */
    mjs_set_property(ctx, math_obj, "min",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2) return MJS_UNDEF_V;
            int32_t a = MJS_GET_INT(argv[0]), b = MJS_GET_INT(argv[1]);
            return MJS_MAKE_INT(a < b ? a : b);
        }, "min"));
    /* Math.max */
    mjs_set_property(ctx, math_obj, "max",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2) return MJS_UNDEF_V;
            int32_t a = MJS_GET_INT(argv[0]), b = MJS_GET_INT(argv[1]);
            return MJS_MAKE_INT(a > b ? a : b);
        }, "max"));
    /* Math.random — returns fixed24.8 in [0.0, 1.0) */
    mjs_set_property(ctx, math_obj, "random",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            (void)c; (void)argc; (void)argv;
            uint64_t x = g_rng;
            x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
            g_rng = x;
            uint64_t v = x * 0x2545F4914F6CDD1DULL;
            /* Return fixed24.8 in [0, 1.0): value 0..255 */
            return MJS_MAKE_INT((int32_t)(v >> 56) & 0xFF);
        }, "random"));
    /* T51: Math.pow(base, exp) — integer power via repeated multiplication.
     * Works in fixed24.8: base and exp are fixed values.  exp is truncated
     * to integer.  Returns fixed24.8.  Negative exp returns 1 (approximation).
     * Overflow clamped to MJS_FIXED_MAX. */
    mjs_set_property(ctx, math_obj, "pow",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !MJS_IS_INT(argv[0]) || !MJS_IS_INT(argv[1])) return MJS_UNDEF_V;
            int32_t base = MJS_GET_INT(argv[0]);    /* raw fixed24.8 */
            int32_t expI = MJS_GET_INT(argv[1]) >> 8;  /* integer part of exp */
            if (expI < 0) expI = 0;  /* negative exp → 1 (base^0) */
            if (expI > 20) expI = 20;  /* limit to prevent overflow */
            /* result = base^exp in fixed24.8.  Each multiply is fixed*fixed>>8. */
            int64_t result = 256;  /* 1.0 in fixed24.8 */
            for (int i = 0; i < expI; i++) {
                result = (result * base) >> 8;
                if (result > 0x7FFFFFFF) { result = 0x7FFFFFFF; break; }
                if (result < -0x80000000) { result = -0x80000000; break; }
            }
            int32_t ri = (int32_t)result;
            MJS_CLAMP_FIXED(ri);
            return MJS_MAKE_INT(ri);
        }, "pow"));
    /* T51: Math.sqrt(x) — integer square root in fixed24.8.
     * Uses Newton's method on the raw fixed24.8 value.
     * sqrt(x) in fixed24.8 = isqrt(x << 8) — i.e. compute integer sqrt
     * of (x << 8) to get the result in fixed24.8 format.
     * x is raw fixed24.8 (e.g. 4.0 = 1024).  sqrt(4.0) = 2.0 = 512.
     * So we compute isqrt(x * 256) = isqrt(x << 8). */
    mjs_set_property(ctx, math_obj, "sqrt",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t x = MJS_GET_INT(argv[0]);  /* raw fixed24.8 */
            if (x < 0) return MJS_MAKE_INT(0);
            if (x == 0) return MJS_MAKE_INT(0);
            /* We want sqrt(x/256) * 256 = sqrt(x*256).
             * x is already fixed24.8 (x/256 = real value).
             * sqrt(real) * 256 = sqrt(real * 256*256) = sqrt(x * 256).
             * So compute integer sqrt of (x << 8) = x * 256. */
            uint64_t v = (uint64_t)x << 8;
            if (v == 0) return MJS_MAKE_INT(0);
            /* Newton's method for integer square root */
            uint64_t x0 = v;
            uint64_t x1 = (x0 + v / x0) / 2;
            while (x1 < x0) {
                x0 = x1;
                x1 = (x0 + v / x0) / 2;
            }
            int32_t ri = (int32_t)x0;
            MJS_CLAMP_FIXED(ri);
            return MJS_MAKE_INT(ri);
        }, "sqrt"));
    /* T51: Math.sin/cos/tan/atan2 — fast approximations using lookup table.
     * Input/output in fixed24.8 radians.  Uses a 256-entry sin table
     * covering [0, 2*PI).  Accuracy: ~2 decimal digits. */

    /* Precompute sin table: sin_table[i] = sin(i/256 * 2*PI) * 256 (fixed24.8). */
    static int16_t g_sin_table[256];
    static bool g_sin_table_init = false;
    if (!g_sin_table_init) {
        for (int i = 0; i < 256; i++) {
            float a = (float)i / 256.0f * 2.0f * 3.14159265f;
            g_sin_table[i] = (int16_t)(sinf(a) * 256.0f);
        }
        g_sin_table_init = true;
    }

    /* Helper: angle in fixed24.8 → table index [0..255] */
    #define MJS_ANGLE_TO_IDX(angle) ({ \
        int32_t _a = (angle); \
        _a = _a % 1608; \
        if (_a < 0) _a += 1608; \
        (int)((int64_t)_a * 256 / 1608); })

    mjs_set_property(ctx, math_obj, "sin",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t angle = MJS_GET_INT(argv[0]);
            int idx = MJS_ANGLE_TO_IDX(angle);
            return MJS_MAKE_INT((int32_t)g_sin_table[idx]);
        }, "sin"));
    mjs_set_property(ctx, math_obj, "cos",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t angle = MJS_GET_INT(argv[0]);
            int idx = MJS_ANGLE_TO_IDX(angle);
            idx = (idx + 64) & 255;
            return MJS_MAKE_INT((int32_t)g_sin_table[idx]);
        }, "cos"));
    mjs_set_property(ctx, math_obj, "tan",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !MJS_IS_INT(argv[0])) return MJS_UNDEF_V;
            int32_t angle = MJS_GET_INT(argv[0]);
            int idx = MJS_ANGLE_TO_IDX(angle);
            int32_t s = g_sin_table[idx];
            int32_t co = g_sin_table[(idx + 64) & 255];
            if (co == 0) return MJS_MAKE_INT(0);
            int32_t r = (s << 8) / co;
            MJS_CLAMP_FIXED(r);
            return MJS_MAKE_INT(r);
        }, "tan"));
    mjs_set_property(ctx, math_obj, "atan2",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !MJS_IS_INT(argv[0]) || !MJS_IS_INT(argv[1])) return MJS_UNDEF_V;
            int32_t y = MJS_GET_INT(argv[0]);
            int32_t x = MJS_GET_INT(argv[1]);
            if (x == 0 && y == 0) return MJS_MAKE_INT(0);
            int64_t r2 = (int64_t)x * x + (int64_t)y * y;
            if (r2 == 0) return MJS_MAKE_INT(0);
            uint64_t v = (uint64_t)(r2 >> 8);
            uint64_t x0 = v;
            uint64_t x1 = (x0 + v / x0) / 2;
            while (x1 < x0) { x0 = x1; x1 = (x0 + v / x0) / 2; }
            int32_t r = (int32_t)x0;
            if (r == 0) return MJS_MAKE_INT(0);
            int32_t sin_val = (int32_t)((int64_t)y * 256 / r);
            if (sin_val > 256) sin_val = 256;
            if (sin_val < -256) sin_val = -256;
            int best_idx = 0, best_err = 99999;
            for (int i = 0; i < 256; i++) {
                int err = abs((int)g_sin_table[i] - sin_val);
                if (err < best_err) { best_err = err; best_idx = i; }
            }
            int32_t angle = (int32_t)((int64_t)best_idx * 1608 / 256);
            if (x < 0) {
                if (y >= 0) angle = 804 - angle;
                else angle = angle - 804;
            } else if (y < 0) {
                angle = angle + 1608;
            }
            return MJS_MAKE_INT(angle);
        }, "atan2"));
    mjs_set_global_value(ctx, "Math", math_obj);

    /* Array methods — push, slice, forEach, isArray */
    MJSValue arr_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, arr_obj, "push",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            /* T51: Support multiple arguments: Array.push(arr, v1, v2, v3).
             * T51-fix: Suppress compaction during the entire push operation.
             *
             * When mjs_set_index grows an array, it calls mjs_alloc which may
             * trigger heap compaction.  Compaction moves ALL live blocks and
             * updates MJSValue fields in globals/locals/stack/compact-roots.
             * BUT argv_buf (in OP_CALL/OP_CALL_WITH_THIS) is a C local variable
             * that compaction does NOT update.  Even with compact roots, the
             * interaction between compaction (moving blocks) and the grow logic
             * (allocating new blocks, copying data, updating references) is
             * extremely fragile and leads to:
             *   - Stale pointers in argv_buf
             *   - Overlapping block addresses (new block allocated inside
             *     the space vacated by compaction of an old block)
             *   - Global references pointing to wrong blocks
             *
             * By suppressing compaction, mjs_alloc will use the bump allocator
             * (or free list without compacting).  GC (mark-and-sweep) still
             * runs — only compaction is suppressed.  This is safe because:
             *   - The bump allocator has enough space (48KB JS heap on ESP32)
             *   - GC reclaims unreachable blocks between pushes
             *   - Compaction is only needed when the heap is severely
             *     fragmented, which is rare for typical programs
             *
             * The same pattern is used by mjs_load_bytecode and json_node_to_mjs
             * which also hold raw pointers across mjs_alloc calls. */
            if (argc < 2 || !mjs_is_array(c, argv[0])) return mjs_int(0);
            bool prev_no_compact = mjs_no_compact;
            mjs_no_compact = true;
            for (int i = 1; i < argc; i++) {
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
                MJSArray *a = (MJSArray*)h;
                int newIdx = a->length;
                mjs_set_index(c, argv[0], newIdx, argv[i]);
                if (c->_array_grown) {
                    MJSValue new_arr = c->_grown_array;
                    c->_array_grown = 0;
                    c->_grown_array = 0;
                    /* argv[0] is valid (no compaction ran).  Scan globals,
                     * locals, and stack for the OLD array value and replace
                     * with the NEW grown array. */
                    MJSValue old_val = argv[0];
                    argv[0] = new_arr;
                    for (uint16_t gi = 0; gi < c->global_count; gi++) {
                        if (c->global_vals[gi] == old_val) {
                            c->global_vals[gi] = new_arr;
                            break;
                        }
                    }
                    for (int li = 0; li < MJS_LOCALS_MAX; li++) {
                        if (c->locals[li] == old_val) {
                            c->locals[li] = new_arr;
                            break;
                        }
                    }
                    MJSValue *stack_end = (MJSValue*)c->buf_end;
                    for (MJSValue *p = c->sp; p < stack_end; p++) {
                        if (*p == old_val) *p = new_arr;
                    }
                }
            }
            mjs_no_compact = prev_no_compact;
            MJSHeader *h2 = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a2 = (MJSArray*)h2;
            return mjs_int((int32_t)a2->length);
        }, "push"));
    mjs_set_property(ctx, arr_obj, "isArray",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return mjs_bool(argc >= 1 && mjs_is_array(c, argv[0]));
        }, "isArray"));
    mjs_set_property(ctx, arr_obj, "slice",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_array(c, argv[0])) return MJS_UNDEF_V;
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a = (MJSArray*)h;
            int32_t start = argc >= 2 ? mjs_to_int(c, argv[1]) : 0;
            int32_t end = argc >= 3 ? mjs_to_int(c, argv[2]) : (int32_t)a->length;
            if (start < 0) start += a->length;
            if (end < 0) end += a->length;
            if (start < 0) start = 0;
            if (end > (int32_t)a->length) end = a->length;
            if (start > end) start = end;
            int32_t n = end - start;
            MJSValue result = mjs_new_array(c, n);
            for (int32_t i = 0; i < n; i++)
                mjs_set_index(c, result, i, mjs_get_index(c, argv[0], start + i));
            return result;
        }, "slice"));
    mjs_set_property(ctx, arr_obj, "forEach",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_array(c, argv[0]) || !mjs_is_function(c, argv[1]))
                return MJS_UNDEF_V;
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a = (MJSArray*)h;
            for (int i = 0; i < a->length; i++) {
                MJSValue cb_argv[1] = { mjs_get_index(c, argv[0], i) };
                mjs_call_value(c, argv[1], 1, cb_argv);
            }
            return MJS_UNDEF_V;
        }, "forEach"));
    /* T51: Array.indexOf(arr, val [, fromIndex]) — find first index of val, or -1 */
    mjs_set_property(ctx, arr_obj, "indexOf",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_array(c, argv[0])) return mjs_int(-1);
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a = (MJSArray*)h;
            MJSValue target = argv[1];
            /* T51: optional fromIndex (3rd arg) — standard JS API. */
            int from = (argc >= 3 && MJS_IS_INT(argv[2]))
                       ? (int)(MJS_GET_INT(argv[2]) >> 8) : 0;
            if (from < 0) from = 0;
            for (int i = from; i < a->length; i++) {
                MJSValue elem = mjs_get_index(c, argv[0], i);
                if (MJS_IS_INT(target) && MJS_IS_INT(elem)) {
                    if (MJS_GET_INT(target) == MJS_GET_INT(elem)) return mjs_int(i);
                } else if (mjs_is_string(c, target) && mjs_is_string(c, elem)) {
                    size_t la, lb; const char *sa = mjs_to_cstr(c, elem, &la);
                    const char *sb = mjs_to_cstr(c, target, &lb);
                    if (la == lb && memcmp(sa, sb, la) == 0) return mjs_int(i);
                } else if (target == elem) {
                    return mjs_int(i);
                }
            }
            return mjs_int(-1);
        }, "indexOf"));
    /* T51: Array.join(arr, sep) — join elements with separator into a string. */
    mjs_set_property(ctx, arr_obj, "join",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_array(c, argv[0])) return mjs_new_string(c, "", 0);
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a = (MJSArray*)h;
            /* Default separator is "," (JS spec).  If argv[1] is a string,
             * use it.  If argv[1] is undefined, use ",". */
            const char *sep = ",";
            size_t seplen = 1;
            if (argc >= 2 && mjs_is_string(c, argv[1])) {
                sep = mjs_to_cstr(c, argv[1], &seplen);
            }
            /* Build the joined string in a temp buffer.  Use system malloc
             * since the result can be large. */
            size_t total = 0;
            for (int i = 0; i < a->length; i++) {
                if (i > 0) total += seplen;
                MJSValue elem = mjs_get_index(c, argv[0], i);
                if (mjs_is_string(c, elem)) {
                    size_t l; mjs_to_cstr(c, elem, &l);
                    total += l;
                } else if (MJS_IS_INT(elem)) {
                    int32_t raw = MJS_GET_INT(elem);
                    bool neg = raw < 0;
                    if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
                    int32_t ip = raw >> 8;
                    int32_t fp = (raw & 0xFF) * 100 / 256;
                    char num[24];
                    if (fp == 0) snprintf(num, sizeof(num), "%s%d", neg?"-":"", (int)ip);
                    else snprintf(num, sizeof(num), "%s%d.%02d", neg?"-":"", (int)ip, (int)fp);
                    total += strlen(num);
                } else if (elem == MJS_TRUE_V) total += 4;
                else if (elem == MJS_FALSE_V) total += 5;
                else if (elem == MJS_NULL_V) total += 4;
                else if (elem == MJS_UNDEF_V) total += 0;  /* undefined → "" */
            }
            if (total == 0) return mjs_new_string(c, "", 0);
            char *buf = (char*)malloc(total + 1);
            if (!buf) return mjs_new_string(c, "", 0);
            size_t pos = 0;
            for (int i = 0; i < a->length; i++) {
                if (i > 0) { memcpy(buf + pos, sep, seplen); pos += seplen; }
                MJSValue elem = mjs_get_index(c, argv[0], i);
                if (mjs_is_string(c, elem)) {
                    size_t l; const char *s = mjs_to_cstr(c, elem, &l);
                    memcpy(buf + pos, s, l); pos += l;
                } else if (MJS_IS_INT(elem)) {
                    int32_t raw = MJS_GET_INT(elem);
                    bool neg = raw < 0;
                    if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
                    int32_t ip = raw >> 8;
                    int32_t fp = (raw & 0xFF) * 100 / 256;
                    char num[24];
                    int nlen;
                    if (fp == 0) nlen = snprintf(num, sizeof(num), "%s%d", neg?"-":"", (int)ip);
                    else nlen = snprintf(num, sizeof(num), "%s%d.%02d", neg?"-":"", (int)ip, (int)fp);
                    memcpy(buf + pos, num, nlen); pos += nlen;
                } else if (elem == MJS_TRUE_V) { memcpy(buf+pos,"true",4); pos+=4; }
                else if (elem == MJS_FALSE_V) { memcpy(buf+pos,"false",5); pos+=5; }
                else if (elem == MJS_NULL_V) { memcpy(buf+pos,"null",4); pos+=4; }
                /* undefined → "" (skip) */
            }
            buf[pos] = '\0';
            MJSValue result = mjs_new_string(c, buf, pos);
            free(buf);
            return result;
        }, "join"));
    /* T51: Array.sort(arr) — sort array in place (numeric ascending).
     * Uses simple selection sort (arrays are small on ESP8266).
     * Returns the same array (sorted in place, like JS spec). */
    mjs_set_property(ctx, arr_obj, "sort",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_array(c, argv[0])) return MJS_UNDEF_V;
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSArray *a = (MJSArray*)h;
            /* T51-fix: packed arrays (u8/u16) can't be sorted in-place
             * because sort swaps MJSValue-sized elements.  Convert to
             * a MJSValue[] array first by re-assigning each element —
             * mjs_set_index will grow/convert the array automatically.
             * But that's O(n) alloc.  Instead, sort the packed array
             * directly by reading/writing through mjs_get_index/set_index. */
            if (a->elem_size == 1) {
                /* u8 packed array — sort in place using uint8_t swaps. */
                uint8_t *items = (uint8_t*)(a + 1);
                for (int i = 0; i < a->length - 1; i++) {
                    int min_idx = i;
                    for (int j = i + 1; j < a->length; j++) {
                        if (items[j] < items[min_idx]) min_idx = j;
                    }
                    if (min_idx != i) {
                        uint8_t tmp = items[i];
                        items[i] = items[min_idx];
                        items[min_idx] = tmp;
                    }
                }
                return argv[0];
            } else if (a->elem_size == 2) {
                /* u16 packed array — sort in place using uint16_t swaps. */
                uint16_t *items = (uint16_t*)(a + 1);
                for (int i = 0; i < a->length - 1; i++) {
                    int min_idx = i;
                    for (int j = i + 1; j < a->length; j++) {
                        if (items[j] < items[min_idx]) min_idx = j;
                    }
                    if (min_idx != i) {
                        uint16_t tmp = items[i];
                        items[i] = items[min_idx];
                        items[min_idx] = tmp;
                    }
                }
                return argv[0];
            }
            /* MJSValue[] array — sort with JS-like comparison.
             * T51-fix: JS spec says sort converts everything to string
             * and sorts lexicographically.  But for all-int arrays,
             * numeric sort is more useful.  We use: if both are ints,
             * compare numerically; otherwise convert both to string
             * and compare lexicographically (matching JS behavior for
             * mixed-type arrays). */
            MJSValue *items = (MJSValue*)(a + 1);
            for (int i = 0; i < a->length - 1; i++) {
                int min_idx = i;
                for (int j = i + 1; j < a->length; j++) {
                    MJSValue vj = items[j];
                    MJSValue vm = items[min_idx];
                    int less = 0;
                    if (MJS_IS_INT(vj) && MJS_IS_INT(vm)) {
                        /* Both ints → numeric comparison. */
                        less = (MJS_GET_INT(vj) < MJS_GET_INT(vm)) ? 1 : 0;
                    } else {
                        /* Mixed types → convert both to string and compare. */
                        char bufj[24], bufm[24];
                        const char *sj, *sm;
                        size_t lj, lm;
                        if (MJS_IS_INT(vj)) {
                            int32_t raw = MJS_GET_INT(vj);
                            bool neg = raw < 0;
                            if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
                            int32_t ip = raw >> 8;
                            snprintf(bufj, sizeof(bufj), "%s%d", neg?"-":"", (int)ip);
                            sj = bufj; lj = strlen(sj);
                        } else if (mjs_is_string(c, vj)) {
                            sj = mjs_to_cstr(c, vj, &lj);
                        } else if (vj == MJS_TRUE_V) { sj = "true"; lj = 4; }
                        else if (vj == MJS_FALSE_V) { sj = "false"; lj = 5; }
                        else if (vj == MJS_NULL_V) { sj = "null"; lj = 4; }
                        else { sj = ""; lj = 0; }

                        if (MJS_IS_INT(vm)) {
                            int32_t raw = MJS_GET_INT(vm);
                            bool neg = raw < 0;
                            if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
                            int32_t ip = raw >> 8;
                            snprintf(bufm, sizeof(bufm), "%s%d", neg?"-":"", (int)ip);
                            sm = bufm; lm = strlen(sm);
                        } else if (mjs_is_string(c, vm)) {
                            sm = mjs_to_cstr(c, vm, &lm);
                        } else if (vm == MJS_TRUE_V) { sm = "true"; lm = 4; }
                        else if (vm == MJS_FALSE_V) { sm = "false"; lm = 5; }
                        else if (vm == MJS_NULL_V) { sm = "null"; lm = 4; }
                        else { sm = ""; lm = 0; }

                        size_t mlen = lj < lm ? lj : lm;
                        int cmp = memcmp(sj, sm, mlen);
                        if (cmp < 0) less = 1;
                        else if (cmp == 0 && lj < lm) less = 1;
                    }
                    if (less) min_idx = j;
                }
                if (min_idx != i) {
                    MJSValue tmp = items[i];
                    items[i] = items[min_idx];
                    items[min_idx] = tmp;
                }
            }
            return argv[0];
        }, "sort"));
    mjs_set_global_value(ctx, "Array", arr_obj);

    /* T51: Object global — for `new Object()` and instanceof checks */
    MJSValue obj_global = mjs_new_object(ctx);
    /* Object.defineProperty(obj, prop, {get: fn, set: fn}) */
    mjs_set_property(ctx, obj_global, "defineProperty",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 3 || !mjs_is_object(c, argv[0]) || !mjs_is_string(c, argv[2])) return MJS_UNDEF_V;
            /* argv[0] = obj, argv[1] = prop name (string), argv[2] = descriptor object */
            size_t plen; const char *pname = mjs_to_cstr(c, argv[1], &plen);
            uint16_t atom = mjs_atom_find(c, pname, plen);
            if (atom == 0) return MJS_UNDEF_V;
            /* Get get/set from descriptor */
            MJSValue getter = mjs_get_property(c, argv[2], "get");
            MJSValue setter = mjs_get_property(c, argv[2], "set");
            /* Create accessor */
            MJSAccessor *acc = (MJSAccessor*)mjs_alloc(c, sizeof(MJSAccessor));
            if (!acc) return MJS_UNDEF_V;
            MJS_HDR_SET_TYPE(&(acc)->hdr, MJS_T_ACCESSOR);
            acc->getter = getter;
            acc->setter = setter;
            acc->this_val = argv[0];
            MJSValue acc_val = (MJSValue)((uintptr_t)acc | TAG_PTR);
            /* Store accessor in object's slot (replaces existing value) */
            mjs_obj_set(c, argv[0], atom, acc_val);
            return argv[0];
        }, "defineProperty"));
    /* T51: Object.create(proto) — create a new object with the given prototype. */
    mjs_set_property(ctx, obj_global, "create",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            MJSValue obj = mjs_new_object(c);
            if (argc >= 1) {
                mjs_set_prototype(c, obj, argv[0]);
            }
            return obj;
        }, "create"));
    /* T51: Object.getPrototypeOf(obj) — return obj.__proto__ */
    mjs_set_property(ctx, obj_global, "getPrototypeOf",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1) return MJS_NULL_V;
            return mjs_get_prototype(c, argv[0]);
        }, "getPrototypeOf"));
    /* T51: Object.setPrototypeOf(obj, proto) — set obj.__proto__ */
    mjs_set_property(ctx, obj_global, "setPrototypeOf",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2) return MJS_UNDEF_V;
            mjs_set_prototype(c, argv[0], argv[1]);
            return argv[0];
        }, "setPrototypeOf"));
    /* T51: Object.keys(obj) — return array of property names. */
    mjs_set_property(ctx, obj_global, "keys",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_object(c, argv[0])) return mjs_new_array(c, 0);
            MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
            MJSObject *o = (MJSObject*)h;
            MJSSlot *slots = o->slots;
            /* Count own properties. */
            int count = 0;
            for (uint16_t i = 0; i < o->capacity; i++) {
                if (slots[i].atom != 0 && slots[i].atom != 0xFFFFu) count++;
            }
            MJSValue arr = mjs_new_array(c, count);
            int idx = 0;
            for (uint16_t i = 0; i < o->capacity; i++) {
                if (slots[i].atom != 0 && slots[i].atom != 0xFFFFu) {
                    const char *name = (slots[i].atom <= c->atom_count)
                        ? c->atoms[slots[i].atom - 1] : "?";
                    mjs_set_index(c, arr, idx, mjs_new_string(c, name, strlen(name)));
                    idx++;
                }
            }
            return arr;
        }, "keys"));
    mjs_set_global_value(ctx, "Object", obj_global);

    /* Button constants */
    mjs_set_global_value(ctx, "LEFT",  mjs_int(1));
    mjs_set_global_value(ctx, "UP",    mjs_int(2));
    mjs_set_global_value(ctx, "DOWN",  mjs_int(4));
    mjs_set_global_value(ctx, "RIGHT", mjs_int(8));
    mjs_set_global_value(ctx, "A",     mjs_int(16));
    mjs_set_global_value(ctx, "B",     mjs_int(32));
    mjs_set_global_value(ctx, "RGT",   mjs_int(128));
    mjs_set_global_value(ctx, "NaN",   MJS_NAN_V);     /* T51: NaN constant */

    /* String helper functions */
    MJSValue str_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, str_obj, "length",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1) return mjs_int(0);
            if (mjs_is_string(c, argv[0])) { size_t l; mjs_to_cstr(c, argv[0], &l); return mjs_int((int32_t)l); }
            if (mjs_is_array(c, argv[0])) { MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]); return mjs_int((int32_t)((MJSArray*)h)->length); }
            return mjs_int(0);
        }, "length"));
    mjs_set_property(ctx, str_obj, "charAt",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0])) return mjs_new_string(c, "", 0);
            size_t len; const char *s = mjs_to_cstr(c, argv[0], &len);
            int32_t i = mjs_to_int(c, argv[1]);
            if (i < 0 || (size_t)i >= len) return mjs_new_string(c, "", 0);
            return mjs_new_string(c, s + i, 1);
        }, "charAt"));
    mjs_set_property(ctx, str_obj, "indexOf",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0])) return mjs_int(-1);
            size_t len; const char *s = mjs_to_cstr(c, argv[0], &len);
            size_t slen; const char *sub = mjs_to_cstr(c, argv[1], &slen);
            /* T51: optional fromIndex (3rd arg) — standard JS API.
             * Allows scanning for next occurrence past a known position
             * without allocating a substring. */
            int32_t from = (argc >= 3 && MJS_IS_INT(argv[2]))
                           ? (int32_t)(MJS_GET_INT(argv[2]) >> 8) : 0;
            if (from < 0) from = 0;
            if ((size_t)from > len) return mjs_int(-1);
            if (slen == 0 || from + slen > len) return mjs_int(-1);
            for (size_t i = (size_t)from; i + slen <= len; i++) {
                if (memcmp(s + i, sub, slen) == 0) return mjs_int((int32_t)i);
            }
            return mjs_int(-1);
        }, "indexOf"));
    mjs_set_property(ctx, str_obj, "substring",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0])) return mjs_new_string(c, "", 0);
            size_t len; const char *s = mjs_to_cstr(c, argv[0], &len);
            int32_t start = mjs_to_int(c, argv[1]);
            int32_t end = (argc >= 3) ? mjs_to_int(c, argv[2]) : (int32_t)len;
            if (start < 0) start = 0; if (end < 0) end = 0;
            if (start > (int32_t)len) start = (int32_t)len;
            if (end > (int32_t)len) end = (int32_t)len;
            if (start > end) { int32_t t = start; start = end; end = t; }
            return mjs_new_string(c, s + start, end - start);
        }, "substring"));
    /* T51: String.startsWith(prefix) — check if string starts with prefix. */
    mjs_set_property(ctx, str_obj, "startsWith",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return MJS_FALSE_V;
            size_t slen, plen;
            const char *s = mjs_to_cstr(c, argv[0], &slen);
            const char *p = mjs_to_cstr(c, argv[1], &plen);
            if (plen > slen) return MJS_FALSE_V;
            return mjs_bool(memcmp(s, p, plen) == 0);
        }, "startsWith"));
    /* T51: String.endsWith(suffix) — check if string ends with suffix. */
    mjs_set_property(ctx, str_obj, "endsWith",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return MJS_FALSE_V;
            size_t slen, plen;
            const char *s = mjs_to_cstr(c, argv[0], &slen);
            const char *p = mjs_to_cstr(c, argv[1], &plen);
            if (plen > slen) return MJS_FALSE_V;
            return mjs_bool(memcmp(s + slen - plen, p, plen) == 0);
        }, "endsWith"));
    /* T51: String.includes(substring) — check if string contains substring. */
    mjs_set_property(ctx, str_obj, "includes",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return MJS_FALSE_V;
            size_t slen, plen;
            const char *s = mjs_to_cstr(c, argv[0], &slen);
            const char *p = mjs_to_cstr(c, argv[1], &plen);
            if (plen == 0) return MJS_TRUE_V;
            if (plen > slen) return MJS_FALSE_V;
            for (size_t i = 0; i + plen <= slen; i++) {
                if (memcmp(s + i, p, plen) == 0) return MJS_TRUE_V;
            }
            return MJS_FALSE_V;
        }, "includes"));
    mjs_set_property(ctx, str_obj, "toUpperCase",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_string(c, argv[0])) return mjs_new_string(c, "", 0);
            size_t len; const char *s = mjs_to_cstr(c, argv[0], &len);
            char *buf = (char*)malloc(len + 1); if (!buf) return mjs_new_string(c, "", 0);
            for (size_t i = 0; i < len; i++) {
                unsigned char ch = (unsigned char)s[i];
                if (ch >= 'a' && ch <= 'z') ch -= 32;           /* Latin a-z → A-Z */
                else if (ch >= 0xE0 && ch <= 0xFF) ch -= 0x20;  /* CP1251 а-я → А-Я */
                else if (ch == 0xB8) ch = 0xA8;                  /* ё → Ё */
                buf[i] = (char)ch;
            }
            buf[len] = '\0'; MJSValue r = mjs_new_string(c, buf, len); free(buf); return r;
        }, "toUpperCase"));
    mjs_set_property(ctx, str_obj, "toLowerCase",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_string(c, argv[0])) return mjs_new_string(c, "", 0);
            size_t len; const char *s = mjs_to_cstr(c, argv[0], &len);
            char *buf = (char*)malloc(len + 1); if (!buf) return mjs_new_string(c, "", 0);
            for (size_t i = 0; i < len; i++) {
                unsigned char ch = (unsigned char)s[i];
                if (ch >= 'A' && ch <= 'Z') ch += 32;           /* Latin A-Z → a-z */
                else if (ch >= 0xC0 && ch <= 0xDF) ch += 0x20;  /* CP1251 А-Я → а-я */
                else if (ch == 0xA8) ch = 0xB8;                  /* Ё → ё */
                buf[i] = (char)ch;
            }
            buf[len] = '\0'; MJSValue r = mjs_new_string(c, buf, len); free(buf); return r;
        }, "toLowerCase"));
    /* T51: String.split(sep) — split string by separator, return array.
     * Sep can be a string or single char.  Empty sep → each char as element. */
    mjs_set_property(ctx, str_obj, "split",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return MJS_UNDEF_V;
            size_t slen; const char *s = mjs_to_cstr(c, argv[0], &slen);
            size_t seplen; const char *sep = mjs_to_cstr(c, argv[1], &seplen);
            /* Create array with max possible size, then set length.
             * Max parts = slen+1 (if seplen=1 and every char is a separator). */
            int nparts = 0;
            MJSValue arr = mjs_new_array(c, 0);
            if (seplen == 0) {
                /* Empty separator → split into individual chars */
                for (size_t i = 0; i < slen; i++) {
                    MJSValue ch = mjs_new_string(c, s + i, 1);
                    mjs_set_index(c, arr, nparts++, ch);
                }
            } else {
                size_t start = 0;
                for (size_t i = 0; i + seplen <= slen; ) {
                    if (memcmp(s + i, sep, seplen) == 0) {
                        MJSValue part = mjs_new_string(c, s + start, i - start);
                        mjs_set_index(c, arr, nparts++, part);
                        i += seplen;
                        start = i;
                    } else {
                        i++;
                    }
                }
                /* Last part */
                MJSValue part = mjs_new_string(c, s + start, slen - start);
                mjs_set_index(c, arr, nparts++, part);
            }
            /* Set the actual length (mjs_set_index may not auto-update length
             * for non-packed arrays, so we update the header directly). */
            if (MJS_IS_PTR(arr)) {
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(arr);
                if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) ((MJSArray*)h)->length = (uint16_t)nparts;
            }
            return arr;
        }, "split"));
    /* T51: String.replace(str, find, repl) — replace first occurrence. */
    mjs_set_property(ctx, str_obj, "replace",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 3 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]) || !mjs_is_string(c, argv[2]))
                return argv[0];
            size_t slen; const char *s = mjs_to_cstr(c, argv[0], &slen);
            size_t findlen; const char *find = mjs_to_cstr(c, argv[1], &findlen);
            size_t repllen; const char *repl = mjs_to_cstr(c, argv[2], &repllen);
            if (findlen == 0 || findlen > slen) return argv[0];
            /* Find first occurrence */
            int32_t found = -1;
            for (size_t i = 0; i + findlen <= slen; i++) {
                if (memcmp(s + i, find, findlen) == 0) { found = (int32_t)i; break; }
            }
            if (found < 0) return argv[0];  /* not found, return original */
            /* Build result: s[0..found) + repl + s[found+findlen..slen) */
            size_t resultLen = slen - findlen + repllen;
            char *buf = (char*)malloc(resultLen + 1);
            if (!buf) return argv[0];
            memcpy(buf, s, found);
            memcpy(buf + found, repl, repllen);
            memcpy(buf + found + repllen, s + found + findlen, slen - found - findlen);
            buf[resultLen] = '\0';
            MJSValue r = mjs_new_string(c, buf, resultLen);
            free(buf);
            return r;
        }, "replace"));
    /* T51: String.match(str, pattern) — returns 1 if pattern matches str, 0 otherwise.
     * Uses the NFA regex engine from microjs_regex.h (included at top of file).
     * Supports: . * + ? | ( ) and literal characters. */
    mjs_set_property(ctx, str_obj, "match",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return mjs_bool(0);
            size_t slen, plen;
            const char *s = mjs_to_cstr(c, argv[0], &slen);
            const char *p = mjs_to_cstr(c, argv[1], &plen);
            return mjs_bool(regex_match(p, s));
        }, "match"));
    mjs_set_property(ctx, str_obj, "test",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return mjs_bool(0);
            size_t slen, plen;
            const char *s = mjs_to_cstr(c, argv[0], &slen);
            const char *p = mjs_to_cstr(c, argv[1], &plen);
            return mjs_bool(regex_match(p, s));
        }, "test"));
    mjs_set_global_value(ctx, "String", str_obj);

    /* T51: RegExp object — RegExp.test(pattern, text) and RegExp.match(pattern, text) */
    MJSValue regexp_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, regexp_obj, "test",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return mjs_bool(0);
            size_t plen, slen;
            const char *p = mjs_to_cstr(c, argv[0], &plen);
            const char *s = mjs_to_cstr(c, argv[1], &slen);
            return mjs_bool(regex_match(p, s));
        }, "test"));
    mjs_set_property(ctx, regexp_obj, "match",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 2 || !mjs_is_string(c, argv[0]) || !mjs_is_string(c, argv[1]))
                return mjs_bool(0);
            size_t plen, slen;
            const char *p = mjs_to_cstr(c, argv[0], &plen);
            const char *s = mjs_to_cstr(c, argv[1], &slen);
            return mjs_bool(regex_match(p, s));
        }, "match"));
    mjs_set_global_value(ctx, "RegExp", regexp_obj);

    /* T51: tft object — always registered (even in headless mode, as no-ops).
     * In headless mode (DISPLAY_BACKEND_NONE), all tft functions are stubs
     * but still callable from JS.  The /globals endpoint won't include "tft"
     * so the web UI hides the tft section in help. */
    MJSValue tft_obj = mjs_new_object(ctx);
#if DISPLAY_ACTIVE
    mjs_set_property(ctx, tft_obj, "cls",      mjs_new_cfunction(ctx, js_tft_cls,      "cls"));
    mjs_set_property(ctx, tft_obj, "fill",     mjs_new_cfunction(ctx, js_tft_fill,     "fill"));
    mjs_set_property(ctx, tft_obj, "pixel",    mjs_new_cfunction(ctx, js_tft_pixel,    "pixel"));
    mjs_set_property(ctx, tft_obj, "rect",     mjs_new_cfunction(ctx, js_tft_rect,     "rect"));
    mjs_set_property(ctx, tft_obj, "fillRect", mjs_new_cfunction(ctx, js_tft_fillRect, "fillRect"));
    mjs_set_property(ctx, tft_obj, "line",     mjs_new_cfunction(ctx, js_tft_line,     "line"));
    mjs_set_property(ctx, tft_obj, "circle",   mjs_new_cfunction(ctx, js_tft_circle,   "circle"));
    mjs_set_property(ctx, tft_obj, "disc",     mjs_new_cfunction(ctx, js_tft_disc,     "disc"));
    mjs_set_property(ctx, tft_obj, "text",     mjs_new_cfunction(ctx, js_tft_text,     "text"));
    mjs_set_property(ctx, tft_obj, "setFont",  mjs_new_cfunction(ctx, js_tft_setFont,  "setFont"));
    mjs_set_property(ctx, tft_obj, "width",    mjs_new_cfunction(ctx, js_tft_width,    "width"));
    mjs_set_property(ctx, tft_obj, "height",   mjs_new_cfunction(ctx, js_tft_height,   "height"));
    mjs_set_property(ctx, tft_obj, "getpixel", mjs_new_cfunction(ctx, js_tft_getpixel, "getpixel"));
    mjs_set_property(ctx, tft_obj, "flip",     mjs_new_cfunction(ctx, js_tft_flip,     "flip"));
    mjs_set_property(ctx, tft_obj, "sprite",   mjs_new_cfunction(ctx, js_tft_sprite,   "sprite"));
    mjs_set_property(ctx, tft_obj, "spriteMask",mjs_new_cfunction(ctx, js_tft_spriteMask,"spriteMask"));
    /* T51: Register native fns for OP_NATIVE_CALL inline caching. */
    g_native_fns[NATIVE_TFT_PIXEL]      = js_tft_pixel;
    g_native_fns[NATIVE_TFT_RECT]       = js_tft_rect;
    g_native_fns[NATIVE_TFT_FRECT]      = js_tft_fillRect;
    g_native_fns[NATIVE_TFT_CLS]        = js_tft_cls;
    g_native_fns[NATIVE_TFT_FILL]       = js_tft_fill;
    g_native_fns[NATIVE_TFT_LINE]       = js_tft_line;
    g_native_fns[NATIVE_TFT_CIRCLE]     = js_tft_circle;
    g_native_fns[NATIVE_TFT_DISC]       = js_tft_disc;
    g_native_fns[NATIVE_TFT_TEXT]       = js_tft_text;
    g_native_fns[NATIVE_TFT_FLIP]       = js_tft_flip;
    g_native_fns[NATIVE_TFT_SPRITE]     = js_tft_sprite;
    g_native_fns[NATIVE_TFT_SPRITEMASK] = js_tft_spriteMask;
    g_native_fns[NATIVE_TFT_WIDTH]      = js_tft_width;
    g_native_fns[NATIVE_TFT_HEIGHT]     = js_tft_height;
    g_native_fns[NATIVE_TFT_GETPIXEL]   = js_tft_getpixel;
#else
    /* Headless mode — register tft methods as no-op stubs. */
    static MJSValue js_tft_noop(MJSContext *c, int a, MJSValue *v) { return MJS_UNDEF_V; }
    mjs_set_property(ctx, tft_obj, "cls",       mjs_new_cfunction(ctx, js_tft_noop, "cls"));
    mjs_set_property(ctx, tft_obj, "fill",      mjs_new_cfunction(ctx, js_tft_noop, "fill"));
    mjs_set_property(ctx, tft_obj, "pixel",     mjs_new_cfunction(ctx, js_tft_noop, "pixel"));
    mjs_set_property(ctx, tft_obj, "rect",      mjs_new_cfunction(ctx, js_tft_noop, "rect"));
    mjs_set_property(ctx, tft_obj, "fillRect",  mjs_new_cfunction(ctx, js_tft_noop, "fillRect"));
    mjs_set_property(ctx, tft_obj, "line",      mjs_new_cfunction(ctx, js_tft_noop, "line"));
    mjs_set_property(ctx, tft_obj, "circle",    mjs_new_cfunction(ctx, js_tft_noop, "circle"));
    mjs_set_property(ctx, tft_obj, "disc",      mjs_new_cfunction(ctx, js_tft_noop, "disc"));
    mjs_set_property(ctx, tft_obj, "text",      mjs_new_cfunction(ctx, js_tft_noop, "text"));
    mjs_set_property(ctx, tft_obj, "setFont",   mjs_new_cfunction(ctx, js_tft_noop, "setFont"));
    mjs_set_property(ctx, tft_obj, "width",     mjs_new_cfunction(ctx, [](MJSContext*c,int a,MJSValue*v)->MJSValue{ return mjs_int(0); }, "width"));
    mjs_set_property(ctx, tft_obj, "height",    mjs_new_cfunction(ctx, [](MJSContext*c,int a,MJSValue*v)->MJSValue{ return mjs_int(0); }, "height"));
    mjs_set_property(ctx, tft_obj, "getpixel",  mjs_new_cfunction(ctx, [](MJSContext*c,int a,MJSValue*v)->MJSValue{ return mjs_int(0); }, "getpixel"));
    mjs_set_property(ctx, tft_obj, "flip",      mjs_new_cfunction(ctx, js_tft_noop, "flip"));
    mjs_set_property(ctx, tft_obj, "sprite",    mjs_new_cfunction(ctx, js_tft_noop, "sprite"));
    mjs_set_property(ctx, tft_obj, "spriteMask",mjs_new_cfunction(ctx, js_tft_noop, "spriteMask"));
#endif
    mjs_set_global_value(ctx, "tft", tft_obj);

    /* T51: JSON object — parse + stringify. */
    MJSValue json_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, json_obj, "parse",
        mjs_new_cfunction(ctx, js_json_parse, "parse"));
    mjs_set_property(ctx, json_obj, "stringify",
        mjs_new_cfunction(ctx, js_json_stringify, "stringify"));
    mjs_set_global_value(ctx, "JSON", json_obj);

    /* T51: http object — JS HTTP server.
     *   http.onRequest(callback)  — register handler, activates JS server.
     *   http.respond(status, contentType, body) — send response from callback.
     *   http.stop()               — deactivate JS server (back to /edit redirect).
     *
     * After http.onRequest(cb), requests to ip/ are handled by cb(method, path, query, body).
     * cb can either return a string (sent as text/plain 200), return an object
     * {status, contentType, body}, or call http.respond() directly and return undefined.
     * /edit always serves the web editor regardless of JS server state. */
    MJSValue http_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, http_obj, "onRequest",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            if (argc < 1 || !mjs_is_function(c, argv[0])) return MJS_UNDEF_V;
            g_js_http_handler = argv[0];
            g_js_http_active = true;
            Serial.println(F("[http] JS server activated — / now handled by JS"));
            return MJS_UNDEF_V;
        }, "onRequest"));
    mjs_set_property(ctx, http_obj, "respond",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            /* T51-fix: For bound methods (http.respond called as method),
             * argv[0] = bound_this (http object), argv[1..] = actual args.
             * So status=argv[1], contentType=argv[2], body=argv[3]. */
            int status = 200;
            String contentType = "text/plain";
            String body = "";

            /* Debug: log what we actually received. */
            Serial.printf_P(PSTR("[respond] argc=%d"), argc);
            for (int i = 0; i < argc && i < 5; i++) {
                MJSValue v = argv[i];
                if (MJS_IS_INT(v)) {
                    Serial.printf_P(PSTR(" arg%d=INT(%d)"), i, (int)(MJS_GET_INT(v) >> 8));
                } else if (MJS_IS_PTR(v)) {
                    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
                    uint8_t t = MJS_HDR_TYPE(h);
                    const char *tn = t == 1 ? "OBJ" : t == 2 ? "ARR" : t == 3 ? "STR" : t == 4 ? "CFN" : t == 5 ? "FN" : "?";
                    Serial.printf_P(PSTR(" arg%d=PTR(%s)"), i, tn);
                } else {
                    Serial.printf_P(PSTR(" arg%d=SPECIAL(%d)"), i, (int)(v & 0xFF));
                }
            }
            Serial.println();

            /* Detect bound method: if argv[0] is the http object (MJS_T_OBJECT),
             * shift args by 1.  Otherwise treat argv[0] as status (plain call). */
            int off = 0;
            if (argc >= 1 && MJS_IS_PTR(argv[0])) {
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(argv[0]);
                if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) off = 1;
            }
            if (argc >= off + 1 && MJS_IS_INT(argv[off]))
                status = (int)(MJS_GET_INT(argv[off]) >> 8);
            if (argc >= off + 2 && mjs_is_string(c, argv[off + 1])) {
                size_t cl; const char *s = mjs_to_cstr(c, argv[off + 1], &cl);
                contentType = String(s).substring(0, cl);
            }
            if (argc >= off + 3 && mjs_is_string(c, argv[off + 2])) {
                size_t bl; const char *s = mjs_to_cstr(c, argv[off + 2], &bl);
                body = String(s).substring(0, bl);
            }
            /* Buffer response — will be sent by http_root() after
             * mjs_call_value returns.  Calling server.send() from inside
             * nested mjs_run() corrupts ESP8266WebServer state. */
            g_http_resp_status = status;
            g_http_resp_type = contentType;
            g_http_resp_body = body;
            g_http_resp_pending = true;
            Serial.printf_P(PSTR("[http.respond] %d %s (%d bytes)\n"),
                            status, contentType.c_str(), (int)body.length());
            return MJS_UNDEF_V;
        }, "respond"));
    mjs_set_property(ctx, http_obj, "stop",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            g_js_http_active = false;
            g_js_http_handler = MJS_UNDEF_V;
            DBG_PRINTLN("[http] JS server stopped — / redirects to /edit");
            return MJS_UNDEF_V;
        }, "stop"));
    mjs_set_global_value(ctx, "http", http_obj);

    /* T51: files object — LittleFS file management from JS. */
    MJSValue files_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, files_obj, "list",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            (void)argc; (void)argv;
            return js_files_list(c, 0, NULL);
        }, "list"));
    mjs_set_property(ctx, files_obj, "load",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_files_load(c, argc, argv);
        }, "load"));
    mjs_set_property(ctx, files_obj, "save",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_files_save(c, argc, argv);
        }, "save"));
    mjs_set_property(ctx, files_obj, "delete",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_files_delete(c, argc, argv);
        }, "delete"));
    mjs_set_global_value(ctx, "files", files_obj);

    /* T51: i2c object — I2C bus control. */
    MJSValue i2c_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, i2c_obj, "write",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_i2c_write(c, argc, argv);
        }, "write"));
    mjs_set_property(ctx, i2c_obj, "read",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_i2c_read(c, argc, argv);
        }, "read"));
    mjs_set_property(ctx, i2c_obj, "scan",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_i2c_scan(c, argc, argv);
        }, "scan"));
    mjs_set_global_value(ctx, "i2c", i2c_obj);

    /* T51: spi object — SPI bus control. */
    MJSValue spi_obj = mjs_new_object(ctx);
    mjs_set_property(ctx, spi_obj, "transfer",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_spi_transfer(c, argc, argv);
        }, "transfer"));
    mjs_set_property(ctx, spi_obj, "transferArray",
        mjs_new_cfunction(ctx, [](MJSContext *c, int argc, MJSValue *argv) -> MJSValue {
            return js_spi_transfer_array(c, argc, argv);
        }, "transferArray"));
    mjs_set_global_value(ctx, "spi", spi_obj);
}

/* ============================================================
 * HTTP server handlers
 * ============================================================ */

static void http_root() {
    /* T51: Root handler — if JS has activated the HTTP server (via
     * http.onRequest), call the JS callback to produce a response.
     * Otherwise, redirect to /edit (the web editor). */
    if (g_js_http_active && g_js_http_handler != MJS_UNDEF_V && g_ctx) {
        uint32_t reqStart = millis();  /* T51: track response time */
        /* Build args for JS callback: method, path, query, body */
        String method = server.method() == HTTP_GET ? "GET" :
                        server.method() == HTTP_POST ? "POST" :
                        server.method() == HTTP_PUT ? "PUT" :
                        server.method() == HTTP_DELETE ? "DELETE" : "OTHER";
        String path = server.uri();
        String query = "";
        /* Extract query args from server.args(). */
        for (uint8_t i = 0; i < server.args(); i++) {
            if (i > 0) query += "&";
            query += server.argName(i) + "=" + server.arg(i);
        }
        String body = server.hasArg("plain") ? server.arg("plain") : "";

        MJSValue args[4];
        /* T51: Run GC + compaction before each request.
         * GC frees garbage from previous request.
         * Compaction defragments the heap into one contiguous free block,
         * giving the callback maximum room for string concatenation.
         *
         * Without compaction, the free list has many small blocks that
         * can't satisfy a single large string allocation (e.g. 136-byte
         * body), causing mjs_concat to return NULL → body = 0 bytes. */
        mjs_gc(g_ctx);
        mjs_compact(g_ctx);
        args[0] = mjs_new_string(g_ctx, method.c_str(), method.length());
        args[1] = mjs_new_string(g_ctx, path.c_str(), path.length());
        args[2] = mjs_new_string(g_ctx, query.c_str(), query.length());
        args[3] = mjs_new_string(g_ctx, body.c_str(), body.length());

        /* T51: If any arg failed to allocate (OOM), run GC and retry. */
        if (args[0] == MJS_UNDEF_V || args[1] == MJS_UNDEF_V ||
            args[2] == MJS_UNDEF_V || args[3] == MJS_UNDEF_V) {
            mjs_gc(g_ctx);
            args[0] = mjs_new_string(g_ctx, method.c_str(), method.length());
            args[1] = mjs_new_string(g_ctx, path.c_str(), path.length());
            args[2] = mjs_new_string(g_ctx, query.c_str(), query.length());
            args[3] = mjs_new_string(g_ctx, body.c_str(), body.length());
        }

        /* Clear any previous buffered response. */
        g_http_resp_pending = false;

        MJSValue rv = mjs_call_value(g_ctx, g_js_http_handler, 4, args);

        /* After mjs_call_value returns, send the response from the buffer.
         * This runs in normal C context (not nested mjs_run), so
         * ESP8266WebServer state is clean. */
        if (g_http_resp_pending) {
            /* http.respond() was called — send buffered response. */
            server.send(g_http_resp_status, g_http_resp_type, g_http_resp_body);
            g_http_resp_pending = false;
        } else if (mjs_is_string(g_ctx, rv)) {
            /* Callback returned a string — send as text/plain 200. */
            size_t rl; const char *r = mjs_to_cstr(g_ctx, rv, &rl);
            server.send(200, F("text/plain"), r);
        } else {
            server.send(204, F("text/plain"), F(""));
        }
        Serial.printf_P(PSTR("[http] %d in %lums\n"),
                        g_http_resp_pending ? g_http_resp_status : 200,
                        (unsigned long)(millis() - reqStart));
        return;
    }
    /* Default: redirect to /edit */
    server.sendHeader("Location", "/edit");
    server.send(302, F("text/plain"), F(""));
}

static void http_edit() {
    /* /edit — always serves the web editor, regardless of JS server state. */
    server.sendHeader("Cache-Control", "no-cache");
    server.sendHeader("Content-Length", String(strlen_P(WEBUI_INDEX_HTML)));
    server.send_P(200, "text/html", WEBUI_INDEX_HTML);
}

/* /compiler.js — serve the JS compiler (read from LittleFS or PROGMEM).
 * For simplicity, we serve it from a PROGMEM string built from the
 * microjs_compiler.js file.  In a real build, the compiler JS would
 * be stored in LittleFS or generated as a PROGMEM header. */
#include "microjs_compiler_js.h"  /* PROGMEM string of compiler JS */

static void http_compiler_js() {
    server.sendHeader("Cache-Control", "no-cache");
    server.sendHeader("Content-Length", String(strlen_P(MICROJS_COMPILER_JS)));
    server.send_P(200, "application/javascript", MICROJS_COMPILER_JS);
}

/* T51: /globals — return JSON array of all native function/constant
 * names registered by the device.  The browser compiler fetches this
 * on page load and uses it as the set of "known globals" so that
 * references like `parseInt(...)` don't trigger "undefined variable"
 * compile errors.  This eliminates the need to maintain a parallel
 * hardcoded list in microjs_compiler.js — adding a new native in the
 * .ino automatically makes it available to the compiler.
 *
 * Response: ["print","millis","delay",...,"PI","LEFT","UP",...]
 * Names are sorted alphabetically for stable diffs. */
static const char *const NATIVE_GLOBAL_NAMES[] PROGMEM = {
    /* Native functions (registered via mjs_register_global) */
    "print", "millis", "seconds", "centis", "delay", "mem", "jsmem", "gc", "reset",
    "parseInt", "isNaN", "getIP", "gcDebug", "gcRoots", "beep", "fetch", "jsonSelect", "jsonStream",
    "keys", "keysPressed", "keysReleased",
    "backlight", "rand", "hexToColor", "colorToHex",
    "setTimeout", "setInterval", "clearTimeout", "clearInterval",
    /* Global objects (registered via mjs_set_global_value) */
    "console", "Math", "Array", "String", "Object", "RegExp",
#if DISPLAY_ACTIVE
    "tft",
#endif
    "JSON", "http", "files", "i2c", "spi",
    /* Global constants */
    "PI", "NaN",
    /* Button constants */
    "LEFT", "UP", "DOWN", "RIGHT", "A", "B", "RGT",
    /* JS built-in literals (compiler handles these, but include for safety) */
    "undefined", "Infinity",
};
static const size_t NATIVE_GLOBAL_COUNT =
    sizeof(NATIVE_GLOBAL_NAMES) / sizeof(NATIVE_GLOBAL_NAMES[0]);

static void http_globals() {
    server.sendHeader("Cache-Control", "no-cache");
    /* Build JSON array.  Each name is short, so we can use a stack buffer.
     * Worst case: 40 names × ~16 chars + commas/quotes/brackets ≈ 800 B. */
    String json = "[";
    for (size_t i = 0; i < NATIVE_GLOBAL_COUNT; i++) {
        if (i) json += ",";
        json += "\"";
        /* Read name from PROGMEM (FlashStringHelper would also work,
         * but explicit pgm_read_ptr is clearer here). */
        const char *name = (const char*)pgm_read_ptr(&NATIVE_GLOBAL_NAMES[i]);
        /* Escape any special chars (names are simple identifiers, so
         * this is mostly defensive). */
        for (const char *p = name; *p; p++) {
            if (*p == '"' || *p == '\\') json += '\\';
            json += (char)*p;
        }
        json += "\"";
    }
    json += "]";
    server.send(200, F("application/json"), json);
}

/* T51: /favicon.ico — serve embedded PNG favicon (128x128 RGBA).
 * Browsers request this automatically; without it, they show a broken
 * icon or generate a 404 request on every page load. */
#include "microjs_favicon.h"
static void http_favicon() {
    server.sendHeader("Cache-Control", "max-age=86400");
    server.send_P(200, "image/png", (const char*)MICROJS_FAVICON_PNG, MICROJS_FAVICON_PNG_LEN);
}

/* T51-fix: read raw body bytes from the WiFiClient (bypasses ESP32's
 * WString NUL-truncation bug).
 *
 * ESP32 WebServer parses text/plain bodies via `_plainArgs = buf;` where
 * `buf` is a `char*` — the String constructor calls strlen() internally,
 * so the body gets truncated at the first NUL byte.  This breaks binary
 * bytecode (which contains NUL bytes after the "MJSB" magic header).
 *
 * Workaround: when the body needs to be treated as raw bytes (bytecode
 * upload to /run, .mjsb chunked save to /file), we read directly from
 * server.client() using the Content-Length header (which we collect in
 * setup()).  We also try arg("plain") first as a fast path for ESP8266
 * (which doesn't have the truncation bug).
 *
 * Caller must free() the returned buffer.  Returns NULL on error.
 * Sets *out_len to the actual byte count (may be 0). */
static uint8_t* read_body_binary(size_t *out_len) {
    *out_len = 0;
    /* Fast path: ESP8266's arg("plain") returns the body correctly
     * even with embedded NUL bytes (String stores length separately). */
#if defined(ESP8266)
    if (server.hasArg("plain")) {
        String body = server.arg("plain");
        if (body.length() > 0) {
            uint8_t *buf = (uint8_t*)malloc(body.length());
            if (!buf) return NULL;
            memcpy(buf, body.c_str(), body.length());
            *out_len = body.length();
            return buf;
        }
    }
#endif
    /* Slow path: read directly from client using Content-Length.
     * This is required on ESP32 (where arg("plain") truncates at NUL),
     * and also for application/octet-stream content-type on both
     * platforms (where arg("plain") is empty). */
    if (!server.hasHeader("Content-Length")) {
        return NULL;
    }
    String clStr = server.header("Content-Length");
    size_t cl = (size_t)clStr.toInt();
    if (cl == 0 || cl > 64 * 1024) {
        /* 64KB sanity limit — bytecode is at most a few KB, and we
         * don't want to OOM the device with a malicious request. */
        return NULL;
    }
    uint8_t *buf = (uint8_t*)malloc(cl);
    if (!buf) return NULL;
    size_t got = 0;
    WiFiClient client = server.client();
    /* Drain the body from the client buffer.  5s timeout for slow
     * connections; ESP32 typically has the whole body already in the
     * TCP receive buffer by the time the handler runs. */
    uint32_t start = millis();
    while (got < cl) {
        int avail = client.available();
        if (avail > 0) {
            int rd = client.read(buf + got, cl - got);
            if (rd > 0) {
                got += (size_t)rd;
            }
        } else if (millis() - start > 5000) {
            break;  /* timeout */
        }
        yield();
    }
    *out_len = got;
    return buf;
}

/* /run — body is comma-separated decimal MJSB bytecode (text-encoded
 * to avoid ESP32 WebServer's String=NUL-truncation bug on binary bodies).
 * Load + run + return JSON. */
static void http_run() {
    /* Read the body.  On ESP8266, server.arg("plain") works directly.
     * On ESP32, server.arg("plain") also works because we send the body
     * as text/plain (which ESP32 parses).  The body is pure ASCII text
     * (comma-separated decimals), so no NUL-truncation issue. */
    String body;
    if (server.hasArg("plain")) {
        body = server.arg("plain");
    }
    size_t body_len = body.length();
    DBG_PRINT(PSTR("[run] body length=%u\n"), (unsigned)body_len);
    if (body_len < 8) {
        String err = "{\"error\":\"bytecode too small (got ";
        err += String(body_len);
        err += " bytes, need >= 8)\"}";
        server.send(400, F("application/json"), err);
        return;
    }
    /* Parse the body as comma-separated decimals → binary bytecode.
     * Example body: "77,74,83,66,5,0,12,34,..." */
    /* First pass: count bytes to allocate the right buffer size. */
    size_t bc_count = 0;
    {
        int p = 0;
        while (p < (int)body_len) {
            while (p < (int)body_len && (body[p] == ' ' || body[p] == ',')) p++;
            if (p >= (int)body_len) break;
            int v = 0;
            while (p < (int)body_len && body[p] >= '0' && body[p] <= '9') {
                v = v * 10 + (body[p] - '0'); p++;
            }
            (void)v;
            bc_count++;
        }
    }
    DBG_PRINT(PSTR("[run] parsed %u bytecode bytes\n"), (unsigned)bc_count);
    if (bc_count < 8) {
        String err = "{\"error\":\"bytecode too small after parse (got ";
        err += String(bc_count);
        err += " bytes, need >= 8)\"}";
        server.send(400, F("application/json"), err);
        return;
    }
    /* Allocate buffer for the parsed bytecode. */
    uint8_t *bc_buf = (uint8_t*)malloc(bc_count);
    if (!bc_buf) {
        server.send(500, F("application/json"), F("{\"error\":\"OOM for bytecode\"}"));
        return;
    }
    /* Second pass: actually parse and store bytes. */
    {
        size_t p = 0, idx = 0;
        while (p < body_len) {
            while (p < body_len && (body[p] == ' ' || body[p] == ',')) p++;
            if (p >= body_len) break;
            int v = 0;
            while (p < body_len && body[p] >= '0' && body[p] <= '9') {
                v = v * 10 + (body[p] - '0'); p++;
            }
            bc_buf[idx++] = (uint8_t)v;
        }
    }
    size_t bc_size = bc_count;

    /* T51: If a script is currently running (e.g. boot script with
     * infinite loop), signal it to abort.  The yield callback in mjs_run
     * calls server.handleClient() which triggers this http_run handler.
     * g_script_abort was already set to true by this very call (we're
     * inside the nested handleClient).  The running mjs_run will see
     * it on the next yield and abort.  Wait for it to exit. */
    g_script_abort = true;
    /* Wait for the running script to notice the abort flag and exit.
     * mjs_run checks every 1024 opcodes (~1ms), so 500ms is plenty. */
    uint32_t waitStart = millis();
    while (millis() - waitStart < 500) {
        delay(1);
        yield();
    }
    g_script_abort = false;

    /* Reset the JS context for a fresh run.  We re-init the heap
     * (clearing any previous allocations) but keep the natives. */
    timers_clear_all();  /* invalidate old timer callbacks */
    /* T50: free any boot-script blob — its const strings pointed into
     * it, and the old g_ctx is about to be wiped.  Without this, every
     * /run after a boot-script run leaks sz bytes of system heap. */
    if (g_boot_blob) { free(g_boot_blob); g_boot_blob = NULL; }
    g_ctx = mjs_init(g_js_heap, JS_HEAP_SIZE);
    if (!g_ctx) {
        free(bc_buf);
        server.send(500, F("application/json"), F("{\"error\":\"init failed\"}"));
        return;
    }
    /* T51: Reset JS HTTP server state — new script must re-activate it. */
    g_js_http_active = false;
    g_js_http_handler = MJS_UNDEF_V;
    mjs_set_gc_hook(g_ctx, gc_walk_timers, NULL);
    mjs_set_yield_callback([]() -> bool {
        /* T51: Process pending HTTP requests during long-running scripts.
         * This allows /run to interrupt an infinite loop (e.g. game).
         * If http_run receives a new /run, it sets g_script_abort = true. */
        server.handleClient();
        return g_script_abort;
    });
    /* T51-fix: Register C-side MJSValue pointers as compaction roots.
     * When compaction moves heap blocks, these pointers must be updated
     * or they become dangling. */
    mjs_clear_compact_roots();
    mjs_add_compact_root(&g_js_http_handler);
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        mjs_add_compact_root(&g_timers[i].cb);
    }
    /* Re-register natives (atoms are loaded from bytecode, so this
     * must come AFTER mjs_load_bytecode).  We need to load bytecode
     * first so atoms exist, then register natives. */
    DBG_PRINT(PSTR("[run] loading bytecode (size=%u) into VM\n"),
                    (unsigned)bc_size);
    if (mjs_load_bytecode(g_ctx, bc_buf, bc_size) != 0) {
        String json = "{\"error\":\"load: ";
        json += jsonEscape(mjs_last_error(g_ctx));
        json += "\"}";
        free(bc_buf);
        server.send(400, F("application/json"), json);
        return;
    }
    free(bc_buf);  /* bytecode loaded into VM heap — body buffer no longer needed */
    register_natives();
    DBG_PRINTLN("[run] bytecode loaded, natives registered");
    DBG_PRINT(PSTR("[run] free heap before mjs_run: %u, js heap free: %u\n"),
                    (unsigned)ESP.getFreeHeap(),
                    (unsigned)mjs_free_mem(g_ctx));

    /* Run. */
    out_reset();
    g_capture_active = true;
    g_ctx->run_timeout_ms = 10000;  /* T51: 10s timeout for HTTP /run */
    uint32_t t0 = millis();
    DBG_PRINTLN("[run] calling mjs_run...");
    int r = mjs_run(g_ctx);
    DBG_PRINT(PSTR("[run] mjs_run returned %d in %lums\n"),
                    r, (unsigned long)(millis() - t0));
    uint32_t elapsed = millis() - t0;
    g_capture_active = false;

    /* Build JSON response. */
    String json = "{";
    if (r != 0) {
        json += "\"error\":\"";
        json += jsonEscape(mjs_last_error(g_ctx));
        json += "\",\"pc\":";
        json += String(g_ctx->err_pc);
        json += ",";
    }
    json += "\"stdout\":\"";
    json += jsonEscape(g_out_buf);
    json += "\",\"truncated\":";
    json += g_out_truncated ? "true" : "false";  /* T50: signal silent truncation */
    json += ",\"ms\":";
    json += String(elapsed);
    json += ",\"mem\":";
    json += String(ESP.getFreeHeap());
    json += "}";
    server.send(200, F("application/json"), json);
}

/* /save — body is JSON {source, bytecode:[]} as text/plain.
 * Save both /boot.js (source) and /boot.mjsb (bytecode) to flash. */
static void http_save() {
    if (!server.hasArg("plain")) {
        DBG_PRINTLN("[save] ERROR: no plain body");
        server.send(400, F("text/plain"), F("no body"));
        return;
    }
    String body = server.arg("plain");
    DBG_PRINT(PSTR("[save] body length=%u\n"), (unsigned)body.length());
    /* Parse JSON manually (we don't have a JSON library).  We look
     * for "source":"..." and "bytecode":[...] and extract them. */
    int src_idx = body.indexOf("\"source\":\"");
    int bc_idx  = body.indexOf("\"bytecode\":[");
    DBG_PRINT(PSTR("[save] src_idx=%d bc_idx=%d\n"), src_idx, bc_idx);
    if (src_idx < 0 || bc_idx < 0) {
        DBG_PRINTLN("[save] ERROR: missing source or bytecode");
        server.send(400, F("text/plain"), F("missing source or bytecode"));
        return;
    }
    /* Extract source — find end quote (handle escaped quotes). */
    src_idx += 10;
    String source;
    int i = src_idx;
    while (i < (int)body.length()) {
        char c = body[i];
        if (c == '\\' && i + 1 < (int)body.length()) {
            char e = body[i+1];
            if (e == 'n') source += '\n';
            else if (e == 't') source += '\t';
            else if (e == 'r') source += '\r';
            else if (e == '"') source += '"';
            else if (e == '\\') source += '\\';
            else source += e;
            i += 2;
        } else if (c == '"') {
            break;
        } else {
            source += c;
            i++;
        }
    }
    /* Extract bytecode — array of integers. */
    bc_idx += 12;
    String bc_str = body.substring(bc_idx);
    int bc_end = bc_str.indexOf(']');
    if (bc_end < 0) {
        server.send(400, F("text/plain"), F("bytecode array not terminated"));
        return;
    }
    bc_str = bc_str.substring(0, bc_end);

    /* Parse the comma-separated integers. */
    int bc_count = 0;
    size_t bc_bytes = 0;
    {
        int p = 0;
        while (p < (int)bc_str.length()) {
            while (p < (int)bc_str.length() && (bc_str[p] == ' ' || bc_str[p] == ',')) p++;
            if (p >= (int)bc_str.length()) break;
            int v = 0;
            while (p < (int)bc_str.length() && bc_str[p] >= '0' && bc_str[p] <= '9') {
                v = v * 10 + (bc_str[p] - '0');
                p++;
            }
            bc_count++;
            bc_bytes++;
            (void)v;
        }
    }

    /* Save source to /boot.js, bytecode to /boot.mjsb. */
    File f1 = LittleFS.open("/boot.js", "w");
    if (f1) { f1.print(source); f1.close(); }
    File f2 = LittleFS.open("/boot.mjsb", "w");
    if (f2) {
        /* Re-parse and write each byte. */
        int p = 0;
        while (p < (int)bc_str.length()) {
            while (p < (int)bc_str.length() && (bc_str[p] == ' ' || bc_str[p] == ',')) p++;
            if (p >= (int)bc_str.length()) break;
            int v = 0;
            while (p < (int)bc_str.length() && bc_str[p] >= '0' && bc_str[p] <= '9') {
                v = v * 10 + (bc_str[p] - '0');
                p++;
            }
            f2.write((uint8_t)v);
        }
        f2.close();
    }

    saved_code_exists = true;
    saved_code_size = bc_bytes;

    String resp = "saved /boot.js (" + String(source.length()) + "B) and /boot.mjsb (" +
                  String(bc_bytes) + "B)";
    server.send(200, F("text/plain"), resp);
    Serial.println(resp);
}

/* /load — return JSON {source, bytecode_count}. */
static void http_load() {
    String resp = "{";
    /* Source. */
    File f = LittleFS.open("/boot.js", "r");
    if (f) {
        String src = f.readString();
        f.close();
        resp += "\"source\":\"";
        resp += jsonEscape(src);
        resp += "\"";
    } else {
        resp += "\"source\":\"\"";
    }
    /* Bytecode size. */
    File f2 = LittleFS.open("/boot.mjsb", "r");
    if (f2) {
        resp += ",\"bytecode_count\":";
        resp += String(f2.size());
        f2.close();
    } else {
        resp += ",\"bytecode_count\":0";
    }
    resp += "}";
    server.send(200, F("application/json"), resp);
}

/* /clear — delete /boot.js and /boot.mjsb. */
static void http_clear() {
    LittleFS.remove("/boot.js");
    LittleFS.remove("/boot.mjsb");
    saved_code_exists = false;
    saved_code_size = 0;
    server.send(200, F("text/plain"), F("cleared"));
}

/* /mem — JSON diagnostics. */
static void http_mem() {
    String json = "{\"free_heap\":";
    json += String(ESP.getFreeHeap());
    json += ",\"flash_size\":";
    json += String(ESP.getFlashChipSize());
    json += ",\"js_heap_total\":";
    json += String(JS_HEAP_SIZE);
    json += ",\"js_heap_free\":";
    json += String(g_ctx ? mjs_free_mem(g_ctx) : 0);
    json += ",\"fs_total\":";
    json += String(fs_total_bytes());
    json += ",\"fs_used\":";
    json += String(fs_used_bytes());
    if (saved_code_exists) {
        json += ",\"saved_code_size\":";
        json += String(saved_code_size);
    }
    json += "}";
    server.send(200, F("application/json"), json);
}

static String jsonEscape(const String &s) {
    String out;
    out.reserve(s.length() + 16);
    for (size_t i = 0; i < s.length(); i++) {
        char c = s[i];
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

/* ============================================================
 * Script runner — runs any .mjsb file from LittleFS
 * ============================================================ */
/* g_boot_blob is now declared near the top of the file (before http_run)
 * so that http_run() can free it when re-initializing the JS context. */

static void run_script(const char *mjsbPath) {
    if (!LittleFS.exists(mjsbPath)) {
        DBG_PRINT(PSTR("[run] no %s\n"), mjsbPath);
        return;
    }
    File f = LittleFS.open(mjsbPath, "r");
    if (!f) {
        DBG_PRINT(PSTR("[run] cannot open %s\n"), mjsbPath);
        return;
    }
    size_t sz = f.size();
    DBG_PRINT(PSTR("[run] %s: %u bytes\n"), mjsbPath, (unsigned)sz);
    if (g_boot_blob) { free(g_boot_blob); g_boot_blob = NULL; }
    g_boot_blob = (uint8_t*)malloc(sz);
    if (!g_boot_blob) { f.close(); DBG_PRINTLN("[run] OOM for blob"); return; }
    size_t rd = f.read(g_boot_blob, sz);
    f.close();
    if (rd != sz) {
        DBG_PRINT(PSTR("[run] short read: %u/%u\n"), (unsigned)rd, (unsigned)sz);
        free(g_boot_blob); g_boot_blob = NULL;
        return;
    }
    /* Verify magic. */
    if (sz < 6 || g_boot_blob[0] != 'M' || g_boot_blob[1] != 'J' ||
        g_boot_blob[2] != 'S' || g_boot_blob[3] != 'B') {
        DBG_PRINT(PSTR("[run] bad magic: %02x %02x %02x %02x\n"),
                      g_boot_blob[0], g_boot_blob[1], g_boot_blob[2], g_boot_blob[3]);
        free(g_boot_blob); g_boot_blob = NULL;
        return;
    }
    DBG_PRINT(PSTR("[run] magic OK, version=%u, free heap=%u\n"),
                  g_boot_blob[4], (unsigned)ESP.getFreeHeap());

    g_ctx = mjs_init(g_js_heap, JS_HEAP_SIZE);
    if (!g_ctx) { free(g_boot_blob); g_boot_blob = NULL; DBG_PRINTLN("[run] mjs_init failed"); return; }
    mjs_set_gc_hook(g_ctx, gc_walk_timers, NULL);
    mjs_clear_compact_roots();
    mjs_add_compact_root(&g_js_http_handler);
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        mjs_add_compact_root(&g_timers[i].cb);
    }
    timers_clear_all();
    if (mjs_load_bytecode_inplace(g_ctx, g_boot_blob, sz) != 0) {
        DBG_PRINT(PSTR("[run] load error: %s\n"), mjs_last_error(g_ctx));
        return;
    }
    register_natives();

    out_reset();
    g_capture_active = false;
    DBG_PRINT(PSTR("[run] running %s...\n"), mjsbPath);
    g_ctx->run_timeout_ms = 0;  /* T51: no timeout — games can loop forever */
    int r = mjs_run(g_ctx);
    if (r != 0) {
        DBG_PRINT(PSTR("[run] runtime: %s (pc=%u)\n"),
                      mjs_last_error(g_ctx), (unsigned)g_ctx->err_pc);
    } else {
        DBG_PRINTLN("[run] done.");
    }
    /* T51: Clear timers AFTER script completes — the script may have
     * registered setInterval/setTimeout callbacks that point to
     * MJSFuncObj objects in the now-stale JS heap.  Without this,
     * timers_tick() in loop() tries to call dead functions → crash.
     *
     * BUT: if the script registered timers (setInterval), DON'T clear
     * them and DON'T draw splash — the script is still "running" via
     * timer callbacks.  Only clear timers if script had an error. */
    if (r != 0) {
        /* Error — clear timers and show splash. */
        timers_clear_all();
        display_flush_now();
        delay(2000);
        draw_splash();
    } else {
        /* Success — check if timers are still active. */
        if (!timers_has_pending()) {
            /* No timers — script finished, show splash. */
            display_flush_now();
            delay(2000);
            draw_splash();
        } else {
            /* Timers active — script runs in background, keep screen as-is. */
            display_flush_now();
        }
    }
}

/* Convenience: run /boot.mjsb (the default boot script). */
static void run_boot_script() {
    run_script("/boot.mjsb");
}

/* T51: Script selector — shows list of .mjsb files, navigate with
 * arrows, run with A.  Called when RGT is pressed. */
static void show_script_selector() {
    /* Scan filesystem for .mjsb files. */
    String names[16];
    int count = 0;
    DirEntry entries[64];
    int n = fs_list_root_files(entries, 64);
    for (int i = 0; i < n && count < 16; i++) {
        const String &name = entries[i].name;
        if (name.endsWith(".mjsb")) {
            /* Strip ".mjsb" (5 chars) for display. */
            String display = name.substring(0, name.length() - 5);
            names[count++] = display;
        }
    }
    if (count == 0) {
        fb_cls();
        fb_text_small(1, 1, "No scripts", 1, 1);
        fb_text_small(1, 8, "found", 1, 1);
        fb_text_small(1, 22, "[RGT] back", 8, 1);
        display_mark_all_dirty();
        display_flush_now();
        /* Wait for RGT to go back. */
        while (~mcp_readReg(0x12) & 0x80) delay(10);
        while (~mcp_readReg(0x12) & 0x80) delay(10);  /* debounce release */
        delay(200);
        return;
    }

    int sel = 0;
    for (;;) {
        fb_cls();
        fb_text_small(1, 1, "Scripts:", 11, 1);
        int startY = 8;
        int maxShow = 10;
        int showStart = (sel >= maxShow) ? sel - maxShow + 1 : 0;
        for (int i = 0; i < maxShow && (showStart + i) < count; i++) {
            int idx = showStart + i;
            int y = startY + i * 6;
            uint8_t color = (idx == sel) ? 11 : 7;
            fb_text_small(1, y, ">", color, 1);
            fb_text_small(4, y, names[idx].c_str(), color, 1);
        }
        int y = 57;
        fb_text_small(1, y, "A:run ^v:sel RGT:back", 3, 1);
        display_mark_all_dirty();
        display_flush_now();  /* push immediately, bypass throttle */

        /* Wait for button press. */
        uint8_t prev = 0xFF;
        for (;;) {
            uint8_t btn = ~mcp_readReg(0x12) & 0xFF;
            uint8_t pressed = btn & ~prev;
            prev = btn;
            if (pressed & 0x02) {  /* UP (bit 1) */
                if (sel > 0) sel--;
                delay(150);
                break;
            }
            if (pressed & 0x04) {  /* DOWN (bit 2) */
                if (sel < count - 1) sel++;
                delay(150);
                break;
            }
            if (pressed & 0x10) {  /* A — run selected script */
                delay(50);
                String path = "/" + names[sel] + ".mjsb";
                run_script(path.c_str());
                /* run_script already flushes display + delays 2s.
                 * Return to splash after the script finishes. */
                draw_splash();
                return;
            }
            if (pressed & 0x80) {  /* RGT — back to splash */
                delay(200);
                while (~mcp_readReg(0x12) & 0x80) delay(10);
                draw_splash();
                return;
            }
            delay(10);
        }
    }
}

/* T51: Get the auto-run script name (reads /autorun.txt).
 * Returns empty string if no auto-run set. */
static String get_autorun_name() {
    if (!LittleFS.exists("/autorun.txt")) return "";
    File f = LittleFS.open("/autorun.txt", "r");
    if (!f) return "";
    String name = f.readString();
    f.close();
    name.trim();
    return name;
}

/* T51: Set or clear auto-run script.
 * name = "" to clear, or a script name (without .mjsb). */
static void set_autorun_name(const String &name) {
    if (name.length() == 0) {
        LittleFS.remove("/autorun.txt");
    } else {
        File f = LittleFS.open("/autorun.txt", "w");
        if (f) { f.print(name); f.close(); }
    }
}

/* ============================================================
 * Splash screen
 * ============================================================ */
static void draw_splash() {
    fb_cls();
#if defined(ESP8266)
    fb_text_small(1, 1,  "mjs T51 esp8266", 11, 1);
#elif defined(ESP32)
    fb_text_small(1, 1,  "mjs T51 esp32", 11, 1);
#endif
    /* Show WiFi SSID + IP (single line, no duplicate). */
    if (WiFi.getMode() == WIFI_STA) {
        fb_text_small(1, 8, WiFi.SSID().c_str(), 7, 1);
        fb_text_small(1, 15, WiFi.localIP().toString().c_str(), 11, 1);
    } else {
        fb_text_small(1, 8, AP_SSID, 7, 1);
        fb_text_small(1, 15, "192.168.4.1", 11, 1);
    }
    /* Show auto-run script name if set. */
    String autoName = get_autorun_name();
    if (autoName.length() > 0) {
        fb_text_small(1, 24, "auto:", 3, 1);
        fb_text_small(1, 31, autoName.c_str(), 11, 1);
    }
    fb_text_small(1, 56, "[RGT] scripts", 2, 1);
    display_mark_all_dirty();
}

/* ============================================================
 * File management — save/load arbitrary .js files in LittleFS
 * ============================================================
 * GET  /files             — JSON list of .js files with sizes
 * GET  /file?name=X.js    — returns file content as text/plain
 * POST /file?name=X.js    — body = file content; saves to LittleFS
 *
 * Files are stored with their original names (e.g. /game.js, /anim.js).
 * The boot script is still /boot.js + /boot.mjsb (handled by /save
 * and /load).  These endpoints are for the "file manager" in the web UI.
 */

static void http_files() {
    String json = "[";
    DirEntry entries[64];
    int n = fs_list_root_files(entries, 64);
    bool first = true;
    for (int i = 0; i < n; i++) {
        const String &name = entries[i].name;
        /* Only list .js files (skip .mjsb and other binary files). */
        if (!name.endsWith(".js")) continue;
        if (!first) json += ",";
        first = false;
        json += "{\"name\":\"" + jsonEscape(name) + "\",\"size\":" +
                String(entries[i].size) + "}";
    }
    json += "]";
    server.send(200, F("application/json"), json);
}

static void http_file_get() {
    if (!server.hasArg("name")) {
        server.send(400, F("text/plain"), F("missing name param"));
        return;
    }
    String name = "/" + server.arg("name");
    if (!LittleFS.exists(name)) {
        server.send(404, F("text/plain"), F("file not found"));
        return;
    }
    File f = LittleFS.open(name, "r");
    String content = f.readString();
    f.close();
    server.sendHeader("Content-Length", String(content.length()));
    server.send(200, F("text/plain"), content);
}

/* T51-fix: Upload handler for streaming file saves via multipart/form-data.
 * ESP8266WebServer calls this for each chunk of uploaded data.
 * State is stored in g_upload_* globals. */
static String g_upload_name;
static File g_upload_file;
static size_t g_upload_total;
static bool g_upload_is_mjsb;
static int g_upload_pending_digit;  /* for .mjsb decimal parsing */

static void handleFileUpload() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
        /* Get filename from query param (not from multipart — we use our own). */
        String name = server.hasArg("name") ? server.arg("name") : upload.filename;
        if (name.length() == 0) {
            DBG_PRINTLN("[upload] no filename");
            return;
        }
        g_upload_name = "/" + name;
        g_upload_is_mjsb = name.endsWith(".mjsb");
        g_upload_total = 0;
        g_upload_pending_digit = -1;
        g_upload_file = LittleFS.open(g_upload_name, "w");
        DBG_PRINT(PSTR("[upload] start %s (mjsb=%d)\n"),
                        g_upload_name.c_str(), (int)g_upload_is_mjsb);
    } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (!g_upload_file) return;
        if (g_upload_is_mjsb) {
            /* Parse comma-separated decimal → binary. */
            for (size_t i = 0; i < upload.currentSize; i++) {
                char c = (char)upload.buf[i];
                if (c >= '0' && c <= '9') {
                    if (g_upload_pending_digit < 0) g_upload_pending_digit = 0;
                    g_upload_pending_digit = g_upload_pending_digit * 10 + (c - '0');
                } else {
                    if (g_upload_pending_digit >= 0) {
                        g_upload_file.write((uint8_t)g_upload_pending_digit);
                        g_upload_total++;
                        g_upload_pending_digit = -1;
                    }
                }
            }
        } else {
            /* Raw bytes for .js. */
            g_upload_file.write(upload.buf, upload.currentSize);
            g_upload_total += upload.currentSize;
        }
    } else if (upload.status == UPLOAD_FILE_END) {
        if (g_upload_pending_digit >= 0) {
            g_upload_file.write((uint8_t)g_upload_pending_digit);
            g_upload_total++;
            g_upload_pending_digit = -1;
        }
        if (g_upload_file) g_upload_file.close();
        DBG_PRINT(PSTR("[upload] saved %s (%u bytes)\n"),
                        g_upload_name.c_str(), (unsigned)g_upload_total);
    } else if (upload.status == UPLOAD_FILE_ABORTED) {
        if (g_upload_file) g_upload_file.close();
        LittleFS.remove(g_upload_name);
        DBG_PRINTLN("[upload] aborted");
    }
}

static void http_file_put() {
    Serial.printf_P(PSTR("[file PUT] args=%d plain=%d\n"),
                    (int)server.args(),
                    (int)(server.hasArg("plain") ? server.arg("plain").length() : -1));
    if (!server.hasArg("name")) {
        server.send(400, F("text/plain"), F("missing name param"));
        return;
    }
    String name = "/" + server.arg("name");
    /* T51: Chunked save — append=1 opens file in append mode.
     * First chunk: name=x&append=new → create/truncate file.
     * Subsequent: name=x&append=1 → append to file.
     * Last: name=x&append=end → close, return total. */
    if (server.hasArg("append")) {
        String mode = server.arg("append");
        bool isFirst = (mode == "new");
        bool isLast = (mode == "end");
        /* T51-fix: Use server.arg("plain") — the WebUI now sends .mjsb
         * as comma-separated decimal text (Content-Type: text/plain),
         * so there are no NUL bytes and ESP32's WString strlen-truncation
         * bug doesn't apply.  The decimal format is detected by checking
         * the first byte (a digit) and parsed back to bytes. */
        String body = server.hasArg("plain") ? server.arg("plain") : String("");
        size_t body_len = body.length();
        DBG_PRINT(PSTR("[file] chunk %s mode=%s body=%u\n"),
                        name.c_str(), mode.c_str(), (unsigned)body_len);
        if (body_len == 0 && !isLast) {
            server.send(400, F("text/plain"), F("no body"));
            return;
        }
        File f = LittleFS.open(name, isFirst ? "w" : "a");
        if (!f) {
            server.send(500, F("text/plain"), F("cannot open file"));
            return;
        }
        if (body_len > 0) {
            if (name.endsWith(".mjsb") && body[0] >= '0' && body[0] <= '9') {
                /* Decimal .mjsb — parse comma-separated numbers to binary. */
                int p = 0;
                size_t written = 0;
                while (p < (int)body_len) {
                    while (p < (int)body_len && (body[p] == ' ' || body[p] == ',')) p++;
                    if (p >= (int)body_len) break;
                    int v = 0;
                    while (p < (int)body_len && body[p] >= '0' && body[p] <= '9') {
                        v = v * 10 + (body[p] - '0'); p++;
                    }
                    f.write((uint8_t)v);
                    written++;
                }
                DBG_PRINT(PSTR("[file] parsed %u decimal bytes → %s\n"),
                                (unsigned)written, name.c_str());
            } else {
                /* Raw bytes (text .js, or any non-decimal body) — write directly. */
                f.write((const uint8_t*)body.c_str(), body_len);
            }
        }
        size_t sz = f.size();
        f.close();
        DBG_PRINT(PSTR("[file] saved %s mode=%s final_size=%u\n"),
                        name.c_str(), mode.c_str(), (unsigned)sz);
        server.send(200, F("text/plain"), String(sz));
        return;
    }
    /* Check for delete flag. */
    if (server.hasArg("delete")) {
        LittleFS.remove(name);
        if (name.endsWith(".js")) {
            String mjsb = name.substring(0, name.length() - 3) + ".mjsb";
            LittleFS.remove(mjsb);
        }
        if (name.endsWith(".js")) {
            String baseName = name.substring(1, name.length() - 3);
            String autoName = get_autorun_name();
            if (autoName == baseName) {
                set_autorun_name("");
            }
        }
        server.send(200, F("text/plain"), "deleted " + name);
        return;
    }
    /* T51-fix: For multipart uploads, the body is already saved by
     * handleFileUpload.  Just return the result. */
    if (g_upload_total > 0) {
        server.send(200, F("text/plain"), String(g_upload_total) + "B");
        g_upload_total = 0;
        return;
    }
    /* T51-fix: Non-chunked save — body comes in as server.arg("plain")
     * (text/plain Content-Type).  For .mjsb files, the WebUI now sends
     * comma-separated decimal text (no NUL bytes), so ESP32's WString
     * strlen-truncation bug doesn't apply.  For .js files, the body is
     * plain text.  For .mjsb binary (legacy direct upload), the body
     * might be truncated at NUL — we detect this and report. */
    String body = server.hasArg("plain") ? server.arg("plain") : String("");
    size_t body_len = body.length();
    DBG_PRINT(PSTR("[file PUT non-chunked] name=%s body=%u\n"),
                    name.c_str(), (unsigned)body_len);
    if (body_len == 0) {
        server.send(400, F("text/plain"), F("no body"));
        return;
    }
    {
        File f = LittleFS.open(name, "w");
        if (!f) {
            DBG_PRINT(PSTR("[file] ERROR: cannot open %s for writing\n"),
                            name.c_str());
            server.send(500, F("text/plain"), F("cannot open file"));
            return;
        }
        size_t written = 0;
        if (name.endsWith(".mjsb")) {
            /* Check if body is decimal text (first byte is digit) or
             * raw binary (first byte is non-digit, e.g., 'M' from "MJSB"
             * magic header). */
            bool isDecimal = body[0] >= '0' && body[0] <= '9';
            if (isDecimal) {
                /* Comma-separated decimal — parse to binary. */
                int p = 0;
                size_t bc = 0;
                while (p < (int)body_len) {
                    while (p < (int)body_len && (body[p] == ' ' || body[p] == ',')) p++;
                    if (p >= (int)body_len) break;
                    int v = 0;
                    while (p < (int)body_len && body[p] >= '0' && body[p] <= '9') {
                        v = v * 10 + (body[p] - '0');
                        p++;
                    }
                    f.write((uint8_t)v);
                    bc++;
                }
                written = bc;
            } else {
                /* Raw binary (legacy path — may be truncated at NUL on ESP32). */
                written = f.write((const uint8_t*)body.c_str(), body_len);
            }
        } else {
            /* .js file — write text directly. */
            written = f.write((const uint8_t*)body.c_str(), body_len);
        }
        f.close();
        DBG_PRINT(PSTR("[file] wrote %u bytes to %s (close returned)\n"),
                        (unsigned)written, name.c_str());
        /* T51-fix: Post-save verification.  Verify the file actually
         * persisted to SPIFFS by re-opening it and checking the size.
         * This catches silent write failures (where f.write returns N
         * but the data never actually lands in flash). */
        if (LittleFS.exists(name)) {
            File vf = LittleFS.open(name, "r");
            size_t actualSize = vf.size();
            vf.close();
            DBG_PRINT(PSTR("[file] VERIFIED %s exists, size=%u (wrote=%u)\n"),
                            name.c_str(), (unsigned)actualSize, (unsigned)written);
            if (actualSize != written) {
                DBG_PRINT(PSTR("[file] WARNING: size mismatch! wrote=%u but verified=%u\n"),
                                (unsigned)written, (unsigned)actualSize);
            }
        } else {
            DBG_PRINT(PSTR("[file] ERROR: %s does NOT exist after save!\n"),
                            name.c_str());
        }
        server.send(200, F("text/plain"), String(written) + "B");
        return;
    }
    server.send(400, F("text/plain"), F("no body"));
}

/* ============================================================
 * Setup — 14-step boot sequence (verbatim from the original
 * quickjs_esp8266.ino, with mquickjs-specific steps removed).
 * The MCP23017 must be initialized BEFORE the TFT, because the
 * TFT CS line is on MCP23017 GPB0.  Without this sequence the
 * screen stays white because TFT CS is never driven LOW.
 * ============================================================ */
void setup() {
    Serial.begin(115200);
    delay(200);
#if defined(ESP8266)
    Serial.println(F("\n=== microjs T51 esp8266 boot ==="));
#elif defined(ESP32)
    Serial.println(F("\n=== microjs T51 esp32 boot (SPIFFS) ==="));
#endif

    /* ---- STEP 0: framebuffer + PROGMEM palette init ----
     * display_init() zeros the framebuffer + dirty mask and pushes
     * a black frame.  Note: it calls tft.fillScreen(TFT_BLACK),
     * which requires tft to already be initialized — so we call
     * display_init() AFTER step 8 (tft.begin).  Here we just zero
     * the framebuffer.
     * T51-fix: g_fb_dirty_rows is an array of uint64_t (1 element on
     * ESP8266 with 64 rows, 2 elements on ESP32 with 120 rows), so
     * we can't assign a scalar — use memset to zero the whole array. */
    memset(g_framebuffer, 0, FB_SIZE);
    memset(g_fb_dirty_rows, 0, sizeof(g_fb_dirty_rows));
    Serial.println(F("[0/14] framebuffer zeroed"));

    /* ---- STEP 1: WiFi OFF (CHIP8 calls this FIRST) ---- */
    WiFi.mode(WIFI_OFF);
    Serial.println(F("[1/14] WiFi OFF"));

    /* ---- STEP 1a: mount filesystem (LittleFS on ESP8266, SPIFFS on ESP32) ---- */
#if defined(ESP8266)
    LittleFSConfig fsCfg;
    fsCfg.setAutoFormat(true);
    LittleFS.setConfig(fsCfg);
    if (!LittleFS.begin()) {
        Serial.println(F("[1a]  LittleFS mount FAILED (trying format...)"));
        LittleFS.format();
        if (!LittleFS.begin()) {
            Serial.println(F("[1a]  LittleFS STILL failed — boot script disabled"));
        } else {
            Serial.println(F("[1a]  LittleFS mounted after format"));
        }
    } else {
        FSInfo info;
        if (LittleFS.info(info)) {
            Serial.printf_P(PSTR("[1a]  LittleFS: %u KB total, %u KB used\n"),
                          (unsigned)(info.totalBytes / 1024),
                          (unsigned)(info.usedBytes / 1024));
        }
        if (LittleFS.exists("/boot.mjsb")) {
            File f = LittleFS.open("/boot.mjsb", "r");
            saved_code_exists = true;
            saved_code_size = f.size();
            f.close();
            Serial.printf_P(PSTR("[1a]  boot script: %u bytes\n"),
                          (unsigned)saved_code_size);
        }
    }
#elif defined(ESP32)
    /* ESP32 + SPIFFS: begin() (with formatOnFail=true) mounts the SPIFFS
     * partition.  If mount fails, format() then try again. */
    if (!SPIFFS.begin(true)) {
        Serial.println(F("[1a]  SPIFFS mount FAILED (trying format...)"));
        SPIFFS.format();
        if (!SPIFFS.begin(false)) {
            Serial.println(F("[1a]  SPIFFS STILL failed — boot script disabled"));
        } else {
            Serial.println(F("[1a]  SPIFFS mounted after format"));
        }
    } else {
        Serial.printf_P(PSTR("[1a]  SPIFFS: %u KB total, %u KB used\n"),
                      (unsigned)(SPIFFS.totalBytes() / 1024),
                      (unsigned)(SPIFFS.usedBytes() / 1024));
        if (SPIFFS.exists("/boot.mjsb")) {
            File f = SPIFFS.open("/boot.mjsb", "r");
            saved_code_exists = true;
            saved_code_size = f.size();
            f.close();
            Serial.printf_P(PSTR("[1a]  boot script: %u bytes\n"),
                          (unsigned)saved_code_size);
        }
    }
#endif

    /* ---- STEP 2: I2C + MCP23017 begin ----
     * Wire.begin() with no args uses default SDA=GPIO4, SCL=GPIO5
     * on ESP8266.  MCP23017 IODIRA and IODIRB are set to all-inputs
     * as a safe starting state. */
    Wire.begin();
    Wire.setClock(400000);
    mcp_writeReg(0x00, 0xFF);  /* IODIRA = all inputs */
    mcp_writeReg(0x01, 0xFF);  /* IODIRB = all inputs */
    Serial.println(F("[2/14] MCP23017 @0x20: IODIRA=0xFF, IODIRB=0xFF"));

    /* ---- STEP 3: probe MCP4725 (backlight DAC) ---- */
    {
        Wire.beginTransmission(MCP4725_ADDR);
        bool dac_ok = !Wire.endTransmission();
        Serial.printf_P(PSTR("[3/14] MCP4725 @0x60: %s\n"),
                      dac_ok ? "OK" : "NOT DETECTED");
    }

    /* ---- STEP 4: GPA0..GPA7 = INPUT + pull-up (8 buttons) ---- */
    for (uint8_t i = 0; i < 8; i++) {
        mcp_pinMode(i, INPUT);
        mcp_pullUp(i, HIGH);
    }
    Serial.println(F("[4/14] GPA0..GPA7 = INPUT + pull-up (8 buttons)"));

    /* ---- STEP 5: LEDLOCK (GPB1) = OUTPUT, LOW ----
     * GPB1 drives the 74HCT125 latch that gates WS2812B data. */
    mcp_pinMode(LEDLOCK_PIN, OUTPUT);
    mcp_digitalWrite(LEDLOCK_PIN, LOW);
    Serial.println(F("[5/14] GPB1 (LEDLOCK) = OUTPUT, LOW"));

    /* ---- STEP 6: TFT CS (GPB0) = OUTPUT, LOW ----
     * CRITICAL: TFT CS must be LOW before tft.begin(), otherwise
     * the TFT controller never sees the init commands and the
     * screen stays white. */
    mcp_pinMode(CSTFT_PIN, OUTPUT);
    mcp_digitalWrite(CSTFT_PIN, LOW);
    Serial.println(F("[6/14] GPB0 (CSTFT) = OUTPUT, LOW"));

    /* ---- STEP 7: backlight OFF before TFT init ---- */
    dac_write(0, false);
    Serial.println(F("[7/14] backlight = 0 (off during TFT init)"));

    /* ---- STEP 8: TFT init — exact CHIP8 call order ----
     * tft.begin() sends the ST7735 init sequence over SPI.
     * setSwapBytes(true) fixes byte order: ESP8266 is little-endian,
     * ST7735 expects big-endian RGB565 on SPI. */
    display_backend_init();
    delay(100);
    display_backend_fillScreen(0x0000);
    Serial.println(F("[8/14] display init + fillScreen(BLACK)"));

    /* Now that tft is alive, call display_init() to push the
     * initial black frame and mark the framebuffer as clean. */
    display_init();
    Serial.println(F("[8b]  display_init() — framebuffer + palette ready"));

    /* ---- STEP 9: (debug test pattern removed) ---- */

    /* ---- STEP 10: fade backlight in ---- */
    for (uint16_t b = 300; b < 2500; b += 30) {
        dac_write(b, false);
        delay(10);
    }
    Serial.println(F("[10/14] backlight faded 300 -> 2500"));

    /* ---- STEP 11: full brightness ---- */
    delay(500);
    dac_write(4095, false);
    Serial.println(F("[11/14] backlight = 4095 (full brightness)"));

    /* ---- STEP 1b: init JS engine (just to have a valid g_ctx) ---- */
    g_ctx = mjs_init(g_js_heap, JS_HEAP_SIZE);
    mjs_set_gc_hook(g_ctx, gc_walk_timers, NULL);
    mjs_set_yield_callback([]() -> bool {
        /* T51: Process pending HTTP requests during long-running scripts.
         * This allows /run to interrupt an infinite loop (e.g. game).
         * If http_run receives a new /run, it sets g_script_abort = true. */
        server.handleClient();
        return g_script_abort;
    });
    /* T51-fix: Register C-side MJSValue pointers as compaction roots.
     * When compaction moves heap blocks, these pointers must be updated
     * or they become dangling. */
    mjs_clear_compact_roots();
    mjs_add_compact_root(&g_js_http_handler);
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        mjs_add_compact_root(&g_timers[i].cb);
    }
    Serial.printf_P(PSTR("[1b]  JS heap: %u bytes, free system heap: %u\n"),
                  (unsigned)JS_HEAP_SIZE, (unsigned)ESP.getFreeHeap());

    /* Seed RNG.  ESP_CHIP_ID() = ESP.getChipId() on ESP8266,
     * ESP.getEfuseMac() on ESP32 (ESP32 has no getChipId()). */
    g_rng = ((uint64_t)micros() << 16) ^ (uint64_t)ESP_CHIP_ID() ^ 0x9E3779B97F4A7C15ULL;
    if (g_rng == 0) g_rng = 1;

    /* ---- STEP 12: start WiFi ----
     * T51: Try STA mode first (connect to router with saved credentials).
     * If no credentials or connection fails within 8s, fall back to AP. */
    Serial.println(F("[12/14] starting WiFi ..."));
    WiFi.persistent(false);
    bool staConnected = false;

    /* Try to read saved WiFi credentials from LittleFS. */
    if (LittleFS.exists("/wifi.txt")) {
        File wf = LittleFS.open("/wifi.txt", "r");
        if (wf) {
            String wifiData = wf.readString();
            wf.close();
            /* Format: SSID\nPASSWORD */
            int newline = wifiData.indexOf('\n');
            String sta_ssid, sta_pass;
            if (newline > 0) {
                sta_ssid = wifiData.substring(0, newline);
                sta_pass = wifiData.substring(newline + 1);
                sta_pass.trim();
            } else {
                sta_ssid = wifiData;
                sta_pass = "";
            }
            sta_ssid.trim();
            if (sta_ssid.length() > 0) {
                Serial.printf_P(PSTR("  STA: connecting to '%s'...\n"), sta_ssid.c_str());
                /* T51: Show connecting animation on TFT. */
                fb_cls();
#if defined(ESP8266)
                fb_text_small(1, 1, "mjs T51 esp8266", 11, 1);
#elif defined(ESP32)
                fb_text_small(1, 1, "mjs T51 esp32", 11, 1);
#endif
                fb_text_small(1, 10, "Connecting to:", 3, 1);
                fb_text_small(1, 18, sta_ssid.c_str(), 7, 1);
                display_mark_all_dirty();
                display_flush_now();

                WiFi.mode(WIFI_STA);
                WiFi.begin(sta_ssid.c_str(), sta_pass.length() > 0 ? sta_pass.c_str() : nullptr);
                WiFi.setSleep(false);

                /* T51: Try connecting up to 3 times, 10 seconds each.
                 * Log the WiFi status code on failure for diagnostics. */
                for (int attempt = 1; attempt <= 3 && !staConnected; attempt++) {
                    Serial.printf_P(PSTR("  STA: attempt %d/3 to '%s'...\n"),
                                    attempt, sta_ssid.c_str());
                    if (attempt > 1) {
                        /* Re-trigger connection for subsequent attempts. */
                        WiFi.disconnect();
                        delay(500);
                        WiFi.begin(sta_ssid.c_str(), sta_pass.length() > 0 ? sta_pass.c_str() : nullptr);
                    }
                    uint32_t startWait = millis();
                    int dotCount = 0;
                    int lastStatus = -1;
                    while (millis() - startWait < 10000) {
                        int st = WiFi.status();
                        if (st != lastStatus) {
                            /* Log status changes for diagnostics. */
                            const char *sn = "unknown";
                            switch (st) {
                                case WL_IDLE_STATUS: sn = "IDLE"; break;
                                case WL_NO_SSID_AVAIL: sn = "NO_SSID_AVAIL"; break;
                                case WL_SCAN_COMPLETED: sn = "SCAN_COMPLETED"; break;
                                case WL_CONNECT_FAILED: sn = "CONNECT_FAILED"; break;
                                case WL_CONNECTION_LOST: sn = "CONNECTION_LOST"; break;
                                case WL_DISCONNECTED: sn = "DISCONNECTED"; break;
                                case WL_CONNECTED: sn = "CONNECTED"; break;
                            }
                            Serial.printf_P(PSTR("  STA status: %d (%s)\n"), st, sn);
                            lastStatus = st;
                        }
                        if (st == WL_CONNECTED) {
                            staConnected = true;
                            break;
                        }
                        /* Animate dots every 300ms. */
                        if ((millis() - startWait) % 300 < 50) {
                            for (int px = 0; px < 64; px++)
                                for (int py = 28; py < 36; py++)
                                    g_framebuffer[py * FB_W + px] = 0;
                            dotCount = (dotCount % 3) + 1;
                            for (int d = 0; d < dotCount; d++)
                                fb_text_small(1 + d * 6, 28, ".", 11, 1);
                            display_mark_all_dirty();
                            display_flush_now();
                        }
                        delay(50);
                        yield();
                    }
                }
                if (staConnected) {
                    Serial.print(F("  STA IP: "));
                    Serial.println(WiFi.localIP());
                    /* Show "Connected!" briefly. */
                    fb_cls();
#if defined(ESP8266)
                    fb_text_small(1, 1, "mjs T51 esp8266", 11, 1);
#elif defined(ESP32)
                    fb_text_small(1, 1, "mjs T51 esp32", 11, 1);
#endif
                    fb_text_small(1, 10, "Connected!", 2, 1);
                    String ipStr = WiFi.localIP().toString();
                    fb_text_small(1, 18, ipStr.c_str(), 11, 1);
                    display_mark_all_dirty();
                    display_flush_now();
                    delay(1000);
                } else {
                    Serial.println(F("  STA: failed, falling back to AP"));
                    /* Show fallback message. */
                    fb_cls();
#if defined(ESP8266)
                    fb_text_small(1, 1, "mjs T51 esp8266", 11, 1);
#elif defined(ESP32)
                    fb_text_small(1, 1, "mjs T51 esp32", 11, 1);
#endif
                    fb_text_small(1, 10, "WiFi failed", 1, 1);
                    fb_text_small(1, 18, "Using AP:", 3, 1);
                    fb_text_small(1, 26, AP_SSID, 7, 1);
                    display_mark_all_dirty();
                    display_flush_now();
                    delay(1500);
                }
            }
        }
    }

    if (!staConnected) {
        /* Fall back to AP mode. */
        WiFi.mode(WIFI_AP);
        WiFi.softAP(AP_SSID, (AP_PASS[0] ? AP_PASS : nullptr),
                    1, false, AP_MAX_CLIENTS);
        WiFi.setSleep(false);  /* T51: keep radio always on */
        Serial.print(F("  AP IP: ")); Serial.println(WiFi.softAPIP());
        Serial.printf_P(PSTR("  Connect to Wi-Fi '%s' (%s)\n"),
                      AP_SSID, (AP_PASS[0] ? "WPA" : "open"));
    }

    /* ---- STEP 12b: draw splash on TFT ---- */
    draw_splash();
    display_flush_now();  /* push splash immediately (bypass throttle) */
    Serial.println(F("[12b]  splash drawn on TFT"));

    /* ---- STEP 13: start HTTP server ---- */
    server.on("/",            HTTP_GET,  http_root);     /* T51: / → JS or redirect to /edit */
    server.on("/edit",        HTTP_GET,  http_edit);     /* T51: web editor (always) */
    server.on("/compiler.js", HTTP_GET,  http_compiler_js);
    server.on("/globals",     HTTP_GET,  http_globals);  /* T51: native names for compiler */
    server.on("/favicon.ico", HTTP_GET,  http_favicon);  /* T51: embedded PNG favicon */
    server.on("/run",         HTTP_POST, http_run);
    server.on("/save",        HTTP_POST, http_save);
    server.on("/load",        HTTP_GET,  http_load);
    server.on("/clear",       HTTP_POST, http_clear);
    server.on("/mem",         HTTP_GET,  http_mem);
    server.on("/files",       HTTP_GET,  http_files);
    server.on("/file",        HTTP_GET,  http_file_get);
    server.on("/file",        HTTP_POST, http_file_put);
    /* T51: /autorun — GET returns current auto-run name, POST sets it. */
    server.on("/autorun", HTTP_GET, []() {
        String name = get_autorun_name();
        String json = "{\"autorun\":\"" + name + "\"}";
        server.send(200, F("application/json"), json);
    });
    server.on("/autorun", HTTP_POST, []() {
        if (!server.hasArg("plain")) {
            server.send(400, F("text/plain"), F("missing body"));
            return;
        }
        String body = server.arg("plain");
        body.trim();
        set_autorun_name(body);
        String resp = body.length() > 0 ? ("autorun set to: " + body) : "autorun cleared";
        server.send(200, F("text/plain"), resp);
        Serial.println(resp);
    });
    /* T51: /wifi — GET returns current WiFi mode + IP.
     * POST with body "SSID\nPASSWORD" saves credentials and reboots.
     * POST with empty body clears credentials. */
    server.on("/wifi", HTTP_GET, []() {
        String mode = (WiFi.getMode() == WIFI_STA) ? "STA" : "AP";
        String ip = (WiFi.getMode() == WIFI_STA) ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
        String ssid = (WiFi.getMode() == WIFI_STA) ? WiFi.SSID() : String(AP_SSID);
        String json = "{\"mode\":\"" + mode + "\",\"ip\":\"" + ip + "\",\"ssid\":\"" + ssid + "\"}";
        server.send(200, F("application/json"), json);
    });
    server.on("/wifi", HTTP_POST, []() {
        if (!server.hasArg("plain")) {
            server.send(400, F("text/plain"), F("missing body"));
            return;
        }
        String body = server.arg("plain");
        body.trim();
        if (body.length() == 0) {
            /* Clear credentials. */
            LittleFS.remove("/wifi.txt");
            server.send(200, F("text/plain"), F("WiFi cleared. Rebooting to AP mode..."));
            Serial.println(F("[wifi] cleared, rebooting..."));
            delay(500);
            ESP.restart();
        } else {
            /* Save credentials. Format: SSID\nPASSWORD */
            File wf = LittleFS.open("/wifi.txt", "w");
            if (!wf) {
                server.send(500, F("text/plain"), F("cannot save wifi config"));
                return;
            }
            wf.print(body);
            wf.close();
            server.send(200, F("text/plain"), F("WiFi saved. Rebooting to connect..."));
            Serial.printf_P(PSTR("[wifi] saved: %s\n"), body.c_str());
            delay(500);
            ESP.restart();
        }
    });
    /* T51: Captive portal — redirect ALL unknown URLs to the editor.
     * When a phone/laptop connects to the "MicroJS-AP" WiFi, the OS
     * probes for internet by requesting URLs like:
     *   - http://connectivitycheck.gstatic.com/generate_204
     *   - http://msftconnecttest.com/redirect
     *   - http://www.apple.com/library/test/success.html
     *   - http://detectportal.firefox.com/canonical.html
     * By responding with a 302 redirect to our editor (http://192.168.4.1/),
     * the OS opens the browser automatically and the user sees the editor
     * without typing the IP.  This is the "captive portal" technique.
     *
     * For Android: the redirect must go to http://192.168.4.1/ (not https).
     * For iOS: the redirect is followed in a mini-browser (captive portal
     *   view), but tapping "Open" opens Safari with our editor.
     * For Windows: the redirect opens in a "Network Login" mini-browser.
     *
     * We detect portal probes by checking if the Host header is NOT
     * 192.168.4.1 (or our IP).  If it's a different host, it's a probe. */
    server.onNotFound([]() {
        String uri = server.uri();
        DBG_PRINT(PSTR("[onNotFound] %s %s (args=%d js_active=%d)\n"),
                        server.method() == HTTP_GET ? "GET" :
                        server.method() == HTTP_POST ? "POST" : "OTHER",
                        uri.c_str(), (int)server.args(),
                        (int)g_js_http_active);
        /* T51: If JS HTTP server is active, route ALL unmatched requests
         * to JS handler — EXCEPT system paths. */
        if (uri == "/file" || uri == "/run" || uri == "/save" ||
            uri == "/edit" || uri == "/compiler.js" || uri == "/globals" ||
            uri == "/favicon.ico" || uri == "/files" || uri == "/mem" ||
            uri == "/autorun" || uri == "/wifi" || uri == "/load" ||
            uri == "/clear") {
            DBG_PRINT(PSTR("[onNotFound] system path — 404\n"));
            server.send(404, F("text/plain"), F("not found"));
            return;
        } else if (g_js_http_active && g_js_http_handler != MJS_UNDEF_V && g_ctx) {
            http_root();
            return;
        }
        IPAddress ip = WiFi.softAPIP();
        String my_ip = ip.toString();
        String host = server.hostHeader();
        host.toLowerCase();
        int colon = host.indexOf(':');
        if (colon > 0) host = host.substring(0, colon);
        bool is_portal_probe = (host != my_ip && host != "192.168.4.1");
        String url = "http://" + my_ip + "/edit";
        if (is_portal_probe) {
            server.sendHeader("Location", url, true);
            server.send(302, F("text/plain"), F(""));
        } else {
            server.sendHeader("Location", url, true);
            server.send(302, F("text/plain"), F(""));
        }
    });
    /* T51-fix: Collect Content-Length header so http_file_put can read
     * body size for streaming saves (application/octet-stream doesn't
     * get body parsed by ESP8266WebServer automatically).
     * ESP8266WebServer 3.x exposes a variadic-template collectHeaders(String...).
     * ESP32 WebServer (core 1.0.4) expects (const char*[], size_t). */
#if defined(ESP8266)
    server.collectHeaders(String("Content-Length"));
#elif defined(ESP32)
    {
        const char* keys[1] = { "Content-Length" };
        server.collectHeaders(keys, 1);
    }
#endif
    server.begin();
    Serial.println(F("[13/14] HTTP server on :80"));

    /* ---- STEP 14: done ---- */
    Serial.println(F("[14/14] ready."));
    Serial.println(F("POST bytecode to /run  — response is JSON"));
    Serial.println(F("POST JSON {source,bytecode} to /save  — saves /boot.js + /boot.mjsb"));
    Serial.println(F("RGT button opens script selector"));
    Serial.println();

    /* T51: Auto-run — if /autorun.txt exists and points to a valid
     * .mjsb file, run it immediately after boot. */
    String autoName = get_autorun_name();
    if (autoName.length() > 0) {
        String path = "/" + autoName + ".mjsb";
        if (LittleFS.exists(path)) {
            Serial.printf_P(PSTR("[autorun] running %s...\n"), autoName.c_str());
            run_script(path.c_str());
            /* run_script flushes display + delays 2s.
             * Don't call draw_splash — leave the script's output visible.
             * User presses RGT to access script selector. */
        } else {
            Serial.printf_P(PSTR("[autorun] %s.mjsb not found\n"), autoName.c_str());
        }
    }
}

/* ============================================================
 * Main loop
 * ============================================================ */
void loop() {
    server.handleClient();

    /* Fire any pending timer callbacks.  This is the event loop for
     * setInterval/setTimeout.  Each call to timers_tick() invokes at
     * most one round of due timers; if any fire, the JS callback may
     * register more timers or clear existing ones. */
    if (timers_has_pending() && g_ctx) {
        timers_tick();
    }

    /* Run saved boot script on button 128 (RGT).
     * Button bit mask (ESPboy PCB, MCP23017 GPA0..GPA7):
     *   bit 0 (0x001) = left
     *   bit 1 (0x002) = up
     *   bit 2 (0x004) = down
     *   bit 3 (0x008) = right
     *   bit 4 (0x010) = A
     *   bit 5 (0x020) = B
     *   bit 7 (0x080) = RGT (the "right-action" button — runs boot script)
     * (bit 6 is unused on most ESPboy boards) */
    uint8_t btn = ~mcp_readReg(0x12) & 0xFF;
    if (btn & 0x80) {  /* RGT button — opens script selector */
        delay(50);  /* debounce */
        show_script_selector();
        /* Wait for button release. */
        while (~mcp_readReg(0x12) & 0x80) delay(10);
    }

    /* Display flush (15 FPS dirty-row flush). */
    display_tick();

    /* T51: Serial REPL — type JS code in Serial Monitor, it compiles
     * on-device and runs immediately.  Single-line only: each line
     * ending with ';' or '}' is compiled and executed as a complete
     * statement.  Multi-line input was removed because the terminator
     * detection was fragile and confusing.
     *
     * T51-fix: REPL output buffer (1 KB) is malloc'd at compile time
     * and free'd after run.  Combined with heap-allocated compiler
     * buffers in microjs_repl.h, REPL holds 0 B when idle.
     *
     * T51-fix: hard cap on input line length to prevent OOM from
     * malformed or flooded serial input. */
    static String repl_current;
    #define REPL_MAX_INPUT 2048
    while (Serial.available()) {
        char c = Serial.read();
        if (c == '\r') continue;
        if (c == '\n') {
            String trimmed = repl_current;
            trimmed.trim();
            repl_current = "";
            if (trimmed.length() == 0) continue;
            /* Only execute lines that look like complete statements. */
            if (!trimmed.endsWith(";") && !trimmed.endsWith("}")) {
                Serial.println(F("[repl] line must end with ; or }"));
                continue;
            }
            /* Heap-alloc output buffer — freed after run.
             * Each JS token typically expands to 1-3 bytes of bytecode. */
            uint8_t *repl_out = (uint8_t*)malloc(1024);
            if (!repl_out) {
                Serial.println(F("[repl] OOM"));
            } else {
                int sz = repl_compile(trimmed.c_str(), repl_out, 1024);
                if (sz <= 0) {
                    Serial.println(F("[repl] compile error"));
                } else if (sz > 1024) {
                    Serial.println(F("[repl] bytecode too large (>1KB)"));
                } else {
                    /* Reset context for REPL (keep natives) */
                    timers_clear_all();
                    if (g_boot_blob) { free(g_boot_blob); g_boot_blob = NULL; }
                    g_ctx = mjs_init(g_js_heap, JS_HEAP_SIZE);
                    if (g_ctx) {
                        mjs_set_gc_hook(g_ctx, gc_walk_timers, NULL);
    mjs_clear_compact_roots();
    mjs_add_compact_root(&g_js_http_handler);
    for (int i = 0; i < MJS_MAX_TIMERS; i++) {
        mjs_add_compact_root(&g_timers[i].cb);
    }
                        if (mjs_load_bytecode(g_ctx, repl_out, sz) == 0) {
                            register_natives();
                            out_reset();
                            g_capture_active = true;
                            int r = mjs_run(g_ctx);
                            g_capture_active = false;
                            if (r != 0) {
                                Serial.print(F("[repl] error: "));
                                Serial.println(mjs_last_error(g_ctx));
                            }
                            /* Print captured output */
                            if (g_out_len > 0) {
                                Serial.print(F("[repl] "));
                                Serial.println(g_out_buf);
                            }
                            display_mark_all_dirty();
                        }
                    }
                }
                free(repl_out);
            }
        } else {
            /* Cap repl_current to prevent unbounded growth. */
            if (repl_current.length() < REPL_MAX_INPUT) {
                repl_current += c;
            }
        }
    }

    yield();
}
