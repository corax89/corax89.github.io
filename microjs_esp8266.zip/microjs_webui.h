/* microjs_webui.h — T32 web UI for ESPboy microjs REPL.
 *
 * Features:
 *   - PrismJS syntax highlighting (compact, inlined)
 *   - File manager (save/load .js files to LittleFS)
 *   - Compile in browser, send bytecode to device
 *   - Performance benchmark example
 *
 * SPDX-License-Identifier: MIT
 */
#ifndef MICROJS_WEBUI_H
#define MICROJS_WEBUI_H

static const char WEBUI_INDEX_HTML[] PROGMEM = R"HTML(
<!DOCTYPE html>
<html lang=en>
<head>
<meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<link rel=icon type=image/png href=/favicon.ico>
<title>microjs ESPboy</title>
<style>
body{font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#1e1e1e;color:#d4d4d4;margin:0;padding:8px;max-width:100%;height:100vh;box-sizing:border-box;display:flex;flex-direction:column;overflow:hidden}
h1{font-size:18px;margin:8px 0;color:#4ec9b0}
.toolbar{display:flex;gap:4px;flex-wrap:wrap;align-items:center;margin:4px 0}
.toolbar button{background:#0e639c;color:#fff;border:none;padding:5px 10px;border-radius:3px;cursor:pointer;font:inherit}
.toolbar button:hover{background:#1177bb}
.toolbar button.save{background:#388a34}
.toolbar button.del{background:#a1260d}
.toolbar select{background:#252526;color:#d4d4d4;border:1px solid #3c3c3c;padding:4px;border-radius:3px;font:inherit;max-width:120px}
.editor{position:relative;margin:4px 0;display:flex;flex:1;min-height:120px}
.editor .gutter{width:38px;flex-shrink:0;background:#1e1e1e;color:#858585;font:13px/1.4 "Cascadia Code",Consolas,monospace;padding:8px 4px 8px 0;text-align:right;user-select:none;overflow:hidden;z-index:3;box-sizing:border-box;border:1px solid #3c3c3c;border-right:none;border-radius:3px 0 0 3px;white-space:pre}
.editor .code-wrap{position:relative;flex:1}
.editor pre{margin:0;position:absolute;top:0;left:0;width:100%;height:100%;overflow:hidden;font:13px/1.4 "Cascadia Code",Consolas,monospace;padding:8px;box-sizing:border-box;tab-size:2;white-space:pre;pointer-events:none;z-index:1}
.editor textarea{position:relative;width:100%;height:100%;background:transparent;color:transparent;caret-color:#d4d4d4;border:1px solid #3c3c3c;font:13px/1.4 "Cascadia Code",Consolas,monospace;padding:8px;box-sizing:border-box;tab-size:2;resize:none;z-index:2;outline:none;white-space:pre;overflow:auto;word-wrap:normal}
.editor textarea:focus{border-color:#007acc}
.err{color:#f48771;background:#5a1d1d;padding:4px 8px;margin:4px 0;border-radius:3px;font:13px/1.4 monospace;white-space:pre-wrap}
.err-line{background:#5a1d1d !important}
.err-highlight{position:absolute;left:0;right:0;height:18px;background:rgba(244,135,113,0.15);pointer-events:none;z-index:0;display:none}
.out{background:#252526;color:#dcdcdc;padding:8px;margin:4px 0;border-radius:3px;font:13px/1.4 monospace;white-space:pre-wrap;min-height:1em;height:90px;max-height:50vh;flex-shrink:0;overflow:auto}
.out.expanded{height:50vh;max-height:50vh}
.meta{font:11px/1.4 monospace;color:#888;margin:4px 0;flex-shrink:0}
.help-panel{display:none;background:#252526;padding:8px;margin:8px 0;border-radius:3px;font-size:12px;max-height:300px;overflow:auto}
.help-panel h2{margin:4px 0;color:#569cd6;font-size:14px}
.help-panel table{border-collapse:collapse;margin:4px 0}
.help-panel td{padding:1px 8px 1px 0}
.hint{color:#888;font-size:11px;margin:2px 0}
.editor pre code{display:inline-block;min-width:100%}
.token.comment,.token.prolog,.token.doctype,.token.cdata{color:#6a9955}
.token.punctuation{color:#d4d4d4}
.token.keyword{color:#c586c0}
.token.string{color:#ce9178}
.token.number{color:#b5cea8}
.token.boolean{color:#569cd6}
.token.function{color:#dcdcaa}
.token.operator{color:#d4d4d4}
.token.property{color:#9cdcfe}
.token.tag{color:#569cd6}
.token.attr-name{color:#9cdcfe}
.token.attr-value{color:#ce9178}
/* T51: Sprite editor — responsive (vertical on phone, horizontal on desktop) */
.modal-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:100;display:none;align-items:center;justify-content:center}
.modal-overlay.show{display:flex}
.sprite-editor{background:#1e1e1e;border:1px solid #3c3c3c;border-radius:6px;padding:12px;box-shadow:0 8px 32px rgba(0,0,0,0.5);font:13px/1.4 "Cascadia Code",Consolas,monospace;color:#d4d4d4;max-width:92vw;max-height:96vh;overflow-y:auto;overflow-x:hidden;box-sizing:border-box}
.sprite-editor h2{margin:0 0 8px 0;color:#4ec9b0;font-size:15px}
/* T51-fix: se-row now uses column on narrow screens (phone portrait)
 * and row on wide screens (desktop).  This stacks canvas on top and
 * palette below on phones, fitting a vertical screen. */
.sprite-editor .se-row{display:flex;flex-direction:column;gap:10px;align-items:center;overflow:hidden}
.sprite-editor .se-canvas-wrap{display:flex;flex-direction:column;gap:6px;align-items:center;width:100%}
.sprite-editor canvas{border:2px solid #3c3c3c;background:#000;cursor:crosshair;image-rendering:pixelated;image-rendering:crisp-edges;max-width:90vw;max-height:50vh}
.sprite-editor .se-palette-wrap{display:flex;flex-direction:column;gap:6px;width:100%;align-items:center;overflow:hidden}
/* T51-fix: palette grid is 8 columns, wraps to fit narrow screens.
 * On phone (320px wide), 8 cols × ~32px = 256px fits.  On very narrow
 * screens, swatches shrink to 28px to fit 8 columns. */
.sprite-editor .se-palette{display:grid;grid-template-columns:repeat(8,1fr);gap:3px;width:100%;max-width:280px}
.sprite-editor .se-swatch{width:100%;aspect-ratio:1;min-height:24px;border:2px solid #3c3c3c;border-radius:3px;cursor:pointer}
.sprite-editor .se-swatch.sel{border-color:#007acc;box-shadow:0 0 0 2px rgba(0,122,204,0.4)}
.sprite-editor .se-controls{display:flex;flex-direction:row;gap:10px;margin-top:4px;justify-content:center;flex-wrap:wrap}
.sprite-editor label{display:flex;align-items:center;gap:4px}
.sprite-editor input[type=number]{width:44px;background:#252526;color:#d4d4d4;border:1px solid #3c3c3c;border-radius:3px;padding:2px 4px;font:inherit}
.sprite-editor .se-buttons{display:flex;gap:8px;margin-top:10px;justify-content:flex-end}
.sprite-editor .se-buttons button{background:#0e639c;color:#fff;border:none;padding:6px 14px;border-radius:3px;cursor:pointer;font:inherit}
.sprite-editor .se-buttons button:hover{background:#1177bb}
.sprite-editor .se-buttons button.cancel{background:#5a1d1d}
.sprite-editor .se-buttons button.cancel:hover{background:#7a2d2d}
.sprite-editor .se-hint{font-size:11px;color:#888;margin:4px 0;text-align:center}
/* T51-fix: on wider screens (landscape / desktop), use horizontal layout */
@media(min-width:600px){
  .sprite-editor{max-width:560px}
  .sprite-editor .se-row{flex-direction:row;align-items:flex-start;gap:16px}
  .sprite-editor .se-canvas-wrap{width:auto}
  .sprite-editor .se-palette-wrap{width:auto}
  .sprite-editor .se-palette{width:248px;max-width:248px}
  .sprite-editor .se-swatch{width:26px;min-height:26px}
}
</style>
</head>
<body>
<div id=loadingOverlay style="position:fixed;top:0;left:0;width:100%;height:100%;background:#1e1e1e;z-index:9999;display:flex;align-items:center;justify-content:center;flex-direction:column">
  <h2 style="color:#4ec9b0;margin:0 0 8px">microjs ESPboy</h2>
  <p id=loadingStatus style="color:#888;font-size:14px">Loading compiler...</p>
  <p style="color:#666;font-size:11px;margin-top:4px">If this persists, check WiFi connection</p>
</div>
<h1>microjs ESPboy &mdash; T51</h1>

<div class=toolbar>
  <select id=filesel onchange=loadFile()><option value="">— files —</option></select>
  <button onclick=newFile()>New</button>
  <button class=save onclick=saveFile()>Save File</button>
  <button class=del onclick=delFile()>Delete</button>
  <button onclick=toggleAutorun()>Auto-run</button>
  <button onclick=loadFiles()>Refresh</button>
  <select id=samplesel onchange=loadSample()><option value="">— examples —</option></select>
</div>

<div class=editor>
  <div class=gutter id=gutter><div id=gutterInner></div></div>
  <div class=code-wrap>
    <div class=err-highlight id=errhl></div>
    <pre id=hl><code class=language-js></code></pre>
    <textarea id=code spellcheck=false>// microjs ESPboy — globals:
// print(), millis(), delay(ms), mem(), gc(), keys(), keysPressed(), keysReleased()
// setTimeout/setInterval/clearTimeout, tft.*, String.*, Array.*
// Math.floor/random/abs/min/max, console.log
// Buttons: LEFT=1 UP=2 DOWN=4 RIGHT=8 A=16 B=32 RGT=128

tft.cls();
tft.text(4, 4, "Hello!", 3, 2);
tft.flip();
print("heap:", mem());
</textarea>
  </div>
</div>

<div class=toolbar>
  <button onclick=runCode()>Run</button>
  <button onclick=openSpriteEditor()>Sprite Editor</button>
  <button onclick=showBytecode()>Bytecode</button>
  <button onclick=clearOutput()>Clear</button>
  <button onclick=toggleHelp()>? Help</button>
  <button onclick=toggleWifi()>WiFi</button>
</div>

<div id=err class=err style=display:none></div>
<pre id=out class=out>(output appears here)</pre>
<div id=meta class=meta></div>

<!-- T51: Sprite Editor modal -->
<div class="modal-overlay" id=spriteModal>
  <div class="sprite-editor">
    <h2>Sprite Editor</h2>
    <div class=se-row>
      <div class=se-canvas-wrap>
        <canvas id=seCanvas width=256 height=256></canvas>
        <div class=se-controls>
          <label>W: <input type=number id=seW min=2 max=16 value=8></label>
          <label>H: <input type=number id=seH min=2 max=16 value=8></label>
        </div>
      </div>
      <div class=se-palette-wrap>
        <div class=se-palette id=sePalette></div>
        <div class=se-hint style=margin-top:8px>Click to draw, Right-click to erase<br>Color: <span id=seColorInfo>1</span> <span id=seColorRGB style="color:#888;font-family:monospace"></span></div>
      </div>
    </div>
    <div class=se-buttons>
      <button class=cancel onclick=closeSpriteEditor()>Cancel</button>
      <button onclick=applySprite()>OK</button>
    </div>
  </div>
</div>

<div id=wifiPanel class=help-panel>
  <h2>WiFi Settings</h2>
  <p id=wifiStatus>Loading...</p>
  <label>SSID: <input id=wifiSsid type=text style="background:#252526;color:#d4d4d4;border:1px solid #3c3c3c;border-radius:3px;padding:2px 4px;font:inherit;width:140px"></label>
  <label>Password: <input id=wifiPass type=password style="background:#252526;color:#d4d4d4;border:1px solid #3c3c3c;border-radius:3px;padding:2px 4px;font:inherit;width:140px"></label>
  <button onclick=saveWifi() style="background:#0e639c;color:#fff;border:none;padding:4px 10px;border-radius:3px;cursor:pointer;font:inherit">Save & Reboot</button>
  <button onclick=clearWifi() style="background:#5a1d1d;color:#fff;border:none;padding:4px 10px;border-radius:3px;cursor:pointer;font:inherit">Clear (use AP)</button>
</div>

<div id=help class=help-panel>
  <h2>API Reference</h2>
  <h3>Globals</h3>
  <table>
    <tr><td><code>print(...args)</code></td><td>print to output + serial</td></tr>
    <tr><td><code>millis()</code></td><td>ms since boot, wraps at 999 (for sub-second timing)</td></tr>
    <tr><td><code>seconds()</code></td><td>seconds since boot (0..~2M, ~24 day range)</td></tr>
    <tr><td><code>centis()</code></td><td>centiseconds (÷10 ms) since boot (~24 day range)</td></tr>
    <tr><td><code>delay(ms)</code></td><td>yield-friendly sleep</td></tr>
    <tr><td><code>mem()</code></td><td>system free heap (ESP.getFreeHeap)</td></tr>
    <tr><td><code>jsmem()</code></td><td>JS-heap free bytes (inside the isolated pool)</td></tr>
    <tr><td><code>gc()</code></td><td>run GC, returns free JS-heap bytes</td></tr>
    <tr><td><code>keys()</code></td><td>8-bit button mask (1 = pressed)</td></tr>
    <tr><td><code>keysPressed()</code></td><td>bits that went 0&rarr;1 since last call (just pressed)</td></tr>
    <tr><td><code>keysReleased()</code></td><td>bits that went 1&rarr;0 since last call (just released)</td></tr>
    <tr><td><code>backlight(v)</code></td><td>MCP4725 DAC 0..4095</td></tr>
    <tr><td><code>rand()</code></td><td>random int in [0, 2^30)</td></tr>
    <tr><td><code>parseInt(s)</code></td><td>parse integer from string (also accepts number)</td></tr>
    <tr><td><code>isNaN(v)</code></td><td>returns true if v is NaN or not a number</td></tr>
    <tr><td><code>getIP()</code></td><td>returns current IP address as string ("192.168.x.x")</td></tr>
    <tr><td><code>hexToColor(hex)</code></td><td>convert "#RRGGBB" → nearest palette idx</td></tr>
    <tr><td><code>colorToHex(idx)</code></td><td>convert palette idx → "#RRGGBB" string</td></tr>
    <tr><td><code>setTimeout(fn, ms)</code></td><td>one-shot timer (returns id)</td></tr>
    <tr><td><code>setInterval(fn, ms)</code></td><td>repeating timer (returns id)</td></tr>
    <tr><td><code>clearTimeout(id)</code></td><td>cancel timer</td></tr>
  </table>
  <h3>Buttons (keys() &amp; NAME)</h3>
  <table>
    <tr><td><code>LEFT</code>=1</td><td><code>UP</code>=2</td><td><code>DOWN</code>=4</td><td><code>RIGHT</code>=8</td></tr>
    <tr><td><code>A</code>=16</td><td><code>B</code>=32</td><td><code>RGT</code>=128</td><td></td></tr>
  </table>
  <h3 id="tftSection">tft.* (64x64 framebuffer, scaled 2x)</h3>
  <table id="tftTable">
    <tr><td><code>cls()</code></td><td><code>fill(c)</code></td><td><code>pixel(x,y,c)</code></td></tr>
    <tr><td><code>rect(x,y,w,h,c)</code></td><td><code>fillRect(x,y,w,h,c)</code></td><td><code>line(x0,y0,x1,y1,c)</code></td></tr>
    <tr><td><code>circle(cx,cy,r,c)</code></td><td><code>disc(cx,cy,r,c)</code></td><td><code>text(x,y,str,c,size)</code></td></tr>
    <tr><td><code>getpixel(x,y)</code></td><td><code>flip()</code></td><td><code>setFont(0|1)</code> &mdash; 0=5x7, 1=Tiny5 (both +CP1251 Russian)</td></tr>
    <tr><td colspan=3><code>sprite(x,y,w,h,colors)</code> &mdash; blit w&times;h palette indices</td></tr>
    <tr><td colspan=3><code>spriteMask(x,y,w,h,colors,mask)</code> &mdash; skip where color==mask</td></tr>
  </table>
  <h3>Math.*</h3>
  <table>
    <tr><td><code>Math.PI</code></td><td><code>Math.E</code></td><td><code>Math.floor(v)</code></td><td><code>Math.round(v)</code></td></tr>
    <tr><td><code>Math.abs(v)</code></td><td><code>Math.min(a,b)</code></td><td><code>Math.max(a,b)</code></td><td><code>Math.random()</code></td></tr>
    <tr><td><code>Math.pow(b,e)</code></td><td><code>Math.sqrt(v)</code></td><td><code>Math.sin(a)</code></td><td><code>Math.cos(a)</code></td></tr>
    <tr><td><code>Math.tan(a)</code></td><td><code>Math.atan2(y,x)</code></td><td></td><td></td></tr>
  </table>
  <h3>String / Array helpers</h3>
  <table>
    <tr><td><code>String.length(s)</code></td><td><code>String.charAt(s,i)</code></td><td><code>String.indexOf(s,sub)</code></td></tr>
    <tr><td><code>String.substring(s,a,b)</code></td><td><code>String.toUpperCase(s)</code></td><td><code>String.toLowerCase(s)</code></td></tr>
    <tr><td><code>String.split(s,sep)</code></td><td><code>String.replace(s,find,repl)</code></td><td><code>String.match(s,re)</code></td></tr>
    <tr><td><code>Array.push(arr,...v)</code></td><td><code>Array.isArray(x)</code></td><td><code>Array.indexOf(arr,v)</code></td></tr>
    <tr><td colspan=3><code>RegExp.test(pattern,text)</code> / <code>RegExp.match(pattern,text)</code> &mdash; regex match</td></tr>
  </table>
  <h3>HTTP &amp; JSON</h3>
  <table>
    <tr><td colspan=2><b>fetch(url [, opts] [, cb])</b> &mdash; HTTP/HTTPS client</td></tr>
    <tr><td><code>fetch("http://api.example.com/data")</code></td><td>GET, returns body as string</td></tr>
    <tr><td><code>fetch("https://example.com/api")</code></td><td>HTTPS (ESP32 only, setInsecure)</td></tr>
    <tr><td><code>fetch(url, {method:"POST", body:"...", headers:{...}})</code></td><td>browser-style options</td></tr>
    <tr><td><code>fetch(url, function(chunk, total) {...})</code></td><td>streaming &mdash; 256-byte chunks</td></tr>
    <tr><td><code>fetch(url, {method:"PUT", body:JSON.stringify({x:1})}, cb)</code></td><td>options + streaming</td></tr>
    <tr><td><code>fetch(url, "POST", "body", "Header: val\\n...")</code></td><td>legacy positional form</td></tr>
    <tr><td colspan=2>Streaming callback returns total bytes; <code>return false</code> aborts.<br>HTTPS requires ESP32 (BearSSL needs ~11KB heap, ESP8266 has only ~8KB free).</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>jsonSelect(jsonStr, path)</b> &mdash; extract a field from a JSON string</td></tr>
    <tr><td><code>jsonSelect('{"u":{"name":"Mikl"}}', "u.name")</code></td><td>&rarr; "Mikl"</td></tr>
    <tr><td><code>jsonSelect('[10,20,30]', "1")</code></td><td>&rarr; "20"</td></tr>
    <tr><td><code>jsonSelect(j, "items.0.id")</code></td><td>nested path with array index</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>jsonStream(url, path, callback)</b> &mdash; streaming SAX parser</td></tr>
    <tr><td colspan=2>Fetches URL, parses JSON incrementally, calls <code>callback(value)</code><br>for each value at the given path.  No buffering — handles arbitrarily<br>large JSON with flat memory.  Path examples:</td></tr>
    <tr><td><code>jsonStream(url, "title", fn)</code></td><td>top-level field</td></tr>
    <tr><td><code>jsonStream(url, "items.title", fn)</code></td><td>all titles in items array</td></tr>
    <tr><td><code>jsonStream(url, "*", fn)</code></td><td>every value (debug)</td></tr>
    <tr><td colspan=2><code>JSON.parse(str)</code> / <code>JSON.stringify(obj)</code> &mdash; full parse/stringify</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>http.* (JS HTTP server)</b> &mdash; handle requests from JS</td></tr>
    <tr><td colspan=2>By default <code>ip/</code> redirects to <code>ip/edit</code> (this editor).<br>After <code>http.onRequest(cb)</code>, <code>ip/</code> is handled by JS:<br><code>cb(method, path, query, body)</code> &rarr; call <code>http.respond()</code> or return string.</td></tr>
    <tr><td><code>http.onRequest(fn)</code></td><td>activate JS server, register handler</td></tr>
    <tr><td><code>http.respond(status, type, body)</code></td><td>send HTTP response from handler</td></tr>
    <tr><td><code>http.stop()</code></td><td>deactivate JS server (&rarr; redirect to /edit)</td></tr>
    <tr><td colspan=2><code>/edit</code> always opens this editor, regardless of JS server state.</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>files.* (on-device file management)</b></td></tr>
    <tr><td><code>files.list()</code></td><td>returns array of saved .js file names</td></tr>
    <tr><td><code>files.load(name)</code></td><td>load .js file content as string</td></tr>
    <tr><td><code>files.save(name, content)</code></td><td>save .js file to flash filesystem</td></tr>
    <tr><td><code>files.delete(name)</code></td><td>delete a file</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>i2c.* (I2C bus control)</b></td></tr>
    <tr><td><code>i2c.write(addr, data)</code></td><td>write byte or array to device</td></tr>
    <tr><td><code>i2c.read(addr, len)</code></td><td>read len bytes → array</td></tr>
    <tr><td><code>i2c.scan()</code></td><td>scan bus → array of addresses</td></tr>
    <tr><td colspan=2>&nbsp;</td></tr>
    <tr><td colspan=2><b>spi.* (SPI bus control)</b></td></tr>
    <tr><td><code>spi.transfer(byte)</code></td><td>transfer single byte, returns received</td></tr>
    <tr><td><code>spi.transferArray(arr)</code></td><td>transfer byte array, returns received array</td></tr>
  </table>
  <h3>Palette (256 colors, 0-255)</h3>
  <p class=hint>
    &bull; 0-7: black, red, green, yellow, blue, magenta, cyan, white<br>
    &bull; 8-15: dark grey, orange, + repeats<br>
    &bull; 16-231: 6&times;6&times;6 color cube (idx=16+36r+6g+b, r/g/b=0..5)<br>
    &bull; 232-255: greyscale ramp<br>
    &bull; Use <b>Sprite Editor</b> button to pick colors visually.
  </p>
  <h3>Notes</h3>
  <p class=hint>
    &bull; Numbers are int30 only (no float). <code>1/2 = 0</code>.<br>
    &bull; <code>===</code> strict, <code>typeof</code>, <code>switch</code>, <code>for...in</code>, <code>for...of</code> supported.<br>
    &bull; No <code>try/catch</code> — errors halt the script.<br>
    &bull; Compilation happens in browser — fix compile errors before device sees anything.
  </p>
</div>

<script src=/compiler.js></script>
<script>
/* T51: Loading indicator — hidden when globals are loaded. */
var GLOBALS_READY = false;
function updateLoadingStatus(msg) {
  var el = document.getElementById('loadingStatus');
  if (el) el.textContent = msg;
}
function checkReady() {
  if (GLOBALS_READY) {
    var ov = document.getElementById('loadingOverlay');
    if (ov) ov.style.display = 'none';
  }
}
</script>
<script>
/* ===== PrismJS compact tokenizer (inlined, ~2 KB) ===== */
var Prism={highlight:function(e,g){var t=[e];for(var n in g){if(!g.hasOwnProperty(n))continue;var r=g[n];if(!Array.isArray(r))r=[r];for(var ri=0;ri<r.length;ri++){var pat=r[ri].pattern||r[ri];var ins=r[ri].inside;var lookbehind=!!r[ri].lookbehind;var greedy=!!r[ri].greedy;var gl=pat.global?pat:RegExp(pat.source,(pat.flags||'')+'g');for(var i=0;i<t.length;i++){var tok=t[i];if(typeof tok!=='string')continue;var str=tok,out=[],last=0,m;gl.lastIndex=0;while(m=gl.exec(str)){var ms=m.index,mL=m[0].length;if(lookbehind&&m[1]!==undefined){ms+=m[1].length;mL-=m[1].length}if(mEnd=ms+mL,mEnd<=last){if(gl.lastIndex===m.index)gl.lastIndex++;continue}if(ms>last)out.push(str.slice(last,ms));var matched=str.slice(ms,mEnd);out.push({type:n,content:ins?this.highlight(matched,ins):matched});last=mEnd;if(!greedy){if(gl.lastIndex===m.index)gl.lastIndex++;break}}if(last<str.length)out.push(str.slice(last));if(out.length){t.splice.apply(t,[i,1].concat(out));i+=out.length-1}}}}return this.stringify(t,{})},stringify:function(t,g){if(typeof t==='string')return this.esc(t);if(Array.isArray(t))return t.map(function(x){return this.stringify(x,g)},this).join('');var cls='token '+t.type;return '<span class="'+cls+'">'+this.stringify(t.content,g)+'</span>'},esc:function(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}};
var jsGrammar={comment:{pattern:/(\/\/[^\n]*|\/\*[\s\S]*?\*\/)/,greedy:1},string:{pattern:/(['"])(?:\\.|(?!\1)[^\\])*\1/,greedy:1},keyword:/\b(var|let|const|function|return|if|else|while|do|for|in|of|break|continue|new|switch|case|default|typeof|instanceof|true|false|null|undefined)\b/,"function":/\b(print|millis|seconds|centis|delay|mem|gc|keys|backlight|rand|setTimeout|setInterval|clearTimeout|clearInterval|fetch|jsonSelect|jsonStream|parseInt|isNaN|getIP|JSON|http|files|i2c|spi)\b/,number:/\b\d+\b/,punctuation:/[{}[\];(),.:?]/,operator:/[+\-*\/%=<>!&|^~]/};
function highlightCode(code){try{return Prism.highlight(code,jsGrammar)}catch(e){return Prism.esc(code)}}

/* ===== Sample programs ===== */
var SAMPLES=[
  ["Hello","tft.cls();\ntft.text(4, 4, 'Hello', 2, 2);\ntft.flip();\nprint('hi');"],
  ["Graphics","/* Grid + Rings + Palette demos */\n/* Grid pattern */\ntft.cls();\nfor (var y = 0; y < 64; y += 8)\n  for (var x = 0; x < 64; x += 8)\n    tft.fillRect(x, y, 7, 7, x == y ? 4 : 1);\ntft.flip();\ndelay(1000);\n/* Concentric rings */\ntft.cls();\nfor (var r = 30; r > 0; r -= 4)\n  tft.disc(32, 32, r, r % 8 ? 3 : 1);\ntft.flip();\ndelay(1000);\n/* Palette */\ntft.cls();\nfor (var i = 0; i < 256; i++)\n  tft.fillRect((i % 16) * 4, (i / 16 | 0) * 4, 3, 3, i);\ntft.flip();"],
  ["Anim+Game","/* Animation + simple game (use D-pad to move) */\nvar mode = 0;\nvar px = 32, py = 32, t = 0;\nsetInterval(function() {\n  var k = keys();\n  if (k & A) mode = 1 - mode;\n  tft.cls();\n  if (mode == 0) {\n    tft.disc(32, 32, 5 + (t % 20), 1 + (t % 15));\n  } else {\n    if (k & LEFT)  px--;\n    if (k & RIGHT) px++;\n    if (k & UP)    py--;\n    if (k & DOWN)  py++;\n    if (px < 0) px = 0; if (px > 57) px = 57;\n    if (py < 0) py = 0; if (py > 56) py = 56;\n    tft.fillRect(px, py, 6, 6, 3);\n  }\n  tft.text(0, 0, mode ? 'Game' : 'Anim', 7, 1);\n  tft.flip();\n  t++;\n}, 100);"],
  ["Sprite","var s = [\n  0,1,1,1,0,\n  1,0,0,0,1,\n  0,0,1,1,1,\n  1,1,0,0,1,\n  0,1,1,1,0,\n  1,0,0,1,0\n];\ntft.cls();\ntft.sprite(28, 28, 5, 6, s);\ntft.flip();"],
  ["Bench","var N = 2000;\nvar t0 = millis();\nvar s = 0;\nfor (var i = 0; i < N; i++) s += i;\nvar t1 = millis();\nprint('loop', N, 'iter in', t1 - t0, 'ms');\nprint('sum =', s);\nprint('ops/sec =', (N * 1000) / (t1 - t0));\nt0 = millis();\nfor (var i = 0; i < 100; i++) { var o = {x: i, y: i * 2}; }\nt1 = millis();\nprint('100 obj alloc in', t1 - t0, 'ms');\nt0 = millis();\nfor (var i = 0; i < 100; i++) { var a = [1,2,3,4,5,6,7,8]; }\nt1 = millis();\nprint('100 array alloc in', t1 - t0, 'ms');\nprint('js heap:', jsmem());\nprint('sys heap:', mem());"],
  ["Syntax","/* switch, typeof, for..in, for..of, strict eq */\nvar x = 2;\nswitch (x) {\n  case 1: print(10); break;\n  case 2: print(20); break;\n  default: print(0);\n}\nprint(typeof 42);\nprint(typeof 'hi');\nvar o = {a: 1, b: 2};\nfor (var k in o) print(k, o[k]);\nvar a = [10, 20, 30];\nfor (var v of a) print(v);\nprint(1 === 1);\nprint(1 === '1');"],
  ["Math+Array","/* Math functions + Array methods */\nprint(2 + 3 * 4);\nprint(10 / 3);\nprint(Math.floor(3.7));\nprint(Math.random());\nvar a = [1, 2, 3];\na.push(4);\nprint(a.length);\nprint(a[3]);\nvar b = a.slice(1, 3);\nprint(b[0], b[1]);"],
  ["HTTP GET","/* fetch + jsonSelect for field extraction. */\nvar r = fetch('http://jsonplaceholder.typicode.com/posts/1');\nif (r.substring(0, 5) == 'ERROR') {\n  print(r);\n} else {\n  print('Got ' + r.length + ' bytes');\n  print('userId: ' + jsonSelect(r, 'userId'));\n  print('id:     ' + jsonSelect(r, 'id'));\n  print('title:  ' + jsonSelect(r, 'title'));\n  var obj = JSON.parse(r);\n  print('body:   ' + obj.body.substring(0, 40) + '...');\n}"],
  ["HTTP POST","/* Browser-style fetch with options object. */\nvar payload = JSON.stringify({ name: 'Mikl', age: 42 });\nvar r = fetch('http://httpbin.org/post', {\n  method: 'POST',\n  headers: { 'Content-Type': 'application/json' },\n  body: payload\n});\nif (r.substring(0, 5) == 'ERROR') {\n  print(r);\n} else {\n  print('Response: ' + r.length + ' bytes');\n  var dataStr = jsonSelect(r, 'data');\n  var data = JSON.parse(dataStr);\n  print('name: ' + data.name);\n  print('age:  ' + data.age);\n}"],
  ["HTTP stream","/* Streaming fetch — count posts in 256-byte chunks. */\nvar count = 0;\nvar bytes = 0;\nfetch('http://jsonplaceholder.typicode.com/posts?_limit=10', function(chunk, total) {\n  bytes = total;\n  var i = 0;\n  while (true) {\n    var p = chunk.indexOf('\"title\"', i);\n    if (p < 0) break;\n    count++;\n    i = p + 7;\n  }\n  return true;\n});\nprint('Total: ' + bytes + 'B, titles: ' + count);"],
  ["JSON stream","/* jsonStream — SAX parser, extract fields from large JSON. */\nvar n = jsonStream(\n  'http://jsonplaceholder.typicode.com/posts?_limit=5',\n  'title',\n  function(v) { print('  title: ' + v); }\n);\nprint('Matched ' + n + ' titles');"],
  ["HTTP server","/* http.onRequest — JS HTTP server.\n * /edit always opens this editor. */\nvar count = 0;\nhttp.onRequest(function(method, path, query, body) {\n  count++;\n  print('Request #' + count + ': ' + method + ' ' + path);\n  if (path == '/') {\n    http.respond(200, 'text/html',\n      '<h1>Hello from ESPboy!</h1>' +\n      '<p>Request #' + count + '</p>' +\n      '<p>Method: ' + method + '</p>' +\n      '<p><a href=\"/edit\">Open editor</a></p>');\n    return;\n  }\n  if (path == '/api') {\n    http.respond(200, 'application/json',\n      '{\"count\":' + count + ',\"method\":\"' + method + '\"}');\n    return;\n  }\n  http.respond(404, 'text/plain', 'Not found: ' + path);\n});\nprint('HTTP server active. Visit:');\nprint('  ip/      (HTML page)');\nprint('  ip/api   (JSON)');\nprint('  ip/edit  (editor)');"]
];

/* ===== Init sample dropdown ===== */
(function(){
  var sel=document.getElementById('samplesel');
  SAMPLES.forEach(function(s,idx){
    var o=document.createElement('option');
    o.value=idx;
    o.textContent=s[0];
    sel.appendChild(o);
  });
})();

function loadSample(){
  var sel=document.getElementById('samplesel');
  var idx=parseInt(sel.value);
  if(isNaN(idx))return;
  document.getElementById('code').value=SAMPLES[idx][1];
  doHighlight();
  sel.value='';
}

/* ===== Syntax highlighting ===== */
var codeEl=document.getElementById('code');
var hlEl=document.getElementById('hl').getElementsByTagName('code')[0];
var gutterInnerEl=document.getElementById('gutterInner');
/* T49: compute actual line-height from the textarea's computed style.
 * Using a hardcoded 18.2 caused off-by-one highlight errors because the
 * real rendered line-height can differ slightly from font-size*1.4. */
var realLineHeight=parseFloat(getComputedStyle(codeEl).lineHeight)||18.2;
/* T49: make the error-highlight overlay height match the real line-height
 * so it covers exactly one line (was hardcoded 18px in CSS). */
document.getElementById('errhl').style.height=realLineHeight+'px';
var doHighlight=function(){hlEl.innerHTML=highlightCode(codeEl.value)};
codeEl.addEventListener('scroll',function(){
  /* T49: use transform:translateY on the inner elements instead of
   * scrollTop on overflow:hidden containers.  The textarea can scroll
   * past its content (for caret visibility) but overflow:hidden
   * elements clamp scrollTop to scrollHeight-clientHeight, causing a
   * 1-line desync at the bottom.  transform has no such clamp. */
  var st=codeEl.scrollTop, sl=codeEl.scrollLeft;
  var code=hlEl;
  code.style.transform='translate('+(-sl)+'px,'+(-st)+'px)';
  gutterInnerEl.style.transform='translate(0,'+(-st)+'px)';
  /* Update error highlight position on scroll */
  var eh=document.getElementById('errhl');
  if(eh.style.display==='block'){
    var line=parseInt(eh.getAttribute('data-line'));
    if(line){
      var top=8+(line-1)*realLineHeight-st;
      if(top<-realLineHeight||top>codeEl.offsetHeight)eh.style.display='none';
      else eh.style.top=top+'px';
    }
  }
});
function updateGutter(){
  var lines=codeEl.value.split('\n').length;
  var html='';
  for(var i=1;i<=lines;i++){
    if(i>1)html+='\n';
    var s=String(i);
    while(s.length<3) s='0'+s;
    html+=s;
  }
  gutterInnerEl.textContent=html;
}
codeEl.addEventListener('input',function(){doHighlight();updateGutter()});
doHighlight();
updateGutter();

/* ===== Tab key in editor ===== */
codeEl.addEventListener('keydown',function(e){if(e.key==='Tab'){e.preventDefault();var s=codeEl.selectionStart,en=codeEl.selectionEnd;codeEl.value=codeEl.value.substring(0,s)+'  '+codeEl.value.substring(en);codeEl.selectionStart=codeEl.selectionEnd=s+2;doHighlight()}});

/* ===== UI helpers ===== */
function showErr(html){var e=document.getElementById('err');e.innerHTML=html;e.style.display=html?'block':'none'}
function clearOutput(){
  var out=document.getElementById('out');
  out.textContent='(output appears here)';
  out.classList.remove('expanded');  /* T51: collapse output panel */
  document.getElementById('meta').textContent='';
  showErr('');
  clearErrorLine();
}
function clearErrorLine(){
  document.getElementById('errhl').style.display='none';
}
function highlightErrorLine(line){
  clearErrorLine();
  if(!line)return;
  var lineHeight=realLineHeight;
  var scrollTarget=(line-3)*lineHeight;
  if(scrollTarget<0)scrollTarget=0;
  codeEl.scrollTop=scrollTarget;
  /* T49: sync highlight layer via transform (not scrollTop) — the pre
   * has overflow:hidden which clamps scrollTop and causes desync. */
  var st=codeEl.scrollTop;
  hlEl.style.transform='translate('+(-codeEl.scrollLeft)+'px,'+(-st)+'px)';
  gutterInnerEl.style.transform='translate(0,'+(-st)+'px)';
  /* Position the highlight overlay at the error line.
   * Line 1 is at top = padding (8px). Line N is at (N-1)*lineHeight + padding.
   * The textarea padding is 8px, so we need to add it. */
  var top=8+(line-1)*lineHeight-st;
  var eh=document.getElementById('errhl');
  eh.setAttribute('data-line',line);
  eh.style.top=top+'px';
  eh.style.display='block';
}
function toggleHelp(){var h=document.getElementById('help');h.style.display=h.style.display==='block'?'none':'block'}
/* T51: WiFi settings panel. */
function toggleWifi(){
  var w=document.getElementById('wifiPanel');
  if(w.style.display==='block'){w.style.display='none';return}
  w.style.display='block';
  /* Fetch current WiFi status. */
  fetch('/wifi').then(function(r){return r.json()}).then(function(j){
    document.getElementById('wifiStatus').textContent='Mode: '+j.mode+' | SSID: '+j.ssid+' | IP: '+j.ip;
  }).catch(function(e){
    document.getElementById('wifiStatus').textContent='Error: '+e.message;
  });
}
async function saveWifi(){
  var ssid=document.getElementById('wifiSsid').value;
  var pass=document.getElementById('wifiPass').value;
  if(!ssid){alert('Enter SSID');return}
  var body=ssid+'\n'+pass;
  if(!confirm('Save WiFi and reboot? Device will try to connect to "'+ssid+'" on next boot.'))return;
  try{
    var r=await fetch('/wifi',{method:'POST',headers:{'Content-Type':'text/plain'},body:body});
    var t=await r.text();
    document.getElementById('wifiStatus').textContent=t;
  }catch(e){alert('Failed: '+e.message)}
}
async function clearWifi(){
  if(!confirm('Clear WiFi credentials and reboot to AP mode?'))return;
  try{
    var r=await fetch('/wifi',{method:'POST',headers:{'Content-Type':'text/plain'},body:''});
    var t=await r.text();
    document.getElementById('wifiStatus').textContent=t;
  }catch(e){alert('Failed: '+e.message)}
}
function escapeHtml(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

/* ===== T51: Sprite Editor ===== */
/* 64-color palette: first 8 are device basic colors (0-7: black,red,green,
   yellow,blue,magenta,cyan,white), then 48 cube colors (device idx 16,20,24,...),
   then 8 greyscale (device idx 232,236,...,255).
   SE_DEVICE_IDX[i] maps editor swatch → actual device palette index. */
var SE_PALETTE=[
  '#000000','#ff0000','#00ff00','#ffff00','#0000ff','#ff00ff','#00ffff','#ffffff',
  '#000000','#0000d7','#005f87','#008700','#0087d7','#00af87','#00d700','#00d7d7',
  '#00ff87','#5f0000','#5f00d7','#5f5f87','#5f8700','#5f87d7','#5faf87','#5fd700',
  '#5fd7d7','#5fff87','#870000','#8700d7','#875f87','#878700','#8787d7','#87af87',
  '#87d700','#87d7d7','#87ff87','#af0000','#af00d7','#af5f87','#af8700','#af87d7',
  '#afaf87','#afd700','#afd7d7','#afff87','#d70000','#d700d7','#d75f87','#d78700',
  '#d787d7','#d7af87','#d7d700','#d7d7d7','#d7ff87','#ff0000','#ff00d7','#ff5f87',
  '#080808','#303030','#585858','#808080','#a8a8a8','#d0d0d0','#e4e4e4','#eeeeee'
];
var SE_DEVICE_IDX=[
  0,1,2,3,4,5,6,7,
  16,20,24,28,32,36,40,44,
  48,52,56,60,64,68,72,76,
  80,84,88,92,96,100,104,108,
  112,116,120,124,128,132,136,140,
  144,148,152,156,160,164,168,172,
  176,180,184,188,192,196,200,204,
  232,236,240,244,248,252,254,255
];
/* T51: Compute the RGB hex string for a device palette index (0-255).
 * Returns the color the USER INTENDED (before device channel rotation).
 * The device rotates R→B, G→R, B→G, but our RGB565 macro pre-compensates,
 * so the device displays the intended color.  The editor shows intended colors. */
var SE_CUBE_LEVELS=[0,95,135,175,215,255];
function seDeviceIdxToRGB(devIdx){
  var r=0,g=0,b=0;
  if(devIdx<=7){
    var basic=[[0,0,0],[255,0,0],[0,255,0],[255,255,0],[0,0,255],[255,0,255],[0,255,255],[255,255,255]];
    var c=basic[devIdx]; r=c[0];g=c[1];b=c[2];
  }else if(devIdx<=15){
    var extra=[[64,64,64],[255,128,0],[0,255,0],[255,255,0],[0,0,255],[255,0,255],[0,255,255],[255,255,255]];
    var c=extra[devIdx-8]; r=c[0];g=c[1];b=c[2];
  }else if(devIdx<=231){
    var i=devIdx-16;
    r=SE_CUBE_LEVELS[Math.floor(i/36)%6];
    g=SE_CUBE_LEVELS[Math.floor(i/6)%6];
    b=SE_CUBE_LEVELS[i%6];
  }else{
    var v=8+(devIdx-232)*10;
    r=v;g=v;b=v;
  }
  /* Return as #RRGGBB hex string */
  return '#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+b.toString(16)).slice(-2);
}
function seUpdateColorInfo(){
  var devIdx=SE_DEVICE_IDX[seColor];
  document.getElementById('seColorInfo').textContent=devIdx;
  document.getElementById('seColorRGB').textContent=seDeviceIdxToRGB(devIdx).toUpperCase();
}
var seData=[];      /* 2D array [y][x] of color index, 0-63 */
var seW=8,seH=8;
var seColor=1;      /* selected color (0-63) */
var seCanvas,seCtx;
var seEditingRange=null;  /* {start,end} of existing array in textarea */
var SE_CANVAS_SIZE=256;   /* fixed canvas pixel size (internal resolution) */
var seCellSize=32;        /* computed: displayCanvasSize / max(seW,seH) */
var seDisplaySize=256;    /* actual display size in CSS px — adapts to screen */

function seComputeCellSize(){
  /* T51-fix: adapt canvas display size to screen width.
   * On phones (portrait), the canvas should be ~min(screenWidth-40, 256)
   * so it fits without horizontal scroll.  On desktop, keep 256px.
   * Cell size = displaySize / max(seW, seH). */
  var ww=window.innerWidth||document.documentElement.clientWidth||320;
  var wh=window.innerHeight||document.documentElement.clientHeight||480;
  /* Portrait phone: canvas takes up to ~70% of viewport height (leaving
   * room for palette + buttons below).  Min 160px for usability. */
  if(ww<600){
    seDisplaySize=Math.max(160,Math.min(ww-40,Math.floor(wh*0.5),256));
  }else{
    seDisplaySize=256;  /* desktop: fixed */
  }
  /* Update the canvas CSS size (internal resolution stays 256 for crisp rendering). */
  var cv=document.getElementById('seCanvas');
  if(cv){cv.style.width=seDisplaySize+'px';cv.style.height=seDisplaySize+'px';}
  var m=seW>seH?seW:seH;
  /* Cell size is in canvas-internal pixels (256-grid), not display px. */
  seCellSize=Math.floor(SE_CANVAS_SIZE/m);
}

function openSpriteEditor(){
  /* Try to detect an existing array at cursor position and load it. */
  seEditingRange=null;
  var ta=codeEl;
  var val=ta.value;
  var pos=ta.selectionStart;
  /* Find the array literal that contains the cursor.
     Look for [...] where pos is between [ and ]. */
  var lineStart=val.lastIndexOf('\n',pos-1)+1;
  /* Search backwards for [ on current line or previous lines */
  var bpos=val.lastIndexOf('[',pos-1);
  var fpos=val.indexOf(']',pos);
  if(bpos>=0&&fpos>=0&&bpos<pos&&fpos>=pos){
    /* Check there's no ] between bpos and pos (means cursor is inside one array) */
    var inner=val.substring(bpos+1,fpos);
    var nums=inner.match(/-?\d+/g);
    if(nums&&nums.length>=4){
      var n=nums.length;
      /* T51: Detect W and H from the LINE STRUCTURE of the array literal.
       * If the array is formatted as multi-line (each row on its own line),
       * count numbers per line to determine W, and count lines for H.
       * This handles 6x4 sprites correctly (was using sqrt → 5x5).
       * Falls back to sqrt heuristic for single-line arrays. */
      var lines=val.substring(bpos,fpos+1).split('\n');
      var sw=0, sh=0;
      /* Find lines that contain numbers (skip lines with only [ or ]) */
      var numLines=[];
      for(var li=0;li<lines.length;li++){
        var ln=lines[li];
        var lnNums=ln.match(/-?\d+/g);
        if(lnNums&&lnNums.length>0){
          numLines.push(lnNums.length);
        }
      }
      if(numLines.length>=2){
        /* Multi-line: W = first line's count, H = number of lines */
        sw=numLines[0];
        sh=numLines.length;
      }else{
        /* Single line: use sqrt heuristic */
        sw=Math.ceil(Math.sqrt(n));
        sh=Math.ceil(n/sw);
        while(sw*sh<n)sw++;
      }
      if(sw>16)sw=16;
      if(sh>16)sh=16;
      if(sw<2)sw=2;
      if(sh<2)sh=2;
      /* If sw*sh < n, expand sw to fit (shouldn't happen with proper format) */
      while(sw*sh<n&&sw<16)sw++;
      seW=sw;seH=sh;
      document.getElementById('seW').value=sw;
      document.getElementById('seH').value=sh;
      /* Load data (clamp to 16x16). Convert device palette index → editor
         swatch index by finding the nearest SE_DEVICE_IDX entry. */
      seData=[];
      for(var y=0;y<16;y++){seData[y]=[];for(var x=0;x<16;x++){
        var idx=y*sw+x;
        var v=0;
        if(idx<n){
          var devIdx=parseInt(nums[idx],10)&255;
          /* Find the swatch whose SE_DEVICE_IDX is closest to devIdx. */
          var bestSwatch=0,bestDist=999;
          for(var si=0;si<64;si++){
            var d=Math.abs(SE_DEVICE_IDX[si]-devIdx);
            if(d<bestDist){bestDist=d;bestSwatch=si;}
          }
          v=bestSwatch;
        }
        seData[y][x]=v;
      }}
      seEditingRange={start:bpos,end:fpos+1};
    }
  }
  if(!seData.length){
    /* Fresh empty sprite */
    seW=8;seH=8;
    document.getElementById('seW').value=8;
    document.getElementById('seH').value=8;
    seData=[];
    for(var y=0;y<16;y++){seData[y]=[];for(var x=0;x<16;x++)seData[y][x]=0;}
  }
  seComputeCellSize();
  /* Build palette (64 colors, 8x8 grid) */
  var pal=document.getElementById('sePalette');
  pal.innerHTML='';
  for(var i=0;i<64;i++){
    (function(idx){
      var s=document.createElement('div');
      s.className='se-swatch'+(idx===seColor?' sel':'');
      s.style.background=SE_PALETTE[idx];
      s.onclick=function(){
        seColor=idx;
        var sws=pal.querySelectorAll('.se-swatch');
        for(var j=0;j<sws.length;j++)sws[j].classList.remove('sel');
        s.classList.add('sel');
        seUpdateColorInfo();
      };
      pal.appendChild(s);
    })(i);
  }
  /* Show initial color */
  seUpdateColorInfo();
  /* Setup canvas — fixed 256x256, don't resize on W/H change */
  seCanvas=document.getElementById('seCanvas');
  seCtx=seCanvas.getContext('2d');
  seCanvas.onmousedown=seHandleMouse;
  seCanvas.oncontextmenu=function(e){e.preventDefault();};
  document.getElementById('seW').onchange=seResize;
  document.getElementById('seH').onchange=seResize;
  seRedraw();
  document.getElementById('spriteModal').classList.add('show');
}

function seResize(){
  var nw=parseInt(document.getElementById('seW').value)||8;
  var nh=parseInt(document.getElementById('seH').value)||8;
  if(nw<2)nw=2;if(nw>16)nw=16;
  if(nh<2)nh=2;if(nh>16)nh=16;
  document.getElementById('seW').value=nw;
  document.getElementById('seH').value=nh;
  seW=nw;seH=nh;
  seComputeCellSize();
  seRedraw();
}

function seRedraw(){
  /* Clear canvas */
  seCtx.fillStyle='#000';
  seCtx.fillRect(0,0,SE_CANVAS_SIZE,SE_CANVAS_SIZE);
  /* Draw sprite area with checker background for transparency */
  var totalW=seW*seCellSize;
  var totalH=seH*seCellSize;
  for(var y=0;y<seH;y++){
    for(var x=0;x<seW;x++){
      seCtx.fillStyle=((x+y)&1)?'#252526':'#2d2d2d';
      seCtx.fillRect(x*seCellSize,y*seCellSize,seCellSize,seCellSize);
      var c=seData[y]?seData[y][x]:0;
      if(c>0){
        seCtx.fillStyle=SE_PALETTE[c];
        seCtx.fillRect(x*seCellSize,y*seCellSize,seCellSize,seCellSize);
      }
    }
  }
  /* Grid lines */
  seCtx.strokeStyle='#3c3c3c';
  seCtx.lineWidth=1;
  for(var x=0;x<=seW;x++){seCtx.beginPath();seCtx.moveTo(x*seCellSize+0.5,0);seCtx.lineTo(x*seCellSize+0.5,totalH);seCtx.stroke();}
  for(var y=0;y<=seH;y++){seCtx.beginPath();seCtx.moveTo(0,y*seCellSize+0.5);seCtx.lineTo(totalW,y*seCellSize+0.5);seCtx.stroke();}
}

function seHandleMouse(e){
  e.preventDefault();
  var rect=seCanvas.getBoundingClientRect();
  var x=Math.floor((e.clientX-rect.left)/seCellSize);
  var y=Math.floor((e.clientY-rect.top)/seCellSize);
  if(x<0||x>=seW||y<0||y>=seH)return;
  var btn=e.button;
  if(btn===2){
    /* Right-click = erase (set to 0) */
    seData[y][x]=0;
  }else{
    seData[y][x]=seColor;
  }
  seRedraw();
  /* Support drag-draw */
  seCanvas.onmousemove=function(ev){
    var r=seCanvas.getBoundingClientRect();
    var px=Math.floor((ev.clientX-r.left)/seCellSize);
    var py=Math.floor((ev.clientY-r.top)/seCellSize);
    if(px<0||px>=seW||py<0||py>=seH)return;
    if(btn===2){seData[py][px]=0;}else{seData[py][px]=seColor;}
    seRedraw();
  };
  document.onmouseup=function(){
    seCanvas.onmousemove=null;
    document.onmouseup=null;
  };
}

function closeSpriteEditor(){
  document.getElementById('spriteModal').classList.remove('show');
}

function applySprite(){
  /* T51: Generate the array literal formatted as rows matching sprite dimensions.
     A 4x4 sprite produces:
       [4,8,12,16,
        20,24,28,32,
        36,40,44,48,
        52,56,60,64]
     Values are DEVICE palette indices (0-255), converted from editor
     swatch indices (0-63) via SE_DEVICE_IDX[i] = i*4. */
  var rows=[];
  for(var y=0;y<seH;y++){
    var row=[];
    for(var x=0;x<seW;x++){
      var swatchIdx=seData[y][x]||0;
      row.push(SE_DEVICE_IDX[swatchIdx]);  /* convert to device palette index */
    }
    rows.push(row.join(','));
  }
  /* Join rows with ",\n" (newline + continuation).  For short sprites
     (W<=4), keep on one line.  For larger, use multi-line format. */
  var text;
  if(seW<=4&&seH<=4){
    /* Single line for tiny sprites */
    var all=[];
    for(var y=0;y<seH;y++)for(var x=0;x<seW;x++){
      var si=seData[y][x]||0;
      all.push(SE_DEVICE_IDX[si]);
    }
    text='['+all.join(',')+']';
  }else{
    /* Multi-line: each row on its own line, indented */
    text='[\n'+rows.map(function(r){return '  '+r;}).join(',\n')+'\n]';
  }
  var ta=codeEl;
  var val=ta.value;
  if(seEditingRange){
    /* Replace existing array */
    var before=val.substring(0,seEditingRange.start);
    var after=val.substring(seEditingRange.end);
    ta.value=before+text+after;
    ta.selectionStart=seEditingRange.start;
    ta.selectionEnd=seEditingRange.start+text.length;
  }else{
    /* Insert at cursor */
    var pos=ta.selectionStart;
    var before=val.substring(0,pos);
    var after=val.substring(ta.selectionEnd);
    ta.value=before+text+after;
    ta.selectionStart=pos;
    ta.selectionEnd=pos+text.length;
  }
  doHighlight();updateGutter();
  closeSpriteEditor();
}

/* ===== Run / Save ===== */
/* T49: map a runtime-error pc back to a source line using the compiler's
 * pc→line table.  Returns 0 if the pc is outside the top-level region
 * (e.g. inside a function body — we don't track those yet). */
function pcToLine(lineMap, pc, topLevelSize){
  if(!lineMap||lineMap.length===0||pc>=topLevelSize)return 0;
  /* lineMap is sorted by pc.  Find the last entry with pc <= target. */
  var lo=0, hi=lineMap.length;
  while(lo<hi){
    var mid=(lo+hi)>>1;
    if(lineMap[mid].pc<=pc)lo=mid+1; else hi=mid;
  }
  if(lo===0)return lineMap[0].line;
  return lineMap[lo-1].line;
}
/* T51: Fetch the list of native globals from the device.  This replaces
 * the hardcoded knownGlobals in the compiler — adding a new native in
 * the .ino's NATIVE_GLOBAL_NAMES array automatically makes it visible
 * to the compiler on next page load.  Stored globally so all compile
 * calls (runCode, saveBoot) share the same list. */
var DEVICE_GLOBALS = null;
async function fetchGlobals(){
  try{
    updateLoadingStatus('Loading globals...');
    var resp = await fetch('/globals');
    DEVICE_GLOBALS = await resp.json();
    console.log('[microjs] device globals:', DEVICE_GLOBALS.length, 'names');
    /* T51: Hide tft section if device is headless (no 'tft' in globals). */
    if(DEVICE_GLOBALS.indexOf('tft')<0){
      var ts=document.getElementById('tftSection');if(ts)ts.style.display='none';
      var tt=document.getElementById('tftTable');if(tt)tt.style.display='none';
      console.log('[microjs] headless mode — tft section hidden');
    }
    GLOBALS_READY = true;
    checkReady();
  }catch(e){
    console.warn('[microjs] failed to fetch /globals, using fallback:', e.message);
    DEVICE_GLOBALS = null;
    GLOBALS_READY = true;
    checkReady();
  }
}

/* Create a compiler instance pre-configured with the device's globals. */
function makeCompiler(){
  if(typeof MicroJSCompiler==='undefined'){
    showErr('<b>Compiler not loaded!</b> Please reload the page.');
    return null;
  }
  var c = new MicroJSCompiler();
  if(DEVICE_GLOBALS) c.setKnownGlobals(DEVICE_GLOBALS);
  return c;
}

async function runCode(){
  showErr('');clearErrorLine();var src=codeEl.value;
  var c=makeCompiler();
  if(!c)return;
  var r=c.compile(src);
  if(r.error){showErr('<b>Compile error</b> at line '+r.line+': '+r.error+(r.src_line?'<br><code>'+escapeHtml(r.src_line)+'</code>':''));highlightErrorLine(r.line);return}
  /* Debug: log bytecode to browser console */
  console.log('[microjs] bc='+r.bytecode.length+'B atoms='+r.atoms+' consts='+r.consts+' funcs='+r.funcs+' topBC='+r.bcSize+' bodyBC='+r.bodySize,
    Array.from(r.bytecode).map(function(b){return ('0'+b.toString(16)).slice(-2)}).join(' '));
  var t0=performance.now();
  var out=document.getElementById('out');
  out.classList.remove('expanded');
  out.textContent='Running... ('+r.bytecode.length+'B bytecode)';
  try{
    /* T51-fix: send bytecode as comma-separated decimal TEXT (not raw binary).
     * ESP32 WebServer's _plainArgs = char* assignment calls strlen() which
     * truncates the body at the first NUL byte.  Binary bytecode has NULs
     * after the "MJSB" magic header.  Encoding as decimal text avoids the
     * truncation — the body is pure ASCII, no NUL bytes.
     * Server-side /run parses this back into raw bytes. */
    var bcStr=Array.from(new Uint8Array(r.bytecode)).join(',');
    var resp=await fetch('/run',{method:'POST',headers:{'Content-Type':'text/plain'},body:bcStr});
    /* T50: device outputs CP1251 bytes (single-byte Cyrillic).  The JSON
     * structure is ASCII, but string values contain CP1251 high bytes.
     * Decode the entire response as windows-1251 so Cyrillic displays
     * correctly in the browser.  (resp.json() would use UTF-8 and show ???). */
    var buf=await resp.arrayBuffer();
    var text=new TextDecoder('windows-1251').decode(buf);
    var json=JSON.parse(text);
    var ms=(performance.now()-t0).toFixed(1);
    if(json.error){
      out.textContent='Runtime error: '+json.error+(json.pc!==undefined?' (pc='+json.pc+')':'');
      /* T49: try to highlight the source line for this pc */
      var line=pcToLine(r.lineMap, json.pc||0, r.bcSize);
      if(line)highlightErrorLine(line);
    }
    else{
      out.textContent=json.stdout||'(no output)';
      /* T50: warn if output was silently truncated (>512 bytes) */
      if(json.truncated){
        out.textContent+='\\n[output truncated at 512 bytes]';
        out.style.color='#f48771';
      } else { out.style.color='#dcdcdc'; }
    }
    document.getElementById('meta').textContent='bc='+r.bytecode.length+'B  atoms='+r.atoms+'  funcs='+r.funcs+'  device='+(json.ms||0)+'ms  roundtrip='+ms+'ms  mem='+(json.mem||0);
  }catch(e){showErr('<b>Network error</b>: '+e.message)}
}

async function saveBoot(){
  showErr('');var src=codeEl.value;
  var c=makeCompiler();if(!c)return;
  var r=c.compile(src);
  if(r.error){showErr('<b>Compile error</b> at line '+r.line+': '+r.error);return}
  var body=JSON.stringify({source:src,bytecode:Array.from(r.bytecode)});
  try{
    /* T51-fix: Use text/plain (not application/json) so ESP32 WebServer
     * parses the body into server.arg("plain").  ESP32 only parses
     * text/plain, x-www-form-urlencoded, and multipart/form-data — other
     * content-types are not parsed, causing "no body" → HTTP 400. */
    var resp=await fetch('/save',{method:'POST',headers:{'Content-Type':'text/plain'},body:body});
    var txt=await resp.text();
    document.getElementById('out').textContent=txt;
    loadFiles()
  }catch(e){showErr('<b>Save failed</b>: '+e.message)}
}

/* ===== T51: Bytecode disassembler =====
 * Compiles the current source and shows the MJSB bytecode as a
 * human-readable assembly listing in the output panel.  Useful for
 * debugging compiler output and understanding how JS maps to opcodes.
 *
 * Format:
 *   ; === Atoms (N) ===
 *   0001: print
 *   0002: x
 *   ; === Constants (N) ===
 *   0000: int 42
 *   0001: str "hello"
 *   ; === Functions (N) ===
 *   0000: argc=1 nlocals=2 pc=15 bodySize=10
 *   ; === Top-level bytecode (N bytes) ===
 *   0000: INT8 42
 *   0002: STORE_GLOBAL 1  ; x
 *   0004: POP
 *   0005: HALT
 *   ; === Function bodies ===
 *   func 0 @ pc=15:
 *   0015: LOAD_LOCAL 0
 *   0017: RET
 */
var OPNAMES = {};  /* opcode value → name, built lazily */
function buildOpnames(){
  if(OPNAMES._built) return;
  /* MJS_OP is set by the compiler script (window.MJS_OP). */
  var O = window.MJS_OP || {};
  for(var k in O) OPNAMES[O[k]] = k;
  OPNAMES._built = true;
}
/* Opcodes that take a 1-byte operand (atom id, local slot, const idx, argc). */
var OP_HAS_ARG1 = {
  0x05:'INT8', 0x08:'CONST', 0x09:'LOAD_LOCAL', 0x0A:'STORE_LOCAL',
  0x0B:'LOAD_GLOBAL', 0x0C:'STORE_GLOBAL', 0x10:'LOAD_PROP', 0x11:'STORE_PROP',
  0x15:'NEW_ARRAY', 0x33:'CALL', 0x34:'CALL_METHOD', 0x38:'FUNCTION', 0x43:'NEW', 0x45:'CALL_WITH_THIS', 0x46:'NATIVE_CALL', 0x47:'NEW_ARRAY_U8', 0x48:'NEW_ARRAY_U16',
  0x3F:'DEFINE_ACCESSOR'
};
/* Opcodes that take a 2-byte operand (i16 jump offset). */
var OP_HAS_ARG2 = {
  0x06:'INT16', 0x30:'JMP', 0x31:'JZ', 0x32:'JNZ', 0x40:'PUSH_TRY'
};
/* Opcodes that take a 3-byte operand (i24). */
var OP_HAS_ARG3 = {0x07:'INT24'};

function disassemble(c, r){
  buildOpnames();
  var bc = r.bytecode;
  var lines = [];
  /* Header */
  lines.push('; === microjs bytecode listing ===');
  lines.push('; total size: ' + bc.length + ' bytes');
  lines.push('; atoms: ' + r.atoms + ', consts: ' + r.consts + ', funcs: ' + r.funcs);
  lines.push('; top-level: ' + r.bcSize + ' bytes, body: ' + r.bodySize + ' bytes');
  lines.push('');

  /* Atoms */
  if(c.atoms.length > 0){
    lines.push('; --- Atoms (' + c.atoms.length + ') ---');
    for(var i = 0; i < c.atoms.length; i++){
      lines.push('  ' + pad(i+1, 4) + ': ' + c.atoms[i]);
    }
    lines.push('');
  }

  /* Constants */
  if(c.consts.length > 0){
    lines.push('; --- Constants (' + c.consts.length + ') ---');
    for(var i = 0; i < c.consts.length; i++){
      var cn = c.consts[i];
      if(cn.type === 0){
        /* int30: stored as raw fixed24.8.  Display as decimal. */
        var raw = cn.value;
        var ip = raw >> 8;
        var fp = (raw & 0xFF) * 100 / 256;
        var s = fp > 0 ? (ip + '.' + String(Math.floor(fp)).padStart(2,'0')) : String(ip);
        lines.push('  ' + pad(i, 4) + ': int ' + s + '  (raw=' + raw + ')');
      } else {
        lines.push('  ' + pad(i, 4) + ': str ' + JSON.stringify(cn.value));
      }
    }
    lines.push('');
  }

  /* Functions */
  if(c.funcs.length > 0){
    lines.push('; --- Functions (' + c.funcs.length + ') ---');
    for(var i = 0; i < c.funcs.length; i++){
      var f = c.funcs[i];
      lines.push('  func ' + i + ': argc=' + f.argc + ' nlocals=' + f.nlocals +
                 ' pc=' + f.pcAbsolute + ' bodySize=' + f.bodySize);
    }
    lines.push('');
  }

  /* Disassemble bytecode.
   * The bytecode blob layout (from serialize()):
   *   [magic 6B][atoms 2B + atom data][consts 2B + const data]
   *   [funcs 2B + func data][allBc: top-level + body]
   * We need to find where allBc starts.  Instead of parsing the blob,
   * we disassemble c.bc (top-level) and c.body (function bodies) directly
   * — these are the raw opcode arrays before serialization.
   */
  lines.push('; --- Top-level bytecode (' + c.bc.length + ' bytes) ---');
  disasmRegion(c.bc, 0, lines, c);

  if(c.body.length > 0){
    lines.push('');
    lines.push('; --- Function body bytecode (' + c.body.length + ' bytes) ---');
    /* Annotate with function boundaries */
    var bodyOff = 0;
    for(var fi = 0; fi < c.funcs.length; fi++){
      var fn = c.funcs[fi];
      var absPc = c.bc.length + fn.pc;  /* absolute pc in combined bc */
      lines.push('  ; func ' + fi + ' @ pc=' + absPc +
                 ' (body+' + fn.pc + ') argc=' + fn.argc +
                 ' nlocals=' + fn.nlocals);
      var end = fn.pc + fn.bodySize;
      disasmRegion(c.body.slice(fn.pc, end), c.bc.length + fn.pc, lines, c);
      bodyOff = end;
    }
  }

  return lines.join('\n');
}

function pad(n, w){
  var s = String(n);
  while(s.length < w) s = ' ' + s;
  return s;
}

function disasmRegion(bc, basePc, lines, c){
  var i = 0;
  while(i < bc.length){
    var pc = basePc + i;
    var op = bc[i];
    var name = OPNAMES[op] || ('0x' + op.toString(16));
    var argInfo = '';
    var bytes = 1;

    if(OP_HAS_ARG1[op]){
      var a = bc[i+1];
      bytes = 2;
      var extra = '';
      if(op === 0x0B || op === 0x0C || op === 0x10 || op === 0x11){
        /* LOAD_GLOBAL, STORE_GLOBAL, LOAD_PROP, STORE_PROP — arg is atom id (1-based). */
        if(a > 0 && a <= c.atoms.length) extra = '  ; ' + c.atoms[a-1];
      } else if(op === 0x08){
        /* CONST — arg is const index. */
        if(a < c.consts.length){
          var cn = c.consts[a];
          extra = cn.type === 0 ? '  ; int ' + (cn.value>>8) : '  ; ' + JSON.stringify(cn.value);
        }
      } else if(op === 0x38){
        /* FUNCTION — arg is func index. */
        extra = '  ; func ' + a;
      }
      argInfo = ' ' + a + extra;
    } else if(OP_HAS_ARG2[op]){
      var v = bc[i+1] | (bc[i+2] << 8);
      /* For jumps, v is a signed offset from the next instruction. */
      if(op >= 0x30 && op <= 0x32 || op === 0x40){
        var signed = v > 32767 ? v - 65536 : v;
        var target = pc + 2 + signed;
        argInfo = ' ' + signed + '  ; → pc=' + target;
      } else {
        argInfo = ' ' + v;
      }
      bytes = 3;
    } else if(OP_HAS_ARG3[op]){
      var v3 = bc[i+1] | (bc[i+2] << 8) | (bc[i+3] << 16);
      if(v3 & 0x800000) v3 |= 0xFF000000;  /* sign extend */
      argInfo = ' ' + (v3 >> 8);  /* fixed24.8 → integer */
      bytes = 4;
    }

    /* Hex bytes column */
    var hex = '';
    for(var b = 0; b < bytes && i+b < bc.length; b++){
      hex += ('0' + bc[i+b].toString(16)).slice(-2) + ' ';
    }
    lines.push('  ' + pad(pc, 4) + ': ' + hex.padEnd(13) + name + argInfo);
    i += bytes;
  }
}

function showBytecode(){
  showErr('');
  var src = codeEl.value;
  var c = makeCompiler();
  if(!c)return;
  var r = c.compile(src);
  if(r.error){
    showErr('<b>Compile error</b> at line ' + r.line + ': ' + r.error);
    return;
  }
  var listing = disassemble(c, r);
  var out = document.getElementById('out');
  out.textContent = listing;
  out.style.color = '#dcdcdc';
  out.classList.add('expanded');  /* T51: expand output panel for listing */
  document.getElementById('meta').textContent =
    'bc=' + r.bytecode.length + 'B  atoms=' + r.atoms + '  funcs=' + r.funcs +
    '  top=' + r.bcSize + 'B  body=' + r.bodySize + 'B';
}

/* ===== File manager ===== */
async function loadFiles(){
  try{
    var resp=await fetch('/files');var list=await resp.json();
    var sel=document.getElementById('filesel');
    sel.innerHTML='<option value="">-- files --</option>';
    list.forEach(function(f){var o=document.createElement('option');o.value=f.name;o.textContent=f.name+' ('+f.size+'B)';sel.appendChild(o)})
  }catch(e){}
}
async function loadFile(){
  var name=document.getElementById('filesel').value;
  if(!name)return;
  try{var resp=await fetch('/file?name='+encodeURIComponent(name));var txt=await resp.text();codeEl.value=txt;doHighlight()}catch(e){showErr('Load failed: '+e.message)}
}
async function saveFile(){
  var name=document.getElementById('filesel').value;
  if(!name){name=prompt('File name (e.g. game.js):');if(!name)return}
  if(!name.endsWith('.js'))name+='.js';
  var src=codeEl.value;
  var out=document.getElementById('out');
  out.classList.remove('expanded');
  out.style.color='#dcdcdc';
  /* Disable all buttons during save to prevent double-clicks. */
  var btns=document.querySelectorAll('.toolbar button');
  btns.forEach(function(b){b.disabled=true});
  var saveTimeout;
  var log='';
  try{
    out.textContent='Saving '+name+'...';
    saveTimeout=setTimeout(function(){showErr('Save timed out — server not responding');btns.forEach(function(b){b.disabled=false})},10000);
    /* T51-fix: send the whole file in ONE request (no chunking).
     * ESP32 has plenty of free heap (~215KB), so the entire JS source
     * (typically <10KB) and the entire .mjsb bytecode (typically <5KB)
     * fit in a single HTTP request body without OOM.  This is simpler
     * and avoids the chunking protocol's content-type/NUL-byte issues.
     * Server-side http_file_put() handles the simple POST case directly
     * when no `append` query parameter is present. */
    /* Step 1: Save .js source (whole file in one POST). */
    var jsUrl='/file?name='+encodeURIComponent(name);
    var resp=await fetch(jsUrl,{method:'POST',headers:{'Content-Type':'text/plain'},body:src});
    if(!resp.ok)throw new Error('HTTP '+resp.status+' saving .js');
    var jsSize=await resp.text();
    log+='Saved .js: '+name+' ('+jsSize+')\n';
    clearTimeout(saveTimeout);
    /* Step 2: Compile. */
    out.textContent=log+'Compiling...';
    var baseName=name.replace(/\.js$/,'');
    var c=makeCompiler();if(!c){btns.forEach(function(b){b.disabled=false});return}
    var r=c.compile(src);
    if(r.error){
      log+='Compile ERROR: '+r.error+' (line '+r.line+')\n.mjsb NOT saved. Fix errors first.';
      out.textContent=log;out.style.color='#f48771';out.classList.add('expanded');
      loadFiles();return;
    }
    if(!r.bytecode||r.bytecode.length===0){
      log+='Compile returned empty bytecode.\n.mjsb NOT saved.';
      out.textContent=log;out.style.color='#f48771';out.classList.add('expanded');
      loadFiles();return;
    }
    /* Step 3: Save .mjsb as comma-separated decimal text (no NUL bytes).
     * Encoding as decimals avoids ESP32 WebServer's String=NUL-truncation
     * bug.  Server-side http_file_put() detects the decimal format (first
     * byte is a digit) and parses comma-separated numbers to bytes. */
    out.textContent=log+'Saving .mjsb ('+r.bytecode.length+'B)...';
    saveTimeout=setTimeout(function(){showErr('Save .mjsb timed out');btns.forEach(function(b){b.disabled=false})},10000);
    var bcStr=Array.from(new Uint8Array(r.bytecode)).join(',');
    var mjsbUrl='/file?name='+encodeURIComponent(baseName+'.mjsb');
    var resp2=await fetch(mjsbUrl,{method:'POST',headers:{'Content-Type':'text/plain'},body:bcStr});
    if(!resp2.ok)throw new Error('HTTP '+resp2.status+' saving .mjsb');
    var mjsbSize=await resp2.text();
    clearTimeout(saveTimeout);
    log+='Saved .mjsb: '+baseName+'.mjsb ('+mjsbSize+', '+r.bytecode.length+'B bc)';
    out.textContent=log;out.classList.add('expanded');
    document.getElementById('meta').textContent=name+'  bc='+r.bytecode.length+'B  atoms='+r.atoms+'  funcs='+r.funcs;
  }catch(e){
    log+='ERROR: '+e.message;
    out.textContent=log;out.style.color='#f48771';out.classList.add('expanded');
    showErr('Save failed: '+e.message);
  }finally{
    clearTimeout(saveTimeout);
    btns.forEach(function(b){b.disabled=false});
    loadFiles();
  }
}
function newFile(){
  var name=prompt('New file name (e.g. game.js):');
  if(!name)return;if(!name.endsWith('.js'))name+='.js';
  codeEl.value='// '+name+'\n';doHighlight();
  var sel=document.getElementById('filesel');var o=document.createElement('option');o.value=name;o.textContent=name+' (new)';sel.appendChild(o);sel.value=name;
}
async function delFile(){
  var name=document.getElementById('filesel').value;if(!name)return;
  if(!confirm('Delete '+name+'?'))return;
  try{await fetch('/file?name='+encodeURIComponent(name)+'&delete=1',{method:'POST'});loadFiles();document.getElementById('out').textContent='deleted '+name}catch(e){showErr('Delete failed: '+e.message)}
}
/* T51: Toggle auto-run for the selected file.
 * Save File already saves both .js and .mjsb.
 * Auto-run just sets/clears /autorun.txt to point to the script. */
async function toggleAutorun(){
  var name=document.getElementById('filesel').value;
  if(!name){
    showErr('Select a file first');
    return;
  }
  var baseName=name.replace(/\.js$/,'');
  var out=document.getElementById('out');
  out.classList.remove('expanded');
  out.style.color='#dcdcdc';

  /* Check current autorun. */
  var isAuto=false;
  try{
    var r=await fetch('/autorun');
    var j=await r.json();
    isAuto=(j.autorun===baseName);
  }catch(e){}

  if(isAuto){
    /* Clear auto-run. */
    try{
      await fetch('/autorun',{method:'POST',headers:{'Content-Type':'text/plain'},body:''});
      out.textContent='Auto-run DISABLED for "'+baseName+'".\nScript still saved — use RGT to run manually.';
    }catch(e){
      showErr('Failed to clear auto-run: '+e.message);
    }
  }else{
    /* Check that .mjsb exists (Save File must be done first). */
    var hasMjsb=false;
    try{
      var resp=await fetch('/files');
      var files=await resp.json();
      for(var i=0;i<files.length;i++){
        if(files[i].name===baseName+'.mjsb'){hasMjsb=true;break}
      }
    }catch(e){}
    /* Also check .mjsb files (they're not in the .js list). */
    if(!hasMjsb){
      /* Try listing all files including .mjsb. */
      try{
        var resp2=await fetch('/file?name='+encodeURIComponent(baseName+'.mjsb'));
        hasMjsb=resp2.ok;
      }catch(e){}
    }
    if(!hasMjsb){
      out.textContent='No .mjsb for "'+baseName+'".\nPress "Save File" first to compile and save bytecode.';
      out.style.color='#f48771';
      out.classList.add('expanded');
      return;
    }
    /* Set as autorun. */
    try{
      var resp3=await fetch('/autorun',{method:'POST',headers:{'Content-Type':'text/plain'},body:baseName});
      var txt3=await resp3.text();
      out.textContent='Auto-run ENABLED for "'+baseName+'".\nDevice will run this script on boot.';
    }catch(e){
      showErr('Set autorun failed: '+e.message);
    }
  }
  loadFiles();
}

/* Load file list + device globals on startup */
loadFiles();
fetchGlobals();
/* T51-fix: recompute sprite editor canvas size on window resize/orientation
 * change so it adapts when the phone rotates between portrait/landscape. */
window.addEventListener('resize',function(){
  if(document.getElementById('spriteModal').classList.contains('show')){
    seComputeCellSize();
    seRedraw();
  }
});
</script>
</body>
</html>
)HTML";

#endif /* MICROJS_WEBUI_H */
