/*
 * microjs_vm.h — bytecode-only JS interpreter for ESP8266
 * ====================================================================
 *
 * T26 ARCHITECTURE — compiler/VM split:
 *   - Browser (web UI): lexer + parser + bytecode emitter (microjs_compiler.js)
 *   - Device (ESP8266): this file — bytecode VM only, no parser.
 *
 * The browser compiles JS source to a portable bytecode blob and POSTs
 * it to /run.  The device receives the blob, calls mjs_load_bytecode()
 * to register its atoms/consts/funcs/bytecode, then calls mjs_run().
 *
 * This dramatically shrinks the device footprint:
 *   - No lexer, no parser, no emitter → ~50 KB ROM savings
 *   - No AST-in-RAM during compilation → ~4 KB RAM savings
 *   - No MJSEmitter / look-ahead state → simpler context
 *
 * TRADE-OFFS (same as T25 microjs):
 *   - int30 numbers only (no float)
 *   - No try/catch (errors halt the script)
 *   - No ===, no TypedArray, no RegExp, no Date
 *   - Errors are reported as "runtime halt at pc=N" (line info is in
 *     the bytecode debug map, optionally emitted by the compiler)
 *
 * BYTECODE FORMAT (portable, little-endian):
 *   See mjs_load_bytecode() below for the layout.
 *
 * PUBLIC API:
 *   mjs_init(mem, mem_size)            -> MJSContext*
 *   mjs_destroy(ctx)
 *   mjs_load_bytecode(ctx, buf, size)  -> int (0=ok, non-zero=err)
 *   mjs_run(ctx, err, err_size)        -> int (0=ok)
 *   mjs_register_global(ctx, name, fn)
 *   mjs_set_global_value(ctx, name, val)
 *   mjs_new_object / mjs_new_array / mjs_new_string / mjs_new_cfunction
 *   mjs_get_property / mjs_set_property / mjs_get_index / mjs_set_index
 *   mjs_int / mjs_undefined / mjs_null / mjs_true / mjs_false / mjs_bool
 *   mjs_to_int / mjs_to_cstr / mjs_is_*
 *   mjs_last_error(ctx)                -> const char*
 *   mjs_free_mem(ctx) / mjs_total_mem(ctx)
 *
 * USAGE (in the .ino):
 *   #define MJS_VM_IMPLEMENTATION
 *   #include "microjs_vm.h"
 *
 * LICENSE: MIT.
 * ====================================================================
 */
#ifndef MICROJS_VM_H
#define MICROJS_VM_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================
 * Public types
 * ============================================================ */

typedef struct MJSContext MJSContext;

/* JS value — tagged word.  On 32-bit platforms (ESP8266): uint32_t.
 * On 64-bit (PC test): uint64_t so host pointers fit. */
#if defined(__x86_64__) || defined(__aarch64__) || defined(__LP64__) || defined(_LP64)
typedef uint64_t MJSValue;
#define MJS_PTR_MASK (~(uint64_t)3)
#else
typedef uint32_t MJSValue;
#define MJS_PTR_MASK (~(uint32_t)3)
#endif

typedef MJSValue (*MJSCFunction)(MJSContext *ctx, int argc, MJSValue *argv);

/* T51: Native function table for OP_NATIVE_CALL inline caching.
 * Defined in the .ino, declared extern here so the VM can access it. */
extern MJSCFunction g_native_fns[16];

/* ============================================================
 * Lifecycle + bytecode loading
 * ============================================================ */

MJSContext *mjs_init(void *mem, size_t mem_size);
void        mjs_destroy(MJSContext *ctx);

/* Parse a bytecode blob and wire it into the context.  After this,
 * call mjs_run() to execute.  Returns 0 on success, non-zero on
 * error (mjs_last_error() returns the message). */
int mjs_load_bytecode(MJSContext *ctx, const uint8_t *buf, size_t size);
/* Like mjs_load_bytecode but uses the buffer directly (no copy into JS heap).
 * The buffer MUST outlive the MJSContext — const strings point into it.
 * If the buffer is freed while the context is alive, accessing any string
 * constant will cause a Hard Fault.  The caller is responsible for
 * managing the buffer lifetime. */
int mjs_load_bytecode_inplace(MJSContext *ctx, uint8_t *buf, size_t size);

/* Execute the currently-loaded bytecode starting at pc=0.
 * Returns 0 on normal HALT, non-zero on runtime error. */
int mjs_run(MJSContext *ctx);

/* ============================================================
 * Native function registration + value construction
 * ============================================================ */

void     mjs_register_global(MJSContext *ctx, const char *name, MJSCFunction fn);
void     mjs_set_global_value(MJSContext *ctx, const char *name, MJSValue val);

MJSValue mjs_new_object(MJSContext *ctx);
MJSValue mjs_new_array(MJSContext *ctx, int initial_len);
MJSValue mjs_new_string(MJSContext *ctx, const char *s, size_t len);
MJSValue mjs_new_const_string(MJSContext *ctx, const char *s, size_t len);
MJSValue mjs_new_cfunction(MJSContext *ctx, MJSCFunction fn, const char *name);
MJSValue mjs_new_bound_method(MJSContext *ctx, MJSCFunction fn, MJSValue this_val);

/* T51: Prototype chain — get/set __proto__ for inheritance. */
MJSValue mjs_get_prototype(MJSContext *ctx, MJSValue obj);
void     mjs_set_prototype(MJSContext *ctx, MJSValue obj, MJSValue proto);

MJSValue mjs_get_property(MJSContext *ctx, MJSValue obj, const char *key);
void     mjs_set_property(MJSContext *ctx, MJSValue obj, const char *key, MJSValue val);
MJSValue mjs_get_index(MJSContext *ctx, MJSValue arr, int idx);
void     mjs_set_index(MJSContext *ctx, MJSValue arr, int idx, MJSValue val);

/* Call a JS function value (returned by mjs_get_property or pushed by
 * OP_FUNCTION) from native code.  Used for setTimeout/setInterval
 * callbacks.  Returns the function's return value (or MJS_UNDEF_V on
 * error — check mjs_last_error()).
 *
 * IMPORTANT: this is RE-ENTRANT — it pushes a new call frame on top of
 * any currently-executing frame.  The caller must NOT be in the middle
 * of an OP_CALL setup (i.e., the value stack must be at a frame
 * boundary).  In practice this means: call mjs_call_value() only from
 * the .ino's main loop() AFTER mjs_run() has returned, NOT from inside
 * a native function that was itself called by mjs_run(). */
MJSValue mjs_call_value(MJSContext *ctx, MJSValue fn,
                        int argc, MJSValue *argv);

/* ============================================================
 * Value constructors / predicates / accessors
 * ============================================================ */

MJSValue mjs_int(int32_t i);
MJSValue mjs_undefined(void);
MJSValue mjs_null(void);
MJSValue mjs_true(void);
MJSValue mjs_false(void);
MJSValue mjs_bool(int b);

int32_t      mjs_to_int(MJSContext *ctx, MJSValue v);
int          mjs_to_bool(MJSContext *ctx, MJSValue v);
const char  *mjs_to_cstr(MJSContext *ctx, MJSValue v, size_t *len_out);

int mjs_is_int(MJSValue v);
int mjs_is_string(MJSContext *ctx, MJSValue v);
int mjs_is_object(MJSContext *ctx, MJSValue v);
int mjs_is_array(MJSContext *ctx, MJSValue v);
int mjs_is_function(MJSContext *ctx, MJSValue v);
int mjs_is_undefined(MJSValue v);
int mjs_is_null(MJSValue v);

/* ============================================================
 * Diagnostics
 * ============================================================ */

const char *mjs_last_error(MJSContext *ctx);
size_t      mjs_free_mem(MJSContext *ctx);
size_t      mjs_total_mem(MJSContext *ctx);

/* Force garbage collection.  Marks all reachable objects from roots
 * (globals, locals, value stack, constants) and frees unreachable
 * heap objects.  Called automatically on OOM, but can be called
 * manually (e.g. from the gc() native) to reclaim memory. */
void        mjs_gc(MJSContext *ctx);

/* T50: mark a value as a GC root.  Exposed so the .ino's GC root
 * walker (set via mjs_set_gc_hook) can mark additional roots that
 * live in C globals (e.g. g_timers[].cb). */
void        mjs_mark_value(MJSContext *ctx, MJSValue v);

/* T50: GC root walker hook.  The .ino can register a function that
 * the GC will call during the mark phase to mark additional roots.
 * The walker should call mjs_mark_value(ctx, v) for each reachable
 * JS value it holds.  user_data is passed through to the walker. */
typedef void (*MJS_GC_RootWalker)(MJSContext *ctx, void *user_data);
void        mjs_set_gc_hook(MJSContext *ctx, MJS_GC_RootWalker walker, void *user_data);
/* T51-fix: Compaction root registration — C-side MJSValue pointers that
 * compaction must update when moving heap blocks. */
void        mjs_add_compact_root(MJSValue *vp);
void        mjs_clear_compact_roots(void);
void        mjs_compact(MJSContext *ctx);  /* T51: explicit heap compaction */
/* T51: Yield callback — called every 1024 opcodes during mjs_run.
 * If it returns true, mjs_run aborts (cooperative multitasking).
 * Used by .ino to check for incoming HTTP /run requests. */
typedef bool (*mjs_yield_cb_t)(void);
void        mjs_set_yield_callback(mjs_yield_cb_t cb);

#ifdef __cplusplus
}
#endif

#endif /* MICROJS_VM_H */


/* ============================================================
 *
 * IMPLEMENTATION
 *
 * ============================================================ */
#ifdef MJS_VM_IMPLEMENTATION

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================
 * Value encoding
 * ============================================================
 *
 * 32-bit tagged value (or 64-bit on x86_64 for testing):
 *   bits 0-1 (tag):
 *     00 = pointer (always 4-byte aligned, low 2 bits zero)
 *     01 = int30 (signed: -536870912 .. 536870911)
 *     10 = special (bits 2-4 encode which: undef/null/true/false/exc)
 *     11 = reserved
 */
#define TAG_PTR      0u
#define TAG_INT      1u
#define TAG_SPECIAL  2u

#define SPECIAL_UNDEF  0x02u
#define SPECIAL_NULL   0x06u
#define SPECIAL_TRUE   0x0Au
#define SPECIAL_FALSE  0x0Eu
#define SPECIAL_NAN    0x12u   /* T51: NaN as special value */

#define MJS_MAKE_INT(i)    ((MJSValue)((((uint32_t)(i)) << 2u) | TAG_INT))
#define MJS_GET_INT(v)     ((int32_t)(((int32_t)(uint32_t)(v)) >> 2))

#define MJS_MAKE_SPECIAL(s) ((MJSValue)((s) | TAG_SPECIAL))
#define MJS_UNDEF_V    MJS_MAKE_SPECIAL(SPECIAL_UNDEF)
#define MJS_NULL_V     MJS_MAKE_SPECIAL(SPECIAL_NULL)
#define MJS_TRUE_V     MJS_MAKE_SPECIAL(SPECIAL_TRUE)
#define MJS_FALSE_V    MJS_MAKE_SPECIAL(SPECIAL_FALSE)
#define MJS_NAN_V      MJS_MAKE_SPECIAL(SPECIAL_NAN)

#define MJS_IS_INT(v)      (((v) & 3u) == TAG_INT)
#define MJS_IS_PTR(v)      (((v) & 3u) == TAG_PTR)
#define MJS_IS_SPECIAL(v)  (((v) & 3u) == TAG_SPECIAL)
#define MJS_IS_UNDEF(v)    ((v) == MJS_UNDEF_V)
#define MJS_IS_NULL(v)     ((v) == MJS_NULL_V)
#define MJS_GET_PTR(v)     ((void*)((uintptr_t)(v) & (uintptr_t)MJS_PTR_MASK))

/* ============================================================
 * Heap object types
 * ============================================================ */

#define MJS_T_OBJECT   1u
#define MJS_T_ARRAY    2u
#define MJS_T_STRING   3u
#define MJS_T_CFUNC    4u
#define MJS_T_FUNC     5u
#define MJS_T_SLOTS    6u  /* T51: object slot array (collectable by GC) */
#define MJS_T_ACCESSOR 7u  /* T51: get/set property accessor */
/* T51-fix/GC-1: marker for blocks that sweep has added to free_list.
 * The compactor must distinguish "bytecode blob (type=0, pinned)" from
 * "swept freed block (was type!=0, now needs to be reclaimed)".
 * Previously sweep left the type field untouched, so the compactor's
 * `is_live = (type != 0)` test saw freed blocks as live and copied them
 * — making compaction a no-op and the heap filled up despite GC running.
 * Now sweep stamps MJS_T_FREED on every block it adds to free_list;
 * the compactor simply skips blocks with type==MJS_T_FREED. */
#define MJS_T_FREED    0xFFu

/* T51: Compressed MJSHeader - 4 bytes total (was 8). */
#define MJS_HEADER_SIZE     4
#define MJS_HEADER_LARGE    0xFF

typedef struct {
    uint8_t  type_gc;  /* low 4 bits = type, bit 7 = gc_mark */
    uint8_t  size8;    /* size / 8, or MJS_HEADER_LARGE */
    uint16_t next8;    /* next_free offset / 8 */
} MJSHeader;

#define MJS_HDR_TYPE(h)     ((h)->type_gc & 0x0F)
#define MJS_HDR_SET_TYPE(h, t)  do { (h)->type_gc = ((h)->type_gc & 0xF0) | ((t) & 0x0F); } while(0)
#define MJS_HDR_MARK(h)     (((h)->type_gc & 0x80) != 0)
#define MJS_HDR_SET_MARK(h, m) do { if (m) (h)->type_gc |= 0x80; else (h)->type_gc &= 0x7F; } while(0)

static uint16_t mjs_hdr_size(MJSHeader *h) {
    if (h->size8 == MJS_HEADER_LARGE) { uint8_t *d = (uint8_t*)(h+1); return *(uint16_t*)d; }
    return (uint16_t)h->size8 * 8;
}
static void mjs_hdr_set_size(MJSHeader *h, uint16_t sz) {
    sz = (sz + 7) & ~7;
    if (sz <= 2040) { h->size8 = (uint8_t)(sz / 8); }
    else { h->size8 = MJS_HEADER_LARGE; uint8_t *d = (uint8_t*)(h+1); *(uint16_t*)d = sz; }
}
static uint32_t mjs_hdr_next(MJSHeader *h) { return (uint32_t)h->next8 * 8; }
static void mjs_hdr_set_next(MJSHeader *h, uint32_t off) { h->next8 = (uint16_t)(off / 8); }


typedef struct {
    MJSHeader hdr;
    uint16_t len;
    uint16_t hash;
    const char *data;  /* T36: pointer to string bytes.
                        * For heap strings: points to (char*)(this + 1).
                        * For const strings: points into bytecode blob (PROGMEM-ok on ESP8266).
                        * Eliminates copying const strings to heap. */
} MJSString;

typedef struct {
    uint16_t atom;
    MJSValue val;
} MJSSlot;

typedef struct {
    MJSHeader hdr;
    uint16_t capacity;
    uint16_t count;
    MJSSlot *slots;  /* T51: pointer to separately-allocated slot array,
                      * allows resizing without moving the object. */
    MJSValue proto;  /* T51: prototype object for inheritance chain.
                      * MJS_NULL_V = no prototype (root object).
                      * Otherwise points to another MJSObject. */
} MJSObject;

typedef struct {
    MJSHeader hdr;
    uint16_t capacity;
    uint16_t length;
    uint8_t  elem_size;  /* 0 = MJSValue[], 1 = uint8_t[], 2 = uint16_t[] */
    uint8_t  _pad[3];
    /* T51-fix: Ensure items[] (which starts at sizeof(MJSArray)) is aligned
     * for MJSValue access.  On 64-bit (test VM), MJSValue is 8 bytes and
     * requires 8-byte alignment.  Without this pad, sizeof(MJSArray)=12,
     * which is MISaligned for MJSValue (12 % 8 = 4, not 0).
     * This caused array elements to be read/written at misaligned addresses,
     * leading to data corruption on 64-bit (silent on x86, crash on ARM).
     * The pad makes sizeof(MJSArray)=16, so items start at offset 16 (aligned). */
    uint32_t _align_pad;
} MJSArray;

typedef struct {
    MJSHeader hdr;
    MJSCFunction fn;
    uint16_t name_atom;
    uint16_t _pad;
    MJSValue bound_this;  /* T38: for arr.push() etc — the array/object */
} MJSCFunc;

/* T51: Property accessor (get/set).  Stored in MJSSlot.val instead of
 * a regular value.  When LOAD_PROP finds an accessor, it calls getter.
 * When STORE_PROP finds an accessor, it calls setter. */
typedef struct {
    MJSHeader hdr;
    MJSValue getter;  /* MJS_T_FUNC or MJS_T_CFUNC, or UNDEF if no getter */
    MJSValue setter;  /* MJS_T_FUNC or MJS_T_CFUNC, or UNDEF if no setter */
    MJSValue this_val; /* the object this accessor belongs to */
} MJSAccessor;

typedef struct {
    MJSHeader hdr;
    uint16_t pc;
    uint8_t  argc;
    uint8_t  nlocals;
    MJSValue proto;  /* T51: auto-created prototype object for `new`.
                      * When a function is declared, a prototype object
                      * is created automatically (like JS spec).
                      * Accessible via Constructor.prototype. */
} MJSFuncObj;

/* ============================================================
 * Opcodes — must match microjs_compiler.js exactly.
 * ============================================================ */

enum MJSOp {
    OP_NOP        = 0x00,
    OP_UNDEF      = 0x01,
    OP_NULL       = 0x02,
    OP_TRUE       = 0x03,
    OP_FALSE      = 0x04,
    OP_INT8       = 0x05,
    OP_INT16      = 0x06,
    OP_INT24      = 0x07,
    OP_CONST      = 0x08,
    OP_LOAD_LOCAL = 0x09,
    OP_STORE_LOCAL= 0x0A,
    OP_LOAD_GLOBAL= 0x0B,
    OP_STORE_GLOBAL=0x0C,
    OP_POP        = 0x0D,
    OP_DUP        = 0x0E,
    OP_SWAP       = 0x0F,
    OP_LOAD_PROP  = 0x10,
    OP_STORE_PROP = 0x11,
    OP_LOAD_INDEX = 0x12,
    OP_STORE_INDEX= 0x13,
    OP_NEW_OBJECT = 0x14,
    OP_NEW_ARRAY  = 0x15,
    OP_ADD        = 0x18,
    OP_SUB        = 0x19,
    OP_MUL        = 0x1A,
    OP_DIV        = 0x1B,
    OP_MOD        = 0x1C,
    OP_NEG        = 0x1D,
    OP_INC        = 0x1E,
    OP_DEC        = 0x1F,
    OP_AND        = 0x20,
    OP_OR         = 0x21,
    OP_XOR        = 0x22,
    OP_SHL        = 0x23,
    OP_SHR        = 0x24,
    OP_USHR       = 0x25,
    OP_BNOT       = 0x26,
    OP_LNOT       = 0x27,
    OP_EQ         = 0x28,
    OP_NE         = 0x29,
    OP_LT         = 0x2A,
    OP_LE         = 0x2B,
    OP_GT         = 0x2C,
    OP_GE         = 0x2D,
    OP_JMP        = 0x30,
    OP_JZ         = 0x31,
    OP_JNZ        = 0x32,
    OP_CALL       = 0x33,
    OP_CALL_METHOD= 0x34,
    OP_RET        = 0x35,
    OP_RET_UNDEF  = 0x36,
    OP_HALT       = 0x37,
    OP_FUNCTION   = 0x38,
    /* T30 additions */
    OP_STRICT_EQ  = 0x39,  /* === : same type + same value */
    OP_STRICT_NE  = 0x3A,  /* !== */
    OP_TYPEOF     = 0x3B,  /* push string describing top of stack's type */
    OP_INSTANCEOF = 0x3C,  /* simplified instanceof (compares type tags) */
    OP_FOR_IN_NEXT= 0x3D,  /* iterate object keys: pops iter, pushes key or undef */
    OP_FOR_OF_NEXT= 0x3E,  /* iterate array values: pops iter, pushes val or undef */
    OP_DEFINE_ACCESSOR = 0x3F, /* T51: stack [obj, fn, atom_u8, is_get_u8] → [obj] */
    OP_PUSH_TRY   = 0x40,  /* T51: push try handler: 2 bytes (catch_pc as i16) */
    OP_POP_TRY    = 0x41,  /* T51: pop try handler (try block completed normally) */
    OP_THROW      = 0x42,  /* T51: throw top of stack as error */
    OP_NEW        = 0x43,  /* T51: new Constructor(args) */
    OP_THIS       = 0x44,  /* T51: push current `this` value */
    OP_CALL_WITH_THIS = 0x45,  /* T51: call method with this=obj */
    OP_NATIVE_CALL = 0x46,     /* T51: inline native call — 1 byte native_id */
    OP_NEW_ARRAY_U8 = 0x47,   /* T51: compact u8 array — count, then count raw bytes */
    OP_NEW_ARRAY_U16 = 0x48,  /* T51: compact u16 array — count, then count*2 raw bytes */
    OP_NEW_ARRAY16 = 0x49,    /* T51: array with 16-bit count (for > 255 elements) */
    /* T54/JS-10-vm: Unary +x — ToNumber coercion for the top-of-stack value.
     * Both microjs_repl.h (ROP_TO_NUMBER) and the browser compiler
     * (microjs_compiler_js.h, TO_NUMBER:74) emit byte 0x4A, so the VM
     * must implement it.  Previously OP_LAST was at 0x4A, which made
     * every `+x` expression hit the dispatch default → "bad opcode". */
    OP_TO_NUMBER  = 0x4A,
    OP_LAST       = 0x4B
};

/* ============================================================
 * Context
 * ============================================================ */

#define MJS_MAX_GLOBALS  128
/* T51: Reduced MJS_LOCALS_MAX from 2048 to 512.
 * locals[] is embedded in MJSContext (not in the heap buffer), so each
 * slot costs 8 bytes of static memory.  2048 slots = 16 KB, which with
 * the 28 KB ESP8266 buffer left only ~1.6 KB for the JS heap!
 *
 * 512 slots × 8 bytes = 4 KB.  With MJS_LOCALS_PER_FRAME=16 and
 * MJS_CALL_DEPTH=24, max usage is 24×16=384, leaving headroom.
 * This supports 24 levels of recursion with up to 16 locals each.
 *
 * MJS_LOCALS_PER_FRAME reduced from 64 to 16 — most functions use <10
 * locals (params + temporaries).  16 is enough for QuickSort's partition
 * (7 locals) and similar.  This allows 512/16=32 levels of recursion.
 *
 * MJS_STACK_MAX reduced from 512 to 128 (1 KB) — stack is used for
 * expression evaluation, 128 values is plenty for non-pathological code.
 *
 * This frees ~12 KB for the JS heap: 1.6 KB → ~16 KB available. */
#define MJS_LOCALS_MAX   512
#define MJS_LOCALS_PER_FRAME 16
#define MJS_STACK_MAX    128   /* 128 × 8 = 1 KB stack (was 512 = 4 KB) */
#define MJS_CALL_DEPTH   24    /* T36: was 16 */
#define MJS_TRY_DEPTH    16    /* T51: max nested try blocks */
#define MJS_ERR_SIZE     160
#define MJS_ATOM_HASH_SIZE 256  /* power of 2, >= max atoms */
#define MJS_GLOBAL_HASH_SIZE 128  /* power of 2, >= max globals */

struct MJSContext {
    /* Buffer boundaries */
    uint8_t *buf_start;
    uint8_t *buf_end;
    size_t   buf_size;

    /* Heap allocator (bump + free list) */
    uint8_t *heap_ptr;
    uint8_t *heap_start;   /* start of heap region (for GC sweep) */
    uint8_t *heap_limit;
    uint32_t free_list;

    /* Bytecode buffer — points INTO the loaded bytecode blob.
     * The blob is copied into the heap region by mjs_load_bytecode,
     * so the caller can free the original buffer after load. */
    uint8_t *bc_start;       /* start of bytecode (after header) */
    uint8_t *bc_end;         /* end of bytecode */
    uint16_t bc_size;

    /* Atoms (parsed from blob).  atoms[i] points to a NUL-terminated
     * string inside bc_start.  atoms[0] is reserved. */
    const char *atoms[256];
    uint16_t    atom_count;
    /* T37: hash table for fast atom lookup.  Maps hash%SIZE → atom_id (1-based, 0=empty).
     * Open addressing with linear probing.  Built once in mjs_load_bytecode. */
    uint8_t     atom_hash[MJS_ATOM_HASH_SIZE];

    /* Constants (parsed from blob).  consts[i] is a decoded MJSValue. */
    MJSValue consts[256];
    uint16_t const_count;

    /* Functions (parsed from blob).  funcs[i] = {pc, argc, nlocals}. */
    struct {
        uint16_t pc;
        uint8_t  argc;
        uint8_t  nlocals;
    } funcs[64];
    uint16_t func_count;

    /* Globals (registered by .ino via mjs_register_global) */
    uint16_t  global_atoms[MJS_MAX_GLOBALS];
    MJSValue  global_vals[MJS_MAX_GLOBALS];
    uint16_t  global_count;
    /* T37: hash table for O(1) global lookup by atom id. */
    uint8_t   global_hash[MJS_GLOBAL_HASH_SIZE];

    /* Locals pool (separate from value stack to avoid PUSH collision) */
    MJSValue  locals[MJS_LOCALS_MAX];
    int       local_base;

    /* Value stack (grows down from buf_end) */
    MJSValue *sp;
    MJSValue *stack_bottom;

    /* Call frames */
    struct {
        uint16_t pc;
        uint16_t bc_region;  /* 0 = top-level, 1 = body region */
        int      base;
        MJSValue this_val;   /* T51: saved `this` for this frame */
        /* T51-fix/BUG-7: per-frame nlocals, copied from MJSFuncObj at
         * call time.  GC mark phase and compaction Phase 2 walk
         * locals[0 .. local_base + top_frame.nlocals - 1] using this
         * field.  Previously both phases hardcoded MJS_LOCALS_PER_FRAME
         * (= 16), so any function with nlocals > 16 had its upper
         * locals unmarked / unrelocated → silent UAF. */
        uint8_t  nlocals;
    } frames[MJS_CALL_DEPTH];
    int frame_depth;
    MJSValue _this;  /* T51: current `this` value (UNDEF at top level) */

    /* T51: Try/catch handler stack */
    struct {
        uint16_t catch_pc;  /* pc to jump to on error */
        int      frame_depth;  /* frame_depth at time of PUSH_TRY */
        int      local_base;   /* local_base at time of PUSH_TRY */
        MJSValue *sp;          /* sp at time of PUSH_TRY */
    } try_stack[MJS_TRY_DEPTH];
    int try_depth;

    /* Error state */
    char     err_buf[MJS_ERR_SIZE];
    int      has_error;
    uint16_t err_pc;

    /* VM state */
    uint16_t pc;

    /* T51: Run timeout — if non-zero, mjs_run aborts after this many ms. */
    uint32_t run_timeout_ms;
    uint32_t run_start_ms;

    /* T50: GC root walker — lets the .ino register additional GC roots
     * (e.g. timer callbacks) so they don't get swept while still
     * reachable from C code.  Set via mjs_set_gc_hook(). */
    void (*gc_root_walker)(MJSContext *ctx, void *user_data);
    void *gc_root_user;
    /* T51-debug: GC statistics — filled by mjs_gc, read by gcDebug. */
    int _gc_marked;
    int _gc_swept;
    int _gc_bytecode;
    /* T51-fix: array grow side-channel. */
    MJSValue _grown_array;
    int _array_grown;
    /* T51: new() target — when OP_NEW calls a JS function as constructor,
     * this holds the newly-created object.  When the function returns
     * (OP_RET), if the return value is not an object, this is pushed
     * instead.  Reset to UNDEF after each OP_RET. */
    MJSValue _new_target;
};

/* ============================================================
 * Public value constructors / predicates
 * ============================================================ */

MJSValue mjs_int(int32_t i) { return MJS_MAKE_INT((int32_t)(i) << 8); }  /* fixed24.8: integer → fixed */
MJSValue mjs_undefined(void) { return MJS_UNDEF_V; }
MJSValue mjs_null(void) { return MJS_NULL_V; }
MJSValue mjs_true(void) { return MJS_TRUE_V; }
MJSValue mjs_false(void) { return MJS_FALSE_V; }
MJSValue mjs_bool(int b) { return b ? MJS_TRUE_V : MJS_FALSE_V; }

int mjs_is_int(MJSValue v) { return MJS_IS_INT(v); }
int mjs_is_undefined(MJSValue v) { return MJS_IS_UNDEF(v); }
int mjs_is_null(MJSValue v) { return MJS_IS_NULL(v); }

int mjs_is_string(MJSContext *ctx, MJSValue v) {
    (void)ctx;
    if (!MJS_IS_PTR(v)) return 0;
    return MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(v)) == MJS_T_STRING;
}
int mjs_is_object(MJSContext *ctx, MJSValue v) {
    (void)ctx;
    if (!MJS_IS_PTR(v)) return 0;
    return MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(v)) == MJS_T_OBJECT;
}
int mjs_is_array(MJSContext *ctx, MJSValue v) {
    (void)ctx;
    if (!MJS_IS_PTR(v)) return 0;
    return MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(v)) == MJS_T_ARRAY;
}
int mjs_is_function(MJSContext *ctx, MJSValue v) {
    (void)ctx;
    if (!MJS_IS_PTR(v)) return 0;
    uint8_t t = MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(v));
    return t == MJS_T_CFUNC || t == MJS_T_FUNC;
}

int32_t mjs_to_int(MJSContext *ctx, MJSValue v) {
    (void)ctx;
    if (MJS_IS_INT(v)) return MJS_GET_INT(v) >> 8;  /* fixed24.8: extract integer part */
    if (v == MJS_TRUE_V)  return 1;
    if (v == MJS_FALSE_V || v == MJS_NULL_V || v == MJS_UNDEF_V || v == MJS_NAN_V) return 0;
    if (MJS_IS_PTR(v)) {
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
        if (MJS_HDR_TYPE(h) == MJS_T_STRING) {
            MJSString *s = (MJSString*)h;
            int32_t n = 0; int sign = 1; size_t i = 0;
            const char *p = s->data;
            while (i < s->len && (*p == ' ' || *p == '\t')) { p++; i++; }
            if (i < s->len && (*p == '+' || *p == '-')) {
                if (*p == '-') sign = -1;
                p++; i++;
            }
            while (i < s->len && *p >= '0' && *p <= '9') {
                n = n * 10 + (*p - '0'); p++; i++;
            }
            return n * sign;
        }
    }
    return 0;
}

int mjs_to_bool(MJSContext *ctx, MJSValue v) {
    if (MJS_IS_INT(v)) return MJS_GET_INT(v) != 0;
    if (v == MJS_TRUE_V)  return 1;
    if (v == MJS_FALSE_V || v == MJS_NULL_V || v == MJS_UNDEF_V || v == MJS_NAN_V) return 0;
    if (MJS_IS_PTR(v)) {
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
        if (MJS_HDR_TYPE(h) == MJS_T_STRING) return ((MJSString*)h)->len != 0;
        return 1;
    }
    return 0;
}

const char *mjs_to_cstr(MJSContext *ctx, MJSValue v, size_t *len_out) {
    (void)ctx;
    if (MJS_IS_PTR(v)) {
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
        if (MJS_HDR_TYPE(h) == MJS_T_STRING) {
            MJSString *s = (MJSString*)h;
            if (len_out) *len_out = s->len;
            return s->data;  /* T36: use data pointer instead of (s+1) */
        }
    }
    if (len_out) *len_out = 0;
    return "";
}

const char *mjs_last_error(MJSContext *ctx) {
    return ctx && ctx->has_error ? ctx->err_buf : "";
}

/* ============================================================
 * Heap allocator
 * ============================================================ */

#define MJS_ALIGN8(n) (((n) + 7u) & ~7u)

/* T51-compact: Forward declaration. */
void mjs_compact(MJSContext *ctx);

/* T51-compact: Relocation map entry — records old offset → new offset
 * for each moved block.  Used by mjs_relocate_value to update pointers.
 * T51-fix: Reduced from 512 to 64 — saves 3.5KB BSS, enough for typical
 * heap compaction (rarely more than 30-40 live blocks). */
/* T51-fix/BUG-4: bumped from 64 to 256.  A 16 KB ESP8266 heap easily
 * holds 200+ small objects (strings, slots, closures); when compaction
 * triggers under OOM (the densest possible heap state), more than 64
 * live blocks routinely need to be moved.  The old fixed cap of 64
 * silently dropped entries from the (old→new) relocation map, leaving
 * MJSValues and C-side raw pointers pointing at the OLD (now vacated
 * or reused) heap location → UAF.  256 entries × 4 bytes × 2 arrays
 * = 2 KB BSS, acceptable on ESP8266.  If a future heap grows past
 * this, switch to a dynamic resizable map or a mark-shift compact. */
#define MJS_MAX_RELOC 256
static uint32_t mjs_reloc_old[MJS_MAX_RELOC];
static uint32_t mjs_reloc_new[MJS_MAX_RELOC];
static int mjs_reloc_count;
static MJSContext *mjs_reloc_ctx;  /* context being compacted */

/* T51-fix: Flag to suppress compaction during critical sections
 * (e.g. mjs_load_bytecode which holds a pointer across mjs_alloc). */
static bool mjs_no_compact = false;

/* T51-fix: Compaction roots — C-side MJSValue pointers that need updating
 * when compaction moves heap blocks.  The .ino registers pointers like
 * g_js_http_handler and timer callbacks here, so compaction can update them.
 *
 * Without this, compaction moves callback function objects but C globals
 * still point to the old (freed) location → dangling pointer → NULL body. */
#define MJS_MAX_COMPACT_ROOTS 32
static MJSValue *mjs_compact_roots[MJS_MAX_COMPACT_ROOTS];
static int mjs_compact_root_count = 0;

void mjs_add_compact_root(MJSValue *vp) {
    if (mjs_compact_root_count < MJS_MAX_COMPACT_ROOTS) {
        mjs_compact_roots[mjs_compact_root_count++] = vp;
    }
}

void mjs_clear_compact_roots(void) {
    mjs_compact_root_count = 0;
}

/* T51-compact: Update a single MJSValue if it points to a moved block.
 * Called for every pointer in the system after compaction.
 * Handles both pointers to block start AND pointers inside blocks
 * (e.g. o->slots points to slots_block + sizeof(MJSHeader)). */
static void mjs_relocate_value(MJSValue *vp) {
    MJSValue v = *vp;
    if (!MJS_IS_PTR(v)) return;
    uint8_t *ptr = (uint8_t*)MJS_GET_PTR(v);
    uint8_t *heap_start = mjs_reloc_ctx->heap_start;
    uint8_t *heap_limit = mjs_reloc_ctx->heap_limit;
    /* Only relocate pointers that point into the heap. */
    if (ptr < heap_start || ptr >= heap_limit) return;
    uint32_t off = (uint32_t)(ptr - mjs_reloc_ctx->buf_start);
    /* Search relocation map for a block that contains this pointer.
     * Check if off is within [old, old + block_size).  But we don't
     * store block sizes in the reloc map.  Instead, since blocks are
     * sorted by offset (we walk heap linearly), find the block with
     * the largest old_off that is <= off. */
    int best = -1;
    for (int i = 0; i < mjs_reloc_count; i++) {
        if (mjs_reloc_old[i] <= off && (best == -1 || mjs_reloc_old[i] > mjs_reloc_old[best])) {
            best = i;
        }
    }
    if (best >= 0) {
        /* Pointer is inside block `best`.  Compute new pointer:
         * new_off = new_block_start + (off - old_block_start) */
        uint32_t delta = off - mjs_reloc_old[best];
        uint32_t new_off = mjs_reloc_new[best] + delta;
        *vp = (MJSValue)(((uintptr_t)mjs_reloc_ctx->buf_start + new_off) | TAG_PTR);
    }
    /* If best == -1, pointer didn't move (no block with old_off <= off
     * that was relocated).  Leave as-is. */
}

/* T51-compact: Update a raw pointer (not MJSValue) that points into heap.
 * Used for o->slots which is MJSSlot*, not MJSValue. */
static void mjs_relocate_ptr(void **pp) {
    uint8_t *ptr = (uint8_t*)*pp;
    uint8_t *heap_start = mjs_reloc_ctx->heap_start;
    uint8_t *heap_limit = mjs_reloc_ctx->heap_limit;
    if (ptr < heap_start || ptr >= heap_limit) return;
    uint32_t off = (uint32_t)(ptr - mjs_reloc_ctx->buf_start);
    int best = -1;
    for (int i = 0; i < mjs_reloc_count; i++) {
        if (mjs_reloc_old[i] <= off && (best == -1 || mjs_reloc_old[i] > mjs_reloc_old[best])) {
            best = i;
        }
    }
    if (best >= 0) {
        uint32_t delta = off - mjs_reloc_old[best];
        uint32_t new_off = mjs_reloc_new[best] + delta;
        *pp = (void*)(mjs_reloc_ctx->buf_start + new_off);
    }
}

/* T51-compact: Full heap compaction.
 * Moves all live (type != 0) blocks to the start of heap, then updates
 * every pointer in the system to point to the new locations.
 *
 * After compaction:
 *   - heap_ptr = end of live blocks (start of free space)
 *   - free_list = 0 (all free space is one contiguous block at end)
 *   - All MJSValue pointers updated to new locations
 *
 * This is O(n * m) where n = live blocks, m = total pointers.
 * Only called when allocation fails (rare), so performance is acceptable. */
void mjs_compact(MJSContext *ctx) {
    mjs_reloc_ctx = ctx;
    mjs_reloc_count = 0;

    /* Phase 1: Move live blocks to the start, build relocation map. */
    uint8_t *read_ptr = ctx->heap_start;
    uint8_t *write_ptr = ctx->heap_start;

    while (read_ptr < ctx->heap_ptr) {
        MJSHeader *h = (MJSHeader*)read_ptr;
        uint16_t sz = mjs_hdr_size(h);
        if (sz == 0) break;  /* corrupt heap */

        /* T51-fix/GC-1: real compaction logic.
         *   type == 0           → bytecode blob, pinned, copy to write_ptr
         *   type == MJS_T_FREED → swept free block, SKIP (do NOT copy,
         *                          this is the space being reclaimed)
         *   type != 0 && != FREED → live object, copy to write_ptr
         * Previously the test was a tautology `is_live || type==0`
         * which copied everything, making compaction a no-op. */
        uint8_t htype = MJS_HDR_TYPE(h);
        if (htype == MJS_T_FREED) {
            /* Freed block — skip.  write_ptr stays put; this slot will
             * be overwritten by the next live block's memmove (or remain
             * as free space if there are no more live blocks after it). */
            ;
        } else {
            /* Live object or bytecode blob — copy to write_ptr. */
            uint32_t old_off = (uint32_t)(read_ptr - ctx->buf_start);
            uint32_t new_off = (uint32_t)(write_ptr - ctx->buf_start);
            if (old_off != new_off) {
                /* Block needs to move. */
                memmove(write_ptr, read_ptr, sz);  /* memmove handles overlap */
                if (mjs_reloc_count < MJS_MAX_RELOC) {
                    mjs_reloc_old[mjs_reloc_count] = old_off;
                    mjs_reloc_new[mjs_reloc_count] = new_off;
                    mjs_reloc_count++;
                }
            }
            write_ptr += sz;
        }
        read_ptr += sz;
    }

    /* If nothing moved, no need to update pointers. */
    if (mjs_reloc_count == 0) {
        ctx->heap_ptr = write_ptr;
        ctx->free_list = 0;
        return;
    }

    /* Phase 2: Update all MJSValue pointers in context. */
    /* Globals. */
    for (int i = 0; i < ctx->global_count; i++) {
        mjs_relocate_value(&ctx->global_vals[i]);
    }
    /* Constants (const strings point into bytecode blob, not heap —
     * but const object/array values may point to heap). */
    for (int i = 0; i < ctx->const_count; i++) {
        mjs_relocate_value(&ctx->consts[i]);
    }
    /* Locals.
     * T51-fix/BUG-7: walk local_base + top_frame.nlocals slots, not
     * the hardcoded MJS_LOCALS_PER_FRAME=16, so functions with nlocals
     * > 16 get their upper locals relocated too. */
    int cm_top_nlocals = (ctx->frame_depth > 0)
        ? ctx->frames[ctx->frame_depth - 1].nlocals
        : MJS_LOCALS_PER_FRAME;
    if (cm_top_nlocals < MJS_LOCALS_PER_FRAME) cm_top_nlocals = MJS_LOCALS_PER_FRAME;
    int cm_max_locals = ctx->local_base + cm_top_nlocals;
    if (cm_max_locals > MJS_LOCALS_MAX) cm_max_locals = MJS_LOCALS_MAX;
    for (int i = 0; i < cm_max_locals; i++) {
        mjs_relocate_value(&ctx->locals[i]);
    }
    /* Value stack (from sp to buf_end — stack grows down).
     * buf_end is uint8_t*, cast to MJSValue* for comparison. */
    MJSValue *stack_end = (MJSValue*)ctx->buf_end;
    for (MJSValue *p = ctx->sp; p < stack_end; p++) {
        mjs_relocate_value(p);
    }
    /* T51-fix: Update C-side compaction roots (g_js_http_handler, timer
     * callbacks, etc.).  These are MJSValue pointers in C globals that
     * compaction must update — otherwise they become dangling pointers
     * after compaction moves the referenced objects. */
    for (int i = 0; i < mjs_compact_root_count; i++) {
        mjs_relocate_value(mjs_compact_roots[i]);
    }
    /* Call frames' this_val. */
    for (int i = 0; i < ctx->frame_depth; i++) {
        mjs_relocate_value(&ctx->frames[i].this_val);
    }
    /* Current this. */
    mjs_relocate_value(&ctx->_this);
    /* T51-fix/GC-5: ctx->_new_target and ctx->_grown_array.
     * These are MJSValue fields in ctx that hold a reference to a
     * freshly-allocated heap object (constructor's `new` target /
     * grown array's new block) between two opcodes.  If compaction
     * moves the referenced object, these MUST be updated too —
     * otherwise the next OP_RET or OP_STORE_INDEX pushes/writes a
     * stale pointer to the OLD (now vacated or reused) heap location. */
    mjs_relocate_value(&ctx->_new_target);
    if (ctx->_array_grown) {
        mjs_relocate_value(&ctx->_grown_array);
    }

    /* Phase 3: Walk all heap objects and update their internal pointers. */
    uint8_t *p = ctx->heap_start;
    while (p < write_ptr) {  /* only walk live blocks (up to write_ptr) */
        MJSHeader *h = (MJSHeader*)p;
        uint16_t sz = mjs_hdr_size(h);
        if (sz == 0) break;
        uint8_t type = MJS_HDR_TYPE(h);

        if (type == MJS_T_OBJECT) {
            MJSObject *o = (MJSObject*)h;
            mjs_relocate_value(&o->proto);
            if (o->slots) {
                /* slots is a raw pointer to MJSSlot[] inside a MJS_T_SLOTS block.
                 * Use mjs_relocate_ptr (handles internal pointers). */
                mjs_relocate_ptr((void**)&o->slots);
                /* Update each slot's value. */
                for (uint16_t i = 0; i < o->capacity; i++) {
                    mjs_relocate_value(&o->slots[i].val);
                }
            }
        } else if (type == MJS_T_ARRAY) {
            MJSArray *a = (MJSArray*)h;
            /* elem_size == 0 means MJSValue[] (generic array).
             * elem_size 1 or 2 are packed u8/u16 arrays (no pointers). */
            if (a->elem_size == 0) {
                MJSValue *items = (MJSValue*)(a + 1);
                for (uint16_t i = 0; i < a->length; i++) {
                    mjs_relocate_value(&items[i]);
                }
            }
        } else if (type == MJS_T_STRING) {
            MJSString *s = (MJSString*)h;
            /* Heap-owned strings have data pointing right after the struct
             * (at s + sizeof(MJSString)).  Since the struct moved, update
             * data pointer using mjs_relocate_ptr (handles internal ptrs).
             * Const strings point into bytecode blob (not heap) — leave alone. */
            mjs_relocate_ptr((void**)&s->data);
        } else if (type == MJS_T_CFUNC) {
            MJSCFunc *c = (MJSCFunc*)h;
            mjs_relocate_value(&c->bound_this);
        } else if (type == MJS_T_FUNC) {
            MJSFuncObj *f = (MJSFuncObj*)h;
            mjs_relocate_value(&f->proto);
        } else if (type == MJS_T_SLOTS) {  /* MJS_T_SLOTS = 6 */
            /* Slot array — contains MJSSlot[] with MJSValue values.
             * The slots pointer in MJSObject points here.  Update all
             * slot values (slot.atom is not a pointer, only slot.val is). */
            MJSSlot *slots = (MJSSlot*)((uint8_t*)h + sizeof(MJSHeader));
            /* Calculate capacity from block size. */
            uint16_t cap = (sz - sizeof(MJSHeader)) / sizeof(MJSSlot);
            for (uint16_t i = 0; i < cap; i++) {
                mjs_relocate_value(&slots[i].val);
            }
        } else if (type == MJS_T_ACCESSOR) {  /* MJS_T_ACCESSOR = 7 */
            MJSAccessor *acc = (MJSAccessor*)h;
            mjs_relocate_value(&acc->getter);
            mjs_relocate_value(&acc->setter);
            mjs_relocate_value(&acc->this_val);
        }

        p += sz;
    }

    /* Phase 4: Reset heap state. */
    ctx->heap_ptr = write_ptr;
    ctx->free_list = 0;  /* all free space is one block at end */
}

static void *mjs_alloc(MJSContext *ctx, uint32_t size) {
    size = MJS_ALIGN8(size);
    if (size < 16) size = 16;

    /* T51: Try free list first — with BLOCK SPLITTING.
     * Uses a "prev header" pointer approach instead of &h->next_free
     * since next_free is now accessed via mjs_hdr_next()/mjs_hdr_set_next(). */
    uint32_t prev_off = 0;  /* offset of previous block's next field, 0 = ctx->free_list */
    uint32_t cur_off = ctx->free_list;
    while (cur_off) {
        MJSHeader *h = (MJSHeader*)(ctx->buf_start + cur_off);
        if (mjs_hdr_size(h) >= size) {
            uint16_t remainder = mjs_hdr_size(h) - (uint16_t)size;
            if (remainder >= size + 16) {
                /* Split: shrink this block, create new block from remainder. */
                MJSHeader *split = (MJSHeader*)((uint8_t*)h + size);
                MJS_HDR_SET_TYPE(split, 0);
                MJS_HDR_SET_MARK(split, 0);
                mjs_hdr_set_size(split, remainder);
                mjs_hdr_set_next(split, mjs_hdr_next(h));
                mjs_hdr_set_size(h, (uint16_t)size);
                uint32_t split_off = (uint32_t)((uint8_t*)split - ctx->buf_start);
                if (prev_off == 0) ctx->free_list = split_off;
                else mjs_hdr_set_next((MJSHeader*)(ctx->buf_start + prev_off), split_off);
            } else {
                /* Don't split — use the whole block. */
                uint32_t next_off = mjs_hdr_next(h);
                if (prev_off == 0) ctx->free_list = next_off;
                else mjs_hdr_set_next((MJSHeader*)(ctx->buf_start + prev_off), next_off);
            }
            MJS_HDR_SET_MARK(h, 0);
            return (void*)h;
        }
        prev_off = cur_off;
        cur_off = mjs_hdr_next(h);
    }

    /* Bump-allocate.  If OOM, try GC first.
     * T51-fix: GC (mark-and-sweep) is ALWAYS safe to run — it does NOT
     * move blocks.  Only compaction moves blocks.  So even when
     * mjs_no_compact is true, we can still run GC to reclaim memory.
     * Previously we skipped GC when no_compact was set, which caused
     * the free list to become stale — mjs_alloc would return blocks
     * that were already in use → heap corruption → crash. */
    if (ctx->heap_ptr + size > ctx->heap_limit) {
        mjs_gc(ctx);
        /* Retry free list after GC. */
        prev_off = 0;
        cur_off = ctx->free_list;
        while (cur_off) {
            MJSHeader *h = (MJSHeader*)(ctx->buf_start + cur_off);
            if (mjs_hdr_size(h) >= size) {
                uint16_t remainder = mjs_hdr_size(h) - (uint16_t)size;
                if (remainder >= size + 16) {
                    MJSHeader *split = (MJSHeader*)((uint8_t*)h + size);
                    MJS_HDR_SET_TYPE(split, 0);
                    MJS_HDR_SET_MARK(split, 0);
                    mjs_hdr_set_size(split, remainder);
                    mjs_hdr_set_next(split, mjs_hdr_next(h));
                    mjs_hdr_set_size(h, (uint16_t)size);
                    uint32_t split_off = (uint32_t)((uint8_t*)split - ctx->buf_start);
                    if (prev_off == 0) ctx->free_list = split_off;
                    else mjs_hdr_set_next((MJSHeader*)(ctx->buf_start + prev_off), split_off);
                } else {
                    uint32_t next_off = mjs_hdr_next(h);
                    if (prev_off == 0) ctx->free_list = next_off;
                    else mjs_hdr_set_next((MJSHeader*)(ctx->buf_start + prev_off), next_off);
                }
                MJS_HDR_SET_MARK(h, 0);
                return (void*)h;
            }
            prev_off = cur_off;
            cur_off = mjs_hdr_next(h);
        }
        #ifdef MJS_DEBUG_CONCAT
        fprintf(stderr, "[alloc] FAILED size=%d heap_ptr=%p heap_limit=%p free=%d\n",
                (int)size, (void*)ctx->heap_ptr, (void*)ctx->heap_limit,
                (int)(ctx->heap_limit - ctx->heap_ptr));
        /* Dump free list */
        fprintf(stderr, "[alloc] free_list: ");
        uint32_t d_off = ctx->free_list;
        int d_count = 0;
        while (d_off && d_count < 30) {
            MJSHeader *dh = (MJSHeader*)(ctx->buf_start + d_off);
            fprintf(stderr, "[%u:s=%u] ", d_off, mjs_hdr_size(dh));
            d_off = mjs_hdr_next(dh);
            d_count++;
        }
        fprintf(stderr, "\n");
        #endif
        /* Don't return NULL yet — try coalescing first (below). */
    }

    /* T51-compact: Heap fragmentation — allocation failed because free
     * space is split into small blocks.  Run full heap compaction:
     * move all live blocks to the start of heap, update all pointers,
     * then retry allocation from the resulting single free block at end.
     *
     * T51-fix: Don't compact if mjs_no_compact is set — callers like
     * mjs_load_bytecode hold raw pointers across mjs_alloc, and
     * compaction would invalidate them. */
    if (ctx->heap_ptr > ctx->heap_start && !mjs_no_compact) {
        mjs_compact(ctx);
        /* Retry allocation from bump space (now has one big free block). */
        if (ctx->heap_ptr + size <= ctx->heap_limit) {
            MJSHeader *h = (MJSHeader*)ctx->heap_ptr;
            ctx->heap_ptr += size;
            MJS_HDR_SET_TYPE(h, 0);
            MJS_HDR_SET_MARK(h, 0);
            mjs_hdr_set_size(h, (uint16_t)size);
            mjs_hdr_set_next(h, 0);
            return (void*)h;
        }
    }
    /* Bump allocation — check if there's room. */
    if (ctx->heap_ptr + size > ctx->heap_limit) return NULL;
    MJSHeader *h = (MJSHeader*)ctx->heap_ptr;
    ctx->heap_ptr += size;
    MJS_HDR_SET_TYPE(h, 0);
    MJS_HDR_SET_MARK(h, 0);
    mjs_hdr_set_size(h, (uint16_t)size);
    mjs_hdr_set_next(h, 0);

    /* T50: proactive GC — if free memory (bump space) is low after this
     * allocation, trigger GC to reclaim unreachable objects before the
     * NEXT allocation fails.
     * T51: Changed from 1/8 to 1/4 — more frequent GC reduces fragmentation
     * by cleaning up before small blocks accumulate between live objects.
     * T51-fix: GC (mark-and-sweep) is ALWAYS safe — it doesn't move blocks.
     * Only compaction is suppressed by mjs_no_compact.  Running GC keeps
     * the free list fresh, preventing stale-entry heap corruption. */
    if ((size_t)(ctx->heap_limit - ctx->heap_ptr) < (size_t)(ctx->heap_limit - ctx->heap_start) / 4) {
        mjs_gc(ctx);
    }

    return (void*)h;
}

/* ============================================================
 * Mark-and-sweep GC
 * ============================================================
 *
 * Mark phase: walk all roots (globals, locals, value stack, timers)
 * and mark every reachable heap object.
 *
 * Sweep phase: walk every allocated block from heap_start to heap_ptr.
 * If a block is not marked, add it to the free list.  If it is marked,
 * clear the mark for next cycle.
 *
 * Roots:
 *   - global_vals[] (registered globals like print, tft, etc.)
 *   - locals[] (all slots up to local_base + MJS_LOCALS_PER_FRAME)
 *   - value stack (from sp to buf_end)
 *   - timer callbacks (g_timers[] in the .ino — but GC doesn't know
 *     about those; they're kept alive because the .ino's timer slots
 *     hold MJSValue references.  We handle this by NOT collecting
 *     function objects — see the sweep phase comment.)
 */

static void mjs_mark_value_impl(MJSContext *ctx, MJSValue v);  /* fwd decl — T50 */

static void mjs_mark_obj(MJSContext *ctx, MJSHeader *h) {
    if (!h || MJS_HDR_MARK(h)) return;  /* already marked */
    MJS_HDR_SET_MARK(h, 1);

    if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) {
        MJSObject *o = (MJSObject*)h;
        MJSSlot *slots = o->slots;
        /* T51: Mark the slots block itself (it's a separate heap block).
         * T51-fix: o->slots now points PAST the MJSHeader (to slot data).
         * To mark the underlying GC block, back up by sizeof(MJSHeader). */
        if (slots) mjs_mark_obj(ctx, (MJSHeader*)((uint8_t*)slots - sizeof(MJSHeader)));
        for (uint16_t i = 0; i < o->capacity; i++) {
            if (slots && slots[i].atom != 0 && slots[i].atom != 0xFFFFu) {
                mjs_mark_value(ctx, slots[i].val);
            }
        }
        /* T51: Mark the prototype object (inheritance chain). */
        if (o->proto != MJS_NULL_V) {
            mjs_mark_value(ctx, o->proto);
        }
    } else if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) {
        MJSArray *a = (MJSArray*)h;
        if (a->elem_size == 0) {  /* only MJSValue arrays have refs */
            MJSValue *items = (MJSValue*)(a + 1);
            for (uint16_t i = 0; i < a->length; i++) {
                mjs_mark_value(ctx, items[i]);
            }
        }
    } else if (MJS_HDR_TYPE(h) == MJS_T_ACCESSOR) {
        /* T51: Mark getter and setter functions */
        MJSAccessor *acc = (MJSAccessor*)h;
        mjs_mark_value(ctx, acc->getter);
        mjs_mark_value(ctx, acc->setter);
        mjs_mark_value(ctx, acc->this_val);
    } else if (MJS_HDR_TYPE(h) == MJS_T_FUNC) {
        /* T51: Mark the function's auto-created prototype object. */
        MJSFuncObj *f = (MJSFuncObj*)h;
        if (f->proto != MJS_NULL_V && f->proto != MJS_UNDEF_V) {
            mjs_mark_value(ctx, f->proto);
        }
    } else if (MJS_HDR_TYPE(h) == MJS_T_CFUNC) {
        /* T51-fix: Mark bound_this — CFUNCs DO have outgoing references!
         * When arr.push() creates a bound method, the CFUNC holds a
         * reference to the array via bound_this.  Without marking it,
         * GC could free the array while the bound method is still alive
         * on the stack → use-after-free → "not a function" crash. */
        MJSCFunc *c = (MJSCFunc*)h;
        if (c->bound_this != MJS_UNDEF_V) {
            mjs_mark_value(ctx, c->bound_this);
        }
    }
    /* Strings have no outgoing references. */
}

/* T50: mjs_mark_value is now a public non-static function.  The .ino's
 * GC root walker calls it to mark externally-held MJSValue references
 * (e.g. g_timers[].cb).  Inside this file we also use it directly. */
void mjs_mark_value(MJSContext *ctx, MJSValue v);

static void mjs_mark_value_impl(MJSContext *ctx, MJSValue v) {
    if (!MJS_IS_PTR(v)) return;
    mjs_mark_obj(ctx, (MJSHeader*)MJS_GET_PTR(v));
}

void mjs_mark_value(MJSContext *ctx, MJSValue v) {
    mjs_mark_value_impl(ctx, v);
}

void mjs_set_gc_hook(MJSContext *ctx, MJS_GC_RootWalker walker, void *user_data) {
    if (!ctx) return;
    ctx->gc_root_walker = walker;
    ctx->gc_root_user = user_data;
}

void mjs_gc(MJSContext *ctx) {
    if (!ctx || !ctx->heap_start) return;

    /* T51-fix: Clear stale data from the value stack BEFORE marking.
     * The stack grows DOWN: sp starts at buf_end and decreases on PUSH.
     * Active values: [sp, buf_end).  Popped values: above buf_end (none)
     * and the area [stack_bottom, sp) is UNUSED (below the active stack).
     *
     * BUT: some opcodes POP values without clearing them, leaving stale
     * pointers at addresses >= sp (in the "popped" region above sp).
     * Wait — no.  After POP (sp++), the popped value is at sp-1, which
     * is BELOW the new sp.  So [stack_bottom, sp) contains stale values!
     *
     * The mark phase marks [sp, buf_end) — the ACTIVE region.  Stale
     * values in [stack_bottom, sp) are NOT marked.  So they don't cause
     * leaks.
     *
     * The real leak was: ctx->sp was stale (not synced with local sp
     * in mjs_run).  Now fixed by syncing ctx->sp at the top of every
     * opcode dispatch.  The clearing below is a belt-and-suspenders
     * safety net for any remaining stale data in the unused stack area. */
    /* Clear the unused stack region [stack_bottom, sp) — these are
     * popped values that might contain stale object pointers.  By
     * clearing them, even if ctx->sp is briefly stale, no stale
     * pointers survive to be marked. */
    MJSValue *sb = (MJSValue*)ctx->stack_bottom;
    for (MJSValue *p = sb; p < ctx->sp; p++) {
        *p = MJS_UNDEF_V;
    }
    /* Clear locals above the active frame — leftover from returned
     * function calls that wrote to locals[new_base + ...]. */
    /* T51-fix/BUG-7: clear locals ABOVE the active top frame so stale
     * heap pointers in unused slots don't keep dead objects alive (or
     * worse, get marked and cause confusion).  Use the top frame's
     * nlocals, not the hardcoded MJS_LOCALS_PER_FRAME, so functions
     * with nlocals > 16 don't have their upper locals clobbered. */
    int top_nlocals = (ctx->frame_depth > 0)
        ? ctx->frames[ctx->frame_depth - 1].nlocals
        : MJS_LOCALS_PER_FRAME;
    if (top_nlocals < MJS_LOCALS_PER_FRAME) top_nlocals = MJS_LOCALS_PER_FRAME;
    int clear_from = ctx->local_base + top_nlocals;
    if (clear_from > MJS_LOCALS_MAX) clear_from = MJS_LOCALS_MAX;
    for (int i = clear_from; i < MJS_LOCALS_MAX; i++) {
        ctx->locals[i] = MJS_UNDEF_V;
    }

    /* ---- Mark phase ---- */
    /* 1. Globals. */
    for (uint16_t i = 0; i < ctx->global_count; i++) {
        mjs_mark_value(ctx, ctx->global_vals[i]);
    }
    /* 2. Locals — mark all slots up to local_base + top_frame.nlocals.
     *    (We don't know exactly how many frames are active, but marking
     *    extra slots is safe — they'll be undef which is not a pointer.)
     *    T51-fix/BUG-7: use top frame's nlocals instead of the hardcoded
     *    MJS_LOCALS_PER_FRAME=16, so functions with nlocals > 16 have
     *    their upper locals marked (not swept → no UAF). */
    int max_locals = ctx->local_base + top_nlocals;
    if (max_locals > MJS_LOCALS_MAX) max_locals = MJS_LOCALS_MAX;
    for (int i = 0; i < max_locals; i++) {
        mjs_mark_value(ctx, ctx->locals[i]);
    }
    /* 3. Value stack — from sp to buf_end. */
    MJSValue *stack_top = (MJSValue*)ctx->buf_end;
    for (MJSValue *p = ctx->sp; p < stack_top; p++) {
        mjs_mark_value(ctx, *p);
    }
    /* 4. Constants — string consts are heap objects. */
    for (uint16_t i = 0; i < ctx->const_count; i++) {
        mjs_mark_value(ctx, ctx->consts[i]);
    }
    /* T50: 5. External roots — e.g. timer callbacks in the .ino.
     * Without this, a setInterval callback MJSFuncObj could be swept
     * while still in the g_timers[] array, causing use-after-free
     * when the timer fires.  The .ino registers a walker that calls
     * mjs_mark_value for each active timer's cb. */
    if (ctx->gc_root_walker) {
        ctx->gc_root_walker(ctx, ctx->gc_root_user);
    }
    /* T51-fix: 6. Mark ctx->_this (current `this` value).
     * If `this` points to a heap object and GC doesn't mark it,
     * the object gets freed.  When the current function tries to
     * access `this` after gc(), it reads freed memory. */
    mjs_mark_value(ctx, ctx->_this);
    /* T51-fix: 7. Mark all call frames' this_val.
     * Saved `this` values in frames[] are heap object references
     * that GC must mark.  Without this, a saved `this` could be
     * freed while the function that saved it is still on the stack. */
    for (int i = 0; i < ctx->frame_depth; i++) {
        mjs_mark_value(ctx, ctx->frames[i].this_val);
    }
    /* T51-fix/GC-3: 8. Mark ctx->_new_target — the object currently
     * being constructed by OP_NEW, between OP_NEW setting it and
     * OP_RET consuming it.  Without this, GC during the constructor
     * body could sweep the half-constructed object.  Combined with
     * the same staging in mjs_new_object (GC-2), this closes the
     * "constructor's `this` disappears mid-construction" hole. */
    mjs_mark_value(ctx, ctx->_new_target);
    /* T51-fix/GC-4: 9. Mark ctx->_grown_array — the new (bigger)
     * array block produced by mjs_set_index's grow path, consumed
     * by the NEXT OP_STORE_INDEX.  If GC runs between the grow and
     * the store, the grown block is unreachable and gets swept —
     * then OP_STORE_INDEX writes a dangling pointer into the slot. */
    if (ctx->_array_grown) {
        mjs_mark_value(ctx, ctx->_grown_array);
    }

    /* ---- Sweep phase ----
     * Walk every allocated block from heap_start to heap_ptr.
     * Each block has a MJSHeader with size field.  If not marked,
     * add to free list.  If marked, clear the mark.
     *
     * T51: bytecode blob protection — type==0 blocks are never collected.
     * T51-fix: Now that mjs_mark_obj properly marks CFUNC.bound_this,
     * normal sweep is safe — all reachable objects are marked. */
    ctx->free_list = 0;
    int marked_count = 0, swept_count = 0, bytecode_count = 0;
    uint8_t *p = ctx->heap_start;
    while (p < ctx->heap_ptr) {
        MJSHeader *h = (MJSHeader*)p;
        uint16_t sz = mjs_hdr_size(h);
        if (sz == 0) break;  /* safety */
        uint8_t htype = MJS_HDR_TYPE(h);
        if (htype == 0) {
            bytecode_count++;  /* raw blob — never collect */
        } else if (!MJS_HDR_MARK(h)) {
            /* Collectible and unreachable — add to free list. */
            /* T51-debug: GC sweep logging — uncomment #if 1 to re-enable.
            #if 0
            if (htype == MJS_T_ARRAY || htype == MJS_T_OBJECT ||
                htype == MJS_T_FUNC || htype == MJS_T_SLOTS) {
                extern void mjs_gc_sweep_log(uint8_t type, uint16_t size, void *ptr);
                mjs_gc_sweep_log(htype, sz, (void*)p);
            }
            #endif
            */
            mjs_hdr_set_next(h, ctx->free_list);
            ctx->free_list = (uint32_t)(p - ctx->buf_start);
            /* T51-fix/GC-1: stamp MJS_T_FREED so the compactor can
             * distinguish swept freed blocks from bytecode blobs (which
             * also have type==0).  The compactor's main loop skips
             * type==MJS_T_FREED blocks, so freed space is finally
             * reclaimed instead of being memmoved into the live region
             * (the original "compaction is a no-op" bug). */
            MJS_HDR_SET_TYPE(h, MJS_T_FREED);
            swept_count++;
        } else {
            marked_count++;
        }
        MJS_HDR_SET_MARK(h, 0);  /* clear for next cycle */
        p += sz;
    }
    /* Store counts for gcDebug to read. */
    ctx->_gc_marked = marked_count;
    ctx->_gc_swept = swept_count;
    ctx->_gc_bytecode = bytecode_count;
}

/* ============================================================
 * Constructors
 * ============================================================ */

MJSValue mjs_new_object(MJSContext *ctx) {
    /* T51: Start with capacity 4 (was 16) to save memory on small objects.
     * Slots are allocated separately so the table can grow dynamically
     * via mjs_obj_set when it fills up.  This saves ~96 bytes per object
     * for the common case of objects with 1-4 properties. */
    uint16_t cap = 4;
    MJSObject *o = (MJSObject*)mjs_alloc(ctx, sizeof(MJSObject));
    if (!o) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(o)->hdr, MJS_T_OBJECT);
    o->capacity = cap;
    o->count = 0;
    /* T51-fix/GC-2: STAGE the new object in ctx->_new_target BEFORE the
     * second mjs_alloc below.  Without this, if proactive GC fires
     * inside that second mjs_alloc, the freshly-created object `o`
     * has type=MJS_T_OBJECT, mark=0, and NO root pointing to it — so
     * sweep sees it as unreachable and adds it to free_list.  Then
     * `o->slots = ...` writes into freed memory; the very next mjs_alloc
     * may reuse the same block for a different object, and we get
     * aliasing corruption.  Putting `o` in _new_target makes the GC mark
     * phase (see mjs_gc) treat it as a live root.  Cleared after the
     * slots alloc so we don't keep a stale root around. */
    MJSValue obj_val = (MJSValue)((uintptr_t)o | TAG_PTR);
    MJSValue saved_target = ctx->_new_target;
    ctx->_new_target = obj_val;
    /* T51-fix: Allocate slots WITH room for the MJSHeader in front.
     * The slots pointer (o->slots) points to the slot DATA, AFTER the
     * MJSHeader — same pattern as MJSArray items[] and MJSString data[].
     * Previously the allocation was `cap * sizeof(MJSSlot)` (32 B) but
     * the pointer was used as if pointing to data — causing slot[0] to
     * overlap with the MJSHeader bytes, and `memset(... + sizeof(MJSHeader),
     * 0, cap * sizeof(MJSSlot))` to overflow by 4 bytes into the next
     * heap block, corrupting its MJSHeader and triggering random
     * reboots / GC crashes / "object property not found" bugs.
     *
     * Layout now:
     *   bytes 0..3      : MJSHeader (type_gc, size8, next8)
     *   bytes 4..4+cap*8: slot[0], slot[1], ..., slot[cap-1]
     * o->slots = (MJSSlot*)(block + sizeof(MJSHeader))
     * GC walks blocks via MJSHeader* (the block pointer), not via slots. */
    uint32_t slots_alloc_size = sizeof(MJSHeader) + (uint32_t)cap * sizeof(MJSSlot);
    MJSSlot *slots_block = (MJSSlot*)mjs_alloc(ctx, slots_alloc_size);
    if (!slots_block) {
        /* OOM on slots — restore _new_target (the partial object `o`
         * will be reclaimed by the next GC since nothing references it). */
        ctx->_new_target = saved_target;
        o->capacity = 0;
        o->slots = NULL;
        return MJS_NULL_V;
    }
    /* Successfully allocated slots — clear _new_target so the new object
     * is only kept alive by the caller's reference (the returned MJSValue). */
    ctx->_new_target = saved_target;
    MJS_HDR_SET_TYPE((MJSHeader*)slots_block, MJS_T_SLOTS);  /* T51: GC can collect old slots */
    MJSSlot *slots = (MJSSlot*)((uint8_t*)slots_block + sizeof(MJSHeader));
    /* Zero the slot data (header is already set up by mjs_alloc). */
    memset(slots, 0, cap * sizeof(MJSSlot));
    o->slots = slots;
    o->proto = MJS_NULL_V;  /* T51: no prototype by default */
    return obj_val;
}

/* T51: Prototype chain access — get/set the __proto__ of an object.
 * Used by inheritance: when a property isn't found on obj, the VM
 * walks obj->proto → proto->proto → ... until found or chain ends.
 * mjs_get_prototype returns the proto MJSValue (or MJS_NULL_V).
 * mjs_set_prototype sets it (only works on objects). */
MJSValue mjs_get_prototype(MJSContext *ctx, MJSValue obj) {
    (void)ctx;
    if (!MJS_IS_PTR(obj)) return MJS_NULL_V;
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
    if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) return MJS_NULL_V;
    MJSObject *o = (MJSObject*)h;
    return o->proto;
}

void mjs_set_prototype(MJSContext *ctx, MJSValue obj, MJSValue proto) {
    (void)ctx;
    if (!MJS_IS_PTR(obj)) return;
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
    if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) return;
    MJSObject *o = (MJSObject*)h;
    /* Only allow object or null as prototype. */
    if (proto == MJS_NULL_V) {
        o->proto = MJS_NULL_V;
    } else if (MJS_IS_PTR(proto)) {
        MJSHeader *ph = (MJSHeader*)MJS_GET_PTR(proto);
        if (MJS_HDR_TYPE(ph) == MJS_T_OBJECT) {
            o->proto = proto;
        }
    }
}

MJSValue mjs_new_array(MJSContext *ctx, int initial_len) {
    if (initial_len < 0) initial_len = 0;
    if (initial_len > 65535) initial_len = 65535;
    uint16_t cap = 4;
    while (cap < initial_len) cap <<= 1;
    uint32_t size = sizeof(MJSArray) + cap * sizeof(MJSValue);
    MJSArray *a = (MJSArray*)mjs_alloc(ctx, size);
    if (!a) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(a)->hdr, MJS_T_ARRAY);
    /* T51: don't override hdr.size (see mjs_new_object comment) */
    a->capacity = cap;
    a->length = (uint16_t)initial_len;
    a->elem_size = 0;  /* MJSValue[] by default */
    MJSValue *items = (MJSValue*)(a + 1);
    for (int i = 0; i < initial_len; i++) items[i] = MJS_UNDEF_V;
    return (MJSValue)((uintptr_t)a | TAG_PTR);
}

/* Create a packed array of small ints (uint8_t or uint16_t).  Used by
 * OP_NEW_ARRAY when all elements are small ints — saves 4× RAM on
 * ESP8266 (1 byte per element vs 4-byte MJSValue).  Good for sprites. */
MJSValue mjs_new_array_packed(MJSContext *ctx, int initial_len, uint8_t elem_size) {
    if (initial_len < 0) initial_len = 0;
    if (initial_len > 65535) initial_len = 65535;
    if (elem_size != 1 && elem_size != 2) elem_size = 1;
    uint16_t cap = 4;
    while (cap < initial_len) cap <<= 1;
    uint32_t bytes_per_elem = elem_size;
    uint32_t size = sizeof(MJSArray) + cap * bytes_per_elem;
    MJSArray *a = (MJSArray*)mjs_alloc(ctx, size);
    if (!a) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(a)->hdr, MJS_T_ARRAY);
    /* T51: don't override hdr.size (see mjs_new_object comment) */
    a->capacity = cap;
    a->length = (uint16_t)initial_len;
    a->elem_size = elem_size;
    /* Zero the data area. */
    memset((uint8_t*)(a + 1), 0, cap * bytes_per_elem);
    return (MJSValue)((uintptr_t)a | TAG_PTR);
}

static uint16_t mjs_hash(const char *s, size_t len) {
    uint16_t h = 0x811Cu;
    for (size_t i = 0; i < len; i++) {
        h ^= (uint8_t)s[i];
        h = (uint16_t)(h * 16777619u);
    }
    return h ? h : 1;
}

MJSValue mjs_new_string(MJSContext *ctx, const char *s, size_t len) {
    if (len == 0 && s) len = strlen(s);
    if (len > 65535) len = 65535;
    uint32_t size = sizeof(MJSString) + len + 1;
    MJSString *str = (MJSString*)mjs_alloc(ctx, size);
    if (!str) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(str)->hdr, MJS_T_STRING);
    /* T51: don't override hdr.size (see mjs_new_object comment) */
    str->len = (uint16_t)len;
    /* T51-fix: s may be NULL when called from mjs_concat (which allocates
     * an empty string then fills it in).  Handle gracefully. */
    str->hash = s ? mjs_hash(s, len) : 0;
    /* data points right after this struct (heap-owned copy) */
    str->data = (const char*)(str + 1);
    if (s && len > 0) memcpy((char*)str->data, s, len);
    ((char*)str->data)[len] = '\0';
    return (MJSValue)((uintptr_t)str | TAG_PTR);
}

/* Create a const string that points into an external buffer (e.g. bytecode
 * blob in RAM or PROGMEM).  Does NOT copy the string data — just creates
 * a lightweight MJSString header on the heap.  The caller must ensure the
 * buffer outlives the MJSString.  GC will NOT free the data (only the header). */
MJSValue mjs_new_const_string(MJSContext *ctx, const char *s, size_t len) {
    if (len == 0 && s) len = strlen(s);
    if (len > 65535) len = 65535;
    /* Only allocate the header — no data copy. */
    uint32_t size = sizeof(MJSString);
    MJSString *str = (MJSString*)mjs_alloc(ctx, size);
    if (!str) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(str)->hdr, MJS_T_STRING);
    /* T51: don't override hdr.size (see mjs_new_object comment) */
    str->len = (uint16_t)len;
    str->hash = mjs_hash(s, len);
    str->data = s;  /* points into external buffer (blob/PROGMEM) */
    return (MJSValue)((uintptr_t)str | TAG_PTR);
}

MJSValue mjs_new_cfunction(MJSContext *ctx, MJSCFunction fn, const char *name) {
    MJSCFunc *c = (MJSCFunc*)mjs_alloc(ctx, sizeof(MJSCFunc));
    if (!c) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(c)->hdr, MJS_T_CFUNC);
    /* T51: hdr.size set by mjs_alloc */
    c->fn = fn;
    c->name_atom = 0;
    c->_pad = 0;
    c->bound_this = MJS_UNDEF_V;
    (void)name;
    return (MJSValue)((uintptr_t)c | TAG_PTR);
}

/* T38: create a bound method — cfunction with `this` pinned.
 * T51-fix: Suppress compaction during mjs_alloc — the `this_val`
 * parameter is a C local variable (a copy of the stack value), so
 * if compaction runs inside mjs_alloc and moves the referenced
 * object, `this_val` is NOT updated (compaction only updates
 * MJSValue fields in globals/locals/stack/compact-roots, not C
 * function parameters).  This caused bound methods to hold stale
 * pointers to moved array/object blocks, leading to crashes when
 * the bound method was later called via OP_CALL_WITH_THIS. */
MJSValue mjs_new_bound_method(MJSContext *ctx, MJSCFunction fn, MJSValue this_val) {
    bool prev_no_compact = mjs_no_compact;
    mjs_no_compact = true;
    MJSCFunc *c = (MJSCFunc*)mjs_alloc(ctx, sizeof(MJSCFunc));
    mjs_no_compact = prev_no_compact;
    if (!c) return MJS_NULL_V;
    MJS_HDR_SET_TYPE(&(c)->hdr, MJS_T_CFUNC);
    c->fn = fn;
    c->name_atom = 0;
    c->_pad = 0;
    c->bound_this = this_val;
    return (MJSValue)((uintptr_t)c | TAG_PTR);
}

/* ============================================================
 * Property / index access
 * ============================================================ */

/* Find atom by string.  T37: uses hash table for O(1) average lookup.
 * Falls back to linear scan on hash miss (shouldn't happen if table is built). */
static uint16_t mjs_atom_find(MJSContext *ctx, const char *s, size_t len) {
    if (ctx->atom_count == 0) return 0;
    uint16_t h = mjs_hash(s, len);
    uint16_t mask = MJS_ATOM_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(h & mask);
    for (uint16_t probe = 0; probe < MJS_ATOM_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        uint8_t aid = ctx->atom_hash[slot];
        if (aid == 0) return 0;  /* empty slot — not found */
        /* aid is 1-based atom id.  Verify string matches. */
        const char *a = ctx->atoms[aid - 1];
        if (strlen(a) == len && memcmp(a, s, len) == 0) return aid;
    }
    return 0;  /* table full (shouldn't happen) */
}

/* T51-fix: Intern an atom — find or CREATE.
 * Used by mjs_set_property so that JSON keys (which never appear as
 * identifiers in the JS source and thus aren't in the bytecode's atom
 * table) can be stored as object properties.
 *
 * If the atom exists, returns its ID.  If not, and there's room
 * (atom_count < 256), strdup's the string into the system heap,
 * stores the pointer in atoms[atom_count], adds it to the hash table,
 * and returns atom_count+1 (1-based ID).
 *
 * The strdup'd string is freed in mjs_destroy().  It MUST NOT point
 * into the bytecode blob (which can be freed separately). */
static uint16_t mjs_atom_intern(MJSContext *ctx, const char *s, size_t len) {
    /* Fast path: atom already exists. */
    uint16_t existing = mjs_atom_find(ctx, s, len);
    if (existing != 0) return existing;
    /* Not found — create.  Check capacity. */
    if (ctx->atom_count >= 255) return 0;  /* table full (0 = reserved) */
    /* strdup the string into the system heap.  The atoms[] array holds
     * either pointers into bc_start (for atoms loaded from bytecode)
     * or pointers into malloc'd memory (for runtime-interned atoms).
     * Both are NUL-terminated.  mjs_destroy() frees the runtime ones
     * by checking if the pointer falls outside [bc_start, bc_end). */
    char *copy = (char*)malloc(len + 1);
    if (!copy) return 0;
    memcpy(copy, s, len);
    copy[len] = '\0';
    uint16_t new_id = (uint16_t)(ctx->atom_count + 1);  /* 1-based */
    ctx->atoms[ctx->atom_count] = copy;
    ctx->atom_count++;
    /* Add to hash table. */
    uint16_t h = mjs_hash(s, len);
    uint16_t mask = MJS_ATOM_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(h & mask);
    for (uint16_t probe = 0; probe < MJS_ATOM_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        if (ctx->atom_hash[slot] == 0) {
            ctx->atom_hash[slot] = (uint8_t)new_id;
            break;
        }
    }
    return new_id;
}

/* Build atom hash table after loading atoms from bytecode. */
static void mjs_atom_hash_build(MJSContext *ctx) {
    memset(ctx->atom_hash, 0, sizeof(ctx->atom_hash));
    uint16_t mask = MJS_ATOM_HASH_SIZE - 1;
    for (uint16_t i = 0; i < ctx->atom_count; i++) {
        const char *s = ctx->atoms[i];
        uint16_t h = mjs_hash(s, strlen(s));
        uint16_t idx = (uint16_t)(h & mask);
        for (uint16_t probe = 0; probe < MJS_ATOM_HASH_SIZE; probe++) {
            uint16_t slot = (uint16_t)((idx + probe) & mask);
            if (ctx->atom_hash[slot] == 0) {
                ctx->atom_hash[slot] = (uint8_t)(i + 1);  /* 1-based */
                break;
            }
        }
    }
}

/* T51: Property lookup with prototype chain traversal.
 * Searches obj's own slots first.  If not found, walks up the
 * __proto__ chain until found or chain ends (proto == NULL).
 * Depth limit prevents infinite loops on circular prototype chains. */
#define MJS_PROTO_DEPTH_MAX 16

/* T51/GC-6: Internal helper — actual property lookup body.
 * mjs_obj_get() wraps this with mjs_no_compact=true so that any
 * GC triggered by mjs_call_value (getter invocation) does NOT
 * compact the heap, which would invalidate the C-side pointers
 * (h, o, slots, vh, acc) kept across the prototype-chain walk.
 * Splitting the body out lets us use direct `return` instead of
 * `goto done`, which avoids the C++ "jump crosses initialization"
 * error that the previous single-function wrapper triggered. */
static MJSValue mjs_obj_get_impl(MJSContext *ctx, MJSValue obj, uint16_t atom) {
    if (!MJS_IS_PTR(obj)) return MJS_UNDEF_V;
    MJSValue cur = obj;
    for (int depth = 0; depth < MJS_PROTO_DEPTH_MAX; depth++) {
        if (!MJS_IS_PTR(cur)) return MJS_UNDEF_V;
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(cur);
        if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) return MJS_UNDEF_V;
        MJSObject *o = (MJSObject*)h;
        MJSSlot *slots = o->slots;
        if (slots && o->capacity > 0) {
            uint16_t mask = o->capacity - 1;
            uint16_t i = (uint16_t)(atom & mask);
            for (uint16_t probe = 0; probe < o->capacity; probe++) {
                uint16_t idx = (uint16_t)((i + probe) & mask);
                if (slots[idx].atom == 0) break;  /* not in this object */
                if (slots[idx].atom == atom) {
                    MJSValue val = slots[idx].val;
                    /* T51: Check for accessor (get/set) */
                    if (MJS_IS_PTR(val)) {
                        MJSHeader *vh = (MJSHeader*)MJS_GET_PTR(val);
                        if (MJS_HDR_TYPE(vh) == MJS_T_ACCESSOR) {
                            MJSAccessor *acc = (MJSAccessor*)vh;
                            if (MJS_IS_PTR(acc->getter)) {
                                /* T51-fix: Call getter with no args and `this=obj`.
                                 * Old code: `mjs_call_value(ctx, acc->getter, obj, NULL)`
                                 * passed `obj` (MJSValue) as `argc` (int). With argc
                                 * holding the bit pattern of obj (often > 1 billion)
                                 * and argv=NULL, mjs_call_value would dereference
                                 * NULL when copying args into locals → crash. */
                                MJSValue saved_this = ctx->_this;
                                ctx->_this = obj;
                                MJSValue r = mjs_call_value(ctx, acc->getter, 0, NULL);
                                ctx->_this = saved_this;
                                return r;
                            }
                            return MJS_UNDEF_V;  /* no getter */
                        }
                    }
                    return val;
                }
            }
        }
        /* Not found in this object — walk up the prototype chain. */
        if (o->proto == MJS_NULL_V) return MJS_UNDEF_V;
        cur = o->proto;
    }
    return MJS_UNDEF_V;  /* chain too deep */
}

/* T51/GC-6: Public wrapper — suppresses compaction around the
 * prototype-chain walk + potential getter call.  After this
 * returns, the caller may dereference MJSValues that were live
 * before the call (e.g. a stack slot holding an array); marking
 * still runs so any newly dead objects will be reclaimed on the
 * NEXT GC pass, but nothing moves under our hands. */
static MJSValue mjs_obj_get(MJSContext *ctx, MJSValue obj, uint16_t atom) {
    bool prev_no_compact = mjs_no_compact;
    mjs_no_compact = true;
    MJSValue r = mjs_obj_get_impl(ctx, obj, atom);
    mjs_no_compact = prev_no_compact;
    return r;
}

/* T51: Resize object's slot array when the hash table is full.
 * Doubles capacity (4 → 8 → 16 → 32...), rehashes all existing slots. */
static void mjs_obj_resize(MJSContext *ctx, MJSObject *o) {
    uint16_t new_cap = o->capacity * 2;
    if (new_cap > 256) return;  /* cap at 256 slots */
    /* T51-fix: include MJSHeader in allocation; new_slots_data points
     * PAST the header.  See mjs_new_object() for layout details. */
    uint32_t alloc_size = sizeof(MJSHeader) + (uint32_t)new_cap * sizeof(MJSSlot);
    MJSSlot *new_slots_block = (MJSSlot*)mjs_alloc(ctx, alloc_size);
    if (!new_slots_block) return;
    MJS_HDR_SET_TYPE((MJSHeader*)new_slots_block, MJS_T_SLOTS);
    MJSSlot *new_slots = (MJSSlot*)((uint8_t*)new_slots_block + sizeof(MJSHeader));
    /* Zero the slot data (header is already set up). */
    memset(new_slots, 0, new_cap * sizeof(MJSSlot));
    /* Rehash existing slots into new array */
    uint16_t new_mask = new_cap - 1;
    for (uint16_t j = 0; j < o->capacity; j++) {
        if (o->slots[j].atom != 0 && o->slots[j].atom != 0xFFFFu) {
            uint16_t i = (uint16_t)(o->slots[j].atom & new_mask);
            for (uint16_t probe = 0; probe < new_cap; probe++) {
                uint16_t idx = (uint16_t)((i + probe) & new_mask);
                if (new_slots[idx].atom == 0) {
                    new_slots[idx] = o->slots[j];
                    break;
                }
            }
        }
    }
    /* Old slots block is now garbage — GC will reclaim it. */
    o->slots = new_slots;
    o->capacity = new_cap;
}

/* T51/GC-6: Internal helper — actual property store body.
 * mjs_obj_set() wraps this with mjs_no_compact=true so that any
 * GC triggered by mjs_call_value (setter invocation) or by
 * mjs_obj_resize (which calls mjs_alloc) does NOT compact the
 * heap, which would invalidate the C-side pointers (h, o, slots,
 * vh, acc) used here.  Splitting the body out lets us use direct
 * `return` instead of `goto done`, which avoids the C++ "jump
 * crosses initialization" error that the previous single-function
 * wrapper triggered. */
static void mjs_obj_set_impl(MJSContext *ctx, MJSValue obj, uint16_t atom, MJSValue val) {
    if (!MJS_IS_PTR(obj)) return;
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
    if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) return;
    MJSObject *o = (MJSObject*)h;
    MJSSlot *slots = o->slots;
    if (!slots) return;
    uint16_t mask = o->capacity - 1;
    uint16_t i = (uint16_t)(atom & mask);
    for (uint16_t probe = 0; probe < o->capacity; probe++) {
        uint16_t idx = (uint16_t)((i + probe) & mask);
        if (slots[idx].atom == 0 || slots[idx].atom == 0xFFFFu) {
            slots[idx].atom = atom;
            slots[idx].val = val;
            o->count++;
            return;
        }
        if (slots[idx].atom == atom) {
            /* T51: Check for accessor (get/set) */
            MJSValue cur = slots[idx].val;
            if (MJS_IS_PTR(cur)) {
                MJSHeader *vh = (MJSHeader*)MJS_GET_PTR(cur);
                if (MJS_HDR_TYPE(vh) == MJS_T_ACCESSOR) {
                    MJSAccessor *acc = (MJSAccessor*)vh;
                    if (MJS_IS_PTR(acc->setter)) {
                        /* Call setter with this=obj, arg=val */
                        MJSValue args[1] = { val };
                        mjs_call_value(ctx, acc->setter, 1, args);
                    }
                    return;  /* don't overwrite accessor */
                }
            }
            slots[idx].val = val;
            return;
        }
    }
    /* T51: Table full — try resizing, then retry. */
    mjs_obj_resize(ctx, o);
    slots = o->slots;
    mask = o->capacity - 1;
    i = (uint16_t)(atom & mask);
    for (uint16_t probe = 0; probe < o->capacity; probe++) {
        uint16_t idx = (uint16_t)((i + probe) & mask);
        if (slots[idx].atom == 0 || slots[idx].atom == 0xFFFFu) {
            slots[idx].atom = atom;
            slots[idx].val = val;
            o->count++;
            return;
        }
    }
    /* Still full after resize — shouldn't happen, but drop to be safe. */
}

/* T51/GC-6: Public wrapper — suppresses compaction around the
 * hash-table probe + potential setter call + potential resize.
 * See mjs_obj_get() above for rationale. */
static void mjs_obj_set(MJSContext *ctx, MJSValue obj, uint16_t atom, MJSValue val) {
    bool prev_no_compact = mjs_no_compact;
    mjs_no_compact = true;
    mjs_obj_set_impl(ctx, obj, atom, val);
    mjs_no_compact = prev_no_compact;
}

MJSValue mjs_get_property(MJSContext *ctx, MJSValue obj, const char *key) {
    uint16_t a = mjs_atom_find(ctx, key, strlen(key));
    if (a == 0) return MJS_UNDEF_V;
    return mjs_obj_get(ctx, obj, a);
}

void mjs_set_property(MJSContext *ctx, MJSValue obj, const char *key, MJSValue val) {
    /* T51-fix: Use mjs_atom_intern (find or CREATE) instead of mjs_atom_find.
     * This fixes JSON.parse silently dropping properties whose keys don't
     * appear as identifiers in the JS source (e.g., "CPU Core #1" only
     * appears as a JSON string value, never as a JS identifier, so it was
     * never in the bytecode's atom table → mjs_atom_find returned 0 →
     * property was dropped).  Now the atom is created on the fly. */
    uint16_t a = mjs_atom_intern(ctx, key, strlen(key));
    if (a == 0) return;  /* atom table full (255+ atoms) */
    mjs_obj_set(ctx, obj, a, val);
}

MJSValue mjs_get_index(MJSContext *ctx, MJSValue arr, int idx) {
    (void)ctx;
    if (!MJS_IS_PTR(arr)) return MJS_UNDEF_V;
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(arr);
    if (MJS_HDR_TYPE(h) != MJS_T_ARRAY) return MJS_UNDEF_V;
    MJSArray *a = (MJSArray*)h;
    if (idx < 0 || idx >= a->length) return MJS_UNDEF_V;
    if (a->elem_size == 1) {
        uint8_t *items = (uint8_t*)(a + 1);
        return mjs_int((int32_t)items[idx]);
    } else if (a->elem_size == 2) {
        uint16_t *items = (uint16_t*)(a + 1);
        return mjs_int((int32_t)items[idx]);
    } else {
        MJSValue *items = (MJSValue*)(a + 1);
        return items[idx];
    }
}

void mjs_set_index(MJSContext *ctx, MJSValue arr, int idx, MJSValue val) {
    /* T51-fix/BUG-8: clear the grow side-channel flag at entry so a
     * stale _array_grown set by an earlier native call (e.g. C-side
     * arr.push that triggered a grow) doesn't leak into this call's
     * OP_STORE_INDEX and cause a STALE _grown_array to be written
     * back to a wrong slot. */
    ctx->_array_grown = 0;
    /* T51-fix/GC-6: suppress compaction for the entire grow path —
     * the C-local `a`/`na`/`h` pointers below must stay valid across
     * any mjs_alloc that triggers GC.  Marking still runs (so fresh
     * garbage gets reclaimed on the next cycle), but no block moves
     * under our hands.  Matches the pattern in mjs_new_bound_method
     * and mjs_obj_get/set. */
    bool prev_no_compact = mjs_no_compact;
    mjs_no_compact = true;
    if (!MJS_IS_PTR(arr)) { mjs_no_compact = prev_no_compact; return; }
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(arr);
    if (MJS_HDR_TYPE(h) != MJS_T_ARRAY) { mjs_no_compact = prev_no_compact; return; }
    MJSArray *a = (MJSArray*)h;
    if (idx < 0) { mjs_no_compact = prev_no_compact; return; }
    if (idx >= 65535) { mjs_no_compact = prev_no_compact; return; }

    /* T51-fix: Grow the array if idx exceeds capacity.
     * Also: if the array is packed (u8/u16) but val is not a
     * representable int, convert to MJSValue[] array first. */
    int need_grow = (idx >= a->capacity);
    int need_convert = 0;
    if (a->elem_size != 0) {
        if (!MJS_IS_INT(val)) {
            need_convert = 1;
        } else {
            int32_t raw = MJS_GET_INT(val);
            int32_t iv = raw >> 8;  /* integer value */
            if (raw & 0xFF) { need_convert = 1; }  /* fractional */
            else if (a->elem_size == 1 && (iv < 0 || iv > 255)) need_convert = 1;
            else if (a->elem_size == 2 && (iv < 0 || iv > 65535)) need_convert = 1;
        }
    }

    if (need_convert || need_grow) {
        /* Allocate a new MJSValue[] array with enough capacity. */
        uint16_t new_cap = a->capacity;
        if (new_cap == 0) new_cap = 4;
        while (new_cap <= (uint16_t)idx) new_cap <<= 1;
        if (new_cap > 65535) new_cap = 65535;
        uint32_t new_size = sizeof(MJSArray) + (uint32_t)new_cap * sizeof(MJSValue);
        MJSArray *na = (MJSArray*)mjs_alloc(ctx, new_size);
        if (!na) { mjs_no_compact = prev_no_compact; return; }  /* OOM — silently fail */
        /* T51-CRITICAL FIX: Save the header that mjs_alloc set up (with the
         * CORRECT size for the new block), then copy ONLY the mark bit from
         * the old header.  Previously, `na->hdr = a->hdr` copied the OLD
         * header including the OLD size — so a cap=8 array (48 bytes) had
         * its header say size=32 (from the old cap=4 array).  GC sweep
         * read the wrong size, advanced by 32 instead of 48, and read
         * garbage inside the array as a new block header → heap corruption
         * → "OBJECT@... sz=288" in sweep log → crash. */
        MJSHeader alloc_hdr = na->hdr;  /* save mjs_alloc's correct header */
        na->hdr = a->hdr;              /* copy type/mark/next from old */
        na->hdr.size8 = alloc_hdr.size8;  /* restore correct size */
        if (alloc_hdr.size8 == MJS_HEADER_LARGE) {
            /* Large block — restore the extended size field too.
             * T51-fix/BUG-5: previously `uint16_t *new_sz = (uint16_t*)(na + 1)`
             * advanced by sizeof(MJSArray) = 16 bytes (because na is
             * MJSArray*), but the LARGE size field lives at offset 4
             * (right after the 4-byte MJSHeader).  This wrote 2 bytes of
             * C-stack garbage into items[0..1], corrupting array element
             * 0 on every grow to >2040 bytes.  Use (MJSHeader*)na + 1
             * to advance by exactly sizeof(MJSHeader) = 4 bytes. */
            uint16_t *new_sz = (uint16_t*)((MJSHeader*)na + 1);
            uint16_t *alloc_sz = (uint16_t*)((MJSHeader*)&alloc_hdr + 1);
            *new_sz = *alloc_sz;
        }
        MJS_HDR_SET_TYPE(&(na->hdr), MJS_T_ARRAY);
        MJS_HDR_SET_MARK(&(na->hdr), 0);  /* clear mark — new block is unmarked */
        na->capacity = new_cap;
        na->length = a->length;
        na->elem_size = 0;  /* always MJSValue[] after grow/convert */
        MJSValue *new_items = (MJSValue*)(na + 1);
        /* Copy old elements (converting to MJSValue if needed). */
        if (a->elem_size == 0) {
            MJSValue *old_items = (MJSValue*)(a + 1);
            for (int i = 0; i < a->length; i++) new_items[i] = old_items[i];
        } else if (a->elem_size == 1) {
            uint8_t *old_items = (uint8_t*)(a + 1);
            for (int i = 0; i < a->length; i++) new_items[i] = mjs_int((int32_t)old_items[i]);
        } else {
            uint16_t *old_items = (uint16_t*)(a + 1);
            for (int i = 0; i < a->length; i++) new_items[i] = mjs_int((int32_t)old_items[i]);
        }
        /* Fill gap [length, idx) with UNDEF. */
        for (int i = a->length; i < idx; i++) new_items[i] = MJS_UNDEF_V;
        /* Fill [idx+1, new_cap) with UNDEF (rest of capacity). */
        for (int i = (idx > a->length ? idx + 1 : a->length); i < new_cap; i++) new_items[i] = MJS_UNDEF_V;
        /* Update length. */
        if (idx >= a->length) na->length = (uint16_t)(idx + 1);
        /* Store the value. */
        new_items[idx] = val;
        /* T51-fix: signal OP_STORE_INDEX that the array grew.
         * OP_STORE_INDEX reads ctx->_grown_array and writes it back
         * to the global/local slot that holds the array reference.
         * Without this, the new (bigger) array block would be
         * unreachable and the old (too-small) block would still be
         * used for subsequent reads. */
        ctx->_grown_array = (MJSValue)((uintptr_t)na | TAG_PTR);
        ctx->_array_grown = 1;
        mjs_no_compact = prev_no_compact;
        return;
    }

    /* T51: Fill gap with UNDEF/0 when extending beyond current length. */
    if (idx > a->length) {
        if (a->elem_size == 0) {
            MJSValue *items = (MJSValue*)(a + 1);
            for (int i = a->length; i < idx && i < a->capacity; i++)
                items[i] = MJS_UNDEF_V;
        } else if (a->elem_size == 1) {
            uint8_t *items = (uint8_t*)(a + 1);
            memset(items + a->length, 0, idx - a->length);
        } else {
            uint16_t *items = (uint16_t*)(a + 1);
            for (int i = a->length; i < idx; i++) items[i] = 0;
        }
    }
    if (a->elem_size == 1) {
        int32_t v = mjs_to_int(ctx, val);
        if (v < 0 || v > 255) { mjs_no_compact = prev_no_compact; return; }
        uint8_t *items = (uint8_t*)(a + 1);
        items[idx] = (uint8_t)v;
    } else if (a->elem_size == 2) {
        int32_t v = mjs_to_int(ctx, val);
        if (v < 0 || v > 65535) { mjs_no_compact = prev_no_compact; return; }
        uint16_t *items = (uint16_t*)(a + 1);
        items[idx] = (uint16_t)v;
    } else {
        MJSValue *items = (MJSValue*)(a + 1);
        items[idx] = val;
    }
    if (idx >= a->length) a->length = (uint16_t)(idx + 1);
    mjs_no_compact = prev_no_compact;
}

/* ============================================================
 * Global variable storage
 * ============================================================ */

/* T37: hash table for O(1) global lookup.  Uses atom id as hash key. */
static void mjs_global_hash_add(MJSContext *ctx, uint8_t atom_id, uint8_t global_idx) {
    uint16_t mask = MJS_GLOBAL_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(atom_id & mask);
    for (uint16_t probe = 0; probe < MJS_GLOBAL_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        if (ctx->global_hash[slot] == 0) {
            ctx->global_hash[slot] = (uint8_t)(global_idx + 1);  /* 1-based */
            return;
        }
    }
}

void mjs_register_global(MJSContext *ctx, const char *name, MJSCFunction fn) {
    if (ctx->global_count >= MJS_MAX_GLOBALS) return;
    uint16_t a = mjs_atom_find(ctx, name, strlen(name));
    if (a == 0) return;  /* atom must exist in bytecode */
    /* Check if already registered (hash lookup). */
    uint16_t mask = MJS_GLOBAL_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(a & mask);
    for (uint16_t probe = 0; probe < MJS_GLOBAL_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        uint8_t gid = ctx->global_hash[slot];
        if (gid == 0) break;
        uint16_t gi = gid - 1;
        if (ctx->global_atoms[gi] == a) {
            ctx->global_vals[gi] = mjs_new_cfunction(ctx, fn, name);
            return;
        }
    }
    /* Add new. */
    uint16_t gi = ctx->global_count;
    ctx->global_atoms[gi] = a;
    ctx->global_vals[gi] = mjs_new_cfunction(ctx, fn, name);
    ctx->global_count++;
    mjs_global_hash_add(ctx, (uint8_t)a, (uint8_t)gi);
}

void mjs_set_global_value(MJSContext *ctx, const char *name, MJSValue val) {
    if (ctx->global_count >= MJS_MAX_GLOBALS) return;
    uint16_t a = mjs_atom_find(ctx, name, strlen(name));
    if (a == 0) return;
    /* Check if exists. */
    uint16_t mask = MJS_GLOBAL_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(a & mask);
    for (uint16_t probe = 0; probe < MJS_GLOBAL_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        uint8_t gid = ctx->global_hash[slot];
        if (gid == 0) break;
        uint16_t gi = gid - 1;
        if (ctx->global_atoms[gi] == a) {
            ctx->global_vals[gi] = val;
            return;
        }
    }
    /* Add new. */
    uint16_t gi = ctx->global_count;
    ctx->global_atoms[gi] = a;
    ctx->global_vals[gi] = val;
    ctx->global_count++;
    mjs_global_hash_add(ctx, (uint8_t)a, (uint8_t)gi);
}

static MJSValue mjs_global_get(MJSContext *ctx, uint16_t a) {
    /* T37: hash table lookup. */
    uint16_t mask = MJS_GLOBAL_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(a & mask);
    for (uint16_t probe = 0; probe < MJS_GLOBAL_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        uint8_t gid = ctx->global_hash[slot];
        if (gid == 0) return MJS_UNDEF_V;  /* empty — not found */
        uint16_t gi = gid - 1;
        if (ctx->global_atoms[gi] == a) return ctx->global_vals[gi];
    }
    return MJS_UNDEF_V;
}

static void mjs_global_set(MJSContext *ctx, uint16_t a, MJSValue v) {
    /* Check if already exists (hash lookup). */
    uint16_t mask = MJS_GLOBAL_HASH_SIZE - 1;
    uint16_t idx = (uint16_t)(a & mask);
    for (uint16_t probe = 0; probe < MJS_GLOBAL_HASH_SIZE; probe++) {
        uint16_t slot = (uint16_t)((idx + probe) & mask);
        uint8_t gid = ctx->global_hash[slot];
        if (gid == 0) break;  /* not found */
        uint16_t gi = gid - 1;
        if (ctx->global_atoms[gi] == a) {
            ctx->global_vals[gi] = v;
            return;
        }
    }
    /* Add new global. */
    if (ctx->global_count < MJS_MAX_GLOBALS) {
        uint16_t gi = ctx->global_count;
        ctx->global_atoms[gi] = a;
        ctx->global_vals[gi] = v;
        ctx->global_count++;
        mjs_global_hash_add(ctx, (uint8_t)a, (uint8_t)gi);
    }
}

/* ============================================================
 * Lifecycle
 * ============================================================ */

MJSContext *mjs_init(void *mem, size_t mem_size) {
    if (!mem) return NULL;
    if (mem_size < 4096) return NULL;
    /* T51-fix: require 8-byte alignment.  The GC freelist uses
     * next8 = offset/8 to compress 32-bit offsets into uint16_t.
     * This only works if all block offsets are multiples of 8.
     * If mem is only 4-aligned, offsets from buf_start have
     * remainder 4, and next8 truncation corrupts the freelist —
     * causing "GC doesn't free memory" and heap corruption. */
    if (((uintptr_t)mem & 7u) != 0) return NULL;

    MJSContext *ctx = (MJSContext*)mem;
    memset(ctx, 0, sizeof(*ctx));
    ctx->buf_start = (uint8_t*)mem;
    ctx->buf_end   = (uint8_t*)mem + mem_size;
    ctx->buf_size  = mem_size;

    /* Heap region: starts right after the context header, grows up.
     * Value stack grows down from buf_end.  We reserve 1/4 of the
     * buffer for the stack. */
    uint8_t *heap_start = (uint8_t*)mem + sizeof(MJSContext);
    heap_start = (uint8_t*)(((uintptr_t)heap_start + 7u) & ~(uintptr_t)7u);
    ctx->heap_ptr = heap_start;
    ctx->heap_start = heap_start;

    uint32_t stack_bytes = (uint32_t)(mem_size / 4);
    if (stack_bytes > MJS_STACK_MAX * sizeof(MJSValue)) {
        stack_bytes = MJS_STACK_MAX * sizeof(MJSValue);
    }
    ctx->heap_limit   = ctx->buf_end - stack_bytes;
    ctx->sp           = (MJSValue*)ctx->buf_end;
    ctx->stack_bottom = (MJSValue*)ctx->heap_limit;

    ctx->local_base  = 0;
    ctx->frame_depth = 0;
    ctx->try_depth   = 0;  /* T51: init try/catch stack */
    ctx->free_list   = 0;
    ctx->has_error   = 0;
    ctx->err_buf[0]  = '\0';
    ctx->_gc_marked = 0;
    ctx->_gc_swept = 0;
    ctx->_gc_bytecode = 0;
    ctx->_grown_array = 0;
    ctx->_array_grown = 0;
    ctx->_new_target = MJS_UNDEF_V;
    ctx->_this = MJS_UNDEF_V;

    return ctx;
}

void mjs_destroy(MJSContext *ctx) {
    if (!ctx) return;
    /* Caller owns the buffer — just zero the header for safety. */
    memset(ctx, 0, sizeof(*ctx));
}

size_t mjs_free_mem(MJSContext *ctx) {
    /* T50: Returns total free memory = bump-pointer space + freelist blocks.
     * Previously only returned bump-pointer space (heap_limit - heap_ptr),
     * which underreported free memory when GC had freed blocks to the
     * freelist.  This caused "js heap: 4" even when several KB of
     * freelist blocks were available for reuse. */
    if (!ctx) return 0;
    size_t bump_free = (size_t)(ctx->heap_limit - ctx->heap_ptr);
    size_t freelist_free = 0;
    uint32_t off = ctx->free_list;
    while (off) {
        MJSHeader *h = (MJSHeader*)(ctx->buf_start + off);
        freelist_free += mjs_hdr_size(h);
        off = mjs_hdr_next(h);
    }
    return bump_free + freelist_free;
}

size_t mjs_total_mem(MJSContext *ctx) {
    return ctx ? ctx->buf_size : 0;
}

/* ============================================================
 * Bytecode loader
 * ============================================================
 *
 * Format (little-endian):
 *   off  size  field
 *   0    4     magic "MJSB"
 *   4    1     version (1)
 *   5    1     flags (reserved, 0)
 *   6    2     atom_count
 *   8    var   atoms: for each atom: u16 len + len+1 bytes (NUL-terminated)
 *   ...  2     const_count
 *   ...  var   consts: for each const: u8 type + payload
 *                type 0 = int30  -> 4 bytes (LE, value = MAKE_INT(v))
 *                type 1 = string -> u16 len + len+1 bytes
 *   ...  2     func_count
 *   ...  var   funcs: for each func: u8 argc + u8 nlocals + u16 pc + u16 body_size
 *   ...  var   bytecode (top-level + function bodies, concatenated)
 *
 * The bytecode buffer is COPIED into the heap region so the caller
 * can free the original after mjs_load_bytecode returns.  This means
 * we need enough free heap to hold the bytecode blob.
 */
int mjs_load_bytecode(MJSContext *ctx, const uint8_t *buf, size_t size) {
    if (!ctx || !buf || size < 8) {
        if (ctx) {
            ctx->has_error = 1;
            strncpy(ctx->err_buf, "bytecode too small", MJS_ERR_SIZE - 1);
        }
        return 1;
    }
    /* T50: Allocate space for the blob AND a separate MJSHeader.
     * Previously we allocated exactly 'size' bytes and memcpy'd the
     * blob over the MJSHeader that mjs_alloc set up.  This left the
     * header's type field = 'M' (0x4D, from "MJSB" magic), which made
     * the GC think the blob was a collectable JS object.  The sweep
     * would then either free it (crash) or walk past it incorrectly,
     * preventing any OTHER unreachable objects from being freed.
     *
     * Fix: allocate size + sizeof(MJSHeader), place the MJSHeader at
     * the start (type=0, so GC skips it), and the blob content after. */
    uint32_t hdr_size = MJS_ALIGN8(sizeof(MJSHeader));
    uint32_t alloc_size = hdr_size + MJS_ALIGN8((uint32_t)size);
    if (alloc_size < 16) alloc_size = 16;
    /* T51-fix: Suppress compaction during the ENTIRE load_bytecode —
     * both the initial alloc AND the inplace parse (which creates const
     * string objects that trigger more allocs).  Compaction would move
     * the bytecode blob, invalidating atoms/consts pointers that point
     * into it. */
    mjs_no_compact = true;
    uint8_t *block = (uint8_t*)mjs_alloc(ctx, alloc_size);
    #ifdef MJS_DEBUG_CONCAT
    fprintf(stderr, "[load_bytecode] block=%p alloc_size=%d hdr_size=%d blob=%p\n",
            (void*)block, (int)alloc_size, (int)hdr_size, (void*)(block + hdr_size));
    #endif
    if (!block) {
        mjs_no_compact = false;
        ctx->has_error = 1;
        strncpy(ctx->err_buf, "OOM loading bytecode", MJS_ERR_SIZE - 1);
        return 1;
    }
    /* mjs_alloc already set up the header at 'block'.  Just verify
     * type is 0 (GC skips type==0 blocks during sweep). */
    MJSHeader *h = (MJSHeader*)block;
    MJS_HDR_SET_TYPE(h, 0);       /* raw — GC must not collect this */
    MJS_HDR_SET_MARK(h, 0);
    mjs_hdr_set_size(h, (uint16_t)alloc_size);
    mjs_hdr_set_next(h, 0);
    /* Blob content starts after the header. */
    uint8_t *blob = block + hdr_size;
    memcpy(blob, buf, size);
    int r = mjs_load_bytecode_inplace(ctx, blob, size);
    mjs_no_compact = false;
    return r;
}

/* Parse a bytecode blob that's already in memory (no copy). */
int mjs_load_bytecode_inplace(MJSContext *ctx, uint8_t *buf, size_t size) {
    #define TRUNC_RET() do { \
        ctx->has_error = 1; \
        strncpy(ctx->err_buf, "truncated bytecode", MJS_ERR_SIZE - 1); \
        ctx->err_buf[MJS_ERR_SIZE - 1] = '\0'; \
        return 1; \
    } while (0)

    if (!ctx || !buf || size < 8) {
        if (ctx) {
            ctx->has_error = 1;
            strncpy(ctx->err_buf, "bytecode too small", MJS_ERR_SIZE - 1);
        }
        return 1;
    }
    /* Verify magic. */
    if (buf[0] != 'M' || buf[1] != 'J' || buf[2] != 'S' || buf[3] != 'B') {
        ctx->has_error = 1;
        strncpy(ctx->err_buf, "bad magic (not MJSB)", MJS_ERR_SIZE - 1);
        return 1;
    }
    uint8_t version = buf[4];
    if (version != 1) {
        ctx->has_error = 1;
        snprintf(ctx->err_buf, MJS_ERR_SIZE, "unsupported version %u", version);
        return 1;
    }

    /* Use buf directly — no copy.  const strings will point into this buffer. */
    uint8_t *blob = buf;

    /* Parse header. */
    size_t pos = 6;
    uint16_t atom_count = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
    if (atom_count > 256) {
        ctx->has_error = 1;
        snprintf(ctx->err_buf, MJS_ERR_SIZE, "too many atoms %u", atom_count);
        return 1;
    }
    ctx->atom_count = atom_count;
    for (uint16_t i = 0; i < atom_count; i++) {
        if (pos + 2 > size) { TRUNC_RET(); }
        uint16_t alen = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
        if (pos + alen + 1 > size) { TRUNC_RET(); }
        ctx->atoms[i] = (const char*)(blob + pos);
        pos += alen + 1;  /* skip len + NUL */
    }

    if (pos + 2 > size) { TRUNC_RET(); }
    uint16_t const_count = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
    if (const_count > 256) {
        ctx->has_error = 1;
        snprintf(ctx->err_buf, MJS_ERR_SIZE, "too many consts %u", const_count);
        return 1;
    }
    ctx->const_count = const_count;
    for (uint16_t i = 0; i < const_count; i++) {
        if (pos + 1 > size) { TRUNC_RET(); }
        uint8_t type = blob[pos++];
        if (type == 0) {  /* int30 */
            if (pos + 4 > size) { TRUNC_RET(); }
            uint32_t v = (uint32_t)blob[pos] | ((uint32_t)blob[pos+1] << 8) |
                         ((uint32_t)blob[pos+2] << 16) | ((uint32_t)blob[pos+3] << 24);
            pos += 4;
            ctx->consts[i] = (MJSValue)v;  /* already encoded as MAKE_INT */
        } else if (type == 1) {  /* string */
            if (pos + 2 > size) { TRUNC_RET(); }
            uint16_t slen = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
            if (pos + slen + 1 > size) { TRUNC_RET(); }
            /* T36: create a const string pointing into the blob — no data copy.
             * The blob is in heap (or PROGMEM for boot script), so the pointer
             * is valid as long as the blob is alive (which is the lifetime of
             * the context).  Saves len+1 bytes per const string on the heap. */
            ctx->consts[i] = mjs_new_const_string(ctx, (const char*)(blob + pos), slen);
            pos += slen + 1;
        } else {
            ctx->has_error = 1;
            snprintf(ctx->err_buf, MJS_ERR_SIZE, "bad const type %u", type);
            return 1;
        }
    }

    if (pos + 2 > size) { TRUNC_RET(); }
    uint16_t func_count = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
    if (func_count > 64) {
        ctx->has_error = 1;
        snprintf(ctx->err_buf, MJS_ERR_SIZE, "too many funcs %u", func_count);
        return 1;
    }
    ctx->func_count = func_count;
    for (uint16_t i = 0; i < func_count; i++) {
        if (pos + 6 > size) { TRUNC_RET(); }
        ctx->funcs[i].argc    = blob[pos++];
        ctx->funcs[i].nlocals = blob[pos++];
        ctx->funcs[i].pc      = (uint16_t)(blob[pos] | (blob[pos+1] << 8)); pos += 2;
        pos += 2;  /* body_size — unused at runtime, just for validation */
    }

    /* The rest is bytecode. */
    ctx->bc_start = blob + pos;
    ctx->bc_size  = (uint16_t)(size - pos);
    ctx->bc_end   = blob + size;

    /* T37: build atom hash table for O(1) lookup. */
    mjs_atom_hash_build(ctx);

    ctx->has_error = 0;
    #undef TRUNC_RET
    return 0;
}

/* ============================================================
 * VM main loop
 * ============================================================ */

static int mjs_str_eq(MJSContext *ctx, MJSValue a, MJSValue b) {
    if (a == b) return 1;
    if (!MJS_IS_PTR(a) || !MJS_IS_PTR(b)) return 0;
    MJSHeader *ha = (MJSHeader*)MJS_GET_PTR(a);
    MJSHeader *hb = (MJSHeader*)MJS_GET_PTR(b);
    if (MJS_HDR_TYPE(ha) != MJS_T_STRING || MJS_HDR_TYPE(hb) != MJS_T_STRING) return 0;
    MJSString *sa = (MJSString*)ha, *sb = (MJSString*)hb;
    if (sa->len != sb->len) return 0;
    return memcmp(sa->data, sb->data, sa->len) == 0;
}

MJSValue mjs_concat(MJSContext *ctx, MJSValue a, MJSValue b) {
    /* T51-fix: Suppress compaction during concat.
     * mjs_concat calls mjs_alloc (for the result string), which may trigger
     * compaction.  Compaction moves heap blocks and updates MJSValue fields
     * in globals/locals/stack.  But the `a` and `b` parameters are C locals
     * (passed by value) that compaction does NOT update.  If compaction
     * moves the string blocks that `a` and `b` point to, the sa/sb pointers
     * become dangling → use-after-free → corrupted string data.
     *
     * The OP_ADD handler keeps a and b on the stack as GC roots, but
     * compaction only updates the STACK values — the C locals `a` and `b`
     * in mjs_concat's frame are still stale.  By suppressing compaction,
     * mjs_alloc will use the bump allocator (or free list without compacting).
     * GC (mark-and-sweep) still runs — only compaction is suppressed. */
    bool prev_no_compact = mjs_no_compact;
    mjs_no_compact = true;
    char buf_a[32], buf_b[32];
    const char *sa, *sb;
    size_t la, lb;
    if (MJS_IS_INT(a)) {
        int32_t raw = MJS_GET_INT(a);
        bool neg = raw < 0;
        if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
        int32_t ip = raw >> 8;
        int32_t fp = (raw & 0xFF) * 100 / 256;
        if (fp == 0) snprintf(buf_a, sizeof(buf_a), "%s%d", neg?"-":"", (int)ip);
        else snprintf(buf_a, sizeof(buf_a), "%s%d.%02d", neg?"-":"", (int)ip, (int)fp);
        sa = buf_a; la = strlen(sa);
    } else if (mjs_is_string(ctx, a)) sa = mjs_to_cstr(ctx, a, &la);
    else if (a == MJS_TRUE_V) { sa = "true"; la = 4; }
    else if (a == MJS_FALSE_V) { sa = "false"; la = 5; }
    else if (a == MJS_NULL_V) { sa = "null"; la = 4; }
    else if (a == MJS_NAN_V) { sa = "NaN"; la = 3; }
    else { sa = "undefined"; la = 9; }

    if (MJS_IS_INT(b)) {
        int32_t raw = MJS_GET_INT(b);
        bool neg = raw < 0;
        if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
        int32_t ip = raw >> 8;
        int32_t fp = (raw & 0xFF) * 100 / 256;
        if (fp == 0) snprintf(buf_b, sizeof(buf_b), "%s%d", neg?"-":"", (int)ip);
        else snprintf(buf_b, sizeof(buf_b), "%s%d.%02d", neg?"-":"", (int)ip, (int)fp);
        sb = buf_b; lb = strlen(sb);
    } else if (mjs_is_string(ctx, b)) sb = mjs_to_cstr(ctx, b, &lb);
    else if (b == MJS_TRUE_V) { sb = "true"; lb = 4; }
    else if (b == MJS_FALSE_V) { sb = "false"; lb = 5; }
    else if (b == MJS_NULL_V) { sb = "null"; lb = 4; }
    else if (b == MJS_NAN_V) { sb = "NaN"; lb = 3; }
    else { sb = "undefined"; lb = 9; }

    /* T51-fix: Allocate result string directly — no 256-byte static buffer.
     * Old code used `static char sbuf[256]` which:
     * 1. Limited concatenation results to 255 bytes (silently returned NULL)
     * 2. Was not reentrant (static buffer shared across recursive calls)
     * 3. Caused body to become NULL/undefined after ~45 requests when
     *    intermediate concatenations exceeded 256 bytes
     *
     * New approach: allocate MJSString of exact size, copy both parts
     * directly into it.  No temp buffer, no size limit (except heap). */
    size_t total = la + lb;
    if (total > 65535) total = 65535;  /* MJSString.len is uint16_t */

    /* T51-test: Debug — check if sa/sb are still valid before alloc */
    #ifdef MJS_DEBUG_CONCAT
    fprintf(stderr, "[concat] la=%d lb=%d total=%d sa='%c' sb='%c' free=%d\n",
            (int)la, (int)lb, (int)total,
            la > 0 ? sa[0] : '?',
            lb > 0 ? sb[0] : '?',
            (int)mjs_free_mem(ctx));
    #endif

    MJSValue result = mjs_new_string(ctx, NULL, total);
    if (result == MJS_NULL_V) {
        /* Allocation failed — could be OOM or GC collected something. */
        #ifdef MJS_DEBUG_CONCAT
        fprintf(stderr, "[concat] mjs_new_string returned NULL! free=%d\n",
                (int)mjs_free_mem(ctx));
        #endif
        return MJS_NULL_V;
    }
    if (MJS_IS_PTR(result)) {
        MJSString *str = (MJSString*)MJS_GET_PTR(result);
        /* mjs_new_string with s=NULL and len=total allocates but doesn't copy.
         * We need to copy the data ourselves. */
        if (sa && la > 0) memcpy((char*)str->data, sa, la);
        if (sb && lb > 0) memcpy((char*)str->data + la, sb, lb);
        ((char*)str->data)[total] = '\0';
        str->hash = mjs_hash(str->data, total);
    }
    mjs_no_compact = prev_no_compact;  /* T51-fix: restore compaction */
    return result;
}

/* T46: build a call stack trace for runtime errors.
 * Shows the last few function names (if available) + pc offsets. */
static void mjs_set_err(MJSContext *ctx, const char *msg, uint16_t pc) {
    if (!ctx->has_error) {
        ctx->has_error = 1;
        ctx->err_pc = pc;
        /* Build error message with call stack. */
        int len = snprintf(ctx->err_buf, MJS_ERR_SIZE, "%s (pc=%u", msg, (unsigned)pc);
        /* Add call stack frames. */
        for (int i = ctx->frame_depth - 1; i >= 0 && len < MJS_ERR_SIZE - 20; i--) {
            uint16_t fpc = ctx->frames[i].pc;
            len += snprintf(ctx->err_buf + len, MJS_ERR_SIZE - len,
                           " <- pc=%u", (unsigned)fpc);
        }
        if (len < MJS_ERR_SIZE - 2) {
            ctx->err_buf[len++] = ')';
            ctx->err_buf[len] = '\0';
        }
    }
}

/* T51: Yield callback for cooperative multitasking. */
static mjs_yield_cb_t s_yield_cb = nullptr;
void mjs_set_yield_callback(mjs_yield_cb_t cb) { s_yield_cb = cb; }

int mjs_run(MJSContext *ctx) {
    uint8_t *bc = ctx->bc_start;
    if (!bc) {
        mjs_set_err(ctx, "no bytecode loaded", 0);
        return 1;
    }
    /* Use ctx state as initial values — this allows mjs_call_value()
     * to pre-set pc/frame_depth/local_base for timer callbacks. */
    MJSValue *sp = ctx->sp;
    uint16_t pc = ctx->pc;
    int frame_depth = ctx->frame_depth;
    int local_base = ctx->local_base;
    #if defined(ESP8266) || defined(ESP32)
    uint32_t op_counter = 0;  /* T51: for periodic yield() */
    #endif
    /* T51: Run timeout — 0 means no timeout (infinite loops allowed).
     * Set by .ino before calling mjs_run for HTTP /run (10s timeout).
     * Boot script / button run: 0 (no timeout, games can loop forever). */
    ctx->run_start_ms = millis();

    /* T51: yield callback — called every 1024 opcodes.  If it returns
     * non-zero, mjs_run aborts (cooperative multitasking).  Used by .ino
     * to check for incoming HTTP requests and abort long-running scripts. */

#define PUSH(v) (*--sp = (v))
#define POP()   (*sp++)
#define TOP()   (*sp)
/* T51: ERR macro — if a try handler is active, unwind to it instead
 * of going to done.  The error message (without pc suffix) is pushed
 * as a string onto the stack at the catch_pc. */
#define ERR(msg) do { \
    if (ctx->try_depth > 0) { \
        ctx->try_depth--; \
        pc = ctx->try_stack[ctx->try_depth].catch_pc; \
        frame_depth = ctx->try_stack[ctx->try_depth].frame_depth; \
        local_base = ctx->try_stack[ctx->try_depth].local_base; \
        sp = ctx->try_stack[ctx->try_depth].sp; \
        PUSH(mjs_new_string(ctx, msg, strlen(msg))); \
        ctx->has_error = 0; \
        continue; \
    } \
    mjs_set_err(ctx, msg, pc); \
    goto done; \
} while(0)

    for (;;) {
        if (sp < ctx->stack_bottom) ERR("stack overflow");
        /* T51-fix: Sync ctx->sp BEFORE every opcode dispatch.
         * mjs_alloc() may trigger proactive GC when heap is low.
         * GC's mark phase scans [ctx->sp, buf_end) for roots.
         * If ctx->sp is stale (only updated at CFUNC calls), GC marks
         * popped-but-not-cleared stack values as live roots — keeping
         * unreachable objects alive (the "GC doesn't free after loops"
         * bug).  By syncing here, proactive GC always sees the correct
         * active stack extent.  Cost: one store per opcode — negligible. */
        ctx->sp = sp;
        uint8_t op = bc[pc++];

        /* T51: Yield to ESP8266 WiFi stack every 1024 opcodes to
         * prevent Soft WDT reset during long loops.  yield() is defined
         * as a macro stub on non-Arduino platforms.
         * Also check run timeout and yield callback for cooperative abort. */
        #if defined(ESP8266) || defined(ESP32)
        if ((++op_counter & 1023) == 0) {
            yield();
            if (ctx->run_timeout_ms > 0 &&
                millis() - ctx->run_start_ms > ctx->run_timeout_ms) {
                mjs_set_err(ctx, "script timeout", pc);
                goto done;
            }
            if (s_yield_cb && s_yield_cb()) {
                mjs_set_err(ctx, "aborted by new request", pc);
                goto done;
            }
        }
        #endif

        switch (op) {
            case OP_NOP: break;
            case OP_UNDEF: PUSH(MJS_UNDEF_V); break;
            case OP_NULL:  PUSH(MJS_NULL_V);  break;
            case OP_TRUE:  PUSH(MJS_TRUE_V);  break;
            case OP_FALSE: PUSH(MJS_FALSE_V); break;

            case OP_INT8:  PUSH(MJS_MAKE_INT((int32_t)(uint8_t)bc[pc++] << 8)); break;  /* T51-fix: uint8_t — was int8_t, broke values 128-255 (e.g. 200 became -56) */
            case OP_INT16: { int16_t v = (int16_t)(bc[pc] | (bc[pc+1] << 8)); pc += 2;
                             PUSH(MJS_MAKE_INT((int32_t)v << 8)); break; }
            case OP_INT24: { int32_t v = (int32_t)(bc[pc] | (bc[pc+1] << 8) | (bc[pc+2] << 16));
                             if (v & 0x800000) v |= 0xFF000000; pc += 3;
                             PUSH(MJS_MAKE_INT(v << 8)); break; }
            case OP_CONST: { uint8_t i = bc[pc++];
                             if (i >= ctx->const_count) ERR("const OOB");
                             PUSH(ctx->consts[i]); break; }

            case OP_LOAD_LOCAL: { uint8_t s = bc[pc++];
                                  PUSH(ctx->locals[local_base + s]); break; }
            case OP_STORE_LOCAL:{ uint8_t s = bc[pc++];
                                  /* Keep the value on the stack — assignment is an
                                   * expression in JS and the value is the result. */
                                  ctx->locals[local_base + s] = TOP(); break; }
            case OP_LOAD_GLOBAL:{ uint8_t a = bc[pc++]; PUSH(mjs_global_get(ctx, a)); break; }
            case OP_STORE_GLOBAL:{uint8_t a = bc[pc++];
                                  mjs_global_set(ctx, a, TOP()); break; }

            case OP_POP:  sp++; break;
            case OP_DUP:  { MJSValue v = TOP(); PUSH(v); break; }
            case OP_SWAP: { MJSValue t = sp[0]; sp[0] = sp[1]; sp[1] = t; break; }

            case OP_LOAD_PROP: { uint8_t a = bc[pc++];
                                 MJSValue o = POP();
                                 /* T39: array properties — length, push, slice, forEach */
                                 if (MJS_IS_PTR(o)) {
                                     MJSHeader *h = (MJSHeader*)MJS_GET_PTR(o);
                                     if (MJS_HDR_TYPE(h) == MJS_T_ARRAY && a > 0 && a <= ctx->atom_count) {
                                         const char *pname = ctx->atoms[a - 1];
                                         MJSArray *arr = (MJSArray*)h;
                                         if (strcmp(pname, "length") == 0) {
                                             PUSH(mjs_int((int32_t)arr->length)); break;
                                         }
                                         /* Method lookup: check if a global "Array" object
                                          * has a property with this name.  If yes, create
                                          * a bound method with this array as `this`. */
                                         MJSValue array_global = mjs_global_get(ctx, mjs_atom_find(ctx, "Array", 5));
                                         if (MJS_IS_PTR(array_global)) {
                                             MJSHeader *ah = (MJSHeader*)MJS_GET_PTR(array_global);
                                             if (MJS_HDR_TYPE(ah) == MJS_T_OBJECT) {
                                                 MJSValue method = mjs_obj_get(ctx, array_global, a);
                                                 if (MJS_IS_PTR(method)) {
                                                     MJSHeader *mh = (MJSHeader*)MJS_GET_PTR(method);
                                                     if (MJS_HDR_TYPE(mh) == MJS_T_CFUNC) {
                                                         /* Create bound method with this array as first arg */
                                                         PUSH(mjs_new_bound_method(ctx,
                                                             ((MJSCFunc*)mh)->fn, o));
                                                         break;
                                                     }
                                                 }
                                             }
                                         }
                                         PUSH(MJS_UNDEF_V); break;
                                     }
                                     /* T39: string properties — length */
                                     if (MJS_HDR_TYPE(h) == MJS_T_STRING && a > 0 && a <= ctx->atom_count) {
                                         const char *pname = ctx->atoms[a - 1];
                                         MJSString *str = (MJSString*)h;
                                         if (strcmp(pname, "length") == 0) {
                                             PUSH(mjs_int((int32_t)str->len)); break;
                                         }
                                         /* String methods via String.* global */
                                         MJSValue str_global = mjs_global_get(ctx, mjs_atom_find(ctx, "String", 6));
                                         if (MJS_IS_PTR(str_global)) {
                                             MJSHeader *sh = (MJSHeader*)MJS_GET_PTR(str_global);
                                             if (MJS_HDR_TYPE(sh) == MJS_T_OBJECT) {
                                                 MJSValue method = mjs_obj_get(ctx, str_global, a);
                                                 if (MJS_IS_PTR(method)) {
                                                     MJSHeader *mh = (MJSHeader*)MJS_GET_PTR(method);
                                                     if (MJS_HDR_TYPE(mh) == MJS_T_CFUNC) {
                                                         PUSH(mjs_new_bound_method(ctx,
                                                             ((MJSCFunc*)mh)->fn, o));
                                                         break;
                                                     }
                                                 }
                                             }
                                         }
                                         PUSH(MJS_UNDEF_V); break;
                                     }
                                 }
                                 /* T51: __proto__ special property — returns the
                                  * object's prototype (for inheritance chain access). */
                                 if (MJS_IS_PTR(o) && a > 0 && a <= ctx->atom_count) {
                                     const char *pname = ctx->atoms[a - 1];
                                     if (strcmp(pname, "__proto__") == 0) {
                                         MJSValue proto = mjs_get_prototype(ctx, o);
                                         PUSH(proto);
                                         break;
                                     }
                                     /* T51: Function .prototype property — every JS
                                      * function has an auto-created prototype object
                                      * for use with `new`.  Return f->proto. */
                                     MJSHeader *oh = (MJSHeader*)MJS_GET_PTR(o);
                                     if (MJS_HDR_TYPE(oh) == MJS_T_FUNC &&
                                         strcmp(pname, "prototype") == 0) {
                                         MJSFuncObj *f = (MJSFuncObj*)oh;
                                         PUSH(f->proto);
                                         break;
                                     }
                                 }
                                 /* T51: mjs_obj_get may call mjs_call_value (for get/set
                                  * accessors), which changes ctx->sp.  Sync sp. */
                                 ctx->sp = sp;
                                 MJSValue pv = mjs_obj_get(ctx, o, a);
                                 sp = ctx->sp;
                                 PUSH(pv); break; }
            case OP_STORE_PROP:{ uint8_t a = bc[pc++];
                                 /* Stack: [..., obj, val].  Set obj.a = val,
                                  * leave val as the expression result. */
                                 MJSValue v = TOP();
                                 MJSValue o = sp[1];
                                 /* T51: __proto__ special property — set the
                                  * object's prototype (for inheritance chain). */
                                 if (MJS_IS_PTR(o) && a > 0 && a <= ctx->atom_count) {
                                     const char *pname = ctx->atoms[a - 1];
                                     if (strcmp(pname, "__proto__") == 0) {
                                         mjs_set_prototype(ctx, o, v);
                                         sp[1] = v;
                                         sp++;
                                         break;
                                     }
                                     /* T51: Function .prototype setter — when
                                      * code does `Func.prototype = newProto`,
                                      * update f->proto so `new Func()` uses
                                      * the new prototype. */
                                     if (strcmp(pname, "prototype") == 0) {
                                         MJSHeader *oh2 = (MJSHeader*)MJS_GET_PTR(o);
                                         if (MJS_HDR_TYPE(oh2) == MJS_T_FUNC) {
                                             MJSFuncObj *f2 = (MJSFuncObj*)oh2;
                                             f2->proto = v;
                                             sp[1] = v;
                                             sp++;
                                             break;
                                         }
                                     }
                                     /* T51-fix: arr.length = N — set the array's
                                      * length property.  This allows code like:
                                      *   arr.length = arr.length - 1;  // remove last
                                      *   arr.length = 0;               // clear array
                                      * Truncation is safe: elements beyond the new
                                      * length are still in memory but not accessible
                                      * (GC won't free them since they're inside the
                                      * array block, not separate objects).  Setting
                                      * length > capacity is ignored (no grow). */
                                     if (strcmp(pname, "length") == 0) {
                                         MJSHeader *oh3 = (MJSHeader*)MJS_GET_PTR(o);
                                         if (MJS_HDR_TYPE(oh3) == MJS_T_ARRAY) {
                                             MJSArray *arr3 = (MJSArray*)oh3;
                                             /* T51-fix: mjs_to_int already does >> 8
                                              * (extracts integer from fixed24.8).
                                              * Don't shift again! */
                                             int32_t newLen = mjs_to_int(ctx, v);
                                             if (newLen < 0) newLen = 0;
                                             if (newLen > arr3->capacity) newLen = arr3->capacity;
                                             /* Clear elements being removed (so GC
                                              * doesn't mark stale pointers). */
                                             if (arr3->elem_size == 0 && newLen < arr3->length) {
                                                 MJSValue *items = (MJSValue*)(arr3 + 1);
                                                 for (int i = newLen; i < arr3->length; i++) {
                                                     items[i] = MJS_UNDEF_V;
                                                 }
                                             }
                                             arr3->length = (uint16_t)newLen;
                                             sp[1] = v;
                                             sp++;
                                             break;
                                         }
                                     }
                                 }
                                 /* T51: mjs_obj_set may call mjs_call_value (for set
                                  * accessors), which changes ctx->sp.  Sync sp. */
                                 ctx->sp = sp;
                                 mjs_obj_set(ctx, o, a, v);
                                 sp = ctx->sp;
                                 sp[1] = v;  /* overwrite obj with val */
                                 sp++;       /* pop one (the old val slot) */
                                 break; }
            case OP_LOAD_INDEX: {
                MJSValue idx = POP(); MJSValue obj = POP();
                if (MJS_IS_INT(idx) && mjs_is_array(ctx, obj))
                    PUSH(mjs_get_index(ctx, obj, mjs_to_int(ctx, idx)));
                else if (MJS_IS_INT(idx) && mjs_is_string(ctx, obj)) {
                    /* T51-fix: string[int] → single-char string (JS spec).
                     * "Hello"[0] = "H", "Hello"[4] = "o".
                     * Out-of-range → undefined. */
                    size_t slen; const char *s = mjs_to_cstr(ctx, obj, &slen);
                    int32_t i = mjs_to_int(ctx, idx);
                    if (i < 0 || (size_t)i >= slen) PUSH(MJS_UNDEF_V);
                    else PUSH(mjs_new_string(ctx, s + i, 1));
                }
                else if (MJS_IS_INT(idx) && mjs_is_object(ctx, obj)) {
                    /* T51: Object[number] → convert number to string atom
                     * and look up property.  Supports { 0: value } access. */
                    int32_t i = mjs_to_int(ctx, idx);
                    char buf[12];
                    snprintf(buf, sizeof(buf), "%d", (int)i);
                    uint16_t a = mjs_atom_find(ctx, buf, strlen(buf));
                    PUSH(a ? mjs_obj_get(ctx, obj, a) : MJS_UNDEF_V);
                }
                else if (mjs_is_string(ctx, idx)) {
                    size_t l; const char *s = mjs_to_cstr(ctx, idx, &l);
                    uint16_t a = mjs_atom_find(ctx, s, l);
                    PUSH(a ? mjs_obj_get(ctx, obj, a) : MJS_UNDEF_V);
                } else PUSH(MJS_UNDEF_V);
                break;
            }
            case OP_STORE_INDEX: {
                /* Stack: [..., obj, idx, val].  Set obj[idx] = val,
                 * leave val as the expression result. */
                MJSValue v = TOP();
                MJSValue idx = sp[1];
                MJSValue obj = sp[2];
                if (MJS_IS_INT(idx) && mjs_is_array(ctx, obj)) {
                    mjs_set_index(ctx, obj, mjs_to_int(ctx, idx), v);
                    /* T51-fix: if mjs_set_index grew the array (idx >=
                     * capacity), the old array block is now stale.
                     * Write the new array back to the global/local that
                     * holds the reference.  We scan globals + locals for
                     * a match — O(N) but grow is rare. */
                    if (ctx->_array_grown) {
                        MJSValue new_arr = ctx->_grown_array;
                        ctx->_array_grown = 0;
                        /* Search globals. */
                        for (uint16_t i = 0; i < ctx->global_count; i++) {
                            if (ctx->global_vals[i] == obj) {
                                ctx->global_vals[i] = new_arr;
                                break;
                            }
                        }
                        /* Also search locals (for arrays in functions). */
                        for (int i = 0; i < MJS_LOCALS_MAX; i++) {
                            if (ctx->locals[i] == obj) {
                                ctx->locals[i] = new_arr;
                                break;
                            }
                        }
                        /* Update obj on stack (in case it's used later). */
                        sp[2] = new_arr;
                        obj = new_arr;
                    }
                }
                else if (mjs_is_string(ctx, idx)) {
                    size_t l; const char *s = mjs_to_cstr(ctx, idx, &l);
                    uint16_t a = mjs_atom_find(ctx, s, l);
                    if (a) mjs_obj_set(ctx, obj, a, v);
                }
                /* Collapse stack: [obj, idx, val] -> [val] */
                sp[2] = v;
                sp += 2;
                break;
            }
            case OP_NEW_OBJECT: PUSH(mjs_new_object(ctx)); break;
            case OP_NEW_ARRAY: {
                uint8_t n = bc[pc++];
                /* T47: empty arrays [] must be MJSValue arrays (elem_size=0)
                 * because we don't know what types will be pushed later.
                 * Packed u8/u16 only for literals with known elements.
                 * T51: Check raw fixed value — if it has a fractional part
                 * (raw & 0xFF != 0), it can't be packed as int. */
                uint8_t elem_size = 0;  /* 0 = MJSValue */
                if (n > 0) {
                    int all_u8 = 1, all_u16 = 1;
                    for (int i = 0; i < n; i++) {
                        MJSValue v = sp[n - 1 - i];
                        if (!MJS_IS_INT(v)) { all_u8 = 0; all_u16 = 0; break; }
                        int32_t raw = MJS_GET_INT(v);  /* raw fixed24.8 */
                        /* Must be a pure integer (no fractional part) */
                        if (raw & 0xFF) { all_u8 = 0; all_u16 = 0; break; }
                        int32_t iv = raw >> 8;  /* integer value */
                        if (iv < 0 || iv > 255) all_u8 = 0;
                        if (iv < 0 || iv > 65535) all_u16 = 0;
                    }
                    if (all_u8) elem_size = 1;
                    else if (all_u16) elem_size = 2;
                }
                MJSValue arr;
                if (elem_size == 0) {
                    arr = mjs_new_array(ctx, n);
                    for (int i = n - 1; i >= 0; i--) mjs_set_index(ctx, arr, i, POP());
                } else {
                    arr = mjs_new_array_packed(ctx, n, elem_size);
                    /* Pop the n values and store them. */
                    for (int i = n - 1; i >= 0; i--) mjs_set_index(ctx, arr, i, POP());
                }
                PUSH(arr);
                break;
            }

/* T42: overflow protection for fixed24.8.
 * 30-bit payload, 8 bits fractional → 22 bits integer → max ±2,097,151.
 * Values outside this range are clamped to prevent tag corruption. */
#define MJS_FIXED_MAX  ((int32_t)0x1FFFFF << 8)   /* +2097151.0 in raw fixed */
#define MJS_FIXED_MIN  ((int32_t)(-0x200000) << 8) /* -2097152.0 in raw fixed */
#define MJS_CLAMP_FIXED(v) do { \
    if ((v) > MJS_FIXED_MAX) (v) = MJS_FIXED_MAX; \
    else if ((v) < MJS_FIXED_MIN) (v) = MJS_FIXED_MIN; \
} while (0)

            /* fixed24.8 arithmetic — MJS_GET_INT returns raw fixed-point value */
            case OP_ADD: {
                /* T51-fix: Don't POP a and b before mjs_concat — if we pop
                 * them, they become C locals invisible to GC.  When mjs_concat
                 * calls mjs_alloc → proactive GC, the temporary string operands
                 * get collected (use-after-free → corrupted/NULL body).
                 * Instead, peek at sp[0] and sp[1], sync ctx->sp so GC sees
                 * them as stack roots, then pop after concat completes. */
                MJSValue b = sp[0];   /* top of stack */
                MJSValue a = sp[1];   /* second from top */
                if (MJS_IS_INT(a) && MJS_IS_INT(b)) {
                    sp += 2;  /* pop both */
                    int32_t r = MJS_GET_INT(a) + MJS_GET_INT(b);
                    MJS_CLAMP_FIXED(r);
                    PUSH(MJS_MAKE_INT(r));
                } else {
                    /* Keep a and b on stack as GC roots during concat. */
                    ctx->sp = sp;  /* sync so GC sees a, b at sp[0], sp[1] */
                    MJSValue r = mjs_concat(ctx, a, b);
                    sp = ctx->sp;  /* restore (GC may have changed ctx->sp) */
                    sp += 2;       /* pop a and b */
                    PUSH(r);
                }
                break; }
            case OP_SUB: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP());
                           int32_t r = a - b; MJS_CLAMP_FIXED(r);
                           PUSH(MJS_MAKE_INT(r)); break; }
            case OP_MUL: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP());
                           int64_t r = (int64_t)a * b >> 8;
                           int32_t ri = (int32_t)r; MJS_CLAMP_FIXED(ri);
                           PUSH(MJS_MAKE_INT(ri)); break; }
            case OP_DIV: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP());
                           if (b == 0) PUSH(MJS_MAKE_INT(0));
                           else { int64_t r = ((int64_t)a << 8) / b;
                                  int32_t ri = (int32_t)r; MJS_CLAMP_FIXED(ri);
                                  PUSH(MJS_MAKE_INT(ri)); }
                           break; }
            case OP_MOD: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP());
                           if (b == 0) PUSH(MJS_MAKE_INT(0));
                           else PUSH(MJS_MAKE_INT(a % b)); break; }
            case OP_NEG: { int32_t a = MJS_GET_INT(POP()); PUSH(MJS_MAKE_INT(-a)); break; }
            case OP_INC: { int32_t a = MJS_GET_INT(TOP()); TOP() = MJS_MAKE_INT(a + 256); break; }  /* +1.0 in fixed */
            case OP_DEC: { int32_t a = MJS_GET_INT(TOP()); TOP() = MJS_MAKE_INT(a - 256); break; }
            /* T54/JS-10-vm: Unary +x — ToNumber coercion.
             * ECMA §7.1.3 ToNumber rules, scoped to int30 fixed24.8:
             *   - number  → unchanged (preserves fractional bits, unlike mjs_to_int)
             *   - true     → 1.0     (== MJS_MAKE_INT(256))
             *   - false/null/undefined → 0.0
             *   - string  → parsed integer × 256  (fractional literals not supported
             *               by the int30 design — JS-2, intentionally unfixed)
             *   - object/array/function/symbol → 0  (we have no NaN coercion path)
             * NOTE: This is the SCOPED version of JS-1 (unary + only).  The
             * broad JS-1 fix (ToNumber in OP_SUB/MUL/DIV/MOD) is still
             * intentionally not applied — operands there are assumed int. */
            case OP_TO_NUMBER: {
                MJSValue v = POP();
                if (MJS_IS_INT(v)) {
                    PUSH(v);
                } else if (v == MJS_TRUE_V) {
                    PUSH(MJS_MAKE_INT(256));
                } else if (v == MJS_FALSE_V || v == MJS_NULL_V ||
                           v == MJS_UNDEF_V || v == MJS_NAN_V) {
                    PUSH(MJS_MAKE_INT(0));
                } else if (MJS_IS_PTR(v)) {
                    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
                    if (MJS_HDR_TYPE(h) == MJS_T_STRING) {
                        MJSString *s = (MJSString*)h;
                        int32_t n = 0; int sign = 1; size_t i = 0;
                        const char *p = s->data;
                        while (i < s->len && (*p == ' ' || *p == '\t')) { p++; i++; }
                        if (i < s->len && (*p == '+' || *p == '-')) {
                            if (*p == '-') sign = -1;
                            p++; i++;
                        }
                        while (i < s->len && *p >= '0' && *p <= '9') {
                            n = n * 10 + (*p - '0'); p++; i++;
                        }
                        PUSH(MJS_MAKE_INT(sign * (n << 8)));
                    } else {
                        PUSH(MJS_MAKE_INT(0));
                    }
                } else {
                    PUSH(MJS_MAKE_INT(0));
                }
                break;
            }

            /* Bitwise — operate on integer part, return fixed-point */
            case OP_AND:  { int32_t b = MJS_GET_INT(POP()) >> 8, a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((a & b) << 8)); break; }
            case OP_OR:   { int32_t b = MJS_GET_INT(POP()) >> 8, a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((a | b) << 8)); break; }
            case OP_XOR:  { int32_t b = MJS_GET_INT(POP()) >> 8, a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((a ^ b) << 8)); break; }
            case OP_SHL:  { int32_t b = MJS_GET_INT(POP()) >> 8; int32_t a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((a << b) << 8)); break; }
            case OP_SHR:  { int32_t b = MJS_GET_INT(POP()) >> 8; int32_t a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((a >> b) << 8)); break; }
            case OP_USHR: { /* T51: unsigned right shift — clamp to fixed24.8 range */
                           int32_t b = MJS_GET_INT(POP()) >> 8;
                           int32_t a = MJS_GET_INT(POP()) >> 8;
                           uint32_t ur = (uint32_t)a >> b;
                           /* fixed24.8 max integer = 0x1FFFFF (2097151).
                            * Values larger than this can't be represented. */
                           if (ur > 0x1FFFFF) ur = 0x1FFFFF;
                           PUSH(mjs_int((int32_t)ur)); break; }
            case OP_BNOT: { int32_t a = MJS_GET_INT(POP()) >> 8; PUSH(MJS_MAKE_INT((~a) << 8)); break; }
            case OP_LNOT: { int b = !mjs_to_bool(ctx, POP()); PUSH(mjs_bool(b)); break; }

            case OP_EQ: { MJSValue b = POP(), a = POP();
                /* T51: == with type coercion (loose equality).
                 * If both same type: compare directly.
                 * If int and string: convert string to int, compare.
                 * If int and bool: convert bool to int, compare.
                 * If int and special (null/undef/NaN): compare int to 0/1/0.
                 * If string and bool: convert string to bool, compare.
                 * If string and special: compare string to "null"/"undefined"/etc.
                 * If both special: compare directly.
                 * If both ptr: compare by identity or string content. */
                if (MJS_IS_INT(a) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool(MJS_GET_INT(a) == MJS_GET_INT(b)));
                } else if (MJS_IS_INT(a) && mjs_is_string(ctx, b)) {
                    /* int == string: convert string to int */
                    PUSH(mjs_bool(mjs_to_int(ctx, a) == mjs_to_int(ctx, b)));
                } else if (mjs_is_string(ctx, a) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) == mjs_to_int(ctx, b)));
                } else if (MJS_IS_INT(a) && (b == MJS_TRUE_V || b == MJS_FALSE_V)) {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) == (b == MJS_TRUE_V ? 1 : 0)));
                } else if ((a == MJS_TRUE_V || a == MJS_FALSE_V) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool((a == MJS_TRUE_V ? 1 : 0) == mjs_to_int(ctx, b)));
                } else if (MJS_IS_SPECIAL(a) && MJS_IS_SPECIAL(b)) {
                    PUSH(mjs_bool(a == b));
                } else if (a == MJS_NULL_V && MJS_IS_PTR(b)) {
                    PUSH(mjs_bool(0));  /* null != object (simplified) */
                } else if (b == MJS_NULL_V && MJS_IS_PTR(a)) {
                    PUSH(mjs_bool(0));
                } else if (MJS_IS_PTR(a) && MJS_IS_PTR(b)) {
                    /* Both pointers: compare by identity or string content */
                    PUSH(mjs_bool(a == b || mjs_str_eq(ctx, a, b)));
                } else {
                    /* Fallback: convert both to int and compare */
                    PUSH(mjs_bool(mjs_to_int(ctx, a) == mjs_to_int(ctx, b)));
                }
                break; }
            case OP_NE: { MJSValue b = POP(), a = POP();
                /* T51: != is the negation of == (with same coercion rules) */
                if (MJS_IS_INT(a) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool(MJS_GET_INT(a) != MJS_GET_INT(b)));
                } else if (MJS_IS_INT(a) && mjs_is_string(ctx, b)) {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) != mjs_to_int(ctx, b)));
                } else if (mjs_is_string(ctx, a) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) != mjs_to_int(ctx, b)));
                } else if (MJS_IS_INT(a) && (b == MJS_TRUE_V || b == MJS_FALSE_V)) {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) != (b == MJS_TRUE_V ? 1 : 0)));
                } else if ((a == MJS_TRUE_V || a == MJS_FALSE_V) && MJS_IS_INT(b)) {
                    PUSH(mjs_bool((a == MJS_TRUE_V ? 1 : 0) != mjs_to_int(ctx, b)));
                } else if (MJS_IS_SPECIAL(a) && MJS_IS_SPECIAL(b)) {
                    PUSH(mjs_bool(a != b));
                } else if (a == MJS_NULL_V && MJS_IS_PTR(b)) {
                    PUSH(mjs_bool(1));
                } else if (b == MJS_NULL_V && MJS_IS_PTR(a)) {
                    PUSH(mjs_bool(1));
                } else if (MJS_IS_PTR(a) && MJS_IS_PTR(b)) {
                    PUSH(mjs_bool(!(a == b || mjs_str_eq(ctx, a, b))));
                } else {
                    PUSH(mjs_bool(mjs_to_int(ctx, a) != mjs_to_int(ctx, b)));
                }
                break; }
            case OP_STRICT_EQ: {
                /* === : same type AND same value, no coercion.
                 * For our tagged values: tags must match, then payloads compared.
                 *   int==int: compare values
                 *   ptr==ptr: same pointer (or string content equality)
                 *   special==special: same encoding */
                MJSValue b = POP(), a = POP();
                int eq = 0;
                if (MJS_IS_INT(a) && MJS_IS_INT(b)) {
                    eq = (MJS_GET_INT(a) == MJS_GET_INT(b));
                } else if (MJS_IS_INT(a) || MJS_IS_INT(b)) {
                    eq = 0;  /* different types */
                } else if (MJS_IS_SPECIAL(a) && MJS_IS_SPECIAL(b)) {
                    eq = (a == b);
                } else if (MJS_IS_SPECIAL(a) || MJS_IS_SPECIAL(b)) {
                    eq = 0;
                } else if (MJS_IS_PTR(a) && MJS_IS_PTR(b)) {
                    /* both pointers — compare by content for strings, by
                     * identity for objects/arrays/functions. */
                    MJSHeader *ha = (MJSHeader*)MJS_GET_PTR(a);
                    MJSHeader *hb = (MJSHeader*)MJS_GET_PTR(b);
                    if (MJS_HDR_TYPE(ha) == MJS_T_STRING && MJS_HDR_TYPE(hb) == MJS_T_STRING) {
                        eq = mjs_str_eq(ctx, a, b);
                    } else {
                        eq = (a == b);  /* identity */
                    }
                }
                PUSH(mjs_bool(eq));
                break;
            }
            case OP_STRICT_NE: {
                /* reuse OP_STRICT_EQ logic, invert */
                MJSValue b = POP(), a = POP();
                int eq = 0;
                if (MJS_IS_INT(a) && MJS_IS_INT(b)) {
                    eq = (MJS_GET_INT(a) == MJS_GET_INT(b));
                } else if (MJS_IS_INT(a) || MJS_IS_INT(b)) {
                    eq = 0;
                } else if (MJS_IS_SPECIAL(a) && MJS_IS_SPECIAL(b)) {
                    eq = (a == b);
                } else if (MJS_IS_SPECIAL(a) || MJS_IS_SPECIAL(b)) {
                    eq = 0;
                } else if (MJS_IS_PTR(a) && MJS_IS_PTR(b)) {
                    MJSHeader *ha = (MJSHeader*)MJS_GET_PTR(a);
                    MJSHeader *hb = (MJSHeader*)MJS_GET_PTR(b);
                    if (MJS_HDR_TYPE(ha) == MJS_T_STRING && MJS_HDR_TYPE(hb) == MJS_T_STRING) {
                        eq = mjs_str_eq(ctx, a, b);
                    } else {
                        eq = (a == b);
                    }
                }
                PUSH(mjs_bool(!eq));
                break;
            }
            case OP_TYPEOF: {
                /* Pop a value, push a string describing its type. */
                MJSValue v = POP();
                const char *t;
                if (MJS_IS_INT(v) || v == MJS_NAN_V) t = "number";
                else if (v == MJS_UNDEF_V) t = "undefined";
                else if (v == MJS_NULL_V) t = "object";  /* per JS spec */
                else if (v == MJS_TRUE_V || v == MJS_FALSE_V) t = "boolean";
                else if (MJS_IS_PTR(v)) {
                    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
                    if (MJS_HDR_TYPE(h) == MJS_T_STRING) t = "string";
                    else if (MJS_HDR_TYPE(h) == MJS_T_CFUNC || MJS_HDR_TYPE(h) == MJS_T_FUNC) t = "function";
                    else t = "object";
                } else {
                    t = "undefined";
                }
                PUSH(mjs_new_string(ctx, t, strlen(t)));
                break;
            }
            case OP_INSTANCEOF: {
                /* T51: Real prototype-chain instanceof.
                 * val instanceof ctor → walk val.__proto__ chain, check
                 * if any prototype === ctor.prototype. */
                MJSValue ctor = POP();
                MJSValue val = POP();
                int result = 0;
                if (MJS_IS_PTR(ctor) && MJS_IS_PTR(val)) {
                    MJSHeader *ch = (MJSHeader*)MJS_GET_PTR(ctor);
                    /* Get ctor.prototype.
                     * T51: For MJS_T_FUNC, use f->proto directly. */
                    MJSValue proto = MJS_UNDEF_V;
                    if (MJS_HDR_TYPE(ch) == MJS_T_FUNC) {
                        MJSFuncObj *f = (MJSFuncObj*)ch;
                        proto = f->proto;
                    }
                    if (MJS_IS_PTR(proto)) {
                        /* Walk val's prototype chain. */
                        MJSValue cur = val;
                        for (int depth = 0; depth < MJS_PROTO_DEPTH_MAX; depth++) {
                            MJSValue p = mjs_get_prototype(ctx, cur);
                            if (p == proto) { result = 1; break; }
                            if (p == MJS_NULL_V || !MJS_IS_PTR(p)) break;
                            cur = p;
                        }
                    }
                }
                PUSH(mjs_bool(result));
                break;
            }
            case OP_FOR_IN_NEXT: {
                /* Stack: [obj, idx].  Pop both, push next key string or
                 * undef (if iteration is done).  The compiler stores the
                 * updated idx back into the local.  We walk the object's
                 * hash table slots in order, skipping empty/tombstone. */
                int32_t idx = mjs_to_int(ctx, POP());
                MJSValue obj = POP();
                MJSValue result = MJS_UNDEF_V;
                if (MJS_IS_PTR(obj)) {
                    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
                    if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) {
                        MJSObject *o = (MJSObject*)h;
                        MJSSlot *slots = o->slots;
                        /* Walk slots starting from idx, find next non-empty. */
                        int32_t i = idx;
                        while (i < o->capacity) {
                            if (slots[i].atom != 0 && slots[i].atom != 0xFFFFu) {
                                /* Found a key — return its string. */
                                if (slots[i].atom <= ctx->atom_count) {
                                    const char *s = ctx->atoms[slots[i].atom - 1];
                                    result = mjs_new_string(ctx, s, strlen(s));
                                }
                                /* Advance idx past this slot for next call. */
                                idx = i + 1;
                                break;
                            }
                            i++;
                        }
                        if (i >= o->capacity) {
                            /* Iteration done. */
                            result = MJS_UNDEF_V;
                        }
                    } else if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) {
                        /* T42: for...in on array returns integer index
                         * (not string) to avoid heap allocation per iteration. */
                        MJSArray *a = (MJSArray*)h;
                        if (idx < a->length) {
                            result = mjs_int(idx);  /* int, not string */
                            idx = idx + 1;
                        } else {
                            result = MJS_UNDEF_V;
                        }
                    }
                }
                PUSH(result);
                /* Push updated idx (compiler stores it back to local). */
                PUSH(mjs_int(idx));
                break;
            }
            case OP_FOR_OF_NEXT: {
                /* Stack: [arr, idx].  Pop both, push next value or undef. */
                int32_t idx = mjs_to_int(ctx, POP());
                MJSValue arr = POP();
                MJSValue result = MJS_UNDEF_V;
                if (MJS_IS_PTR(arr)) {
                    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(arr);
                    if (MJS_HDR_TYPE(h) == MJS_T_ARRAY) {
                        MJSArray *a = (MJSArray*)h;
                        if (idx < a->length) {
                            result = mjs_get_index(ctx, arr, idx);
                            idx = idx + 1;
                        } else {
                            result = MJS_UNDEF_V;
                        }
                    } else if (MJS_HDR_TYPE(h) == MJS_T_STRING) {
                        /* for...of on string iterates chars. */
                        MJSString *s = (MJSString*)h;
                        if (idx < s->len) {
                            result = mjs_new_string(ctx, s->data + idx, 1);
                            idx = idx + 1;
                        } else {
                            result = MJS_UNDEF_V;
                        }
                    }
                }
                PUSH(result);
                PUSH(mjs_int(idx));
                break;
            }
            case OP_DEFINE_ACCESSOR: {
                /* T51: Define a get/set accessor on an object.
                 * Bytecode: OP_DEFINE_ACCESSOR atom_u8 is_get_u8
                 * Stack: [obj, fn] → [obj] (obj stays on stack) */
                uint8_t atom = bc[pc++];
                uint8_t is_get = bc[pc++];
                MJSValue fn = POP();
                MJSValue obj = TOP();
                if (!MJS_IS_PTR(obj)) break;
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
                if (MJS_HDR_TYPE(h) != MJS_T_OBJECT) break;
                /* Check if accessor already exists for this property */
                MJSValue existing = mjs_obj_get(ctx, obj, atom);
                MJSAccessor *acc = NULL;
                if (MJS_IS_PTR(existing)) {
                    MJSHeader *eh = (MJSHeader*)MJS_GET_PTR(existing);
                    if (MJS_HDR_TYPE(eh) == MJS_T_ACCESSOR)
                        acc = (MJSAccessor*)eh;
                }
                if (!acc) {
                    acc = (MJSAccessor*)mjs_alloc(ctx, sizeof(MJSAccessor));
                    if (!acc) break;
                    MJS_HDR_SET_TYPE(&(acc)->hdr, MJS_T_ACCESSOR);
                    acc->getter = MJS_UNDEF_V;
                    acc->setter = MJS_UNDEF_V;
                    acc->this_val = obj;
                }
                if (is_get) acc->getter = fn; else acc->setter = fn;
                MJSValue acc_val = (MJSValue)((uintptr_t)acc | TAG_PTR);
                mjs_obj_set(ctx, obj, atom, acc_val);
                break;
            }
            case OP_LT: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP()); PUSH(mjs_bool(a < b)); break; }
            case OP_LE: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP()); PUSH(mjs_bool(a <= b)); break; }
            case OP_GT: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP()); PUSH(mjs_bool(a > b)); break; }
            case OP_GE: { int32_t b = MJS_GET_INT(POP()), a = MJS_GET_INT(POP()); PUSH(mjs_bool(a >= b)); break; }

            case OP_JMP: { int16_t o = (int16_t)(bc[pc] | (bc[pc+1] << 8)); pc += 2;
                           pc = (uint16_t)((int32_t)pc + o); break; }
            case OP_JZ:  { int16_t o = (int16_t)(bc[pc] | (bc[pc+1] << 8)); pc += 2;
                           if (!mjs_to_bool(ctx, POP())) pc = (uint16_t)((int32_t)pc + o); break; }
            case OP_JNZ: { int16_t o = (int16_t)(bc[pc] | (bc[pc+1] << 8)); pc += 2;
                           if (mjs_to_bool(ctx, POP())) pc = (uint16_t)((int32_t)pc + o); break; }

            case OP_CALL: {
                uint8_t argc = bc[pc++];
                MJSValue fn = sp[argc];
                if (!MJS_IS_PTR(fn)) {
                    /* Build a descriptive error message. */
                    char errbuf[80];
                    if (MJS_IS_UNDEF(fn))
                        strcpy(errbuf, "not a function (undefined)");
                    else if (MJS_IS_INT(fn))
                        snprintf(errbuf, sizeof(errbuf), "not a function (number: %d)", (int)mjs_to_int(ctx, fn));
                    else if (fn == MJS_NULL_V)
                        strcpy(errbuf, "not a function (null)");
                    else if (fn == MJS_TRUE_V || fn == MJS_FALSE_V)
                        strcpy(errbuf, "not a function (boolean)");
                    else
                        strcpy(errbuf, "not a function");
                    ERR(errbuf);
                }
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(fn);
                if (MJS_HDR_TYPE(h) == MJS_T_CFUNC) {
                    MJSCFunc *c = (MJSCFunc*)h;
                    MJSValue argv_buf[17];
                    int eff_argc = argc;
                    /* T44: sync ctx->sp before calling CFUNC — the native
                     * function might call mjs_call_value (e.g. forEach)
                     * which reads ctx->sp to save/restore the stack. */
                    ctx->sp = sp;
                    if (c->bound_this != MJS_UNDEF_V) {
                        argv_buf[0] = c->bound_this;
                        for (int i = 0; i < argc && i < 16; i++)
                            argv_buf[i + 1] = sp[argc - 1 - i];
                        eff_argc = argc + 1;
                    } else {
                        for (int i = 0; i < argc && i < 16; i++)
                            argv_buf[i] = sp[argc - 1 - i];
                    }
                    MJSValue r = c->fn(ctx, eff_argc, argv_buf);
                    /* T44: restore sp from ctx — mjs_call_value inside
                     * CFUNC may have changed ctx->sp. */
                    sp = ctx->sp;
                    sp += argc + 1;
                    PUSH(r);
                } else if (MJS_HDR_TYPE(h) == MJS_T_FUNC) {
                    MJSFuncObj *f = (MJSFuncObj*)h;
                    if (frame_depth >= MJS_CALL_DEPTH) ERR("call depth exceeded");
                    int new_base = local_base + MJS_LOCALS_PER_FRAME;
                    if (new_base + f->nlocals > MJS_LOCALS_MAX) ERR("locals overflow");
                    /* Save frame. */
                    ctx->frames[frame_depth].pc = pc;
                    ctx->frames[frame_depth].base = local_base;
                    ctx->frames[frame_depth].nlocals = f->nlocals;  /* BUG-7 */
                    /* T51-fix/GC-7: initialise this_val so the mark phase
                     * doesn't see a stale heap pointer left over from a
                     * previous OP_CALL_WITH_THIS / OP_NEW at the same
                     * frame_depth.  Without this, GC could (a) keep a
                     * dead object alive by marking the stale slot, or
                     * (b) write a mark bit on a freed block whose type
                     * wasn't reset by sweep — corrupting free_list. */
                    ctx->frames[frame_depth].this_val = ctx->_this;
                    frame_depth++;
                    /* Copy args into locals in correct order. */
                    for (int i = 0; i < argc; i++)
                        ctx->locals[new_base + i] = sp[argc - 1 - i];
                    for (int i = argc; i < f->nlocals; i++)
                        ctx->locals[new_base + i] = MJS_UNDEF_V;
                    /* Pop fn + args. */
                    sp += argc + 1;
                    local_base = new_base;
                    pc = f->pc;
                } else if (MJS_HDR_TYPE(h) == MJS_T_OBJECT) {
                    /* T51-fix: Calling a global object as a function (e.g.
                     * String(x)) — convert x to string.  Array(x) → [x]. */
                    MJSValue arg = (argc > 0) ? sp[0] : MJS_UNDEF_V;
                    MJSValue result = MJS_UNDEF_V;
                    /* Identify String by checking if it has "length" (CFUNC). */
                    uint16_t len_atom = mjs_atom_find(ctx, "length", 6);
                    if (len_atom > 0) {
                        MJSValue len_prop = mjs_obj_get(ctx, fn, len_atom);
                        if (MJS_IS_PTR(len_prop)) {
                            MJSHeader *lh = (MJSHeader*)MJS_GET_PTR(len_prop);
                            if (MJS_HDR_TYPE(lh) == MJS_T_CFUNC) {
                                /* String(x) → convert to string */
                                if (MJS_IS_INT(arg)) {
                                    int32_t raw = MJS_GET_INT(arg);
                                    bool neg = raw < 0;
                                    if (neg) raw = -raw;
                                    int32_t ip = raw >> 8;
                                    int32_t fp = raw & 0xFF;
                                    char buf[32];
                                    if (fp == 0) snprintf(buf, sizeof(buf), "%s%d", neg?"-":"", (int)ip);
                                    else snprintf(buf, sizeof(buf), "%s%d.%02d", neg?"-":"", (int)ip, (int)(fp*100/256));
                                    result = mjs_new_string(ctx, buf, strlen(buf));
                                } else if (mjs_is_string(ctx, arg)) {
                                    result = arg;
                                } else if (arg == MJS_TRUE_V) {
                                    result = mjs_new_string(ctx, "true", 4);
                                } else if (arg == MJS_FALSE_V) {
                                    result = mjs_new_string(ctx, "false", 5);
                                } else if (arg == MJS_NULL_V) {
                                    result = mjs_new_string(ctx, "null", 4);
                                } else if (arg == MJS_UNDEF_V) {
                                    result = mjs_new_string(ctx, "undefined", 9);
                                } else {
                                    result = mjs_new_string(ctx, "[object]", 8);
                                }
                            }
                        }
                    }
                    /* If not String, try Array (has "push" CFUNC). */
                    if (result == MJS_UNDEF_V) {
                        uint16_t push_atom = mjs_atom_find(ctx, "push", 4);
                        if (push_atom > 0) {
                            MJSValue push_prop = mjs_obj_get(ctx, fn, push_atom);
                            if (MJS_IS_PTR(push_prop)) {
                                MJSHeader *ph = (MJSHeader*)MJS_GET_PTR(push_prop);
                                if (MJS_HDR_TYPE(ph) == MJS_T_CFUNC) {
                                    MJSValue arr = mjs_new_array(ctx, 1);
                                    mjs_set_index(ctx, arr, 0, arg);
                                    result = arr;
                                }
                            }
                        }
                    }
                    sp += argc + 1;
                    PUSH(result);
                } else ERR("not callable");
                break;
            }
            case OP_CALL_WITH_THIS: {
                /* T51: Call a method with `this` = the object.
                 * Stack: [obj, args..., fn, argc]
                 * After: [result]
                 *
                 * The compiler emits this for `obj.method(args)` calls.
                 * It DUPs obj before LOAD_PROP, so the stack has:
                 *   [obj, args..., method_fn, argc]
                 * This opcode sets ctx->_this = obj (the value BELOW the
                 * args+fn), then calls fn with argc args.
                 *
                 * For JS functions: sets up a new frame with this=obj.
                 * For C functions: passes obj as argv[0] (this). */
                uint8_t argc = bc[pc++];
                /* fn is at sp[argc], args at sp[0..argc-1], obj at sp[argc+1]. */
                MJSValue fn = sp[argc];
                MJSValue this_obj = sp[argc + 1];
                if (!MJS_IS_PTR(fn)) ERR("not a function (method call)");
                MJSHeader *h = (MJSHeader*)MJS_GET_PTR(fn);
                if (MJS_HDR_TYPE(h) == MJS_T_CFUNC) {
                    MJSCFunc *c = (MJSCFunc*)h;
                    MJSValue argv_buf[18];
                    MJSValue r;
                    /* T51: For C functions called via CALL_WITH_THIS:
                     * - If CFUNC has bound_this (bound method from
                     *   LOAD_PROP for array/string methods), pass
                     *   bound_this as argv[0], then args as argv[1..].
                     *   This matches how OP_CALL works for bound methods.
                     * - If CFUNC has no bound_this (plain CFUNC like
                     *   Object.create), set bound_this = this_obj and
                     *   pass args as argv[0..argc-1]. */
                    int had_bound_this = (c->bound_this != MJS_UNDEF_V);
                    if (had_bound_this) {
                        /* Bound method: argv[0] = bound_this, argv[1..] = args. */
                        argv_buf[0] = c->bound_this;
                        for (int i = 0; i < argc && i < 16; i++)
                            argv_buf[i + 1] = sp[argc - 1 - i];
                        ctx->sp = sp;
                        r = c->fn(ctx, argc + 1, argv_buf);
                    } else {
                        /* Plain CFUNC: set bound_this, pass args as argv[0..]. */
                        c->bound_this = this_obj;
                        for (int i = 0; i < argc && i < 16; i++)
                            argv_buf[i] = sp[argc - 1 - i];
                        ctx->sp = sp;
                        r = c->fn(ctx, argc, argv_buf);
                        c->bound_this = MJS_UNDEF_V;
                    }
                    sp = ctx->sp;
                    sp += argc + 2;  /* pop fn + args + obj */
                    PUSH(r);
                } else if (MJS_HDR_TYPE(h) == MJS_T_FUNC) {
                    MJSFuncObj *f = (MJSFuncObj*)h;
                    if (frame_depth >= MJS_CALL_DEPTH) ERR("call depth exceeded");
                    int new_base = local_base + MJS_LOCALS_PER_FRAME;
                    if (new_base + f->nlocals > MJS_LOCALS_MAX) ERR("locals overflow");
                    ctx->frames[frame_depth].pc = pc;
                    ctx->frames[frame_depth].base = local_base;
                    /* T51: save `this`, set new `this` = obj. */
                    ctx->frames[frame_depth].this_val = ctx->_this;
                    ctx->frames[frame_depth].nlocals = f->nlocals;  /* BUG-7 */
                    ctx->_this = this_obj;
                    frame_depth++;
                    /* Copy args into locals. */
                    for (int i = 0; i < argc; i++)
                        ctx->locals[new_base + i] = sp[argc - 1 - i];
                    for (int i = argc; i < f->nlocals; i++)
                        ctx->locals[new_base + i] = MJS_UNDEF_V;
                    sp += argc + 2;  /* pop fn + args + obj */
                    local_base = new_base;
                    pc = f->pc;
                } else ERR("not callable");
                break;
            }

            case OP_RET: {
                MJSValue r = POP();
                if (frame_depth == 0 ||
                    ctx->frames[frame_depth - 1].pc == 0xFFFF) {
                    PUSH(r);
                    goto done;
                }
                frame_depth--;
                local_base = ctx->frames[frame_depth].base;
                uint16_t saved_pc = ctx->frames[frame_depth].pc;
                /* T51: restore `this` from saved frame. */
                ctx->_this = ctx->frames[frame_depth].this_val;
                if (saved_pc & 0x8000) {
                    pc = saved_pc & 0x7FFF;
                    if (!MJS_IS_PTR(r) ||
                        MJS_HDR_TYPE((MJSHeader*)MJS_GET_PTR(r)) != MJS_T_OBJECT) {
                        r = ctx->_new_target;
                    }
                    ctx->_new_target = MJS_UNDEF_V;
                } else {
                    pc = saved_pc;
                }
                PUSH(r);
                break;
            }
            case OP_RET_UNDEF: {
                if (frame_depth == 0 ||
                    ctx->frames[frame_depth - 1].pc == 0xFFFF) {
                    goto done;
                }
                frame_depth--;
                local_base = ctx->frames[frame_depth].base;
                uint16_t saved_pc = ctx->frames[frame_depth].pc;
                /* T51: restore `this` from saved frame. */
                ctx->_this = ctx->frames[frame_depth].this_val;
                MJSValue r;
                if (saved_pc & 0x8000) {
                    pc = saved_pc & 0x7FFF;
                    r = ctx->_new_target;
                    ctx->_new_target = MJS_UNDEF_V;
                } else {
                    pc = saved_pc;
                    r = MJS_UNDEF_V;
                }
                PUSH(r);
                break;
            }

            case OP_FUNCTION: {
                /* Push a user function as a callable heap object. */
                uint8_t idx = bc[pc++];
                if (idx >= ctx->func_count) ERR("func OOB");
                MJSFuncObj *f = (MJSFuncObj*)mjs_alloc(ctx, sizeof(MJSFuncObj));
                if (!f) ERR("OOM function");
                MJS_HDR_SET_TYPE(&(f)->hdr, MJS_T_FUNC);
                f->pc      = ctx->funcs[idx].pc;
                f->argc    = ctx->funcs[idx].argc;
                f->nlocals = ctx->funcs[idx].nlocals;
                /* T51: Auto-create a prototype object (JS spec: every
                 * function gets a .prototype = {} automatically).
                 * This allows `Func.prototype.method = ...` and
                 * `new Func()` to set __proto__ = Func.prototype. */
                f->proto = mjs_new_object(ctx);
                PUSH((MJSValue)((uintptr_t)f | TAG_PTR));
                break;
            }

            case OP_HALT:
                goto done;

            /* T51: try/catch/throw */
            case OP_PUSH_TRY: {
                int16_t off = (int16_t)(bc[pc] | (bc[pc+1] << 8));
                pc += 2;
                uint16_t catch_pc = (uint16_t)((int32_t)pc + off);
                if (ctx->try_depth >= MJS_TRY_DEPTH) ERR("try depth exceeded");
                ctx->try_stack[ctx->try_depth].catch_pc = catch_pc;
                ctx->try_stack[ctx->try_depth].frame_depth = frame_depth;
                ctx->try_stack[ctx->try_depth].local_base = local_base;
                ctx->try_stack[ctx->try_depth].sp = sp;
                ctx->try_depth++;
                break;
            }
            case OP_POP_TRY: {
                if (ctx->try_depth > 0) ctx->try_depth--;
                break;
            }
            case OP_THROW: {
                /* Throw top of stack as error.
                 * If it's a string, use it as the error message (no pc suffix).
                 * If it's a number, convert to string.
                 * Then unwind to nearest try handler or halt. */
                MJSValue errval = POP();
                char throw_msg[MJS_ERR_SIZE];
                if (mjs_is_string(ctx, errval)) {
                    size_t l; const char *s = mjs_to_cstr(ctx, errval, &l);
                    snprintf(throw_msg, sizeof(throw_msg), "%s", s);
                } else if (MJS_IS_INT(errval)) {
                    snprintf(throw_msg, sizeof(throw_msg), "%d", (int)mjs_to_int(ctx, errval));
                } else {
                    snprintf(throw_msg, sizeof(throw_msg), "thrown error");
                }
                if (ctx->try_depth > 0) {
                    ctx->try_depth--;
                    pc = ctx->try_stack[ctx->try_depth].catch_pc;
                    frame_depth = ctx->try_stack[ctx->try_depth].frame_depth;
                    local_base = ctx->try_stack[ctx->try_depth].local_base;
                    sp = ctx->try_stack[ctx->try_depth].sp;
                    PUSH(mjs_new_string(ctx, throw_msg, strlen(throw_msg)));
                    ctx->has_error = 0;
                    continue;
                }
                /* No try handler — set error and halt */
                ctx->has_error = 1;
                ctx->err_pc = pc;
                snprintf(ctx->err_buf, MJS_ERR_SIZE, "%s", throw_msg);
                goto done;
            }

            case OP_NEW: {
                /* T51: new Constructor(args...)
                 * Stack before: [..., args, ctor, argc]
                 * After: [obj]
                 *
                 * For JS functions (MJS_T_FUNC):
                 *   1. Create new object, set __proto__ = ctor.prototype
                 *   2. Set up a new call frame with this=newObj as local[0]
                 *   3. Jump to function body
                 *   4. On RET, check return value; if object, use it, else newObj
                 *
                 * For C functions (MJS_T_CFUNC):
                 *   1. Create new object, set __proto__
                 *   2. Call with argv[0] = newObj (as `this`)
                 *   3. Use return value or newObj
                 */
                uint8_t argc = bc[pc++];
                MJSValue ctor = sp[argc];
                if (!MJS_IS_PTR(ctor)) ERR("new: not a constructor");
                MJSHeader *ch = (MJSHeader*)MJS_GET_PTR(ctor);
                /* Create the new object. */
                MJSValue newObj = mjs_new_object(ctx);
                /* Set __proto__ to ctor.prototype.
                 * For MJS_T_FUNC, use f->proto directly (auto-created).
                 * For MJS_T_CFUNC, try mjs_obj_get (won't find one —
                 * C functions don't have auto-prototypes). */
                MJSValue proto = MJS_UNDEF_V;
                if (MJS_HDR_TYPE(ch) == MJS_T_FUNC) {
                    MJSFuncObj *f = (MJSFuncObj*)ch;
                    proto = f->proto;
                }
                if (MJS_IS_PTR(proto)) {
                    mjs_set_prototype(ctx, newObj, proto);
                }

                if (MJS_HDR_TYPE(ch) == MJS_T_FUNC) {
                    MJSFuncObj *f = (MJSFuncObj*)ch;
                    if (frame_depth >= MJS_CALL_DEPTH) ERR("call depth exceeded");
                    int new_base = local_base + MJS_LOCALS_PER_FRAME;
                    if (new_base + f->nlocals > MJS_LOCALS_MAX) ERR("locals overflow");
                    /* Save frame — use a special pc marker to indicate
                     * "return from new" so we can check the return value. */
                    ctx->frames[frame_depth].pc = pc | 0x8000;  /* marker bit */
                    ctx->frames[frame_depth].base = local_base;
                    /* T51: save current `this` and set new `this` = newObj. */
                    ctx->frames[frame_depth].this_val = ctx->_this;
                    ctx->frames[frame_depth].nlocals = f->nlocals;  /* BUG-7 */
                    ctx->_this = newObj;
                    frame_depth++;
                    /* Copy args into locals — same as OP_CALL.
                     * `this` is NOT stored in a local slot; it's in
                     * ctx->_this, accessed via OP_THIS.  Parameters
                     * go to locals[new_base + 0..argc-1]. */
                    for (int i = 0; i < argc; i++)
                        ctx->locals[new_base + i] = sp[argc - 1 - i];
                    for (int i = argc; i < f->nlocals; i++)
                        ctx->locals[new_base + i] = MJS_UNDEF_V;
                    /* Pop fn + args. */
                    sp += argc + 1;
                    local_base = new_base;
                    pc = f->pc;
                    /* When this function returns (OP_RET), the VM will
                     * push the return value.  We need to intercept it
                     * to apply the "if object use it, else use newObj"
                     * rule.  This is handled by checking the marker bit
                     * in OP_RET.  For now, store newObj in a ctx field. */
                    ctx->_new_target = newObj;
                    break;
                } else if (MJS_HDR_TYPE(ch) == MJS_T_CFUNC) {
                    MJSCFunc *c = (MJSCFunc*)ch;
                    /* Build argv: [newObj, arg1, arg2, ...] */
                    MJSValue argv_buf[17];
                    argv_buf[0] = newObj;
                    for (int i = 0; i < argc && i < 16; i++)
                        argv_buf[i + 1] = sp[argc - 1 - i];
                    ctx->sp = sp;
                    MJSValue r = c->fn(ctx, argc + 1, argv_buf);
                    sp = ctx->sp;
                    sp += argc + 1;  /* pop fn + args */
                    if (MJS_IS_PTR(r)) {
                        MJSHeader *rh = (MJSHeader*)MJS_GET_PTR(r);
                        if (MJS_HDR_TYPE(rh) == MJS_T_OBJECT) {
                            PUSH(r);
                            break;
                        }
                    }
                    PUSH(newObj);
                    break;
                } else {
                    ERR("new: not callable");
                }
                break;
            }

            case OP_THIS:
                PUSH(ctx->_this);
                break;

            case OP_NATIVE_CALL: {
                /* T51: Inline native call — bypasses LOAD_PROP + CALL
                 * for hot-path tft methods.  1-byte native_id selects
                 * the function.  Args on stack, argc encoded in high nibble. */
                uint8_t nid = bc[pc++];
                uint8_t nargc = (nid >> 4) & 0x0F;
                uint8_t nfn = nid & 0x0F;
                MJSValue nav[8];
                for (int i = 0; i < nargc && i < 8; i++)
                    nav[i] = sp[nargc - 1 - i];
                sp += nargc;
                if (nfn < 16 && g_native_fns[nfn]) {
                    ctx->sp = sp;
                    MJSValue r = g_native_fns[nfn](ctx, nargc, nav);
                    sp = ctx->sp;
                    PUSH(r);
                } else {
                    PUSH(MJS_UNDEF_V);
                }
                break;
            }

            case OP_NEW_ARRAY_U8: {
                /* T51: Compact u8 array — 1 byte count, then count raw u8 values.
                 * Creates a packed u8 array directly, no stack pushing.
                 * Saves ~50% bytecode for integer arrays. */
                uint8_t count = bc[pc++];
                MJSValue arr = mjs_new_array_packed(ctx, count, 1);
                /* T51-fix/BUG-1: mjs_new_array_packed returns MJS_NULL_V
                 * on OOM.  MJS_GET_PTR(MJS_NULL_V) returns 4 (NOT 0),
                 * because MJS_NULL_V=0x06 & MJS_PTR_MASK=~3 = 0x04.
                 * Without this guard, the loop below writes up to 255
                 * bytes starting at virtual address ~20 → Hard Fault. */
                if (!MJS_IS_PTR(arr)) {
                    ERR("OOM in OP_NEW_ARRAY_U8");
                    break;
                }
                MJSArray *a = (MJSArray*)MJS_GET_PTR(arr);
                uint8_t *items = (uint8_t*)(a + 1);
                for (uint8_t i = 0; i < count; i++) {
                    items[i] = bc[pc++];
                }
                a->length = count;
                PUSH(arr);
                break;
            }
            case OP_NEW_ARRAY_U16: {
                /* T51: Compact u16 array — 1 byte count, then count*2 raw u16 values. */
                uint8_t count = bc[pc++];
                MJSValue arr = mjs_new_array_packed(ctx, count, 2);
                /* T51-fix/BUG-2: same OOM guard as OP_NEW_ARRAY_U8. */
                if (!MJS_IS_PTR(arr)) {
                    ERR("OOM in OP_NEW_ARRAY_U16");
                    break;
                }
                MJSArray *a = (MJSArray*)MJS_GET_PTR(arr);
                uint16_t *items = (uint16_t*)(a + 1);
                for (uint8_t i = 0; i < count; i++) {
                    items[i] = (uint16_t)(bc[pc] | (bc[pc+1] << 8));
                    pc += 2;
                }
                a->length = count;
                PUSH(arr);
                break;
            }
            case OP_NEW_ARRAY16: {
                /* T51: Like OP_NEW_ARRAY but with 16-bit count (for > 255 elements). */
                uint16_t n = (uint16_t)(bc[pc] | (bc[pc+1] << 8)); pc += 2;
                uint8_t elem_size = 0;
                if (n > 0) {
                    int all_u8 = 1, all_u16 = 1;
                    for (int i = 0; i < n; i++) {
                        MJSValue v = sp[n - 1 - i];
                        if (!MJS_IS_INT(v)) { all_u8 = 0; all_u16 = 0; break; }
                        int32_t raw = MJS_GET_INT(v);
                        if (raw & 0xFF) { all_u8 = 0; all_u16 = 0; break; }
                        int32_t iv = raw >> 8;
                        if (iv < 0 || iv > 255) all_u8 = 0;
                        if (iv < 0 || iv > 65535) all_u16 = 0;
                    }
                    if (all_u8) elem_size = 1;
                    else if (all_u16) elem_size = 2;
                }
                MJSValue arr;
                if (elem_size == 0) {
                    arr = mjs_new_array(ctx, n);
                    for (int i = n - 1; i >= 0; i--) mjs_set_index(ctx, arr, i, POP());
                } else {
                    arr = mjs_new_array_packed(ctx, n, elem_size);
                    for (int i = n - 1; i >= 0; i--) mjs_set_index(ctx, arr, i, POP());
                }
                PUSH(arr);
                break;
            }

            default:
                mjs_set_err(ctx, "bad opcode", pc - 1);
                goto done;
        }
    }

done:
    ctx->pc = pc;
    ctx->sp = sp;
    ctx->frame_depth = frame_depth;
    ctx->local_base = local_base;
    /* T51-fix: Clear value stack and unused locals after script completes.
     * Without this, stale MJSValue pointers left on the stack or in
     * locals[] above the active frame would be marked as GC roots,
     * preventing unreachable objects from being collected.  This was
     * the root cause of "gc() doesn't free memory after loops" — the
     * loop body left intermediate object pointers on the stack/in
     * locals, and GC kept them alive.
     *
     * After mjs_run() returns (top-level script done), reset:
     *   - sp to buf_end (empty stack)
     *   - locals above local_base + MJS_LOCALS_PER_FRAME to UNDEF
     *   - local_base to 0, frame_depth to 0
     * Then run a GC to collect everything that's now unreachable. */
    if (ctx->frame_depth == 0) {
        /* Only clear if we're at top level (not inside mjs_call_value). */
        ctx->sp = (MJSValue*)ctx->buf_end;
        /* Clear locals above the top-level frame.  Top-level uses
         * local_base=0, MJS_LOCALS_PER_FRAME slots.  Anything above
         * is leftover from function calls that have returned. */
        for (int i = ctx->local_base + MJS_LOCALS_PER_FRAME; i < MJS_LOCALS_MAX; i++) {
            ctx->locals[i] = MJS_UNDEF_V;
        }
        /* Run GC immediately — collect all the garbage from this run. */
        mjs_gc(ctx);
    }
    return ctx->has_error ? 1 : 0;

#undef PUSH
#undef POP
#undef TOP
#undef ERR
}

/* ============================================================
 * mjs_call_value — call a JS function from native code.
 *
 * Pushes a new frame on top of the current state and runs the VM
 * until that frame returns.  The caller's value stack must be at a
 * frame boundary (i.e., empty or with only completed-expression
 * values on it).
 * ============================================================ */
MJSValue mjs_call_value(MJSContext *ctx, MJSValue fn,
                        int argc, MJSValue *argv) {
    if (!ctx || !MJS_IS_PTR(fn)) {
        mjs_set_err(ctx, "call_value: not a function", 0);
        return MJS_UNDEF_V;
    }
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(fn);
    if (MJS_HDR_TYPE(h) == MJS_T_CFUNC) {
        MJSCFunc *c = (MJSCFunc*)h;
        return c->fn(ctx, argc, argv);
    }
    if (MJS_HDR_TYPE(h) != MJS_T_FUNC) {
        mjs_set_err(ctx, "call_value: not callable", 0);
        return MJS_UNDEF_V;
    }
    MJSFuncObj *f = (MJSFuncObj*)h;

    if (ctx->frame_depth >= MJS_CALL_DEPTH) {
        mjs_set_err(ctx, "call_value: depth exceeded", 0);
        return MJS_UNDEF_V;
    }
    int new_base = ctx->local_base + MJS_LOCALS_PER_FRAME;
    if (new_base + f->nlocals > MJS_LOCALS_MAX) {
        mjs_set_err(ctx, "call_value: locals overflow", 0);
        return MJS_UNDEF_V;
    }

    /* Save current pc + local_base into a fresh frame.  We mark the
     * saved pc with HALT so when this frame returns, the VM stops. */
    ctx->frames[ctx->frame_depth].pc = 0xFFFF;  /* sentinel: halt on return */
    ctx->frames[ctx->frame_depth].bc_region = 0;
    ctx->frames[ctx->frame_depth].base = ctx->local_base;
    ctx->frame_depth++;

    /* Set up locals. */
    for (int i = 0; i < argc && i < f->nlocals; i++)
        ctx->locals[new_base + i] = argv[i];
    for (int i = argc; i < f->nlocals; i++)
        ctx->locals[new_base + i] = MJS_UNDEF_V;

    int saved_local_base = ctx->local_base;
    int saved_frame_depth = ctx->frame_depth - 1;  /* we added 1 above */
    ctx->local_base = new_base;
    /* Save current sp — the VM will push the return value here. */
    MJSValue *saved_sp = ctx->sp;

    /* Run the VM starting at the function's pc. */
    ctx->pc = f->pc;
    int r = mjs_run(ctx);

    /* After mjs_run returns, the result is on top of the stack (if
     * the function returned normally) or there's an error.  Pop it. */
    MJSValue result = MJS_UNDEF_V;
    /* T51: Bug fix — stack grows DOWN, so after PUSH(return_value),
     * ctx->sp = saved_sp - 1 (lower address).  Old check was > (wrong
     * direction).  Fixed to < (sp decreased = value was pushed). */
    if (r == 0 && ctx->sp < saved_sp) {
        result = *ctx->sp;
        ctx->sp++;
    }

    /* Restore state — frame_depth was decremented by OP_RET inside
     * mjs_run, but if there was an error it might not have been.
     * Force-restore to the saved value. */
    ctx->local_base = saved_local_base;
    ctx->frame_depth = saved_frame_depth;
    ctx->sp = saved_sp;  /* reset sp to before the call */
    return result;
}

#ifdef __cplusplus
}
#endif

#endif /* MJS_VM_IMPLEMENTATION */
