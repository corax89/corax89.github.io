/* microjs_repl.h — Compact serial REPL compiler for microjs ESPboy
 *
 * Reads JS source from a buffer (filled from Serial), compiles to MJSB
 * bytecode, and loads it into the VM for execution.
 *
 * Memory usage: ~1.6 KB static (tables + buffers + small fix stacks),
 * no dynamic allocation beyond a single arena.
 *
 * Supported (aligned with browser-side microjs_compiler.js):
 *   - var/let/const (let/const treated as var — see LIMITATIONS below)
 *   - if/else, while, do-while, for, switch/case/default (no fallthrough)
 *   - function declarations + calls + return
 *   - break/continue (also valid inside switch)
 *   - try/catch/throw/finally (finally via extra JMP wrapper)
 *   - new Ctor(args), typeof x, instanceof, void
 *   - Object literals {a:1, b:2}, array literals [1,2,3]
 *   - Numbers (decimal, hex 0x..), strings with full escape set (\n\t\r\\\0\'\"\xNN\uNNNN)
 *   - Arithmetic + - * / %, comparisons < <= > >=, == !=, === !==
 *   - Logical && || !, bitwise & | ^ ~ << >> >>>
 *   - Compound assignments: = += -= *= /= %= &= |= ^= <<= >>= >>>=
 *   - Unary + - ! ~, prefix ++ --, postfix ++ --
 *   - Property access . and [], method calls obj.m(args)
 *   - Ternary cond ? a : b, comma operator
 *   - // line comments and slash-star block comments star-slash
 *
 * Limitations (intentional, given 2 KB arena / 1 KB bc buffer):
 *   MAX_ATOMS=16, MAX_CONSTS=8, MAX_FUNCS=4, MAX_LOCALS=12
 *   No float literals (numbers are int30 fixed24.8 - see int30 doc).
 *   No arrow functions, no template literals, no destructuring,
 *   no for-in/of, no get/set in object literals, no RegExp/Date/Promise.
 *   let/const use function scope (treated as var).
 *
 * SPDX-License-Identifier: MIT
 */
#ifndef MICROJS_REPL_H
#define MICROJS_REPL_H

#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>   /* snprintf — used by object literal numeric keys */

/* Compile source string into MJSB bytecode buffer.
 * Returns total size (>0) on success, 0 on error.
 * buf must be at least bufSize bytes. */
int repl_compile(const char *src, uint8_t *buf, int bufSize);

/* Run compiled bytecode in the given context.
 * Returns 0 on success, non-zero on runtime error. */
int repl_run(uint8_t *bc, int bcSize);

#endif /* MICROJS_REPL_H */

#ifdef MICROJS_REPL_IMPLEMENTATION

/* ============================================================
 * Compact compiler — reads from a string, writes MJSB bytecode
 * T51-repl-v2: expanded to track browser compiler feature set
 * while preserving the 2 KB arena / 1 KB bc budget.
 * ============================================================ */

#define REPL_MAX_ATOMS  16
#define REPL_MAX_CONSTS 8
#define REPL_MAX_FUNCS  4
#define REPL_MAX_LOCALS 12
#define REPL_MAX_NAME   16   /* T51-fix: was 24.  16 bytes covers i/x/y/led/btn/...
                                 * Saves 224 B (28 entries × 8 B). */
#define REPL_MAX_STR    64
#define REPL_BC_RESERVE 128  /* space reserved at start of buf for header */
#define REPL_BC_MAX     1024 /* working bytecode buffer for compile */
#define REPL_MAX_NESTING 8   /* T51-fix: max loop nesting for break/continue.
                              * Was 32 — overkill for REPL.  8 is plenty
                              * and saves 224 B (was 2×128 B, now 2×16 B). */
#define REPL_MAX_TRY_NESTING 4  /* catch_pc + end_jmp placeholders, 2 per try */
#define REPL_MAX_SWITCH 4      /* switch end_jmp placeholders, 1 per switch */
/* T51-fix: single arena size — all heap buffers carved from one pool.
 * Layout (with 4-byte alignment for ReplConst/ReplFunc):
 *   atoms   16×16  = 256  (off 0)
 *   consts  8×68   = 544  (off 256, aligned)
 *   funcs   4×6    =  24  (off 800, aligned)
 *   locals  12×16  = 192  (off 824)
 *   buf     1024   =1024  (off 1016)
 *   breaks  8×2    =  16  (off 2040, 2-byte aligned)
 *   conts   8×2    =  16  (off 2056)
 * Total: 2072, rounded up to 2080.
 * One malloc saves ~48 B of heap-header overhead vs 7 separate mallocs.
 * try_stack (8 × 2 = 16 B) and switch_ends (4 × 2 = 8 B) are file-scope
 * statics — they don't grow the arena. */
#define REPL_ARENA_SIZE 2080

/* Opcode constants — must match microjs_vm.h */
#define ROP_UNDEF      0x01
#define ROP_NULL       0x02
#define ROP_TRUE       0x03
#define ROP_FALSE      0x04
#define ROP_INT8       0x05
#define ROP_INT16      0x06
#define ROP_INT24      0x07
#define ROP_CONST      0x08
#define ROP_LOAD_LOCAL 0x09
#define ROP_STORE_LOCAL 0x0A
#define ROP_LOAD_GLOBAL 0x0B
#define ROP_STORE_GLOBAL 0x0C
#define ROP_POP        0x0D
#define ROP_DUP        0x0E
#define ROP_SWAP       0x0F
#define ROP_LOAD_PROP  0x10
#define ROP_STORE_PROP 0x11
#define ROP_LOAD_INDEX 0x12
#define ROP_STORE_INDEX 0x13
#define ROP_NEW_OBJECT 0x14
#define ROP_NEW_ARRAY  0x15
#define ROP_ADD        0x18
#define ROP_SUB        0x19
#define ROP_MUL        0x1A
#define ROP_DIV        0x1B
#define ROP_MOD        0x1C
#define ROP_NEG        0x1D
#define ROP_INC        0x1E
#define ROP_DEC        0x1F
#define ROP_AND        0x20
#define ROP_OR         0x21
#define ROP_XOR        0x22
#define ROP_SHL        0x23
#define ROP_SHR        0x24
#define ROP_USHR       0x25
#define ROP_BNOT       0x26
#define ROP_LNOT       0x27
#define ROP_EQ         0x28
#define ROP_NE         0x29
#define ROP_LT         0x2A
#define ROP_LE         0x2B
#define ROP_GT         0x2C
#define ROP_GE         0x2D
#define ROP_JMP        0x30
#define ROP_JZ         0x31
#define ROP_JNZ        0x32
#define ROP_CALL       0x33
#define ROP_RET        0x35
#define ROP_RET_UNDEF  0x36
#define ROP_HALT       0x37
#define ROP_FUNCTION   0x38
#define ROP_STRICT_EQ  0x39
#define ROP_STRICT_NE  0x3A
#define ROP_TYPEOF     0x3B
#define ROP_INSTANCEOF 0x3C
#define ROP_PUSH_TRY   0x40
#define ROP_POP_TRY    0x41
#define ROP_THROW      0x42
#define ROP_NEW        0x43
#define ROP_THIS       0x44
#define ROP_CALL_WITH_THIS 0x45
#define ROP_TO_NUMBER  0x4A   /* JS-10-fix: unary plus +x */

/* Token kinds */
enum {
    RTK_EOF, RTK_IDENT, RTK_NUM, RTK_STR, RTK_HEX,
    RTK_LPAREN, RTK_RPAREN, RTK_LBRACE, RTK_RBRACE, RTK_LBRACK, RTK_RBRACK,
    RTK_SEMI, RTK_COMMA, RTK_DOT, RTK_COLON, RTK_QUESTION,
    ROP_ASSIGN, RTK_PLUS, RTK_MINUS, RTK_STAR, RTK_SLASH, RTK_PERCENT,
    RTK_INC, RTK_DEC,
    RTK_EQ, RTK_NE, RTK_LT, RTK_LE, RTK_GT, RTK_GE,
    RTK_STRICT_EQ, RTK_STRICT_NE,
    RTK_AND, RTK_OR, RTK_XOR, RTK_BNOT, RTK_LNOT,
    RTK_SHL, RTK_SHR, RTK_USHR,
    RTK_PLUSEQ, RTK_MINUSEQ, RTK_STAREQ, RTK_SLASHEQ, RTK_PERCENTEQ,
    RTK_ANDEQ, RTK_OREQ, RTK_XOREQ, RTK_SHLEQ, RTK_SHREQ, RTK_USHREQ,
    RTK_AMPAMP, RTK_PIPEPIPE,
    RTK_NULLISH,  /* ?? — recognized but falls back to || semantics */
    RTK_OPTCHAIN, /* ?. — recognized but treated like . for now */
    RTK_VAR, RTK_LET, RTK_CONST, RTK_FUNC, RTK_RETURN,
    RTK_IF, RTK_ELSE, RTK_WHILE, RTK_DO, RTK_FOR,
    RTK_BREAK, RTK_CONTINUE,
    RTK_SWITCH, RTK_CASE, RTK_DEFAULT,
    RTK_TRY, RTK_CATCH, RTK_FINALLY, RTK_THROW,
    RTK_NEW, RTK_TYPEOF, RTK_INSTANCEOF, RTK_VOID, RTK_IN, RTK_OF,
    RTK_TRUE, RTK_FALSE, RTK_NULL, RTK_UNDEF, RTK_THIS,
};

/* Lexer state — T51-fix: shrunk int (4 B) → uint16_t/int16_t (2 B) each.
 * Saves ~16 B BSS.  Values fit: repl_pos < 2048 (source), repl_ch is
 * -1..255, repl_tok is enum 0..N. */
static const char *repl_src;
static uint16_t repl_pos;
static int16_t  repl_ch;   /* -1 = EOF */
static int16_t  repl_tok;
static int32_t  repl_ival; /* number value (raw fixed24.8) — keep 4 B */
static char repl_str[REPL_MAX_STR]; /* ident/string value */

/* Compiler state */
static uint8_t *repl_buf;
static uint16_t repl_buflen;
static int16_t *repl_breaks;   /* T51-fix: was int* — 2 B vs 4 B per slot */
static uint8_t  repl_breakcnt;
static int16_t *repl_conts;
static uint8_t  repl_contcnt;

/* try-stack — 2 placeholders per try (catch_pc and end_jmp).
 * T51-repl-v2: file-scope static, no arena growth. */
static int16_t repl_try_stack[REPL_MAX_TRY_NESTING * 2];
static uint8_t  repl_try_sp;

/* switch end-jmp placeholders — 1 per switch.
 * Reuses repl_breaks for case-body break/jmp_end. */
static int16_t repl_switch_ends[REPL_MAX_SWITCH];
static uint8_t  repl_switch_sp;

/* inTypeof — set when typeof IDENT; suppresses undeclared errors. */
static uint8_t repl_in_typeof;

/* T54-repl-fix: Track the last emitted simple lvalue load, so prefix
 * (++x) and postfix (x++) can correctly DUP/INC/STORE the result back
 * to the variable.  Without this, T51-repl-v2 emitted only INC/DEC
 * which mutated the top of stack but never wrote back to the local
 * or global — making every `i++` a no-op and loops like
 * `do { s+=i; i++ } while (i<5)` infinite.
 *
 *   repl_last_lv_kind:
 *     0 = not a simple lvalue (e.g. obj.prop, arr[idx], or a complex expr)
 *     1 = LOAD_LOCAL  — slot index in repl_last_lv_idx
 *     2 = LOAD_GLOBAL — atom index in repl_last_lv_idx
 *
 * Set in repl_primary() when emitting a bare IDENT load.
 * Cleared in repl_postfix()'s `.[(` loop as soon as the lvalue is "wrapped"
 * (member access, indexing, or call).  Read and cleared in the
 * prefix/postfix INC/DEC handlers. */
static uint8_t repl_last_lv_kind = 0;
static uint8_t repl_last_lv_idx  = 0;

/* Tables — heap-allocated in repl_compile() via single arena pool.
 * Before repl_compile() runs, these are NULL.  After it returns,
 * they're free'd back to NULL. */
/* T51-fix: ReplConst uses union — num and str are mutually exclusive.
 * Saves ~32 B heap (was 8×(1+3pad+4+64pad)=8×72=576 B, now 8×(1+3pad+64)=8×68=544 B). */
typedef struct {
    uint8_t type;  /* 0 = num, 1 = str */
    union {
        int32_t num;
        char    str[REPL_MAX_STR];
    } val;
} ReplConst;
typedef struct { uint16_t pc; uint8_t argc, nlocals; uint16_t bodySize; } ReplFunc;

static char (*repl_atoms)[REPL_MAX_NAME];
static uint8_t repl_atom_count;

static ReplConst *repl_consts;
static uint8_t   repl_const_count;

static ReplFunc *repl_funcs;
static uint8_t  repl_func_count;

static char (*repl_locals)[REPL_MAX_NAME];
static uint8_t  repl_local_count;
static uint8_t  repl_is_top_level;

/* T51-fix: single arena — one malloc, one free, no fragmentation. */
static uint8_t *repl_arena = NULL;
static uint8_t  repl_buffers_allocated = 0;

static void repl_free_buffers() {
    if (!repl_buffers_allocated) return;
    free(repl_arena);
    repl_arena = NULL;
    repl_atoms    = NULL;
    repl_consts   = NULL;
    repl_funcs   = NULL;
    repl_locals   = NULL;
    repl_buf      = NULL;
    repl_breaks   = NULL;
    repl_conts    = NULL;
    repl_buffers_allocated = 0;
}

/* ---- Lexer ---- */
static void repl_nextch() {
    repl_ch = repl_src[repl_pos++];
    if (repl_ch == '\0') repl_ch = -1;
}

static void repl_skipws() {
    while (repl_ch == ' ' || repl_ch == '\t' || repl_ch == '\r' || repl_ch == '\n') repl_nextch();
}

static int repl_is_ident_start(int c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
}
static int repl_is_ident_cont(int c) {
    return repl_is_ident_start(c) || (c >= '0' && c <= '9');
}

static int repl_hex_val(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static int repl_atom(const char *s) {
    for (int i = 0; i < repl_atom_count; i++)
        if (strcmp(repl_atoms[i], s) == 0) return i + 1;
    if (repl_atom_count < REPL_MAX_ATOMS) {
        strncpy(repl_atoms[repl_atom_count], s, REPL_MAX_NAME-1);
        repl_atoms[repl_atom_count][REPL_MAX_NAME-1] = '\0';
        return ++repl_atom_count;
    }
    return 0;
}

static int repl_const_num(int32_t v) {
    for (int i = 0; i < repl_const_count; i++)
        if (repl_consts[i].type == 0 && repl_consts[i].val.num == v) return i;
    if (repl_const_count < REPL_MAX_CONSTS) {
        repl_consts[repl_const_count].type = 0;
        repl_consts[repl_const_count].val.num = v;
        return repl_const_count++;
    }
    return 0;
}

static int repl_const_str(const char *s) {
    for (int i = 0; i < repl_const_count; i++)
        if (repl_consts[i].type == 1 && strcmp(repl_consts[i].val.str, s) == 0) return i;
    if (repl_const_count < REPL_MAX_CONSTS) {
        repl_consts[repl_const_count].type = 1;
        strncpy(repl_consts[repl_const_count].val.str, s, REPL_MAX_STR-1);
        repl_consts[repl_const_count].val.str[REPL_MAX_STR-1] = '\0';
        return repl_const_count++;
    }
    return 0;
}

static int repl_local_find(const char *n) {
    for (int i = 0; i < repl_local_count; i++)
        if (strcmp(repl_locals[i], n) == 0) return i;
    return -1;
}

static int repl_local_add(const char *n) {
    if (repl_local_count < REPL_MAX_LOCALS) {
        strncpy(repl_locals[repl_local_count], n, REPL_MAX_NAME-1);
        repl_locals[repl_local_count][REPL_MAX_NAME-1] = '\0';
        return repl_local_count++;
    }
    return -1;
}

static void repl_next_token() {
    repl_skipws();
    repl_tok = RTK_EOF;
    if (repl_ch < 0) return;

    /* comments — line and block */
    if (repl_ch == '/' && repl_src[repl_pos] == '/') {
        while (repl_ch >= 0 && repl_ch != '\n') repl_nextch();
        repl_next_token();
        return;
    }
    if (repl_ch == '/' && repl_src[repl_pos] == '*') {
        repl_nextch(); repl_nextch();  /* consume / * */
        while (repl_ch >= 0) {
            if (repl_ch == '*' && repl_src[repl_pos] == '/') {
                repl_nextch(); repl_nextch();
                break;
            }
            repl_nextch();
        }
        repl_next_token();
        return;
    }

    /* identifier / keyword */
    if (repl_is_ident_start(repl_ch)) {
        int i = 0;
        while (repl_is_ident_cont(repl_ch)) {
            if (i < REPL_MAX_STR-1) repl_str[i++] = (char)repl_ch;
            repl_nextch();
        }
        repl_str[i] = '\0';
        /* keywords — return via if/else chain */
        if      (!strcmp(repl_str,"var"))         repl_tok=RTK_VAR;
        else if (!strcmp(repl_str,"let"))         repl_tok=RTK_LET;
        else if (!strcmp(repl_str,"const"))       repl_tok=RTK_CONST;
        else if (!strcmp(repl_str,"function"))    repl_tok=RTK_FUNC;
        else if (!strcmp(repl_str,"return"))      repl_tok=RTK_RETURN;
        else if (!strcmp(repl_str,"if"))          repl_tok=RTK_IF;
        else if (!strcmp(repl_str,"else"))        repl_tok=RTK_ELSE;
        else if (!strcmp(repl_str,"while"))       repl_tok=RTK_WHILE;
        else if (!strcmp(repl_str,"do"))          repl_tok=RTK_DO;
        else if (!strcmp(repl_str,"for"))         repl_tok=RTK_FOR;
        else if (!strcmp(repl_str,"break"))       repl_tok=RTK_BREAK;
        else if (!strcmp(repl_str,"continue"))    repl_tok=RTK_CONTINUE;
        else if (!strcmp(repl_str,"switch"))      repl_tok=RTK_SWITCH;
        else if (!strcmp(repl_str,"case"))        repl_tok=RTK_CASE;
        else if (!strcmp(repl_str,"default"))     repl_tok=RTK_DEFAULT;
        else if (!strcmp(repl_str,"try"))         repl_tok=RTK_TRY;
        else if (!strcmp(repl_str,"catch"))       repl_tok=RTK_CATCH;
        else if (!strcmp(repl_str,"finally"))     repl_tok=RTK_FINALLY;
        else if (!strcmp(repl_str,"throw"))       repl_tok=RTK_THROW;
        else if (!strcmp(repl_str,"new"))         repl_tok=RTK_NEW;
        else if (!strcmp(repl_str,"typeof"))      repl_tok=RTK_TYPEOF;
        else if (!strcmp(repl_str,"instanceof"))  repl_tok=RTK_INSTANCEOF;
        else if (!strcmp(repl_str,"void"))        repl_tok=RTK_VOID;
        else if (!strcmp(repl_str,"in"))          repl_tok=RTK_IN;
        else if (!strcmp(repl_str,"of"))          repl_tok=RTK_OF;
        else if (!strcmp(repl_str,"true"))        repl_tok=RTK_TRUE;
        else if (!strcmp(repl_str,"false"))       repl_tok=RTK_FALSE;
        else if (!strcmp(repl_str,"null"))        repl_tok=RTK_NULL;
        else if (!strcmp(repl_str,"undefined"))   repl_tok=RTK_UNDEF;
        else if (!strcmp(repl_str,"this"))         repl_tok=RTK_THIS;
        else repl_tok=RTK_IDENT;
        return;
    }

    /* number — decimal or hex */
    if (repl_ch >= '0' && repl_ch <= '9') {
        /* hex prefix 0x / 0X */
        if (repl_ch == '0' && (repl_src[repl_pos] == 'x' || repl_src[repl_pos] == 'X')) {
            repl_nextch(); repl_nextch();  /* consume 0 and x */
            int32_t v = 0;
            int hv = repl_hex_val(repl_ch);
            if (hv < 0) {
                /* just "0x" with no hex digit — treat as 0 */
                repl_ival = 0;
                repl_tok = RTK_NUM;
                return;
            }
            while (hv >= 0) {
                v = (v << 4) | hv;
                repl_nextch();
                hv = repl_hex_val(repl_ch);
            }
            repl_ival = v;  /* VM applies << 8 for fixed24.8 in repl_emit_int */
            repl_tok = RTK_HEX;
            return;
        }
        int v = 0;
        while (repl_ch >= '0' && repl_ch <= '9') {
            v = v * 10 + (repl_ch - '0');
            repl_nextch();
        }
        repl_ival = v; /* integer value (VM applies << 8 for fixed24.8) */
        repl_tok = RTK_NUM;
        return;
    }

    /* string */
    if (repl_ch == '"' || repl_ch == '\'') {
        int q = repl_ch; repl_nextch();
        int i = 0;
        while (repl_ch >= 0 && repl_ch != q) {
            if (repl_ch == '\\' && repl_src[repl_pos] != '\0') {
                repl_nextch();
                char e = (char)repl_ch;
                if (e=='n') e='\n'; else if (e=='t') e='\t'; else if (e=='r') e='\r';
                else if (e=='\\') e='\\'; else if (e=='\'') e='\''; else if (e=='"') e='"';
                else if (e=='0') e='\0';
                else if (e=='b') e='\b';      /* T51-repl-v2: backspace */
                else if (e=='f') e='\f';      /* T51-repl-v2: form feed */
                else if (e=='v') e='\v';      /* T51-repl-v2: vertical tab */
                else if (e=='x' && repl_src[repl_pos] && repl_src[repl_pos+1]) {
                    /* parse two hex digits */
                    char h1 = repl_src[repl_pos], h2 = repl_src[repl_pos+1];
                    int hv = 0;
                    if (h1 >= '0' && h1 <= '9') hv = (h1-'0')<<4;
                    else if (h1 >= 'a' && h1 <= 'f') hv = (h1-'a'+10)<<4;
                    else if (h1 >= 'A' && h1 <= 'F') hv = (h1-'A'+10)<<4;
                    if (h2 >= '0' && h2 <= '9') hv |= (h2-'0');
                    else if (h2 >= 'a' && h2 <= 'f') hv |= (h2-'a'+10);
                    else if (h2 >= 'A' && h2 <= 'F') hv |= (h2-'A'+10);
                    e = (char)hv;
                    repl_nextch();  /* consume first hex digit */
                    repl_nextch();  /* T51-fix: consume second hex digit too. */
                } else if (e=='u' && repl_src[repl_pos] && repl_src[repl_pos+1]
                                     && repl_src[repl_pos+2] && repl_src[repl_pos+3]) {
                    /* T51-repl-v2: \uNNNN unicode escape.
                     * Encode as CP1251 if in Cyrillic range, else '?'.
                     * (Matches the device font — see cp1251Encode in compiler.js.) */
                    int hv = 0;
                    for (int k = 0; k < 4; k++) {
                        int d = repl_hex_val(repl_src[repl_pos+k]);
                        if (d < 0) { hv = -1; break; }
                        hv = (hv << 4) | d;
                    }
                    if (hv < 0) {
                        e = '?';
                    } else if (hv >= 0x0410 && hv <= 0x044F) {
                        e = (char)(hv - 0x350);  /* Cyrillic А-я → 0xC0-0xFF */
                    } else if (hv == 0x0401) {
                        e = (char)0xA8;          /* Ё */
                    } else if (hv == 0x0451) {
                        e = (char)0xB8;          /* ё */
                    } else if (hv >= 0x20 && hv <= 0x7E) {
                        e = (char)hv;            /* ASCII printable */
                    } else if (hv >= 0xA0 && hv <= 0xFF) {
                        e = (char)hv;            /* Latin-1 supplement */
                    } else {
                        e = '?';
                    }
                    repl_nextch(); repl_nextch();
                    repl_nextch(); repl_nextch();  /* consume 4 hex digits */
                }
                /* \n already handled above; fallthrough default: keep e as-is
                 * for unrecognized escapes (e.g. \/ -> /, \? -> ?) */
                if (e=='/') e='/'; else if (e=='?') e='?';
                if (i < REPL_MAX_STR-1) repl_str[i++] = e;
            } else {
                if (i < REPL_MAX_STR-1) repl_str[i++] = (char)repl_ch;
            }
            repl_nextch();
        }
        repl_str[i] = '\0';
        if (repl_ch == q) repl_nextch();
        repl_tok = RTK_STR;
        return;
    }

    /* operators — check 3-char, then 2-char, then 1-char */
    int c = repl_ch; repl_nextch();
    int c2 = repl_ch;
    int c3 = (c2 >= 0) ? repl_src[repl_pos] : -1;

    /* 3-char operators: >>>, <<=, >>=, >>>= */
    if (c=='<' && c2=='<' && c3=='=') { repl_tok=RTK_SHLEQ; repl_nextch(); repl_nextch(); return; }
    if (c=='>' && c2=='>' && c3=='=') { repl_tok=RTK_SHREQ; repl_nextch(); repl_nextch(); return; }
    if (c=='>' && c2=='>' && c3=='>') {
        repl_nextch();  /* consume 3rd '>' */
        if (repl_src[repl_pos-1+1] == '=') { /* the char after >>> is '=' */
            /* Actually we already consumed '>>>' (3 chars). Check next char. */
        }
        /* peek: repl_ch now is char after the 3rd '>' */
        if (repl_ch == '=') { repl_tok=RTK_USHREQ; repl_nextch(); }
        else { repl_tok=RTK_USHR; }
        return;
    }

    /* 2-char operators */
    if (c=='='&&c2=='='&&c3=='=') { repl_tok=RTK_STRICT_EQ; repl_nextch(); repl_nextch(); return; }
    if (c=='!'&&c2=='='&&c3=='=') { repl_tok=RTK_STRICT_NE; repl_nextch(); repl_nextch(); return; }
    if (c=='+'&&c2=='+'){repl_tok=RTK_INC;repl_nextch();return;}
    if (c=='-'&&c2=='-'){repl_tok=RTK_DEC;repl_nextch();return;}
    if (c=='='&&c2=='='){repl_tok=RTK_EQ;repl_nextch();return;}
    if (c=='!'&&c2=='='){repl_tok=RTK_NE;repl_nextch();return;}
    if (c=='<'&&c2=='='){repl_tok=RTK_LE;repl_nextch();return;}
    if (c=='>'&&c2=='='){repl_tok=RTK_GE;repl_nextch();return;}
    if (c=='<'&&c2=='<'){repl_tok=RTK_SHL;repl_nextch();return;}
    if (c=='>'&&c2=='>'){repl_tok=RTK_SHR;repl_nextch();return;}
    if (c=='&'&&c2=='&'){repl_tok=RTK_AMPAMP;repl_nextch();return;}
    if (c=='|'&&c2=='|'){repl_tok=RTK_PIPEPIPE;repl_nextch();return;}
    if (c=='?'&&c2=='?'){repl_tok=RTK_NULLISH;repl_nextch();return;}
    if (c=='?'&&c2=='.'){repl_tok=RTK_OPTCHAIN;repl_nextch();return;}
    if (c=='+'&&c2=='='){repl_tok=RTK_PLUSEQ;repl_nextch();return;}
    if (c=='-'&&c2=='='){repl_tok=RTK_MINUSEQ;repl_nextch();return;}
    if (c=='*'&&c2=='='){repl_tok=RTK_STAREQ;repl_nextch();return;}
    if (c=='/'&&c2=='='){repl_tok=RTK_SLASHEQ;repl_nextch();return;}
    if (c=='%'&&c2=='='){repl_tok=RTK_PERCENTEQ;repl_nextch();return;}
    if (c=='&'&&c2=='='){repl_tok=RTK_ANDEQ;repl_nextch();return;}
    if (c=='|'&&c2=='='){repl_tok=RTK_OREQ;repl_nextch();return;}
    if (c=='^'&&c2=='='){repl_tok=RTK_XOREQ;repl_nextch();return;}

    /* 1-char */
    switch(c){
        case '(':repl_tok=RTK_LPAREN;break; case ')':repl_tok=RTK_RPAREN;break;
        case '{':repl_tok=RTK_LBRACE;break; case '}':repl_tok=RTK_RBRACE;break;
        case '[':repl_tok=RTK_LBRACK;break; case ']':repl_tok=RTK_RBRACK;break;
        case ';':repl_tok=RTK_SEMI;break; case ',':repl_tok=RTK_COMMA;break;
        case '.':repl_tok=RTK_DOT;break; case ':':repl_tok=RTK_COLON;break;
        case '?':repl_tok=RTK_QUESTION;break;
        case '=':repl_tok=ROP_ASSIGN;break; case '+':repl_tok=RTK_PLUS;break;
        case '-':repl_tok=RTK_MINUS;break; case '*':repl_tok=RTK_STAR;break;
        case '/':repl_tok=RTK_SLASH;break; case '%':repl_tok=RTK_PERCENT;break;
        case '<':repl_tok=RTK_LT;break; case '>':repl_tok=RTK_GT;break;
        case '!':repl_tok=RTK_LNOT;break; case '&':repl_tok=RTK_AND;break;
        case '|':repl_tok=RTK_OR;break; case '^':repl_tok=RTK_XOR;break;
        case '~':repl_tok=RTK_BNOT;break;
        default:repl_tok=RTK_EOF;break;
    }
}

/* ---- Emitter ---- */
static void repl_emit(uint8_t b) {
    if (repl_buflen < REPL_BC_MAX) repl_buf[repl_buflen++] = b;
}

static void repl_emit_u16(uint16_t v) {
    repl_emit(v & 0xFF); repl_emit((v >> 8) & 0xFF);
}

static int repl_placeholder() {
    int p = repl_buflen;
    repl_emit(0); repl_emit(0);
    return p;
}

static void repl_patch(int at, int to) {
    int d = to - (at + 2);
    repl_buf[at] = d & 0xFF;
    repl_buf[at+1] = (d >> 8) & 0xFF;
}

static void repl_emit_int(int32_t v) {
    /* v is integer value. VM applies << 8 for fixed24.8. */
    if (v >= 0 && v <= 255) { repl_emit(ROP_INT8); repl_emit((uint8_t)v); }
    else if (v >= -32768 && v <= 32767) { repl_emit(ROP_INT16); repl_emit_u16((uint16_t)v); }
    else { repl_emit(ROP_CONST); repl_emit(repl_const_num(v << 8)); /* const stores raw fixed */ }
}

/* ---- Parser ---- */
static void repl_expr();
static void repl_assign();
static void repl_stmt();
static void repl_block();
static void repl_ternary();

static void repl_primary() {
    switch (repl_tok) {
        case RTK_NUM:
        case RTK_HEX:
            repl_emit_int(repl_ival); repl_next_token(); break;
        case RTK_STR:
            repl_emit(ROP_CONST); repl_emit(repl_const_str(repl_str)); repl_next_token(); break;
        case RTK_TRUE: repl_emit(ROP_TRUE); repl_next_token(); break;
        case RTK_FALSE: repl_emit(ROP_FALSE); repl_next_token(); break;
        case RTK_NULL: repl_emit(ROP_NULL); repl_next_token(); break;
        case RTK_UNDEF: repl_emit(ROP_UNDEF); repl_next_token(); break;
        case RTK_THIS: repl_emit(ROP_THIS); repl_next_token(); break;
        case RTK_IDENT: {
                int s = repl_local_find(repl_str);
                if (s >= 0) {
                    repl_emit(ROP_LOAD_LOCAL); repl_emit((uint8_t)s);
                    /* T54-repl-fix: bare local lvalue — eligible for ++/-- store-back. */
                    repl_last_lv_kind = 1;
                    repl_last_lv_idx  = (uint8_t)s;
                } else {
                    /* JS-11-fix: typeof undeclared_var → "undefined" at runtime.
                     * Set repl_in_typeof in parseUnary; if set, we emit
                     * LOAD_GLOBAL with atom 0 (UNDEF sentinel) followed by
                     * OP_TYPEOF which converts it.  This avoids the runtime
                     * "ReferenceError" path that the VM would otherwise emit
                     * for an unregistered atom. */
                    if (repl_in_typeof) {
                        repl_emit(ROP_UNDEF);
                        /* typeof undefined — not an assignable lvalue. */
                        repl_last_lv_kind = 0;
                    } else {
                        int a = repl_atom(repl_str);
                        repl_emit(ROP_LOAD_GLOBAL); repl_emit((uint8_t)a);
                        /* T54-repl-fix: bare global lvalue — eligible for ++/-- store-back. */
                        repl_last_lv_kind = 2;
                        repl_last_lv_idx  = (uint8_t)a;
                    }
                }
                repl_next_token(); break;
            }
        case RTK_LPAREN: repl_next_token(); repl_expr();
            if (repl_tok==RTK_RPAREN) repl_next_token(); break;
        case RTK_LBRACK: {
                repl_next_token();
                int n = 0;
                while (repl_tok != RTK_RBRACK && repl_tok != RTK_EOF) {
                    repl_expr(); n++;
                    if (repl_tok == RTK_COMMA) repl_next_token(); else break;
                }
                if (repl_tok==RTK_RBRACK) repl_next_token();
                repl_emit(ROP_NEW_ARRAY); repl_emit((uint8_t)(n > 255 ? 255 : n));
                break;
            }
        case RTK_LBRACE: {
                /* T51-repl-v2: object literals {a:1, b:2, "c":3}.
                 * Emits: NEW_OBJECT, then per pair: DUP, parseExpr(value),
                 * STORE_PROP atom, POP.  Final stack: [obj].
                 * The atom for the key is added as a side effect — counts
                 * toward the 16-atom limit. */
                repl_next_token();  /* consume '{' */
                repl_emit(ROP_NEW_OBJECT);
                while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
                    /* key: IDENT, STRING, or NUM (as ident) */
                    char key[REPL_MAX_NAME];
                    if (repl_tok == RTK_IDENT || repl_tok == RTK_STR) {
                        strncpy(key, repl_str, REPL_MAX_NAME-1);
                        key[REPL_MAX_NAME-1] = '\0';
                        repl_next_token();
                    } else if (repl_tok == RTK_NUM || repl_tok == RTK_HEX) {
                        /* numeric key — convert to decimal string */
                        snprintf(key, sizeof(key), "%d", (int)repl_ival);
                        repl_next_token();
                    } else {
                        /* unexpected — bail */
                        return;
                    }
                    int ka = repl_atom(key);
                    if (repl_tok != RTK_COLON) return;
                    repl_next_token();  /* consume ':' */
                    repl_emit(ROP_DUP);
                    repl_assign();
                    repl_emit(ROP_STORE_PROP); repl_emit((uint8_t)ka);
                    repl_emit(ROP_POP);
                    if (repl_tok == RTK_COMMA) repl_next_token(); else break;
                }
                if (repl_tok==RTK_RBRACE) repl_next_token();
                break;
            }
        case RTK_FUNC: {
                /* T51-repl-v2: function expression (anonymous or named).
                 * Same encoding as function statement, but the result
                 * (the function value) is left on the stack.
                 * Limitation: only anonymous function expressions are
                 * supported; named function expressions treat the name
                 * as an atom but don't bind it in a closure scope. */
                repl_next_token();  /* consume 'function' */
                if (repl_tok == RTK_IDENT) {
                    /* named function expression — consume name, no binding */
                    repl_next_token();
                }
                if (repl_tok==RTK_LPAREN) repl_next_token();
                int saved_lc = repl_local_count;
                int saved_tl = repl_is_top_level;
                repl_local_count = 0;
                repl_is_top_level = 0;
                int argc = 0;
                while (repl_tok == RTK_IDENT) {
                    repl_local_add(repl_str); argc++;
                    repl_next_token();
                    if (repl_tok==RTK_COMMA) repl_next_token(); else break;
                }
                if (repl_tok==RTK_RPAREN) repl_next_token();
                if (repl_func_count < REPL_MAX_FUNCS) {
                    int fi = repl_func_count++;
                    repl_funcs[fi].argc = (uint8_t)argc;
                    int body_start = repl_buflen;
                    repl_block();
                    repl_emit(ROP_RET_UNDEF);
                    int body_len = repl_buflen - body_start;
                    uint8_t *body_save = (uint8_t*)malloc((size_t)body_len);
                    if (!body_save) {
                        repl_func_count--;
                        repl_local_count = (uint8_t)saved_lc;
                        repl_is_top_level = (uint8_t)saved_tl;
                        return;
                    }
                    memcpy(body_save, repl_buf + body_start, body_len);
                    repl_buflen = (uint16_t)body_start;
                    repl_emit(ROP_FUNCTION); repl_emit((uint8_t)fi);
                    repl_funcs[fi].pc = repl_buflen;
                    repl_funcs[fi].nlocals = repl_local_count;
                    repl_funcs[fi].bodySize = (uint16_t)body_len;
                    memcpy(repl_buf + repl_buflen, body_save, body_len);
                    repl_buflen += body_len;
                    free(body_save);
                } else {
                    repl_block();
                }
                repl_local_count = (uint8_t)saved_lc;
                repl_is_top_level = (uint8_t)saved_tl;
                break;
            }
        default: break;
    }
}

static void repl_postfix() {
    repl_primary();
    while (1) {
        if (repl_tok == RTK_DOT || repl_tok == RTK_OPTCHAIN) {
            /* T54-repl-fix: member access wraps the lvalue → can't store back. */
            repl_last_lv_kind = 0;
            repl_next_token();
            if (repl_tok == RTK_IDENT) {
                repl_emit(ROP_LOAD_PROP); repl_emit((uint8_t)repl_atom(repl_str));
                repl_next_token();
            }
        } else if (repl_tok == RTK_LBRACK) {
            /* T54-repl-fix: index access wraps the lvalue → can't store back. */
            repl_last_lv_kind = 0;
            repl_next_token(); repl_expr();
            if (repl_tok==RTK_RBRACK) repl_next_token();
            repl_emit(ROP_LOAD_INDEX);
        } else if (repl_tok == RTK_LPAREN) {
            /* T54-repl-fix: call wraps the lvalue → not an assignable lvalue. */
            repl_last_lv_kind = 0;
            repl_next_token();
            int argc = 0;
            while (repl_tok != RTK_RPAREN && repl_tok != RTK_EOF) {
                repl_assign(); argc++;
                if (repl_tok == RTK_COMMA) repl_next_token(); else break;
            }
            if (repl_tok==RTK_RPAREN) repl_next_token();
            repl_emit(ROP_CALL); repl_emit((uint8_t)(argc > 16 ? 16 : argc));
        } else break;
    }
    /* T54-repl-fix: Postfix ++/--
     * For bare IDENT lvalues (LOAD_LOCAL/LOAD_GLOBAL of IDENT), we emit:
     *    DUP, INC/DEC, STORE_LOCAL/GLOBAL, POP, (old value remains on stack)
     * The trailing POP discards the new value that STORE_* leaves on top
     * (STORE_* reads TOP without popping — see OP_STORE_GLOBAL in vm.h).
     * Stack trace for `i++` (postfix, with i starting at 5):
     *   LOAD i  → [5]
     *   DUP     → [5, 5]
     *   INC     → [5, 6]
     *   STORE_G → stores TOP (6) to i, stack unchanged: [5, 6]
     *   POP     → [5]   ← old value is the expression result ✓
     *   (caller's statement-level POP then removes the 5)
     * For LOAD_PROP/LOAD_INDEX, fall back to plain INC/DEC (no store-back). */
    if (repl_tok == RTK_INC || repl_tok == RTK_DEC) {
        int is_inc = (repl_tok == RTK_INC);
        repl_next_token();
        if (repl_last_lv_kind == 1) {
            repl_emit(ROP_DUP);
            repl_emit(is_inc ? ROP_INC : ROP_DEC);
            repl_emit(ROP_STORE_LOCAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else if (repl_last_lv_kind == 2) {
            repl_emit(ROP_DUP);
            repl_emit(is_inc ? ROP_INC : ROP_DEC);
            repl_emit(ROP_STORE_GLOBAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else {
            /* Property/index lvalue — no store-back.  Existing T51-repl-v2
             * behavior preserved as a documented limitation. */
            repl_emit(is_inc ? ROP_INC : ROP_DEC);
        }
        repl_last_lv_kind = 0;  /* consumed */
    }
}

static void repl_unary() {
    if (repl_tok == RTK_MINUS) { repl_next_token(); repl_unary(); repl_emit(ROP_NEG); }
    else if (repl_tok == RTK_PLUS)  { repl_next_token(); repl_unary(); repl_emit(ROP_TO_NUMBER); }  /* JS-10-fix */
    else if (repl_tok == RTK_LNOT)  { repl_next_token(); repl_unary(); repl_emit(ROP_LNOT); }
    else if (repl_tok == RTK_BNOT)  { repl_next_token(); repl_unary(); repl_emit(ROP_BNOT); }
    /* T54-repl-fix: Prefix ++/--x
     * The recursive repl_unary() parses the operand.  If the operand
     * was a bare IDENT (LOAD_LOCAL/LOAD_GLOBAL), repl_primary set
     * repl_last_lv_kind=1/2 and repl_postfix's `.[(` loop did NOT
     * clear it (since no `.[(` followed).  In that case we emit:
     *    INC, DUP, STORE_LOCAL/GLOBAL, POP, (new value remains on stack)
     * The trailing POP discards the new value that STORE_* leaves on top
     * (STORE_* reads TOP without popping — see OP_STORE_GLOBAL in vm.h).
     * Stack trace for `++i` (prefix, with i starting at 5):
     *   LOAD i  → [5]
     *   INC     → [6]
     *   DUP     → [6, 6]
     *   STORE_G → stores TOP (6) to i, stack unchanged: [6, 6]
     *   POP     → [6]   ← new value is the expression result ✓
     * For LOAD_PROP/LOAD_INDEX, fall back to plain INC/DEC (no store). */
    else if (repl_tok == RTK_INC) {
        repl_next_token();
        repl_last_lv_kind = 0;  /* clear stale — only the inner call's IDENT counts */
        repl_unary();
        if (repl_last_lv_kind == 1) {
            repl_emit(ROP_INC);
            repl_emit(ROP_DUP);
            repl_emit(ROP_STORE_LOCAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else if (repl_last_lv_kind == 2) {
            repl_emit(ROP_INC);
            repl_emit(ROP_DUP);
            repl_emit(ROP_STORE_GLOBAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else {
            repl_emit(ROP_INC);
        }
        repl_last_lv_kind = 0;  /* consumed */
    }
    else if (repl_tok == RTK_DEC) {
        repl_next_token();
        repl_last_lv_kind = 0;
        repl_unary();
        if (repl_last_lv_kind == 1) {
            repl_emit(ROP_DEC);
            repl_emit(ROP_DUP);
            repl_emit(ROP_STORE_LOCAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else if (repl_last_lv_kind == 2) {
            repl_emit(ROP_DEC);
            repl_emit(ROP_DUP);
            repl_emit(ROP_STORE_GLOBAL); repl_emit(repl_last_lv_idx);
            repl_emit(ROP_POP);
        } else {
            repl_emit(ROP_DEC);
        }
        repl_last_lv_kind = 0;
    }
    else if (repl_tok == RTK_VOID)  { repl_next_token(); repl_unary(); repl_emit(ROP_POP); repl_emit(ROP_UNDEF); }
    else if (repl_tok == RTK_TYPEOF) {
        repl_next_token();
        uint8_t saved = repl_in_typeof;
        repl_in_typeof = 1;
        repl_unary();
        repl_in_typeof = saved;
        repl_emit(ROP_TYPEOF);
    }
    else if (repl_tok == RTK_NEW) {
        /* T51-repl-v2: new Ctor(args) — simplified vs compiler.js.
         * We don't special-case Object/Array (user can use {} and []).
         * Stack: ctor, arg1, ..., argN → OP_NEW argc → new obj. */
        repl_next_token();  /* consume 'new' */
        repl_postfix();  /* parse constructor (IDENT) — but stop at LPAREN */
        int argc = 0;
        if (repl_tok == RTK_LPAREN) {
            repl_next_token();
            while (repl_tok != RTK_RPAREN && repl_tok != RTK_EOF) {
                repl_assign(); argc++;
                if (repl_tok == RTK_COMMA) repl_next_token(); else break;
            }
            if (repl_tok==RTK_RPAREN) repl_next_token();
        }
        repl_emit(ROP_NEW); repl_emit((uint8_t)(argc > 16 ? 16 : argc));
    }
    else repl_postfix();
}

static int repl_binop_prec(int t) {
    switch(t){
        case RTK_STAR:case RTK_SLASH:case RTK_PERCENT:return 5;
        case RTK_PLUS:case RTK_MINUS:return 4;
        case RTK_SHL:case RTK_SHR:case RTK_USHR:return 3;
        case RTK_AND:case RTK_OR:case RTK_XOR:
        case RTK_LT:case RTK_LE:case RTK_GT:case RTK_GE:
        case RTK_EQ:case RTK_NE:case RTK_STRICT_EQ:case RTK_STRICT_NE:
        case RTK_INSTANCEOF:case RTK_IN:return 2;
        case RTK_AMPAMP:return 1;
        case RTK_PIPEPIPE:return 0;
        case RTK_NULLISH:return 0;  /* ?? — same precedence as || */
        default:return -1000;
    }
}

static void repl_binop_emit(int t) {
    switch(t){
        case RTK_PLUS:repl_emit(ROP_ADD);break;
        case RTK_MINUS:repl_emit(ROP_SUB);break;
        case RTK_STAR:repl_emit(ROP_MUL);break;
        case RTK_SLASH:repl_emit(ROP_DIV);break;
        case RTK_PERCENT:repl_emit(ROP_MOD);break;
        case RTK_LT:repl_emit(ROP_LT);break;
        case RTK_LE:repl_emit(ROP_LE);break;
        case RTK_GT:repl_emit(ROP_GT);break;
        case RTK_GE:repl_emit(ROP_GE);break;
        case RTK_EQ:repl_emit(ROP_EQ);break;
        case RTK_NE:repl_emit(ROP_NE);break;
        case RTK_STRICT_EQ:repl_emit(ROP_STRICT_EQ);break;
        case RTK_STRICT_NE:repl_emit(ROP_STRICT_NE);break;
        case RTK_AND:repl_emit(ROP_AND);break;
        case RTK_OR:repl_emit(ROP_OR);break;
        case RTK_XOR:repl_emit(ROP_XOR);break;
        case RTK_SHL:repl_emit(ROP_SHL);break;
        case RTK_SHR:repl_emit(ROP_SHR);break;
        case RTK_USHR:repl_emit(ROP_USHR);break;
        case RTK_INSTANCEOF:repl_emit(ROP_INSTANCEOF);break;
        /* RTK_IN — not emitted at runtime; for-in is unsupported in repl.
         * It's parsed for error reporting only. */
    }
}

static void repl_binary(int min_prec) {
    repl_unary();
    while (1) {
        int t = repl_tok;
        int p = repl_binop_prec(t);
        if (p < min_prec) break;
        if (t == RTK_AMPAMP || t == RTK_PIPEPIPE || t == RTK_NULLISH) {
            repl_next_token();
            repl_emit(ROP_DUP);
            repl_emit(t == RTK_AMPAMP ? ROP_JZ : ROP_JNZ);
            int jmp = repl_placeholder();
            repl_emit(ROP_POP);
            repl_binary(p + 1);
            repl_patch(jmp, repl_buflen);
        } else {
            repl_next_token();
            repl_binary(p + 1);
            repl_binop_emit(t);
        }
    }
}

/* T51-repl-v2: ternary cond ? a : b — handles right-assoc nesting. */
static void repl_ternary() {
    repl_binary(-100);
    while (repl_tok == RTK_QUESTION) {
        repl_next_token();
        repl_emit(ROP_JZ);
        int jelse = repl_placeholder();
        repl_assign();   /* then-branch — full assign-level */
        if (repl_tok == RTK_COLON) {
            repl_next_token();
            repl_emit(ROP_JMP);
            int jend = repl_placeholder();
            repl_patch(jelse, repl_buflen);
            repl_assign();  /* else-branch */
            repl_patch(jend, repl_buflen);
        } else {
            /* Missing ':' — leave undefined.  Patch jelse to here. */
            repl_patch(jelse, repl_buflen);
            repl_emit(ROP_UNDEF);
        }
    }
}

static void repl_expr() {
    /* T51-repl-v2: comma operator at the lowest precedence.
     * a, b evaluates a (POP), evaluates b, leaves b on stack. */
    repl_ternary();
    while (repl_tok == RTK_COMMA) {
        repl_next_token();
        repl_emit(ROP_POP);
        repl_ternary();
    }
}

/* Assignment — handle IDENT = expr, IDENT op= expr, and member assignments
 * (a.b = expr, a[i] = expr, this.x = expr).
 * T51-repl-v2: extended with all compound bitwise assignments and
 * member/index assignment via a backtracking approach.
 *
 * Strategy: tentatively parse the LHS as a ternary expression, leaving
 * LOAD ops on the stack.  If after the LHS we see an assignment operator,
 * save state, roll back the bytecode, and re-parse the LHS in "lvalue
 * mode" — for the final member/index access, emit STORE_PROP / STORE_INDEX
 * instead of LOAD_PROP / LOAD_INDEX.
 *
 * Compound assignment to a member (a.b += c) is supported via:
 *   LOAD a, DUP, LOAD_PROP b, parse RHS, BINOP, STORE_PROP b
 * This leaves [val] on the stack as required.  Compound assignment to
 * an index (a[i] += c) is NOT supported (would require saving the index);
 * use `a[i] = a[i] + c` instead. */
static void repl_assign() {
    /* Fast path: IDENT followed by assignment — no member access. */
    if (repl_tok == RTK_IDENT) {
        char name[REPL_MAX_NAME];
        strncpy(name, repl_str, REPL_MAX_NAME);
        name[REPL_MAX_NAME-1] = '\0';
        int save_pos = repl_pos;
        int save_ch = repl_ch;
        int save_tok = repl_tok;
        char save_str[REPL_MAX_NAME];
        strncpy(save_str, repl_str, REPL_MAX_NAME);

        repl_next_token();
        int op = repl_tok;
        if (op == ROP_ASSIGN || op == RTK_PLUSEQ || op == RTK_MINUSEQ ||
            op == RTK_STAREQ || op == RTK_SLASHEQ || op == RTK_PERCENTEQ ||
            op == RTK_ANDEQ || op == RTK_OREQ || op == RTK_XOREQ ||
            op == RTK_SHLEQ || op == RTK_SHREQ || op == RTK_USHREQ) {
            /* But only if the token after IDENT is `=` directly (no . or [).
             * If the next token is . or [, we fall through to the
             * backtracking path below. */
            repl_next_token();
            repl_assign();
            int s = repl_local_find(name);
            if (s >= 0) {
                if (op == ROP_ASSIGN) { repl_emit(ROP_STORE_LOCAL); repl_emit((uint8_t)s); }
                else {
                    repl_emit(ROP_LOAD_LOCAL); repl_emit((uint8_t)s);
                    if(op==RTK_PLUSEQ)repl_emit(ROP_ADD);
                    else if(op==RTK_MINUSEQ)repl_emit(ROP_SUB);
                    else if(op==RTK_STAREQ)repl_emit(ROP_MUL);
                    else if(op==RTK_SLASHEQ)repl_emit(ROP_DIV);
                    else if(op==RTK_PERCENTEQ)repl_emit(ROP_MOD);
                    else if(op==RTK_ANDEQ)repl_emit(ROP_AND);
                    else if(op==RTK_OREQ)repl_emit(ROP_OR);
                    else if(op==RTK_XOREQ)repl_emit(ROP_XOR);
                    else if(op==RTK_SHLEQ)repl_emit(ROP_SHL);
                    else if(op==RTK_SHREQ)repl_emit(ROP_SHR);
                    else if(op==RTK_USHREQ)repl_emit(ROP_USHR);
                    repl_emit(ROP_STORE_LOCAL); repl_emit((uint8_t)s);
                }
            } else {
                int a = repl_atom(name);
                if (op == ROP_ASSIGN) { repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)a); }
                else {
                    repl_emit(ROP_LOAD_GLOBAL); repl_emit((uint8_t)a);
                    if(op==RTK_PLUSEQ)repl_emit(ROP_ADD);
                    else if(op==RTK_MINUSEQ)repl_emit(ROP_SUB);
                    else if(op==RTK_STAREQ)repl_emit(ROP_MUL);
                    else if(op==RTK_SLASHEQ)repl_emit(ROP_DIV);
                    else if(op==RTK_PERCENTEQ)repl_emit(ROP_MOD);
                    else if(op==RTK_ANDEQ)repl_emit(ROP_AND);
                    else if(op==RTK_OREQ)repl_emit(ROP_OR);
                    else if(op==RTK_XOREQ)repl_emit(ROP_XOR);
                    else if(op==RTK_SHLEQ)repl_emit(ROP_SHL);
                    else if(op==RTK_SHREQ)repl_emit(ROP_SHR);
                    else if(op==RTK_USHREQ)repl_emit(ROP_USHR);
                    repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)a);
                }
            }
            return;
        }
        /* Not assignment — restore lexer state */
        repl_pos = save_pos;
        repl_ch = save_ch;
        repl_tok = save_tok;
        strncpy(repl_str, save_str, REPL_MAX_NAME);
    }

    /* Slow path: tentatively parse the LHS as an expression.  If `=`
     * follows, backtrack and re-parse with STORE emission. */
    if (repl_tok == RTK_IDENT || repl_tok == RTK_THIS) {
        /* Save full lexer + bytecode state for backtracking */
        int save_pos = repl_pos;
        int save_ch = repl_ch;
        int save_tok = repl_tok;
        char save_str[REPL_MAX_NAME];
        strncpy(save_str, repl_str, REPL_MAX_NAME);
        int save_buflen = repl_buflen;
        int save_atom_count = repl_atom_count;
        int save_in_typeof = repl_in_typeof;

        /* Tentatively parse the LHS expression.  This emits LOAD ops
         * (LOAD_LOCAL/GLOBAL/THIS, LOAD_PROP, LOAD_INDEX) and may add
         * atoms (idempotent — re-parse will find existing, not dup). */
        repl_ternary();

        int op = repl_tok;
        int is_assign = (op == ROP_ASSIGN || op == RTK_PLUSEQ || op == RTK_MINUSEQ ||
                         op == RTK_STAREQ || op == RTK_SLASHEQ || op == RTK_PERCENTEQ ||
                         op == RTK_ANDEQ || op == RTK_OREQ || op == RTK_XOREQ ||
                         op == RTK_SHLEQ || op == RTK_SHREQ || op == RTK_USHREQ);
        if (!is_assign) {
            /* Not an assignment — leave the LHS expression result on the
             * stack and return (the caller will handle further parsing). */
            return;
        }

        /* Member/index assignment detected.  Roll back and re-parse. */
        repl_pos = (uint16_t)save_pos;
        repl_ch = (int16_t)save_ch;
        repl_tok = (int16_t)save_tok;
        strncpy(repl_str, save_str, REPL_MAX_NAME);
        repl_buflen = (uint16_t)save_buflen;
        repl_atom_count = (uint8_t)save_atom_count;
        repl_in_typeof = (uint8_t)save_in_typeof;

        /* Re-parse base: this or IDENT */
        if (repl_tok == RTK_THIS) {
            repl_emit(ROP_THIS);
            repl_next_token();
        } else {
            char name[REPL_MAX_NAME];
            strncpy(name, repl_str, REPL_MAX_NAME);
            name[REPL_MAX_NAME-1] = '\0';
            repl_next_token();
            int s = repl_local_find(name);
            if (s >= 0) { repl_emit(ROP_LOAD_LOCAL); repl_emit((uint8_t)s); }
            else { repl_emit(ROP_LOAD_GLOBAL); repl_emit((uint8_t)repl_atom(name)); }
        }

        /* Walk the member/index chain.  Each step but the last emits
         * LOAD_PROP / LOAD_INDEX.  The last step (just before `=`) emits
         * STORE_PROP / STORE_INDEX instead. */
        while (repl_tok == RTK_DOT || repl_tok == RTK_OPTCHAIN ||
               repl_tok == RTK_LBRACK) {
            if (repl_tok == RTK_DOT || repl_tok == RTK_OPTCHAIN) {
                int is_opt = (repl_tok == RTK_OPTCHAIN);
                (void)is_opt;  /* opt chain not yet handled — treat as . */
                repl_next_token();  /* consume . */
                if (repl_tok != RTK_IDENT) return;
                int patom = repl_atom(repl_str);
                repl_next_token();  /* consume ident */
                if (repl_tok == op) {
                    /* Final member access — assignment target. */
                    if (op == ROP_ASSIGN) {
                        repl_next_token();  /* consume = */
                        repl_assign();  /* RHS */
                        repl_emit(ROP_STORE_PROP); repl_emit((uint8_t)patom);
                    } else {
                        /* Compound: a.b op= c  ->  a.b = a.b op c
                         * Stack: [obj]. DUP, LOAD_PROP b, parse RHS, BINOP,
                         * STORE_PROP b.  STORE_PROP leaves the new value. */
                        repl_emit(ROP_DUP);
                        repl_emit(ROP_LOAD_PROP); repl_emit((uint8_t)patom);
                        repl_next_token();  /* consume op= */
                        repl_assign();  /* RHS */
                        if(op==RTK_PLUSEQ)repl_emit(ROP_ADD);
                        else if(op==RTK_MINUSEQ)repl_emit(ROP_SUB);
                        else if(op==RTK_STAREQ)repl_emit(ROP_MUL);
                        else if(op==RTK_SLASHEQ)repl_emit(ROP_DIV);
                        else if(op==RTK_PERCENTEQ)repl_emit(ROP_MOD);
                        else if(op==RTK_ANDEQ)repl_emit(ROP_AND);
                        else if(op==RTK_OREQ)repl_emit(ROP_OR);
                        else if(op==RTK_XOREQ)repl_emit(ROP_XOR);
                        else if(op==RTK_SHLEQ)repl_emit(ROP_SHL);
                        else if(op==RTK_SHREQ)repl_emit(ROP_SHR);
                        else if(op==RTK_USHREQ)repl_emit(ROP_USHR);
                        repl_emit(ROP_STORE_PROP); repl_emit((uint8_t)patom);
                    }
                    return;
                }
                /* Not the target — continue chain */
                repl_emit(ROP_LOAD_PROP); repl_emit((uint8_t)patom);
            } else if (repl_tok == RTK_LBRACK) {
                /* Index access.  Parse the index expression. */
                /* For STORE_INDEX we need the index on the stack.
                 * But we also need it on the stack for LOAD_INDEX.
                 * So: parse index expression, then either LOAD_INDEX or STORE_INDEX.
                 * For compound a[i] op= c, we'd need to save the index for reuse —
                 * not supported here. */
                repl_next_token();  /* consume [ */
                repl_expr();
                if (repl_tok != RTK_RBRACK) return;
                repl_next_token();  /* consume ] */
                if (repl_tok == op) {
                    if (op == ROP_ASSIGN) {
                        repl_next_token();  /* consume = */
                        repl_assign();  /* RHS */
                        repl_emit(ROP_STORE_INDEX);
                    } else {
                        /* Compound a[i] op= c — not supported (would need
                         * to save i).  Fall back: parse as `a[i] = a[i] op c`. */
                        /* For now, just emit LOAD_INDEX and skip the assign.
                         * The user will see no assignment happen — but at
                         * least the compiler doesn't crash. */
                        repl_emit(ROP_LOAD_INDEX);
                        return;
                    }
                    return;
                }
                repl_emit(ROP_LOAD_INDEX);
            } else {
                break;
            }
        }
        /* Fell out without finding `=` — already-emitted LOAD ops are
         * orphaned.  This is a known issue with the backtracking approach
         * if state was mutated by side effects (e.g., new atoms).  In
         * practice, the only mutations are atom additions, which are
         * idempotent on re-parse.  Leave as-is. */
        return;
    }

    /* Default: parse as ternary (no assignment). */
    repl_ternary();
}

static void repl_block() {
    if (repl_tok == RTK_LBRACE) repl_next_token();
    while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
        repl_stmt();
    }
    if (repl_tok == RTK_RBRACE) repl_next_token();
}

/* T51-repl-v2: switch (e) { case v1: ...; case v2: ...; default: ... }
 * No fallthrough — each case body auto-inserts JMP end.
 * Encoding matches the browser compiler. */
static void repl_switch() {
    if (repl_switch_sp >= REPL_MAX_SWITCH) {
        /* Too many nested switches — skip body to avoid corruption. */
        repl_next_token();
        return;
    }
    repl_next_token();  /* consume 'switch' */
    if (repl_tok==RTK_LPAREN) repl_next_token();
    repl_expr();  /* the switch value — stays on stack */
    if (repl_tok==RTK_RPAREN) repl_next_token();
    if (repl_tok != RTK_LBRACE) return;
    repl_next_token();  /* consume '{' */

    int sb = repl_breakcnt;  /* break inside switch breaks the switch */
    int idx = repl_switch_sp++;
    repl_switch_ends[idx] = -1;  /* will hold JMP end placeholder */

    while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
        if (repl_tok == RTK_CASE) {
            repl_next_token();
            /* DUP switch val, push case val, STRICT_EQ, JZ next */
            repl_emit(ROP_DUP);
            repl_assign();
            repl_emit(ROP_STRICT_EQ);
            repl_emit(ROP_JZ);
            int jnext = repl_placeholder();
            /* POP the dup */
            repl_emit(ROP_POP);
            if (repl_tok == RTK_COLON) repl_next_token();
            /* parse case body */
            while (repl_tok != RTK_CASE && repl_tok != RTK_DEFAULT &&
                   repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
                repl_stmt();
            }
            /* auto-insert JMP end (no fallthrough) */
            repl_emit(ROP_JMP);
            int jend = repl_placeholder();
            /* save jend as a break target so `break` and case-end both patch here */
            if (repl_breakcnt < REPL_MAX_NESTING) {
                repl_breaks[repl_breakcnt++] = (int16_t)jend;
            }
            /* patch JZ to here (next case or end) */
            repl_patch(jnext, repl_buflen);
        } else if (repl_tok == RTK_DEFAULT) {
            repl_next_token();
            if (repl_tok == RTK_COLON) repl_next_token();
            while (repl_tok != RTK_CASE && repl_tok != RTK_DEFAULT &&
                   repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
                repl_stmt();
            }
            /* auto-insert JMP end */
            repl_emit(ROP_JMP);
            int jend = repl_placeholder();
            if (repl_breakcnt < REPL_MAX_NESTING) {
                repl_breaks[repl_breakcnt++] = (int16_t)jend;
            }
        } else {
            break;  /* unexpected token */
        }
    }
    if (repl_tok == RTK_RBRACE) repl_next_token();
    /* POP the switch value */
    repl_emit(ROP_POP);
    /* patch all break/case-end jumps to here */
    int end_pos = repl_buflen;
    while (repl_breakcnt > sb) {
        repl_patch(repl_breaks[--repl_breakcnt], end_pos);
    }
    repl_switch_sp--;
}

/* T51-repl-v2: try { body } catch (e) { handler } [finally { finalizer }]
 * Encoding:
 *   PUSH_TRY catch_pc    (2-byte placeholder for catch_pc)
 *   <body>
 *   POP_TRY
 *   JMP end              (placeholder, also saved for finally)
 *   catch:
 *     STORE errVar
 *     POP
 *     <handler>
 *     JMP end_finally    (placeholder for finally)
 *   end_catch_or_finally_start:
 *   finally (if present):
 *     <finalizer>
 *     JMP end
 *   end:
 */
static void repl_try() {
    if (repl_try_sp >= REPL_MAX_TRY_NESTING) {
        /* Too many nested tries — skip body to avoid corruption. */
        repl_next_token();
        return;
    }
    repl_next_token();  /* consume 'try' */
    if (repl_tok != RTK_LBRACE) return;
    repl_next_token();  /* consume '{' */

    int tidx = repl_try_sp++;
    int catch_pc_ph = repl_placeholder();
    repl_buf[repl_buflen-2] = 0;  /* will be patched */
    /* emit PUSH_TRY at start, with placeholder for catch_pc */
    /* Actually emit PUSH_TRY first, THEN the placeholder.  Let's redo. */
    repl_buflen -= 2;  /* undo the placeholder we just emitted */
    repl_emit(ROP_PUSH_TRY);
    (void)catch_pc_ph;
    int catch_ph = repl_placeholder();

    /* parse try body */
    while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
        repl_stmt();
    }
    if (repl_tok == RTK_RBRACE) repl_next_token();

    /* normal completion: pop try handler, jump past catch */
    repl_emit(ROP_POP_TRY);
    repl_emit(ROP_JMP);
    int end_jmp_ph = repl_placeholder();
    repl_try_stack[tidx * 2 + 0] = (int16_t)end_jmp_ph;

    /* catch: — patch PUSH_TRY to point here */
    int catch_pc = repl_buflen;
    repl_patch(catch_ph, catch_pc);

    int end_finally_ph = -1;
    if (repl_tok == RTK_CATCH) {
        repl_next_token();
        if (repl_tok == RTK_LPAREN) {
            repl_next_token();
            if (repl_tok == RTK_IDENT) {
                char ename[REPL_MAX_NAME];
                strncpy(ename, repl_str, REPL_MAX_NAME);
                ename[REPL_MAX_NAME-1] = '\0';
                repl_next_token();
                int s = repl_is_top_level ? -1 : repl_local_add(ename);
                if (s >= 0) { repl_emit(ROP_STORE_LOCAL); repl_emit((uint8_t)s); }
                else { repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)repl_atom(ename)); }
                repl_emit(ROP_POP);
            } else {
                /* missing name — drop the error string */
                repl_emit(ROP_POP);
            }
            if (repl_tok == RTK_RPAREN) repl_next_token();
        }
        if (repl_tok == RTK_LBRACE) {
            repl_next_token();
            while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
                repl_stmt();
            }
            if (repl_tok == RTK_RBRACE) repl_next_token();
        }
        /* jump past finally (if any) */
        repl_emit(ROP_JMP);
        end_finally_ph = repl_placeholder();
        repl_try_stack[tidx * 2 + 1] = (int16_t)end_finally_ph;
    } else {
        /* no catch — try must have finally or be malformed.
         * Drop the would-be error value. */
        repl_emit(ROP_POP);
        repl_try_stack[tidx * 2 + 1] = -1;
    }

    /* finally: — parse finalizer */
    if (repl_tok == RTK_FINALLY) {
        repl_next_token();
        if (repl_tok == RTK_LBRACE) {
            repl_next_token();
            while (repl_tok != RTK_RBRACE && repl_tok != RTK_EOF) {
                repl_stmt();
            }
            if (repl_tok == RTK_RBRACE) repl_next_token();
        }
    }

    /* end: — patch end_jmp and end_finally (if set) */
    int end_pos = repl_buflen;
    repl_patch(end_jmp_ph, end_pos);
    if (end_finally_ph >= 0) {
        repl_patch(end_finally_ph, end_pos);
    }
    repl_try_sp--;
}

static void repl_stmt() {
    if (repl_tok == RTK_IF) {
        repl_next_token();
        if (repl_tok==RTK_LPAREN) repl_next_token();
        repl_expr();
        if (repl_tok==RTK_RPAREN) repl_next_token();
        repl_emit(ROP_JZ);
        int j1 = repl_placeholder();
        repl_stmt();
        if (repl_tok == RTK_ELSE) {
            repl_next_token();
            repl_emit(ROP_JMP);
            int j2 = repl_placeholder();
            repl_patch(j1, repl_buflen);
            repl_stmt();
            repl_patch(j2, repl_buflen);
        } else {
            repl_patch(j1, repl_buflen);
        }
        return;
    }
    if (repl_tok == RTK_WHILE) {
        repl_next_token();
        if (repl_tok==RTK_LPAREN) repl_next_token();
        int ls = repl_buflen;
        repl_expr();
        if (repl_tok==RTK_RPAREN) repl_next_token();
        repl_emit(ROP_JZ);
        int je = repl_placeholder();
        int sb = repl_breakcnt, sc = repl_contcnt;
        repl_stmt();
        repl_emit(ROP_JMP);
        repl_patch(repl_placeholder(), ls);
        repl_patch(je, repl_buflen);
        while (repl_breakcnt > sb) repl_patch(repl_breaks[--repl_breakcnt], repl_buflen);
        while (repl_contcnt > sc) repl_patch(repl_conts[--repl_contcnt], ls);
        return;
    }
    if (repl_tok == RTK_DO) {
        /* T51-repl-v2: do { body } while (cond); */
        repl_next_token();
        int ls = repl_buflen;
        int sb = repl_breakcnt, sc = repl_contcnt;
        repl_stmt();
        if (repl_tok == RTK_WHILE) {
            repl_next_token();
            if (repl_tok==RTK_LPAREN) repl_next_token();
            repl_expr();
            if (repl_tok==RTK_RPAREN) repl_next_token();
            repl_emit(ROP_JNZ);
            repl_patch(repl_placeholder(), ls);
            if (repl_tok==RTK_SEMI) repl_next_token();
        }
        while (repl_breakcnt > sb) repl_patch(repl_breaks[--repl_breakcnt], repl_buflen);
        while (repl_contcnt > sc) repl_patch(repl_conts[--repl_contcnt], ls);
        return;
    }
    if (repl_tok == RTK_FOR) {
        repl_next_token();
        if (repl_tok==RTK_LPAREN) repl_next_token();
        /* init */
        if (repl_tok == RTK_VAR || repl_tok == RTK_LET || repl_tok == RTK_CONST) {
            /* T51-repl-v2: let/const treated as var */
            repl_next_token();
            if (repl_tok == RTK_IDENT) {
                char name[REPL_MAX_NAME]; strncpy(name, repl_str, REPL_MAX_NAME);
                name[REPL_MAX_NAME-1] = '\0';
                repl_next_token();
                int s = repl_is_top_level ? -1 : repl_local_add(name);
                if (repl_tok == ROP_ASSIGN) {
                    repl_next_token(); repl_expr();
                    if (s >= 0) { repl_emit(ROP_STORE_LOCAL); repl_emit((uint8_t)s); }
                    else { repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)repl_atom(name)); }
                    repl_emit(ROP_POP);
                }
            }
        } else if (repl_tok != RTK_SEMI) {
            repl_expr(); repl_emit(ROP_POP);
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        /* cond — parse condition, emit JZ to end */
        int ls = repl_buflen;
        int je = -1;
        if (repl_tok != RTK_SEMI) {
            repl_expr();
            repl_emit(ROP_JZ);
            je = repl_placeholder();
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        /* post — parse and emit as forward jump target. */
        /* JMP to body (skip post) */
        repl_emit(ROP_JMP);
        int jmp_to_body = repl_placeholder();
        /* post */
        int ps = repl_buflen;
        if (repl_tok != RTK_RPAREN) {
            repl_assign(); repl_emit(ROP_POP);
        }
        if (repl_tok==RTK_RPAREN) repl_next_token();
        /* JMP back to cond */
        repl_emit(ROP_JMP); repl_patch(repl_placeholder(), ls);
        /* body — patch JMP to here */
        repl_patch(jmp_to_body, repl_buflen);
        int sb = repl_breakcnt, sc = repl_contcnt;
        repl_stmt();
        /* JMP to post */
        repl_emit(ROP_JMP); repl_patch(repl_placeholder(), ps);
        /* patch cond JZ to here */
        if (je >= 0) repl_patch(je, repl_buflen);
        while (repl_breakcnt > sb) repl_patch(repl_breaks[--repl_breakcnt], repl_buflen);
        while (repl_contcnt > sc) repl_patch(repl_conts[--repl_contcnt], ps);
        return;
    }
    if (repl_tok == RTK_RETURN) {
        repl_next_token();
        if (repl_tok==RTK_SEMI||repl_tok==RTK_RBRACE||repl_tok==RTK_EOF) {
            repl_emit(ROP_RET_UNDEF);
        } else {
            repl_expr(); repl_emit(ROP_RET);
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        return;
    }
    if (repl_tok == RTK_VAR || repl_tok == RTK_LET || repl_tok == RTK_CONST) {
        /* T51-repl-v2: let/const treated as var */
        repl_next_token();
        while (repl_tok == RTK_IDENT) {
            char name[REPL_MAX_NAME]; strncpy(name, repl_str, REPL_MAX_NAME);
            name[REPL_MAX_NAME-1] = '\0';
            repl_next_token();
            int s = repl_is_top_level ? -1 : repl_local_add(name);
            if (repl_tok == ROP_ASSIGN) {
                repl_next_token(); repl_expr();
            } else {
                repl_emit(ROP_UNDEF);
            }
            if (s >= 0) { repl_emit(ROP_STORE_LOCAL); repl_emit((uint8_t)s); }
            else { repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)repl_atom(name)); }
            repl_emit(ROP_POP);
            if (repl_tok==RTK_COMMA) repl_next_token(); else break;
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        return;
    }
    if (repl_tok == RTK_FUNC) {
        repl_next_token();
        if (repl_tok == RTK_IDENT) {
            char name[REPL_MAX_NAME]; strncpy(name, repl_str, REPL_MAX_NAME);
            name[REPL_MAX_NAME-1] = '\0';
            repl_next_token();
            if (repl_is_top_level) repl_atom(name);
            /* params */
            if (repl_tok==RTK_LPAREN) repl_next_token();
            int saved = repl_local_count;
            int saved_tl = repl_is_top_level;
            repl_local_count = 0;
            repl_is_top_level = 0;
            int argc = 0;
            while (repl_tok == RTK_IDENT) {
                repl_local_add(repl_str); argc++;
                repl_next_token();
                if (repl_tok==RTK_COMMA) repl_next_token(); else break;
            }
            if (repl_tok==RTK_RPAREN) repl_next_token();
            /* func entry */
            if (repl_func_count < REPL_MAX_FUNCS) {
                int fi = repl_func_count++;
                repl_funcs[fi].argc = (uint8_t)argc;
                int body_start = repl_buflen;
                repl_block();
                repl_emit(ROP_RET_UNDEF);
                int body_len = repl_buflen - body_start;
                uint8_t *body_save = (uint8_t*)malloc((size_t)body_len);
                if (!body_save) {
                    repl_func_count--;
                    repl_local_count = saved;
                    repl_is_top_level = saved_tl;
                    return;
                }
                memcpy(body_save, repl_buf + body_start, body_len);
                repl_buflen = body_start;
                repl_emit(ROP_FUNCTION); repl_emit((uint8_t)fi);
                repl_emit(ROP_STORE_GLOBAL); repl_emit((uint8_t)repl_atom(name));
                repl_emit(ROP_POP);
                repl_funcs[fi].pc = repl_buflen;
                repl_funcs[fi].nlocals = repl_local_count;
                repl_funcs[fi].bodySize = (uint16_t)body_len;
                memcpy(repl_buf + repl_buflen, body_save, body_len);
                repl_buflen += body_len;
                free(body_save);
            } else {
                repl_block();
            }
            repl_local_count = (uint8_t)saved;
            repl_is_top_level = (uint8_t)saved_tl;
        }
        return;
    }
    if (repl_tok == RTK_BREAK) {
        repl_next_token();
        repl_emit(ROP_JMP);
        if (repl_breakcnt < REPL_MAX_NESTING) {
            repl_breaks[repl_breakcnt++] = (int16_t)repl_placeholder();
        } else {
            (void)repl_placeholder();
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        return;
    }
    if (repl_tok == RTK_CONTINUE) {
        repl_next_token();
        repl_emit(ROP_JMP);
        if (repl_contcnt < REPL_MAX_NESTING) {
            repl_conts[repl_contcnt++] = (int16_t)repl_placeholder();
        } else {
            (void)repl_placeholder();
        }
        if (repl_tok==RTK_SEMI) repl_next_token();
        return;
    }
    if (repl_tok == RTK_SWITCH) { repl_switch(); return; }
    if (repl_tok == RTK_TRY)   { repl_try(); return; }
    if (repl_tok == RTK_THROW) {
        repl_next_token();
        repl_expr();
        repl_emit(ROP_THROW);
        if (repl_tok==RTK_SEMI) repl_next_token();
        return;
    }
    if (repl_tok == RTK_LBRACE) { repl_block(); return; }
    if (repl_tok == RTK_SEMI) { repl_next_token(); return; }
    /* expression statement */
    repl_assign(); repl_emit(ROP_POP);
    if (repl_tok==RTK_SEMI) repl_next_token();
}

/* ---- Serializer ---- */
static int repl_serialize(uint8_t *out, int outSize) {
    int p = 0;
    /* T51-fix: bounds-checked emit helper so we can't overflow out
     * if the caller passed a smaller outSize than the working buffer. */
    #define SOUT(b) do { if (p < outSize) out[p] = (b); p++; } while (0)
    /* magic */
    SOUT('M'); SOUT('J'); SOUT('S'); SOUT('B');
    SOUT(1); SOUT(0);
    /* atoms */
    SOUT(repl_atom_count & 0xFF);
    SOUT((repl_atom_count >> 8) & 0xFF);
    for (int i = 0; i < repl_atom_count; i++) {
        int len = strlen(repl_atoms[i]);
        SOUT(len&0xFF); SOUT((len>>8)&0xFF);
        for (int j = 0; j < len; j++) SOUT((uint8_t)repl_atoms[i][j]);
        SOUT(0);
    }
    /* consts */
    SOUT(repl_const_count & 0xFF);
    SOUT((repl_const_count >> 8) & 0xFF);
    for (int i = 0; i < repl_const_count; i++) {
        if (repl_consts[i].type == 0) {
            SOUT(0);
            int32_t v = repl_consts[i].val.num;
            uint32_t enc = ((uint32_t)(v & 0x3FFFFFFF) << 2) | 1;
            SOUT(enc&0xFF); SOUT((enc>>8)&0xFF);
            SOUT((enc>>16)&0xFF); SOUT((enc>>24)&0xFF);
        } else {
            SOUT(1);
            int len = strlen(repl_consts[i].val.str);
            SOUT(len&0xFF); SOUT((len>>8)&0xFF);
            for (int j = 0; j < len; j++) SOUT((uint8_t)repl_consts[i].val.str[j]);
            SOUT(0);
        }
    }
    /* funcs */
    SOUT(repl_func_count & 0xFF);
    SOUT((repl_func_count >> 8) & 0xFF);
    for (int i = 0; i < repl_func_count; i++) {
        SOUT(repl_funcs[i].argc);
        SOUT(repl_funcs[i].nlocals);
        uint16_t pc = repl_funcs[i].pc;
        SOUT(pc&0xFF); SOUT((pc>>8)&0xFF);
        SOUT(repl_funcs[i].bodySize&0xFF);
        SOUT((repl_funcs[i].bodySize>>8)&0xFF);
    }
    /* bytecode */
    for (int i = 0; i < repl_buflen; i++) SOUT(repl_buf[i]);
    #undef SOUT
    return p;
}

/* ---- Public API ---- */

int repl_compile(const char *src, uint8_t *out, int outSize) {
    repl_arena = (uint8_t*)malloc(REPL_ARENA_SIZE);
    if (!repl_arena) {
        return 0;  /* OOM */
    }
    /* Carve slices from the arena, with 4-byte alignment where needed. */
    size_t off = 0;
    repl_atoms = (char(*)[REPL_MAX_NAME])(repl_arena + off);
    off += (size_t)REPL_MAX_ATOMS * REPL_MAX_NAME;
    off = (off + 3u) & ~3u;
    repl_consts = (ReplConst*)(repl_arena + off);
    off += (size_t)REPL_MAX_CONSTS * sizeof(ReplConst);
    off = (off + 1u) & ~1u;
    repl_funcs = (ReplFunc*)(repl_arena + off);
    off += (size_t)REPL_MAX_FUNCS * sizeof(ReplFunc);
    repl_locals = (char(*)[REPL_MAX_NAME])(repl_arena + off);
    off += (size_t)REPL_MAX_LOCALS * REPL_MAX_NAME;
    repl_buf = (uint8_t*)(repl_arena + off);
    off += REPL_BC_MAX;
    off = (off + 1u) & ~1u;
    repl_breaks = (int16_t*)(repl_arena + off);
    off += (size_t)REPL_MAX_NESTING * sizeof(int16_t);
    repl_conts = (int16_t*)(repl_arena + off);
    off += (size_t)REPL_MAX_NESTING * sizeof(int16_t);
    repl_buffers_allocated = 1;

    /* Reset state */
    repl_src = src;
    repl_pos = 0;
    repl_atom_count = 0;
    repl_const_count = 0;
    repl_func_count = 0;
    repl_local_count = 0;
    repl_is_top_level = 1;
    repl_buflen = 0;
    repl_breakcnt = 0;
    repl_contcnt = 0;
    repl_try_sp = 0;
    repl_switch_sp = 0;
    repl_in_typeof = 0;

    /* Lex — read first char */
    repl_ch = repl_src[0];
    repl_pos = 1;
    repl_next_token();

    /* Parse */
    while (repl_tok != RTK_EOF) {
        repl_stmt();
    }
    repl_emit(ROP_HALT);

    /* Serialize */
    int total = repl_serialize(out, outSize);

    /* Free all heap buffers — REPL is idle until next call. */
    repl_free_buffers();
    return total;
}

#endif /* MICROJS_REPL_IMPLEMENTATION */
