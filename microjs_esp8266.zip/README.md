# QuickJS-ESPboy — mquickjs + LittleFS Web REPL (T14)

**New in T14**: the project has been rewritten to use
[mquickjs](https://github.com/bellard/mquickjs) (Fabrice Bellard's
minimal QuickJS variant for embedded systems) instead of picojs, and
[LittleFS](https://github.com/esp8266/Arduino/tree/master/libraries/LittleFS)
instead of EEPROM for persistent storage.

## Why mquickjs?

- Full ES5 + ES6 subset (typed arrays, `for-of`, `codePointAt`, `**`, etc).
- Strict-mode only — catches more bugs at parse time.
- ~100 KB ROM, ~10 KB RAM minimum (smaller than full QuickJS).
- Caller-supplied heap (no malloc dependency) — isolated from system heap.
- Tracing + compacting (moving) GC — no manual `free()` calls, no leaks.
- Non-recursive parser — bounded C stack usage.
- Software float path (`-DUSE_SOFTFLOAT`) for the ESP8266's FPU-less L106.
- No more `===` / `!==` limitation that picojs had.
- No more T13-style Exception (3) crashes from heap corruption.

## Why LittleFS (instead of EEPROM)?

- Power-loss safe (atomic metadata updates).
- Real directories (`mkdir`/`rmdir`).
- 32 KB max boot script (vs 2 KB EEPROM limit).
- Wear leveling (vs EEPROM's single 4 KB sector).
- Much faster mount time.
- Drop-in API replacement for SPIFFS.

## Files (T14)

| File / Dir | Description |
|------------|-------------|
| `quickjs_esp8266.ino` | Main Arduino sketch — mquickjs + LittleFS + WiFi AP + TFT. |
| `mquickjs_lib/` | Complete mquickjs distribution + our `espboy_stdlib.c/h` + `quickjs_esp.h` wrapper. |
| `mquickjs_lib/espboy_stdlib.c` | Our stdlib declaration (ESPboy natives + upstream mquickjs stdlib). |
| `mquickjs_lib/espboy_stdlib.h` | Generated ROM tables — regenerate via `./build_stdlib.sh`. |
| `mquickjs_lib/espboy_atom.h` | Generated atom #defines — regenerate via `./build_stdlib.sh`. |
| `mquickjs_lib/quickjs_esp.h` | Arduino-friendly wrapper: `qjs_init`, `qjs_eval`, `qjs_destroy`. |
| `mquickjs_lib/webui_html.h` | Web REPL page (HTML+CSS+JS, inline PrismJS-compatible highlighter, help panel). |
| `mquickjs_lib/build_stdlib.sh` | Regenerates the two .h files from espboy_stdlib.c (run on Linux/macOS). |
| `picojs.h`, `picojs_esp8266.ino` | Old T1-T13 picojs version (kept for reference, no longer maintained). |

## Recent changes (T30) — strict equality, typeof, for...in/of, switch, String methods, examples

**New language features (T30):**

- **`===` / `!==` strict equality** — new opcodes `OP_STRICT_EQ` and
  `OP_STRICT_NE`.  Compare type AND value without coercion:
  - `1 === 1` → true, `1 === "1"` → false
  - `null === null` → true, `null === undefined` → false

- **`typeof`** — new opcode `OP_TYPEOF`.  Returns string:
  - `typeof 42` → "number", `typeof "hi"` → "string"
  - `typeof true` → "boolean", `typeof null` → "object" (per JS spec)
  - `typeof {}` → "object", `typeof function(){}` → "function"
  - `typeof undef` → "undefined"

- **`instanceof`** (simplified) — `OP_INSTANCEOF` compares by
  constructor name: `x instanceof Array`, `x instanceof String`, etc.

- **`for...in`** — iterate object keys:
  ```js
  var o = {a:1, b:2, c:3};
  for (var k in o) print(k, o[k]);  // → "a 1", "b 2", "c 3"
  ```

- **`for...of`** — iterate array values (and string chars):
  ```js
  var a = [10, 20, 30];
  for (var v of a) print(v);  // → 10, 20, 30
  ```

- **`switch` statement** — with `case`/`default`/`break`:
  ```js
  switch (x) {
      case 1: print(10); break;
      case 2: print(20); break;
      default: print(0);
  }
  ```
  Supports C-style fallthrough (omit `break` to fall into next case).

- **`break` / `continue` fix** — now correctly emit `JMP` before the
  placeholder (was emitting raw bytes, causing garbage opcodes).

**New native APIs (T30):**

- **String methods** — `String.length(s)`, `String.charAt(s, i)`,
  `String.indexOf(s, sub)`, `String.substring(s, start, end)`,
  `String.toUpperCase(s)`, `String.toLowerCase(s)`.

- **Array helpers** — `Array.push(arr, val)`, `Array.isArray(x)`.

**New examples (T30):**

- **Anim** — animated pulsing disc using `setInterval`:
  ```js
  var t = 0;
  setInterval(function() {
      tft.cls();
      var r = 5 + (t % 20);
      tft.disc(32, 32, r, 1 + (t % 15));
      tft.flip();
      t++;
  }, 100);
  ```

- **Game** — arrow-controlled sprite with boundary clamping:
  ```js
  var px = 32, py = 32;
  setInterval(function() {
      var k = keys();
      var dx = 0, dy = 0;
      if (k & LEFT) dx = -1;
      if (k & RIGHT) dx = 1;
      if (k & UP) dy = -1;
      if (k & DOWN) dy = 1;
      px += dx; py += dy;
      if (px < 0) px = 0; if (px > 57) px = 57;
      if (py < 0) py = 0; if (py > 56) py = 56;
      tft.cls();
      tft.fillRect(px, py, 6, 6, 3);
      tft.flip();
  }, 100);
  ```

- **Switch**, **Typeof**, **Strict**, **ForIn**, **ForOf** —
  demonstrate the new language features.

**Timers verified working (T30):**

`setInterval` / `setTimeout` callbacks fire correctly via
`mjs_call_value()` from `loop()`.  The animation example updates the
screen at 10 FPS using `setInterval(fn, 100)`.

**PC-verified tests (T30):**

```
print(2+3*4);                                       → 14
var s=0;for(var i=0;i<10;i++) s+=i; print(s);       → 55
var x=5; print(x==5?1:2);                           → 1
print(1===1);                                       → true
print(1==="1");                                     → false
print(typeof 42);                                   → number
var x=2; switch(x){case 1:print(10);break;case 2:print(20);break;default:print(0);} → 20
var o={a:1,b:2,c:3}; for(var k in o) print(k);      → a, b, c
var a=[10,20,30]; for(var v of a) print(v);         → 10, 20, 30
```

## Recent changes (T29) — robust parseFor + button constants

**Bug fixes (T29):**

- **`parseFor` rewrite** — replaced the fragile JMP-over-post scheme
  with a classic structure:
  ```
  init
  loopStart: <cond> JZ end
  <body>
  postStart: <post> POP
  JMP loopStart
  end:
  ```
  The post expression is parsed twice: once to discover its token
  range (bytecode discarded), then re-emitted after the body.  The
  key fix is consuming the `)` after the throwaway post parse so
  the body can be parsed, then rewinding to re-emit the post, then
  re-consuming the `)` to keep the lexer in sync.

  This fixes all three original failing samples:
  - `for(var y=0;y<64;y+=8) for(var x=0;x<64;x+=8) tft.fillRect(...)` ✓
  - `for(var r=30;r>0;r-=4) tft.disc(32,32,r, r%8?3:1);` ✓
  - `for(var i=0;i<256;i++) tft.fillRect((i%16)*4,(i/16|0)*4,3,3,i);` ✓

- **`parse()` state reset** — added `this.bc = []; this.body = [];`
  etc. at the start of `parse()` so `compile()` can be called
  multiple times on the same compiler instance (was leaking state
  from previous runs).

**New features (T29):**

- **Button constants** — JS globals for each button bit:
  ```js
  LEFT=1   UP=2     DOWN=4   RIGHT=8
  A=16    B=32              RGT=128
  ```
  Use like `if (keys() & A) { ... }`.  `RGT` (bit 7, value 128) is
  the same button that runs the saved boot script.

- **Boot script on RGT button** — changed from button A (bit 0) to
  RGT (bit 7).  The splash screen now shows `[RGT] run` instead of
  `[A] run`.

- **Help panel updated** — web UI now lists all globals (including
  `setTimeout`, `setInterval`, `rand`) and the button constants
  table.

**PC-verified tests (T29):**

All 14 tests pass:

```
print(2+3*4);                                          → 14
var x=10; var y=20; print(x+y);                        → 30
var a=5; if (a>3) { print(99); } else { print(0); }    → 99
var a=[10,20,30]; print(a[0]+a[1]+a[2]);               → 60
var o={x:1,y:2}; print(o.x+o.y);                       → 3
function add(a,b){return a+b;} print(add(3,4));        → 7
var s=0; for (var i=0; i<10; i=i+1) { s=s+i; } print(s); → 55
var o={x:1}; o.x=99; print(o.x);                       → 99
var a=[1,2,3]; a[1]=99; print(a[0]+a[1]+a[2]);         → 103
var s=0; for (var i=0; i<10; i++) s=s+i; print(s);     → 55   ← i++
var x=5; print(x==5?1:2);                              → 1    ← ?:
for (var i=0; i<5; i++) print(i);                      → 0,1,2,3,4
for (var y=0; y<64; y+=8) print(y);                    → 0,8,16,...,56   ← y+=8
for (var r=30; r>0; r-=4) print(r);                    → 30,26,22,...,2  ← r-=4
```

## Recent changes (T28) — postfix `i++`, ternary `?:`, TFT init fix

**Bug fixes (T28):**

- **Postfix `i++` / `i--`** — added `parseIncrement(isPrefix, isInc)`
  that emits the correct LOAD + INC/DEC + STORE sequence.  Postfix
  peeks ahead in `parsePostfix` for IDENT followed by `++`/`--`.
  Prefix `++i` uses the same helper.  Both work in statement and
  expression context.  `for (var i = 0; i < 256; i++) { ... }` now
  compiles.

- **Ternary `cond ? a : b`** — added `parseTernary()` between
  `parseExpr` and `parseAssignment`.  Emits the standard JZ/JMP
  pattern.  `x == y ? 4 : 1` now compiles.

- **White screen fix** — rewrote `setup()` to follow the original
  14-step boot sequence verbatim.  The critical bug was that
  `Wire.begin()` + `tft.init()` was called BEFORE initializing the
  MCP23017, so TFT CS (on MCP23017 GPB0) was floating HIGH and the
  ST7735 controller never received init commands.  The new sequence:
  1. WiFi OFF
  2. LittleFS mount
  3. I2C + MCP23017 begin (IODIRA/B = 0xFF)
  4. MCP4725 probe
  5. GPA0..7 = INPUT + pull-up (buttons)
  6. GPB1 (LEDLOCK) = OUTPUT, LOW
  7. **GPB0 (CSTFT) = OUTPUT, LOW** ← this was missing
  8. Backlight OFF
  9. **tft.begin() + setSwapBytes(true) + fillScreen(BLACK)**
  10. display_init() (framebuffer + palette)
  11. Fade backlight in (300 → 2500)
  12. Full brightness (4095)
  13. WiFi AP start
  14. Splash on TFT + `display_flush_now()` (immediate, no throttle)

- Also added `display_flush_now()` after the splash so it appears
  immediately during setup (the throttle in `display_tick()` would
  otherwise wait ~66 ms before the first flush).

**PC-verified tests (T28):**

All 12 tests pass:

```
print(2+3*4);                                          → 14
var x=10; var y=20; print(x+y);                        → 30
var a=5; if (a>3) { print(99); } else { print(0); }    → 99
var a=[10,20,30]; print(a[0]+a[1]+a[2]);               → 60
var o={x:1,y:2}; print(o.x+o.y);                       → 3
function add(a,b){return a+b;} print(add(3,4));        → 7
var s=0; for (var i=0; i<10; i=i+1) { s=s+i; } print(s); → 45
var o={x:1}; o.x=99; print(o.x);                       → 99
var a=[1,2,3]; a[1]=99; print(a[0]+a[1]+a[2]);         → 103
var s=0; for (var i=0; i<10; i++) s=s+i; print(s);     → 45   ← i++
var x=5; print(x==5?1:2);                              → 1    ← ?:
for (var i=0; i<5; i++) print(i);                      → 0,1,2,3,4
```

## Recent changes (T27) — fixes + setTimeout + packed arrays

**Bug fixes (T27):**
- `goto trunc` crossing variable initialization in `mjs_load_bytecode`
  → replaced with `TRUNC_RET()` macro that returns inline.  Fixes the
  C++ compile error reported on Arduino.
- `LittleFS.totalBytes()` / `usedBytes()` → use `FSInfo` + `LittleFS.info()`
  (the right ESP8266 LittleFS API).
- `fb_text(x, y, str, c, scale)` missing the `len` argument → added
  a convenience overload that calls `strlen()` automatically.
- `for (init; cond; post)` loops → rewrote the parser to emit the
  correct control flow:
  ```
  loopStart: <cond> JZ end
             JMP bodyStart          ; skip post on first iter
  postStart: <post> POP
             JMP loopStart
  bodyStart: <body>
             JMP postStart          ; continue target
  end:
  ```
- `obj.prop = value` → fixed: the lookahead consumed `.prop` but the
  emission block was trying to `expect('.')` again (lexer was already
  on the RHS).  Now correctly emits `LOAD obj; <rhs>; STORE_PROP atom`.
- `arr[i] = value` → fixed by saving the index expression's token
  range during lookahead and re-parsing it during emission.
- `STORE_LOCAL` / `STORE_GLOBAL` / `STORE_PROP` / `STORE_INDEX` → now
  leave the assigned value on the stack (per JS assignment semantics).
  Object literals emit `DUP` before the value + `POP` after to keep
  the object reference alive.

**New features (T27):**

- `setTimeout(fn, ms)`, `setInterval(fn, ms)`, `clearTimeout(id)`,
  `clearInterval(id)` — timer wheel with up to 8 concurrent timers.
  The event loop in `loop()` calls `timers_tick()` which fires due
  callbacks via the new `mjs_call_value()` VM API.

- **Packed arrays** — when an array literal `[1, 2, 3, ...]` contains
  ONLY small integers in 0..255, the VM stores it as a packed `uint8_t[]`
  instead of `MJSValue[]`.  If all values fit in 0..65535, it uses
  `uint16_t[]`.  This saves 4× RAM on ESP8266 (4-byte MJSValue → 1-byte
  u8) and 8× on x86_64 — important for sprite data.

  Example:
  ```js
  var sprite = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
                0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
  // 32 elements × 1 byte = 32 bytes (was 128 bytes on ESP8266)
  ```

  Mixed arrays (with strings or out-of-range ints) fall back to
  `MJSValue[]` automatically.  Storing a non-fitting value into a
  packed array via `arr[i] = v` is silently ignored (no promotion).

**PC-verified tests (T27):**

All 9 tests pass through the browser-compiler → C-VM pipeline:

```
print(2+3*4);                                          → 14
var x=10; var y=20; print(x+y);                        → 30
var a=5; if (a>3) { print(99); } else { print(0); }    → 99
var a=[10,20,30]; print(a[0]+a[1]+a[2]);               → 60
var o={x:1,y:2}; print(o.x+o.y);                       → 3
function add(a,b){return a+b;} print(add(3,4));        → 7
var s=0; for (var i=0; i<10; i=i+1) { s=s+i; } print(s); → 45
var o={x:1}; o.x=99; print(o.x);                       → 99
var a=[1,2,3]; a[1]=99; print(a[0]+a[1]+a[2]);         → 103
```

Plus packed-array verification:
```
var sprite = [0,1,...,15, 0,1,...,15];  // 32 elements
print(sprite);   → [arr len=32 cap=32 elem_size=1]   (packed u8!)
print(sum(sprite));  → 240
```

## Recent changes (T26) — compiler/VM split

**Architecture change:** the JS compiler now runs in the browser, and
the device only runs a bytecode VM.  This dramatically shrinks the
device footprint and removes the serial REPL.

```
  Browser (web UI)              ESP8266 (device)
  ─────────────────             ─────────────────
  microjs_compiler.js           microjs_vm.h
  ┌────────────────┐            ┌──────────────────┐
  │ JS source      │  compile   │                  │
  │      ↓         │───────►    │ bytecode blob    │
  │ MJSB bytecode  │   HTTP     │      ↓           │
  └────────────────┘   POST     │ mjs_load_bytecode│
                                │      ↓           │
                                │ mjs_run (VM)     │
                                │      ↓           │
                                │ natives (tft.*)  │
                                └──────────────────┘
```

**Files (T26):**

| File | Where | Purpose |
|------|-------|---------|
| `microjs_vm.h` | device | Bytecode VM, ~1100 lines C, single-header |
| `microjs_compiler.js` | browser | Lexer + parser + emitter, ~700 lines JS |
| `microjs_compiler_js.h` | device | PROGMEM copy of `microjs_compiler.js` (auto-generated, served at `/compiler.js`) |
| `microjs_webui.h` | device | HTML for `/` endpoint |
| `microjs_esp8266.ino` | device | Main sketch — uses `microjs_vm.h` instead of mquickjs |
| `espboy_display.h` | device | 64×64 framebuffer + PROGMEM palette (unchanged from T14) |
| `espboy_font_a.h` | device | 5×7 CP1251 font (unchanged) |

Old files NOT needed in T26 build:
- `mquickjs.c`, `mquickjs.h`, `mquickjs_priv.h`, `mquickjs_opcode.h`,
  `mquickjs_build.h`, `mquickjs_atom.h`
- `libm.c`, `libm.h`, `dtoa.c`, `dtoa.h`, `cutils.c`, `cutils.h`, `list.h`
- `softfp_template.h`, `softfp_template_icvt.h`
- `espboy_stdlib.c`, `espboy_stdlib.h`, `espboy_atom.h`
- `mqjs_stdlib.c`
- `quickjs_esp.h`, `webui_html.h`
- `microjs.h` (T25 — superseded by `microjs_vm.h` + `microjs_compiler.js`)
- `build_stdlib.sh`

**Bytecode format (MJSB — MicroJS Bytecode, portable, little-endian):**

```
Offset  Size  Field
0       4     Magic "MJSB"
4       1     Version (1)
5       1     Flags (reserved, 0)
6       2     Atom count (N_a)
8       var   Atom table: for each atom: u16 len + len+1 bytes (NUL-terminated)
...     2     Const count (N_c)
...     var   Const table: for each const:
                type 0 = int30  → 4 bytes (LE, value = MAKE_INT(v))
                type 1 = string → u16 len + len+1 bytes
...     2     Func count (N_f)
...     var   Func table: for each func: u8 argc + u8 nlocals + u16 pc + u16 body_size
...     var   Bytecode (top-level + function bodies, concatenated, ends with OP_HALT)
```

`pc` is an absolute offset from the start of the bytecode region.

**HTTP API (T26):**

| Method | Path | Body | Response |
|--------|------|------|----------|
| GET | `/` | — | HTML page (loads `/compiler.js`) |
| GET | `/compiler.js` | — | `application/javascript` — the compiler |
| POST | `/run` | MJSB bytecode (binary) | JSON `{stdout, ms, mem, error?, pc?}` |
| POST | `/save` | JSON `{source, bytecode:[...]}` | plain text confirmation |
| GET | `/load` | — | JSON `{source, bytecode_count}` |
| POST | `/clear` | — | plain text |
| GET | `/mem` | — | JSON diagnostics |

**Removed (T26):**
- Serial REPL (no parser on device).
- Old `quickjs_esp.h` wrapper (replaced by `microjs_vm.h`).
- All mquickjs files (libm, dtoa, softfloat, stdlib tables).
- `setTimeout` / `setInterval` / `palette` / `jsmem` (will re-add as
  natives in a future patch).
- `try/catch`, `throw` — by design.
- Float path (int30 only).

**Footprint comparison:**

| Component | T25 (mquickjs) | T26 (microjs VM only) |
|-----------|----------------|----------------------|
| ROM (interpreter) | ~100 KB | ~12 KB |
| ROM (stdlib) | ~10 KB | 0 (natives in .ino) |
| ROM (libm + dtoa) | ~70 KB | 0 (no float) |
| ROM (softfloat) | ~10 KB | 0 |
| **Total ROM** | **~190 KB** | **~12 KB** (+ .ino natives ~5 KB) |
| RAM (parser state) | ~4 KB | 0 (no parser) |
| RAM (JS heap) | 12 KB | 16 KB (configurable) |
| RAM (atom table) | ~2 KB | ~2 KB |
| **Total RAM** | ~30 KB | **~22 KB** |

**PC test (verify the pipeline works end-to-end):**

```bash
cd scripts
# Compile VM test
gcc -g -O0 -o mjs_vm_test mjs_vm_test.c -lm

# Compile a JS source to bytecode, run in the VM
echo 'print(2+3*4);' > /tmp/t.js
node -e "
const {MicroJSCompiler} = require('./microjs_compiler.js');
const fs = require('fs');
const r = new MicroJSCompiler().compile(fs.readFileSync('/tmp/t.js','utf8'));
if (r.error) { console.error(r.error); process.exit(1); }
fs.writeFileSync('/tmp/t.mjsb', Buffer.from(r.bytecode));
"
./mjs_vm_test /tmp/t.mjsb
# Output: 14
```

**Verified working (T26 PC pipeline):**
- `print(2+3*4);` → 14
- `var x=10; var y=20; print(x+y);` → 30
- `var a=5; if (a>3) { print(99); } else { print(0); }` → 99
- `var a=[10,20,30]; print(a[0]+a[1]+a[2]);` → 60
- `var o={x:1,y:2}; print(o.x+o.y);` → 3
- `function add(a,b){return a+b;} print(add(3,4));` → 7

**Known issues (T26):**
- `for (init; cond; post)` loops — parser bug in the compiler (works
  for `while`, so use that for now).
- `while` with `print()` inside — works on PC but may have issues
  on device due to print capturing.
- `obj.prop = value` — compound lvalue paths not fully implemented
  in the compiler.
- Device build (`microjs_esp8266.ino`) is NOT yet tested with the
  Arduino ESP8266 toolchain — porting requires verifying that the
  `espboy_display.h` API matches what `microjs_esp8266.ino` calls.
- No `setTimeout`/`setInterval` yet (T25 had these — easy to re-add
  as natives + an event loop in `loop()`).

**Status:** preview.  The browser→device pipeline is verified on PC.
Porting to ESP8266 requires Arduino IDE testing.

## Recent changes (T25) — microjs: ultra-compact JS engine for games

**Goal:** replace mquickjs with a from-scratch engine optimized for
maximum speed and minimum memory, at the cost of compatibility.
Designed specifically for game scripting on the 64×64 framebuffer.

**Files:**
- `mquickjs_lib/microjs.h` — single-header engine (~2700 lines).
  Drop-in alternative to mquickjs.  Includes lexer, single-pass
  recursive-descent parser → bytecode emitter, stack-based VM,
  mark-sweep GC stub, atom table, all in one pre-allocated buffer.
- `scripts/mjs_test.c` — PC-side test that compiles with gcc.

**Architecture:**

| Aspect | mquickjs | microjs |
|---|---|---|
| Numbers | `double` (8 B) | **int30** (4 B tagged value, -536M..536M) |
| Value encoding | 32-bit tagged | 32-bit tagged (or 64-bit on x86_64 for testing) |
| Opcodes | variable length | **1 byte + inline imm** (8/16/24-bit) |
| Heap | bump+compact arena | bump+freelist+mark-sweep |
| Parser | recursive | recursive descent, single-pass, no AST in RAM |
| try/catch | native | **none** (errors halt) |
| Float path | softfloat | **none** (no float at all) |
| TypedArray/RegExp/Date | yes | **no** |
| `===` | yes | `===` parsed as `==` (one number type) |

**Memory layout (single malloc'd buffer):**
```
[MJSContext header ~10 KB]
[atom table 2 KB]
[atom strings 2 KB]
[const pool 2 KB]
[top-level bytecode 2 KB]
[function body bytecode 2 KB]
[function metadata 4 KB]
[heap objects (bump+freelist)]
  ... free space ...
[value stack 1/4 of buffer, grows down]
```

**Supported (verified by PC tests):**
- `var`/`let`/`const` declarations
- Integer arithmetic (+, -, *, /, %, &, |, ^, <<, >>, >>>)
- Comparison (==, !=, <, <=, >, >=)
- Control flow: `if/else` (numeric conditions), `while`, `do/while`, `return`
- Functions (declarations + expressions) with parameters
- Array literals `[1, 2, 3]` and `arr[i]` access
- Object literals `{x: 1, y: 2}` and `obj.prop` access
- String literals (basic, no escapes)
- Native C function registration via `mjs_register_global`
- Native object setup via `mjs_new_object` + `mjs_set_property`
- `print()`, `tft.*`, `millis()`, `keys()` etc. (whatever the .ino registers)

**Not yet working (known bugs):**
- `if/else` with string-literal branches (segfault — likely a string
  interning issue in the constant pool when strings are used as
  standalone expressions inside blocks).
- `for (init; cond; post)` loops (parser issue with the second `;`).
- `obj.prop = value` assignment (compound lvalue paths incomplete).
- `try/catch`, `throw` — by design (use error return codes from natives).

**Integration with quickjs_esp8266.ino (TODO):**

The microjs API is intentionally similar to mquickjs's qjs_* wrapper:

```c
#include "microjs.h"
#define MJS_IMPLEMENTATION
#include "microjs.h"

#define JS_HEAP_SIZE (12 * 1024)
static MJSContext *g_ctx;

void setup() {
    static uint8_t js_buf[JS_HEAP_SIZE] __attribute__((aligned(4)));
    g_ctx = mjs_init(js_buf, sizeof(js_buf));
    mjs_register_global(g_ctx, "print", js_print);
    mjs_register_global(g_ctx, "millis", js_millis);

    MJSValue tft = mjs_new_object(g_ctx);
    mjs_set_property(g_ctx, tft, "cls",
        mjs_new_cfunction(g_ctx, js_tft_cls, "cls"));
    mjs_set_global_value(g_ctx, "tft", tft);
}
```

Native function signature:

```c
/* mquickjs: */                       /* microjs: */
JSValue fn(JSContext*,                MJSValue fn(MJSContext*,
            JSValue*,                              int argc,
            int,                                   MJSValue *argv);
            JSValue*);
```

Most existing native functions translate mechanically:

```c
/* Old (mquickjs) */
JSValue js_millis(JSContext *ctx, JSValue *tv, int argc, JSValue *argv) {
    return JS_NewInt32(ctx, (int32_t)millis());
}
/* New (microjs) */
MJSValue js_millis(MJSContext *ctx, int argc, MJSValue *argv) {
    (void)argc; (void)argv;
    return mjs_int((int32_t)millis());
}
```

**Status:** preview/beta.  Compiles and runs basic scripts on x86_64.
Porting to ESP8266 requires fixing remaining parser bugs first.
mquickjs remains the production engine; microjs is experimental.

**Build the PC test:**
```bash
cd scripts
gcc -g -O0 -o mjs_test mjs_test.c -lm
./mjs_test
```

## Recent changes (T24) — memory diet

**Goal:** free up system RAM without sacrificing the ES6/softfloat/GC
features that mquickjs provides over picojs/MuJS/mJS/r8e.

**Changes (Level 1 — applied to source):**
- `JS_HEAP_SIZE`: 16 KB → 12 KB  (`quickjs_esp8266.ino:236`).
  The largest tested sample (256-color palette test + animation loop)
  peaks at ~9 KB used JS-heap, leaving ~3 KB headroom.  Frees **+4 KB**
  of system heap (visible via `mem()`).
- `MAX_CODE_LEN`: 6 KB → 4 KB  (`quickjs_esp8266.ino:216`).  Frees
  **+2 KB** peak heap during each HTTP `/run` request.
- `WiFi.setSleep(true)` added after `softAP()`  (`quickjs_esp8266.ino:2231`).
  Frees **+1–2 KB** peak heap during idle beacon intervals.
- `QJS_MAX_TIMERS`: 8 → 4  (`quickjs_esp.h:382`).  Frees 48 B BSS.
  Realistic REPL usage never exceeds 2 concurrent timers.

**Changes (Level 2 — gated by `#define` in `espboy_stdlib.c`):**
- `ESPBOY_NO_TYPED_ARRAYS` — drops Int8Array, Uint8Array, …, Float64Array,
  Uint8ClampedArray, ArrayBuffer (10 classes).  None are used in the .ino,
  webui samples, or help panel.  Saves ~6 KB flash + ~1 KB RAM (atom table).
- `ESPBOY_NO_REGEXP` — drops the RegExp class.  No JS sample uses it.
  String.match/search/replaceAll become no-ops.  Saves ~3 KB flash + ~400 B RAM.
- `ESPBOY_NO_DATE` — drops the Date class.  `performance.now()` still works.
  Saves ~1 KB flash + ~300 B RAM.
- `ESPBOY_NO_RARE_ERRORS` — drops EvalError, ReferenceError, URIError,
  InternalError.  KEEPS Error, RangeError, SyntaxError, TypeError (used by
  C code via `JS_Throw*`).  Saves ~1 KB flash + ~500 B RAM.

**Important — after toggling any Level 2 flag you MUST:**
1. Re-run `./build_stdlib.sh` on a Linux/macOS host.
2. Copy the regenerated `espboy_stdlib.h` + `espboy_atom.h` back.
3. Re-count CFUNC indices via `python3 scripts/find_cfunc_indices.py` and
   update the `JS_CFUNC_IDX_*` constants in `quickjs_esp.h` — the indices
   of `tft.*`/`print`/`millis`/etc shift downward as upstream CFUNC entries
   are removed.

**Optional (Level 3 — uncomment in `espboy_stdlib.c` for more savings):**
- `ESPBOY_NO_MATH_TRIG` — drops sin/cos/tan/asin/acos/atan/atan2/exp/log/
  log2/log10/sqrt/pow/sign/imul/clz32/fround/trunc.  KEEPS floor/round/abs/
  min/max/random + constants.  This also lets libm.c drop most of its code
  (~50 KB flash).  Risk: breaks user scripts that call `Math.sqrt()` etc.

**Total expected savings:**
- Level 1 alone: **+5–6 KB free system heap** (no rebuild needed).
- Level 1 + Level 2: **+5–6 KB free heap + ~11 KB flash + ~2.2 KB RAM**
  (atom table is allocated inside the JS heap arena, so the RAM savings
  show up as `jsmem()` going up, not `mem()`).

## Recent changes (T19)

**Bug fix — broken globals (`palette`, `setTimeout`, `setInterval`, `rand`,
`Math.random`):** the constants `JS_CFUNC_IDX_RAND/SET_TIMEOUT/SET_INTERVAL/
CLEAR_TIMER/PALETTE` in `quickjs_esp.h` were pointing at the wrong indices
in `c_function_table`. They were set to `86..90` (the count of *upstream-only*
entries), but the actual ESPboy-extended table has 169 entries before the
extra block — so our globals were silently bound to unrelated math functions:

| JS global | Was bound to (wrong) | Now bound to (correct) |
|-----------|---------------------|------------------------|
| `rand()`        | `js_asin` (idx 86)  | `js_rand` (idx 169) |
| `Math.random()` | `js_asin` (idx 86)  | `js_rand` (idx 169) |
| `setTimeout`    | `js_acos` (idx 87)  | `js_setTimeout` (idx 170) |
| `setInterval`   | `js_atan` (idx 88)  | `js_setInterval` (idx 171) |
| `clearTimeout`  | `js_atan2` (idx 89) | `js_clearTimer` (idx 172) |
| `palette()`     | `js_exp` (idx 90)   | `js_palette` (idx 173) |

Visible symptoms before the fix:
- `Math.random()` returned `NaN`
- `rand()` returned `NaN`
- `palette()` returned `NaN` and didn't actually set the palette
- `setInterval(fn, 50)` returned `NaN` — no timer was registered, so the
  event loop was a no-op and callback functions never fired
- Custom palette sample (`palette(0,'red'); tft.fill(0); ...`) silently
  filled the screen with black instead of red/green/blue stripes

After the fix all of these work correctly — verify with the "CustomPal"
and "Palette" sample chips in the web UI.

**Improved error reporting:** both syntax errors and runtime errors now
report `error_line`, `error_col`, `error_file`, `error_token`, and
`error_src_line` in the `/run` JSON response. Previously only syntax
errors carried location info — runtime errors like "not a function" or
"variable is not defined" only had the bare message.

Examples (after the fix):

```json
// Runtime: variable is not defined
{"error":"variable 'foo' is not defined",
 "error_file":"/run","error_line":3,"error_col":1,
 "error_token":"foo",
 "error_src_line":"foo();",
 "error_stack":"    at <eval> (/run:3:1)\n"}

// Runtime: not a function
{"error":"not a function",
 "error_file":"/run","error_line":1,"error_col":13,
 "error_token":"x",
 "error_src_line":"var x = 5; x();",
 "error_stack":"    at <eval> (/run:1:13)\n"}

// Syntax: expecting ',' (col points at the offending char)
{"error":"expecting ','",
 "error_file":"/run","error_line":1,"error_col":14,
 "error_token":"'hello'",
 "error_src_line":"print('hello';",
 "error_stack":"    at /run:1:14\n"}
```

The web UI renders:
- A red highlight bar over the offending line in the editor overlay
- The error message with `at line N col M`
- The offending source line with a `^` caret pointing at the column
- The "near token" (e.g. `x`, `x.foo`, `'hello'`, `null.foo`, `10`)
- The full stack trace (including function names for nested calls)

**Web UI additions:**
- New `? Help` button toggles an inline API reference panel listing all
  globals, tft.\* methods, palette API, color names, button bit masks,
  built-in JS objects, and the file save workflow (8 sections, 47 rows).
- Sample chips now use `data-sample` attributes + event delegation
  (instead of inline `onclick="loadSample('...')"`), which fixes the
  `Uncaught SyntaxError: missing ) after argument list` browser errors
  that nested single-quotes caused on the `(index)` page.

## Quick start (T14 / mquickjs)

1. Install the **ESP8266 board package** in Arduino IDE
   (Boards Manager → "esp8266 by ESP8266 Community" >= 3.0.0).
2. Install **TFT_eSPI** by Bodmer (Library Manager → "TFT_eSPI" v2.2.6+).
3. Configure TFT_eSPI's `User_Setup.h` for ST7735 128x128 GREENTAB3
   (see comment block at top of `quickjs_esp8266.ino`).
4. Copy **ALL files** from `mquickjs_lib/` into the same folder as
   `quickjs_esp8266.ino` (Arduino IDE treats every .c/.cpp/.h in the
   sketch folder as part of the build).
5. Tools menu:
   - Board: "Generic ESP8266 Module" or "NodeMCU 1.0"
   - Flash Size: **"4MB (FS:2MB OTA:~1MB)"** — must include a filesystem
   - Upload Speed: 115200
6. (Optional) Add `-DUSE_SOFTFLOAT` to build flags for the no-FPU path.
   Set via Tools > "Build Optimization" or in `platform.local.txt`
   next to the ESP8266 core.
7. Upload, open Serial Monitor at 115200 baud, note the IP address.
8. Join the "QuickJS-AP" WiFi network (open, no password).
9. Browse to `http://192.168.4.1/` and start writing JavaScript.

## Regenerating espboy_stdlib.h

If you add or remove native functions in `espboy_stdlib.c`, you must
regenerate the two header files on a Linux/macOS host:

```bash
cd mquickjs_lib
./build_stdlib.sh
# outputs: espboy_stdlib.h, espboy_atom.h
```

Then copy those two .h files back to the sketch folder. The Arduino IDE
will pick them up on next compile.

## JavaScript API

> **T20 architecture change (framebuffer + PROGMEM palette):**
> The display is now driven through a 64×64 byte-indexed framebuffer
> (each byte = palette index 0..255).  The framebuffer is scaled 2× at
> flush time to fill the 128×128 ST7735.  The palette lives in PROGMEM
> (immutable).  All `tft.*` color arguments must be **numbers** (palette
> indices 0..255) — strings are no longer accepted.  JS code controls
> frame rate by calling `tft.flip()` after drawing; the background
> `loop()` flushes dirty rows to the TFT at ≤15 FPS.

### Globals
```javascript
print(...args)              // print + serial
console.log/warn/error/info(...args)
millis()                    // ms since boot
delay(ms)                   // yield-friendly sleep
mem()                       // system free heap (ESP.getFreeHeap)
jsmem()                     // JS-heap free bytes (T23) — independent of mem()
gc()                        // force JS_GC (frees unreachable JS objects)
keys()                      // 8-bit button mask (bit 0 = A, bit 7 = ...)
backlight(v)                // MCP4725 DAC 0..4095
rand()                      // random float in [0,1)  (xorshift64*)
Math.random()               // same as rand()  (overrides ROM default)
setTimeout(fn, ms)          // one-shot timer (returns id)
setInterval(fn, ms)         // repeating timer (returns id)
clearTimeout(id)            // cancel timer (works for both setTimeout/setInterval)
clearInterval(id)           // alias for clearTimeout
palette(i)                  // 256-color palette GET (read-only, PROGMEM)
```

**`mem()` vs `jsmem()` — important distinction (T23):**
- `mem()` returns bytes free in the **system heap** (ESP8266 DRAM
  shared with WiFi, TFT, LittleFS, and the JS heap buffer itself).
- `jsmem()` returns bytes free **inside the JS engine's isolated 16 KB
  heap** — the pool that holds JS objects, strings, arrays, and parsed
  bytecode.  Filling this pool triggers "Out of memory" exceptions;
  calling `gc()` reclaims unreachable objects.
- The two are independent: `var a = [1,2,3]` decreases `jsmem()` but
  not `mem()`.  Growing `JS_HEAP_SIZE` decreases `mem()` by the same
  amount (since the JS heap is `malloc`'d from the system heap).

### tft.* methods (64×64 framebuffer, scaled 2× to 128×128)
```javascript
tft.cls()                                     // clear FB to palette[0] (black)
tft.fill(c)                                   // fill FB with palette[c]
tft.pixel(x, y, c)                            // single pixel at FB coords (0..63)
tft.rect(x, y, w, h, c)                       // rectangle outline
tft.fillRect(x, y, w, h, c)                   // filled rectangle
tft.line(x0, y0, x1, y1, c)                   // Bresenham line
tft.circle(cx, cy, r, c)                      // circle outline
tft.disc(cx, cy, r, c)                        // filled circle
tft.text(x, y, str, c, size=1)                // 5×7 font, size 1..4
                                              // str accepts UTF-8: Russian
                                              // А..Я а..я Ёё are decoded to
                                              // CP1251 and rendered via the
                                              // 256-glyph font_a (ESPboy LGE).
                                              // Other non-ASCII chars → '?'
tft.sprite(x, y, w, h, colors)                // blit palette indices to FB
tft.spriteMask(x, y, w, h, colors, mask)      // skip pixels where color == mask
tft.getpixel(x, y)                            // -> palette index at (x, y)
tft.flip()                                    // mark all 64 rows dirty
tft.width()                                   // -> 64
tft.height()                                  // -> 64
```

### Colors — palette indices only (NUMBERS)
Color arguments must be a **number** 0..255 (palette index). Strings
are no longer accepted — the palette is immutable (PROGMEM).

### 256-color palette (PROGMEM, immutable)
The palette lives entirely in flash (512 bytes) and cannot be modified
at runtime.  Layout matches xterm-256 so terminal users know the indices:
- `0..15`     — CGA/VGA 16 colors (black, red, green, yellow, blue,
  magenta, cyan, white, then bright variants)
- `16..231`   — 6×6×6 color cube: index = `16 + 36*r + 6*g + b` where
  `r,g,b ∈ 0..5` map to levels `{0, 95, 135, 175, 215, 255}`
- `232..255`  — 24-step grayscale ramp: RGB = `8 + 10*level` (8..238)

```javascript
palette()           // -> 256 (palette size)
palette(i)          // -> RGB565 value of slot i (0..255, read-only)
```

### Frame rate and dirty-row flushing
- `tft.*` primitives write to the framebuffer in RAM and mark the
  affected rows dirty (a 64-bit bitmask `g_fb_dirty_rows`).
- `tft.flip()` marks ALL 64 rows dirty — call this after drawing a
  complete frame.
- The background `loop()` calls `display_tick()`, which throttle-flushes
  dirty rows to the TFT at ≤15 FPS (one frame per ~66 ms).  Only dirty
  rows are pushed (via `tft.pushRect`), so partial updates are cheap.
- The framebuffer is scaled 2× at flush time: each FB pixel becomes a
  2×2 block on the 128×128 screen.

Examples:
```javascript
// 256-color test pattern: 16x16 grid of 4x4 cells (fits in 64x64 FB)
tft.cls();
for (var i = 0; i < 256; i++)
    tft.fillRect((i % 16) * 4, Math.floor(i / 16) * 4, 3, 3, i);
tft.text(2, 56, "256 colors", 7, 1);
tft.flip();                // push the frame at the next 15 FPS tick

// Animation loop using setInterval
setInterval(function() {
    tft.cls();
    tft.disc(32, 32, 10 + Math.floor(Math.random() * 5), 1 + (millis() / 100) % 256);
    tft.flip();
}, 100);
```

### HTTP API
- `GET /` — HTML REPL page (browser-based code editor with Run/Save buttons)
- `POST /run` — body is JS source; response is JSON
  `{"result":"...","stdout":"...","ms":N,"mem":N}`
- `POST /save` — body is JS source; saves to LittleFS `/boot.js`
- `GET /load` — returns the saved boot script as plain text
- `POST /clear` — deletes `/boot.js`
- `GET /mem` — JSON with `free_heap`, `flash_size`, `fs_total`, `fs_used`, etc.
- Any other URL — 302 redirect to `/` (captive portal)

### Serial REPL
At 115200 baud, type JS and press Enter. Multi-line input via trailing
backslash (`\`). Prompt is `quickjs>`.

### Button A
Press button A (GPA0 on MCP23017) to run the saved boot script.
On first run with no saved code, you'll see "no code" on the TFT
for ~800 ms, then the WiFi splash returns.

### Initial screen (splash)

The 64×64 framebuffer (scaled 2× to 128×128) only fits ~10 chars per
line and ~8 lines of text, so the splash shows the bare minimum:

```
       QuickJS         <- title (yellow)
                       <- blank
       QuickJS-AP      <- SSID (white)
                       <- blank
       192.168.4.1     <- IP address (yellow)
                       <- blank
       [A] run         <- button hint (green) or "no code" (grey)
```

The old splash also showed NET security, URL prefix, `[AP]` mode badge,
client count, and DAC status — those were removed in T22 to fit the
smaller framebuffer.  All that info is still on the Serial Monitor.

## Differences from picojs version (T1-T13)

| Aspect | picojs (T1-T13) | mquickjs (T14) |
|--------|-----------------|----------------|
| JS engine | Custom minimal interpreter | Bellard's mquickjs |
| Language | Custom subset (no `===`) | ES5 + ES6 subset (strict mode) |
| `===` / `!==` | Not supported | Supported |
| Array.reduce | Custom impl | Native |
| JSON | Custom impl | Native |
| Try/catch | setjmp/longjmp | Native |
| Closures | Custom impl | Native |
| GC | Manual `picojs_cleanup()` | Tracing + compacting (automatic) |
| Heap | System heap (malloc) | Isolated 16 KB buffer |
| Storage | EEPROM (2 KB max, no wear-leveling) | LittleFS (32 KB max, power-loss safe) |
| Boot script path | EEPROM bytes 8..2055 | LittleFS `/boot.js` |
| Storage corruption risk | High (sudden power loss) | None (atomic writes) |
| Exception (3) crashes | Yes (T13 leak) | None observed |

---

# PicoJS extended — ESP8266 JavaScript REPL

Extended version of [corax89/PicoJS](https://github.com/corax89/Picojs) with
class/new/this, typeof, switch/break/continue, try/catch/throw, instanceof,
compound assignment, Math, String, Array, JSON built-in objects, and a
128×128 16-color TFT graphics API.

## Files

| File | Description |
|------|-------------|
| `picojs.h` | Single-header JavaScript interpreter (extended). `#define PICOJS_IMPLEMENTATION` before `#include`. |
| `picojs_esp8266.ino` | Arduino sketch for ESP8266: built-in web server + browser REPL page + 128×128 TFT graphics. |

## Quick start (ESP8266)

1. Install the **ESP8266 board package** in Arduino IDE
   (Boards Manager → search "esp8266" → install).
2. Install the **TFT_eSPI** library by Bodmer (Library Manager → "TFT_eSPI").
3. Configure TFT_eSPI's `User_Setup.h` (in `libraries/TFT_eSPI/`) for your
   128×128 display — see the comment block at the top of `picojs_esp8266.ino`
   for the recommended pin assignments and driver defines.
4. Open `picojs_esp8266.ino` — `picojs.h` must be in the same folder.
5. Set `WIFI_SSID` / `WIFI_PASS` at the top of the `.ino`.
   Leave `WIFI_SSID` empty to start an access point instead.
6. Select your board (e.g. "NodeMCU 1.0 (ESP-12E Module)"), upload.
7. Open Serial Monitor at **115200 baud** — note the IP address printed.
8. Browse to `http://<ip>/` and start typing JavaScript.

The web REPL works without TFT_eSPI — comment out `#define PICOJS_GFX_ENABLE`
at the top of the `.ino` to build with all gfx calls compiled out as no-ops.

## Supported JavaScript features

### Original PicoJS (preserved)
- `var` / `let` / `const` declarations
- Numbers, strings, booleans, `null`, `undefined`
- Objects `{}` and arrays `[]`
- `function` declarations and expressions (closures)
- `if` / `else`, `while`, `for`, `return`
- `this` (in method calls)
- Bitwise operators (`& | ^ << >> >>>`)
- Comparison, logical, arithmetic operators
- Native function registration via `picojs_register()`

### Added in this build
- **`typeof`** — returns `"number"`, `"string"`, `"boolean"`, `"object"`, `"function"`, `"undefined"` (`typeof null` → `"object"`, per JS spec)
- **`switch` / `case` / `default`** — with fallthrough semantics
- **`break` / `continue`** — in loops and switch
- **`try` / `catch` / `finally` / `throw`** — setjmp/longjmp-based exception handling
- **`class`** — with `constructor`, instance methods, `static` methods, automatic prototype chain
- **`new`** — creates instance, calls constructor with `this` = new object
- **`instanceof`** — walks prototype chain
- **Compound assignment** — `+=`, `-=`, `*=`, `/=`, `%=`
- **`Math`** object — `PI`, `E`, `abs`, `floor`, `ceil`, `round`, `sqrt`, `pow`, `min`, `max`, `random`, `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `atan2`, `log`, `exp`, `sign`, `trunc`
- **String methods** — `length`, `charAt`, `charCodeAt`, `indexOf`, `lastIndexOf`, `substring`, `substr`, `slice`, `toUpperCase`, `toLowerCase`, `trim`, `split`, `replace`, `concat`, `includes`, `startsWith`, `endsWith`, `repeat`, `toString`, `valueOf`
- **String[i]** — single character access
- **Array methods** — `push`, `pop`, `shift`, `unshift`, `indexOf`, `lastIndexOf`, `includes`, `join`, `slice`, `reverse`, `concat`, `length`
- **`String.fromCharCode(c1, c2, ...)`** — static method
- **`Array.isArray(x)`** — static method
- **`JSON.parse(s)`** — parses JSON strings into values
- **`JSON.stringify(v)`** — serializes values to JSON strings
- **Boolean formatting** — `true` / `false` (not `1` / `0`)
- **Array toString** — `[1,2,3].toString()` → `"1,2,3"`

## Native functions available on ESP8266

| Function | Description |
|----------|-------------|
| `print(...)` | Print args to Serial + web output |
| `millis()` | Milliseconds since boot |
| `delay(ms)` | Yield-friendly delay |
| `pinMode(p, m)` | Configure pin (alias: `pm`) |
| `digitalWrite(p, v)` | Set pin high/low (alias: `dw`) |
| `digitalRead(p)` | Read pin (alias: `dr`) |
| `analogRead(p)` | Read ADC (ESP8266 has only A0) (alias: `ar`) |
| `led(v)` | Toggle onboard LED |
| `mem()` | Free heap in bytes |
| `gc()` | Force garbage collection |
| `key()` | Read one char from Serial (or `""`) |

## GFX API (128×128 TFT via TFT_eSPI)

A 16-color palette framebuffer (8 KB) with per-line dirty tracking — only
the rows that actually changed since the last frame are pushed to the TFT.

| Method | Description |
|--------|-------------|
| `gfx.cls(c?)` | Clear to palette color c (default: current bg) |
| `gfx.color(fg, bg?)` | Set current fg (and bg) palette indices 0..15 |
| `gfx.pixel(x, y, c?)` | Plot a pixel |
| `gfx.line(x0,y0,x1,y1,c?)` | Bresenham line |
| `gfx.rect(x,y,w,h,c?)` | Rectangle outline |
| `gfx.fill(x,y,w,h,c?)` | Filled rectangle |
| `gfx.circle(cx,cy,r,c?)` | Circle outline (midpoint algorithm) |
| `gfx.disc(cx,cy,r,c?)` | Filled circle (scanline fill) |
| `gfx.text(x,y,str,fg?,bg?)` | Draw 5×7 text (CP1251 + Russian, UTF-8 input) |
| `gfx.show()` | Flush dirty lines to TFT (also auto-called after each `/run`) |
| `gfx.setPalette(i, rgb565)` | Overwrite palette entry i |
| `gfx.setColorRGB(i, r, g, b)` | Same with 8-bit RGB inputs |
| `gfx.width()` / `gfx.height()` | Return 128 / 128 |
| `gfx.fg(c?)` / `gfx.bg(c?)` | Get or set current fg / bg |

Default palette is CGA-style 16 colors (black, blue, green, cyan, red,
magenta, brown, light gray, dark gray, light blue, light green, light cyan,
light red, light magenta, yellow, white) mapped to RGB565.

**Dirty-line flush:** every draw call sets the dirty bit on each row it
writes to. On `gfx.show()` (or automatically at the end of each `/run`),
only the rows whose dirty bit is set are converted from 4-bit palette
indices to RGB565 and pushed to the TFT. The dirty mask is then cleared.
A full screen redraw costs ~128 SPI row-writes; a small 16-pixel-tall
sprite costs only ~16.

```js
// Bouncing balls demo (auto-flush at end of script)
gfx.cls(0);
var balls = [];
for (var i = 0; i < 8; i++) {
  balls.push({
    x: 64, y: 64,
    vx: Math.floor(Math.random()*7)-3,
    vy: Math.floor(Math.random()*7)-3,
    c: i + 1
  });
}
for (var frame = 0; frame < 60; frame++) {
  gfx.cls(0);
  for (var i = 0; i < balls.length; i++) {
    var b = balls[i];
    b.x += b.vx; b.y += b.vy;
    if (b.x < 4 || b.x > 124) b.vx = -b.vx;
    if (b.y < 4 || b.y > 124) b.vy = -b.vy;
    gfx.disc(b.x, b.y, 4, b.c);
  }
  gfx.show();
  delay(33);
}
```

## HTTP API

| Method | Path | Body | Response |
|--------|------|------|----------|
| GET | `/` | — | HTML REPL page |
| POST | `/run` | raw JS code | `{"result":...,"stdout":...,"error":...,"ms":...,"mem":...}` |
| GET | `/mem` | — | `{"free_heap":...,"flash_size":...,"chip_id":...}` |

## Testing on PC

The header also works standalone (for development/testing):

```bash
gcc -Wall -o test test.c -lm
./test
```

Example `test.c`:
```c
#define PICOJS_IMPLEMENTATION
#include "picojs.h"
#include <stdio.h>

picojs_val native_print(int argc, picojs_val* argv) {
    for (int i = 0; i < argc; i++) {
        if (i) putchar(' ');
        fputs(picojs_to_str(argv[i]), stdout);
    }
    putchar('\n');
    return picojs_undef();
}

int main(void) {
    picojs_init();
    picojs_register("print", native_print);
    picojs_exec_safe("class Point { constructor(x,y){this.x=x;this.y=y;} "
                     "sum(){return this.x+this.y;} }"
                     "var p = new Point(3,4); print(p.sum());");
    picojs_cleanup();
    return 0;
}
```

## Memory footprint on ESP8266

| Component | Approximate flash | Approximate RAM |
|-----------|-------------------|-----------------|
| mquickjs interpreter | ~100 KB | ~2 KB (globals + ctx) |
| Built-in objects (Math/String/Array/JSON) | ~8 KB | ~1 KB |
| **JS heap** (T23 grew 12 → 16 KB) | 0 | 16 KB (malloc'd) |
| **Framebuffer** (64×64 bytes) | 0 | 4 KB |
| **Palette** (256 × RGB565) | 0.5 KB (PROGMEM) | 0 |
| Dirty-row mask + scanline buffer | 0 | 0.5 KB |
| 5×7 CP1251 font (256 glyphs incl. Russian) | 1.25 KB (PROGMEM) | 0 |
| Stdout/error/stack capture buffers (T23 diet) | 0 | 0.75 KB (was 2.8 KB) |
| **Saved boot script** (T23: no RAM mirror) | 0 | **0** (was up to 12 KB!) |
| WiFi + HTTP server | ~250 KB | ~10 KB |
| **Total** | **~360 KB** | **~34 KB free** (was ~17 KB free) |

**T23 changes — major memory overhaul:**

1. **Removed saved boot-script RAM mirror (saves up to 12 KB RAM).** The
   previous code held a heap-allocated copy of `/boot.js` in RAM for the
   lifetime of the program.  Now we only store `saved_code_exists` (bool)
   and `saved_code_size` (size_t) — 5 bytes total.  Button A reads
   `/boot.js` from LittleFS into a temporary buffer, runs it, then frees
   the buffer.  HTTP `/load` streams the file directly in 256-byte
   chunks (`sendContent()`) with no full-file RAM copy.

2. **Grew JS heap 12 KB → 16 KB (+4 KB for scripts).** Paid for by
   the saved_code removal (~12 KB saved) and by further shrinking the
   capture buffers (next bullet).  Net change to `ESP.getFreeHeap()`:
   **+8 KB more free system RAM** compared to T22.

3. **Shrunk capture buffers in `quickjs_esp.h` (saved ~700 B BSS).**
   `g_out_buf` 1024 → 512, `g_stack_buf` 256 → 128, `g_err_buf` 192 →
   128.  Total BSS saved vs original (T22+T23): 2048 bytes.  Output
   beyond 511 bytes silently truncates in the JSON response — Serial
   output is unaffected.

4. **New `jsmem()` JS global — real JS-heap free memory query.**
   Returns free bytes inside the 16 KB JS pool via a new
   `JS_GetFreeMem()` API added to mquickjs.  Independent of `mem()`
   which returns system free heap.  Useful for OOM-aware scripts and
   for profiling how much JS-heap an operation consumes.  Example:
   ```javascript
   print(mem(), jsmem());  // e.g. "27832 14592"
   gc();                    // run JS garbage collector
   print(jsmem());          // e.g. "15200" (reclaimed some)
   ```
   The HTTP `/mem` endpoint now also reports `js_heap_total` and
   `js_heap_free` for remote monitoring.

**T22 BSS diet (kept, not reinvested):** the stdout / error / stack
trace capture buffers in `quickjs_esp.h` were originally 2.8 KB.  T22
shrunk them to 1.4 KB; T23 further squeezed them to 0.75 KB.  The
savings are NOT reinvested into the JS heap directly (JS heap already
grew to 16 KB thanks to the saved_code removal — see above).

**Per-request /run body limit:** `MAX_CODE_LEN` is 6 KB (down from
8 KB) to lower peak heap usage during a request.  Saved boot scripts
(`MAX_SAVED_CODE_LEN`) remain at 12 KB.  Serial REPL paste limit is
2 KB.

## License

MIT — same as upstream PicoJS.
