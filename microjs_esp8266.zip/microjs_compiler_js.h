/* Auto-generated from microjs_compiler.js (minified).
 * Generated: 2026-08-27T19:04:09.032Z
 * Source: /home/z/my-project/download/microjs_compiler.js
 * Original size: 135332 bytes
 * Minified size: 54102 bytes (40.0%)
 *
 * DO NOT EDIT — regenerate via:
 *   node /home/z/my-project/scripts/minify_compiler.js
 */
#ifndef MICROJS_COMPILER_JS_H
#define MICROJS_COMPILER_JS_H

static const char MICROJS_COMPILER_JS[] PROGMEM = R"JS(
const OP={NOP:0,UNDEF:1,NULL:2,TRUE:3,FALSE:4,INT8:5,INT16:6,INT24:7,CONST:8,LOAD_LOCAL:9,STORE_LOCAL:10,LOAD_GLOBAL:11,STORE_GLOBAL:12,POP:13,DUP:14,SWAP:15,LOAD_PROP:16,STORE_PROP:17,LOAD_INDEX:18,
STORE_INDEX:19,NEW_OBJECT:20,NEW_ARRAY:21,ADD:24,SUB:25,MUL:26,DIV:27,MOD:28,NEG:29,INC:30,DEC:31,AND:32,OR:33,XOR:34,SHL:35,SHR:36,USHR:37,BNOT:38,LNOT:39,EQ:40,NE:41,LT:42,LE:43,GT:44,GE:45,JMP:48,
JZ:49,JNZ:50,CALL:51,CALL_METHOD:52,RET:53,RET_UNDEF:54,HALT:55,FUNCTION:56,STRICT_EQ:57,STRICT_NE:58,TYPEOF:59,INSTANCEOF:60,FOR_IN_NEXT:61,FOR_OF_NEXT:62,DEFINE_ACCESSOR:63,PUSH_TRY:64,POP_TRY:65,
THROW:66,NEW:67,THIS:68,CALL_WITH_THIS:69,NATIVE_CALL:70,NEW_ARRAY_U8:71,NEW_ARRAY_U16:72,NEW_ARRAY16:73,TO_NUMBER:74,LAST:75};const TK={EOF:0,IDENT:1,INT:2,STRING:3,LPAREN:4,RPAREN:5,LBRACE:6,
RBRACE:7,LBRACKET:8,RBRACKET:9,SEMI:10,COMMA:11,DOT:12,COLON:13,QUESTION:14,ASSIGN:15,PLUS:16,MINUS:17,STAR:18,SLASH:19,PERCENT:20,INC:21,DEC:22,EQ:23,NE:24,LT:25,LE:26,GT:27,GE:28,AND:29,OR:30,
BNOT:31,LNOT:32,BAND:33,BOR:34,XOR:35,SHL:36,SHR:37,USHR:38,PLUSEQ:39,MINUSEQ:40,STAREQ:41,SLASHEQ:42,PERCENTEQ:43,ANDEQ:44,OREQ:45,XOREQ:46,SHLEQ:47,SHREQ:48,USHREQ:49,AMPAMP:50,PIPEPIPE:51,VAR:52,
LET:53,CONST:54,FUNCTION:55,RETURN:56,IF:57,ELSE:58,WHILE:59,DO:60,FOR:61,BREAK:62,CONTINUE:63,NEW:64,IN:65,TRUE:66,FALSE:67,NULL:68,UNDEFINED:69,TYPEOF:70,INSTANCEOF:71,DELETE:72,VOID:73,
STRICT_EQ:74,STRICT_NE:75,OF:76,SWITCH:77,CASE:78,DEFAULT:79,TRY:80,CATCH:81,THROW:82,FINALLY:83,THIS:84,ARROW:85,TEMPLATE:86,OPTCHAIN:87,NULLISH:88};const KEYWORDS={var:TK.VAR,let:TK.LET,
const:TK.CONST,function:TK.FUNCTION,return:TK.RETURN,if:TK.IF,else:TK.ELSE,while:TK.WHILE,do:TK.DO,for:TK.FOR,break:TK.BREAK,continue:TK.CONTINUE,new:TK.NEW,in:TK.IN,of:TK.OF,true:TK.TRUE,
false:TK.FALSE,null:TK.NULL,undefined:TK.UNDEFINED,typeof:TK.TYPEOF,instanceof:TK.INSTANCEOF,delete:TK.DELETE,void:TK.VOID,switch:TK.SWITCH,case:TK.CASE,default:TK.DEFAULT,try:TK.TRY,catch:TK.CATCH,
throw:TK.THROW,finally:TK.FINALLY,this:TK.THIS};class CompileError extends Error{constructor(msg,line,col,token,src_line){super(msg);this.name="CompileError";this.line=line;this.col=col
;this.token=token;this.src_line=src_line}}class MicroJSCompiler{constructor(){this.atoms=[];this.atomMap={};this.consts=[];this.constMap={};this.funcs=[];this.bc=[];this.body=[];this.src=""
;this.srcLines=[];this.lineMap=[];this.curLine=0
;this.knownGlobals=new Set(["print","millis","seconds","centis","delay","mem","jsmem","gc","reset","fetch","jsonSelect","jsonStream","parseInt","isNaN","getIP","beep","gcDebug","gcRoots","keys","keysPressed","keysReleased","backlight","rand","hexToColor","colorToHex","setTimeout","setInterval","clearTimeout","clearInterval","console","Math","Array","Object","String","RegExp","JSON","tft","http","files","i2c","spi","PI","NaN","LEFT","UP","DOWN","RIGHT","A","B","RGT","undefined","Infinity"])
}setKnownGlobals(arr){const merged=new Set(arr||[]);merged.add("undefined");merged.add("NaN");merged.add("Infinity");this.knownGlobals=merged}atom(s){if(void 0!==this.atomMap[s])return this.atomMap[s]
;if(this.atoms.length>=255)throw new CompileError("too many atoms",0,0,s,"");const id=this.atoms.length+1;this.atoms.push(s);this.atomMap[s]=id;return id}addConstNum(v){const key="n"+v
;if(void 0!==this.constMap[key])return this.constMap[key];if(this.consts.length>=255)throw new CompileError("too many consts",0,0,"","");const idx=this.consts.length;this.consts.push({type:0,value:v})
;this.constMap[key]=idx;return idx}addConstString(s){const key="s"+s;if(void 0!==this.constMap[key])return this.constMap[key]
;if(this.consts.length>=255)throw new CompileError("too many consts",0,0,"","");const idx=this.consts.length;this.consts.push({type:1,value:s});this.constMap[key]=idx;return idx}tokenize(src){
this.src=src;this.srcLines=src.split("\n");const tokens=[];let pos=0,line=1;const isIdentStart=c=>/[A-Za-z_$]/.test(c);const isIdent=c=>/[A-Za-z0-9_$]/.test(c);const isDigit=c=>c>="0"&&c<="9"
;while(pos<src.length){const c=src[pos];if(" "===c||"\t"===c||"\r"===c){pos++;continue}if("\n"===c){pos++;line++;continue}if("/"===c&&"/"===src[pos+1]){while(pos<src.length&&"\n"!==src[pos])pos++
;continue}if("/"===c&&"*"===src[pos+1]){pos+=2;while(pos+1<src.length&&("*"!==src[pos]||"/"!==src[pos+1])){"\n"===src[pos]&&line++;pos++}pos+1<src.length&&(pos+=2);continue}if(isIdentStart(c)){
let start=pos;while(pos<src.length&&isIdent(src[pos]))pos++;const word=src.slice(start,pos);void 0!==KEYWORDS[word]?tokens.push({kind:KEYWORDS[word],sval:word,line:line}):tokens.push({kind:TK.IDENT,
sval:word,line:line});continue}if(isDigit(c)){let n=0;let isFloat=!1;let fixedVal=0;if("0"!==c||"x"!==src[pos+1]&&"X"!==src[pos+1]){while(pos<src.length&&isDigit(src[pos])){
n=10*n+(src.charCodeAt(pos)-48);pos++}if("."===src[pos]){isFloat=!0;pos++;let frac=0;let divisor=1;while(pos<src.length&&isDigit(src[pos])){frac=10*frac+(src.charCodeAt(pos)-48);divisor*=10;pos++}
fixedVal=(n<<8)+Math.round(256*frac/divisor)}if("e"===src[pos]||"E"===src[pos]){pos++;"+"!==src[pos]&&"-"!==src[pos]||pos++;while(pos<src.length&&isDigit(src[pos]))pos++}}else{pos+=2
;while(pos<src.length&&/[0-9a-fA-F]/.test(src[pos])){n=n<<4|parseInt(src[pos],16);pos++}}tokens.push({kind:TK.INT,ival:n,fval:fixedVal,isFloat:isFloat,line:line});continue}if('"'===c||"'"===c){
const quote=c;pos++;let out="";while(pos<src.length&&src[pos]!==quote)if("\\"===src[pos]&&pos+1<src.length){const e=src[pos+1];const map={n:"\n",t:"\t",r:"\r","\\":"\\","'":"'",'"':'"',0:"\0"}
;out+=void 0!==map[e]?map[e]:e;pos+=2}else{"\n"===src[pos]&&line++;out+=src[pos];pos++}pos<src.length&&pos++;tokens.push({kind:TK.STRING,sval:out,line:line});continue}if("`"===c){pos++;let out=""
;while(pos<src.length&&"`"!==src[pos])if("\\"===src[pos]&&pos+1<src.length){const e=src[pos+1];const map={n:"\n",t:"\t",r:"\r","\\":"\\","`":"`",$:"$"};out+=void 0!==map[e]?map[e]:e;pos+=2}else{
"\n"===src[pos]&&line++;out+=src[pos];pos++}pos<src.length&&pos++;tokens.push({kind:TK.TEMPLATE,sval:out,line:line});continue}pos++;const two=c+(src[pos]||"");const three=two+(src[pos+1]||"")
;if("==="===three){tokens.push({kind:TK.STRICT_EQ,line:line});pos+=2;continue}if("!=="===three){tokens.push({kind:TK.STRICT_NE,line:line});pos+=2;continue}if(">>>"===three){tokens.push({kind:TK.USHR,
line:line});pos+=2;continue}if(">>>="===three){tokens.push({kind:TK.USHREQ,line:line});pos+=3;continue}const twoMap={"==":TK.EQ,"!=":TK.NE,"<=":TK.LE,">=":TK.GE,"&&":TK.AMPAMP,"||":TK.PIPEPIPE,
"++":TK.INC,"--":TK.DEC,"<<":TK.SHL,">>":TK.SHR,"+=":TK.PLUSEQ,"-=":TK.MINUSEQ,"*=":TK.STAREQ,"/=":TK.SLASHEQ,"%=":TK.PERCENTEQ,"&=":TK.ANDEQ,"|=":TK.OREQ,"^=":TK.XOREQ,"<<=":TK.SHLEQ,">>=":TK.SHREQ,
"=>":TK.ARROW,"?.":TK.OPTCHAIN,"??":TK.NULLISH};if(void 0!==twoMap[two]&&"=="!==two&&"!="!==two){tokens.push({kind:twoMap[two],line:line});pos++;continue}if("=="===two){tokens.push({kind:TK.EQ,
line:line});pos++;continue}if("!="===two){tokens.push({kind:TK.NE,line:line});pos++;continue}const oneMap={"(":TK.LPAREN,")":TK.RPAREN,"{":TK.LBRACE,"}":TK.RBRACE,"[":TK.LBRACKET,"]":TK.RBRACKET,
";":TK.SEMI,",":TK.COMMA,".":TK.DOT,":":TK.COLON,"?":TK.QUESTION,"=":TK.ASSIGN,"+":TK.PLUS,"-":TK.MINUS,"*":TK.STAR,"/":TK.SLASH,"%":TK.PERCENT,"<":TK.LT,">":TK.GT,"~":TK.BNOT,"!":TK.LNOT,"&":TK.BAND,
"|":TK.BOR,"^":TK.XOR};if(void 0===oneMap[c])throw new CompileError(`unexpected character '${c}'`,line,pos,c,this.srcLines[line-1]||"");tokens.push({kind:oneMap[c],line:line})}tokens.push({
kind:TK.EOF,line:line});return tokens}getNativeCallId(objName,methodName){if("tft"===objName){const map={pixel:0,rect:1,fillRect:2,cls:3,fill:4,line:5,circle:6,disc:7,text:8,flip:9,sprite:10,
spriteMask:11,width:12,height:13,getpixel:14};return void 0!==map[methodName]?map[methodName]:-1}return-1}emitByte(b,target=this.bc){if(b<0||b>255)throw new Error(`bad byte ${b}`)
;if(target===this.bc&&this.cur&&this.cur.line!==this.curLine){this.curLine=this.cur.line;this.lineMap.push({pc:target.length,line:this.curLine})}target.push(b)}emitU16(v,target=this.bc){
this.emitByte(255&v,target);this.emitByte(v>>8&255,target)}emitI16(v,target=this.bc){this.emitU16(65535&v,target)}emitInt(v){if(v>=0&&v<=255){this.emitByte(OP.INT8);this.emitByte(v)
}else if(v>=-32768&&v<=32767){this.emitByte(OP.INT16);this.emitI16(v)}else{this.emitByte(OP.INT24);this.emitByte(255&v);this.emitByte(v>>8&255);this.emitByte(v>>16&255)}}
emitPlaceholder(target=this.bc){const off=target.length;target.push(0,0);return off}patchJump(at,to,target=this.bc){const delta=to-(at+2);target[at]=255&delta;target[at+1]=delta>>8&255}parse(src){
this.tokens=this.tokenize(src);this.tokIdx=0;this.cur=this.tokens[0];this.nlocals=0;this.locals=[];this.breakStack=[];this.continueStack=[];this.bc=[];this.body=[];this.atoms=[];this.atomMap={}
;this.consts=[];this.constMap={};this.funcs=[];this.topLevelConsts={};this.lineMap=[];this.curLine=0;this.topLevelDecls=new Set;this.inTypeof=!1
;this.reservedNames=new Set(["print","millis","delay","mem","jsmem","gc","reset","parseInt","gcDebug","gcRoots","beep","fetch","jsonSelect","jsonStream","keys","keysPressed","keysReleased","backlight","rand","hexToColor","colorToHex","setTimeout","setInterval","clearTimeout","clearInterval","console","Math","Array","String","Object","RegExp","tft","JSON","http","files","PI","NaN","LEFT","UP","DOWN","RIGHT","A","B","RGT"])
;this.atom("Array");this.atom("String");this.atom("console");this.atom("Math");this.atom("push");this.atom("slice");this.atom("forEach");this.atom("isArray");this.atom("length");this.atom("charAt")
;this.atom("indexOf");this.atom("substring");this.atom("toUpperCase");this.atom("toLowerCase");this.atom("split");this.atom("replace");this.atom("match");this.atom("test");this.atom("floor")
;this.atom("round");this.atom("abs");this.atom("min");this.atom("max");this.atom("random");this.atom("pow");this.atom("sqrt");this.atom("sin");this.atom("cos");this.atom("tan");this.atom("atan2")
;this.atom("log");this.atom("warn");this.atom("error");this.atom("info");this.atom("PI");while(this.cur.kind!==TK.EOF)this.parseStmt();this.emitByte(OP.HALT)}peek(off=0){
return this.tokens[this.tokIdx+off]||this.tokens[this.tokens.length-1]}advance(){const t=this.cur;this.tokIdx++;this.cur=this.tokens[this.tokIdx]||this.tokens[this.tokens.length-1];return t}accept(k){
if(this.cur.kind===k){this.advance();return!0}return!1}acceptSemi(){if(this.accept(TK.SEMI))return!0;if(this.tokIdx>0){var prevTok=this.tokens[this.tokIdx-1]
;if(prevTok&&this.cur.line>prevTok.line)return!0}return this.cur.kind===TK.EOF||this.cur.kind===TK.RBRACE}expect(k,what){
if(this.cur.kind!==k)throw new CompileError(`expected ${what}`,this.cur.line,this.tokIdx,this.cur.sval||"",this.srcLines[this.cur.line-1]||"");return this.advance()}err(msg){
throw new CompileError(msg,this.cur.line,this.tokIdx,this.cur.sval||"",this.srcLines[this.cur.line-1]||"")}localFind(name){
for(let i=this.locals.length-1;i>=0;i--)if(this.locals[i].name===name)return this.locals[i].slot;return-1}localFindConst(name){
for(let i=this.locals.length-1;i>=0;i--)if(this.locals[i].name===name)return this.locals[i].isConst;return!(!this.topLevelConsts||!this.topLevelConsts[name])}localAdd(name,isConst){
this.locals.length>=63&&this.err("too many locals in one function");const slot=this.locals.length;this.locals.push({name:name,slot:slot,isConst:!!isConst});return slot}parseStmt(){const t=this.cur
;switch(t.kind){case TK.LBRACE:return this.parseBlock();case TK.VAR:case TK.LET:case TK.CONST:return this.parseVar();case TK.IF:return this.parseIf();case TK.WHILE:return this.parseWhile()
;case TK.FOR:return this.parseFor();case TK.DO:return this.parseDo();case TK.RETURN:return this.parseReturn();case TK.SWITCH:return this.parseSwitch();case TK.TRY:return this.parseTry();case TK.THROW:
this.advance();this.parseExpr();this.emitByte(OP.THROW);this.acceptSemi();return;case TK.BREAK:{this.advance();0===this.breakStack.length&&this.err("break outside loop or switch")
;this.emitByte(OP.JMP);const ph=this.emitPlaceholder();this.breakStack[this.breakStack.length-1].push(ph);this.acceptSemi();return}case TK.CONTINUE:{this.advance()
;0===this.continueStack.length&&this.err("continue outside loop");this.emitByte(OP.JMP);const ph=this.emitPlaceholder();this.continueStack[this.continueStack.length-1].push(ph);this.acceptSemi()
;return}case TK.SEMI:this.advance();return;case TK.FUNCTION:{this.advance();this.cur.kind!==TK.IDENT&&this.err("expected function name");const name=this.advance().sval;this.parseFunction(name);return}
case TK.EOF:return;default:this.parseExpr();this.emitByte(OP.POP);this.acceptSemi();return}}parseBlock(){this.expect(TK.LBRACE,"'{'")
;while(this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)this.parseStmt();this.expect(TK.RBRACE,"'}'")}parseVar(){const declKind=this.cur.kind;this.advance();const isTopLevel=0===this.locals.length
;for(;;){if(this.cur.kind===TK.LBRACKET){this.advance();let names=[];while(this.cur.kind!==TK.RBRACKET)if(this.cur.kind!==TK.COMMA){
this.cur.kind!==TK.IDENT&&this.err("expected identifier in array destructuring");names.push(this.advance().sval);this.cur.kind===TK.COMMA&&this.advance()}else{names.push(null);this.advance()}
this.expect(TK.RBRACKET,"']'");this.expect(TK.ASSIGN,"'='");this.parseExpr();for(let i=0;i<names.length;i++)if(null!==names[i]){i<names.length-1&&this.emitByte(OP.DUP);this.emitByte(OP.INT8)
;this.emitByte(i);this.emitByte(OP.LOAD_INDEX);if(isTopLevel){this.emitByte(OP.STORE_GLOBAL);this.emitByte(this.atom(names[i]));this.topLevelDecls.add(names[i])}else{
const s=this.localAdd(names[i],declKind===TK.CONST);this.emitByte(OP.STORE_LOCAL);this.emitByte(s)}i<names.length-1&&this.emitByte(OP.POP)}this.emitByte(OP.POP);if(!this.accept(TK.COMMA))break
;continue}if(this.cur.kind===TK.LBRACE){this.advance();let pairs=[];while(this.cur.kind!==TK.RBRACE){this.cur.kind!==TK.IDENT&&this.err("expected identifier in object destructuring")
;const key=this.advance().sval;let alias=key;if(this.cur.kind===TK.COLON){this.advance();this.cur.kind!==TK.IDENT&&this.err("expected identifier after ':'");alias=this.advance().sval}pairs.push({
key:key,alias:alias});this.cur.kind===TK.COMMA&&this.advance()}this.expect(TK.RBRACE,"'}'");this.expect(TK.ASSIGN,"'='");this.parseExpr();for(let i=0;i<pairs.length;i++){
i<pairs.length-1&&this.emitByte(OP.DUP);this.emitByte(OP.LOAD_PROP);this.emitByte(this.atom(pairs[i].key));if(isTopLevel){this.emitByte(OP.STORE_GLOBAL);this.emitByte(this.atom(pairs[i].alias))
;this.topLevelDecls.add(pairs[i].alias)}else{const s=this.localAdd(pairs[i].alias,declKind===TK.CONST);this.emitByte(OP.STORE_LOCAL);this.emitByte(s)}i<pairs.length-1&&this.emitByte(OP.POP)}
this.emitByte(OP.POP);if(!this.accept(TK.COMMA))break;continue}this.cur.kind!==TK.IDENT&&this.err("expected identifier in var");const name=this.advance().sval
;isTopLevel&&this.reservedNames.has(name)&&this.err(`'${name}' is a reserved system name — cannot be used as a variable`);let slot;let useGlobal=isTopLevel;if(useGlobal){slot=-1
;declKind===TK.CONST&&(this.topLevelConsts[name]=!0);this.topLevelDecls.add(name)}else slot=this.localAdd(name,declKind===TK.CONST);if(this.accept(TK.ASSIGN)){this.parseExpr();if(useGlobal){
this.emitByte(OP.STORE_GLOBAL);this.emitByte(this.atom(name))}else{this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}this.emitByte(OP.POP)}else{this.emitByte(OP.UNDEF);if(useGlobal){
this.emitByte(OP.STORE_GLOBAL);this.emitByte(this.atom(name))}else{this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}this.emitByte(OP.POP)}if(!this.accept(TK.COMMA))break}this.acceptSemi()}parseIf(){
this.advance();this.expect(TK.LPAREN,"'('");this.parseExpr();this.expect(TK.RPAREN,"')'");this.emitByte(OP.JZ);const jmpElse=this.emitPlaceholder();this.parseStmt();if(this.accept(TK.ELSE)){
this.emitByte(OP.JMP);const jmpEnd=this.emitPlaceholder();const elsePos=this.bc.length;this.patchJump(jmpElse,elsePos);this.parseStmt();const endPos=this.bc.length;this.patchJump(jmpEnd,endPos)}else{
const endPos=this.bc.length;this.patchJump(jmpElse,endPos)}}parseWhile(){this.advance();this.expect(TK.LPAREN,"'('");const loopStart=this.bc.length;this.parseExpr();this.expect(TK.RPAREN,"')'")
;this.emitByte(OP.JZ);const jmpEnd=this.emitPlaceholder();this.breakStack.push([]);this.continueStack.push([]);this.parseStmt();const continueTarget=this.bc.length+3;this.emitByte(OP.JMP)
;const back=loopStart-(this.bc.length+2);this.emitI16(back);const endPos=this.bc.length;this.patchJump(jmpEnd,endPos);for(const ph of this.breakStack.pop())this.patchJump(ph,endPos)
;for(const ph of this.continueStack.pop())this.patchJump(ph,continueTarget)}parseDo(){this.advance();const loopStart=this.bc.length;this.breakStack.push([]);this.continueStack.push([])
;this.parseStmt();const continueTarget=this.bc.length;this.expect(TK.WHILE,"'while'");this.expect(TK.LPAREN,"'('");this.parseExpr();this.expect(TK.RPAREN,"')'");this.emitByte(OP.JNZ)
;const back=loopStart-(this.bc.length+2);this.emitI16(back);const endPos=this.bc.length;for(const ph of this.breakStack.pop())this.patchJump(ph,endPos)
;for(const ph of this.continueStack.pop())this.patchJump(ph,continueTarget);this.acceptSemi()}parseFor(){this.advance();this.expect(TK.LPAREN,"'('")
;if(this.cur.kind===TK.VAR||this.cur.kind===TK.LET||this.cur.kind===TK.CONST){const saveIdx=this.tokIdx;const saveTok=this.cur;this.advance();if(this.cur.kind===TK.IDENT){const varName=this.cur.sval
;this.advance();if(this.cur.kind===TK.IN){this.advance();this.parseExpr();this.expect(TK.RPAREN,"')'");const isTopLevel=0===this.locals.length;let slot=-1,idxSlot=-1,objSlot=-1
;let idxAtom=0,objAtom=0,varAtom=0;if(isTopLevel){varAtom=this.atom(varName);idxAtom=this.atom("__for_in_idx");objAtom=this.atom("__for_in_obj");this.topLevelDecls.add(varName)}else{
slot=this.localAdd(varName);idxSlot=this.localAdd("__for_in_idx");objSlot=this.localAdd("__for_in_obj")}const emitStore=(s,a)=>{if(isTopLevel){this.emitByte(OP.STORE_GLOBAL);this.emitByte(a)}else{
this.emitByte(OP.STORE_LOCAL);this.emitByte(s)}};const emitLoad=(s,a)=>{if(isTopLevel){this.emitByte(OP.LOAD_GLOBAL);this.emitByte(a)}else{this.emitByte(OP.LOAD_LOCAL);this.emitByte(s)}}
;emitStore(objSlot,objAtom);this.emitByte(OP.POP);this.emitByte(OP.INT8);this.emitByte(0);emitStore(idxSlot,idxAtom);this.emitByte(OP.POP);const loopStart=this.bc.length;emitLoad(objSlot,objAtom)
;emitLoad(idxSlot,idxAtom);this.emitByte(OP.FOR_IN_NEXT);emitStore(idxSlot,idxAtom);this.emitByte(OP.POP);this.emitByte(OP.DUP);this.emitByte(OP.UNDEF);this.emitByte(OP.STRICT_EQ)
;this.emitByte(OP.JNZ);const jmpEnd=this.emitPlaceholder();emitStore(slot,varAtom);this.emitByte(OP.POP);this.breakStack.push([]);this.continueStack.push([]);this.parseStmt();this.emitByte(OP.JMP)
;const back=loopStart-(this.bc.length+2);this.emitI16(back);const endPos=this.bc.length;this.patchJump(jmpEnd,endPos);for(const ph of this.breakStack.pop())this.patchJump(ph,endPos)
;for(const ph of this.continueStack.pop())this.patchJump(ph,loopStart);return}if(this.cur.kind===TK.OF){this.advance();this.parseExpr();this.expect(TK.RPAREN,"')'")
;const isTopLevel=0===this.locals.length;let slot=-1,idxSlot=-1,arrSlot=-1;let idxAtom=0,arrAtom=0,varAtom=0;if(isTopLevel){varAtom=this.atom(varName);idxAtom=this.atom("__for_of_idx")
;arrAtom=this.atom("__for_of_arr");this.topLevelDecls.add(varName)}else{slot=this.localAdd(varName);idxSlot=this.localAdd("__for_of_idx");arrSlot=this.localAdd("__for_of_arr")}const emitStore=(s,a)=>{
if(isTopLevel){this.emitByte(OP.STORE_GLOBAL);this.emitByte(a)}else{this.emitByte(OP.STORE_LOCAL);this.emitByte(s)}};const emitLoad=(s,a)=>{if(isTopLevel){this.emitByte(OP.LOAD_GLOBAL)
;this.emitByte(a)}else{this.emitByte(OP.LOAD_LOCAL);this.emitByte(s)}};emitStore(arrSlot,arrAtom);this.emitByte(OP.POP);this.emitByte(OP.INT8);this.emitByte(0);emitStore(idxSlot,idxAtom)
;this.emitByte(OP.POP);const loopStart=this.bc.length;emitLoad(arrSlot,arrAtom);emitLoad(idxSlot,idxAtom);this.emitByte(OP.FOR_OF_NEXT);emitStore(idxSlot,idxAtom);this.emitByte(OP.POP)
;this.emitByte(OP.DUP);this.emitByte(OP.UNDEF);this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JNZ);const jmpEnd=this.emitPlaceholder();emitStore(slot,varAtom);this.emitByte(OP.POP)
;this.breakStack.push([]);this.continueStack.push([]);this.parseStmt();this.emitByte(OP.JMP);const back=loopStart-(this.bc.length+2);this.emitI16(back);const endPos=this.bc.length
;this.patchJump(jmpEnd,endPos);for(const ph of this.breakStack.pop())this.patchJump(ph,endPos);for(const ph of this.continueStack.pop())this.patchJump(ph,loopStart);return}}this.tokIdx=saveIdx
;this.cur=saveTok}if(this.cur.kind===TK.VAR||this.cur.kind===TK.LET||this.cur.kind===TK.CONST)this.parseVar();else{if(this.cur.kind!==TK.SEMI){this.parseExpr();this.emitByte(OP.POP)}
this.expect(TK.SEMI,"';'")}let jmpEnd=-1;const loopStart=this.bc.length;if(this.cur.kind!==TK.SEMI){this.parseExpr();this.emitByte(OP.JZ);jmpEnd=this.emitPlaceholder()}this.expect(TK.SEMI,"';'")
;const bcLenBeforePost=this.bc.length;const postStartTok=this.tokIdx;this.cur.kind!==TK.RPAREN&&this.parseExpr();const postEndTok=this.tokIdx;this.bc.length=bcLenBeforePost
;this.expect(TK.RPAREN,"')'");this.breakStack.push([]);this.continueStack.push([]);this.parseStmt();const afterBodyTokIdx=this.tokIdx;const afterBodyTok=this.cur;const postStart=this.bc.length
;if(postEndTok>postStartTok){this.tokIdx=postStartTok;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitByte(OP.POP);this.cur.kind===TK.RPAREN&&this.advance()}this.tokIdx=afterBodyTokIdx
;this.cur=afterBodyTok;this.emitByte(OP.JMP);const back=loopStart-(this.bc.length+2);this.emitI16(back);const endPos=this.bc.length;jmpEnd>=0&&this.patchJump(jmpEnd,endPos)
;for(const ph of this.breakStack.pop())this.patchJump(ph,endPos);for(const ph of this.continueStack.pop())this.patchJump(ph,postStart)}parseReturn(){this.advance()
;if(this.cur.kind!==TK.SEMI&&this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF){this.parseExpr();this.emitByte(OP.RET);this.acceptSemi()}else{this.emitByte(OP.RET_UNDEF);this.acceptSemi()}}parseTry(){
this.advance();this.expect(TK.LBRACE,"'{' after try");this.emitByte(OP.PUSH_TRY);const catchPcPlaceholder=this.emitPlaceholder()
;while(this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)this.parseStmt();this.expect(TK.RBRACE,"'}'");this.emitByte(OP.POP_TRY);this.emitByte(OP.JMP);const endJmp=this.emitPlaceholder()
;const catchPc=this.bc.length;this.patchJump(catchPcPlaceholder,catchPc);this.expect(TK.CATCH,"'catch'");this.expect(TK.LPAREN,"'(' after catch")
;this.cur.kind!==TK.IDENT&&this.err("expected catch variable name");const errVar=this.cur.sval;this.advance();this.expect(TK.RPAREN,"')'");this.expect(TK.LBRACE,"'{' after catch")
;const isTopLevel=0===this.locals.length;if(isTopLevel){const atom=this.atom(errVar);this.topLevelDecls.add(errVar);this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}else{
const slot=this.localAdd(errVar);this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}this.emitByte(OP.POP);while(this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)this.parseStmt()
;this.expect(TK.RBRACE,"'}'");const endPc=this.bc.length;this.patchJump(endJmp,endPc)}parseSwitch(){this.advance();this.expect(TK.LPAREN,"'('");this.parseExpr();this.expect(TK.RPAREN,"')'")
;this.expect(TK.LBRACE,"'{'");this.breakStack.push([]);while(this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)if(this.cur.kind===TK.CASE){this.advance();this.emitByte(OP.DUP);this.parseExpr()
;this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JZ);const jmpNext=this.emitPlaceholder();this.emitByte(OP.POP);this.expect(TK.COLON,"':'")
;while(this.cur.kind!==TK.CASE&&this.cur.kind!==TK.DEFAULT&&this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)this.parseStmt();this.emitByte(OP.JMP);const jmpEnd=this.emitPlaceholder()
;this.breakStack[this.breakStack.length-1].push(jmpEnd);this.patchJump(jmpNext,this.bc.length)}else if(this.cur.kind===TK.DEFAULT){this.advance();this.expect(TK.COLON,"':'")
;while(this.cur.kind!==TK.CASE&&this.cur.kind!==TK.DEFAULT&&this.cur.kind!==TK.RBRACE&&this.cur.kind!==TK.EOF)this.parseStmt();this.emitByte(OP.JMP);const jmpEnd=this.emitPlaceholder()
;this.breakStack[this.breakStack.length-1].push(jmpEnd)}else this.err("expected 'case' or 'default' in switch");this.expect(TK.RBRACE,"'}'");this.emitByte(OP.POP);const endPos=this.bc.length
;for(const ph of this.breakStack.pop())this.patchJump(ph,endPos)}parseFunction(name){if(name&&0===this.locals.length){
this.reservedNames.has(name)&&this.err(`'${name}' is a reserved system name — cannot be used as a function name`);this.topLevelDecls.add(name)}this.expect(TK.LPAREN,"'(' after function name")
;const savedLocals=this.locals;const savedNlocals=this.nlocals;this.locals=[];let argc=0;let defaultInits=[];while(this.cur.kind!==TK.RPAREN){
this.cur.kind!==TK.IDENT&&this.err("expected parameter name");const pname=this.advance().sval;const slot=this.localAdd(pname);argc++;if(this.cur.kind===TK.ASSIGN){this.advance()
;const exprStart=this.tokIdx;const savedBc=this.bc;this.bc=[];this.parseExpr();this.bc=savedBc;const exprEnd=this.tokIdx;defaultInits.push({slot:slot,exprStart:exprStart,exprEnd:exprEnd})}
if(!this.accept(TK.COMMA))break}this.expect(TK.RPAREN,"')'");this.funcs.length>=63&&this.err("too many functions");const funcIdx=this.funcs.length;const funcEntry={pc:0,argc:argc,nlocals:0,bodySize:0}
;this.funcs.push(funcEntry);const savedBc=this.bc;this.bc=this.body;funcEntry.pc=this.bc.length;for(const di of defaultInits){this.emitByte(OP.LOAD_LOCAL);this.emitByte(di.slot);this.emitByte(OP.DUP)
;this.emitByte(OP.UNDEF);this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JNZ);const jmp=this.emitPlaceholder();this.emitByte(OP.POP);const savedTI=this.tokIdx;const savedCur=this.cur
;this.tokIdx=di.exprStart;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.tokIdx=savedTI;this.cur=savedCur;this.emitByte(OP.STORE_LOCAL);this.emitByte(di.slot)
;this.patchJump(jmp,this.bc.length)}this.parseBlock();this.emitByte(OP.RET_UNDEF);funcEntry.nlocals=this.locals.length;funcEntry.bodySize=this.bc.length-funcEntry.pc;this.bc=savedBc
;this.locals=savedLocals;this.nlocals=savedNlocals;this.emitByte(OP.FUNCTION);this.emitByte(funcIdx);if(name){const atom=this.atom(name);const slot=this.localFind(name);if(slot>=0){
this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}}}parseExpr(){this.parseTernary()}parseTernary(){this.parseAssignment()
;if(this.cur.kind===TK.QUESTION){this.advance();this.emitByte(OP.JZ);const jmpElse=this.emitPlaceholder();this.parseTernary();this.emitByte(OP.JMP);const jmpEnd=this.emitPlaceholder()
;this.patchJump(jmpElse,this.bc.length);this.expect(TK.COLON,"':'");this.parseTernary();this.patchJump(jmpEnd,this.bc.length)}}parseAssignment(){if(this.cur.kind===TK.THIS){const saveIdx=this.tokIdx
;const saveTok=this.cur;this.advance();if(this.cur.kind!==TK.DOT&&this.cur.kind!==TK.LBRACKET){this.tokIdx=saveIdx;this.cur=saveTok;return this.parseBinary(-100)}let chain=[];let chainDepth=0
;let rollback=!1;while(this.cur.kind===TK.DOT||this.cur.kind===TK.LBRACKET)if(this.cur.kind===TK.DOT){this.advance();if(this.cur.kind!==TK.IDENT){this.tokIdx=saveIdx;this.cur=saveTok;rollback=!0;break
}const a=this.atom(this.advance().sval);chain.push({type:"prop",atom:a});chainDepth++}else{const ist=this.tokIdx+1;this.advance();let depth=1;while(depth>0&&this.cur.kind!==TK.EOF){
this.cur.kind===TK.LBRACKET?depth++:this.cur.kind===TK.RBRACKET&&depth--;depth>0&&this.advance()}if(this.cur.kind!==TK.RBRACKET){this.tokIdx=saveIdx;this.cur=saveTok;break}const iet=this.tokIdx
;this.advance();chain.push({type:"index",tokStart:ist,tokEnd:iet});chainDepth++}if(rollback)return this.parseBinary(-100)
;if(this.cur.kind!==TK.ASSIGN&&this.cur.kind!==TK.PLUSEQ&&this.cur.kind!==TK.MINUSEQ&&this.cur.kind!==TK.STAREQ&&this.cur.kind!==TK.SLASHEQ&&this.cur.kind!==TK.PERCENTEQ){this.tokIdx=saveIdx
;this.cur=saveTok;return this.parseBinary(-100)}const opKind=this.cur.kind;this.advance();this.emitByte(OP.THIS);const rhsTokIdx=this.tokIdx;for(let ci=0;ci<chain.length-1;ci++){const step=chain[ci]
;if("prop"===step.type){this.emitByte(OP.LOAD_PROP);this.emitByte(step.atom)}else{this.tokIdx=step.tokStart;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.expect(TK.RBRACKET,"']'")
;this.emitByte(OP.LOAD_INDEX)}}const last=chain[chain.length-1];if("prop"===last.type)if(opKind===TK.ASSIGN){this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx];this.parseExpr()
;this.emitByte(OP.STORE_PROP);this.emitByte(last.atom)}else{this.emitByte(OP.DUP);this.emitByte(OP.LOAD_PROP);this.emitByte(last.atom);this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx]
;this.parseExpr();this.emitOpForCompound(opKind);this.emitByte(OP.STORE_PROP);this.emitByte(last.atom)}else if(opKind===TK.ASSIGN){this.tokIdx=last.tokStart;this.cur=this.tokens[this.tokIdx]
;this.parseExpr();this.expect(TK.RBRACKET,"']'");this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitByte(OP.STORE_INDEX)}else{
const tempIdxSlot=this.localAdd("__compound_idx");this.tokIdx=last.tokStart;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.expect(TK.RBRACKET,"']'");this.emitByte(OP.STORE_LOCAL)
;this.emitByte(tempIdxSlot);this.emitByte(OP.POP);this.emitByte(OP.DUP);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempIdxSlot);this.emitByte(OP.LOAD_INDEX);this.tokIdx=rhsTokIdx
;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitOpForCompound(opKind);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempIdxSlot);this.emitByte(OP.SWAP);this.emitByte(OP.STORE_INDEX)}return}
if(this.cur.kind===TK.IDENT){const saveIdx=this.tokIdx;const saveTok=this.cur;this.advance();let isLocal=!1,slot=-1,atom=0;const name=saveTok.sval;slot=this.localFind(name)
;slot>=0?isLocal=!0:atom=this.atom(name);let chainDepth=0,hasIndex=!1;let propAtoms=[];let idxStartTok=-1,idxEndTok=-1;let rollback=!1;let chain=[]
;while(this.cur.kind===TK.DOT||this.cur.kind===TK.LBRACKET)if(this.cur.kind===TK.DOT){this.advance();if(this.cur.kind!==TK.IDENT){this.tokIdx=saveIdx;this.cur=saveTok;rollback=!0;break}
const a=this.atom(this.advance().sval);propAtoms.push(a);chain.push({type:"prop",atom:a});chainDepth++}else{const ist=this.tokIdx+1;this.advance();let depth=1;while(depth>0&&this.cur.kind!==TK.EOF){
this.cur.kind===TK.LBRACKET?depth++:this.cur.kind===TK.RBRACKET&&depth--;depth>0&&this.advance()}if(this.cur.kind!==TK.RBRACKET){this.tokIdx=saveIdx;this.cur=saveTok;break}const iet=this.tokIdx
;this.advance();idxStartTok=ist;idxEndTok=iet;hasIndex=!0;chainDepth++;chain.push({type:"index",tokStart:ist,tokEnd:iet})}if(rollback)return this.parseBinary(-100)
;if(this.cur.kind!==TK.ASSIGN&&this.cur.kind!==TK.PLUSEQ&&this.cur.kind!==TK.MINUSEQ&&this.cur.kind!==TK.STAREQ&&this.cur.kind!==TK.SLASHEQ&&this.cur.kind!==TK.PERCENTEQ){this.tokIdx=saveIdx
;this.cur=saveTok;return this.parseBinary(-100)}const opKind=this.cur.kind;this.advance();if(0===chainDepth){isLocal&&this.localFindConst(name)&&this.err("assignment to constant '"+name+"'")
;!isLocal&&this.topLevelConsts&&this.topLevelConsts[name]&&this.err("assignment to constant '"+name+"'")
;isLocal||this.knownGlobals.has(name)||this.topLevelDecls.has(name)||this.err("undefined variable '"+name+"'");this.parseExpr();if(opKind===TK.ASSIGN)if(isLocal){this.emitByte(OP.STORE_LOCAL)
;this.emitByte(slot)}else{this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}else{isLocal&&this.localFindConst(name)&&this.err("assignment to constant '"+name+"'");if(isLocal){
this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitOpForCompound(opKind);if(isLocal){this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)
}else{this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}}return}if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}
const rhsTokIdx=this.tokIdx;for(let ci=0;ci<chain.length-1;ci++){const step=chain[ci];if("prop"===step.type){this.emitByte(OP.LOAD_PROP);this.emitByte(step.atom)}else{this.tokIdx=step.tokStart
;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.expect(TK.RBRACKET,"']'");this.emitByte(OP.LOAD_INDEX)}}const last=chain[chain.length-1];if("prop"===last.type)if(opKind===TK.ASSIGN){
this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitByte(OP.STORE_PROP);this.emitByte(last.atom)}else{this.emitByte(OP.DUP);this.emitByte(OP.LOAD_PROP)
;this.emitByte(last.atom);this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitOpForCompound(opKind);this.emitByte(OP.STORE_PROP);this.emitByte(last.atom)
}else if(opKind===TK.ASSIGN){this.tokIdx=last.tokStart;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.expect(TK.RBRACKET,"']'");this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx]
;this.parseExpr();this.emitByte(OP.STORE_INDEX)}else{const tempIdxSlot=this.localAdd("__compound_idx");this.tokIdx=last.tokStart;this.cur=this.tokens[this.tokIdx];this.parseExpr()
;this.expect(TK.RBRACKET,"']'");this.emitByte(OP.STORE_LOCAL);this.emitByte(tempIdxSlot);this.emitByte(OP.POP);this.emitByte(OP.DUP);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempIdxSlot)
;this.emitByte(OP.LOAD_INDEX);this.tokIdx=rhsTokIdx;this.cur=this.tokens[this.tokIdx];this.parseExpr();this.emitOpForCompound(opKind);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempIdxSlot)
;this.emitByte(OP.SWAP);this.emitByte(OP.STORE_INDEX)}return}return this.parseBinary(-100)}emitOpForCompound(opKind){const m={[TK.PLUSEQ]:OP.ADD,[TK.MINUSEQ]:OP.SUB,[TK.STAREQ]:OP.MUL,
[TK.SLASHEQ]:OP.DIV,[TK.PERCENTEQ]:OP.MOD,[TK.ANDEQ]:OP.AND,[TK.OREQ]:OP.OR,[TK.XOREQ]:OP.XOR,[TK.SHLEQ]:OP.SHL,[TK.SHREQ]:OP.SHR,[TK.USHREQ]:OP.USHR}
;void 0===m[opKind]&&this.err("unsupported compound op");this.emitByte(m[opKind])}binopPrec(k){switch(k){case TK.STAR:case TK.SLASH:case TK.PERCENT:return 5;case TK.PLUS:case TK.MINUS:return 4
;case TK.SHL:case TK.SHR:case TK.USHR:case TK.BAND:case TK.BOR:case TK.XOR:return 3;case TK.LT:case TK.LE:case TK.GT:case TK.GE:case TK.IN:case TK.INSTANCEOF:return 2;case TK.EQ:case TK.NE:
case TK.STRICT_EQ:case TK.STRICT_NE:return 1;case TK.AMPAMP:return 0;case TK.PIPEPIPE:return-1;case TK.NULLISH:return-2;default:return-1e3}}emitBinop(k){const m={[TK.PLUS]:OP.ADD,[TK.MINUS]:OP.SUB,
[TK.STAR]:OP.MUL,[TK.SLASH]:OP.DIV,[TK.PERCENT]:OP.MOD,[TK.SHL]:OP.SHL,[TK.SHR]:OP.SHR,[TK.USHR]:OP.USHR,[TK.BAND]:OP.AND,[TK.BOR]:OP.OR,[TK.XOR]:OP.XOR,[TK.LT]:OP.LT,[TK.LE]:OP.LE,[TK.GT]:OP.GT,
[TK.GE]:OP.GE,[TK.EQ]:OP.EQ,[TK.NE]:OP.NE,[TK.STRICT_EQ]:OP.STRICT_EQ,[TK.STRICT_NE]:OP.STRICT_NE,[TK.INSTANCEOF]:OP.INSTANCEOF};k===TK.IN&&this.err("'in' is only valid in for...in loops")
;void 0===m[k]&&this.err("unsupported operator");this.emitByte(m[k])}parseBinary(minPrec){this.parseUnary();for(;;){const k=this.cur.kind;if(k===TK.AMPAMP||k===TK.PIPEPIPE){if(minPrec>-1)return
;this.advance();this.emitByte(OP.DUP);this.emitByte(k===TK.AMPAMP?OP.JZ:OP.JNZ);const jmp=this.emitPlaceholder();this.emitByte(OP.POP);this.parseBinary(minPrec);this.patchJump(jmp,this.bc.length)
;continue}if(k===TK.NULLISH){if(minPrec>-2)return;this.advance();this.emitByte(OP.DUP);this.emitByte(OP.UNDEF);this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JNZ);const jmp1=this.emitPlaceholder()
;this.emitByte(OP.DUP);this.emitByte(OP.NULL);this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JNZ);const jmp2=this.emitPlaceholder();this.emitByte(OP.JMP);const jmpEnd=this.emitPlaceholder()
;this.patchJump(jmp1,this.bc.length);this.patchJump(jmp2,this.bc.length);this.emitByte(OP.POP);this.parseBinary(minPrec);this.patchJump(jmpEnd,this.bc.length);continue}const p=this.binopPrec(k)
;if(-1e3===p||p<minPrec)break;this.advance();this.parseBinary(p+1);this.emitBinop(k)}}parseUnary(){switch(this.cur.kind){case TK.MINUS:this.advance();this.parseUnary();this.emitByte(OP.NEG);return
;case TK.PLUS:this.advance();this.parseUnary();this.emitByte(OP.TO_NUMBER);return;case TK.LNOT:this.advance();this.parseUnary();this.emitByte(OP.LNOT);return;case TK.BNOT:this.advance()
;this.parseUnary();this.emitByte(OP.BNOT);return;case TK.INC:this.advance();this.parseIncrement(!0,!0);return;case TK.DEC:this.advance();this.parseIncrement(!0,!1);return;case TK.TYPEOF:{
this.advance();const savedInTypeof=this.inTypeof;this.inTypeof=!0;this.parseUnary();this.inTypeof=savedInTypeof;this.emitByte(OP.TYPEOF);return}case TK.VOID:this.advance();this.parseUnary()
;this.emitByte(OP.POP);this.emitByte(OP.UNDEF);return;case TK.NEW:this.advance();if(this.cur.kind===TK.IDENT){const name=this.cur.sval;const nextIsParen=this.peek(1).kind===TK.LPAREN
;if("Object"===name&&nextIsParen){this.advance();this.advance();while(this.cur.kind!==TK.RPAREN)this.advance();this.advance();this.emitByte(OP.NEW_OBJECT);return}if("Array"===name&&nextIsParen){
this.advance();this.advance();if(this.cur.kind!==TK.RPAREN){this.parseExpr();this.emitByte(OP.NEW_ARRAY);this.emitByte(1)}else{this.emitByte(OP.NEW_ARRAY);this.emitByte(0)}this.expect(TK.RPAREN,"')'")
;return}}this.parsePrimary();if(this.cur.kind===TK.LPAREN){this.advance();let argc=0;while(this.cur.kind!==TK.RPAREN&&this.cur.kind!==TK.EOF){this.parseExpr();argc++;if(!this.accept(TK.COMMA))break}
this.expect(TK.RPAREN,"')'");this.emitByte(OP.NEW);this.emitByte(argc)}else{this.emitByte(OP.NEW);this.emitByte(0)}return;case TK.LPAREN:{const saveIdx=this.tokIdx;const saveTok=this.cur
;this.advance();let params=[];let isArrow=!0;if(this.cur.kind!==TK.RPAREN)while(1){if(this.cur.kind!==TK.IDENT){isArrow=!1;break}params.push(this.cur.sval);this.advance()
;if(this.cur.kind!==TK.COMMA)break;this.advance()}if(isArrow&&this.cur.kind===TK.RPAREN){this.advance();if(this.cur.kind===TK.ARROW){this.advance();this.parseArrowFunction(params);return}isArrow=!1}
this.tokIdx=saveIdx;this.cur=saveTok;return this.parsePostfix()}case TK.IDENT:if(this.peek(1).kind===TK.ARROW){const param=this.cur.sval;this.advance();this.advance();this.parseArrowFunction([param])
;return}return this.parsePostfix();default:return this.parsePostfix()}}parseArrowFunction(params){this.funcs.length>=63&&this.err("too many functions");const funcIdx=this.funcs.length
;const savedBc=this.bc;const savedLocals=this.locals;const savedNlocals=this.nlocals;this.bc=this.body;this.locals=[];for(const p of params)this.localAdd(p);const funcEntry={pc:this.bc.length,
argc:params.length,nlocals:0,bodySize:0};this.funcs.push(funcEntry);if(this.cur.kind===TK.LBRACE){this.parseBlock();this.emitByte(OP.RET_UNDEF)}else{this.parseExpr();this.emitByte(OP.RET)}
funcEntry.nlocals=this.locals.length;funcEntry.bodySize=this.bc.length-funcEntry.pc;this.bc=savedBc;this.locals=savedLocals;this.nlocals=savedNlocals;this.emitByte(OP.FUNCTION);this.emitByte(funcIdx)}
parseTemplateLiteral(raw){let parts=[];let i=0;while(i<raw.length){if("$"===raw[i]&&"{"===raw[i+1]){let j=i+2;let depth=1;while(j<raw.length&&depth>0){"{"===raw[j]?depth++:"}"===raw[j]&&depth--
;depth>0&&j++}if(0===depth){parts.push({type:"expr",code:raw.substring(i+2,j)});i=j+1;continue}}let text="";while(i<raw.length){if("$"===raw[i]&&"{"===raw[i+1])break;text+=raw[i];i++}
text.length>0&&parts.push({type:"text",text:text})}if(0===parts.length){this.emitByte(OP.UNDEF);return}let first=!0;for(const part of parts){if("text"===part.type){
const idx=this.addConstString(part.text);this.emitByte(OP.CONST);this.emitByte(idx)}else{const savedTokens=this.tokens;const savedTokIdx=this.tokIdx;const savedCur=this.cur
;const subTokens=this.tokenize(part.code);this.tokens=subTokens;this.tokIdx=0;this.cur=this.tokens[0];this.parseExpr();this.tokens=savedTokens;this.tokIdx=savedTokIdx;this.cur=savedCur}
first||this.emitByte(OP.ADD);first=!1}}parseIncrement(isPrefix,isInc){this.cur.kind!==TK.IDENT&&this.err("++/-- requires an identifier operand");const name=this.cur.sval;this.advance()
;if(this.cur.kind===TK.DOT||this.cur.kind===TK.LBRACKET){const slot=this.localFind(name);const isLocal=slot>=0;const atom=isLocal?0:this.atom(name);if(this.cur.kind===TK.DOT){this.advance()
;this.cur.kind!==TK.IDENT&&this.err("expected property name after '.'");const propAtom=this.atom(this.advance().sval);if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{
this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(OP.DUP);this.emitByte(OP.LOAD_PROP);this.emitByte(propAtom);if(!isPrefix){
this.cur.kind!==TK.INC&&this.cur.kind!==TK.DEC&&this.err("expected ++ or --");this.advance()}if(isPrefix){this.emitByte(isInc?OP.INC:OP.DEC);this.emitByte(OP.STORE_PROP);this.emitByte(propAtom)}else{
const tempSlot=this.localAdd("__inc_old");this.emitByte(OP.STORE_LOCAL);this.emitByte(tempSlot);this.emitByte(OP.POP);if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{
this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(OP.LOAD_PROP);this.emitByte(propAtom);this.emitByte(isInc?OP.INC:OP.DEC);if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)
}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(OP.SWAP);this.emitByte(OP.STORE_PROP);this.emitByte(propAtom);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempSlot)
;this.emitByte(OP.SWAP);this.emitByte(OP.POP)}}else if(this.cur.kind===TK.LBRACKET){this.advance();this.parseExpr();this.expect(TK.RBRACKET,"']'");const tempIdxSlot=this.localAdd("__inc_idx")
;this.emitByte(OP.STORE_LOCAL);this.emitByte(tempIdxSlot);this.emitByte(OP.POP);if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}
this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempIdxSlot);this.emitByte(OP.LOAD_INDEX);const tempOldSlot=this.localAdd("__inc_old");const tempNewSlot=this.localAdd("__inc_new")
;this.emitByte(OP.STORE_LOCAL);this.emitByte(tempOldSlot);this.emitByte(OP.POP);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempOldSlot);this.emitByte(isInc?OP.INC:OP.DEC);this.emitByte(OP.STORE_LOCAL)
;this.emitByte(tempNewSlot);this.emitByte(OP.POP);if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(OP.LOAD_LOCAL)
;this.emitByte(tempIdxSlot);this.emitByte(OP.LOAD_LOCAL);this.emitByte(tempNewSlot);this.emitByte(OP.STORE_INDEX);if(!isPrefix){this.emitByte(OP.POP);this.emitByte(OP.LOAD_LOCAL)
;this.emitByte(tempOldSlot)}}return}isPrefix||this.advance();const slot=this.localFind(name);const isLocal=slot>=0;const atom=isLocal?0:this.atom(name)
;isLocal&&this.localFindConst(name)&&this.err("assignment to constant '"+name+"'");isLocal||this.knownGlobals.has(name)||this.topLevelDecls.has(name)||this.err("undefined variable '"+name+"'")
;if(isPrefix){if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(isInc?OP.INC:OP.DEC);if(isLocal){
this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}else{this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}}else{if(isLocal){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{
this.emitByte(OP.LOAD_GLOBAL);this.emitByte(atom)}this.emitByte(OP.DUP);this.emitByte(isInc?OP.INC:OP.DEC);if(isLocal){this.emitByte(OP.STORE_LOCAL);this.emitByte(slot)}else{
this.emitByte(OP.STORE_GLOBAL);this.emitByte(atom)}this.emitByte(OP.SWAP);this.emitByte(OP.POP)}}parsePostfix(){if(this.cur.kind===TK.IDENT){let lookIdx=1;let depth=0;let foundIncDec=!1
;while(lookIdx<20){const t=this.peek(lookIdx);if(!t)break;if(t.kind!==TK.DOT){if(t.kind!==TK.LBRACKET){if(0===depth&&(t.kind===TK.INC||t.kind===TK.DEC)){foundIncDec=!0;break}break}lookIdx++;depth=1
;while(depth>0&&lookIdx<20){const tt=this.peek(lookIdx);if(!tt)break;tt.kind===TK.LBRACKET?depth++:tt.kind===TK.RBRACKET&&depth--;lookIdx++}}else lookIdx+=2}if(foundIncDec){
const isInc=this.peek(lookIdx).kind===TK.INC;this.parseIncrement(!1,isInc);return}if(this.peek(1).kind===TK.INC||this.peek(1).kind===TK.DEC){const isInc=this.peek(1).kind===TK.INC
;this.parseIncrement(!1,isInc);return}}this.parsePrimary();var lastObj=this.lastGlobalName||"";for(;;)switch(this.cur.kind){case TK.DOT:{this.advance()
;this.cur.kind!==TK.IDENT&&this.err("expected property name after '.'");const methodName=this.advance().sval;const a=this.atom(methodName);if(this.cur.kind===TK.LPAREN){
const nativeId=this.getNativeCallId(lastObj,methodName);if(nativeId>=0){this.emitByte(OP.POP);this.advance();let argc=0;while(this.cur.kind!==TK.RPAREN){this.parseExpr();argc++
;if(!this.accept(TK.COMMA))break}this.expect(TK.RPAREN,"')'");this.emitByte(OP.NATIVE_CALL);this.emitByte(argc<<4|nativeId)}else{this.emitByte(OP.DUP);this.emitByte(OP.LOAD_PROP);this.emitByte(a)
;this.advance();let argc=0;while(this.cur.kind!==TK.RPAREN){this.parseExpr();argc++;if(!this.accept(TK.COMMA))break}this.expect(TK.RPAREN,"')'");this.emitByte(OP.CALL_WITH_THIS);this.emitByte(argc)}
}else{this.emitByte(OP.LOAD_PROP);this.emitByte(a)}continue}case TK.LBRACKET:this.advance();this.parseExpr();this.expect(TK.RBRACKET,"']'");this.emitByte(OP.LOAD_INDEX);continue;case TK.LPAREN:{
this.advance();let argc=0;while(this.cur.kind!==TK.RPAREN){this.parseExpr();argc++;if(!this.accept(TK.COMMA))break}this.expect(TK.RPAREN,"')'");this.emitByte(OP.CALL);this.emitByte(argc);continue}
case TK.OPTCHAIN:{this.advance();this.cur.kind!==TK.IDENT&&this.err("expected property name after '?.'");const a=this.atom(this.advance().sval);this.emitByte(OP.DUP);this.emitByte(OP.DUP)
;this.emitByte(OP.UNDEF);this.emitByte(OP.STRICT_EQ);this.emitByte(OP.JNZ);const skipProp=this.emitPlaceholder();this.emitByte(OP.POP);this.emitByte(OP.LOAD_PROP);this.emitByte(a)
;this.emitByte(OP.JMP);const endOpt=this.emitPlaceholder();this.patchJump(skipProp,this.bc.length);this.emitByte(OP.POP);this.patchJump(endOpt,this.bc.length);continue}default:return}}parsePrimary(){
const t=this.cur;switch(t.kind){case TK.INT:if(t.isFloat){const idx=this.addConstNum(t.fval);this.advance();this.emitByte(OP.CONST);this.emitByte(idx)}else{const v=t.ival;this.advance()
;this.emitInt(v)}return;case TK.STRING:{const idx=this.addConstString(t.sval);this.advance();this.emitByte(OP.CONST);this.emitByte(idx);return}case TK.TEMPLATE:this.advance()
;this.parseTemplateLiteral(t.sval);return;case TK.TRUE:this.advance();this.emitByte(OP.TRUE);return;case TK.FALSE:this.advance();this.emitByte(OP.FALSE);return;case TK.NULL:this.advance()
;this.emitByte(OP.NULL);return;case TK.UNDEFINED:this.advance();this.emitByte(OP.UNDEF);return;case TK.THIS:this.advance();this.emitByte(OP.THIS);return;case TK.IDENT:{const name=t.sval
;const a=this.atom(name);this.advance();const slot=this.localFind(name);if(slot>=0){this.emitByte(OP.LOAD_LOCAL);this.emitByte(slot)}else{
if(!this.knownGlobals.has(name)&&!this.topLevelDecls.has(name)){if(this.inTypeof){this.emitByte(OP.UNDEF);this.lastGlobalName=null;return}this.err("undefined variable '"+name+"'")}
this.emitByte(OP.LOAD_GLOBAL);this.emitByte(a);this.lastGlobalName=name}this.lastGlobalName=null;return}case TK.LPAREN:this.advance();this.parseExpr();this.expect(TK.RPAREN,"')'");return
;case TK.LBRACKET:{this.advance();let peekIdx=0;let allInts=!0;let intVals=[];let peekCount=0;while(1){const t=this.peek(peekIdx);if(!t||t.kind===TK.RBRACKET)break;if(t.kind===TK.COMMA){peekIdx++
;continue}if(t.kind!==TK.INT||t.isFloat){allInts=!1;break}const next=this.peek(peekIdx+1);if(!next||next.kind!==TK.COMMA&&next.kind!==TK.RBRACKET){allInts=!1;break}intVals.push(t.ival);peekCount++
;peekIdx++}if(allInts&&peekCount>0&&peekCount<=255){let allU8=!0,allU16=!0;for(const v of intVals){(v<0||v>255)&&(allU8=!1);(v<0||v>65535)&&(allU16=!1)}if(allU8||allU16){
const totalToSkip=2*peekCount-1;for(let i=0;i<totalToSkip;i++)this.advance();this.expect(TK.RBRACKET,"']'");if(allU8){this.emitByte(OP.NEW_ARRAY_U8);this.emitByte(peekCount)
;for(const v of intVals)this.emitByte(255&v)}else{this.emitByte(OP.NEW_ARRAY_U16);this.emitByte(peekCount);for(const v of intVals){this.emitByte(255&v);this.emitByte(v>>8&255)}}return}}{let count=0
;while(this.cur.kind!==TK.RBRACKET){this.parseExpr();count++;if(!this.accept(TK.COMMA))break}this.expect(TK.RBRACKET,"']'");if(count>255){this.emitByte(OP.NEW_ARRAY16);this.emitByte(255&count)
;this.emitByte(count>>8&255)}else{this.emitByte(OP.NEW_ARRAY);this.emitByte(count)}}return}case TK.LBRACE:this.advance();this.emitByte(OP.NEW_OBJECT);while(this.cur.kind!==TK.RBRACE){
this.cur.kind!==TK.IDENT&&this.cur.kind!==TK.STRING&&this.cur.kind!==TK.INT&&this.err("expected property name")
;if(this.cur.kind!==TK.IDENT||"get"!==this.cur.sval&&"set"!==this.cur.sval||this.peek(1).kind!==TK.IDENT){let keyStr;keyStr=this.cur.kind===TK.INT?String(this.cur.ival):this.cur.sval
;const ka=this.atom(keyStr);this.advance();this.expect(TK.COLON,"':'");this.emitByte(OP.DUP);this.parseExpr();this.emitByte(OP.STORE_PROP);this.emitByte(ka);this.emitByte(OP.POP)}else{
const isGetter="get"===this.cur.sval;this.advance();const propName=this.cur.sval;const propAtom=this.atom(propName);this.advance();this.expect(TK.LPAREN,"'('");let params=[]
;while(this.cur.kind!==TK.RPAREN){this.cur.kind!==TK.IDENT&&this.err("expected parameter");params.push(this.cur.sval);this.advance();if(!this.accept(TK.COMMA))break}this.expect(TK.RPAREN,"')'")
;const savedBc=this.bc;const savedLocals=this.locals;const savedNlocals=this.nlocals;this.bc=this.body;this.locals=[];for(const p of params)this.localAdd(p);const funcEntry={pc:this.bc.length,
argc:params.length,nlocals:0,bodySize:0};this.funcs.length>=63&&this.err("too many functions");this.funcs.push(funcEntry);this.parseBlock();this.emitByte(OP.RET_UNDEF)
;funcEntry.nlocals=this.locals.length;funcEntry.bodySize=this.bc.length-funcEntry.pc;this.bc=savedBc;this.locals=savedLocals;this.nlocals=savedNlocals;const funcIdx=this.funcs.length-1
;this.emitByte(OP.FUNCTION);this.emitByte(funcIdx);this.emitByte(OP.DEFINE_ACCESSOR);this.emitByte(propAtom);this.emitByte(isGetter?1:0)}if(!this.accept(TK.COMMA))break}this.expect(TK.RBRACE,"'}'")
;return;case TK.FUNCTION:{this.advance();let name=null;this.cur.kind===TK.IDENT&&(name=this.advance().sval);this.parseFunction(name);return}default:this.err("unexpected token in expression")}}
encodeFixed(v){const u=(1073741823&v)<<2|1;return[255&u,u>>8&255,u>>16&255,u>>24&255]}cp1251Encode(s){const bytes=[];for(let i=0;i<s.length;i++){let c=s.charCodeAt(i)
;c<128?bytes.push(c):c>=1040&&c<=1103?bytes.push(c-848):1025===c?bytes.push(168):1105===c?bytes.push(184):c>=160&&c<=255?bytes.push(c):bytes.push(63)}return bytes}serialize(){
const topLevelSize=this.bc.length;const bodyOffset=topLevelSize;for(const f of this.funcs)f.pcAbsolute=bodyOffset+f.pc;const allBc=this.bc.concat(this.body);const parts=[];parts.push([77,74,83,66])
;parts.push([1]);parts.push([0]);const atomCount=this.atoms.length;parts.push([255&atomCount,atomCount>>8&255]);for(const s of this.atoms){const bytes=this.cp1251Encode(s);const len=bytes.length
;parts.push([255&len,len>>8&255]);parts.push(bytes);parts.push([0])}const constCount=this.consts.length;parts.push([255&constCount,constCount>>8&255]);for(const c of this.consts)if(0===c.type){
parts.push([0]);parts.push(this.encodeFixed(c.value))}else{parts.push([1]);const bytes=this.cp1251Encode(c.value);const len=bytes.length;parts.push([255&len,len>>8&255]);parts.push(bytes)
;parts.push([0])}const funcCount=this.funcs.length;parts.push([255&funcCount,funcCount>>8&255])
;for(const f of this.funcs)parts.push([f.argc,f.nlocals,255&f.pcAbsolute,f.pcAbsolute>>8&255,255&f.bodySize,f.bodySize>>8&255]);parts.push(allBc);let total=0;for(const p of parts)total+=p.length
;const out=new Uint8Array(total);let off=0;for(const p of parts){out.set(p,off);off+=p.length}return out}optimize(){const optimizeRegion=bc=>{if(0===bc.length)return
;const opHasU8Arg=op=>op===OP.INT8||op===OP.LOAD_LOCAL||op===OP.STORE_LOCAL||op===OP.LOAD_GLOBAL||op===OP.STORE_GLOBAL||op===OP.LOAD_PROP||op===OP.STORE_PROP||op===OP.NEW_ARRAY||op===OP.CALL||op===OP.FUNCTION||op===OP.CONST||op===OP.NEW||op===OP.CALL_WITH_THIS||op===OP.DEFINE_ACCESSOR||op===OP.NATIVE_CALL
;const opIsJump=op=>op===OP.JMP||op===OP.JZ||op===OP.JNZ||op===OP.PUSH_TRY;const opIsVarLen=op=>op===OP.NEW_ARRAY_U8||op===OP.NEW_ARRAY_U16;const varLenSize=(bc,i)=>{const count=bc[i+1]
;return bc[i]===OP.NEW_ARRAY_U8?2+count:bc[i]===OP.NEW_ARRAY_U16?2+2*count:2};const pcMap=new Array(bc.length+1);let newPc=0;let i=0;while(i<bc.length){const op=bc[i];pcMap[i]=newPc
;if(op===OP.NOP)i++;else if(opIsVarLen(op)){const sz=varLenSize(bc,i);newPc+=sz;i+=sz}else if(opIsJump(op)){newPc+=3;i+=3}else if(opHasU8Arg(op)){newPc+=2;i+=2}else if(op===OP.INT16){newPc+=3;i+=3
}else if(op===OP.INT24){newPc+=4;i+=4}else{newPc+=1;i+=1}}pcMap[bc.length]=newPc;const out=[];i=0;while(i<bc.length){const op=bc[i];if(op!==OP.NOP)if(opIsVarLen(op)){const sz=varLenSize(bc,i)
;for(let j=0;j<sz;j++)out.push(bc[i+j]);i+=sz}else if(opIsJump(op)){const off=bc[i+1]|bc[i+2]<<8;const signed=off>32767?off-65536:off;const oldTarget=i+3+signed
;const newTarget=void 0!==pcMap[oldTarget]?pcMap[oldTarget]:newPc;const newOff=newTarget-(out.length+3);out.push(op,255&newOff,newOff>>8&255);i+=3}else if(opHasU8Arg(op)){out.push(bc[i],bc[i+1]);i+=2
}else if(op===OP.INT16){out.push(bc[i],bc[i+1],bc[i+2]);i+=3}else if(op===OP.INT24){out.push(bc[i],bc[i+1],bc[i+2],bc[i+3]);i+=4}else{out.push(bc[i]);i++}else i++}bc.length=0
;for(const b of out)bc.push(b);if(bc===this.bc&&this.lineMap.length>0)for(const e of this.lineMap)e.pc=void 0!==pcMap[e.pc]?pcMap[e.pc]:e.pc};optimizeRegion(this.bc);optimizeRegion(this.body)
;const topLevelSize=this.bc.length;for(const f of this.funcs)f.pcAbsolute=topLevelSize+f.pc}compile(source){try{this.parse(source);this.optimize();const bc=this.serialize();return{bytecode:bc,
atoms:this.atoms.length,consts:this.consts.length,funcs:this.funcs.length,bcSize:this.bc.length,bodySize:this.body.length,lineMap:this.lineMap}}catch(e){return e instanceof CompileError?{
error:e.message,line:e.line,col:e.col,token:e.token,src_line:e.src_line}:{error:"internal: "+e.message,line:0,col:0,token:"",src_line:""}}}}
"undefined"!=typeof module&&module.exports&&(module.exports={MicroJSCompiler:MicroJSCompiler,OP:OP,TK:TK,CompileError:CompileError});if("undefined"!=typeof window){
window.MicroJSCompiler=MicroJSCompiler;window.MJS_OP=OP;window.MJS_TK=TK}
)JS";

#endif
