/* microjs_regex.h — Tiny regex engine for microjs ESPboy
 *
 * Adapted from https://github.com/wenhu1024/Tiny-regExp
 * (Russ Cox's NFA-based regex, minimal implementation)
 *
 * Supports: literal chars, . * + ? | ( )
 * Does NOT support: [a-z] ranges, \d \w \s, ^ $ anchors
 *
 * API:
 *   int regex_match(const char *pattern, const char *text);
 *   Returns 1 if pattern matches text, 0 otherwise.
 *
 * SPDX-License-Identifier: MIT
 */
#ifndef MICROJS_REGEX_H
#define MICROJS_REGEX_H

#include <stdlib.h>
#include <string.h>

/* ============================================================
 * re2post — convert infix regex to postfix
 * Uses '~' for concatenation (not '.') so '.' can be a wildcard.
 * ============================================================ */
static char *re2post(char *re) {
    int nalt = 0, natom = 0;
    static char buf[512];
    char *dst;
    struct { int nalt, natom; } paren[50], *p;
    p = paren;
    dst = buf;
    if (strlen(re) >= sizeof(buf) / 2) return NULL;
    for (; *re; ++re) {
        switch (*re) {
        case '(': if (natom > 1) { --natom; *dst++ = '~'; }
            if (p >= paren + 50) return NULL;
            p->nalt = nalt; p->natom = natom; ++p;
            nalt = 0; natom = 0; break;
        case '|': if (natom == 0) return NULL;
            while (--natom > 0) *dst++ = '~';
            ++nalt; break;
        case ')': if (p == paren || natom == 0) return NULL;
            while (--natom > 0) *dst++ = '~';
            for (; nalt > 0; --nalt) *dst++ = '|';
            --p; nalt = p->nalt; natom = p->natom; ++natom; break;
        case '*': case '+': case '?':
            if (natom == 0) return NULL;
            *dst++ = *re; break;
        default:  /* literal chars including '.' (wildcard) */
            if (natom > 1) { --natom; *dst++ = '~'; }
            *dst++ = *re; ++natom; break;
        }
    }
    if (p != paren) return NULL;
    while (--natom > 0) *dst++ = '~';
    for (; nalt > 0; nalt--) *dst++ = '|';
    *dst = 0;
    return buf;
}

/* ============================================================
 * NFA construction (verbatim from original)
 * ============================================================ */
enum { SPLIT = 256, MATCH = 257 };
typedef struct State State;
struct State { int c; State *out; State *out1; int lastList; };
static State matchstate = { MATCH };
static int nstate;

static State *state(int c, State *out, State *out1) {
    State *s = (State*)malloc(sizeof *s);
    ++nstate;
    s->c = c; s->out = out; s->out1 = out1; s->lastList = 0;
    return s;
}

typedef struct Frag Frag;
typedef union Ptrlist Ptrlist;
struct Frag { State *start; Ptrlist *out; };
union Ptrlist { Ptrlist *next; State *s; };

static Ptrlist *list1(State **outp) {
    Ptrlist *l = (Ptrlist*)outp; l->next = NULL; return l;
}
static void patch(Ptrlist *l, State *s) {
    Ptrlist *next;
    for (; l; l = next) { next = l->next; l->s = s; }
}
static Ptrlist *append(Ptrlist *l1, Ptrlist *l2) {
    Ptrlist *old = l1;
    while (l1->next) l1 = l1->next;
    l1->next = l2; return old;
}

static State *post2nfa(char *postfix) {
    Frag stack[100], *stackp, e1, e2, e;
    State *s;
    if (postfix == NULL) return NULL;
    stackp = stack;
    for (char *p = postfix; *p; ++p) {
        switch (*p) {
        default:
            s = state(*p, NULL, NULL);
            { Frag f = {s, list1(&s->out)}; *stackp++ = f; }
            break;
        case '~':  /* concatenation (was '.' in original) */
            e2 = *--stackp; e1 = *--stackp;
            patch(e1.out, e2.start);
            { Frag f = {e1.start, e2.out}; *stackp++ = f; }
            break;
        case '|':
            e2 = *--stackp; e1 = *--stackp;
            s = state(SPLIT, e1.start, e2.start);
            { Frag f = {s, append(e1.out, e2.out)}; *stackp++ = f; }
            break;
        case '?':
            e = *--stackp;
            s = state(SPLIT, e.start, NULL);
            { Frag f = {s, append(e.out, list1(&s->out1))}; *stackp++ = f; }
            break;
        case '*':
            e = *--stackp;
            s = state(SPLIT, e.start, NULL);
            patch(e.out, s);
            { Frag f = {s, list1(&s->out1)}; *stackp++ = f; }
            break;
        case '+':
            e = *--stackp;
            s = state(SPLIT, e.start, NULL);
            patch(e.out, s);
            { Frag f = {e.start, list1(&s->out1)}; *stackp++ = f; }
            break;
        }
    }
    e = *--stackp;
    if (stackp != stack) return NULL;
    patch(e.out, &matchstate);
    return e.start;
}

/* ============================================================
 * NFA execution (verbatim from original)
 * ============================================================ */
typedef struct List { State **s; int n; } List;
static List l1, l2;
static int listid;

static void addstate(List *l, State *s) {
    if (s == NULL || s->lastList == listid) return;
    s->lastList = listid;
    if (s->c == SPLIT) { addstate(l, s->out); addstate(l, s->out1); return; }
    l->s[l->n++] = s;
}

static List *startlist(State *start, List *l) {
    l->n = 0; ++listid; addstate(l, start); return l;
}

static int ismatch(List *l) {
    for (int i = 0; i < l->n; ++i)
        if (l->s[i] == &matchstate) return 1;
    return 0;
}

static void step(List *clist, int c, List *nlist) {
    ++listid; nlist->n = 0;
    for (int i = 0; i < clist->n; ++i) {
        State *s = clist->s[i];
        /* T51: '.' (0x2E) matches any character */
        if (s->c == c || s->c == '.') addstate(nlist, s->out);
    }
}

static int nfa_match(State *start, const char *s) {
    List *clist = startlist(start, &l1), *nlist = &l2, *tmp;
    for (; *s; s++) {
        step(clist, *s & 0xFF, nlist);
        tmp = clist; clist = nlist; nlist = tmp;
    }
    return ismatch(clist);
}

/* ============================================================
 * Public API
 * ============================================================ */

/* Free NFA states (walk and free all allocated states). */
static void regex_free_states(State *s) {
    if (!s || s->lastList == -1) return;
    s->lastList = -1;
    if (s->c == SPLIT) {
        regex_free_states(s->out);
        regex_free_states(s->out1);
    } else if (s->c != MATCH) {
        regex_free_states(s->out);
    }
    if (s != &matchstate) free(s);
}

/* Match pattern against text. Returns 1 if match, 0 if no match. */
static int regex_match(const char *pattern, const char *text) {
    nstate = 0;
    listid = 0;  /* defensive: avoid theoretical -1 collision with regex_free_states marker */
    char *post = re2post((char*)pattern);
    if (!post) return 0;
    State *start = post2nfa(post);
    if (!start) return 0;
    if (nstate <= 0) nstate = 1;
    l1.s = (State**)malloc(nstate * sizeof(State*));
    l2.s = (State**)malloc(nstate * sizeof(State*));
    int result = nfa_match(start, text);
    free(l1.s); free(l2.s);
    regex_free_states(start);
    return result;
}

#endif /* MICROJS_REGEX_H */
