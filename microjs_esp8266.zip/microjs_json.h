/* microjs_json.h — JSON.parse + JSON.stringify for microjs ESPboy.
 *
 * Uses tiny-json (https://github.com/rafagafe/tiny-json) for parsing.
 * Stringify is a custom recursive serializer (json-maker not available
 * as a single-header, so we write our own — it's ~80 lines).
 *
 * API exposed to JS:
 *   JSON.parse(str)   → object/array/string/number/boolean/null
 *   JSON.stringify(value) → string
 *
 * Limitations:
 *   - JSON.parse: integers up to 2^30 (fixed24.8), no floats
 *   - JSON.stringify: no pretty-printing, no replacer/space args
 *   - Pool size for parse: 64 json_t entries (enough for typical configs)
 *
 * SPDX-License-Identifier: MIT
 */
#ifndef MICROJS_JSON_H
#define MICROJS_JSON_H

/* tiny-json parser — included inline so we don't need a separate .c */
#include "tiny-json.h"

/* ============================================================
 * JSON.parse — parse a JSON string into JS values
 * ============================================================
 * tiny-json requires a MUTABLE input buffer (it modifies the string
 * in place, replacing structural chars with '\0').  JS strings may
 * be const (pointing into bytecode blob), so we copy to a heap buffer. */

/* Pool size: how many json_t entries to allocate for the parse tree.
 * Each property/array element uses one entry.  64 is enough for most
 * configs.  If the JSON has more fields, parse returns null. */
#define JSON_PARSE_POOL_SIZE 64

/* Forward declaration — defined in microjs_vm.h */
typedef struct MJSContext MJSContext;
typedef uint32_t MJSValue;

/* Recursive: convert a tiny-json node into an MJSValue. */
static MJSValue json_node_to_mjs(MJSContext *ctx, json_t const* node);

static MJSValue js_json_parse(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1 || !mjs_is_string(ctx, argv[0])) return MJS_UNDEF_V;
    size_t slen;
    const char *src = mjs_to_cstr(ctx, argv[0], &slen);
    if (slen == 0) return MJS_UNDEF_V;

    /* tiny-json mutates the input, so copy to a temp buffer.
     * Use system malloc (not JS heap — the buffer is temporary and
     * would waste JS heap space). */
    char *buf = (char*)malloc(slen + 1);
    if (!buf) return MJS_UNDEF_V;
    memcpy(buf, src, slen);
    buf[slen] = '\0';

    json_t pool[JSON_PARSE_POOL_SIZE];
    json_t const* root = json_create(buf, pool, JSON_PARSE_POOL_SIZE);
    if (!root) {
        free(buf);
        return MJS_UNDEF_V;
    }

    /* T51-fix: Suppress compaction during json_node_to_mjs.
     * json_node_to_mjs calls mjs_new_string/mjs_new_object/mjs_new_array
     * which call mjs_alloc.  If mjs_alloc triggers compaction, it would
     * move JS heap blocks and potentially corrupt the stack-allocated
     * pool[] or the malloc'd buf.  mjs_no_compact prevents this. */
    extern bool mjs_no_compact;
    bool saved_no_compact = mjs_no_compact;
    mjs_no_compact = true;

    /* The root from json_create is always JSON_OBJ (unnamed).
     * But if the input was an array like [1,2,3], tiny-json wraps it.
     * Check the actual root type. */
    jsonType_t rt = json_getType(root);
    MJSValue result;
    if (rt == JSON_ARRAY || rt == JSON_OBJ) {
        result = json_node_to_mjs(ctx, root);
    } else {
        json_t const* child = json_getChild(root);
        result = child ? json_node_to_mjs(ctx, child) : MJS_UNDEF_V;
    }

    mjs_no_compact = saved_no_compact;

    /* The buffer can be freed now — strings created by json_node_to_mjs
     * are copies (mjs_new_string allocates new heap strings). */
    free(buf);
    return result;
}

static MJSValue json_node_to_mjs(MJSContext *ctx, json_t const* node) {
    if (!node) return MJS_UNDEF_V;
    jsonType_t t = json_getType(node);
    switch (t) {
        case JSON_NULL:
            return MJS_NULL_V;
        case JSON_BOOLEAN:
            return json_getBoolean(node) ? MJS_TRUE_V : MJS_FALSE_V;
        case JSON_INTEGER: {
            int64_t v = json_getInteger(node);
            /* T51-fix: Clamp to fixed24.8's representable integer range.
             * int30 raw value is signed 30-bit, with 8 bits fractional →
             * 22-bit integer range = [-2097152, 2097151].
             * Old code clamped to ±8388607 (±2^23), but values above
             * 2097151 produce `v << 8` whose sign bit lands in the tag
             * region after MJS_MAKE_INT — the device then decodes them
             * as negative (e.g. JSON 999999 → device prints -1).
             * See MJS_FIXED_MAX / MJS_FIXED_MIN in microjs_vm.h. */
            if (v > 2097151) v = 2097151;
            if (v < -2097152) v = -2097152;
            return MJS_MAKE_INT((int32_t)(v << 8));
        }
        case JSON_REAL: {
            /* No float support — convert to integer (truncate). */
            double v = json_getReal(node);
            int32_t iv = (int32_t)v;
            /* T51-fix: same clamping as JSON_INTEGER — see above. */
            if (iv > 2097151) iv = 2097151;
            if (iv < -2097152) iv = -2097152;
            return MJS_MAKE_INT(iv << 8);
        }
        case JSON_TEXT: {
            const char *s = json_getValue(node);
            return mjs_new_string(ctx, s, strlen(s));
        }
        case JSON_ARRAY: {
            /* Count children first. */
            int count = 0;
            for (json_t const* c = json_getChild(node); c; c = json_getSibling(c))
                count++;
            MJSValue arr = mjs_new_array(ctx, count);
            int i = 0;
            for (json_t const* c = json_getChild(node); c; c = json_getSibling(c)) {
                mjs_set_index(ctx, arr, i, json_node_to_mjs(ctx, c));
                i++;
            }
            return arr;
        }
        case JSON_OBJ: {
            MJSValue obj = mjs_new_object(ctx);
            for (json_t const* c = json_getChild(node); c; c = json_getSibling(c)) {
                const char *name = json_getName(c);
                if (name && name[0]) {
                    /* Use mjs_set_property which takes a char* key. */
                    mjs_set_property(ctx, obj, name, json_node_to_mjs(ctx, c));
                }
            }
            return obj;
        }
        default:
            return MJS_UNDEF_V;
    }
}

/* ============================================================
 * JSON.stringify — serialize JS value to JSON string
 * ============================================================
 * Recursive serializer.  Output is built in a dynamically-growing
 * buffer (system malloc), then converted to an MJSValue string. */

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} JsonBuf;

static void jb_init(JsonBuf *jb) {
    jb->cap = 256;
    jb->buf = (char*)malloc(jb->cap);
    jb->len = 0;
    if (jb->buf) jb->buf[0] = '\0';
}

static void jb_free(JsonBuf *jb) {
    if (jb->buf) free(jb->buf);
    jb->buf = NULL;
}

static void jb_ensure(JsonBuf *jb, size_t need) {
    if (jb->len + need + 1 < jb->cap) return;
    while (jb->len + need + 1 >= jb->cap) jb->cap *= 2;
    char *nb = (char*)realloc(jb->buf, jb->cap);
    if (nb) { jb->buf = nb; jb->buf[jb->len] = '\0'; }
}

static void jb_putc(JsonBuf *jb, char c) {
    jb_ensure(jb, 1);
    if (jb->buf) { jb->buf[jb->len++] = c; jb->buf[jb->len] = '\0'; }
}

static void jb_puts(JsonBuf *jb, const char *s) {
    size_t l = strlen(s);
    jb_ensure(jb, l);
    if (jb->buf) { memcpy(jb->buf + jb->len, s, l); jb->len += l; jb->buf[jb->len] = '\0'; }
}

/* Escape a string for JSON output (quotes, backslashes, control chars). */
static void jb_escape_str(JsonBuf *jb, const char *s, size_t len) {
    jb_putc(jb, '"');
    for (size_t i = 0; i < len; i++) {
        char c = s[i];
        switch (c) {
            case '"':  jb_puts(jb, "\\\""); break;
            case '\\': jb_puts(jb, "\\\\"); break;
            case '\n': jb_puts(jb, "\\n"); break;
            case '\r': jb_puts(jb, "\\r"); break;
            case '\t': jb_puts(jb, "\\t"); break;
            default:
                if ((unsigned char)c < 0x20) {
                    char hex[8];
                    snprintf(hex, sizeof(hex), "\\u%04x", (unsigned char)c);
                    jb_puts(jb, hex);
                } else {
                    jb_putc(jb, c);
                }
        }
    }
    jb_putc(jb, '"');
}

/* Forward declaration for recursion. */
static void jb_serialize(JsonBuf *jb, MJSContext *ctx, MJSValue v);

static void jb_serialize_object(JsonBuf *jb, MJSContext *ctx, MJSValue obj) {
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(obj);
    MJSObject *o = (MJSObject*)h;
    MJSSlot *slots = o->slots;
    jb_putc(jb, '{');
    int first = 1;
    for (uint16_t i = 0; i < o->capacity; i++) {
        if (slots[i].atom != 0 && slots[i].atom != 0xFFFFu) {
            if (!first) jb_putc(jb, ',');
            first = 0;
            /* Get atom name */
            const char *name = (slots[i].atom <= ctx->atom_count)
                ? ctx->atoms[slots[i].atom - 1] : "?";
            jb_escape_str(jb, name, strlen(name));
            jb_putc(jb, ':');
            jb_serialize(jb, ctx, slots[i].val);
        }
    }
    jb_putc(jb, '}');
}

static void jb_serialize_array(JsonBuf *jb, MJSContext *ctx, MJSValue arr) {
    MJSHeader *h = (MJSHeader*)MJS_GET_PTR(arr);
    MJSArray *a = (MJSArray*)h;
    jb_putc(jb, '[');
    for (int i = 0; i < a->length; i++) {
        if (i) jb_putc(jb, ',');
        MJSValue elem = mjs_get_index(ctx, arr, i);
        jb_serialize(jb, ctx, elem);
    }
    jb_putc(jb, ']');
}

static void jb_serialize(JsonBuf *jb, MJSContext *ctx, MJSValue v) {
    if (MJS_IS_INT(v)) {
        /* fixed24.8: print as integer if no fraction, else decimal. */
        int32_t raw = MJS_GET_INT(v);
        bool neg = raw < 0;
        if (neg) raw = (raw == INT32_MIN) ? INT32_MAX : -raw;
        int32_t ip = raw >> 8;
        int32_t fp = (raw & 0xFF) * 100 / 256;
        char num[32];
        if (fp == 0) {
            snprintf(num, sizeof(num), "%s%d", neg ? "-" : "", (int)ip);
        } else {
            snprintf(num, sizeof(num), "%s%d.%02d", neg ? "-" : "", (int)ip, (int)fp);
        }
        jb_puts(jb, num);
    } else if (v == MJS_TRUE_V) {
        jb_puts(jb, "true");
    } else if (v == MJS_FALSE_V) {
        jb_puts(jb, "false");
    } else if (v == MJS_NULL_V) {
        jb_puts(jb, "null");
    } else if (v == MJS_UNDEF_V) {
        jb_puts(jb, "null");  /* JSON has no undefined → null */
    } else if (MJS_IS_PTR(v)) {
        MJSHeader *h = (MJSHeader*)MJS_GET_PTR(v);
        uint8_t t = MJS_HDR_TYPE(h);
        if (t == MJS_T_STRING) {
            MJSString *s = (MJSString*)h;
            jb_escape_str(jb, s->data, s->len);
        } else if (t == MJS_T_OBJECT) {
            jb_serialize_object(jb, ctx, v);
        } else if (t == MJS_T_ARRAY) {
            jb_serialize_array(jb, ctx, v);
        } else {
            /* Functions, accessors — serialize as null. */
            jb_puts(jb, "null");
        }
    } else {
        jb_puts(jb, "null");
    }
}

static MJSValue js_json_stringify(MJSContext *ctx, int argc, MJSValue *argv) {
    if (argc < 1) return mjs_new_string(ctx, "", 0);
    JsonBuf jb;
    jb_init(&jb);
    if (!jb.buf) return mjs_new_string(ctx, "", 0);
    jb_serialize(&jb, ctx, argv[0]);
    MJSValue result = mjs_new_string(ctx, jb.buf, jb.len);
    jb_free(&jb);
    return result;
}

#endif /* MICROJS_JSON_H */
