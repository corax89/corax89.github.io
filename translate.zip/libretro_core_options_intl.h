#ifndef LIBRETRO_CORE_OPTIONS_INTL_H__
#define LIBRETRO_CORE_OPTIONS_INTL_H__

#if defined(_MSC_VER) && (_MSC_VER >= 1500 && _MSC_VER < 1900)
/* https://support.microsoft.com/en-us/kb/980263 */
#pragma execution_character_set("utf-8")
#pragma warning(disable:4566)
#endif

#include <libretro.h>

/*
 ********************************
 * VERSION: 2.0
 ********************************
 *
 * - 2.0: Add support for core options v2 interface
 * - 1.3: Move translations to libretro_core_options_intl.h
 *        - libretro_core_options_intl.h includes BOM and utf-8
 *          fix for MSVC 2010-2013
 *        - Added HAVE_NO_LANGEXTRA flag to disable translations
 *          on platforms/compilers without BOM support
 * - 1.2: Use core options v1 interface when
 *        RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION is >= 1
 *        (previously required RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION == 1)
 * - 1.1: Support generation of core options v0 retro_core_option_value
 *        arrays containing options with a single value
 * - 1.0: First commit
*/

#ifdef __cplusplus
extern "C" {
#endif

/*
 ********************************
 * Core Option Definitions
 ********************************
*/

/* RETRO_LANGUAGE_JAPANESE */

/* RETRO_LANGUAGE_FRENCH */

/* RETRO_LANGUAGE_SPANISH */

/* RETRO_LANGUAGE_GERMAN */

/* RETRO_LANGUAGE_ITALIAN */

/* RETRO_LANGUAGE_DUTCH */

/* RETRO_LANGUAGE_PORTUGUESE_BRAZIL */

/* RETRO_LANGUAGE_PORTUGUESE_PORTUGAL */

/* RETRO_LANGUAGE_RUSSIAN */

struct retro_core_option_v2_category option_cats_ru[] = {
   { NULL, NULL, NULL },
};

struct retro_core_option_v2_definition option_defs_ru[] = {
   {
      "pcsx_rearmed_frameskip",
      "Пропуск кадров",
      NULL,
      "Выберите, сколько кадров пропускать для повышения производительности за счет визуальной плавности.",
      NULL,
      NULL,
      {
         { "0", "0" },
         { "1", "1" },
         { "2", "2" },
         { "3", "3" },
         { "4", "4" },
         { "5", "5" },
         { "6", "6" },
         { "7", "7" },
         { "8", "8" },
         { "9", "9" },
         { "10", "10" },
         { NULL, NULL },
      },
      "0"
   },
   {
      "pcsx_rearmed_bios",
      "Использовать BIOS",
      NULL,
      "Позволяет использовать реальный файл BIOS (если есть) или эмулированный BIOS (HLE). Для лучшей совместимости рекомендуется использовать официальный файл BIOS.",
      NULL,
      NULL,
      {
         { "auto", "авто" },
         { "HLE", "эмулированный (HLE)" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_region",
      "Регион",
      NULL,
      "Выберите регион системы. NTSC для 60 Гц, PAL для 50 Гц.",
      NULL,
      NULL,
      {
         { "auto", "авто" },
         { "NTSC", "NTSC" },
         { "PAL", "PAL" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_memcard2",
      "Включить вторую карту памяти (общую)",
      NULL,
      "Включить второй слот карты памяти. Эта карта памяти используется совместно всеми играми.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_multitap1",
      "Multitap 1",
      NULL,
      "Включает/отключает multitap на порту 1 и позволяет до 5 игроков в играх, поддерживающих эту функцию.",
      NULL,
      NULL,
      {
         { "auto", "авто" },
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_multitap2",
      "Multitap 2",
      NULL,
      "Включает/отключает multitap на порту 2 и позволяет до 8 игроков в играх, поддерживающих эту функцию. Для работы требуется включенный Multitap 1.",
      NULL,
      NULL,
      {
         { "auto", "авто" },
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_negcon_deadzone",
      "NegCon Twist Мертвая зона (в процентах)",
      NULL,
      "Устанавливает мертвую зону левого аналогового стика RetroPad при эмуляции действия 'поворота' контроллера neGcon. Используется для устранения дрейфа/нежелательного ввода.",
      NULL,
      NULL,
      {
         { "0", "0%" },
         { "5", "5%" },
         { "10", "10%" },
         { "15", "15%" },
         { "20", "20%" },
         { "25", "25%" },
         { "30", "30%" },
         { NULL, NULL },
      },
      "0"
   },
   {
      "pcsx_rearmed_negcon_response",
      "NegCon Twist Отклик",
      NULL,
      "Определяет аналоговый отклик при использовании левого аналогового стика RetroPad для имитации 'поворота' эмулируемого контроллера neGcon.",
      NULL,
      NULL,
      {
         { "linear", "линейный" },
         { "quadratic", "квадратичный" },
         { "cubic", "кубический" },
         { NULL, NULL },
      },
      "linear"
   },
   {
      "pcsx_rearmed_vibration",
      "Включить вибрацию",
      NULL,
      "Включает вибрационную обратную связь для контроллеров, поддерживающих вибрацию.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_dithering",
      "Включить дизеринг",
      NULL,
      "Если отключено, отключает шаблон дизеринга, который PSX применяла для борьбы с цветными полосами.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "enabled"
   },

#ifdef NEW_DYNAREC
   {
      "pcsx_rearmed_drc",
      "Динамическая рекомпиляция",
      NULL,
      "Включает использование динамического рекомпилятора или интерпретатора (медленнее) для инструкций CPU.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_psxclock",
      "Тактовая частота CPU PSX",
      NULL,
      "Разгон или замедление CPU PSX. Попробуйте изменить это значение, если игра слишком медленная, слишком быстрая или зависает."
#if defined(HAVE_PRE_ARMV7) && !defined(_3DS)
      " По умолчанию 50."
#else
      " По умолчанию 57."
#endif
      ,
      NULL,
      NULL,
      {
         { "30", "30 МГц (замедление)" },
         { "40", "40 МГц (замедление)" },
         { "50", "50 МГц" },
         { "57", "57 МГц" },
         { "60", "60 МГц (разгон)" },
         { "66", "66 МГц (разгон)" },
         { "75", "75 МГц (разгон)" },
         { NULL, NULL },
      },
#if defined(HAVE_PRE_ARMV7) && !defined(_3DS)
      "50"
#else
      "57"
#endif
   },
#endif /* NEW_DYNAREC */

#ifdef GPU_NEON
   {
      "pcsx_rearmed_neon_interlace_enable_v2",
      "Включить режим чересстрочности",
      NULL,
      "Включает эффект имитации строк развертки.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено (всегда)" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_neon_enhancement_enable",
      "Улучшенное разрешение",
      NULL,
      "Рендеринг с удвоенным разрешением за счет снижения производительности.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_neon_enhancement_no_main",
      "Улучшенное разрешение (Speed Hack)",
      NULL,
      "Оптимизация скорости для опции улучшенного разрешения (может вызывать проблемы в некоторых играх).",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* GPU_NEON */

   {
      "pcsx_rearmed_display_internal_fps",
      "Отображать внутренний FPS",
      NULL,
      "При включении показывает количество кадров в секунду на экране.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },

   /* GPU PEOPS OPTIONS */
#ifdef GPU_PEOPS
   {
      "pcsx_rearmed_show_gpu_peops_settings",
      "Показать расширенные настройки GPU",
      NULL,
      "Включить или отключить различные исправления GPU. Для применения настроек может потребоваться перезапуск ядра. ПРИМЕЧАНИЕ: Для применения этой настройки необходимо изменить Быстрое меню.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_odd_even_bit",
      "(GPU) Odd/Even Bit Hack",
      NULL,
      "Необходимо для Chrono Cross.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_expand_screen_width",
      "(GPU) Расширить ширину экрана",
      NULL,
      "Для файтингов Capcom.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_ignore_brightness",
      "(GPU) Игнорировать яркость цвета",
      NULL,
      "Черный экран в играх Lunar Silver Star Story.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_disable_coord_check",
      "(GPU) Отключить проверку координат",
      NULL,
      "Режим совместимости.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_lazy_screen_update",
      "(GPU) Ленивое обновление экрана",
      NULL,
      "Для Pandemonium 2.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_old_frame_skip",
      "(GPU) Старый пропуск кадров",
      NULL,
      "Пропускать каждый второй кадр.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_repeated_triangles",
      "(GPU) Повторяющиеся плоские текстурированные треугольники",
      NULL,
      "Необходимо для Star Wars: Dark Forces.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_quads_with_triangles",
      "(GPU) Рисовать четырехугольники треугольниками",
      NULL,
      "Лучшие цвета, худшие текстуры.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_fake_busy_state",
      "(GPU) Поддельные состояния 'GPU занят'",
      NULL,
      "Устанавливать флаги занятости после отрисовки.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* GPU_PEOPS */

   {
      "pcsx_rearmed_show_bios_bootlogo",
      "Показывать загрузочный логотип BIOS",
      NULL,
      "При включении показывает логотип PlayStation при запуске или сбросе. (Может нарушить работу некоторых игр).",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_spu_reverb",
      "Звуковая реверберация",
      NULL,
      "Включает или отключает эффект реверберации звука.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_spu_interpolation",
      "Звуковая интерполяция",
      NULL,
      "Выберите метод интерполяции звука для улучшения качества.",
      NULL,
      NULL,
      {
         { "simple", "простая" },
         { "gaussian", "гауссова" },
         { "cubic", "кубическая" },
         { NULL, NULL },
      },
      "gaussian"
   },
   {
      "pcsx_rearmed_icache_emulation",
      "Эмуляция ICache",
      NULL,
      "Исправления для эмуляции кэша инструкций. Может повысить совместимость с некоторыми играми.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "enabled"
   },

   /* ADVANCED OPTIONS */
   {
      "pcsx_rearmed_noxadecoding",
      "Декодирование XA",
      NULL,
      "Включает или отключает декодирование XA аудио.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_nocdaudio",
      "CD аудио",
      NULL,
      "Включает или отключает аудио с CD.",
      NULL,
      NULL,
      {
         { "enabled", "включено" },
         { "disabled", "отключено" },
         { NULL, NULL },
      },
      "enabled"
   },

#ifdef NEW_DYNAREC
   {
      "pcsx_rearmed_nosmccheck",
      "(Speed Hack) Отключить проверки SMC",
      NULL,
      "Может вызывать сбои при загрузке, повреждать карту памяти.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gteregsunneeded",
      "(Speed Hack) Считать GTE регистры ненужными",
      NULL,
      "Может вызывать графические искажения.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_nogteflags",
      "(Speed Hack) Отключить флаги GTE",
      NULL,
      "Вызывает графические искажения.",
      NULL,
      NULL,
      {
         { "disabled", "отключено" },
         { "enabled", "включено" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* NEW_DYNAREC */

   { NULL, NULL, NULL, NULL, NULL, NULL, {{0}}, NULL },
};

struct retro_core_options_v2 options_ru = {
   option_cats_ru,
   option_defs_ru
};

/* RETRO_LANGUAGE_KOREAN */

/* RETRO_LANGUAGE_CHINESE_TRADITIONAL */

/* RETRO_LANGUAGE_CHINESE_SIMPLIFIED */

/* RETRO_LANGUAGE_ESPERANTO */

/* RETRO_LANGUAGE_POLISH */

/* RETRO_LANGUAGE_VIETNAMESE */

/* RETRO_LANGUAGE_ARABIC */

/* RETRO_LANGUAGE_GREEK */

/* RETRO_LANGUAGE_TURKISH */

struct retro_core_option_v2_category option_cats_tr[] = {
   { NULL, NULL, NULL },
};

struct retro_core_option_v2_definition option_defs_tr[] = {
   {
      "pcsx_rearmed_frameskip",
      "Kare Atlama",
      NULL,
      "Görsel pürüzsüzlük pahasına performansı artırmak için ne kadar karenin atlanması gerektiğini seçin.",
      NULL,
      NULL,
      {
         { "0", "0" },
         { "1", "1" },
         { "2", "2" },
         { "3", "3" },
         { "4", "4" },
         { "5", "5" },
         { "6", "6" },
         { "7", "7" },
         { "8", "8" },
         { "9", "9" },
         { "10", "10" },
         { NULL, NULL },
      },
      "0"
   },
   {
      "pcsx_rearmed_bios",
      "BIOS Kullan",
      NULL,
      "Gerçek bios dosyasını (varsa) veya öykünmüş bios'u (HLE) kullanmanızı sağlar. Daha iyi uyumluluk için resmi bios dosyasını kullanmanız önerilir.",
      NULL,
      NULL,
      {
         { "auto", "otomatik" },
         { "HLE", "öykünmüş (HLE)" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_region",
      "Bölge",
      NULL,
      "Sistemin hangi bölgeden olduğunu seçin. NTSC için 60 Hz, PAL için 50 Hz.",
      NULL,
      NULL,
      {
         { "auto", "otomatik" },
         { "NTSC", "NTSC" },
         { "PAL", "PAL" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_memcard2",
      "İkinci Bellek Kartını Etkinleştir (Paylaşılan)",
      NULL,
      "2. Hafıza kartı yuvasını etkinleştirin. Bu hafıza kartı tüm oyunlar arasında paylaşılır.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_multitap1",
      "Multitap 1",
      NULL,
      "Bağlantı noktası 1'deki multitap'ı etkinleştirir / devre dışı bırakır ve izin veren oyunlarda 5 oyuncuya kadar izin verir.",
      NULL,
      NULL,
      {
         { "auto", "otomatik" },
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_multitap2",
      "Multitap 2",
      NULL,
      "Bağlantı noktası 2'deki multitap'ı etkinleştirir/devre dışı bırakır ve izin veren oyunlarda 8 oyuncuya kadar izin verir. Bunun çalışması için Multitap 1'in etkinleştirilmesi gerekir.",
      NULL,
      NULL,
      {
         { "auto", "otomatik" },
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "auto",
   },
   {
      "pcsx_rearmed_negcon_deadzone",
      "NegCon Twist Deadzone (Yüzdelik)",
      NULL,
      "Öykünülmüş neGcon kontrolörünün 'büküm' eylemini simüle ederken RetroPad sol analog çubuğunun ölü bölgesini ayarlar. Sürüklenme/istenmeyen girişi ortadan kaldırmak için kullanılır.",
      NULL,
      NULL,
      {
         { "0", "0%" },
         { "5", "5%" },
         { "10", "10%" },
         { "15", "15%" },
         { "20", "20%" },
         { "25", "25%" },
         { "30", "30%" },
         { NULL, NULL },
      },
      "0"
   },
   {
      "pcsx_rearmed_negcon_response",
      "NegCon Twist Response",
      NULL,
      "Öykünülmüş neGcon kontrolörünün 'bükümünü' simule etmek için bir RetroPad sol analog çubuğu kullanırken analog cevabını belirtir.",
      NULL,
      NULL,
      {
         { "linear", "doğrusal" },
         { "quadratic", "kuadratik" },
         { "cubic", "kübik" },
         { NULL, NULL },
      },
      "linear"
   },
   {
      "pcsx_rearmed_vibration",
      "Titreşimi Etkinleştir",
      NULL,
      "Titreşim özelliklerini destekleyen kontrolörler için titreşim geri bildirimini etkinleştirir.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_dithering",
      "Dithering Etkinleştir",
      NULL,
      "Kapalı ise, PSX'in renk bantlarıyla mücadele etmek için uyguladığı renk taklidi düzenini devre dışı bırakır.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "enabled"
   },

#ifdef NEW_DYNAREC
   {
      "pcsx_rearmed_drc",
      "Dinamik Yeniden Derleyici",
      NULL,
      "Çekirdeğin dinamik yeniden derleyici veya tercüman(daha yavaş) CPU talimatlarını kullanmasını sağlar.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_psxclock",
      "PSX CPU Saat Hızı",
      NULL,
      "Overclock or under-clock the PSX CPU. Try adjusting this if the game is too slow, too fast or hangs."
#if defined(HAVE_PRE_ARMV7) && !defined(_3DS)
      " Default is 50."
#else
      " Default is 57."
#endif
      ,
      NULL,
      NULL,
      {
         { "30", "30 MHz (underclock)" },
         { "40", "40 MHz (underclock)" },
         { "50", "50 MHz" },
         { "57", "57 MHz" },
         { "60", "60 MHz (overclock)" },
         { "66", "66 MHz (overclock)" },
         { "75", "75 MHz (overclock)" },
         { NULL, NULL },
      },
#if defined(HAVE_PRE_ARMV7) && !defined(_3DS)
      "50"
#else
      "57"
#endif
   },
#endif /* NEW_DYNAREC */

#ifdef GPU_NEON
   {
      "pcsx_rearmed_neon_interlace_enable_v2",
      "Interlacing Mode'u etkinleştir",
      NULL,
      "Sahte tarama çizgileri efektini etkinleştirir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin (her zaman)" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_neon_enhancement_enable",
      "Geliştirilmiş Çözünürlük",
      NULL,
      "Düşük performans pahasına çift çözünürlükte işler.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_neon_enhancement_no_main",
      "Geliştirilmiş Çözünürlük (Speed Hack)",
      NULL,
      "Geliştirilmiş çözünürlük seçeneği için hız aşırtma(bazı oyunlarda sorun çıkartabilir).",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* GPU_NEON */

   {
      "pcsx_rearmed_display_internal_fps",
      "Dahili FPS'yi görüntüle",
      NULL,
      "Etkinleştirildiğinde ekranda saniye başına kareyi gösterir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },

   /* GPU PEOPS OPTIONS */
#ifdef GPU_PEOPS
   {
      "pcsx_rearmed_show_gpu_peops_settings",
      "Gelişmiş GPU Ayarlarını Göster",
      NULL,
      "Çeşitli GPU düzeltmelerini etkinleştirin veya devre dışı bırakın. Ayarların etkili olması için core'un yeniden başlatılması gerekebilir. NOT: Bu ayarın etkili olabilmesi için Hızlı Menü'nün değiştirilmesi gerekir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_odd_even_bit",
      "(GPU) Odd/Even Bit Hack",
      NULL,
      "Chrono Cross için gerekli.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_expand_screen_width",
      "(GPU) Ekran Genişliğini Genişlet",
      NULL,
      "Capcom dövüş oyunları",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_ignore_brightness",
      "(GPU) Parlaklık Rengini Yoksay",
      NULL,
      "Lunar Silver Star Story oyunlarında siyah ekran",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_disable_coord_check",
      "(GPU) Koordinat Kontrolünü Devre Dışı Bırak",
      NULL,
      "Uyumluluk modu",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_lazy_screen_update",
      "(GPU) Tembel Ekran Güncellemesi",
      NULL,
      "Pandemonium 2",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_old_frame_skip",
      "(GPU) Eski Çerçeve Atlama",
      NULL,
      "Her ikinci kareyi atla",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_repeated_triangles",
      "(GPU) Tekrarlanan Düz Doku Üçgenleri",
      NULL,
      "Star Wars: Dark Forces için gerekli",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_quads_with_triangles",
      "(GPU) Üçgenler ile Dörtlü Çiz",
      NULL,
      "Daha iyi g renkler, daha kötü dokular",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gpu_peops_fake_busy_state",
      "(GPU) Sahte 'Gpu Meşgul' Konumları",
      NULL,
      "Çizimden sonra meşgul bayraklarını değiştir",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* GPU_PEOPS */

   {
      "pcsx_rearmed_show_bios_bootlogo",
      "Bios Bootlogo'yu Göster",
      NULL,
      "Etkinleştirildiğinde, başlatırken veya sıfırlarken PlayStation logosunu gösterir. (Bazı oyunları bozabilir).",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_spu_reverb",
      "Ses Yankısı",
      NULL,
      "Ses yankı efektini etkinleştirir veya devre dışı bırakır.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_spu_interpolation",
      "Ses Enterpolasyonu",
      NULL,
      "Ses kalitesini artırmak için enterpolasyon yöntemini seçin.",
      NULL,
      NULL,
      {
         { "simple", "basit" },
         { "gaussian", "gaussian" },
         { "cubic", "kübik" },
         { NULL, NULL },
      },
      "gaussian"
   },
   {
      "pcsx_rearmed_icache_emulation",
      "ICache Düzeltmeleri",
      NULL,
      "Önbellek talimatı emülasyonu için düzeltmeler. Bazı oyunlarla uyumluluğu artırabilir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "enabled"
   },

   /* ADVANCED OPTIONS */
   {
      "pcsx_rearmed_noxadecoding",
      "XA Kod Çözme",
      NULL,
      "XA ses kod çözmeyi etkinleştirir veya devre dışı bırakır.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "enabled"
   },
   {
      "pcsx_rearmed_nocdaudio",
      "CD Ses",
      NULL,
      "CD sesini etkinleştirir veya devre dışı bırakır.",
      NULL,
      NULL,
      {
         { "enabled", "etkin" },
         { "disabled", "devre dışı" },
         { NULL, NULL },
      },
      "enabled"
   },

#ifdef NEW_DYNAREC
   {
      "pcsx_rearmed_nosmccheck",
      "(Speed Hack) SMC Kontrollerini Devre Dışı Bırak",
      NULL,
      "Yükleme sırasında çökmelere neden olabilir, hafıza kartını bozabilir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_gteregsunneeded",
      "(Speed Hack) GTE'nin Gereksiz Olduğunu Varsayın",
      NULL,
      "Grafiksel bozukluklara neden olabilir.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
   {
      "pcsx_rearmed_nogteflags",
      "(Speed Hack) GTE Bayraklarını Devredışı Bırakın",
      NULL,
      "Grafiksel bozukluklara neden olur.",
      NULL,
      NULL,
      {
         { "disabled", "devre dışı" },
         { "enabled", "etkin" },
         { NULL, NULL },
      },
      "disabled"
   },
#endif /* NEW_DYNAREC */

   { NULL, NULL, NULL, NULL, NULL, NULL, {{0}}, NULL },
};

struct retro_core_options_v2 options_tr = {
   option_cats_tr,
   option_defs_tr
};

#ifdef __cplusplus
}
#endif

#endif
