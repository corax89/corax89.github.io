#!/bin/bash
# v36.37 E2E: стик/D-pad swap («Поменять местами стик и D-pad») + R2 = цифра 0.
# (наследник v36.36-теста «Раскладка D-pad» — семантика изменилась:
#  пути СТИКА и КРЕСТОВИНЫ раздельны, swap меняет их местами).
#
# ЧТО ПРОВЕРЯЕТСЯ (TestKeys.jar — Canvas, логирующий keyPressed:
# "[JK] pressed <code>"):
#   1) ДЕФОЛТ (swap=off): крестовина шлёт Nokia-стрелки -1/-2/-3/-4,
#      R2 (ZR) шлёт 48 ('0', KEY_NUM0).
#   2) swap=on (глобальная настройка в settings.ini): крестовина шлёт
#      ITU-T-цифры 50 ('2') / 56 ('8') / 52 ('4') / 54 ('6') — коды без
#      софт-алиасинга для a2-портов (NET Lizard и т.п.), а R2 по-прежнему 48.
#      (Стиковый путь зеркален: off — цифры, on — стрелки; проверяется
#      виртуальными осями в scripts/test_switch_input.c секции 7/7b.)
#   3) Кнопки A/B/X/Y не зависят от раскладки: A = -5 (FIRE), X = -6.
#
# Драйвер: NOJME_FRONT_KEYS (однопамповые фронты реальных кнопок — они
# проходят через switch_joy_button_to_keycode -> sdl_dpad_translate, т.е.
# ровно тот путь, что и физическая крестовина).
set -e
cd "$(dirname "$0")/.." || exit 1
JAR="games/TestKeys.jar"
[ -f "$JAR" ] || bash scripts/keysjar/build.sh
[ -f "$JAR" ] || { echo "TestKeys.jar build failed"; exit 1; }

run_case() {
    local tag="$1" swap="$2" front="$3"
    local D=/tmp/sw_dpad_$tag
    rm -rf "$D"; mkdir -p "$D/roms" "$D/xdg"
    cp "$JAR" "$D/roms/"
    cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=nearest
audio=off
vm_speed=turbo
logging=on
swap=$swap
EOF
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    NOJME_LOG=1 \
    NOJME_SWITCH_BROWSE_ROOT="$D/roms" \
    NOJME_SWITCH_UI_DIR="$D" \
    XDG_DATA_HOME="$D/xdg" \
    NOJME_SWITCH_KEYS="A:600,A:800" \
    NOJME_SWITCH_AUTOTEST_EXIT_MS=12000 \
    NOJME_FRONT_KEYS="$front" \
    timeout -k 5 60 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log" || true
    echo "$D"
}

ok=1
say() { if [ "$1" = 0 ]; then echo "  ok   $2"; else echo "  FAIL $2"; ok=0; fi; }

# ---------- Кейс 1: дефолт (swap=off) ----------
D=$(run_case off off "UP:3000,DOWN:400,LEFT:400,RIGHT:400,ZR:800,A:800,X:600")
ALL="$D/log.txt $D/err.log $D/out.log"
grep -ahq "JK] start" $ALL || { echo "FAIL[off]: TestKeys.jar не стартовал"; ok=0; }
grep -ahq "stick=digits 2/4/6/8 dpad=arrows" $ALL && say 0 "off: лог '[SWITCH] stick/dpad layout: stick=digits dpad=arrows'" || { say 1 "off: нет лога stick/dpad layout"; }
grep -ahq "stick dead zone: 50%" $ALL && say 0 "off: лог 'stick dead zone: 50%'" || { say 1 "off: нет лога dead zone"; }
grep -ahq "JK] pressed -1" $ALL && say 0 "off: UP -> keyPressed(-1)" || say 1 "off: UP не дал -1"
grep -ahq "JK] pressed -2" $ALL && say 0 "off: DOWN -> keyPressed(-2)" || say 1 "off: DOWN не дал -2"
grep -ahq "JK] pressed -3" $ALL && say 0 "off: LEFT -> keyPressed(-3)" || say 1 "off: LEFT не дал -3"
grep -ahq "JK] pressed -4" $ALL && say 0 "off: RIGHT -> keyPressed(-4)" || say 1 "off: RIGHT не дал -4"
grep -ahq "JK] pressed 48" $ALL && say 0 "off: R2 (ZR) -> keyPressed(48) = '0'" || say 1 "off: R2 не дал 48"
grep -ahq "JK] pressed -5" $ALL && say 0 "off: A -> keyPressed(-5) FIRE" || say 1 "off: A не дал -5"
grep -ahq "JK] pressed -6" $ALL && say 0 "off: X -> keyPressed(-6) left soft" || say 1 "off: X не дал -6"
grep -ahq "JK] pressed 50" $ALL && { say 1 "off: цифра 50 пришла от крестовины (не должна)"; } || say 0 "off: цифр от крестовины нет"

# ---------- Кейс 2: swap=on ----------
D=$(run_case on on "UP:3000,DOWN:400,LEFT:400,RIGHT:400,ZR:800,B:800")
ALL="$D/log.txt $D/err.log $D/out.log"
grep -ahq "JK] start" $ALL || { echo "FAIL[on]: TestKeys.jar не стартовал"; ok=0; }
grep -ahq "stick=arrows dpad=digits 2/4/6/8" $ALL && say 0 "on: лог '[SWITCH] stick/dpad layout: stick=arrows dpad=digits'" || { say 1 "on: нет лога stick/dpad layout"; }
grep -ahq "JK] pressed 50" $ALL && say 0 "on: UP -> keyPressed(50) = '2'" || say 1 "on: UP не дал 50"
grep -ahq "JK] pressed 56" $ALL && say 0 "on: DOWN -> keyPressed(56) = '8'" || say 1 "on: DOWN не дал 56"
grep -ahq "JK] pressed 52" $ALL && say 0 "on: LEFT -> keyPressed(52) = '4'" || say 1 "on: LEFT не дал 52"
grep -ahq "JK] pressed 54" $ALL && say 0 "on: RIGHT -> keyPressed(54) = '6'" || say 1 "on: RIGHT не дал 54"
grep -ahq "JK] pressed 48" $ALL && say 0 "on: R2 (ZR) -> keyPressed(48) = '0'" || say 1 "on: R2 не дал 48"
grep -ahq "JK] pressed -7" $ALL && say 0 "on: B -> keyPressed(-7) right soft (не зависит от раскладки)" || say 1 "on: B не дал -7"
for bad in -1 -2 -3 -4; do
  if grep -ahq "JK] pressed $bad" $ALL; then
    say 1 "on: стрелка $bad пришла от крестовины (алиасинг не убран)"; else say 0 "on: стрелок $bad нет"; fi
done

[ "$ok" = 1 ] && echo "DPAD-LAYOUT: ALL CHECKS PASSED" || { echo "DPAD-LAYOUT: CHECKS FAILED"; exit 1; }
