#!/bin/bash
# v36.33 E2E: три полевых игры с проблемами (games.zip, запрос пользователя):
#   Speedx 3D (2.0.0)[240x320], Jewel Adventure [480x800],
#   Temple Rush 3D 2 free (1.1.0)[360x640]
# Поле: Invalid memory access 0x736D722E65726F74 (little-endian ASCII
# "tore.rms" — хвост имени файла хранилища RMS вида "store.rms") на ~37 c.
#
# Сценарий на каждую игру: меню-запуск, 38 c игры, выход через паузу
# (MINUS,DOWN,DOWN,A), релаунч, ещё 12 c, выход через паузу, EXIT.
# Проверки: обе сессии стартовали; нет умираний потоков с необработанным
# исключением; нет [RMS-SLOW]; RMS-файлы реально записаны; чистый выход.
set -u
cd "$(dirname "$0")/.." || exit 1

run_game() {
  local JAR="$1"; local TAG="$2"; local PLAY1="$3"; local PLAY2="$4"
  local D="/tmp/sw_g3_$TAG"
  rm -rf "$D"; mkdir -p "$D/roms"
  cp "$JAR" "$D/roms/game.jar"

  cat > "$D/switchui_settings.ini" <<EOF
settings_version=4
scale=fit_black
filter=nearest
audio=off
vm_speed=normal
logging=on
saves_dir=$D/saves
EOF

  export SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
  export NOJME_LOG=1 NOJME_LOGGING=1
  export NOJME_SWITCH_BROWSE_ROOT="$D/roms"
  export NOJME_SWITCH_UI_DIR="$D"
  export NOJME_SWITCH_KEYS="A:600,A:800"
  export NOJME_SWITCH_AUTOTEST_SESSIONS=2
  export NOJME_SWITCH_AUTOTEST_EXIT_MS="$PLAY2"
  # сессия 1: пауза на PLAY1 c -> выход; сессия 2: пауза на PLAY2 c -> выход
  export NOJME_FRONT_KEYS="MINUS:${PLAY1},DOWN:400,DOWN:400,A:900,MINUS:${PLAY2},DOWN:400,DOWN:400,A:900,EXIT:3000"

  echo "=== $TAG ($JAR) ==="
  timeout -k 5 180 ./bin/switchui-verify > "$D/out.log" 2> "$D/err.log"
  local rc=$?
  echo "exit code: $rc (0 — чистый выход)"

  local NS NRMS NSLOW NDEATH NSTR
  NS=$(grep -ahc "\[SWITCH\] session: " "$D/err.log" | awk '{s+=$1} END{print s+0}')
  NRMS=$(find "$D/saves" -name "*.rms" 2>/dev/null | wc -l)
  NSLOW=$(grep -ahc "RMS-SLOW" "$D/err.log" "$D/log.txt" 2>/dev/null | awk '{s+=$1} END{print s+0}')
  NDEATH=$(grep -ahc "terminated with uncaught exception" "$D/err.log" | awk '{s+=$1} END{print s+0}')
  NSTR=$(grep -ahc "STR-CHARS-NULL" "$D/err.log" "$D/log.txt" 2>/dev/null | awk '{s+=$1} END{print s+0}')
  echo "sessions=$NS (want 2)  rms_files=$NRMS  rms_slow=$NSLOW  thread_deaths=$NDEATH  str_null=$NSTR"

  echo "--- RMS stores:"
  find "$D/saves" -name "*.rms" 2>/dev/null | sed "s|$D/saves/||" | head -10
  echo "--- EX-THROW (последние 5):"
  grep -ah "EX-THROW" "$D/log.txt" 2>/dev/null | tail -5
  echo "--- ERR/panic (последние 5):"
  grep -ahi "\[ERROR\]\|panic\|INVALID\|corrupt" "$D/err.log" "$D/log.txt" 2>/dev/null | tail -5
  echo ""
}

run_game "games/Speedx 3D.jar"        speedx 38000 12000
run_game "games/Jewel Adventure.jar"  jewel  38000 12000
run_game "games/Temple Rush 3D 2.jar" temple 38000 12000
