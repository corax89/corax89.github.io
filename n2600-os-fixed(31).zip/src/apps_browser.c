/* apps_browser.c — веб-браузер N2600-OS.
 *
 * Возможности:
 *   - АДРЕСНАЯ СТРОКА: клик по ней или Ctrl+L — редактирование;
 *     Enter / кнопка «Go» — переход. Поддерживаются:
 *       http://host/path        — HTTP GET (в потоке ЭТОГО окна);
 *       имя файла               — открытие файла из RAM disk
 *                                 (readme.txt, help.md, demo.js...);
 *       www.host/path           — автоматически как http://.
 *   - HTTP GET запрос (net_http_get), выполняется в потоке окна:
 *     зависший запрос больше не блокирует систему и другие окна.
 *   - HTML -> Markdown конвертер (htmlconv.c) + рендеринг Markdown.
 *   - Прокрутка (PgUp/PgDn/стрелки/колёсико).
 *   - Сессия 67: кнопка Save (или Ctrl+S) — сохранить открытую страницу
 *     (Markdown/текст) в RAM disk под именем из адреса; существующие
 *     файлы не перезаписываются (подбирается свободное имя).
 *
 * Исправления аудита (реализованы в htmlconv.c и здесь):
 *   [H1] бесконечный цикл in_tag — см. htmlconv.c;
 *   [H2] static char md[8192] — общий на все окна: теперь буфер
 *        выделяется на каждый вызов browser_load_content() и
 *        принадлежит вызвавшему окну (два окна не конфликтуют);
 *   [H3] entities в конце файла — см. htmlconv.c.
 *
 * Буферы этого окна (browser_t) — собственность ОДНОГО окна;
 * fetch-буфер выделяется только на время запроса.
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "clipboard.h" /* Ctrl+C/V — общий буфер с редактором */
#include "task.h"
#include "sync.h"      /* Task 66: s_lock/s_unlock для ramfs_lookup */
#include "htmlconv.h"
#include "utf8.h"
#include "textinput.h"   /* Task 64 [TI-WIDGET]: адресная строка/поля форм */
#include "brlines.h"
#include "brurl.h"    /* Task 61: разбор host:port, статуса и редиректов
                      * (вынесено для хост-тестов scripts/brhost) */
#include "imgsvc.h"   /* сессия 55: декодирование PNG/JPEG/BMP/GIF */
#include "brpage.h"   /* сессия 55: картинки/ссылки страницы */
#include "brform.h"   /* Task 47: модель форм/скриптов страницы */
#include "filedlg.h"  /* Task 62: выбор файла для <input type=file> */
#include "brjs.h"     /* Task 47: JavaScript страницы (MicroQuickJS) */
#include "mqjs_os.h"  /* Task 47: mqjs_stdlib_def/mqjs_br_cfunc_base */

#define BR_HDR 22          /* высота адресной строки */
#define BR_STATUS_H 14
#define BR_MD_MAX 8192     /* МИНИМАЛЬНЫЙ буфер конвертера на вызов (FIX [H2]);
                            * FIX [BR-LONGPAGE]: для HTML ёмкость растёт от
                            * размера страницы (см. browser_load_content) —
                            * раньше 8 КиБ жёстко обрезали длинные страницы */
/* FIX [BR-3MB] (Task 66): 1 МиБ мало большим страницам (запрос
 * пользователя: «подними до 3 мегабайт» — github.com ~530 КиБ,
 * SPA-страницы с инлайн-JSON дорастают до 2–3 МиБ). Буфер освобождается
 * сразу после конвертации; при куче ≤ 32 МиБ malloc честно откажет —
 * браузер покажет «Нет памяти под ответ». */
#define BR_FETCH_MAX 3145728 /* HTTP-ответ на время запроса (3 МиБ; было
                             * 1 МиБ, до того 256 КиБ) */
#define BR_FILE_MAX 3145728 /* лимит файла из RAM disk / не-HTML текста
                            * (было 1 МиБ) */
#define BR_ADDR_MAX 118
#define BR_HIST_MAX 16     /* история для Back (сессия 55) */
/* Task 67 [IMG-BUDGET]: суммарный бюджет декодированных картинок страницы.
 * Прежде br_load_images держал ВСЕ rgba одновременно: 20 фото × 700×400×4
 * ≈ 22 МиБ — на куче 32 МиБ с учётом страницы/JS это OOM. При превышении
 * бюджета выгружаются самые РАННИЕ по позиции на странице (state=0 —
 * заглушка-строка; перезагрузка возможна через F5). */
#define BR_IMG_BUDGET (6u * 1024u * 1024u)
/* Task 67 [BR-SRCCAP]: исходник страницы хранится только для Save.
 * Копия страницы до 3 МиБ — дорого; для страниц > 512 КиБ исходник НЕ
 * хранится (Ctrl+S сохранит Markdown — он и есть текст). */
#define BR_SRC_MAX (512u * 1024u)
/* Task 67 [BR-FIND]: буфер поиска по странице (Ctrl+F) */
#define BR_FIND_MAX 48
/* \u2550\u2550\u2550\u2550 Session 93 \u2550\u2550\u2550\u2550 */
/* [BR-LAZY]: конвертировать только первые 100 KiB HTML (страница видна
 * сразу), весь сырой вход копится в спуле окна; доконвертация ЦЕЛИКОМ
 * свежим прогоном конвертера \u2014 по прокрутке к низу / кнопке
 * «Догрузить» / End. Спул ограничен \u2014 хвост сверх лимита честно
 * отбрасывается со счётчиком. */
#define BR_CONV_AHEAD (100u * 1024u)
#define BR_RAW_KEEP   (1024u * 1024u)
/* [BR-ERRLOG]: журнал ошибок окна (Ctrl+E): кольцо на 12 записей */
#define BR_ERRLOG_N   12
#define BR_ERRLOG_MAX 96
/* ═════ Session 93 ═════ */
/* [BR-LAZY]: конвертировать только первые 100 КиБ HTML (страница видна
 * сразу), весь сырой вход — в спул; доконвертация целиком — при
 * прокрутке к низу / кнопке «Догрузить» / End. */
#define BR_CONV_AHEAD (100u * 1024u)
#define BR_RAW_KEEP   (1024u * 1024u)   /* спул сырого входа под доконвертацию */
/* [BR-ERRLOG]: журнал ошибок окна (Ctrl+E): кольцо на 12 записей */
#define BR_ERRLOG_N   12
#define BR_ERRLOG_MAX 96

/* FIX (аудит UTF-8): прежде строки хранились в фикс-массиве 100x96 БАЙТ:
 *  - длинные строки ОБРЕЗАЛИСЬ (переноса не было вовсе),
 *  - кириллица резалась посередине символа (2 байта UTF-8).
 * Теперь текст хранится как есть (b->md), а строки отображения —
 * динамический массив, который перестраивается с ПЕРЕНОСОМ по СИМВОЛАМ
 * под текущую ширину окна (любая длинная строка переносится корректно). */
typedef struct {
    char *md;              /* исходный текст (Markdown/простой текст) */
    int  md_len;
    brl_list_t L;          /* строки отображения после переноса (brlines.h) */
    int  wrap_maxc;        /* ширина (в символах), по которой строились L; -1 = не строили */
    int  scroll;
    int  fetching;         /* 1 = идёт сетевой запрос (в этом потоке) */
    char url[256];         /* адрес текущей страницы (Task 66: было 128 —
                           * длинные URL обрезались и ломали базу
                           * относительных ссылок/картинок) */
    char status[96];
    char fetch_note[40];   /* Task 66 [BR-STATUS]: "получено X из Y" —
                           * не затирается сообщениями JS-ошибок */
    char hover[96];        /* сессия 55: ссылка под курсором (для статуса) */
    /* адресная строка.
     * Task 64 [TI-WIDGET]: редактирование — общий виджет ввода:
     * кириллица принимается (UTF-8), курсор/удаление — по СИМВОЛАМ,
     * вставка в произвольную позицию, Ctrl+V — из буфера обмена. */
    char addr[BR_ADDR_MAX + 1];
    ti_t addr_ti;              /* buf = addr (см. br_new_state) */
    int  addr_focus;       /* 1 = редактируем адрес */
    /* [BR-ADDRSEL] (сессия 100): выделение мышью в адресной строке */
    int  addr_drag;        /* 1 = ЛКМ зажата в поле адреса (drag) */
    int  addr_anchor;      /* якорь выделения, байты */
    /* [BR-NAVCARET] (сессия 100): интерактивные элементы страницы —
     * «каретка» навигации стрелками. Строится лениво (br_nav_rebuild)
     * по строкам отображения: ссылки, ЧЬЁ НАЧАЛО лежит в строке +
     * строки-якоря полей форм. nav_i — текущий элемент (-1 = нет). */
    int  nav_i;
    u32  nav_gen;          /* wrap_gen при построении списка */
    int  nav_n, nav_cap;
    int *nav_row;          /* строка отображения элемента */
    u8  *nav_kind;         /* 0 = ссылка (page.links), 1 = поле (forms) */
    int *nav_idx;          /* индекс в page.links / forms.fields */
    /* Task 64 [TI-WIDGET]: редактор ЗФОКУСИРОВАННОГО поля формы
     * (buf = fl->value выбранного text/password/search/textarea) */
    ti_t field_ti;
    /* выделение текста (запрос: «копирование между приложениями,
     * в том числе браузером»). Координаты — строки ОТОБРАЖЕНИЯ (b->L)
     * и колонки в СИМВОЛАХ: sel_ar/ac — якорь (нажатие ЛКМ),
     * sel_br/bc — второй конец (drag). Нормализация — в br_sel_norm. */
    int sel_active;        /* 1 = есть непустое выделение */
    int sel_drag;          /* 1 = ЛКМ зажата в контенте (drag) */
    int sel_ar, sel_ac;    /* якорь: строка/колонка отображения */
    int sel_br, sel_bc;    /* второй конец (следует за курсором) */
    /* полоса прокрутки (общий виджет, сессия 17) */
    wm_scrollbar_t sb;
    /* сессия 55: картинки/ссылки страницы + история Back */
    brp_page_t page;
    int  imgs_pending;     /* 1 = картинки ждут загрузки (окно уже есть) */
    char hist[BR_HIST_MAX][256];   /* Task 66: было [128] */
    int  hist_n;
    /* Task 67 [BR-FWD]: стек ВПЕРЁД (Alt+Right). Заполняется при Back,
     * чистится при обычном переходе (как в больших браузерах). */
    char hist_f[BR_HIST_MAX][256];
    int  hist_f_n;
    int  hist_jump;        /* 1 = переход Back/Forward: НЕ чистить hist_f,
                           * историю назад/вперёд не дублировать */
    /* Task 67 [BR-FIND]: поиск по странице (Ctrl+F) */
    char find_q[BR_FIND_MAX + 1];  /* запрос (UTF-8; регистр — только ASCII) */
    int  find_mode;        /* 1 = идёт ввод запроса (мини-режим) */
    int  find_total;       /* совпадений на странице (для статуса) */
    /* Task 67 [BR-NAVT]: защита от бесконечных цепочек JS/meta-редиректов
     * стала ПОЛЕМ окна (было глобальной — UB при двух окнах) */
    int  nav_chain;
    /* Task 62 [BR-UPLOAD]: multipart-POST (было глобальным s_post_* —
     * гонка между окнами браузера) */
    const char *post_ct;
    u32         post_len;
    /* Task 47: формы и JavaScript страницы */
    brf_forms_t forms;     /* поля форм + скрипты (brform.h) */
    brjs_env_t  js;        /* JS-контекст страницы (живёт до закрытия/перехода) */
    int         focus;     /* фокус ввода: индекс поля или -1 */
    /* Task 62 [BR-UPLOAD]: поле <input type=file> — выбранный файл.
     * filedlg_open читает содержимое (до FD_READ_MAX=64К — как раз
     * лимит httpd) и передаёт владение буфером сюда. */
    int         up_field;      /* индекс file-поля (или -1) */
    char        up_fname[64];  /* имя выбранного файла (для filename=) */
    char       *up_data;       /* содержимое (malloc) или NULL */
    u32         up_len;        /* размер содержимого */
    int         file_dlg;      /* 1 = открыт диалог выбора (ввод в окно игнорить) */
    /* Task 60 [BR-TRUNC]: честная диагностика сетевого обреза
     * (ответ не влез в fetch-буфер: net_http_truncated()) */
    int         fetch_trunc;   /* 1 = ответ обрезан по лимиту буфера */
    u32         fetch_total;   /* Content-Length сервера (0 = неизвестен) */
    /* Task 68 [BR-STREAM]: потоковая загрузка страницы (HTML конвертируется
     * по мере приёма; полного ответа в памяти НЕТ) */
    hc_stream_t *hcs;          /* активная конвертация (внутри fetch) */
    /* [HC-ENC-SOFT] (Google): «мягкая» кодировка из Content-Type
     * (iso-8859-1/latin1/windows-1252) — её может переопределить
     * meta-charset HTML (Google шлёт charset=ISO-8859-1 неизвестным
     * UA при UTF-8-теле + meta charset=UTF-8). Хранится для и для
     * ленивой доконвертации (заголовок к тому моменту уже ушёл). */
    char        hcs_soft[24];
    char       *md_buf;        /* буфер md потоковой конвертации (растёт) */
    int         md_cap;        /* его ёмкость */
    u32         net_got;       /* сырых байт тела пришло (для статуса) */
    /* Task 68 [BR-BGIMG]: фоновая загрузка картинок */
    struct br_ichan *ichan;    /* канал окно->воркер (куча, переживает close) */
    int         img_gen;       /* поколение страницы (защита результатов) */
    int         img_ok, img_fail;
    u32         img_used;      /* байт под декодированные rgba (бюджет) */
    /* Session 92 [BR-IMGCACHE]: готовые картинки прошлой страницы —
     * перезагрузка (F5) той же страницы не качает их заново */
#define BR_IMG_CACHE_N 4
    struct {
        u32 hash;
        int w, h, dw, dh;
        u8 *rgba;
    } img_cache[BR_IMG_CACHE_N];
    /* Session 92 [BR-DD]: раскрытый список select */
    int         dd_open;       /* 1 = список раскрыт для поля dd_field */
    int         dd_field;      /* индекс поля (brf_field_t) */
    int         dd_cur;        /* курсор в списке вариантов */
    /* Task 51 [BR-SAVE]: исходник страницы (HTML ДО конвертации) —
     * «Save» сохраняет его как есть: с комментариями, <script> и
     * кнопками (Markdown-конверсия всё это вырезает) */
    char *src;
    int   src_len;
    /* ═══ Session 93 [BR-LAZY]: ленивая конвертация потока ═══
     * Конвертер получает первые BR_CONV_AHEAD байт; весь сырой вход
     * копится в raw_keep; на прокрутке к низу страница ДОконвертируется
     * целиком свежим прогоном конвертера. */
    char       *raw_keep;         /* спул сырого HTML (malloc) или NULL */
    u32         raw_keep_len;
    u32         raw_keep_cap;
    u32         raw_total;        /* всего байт тела пришло (для честного статуса) */
    int         lazy_pending;     /* 1 = есть неконвертированный хвост */
    /* [BR-AUTOTAIL] (сессия 101): тик-барьер автодоконвертации. После
     * отказа памяти (автодогрузка/брак malloc в br_lazy_convert) тик
     * НЕ повторяет попытку 10 секунд — иначе статус каждые полсекунды
     * мигал «Нет памяти», а куча фрагментировалась. Кнопка «Догрузить»
     * и End барьер не читают — явный запрос работает всегда. */
    u32         lazy_cool;
    /* ═══ Session 93 [BR-JSDEFER]: отложенные скрипты ═══
     * Критичные (document.write в коде) исполняются при загрузке;
     * остальные — при первом взаимодействии (клавиша/мышь). Якоря \x04
     * отложенных живут в md до исполнения (не рисуются). */
    int         js_deferred;
    /* ═══ Session 93 [BR-WRAPCACHE]: диагностика кэша переноса ═══ */
    u32         wrap_time;        /* тики последней перестройки строк */
    u32         wrap_gen;         /* счётчик перестроек */
    /* ═══ [BR-THEME]: тема ОКНА (тёмная = 0 по умолчанию / светлая = 1).
     * Локальная палитра браузера поверх глобальной темы WM: кнопка
     * «Свет/Тёмн» в тулбаре переключает на лету. Не сохраняется —
     * живёт, пока живо окно (переживает переходы по ссылкам). */
    int         light;
    /* ═══ Session 93 [BR-RETRY]: сетевая ошибка -> кнопка «Повторить» ═══ */
    int         net_err;          /* 1 = последняя навигация упала по сети */
    char        retry_url[448];   /* адрес для повтора */
    /* ═══ Session 93 [BR-ERRLOG]: журнал ошибок (Ctrl+E) ═══ */
    char        errlog[BR_ERRLOG_N][BR_ERRLOG_MAX];
    u32         errlog_tick[BR_ERRLOG_N];
    int         errlog_n, errlog_head;
    int         errlog_open;
    /* служебное */
    window_t *win;
} browser_t;

/* ---------- утилиты ---------- */

/* ═══ [BR-THEME]: локальная палитра окна браузера. Тёмная — прежние
 * цвета (частично из глобальной темы WM, частично хардкод); светлая —
 * подобрана под белую бумагу: тёмный текст, светло-серые панели,
 * синий акцент. Все рисовальщики окна (br_draw, br_draw_field,
 * br_draw_text_line) берут цвета ТОЛЬКО отсюда — смена темы
 * согласована по всему окну. */
static u32 br_col_bg(browser_t *b)          /* фон контента */
{ return b->light ? fb_rgb(0xF4, 0xF5, 0xF7) : wm_theme_win_bg(); }
static u32 br_col_bg_alt(browser_t *b)      /* статус-бар, шапки */
{ return b->light ? fb_rgb(0xE9, 0xEB, 0xEF) : wm_theme_win_bg_alt(); }
static u32 br_col_toolbar(browser_t *b)     /* тулбар с адресом */
{ return b->light ? fb_rgb(0xDE, 0xE3, 0xEA) : fb_rgb(0x16, 0x1C, 0x24); }
static u32 br_col_field(browser_t *b)       /* поля ввода/кнопок */
{ return b->light ? fb_rgb(0xFF, 0xFF, 0xFF) : fb_rgb(0x1E, 0x24, 0x2C); }
static u32 br_col_field_focus(browser_t *b)
{ return b->light ? fb_rgb(0xFF, 0xFF, 0xFF) : wm_theme_win_bg_alt(); }
static u32 br_col_border(browser_t *b)      /* рамки полей */
{ return b->light ? fb_rgb(0xB6, 0xBE, 0xC8) : fb_rgb(0x34, 0x3A, 0x42); }
static u32 br_col_sep(browser_t *b)         /* рамки кнопок/разделители */
{ return b->light ? fb_rgb(0xC4, 0xCB, 0xD4) : fb_rgb(0x2C, 0x31, 0x38); }
static u32 br_col_text(browser_t *b)        /* основной текст */
{ return b->light ? fb_rgb(0x1A, 0x20, 0x28) : wm_theme_text(); }
static u32 br_col_dim(browser_t *b)         /* приглушённый */
{ return b->light ? fb_rgb(0x62, 0x6C, 0x78) : wm_theme_text_dim(); }
static u32 br_col_info(browser_t *b)        /* статус-бар */
{ return b->light ? fb_rgb(0x27, 0x50, 0x8C) : wm_theme_text_info(); }
static u32 br_col_accent(browser_t *b)      /* ссылки/фокус */
{ return b->light ? fb_rgb(0x0B, 0x57, 0xD0) : wm_theme_accent(); }
static u32 br_col_head(browser_t *b)        /* 2x-заголовки */
{ return b->light ? fb_rgb(0x9A, 0x5B, 0x00) : fb_rgb(0xFF, 0xE0, 0x60); }
static u32 br_col_btn(browser_t *b)         /* кнопки (Go/Save/…) */
{ return b->light ? fb_rgb(0xE4, 0xE8, 0xEE) : wm_theme_sel_bg(); }
static u32 br_col_sel(browser_t *b)         /* подсветка выделения */
{ return b->light ? fb_rgb(0xC9, 0xDB, 0xF7) : wm_theme_sel_bg(); }
static u32 br_col_code_bg(browser_t *b)     /* плашка блока кода */
{ return b->light ? fb_rgb(0xE6, 0xE9, 0xEE) : fb_rgb(0x0E, 0x12, 0x18); }
static u32 br_col_code_border(browser_t *b) /* рамка блока кода */
{ return b->light ? fb_rgb(0xC4, 0xCB, 0xD4) : fb_rgb(0x2E, 0x3A, 0x48); }
static u32 br_col_code_text(browser_t *b)   /* текст кода */
{ return b->light ? fb_rgb(0x1F, 0x3A, 0x5C) : fb_rgb(0x9C, 0xDC, 0xFE); }

/* [BR-HEAD-2X]: длина визуального префикса заголовка (ведущие '#'
 * и пробелы за ними). При отрисовке 2x-заголовка префикс НЕ рисуется
 * (как в настоящих рендерах), при кликах колонка мыши сдвигается
 * на него (piece хранится как есть — srcoff-маппинг не ломается). */
static int br_head_prefix_len(const char *s)
{
    int n = 0;
    while (s[n] == '#') n++;
    if (n > 0 && s[n] == ' ') {
        n++;
        while (s[n] == ' ') n++;
    }
    return n;
}

/* Session 93 [BR-ERRLOG]: запись в кольцевый журнал ошибок окна
 * (сеть/JS/конвертация). Просмотр — Ctrl+E. */
static void br_err_log(browser_t *b, const char *fmt, ...)
{
    if (!b) return;
    /* в freestanding-ядре va_list нет — встроенный __builtin_va_list
     * (как в apps_mp3.c) */
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    char *slot = b->errlog[b->errlog_head];
    vsnprintf(slot, BR_ERRLOG_MAX, fmt, ap);
    __builtin_va_end(ap);
    slot[BR_ERRLOG_MAX - 1] = 0;
    b->errlog_tick[b->errlog_head] = timer_ticks();
    b->errlog_head = (b->errlog_head + 1) % BR_ERRLOG_N;
    if (b->errlog_n < BR_ERRLOG_N) b->errlog_n++;
}

static int ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* Поиск файла в RAM disk без учёта регистра.
 * Возвращает 1 и размер, если найден.
 * Task 66 [BR-RAMFS64]: раньше список ограничивался 64 записями — файлы
 * после 64-го «не находились». RAMFS_MAX_FILES = 256; стек задачи такой
 * массив не держит — статический буфер под спинлоком. */
static volatile int ramfs_lk_lock = 0;
static int ramfs_lookup(const char *name, u32 *out_size)
{
    static ramfs_dirent_t ents[RAMFS_MAX_FILES];
    int n, found = 0;
    s_lock(&ramfs_lk_lock);
    n = ramfs_list(ents, RAMFS_MAX_FILES);
    for (int i = 0; i < n; i++) {
        if (ci_same(ents[i].name, name)) {
            if (out_size) *out_size = ents[i].size;
            found = 1;
            break;
        }
    }
    s_unlock(&ramfs_lk_lock);
    return found;
}

/* ---------- загрузка контента и конвертация ---------- */

/* forward (сессия 55): циклы картинок/разметки */
static void br_layout_images(browser_t *b);
static void br_render_now(browser_t *b);
static void br_ensure_lines(browser_t *b, int cw);
/* Task 68 [BR-STREAM]: общий хвост загрузки страницы (тело ниже) */
static void br_apply_md(browser_t *b, const char *url, char *md, int md_len);
/* forward (Task 47): формы/JS/навигация */
static int  br_parse_host(char *host, u16 *port);
static void br_navigate_ex(browser_t *b, const char *addr, int redirs);
static void br_navigate(browser_t *b, const char *addr);
static void br_navigate_post(browser_t *b, const char *addr, const char *body);
static void br_navigate_post_ex(browser_t *b, const char *addr,
                                const char *body, u32 body_len,
                                const char *content_type);
static void br_form_layout(browser_t *b);
static void br_js_ensure(browser_t *b);
static void br_form_submit(browser_t *b, int form_idx);
static void br_page_refresh(browser_t *b);
/* Session 93: журнал ошибок, отложенные скрипты, ленивая конвертация */
static void br_err_log(browser_t *b, const char *fmt, ...);
static int  br_page_scripts_resume(browser_t *b);   /* 1 = увела навигацией */
static void br_lazy_convert(browser_t *b);
/* Task 62 [BR-UPLOAD]: multipart-отправка и filedlg */
static void br_filedlg_ok(void *ctx, const fd_pick_t *pick,
                          char *content, int len);
static void br_filedlg_cancel(void *ctx);
/* [BR-MP3]/Save: имена RAM disk (определения — в разделе сохранения) */
static void br_save_derive_stem(const char *url, char *out, int out_max);
static int  br_save_free_name_ext(const char *stem, const char *ext,
                                  char *out, int out_max);
/* Task 67 [BR-RELOAD]/[BR-FIND]: перезагрузка/домашняя/поиск — тела ниже
 * (после br_help_md) */
static void br_reload(browser_t *b);
static void br_go_home(browser_t *b);
static void br_find_next(browser_t *b, int from_row);
static void br_find_stop(browser_t *b);
static int  br_find_row_segs(const browser_t *b, int row,
                             int *out, int out_max);
/* Task 62 [BR-UPLOAD]: multipart-POST (см. br_navigate_post_ex) —
 * Task 67: состояние перенесено в browser_t (b->post_ct/b->post_len) */
/* Task 62 [BR-CURSOR]: курсор адресной строки (определения ниже) */
static int br_addr_clamp_cur(const browser_t *b, int cur);
static int br_addr_view_from(const browser_t *b, int max_chars);
/* Task 64 [TI-WIDGET]: синхронизация виджета адресной строки + фокус
 * полей форм (определения ниже) */
static void ti_sync(ti_t *ti);
static void br_focus_field(browser_t *b, int idx);
/* [BR-NAVCARET] (сессия 100): список интерактивных элементов страницы
 * (ссылки + контролы форм) для навигации стрелками — определения ниже */
static void br_nav_rebuild(browser_t *b);
static void br_nav_apply(browser_t *b, int i, int vis);
static int  br_nav_find_field(browser_t *b, int fidx);
/* [BR-SAVEHTML2] (сессия 100): перекачка исходника HTML при сохранении */
static char *br_refetch_html(browser_t *b, int *out_len);

/* Строки отображения под текущую ширину окна (перестройка только
 * при изменении ширины или нового контента). (cw - 16) / 8: текст
 * рисуется с x=4, полоса прокрутки занимает правый край cw-7..cw-2 —
 * резерв 16px держит текст ВНЕ полосы (раньше последний символ
 * наезжал на жёлоб на 2px). */
static void br_ensure_lines(browser_t *b, int cw)
{
    int maxc = (cw - 16) / 8;
    if (maxc < 8) maxc = 8;
    /* Session 93 [BR-WRAPCACHE]: кэш переноса — строки перестраиваются
     * ТОЛЬКО при смене ширины окна или нового контента (wrap_maxc=-1
     * сбрасывает br_apply_md_ex). Повторные вызовы на каждый кадр
     * отрисовки уходят в ранний return — brl_wrap дорог на длинных
     * страницах. wrap_time/wrap_gen — диагностика (сколько раз
     * перестраивали и когда в последний раз). */
    if (b->L.lines && b->wrap_maxc == maxc) return;
    brl_wrap(b->md, b->md_len, maxc, &b->L);
    b->wrap_maxc = maxc;
    b->wrap_time = timer_ticks();
    b->wrap_gen++;
    br_layout_images(b);
    br_form_layout(b);        /* Task 47: якоря полей -> строки отображения */
}

/* ---------- формы и JavaScript (Task 47) ---------- */

/* Поле по строке отображения (якорь \x03) или NULL. */
static brf_field_t *br_field_by_row(browser_t *b, int row)
{
    for (int i = 0; i < b->forms.nfields; i++)
        if (b->forms.fields[i].row == row)
            return &b->forms.fields[i];
    return NULL;
}

/* Якоря \x03 в md -> строки отображения: поле.row + класс строки. */
static void br_form_layout(browser_t *b)
{
    for (int k = 0; k < b->forms.nfields; k++)
        b->forms.fields[k].row = -1;
    for (int i = 0; i < b->L.nlines; i++) {
        const char *s = b->L.lines[i];
        if (s[0] != BRF_MARK || s[1] != 0) continue;
        b->L.cls[i] = BRL_CLS_FORM;
        int src = b->L.srcidx[i];
        for (int k = 0; k < b->forms.nfields; k++) {
            if (b->forms.fields[k].src_line == src) {
                b->forms.fields[k].row = i;
                break;
            }
        }
    }
}

/* Отрезать HTTP-заголовки от сырого ответа (возвращает тело и длину).
 * Task 47: вынесено для fetch()-колбэка JS.
 * FIX [HDR-LIMIT] (Task 65): скан конца заголовков ограничивался 2048
 * байтами. ya.ru отвечает на финальный 200 заголовками на 6215 байт
 * (Set-Cookie×6, CSP, Accept-CH...), github.com — 5690 байт: конец
 * заголовков НЕ находился, заголовки оставались в контенте, '<' в первых
 * 200 байтах не было -> is_html=0 -> браузер показывал СЫРОЙ ответ
 * (заголовки + исходник HTML) вместо страницы. Лимит поднят до 64 КиБ
 * (длина заголовков ограничена буфером ответа, линейный скан дешев). */
#define BR_HDR_SCAN_MAX 65536
static void br_strip_headers(const char *content, int len,
                             const char **out_body, int *out_len)
{
    if (len > 5 && !strncmp(content, "HTTP/", 5)) {
        int i = 0;
        while (i < len && i < BR_HDR_SCAN_MAX) {
            if (content[i] == '\n') {
                if (i + 2 < len && content[i + 1] == '\r' && content[i + 2] == '\n') {
                    content += i + 3;
                    len -= i + 3;
                    break;
                }
                if (i + 1 < len && content[i + 1] == '\n') {
                    content += i + 2;
                    len -= i + 2;
                    break;
                }
            }
            i++;
        }
    }
    *out_body = content;
    *out_len = len;
}

/* Колбэк fetch()/httpGet() из JS и загрузка <script src>.
 * Возвращает длину ТЕЛА или -1 (ошибка — в js.fetch_err). */
static int br_fetch_cb(void *ud, const char *url, char *out, int out_max)
{
    browser_t *b = (browser_t *)ud;
    char host[128];
    char path[380];  /* Task 66: было 256 — длинные пути script-src/fetch обрезались */
    char abs[380];   /* Task 66: было 300 (BRP_URL_MAX=300) */
    img_url_resolve(b->url, url, abs, (int)sizeof(abs));

    const char *p = abs;
    int use_tls = 0;
    /* Task 61: схема без учёта регистра ("HTTPS://..." в src/fetch) */
    if (br_ci_ncmp(p, "https://", 8) == 0) { p += 8; use_tls = 1; }
    else if (br_ci_ncmp(p, "http://", 7) == 0) p += 7;
    else {
        /* не http — попробуем как файл RAM disk */
        u32 fsize = 0;
        if (ramfs_lookup(p, &fsize) && fsize > 0 && fsize < BR_FILE_MAX) {
            char *buf = (char *)malloc(fsize);
            if (!buf) return -1;
            u32 got = ramfs_read(p, buf, fsize);
            int n = got < (u32)out_max ? (int)got : out_max;
            memcpy(out, buf, (u32)n);
            free(buf);
            return n;
        }
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "схема не http(s)");
        return -1;
    }
    int hi = 0;
    while (*p && *p != '/' && hi < 127) host[hi++] = *p++;
    host[hi] = 0;
    u16 port = use_tls ? 443 : 80;
    if (!br_parse_host(host, &port)) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "неверный порт");
        return -1;
    }
    if (!*p) p = "/";
    strncpy(path, p, sizeof(path) - 1);   /* Task 66: было захардкожено 255 */
    path[sizeof(path) - 1] = 0;
    /* Task 61 [BR-PCT]: путь script-src/fetch кодируем (пробел/кириллица
     * ломали request-line) — путь уже нормализован img_url_resolve */
    {
        char enc[512];
        int el = img_url_encode_path(path, enc, (int)sizeof(enc));
        if (el > 0 && el < (int)sizeof(path)) memcpy(path, enc, (u32)el + 1);
    }
    if (!host[0]) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "пустой хост");
        return -1;
    }

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "нет памяти");
        return -1;
    }
    int n = net_http_get(host, port, path, resp, BRJS_FETCH_MAX, 15000);
    if (n <= 0) {
        snprintf(b->js.fetch_err, sizeof(b->js.fetch_err), "%.40s",
                 net_http_errstr());
        free(resp);
        return -1;
    }
    const char *body;
    int blen;
    br_strip_headers(resp, n, &body, &blen);
    if (blen > out_max) blen = out_max;
    memcpy(out, body, (u32)blen);
    free(resp);
    return blen;
}

/* FIX [JS-NAV]/[META-REFRESH]: защита от бесконечных цепочек
 * редиректов из скриптов/meta-refresh (страница редиректит на саму
 * себя или по кругу): не более 8 вложенных переходов. HTTP-редиректы
 * (301/302) имеют отдельный лимит (redirs < 4) — не пересекаются.
 * Task 67 [BR-NAVT]: счётчик — ПОЛЕ browser_t (b->nav_chain), было
 * глобальной переменной: два окна браузера делили один счётчик (UB). */

/* JS-контекст страницы (создаётся лениво). */
static void br_js_ensure(browser_t *b)
{
    if (b->js.alive) return;
    if (brjs_start(&b->js, (const JSSTDLibraryDef *)mqjs_stdlib_def(),
                   mqjs_br_cfunc_base()) != 0) {
        snprintf(b->status, sizeof(b->status), "JS: нет памяти под контекст");
        return;
    }
    /* FIX [JS-NAV]: page_url и location.href — ПОСЛЕ brjs_start
     * (он делает memset окружения). Иначе href="" и ЛЮБОЙ скрипт
     * получал ложный «переход» на текущую страницу. */
    b->js.forms = &b->forms;
    brjs_set_page_url(&b->js, b->url);
    b->js.fetch_fn = br_fetch_cb;
    b->js.fetch_ud = b;
}

/* Вставить текст в md ПЕРЕД строкой src_line (строка-якорь \x04
 * сохраняется — см. [S100-DOCWRITE] в теле).
 * Новая md — свежий malloc (рост), старая освобождается. */
static void br_splice_at_line(browser_t *b, int src_line,
                              const char *ins, int ins_len)
{
    /* найти байтовое начало строки src_line */
    int pos = 0, line = 0;
    while (line < src_line && pos < b->md_len) {
        while (pos < b->md_len && b->md[pos] != '\n') pos++;
        if (pos >= b->md_len) break;
        pos++;
        line++;
    }
    /* [S100-DOCWRITE] (сессия 100, ФИКС «скрипт переписал страницу —
     * страница сломалась»): вставка идёт ПЕРЕД строкой-якорем \x04, и
     * САМ ЯКОРЬ СОХРАНЯЕТСЯ. Прежняя версия ЗАМЕНЯЛА якорь исполнивше-
     * гося скрипта выводом document.write: якорей в md становилось на
     * один меньше, порядковый brf_reindex назначал ПЕРВЫЙ оставшийся
     * якорь предыдущему (уже исполненному) скрипту, а src_line
     * последующих (отложенных) оставался устаревшим. При первом
     * взаимодействии их document.write вставлялся НЕ на место якоря,
     * а в ПРОИЗВОЛЬНУЮ строку выше — затирая контент (страница с
     * критичным document.write-скриптом + счётчиком ниже по коду).
     * Якорь теперь живёт до br_remove_script_anchors — соответствие
     * «якорь <-> скрипт» 1:1 на всех этапах. */
    int keep_from = pos;                 /* якорная строка и всё после */
    int pre_nl = 0;                      /* дописка в конец без '\n' */
    if (pos >= b->md_len && b->md_len > 0 &&
        b->md[b->md_len - 1] != '\n')
        pre_nl = 1;
    int post_nl = 0;                     /* якорь остаётся на своей строке */
    if (ins_len > 0 && keep_from < b->md_len && ins[ins_len - 1] != '\n')
        post_nl = 1;

    int new_len = pos + (int)pre_nl + ins_len + (int)post_nl
                + (b->md_len - keep_from);
    char *nb = (char *)malloc((u32)new_len + 1);
    if (!nb) return;
    memcpy(nb, b->md, (u32)pos);
    int o = pos;
    if (pre_nl) nb[o++] = '\n';
    if (ins_len > 0) memcpy(nb + o, ins, (u32)ins_len);
    o += ins_len;
    if (post_nl) nb[o++] = '\n';
    memcpy(nb + o, b->md + keep_from, (u32)(b->md_len - keep_from));
    o += b->md_len - keep_from;
    nb[o] = 0;
    if (b->md) free(b->md);
    b->md = nb;
    b->md_len = o;
}

/* Вырезать все якоря скриптов \x04 (после исполнения). */
static void br_remove_script_anchors(browser_t *b)
{
    int r = 0, w = 0;
    while (r < b->md_len) {
        int ls = r;
        while (r < b->md_len && b->md[r] != '\n') r++;
        int le = r;
        int had_nl = (r < b->md_len);
        if (had_nl) r++;
        if (le > ls && b->md[ls] == BRJ_MARK && le - ls == 1)
            continue;                            /* строка-якорь — долой */
        for (int q = ls; q < le; q++) b->md[w++] = b->md[q];
        if (had_nl) b->md[w++] = '\n';
    }
    b->md_len = w;
    if (b->md) b->md[w] = 0;
}

/* Число '\n' в буфере. Task 60: смещение точки вставки после splice
 * (вставка заканчивается '\n' — следующая пойдёт в пустой хвост). */
static int br_nl_count(const char *s, int len)
{
    int n = 0;
    for (int i = 0; i < len; i++)
        if (s[i] == '\n') n++;
    return n;
}

/* Task 60 [BR-DOCWRITE]: вывод document.write -> Markdown -> РАЗБОР
 * маркеров (brf_parse во ВРЕМЕННОЙ модели) -> splice -> исполнение
 * найденных скриптов (document.write-редиректоры работают!).
 *
 * Прежняя версия (канал утечки E из разбора Task 60):
 * html_to_md(wbuf) давал \x01-маркеры, splice вставлял их в md как
 * есть, после чего brf_reindex (без brf_parse!) ничего не удалял —
 * маркеры и JS-код РИСОВАЛИСЬ как текст, скрипты не исполнялись.
 * Теперь:
 *   1) html_to_md2 -> wmd (ёмкость BRJS_WBUF_MAX*2+8К, не 8 КиБ —
 *      FIX 1.6 из разбора);
 *   2) brf_parse(&tmp, wmd): SCRIPT-блоки собраны во временную модель,
 *      маркерные строки заменены якорями/удалены;
 *   3) якоря \x04 временной модели вычищаются из вставки (иначе
 *      смещают brf_reindex основной модели);
 *   4) splice; поля/формы/refresh усыновляются (brf_adopt);
 *   5) скрипты tmp исполняются по порядку (fetch src / eval), их
 *      собственный document.write — рекурсивно (глубина <= 2);
 *      на depth >= 2 — только чистка маркеров (brf_scrub). */
static void br_docwrite_emit(browser_t *b, int *line,
                             const char *html, int hlen, int depth);

/* Исполнить один скрипт (инлайн или внешний src). document.write
 * уходит в br_docwrite_emit с той же точкой вставки *line.
 * 1 = запрошен переход (nav_pending). */
static int br_script_exec(browser_t *b, brf_script_t *sc, int *line,
                          int depth)
{
    char *fetched = NULL;
    const char *code = sc->code;
    const char *nm = sc->src[0] ? "external" : "inline";

    if (sc->src[0]) {
        fetched = (char *)malloc(BRJS_FETCH_MAX + 1);
        if (fetched) {
            int n = br_fetch_cb(b, sc->src, fetched, BRJS_FETCH_MAX);
            if (n < 0) {
                snprintf(b->status, sizeof(b->status),
                         "script src: %.46s", b->js.fetch_err);
                br_err_log(b, "JS script src: %.60s", b->js.fetch_err);
                free(fetched);
                fetched = NULL;
            } else {
                fetched[n] = 0;
            }
        }
        code = fetched;
    }
    if (code && code[0]) {
        b->js.wlen = 0;
        b->js.wovf = 0;
        b->js.wbuf_static[0] = 0;
        int rc = brjs_eval(&b->js, code, nm);
        if (b->js.alert_n > 0) {
            snprintf(b->status, sizeof(b->status),
                     "JS alert: %s", b->js.alert);
        } else if (rc != 0) {
            /* Task 66 [BR-STATUS]: если страница обрезана сетью —
             * JS-ошибка почти наверняка следствие обрыва (усечённый код);
             * показываем ОБЕ причины, а не только последнюю */
            if (b->fetch_note[0])
                snprintf(b->status, sizeof(b->status), "%.46s | %s",
                         b->js.last_err, b->fetch_note);
            else
                snprintf(b->status, sizeof(b->status), "%.78s", b->js.last_err);
            br_err_log(b, "JS: %.70s", b->js.last_err);
        }
        /* document.write — на месте скрипта */
        if (b->js.wlen > 0)
            br_docwrite_emit(b, line, b->js.wbuf_static, b->js.wlen, depth);
    }
    /* [BR-REINDEX-ALWAYS]: реиндекс и для пустых/нескачавшихся скриптов
     * (fetch упал, code пуст) — src_line остальных скриптов обязан
     * отражать текущий md после вставок предыдущих document.write.
     * brf_reindex безопасен (только чтение md + запись src_line) и
     * линеен — дешевле, чем вставка не по адресу. */
    brf_reindex(&b->forms, b->md, b->md_len);
    if (fetched) free(fetched);
    return b->js.nav_pending ? 1 : 0;
}

static void br_docwrite_emit(browser_t *b, int *line,
                             const char *html, int hlen, int depth)
{
    /* FIX (1.6 из разбора): прежде wmd был malloc(BR_MD_MAX) = 8 КиБ —
     * Markdown от document.write резался при выходе уже с 4 КиБ HTML.
     * BRJS_WBUF_MAX (16 КиБ) HTML может дать ~2x Markdown. */
    int wcap = BRJS_WBUF_MAX * 2 + 8192;
    char *wmd;
    int wl;

    if (depth > 2) return;
    wmd = (char *)malloc((u32)wcap);
    if (!wmd) return;
    wl = html_to_md2(html, hlen, wmd, wcap, NULL);
    if (wl <= 0) {
        free(wmd);
        return;
    }
    /* гарантия хвостового '\n': следующая вставка придёт в пустую
     * строку после блока, а не заменит последнюю содержательную.
     * Task 66: при wl == wcap-1 ('\n' некуда) жертвуем последним
     * байтом — раньше следующий фрагмент приклеивался без разделителя. */
    if (wmd[wl - 1] != '\n') {
        if (wl < wcap - 1)
            wmd[wl++] = '\n';
        else
            wmd[wl - 1] = '\n';
    }

    if (depth < 2) {
        /* сильный вариант: разбор + исполнение найденных скриптов */
        brf_forms_t tmp;
        int i;

        memset(&tmp, 0, sizeof(tmp));
        wl = brf_parse(&tmp, wmd, wl);           /* маркеры -> якоря */
        wl = brf_strip_script_anchors(wmd, wl);  /* якоря tmp — долой */
        /* [BR-SCRUB-DOCW]: обрыв скрипта посреди document.write даёт
         * обрывок HTML в wbuf_static: brf_parse глотает незакрытый
         * \x01SCRIPT-блок, но \x01 в СЕРЕДИНЕ строк (passthrough
         * brf_parse его копирует как есть) остаётся и рисуется как
         * текст. Чистим перед splice — тот же проход, что на
         * глубине >= 2 ниже (Task 60 [BR-SCRUB]). */
        wl = brf_scrub(wmd, wl);

        br_splice_at_line(b, *line, wmd, wl);
        *line += br_nl_count(wmd, wl);
        free(wmd);
        wmd = NULL;

        brf_adopt(&b->forms, &tmp);
        brf_reindex(&b->forms, b->md, b->md_len);

        for (i = 0; i < tmp.nscripts; i++) {
            if (br_script_exec(b, &tmp.scripts[i], line, depth + 1))
                break;                           /* nav_pending */
        }
        brf_reset(&tmp);                         /* frees script codes */
        return;
    }

    /* глубина исчерпана: только чистка маркеров (без исполнения) */
    wl = brf_scrub(wmd, wl);
    br_splice_at_line(b, *line, wmd, wl);
    *line += br_nl_count(wmd, wl);
    free(wmd);
}

/* Исполнить сниппет (onclick / javascript:). document.write дописывается
 * В КОНЕЦ страницы (отличие от DOM: позиция скрипта известна только при
 * загрузке). 0 = ок. */
static int br_js_run_snippet(browser_t *b, const char *code)
{
    br_js_ensure(b);
    if (!b->js.alive) return -1;
    b->js.wlen = 0;
    b->js.wovf = 0;
    b->js.wbuf_static[0] = 0;
    int rc = brjs_eval(&b->js, code, "snippet");
    if (b->js.alert_n > 0) {
        snprintf(b->status, sizeof(b->status), "JS alert: %s", b->js.alert);
    } else if (rc != 0) {
        snprintf(b->status, sizeof(b->status), "%.78s", b->js.last_err);
    } else {
        snprintf(b->status, sizeof(b->status), "JS выполнен");
    }
    /* Task 60: document.write -> br_docwrite_emit (разбор маркеров +
     * исполнение найденных скриптов) вместо голого splice, который
     * рисовал \x01-маркеры как текст (канал утечки E) */
    /* Task 66 [BR-JSLINE]: безусловно в КОНЕЦ страницы. Раньше при
     * L.nlines==0 брался line=0 — br_splice_at_line заменял ПЕРВУЮ
     * строку md (потеря контента между загрузкой и первым draw). */
    int docw = 0;
    if (b->js.wlen > 0) {
        int line = 0x7FFFFFF;
        br_docwrite_emit(b, &line, b->js.wbuf_static, b->js.wlen, 0);
        brf_reindex(&b->forms, b->md, b->md_len);
        docw = 1;
    }
    /* FIX [JS-NAV]: onclick/javascript:-ссылки тоже умеют навигацию
     * (location.href=..., location.replace(...), document.location=...) */
    if (b->js.nav_pending) {
        char nu[BR_ADDR_MAX + 1];
        char abs[380];   /* Task 66: было 300 (BRP_URL_MAX=300) */
        strncpy(nu, b->js.nav_url, sizeof(nu) - 1);
        nu[sizeof(nu) - 1] = 0;
        b->js.nav_pending = 0;
        img_url_resolve(b->url, nu, abs, (int)sizeof(abs));
        if (b->nav_chain < 8) {
            b->nav_chain++;
            br_navigate(b, abs);
            b->nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        /* страница УЖЕ заменена навигацией: вызывающий (javascript:-ветка
         * br_navigate_full) не должен делать br_page_refresh над НОВОЙ
         * страницей (wlen здесь устаревший, а md новой страницы уже
         * разобран). rc != 0 гасит ветку document.write. */
        if (rc == 0)
            rc = 2;
    }
    /* [BR-SNIPPET-REFRESH] (сбой 6): document.write из сниппета
     * (onclick/javascript:) вставлен в md, но кэш переноса b->L НЕ
     * перестроен (br_ensure_lines уходит в ранний return при той же
     * ширине) — вставка НЕ ВИДНА до случайной перестройки. Раньше
     * refresh делала только javascript:-ветка br_navigate_full (а
     * onclick-кнопки — никогда); теперь сниппет самодостаточен.
     * При навигации (rc==2) страница УЖЕ заменена — refresh старой
     * md не нужен и вреден (двойной разбор). */
    if (docw && rc != 2)
        br_page_refresh(b);
    return rc;
}

/* Session 93 [BR-JSDEFER]: критичный ли скрипт — т.е. меняет содержимое
 * страницы ДО показа: document.write в коде. Внешние (src) код
 * неизвестен до загрузки — считаются откладываемыми (обычно это
 * счётчики/аналитика). */
static int br_ci_have(const char *hay, const char *needle);   /* ниже */
static int br_script_is_critical(const brf_script_t *sc)
{
    if (sc->src[0]) return 0;
    return sc->code && br_ci_have(sc->code, "document.write");
}

/* Исполнить скрипты страницы (по порядку); document.write разбирается
 * (brf_parse во временной модели) и вставляется на месте якоря,
 * найденные во вставке скрипты исполняются (br_docwrite_emit).
 * Внешние <script src> скачиваются br_fetch_cb.
 * FIX [JS-NAV]: возвращает 1, если скрипт запросил переход
 * (браузер уже ушёл на новый адрес — вызывающий код должен выйти).
 *
 * Session 93 [BR-JSDEFER]: НЕкритичные скрипты (счётчики, аналитика,
 * просто код) НЕ исполняются при загрузке — при первом взаимодействии
 * пользователя со страницей (br_page_scripts_resume). Критичные
 * (document.write) исполняются сразу, как прежде. Якоря \x04
 * отложенных остаются в md (не рисуются) до исполнения. */
static int br_page_scripts_run(browser_t *b)
{
    int nav = 0;
    if (b->forms.nscripts == 0) return 0;
    br_js_ensure(b);
    if (!b->js.alive) return 0;

    for (int i = 0; i < b->forms.nscripts; i++) {
        if (b->forms.scripts[i].done)
            continue;                     /* уже исполнен (безопасность) */
        if (!br_script_is_critical(&b->forms.scripts[i])) {
            b->js_deferred = 1;           /* подождёт взаимодействия */
            continue;
        }
        int line = b->forms.scripts[i].src_line;
        if (br_script_exec(b, &b->forms.scripts[i], &line, 0))
            nav = 1;
        b->forms.scripts[i].done = 1;
        /* FIX [JS-NAV]: скрипт запросил переход — оставшиеся скрипты
         * не исполняем (в браузерах навигация отменяет их) и уходим. */
        if (nav)
            break;
    }

    if (nav) {
        char nu[BR_ADDR_MAX + 1];
        char abs[380];   /* Task 66: было 300 (BRP_URL_MAX=300) */
        strncpy(nu, b->js.nav_url, sizeof(nu) - 1);
        nu[sizeof(nu) - 1] = 0;
        b->js.nav_pending = 0;
        img_url_resolve(b->url, nu, abs, (int)sizeof(abs));
        snprintf(b->status, sizeof(b->status), "JS redirect -> %.46s", abs);
        if (b->nav_chain < 8) {
            b->nav_chain++;
            br_navigate(b, abs);
            b->nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        return 1;
    }

    /* якоря снимаются только когда ОТЛОЖЕННЫХ не осталось — иначе
     * точка вставки document.write отложенного скрипта потеряна */
    if (!b->js_deferred)
        br_remove_script_anchors(b);
    brf_reindex(&b->forms, b->md, b->md_len);
    return 0;
}

/* Session 93 [BR-JSDEFER]: исполнить отложенные скрипты (первое
 * взаимодействие со страницей: клавиша/клик). Порядок исходный;
 * документ.write — на месте якоря (src_line реиндексируется после
 * каждого исполнения). */
static int br_page_scripts_resume(browser_t *b)
{
    if (!b->js_deferred) return 0;
    b->js_deferred = 0;
    if (b->forms.nscripts == 0) {
        br_remove_script_anchors(b);
        return 0;
    }
    br_js_ensure(b);
    if (!b->js.alive) return 0;

    int nav = 0;
    for (int i = 0; i < b->forms.nscripts && !nav; i++) {
        if (b->forms.scripts[i].done) continue;
        int line = b->forms.scripts[i].src_line;
        if (br_script_exec(b, &b->forms.scripts[i], &line, 0))
            nav = 1;
        b->forms.scripts[i].done = 1;
    }
    if (nav) {
        char nu[BR_ADDR_MAX + 1];
        char abs[380];
        strncpy(nu, b->js.nav_url, sizeof(nu) - 1);
        nu[sizeof(nu) - 1] = 0;
        b->js.nav_pending = 0;
        img_url_resolve(b->url, nu, abs, (int)sizeof(abs));
        snprintf(b->status, sizeof(b->status), "JS redirect -> %.46s", abs);
        if (b->nav_chain < 8) {
            b->nav_chain++;
            br_navigate(b, abs);
            b->nav_chain--;
        }
        return 1;                  /* страница заменена навигацией */
    }
    br_remove_script_anchors(b);
    brf_reindex(&b->forms, b->md, b->md_len);
    br_page_refresh(b);            /* вставки document.write — в строки */
    win_invalidate(b->win);
    return 0;
}

/* Активировать поле кликом/Enter/Space. */
static void br_filedlg_ok(void *ctx, const fd_pick_t *pick,
                          char *content, int len)
{
    browser_t *b = (browser_t *)ctx;
    b->file_dlg = 0;
    if (b->up_data) { free(b->up_data); b->up_data = NULL; }
    b->up_len = 0;
    b->up_fname[0] = 0;
    if (!pick || len <= 0) { win_invalidate(b->win); return; }
    /* имя без пути (для filename="...") */
    const char *nm = pick->name[0] ? pick->name : pick->path;
    {
        const char *s1 = strrchr(nm, '/');
        const char *s2 = strrchr(nm, '\\');
        if (s1 && s1[1]) nm = s1 + 1;
        if (s2 && s2[1]) nm = s2 + 1;
    }
    snprintf(b->up_fname, sizeof(b->up_fname), "%s", nm);
    b->up_data = content;        /* владение буфером (до 64К) */
    b->up_len = (u32)len;
    if (b->up_field >= 0 && b->up_field < b->forms.nfields) {
        brf_field_t *fl = &b->forms.fields[b->up_field];
        snprintf(fl->value, sizeof(fl->value), "%s", nm);   /* для отображения */
    }
    snprintf(b->status, sizeof(b->status), "Выбран файл: %.46s (%u байт)",
             b->up_fname, b->up_len);
    win_invalidate(b->win);
}

static void br_filedlg_cancel(void *ctx)
{
    browser_t *b = (browser_t *)ctx;
    b->file_dlg = 0;
    win_invalidate(b->win);
}

static void br_field_activate(browser_t *b, brf_field_t *fl)
{
    if (!strcmp(fl->type, "checkbox")) {
        fl->checked = !fl->checked;
    } else if (!strcmp(fl->type, "radio")) {
        /* Session 92 [BRF-RADIO]: выбор одной кнопки группы СНИМАЕТ
         * остальные (name внутри формы); повторный клик по выбранной
         * НЕ снимает её — как в настоящих браузерах */
        fl->checked = 1;
        if (fl->group >= 0) {
            for (int i = 0; i < b->forms.nfields; i++) {
                brf_field_t *g = &b->forms.fields[i];
                if (g != fl && g->group == fl->group &&
                    !strcmp(g->type, "radio"))
                    g->checked = 0;
            }
        }
    } else if (!strcmp(fl->type, "select")) {
        /* Session 92 [BR-DD]: клик по селекту — РАСКРЫТЬ список
         * (выбор — кликом по варианту или Up/Down+Enter) */
        int idx = (int)(fl - b->forms.fields);
        if (b->dd_open && b->dd_field == idx) {
            b->dd_open = 0;              /* повторный клик — свернуть */
        } else {
            b->dd_open = 1;
            b->dd_field = idx;
            b->dd_cur = fl->opt_sel >= 0 ? fl->opt_sel : 0;
        }
    } else if (!strcmp(fl->type, "file")) {
        /* Task 62 [BR-UPLOAD]: выбор файла — общий диалог ОС.
         * Читает RAM disk / HDD(FAT32) / USB(FAT32); содержимое до 64К
         * (лимит httpd) приходит в колбэк готовым. */
        /* индекс поля — для записи имени в value после выбора */
        b->up_field = (int)(fl - b->forms.fields);
        b->file_dlg = 1;
        filedlg_open("Выбор файла для загрузки", "*", NULL,
                     br_filedlg_ok, br_filedlg_cancel, b);
        return;
    } else if (!strcmp(fl->type, "submit") || !strcmp(fl->type, "reset")) {
        /* FIX [BR-JSBTN] (Task 65): <button> без type по HTML5 — "submit",
         * но onclick обязан выполниться ДО действия по умолчанию (как в
         * браузерах; отсутствие preventDefault в нашем движке компенсируем
         * отменой submit при запросе перехода). Раньше onclick кнопки
         * <button onclick="document.location='/x/'">Перейти</button>
         * молча пропускался — клик сразу слал форму/GET на текущий адрес. */
        if (fl->js[0]) {
            int rc = br_js_run_snippet(b, fl->js);
            if (rc == 2) {              /* скрипт запросил переход */
                win_invalidate(b->win);
                return;
            }
        }
        br_form_submit(b, fl->form);        /* reset ведёт себя как submit
                                             * (значения по умолчанию не
                                             * хранятся) */
        return;
    } else if (!strcmp(fl->type, "button")) {
        if (fl->js[0])
            br_js_run_snippet(b, fl->js);
        return;
    }
    win_invalidate(b->win);
}

/* Перестроить страницу после изменения md (document.write и пр.). */
static void br_page_refresh(browser_t *b)
{
    brl_free(&b->L);
    b->wrap_maxc = -1;
    b->dd_open = 0;        /* Session 92 [BR-DD]: строки сдвинулись */
    /* Task 60 [BR-SCRUB]: перед разбором вычистить \x01-маркеры,
     * прилетевшие со вставками (канал утечки F из разбора: splice
     * javascript:-сниппета не делал реиндекса, brp_analyze маркеры
     * игнорирует, brl_wrap рисует их как текст). */
    b->md_len = brf_scrub(b->md, b->md_len);
    /* [BR-REFRESH-REINDEX] (сбой 1, хрупкость 5): scrub может удалить
     * маркерные строки \x01 — нумерация строк md СДВИГАЕТСЯ, и src_line
     * полей/скриптов, проставленный вызывающим ДО refresh, протухает.
     * А br_ensure_lines ниже (br_form_layout) УЖЕ использует src_line
     * для раскладки якорей по строкам отображения. Реиндекс здесь —
     * после scrub, до разбора: линейный проход (дешевле вставки не по
     * адресу), идемпотентен — вызыватели с собственным reindex не
     * страдают. Раньше refresh полагался на вызывающего — хрупко. */
    brf_reindex(&b->forms, b->md, b->md_len);
    b->md_len = brp_analyze(&b->page, b->md, b->md_len);
    br_ensure_lines(b, win_content_w(b->win));
}

/* Отправить форму form_idx (-1 = поля вне форм: GET на текущий адрес). */
static void br_form_submit(browser_t *b, int form_idx)
{
    char body[1024];
    char action[300];
    char abs[380];   /* Task 66: было 300 (BRP_URL_MAX=300) */

    /* Task 62 [BR-UPLOAD]: форма с ВЫБРАННЫМ файлом в file-поле уходит
     * multipart/form-data (как в больших браузерах): текстовые поля —
     * обычными частями, файл — частью с filename= и Content-Type.
     * Тело собирается в куче (файл до 64К — стек не годится) и шлётся
     * net_http_post_len (порции по MSS с ожиданием ACK). */
    {
        int fidx = -1;
        for (int i = 0; i < b->forms.nfields; i++) {
            const brf_field_t *fl = &b->forms.fields[i];
            if (fl->form == form_idx && !strcmp(fl->type, "file") &&
                fl->value[0] && i == b->up_field && b->up_data) {
                fidx = i;
                break;
            }
        }
        if (fidx >= 0) {
            u32 cap = b->up_len + 2048 + 160u * (u32)b->forms.nfields;
            char *mp = (char *)malloc(cap);
            if (!mp) {
                snprintf(b->status, sizeof(b->status),
                         "Нет памяти под multipart (%u К)",
                         (unsigned)(cap / 1024));
                win_invalidate(b->win);
                return;
            }
            char bnd[32];
            snprintf(bnd, sizeof(bnd), "----N2600OS%u",
                     (unsigned)(timer_ticks() & 0xFFFFF));
            u32 o = 0;
            int room = 1;
            /* append с честной границей: не влезло — отказ */
            #define MP_ADD(p_, n_) do { \
                if ((u32)(n_) > cap - o) { room = 0; } \
                else { memcpy(mp + o, (p_), (u32)(n_)); o += (u32)(n_); } \
            } while (0)
            #define MP_ADDS(s_) MP_ADD((s_), strlen(s_))
            for (int i = 0; i < b->forms.nfields && room; i++) {
                const brf_field_t *fl = &b->forms.fields[i];
                if (fl->form != form_idx || !fl->name[0]) continue;
                if (!strcmp(fl->type, "submit") ||
                    !strcmp(fl->type, "button") ||
                    !strcmp(fl->type, "reset")) continue;
                char hd[192];
                if (!strcmp(fl->type, "file") && i == b->up_field &&
                    b->up_data) {
                    snprintf(hd, sizeof(hd),
                             "--%s\r\nContent-Disposition: form-data; "
                             "name=\"%s\"; filename=\"%s\"\r\n"
                             "Content-Type: application/octet-stream\r\n\r\n",
                             bnd, fl->name, b->up_fname);
                    MP_ADDS(hd);
                    if (b->up_len) MP_ADD(b->up_data, b->up_len);
                    if (room) MP_ADDS("\r\n");
                } else {
                    const char *val = fl->value;
                    if (!strcmp(fl->type, "checkbox") ||
                        !strcmp(fl->type, "radio")) {
                        if (!fl->checked) continue;
                        val = fl->value[0] ? fl->value : "on";
                    } else if (!strcmp(fl->type, "select")) {
                        if (fl->opt_sel < 0 || fl->opt_sel >= fl->nopts)
                            continue;
                        val = fl->opts[fl->opt_sel];
                    } else if (!strcmp(fl->type, "file")) {
                        continue;   /* file-поле без выбранного файла */
                    }
                    snprintf(hd, sizeof(hd),
                             "--%s\r\nContent-Disposition: form-data; "
                             "name=\"%s\"\r\n\r\n", bnd, fl->name);
                    MP_ADDS(hd);
                    if (room) MP_ADDS(val);
                    if (room) MP_ADDS("\r\n");
                }
            }
            if (room) {
                char tail[48];
                snprintf(tail, sizeof(tail), "--%s--\r\n", bnd);
                MP_ADDS(tail);
            }
            #undef MP_ADD
            #undef MP_ADDS
            if (!room) {
                free(mp);
                snprintf(b->status, sizeof(b->status),
                         "multipart: не хватило буфера");
                win_invalidate(b->win);
                return;
            }
            /* resolve action как в обычной ветке */
            const brf_form_t *fo = NULL;
            if (form_idx >= 0 && form_idx < b->forms.nforms &&
                b->forms.forms[form_idx].used)
                fo = &b->forms.forms[form_idx];
            if (fo && fo->action[0])
                strncpy(action, fo->action, sizeof(action) - 1);
            else
                strncpy(action, b->url, sizeof(action) - 1);
            action[sizeof(action) - 1] = 0;
            img_url_resolve(b->url, action, abs, (int)sizeof(abs));
            char ct[64];
            snprintf(ct, sizeof(ct), "multipart/form-data; boundary=%s", bnd);
            snprintf(b->status, sizeof(b->status),
                     "Загрузка файла (%u байт)...", (unsigned)b->up_len);
            win_invalidate(b->win);
            br_navigate_post_ex(b, abs, mp, o, ct);
            free(mp);
            /* файл отправлен — освободить содержимое (имя остаётся) */
            if (b->up_data) { free(b->up_data); b->up_data = NULL; }
            b->up_len = 0;
            return;
        }
    }

    if (!brf_serialize(&b->forms, form_idx, body, (int)sizeof(body))) {
        snprintf(b->status, sizeof(b->status), "Форма: слишком длинное тело");
        win_invalidate(b->win);
        return;
    }
    /* Task 62: в форме есть file-поле с именем, но содержимое уже
     * отправлено/не выбрано — честная подсказка вместо 400 сервера */
    for (int i = 0; i < b->forms.nfields; i++) {
        const brf_field_t *fl = &b->forms.fields[i];
        if (fl->form == form_idx && !strcmp(fl->type, "file") && fl->value[0]) {
            snprintf(b->status, sizeof(b->status),
                     "Файл '%.30s' не прикреплён — выберите заново", fl->value);
            win_invalidate(b->win);
            return;
        }
    }

    const brf_form_t *fo = NULL;
    if (form_idx >= 0 && form_idx < b->forms.nforms &&
        b->forms.forms[form_idx].used)
        fo = &b->forms.forms[form_idx];

    if (fo && fo->action[0])
        strncpy(action, fo->action, sizeof(action) - 1);
    else
        strncpy(action, b->url, sizeof(action) - 1);
    action[sizeof(action) - 1] = 0;

    int is_post = (fo && !strcmp(fo->method, "post"));
    img_url_resolve(b->url, action, abs, (int)sizeof(abs));

    if (!is_post) {
        char target[BR_ADDR_MAX + 1];
        if (body[0]) {
            char sep = strchr(abs, '?') ? '&' : '?';
            snprintf(target, sizeof(target), "%s%c%s", abs, sep, body);
        } else {
            snprintf(target, sizeof(target), "%s", abs);
        }
        snprintf(b->status, sizeof(b->status), "Отправка формы (GET)...");
        br_navigate(b, target);
    } else {
        snprintf(b->status, sizeof(b->status), "Отправка формы (POST)...");
        br_navigate_post(b, abs, body);
    }
}

/* ---------- картинки страницы (сессия 55) ---------- */

/* ---------- Session 92 [HC-ENC]: кодировки страниц ---------- */

/* Значение charset= из Content-Type (или 0, если нет). */
static int br_ct_charset(const char *ct, char *out, int out_max)
{
    if (!ct) return 0;
    for (const char *p = ct; *p; p++) {
        if ((p[0] | 0x20) == 'c' && (p[1] | 0x20) == 'h' &&
            (p[2] | 0x20) == 'a' && (p[3] | 0x20) == 'r' &&
            (p[4] | 0x20) == 's' && (p[5] | 0x20) == 'e' &&
            (p[6] | 0x20) == 't' && p[7] == '=') {
            p += 8;
            if (*p == '"') p++;
            int n = 0;
            while (*p && *p != '"' && *p != ';' && *p != ' ' &&
                   *p != '>' && n < out_max - 1)
                out[n++] = *p++;
            out[n] = 0;
            return n;
        }
    }
    return 0;
}

/* Имя — utf-8 (перекодировка не нужна)? */
static int br_cs_is_utf8(const char *cs)
{
    char b[16];
    int k = 0;
    if (!cs || !cs[0]) return 1;
    for (; cs[k] && k < 15; k++) {
        char c = cs[k];
        if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
        if (c == '-' || c == '_') c = ' ';
        b[k] = c;
    }
    b[k] = 0;
    return !strcmp(b, "utf8") || !strcmp(b, "utf 8");
}

/* [HC-ENC-SOFT] (Google): «мягкая» однобайтовая кодировка заголовка
 * (iso-8859-1/latin1/windows-1252/cp1252/ansi). Настольные браузеры
 * позволяют meta-charset HTML переопределить её: Google отдаёт
 * неизвестным UA charset=ISO-8859-1 при UTF-8-теле (в заголовке для
 * Chrome — UTF-8; сравнение curl'ом). Жёсткое доверие такому заголовку
 * перекодировало UTF-8 как CP1252 — mojibake (сломанная кодировка) на
 * google.com и других CDN, пренебрегающих точностью заголовка. */
static int br_cs_is_soft_latin(const char *cs)
{
    char b[16];
    int k = 0;
    if (!cs || !cs[0]) return 0;
    for (; cs[k] && k < 15; k++) {
        char c = cs[k];
        if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
        if (c == '-' || c == '_') c = ' ';
        b[k] = c;
    }
    b[k] = 0;
    return !strcmp(b, "iso 8859 1") || !strcmp(b, "iso8859 1") ||
           !strcmp(b, "latin1")   || !strcmp(b, "windows 1252") ||
           !strcmp(b, "cp1252")   || !strcmp(b, "cp 1252") ||
           !strcmp(b, "1252")     || !strcmp(b, "ansi");
}

/* meta-charset в первых байтах HTML (<meta charset="X"> или
 * http-equiv/content). Возвращает 1 и имя в out (или 0). */
static int br_sniff_charset(const char *d, int len, char *out, int out_max)
{
    if (!d || len < 8) return 0;
    for (int i = 0; i + 8 <= len; i++) {
        if ((d[i] | 0x20) == 'c' && (d[i + 1] | 0x20) == 'h' &&
            (d[i + 2] | 0x20) == 'a' && (d[i + 3] | 0x20) == 'r' &&
            (d[i + 4] | 0x20) == 's' && (d[i + 5] | 0x20) == 'e' &&
            (d[i + 6] | 0x20) == 't' && d[i + 7] == '=') {
            const char *p = d + i + 8;
            int n = 0;
            while (p < d + len && (*p == ' ' || *p == '\t' || *p == '"' ||
                   *p == '\'')) p++;
            while (p < d + len && *p != '"' && *p != '\'' && *p != ';' &&
                   *p != '>' && *p != ' ' && *p != '/' && n < out_max - 1)
                out[n++] = *p++;
            out[n] = 0;
            return n > 0;
        }
    }
    return 0;
}

/* ---------- Session 92 [BR-IMGCACHE]: кэш картинок F5 ---------- */

/* Спасти готовые картинки уходящей страницы (до brp_reset). Записи
 * прошлого спасения освобождаются — у каждой один шанс пригодиться. */
static void br_img_cache_stash(browser_t *b)
{
    int stashed = 0;
    for (int i = 0; i < BR_IMG_CACHE_N; i++) {
        if (b->img_cache[i].rgba) {
            free(b->img_cache[i].rgba);
            b->img_cache[i].rgba = NULL;
        }
        b->img_cache[i].hash = 0;
    }
    for (int i = 0; i < b->page.nimgs && stashed < BR_IMG_CACHE_N; i++) {
        brp_img_t *im = &b->page.imgs[i];
        if (im->state != 1 || !im->rgba || !im->url_hash)
            continue;
        int slot = -1;
        for (int k = 0; k < BR_IMG_CACHE_N; k++)
            if (!b->img_cache[k].rgba) { slot = k; break; }
        if (slot < 0) break;
        b->img_cache[slot].hash = im->url_hash;
        b->img_cache[slot].w = im->w;
        b->img_cache[slot].h = im->h;
        b->img_cache[slot].dw = im->dw;
        b->img_cache[slot].dh = im->dh;
        b->img_cache[slot].rgba = im->rgba;   /* владение — кэшу */
        im->rgba = NULL;                       /* brp_reset не освободит */
        stashed++;
    }
}

/* Приложить спасённые картинки к новой странице (после brp_analyze). */
static void br_img_cache_restore(browser_t *b)
{
    for (int i = 0; i < b->page.nimgs; i++) {
        brp_img_t *im = &b->page.imgs[i];
        if (im->state != 0 || !im->url_hash || !im->url[0])
            continue;
        for (int k = 0; k < BR_IMG_CACHE_N; k++) {
            if (b->img_cache[k].rgba && b->img_cache[k].hash == im->url_hash) {
                im->rgba = b->img_cache[k].rgba;
                im->w = b->img_cache[k].w;
                im->h = b->img_cache[k].h;
                im->dw = b->img_cache[k].dw;
                im->dh = b->img_cache[k].dh;
                im->state = 1;
                b->img_cache[k].rgba = NULL;
                b->img_cache[k].hash = 0;
                b->img_ok++;
                b->img_used += (u32)im->dw * (u32)im->dh * 4u;
                break;
            }
        }
    }
}

/* ---------- Session 92 [BR-DD]: геометрия раскрытого select ---------- */

/* Максимум видимых вариантов; *dy_out — y первого варианта. 0 = скрыт. */
static int br_dd_geom(const browser_t *b, int ch, int *dy_out)
{
    if (!b->dd_open || b->dd_field < 0 || b->dd_field >= b->forms.nfields)
        return 0;
    const brf_field_t *fl = &b->forms.fields[b->dd_field];
    if (fl->nopts <= 0 || fl->row < 0 || fl->row < b->scroll - 1)
        return 0;
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - BR_STATUS_H;
    int dy = area_y + 2 + (fl->row + 1 - b->scroll) * 16;
    if (dy < area_y + 16) return 0;
    int maxvis = (area_y + area_h - dy) / 16;
    if (maxvis > 8) maxvis = 8;
    if (maxvis > fl->nopts) maxvis = fl->nopts;
    if (maxvis < 1) return 0;
    if (dy_out) *dy_out = dy;
    return maxvis;
}

static brp_img_t *br_img_by_src(browser_t *b, int src_idx)
{
    for (int i = 0; i < b->page.nimgs; i++)
        if (b->page.imgs[i].src_idx == src_idx)
            return &b->page.imgs[i];
    return NULL;
}

/* Резерв строк под картинки в списке отображения: якорные строки
 * (BRP_IMG_MARK) получают высоту готовой картинки (в строках по 16px);
 * после якоря вставляются пустые строки BRL_CLS_IMG. */
static void br_layout_images(browser_t *b)
{
    for (int i = 0; i < b->L.nlines; i++) {
        const char *s = b->L.lines[i];
        if (s[0] != BRP_IMG_MARK || s[1] != 0) continue;
        brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
        b->L.cls[i] = BRL_CLS_IMG;
        if (im) {
            int rows = (im->dh + 15) / 16;
            if (rows < 1) rows = 1;
            if (im->state != 1) rows = 1;   /* не готова: строка-заглушка */
            im->row = i;
            im->rows = rows;
            if (rows > 1)
                brl_insert_blanks(&b->L, i + 1, rows - 1, b->L.srcidx[i]);
        }
    }
}

/* ---------- Task 68 [BR-BGIMG]: фоновая загрузка картинок ---------- */

/* Канал окно <-> воркер — ОТДЕЛЬНАЯ куча-структура: воркер вообще не
 * трогает browser_t (окно может закрыться/сменить страницу в любой
 * момент; результаты мимо поколения img_gen отбрасывает ОКНО).
 * Ссылки: refs = 1 (окно) + 1 (живой воркер); последний освобождает. */
#define ICHAN_URL_MAX 320
typedef struct br_ichan {
    volatile int lock;
    volatile int refs;            /* 1 = окно; +1 = воркер запущен */
    volatile int quit;            /* окно закрывается */
    volatile int started;         /* воркер создан */
    volatile int job_pending;     /* окно выдало работу */
    volatile int in_flight;       /* воркер грузит/декодирует */
    volatile int result_ready;    /* результат ждёт применения */
    /* работа (пишет окно под замком, читает воркер под замком) */
    int  job_idx, job_gen, job_maxw, job_maxh;
    char job_url[ICHAN_URL_MAX];
    char job_base[256];
    /* результат (пишет воркер под замком, читает окно под замком) */
    int  res_idx, res_gen, res_state;
    int  res_w, res_h, res_dw, res_dh;
    u8  *res_rgba;
} br_ichan_t;

/* calloc в ядре нет (mem.h даёт только malloc/free) — нулевой блок. */
static void *br_zalloc(u32 n)
{
    void *p = malloc(n);
    if (p) memset(p, 0, n);
    return p;
}

static void br_ichan_new(browser_t *b)
{
    b->ichan = (br_ichan_t *)br_zalloc(sizeof(br_ichan_t));
    if (b->ichan) b->ichan->refs = 1;      /* ссылка окна */
}

/* Страница сменилась: снять невыданную работу, сбросить счётчики
 * (результаты в полёте отбросит pump по img_gen). */
static void br_img_page_changed(browser_t *b)
{
    b->img_gen++;
    b->img_ok = 0;
    b->img_fail = 0;
    b->img_used = 0;
    if (b->ichan) {
        s_lock(&b->ichan->lock);
        b->ichan->job_pending = 0;
        s_unlock(&b->ichan->lock);
    }
}

/* Воркер: одна картинка за раз (сеть всё равно одна транзакция);
 * НЕ касается browser_t — только канала. */
static void br_img_worker(void *arg)
{
    br_ichan_t *ch = (br_ichan_t *)arg;
    for (;;) {
        int has = 0;
        int idx = 0, gen = 0, mw = 0, mh = 0;
        char url[ICHAN_URL_MAX], base[256];

        s_lock(&ch->lock);
        if (ch->quit) { s_unlock(&ch->lock); break; }
        if (ch->job_pending) {
            ch->job_pending = 0;
            ch->in_flight = 1;
            idx = ch->job_idx;
            gen = ch->job_gen;
            mw  = ch->job_maxw;
            mh  = ch->job_maxh;
            memcpy(url, ch->job_url, sizeof(url));
            memcpy(base, ch->job_base, sizeof(base));
            has = 1;
        }
        s_unlock(&ch->lock);

        if (!has) {
            task_msleep(20);               /* ждём работу */
            continue;
        }

        /* сеть + декодирование — БЕЗ замка (долго) */
        img_t t, sc;
        int st = -1, w = 0, h = 0, dw = 0, dh = 0;
        u8 *rgba = NULL;
        if (img_decode_url(url, base[0] ? base : NULL, &t) == 0) {
            w = t.w;
            h = t.h;
            int dw2 = t.w, dh2 = t.h;
            if (dw2 > mw) {
                dh2 = t.h * mw / t.w;
                dw2 = mw;
                if (dh2 < 1) dh2 = 1;
            }
            if (dh2 > mh) {
                dw2 = dw2 * mh / dh2;
                dh2 = mh;
                if (dw2 < 1) dw2 = 1;
            }
            if (img_scale(&t, dw2, dh2, &sc) == 0) {
                rgba = sc.rgba;
                dw = sc.w;
                dh = sc.h;
                st = 1;
            }
            img_dispose(&t);               /* оригинал больше не нужен */
        }

        s_lock(&ch->lock);
        ch->in_flight = 0;
        /* окно забирает результаты на своём тике/отрисовке; если не
         * успело — подождём (защита от перезаписи, в жизни не бывает:
         * pump выдаёт работу только после apply) */
        while (ch->result_ready && !ch->quit) {
            s_unlock(&ch->lock);
            task_msleep(10);
            s_lock(&ch->lock);
        }
        if (ch->quit) {
            s_unlock(&ch->lock);
            if (rgba) free(rgba);
            break;
        }
        ch->res_idx = idx;
        ch->res_gen = gen;
        ch->res_state = st;
        ch->res_w = w;
        ch->res_h = h;
        ch->res_dw = dw;
        ch->res_dh = dh;
        ch->res_rgba = rgba;
        ch->result_ready = 1;
        s_unlock(&ch->lock);
        /* окно разбудит тик/отрисовка — пинать окно из воркера нельзя
         * (указатель window_t мог умереть вместе с browser_t) */
    }

    /* выход: снять ссылку воркера; последний — освобождает канал */
    s_lock(&ch->lock);
    ch->refs--;
    int last = (ch->refs == 0);
    s_unlock(&ch->lock);
    if (last) free(ch);
    task_exit();
}

/* Ленивый запуск воркера (первая страница с картинками). */
static void br_img_ensure_thread(browser_t *b)
{
    br_ichan_t *ch = b->ichan;
    if (!ch) return;
    s_lock(&ch->lock);
    if (ch->started || ch->quit) {
        s_unlock(&ch->lock);
        return;
    }
    ch->started = 1;
    ch->refs++;                            /* ссылка воркера */
    s_unlock(&ch->lock);
    if (task_spawn("br-img", br_img_worker, ch) < 0) {
        /* не родился: вернуть ссылку, больше не пробуем */
        s_lock(&ch->lock);
        ch->refs--;
        ch->started = 0;
        s_unlock(&ch->lock);
    }
}

/* Насос картинок: применить готовый результат + выдать следующую
 * работу. ВЫЗЫВАЕТСЯ ИЗ ПОТОКА ОКНА (br_draw / br_tick) — сеть и
 * декодирование живут в воркере, окно остаётся отзывчивым. */
static void br_img_pump(browser_t *b)
{
    br_ichan_t *ch = b->ichan;
    if (!ch || !b->win) return;

    /* Session 94 [BR-IMGPRIO]: видимый диапазон строк — общий и для
     * приоритета выдачи, и для защиты от вытеснения (ниже).
     * Картинка считается видимой, если её полоса [row .. row+rows-1]
     * пересекается с окном прокрутки. */
    int vis_rows = (win_content_h(b->win) - BR_HDR - BR_STATUS_H) / 16;
    if (vis_rows < 4) vis_rows = 4;
    int sc0 = b->scroll, sc1 = b->scroll + vis_rows;
#define IMG_VISIBLE(im) ((im)->row + (im)->rows > sc0 && (im)->row <= sc1)

    /* --- применить готовый результат (если есть) --- */
    int has = 0;
    int r_idx = 0, r_gen = 0, r_state = 0;
    int r_w = 0, r_h = 0, r_dw = 0, r_dh = 0;
    u8 *r_rgba = NULL;
    int idle = 0;
    s_lock(&ch->lock);
    has = ch->result_ready;
    if (has) {
        r_idx = ch->res_idx;  r_gen = ch->res_gen;
        r_state = ch->res_state;
        r_w = ch->res_w;  r_h = ch->res_h;
        r_dw = ch->res_dw;  r_dh = ch->res_dh;
        r_rgba = ch->res_rgba;
        ch->res_rgba = NULL;
        ch->result_ready = 0;
    }
    idle = !ch->job_pending && !ch->in_flight && !ch->result_ready && !ch->quit;
    s_unlock(&ch->lock);

    int changed = 0;
    if (has) {
        if (r_gen == b->img_gen && r_idx < b->page.nimgs) {
            brp_img_t *im = &b->page.imgs[r_idx];
            if (im->state == 0) {
                if (r_state == 1 && r_rgba) {
                    im->w = r_w;
                    im->h = r_h;
                    im->rgba = r_rgba;
                    im->dw = r_dw;
                    im->dh = r_dh;
                    im->state = 1;
                    b->img_ok++;
                    b->img_used += (u32)r_dw * (u32)r_dh * 4u;
                    /* бюджет: вытесняем готовые (state=0 — строка-
                     * заглушка; noauto=1 — не перезагружать).
                     * [BR-IMGPRIO] сначала НЕВИДИМЫЕ — экран не должен
                     * пустеть: вытесненная (noauto) сама не перезагрузится.
                     * Если невидимых нет — как прежде, самую раннюю. */
                    while (b->img_used > BR_IMG_BUDGET) {
                        brp_img_t *ev = NULL;
                        for (int k = 0; k < b->page.nimgs; k++) {
                            brp_img_t *c = &b->page.imgs[k];
                            if (c->state == 1 && c->rgba &&
                                !IMG_VISIBLE(c)) {
                                ev = c;
                                break;
                            }
                        }
                        if (!ev) {
                            for (int k = 0; k < b->page.nimgs; k++) {
                                if (b->page.imgs[k].state == 1 &&
                                    b->page.imgs[k].rgba) {
                                    ev = &b->page.imgs[k];
                                    break;
                                }
                            }
                        }
                        if (!ev) break;
                        b->img_used -= (u32)ev->dw * (u32)ev->dh * 4u;
                        free(ev->rgba);
                        ev->rgba = NULL;
                        ev->state = 0;
                        ev->dw = ev->dh = 0;
                        ev->noauto = 1;
                        b->img_ok--;
                    }
                } else {
                    if (r_rgba) free(r_rgba);
                    im->state = -1;
                    b->img_fail++;
                }
                changed = 1;
            } else {
                if (r_rgba) free(r_rgba);   /* уже не ждёт — мимо */
            }
        } else {
            if (r_rgba) free(r_rgba);       /* страница сменилась — мимо */
        }
        snprintf(b->status, sizeof(b->status),
                 "Картинки: %d готово, %d недоступно%s",
                 b->img_ok, b->img_fail,
                 idle ? "" : " (грузятся...)");
        /* Session 92 [BR-IMGPROG]: прогресс полосой — «Картинки: 3/5
         * (█████░░░░░ 50%)» — видно объем и темп, не только счетчик */
        if (b->page.nimgs > 0 && !idle) {
            int total = b->page.nimgs;
            int done = b->img_ok + b->img_fail;
            char bar[36];
            int fill = done * 10 / total;
            int k = 0;
            for (int j = 0; j < 10; j++) {
                const char *cell = (j < fill) ? "\xe2\x96\x88"   /* █ */
                                              : "\xe2\x96\x91";  /* ░ */
                bar[k++] = cell[0]; bar[k++] = cell[1]; bar[k++] = cell[2];
            }
            bar[k] = 0;
            snprintf(b->status, sizeof(b->status),
                     "Картинки: %d/%d (%s %d%%)",
                     done, total, bar, done * 100 / total);
        }
    }

    /* --- выдать следующую работу ---
     * [BR-IMGPRIO] два прохода: сначала картинки, чья полоса пересекается
     * с экраном (по порядку документа), потом невидимые. Воркер один
     * (одна сеть), но приоритет гарантирует: зависшая/медленная картинка
     * за пределами экрана не задерживает видимые. Ошибочная (state=-1)
     * из очереди выпадает и соседей не блокирует вовсе. */
    if (idle && b->page.nimgs > 0) {
        int mw = win_content_w(b->win) - 16;
        if (mw < 64) mw = 64;
        int mh = (win_content_h(b->win) * 6) / 10;
        if (mh < 120) mh = 120;
        int pick = -1;
        for (int i = 0; i < b->page.nimgs && pick < 0; i++) {
            brp_img_t *im = &b->page.imgs[i];
            if (im->state != 0 || im->noauto || !im->url[0]) continue;
            if (IMG_VISIBLE(im)) pick = i;
        }
        for (int i = 0; i < b->page.nimgs && pick < 0; i++) {
            brp_img_t *im = &b->page.imgs[i];
            if (im->state != 0 || im->noauto || !im->url[0]) continue;
            pick = i;
        }
        if (pick >= 0) {
            brp_img_t *im = &b->page.imgs[pick];
            s_lock(&ch->lock);
            if (!ch->job_pending && !ch->in_flight && !ch->quit) {
                ch->job_idx = pick;
                ch->job_gen = b->img_gen;
                ch->job_maxw = mw;
                ch->job_maxh = mh;
                strncpy(ch->job_url, im->url, ICHAN_URL_MAX - 1);
                ch->job_url[ICHAN_URL_MAX - 1] = 0;
                strncpy(ch->job_base, b->url, sizeof(ch->job_base) - 1);
                ch->job_base[sizeof(ch->job_base) - 1] = 0;
                ch->job_pending = 1;
            }
            s_unlock(&ch->lock);
        }
    }
#undef IMG_VISIBLE
    br_img_ensure_thread(b);

    /* --- пересобрать строки под новые высоты картинок --- */
    if (changed) {
        /* НЕ трогаем scroll: пользователь читает, картинки догружаются */
        brl_free(&b->L);
        b->wrap_maxc = -1;
        br_ensure_lines(b, win_content_w(b->win));
        win_invalidate(b->win);
    }
}

/* Закрытие окна: канал переживает нас (воркер может быть в полёте) —
 * окно снимает ссылку; последний владелец освобождает. */
static void br_ichan_release(browser_t *b)
{
    br_ichan_t *ch = b->ichan;
    if (!ch) return;
    b->ichan = NULL;
    s_lock(&ch->lock);
    ch->quit = 1;
    ch->job_pending = 0;
    ch->refs--;                            /* ссылка окна */
    int last = (ch->refs == 0);
    s_unlock(&ch->lock);
    if (last) free(ch);                    /* воркер не запускался */
}

static void browser_load_content(browser_t *b, const char *url,
                                  const char *content, int len)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->fetching = 0;
    b->sel_active = 0;     /* новая страница — старое выделение не имеет смысла */
    b->sel_drag = 0;

    /* Task 66 [BR-STATUS]: заметка о сетевом обрезе для статуса —
     * собирается здесь (все пути загрузки проходят через эту функцию);
     * JS-ошибки её больше не затирают (см. br_script_exec) */
    b->fetch_note[0] = 0;
    if (b->fetch_trunc) {
        if (b->fetch_total)
            snprintf(b->fetch_note, sizeof(b->fetch_note),
                     "получено %d из %u", len, (unsigned)b->fetch_total);
        else
            snprintf(b->fetch_note, sizeof(b->fetch_note),
                     "обрезано (лимит %d)", (int)BR_FETCH_MAX);
    }

    /* сессия 55: пиксельные буферы прошлой страницы больше не нужны */
    brp_reset(&b->page);
    b->hover[0] = 0;
    /* Task 67 [BR-FIND]: новая страница — старый запрос не имеет смысла */
    b->find_q[0] = 0;
    b->find_mode = 0;
    b->find_total = 0;

    /* FIX [N5]/[HDR-LIMIT] (Task 65): сырой ответ содержит ЗАГОЛОВКИ;
     * раньше скан конца заголовков останавливался на 2048 байтах —
     * ya.ru/github (заголовки 6215/5690 байт) показывались как СЫРОЙ
     * текст (заголовки + HTML).
     * Task 67 [BR-HDR1]: inline-цикл заменён вызовом br_strip_headers
     * (тот же алгоритм, одна копия кода). */
    br_strip_headers(content, len, &content, &len);

    /* Это HTML или уже Markdown? */
    int is_html = 0;
    for (int i = 0; i < len && i < 200; i++) {
        if (content[i] == '<') { is_html = 1; break; }
    }

    /* Task 51 [BR-SAVE]: храним ИСХОДНИК HTML-страницы (тело после
     * отрезки заголовков, до конвертации). «Save» пишет его как есть:
     * комментарии, <script>-код, кнопки форм — всё на месте (сама
     * конвертация в Markdown теряет их безвозвратно). Не-HTML страницы
     * исходника не имеют — сохраняется их Markdown (он и есть текст).
     * Task 67 [BR-SRCCAP]: страницы > 512 КиБ исходник НЕ хранят
     * (копия до 3 МиБ — дорога на куче 32 МиБ; Save вернётся к Markdown). */
    if (b->src) { free(b->src); b->src = NULL; }
    b->src_len = 0;
    if (is_html && len > 0 && (u32)len <= BR_SRC_MAX) {
        char *sc = (char *)malloc((u32)len + 1);
        if (sc) {
            memcpy(sc, content, (u32)len);
            sc[len] = 0;
            b->src = sc;
            b->src_len = len;
        }
        /* нет памяти под копию — Save вернётся к Markdown (не фатально) */
    }

    /* FIX [BR-LONGPAGE]: длинные страницы обрезались ДВАЖДЫ:
     *  1) HTTP-ответ целиком был ограничен BR_FETCH_MAX (16 КиБ) —
     *     поднят до 256 КиБ (net_http_get сам уважает буфер вызывающего);
     *  2) ёмкость под Markdown была ВСЕГДА BR_MD_MAX (8 КиБ), а
     *     html_to_md честно останавливается на md_max — даже полностью
     *     загруженная страница > 8 КиБ Markdown теряла хвост.
     * Теперь для HTML ёмкость масштабируется от размера входа с запасом
     * x2 + 8 КиБ (худший случай: расширение разметки [T](url) — URL
     * переносится в Markdown целиком, сущности сжимаются).
     * FIX [BR-MD-OVF] (порча кучи «0 блоков» после некоторых сайтов):
     * не-HTML ветка копирует не более BR_FILE_MAX — ёмкость под полный
     * текст выделяется честно (см. исходный FIX ниже). */
    int md_cap = BR_MD_MAX;
    if (is_html) {
        /* Task 66 [BR-CAP3X]: было x2 — на страницах, где инлайн-скрипты
         * (копируются в md СЫРЫМИ между маркерами) съедали ёмкость,
         * обрыв посреди скрипта ОТКАТЫВАЛ весь блок (sc_pos) и всё
         * содержимое после него терялось (habr: 31832 -> 52 б).
         * x3: текст+ссылки (≤ len) + скрипты (≤ len) + запас — откат
         * стал невозможен в принципе. */
        int est = len * 3 + 8192;
        if (est > md_cap) md_cap = est;
    } else {
        int raw = len < BR_FILE_MAX ? len : BR_FILE_MAX;
        if (raw + 1 > md_cap) md_cap = raw + 1;
    }
    char *md = (char *)malloc((u32)md_cap);
    if (!md) {
        snprintf(b->status, sizeof(b->status), "Нет памяти для конвертации");
        brl_free(&b->L);
        b->wrap_maxc = -1;
        return;
    }

    int md_len;
    int md_trunc = 0;
    if (is_html) {
        /* Session 92 [HC-TBL2]: ширина таблиц — под текущее окно */
        if (b->win)
            htmlconv_set_table_width((win_content_w(b->win) - 16) / 8);
        /* Session 92 [HC-ENC]: meta-charset в первых байтах —
         * перекодировку выполнит html_to_md2 (глобаль одноразовая).
         * [HC-ENC-SOFT]: meta нет — мягкая кодировка заголовка
         * (iso-8859-1/1252; буферный путь — POST-ответы и фолбэки). */
        {
            char cs[24];
            if (br_sniff_charset(content, len < 2048 ? len : 2048,
                                 cs, (int)sizeof(cs))) {
                if (!br_cs_is_utf8(cs))
                    htmlconv_set_charset(cs);
            } else if (b->hcs_soft[0]) {
                htmlconv_set_charset(b->hcs_soft);
            }
        }
        snprintf(b->status, sizeof(b->status),
                 "Конвертация HTML->Markdown (%d байт)...", len);
        md_len = html_to_md2(content, len, md, md_cap, &md_trunc);
        /* Task 60 [BR-TRUNC]: честная диагностика обреза (1.4/1.5 из
         * разбора): раньше «HTML N -> M байт» выглядел как норма даже
         * при потере хвоста — флага обреза не было вовсе. */
        if (md_trunc) {
            snprintf(b->status, sizeof(b->status),
                     "HTML %d -> %d б | ОБРЕЗАНО (лимит %d байт)",
                     len, md_len, md_cap);
            br_err_log(b, "конверт: md обрезан (%d -> %d б)", len, md_len);
        } else if (b->fetch_trunc) {
            /* Session 93 [BR-PCT]: процент загрузки вместо голых байтов */
            if (b->fetch_total) {
                unsigned pct = (unsigned)(((u64)len * 100) / b->fetch_total);
                if (pct > 100) pct = 100;
                snprintf(b->status, sizeof(b->status),
                         "HTML %d -> %d б | Загружено %u%% — показано как есть",
                         len, md_len, pct);
            } else {
                snprintf(b->status, sizeof(b->status),
                         "HTML %d -> %d б | обрезано (лимит %d байт)",
                         len, md_len, (int)BR_FETCH_MAX);
            }
        } else {
            snprintf(b->status, sizeof(b->status),
                     "HTML %d байт -> Markdown %d байт", len, md_len);
        }
    } else {
        /* FIX (аудит): простой текст больше не режется до 8 КиБ —
        * храним столько, сколько пришло (в пределах лимита файла). */
        md_len = len < BR_FILE_MAX ? len : BR_FILE_MAX;
        memcpy(md, content, (u32)md_len);
        md[md_len] = 0;
        /* Task 60 [BR-TRUNC]: резка не-HTML больше не молчаливая (1.2/1.7) */
        if (md_len < len)
            snprintf(b->status, sizeof(b->status),
                     "Markdown/текст: %d из %d байт (ОБРЕЗАНО)",
                     md_len, len);
        else
            snprintf(b->status, sizeof(b->status),
                     "Markdown/текст (%d байт)", md_len);
    }

    /* Сжимаем буфер под факт (md_cap до 3x входа — дорога на куче;
     * владение store уйдёт в br_apply_md). */
    {
        char *store = (char *)malloc((u32)md_len + 1);
        if (!store) {
            free(md);
            snprintf(b->status, sizeof(b->status), "Нет памяти под текст");
            brl_free(&b->L);
            b->wrap_maxc = -1;
            return;
        }
        memcpy(store, md, (u32)md_len);
        store[md_len] = 0;

        /* Task 68: общий хвост (JS/формы/якоря/строки) — в br_apply_md */
        br_apply_md(b, url, store, md_len);
    }
    free(md);
}

/* Task 68 [BR-STREAM]: применить готовый Markdown к окну — ОБЩИЙ
 * хвост browser_load_content и потоковой загрузки. md переходит во
 * владение окна (b->md = md). Статус вызывает ДО конца дописывает
 * « | строк: N».
 *
 * Session 93: lazy=1 — применение после ДОконвертации той же страницы
 * (br_lazy_convert): буфер тоже новый (adopt), но позиция прокрутки
 * сохраняется (с прилипанием к дну, если пользователь был внизу),
 * meta-refresh не перезапускается (иначе цикл навигации). */
static void br_apply_md_ex(browser_t *b, const char *url, char *md,
                           int md_len, int lazy)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->hover[0] = 0;
    b->dd_open = 0;        /* Session 92 [BR-DD]: раскрытый список закрыт */

    int pin_bottom = 0;
    if (lazy && b->win && b->L.nlines > 0) {
        /* [BR-LAZY]: был ли скролл на дне (прилепить к дну новой
         * страницы — иначе пользователь потеряет место).
         * [BR-LAZY2]: пустой буфер строк не считается «низом». */
        int vis = (win_content_h(b->win) - BR_HDR - BR_STATUS_H) / 16;
        if (vis < 1) vis = 1;
        int maxs = b->L.nlines - vis;
        if (maxs > 0 && b->scroll >= maxs) pin_bottom = 1;
    }
    if (!lazy) {
        b->fetching = 0;
        b->sel_active = 0; /* новая страница — старое выделение не имеет смысла */
        b->sel_drag = 0;
        /* Task 67 [BR-FIND]: новая страница — старый запрос не имеет смысла */
        b->find_q[0] = 0;
        b->find_mode = 0;
        b->find_total = 0;
    }
    b->net_err = 0;        /* [BR-RETRY]: страница загрузилась */

    /* Session 92 [BR-IMGCACHE]: готовые картинки уходящей страницы —
     * в кэш (при доконвертации URL те же — картинки вернутся из кэша) */
    br_img_cache_stash(b);

    /* сессия 55: пиксельные буферы прошлой страницы больше не нужны */
    brp_reset(&b->page);
    /* Task 68 [BR-BGIMG]: результаты старой страницы — мимо */
    br_img_page_changed(b);

    if (b->md) free(b->md);
    b->md = md;
    b->md_len = md_len;

    /* Task 47: новая страница — старый JS-контекст не имеет смысла */
    brjs_stop(&b->js);
    br_focus_field(b, -1);
    b->js_deferred = 0;    /* [BR-JSDEFER]: сброс при новом применении */

    /* Task 47: формы -> модель, маркеры -> якоря (md только сжимается);
     * затем скрипты по порядку (document.write вставляется на месте),
     * и только потом разбор ссылок/картинок (brp_analyze) — чтобы
     * вывод скриптов тоже стал кликабельным. */
    b->md_len = brf_parse(&b->forms, b->md, b->md_len);

    /* FIX [META-REFRESH]: страницы-редиректы <meta http-equiv=refresh
     * content="N;url=U">. Раньше молча игнорировались. Переход сразу
     * (браузер не ждёт N секунд — деталь, не критичная для UX).
     * [BR-LAZY]: при доконвертации НЕ перезапускать (та же страница). */
    if (!lazy && b->forms.refresh_url[0]) {
        char rabs[300];
        img_url_resolve(b->url, b->forms.refresh_url, rabs, (int)sizeof(rabs));
        snprintf(b->status, sizeof(b->status),
                 "Meta refresh (%d с) -> %.40s", b->forms.refresh_delay, rabs);
        if (b->nav_chain < 8) {
            b->nav_chain++;
            br_navigate(b, rabs);
            b->nav_chain--;
        } else {
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений");
        }
        return;
    }
    if (br_page_scripts_run(b))
        return;          /* JS-редирект: страница уже заменена */

    /* [BR-SCRUB-INIT]: тот же канал утечки, что в br_page_refresh
     * (Task 60 [BR-SCRUB]): усечённая сеть/обрыв document.write могут
     * оставить \x01-маркеры — в т.ч. в СЕРЕДИНЕ строки (passthrough
     * brf_parse копирует их как есть), brl_wrap рисует их как текст и
     * сбивает brp_analyze. Скрипты уже исполнены, все маркерные строки
     * разобраны — чистка безопасна (якоря \x03/\x04 не трогаются,
     * md только сжимается). Линейный проход, памяти не требует. */
    b->md_len = brf_scrub(b->md, b->md_len);

    /* сессия 55: разбор страницы — маркеры картинок -> якоря, сбор
     * ссылок с абсолютными смещениями (md может быть сжат) + [BR-CSS]
     * стилевые спаны. */
    b->md_len = brp_analyze(&b->page, b->md, b->md_len);
    b->imgs_pending = (b->page.nimgs > 0);
    /* Session 92 [BR-IMGCACHE]: вернуть совпавшие по URL картинки */
    br_img_cache_restore(b);

    int keep_scroll = b->scroll;
    brl_free(&b->L);        /* строки построятся при первой отрисовке */
    b->wrap_maxc = -1;
    b->wrap_gen++;          /* [BR-WRAPCACHE]: контент изменился */
    b->nav_i = -1;          /* [BR-NAVCARET]: элементы новой страницы неизвестны */
    b->scroll = lazy ? (pin_bottom ? 0x7FFFFFF : keep_scroll) : 0;
    b->hover[0] = 0;
    {
        /* дописать " | строк: N" без strncat (его нет в kernel string.c).
        * N — строк ИСХОДНОГО текста (перенос может дать больше видимых). */
        int src_lines = 1;
        for (int i = 0; i < b->md_len; i++)
            if (b->md[i] == '\n') src_lines++;
        char tail[48];
        snprintf(tail, sizeof(tail), " | строк: %d", src_lines);
        int pos = (int)strlen(b->status);
        int rem = (int)sizeof(b->status) - 1 - pos;
        if (rem > 0) {
            strncpy(b->status + pos, tail, (u32)rem);
            b->status[pos + ((int)strlen(tail) < rem ? (int)strlen(tail) : rem)] = 0;
        }
    }
    win_invalidate(b->win);
}

static void br_apply_md(browser_t *b, const char *url, char *md, int md_len)
{
    br_apply_md_ex(b, url, md, md_len, 0);
}

/* ---------- Task 68 [BR-STREAM]: потоковая загрузка страницы ---------- */

/* Потолок md потоковой конвертации (буфер растёт хуком до этого
 * значения; дальше — честная обрезка «HTML поток: ОБРЕЗАНО»). */
#define BR_MD_STREAM_MAX (4u * 1024u * 1024u)
#define BR_MD_STREAM_START (256u * 1024u)

/* Подстрока без учёта регистра ASCII (для Content-Type). */
static int br_ci_have(const char *hay, const char *needle)
{
    if (!hay || !needle || !*needle) return 0;
    for (; *hay; hay++) {
        const char *a = hay, *c = needle;
        while (*a && *c) {
            char x = *a, y = *c;
            if (x >= 'A' && x <= 'Z') x = (char)(x + 32);
            if (y >= 'A' && y <= 'Z') y = (char)(y + 32);
            if (x != y) break;
            a++;
            c++;
        }
        if (!*c) return 1;
    }
    return 0;
}

/* Заголовок из сырого блока: имя в начале строки, ':' , значение до
 * '\n' (с обрезкой пробелов). Возвращает длину значения или 0. */
static int br_hdr_get(const char *hdrs, u32 hlen, const char *name,
                      char *out, int out_max)
{
    u32 nl = (u32)strlen(name);
    u32 p = 0;
    while (p < hlen) {
        u32 eol = p;
        while (eol < hlen && hdrs[eol] != '\n') eol++;
        if (p + nl < hlen && br_ci_ncmp(hdrs + p, name, (int)nl) == 0 &&
            hdrs[p + nl] == ':') {
            u32 v = p + nl + 1;
            while (v < eol && (hdrs[v] == ' ' || hdrs[v] == '\t')) v++;
            u32 ve = eol;
            while (ve > v && (hdrs[ve - 1] == ' ' || hdrs[ve - 1] == '\t' ||
                              hdrs[ve - 1] == '\r'))
                ve--;
            int n = (int)(ve - v);
            if (n > out_max - 1) n = out_max - 1;
            if (n > 0) {
                memcpy(out, hdrs + v, (u32)n);
                out[n] = 0;
                return n;
            }
            return 0;
        }
        p = eol + 1;
    }
    return 0;
}

/* Состояние потоковой загрузки (живёт только внутри br_fetch_stream). */
typedef struct {
    browser_t   *b;
    int          verdict;      /* 0 ок; -2 редирект; -3 бинарный; -4 https-only */
    int          code;
    char         loc[512];
    int          decided;      /* 0 сниф; 1 html; 2 простой текст */
    char        *raw_buf;      /* простой текст (до BR_FILE_MAX) */
    int          raw_len;
    char         sniff[200];
    int          sniff_len;
    u32          got_raw;      /* сырых байт (для статуса) */
    int          net_aborted;  /* сами прервали приём (лимит текста) */
    /* Session 92 [HC-ENC]: первые байты html до сниффа meta-charset */
    char         pre[1024];
    int          pre_len;
    int          charset_done; /* 1 = кодировка выставлена (заголовок/снифф) */
    /* [HC-ENC-SOFT]: мягкая кодировка заголовка (iso-8859-1/1252) —
     * применяется только если meta-снифф ничего не нашёл */
    char         hdr_cs[24];
    /* Session 93 [BR-LAZY]: спул ВСЕГО сырого HTML (доконвертация
     * по запросу); в конвертер идут только первые BR_CONV_AHEAD */
    char        *keep_buf;
    u32          keep_len;
    u32          keep_drop;    /* не влезло в спул (BR_RAW_KEEP) */
} br_stream_ctx_t;

/* [BR-LAZY]: дописать кусок сырого HTML в спул окна (буфер выделяется
 * заранее в br_fetch_stream; нет памяти — спула нет и конвертер
 * получает всё, как прежде). */
static void br_raw_keep_append(br_stream_ctx_t *cx, const char *data, u32 len)
{
    if (!cx->keep_buf) {
        cx->keep_drop += len;          /* спула нет — только счётчик */
        return;
    }
    u32 room = BR_RAW_KEEP - cx->keep_len;
    u32 take = len < room ? len : room;
    if (take) {
        memcpy(cx->keep_buf + cx->keep_len, data, take);
        cx->keep_len += take;
    }
    cx->keep_drop += len - take;
}

/* grow-хук конвертера: расширить md (в ядре нет realloc). */
static int br_md_grow(void *ud, char **md, int *max, int want)
{
    browser_t *b = (browser_t *)ud;
    char *nb = (char *)malloc((u32)want);
    if (!nb) return 0;
    if (*md) {
        memcpy(nb, *md, (u32)*max);
        free(*md);
    }
    *md = nb;
    *max = want;
    b->md_buf = nb;            /* у окна тот же указатель */
    b->md_cap = want;
    return 1;
}

/* Заголовки получены: редирект/тип/статус. */
static int br_stream_hdr(void *ud, int status, const char *hdrs, u32 hlen)
{
    br_stream_ctx_t *cx = (br_stream_ctx_t *)ud;
    browser_t *b = cx->b;
    char ct[64];

    if (status == 301 || status == 302 || status == 303 ||
        status == 307 || status == 308) {
        if (br_hdr_get(hdrs, hlen, "Location", cx->loc,
                       (int)sizeof(cx->loc)) > 0 && cx->loc[0]) {
            cx->verdict = -2;
            cx->code = status;
            return -1;                     /* прервать приём */
        }
    }
    if (status == 400 || status == 403 || status == 426) {
        /* сайт жив, но только по TLS ([BR-TLSUP] b) — повторим потоком
         * по HTTPS, не качая тело дважды */
        cx->verdict = -4;
        cx->code = status;
        return -1;
    }
    if (br_hdr_get(hdrs, hlen, "Content-Type", ct, (int)sizeof(ct)) > 0) {
        if (br_ci_have(ct, "html")) {
            cx->decided = 1;               /* html: конвертер с первого байта */
            /* Session 92 [HC-ENC]: charset из HTTP-заголовка — раньше
             * только meta в теле; сервер знает точнее.
             * [HC-ENC-SOFT]: EXCEPT — iso-8859-1/1252 «мягкая»: meta
             * в теле её переопределяет (Google: charset=ISO-8859-1
             * при UTF-8-теле — mojibake на весь текст страницы). */
            {
                char cs[24];
                if (br_ct_charset(ct, cs, (int)sizeof(cs))) {
                    if (br_cs_is_utf8(cs)) {
                        cx->charset_done = 1;
                    } else if (br_cs_is_soft_latin(cs)) {
                        snprintf(cx->hdr_cs, sizeof(cx->hdr_cs), "%s", cs);
                        snprintf(b->hcs_soft, sizeof(b->hcs_soft), "%s", cs);
                        cx->charset_done = 0;    /* ждём meta-снифф */
                    } else {
                        cx->charset_done = 1;
                        if (b->hcs)
                            hc_stream_set_charset(b->hcs, cs);
                    }
                }
            }
        } else if (!br_ci_have(ct, "text") &&
                   !br_ci_have(ct, "xml") &&
                   !br_ci_have(ct, "json")) {
            cx->verdict = -3;              /* картинка/аудио/бинарник:
                                            * буферизованный путь (mp3 и пр.) */
            cx->code = status;
            return -1;
        } else {
            cx->decided = 2;               /* text-звёздочка: копия как есть */
        }
    }
    snprintf(b->status, sizeof(b->status), "Загрузка (HTTP %d)...", status);
    br_render_now(b);
    return 0;
}

/* Кусок тела: конвертеру или в копию текста. */
static int br_stream_body(void *ud, const char *data, u32 len)
{
    br_stream_ctx_t *cx = (br_stream_ctx_t *)ud;
    browser_t *b = cx->b;

    if (cx->verdict) return -1;

    /* статус прогресса (каждые 32 КиБ) */
    if ((cx->got_raw ^ (cx->got_raw + len)) >= 32768u) {
        snprintf(b->status, sizeof(b->status),
                 "Загрузка: %u КБ%s...", (unsigned)((cx->got_raw + len) / 1024),
                 b->hcs ? " (конвертация)" : "");
        br_render_now(b);
    }
    cx->got_raw += len;

    /* Session 93 [BR-LAZY]: сырой HTML — весь в спул окна (доконвертация
     * по запросу). Пока сниф не решил (decided==0) — тоже копим: если
     * окажется текстом, спул освободится. Повторный вызов после рекурсии
     * decided==2 сюда спул не допускает (не дублировать). */
    if (cx->decided != 2)
        br_raw_keep_append(cx, data, len);

    if (cx->decided == 2) {
        /* простой текст/Markdown: копия как есть (до BR_FILE_MAX) */
        if (!cx->raw_buf) {
            cx->raw_buf = (char *)malloc((u32)BR_FILE_MAX);
            if (!cx->raw_buf) return -1;
        }
        u32 room = (u32)BR_FILE_MAX - (u32)cx->raw_len;
        u32 take = len < room ? len : room;
        if (take) {
            memcpy(cx->raw_buf + cx->raw_len, data, take);
            cx->raw_len += (int)take;
        }
        if (cx->raw_len >= BR_FILE_MAX) {
            cx->net_aborted = 1;           /* лимит файла: хватит */
            return -1;
        }
        return 0;
    }

    if (!cx->decided) {
        /* Content-Type не сказал: сниф первых 200 байт ('<') */
        int saw_lt = 0;
        while (cx->sniff_len < (int)sizeof(cx->sniff) && len > 0) {
            char c = *data++;
            len--;
            cx->sniff[cx->sniff_len++] = c;
            if (c == '<') { saw_lt = 1; break; }
        }
        if (saw_lt) {
            cx->decided = 1;
        } else if (cx->sniff_len >= (int)sizeof(cx->sniff)) {
            cx->decided = 2;               /* 200 байт без '<' — текст */
            return br_stream_body(ud, data, len);   /* хвост — как текст */
        } else {
            return 0;                      /* сниф ещё не окончен */
        }
        /* содержимое снифа — в pre-буфер charset-логики (ниже) */
        memcpy(cx->pre, cx->sniff, (u32)cx->sniff_len);
        cx->pre_len = cx->sniff_len;
        cx->sniff_len = 0;
        cx->sniff[0] = 0;
    }

    /* Session 92 [HC-ENC]: если charset не пришёл в заголовке — сниффим
     * meta-charset в первых 1024 байтах ДО подачи конвертеру.
     * [HC-ENC-SOFT]: «мягкая» кодировка заголовка (iso-8859-1/1252)
     * тоже проходит через снифф: meta в теле её переопределяет; нет
     * meta — применяем мягкую кодировку заголовка. */
    if (cx->decided == 1 && !cx->charset_done) {
        while (len > 0 && cx->pre_len < (int)sizeof(cx->pre)) {
            cx->pre[cx->pre_len++] = *data++;
            len--;
            if ((cx->pre_len & 31) == 0 ||
                cx->pre_len >= (int)sizeof(cx->pre)) {
                char cs[24];
                if (br_sniff_charset(cx->pre, cx->pre_len,
                                     cs, (int)sizeof(cs))) {
                    cx->charset_done = 1;
                    if (!br_cs_is_utf8(cs) && b->hcs)
                        hc_stream_set_charset(b->hcs, cs);
                    break;
                }
            }
        }
        if (!cx->charset_done && cx->pre_len < (int)sizeof(cx->pre))
            return 0;              /* ждём ещё байты (charset обычно в head) */
        /* meta не нашлась — мягкая кодировка заголовка (Google и пр.) */
        if (!cx->charset_done && cx->hdr_cs[0] && b->hcs) {
            hc_stream_set_charset(b->hcs, cx->hdr_cs);
            cx->charset_done = 1;
        }
        if (cx->pre_len) {
            if (b->hcs)
                hc_stream_feed(b->hcs, cx->pre, cx->pre_len);
            cx->pre_len = 0;
        }
        if (!len) return 0;
    }

    /* Session 93 [BR-LAZY]: конвертеру — только первые BR_CONV_AHEAD
     * байт входа (если спул под хвост удался); иначе — всё, как прежде. */
    if (b->hcs) {
        if (cx->keep_buf) {
            int done = hc_stream_input_done(b->hcs);
            int feed_n = (int)len;
            if (done >= (int)BR_CONV_AHEAD)
                feed_n = 0;
            else if (done + (int)len > (int)BR_CONV_AHEAD)
                feed_n = (int)BR_CONV_AHEAD - done;
            if (feed_n > 0)
                hc_stream_feed(b->hcs, data, feed_n);
        } else {
            hc_stream_feed(b->hcs, data, (int)len);
        }
    }
    return 0;
}

/* [BR-RETRY1] FIX 4: matcher ПРЕХОДЯЩИХ сбоев — стоит ли повторить
 * запрос. Расширен «handshake timeout» (прерывистые сбои TLS-рукопожатия
 * на загруженном канале — обычное дело: первый SYN/TCP-обмен рукопожатия
 * потерялся, повтор проходит). Используется и потоковым путём
 * (br_fetch_stream), и буферизованным (br_navigate_full). */
static int br_err_transient(const char *why)
{
    if (!why || !why[0]) return 0;
    return br_ci_ncmp(why, "connection", 10) == 0 ||
           br_ci_ncmp(why, "connect timeout", 15) == 0 ||
           br_ci_ncmp(why, "response timeout", 16) == 0 ||
           br_ci_ncmp(why, "handshake timeout", 17) == 0 ||
           br_ci_ncmp(why, "пустой ответ", 12) == 0 ||
           /* [GZ-CORRUPT]: порча сжатого ответа обычно преходящая
            * (битый сегмент Wi-Fi) — повтор того же адреса оправдан */
           br_ci_ncmp(why, "gzip: сжатый ответ повреждён", 29) == 0;
}

/* Потоковый GET страницы.
 * Возврат: >= 0 — страница ПРИМЕНЕНА (md_len);
 *          -1 — сетевая ошибка (статус показан; *try_https_out = 1,
 *               если стоит повторить по HTTPS);
 *          -2 — редирект (*code_out, loc);
 *          -3 — контент не для потока: буферизованный путь (mp3 и пр.). */
static int br_fetch_stream(browser_t *b, const char *full,
                           const char *host, u16 port, const char *path,
                           int use_tls, int redirs,
                           int *try_https_out, int *code_out,
                           char *loc, int loc_max)
{
    br_stream_ctx_t cx;
    memset(&cx, 0, sizeof(cx));
    cx.b = b;
    (void)redirs;
    *try_https_out = 0;
    *code_out = 0;
    loc[0] = 0;
    /* [HC-ENC-SOFT]: мягкая кодировка — свойство СТРАНИЦЫ, каждый
     * fetch начинает с чистого листа */
    b->hcs_soft[0] = 0;
    /* [BR-LAZY]: спул сырого входа — ЗАРАНЕЕ (если памяти нет, конвертер
     * получает всё и ленивая догрузка не возникает) */
    cx.keep_buf = (char *)malloc(BR_RAW_KEEP);

    char *md = (char *)malloc(BR_MD_STREAM_START);
    if (!md) {
        if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }
        snprintf(b->status, sizeof(b->status),
                 "Нет памяти под страницу");
        return -1;
    }
    b->md_buf = md;
    b->md_cap = (int)BR_MD_STREAM_START;

    b->hcs = hc_stream_begin(md, (int)BR_MD_STREAM_START,
                             (int)BR_MD_STREAM_MAX, br_md_grow, b);
    if (!b->hcs) {
        free(md);
        b->md_buf = NULL;
        b->md_cap = 0;
        if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }
        snprintf(b->status, sizeof(b->status),
                 "Нет памяти под конвертер");
        return -1;
    }
    /* Session 92 [HC-TBL2]: ширина таблиц — под текущее окно */
    if (b->win)
        htmlconv_set_table_width((win_content_w(b->win) - 16) / 8);

    /* адрес страницы (для базы относительных ссылок) */
    snprintf(b->addr, sizeof(b->addr), "%s", full);
    ti_sync(&b->addr_ti);

    b->fetching = 1;
    snprintf(b->status, sizeof(b->status), "Запрос %s...", full);
    br_render_now(b);

    /* 15000 мс: транзакция не должна переживать SLOCK_STALE_TICKS (20 с) —
     * иначе второе окно браузера (воркер картинок) отберёт http_busy_lock
     * ПОСРЕДИ потоковой загрузки (порча глобальных буферов клиента). */
    int n = net_http_get_stream(host, port, path, 15000, 1,
                                br_stream_hdr, br_stream_body, &cx);
    b->fetching = 0;
    b->net_got = net_http_raw_received();

    if (n == -2) {
        /* прервано колбэком */
        if (cx.verdict == -2) {
            hc_stream_abort(b->hcs);
            b->hcs = NULL;
            if (b->md_buf) { free(b->md_buf); b->md_buf = NULL; b->md_cap = 0; }
            if (cx.raw_buf) { free(cx.raw_buf); cx.raw_buf = NULL; } /* страховка */
            if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }
            *code_out = cx.code;
            snprintf(loc, loc_max, "%s", cx.loc);
            return -2;
        }
        if (cx.verdict == -3 || cx.verdict == -4) {
            hc_stream_abort(b->hcs);
            b->hcs = NULL;
            if (b->md_buf) { free(b->md_buf); b->md_buf = NULL; b->md_cap = 0; }
            if (cx.raw_buf) { free(cx.raw_buf); cx.raw_buf = NULL; } /* страховка */
            if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }
            if (cx.verdict == -4) {
                if (!use_tls) *try_https_out = 1;
                *code_out = cx.code;
            }
            return -3;
        }
        /* body сам прервал (лимит текста) — это успех с обрезкой */
        cx.net_aborted = 1;
        n = 0;
    }

    if (n < 0) {
        /* сетевая ошибка */
        hc_stream_abort(b->hcs);
        b->hcs = NULL;
        if (b->md_buf) { free(b->md_buf); b->md_buf = NULL; b->md_cap = 0; }
        /* Session 95 [BR-FIX]: decided==2 успел выделить raw_buf (до
         * BR_FILE_MAX) — при обрыве сети он больше никому не нужен */
        if (cx.raw_buf) { free(cx.raw_buf); cx.raw_buf = NULL; }
        if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; cx.keep_len = 0; }
        const char *why = net_http_errstr();
        snprintf(b->status, sizeof(b->status),
                 "Ошибка: %s (HTTP Trace покажет детали)", why);
        b->fetch_note[0] = 0;
        /* Session 93 [BR-RETRY]/[BR-ERRLOG]: кнопка «Повторить» + журнал */
        b->net_err = 1;
        snprintf(b->retry_url, sizeof(b->retry_url), "%s", full);
        br_err_log(b, "сеть: %.60s", why);
        if (br_err_transient(why))
            *try_https_out = 1;
        return -1;
    }

    /* страница получена (полностью или с обрезом) */
    b->fetch_trunc = net_http_truncated() || cx.net_aborted;
    b->fetch_total = net_http_content_length();
    b->fetch_note[0] = 0;
    if (b->fetch_trunc) {
        /* Session 93 [BR-PCT]: процент загрузки — «Загружено 70% —
         * показано как есть» вместо голых байтов */
        if (b->fetch_total) {
            unsigned pct = (unsigned)(((u64)b->net_got * 100) / b->fetch_total);
            if (pct > 100) pct = 100;
            snprintf(b->fetch_note, sizeof(b->fetch_note),
                     "Загружено %u%% (%u из %u) — показано как есть",
                     pct, (unsigned)b->net_got, (unsigned)b->fetch_total);
            br_err_log(b, "сеть: обрыв, %u%% (%u из %u)",
                       pct, (unsigned)b->net_got, (unsigned)b->fetch_total);
        } else {
            snprintf(b->fetch_note, sizeof(b->fetch_note),
                     "получено %u (поток)", (unsigned)b->net_got);
        }
    }

    int md_len;
    if (cx.decided == 2 && cx.raw_buf) {
        /* простой текст */
        md_len = cx.raw_len;
        free(b->md_buf);
        b->md_buf = NULL;
        b->md_cap = 0;
        if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }
        if (b->fetch_trunc)
            snprintf(b->status, sizeof(b->status),
                     "Текст: %d из %u байт (ОБРЕЗАНО)", md_len,
                     (unsigned)b->net_got);
        else
            snprintf(b->status, sizeof(b->status),
                     "Текст (%d байт)", md_len);
        hc_stream_abort(b->hcs);
        b->hcs = NULL;
        br_apply_md(b, full, cx.raw_buf, md_len);
        return md_len;
    }

    {
        int trunc = 0;
        md_len = hc_stream_finish(b->hcs, &trunc);
        hc_stream_free(b->hcs);
        b->hcs = NULL;
        b->fetch_trunc = b->fetch_trunc || trunc;

        /* Session 93 [BR-LAZY]: конвертер получил НЕ всё — хвост в спуле.
         * Отдаём спул окну: доконвертация по прокрутке к низу. */
        if (cx.keep_len > 0 &&
            (u32)cx.keep_len > (u32)BR_CONV_AHEAD - 4096) {
            if (b->raw_keep) free(b->raw_keep);
            b->raw_keep = cx.keep_buf;
            cx.keep_buf = NULL;
            b->raw_keep_len = cx.keep_len;
            b->raw_keep_cap = BR_RAW_KEEP;
            b->raw_total = cx.got_raw;
            b->lazy_pending = 1;
        }
        if (cx.keep_buf) { free(cx.keep_buf); cx.keep_buf = NULL; }

        if (b->fetch_trunc) {
            snprintf(b->status, sizeof(b->status),
                     "HTML %s: сеть %u КБ -> md %d КБ | ОБРЕЗАНО (%s)",
                     use_tls ? "https" : "http",
                     (unsigned)(b->net_got / 1024),
                     md_len / 1024,
                     b->fetch_note[0] ? b->fetch_note : "лимит md");
        } else {
            snprintf(b->status, sizeof(b->status),
                     "HTML поток: сеть %u КБ -> md %d КБ",
                     (unsigned)(b->net_got / 1024), md_len / 1024);
        }
        if (b->lazy_pending) {
            /* [BR-LAZY]: честный статус — показан хвост от 100 КиБ;
             * дозагрузка по End/кнопке/прокрутке вниз */
            char tail2[80];
            if (cx.keep_drop > 0)
                snprintf(tail2, sizeof(tail2),
                         " | дозагрузка: End (%u КБ ждут, %u КБ сверх лимита)",
                         (unsigned)(b->raw_keep_len / 1024),
                         (unsigned)(cx.keep_drop / 1024));
            else
                snprintf(tail2, sizeof(tail2),
                         " | дозагрузка: End (%u КБ ждут)",
                         (unsigned)(b->raw_keep_len / 1024));
            int pos2 = (int)strlen(b->status);
            int rem2 = (int)sizeof(b->status) - 1 - pos2;
            if (rem2 > 0) {
                strncpy(b->status + pos2, tail2, (u32)rem2);
                b->status[pos2 + ((int)strlen(tail2) < rem2
                                  ? (int)strlen(tail2) : rem2)] = 0;
            }
        }

        /* ужать буфер под факт (куча дороже копии) */
        if (b->md_cap > md_len * 2 + 65536) {
            char *tight = (char *)malloc((u32)md_len + 1);
            if (tight) {
                memcpy(tight, b->md_buf, (u32)md_len);
                free(b->md_buf);
                b->md_buf = tight;
                b->md_cap = md_len + 1;
            }
        }
        char *own = b->md_buf;
        b->md_buf = NULL;
        b->md_cap = 0;
        br_apply_md(b, full, own, md_len);
        return md_len;
    }
}

/* ═══════════ Session 93 [BR-LAZY]: ДОконвертация страницы ═══════════
 * Потоковая загрузка сконвертировала только первые BR_CONV_AHEAD байт
 * HTML (страница показана сразу); весь сырой вход ждал в b->raw_keep.
 * Здесь — полный повторный прогон конвертера по сырьцу (свежий буфер,
 * чистая модель форм/скриптов), страница заменяется целиком.
 * Вызывается: прокрутка к низу (клавиши/колесо), End, кнопка
 * «Догрузить» в статус-баре, br_tick. */
static void br_lazy_convert(browser_t *b)
{
    if (!b->lazy_pending || !b->raw_keep || !b->raw_keep_len) return;
    b->lazy_pending = 0;

    int keep_scroll = b->scroll;
    int pin_bottom = 0;
    if (b->win && b->L.nlines > 0) {
        /* [BR-LAZY]: был ли скролл на дне (прилепить к дну новой
         * страницы — иначе пользователь потеряет место).
         * [BR-LAZY2]: пустой буфер строк (nlines=0 — сразу после apply
         * или до первой отрисовки) НЕ считается «низом» — иначе
         * доконвертация, вызванная сразу после загрузки, прыгала
         * в хвост (см. br_tick [BR-LAZY2]). */
        int vis = (win_content_h(b->win) - BR_HDR - BR_STATUS_H) / 16;
        if (vis < 1) vis = 1;
        int maxs = b->L.nlines - vis;
        if (maxs > 0 && b->scroll >= maxs) pin_bottom = 1;
    }

    snprintf(b->status, sizeof(b->status), "Доконвертация %u КБ...",
             (unsigned)(b->raw_keep_len / 1024));
    br_render_now(b);

    /* ёмкость md — как у буферного пути: x3 входа + запас (скрипты
     * копируются сырыми, разметка ссылок расширяется) */
    int cap = (int)b->raw_keep_len * 3 + 8192;
    if (cap > (int)BR_MD_STREAM_MAX) cap = (int)BR_MD_STREAM_MAX;
    char *md = (char *)malloc((u32)cap);
    if (!md) {
        b->lazy_pending = 1;       /* можно повторить позже */
        b->lazy_cool = timer_ticks() + 10000; /* [BR-AUTOTAIL]: 1 тик = 1 мс */
        snprintf(b->status, sizeof(b->status),
                 "Нет памяти под доконвертацию");
        return;
    }
    if (b->win)
        htmlconv_set_table_width((win_content_w(b->win) - 16) / 8);
    hc_stream_t *hs = hc_stream_begin(md, cap, (int)BR_MD_STREAM_MAX,
                                      br_md_grow, b);
    if (!hs) {
        free(md);
        b->lazy_pending = 1;
        b->lazy_cool = timer_ticks() + 10000; /* [BR-AUTOTAIL] */
        snprintf(b->status, sizeof(b->status),
                 "Нет памяти под конвертер (докончание)");
        return;
    }
    /* кодировка сырьца — снифф meta-charset в первых 2 КиБ (заголовок
     * HTTP уже ушёл с транзакцией). [HC-ENC-SOFT]: meta нет — берём
     * мягкую кодировку заголовка (если она была — google.com и пр.). */
    {
        char cs[24];
        int scan = b->raw_keep_len < 2048 ? (int)b->raw_keep_len : 2048;
        if (br_sniff_charset(b->raw_keep, scan, cs, (int)sizeof(cs))) {
            if (!br_cs_is_utf8(cs))
                hc_stream_set_charset(hs, cs);
        } else if (b->hcs_soft[0]) {
            hc_stream_set_charset(hs, b->hcs_soft);
        }
    }
    hc_stream_feed(hs, b->raw_keep, (int)b->raw_keep_len);
    int trunc = 0;
    int md_len = hc_stream_finish(hs, &trunc);
    hc_stream_free(hs);

    /* спул больше не нужен (значения — в локальных для журнала) */
    u32 kept = b->raw_keep_len, total_in = b->raw_total;
    free(b->raw_keep);
    b->raw_keep = NULL;
    b->raw_keep_len = 0;

    if (trunc || total_in > kept)
        br_err_log(b, "конверт: доконвертировано %u КБ (вход %u КБ)%s",
                   (unsigned)(kept / 1024),
                   (unsigned)(total_in / 1024),
                   trunc ? ", md обрезан" : "");

    /* ужать буфер под факт */
    if (cap > md_len * 2 + 65536) {
        char *tight = (char *)malloc((u32)md_len + 1);
        if (tight) {
            memcpy(tight, md, (u32)md_len);
            free(md);
            md = tight;
        }
    }

    br_apply_md_ex(b, b->url, md, md_len, 1);
    /* скролл: был на дне — прилепить к новому дну; иначе сохранить
     * (br_apply_md_ex уже поставил; поправим только грубый случай, когда
     * место потерялось из-за сжатия md) */
    if (pin_bottom)
        b->scroll = 0x7FFFFFF;     /* отрисовка зажмёт к дну */
    else if (keep_scroll > 0 && b->scroll == 0 && !pin_bottom)
        b->scroll = keep_scroll;
    snprintf(b->status, sizeof(b->status),
             "Доконвертировано: %d КБ Markdown", md_len / 1024);
    win_invalidate(b->win);
}
/* ---------- навигация ---------- */

static void br_render_now(browser_t *b)
{
    /* Немедленная отрисовка в canvas своего окна (мы в потоке окна):
     * под rlock — чтобы статус «Запрос...» был виден ДО блокирующего
     * сетевого запроса. Прямой вызов w->draw без rlock гонялся бы
     * с realloc canvas при resize. */
    if (b->win) win_draw_now(b->win);
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs);

static void br_navigate(browser_t *b, const char *addr)
{
    br_navigate_ex(b, addr, 0);
}

/* br_ci_ncmp / br_http_status / br_parse_redirect — в brurl.h
 * (Task 61: вынесены для хост-тестов, поведение прежнее). */

/* [BR-MP3]: похоже ли это на MP3: расширение .mp3 в пути URL
 * (без регистра, до ?/#), либо контент ID3v2, либо frame sync
 * 0xFFEx (MPEG audio). Достаточно консервативно для ветки плеера. */
static int br_looks_like_mp3(const char *url, const char *body, int len)
{
    if (url) {
        const char *seg = strrchr(url, '/');
        seg = seg ? seg + 1 : url;
        const char *dot = strrchr(seg, '.');
        if (dot) {
            char e[8];
            int n = 0;
            for (const char *t = dot + 1;
                 *t && *t != '?' && *t != '#' && n < 7; t++) {
                char c = *t;
                if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
                e[n++] = c;
            }
            e[n] = 0;
            if (!strcmp(e, "mp3")) return 1;
        }
    }
    if (len >= 3 && body[0] == 'I' && body[1] == 'D' && body[2] == '3')
        return 1;
    if (len >= 2 && (unsigned char)body[0] == 0xFF &&
        ((unsigned char)body[1] & 0xE0) == 0xE0)
        return 1;
    return 0;
}

/* [BR-MP3]: отдать MP3 аудиоплееру (mp3svc/dr_mp3) вместо рендера
 * бинарника в Markdown. Копия сохраняется в RAM disk (Файлы/повтор).
 * payload переходит во владение плеера (app_mp3_open_with сам free).
 * 1 = отдали плееру (страницу не рендерить). */
static int br_hand_mp3_to_player(browser_t *b, const char *url_for_stem,
                                 const char *path, const char *resp, int n)
{
    const char *mbody;
    int mlen;
    br_strip_headers(resp, n, &mbody, &mlen);
    if (mlen < 4096 || !br_looks_like_mp3(path, mbody, mlen))
        return 0;

    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];
    int  have_name = 0;

    br_save_derive_stem(url_for_stem, stem, (int)sizeof(stem));
    if (br_save_free_name_ext(stem, "mp3", name, (int)sizeof(name))) {
        ramfs_delete(name);              /* свободное имя — delete страховка */
        if (ramfs_create(name, (u32)mlen + 1) &&
            ramfs_write(name, mbody, (u32)mlen))
            have_name = 1;
    }

    char *payload = (char *)malloc((u32)mlen);
    if (!payload) {
        snprintf(b->status, sizeof(b->status), "Нет памяти под MP3 (%d КБ)",
                 mlen / 1024);
        return 0;
    }
    memcpy(payload, mbody, (u32)mlen);
    snprintf(b->status, sizeof(b->status), "MP3: %s (%d КБ) — в плеер",
             have_name ? name : "поток", mlen / 1024);
    win_invalidate(b->win);
    app_mp3_open_with(have_name ? name : "", payload, (u32)mlen);
    return 1;
}

/* Полная навигация: GET/POST (Task 47) + javascript:-ссылки.
 * redirs — глубина цепочки редиректов (максимум BR_REDIR_MAX из
 * brurl.h — Task 61: было 4, не хватало на цепочки популярных
 * сайтов http:// -> https:// -> www -> canonical). */
static void br_navigate_full(browser_t *b, const char *addr, int redirs,
                             int is_post, const char *post_body)
{
    char host[128];
    char path[256];
    /* сессия 55: локальная копия без фрагментов (на УРОВНЕ функции:
     * p остаётся валидным до конца функции)
     * Task 61 [BR-LONGLOC]: было BR_ADDR_MAX+1 (119) — длинные
     * Location/ссылки (tracking-URL > 118 символов) ОБРЕЗАЛИСЬ до
     * разбора и вели на 404; теперь 300 (адресная строка по-прежнему
     * показывает 118, но ЗАПРОС идёт по полному адресу). */
    char cut[300];
    /* сессия 67: нормализованное имя файла RAM disk (тоже на уровне
     * функции: p = nm живёт до конца функции) */
    char nm[BR_ADDR_MAX + 1];
    const char *p = addr;

    b->addr_focus = 0;

    /* [BR-SAVEHTML2]: исходник ПРЕЖНЕЙ страницы недействителен с первым
     * же переходом. Раньше потоковая загрузка (обычные сайты) b->src не
     * заполняла — «Сохранить как html» молча писала исходник СТАРОЙ
     * страницы или отказывала. Очистка здесь: буферизованный путь ниже
     * заполнит заново (browser_load_content), потоковый — сохранение
     * перекачает ([BR-SAVEHTML2]). */
    if (b->src) { free(b->src); b->src = NULL; }
    b->src_len = 0;

    /* Session 93: новая навигация — хвост ленивой конвертации и
     * состояние «сетевая ошибка» прежней страницы недействительны */
    if (b->raw_keep) { free(b->raw_keep); b->raw_keep = NULL; }
    b->raw_keep_len = 0;
    b->lazy_pending = 0;
    b->net_err = 0;

    /* Пустой ввод — ничего не делать */
    while (*p == ' ') p++;
    if (!*p) {
        win_invalidate(b->win);
        return;
    }

    /* Task 47: javascript:-ссылки исполняются движком страницы
     * (раньше проваливались в ramfs-поиск и получали «Файл не найден»).
     * Task 61: схема без учёта регистра ("JavaScript:..."). */
    if (br_ci_ncmp(p, "javascript:", 11) == 0) {
        char jsbuf[192];
        strncpy(jsbuf, p + 11, sizeof(jsbuf) - 1);
        jsbuf[sizeof(jsbuf) - 1] = 0;
        /* [BR-SNIPPET-REFRESH]: document.write из сниппета теперь
         * дообслуживается ВНУТРИ br_js_run_snippet (refresh виден и
         * onclick-кнопкам). Повторный refresh здесь давал двойной
         * brp_analyze + brl_wrap на каждый javascript:-клик. */
        (void)br_js_run_snippet(b, jsbuf);
        win_invalidate(b->win);
        return;
    }

    /* сессия 55: фрагменты #... отбрасываем (якоря не поддержаны) */
    {
        int ci = 0;
        for (const char *q = p; *q && ci < (int)sizeof(cut) - 1; q++) {
            if (*q == '#') break;
            cut[ci++] = *q;
        }
        cut[ci] = 0;
        while (ci > 0 && cut[ci - 1] == ' ') cut[--ci] = 0;
        if (ci == 0) {
            snprintf(b->status, sizeof(b->status), "Внутренний якорь — пропущен");
            win_invalidate(b->win);
            return;
        }
        /* работаем дальше с ЛОКАЛЬНОЙ обрезанной строкой (без алиасинга
         * с b->addr — ниже ветки сами обновляют адресную строку) */
        addr = cut;
        p = cut;
    }

    /* --- ramfs-файл? (нет схемы и не похоже на URL) --- */
    int has_scheme = 0;
    for (const char *q = p; *q; q++) {
        if (q - p > 12) break;
        if (*q == ':' && q[1] == '/' && q[2] == '/') { has_scheme = 1; break; }
    }

    if (!has_scheme) {
        u32 fsize = 0;
        int is_url = 0;
        /* www.foo.bar или foo.ru — похоже на хост без схемы */
        int dots = 0, spaces = 0;
        for (const char *q = p; *q; q++) {
            if (*q == '.') dots++;
            if (*q == ' ') spaces++;
        }
        if (!strncmp(p, "www.", 4) || (dots >= 1 && spaces == 0 &&
             !strchr(p, '/')))
            is_url = 1;

        /* СЕССИЯ 63: голый "localhost" (и "localhost:8080") — тоже URL:
         * без точек раньше шёл в ramfs-поиск и получал «Файл 'localhost'
         * не найден в RAM disk» вместо локального сервера. */
        if (!is_url && !strncmp(p, "localhost", 9) &&
            (p[9] == 0 || p[9] == ':' || p[9] == '/'))
            is_url = 1;

        /* СЕССИЯ 67: локальные адреса вида "/help.md", "./help.md",
         * "../help.md" (ссылка с абсолютным путём на локальной
         * странице, ручной ввод) — RAM disk хранит имена БЕЗ
         * ведущего '/': нормализуем к имени от корня.
         * Task 61 [BR-NOSLASH]: нормализуем и ищем в RAM disk ВСЕГДА,
         * а не только когда ввод «не похож на URL»: имена с ТОЧКОЙ и
         * БЕЗ слеша ("readme.txt", "help.md", "demo.js" — всё из
         * документации браузера!) перехватывались эвристикой is_url
         * и уходили в DNS («cannot resolve host») вместо открытия
         * файла. Порядок теперь честный: ЛОКАЛЬНЫЙ файл первым,
         * URL — только если файла с таким именем нет. */
        {
            const char *q = p;
            int k = 0;
            for (;;) {
                if (*q == '/') q++;
                else if (q[0] == '.' && q[1] == '/') q += 2;
                else if (q[0] == '.' && q[1] == '.' && q[2] == '/') q += 3;
                else break;
            }
            while (*q && k < BR_ADDR_MAX) nm[k++] = *q++;
            nm[k] = 0;
        }

        if (nm[0] && ramfs_lookup(nm, &fsize)) {
            /* Открываем файл из RAM disk */
            p = nm;
            if (fsize == 0 || fsize > BR_FILE_MAX) {
                snprintf(b->status, sizeof(b->status),
                         "Файл %s: %u байт — вне лимита", p, (unsigned)fsize);
                win_invalidate(b->win);
                return;
            }
            char *buf = (char *)malloc(fsize);
            if (!buf) {
                snprintf(b->status, sizeof(b->status), "Нет памяти");
                win_invalidate(b->win);
                return;
            }
            u32 got = ramfs_read(p, buf, fsize);
            if (got == 0) {
                free(buf);
                snprintf(b->status, sizeof(b->status), "Ошибка чтения %s", p);
                win_invalidate(b->win);
                return;
            }
            b->fetch_trunc = 0;      /* локальный файл — сетевого обреза нет */
            b->fetch_total = 0;
            strncpy(b->addr, p, BR_ADDR_MAX);
            b->addr[BR_ADDR_MAX] = 0;
            ti_sync(&b->addr_ti);
            browser_load_content(b, p, buf, (int)got);
            free(buf);
            win_invalidate(b->win);
            return;
        }
        if (is_url) {
            /* продолжаем как http(s):// с исходной строкой (nm для
             * хостов совпадает с p, но честнее не трогать ввод) */
        } else if (!nm[0]) {
            snprintf(b->status, sizeof(b->status),
                     "Пустое имя файла");
            win_invalidate(b->win);
            return;
        } else {
            p = nm;
            snprintf(b->status, sizeof(b->status),
                     "Файл '%s' не найден в RAM disk", p);
            win_invalidate(b->win);
            return;
        }
    }
    else if (br_ci_ncmp(p, "http://", 7) != 0 &&
             br_ci_ncmp(p, "https://", 8) != 0) {
        snprintf(b->status, sizeof(b->status),
                 "Схема не поддерживается (http:// или https://)");
        win_invalidate(b->win);
        return;
    }

    /* --- HTTP/HTTPS --- */
    /* Task 61: схема без учёта регистра ("HTTP://YA.RU" раньше падала
     * с «Схема не поддерживается», а "Http://host" шла как хост "Http"). */
    int use_tls = 0;
    if (br_ci_ncmp(p, "https://", 8) == 0) { p += 8; use_tls = 1; }
    else if (br_ci_ncmp(p, "http://", 7) == 0) p += 7;
    /* Task 61: разбор хост/порт/путь + нормализация пути ([BR-2SLASH])
     * и процентное кодирование ([BR-PCT]) — в brurl.h (br_split_url),
     * покрыто хост-тестом scripts/brhost. */
    u16 port = 80;
    if (!br_split_url(p, use_tls, host, (int)sizeof(host), &port,
                      path, (int)sizeof(path))) {
        snprintf(b->status, sizeof(b->status), "Неверный порт в адресе");
        win_invalidate(b->win);
        return;
    }

    if (!host[0]) {
        snprintf(b->status, sizeof(b->status), "Пустой хост");
        win_invalidate(b->win);
        return;
    }

    /* СЕССИЯ 63: loopback ("localhost", 127.x.x.x) работает БЕЗ NIC и
     * без настроенного IP — соединение замыкается внутри стека
     * (net_is_loopback), поэтому проверку сети для него пропускаем:
     * раньше без сети браузер отвечал «Сеть не настроена» даже на
     * 127.0.0.1, хотя локальный httpd доступен. */
    if (!net_host_is_loopback(host) &&
        (!net_nic_present() || net_get_ip() == 0)) {
        snprintf(b->status, sizeof(b->status), "Сеть не настроена");
        win_invalidate(b->win);
        return;
    }

    /* Показываем статус ДО блокирующего запроса (запрос выполняется
     * в потоке ЭТОГО окна — система и остальные окна продолжают жить). */
    b->fetching = 1;
    snprintf(b->status, sizeof(b->status),
             "Запрос %s://%s:%u%s ...", use_tls ? "https" : "http",
             host, (unsigned)port, path);
    br_render_now(b);

    /* сессия 55: история Back — текущая страница уходит в стек
     * (сессия 56: только для переходов С НАЧАЛА цепочки —
     * промежуточные редиректы историю не дублируют)
     * Task 67 [BR-FWD]: обычный переход (не Back/Forward) чистит стек
     * «вперёд» — как в больших браузерах; сам Back/Forward (hist_jump=1)
     * историю не дублирует. */
    if (redirs == 0 && b->url[0] && strcmp(b->url, addr) != 0 &&
        !b->hist_jump) {
        b->hist_f_n = 0;
        if (b->hist_n < BR_HIST_MAX) {
            strncpy(b->hist[b->hist_n], b->url, sizeof(b->hist[0]) - 1);
            b->hist[b->hist_n][sizeof(b->hist[0]) - 1] = 0;
            b->hist_n++;
        }
    }

    /* Task 68 [BR-STREAM]: GET страницы — ПОТОКОВО (конвертация по мере
     * приёма; лимита «3 МиБ на ответ» больше нет: буфер только под
     * заголовки + растущий md). POST и «не потоковый» контент —
     * буферизованный путь ниже (он же mp3-детектор и [BR-TLSUP]-b). */
    int stream_mr = 0;
    if (!is_post) {
        int try_https = 0, code = 0;
        char loc[512];
        char full0[448];
        snprintf(full0, sizeof(full0), "%s://%s:%u%s",
                 use_tls ? "https" : "http", host, (unsigned)port, path);
        int mr = br_fetch_stream(b, full0, host, port, path, use_tls,
                                 redirs, &try_https, &code,
                                 loc, (int)sizeof(loc));
        /* [BR-RETRY1] FIX 4: ОДНОРАЗОВЫЙ повтор преходящего сбоя той же
         * схемой (handshake timeout/connect timeout/connection...).
         * Каждая транзакция держит http_busy_lock не дольше 15 с, поэтому
         * повтор не нарушает контракт SLOCK_STALE_TICKS (20 с) — блокировка
         * между попытками отпускается. */
        if (mr == -1 && redirs < BR_REDIR_MAX &&
            br_err_transient(net_http_errstr())) {
            snprintf(b->status, sizeof(b->status),
                     "Преходящий сбой — повтор запроса...");
            win_invalidate(b->win);
            mr = br_fetch_stream(b, full0, host, port, path, use_tls,
                                 redirs, &try_https, &code,
                                 loc, (int)sizeof(loc));
        }
        if (mr >= 0) {
            /* страница применена; картинки — фоном (br_tick/br_draw) */
            br_img_pump(b);
            win_invalidate(b->win);
            return;
        }
        if (mr == -2) {
            if (redirs < BR_REDIR_MAX) {
                char base[448], abs[512];
                snprintf(base, sizeof(base), "%s://%s:%u%s",
                         use_tls ? "https" : "http", host, (unsigned)port,
                         path);
                img_url_resolve(base, loc, abs, (int)sizeof(abs));
                snprintf(b->status, sizeof(b->status),
                         "Редирект %d -> %.46s", code, abs);
                win_invalidate(b->win);
                br_navigate_ex(b, abs, redirs + 1);
                return;
            }
            snprintf(b->status, sizeof(b->status),
                     "Слишком много перенаправлений (> %d): %.40s",
                     BR_REDIR_MAX, full0);
            win_invalidate(b->win);
            return;
        }
        if (mr == -1 && try_https && !use_tls &&
            redirs < BR_REDIR_MAX && !net_host_is_loopback(host)) {
            /* отказ на :80 — повтор по HTTPS тем же потоковым путём */
            snprintf(b->status, sizeof(b->status),
                     "HTTP: отказ — пробую HTTPS...");
            win_invalidate(b->win);
            use_tls = 1;
            port = 443;
            snprintf(full0, sizeof(full0), "https://%s:%u%s",
                     host, (unsigned)port, path);
            mr = br_fetch_stream(b, full0, host, port, path, use_tls,
                                 redirs, &try_https, &code,
                                 loc, (int)sizeof(loc));
            if (mr >= 0) {
                br_img_pump(b);
                win_invalidate(b->win);
                return;
            }
            if (mr == -2 && redirs < BR_REDIR_MAX) {
                char base[448], abs[512];
                snprintf(base, sizeof(base), "https://%s:%u%s",
                         host, (unsigned)port, path);
                img_url_resolve(base, loc, abs, (int)sizeof(abs));
                snprintf(b->status, sizeof(b->status),
                         "Редирект %d -> %.46s", code, abs);
                win_invalidate(b->win);
                br_navigate_ex(b, abs, redirs + 1);
                return;
            }
            if (mr == -1) {
                win_invalidate(b->win);
                return;                /* честная ошибка потока */
            }
            /* -3/-4 — буферизованный путь разберётся */
        }
        if (mr == -1) {
            win_invalidate(b->win);
            return;
        }
        stream_mr = mr;                /* -3/-4: буферизованный путь */
    }

    char *resp = (char *)malloc(BR_FETCH_MAX);
    if (!resp) {
        b->fetching = 0;
        snprintf(b->status, sizeof(b->status), "Нет памяти под ответ");
        win_invalidate(b->win);
        return;
    }

    int n;
    /* Task 66 [BR-T20S]: было 10 с — на медленных каналах (реальное
     * железо/загруженный Wi-Fi) 430-КиБ страница не успевала; таймаут
     * воспринимался как «пустая страница». 20 с — запас; честно
     * завершённые ответы (Content-Length/close) возвращаются сразу. */
    if (is_post) {
        /* Task 62 [POST-LEN]: multipart-тело (с нулями) уходит с явной
         * длиной; обычные формы — по-прежнему net_http_post (strlen). */
        if (b->post_ct)
            n = net_http_post_len(host, port, path,
                                  post_body ? post_body : "", b->post_len,
                                  b->post_ct, resp, BR_FETCH_MAX, 20000);
        else
            n = net_http_post(host, port, path,
                              post_body ? post_body : "", NULL,
                              resp, BR_FETCH_MAX, 20000);
    } else if (stream_mr) {
        /* [BR-STREAM] fallback: бинарный тип / 400/403/426 — качаем
         * буферизованно (mp3-детектор, [BR-TLSUP] b) */
        b->fetching = 1;
        br_render_now(b);
        n = net_http_get_gzip(host, port, path, resp, BR_FETCH_MAX, 20000);
        b->fetching = 0;
    } else
        n = net_http_get_gzip(host, port, path, resp, BR_FETCH_MAX, 20000);
    b->fetching = 0;
    /* [BR-TLSUP] (сессия 79): АВТО-ПЕРЕХОД http -> https. Один повтор
     * на переход (как сессия 58), условия расширены:
     *  (a) сетевой отказ на :80 — "connection refused/reset",
     *      "connect timeout", "response timeout" (сервер молчит),
     *      "пустой ответ" (закрыл соединение, не ответив): типичная
     *      реакция https-only хостов и фильтров plain-HTTP;
     *  (b) сервер ОТВЕТИЛ на plain http кодом 400/403/426 — сайт
     *      жив, но работает только по TLS (nginx: "The plain HTTP
     *      request was sent to HTTPS port" = 400; Cloudflare-заглушки
     *      часто 403; RFC 2817: 426 Upgrade Required);
     *  (c) 301/302/303/307/308 с Location: https://... следуются и
     *     так (сессия 56, br_parse_redirect) — отдельного кода не нужно.
     * Обратное понижение https -> http НЕ делается. Loopback не
     * переключаем (локальный httpd говорит только plain HTTP). */
    if (!use_tls && redirs < BR_REDIR_MAX && !net_host_is_loopback(host)) {
        int try_https = 0;
        char why[56] = "";
        if (n <= 0) {
            const char *why0 = net_http_errstr();
            /* [BR-RETRY1]: matcher общий с потоковым путём — включая
             * «handshake timeout» (прерывистые сбои TLS-рукопожатия) */
            if (br_err_transient(why0)) {
                try_https = 1;
                strncpy(why, why0, sizeof(why) - 1);
                why[sizeof(why) - 1] = 0;
            }
        } else {
            int code = br_http_status(resp, n);
            if (code == 400 || code == 403 || code == 426) {
                try_https = 1;
                snprintf(why, sizeof(why), "HTTP %d — plain отвергнут", code);
            }
        }
        if (try_https) {
            snprintf(b->status, sizeof(b->status),
                     "HTTP: %s — пробую HTTPS...", why);
            b->fetching = 1;
            br_render_now(b);
            use_tls = 1;
            port = 443;
            if (is_post) {
                if (b->post_ct)
                    n = net_http_post_len(host, port, path,
                                          post_body ? post_body : "", b->post_len,
                                          b->post_ct, resp, BR_FETCH_MAX, 20000);
                else
                    n = net_http_post(host, port, path,
                                      post_body ? post_body : "", NULL,
                                      resp, BR_FETCH_MAX, 20000);
            } else
                n = net_http_get_gzip(host, port, path, resp, BR_FETCH_MAX, 20000);
            b->fetching = 0;
        }
    }
    if (n > 0) {
        /* сессия 56: редиректы 301/302/303/307/308. ya.ru и большинство
         * крупных сайтов отвечают 302 (часто на https:// или
         * canonical-хост) — раньше пользователь видел сырые заголовки
         * вместо страницы. Location абсолютный и относительный.
         * Task 61 [BR-REDIR2]: лимит 4 -> BR_REDIR_MAX (8) — цепочки
         * http->https->www->canonical длиной 5-6 обычны; буферы
         * loc/base/abs увеличены (длинные tracking-Location не
         * влезали — редирект молча терялся). */
        if (redirs < BR_REDIR_MAX) {
            int code = 0;
            char loc[512];
            if (br_parse_redirect(resp, n, &code, loc, (int)sizeof(loc))) {
                char base[448], abs[512];
                snprintf(base, sizeof(base), "%s://%s:%u%s",
                         use_tls ? "https" : "http", host, (unsigned)port,
                         path);
                img_url_resolve(base, loc, abs, (int)sizeof(abs));
                snprintf(b->status, sizeof(b->status),
                         "Редирект %d -> %.46s", code, abs);
                free(resp);
                /* Task 61: 307/308 сохраняют метод и тело POST
                 * (RFC 9110); 301/302/303 после POST -> GET */
                if (is_post && (code == 307 || code == 308))
                    br_navigate_full(b, abs, redirs + 1, 1, post_body);
                else
                    br_navigate_ex(b, abs, redirs + 1);
                return;
            }
        }
        const char *scheme = use_tls ? "https" : "http";
        snprintf(b->addr, sizeof(b->addr), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        b->addr[sizeof(b->addr) - 1] = 0;
        ti_sync(&b->addr_ti);
        /* Task 66 [BR-FULL448]: было 168 — host(128)+path(256) влезали
         * лишь частично; усечённая база ломала относительные ссылки */
        char full[448];
        snprintf(full, sizeof(full), "%s://%s:%u%s", scheme,
                 host, (unsigned)port, path);
        /* [BR-MP3]: MP3-ссылка — сразу в аудиоплеер (не рендерим) */
        if (!is_post && br_hand_mp3_to_player(b, full, path, resp, n)) {
            free(resp);
            win_invalidate(b->win);
            return;
        }
        /* Task 60 [BR-TRUNC]: флаги сетевого обреза — ДО конвертации
         * (браузер покажет «получено X из Y байт», если ответ не влез;
         * заметку из них соберёт browser_load_content — [BR-STATUS]) */
        b->fetch_trunc = net_http_truncated();
        b->fetch_total = net_http_content_length();
        browser_load_content(b, full, resp, n);
    } else {
        /* FIX [N1d]: показываем причину сбоя (connect timeout /
         * connection refused / no ARP / resolve) вместо безликого кода */
        snprintf(b->status, sizeof(b->status),
                 "Ошибка: %s (HTTP Trace покажет детали)", net_http_errstr());
        b->fetch_note[0] = 0;
        /* Session 93 [BR-RETRY]/[BR-ERRLOG]: кнопка «Повторить» + журнал */
        b->net_err = 1;
        snprintf(b->retry_url, sizeof(b->retry_url), "%s://%s:%u%s",
                 use_tls ? "https" : "http", host, (unsigned)port, path);
        br_err_log(b, "сеть: %.60s", net_http_errstr());
    }
    free(resp);

    /* Task 68 [BR-BGIMG]: картинки страницы грузятся ФОНОВО (воркер):
     * страница интерактивна сразу, картинки появляются по мере
     * готовности (br_img_pump зовёт br_tick/br_draw) */
    br_img_pump(b);

    win_invalidate(b->win);
}

static void br_navigate_ex(browser_t *b, const char *addr, int redirs)
{
    br_navigate_full(b, addr, redirs, 0, NULL);
}

/* Task 47: POST-навигация (отправка форм). */
static void br_navigate_post(browser_t *b, const char *addr, const char *body)
{
    b->post_ct = NULL; b->post_len = 0;
    br_navigate_full(b, addr, 0, 1, body);
}

/* Task 62 [BR-UPLOAD]: POST-навигация с multipart-телом (с нулями) и
 * Content-Type (boundary). b->post_* читает br_navigate_full для выбора
 * net_http_post_len; 307/308-редирект сохраняет метод И тело (b->post_ct
 * жив до выхода из этой функции — рекурсивный br_navigate_full его видит).
 * Task 67 [BR-NAVT]: поля ОКНА, не глобали — два окна больше не делят
 * состояние POST. */
static void br_navigate_post_ex(browser_t *b, const char *addr,
                                const char *body, u32 body_len,
                                const char *content_type)
{
    b->post_ct = content_type;
    b->post_len = body_len;
    br_navigate_full(b, addr, 0, 1, body);
    b->post_ct = NULL;
    b->post_len = 0;
}

/* Назад (сессия 55): возврат по истории. Backspace / Alt+Left / кнопка.
 * Task 67 [BR-FWD]: классическая модель ДВУХ стеков. Прежде текущая
 * страница при Back заталкивалась ОБРАТНО в стек назад — двойной Back
 * «прыгал» между двумя последними страницами (A->B->back->A->back->B...),
 * а «вперёд» не существовало вовсе. Теперь:
 *   Back    : текущая -> hist_f, hist_n--, навигация без записи в hist;
 *   Forward : текущая -> hist,  hist_f_n--, навигация без записи в hist_f;
 *   обычный переход: текущая -> hist, hist_f очищается (hist_jump=0). */
static void br_go_back(browser_t *b)
{
    char prev[256];   /* Task 66: было 128 (hist теперь 256) */
    if (b->hist_n == 0) {
        snprintf(b->status, sizeof(b->status), "История пуста");
        win_invalidate(b->win);
        return;
    }
    if (b->hist_f_n >= BR_HIST_MAX) {
        /* стек «вперёд» полон — выкинуть самую старую запись */
        for (int k = 1; k < BR_HIST_MAX; k++)
            memcpy(b->hist_f[k - 1], b->hist_f[k], sizeof(b->hist_f[0]));
        b->hist_f_n = BR_HIST_MAX - 1;
    }
    strncpy(b->hist_f[b->hist_f_n], b->url, sizeof(b->hist_f[0]) - 1);
    b->hist_f[b->hist_f_n][sizeof(b->hist_f[0]) - 1] = 0;
    b->hist_f_n++;
    b->hist_n--;
    strncpy(prev, b->hist[b->hist_n], sizeof(prev) - 1);
    prev[sizeof(prev) - 1] = 0;
    b->hist_jump = 1;
    br_navigate(b, prev);
    b->hist_jump = 0;
}

/* Вперёд (Task 67 [BR-FWD]): Alt+Right. Возврат по стеку hist_f. */
static void br_go_forward(browser_t *b)
{
    char next[256];
    if (b->hist_f_n == 0) {
        snprintf(b->status, sizeof(b->status), "Вперёд некуда");
        win_invalidate(b->win);
        return;
    }
    if (b->hist_n < BR_HIST_MAX) {
        strncpy(b->hist[b->hist_n], b->url, sizeof(b->hist[0]) - 1);
        b->hist[b->hist_n][sizeof(b->hist[0]) - 1] = 0;
        b->hist_n++;
    } else {
        /* стек назад полон — выкинуть самую старую (как в больших браузерах) */
        for (int k = 1; k < BR_HIST_MAX; k++)
            memcpy(b->hist[k - 1], b->hist[k], sizeof(b->hist[0]));
        b->hist_n = BR_HIST_MAX - 1;
        strncpy(b->hist[b->hist_n], b->url, sizeof(b->hist[0]) - 1);
        b->hist[b->hist_n][sizeof(b->hist[0]) - 1] = 0;
        b->hist_n++;
    }
    b->hist_f_n--;
    strncpy(next, b->hist_f[b->hist_f_n], sizeof(next) - 1);
    next[sizeof(next) - 1] = 0;
    b->hist_jump = 1;
    br_navigate(b, next);
    b->hist_jump = 0;
}

/* Домашняя страница (Task 67): Ctrl+Home — см. реализацию после br_help_md */

/* ---------- сохранение страницы на RAM disk (сессия 67) ---------- */

/* Имя файла для сохранения из адреса страницы:
 *   "http://host:80/dir/page.html" -> "page"  (расширение добавит
 * br_save_free_name: ".md" — страница уже конвертирована в Markdown);
 *   "https://ya.ru/"               -> "page";
 *   "docs/page.md"                 -> "page.md";
 *   "notes.txt"                    -> "notes.txt" (текст сохраняется
 *                                     как есть, расширение честное).
 * Схема/host:port отрезаются (берётся последний сегмент пути),
 * не-[A-Za-z0-9._-] -> '_'. Стеб ограничен RAMFS_NAME_MAX-8 — запас
 * под суффикс "_NN.md". */
static void br_save_derive_stem(const char *url, char *out, int out_max)
{
    char stem[RAMFS_NAME_MAX + 1];
    int n = 0;
    const char *p = url ? url : "";

    const char *sch = strstr(p, "://");
    if (sch) p = sch + 3;
    const char *last = strrchr(p, '/');
    if (last) p = last + 1;

    for (; *p; p++) {
        char c = *p;
        if (c == '?' || c == '#' || c == '/') break;
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-'))
            c = '_';
        if (n < (int)sizeof(stem) - 1) stem[n++] = c;
    }
    stem[n] = 0;

    /* адрес без имени ("http://host:80/", "dir/") — базовое имя */
    if (!stem[0] || !strcmp(stem, ".") || !strcmp(stem, ".."))
        strcpy(stem, "page");

    /* расширение: .html/.htm убираем (контент уже Markdown), .md и
     * прочие честные расширения сохраняем, без расширения — добавит
     * br_save_free_name */
    {
        char *dot = strrchr(stem, '.');
        if (dot && dot != stem) {
            char e[8];
            int el = 0;
            for (const char *q = dot + 1; *q && el < 7; q++) {
                char lc = *q;
                if (lc >= 'A' && lc <= 'Z') lc += 32;
                e[el++] = lc;
            }
            e[el] = 0;
            if (!strcmp(e, "htm") || !strcmp(e, "html"))
                *dot = 0;                     /* .html/.htm -> стеб */
            /* .md/.txt/... — оставляем как есть */
        }
    }

    /* запас под суффикс "_NN.md" */
    if ((int)strlen(stem) > RAMFS_NAME_MAX - 8)
        stem[RAMFS_NAME_MAX - 8] = 0;
    strncpy(out, stem, (u32)out_max - 1);
    out[out_max - 1] = 0;
}

/* Свободное имя: "stem.md" (или стем с его расширением), затем
 * "stem_2.md"... "stem_99.md". Возвращает 1 при успехе. */
static int br_save_free_name(const char *stem, char *out, int out_max)
{
    char cand[RAMFS_NAME_MAX + 8];

    /* у стема может быть своё расширение (.md/.txt) — тогда "stem.md"
     * не добавляем второе: расширение уже есть */
    const char *dot = strrchr(stem, '.');
    if (dot && dot != stem) {
        snprintf(cand, sizeof(cand), "%s", stem);
    } else {
        snprintf(cand, sizeof(cand), "%s.md", stem);
    }
    if (!ramfs_lookup(cand, NULL)) {
        strncpy(out, cand, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return 1;
    }
    for (int k = 2; k < 100; k++) {
        snprintf(cand, sizeof(cand), "%s_%d.md", stem, k);
        if (!ramfs_lookup(cand, NULL)) {
            strncpy(out, cand, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return 1;
        }
    }
    return 0;
}

/* Свободное имя с ЗАДАННЫМ расширением: "stem.ext" (или стем с его
 * собственным расширением), затем "stem_2.ext"... Возвращает 1.
 * Task 66 [BR-SAVENAME]: в retry-цикле стем режется по последней точке
 * ("song.mp3" -> "song_2.mp3", а не "song.mp3_2.mp3"). */
static int br_save_free_name_ext(const char *stem, const char *ext,
                                 char *out, int out_max)
{
    char cand[RAMFS_NAME_MAX + 8];
    char base[RAMFS_NAME_MAX + 1];   /* стем без расширения */
    int  has_ext = 0;

    {
        const char *dot = strrchr(stem, '.');
        if (dot && dot != stem) {
            int bl = (int)(dot - stem);
            if (bl > RAMFS_NAME_MAX) bl = RAMFS_NAME_MAX;
            memcpy(base, stem, (u32)bl);
            base[bl] = 0;
            has_ext = 1;
        } else {
            strncpy(base, stem, sizeof(base) - 1);
            base[sizeof(base) - 1] = 0;
        }
    }

    if (has_ext)
        snprintf(cand, sizeof(cand), "%s", stem);
    else
        snprintf(cand, sizeof(cand), "%s.%s", base, ext);
    if (!ramfs_lookup(cand, NULL)) {
        strncpy(out, cand, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return 1;
    }
    for (int k = 2; k < 100; k++) {
        snprintf(cand, sizeof(cand), "%s_%d.%s", base, k, ext);
        if (!ramfs_lookup(cand, NULL)) {
            strncpy(out, cand, (u32)out_max - 1);
            out[out_max - 1] = 0;
            return 1;
        }
    }
    return 0;
}

/* Сохранить текущую страницу в RAM disk.
 * Task 51 [BR-SAVE]: для HTML-страниц сохраняется ИСХОДНИК (b->src —
 * он же потом честно открывается браузером снова: комментарии, скрипты
 * и кнопки на месте). Раньше писался только Markdown после конвертации,
 * и пользователь не находил в сохранённом файле ни скриптов, ни
 * комментариев, ни кнопок. Для текстовых/Markdown страниц исходника
 * нет — сохраняется текст страницы (как прежде).
 * Существующие файлы НЕ перезаписываются (подбирается свободное имя). */
static void br_save_page(browser_t *b)
{
    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];

    if ((!b->md || b->md_len <= 0) &&
        (!(b->src && b->src_len > 0))) {
        snprintf(b->status, sizeof(b->status), "Нечего сохранять");
        win_invalidate(b->win);
        return;
    }
    br_save_derive_stem(b->url, stem, (int)sizeof(stem));

    if (b->src && b->src_len > 0) {
        /* --- исходник HTML --- */
        if (!br_save_free_name_ext(stem, "html", name, (int)sizeof(name))) {
            snprintf(b->status, sizeof(b->status), "Нет свободного имени");
            win_invalidate(b->win);
            return;
        }
        ramfs_delete(name);
        if (!ramfs_create(name, (u32)b->src_len + 1) ||
            !ramfs_write(name, b->src, (u32)b->src_len + 1)) {
            snprintf(b->status, sizeof(b->status),
                     "Ошибка записи RAM disk");
            win_invalidate(b->win);
            return;
        }
        snprintf(b->status, sizeof(b->status),
                 "Сохранён исходник: %s (%d байт)", name, b->src_len + 1);
        win_invalidate(b->win);
        return;
    }

    /* --- Markdown/текст (как раньше) --- */
    if (!br_save_free_name(stem, name, (int)sizeof(name))) {
        snprintf(b->status, sizeof(b->status), "Нет свободного имени");
        win_invalidate(b->win);
        return;
    }
    ramfs_delete(name);              /* свободное имя — delete страховка */
    if (!ramfs_create(name, (u32)b->md_len + 1) ||
        !ramfs_write(name, b->md, (u32)b->md_len + 1)) {
        snprintf(b->status, sizeof(b->status),
                 "Ошибка записи RAM disk");
        win_invalidate(b->win);
        return;
    }
    snprintf(b->status, sizeof(b->status), "Сохранено: %s (%d байт)",
             name, b->md_len + 1);
    win_invalidate(b->win);
}

/* ---------- рендеринг ---------- */

/* Сессия 56: строка отображения с ПОДСВЕТКОЙ ССЫЛОК. Ссылка — интервал
 * видимого текста [b_abs, t_end_abs) исходной строки (brpage.h: разметка
 * [T](U) вырезана из md). Кусок отображения покрывает байты
 * [line_base+srcoff, ...+plen) — пересечения рисуем синим с
 * подчёркиванием, остальное — цветом класса строки.
 * Раньше вся строка рисовалась одной fb_text с разметкой на экране:
 * пользователь видел [example.com](http://example.com/). */
#define BR_SEGS_MAX 12
#define BR_SEG_BUF  512
#define BR_STY_SEGS_MAX 16      /* Session 93: стилевых сегментов на кусок */
/* (форвард: определение — в разделе ввода, ниже) */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1);

/* Отрисовать строку отображения. scale=1 — обычный текст (шаг 8px);
 * scale=2 — [BR-HEAD-2X] заголовок: fb_text2x, шаг 16px, ведущий
 * префикс '#'-ей НЕ рисуется (br_head_prefix_len), совпадения поиска
 * и подчёркивание ссылок масштабируются. Ссылочные интервалы (brpage)
 * работают по колонкам piece как прежде — 2x только ВИЗУАЛЬНО. */
static void br_draw_text_line(browser_t *b, int i, int y, u32 color,
                              int scale)
{
    const char *piece = b->L.lines[i];
    int plen = (int)strlen(piece);
    if (plen == 0) return;
    int skip = (scale == 2) ? br_head_prefix_len(piece) : 0;
    int px = 8 * scale;                    /* шаг символа в пикселях */

    brp_seg_t lsegs[BR_SEGS_MAX];
    brp_styseg_t ssegs[BR_STY_SEGS_MAX];
    int nl = 0, ns = 0;
    if ((b->page.nlinks > 0 || b->page.nstyles > 0) &&
        b->page.line_off != NULL &&
        b->L.srcidx && b->L.srcoff &&
        b->L.srcidx[i] >= 0 && b->L.srcidx[i] < b->page.nlines) {
        int piece_abs0 = b->page.line_off[b->L.srcidx[i]] + b->L.srcoff[i];
        nl = brp_link_segs(&b->page, b->L.srcidx[i], piece_abs0,
                           piece, plen, lsegs, BR_SEGS_MAX);
        ns = brp_style_segs(&b->page, piece_abs0, piece, plen,
                            ssegs, BR_STY_SEGS_MAX);
    }

    if (nl == 0 && ns == 0) {
        if (scale == 2) fb_text2x(4, y, piece + skip, color);
        else            fb_text(4, y, piece, color, -1);
    } else {
        u32 link_col = br_col_accent(b);
        int total = utf8_count_chars(piece, -1);
        int col = skip;                    /* 2x: '#'-префикс не рисуем */
        int x = 4;
        char buf[BR_SEG_BUF];
        while (col < total) {
            /* атрибуты колонки col */
            const brp_seg_t *ls = NULL;
            const brp_styseg_t *ss = NULL;
            for (int k = 0; k < nl; k++)
                if (col >= lsegs[k].col0 && col < lsegs[k].col1) {
                    ls = &lsegs[k];
                    break;
                }
            for (int k = 0; k < ns; k++)
                if (col >= ssegs[k].col0 && col < ssegs[k].col1) {
                    ss = &ssegs[k];
                    break;
                }
            /* граница run'а: конец активных сегментов или ближайшее
             * начало следующего */
            int end = total;
            if (ls && ls->col1 < end) end = ls->col1;
            if (ss && ss->col1 < end) end = ss->col1;
            for (int k = 0; k < nl; k++)
                if (lsegs[k].col0 > col && lsegs[k].col0 < end)
                    end = lsegs[k].col0;
            for (int k = 0; k < ns; k++)
                if (ssegs[k].col0 > col && ssegs[k].col0 < end)
                    end = ssegs[k].col0;

            u32 seg_col = color;
            if (ls)
                seg_col = link_col;            /* ссылка перекрашивает спан */
            else if (ss && ss->rgb)
                seg_col = fb_rgb((u8)(ss->rgb >> 16), (u8)(ss->rgb >> 8),
                                 (u8)ss->rgb);
            int bold = ss ? ss->bold : 0;
            int italic = ss ? ss->italic : 0;

            int b0 = brp_byte_of_col(piece, plen, col);
            int b1 = brp_byte_of_col(piece, plen, end);
            int nb = b1 - b0;
            if (nb > (int)sizeof(buf) - 1) nb = (int)sizeof(buf) - 1;
            if (nb > 0) {
                memcpy(buf, piece + b0, (u32)nb);
                buf[nb] = 0;
                /* [BR-HEAD-2X]: у 2x глифов fb_char_fx нет — стиль
                 * bold/italic на заголовках опускаем (крайне редкий
                 * случай: ссылка/стиль внутри '#'-строки) */
                if (scale == 2)
                    fb_text2x(x, y, buf, seg_col);
                else if (bold || italic)
                    fb_text_fx(x, y, buf, seg_col, -1, bold, italic);
                else
                    fb_text(x, y, buf, seg_col, -1);
            }
            if (ls) {
                /* [BR-LINK-2X] (сессия 101, ФИКС «ссылки заголовков
                 * зачёркнуты»): позиция подчёркивания — ПОД глифами
                 * ТЕКУЩЕГО масштаба. Прежде линия рисовалась всегда на
                 * y+14: у обычного текста (глиф 16px) это под базлайном,
                 * а у 2x-заголовков (глиф 32px, базлайн ~y+27) — на
                 * середине роста букв, поэтому ссылки в заголовках
                 * выглядели ЗАЧЁРКНУТЫМИ. y+14*scale сохраняет прежний
                 * вид у обычного текста; у 2x линия под базлайном,
                 * вторая строка даёт толщину 2px — под 2px-штрихи
                 * крупных глифов. */
                fb_hline(x, x + (end - col) * px - 1, y + 14 * scale,
                         link_col);
                if (scale == 2)
                    fb_hline(x, x + (end - col) * px - 1,
                             y + 14 * scale + 1, link_col);
            }
            x += (end - col) * px;
            col = end;
        }
    }

    /* Task 67 [BR-FIND]: подсветка совпадений поиска поверх текста
     * (янтарная плашка + тёмный текст — как выделение в больших
     * браузерах). До 4 совпадений на строку отображения. */
    if (b->find_q[0]) {
        int fseg[8];
        int fn = br_find_row_segs(b, i, fseg, 4);
        for (int k = 0; k < fn; k++) {
            int c0 = fseg[k * 2], c1 = fseg[k * 2 + 1];
            if (c1 <= c0) continue;
            if (c0 < skip) c0 = skip;          /* 2x: префикс не рисуется */
            if (c1 <= c0) continue;
            int b0 = brp_byte_of_col(piece, plen, c0);
            int b1 = brp_byte_of_col(piece, plen, c1);
            if (b1 - b0 >= BR_SEG_BUF - 1) continue;
            char buf[BR_SEG_BUF];
            memcpy(buf, piece + b0, (u32)(b1 - b0));
            buf[b1 - b0] = 0;
            int x = 4 + (c0 - skip) * px;
            int wpx = (c1 - c0) * px;
            fb_fill_rect(x, y - 1, wpx, 15 * scale + 1,
                         fb_rgb(0xC8, 0xA0, 0x28));
            if (scale == 2) fb_text2x(x, y, buf, fb_rgb(0x10, 0x10, 0x10));
            else            fb_text(x, y, buf, fb_rgb(0x10, 0x10, 0x10), -1);
        }
    }
}

/* ---------- Task 47: отрисовка контролов форм ---------- */

static int br_field_box_w(int avail_px)
{
    int w = avail_px - 4;
    if (w > 26 * 8) w = 26 * 8;
    if (w < 10 * 8) w = 10 * 8;
    return w;
}

static void br_draw_field(browser_t *b, brf_field_t *fl, int y, int cw)
{
    u32 txt = br_col_text(b);      /* [BR-THEME]: палитра окна */
    u32 dim = br_col_dim(b);
    int focused = (b->focus >= 0 && &b->forms.fields[b->focus] == fl);
    char shown[132];

    if (!strcmp(fl->type, "text") || !strcmp(fl->type, "password") ||
        !strcmp(fl->type, "search") || !strcmp(fl->type, "textarea")) {
        char lab[24];
        snprintf(lab, sizeof(lab), "%s:",
                 fl->name[0] ? fl->name : "поле");
        fb_text(4, y + 1, lab, dim, -1);
        int lx = 4 + (int)strlen(lab) * 8 + 4;
        int bw2 = br_field_box_w(cw - lx);
        fb_fill_rect(lx, y + 1, bw2, 14,
                     focused ? br_col_field_focus(b) : br_col_field(b));
        fb_rect(lx, y + 1, bw2, 14,
                focused ? br_col_accent(b) : br_col_border(b));
        /* содержимое: пароль звёздами; пустое — placeholder */
        const char *val = fl->value;
        if (!strcmp(fl->type, "password") && val[0]) {
            int vl = (int)strlen(val);
            if (vl > 22) vl = 22;
            for (int i = 0; i < vl; i++) shown[i] = '*';
            shown[vl] = 0;
            val = shown;
        } else if (!val[0] && fl->ph[0]) {
            val = fl->ph;
            txt = dim;
        }
        /* Task 64 [TI-WIDGET]: в фокусе — окно видимости виджета вокруг
         * курсора (СИМВОЛЫ, кириллица не рвётся) + мигающая каретка;
         * вне фокуса — хвост значения (как раньше). */
        int maxc = (bw2 - 10) / 8;
        if (maxc < 1) maxc = 1;
        int from = 0, cpos = -1;
        int vlen = (int)strlen(val);
        if (focused) {
            ti_view_off(&b->field_ti, maxc);
            from = b->field_ti.view_off;
            cpos = utf8_count_chars(val + from, b->field_ti.cur - from);
        } else {
            int total = utf8_count_chars(val, -1);
            if (total > maxc)
                from = utf8_take_bytes(val, -1, total - maxc);
        }
        vlen -= from;
        if (vlen < 0) vlen = 0;
        if (vlen > (int)sizeof(shown) - 4)
            vlen = (int)sizeof(shown) - 4;
        {
            int nch = utf8_count_chars(val + from, vlen);
            if (nch > maxc) {
                vlen = utf8_take_bytes(val + from, vlen, maxc);
                nch = maxc;
            }
            if (!focused) cpos = nch;      /* каретка не рисуется вне фокуса */
        }
        if (!strcmp(fl->type, "password") && vlen > 0) {
            for (int i = 0; i < vlen; i++) shown[i] = '*';
            shown[vlen] = 0;
        } else {
            memcpy(shown, val + from, (u32)vlen);
            shown[vlen] = 0;
        }
        /* [TI-SEL]: плашка выделения в поле формы (в фокусе) */
        if (focused) {
            int d0, d1;
            if (ti_sel_px(&b->field_ti, from, maxc, &d0, &d1))
                fb_fill_rect(lx + 4 + d0, y + 2, d1 - d0, 12, br_col_sel(b));
        }
        if (focused && cpos >= 0) {
            if (wm_blink()) {
                /* '_' на байтовую границу символа под курсором
                 * (у пароля всё по 1 байту — cpos и есть смещение) */
                int bpos = !strcmp(fl->type, "password")
                               ? cpos
                               : utf8_take_bytes(val + from, vlen, cpos);
                if (bpos >= 0 && bpos <= vlen) {
                    memmove(shown + bpos + 1, shown + bpos,
                            (u32)(vlen - bpos) + 1);
                    shown[bpos] = '_';
                }
            } else {
                int cx2 = lx + 4 + cpos * 8;
                if (cx2 >= lx + 1 && cx2 <= lx + bw2 - 3)
                    fb_fill_rect(cx2, y + 2, 2, 12, txt);
            }
        }
        fb_text(lx + 4, y + 1, shown, txt, -1);
    } else if (!strcmp(fl->type, "checkbox") ||
               !strcmp(fl->type, "radio")) {
        /* Session 92: радио — (•)/( ) вместо (x)/( ); чекбокс — [x]/[ ] */
        if (fl->type[0] == 'c') {
            snprintf(shown, sizeof(shown), "[%c] %s",
                     fl->checked ? 'x' : ' ',
                     fl->label[0] ? fl->label
                                  : (fl->name[0] ? fl->name : "выбор"));
        } else {
            snprintf(shown, sizeof(shown), "(%s) %s",
                     fl->checked ? "\xe2\x80\xa2" : " ",
                     fl->label[0] ? fl->label
                                  : (fl->name[0] ? fl->name : "выбор"));
        }
        if (focused)
            fb_rect(2, y, utf8_count_chars(shown, -1) * 8 + 8, 15,
                    br_col_accent(b));
        fb_text(6, y + 1, shown,
                fl->checked ? br_col_accent(b) : txt, -1);
    } else if (!strcmp(fl->type, "select")) {
        char lab[24];
        snprintf(lab, sizeof(lab), "%s:",
                 fl->name[0] ? fl->name : "список");
        fb_text(4, y + 1, lab, dim, -1);
        int lx = 4 + (int)strlen(lab) * 8 + 4;
        int bw2 = br_field_box_w(cw - lx);
        fb_fill_rect(lx, y + 1, bw2, 14, br_col_field(b));
        fb_rect(lx, y + 1, bw2, 14,
                focused ? br_col_accent(b) : br_col_border(b));
        const char *cur = (fl->opt_sel >= 0 && fl->opt_sel < fl->nopts)
                              ? fl->opts[fl->opt_sel] : "(не выбран)";
        int maxc = (bw2 - 20) / 8;
        int total = utf8_count_chars(cur, -1);
        int from = 0;
        if (total > maxc)
            from = utf8_take_bytes(cur, -1, total - maxc);
        strncpy(shown, cur + from, sizeof(shown) - 5);
        shown[sizeof(shown) - 5] = 0;
        /* Session 92 [BR-DD]: ' ' + 3 байта '▼' + NUL = 5 байт запаса
         * (ограничение strncpy выше гарантирует место) */
        {
            size_t sl = strlen(shown);
            shown[sl] = ' ';
            shown[sl + 1] = '\xe2';
            shown[sl + 2] = '\x96';
            shown[sl + 3] = '\xbc';
            shown[sl + 4] = 0;
        }
        fb_text(lx + 4, y + 1, shown, txt, -1);
    } else if (!strcmp(fl->type, "submit") || !strcmp(fl->type, "button") ||
               !strcmp(fl->type, "reset")) {
        const char *lab2 =
            fl->label[0] ? fl->label
                         : (fl->value[0] ? fl->value
                         : (!strcmp(fl->type, "submit") ? "Отправить"
                                                        : fl->name));
        int bw2 = utf8_count_chars(lab2, -1) * 8 + 16;
        if (bw2 < 64) bw2 = 64;
        if (bw2 > cw - 16) bw2 = cw - 16;
        fb_fill_rect(4, y + 1, bw2, 14, br_col_btn(b));
        fb_rect(4, y + 1, bw2, 14,
                focused ? br_col_accent(b) : br_col_sep(b));
        fb_text(4 + (bw2 - utf8_count_chars(lab2, -1) * 8) / 2, y + 1,
                lab2, focused ? br_col_accent(b) : txt, -1);
    }
}

static void br_draw(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Task 68 [BR-BGIMG]: если воркер дал готовую картинку — применяем
     * прямо перед отрисовкой (перестройка строк, кнопки не блокируются) */
    br_img_pump(b);

    /* --- адресная строка (BR_HDR пикселей сверху) --- */
    /* [BR-THEME]: палитра тулбара/кнопок — из локальной темы окна */
    fb_fill_rect(0, 0, cw, BR_HDR, br_col_toolbar(b));
    fb_hline(0, cw - 1, BR_HDR - 1, br_col_sep(b));

    /* поле ввода (сессия 97: правее ЧЕТЫРЕ кнопки — Go/Тема/Back/Save
     * по 44px; Go — сразу за адресом, затем Тема ([BR-THEME]) */
    int box_x = 4, box_y = 3, box_w = cw - 200, box_h = 16;
    if (box_w < 40) box_w = 40;
    fb_fill_rect(box_x, box_y, box_w, box_h,
                 b->addr_focus ? br_col_field_focus(b) : br_col_field(b));
    fb_rect(box_x, box_y, box_w, box_h,
            b->addr_focus ? br_col_accent(b) : br_col_border(b));

    char shown[BR_ADDR_MAX * 2 + 2];   /* x2 — UTF-8: до 2 байт на символ */
    int max_chars = (box_w - 12) / 8;
    if (max_chars < 4) max_chars = 4;
    if (max_chars > BR_ADDR_MAX) max_chars = BR_ADDR_MAX;

    const char *src = b->addr_focus ? b->addr : (b->addr[0] ? b->addr : b->url);
    int sl = (int)strlen(src);
    /* Task 62 [BR-CURSOR]: в фокусе показываем окно ВОКРУГ КУРСОРА
     * (раньше — всегда хвост: курсор в середине не было видно);
     * вне фокуса — как раньше, хвост адреса. Отрезаем по СИМВОЛАМ. */
    int from = br_addr_view_from(b, max_chars);
    int tl = sl - from;
    if (tl < 0) tl = 0;
    if (tl > (int)sizeof(shown) - 2) tl = (int)sizeof(shown) - 2;
    memcpy(shown, src + from, (u32)tl);
    shown[tl] = 0;
    if (b->addr_focus) {
        /* мигающее подчёркивание ЗАМЕНЯЕТ символ под курсором
         * (классическое поведение линейного ввода); между фазами
         * мигания позиция курсора видна как вертикальная полоска.
         * Task 64 [TI-WIDGET]: курсор в СИМВОЛАХ — кириллица не рвётся:
         * '_' вставляется на байтовую границу cpos-го символа. */
        int cur = br_addr_clamp_cur(b, b->addr_ti.cur);
        int cpos = utf8_count_chars(src + from, cur - from);  /* символов до курсора */
        /* Session 95 [BR-FIX]: utf8_take_bytes уже даёт смещение ОТНОСИТЕЛЬНО
         * src+from (позиция в shown = копии src+from); вычитание from при
         * прокрутке адреса (from>0) уводило курсор за экран. */
        int bpos = utf8_take_bytes(src + from, sl - from, cpos);
        /* [BR-ADDRSEL]: плашка выделения ПОД текстом (пересечение с окном) */
        {
            int d0, d1;
            if (ti_sel_px(&b->addr_ti, from, max_chars, &d0, &d1)) {
                int sx = box_x + 6 + d0, sw = d1 - d0;
                if (sx < box_x + 2) { sw -= (box_x + 2) - sx; sx = box_x + 2; }
                if (sx + sw > box_x + box_w - 2) sw = box_x + box_w - 2 - sx;
                if (sw > 0)
                    fb_fill_rect(sx, box_y + 2, sw, box_h - 4, br_col_sel(b));
            }
        }
        if (bpos >= 0 && bpos <= tl) {
            /* [BR-ADDRSEL]: при активном выделении '_' НЕ вставляется
             * (сдвиг текста на клетку ломал бы плашку) — курсор-полоска */
            if (wm_blink() && !ti_sel_active(&b->addr_ti)) {
                memmove(shown + bpos + 1, shown + bpos, (u32)(tl - bpos) + 1);
                shown[bpos] = '_';
                tl++;
                shown[tl] = 0;
            }
            fb_text(box_x + 6, box_y + 1, shown,
                    br_col_text(b), -1);
            if (!wm_blink() || ti_sel_active(&b->addr_ti)) {
                int cx = box_x + 6 + cpos * 8;
                if (cx >= box_x + 2 && cx <= box_x + box_w - 2)
                    fb_fill_rect(cx, box_y + 2, 2, box_h - 4,
                                 br_col_text(b));
            }
        } else {
            fb_text(box_x + 6, box_y + 1, shown, br_col_text(b), -1);
        }
    } else {
        fb_text(box_x + 6, box_y + 1, shown, br_col_dim(b), -1);
    }

    if (!b->addr_focus && !b->addr[0] && !b->url[0])
        fb_text(box_x + 6, box_y + 1, "http://... или имя файла RAM disk",
                br_col_dim(b), -1);

    /* кнопки: Go — СРАЗУ ЗА адресной строкой (сессия 97), затем Тема
     * ([BR-THEME]), Save (сессия 67) и Back (сессия 55) */
    int go_x = cw - 192, go_y = 3, go_w = 44, go_h = 16;
    int sv_x = cw - 48, sv_w = 44;
    int bk_x = cw - 96, bk_w = 44;
    int th_x = cw - 144, th_w = 44;
    const char *th_lab = b->light ? "Тёмн" : "Свет";
    fb_fill_rect(go_x, go_y, go_w, go_h, br_col_btn(b));
    fb_rect(go_x, go_y, go_w, go_h, br_col_sep(b));
    fb_text(go_x + (go_w - 2 * 8) / 2, go_y + 1, "Go",
            br_col_text(b), -1);
    fb_fill_rect(sv_x, go_y, sv_w, go_h, br_col_btn(b));
    fb_rect(sv_x, go_y, sv_w, go_h, br_col_sep(b));
    fb_text(sv_x + (sv_w - 4 * 8) / 2, go_y + 1, "Save",
            br_col_text(b), -1);
    fb_fill_rect(bk_x, go_y, bk_w, go_h,
                 b->hist_n > 0 ? br_col_btn(b) : br_col_field(b));
    fb_rect(bk_x, go_y, bk_w, go_h, br_col_sep(b));
    fb_text(bk_x + (bk_w - 4 * 8) / 2, go_y + 1, "Back",
            b->hist_n > 0 ? br_col_text(b) : br_col_dim(b), -1);
    fb_fill_rect(th_x, go_y, th_w, go_h, br_col_btn(b));
    fb_rect(th_x, go_y, th_w, go_h, br_col_sep(b));
    fb_text(th_x + (th_w - 4 * 8) / 2, go_y + 1, th_lab,
            br_col_text(b), -1);

    /* --- контент --- */
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - BR_STATUS_H;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y, cw, area_h, br_col_bg(b));

    /* FIX (аудит): перенос строк по СИМВОЛАМ под текущую ширину окна
     * (при изменении размеров окно перестраивается автоматически) */
    br_ensure_lines(b, cw);

    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (b->scroll > max_scroll) b->scroll = max_scroll;
    if (b->scroll < 0) b->scroll = 0;

    int start = b->scroll;
    int end = start + vis;
    if (end > b->L.nlines) end = b->L.nlines;

    /* --- сессия 55: картинки рисуем ДО текста (они занимают свои
     * строки; текст на них не пишется, т.к. класс BRL_CLS_IMG
     * пропускается ниже) --- */
    int area_y2 = area_y + 2;
    int area_bot = area_y + area_h;
    for (int i = 0; i < b->page.nimgs; i++) {
        brp_img_t *im = &b->page.imgs[i];
        if (im->state != 1 || !im->rgba || im->dw <= 0 || im->dh <= 0)
            continue;
        int y_top = area_y2 + (im->row - start) * 16;
        int y_bot = y_top + im->dh;
        if (y_bot <= area_y2 || y_top >= area_bot) continue;  /* вне экрана */
        int dy = y_top > area_y2 ? y_top : area_y2;
        int src_y = dy - y_top;
        int h_vis = y_bot - dy;
        if (h_vis > area_bot - dy) h_vis = area_bot - dy;
        if (h_vis <= 0) continue;
        int x = (cw - im->dw) / 2;
        if (x < 2) x = 2;
        /* 1:1 blit видимой части (сдвиг источника при прокрутке) */
        fb_blit_rgba(im->rgba + (u32)src_y * (u32)im->dw * 4,
                     im->dw, h_vis, x, dy, im->dw, h_vis);
    }

    /* [BR-CODE]: плашки и рамки блоков кода — ДО текста (текст ляжет
     * сверху). Блок = сплошной прогон строк BRL_CLS_CODE; рамка по
     * краям прогона, но НЕ там, где блок продолжается за экраном
     * (проверяются cls строк ВНЕ видимого диапазона — рамка не
     * «прыгает» при прокрутке). */
    for (int i = start; i < end; i++) {
        if (!b->L.cls || b->L.cls[i] != BRL_CLS_CODE) continue;
        int j = i;
        while (j < end && b->L.cls[j] == BRL_CLS_CODE) j++;
        int top_cont = (i > 0 && b->L.cls[i - 1] == BRL_CLS_CODE);
        int bot_cont = (j < b->L.nlines && b->L.cls[j] == BRL_CLS_CODE);
        int y0 = area_y2 + (i - start) * 16;
        int y1 = area_y2 + (j - start) * 16;   /* низ последней строки */
        if (y0 < area_y) y0 = area_y;
        if (y1 > area_y + area_h) y1 = area_y + area_h;
        if (y1 <= y0) { i = j - 1; continue; }
        int fx1 = cw - 10;                     /* правее — полоса прокрутки */
        if (fx1 < 12) fx1 = 12;
        fb_fill_rect(2, y0, fx1 - 2, y1 - y0, br_col_code_bg(b));
        if (!top_cont) fb_hline(2, fx1 - 1, y0, br_col_code_border(b));
        if (!bot_cont) fb_hline(2, fx1 - 1, y1 - 1, br_col_code_border(b));
        fb_vline(2, y0, y1 - 1, br_col_code_border(b));
        fb_vline(fx1 - 1, y0, y1 - 1, br_col_code_border(b));
        i = j - 1;
    }

    /* нормализованное выделение (один раз на кадр) для подсветки */
    int sr0 = 0, sc0 = 0, sr1 = -1, sc1 = 0;
    if (b->sel_active) br_sel_norm(b, &sr0, &sc0, &sr1, &sc1);

    /* [BR-NAVCARET]: строка сфокусированной ссылки (рамка фокуса) */
    int nav_link_row = -1, nav_link_idx = -1;
    if (b->nav_i >= 0 && b->nav_row && b->nav_i < b->nav_n &&
        b->nav_kind[b->nav_i] == 0) {
        br_nav_rebuild(b);          /* строки могли перестроиться */
        if (b->nav_i < b->nav_n && b->nav_kind[b->nav_i] == 0) {
            nav_link_row = b->nav_row[b->nav_i];
            nav_link_idx = b->nav_idx[b->nav_i];
        }
    }

    int y = area_y + 2;
    for (int i = start; i < end; i++, y += 16) {
        u32 color = br_col_text(b);
        /* FIX (сессия 19): цвет по КЛАССУ строки отображения (brlines.h):
         * куски-продолжения переносной строки наследуют класс исходной,
         * поэтому длинный заголовок/пункт списка цветной ЦЕЛИКОМ —
         * раньше по первому символу куска цвет имели только первая
         * часть строки и следующий пункт, середина оставалась белой. */
        unsigned char cls = b->L.cls ? b->L.cls[i]
                                     : (b->L.lines[i][0] == '#' ? BRL_CLS_HEAD :
                                        b->L.lines[i][0] == '[' ? BRL_CLS_LINK :
                                        b->L.lines[i][0] == '-' ? BRL_CLS_LIST :
                                        BRL_CLS_TEXT);
        if (cls == BRL_CLS_HEAD)      color = br_col_head(b);        /* заголовки */
        else if (cls == BRL_CLS_LINK) color = br_col_accent(b);      /* ссылки */
        else if (cls == BRL_CLS_LIST) color = br_col_dim(b);         /* списки */
        else if (cls == BRL_CLS_CODE) color = br_col_code_text(b);   /* код */

        /* сессия 55: строки картинок — не текст; якорная строка
         * (BRP_IMG_MARK) неутверждённой картинки показывает заглушку */
        if (cls == BRL_CLS_IMG) {
            const char *ls = b->L.lines[i];
            if (ls[0] == BRP_IMG_MARK && ls[1] == 0) {
                brp_img_t *im = br_img_by_src(b, b->L.srcidx[i]);
                if (im && im->state == 1) {
                    /* картинка нарисована выше — текст не пишем */
                } else if (im && im->state == 0) {
                    fb_text(4, y, "(картинка: загрузка...)",
                            wm_theme_text_dim(), -1);
                } else {
                    /* Session 92 [BR-IMGALT]: подпись из alt */
                    char ph[96];
                    if (im && im->alt[0])
                        snprintf(ph, sizeof(ph),
                                 "[%s — картинка недоступна]", im->alt);
                    else
                        snprintf(ph, sizeof(ph), "[картинка недоступна]");
                    fb_text(4, y, ph, fb_rgb(0x88, 0x70, 0x70), -1);
                }
            }
            continue;
        }

        /* строки уже перенесены по ширине окна (br_ensure_lines);
         * UTF-8 внутри строки не разрезан. Ссылочные интервалы —
         * синим с подчёркиванием (сессия 56). */
        /* Session 93 [BR-JSDEFER]: якорь ОТЛОЖЕННОГО скрипта (\x04) —
         * пустая строка-заполнитель, не рисуем (снимется целиком
         * br_remove_script_anchors после исполнения всех скриптов) */
        if (b->L.lines[i][0] == BRJ_MARK && b->L.lines[i][1] == 0)
            continue;

        /* Task 47: строка-якорь поля формы — рисуем контрол */
        if (b->L.lines[i][0] == BRF_MARK && b->L.lines[i][1] == 0) {
            brf_field_t *fl = br_field_by_row(b, i);
            if (fl)
                br_draw_field(b, fl, y, cw);
            continue;
        }

        /* подсветка выделенной части строки (ПОД текстом): колонки в
         * СИМВОЛАХ, x = 4 + col*8 — та же арифметика, что в hit-тесте.
         * [BR-HEAD-2X]: у заголовков шаг 16px и '#'-префикс не рисуется —
         * колонки выделения (от мыши, с учётом префикса) переводятся в
         * пиксели с учётом того же; высота плашки — 2 строки (глиф 32px). */
        if (i >= sr0 && i <= sr1) {
            const char *ls = b->L.lines[i];
            int nc = utf8_count_chars(ls, -1);
            int a = (i == sr0) ? sc0 : 0;
            int z = (i == sr1) ? sc1 : nc;
            if (a < 0) a = 0;
            if (z > nc) z = nc;
            int scl = (cls == BRL_CLS_HEAD) ? 2 : 1;
            int pre = (scl == 2) ? br_head_prefix_len(ls) : 0;
            if (a < pre) a = pre;
            if (z > a)
                fb_fill_rect(4 + (a - pre) * 8 * scl, y,
                             (z - a) * 8 * scl, 16 * scl, br_col_sel(b));
        }
        br_draw_text_line(b, i, y, color,
                          (cls == BRL_CLS_HEAD) ? 2 : 1);

        /* [BR-NAVCARET]: рамка фокуса навигации вокруг ССЫЛКИ этой строки
         * (у полей рамку рисует br_draw_field по b->focus). Интервал
         * ссылки [b_abs, t_end_abs) пересекается с байтами куска —
         * та же арифметика, что в brp_link_segs. */
        if (i == nav_link_row && nav_link_idx >= 0 &&
            nav_link_idx < b->page.nlinks && b->page.line_off) {
            const brp_link_t *l = &b->page.links[nav_link_idx];
            int src2 = b->L.srcidx[i];
            if (src2 >= 0 && src2 < b->page.nlines) {
                int abs0 = b->page.line_off[src2] + b->L.srcoff[i];
                int plen = (int)strlen(b->L.lines[i]);
                int a = l->b_abs, z = l->t_end_abs;
                if (a < abs0) a = abs0;
                if (z > abs0 + plen) z = abs0 + plen;
                if (z > a) {
                    int c0 = brp_col_of_byte(b->L.lines[i], plen, a - abs0);
                    int c1 = brp_col_of_byte(b->L.lines[i], plen, z - abs0);
                    fb_rect(4 + c0 * 8 - 1, y - 1, (c1 - c0) * 8 + 2, 18,
                            br_col_accent(b));
                }
            }
        }
    }

    /* Session 92 [BR-DD]: раскрытый список select — ПОВЕРХ текста
     * (как выпадающее меню в настольных браузерах) */
    {
        int ddy = 0;
        int ddmax = br_dd_geom(b, ch, &ddy);
        if (ddmax > 0) {
            brf_field_t *dfl = &b->forms.fields[b->dd_field];
            int box_w = cw - 24;
            if (box_w < 120) box_w = 120;
            for (int k = 0; k < ddmax; k++) {
                int sel = (k == b->dd_cur);
                int oy = ddy + k * 16;
                fb_fill_rect(8, oy, box_w, 15,
                             sel ? br_col_accent(b) : br_col_field(b));
                fb_rect(8, oy, box_w, 15,
                        sel ? br_col_accent(b) : br_col_border(b));
                char line[52];
                snprintf(line, sizeof(line), "%s %s",
                         (k == dfl->opt_sel) ? "\xe2\x80\xa2" : " ",
                         dfl->opts[k]);
                fb_text(12, oy + 1, line,
                        sel ? br_col_btn(b) : br_col_text(b), -1);
            }
        }
    }

    /* полоса прокрутки — общий виджет wm_scrollbar (цвет из темы).
     * ПОРЯДОК ПОНЯТЕН: pos=0 — начало текста (ползунок сверху) */
    wm_scrollbar_draw(&b->sb, cw - 7, area_y + 2, 5, area_h - 4,
                      b->scroll, max_scroll, vis);

    /* --- статус-бар --- */
    fb_fill_rect(0, ch - BR_STATUS_H, cw, BR_STATUS_H, br_col_bg_alt(b));
    char st[112];
    if (b->find_mode) {
        /* Task 67 [BR-FIND]: в режиме поиска статус — мини-строка поиска */
        snprintf(st, sizeof(st), "Поиск: %s_  (Enter/F3 — далее, Esc — выход)",
                 b->find_q);
    } else if (b->hover[0])
        snprintf(st, sizeof(st), "ссылка: %s", b->hover);
    else
        snprintf(st, sizeof(st), "%s%s | прокрутка: %d/%d",
                 b->fetching ? "* " : "", b->status, b->scroll, max_scroll);
    fb_text(4, ch - BR_STATUS_H + 2, st, br_col_info(b), -1);

    /* Session 93 [BR-RETRY]/[BR-LAZY]: кнопки статус-бара (клики —
     * в br_mouse, геометрия повторяется там) */
    if (b->net_err && !b->fetching) {
        fb_fill_rect(cw - 92, ch - BR_STATUS_H + 1, 84, 12,
                     br_col_btn(b));
        fb_rect(cw - 92, ch - BR_STATUS_H + 1, 84, 12,
                fb_rgb(0xB0, 0x50, 0x50));
        fb_text(cw - 92 + (84 - 9 * 8) / 2, ch - BR_STATUS_H + 1,
                "Повторить", br_col_text(b), -1);
    }
    if (b->lazy_pending) {
        fb_fill_rect(cw - 180, ch - BR_STATUS_H + 1, 84, 12,
                     br_col_btn(b));
        fb_rect(cw - 180, ch - BR_STATUS_H + 1, 84, 12,
                br_col_accent(b));
        fb_text(cw - 180 + (84 - 9 * 8) / 2, ch - BR_STATUS_H + 1,
                "Догрузить", br_col_text(b), -1);
    }

    /* Session 93 [BR-ERRLOG]: оверлей журнала ошибок (Ctrl+E) */
    if (b->errlog_open) {
        int bw = cw - 24;
        if (bw > 88 * 8) bw = 88 * 8;
        if (bw < 200) bw = 200;
        int bh = 24 + BR_ERRLOG_N * 16 + 18;
        if (bh > ch - 8) bh = ch - 8;
        int bx = (cw - bw) / 2, by = (ch - bh) / 2;
        fb_fill_rect(bx, by, bw, bh, br_col_bg(b));
        fb_rect(bx, by, bw, bh, br_col_accent(b));
        fb_text(bx + 8, by + 4,
                "Последние ошибки (сеть / JS / конвертация)",
                br_col_text(b), -1);
        fb_hline(bx, bx + bw - 1, by + 19, br_col_border(b));
        int shown = b->errlog_n;
        int max_show = (bh - 24 - 18) / 16;
        if (max_show < 0) max_show = 0;
        if (shown > max_show) shown = max_show;
        for (int k = 0; k < shown; k++) {
            int idx = (b->errlog_head - b->errlog_n + k + 2 * BR_ERRLOG_N)
                      % BR_ERRLOG_N;
            fb_text(bx + 8, by + 24 + k * 16, b->errlog[idx],
                    br_col_info(b), -1);
        }
        if (b->errlog_n == 0)
            fb_text(bx + 8, by + 24, "ошибок нет",
                    br_col_dim(b), -1);
        {
            char hint[64];
            snprintf(hint, sizeof(hint), "Esc — закрыть (записей: %d)",
                     b->errlog_n);
            fb_text(bx + 8, by + bh - 15, hint, br_col_dim(b), -1);
        }
    }
}

/* ---------- ввод ---------- */

/* ---------- выделение и копирование (общий буфер, clipboard.h) ---------- */

/* Нормализованный диапазон выделения (r0<=r1; при равенстве c0<=c1),
 * границы clamp'ятся к числу строк/символов (строки могли перестроиться
 * при переносе под новую ширину окна). */
static void br_sel_norm(browser_t *b, int *r0, int *c0, int *r1, int *c1)
{
    int ar = b->sel_ar, ac = b->sel_ac, zr = b->sel_br, zc = b->sel_bc;
    if (b->L.nlines <= 0) { *r0 = *r1 = *c0 = *c1 = 0; return; }
    if (ar < 0) ar = 0;
    if (ar >= b->L.nlines) ar = b->L.nlines - 1;
    if (zr < 0) zr = 0;
    if (zr >= b->L.nlines) zr = b->L.nlines - 1;
    int na = utf8_count_chars(b->L.lines[ar], -1);
    int nz = utf8_count_chars(b->L.lines[zr], -1);
    if (ac < 0) ac = 0;
    if (ac > na) ac = na;
    if (zc < 0) zc = 0;
    if (zc > nz) zc = nz;
    if (ar < zr || (ar == zr && ac <= zc)) {
        *r0 = ar; *c0 = ac; *r1 = zr; *c1 = zc;
    } else {
        *r0 = zr; *c0 = zc; *r1 = ar; *c1 = ac;
    }
}

/* ---------- Task 64 [TI-WIDGET]: адресная строка на общем виджете ---------- */

/* Синхронизировать виджет после ВНЕШНЕЙ правки b->addr (strncpy из
 * навигации/истории): длина — по строке, курсор — в конец. */
static void ti_sync(ti_t *ti)
{
    ti->len = (int)strlen(ti->buf);
    ti->cur = ti->len;
    ti->view_off = 0;
    ti->rejected = 0;
}

/* Задать фокус поля формы и привязать редактор виджета к fl->value
 * (Task 64 [TI-WIDGET]): пароль — '*', textarea — многострочный,
 * курсор — в конец существующего значения. idx < 0 — снять фокус. */
static void br_focus_field(browser_t *b, int idx)
{
    b->focus = idx;
    if (idx < 0 || idx >= b->forms.nfields) return;
    brf_field_t *fl = &b->forms.fields[idx];
    int text_like = !strcmp(fl->type, "text") ||
                    !strcmp(fl->type, "password") ||
                    !strcmp(fl->type, "search") ||
                    !strcmp(fl->type, "textarea");
    if (!text_like) return;                 /* чекбоксы/кнопки — без редактора */
    ti_init(&b->field_ti, fl->value, BRF_VAL_MAX);
    ti_reset(&b->field_ti, fl->value);
    b->field_ti.password = !strcmp(fl->type, "password");
    b->field_ti.multiline = !strcmp(fl->type, "textarea");
    b->field_ti.paste_fn = clip_text_get;
    b->field_ti.copy_fn = ti_clip_set;      /* [TI-SEL] Ctrl+C/X в поле */
    /* [BR-NAVCARET]: Tab/клик по полю синхронизируют «каретку» навигации —
     * стрелки продолжат с этого элемента, а не с нуля */
    b->nav_i = br_nav_find_field(b, idx);
}

/* Клемп позиции курсора к длине адреса (после внешних изменений addr). */
static int br_addr_clamp_cur(const browser_t *b, int cur)
{
    if (cur < 0) cur = 0;
    if (cur > b->addr_ti.len) cur = b->addr_ti.len;
    return cur;
}

/* Начало видимого окна адреса (в БАЙТАХ). Не-фокус: хвост адреса
 * (как раньше); фокус: окно видимости виджета вокруг курсора —
 * в СИМВОЛАХ (кириллица не рвётся). */
static int br_addr_view_from(const browser_t *b, int max_chars)
{
    const char *src = b->addr_focus ? b->addr
                                    : (b->addr[0] ? b->addr : b->url);
    if (!b->addr_focus) {
        int total = utf8_count_chars(src, -1);
        if (total > max_chars)
            return utf8_take_bytes(src, -1, total - max_chars);
        return 0;
    }
    return ti_view_off((ti_t *)&b->addr_ti, max_chars);
}

/* Скопировать выделенный текст в общий буфер обмена (строки — через
 * '\n'; пустое выделение — ничего). Статус — сколько скопировано. */
static void br_sel_copy(browser_t *b)
{
    if (!b->sel_active || !b->L.lines) return;
    int r0, c0, r1, c1;
    br_sel_norm(b, &r0, &c0, &r1, &c1);

    int total = 0;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a)
            total += utf8_take_bytes(ls, -1, z) - utf8_take_bytes(ls, -1, a);
        if (r < r1) total++;
    }
    if (total <= 0) return;

    char *buf = (char *)malloc((u32)total + 1);
    if (!buf) return;
    char *p = buf;
    for (int r = r0; r <= r1; r++) {
        const char *ls = b->L.lines[r];
        int nc = utf8_count_chars(ls, -1);
        int a = (r == r0) ? c0 : 0;
        int z = (r == r1) ? c1 : nc;
        if (a < 0) a = 0;
        if (z > nc) z = nc;
        if (z > a) {
            int b0 = utf8_take_bytes(ls, -1, a);
            int b1 = utf8_take_bytes(ls, -1, z);
            memcpy(p, ls + b0, (u32)(b1 - b0));
            p += b1 - b0;
        }
        if (r < r1) *p++ = '\n';
    }
    *p = 0;
    clip_text_set(buf, total);
    free(buf);
    snprintf(b->status, sizeof(b->status),
             "Скопировано %d симв. (Ctrl+V — в редактор)", total);
}

/* ---------- [BR-NAVCARET] (сессия 100): навигация стрелками ----------
 * Запрос: «переработай навигацию стрелками по странице — она должна
 * проматывать страницу и при этом переключаться по кнопкам и ссылкам».
 *
 * Модель «каретки» (как в Lynx/каретном просмотре): Down/Up переходят
 * к СЛЕДУЮЩЕМУ/ПРЕДЫДУЩЕМУ интерактивному элементу (ссылка, кнопка,
 * поле, чекбокс, select) с автопрокруткой к нему; элементы кончились —
 * стрелки продолжают чистую прокрутку. PgUp/PgDn/Home/End — прокрутка
 * как прежде, Enter открывает сфокусированную ссылку.
 *
 * Список строится лениво по строкам ОТОБРАЖЕНИЯ (b->L): ссылка
 * записывается на строку, где НАЧИНАЕТСЯ её видимый текст (перенос
 * длинной ссылки продолжает строку без новой записи), строка-якорь
 * \x03 поля форм — записью поля. И ссылки (brp_analyze), и строки
 * отображения отсортированы по позиции в md — хватает одного слияния. */
static void br_nav_push(browser_t *b, int row, u8 kind, int idx)
{
    if (b->nav_n >= b->nav_cap) {
        int ncap = b->nav_cap ? b->nav_cap * 2 : 64;
        /* realloc в куче ОС нет (как в brl_push) — удвоение вручную */
        int *nr = (int *)malloc((u32)ncap * sizeof(int));
        u8  *nk = (u8 *)malloc((u32)ncap);
        int *ni = (int *)malloc((u32)ncap * sizeof(int));
        if (!nr || !nk || !ni) {
            free(nr); free(nk); free(ni);
            return;
        }
        if (b->nav_row) {
            memcpy(nr, b->nav_row, (u32)b->nav_n * sizeof(int));
            memcpy(nk, b->nav_kind, (u32)b->nav_n);
            memcpy(ni, b->nav_idx, (u32)b->nav_n * sizeof(int));
            free(b->nav_row); free(b->nav_kind); free(b->nav_idx);
        }
        b->nav_row = nr;
        b->nav_kind = nk;
        b->nav_idx = ni;
        b->nav_cap = ncap;
    }
    b->nav_row[b->nav_n] = row;
    b->nav_kind[b->nav_n] = kind;
    b->nav_idx[b->nav_n] = idx;
    b->nav_n++;
}

static void br_nav_rebuild(browser_t *b)
{
    if (b->nav_row && b->nav_gen == b->wrap_gen) return;
    b->nav_n = 0;
    b->nav_gen = b->wrap_gen;
    if (!b->L.lines || b->L.nlines <= 0 || !b->L.srcidx) {
        b->nav_i = -1;
        return;
    }
    int lj = 0;    /* курсор по ссылкам: отсортированы по (src_idx, b_abs) */
    int nlinks = b->page.nlinks;
    for (int r = 0; r < b->L.nlines; r++) {
        const char *piece = b->L.lines[r];
        /* строка-якорь поля формы */
        if (piece[0] == BRF_MARK && piece[1] == 0) {
            brf_field_t *fl = br_field_by_row(b, r);
            if (fl && strcmp(fl->type, "hidden") != 0)
                br_nav_push(b, r, 1, (int)(fl - b->forms.fields));
            continue;
        }
        /* ссылки, НАЧИНАЮЩИЕСЯ в этой строке отображения */
        if (nlinks <= 0 || !b->page.line_off) continue;
        int src = b->L.srcidx[r];
        if (src < 0 || src >= b->page.nlines) continue;
        int base = b->page.line_off[src] + b->L.srcoff[r];
        int plen = (int)strlen(piece);
        while (lj < nlinks) {
            const brp_link_t *l = &b->page.links[lj];
            if (l->src_idx < src ||
                (l->src_idx == src && l->b_abs < base)) {
                lj++;                       /* ссылка кончилась левее */
                continue;
            }
            break;
        }
        for (int k = lj; k < nlinks; k++) {
            const brp_link_t *l = &b->page.links[k];
            if (l->src_idx != src || l->b_abs >= base + plen) break;
            if (l->b_abs >= base)
                br_nav_push(b, r, 0, k);
        }
    }
    if (b->nav_i >= b->nav_n) b->nav_i = -1;
}

/* Найти элемент списка, соответствующий полю fidx (для синхронизации
 * Tab/клика со стрелками). -1 = поля в списке нет. */
static int br_nav_find_field(browser_t *b, int fidx)
{
    if (fidx < 0) return -1;
    br_nav_rebuild(b);
    for (int i = 0; i < b->nav_n; i++)
        if (b->nav_kind[i] == 1 && b->nav_idx[i] == fidx) return i;
    return -1;
}

/* Прокрутка так, чтобы строка row была видна (с одной строкой контекста). */
static void br_nav_ensure_visible(browser_t *b, int row, int vis)
{
    int maxs = b->L.nlines - vis;
    if (maxs < 0) maxs = 0;
    if (row < b->scroll)
        b->scroll = row > 0 ? row - 1 : 0;
    else if (row >= b->scroll + vis)
        b->scroll = row - vis + 1;
    if (b->scroll > maxs) b->scroll = maxs;
    if (b->scroll < 0) b->scroll = 0;
}

/* Сфокусировать элемент i: подсветка, статус, прокрутка к нему. */
static void br_nav_apply(browser_t *b, int i, int vis)
{
    br_nav_rebuild(b);
    if (i < 0 || i >= b->nav_n || !b->nav_row) {
        b->nav_i = -1;
        return;
    }
    b->nav_i = i;
    if (b->nav_kind[i] == 1) {
        br_focus_field(b, b->nav_idx[i]);   /* рамка фокуса рисует поле */
        b->hover[0] = 0;
    } else {
        if (b->focus >= 0) br_focus_field(b, -1);   /* снять редактор поля */
        const brp_link_t *l = &b->page.links[b->nav_idx[i]];
        snprintf(b->hover, sizeof(b->hover), "%s", l->url);  /* статус */
    }
    br_nav_ensure_visible(b, b->nav_row[i], vis);
}

/* Шаг навигации стрелкой: dir = +1 (вниз) / -1 (вверх). */
static void br_nav_move(browser_t *b, int dir, int vis)
{
    br_nav_rebuild(b);
    int step = vis < WM_KEY_SCROLL_LINES ? vis : WM_KEY_SCROLL_LINES;
    if (b->nav_n <= 0 || !b->nav_row) {
        /* элементов нет — чистая прокрутка (как прежде) */
        int maxs = b->L.nlines - vis;
        if (maxs < 0) maxs = 0;
        b->scroll += dir * step;
        if (b->scroll > maxs) b->scroll = maxs;
        if (b->scroll < 0) b->scroll = 0;
        return;
    }
    if (b->nav_i < 0 || b->nav_i >= b->nav_n) {
        /* фокуса ещё нет: первый видимый (вниз) / последний видимый (вверх);
         * на экране элементов нет — ближайший в направлении движения */
        int pick = -1;
        if (dir > 0) {
            for (int i = 0; i < b->nav_n; i++)
                if (b->nav_row[i] >= b->scroll) { pick = i; break; }
            if (pick < 0) pick = b->nav_n - 1;
        } else {
            for (int i = b->nav_n - 1; i >= 0; i--)
                if (b->nav_row[i] < b->scroll + vis) { pick = i; break; }
            if (pick < 0) pick = 0;
        }
        br_nav_apply(b, pick, vis);
        return;
    }
    int ni = b->nav_i + dir;
    if (ni < 0 || ni >= b->nav_n) {
        /* край списка — страница продолжается текстом: прокрутка */
        int maxs = b->L.nlines - vis;
        if (maxs < 0) maxs = 0;
        b->scroll += dir * step;
        if (b->scroll > maxs) b->scroll = maxs;
        if (b->scroll < 0) b->scroll = 0;
        return;
    }
    br_nav_apply(b, ni, vis);
}

/* ---------- [BR-PAGEMENU] (сессия 99): контекстное меню страницы ----------
 * Запрос: «добавь в контекстное меню кнопки "сохранить как md" и
 * "сохранить как html"». ПКМ по тексту страницы открывает меню:
 *   Копировать текст    — выделение в буфер обмена (br_sel_copy);
 *   ────────────
 *   Сохранить как md    — Markdown «КАК ЕСТЬ» (см. br_save_md_file);
 *   Сохранить как html  — HTML-исходник ответа (b->src, см. ниже).
 * Массив пунктов СТАТИЧЕСКИЙ: wm_menu_open хранит указатель и читает
 * его после возврата (отрисовка в композиторе, hit-тест кликов) —
 * стековый массив дал бы висячий указатель ([TI-MENU-STATIC]). */
#define BR_MNU_COPY     1
#define BR_MNU_SAVEMD   2
#define BR_MNU_SAVEHTML 3
static wm_menu_item_t g_br_page_menu[4];

/* [BR-PAGEMENU]: сохранить Markdown страницы «КАК ЕСТЬ» — вместе со
 * ВСЕМИ служебными маркерами конвейера (\x01 — поля форм, \x03/\x04 —
 * якоря скриптов, разметка ссылок [t](u), байты стилей), БЕЗ чистки
 * (brf_scrub) и без подстановок. Такой дамп — «рентген» того, что
 * браузер ПОЛУЧИЛ после html_to_md: по нему видно, где потерялись
 * структура (таблицы/поля/код) и откуда взялись битые маркеры.
 * Файл кладётся в RAM disk, существующие имена не перезаписываются. */
static void br_save_md_file(browser_t *b)
{
    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];

    if (!b->md || b->md_len <= 0) {
        snprintf(b->status, sizeof(b->status), "Нечего сохранять (md)");
        win_invalidate(b->win);
        return;
    }
    br_save_derive_stem(b->url, stem, (int)sizeof(stem));
    if (!br_save_free_name_ext(stem, "md", name, (int)sizeof(name))) {
        snprintf(b->status, sizeof(b->status), "Нет свободного имени");
        win_invalidate(b->win);
        return;
    }
    ramfs_delete(name);
    if (!ramfs_create(name, (u32)b->md_len + 1) ||
        !ramfs_write(name, b->md, (u32)b->md_len + 1)) {
        snprintf(b->status, sizeof(b->status), "Ошибка записи RAM disk");
        win_invalidate(b->win);
        return;
    }
    snprintf(b->status, sizeof(b->status),
             "Сохранён md: %s (%d байт, с маркерами \\x01/\\x03)",
             name, b->md_len + 1);
    win_invalidate(b->win);
}

/* [BR-SAVEHTML2] (сессия 100): перекачать исходник текущей страницы.
 * Страницы ПОТОКОВОЙ загрузки (обычные сайты) исходник в памяти НЕ
 * держат: тело собрано по кускам конвертером, копия до 512 КиБ дорога.
 * Запрос: «html из браузера не сохраняется (если его нет в памяти —
 * можно по крайней мере его перекачать при сохранении)». Синхронный GET
 * того же адреса (редиректы — до BR_REDIR_MAX, как в навигации), тело —
 * уже распакованное (net_http_get_gzip). Возвращает malloc-буфер
 * (NUL-терминированный, заголовки срезаны) или NULL. */
static char *br_refetch_html(browser_t *b, int *out_len)
{
    char host[128], path[256];
    u16 port = 80;
    int use_tls = 0;
    const char *p = b->url;
    char *resp;

    *out_len = 0;
    if (br_ci_ncmp(p, "https://", 8) == 0)      { p += 8; use_tls = 1; }
    else if (br_ci_ncmp(p, "http://", 7) == 0)  { p += 7; }
    else return NULL;                           /* не http(s) — не перекачать */
    if (!br_split_url(p, use_tls, host, (int)sizeof(host), &port,
                      path, (int)sizeof(path)) || !host[0])
        return NULL;

    resp = (char *)malloc(BR_SRC_MAX + 8192);
    if (!resp) return NULL;

    for (int redirs = 0; redirs <= BR_REDIR_MAX; redirs++) {
        snprintf(b->status, sizeof(b->status),
                 "Сохранение: перекачка %s://%s:%u%s...",
                 use_tls ? "https" : "http", host, (unsigned)port, path);
        win_invalidate(b->win);
        br_render_now(b);
        b->fetching = 1;
        int n = net_http_get_gzip(host, port, path, resp,
                                  BR_SRC_MAX + 8192, 20000);
        b->fetching = 0;
        if (n <= 0) { free(resp); return NULL; }

        int code = 0;
        char loc[512];
        if (redirs < BR_REDIR_MAX &&
            br_parse_redirect(resp, n, &code, loc, (int)sizeof(loc))) {
            char base[448], abs[512];
            snprintf(base, sizeof(base), "%s://%s:%u%s",
                     use_tls ? "https" : "http", host, (unsigned)port, path);
            img_url_resolve(base, loc, abs, (int)sizeof(abs));
            p = abs;
            use_tls = 0;
            if (br_ci_ncmp(p, "https://", 8) == 0)      { p += 8; use_tls = 1; }
            else if (br_ci_ncmp(p, "http://", 7) == 0)  { p += 7; }
            if (!br_split_url(p, use_tls, host, (int)sizeof(host), &port,
                              path, (int)sizeof(path))) {
                free(resp);
                return NULL;
            }
            continue;
        }

        /* заголовки долой; остаться должен HTML (иначе «страница — не HTML») */
        const char *body = resp;
        int blen = n;
        br_strip_headers(body, blen, &body, &blen);
        int is_html = 0;
        for (int i = 0; i < blen && i < 200; i++)
            if (body[i] == '<') { is_html = 1; break; }
        if (!is_html) { free(resp); return NULL; }
        if (blen > 0)
            memmove(resp, body, (u32)blen);
        resp[blen] = 0;
        *out_len = blen;
        return resp;
    }
    free(resp);
    return NULL;
}

/* [BR-PAGEMENU]: сохранить HTML-исходник страницы как .html. Есть в
 * памяти (b->src — буферизованный путь) — пишем его; нет (потоковая
 * загрузка) — перекачиваем при сохранении ([BR-SAVEHTML2]). */
static void br_save_html_file(browser_t *b)
{
    char stem[RAMFS_NAME_MAX + 1];
    char name[RAMFS_NAME_MAX + 8];
    char *use = b->src;
    int   use_len = b->src_len;
    char *fetched = NULL;

    if (!(use && use_len > 0)) {
        int flen = 0;
        fetched = br_refetch_html(b, &flen);
        if (!fetched || flen <= 0) {
            snprintf(b->status, sizeof(b->status),
                     "HTML-исходник недоступен (не http(s) или не HTML)");
            win_invalidate(b->win);
            return;
        }
        use = fetched;
        use_len = flen;
    }
    br_save_derive_stem(b->url, stem, (int)sizeof(stem));
    if (!br_save_free_name_ext(stem, "html", name, (int)sizeof(name))) {
        snprintf(b->status, sizeof(b->status), "Нет свободного имени");
        if (fetched) free(fetched);
        win_invalidate(b->win);
        return;
    }
    ramfs_delete(name);
    if (!ramfs_create(name, (u32)use_len + 1) ||
        !ramfs_write(name, use, (u32)use_len + 1)) {
        snprintf(b->status, sizeof(b->status), "Ошибка записи RAM disk");
        if (fetched) free(fetched);
        win_invalidate(b->win);
        return;
    }
    if (fetched)
        snprintf(b->status, sizeof(b->status),
                 "Сохранён html: %s (%d байт, перекачан)", name, use_len + 1);
    else
        snprintf(b->status, sizeof(b->status),
                 "Сохранён html: %s (%d байт)", name, use_len + 1);
    if (fetched) free(fetched);
    win_invalidate(b->win);
}

/* Колбэк меню страницы: исполняется в ПОТОКЕ ОКНА (WEV_MENU) —
 * данные браузера трогаем без блокировок. */
static void br_page_menu_cb(int id, void *uctx)
{
    browser_t *b = (browser_t *)uctx;
    if (id == BR_MNU_COPY) {
        br_sel_copy(b);
    } else if (id == BR_MNU_SAVEMD) {
        br_save_md_file(b);
        return;                    /* статус уже отрисован внутри */
    } else if (id == BR_MNU_SAVEHTML) {
        br_save_html_file(b);
        return;
    } else {
        return;
    }
    win_invalidate(b->win);
}

/* Открыть меню страницы (ПКМ по контенту мимо полей форм). */
static void br_page_menu_open(browser_t *b, window_t *w, int mx, int my)
{
    g_br_page_menu[0].label    = "Копировать текст";
    g_br_page_menu[0].id       = BR_MNU_COPY;
    g_br_page_menu[0].disabled = (u8)(!b->sel_active);
    g_br_page_menu[1].label    = NULL;          /* разделитель */
    g_br_page_menu[1].id       = 0;
    g_br_page_menu[1].disabled = 0;
    g_br_page_menu[2].label    = "Сохранить как md";
    g_br_page_menu[2].id       = BR_MNU_SAVEMD;
    g_br_page_menu[2].disabled = (u8)(!b->md || b->md_len <= 0);
    g_br_page_menu[3].label    = "Сохранить как html";
    g_br_page_menu[3].id       = BR_MNU_SAVEHTML;
    /* [BR-SAVEHTML2]: исходник в памяти ИЛИ страница http(s) — тогда
     * сохранение перекачает исходник; для локальных md/файлов — серый */
    g_br_page_menu[3].disabled = (u8)(
        !((b->src && b->src_len > 0) ||
          br_ci_ncmp(b->url, "http://", 7) == 0 ||
          br_ci_ncmp(b->url, "https://", 8) == 0));
    b->sel_drag = 0;
    wm_menu_open(w, mx, my, g_br_page_menu, 4, br_page_menu_cb, b);
}

static void br_key(window_t *w, const key_event_t *ev)
{
    browser_t *b = (browser_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    /* Task 62 [BR-UPLOAD]: пока открыт диалог выбора файла — окно
     * ввод не получает (диалог модален, как в редакторе/плеере) */
    if (b->file_dlg) return;

    /* Session 93 [BR-ERRLOG]: открыт журнал ошибок — Esc/Ctrl+E закрывают,
     * прочие клавиши глотаются (модальный оверлей) */
    if (b->errlog_open) {
        if (ev->ch == 0x1B || ev->code == 0x01 ||
            ((ev->flags & KF_CTRL) &&
             (ev->ch == 'e' || ev->ch == 'E' || ev->ch == 0x05))) {
            b->errlog_open = 0;
            win_invalidate(w);
        }
        return;
    }

    /* Session 93 [BR-ERRLOG]: Ctrl+E — журнал ошибок (сеть/JS/конвертация) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'e' || ev->ch == 'E' || ev->ch == 0x05)) {
        b->errlog_open = 1;
        win_invalidate(w);
        return;
    }

    /* Ctrl+S — сохранить страницу в RAM disk (сессия 67) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 's' || ev->ch == 'S' || ev->ch == 0x13)) {
        br_save_page(b);
        return;
    }

    /* Ctrl+L — фокус на адресную строку (как в больших браузерах).
     * [BR-FOCUSADDR] (сессия 101, ФИКС «выбор попал на поле ввода —
     * ввод всегда идёт в поле, до адресной строки не добраться»):
     * снимаем фокус с поля страницы (и раскрытый select) — прежде поле
     * оставалось сфокусированным: ветка поля стоит выше ветки адреса и
     * глотала ввод, Ctrl+L «не работала». */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'l' || ev->ch == 'L' || ev->ch == 0x0C)) {
        if (b->focus >= 0) br_focus_field(b, -1);
        b->dd_open = 0;
        b->addr_focus = 1;
        ti_sel_clear(&b->addr_ti);    /* [BR-ADDRSEL] */
        ti_end(&b->addr_ti);          /* Task 64 [TI-WIDGET]: курсор в конец */
        win_invalidate(w);
        return;
    }

    /* Task 67 [BR-FIND]: Ctrl+F — поиск по странице (мини-режим ввода) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'f' || ev->ch == 'F' || ev->ch == 0x06)) {
        b->find_mode = 1;
        b->find_q[0] = 0;
        snprintf(b->status, sizeof(b->status),
                 "Поиск: (Enter — искать, Esc — выход)");
        win_invalidate(w);
        return;
    }

    /* Task 67 [BR-RELOAD]: F5 / Ctrl+R — перезагрузка страницы */
    if (ev->code == 0x3F ||
        ((ev->flags & KF_CTRL) &&
         (ev->ch == 'r' || ev->ch == 'R' || ev->ch == 0x12))) {
        br_reload(b);
        return;
    }

    /* Session 93 [BR-JSDEFER]: первое взаимодействие — исполнить
     * отложенные скрипты (некритичные: счётчики, обработчики). Если
     * скрипт увёл навигацией — клавишу не продолжаем. */
    if (br_page_scripts_resume(b))
        return;

    /* Task 67 [BR-FWD]: Alt+Left — назад, Alt+Right — вперёд */
    if (ev->flags & KF_ALT) {
        if (ev->code == KBD_LEFT) { br_go_back(b); return; }
        if (ev->code == KBD_RIGHT) { br_go_forward(b); return; }
    }

    /* Task 67 [BR-FIND]: ввод запроса — высший приоритет после Ctrl-хоткеев */
    if (b->find_mode) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            br_find_stop(b);
            snprintf(b->status, sizeof(b->status), "Поиск закрыт");
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n' || ev->code == 0x3D) {
            /* Enter или F3 — следующее совпадение */
            br_find_next(b, b->scroll + 1);
            return;
        }
        if (ev->code == 0x0E) {                            /* Backspace */
            /* отрезать последний СИМВОЛ (UTF-8) */
            int L = (int)strlen(b->find_q);
            while (L > 0 && ((unsigned char)b->find_q[L - 1] & 0xC0) == 0x80)
                L--;
            if (L > 0) L--;
            b->find_q[L] = 0;
            if (b->find_q[0]) br_find_next(b, b->scroll);
            else win_invalidate(w);
            return;
        }
        if (ev->ch >= 32 && ev->code != 0x39) {            /* печатный */
            int L = (int)strlen(b->find_q);
            if (L + 1 < BR_FIND_MAX + 1 && (unsigned char)ev->ch >= 32) {
                b->find_q[L] = ev->ch;
                b->find_q[L + 1] = 0;
                br_find_next(b, b->scroll);
                return;
            }
            win_invalidate(w);
            return;
        }
        /* прочие клавиши (стрелки и т.п.) — прокрутка ниже */
    }

    /* Ctrl+C — скопировать выделенный текст (буфер общий с редактором;
    * вставка — Ctrl+V в редакторе). Только вне режима адреса. */
    if ((ev->flags & KF_CTRL) && !b->addr_focus &&
        (ev->ch == 'c' || ev->ch == 'C' || ev->code == 0x2E)) {
        br_sel_copy(b);
        win_invalidate(w);
        return;
    }

    /* ---- Task 47: редактирование поля формы ----
     * [BR-FOCUSADDR] (сессия 101): пока редактируется адресная строка
     * (addr_focus), поле страницы ввод не глотает — все клавиши уходят
     * в ветку адреса ниже. Прежде эта ветка стояла ВЫШЕ и перехватывала
     * печать даже при открытом адресе: «фокус» на адресной строке не
     * давал ввода. Ctrl+L/клик по адресу теперь ещё и снимают фокус
     * поля (см. выше), так что случай addr_focus+поле — редкий, но
     * корректный. */
    if (!b->addr_focus && b->focus >= 0 && b->focus < b->forms.nfields) {
        brf_field_t *fl = &b->forms.fields[b->focus];
        if (ev->code == 0x0F) {                       /* Tab — следующее поле */
            b->dd_open = 0;                           /* [BR-DD] */
            int k = b->focus;
            for (int step = 0; step < b->forms.nfields; step++) {
                k = (k + 1) % b->forms.nfields;
                if (strcmp(b->forms.fields[k].type, "hidden") != 0)
                    break;
            }
            br_focus_field(b, k);         /* [TI-WIDGET]: перепривязка */
            win_invalidate(w);
            return;
        }
        /* Session 92 [BR-DD]: select — псевдографический выпадающий
         * список: Up/Down — курсор, Enter/Space — открыть/подтвердить,
         * Esc — свернуть (или снять фокус, если закрыт) */
        if (!strcmp(fl->type, "select")) {
            if (ev->ch == 0x1B || ev->code == 0x01) {
                if (b->dd_open && b->dd_field == b->focus) {
                    b->dd_open = 0;
                    win_invalidate(w);
                    return;
                }
                br_focus_field(b, -1);
                win_invalidate(w);
                return;
            }
            if (ev->code == KBD_UP || ev->code == KBD_DOWN) {
                if (!b->dd_open || b->dd_field != b->focus) {
                    b->dd_open = 1;
                    b->dd_field = b->focus;
                    b->dd_cur = fl->opt_sel >= 0 ? fl->opt_sel : 0;
                } else {
                    b->dd_cur += (ev->code == KBD_DOWN) ? 1 : -1;
                    if (b->dd_cur < 0) b->dd_cur = 0;
                    if (b->dd_cur >= fl->nopts) b->dd_cur = fl->nopts - 1;
                }
                win_invalidate(w);
                return;
            }
            if (ev->code == 0x1C || ev->ch == '\n' ||
                (ev->code == 0x39 && !(ev->flags & KF_CTRL))) {
                if (!b->dd_open || b->dd_field != b->focus) {
                    b->dd_open = 1;
                    b->dd_field = b->focus;
                    b->dd_cur = fl->opt_sel >= 0 ? fl->opt_sel : 0;
                } else {
                    if (fl->nopts > 0 && b->dd_cur >= 0 &&
                        b->dd_cur < fl->nopts)
                        fl->opt_sel = b->dd_cur;
                    b->dd_open = 0;
                }
                win_invalidate(w);
                return;
            }
        } else if (b->dd_open) {
            b->dd_open = 0;               /* ушли на другое поле */
        }
        /* [BR-NAVCARET]: ВВЕРХ/ВНИЗ покидают поле и продолжают навигацию
         * по странице (прокрутка + переключение элементов). Раньше
         * стрелки в поле глотались — «застревал» в нём. Select —
         * исключение: его Up/Down выше открыли/двигают список. */
        if ((ev->code == KBD_UP || ev->code == KBD_DOWN) &&
            strcmp(fl->type, "select") != 0) {
            int vis2 = (win_content_h(w) - BR_HDR - BR_STATUS_H) / 16;
            if (vis2 < 1) vis2 = 1;
            br_nav_move(b, ev->code == KBD_DOWN ? 1 : -1, vis2);
            win_invalidate(w);
            if (b->lazy_pending) {        /* как в конце br_key */
                int maxs2 = b->L.nlines - vis2;
                if (maxs2 < 0) maxs2 = 0;
                if (maxs2 > 0 && b->scroll >= maxs2)
                    br_lazy_convert(b);
            }
            return;
        }
        if (ev->ch == 0x1B || ev->code == 0x01) {     /* Esc — снять фокус */
            br_focus_field(b, -1);
            win_invalidate(w);
            return;
        }
        /* Task 64 [TI-WIDGET]: редактирование текстовых полей — общий
         * виджет (курсор в СИМВОЛАХ, Backspace/Delete по символу,
         * кириллица UTF-8, Ctrl+V, textarea — Enter добавляет строку). */
        {
            int text_like = !strcmp(fl->type, "text") ||
                            !strcmp(fl->type, "password") ||
                            !strcmp(fl->type, "search") ||
                            !strcmp(fl->type, "textarea");
            if (text_like) {
                int r = ti_key(&b->field_ti, ev);
                if (r == TI_K_EATEN) { win_invalidate(w); return; }
                if (r == TI_K_ENTER) {
                    /* textarea уходит через multiline-режим виджета;
                     * сюда попадают только однострочные поля */
                    br_form_submit(b, fl->form);
                    return;
                }
                if (r == TI_K_ESC) {
                    br_focus_field(b, -1);
                    win_invalidate(w);
                    return;
                }
                /* TI_K_IGNORE — упадёт в Space/активацию ниже */
            }
        }
        if (ev->code == 0x1C || ev->ch == '\n') {     /* Enter */
            /* не-текстовые поля: активировать (как раньше; текстовые
             * уходят через виджет выше) */
            br_field_activate(b, fl);
            return;
        }
        if (ev->code == 0x39 && !(ev->flags & KF_CTRL)) {   /* Space */
            if (strcmp(fl->type, "text") != 0 &&
                strcmp(fl->type, "password") != 0 &&
                strcmp(fl->type, "search") != 0 &&
                strcmp(fl->type, "textarea") != 0) {
                br_field_activate(b, fl);
                win_invalidate(w);
                return;
            }
        }
        return;   /* прочие клавиши в поле — игнор */
    }

    /* Tab — фокус на первое поле формы */
    if (ev->code == 0x0F) {
        for (int k = 0; k < b->forms.nfields; k++) {
            if (strcmp(b->forms.fields[k].type, "hidden") != 0) {
                br_focus_field(b, k);     /* [TI-WIDGET] */
                win_invalidate(w);
                return;
            }
        }
    }

    /* --- режим редактирования адреса --- */
    if (b->addr_focus) {
        if (ev->ch == 0x1B || ev->code == 0x01) {          /* Esc */
            b->addr_focus = 0;
            ti_sel_clear(&b->addr_ti);       /* [BR-ADDRSEL] */
            win_invalidate(w);
            return;
        }
        if (ev->code == 0x1C || ev->ch == '\n') {          /* Enter */
            br_navigate(b, b->addr);
            return;
        }
        /* Task 67 [BR-TABAC]: Tab — автодополнение из истории: ближайшая
         * ПОСЛЕДНЯЯ запись, начинающаяся с введённого префикса */
        if (ev->code == 0x0F && b->addr[0]) {
            for (int k = b->hist_n - 1; k >= 0; k--) {
                const char *h = b->hist[k];
                int i = 0;
                while (h[i] && b->addr[i]) {
                    char a = h[i], c = b->addr[i];
                    if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
                    if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
                    if (a != c) break;
                    i++;
                }
                if (b->addr[i] == 0 && h[i]) {
                    /* префикс сошёлся — дополнить (влезает в addr?) */
                    if ((int)strlen(h) <= BR_ADDR_MAX) {
                        strcpy(b->addr, h);
                        ti_sync(&b->addr_ti);
                        ti_end(&b->addr_ti);
                    }
                    win_invalidate(w);
                    return;
                }
            }
            win_invalidate(w);
            return;
        }
        /* Task 64 [TI-WIDGET]: редактирование адреса — общий виджет:
         * Left/Right/Home/End, Backspace/Delete — по СИМВОЛАМ,
         * печать/кириллица — вставка в позицию курсора, Ctrl+V —
         * вставка из буфера обмена (UTF-8; paste_fn = clip_text_get).
         * [TI-SEL] (сессия 100): Shift+стрелки/мышь выделяют, Ctrl+A —
         * всё, Ctrl+C/X — копия/вырезка выделения (copy_fn). */
        int kr = ti_key(&b->addr_ti, ev);
        if (kr == TI_K_EATEN) {
            win_invalidate(w);
            return;
        }
        /* [BR-ADDRSEL]: Ctrl+C БЕЗ выделения — копировать весь адрес
         * (поведение больших браузеров) */
        if ((ev->flags & KF_CTRL) &&
            (ev->ch == 'c' || ev->ch == 'C' || ev->code == 0x2E)) {
            if (b->addr[0])
                clip_text_set(b->addr, (int)strlen(b->addr));
        }
        return;   /* прочие клавиши в режиме ввода игнорируем */
    }

    /* --- обычный режим: прокрутка ---
     * СЕССИЯ 17 (ФИКС): раньше было ЗАДОМ НАПЕРЁД — PgUp увеличивал
     * scroll (первую видимую строку), Home прыгал в конец. Теперь:
     * scroll — первая видимая строка; PgUp/вверх — к началу.
     * ЗАДАЧА 53: PgUp/PgDn — страница.
     * [BR-NAVCARET] (сессия 100): СТРЕЛКИ — навигация по элементам
     * (ссылки/кнопки/поля) с автопрокруткой; элементы кончились —
     * прокрутка. PgUp/PgDn/Home/End — чистая прокрутка, как прежде. */
    int ch = win_content_h(w);
    int vis = (ch - BR_HDR - BR_STATUS_H) / 16;
    if (vis < 1) vis = 1;
    int max_scroll = b->L.nlines - vis;
    if (max_scroll < 0) max_scroll = 0;

    if (ev->code == 0x49) {                                 /* PgUp */
        b->scroll -= vis;
        if (b->scroll < 0) b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == KBD_UP) {                        /* вверх */
        br_nav_move(b, -1, vis);
        win_invalidate(w);
    } else if (ev->code == 0x51) {                          /* PgDn */
        b->scroll += vis;
        if (b->scroll > max_scroll) b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == KBD_DOWN) {                      /* вниз */
        br_nav_move(b, +1, vis);
        win_invalidate(w);
    } else if (ev->code == 0x4F) {                          /* End */
        b->scroll = max_scroll;
        win_invalidate(w);
        /* [BR-LAZY]: End — ЯВНЫЙ запрос хвоста страницы (тик/прокрутка
         * авто-доконвертацию больше не запускают на не-прокручиваемом
         * экране — [BR-LAZY2]; кнопка «Догрузить» и End работают) */
        if (b->lazy_pending)
            br_lazy_convert(b);
    } else if (ev->code == 0x47) {                          /* Home */
        if (ev->flags & KF_CTRL) {
            br_go_home(b);          /* Task 67: Ctrl+Home — домашняя */
            return;
        }
        b->scroll = 0;
        win_invalidate(w);
    } else if (ev->code == 0x0E) {                          /* Backspace */
        br_go_back(b);                       /* сессия 55: назад */
    } else if (ev->code == 0x1C || ev->ch == '\n') {         /* Enter */
        /* [BR-NAVCARET]: Enter открывает сфокусированную ссылку
         * (поля обрабатываются своей веткой выше — там фокус уже стоит) */
        if (b->nav_i >= 0 && b->nav_row && b->nav_i < b->nav_n &&
            b->nav_kind[b->nav_i] == 0) {
            const brp_link_t *l = &b->page.links[b->nav_idx[b->nav_i]];
            char abs2[512];
            img_url_resolve(b->url, l->url, abs2, (int)sizeof(abs2));
            br_navigate(b, abs2);
            return;
        }
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    }

    /* Session 93 [BR-LAZY]: дошли до низа — доконвертировать хвост
     * (сконвертированы были только первые 100 КиБ). [BR-LAZY2] (сессия
     * 100): только когда страница ДЕЙСТВИТЕЛЬНО прокручивается (maxs>0) —
     * пустой буфер строк после apply делал maxs=0, «низом» считался
     * САМ ВЕРХ, и загрузка сайта сразу прыгала в хвост страницы. */
    if (b->lazy_pending && max_scroll > 0 && b->scroll >= max_scroll)
        br_lazy_convert(b);
}

/* Ссылка под точкой контента или NULL. r — строка отображения,
 * col — колонка в символах. */
static const char *br_link_at(browser_t *b, int r, int col)
{
    if (r < 0 || r >= b->L.nlines) return NULL;
    const char *piece = b->L.lines[r];
    int plen = (int)strlen(piece);
    return brp_click_link(&b->page, b->md, b->L.srcidx[r], b->L.srcoff[r],
                          piece, plen, col,
                          b->L.cls[r] == BRL_CLS_LINK ? 1 : 0);
}

/* Колонка piece (в СИМВОЛАХ) под точкой мыши в строке r. Для 2x-заголовков
 * ([BR-HEAD-2X]) шаг символа 16px и видимый текст сдвинут на префикс —
 * та же арифметика, что в br_draw_text_line/подсветке выделения.
 * Возвращает -1 левее текста (мимо). */
static int br_col_at(browser_t *b, int r, int mx)
{
    if (mx < 4) return -1;
    int col = (mx - 4) / 8;
    if (r >= 0 && r < b->L.nlines && b->L.cls &&
        b->L.cls[r] == BRL_CLS_HEAD)
        col = br_head_prefix_len(b->L.lines[r]) + (mx - 4) / 16;
    return col;
}

static void br_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), chh = win_content_h(w);

    /* Session 93 [BR-ERRLOG]: открыт журнал — клик мимо закрывает,
     * клик по нему глотается (модальный оверлей) */
    if (b->errlog_open) {
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            int bw = cw - 24, bh = 24 + BR_ERRLOG_N * 16 + 18;
            if (bw > 88 * 8) bw = 88 * 8;
            if (bw < 200) bw = 200;
            if (bh > chh - 8) bh = chh - 8;
            int bx = (cw - bw) / 2, by = (chh - bh) / 2;
            if (mx < bx || mx >= bx + bw || my < by || my >= by + bh) {
                b->errlog_open = 0;
                win_invalidate(w);
            }
        }
        return;
    }

    /* Session 93 [BR-JSDEFER]: клик — взаимодействие; отложенные
     * скрипты исполняются до обработки (могут увести навигацией) */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && br_page_scripts_resume(b))
        return;

    /* ОТпускание ЛКМ после drag выделения — принимается В ЛЮБОМ месте
     * (включая отрицательные координаты за пределами окна: сессия 20
     * доставляет их при неявном захвате мыши — иначе drag «залипал»). */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
        /* [BR-ADDRSEL]: drag в адресной строке завершён */
        if (b->addr_drag) {
            b->addr_drag = 0;
            win_invalidate(w);
            return;                /* клик без выделения: курсор уже стоит */
        }
        if (b->sel_drag) {
            b->sel_drag = 0;
            if (b->sel_active) {               /* было перетаскивание — это НЕ клик */
                win_invalidate(w);
                return;
            }
            /* клик без перемещения: ссылка под точкой отпускания? */
            int area_y = BR_HDR;
            int area_h = chh - BR_HDR - BR_STATUS_H;
            if (my >= area_y && my < area_y + area_h) {
                int r = b->scroll + (my - area_y - 2) / 16;
                int col = br_col_at(b, r, mx);   /* [BR-HEAD-2X]: 16px у заголовков */
                const char *u = (col >= 0) ? br_link_at(b, r, col) : NULL;
                if (u) {
                    /* клик по ссылке: относительные адреса — против страницы */
                    char abs[380];   /* Task 66: было 300 (BRP_URL_MAX=300) */
                    img_url_resolve(b->url, u, abs, (int)sizeof(abs));
                    /* [BR-NAVCARET]: каретка навигации — на ссылку под кликом,
                     * чтобы стрелки продолжали с неё */
                    {
                        br_nav_rebuild(b);
                        for (int i = b->nav_n - 1; i >= 0; i--) {
                            if (b->nav_kind[i] == 0 && b->nav_row[i] <= r) {
                                const brp_link_t *nl = &b->page.links[b->nav_idx[i]];
                                if (strcmp(nl->url, u) == 0) { b->nav_i = i; break; }
                            }
                        }
                    }
                    br_navigate(b, abs);
                    return;
                }
            }
            if (b->addr_focus) {
                b->addr_focus = 0;
                ti_sel_clear(&b->addr_ti);   /* [BR-ADDRSEL] */
            }
            win_invalidate(w);
            return;
        }
    }

    if (my < 0 || mx < 0) return;

    /* --- Session 93: статус-бар — кнопки «Повторить» (сетевая ошибка)
     * и «Догрузить» (ленивая конвертация хвоста) --- */
    if (my >= chh - BR_STATUS_H) {
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            if (b->net_err && !b->fetching &&
                mx >= cw - 92 && mx < cw - 8) {
                char u[448];
                snprintf(u, sizeof(u), "%s", b->retry_url);
                br_navigate(b, u);          /* [BR-RETRY] */
                return;
            }
            if (b->lazy_pending &&
                mx >= cw - 180 && mx < cw - 96) {
                br_lazy_convert(b);         /* [BR-LAZY] */
                return;
            }
        }
        return;                            /* прочий клик в статус — мимо */
    }

    if (my < BR_HDR) {
        /* [BR-ADDRSEL]: тянем выделение в поле адреса (ЛКМ зажата после
         * нажатия в поле) — до кнопок/ПКМ не доходим */
        if (b->addr_drag && (btn & MSB_LEFT)) {
            int max_chars2 = (cw - 200 - 12) / 8;
            if (max_chars2 < 4) max_chars2 = 4;
            if (max_chars2 > BR_ADDR_MAX) max_chars2 = BR_ADDR_MAX;
            int from2 = br_addr_view_from(b, max_chars2);
            int col2 = (mx - 4 - 6) / 8;
            if (col2 < 0) col2 = 0;
            int bpos2 = from2 + utf8_take_bytes(b->addr + from2,
                                                b->addr_ti.len - from2, col2);
            b->addr_ti.cur = br_addr_clamp_cur(b, bpos2);
            b->addr_ti.sel_a = b->addr_anchor;
            b->addr_ti.sel_b = b->addr_ti.cur;
            win_invalidate(w);
            return;
        }
        /* [TI-CLIPMENU] ПКМ по полю адреса — меню «Копировать/Вставить»
         * (до LEFT-фильтра: правая кнопка здесь тоже живёт).
         * [BR-FOCUSADDR]: поле страницы теряет фокус. */
        if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT) && mx < cw - 200) {
            if (b->focus >= 0) br_focus_field(b, -1);
            b->dd_open = 0;
            b->addr_focus = 1;
            ti_menu_open(w, &b->addr_ti, mx, my);
            win_invalidate(w);
            return;
        }
        if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT))
            return;                   /* интересует только нажатие ЛКМ */
        b->sel_drag = 0;              /* нажатие в шапке — не drag текста */
        /* полоса адреса: Go (сразу за адресом — сессия 97) / Тема
         * ([BR-THEME]) / Back / Save / поле */
        if (mx >= cw - 192 && mx < cw - 148) {
            br_navigate(b, b->addr);   /* кнопка Go */
        } else if (mx >= cw - 144 && mx < cw - 100) {
            b->light = !b->light;      /* кнопка темы ([BR-THEME]) */
            snprintf(b->status, sizeof(b->status), "Тема: %s",
                     b->light ? "светлая" : "тёмная");
            win_invalidate(w);
        } else if (mx >= cw - 96 && mx < cw - 52) {
            br_go_back(b);             /* кнопка Back (сессия 55) */
        } else if (mx >= cw - 48 && mx < cw - 4) {
            br_save_page(b);           /* кнопка Save (сессия 67) */
        } else if (mx < cw - 200) {
            /* Task 62 [BR-CURSOR]: клик по полю — фокус + КУРСОР на место
             * (ближайшая граница символа под точкой клика).
             * [BR-ADDRSEL]: нажатие — ЯКОРЬ будущего drag-выделения
             * (как в содержимом: тяни мышью — выделяется часть адреса).
             * [BR-FOCUSADDR] (сессия 101): клик по адресу снимает фокус
             * с поля страницы — иначе печать продолжала идти в поле
             * (ветка поля выше ветки адреса). */
            if (b->focus >= 0) br_focus_field(b, -1);
            b->dd_open = 0;
            b->addr_focus = 1;
            {
                /* Task 64 [TI-WIDGET]: from — байты, col — СИМВОЛЫ:
                 * курсор = граница символа под точкой клика */
                int max_chars = (cw - 200 - 12) / 8;
                if (max_chars < 4) max_chars = 4;
                if (max_chars > BR_ADDR_MAX) max_chars = BR_ADDR_MAX;
                int from = br_addr_view_from(b, max_chars);
                int col = (mx - 4 - 6) / 8;
                if (col < 0) col = 0;
                int bpos = from + utf8_take_bytes(b->addr + from,
                                                  b->addr_ti.len - from, col);
                b->addr_ti.cur = br_addr_clamp_cur(b, bpos);
                ti_sel_clear(&b->addr_ti);     /* новое нажатие — старое выделение долой */
                b->addr_drag = 1;
                b->addr_anchor = b->addr_ti.cur;
            }
            win_invalidate(w);
        }
        return;
    }

    /* полоса прокрутки (сессия 17); сессия 20: при drag полосу не
     * отпускаем — события с любыми координатами (захват мыши) */
    if ((mx >= cw - 9 && my < chh - BR_STATUS_H) || b->sb.dragging) {
        int np = wm_scrollbar_mouse(&b->sb, mx, my, btn, changed);
        if (np >= 0) { b->scroll = np; win_invalidate(w); }
        return;
    }

    /* --- контент (сессия 55): ховер, выделение, клики по ссылкам --- */
    int area_y = BR_HDR;
    int area_h = chh - BR_HDR - BR_STATUS_H;
    if (my >= area_y && my < area_y + area_h) {
        int r = b->scroll + (my - area_y - 2) / 16;
        int col = br_col_at(b, r, mx);   /* [BR-HEAD-2X]: 16px у заголовков */

        /* ховер: показ адреса в статусе (перерисовка только при смене;
         * во время drag выделения ховер не трогаем — статус оставим) */
        if (!b->sel_drag) {
            const char *url = (col >= 0) ? br_link_at(b, r, col) : NULL;
            const char *h = url ? url : "";
            if (strncmp(b->hover, h, sizeof(b->hover) - 1) != 0) {
                strncpy(b->hover, h, sizeof(b->hover) - 1);
                b->hover[sizeof(b->hover) - 1] = 0;
                win_invalidate(w);
            }
        }

        /* Task 51 [BR-INPUT]: КЛИК ПО КОНТРОЛУ ФОРМЫ. Раньше контролы
         * реагировали только на клавиатуру (Tab — фокус, Enter/Space —
         * активация), а клик мышью по кнопке/полю обрабатывался как
         * клик по обычному тексту (начинал выделение, снимал фокус
         * адреса) — «не могу нажать кнопки и ввести что-либо в поле
         * ввода». Теперь: клик по строке-якорю \x03 ставит фокус поля;
         * кнопки/чекбоксы/select активируются сразу, текстовые поля
         * ждут ввод с клавиатуры. */
        /* Session 92 [BR-DD]: клик по РАСКРЫТОМУ списку — выбор варианта */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && b->dd_open) {
            int ddy = 0;
            int ddmax = br_dd_geom(b, chh, &ddy);
            if (ddmax > 0 && my >= ddy) {
                int k = (my - ddy) / 16;
                brf_field_t *dfl = &b->forms.fields[b->dd_field];
                int box_w = cw - 24;
                if (box_w < 120) box_w = 120;
                if (k >= 0 && k < ddmax && mx >= 8 && mx < 8 + box_w) {
                    dfl->opt_sel = k;
                    b->dd_open = 0;
                    win_invalidate(w);
                    return;
                }
                if (my >= ddy && my < ddy + ddmax * 16) {
                    /* клик по рамке списка — просто глотаем */
                    win_invalidate(w);
                    return;
                }
                b->dd_open = 0;           /* мимо списка — свернуть */
                win_invalidate(w);
                return;
            }
        }
        if ((changed & MSB_RIGHT) && (btn & MSB_RIGHT)) {
            /* [TI-CLIPMENU] ПКМ на строке-якоре текстового поля —
             * фокус + меню «Копировать/Вставить» */
            brf_field_t *fl = (r >= 0 && r < b->L.nlines)
                              ? br_field_by_row(b, r) : NULL;
            if (fl && b->L.lines[r][0] == BRF_MARK &&
                b->L.lines[r][1] == 0) {
                int text_like = !strcmp(fl->type, "text") ||
                                !strcmp(fl->type, "password") ||
                                !strcmp(fl->type, "search") ||
                                !strcmp(fl->type, "textarea");
                if (text_like) {
                    br_focus_field(b, (int)(fl - b->forms.fields));
                    b->sel_drag = 0;
                    b->sel_active = 0;
                    ti_menu_open(w, &b->field_ti, mx, my);
                    win_invalidate(w);
                    return;
                }
            }
            /* [BR-PAGEMENU] (сессия 99): ПКМ мимо поля — меню страницы:
             * копировать выделение, сохранить как md (с маркерами) /
             * как html (исходник). Прежде правый клик по тексту страницы
             * молча игнорировался — меню «как будто нет». */
            if (r >= 0 && r < b->L.nlines &&
                b->L.lines[r][0] != BRF_MARK) {
                br_page_menu_open(b, w, mx, my);
                win_invalidate(w);
            }
            return;
        }
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) &&
            r >= 0 && r < b->L.nlines &&
            b->L.lines[r][0] == BRF_MARK && b->L.lines[r][1] == 0) {
            brf_field_t *fl = br_field_by_row(b, r);
            if (fl && strcmp(fl->type, "hidden") != 0) {
                br_focus_field(b, (int)(fl - b->forms.fields));  /* [TI-WIDGET] */
                b->sel_drag = 0;          /* клик по контролу — не выделение */
                b->sel_active = 0;
                int text_like = !strcmp(fl->type, "text") ||
                                !strcmp(fl->type, "password") ||
                                !strcmp(fl->type, "search") ||
                                !strcmp(fl->type, "textarea");
                if (!text_like)
                    br_field_activate(b, fl);   /* submit/button/checkbox/
                                                 * radio/select — сразу */
                win_invalidate(w);
                return;
            }
        }

        /* ВЫДЕЛЕНИЕ: нажатие ставит ЯКОРЬ, drag тянет второй конец;
         * клик БЕЗ перемещения обрабатывается в блоке отпускания выше
         * (ссылка/фокус адреса — как раньше, но на mouse-up). */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
            b->sel_drag = 1;
            b->sel_active = 0;
            b->sel_ar = b->sel_br = r;
            b->sel_ac = b->sel_bc = col;
            /* клик по контенту снимает фокус с адресной строки */
            if (b->addr_focus) {
                b->addr_focus = 0;
                ti_sel_clear(&b->addr_ti);   /* [BR-ADDRSEL] */
            }
            win_invalidate(w);
        } else if (b->sel_drag && (btn & MSB_LEFT)) {
            /* drag: второй конец следует за курсором */
            if (r != b->sel_br || col != b->sel_bc) {
                b->sel_br = r;
                b->sel_bc = col;
                b->sel_active = (r != b->sel_ar || col != b->sel_ac);
                win_invalidate(w);
            }
        }
    } else if (b->hover[0]) {
        b->hover[0] = 0;
        win_invalidate(w);
    }
}

/* Task 67 [BR-FREESTATE]: единая очистка состояния браузера (было ДВЕ
 * копии списка free() — в br_close и в провале win_create; при добавлении
 * нового поля утечки появлялись в одной копии и не появлялись в другой). */
static void br_free_state(browser_t *b)
{
    if (!b) return;
    br_ichan_release(b);      /* Task 68: канал картинок (воркер — сам) */
    brjs_stop(&b->js);
    brf_reset(&b->forms);
    if (b->up_data) { free(b->up_data); b->up_data = NULL; }
    b->up_len = 0;
    brl_free(&b->L);
    if (b->md) free(b->md);
    if (b->src) free(b->src);            /* [BR-SAVE]: исходник */
    if (b->raw_keep) free(b->raw_keep);  /* [BR-LAZY]: спул хвоста */
    b->raw_keep = NULL;
    b->raw_keep_len = 0;
    /* [BR-NAVCARET]: список элементов навигации */
    if (b->nav_row)  free(b->nav_row);
    if (b->nav_kind) free(b->nav_kind);
    if (b->nav_idx)  free(b->nav_idx);
    b->nav_row = NULL;
    b->nav_kind = NULL;
    b->nav_idx = NULL;
    b->nav_n = b->nav_cap = 0;
    b->nav_i = -1;
    brp_reset(&b->page);                 /* сессия 55: пиксели картинок */
    if (b->page.line_off) free(b->page.line_off);
    b->page.line_off = NULL;
    free(b);
}

static void br_close(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (b) {
        /* Task 66 [FD-DETACH]: окно может закрыться при открытом диалоге
         * выбора файла — отвязываем колбэки, иначе use-after-free */
        if (b->file_dlg) filedlg_detach_ctx(b);
        /* Task 51 [JS-FREE]: ГЛАВНАЯ утечка памяти браузера. JS-контекст
         * страницы (brjs_start: пул 256 КиБ + сегменты роста до 512 КиБ)
         * освобождался только при переходе на новую страницу — при
         * ЗАКРЫТИИ окна brjs_stop не звался вовсе. Теперь контекст и пул
         * возвращаются системе (см. br_free_state). */
        br_free_state(b);
    }
}

/* ---------- стартовая страница ---------- */

static const char *br_help_md =
    "# Браузер N2600-OS\n\n"
    "## Ссылки\n"
    "- Ссылки — СИНИЕ с подчёркиванием: [пример.com](http://example.com/)\n"
    "- Клик — переход; адрес под курсором — в статус-строке\n"
    "- Редиректы (301/302) проходятся автоматически — до 4 раз\n"
    "- Кнопка **Back** или **Backspace** — назад; `<a href>` из HTML\n"
    "  и `[текст](url)` из Markdown работают одинаково\n\n"
    "## Картинки\n"
    "![логотип N2600](LOGO.PNG)\n"
    "- Форматы: PNG, JPEG, BMP, GIF (stb_image)\n"
    "- `<img src=...>` из HTML и `![alt](url)` из Markdown; относительные\n"
    "  пути разрешаются от адреса страницы; локальные файлы — RAM disk\n\n"
    "## Выделение и копирование\n"
    "- Проведите мышью с зажатой ЛКМ — текст выделится\n"
    "- **Ctrl+C** — скопировать выделенное в общий буфер обмена\n"
    "- **ПКМ** на любом поле ввода — меню **Копировать/Вставить**\n"
    "  (адресная строка, поля форм, терминал, диалоги файлов)\n"
    "- **Ctrl+V** — вставка из буфера (в полях, редакторе, терминале)\n\n"
    "## Адресная строка\n"
    "- Клик по ней или **Ctrl+L** — редактирование\n"
    "- **Enter** или кнопка **Go** (сразу за адресом) — переход\n"
    "- Кнопка **Свет/Тёмн** — светлая/тёмная тема окна\n"
    "- **Tab** в адресной строке — автодополнение из истории\n"
    "- `http://host/path` или `https://` — запрос (в потоке этого окна:\n"
    "  зависший запрос не вешает систему)\n"
    "- Имя файла (`help.md`, `demo.js`) — открыть файл из RAM disk\n"
    "- Кнопка **Save** или **Ctrl+S** — сохранить страницу в RAM disk\n"
    "  (имя — из адреса, существующие файлы не перезаписываются)\n\n"
    "## Клавиши\n"
    "- **F5** / **Ctrl+R** — перезагрузить страницу\n"
    "- **Alt+Left** — назад, **Alt+Right** — вперёд (Backspace — назад)\n"
    "- **Ctrl+Home** — домашняя страница\n"
    "- **Ctrl+F** — поиск по странице (Enter/F3 — далее, Esc — выход)\n"
    "- **Ctrl+E** — журнал ошибок (сеть / JS / конвертация)\n"
    "- **Esc** — снять фокус с поля страницы (стрелки/ввод снова окну)\n"
    "- **Ctrl+L** — фокус в адресную строку (работает и из поля формы);\n"
    "  Esc в адресе — вернуться к странице\n"
    "- **End** — в конец страницы (догрузит отложенный хвост)\n\n"
    "## Большие страницы и ошибки\n"
    "- Конвертируются первые 100 КиБ HTML — страница видна сразу;\n"
    "  хвост ДОГРУЖАЕТСЯ САМ: прокрутка до низа или когда страница\n"
    "  влезла на экран (хватает памяти — статус предупредит иначе);\n"
    "  принудительно — **End** или кнопка «Догрузить»\n"
    "- При сетевой ошибке в статус-баре появляется кнопка **Повторить**\n"
    "- Если ответ оборван — статус покажет «Загружено N% — показано\n"
    "  как есть»; детали — в журнале Ctrl+E\n\n"
    "## CSS (минимальный)\n"
    "- color из style/атрибута красит текст, font-weight:bold — жирным,\n"
    "  font-style:italic — курсивом, margin-left — отступом абзаца\n\n"
    "## Если «connection refused (RST ... ttl=...)»\n"
    "- Соединение сбросил не сайт: ttl=64 — фильтр вашей же сети\n"
    "  (роутер/AP/DNS-синкхол); меньше — хост интернета\n"
    "- Попробуйте https:// или info.cern.ch, neverssl.com, example.com\n\n"
    "## Поддержка Markdown\n"
    "- Заголовки `#`, `##`, `###` (шрифтом 2x); **жирный**, *курсив*, `код`\n"
    "- Списки и ссылки [текст](http://example.com/)\n"
    "- Блоки ``` и `<pre>` — в рамке, отдельным цветом:\n"
    "```\n"
    "int main(void) { return 0; }  /* пример блока кода */\n"
    "```\n"
    "- Таблицы — рамкой псевдографики, ширина — под окно\n\n"
    "## Формы\n"
    "- Radio — ( )/(•): выбор одной снимает другие группы\n"
    "- Select — ▼: Enter/клик раскрывает список, Up/Down + Enter\n\n"
    "## Команды терминала\n"
    "- `curl http://example.com/` — загрузить страницу в новое окно\n"
    "- `spawn browser` — ещё одно окно браузера\n"
    "- `js img.js` — картинки из JS-скрипта (QuickJS)\n\n"
    "---\n"
    "Прокрутка: PgUp/PgDn, стрелки, колёсико мыши; назад — Backspace\n";

/* Перезагрузка (Task 67 [BR-RELOAD]): F5 / Ctrl+R. Локальная страница
 * «help» перезагружается из встроенного текста (в RAM disk её нет). */
static void br_reload(browser_t *b)
{
    if (!strcmp(b->url, "help")) {
        browser_load_content(b, "help", br_help_md,
                             (int)strlen(br_help_md));
        strcpy(b->addr, "help");
        ti_sync(&b->addr_ti);
        b->scroll = 0;
        win_invalidate(b->win);
        return;
    }
    if (!b->url[0]) {
        snprintf(b->status, sizeof(b->status), "Нечего перезагружать");
        win_invalidate(b->win);
        return;
    }
    br_navigate(b, b->url);
}

/* Домашняя страница (Task 67): Ctrl+Home. */
static void br_go_home(browser_t *b)
{
    browser_load_content(b, "help", br_help_md, (int)strlen(br_help_md));
    strcpy(b->addr, "help");
    ti_sync(&b->addr_ti);
    b->scroll = 0;
    win_invalidate(b->win);
}

/* ---------- поиск по странице (Task 67 [BR-FIND], Ctrl+F) ---------- */

/* Подстрока без учёта РЕГИСТРА ASCII (кириллица — точное совпадение
 * байтов: полноценный casefold UTF-8 в ядре не нужен). Возвращает
 * позицию в s или -1. */
static int br_find_in(const char *s, const char *q)
{
    if (!q[0]) return -1;
    for (int i = 0; s[i]; i++) {
        int k = 0;
        for (; q[k]; k++) {
            char a = s[i + k], b = q[k];
            if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
            if (a != b) break;
            if (!s[i + k]) break;      /* s кончился посреди сравнения */
        }
        if (!q[k]) return i;
    }
    return -1;
}

/* Совпадений запроса в строке отображения (для подсветки): до 4 пар
 * (col0, col1) в СИМВОЛАХ. */
static int br_find_row_segs(const browser_t *b, int row,
                            int *out, int out_max)
{
    if (!b->find_q[0] || row < 0 || row >= b->L.nlines) return 0;
    const char *piece = b->L.lines[row];
    int n = 0;
    int pos = 0;                       /* байтовая позиция поиска */
    int col = 0;                       /* символов до pos */
    while (n < out_max) {
        int hit = br_find_in(piece + pos, b->find_q);
        if (hit < 0) break;
        int hb = pos + hit;            /* байт начала */
        /* символы от pos до hb */
        {
            const char *p = piece + pos;
            const char *end = piece + hb;
            while (p < end) { utf8_next(&p); col++; }
        }
        int qlen = (int)strlen(b->find_q);
        int col1 = col;
        {
            const char *p = piece + hb;
            const char *end = piece + hb + qlen;
            while (p < end && *p) { utf8_next(&p); col1++; }
        }
        out[n * 2] = col;
        out[n * 2 + 1] = col1;
        n++;
        pos = hb + qlen;
        col = col1;
        if (!piece[pos]) break;
    }
    return n;
}

/* Число совпадений по всей странице (для статуса после Enter). */
static int br_find_count_all(browser_t *b)
{
    int total = 0;
    int seg[8];
    for (int i = 0; i < b->L.nlines; i++)
        total += br_find_row_segs(b, i, seg, 8);
    return total;
}

/* Найти СЛЕДУЮЩЕЕ совпадение от строки from_row (вперёд по странице,
 * с заворотом). Совпадение -> scroll к строке. */
static void br_find_next(browser_t *b, int from_row)
{
    if (!b->find_q[0]) {
        snprintf(b->status, sizeof(b->status), "Поиск: введите запрос");
        win_invalidate(b->win);
        return;
    }
    int n = b->L.nlines;
    if (n == 0) return;
    for (int k = 0; k < n; k++) {
        int row = (from_row + k) % n;
        int seg[8];
        if (br_find_row_segs(b, row, seg, 8) > 0) {
            b->scroll = row;
            b->find_total = br_find_count_all(b);
            snprintf(b->status, sizeof(b->status),
                     "Найдено (всего %d) — F3/Enter: далее, Esc: выход",
                     b->find_total);
            win_invalidate(b->win);
            return;
        }
    }
    b->find_total = 0;
    snprintf(b->status, sizeof(b->status), "Не найдено: %.40s", b->find_q);
    win_invalidate(b->win);
}

/* Выйти из режима поиска (Esc) — запрос и подсветка остаются до
 * следующего Ctrl+F / смены страницы. */
static void br_find_stop(browser_t *b)
{
    b->find_mode = 0;
    win_invalidate(b->win);
}



/* ---------- создание окна ---------- */

/* Task 68 [BR-BGIMG]: тик окна — применить готовые картинки и выдать
 * воркеру следующую работу (WM шлёт WEV_TICK раз в ~500 мс). */
static void br_tick(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (!b) return;
    br_img_pump(b);
    /* Session 93 [BR-LAZY]: пользователь дошёл до низа (прокрутка мышью
     * по желобу и т.п.) — доконвертировать отложенный хвост страницы.
     * [BR-LAZY2] (сессия 100, ФИКС «при загрузке сайта просмотр сразу
     * в хвосте»): после br_apply_md буфер строк ПУСТ (brl_free, строки
     * строит первая отрисовка) — nlines=0 давало maxs=0, «низом»
     * считался сам ВЕРХ, tick запускал доконвертацию с pin_bottom=1,
     * и отрисовка зажимала scroll к дну УЖЕ полной страницы. Защита
     * nlines>0 остаётся; случай «контент влез на экран» вернули —
     * см. [BR-AUTOTAIL] ниже (сессия 101). */
    if (b->lazy_pending && b->L.lines && b->L.nlines > 0 &&
        timer_ticks() >= b->lazy_cool) {
        int vis = (win_content_h(w) - BR_HDR - BR_STATUS_H) / 16;
        if (vis < 1) vis = 1;
        int maxs = b->L.nlines - vis;
        /* [BR-AUTOTAIL] (сессия 101, запрос «догружать автоматически,
         * если есть место в памяти и видимая страница доскроллена до
         * конца — особенно если конечный маркдаун и так весь влез на
         * экран»): автодоконвертация в ДВУХ случаях —
         *   (а) страница прокручивается и скролл на дне (прежний
         *       случай [BR-LAZY2]);
         *   (б) контент ЦЕЛИКОМ влезает в экран (maxs<=0): прокрутки
         *       нет — «дно» и так на виду. Прыжка в хвост из [BR-LAZY2]
         *       здесь нет: строки построены (nlines>0), pin_bottom в
         *       br_lazy_convert при maxs==0 не сработает — скролл
         *       останется на 0, страница РАСТЁТ вниз.
         * Оба — только при достатке памяти: свободная куча >= буфер
         * доконвертации (х3 хвоста, как в br_lazy_convert) + поле
         * 512 КиБ. Иначе — статус и кулдаун 10 с; кнопка «Догрузить»
         * и End работают как прежде (явный запрос без барьера). */
        int at_bottom = (maxs > 0 && b->scroll >= maxs);
        int fits_screen = (maxs <= 0);
        if (at_bottom || fits_screen) {
            u32 need = b->raw_keep_len * 3u + 8192u;
            if (need > (u32)BR_MD_STREAM_MAX)
                need = (u32)BR_MD_STREAM_MAX;
            u32 free_heap = mem_debug_walk(NULL, NULL);
            if (free_heap >= need + 512u * 1024u) {
                br_lazy_convert(b);
            } else {
                b->lazy_cool = timer_ticks() + 10000; /* 1 тик = 1 мс */
                snprintf(b->status, sizeof(b->status),
                         "Хвост %u КБ ждёт: мало памяти для автодогрузки",
                         (unsigned)(b->raw_keep_len / 1024));
                win_invalidate(w);
            }
        }
    }
}

static browser_t *br_new_state(void)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return NULL;
    memset(b, 0, sizeof(*b));
    br_ichan_new(b);          /* Task 68 [BR-BGIMG]: канал картинок */
    ti_init(&b->addr_ti, b->addr, BR_ADDR_MAX + 1);   /* [TI-WIDGET] */
    b->addr_ti.paste_fn = clip_text_get;   /* Ctrl+V из буфера обмена */
    b->addr_ti.copy_fn = ti_clip_set;      /* [TI-SEL] Ctrl+C/X выделения */
    b->nav_i = -1;                         /* [BR-NAVCARET] */
    strncpy(b->url, "help", sizeof(b->url) - 1);
    strcpy(b->status, "Готово");
    return b;
}

static void br_open_common(browser_t *b, int load_help)
{
    if (load_help) {
        browser_load_content(b, "help", br_help_md, (int)strlen(br_help_md));
        strcpy(b->addr, "help");
        ti_sync(&b->addr_ti);
    }

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    window_t *w = win_create("Браузер", (int)W / 2 - ww / 2, 16, ww, wh,
                              br_draw, br_key, br_mouse, br_tick, br_close, b);
    if (!w) {
        /* FIX [BR-OPEN-LEAK] (ревью, баг 6): провал win_create терял
         * ВСЕ буферы состояния. Task 67 [BR-FREESTATE]: один общий
         * br_free_state (ровно как в br_close). */
        br_free_state(b);
        return;
    }
    b->win = w;

    /* Task 68 [BR-BGIMG]: контент уже загружен (curl/help) — картинки
     * грузятся ФОНОВО (воркер), окно остаётся отзывчивым */
    br_img_pump(b);
}

void app_browser_open(void)
{
    browser_t *b = br_new_state();
    if (!b) return;
    br_open_common(b, 1);
}

void app_browser_open_with(const char *url, const char *content, int len)
{
    browser_t *b = br_new_state();
    if (!b) return;
    browser_load_content(b, url ? url : "(curl)", content, len);
    if (url) {
        strncpy(b->addr, url, BR_ADDR_MAX);
        b->addr[BR_ADDR_MAX] = 0;
        ti_sync(&b->addr_ti);
    }
    br_open_common(b, 0);
}
