/* sdl_demo.c4.c — пример программы с SDL2-подобным API N2600-OS.
 *
 * Вставьте этот текст в редактор C (через Файлы → Открыть .c) и нажмите F9.
 * Программа нарисует движущиеся прямоугольники, опрашивает клавиатуру на выход.
 *
 * Доступные функции (это не весь SDL2, а только подмножество):
 *
 *   int  kinit(void);            инициализация (no-op, всегда 0)
 *   int  kquit(void);            финализация (no-op)
 *   void kdelay(int ms);         уступить CPU на ms миллисекунд (10 тиков = 100ms)
 *   void kfill(int x, int y, int w, int h, int color);  заливка прямоугольника
 *   void ktext(int x, int y, char *s, int fg, int bg);  вывод строки (bg=-1 прозрачно)
 *   void kflip(void);           перерисовать помеченные области
 *   int  krgb(int r, int g, int b);   получить цвет (0..255 в каждом канале)
 *   int  kevent(char *buf);     получить событие: 0=нет, 1=клавиша, 3=Esc (выход)
 *                                buf[0]=ch, buf[1]=code, buf[2]=flags
 *   void kclear(int color);     залить весь экран цветом
 *   int  kw(void);              ширина экрана в пикселях
 *   int  kh(void);              высота экрана в пикселях
 *   int  kmtime(void);          текущее время в миллисекундах
 *
 * В c4 НЕ поддерживаются: for, struct, float, #define, #include, switch.
 * Только char/int/указатели, if/while/return, функции, выражения.
 */

int main() {
    int w;
    int h;
    int x;
    int y;
    int dx;
    int dy;
    char ev[8];
    int frame;
    int t0;

    w = kw();
    h = kh();
    x = w / 2;
    y = h / 2;
    dx = 5;
    dy = 3;
    frame = 0;
    t0 = kmtime();

    while (frame < 200) {
        int r;
        int g;
        int b;
        int color;

        r = (frame * 7) % 256;
        g = (frame * 13) % 256;
        b = (frame * 17) % 256;
        color = krgb(r, g, b);

        kclear(krgb(0, 0, 32));
        kfill(x, y, 60, 60, color);
        ktext(x + 4, y + 22, "C4+SDL!", krgb(255, 255, 255), -1);
        ktext(8, 4, "frame: ", krgb(255, 255, 0), -1);

        /* Вывод числа frame (k4 умеет %d) */
        printf("frame %d\n", frame);

        kflip();
        kdelay(20);

        /* Двигаем прямоугольник */
        x = x + dx;
        y = y + dy;
        if (x < 0)  { x = 0;  dx = -dx; }
        if (y < 0)  { y = 0;  dy = -dy; }
        if (x > w - 60) { x = w - 60; dx = -dx; }
        if (y > h - 60) { y = h - 60; dy = -dy; }

        /* Проверяем Esc */
        if (kevent(ev) == 3) {
            printf("exiting by Esc at frame %d\n", frame);
            return 0;
        }

        frame = frame + 1;
    }

    printf("done: %d frames in %d ms\n", frame, kmtime() - t0);
    return 0;
}
