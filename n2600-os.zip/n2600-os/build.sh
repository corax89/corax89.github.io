#!/bin/sh
# N2600-OS: сборка ядра (Linux/macOS).
# Использует тот же MinGW-тулчейн, что и Windows (i686-w64-mingw32-*),
# а при его отсутствии — системный gcc -m32.
set -e
cd "$(dirname "$0")"

if command -v i686-w64-mingw32-gcc >/dev/null 2>&1; then
    CC=i686-w64-mingw32-gcc
    OBJCOPY=i686-w64-mingw32-objcopy
elif command -v gcc >/dev/null 2>&1; then
    CC=gcc
    OBJCOPY=objcopy
else
    echo "Не найден компилятор (нужен i686-w64-mingw32-gcc или gcc)" >&2
    exit 1
fi
echo "Использую: $CC"

CFLAGS="-m32 -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
-fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
-O2 -Wall -Wextra -Isrc"

mkdir -p build

echo "[1/3] Компиляция..."
for f in src/*.c; do
    echo "  CC $f"
    $CC $CFLAGS -c "$f" -o "build/$(basename "${f%.c}").o"
done

echo "[2/3] Линковка..."
$CC -m32 -nostdlib -Wl,-T,linker.ld -Wl,--image-base=0x100000 \
    -o build/kernel.tmp.exe build/*.o

echo "[3/3] Плоский бинарник..."
$OBJCOPY -O binary build/kernel.tmp.exe kernel.bin

echo "[OK] Готово: kernel.bin"
