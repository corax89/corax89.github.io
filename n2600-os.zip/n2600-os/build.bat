@echo off
rem ============================================================
rem  N2600-OS: сборка ядра MinGW на Windows
rem  Требуется 32-битный (i686) MinGW-w64 GCC >= 8 в PATH:
rem    - w64devkit (i686-вариант), или
rem    - mingw-w64 "i686-posix-dwarf" от niXman (niXman/mingw-builds-binaries),
rem    - старый MinGW32 тоже подойдёт (GCC 8+).
rem  Результат: kernel.bin (плоский multiboot-образ, грузится GRUB'ом).
rem ============================================================
setlocal
where gcc >nul 2>nul || (
  echo [ОШИБКА] gcc не найден в PATH. Установите 32-битный MinGW-w64 и добавьте его bin в PATH.
  exit /b 1
)

if not exist build mkdir build

rem --- проверка, что gcc умеет -m32 (на x86_64-сборках без multilib упадёт) ---
echo int main(void){return 0;} > build\probe.c
gcc -m32 -c build\probe.c -o build\probe.o 2>nul
if errorlevel 1 (
  echo [ОШИБКА] Этот gcc не поддерживает -m32. Нужен i686-сборка MinGW-w64 ^(см. шапку файла^).
  del build\probe.c
  exit /b 1
)
del build\probe.c build\probe.o

set CFLAGS=-m32 -ffreestanding -fno-pic -fno-pie -fno-stack-protector -fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe -O2 -Wall -Wextra -Isrc

echo [1/3] Компиляция исходников...
for %%f in (src\*.c) do (
  echo   CC %%f
  gcc %CFLAGS% -c "%%f" -o "build\%%~nf.o"
  if errorlevel 1 goto :fail
)

echo [2/3] Линковка...
gcc -m32 -nostdlib -Wl,-T,linker.ld -Wl,--image-base=0x100000 -o build\kernel.tmp.exe build\*.o
if errorlevel 1 goto :fail

echo [3/3] Извлечение плоского бинарника...
objcopy -O binary build\kernel.tmp.exe kernel.bin
if errorlevel 1 goto :fail

echo.
echo [OK] Готово: kernel.bin
echo      Дальше: положите kernel.bin в isodir\boot\ и соберите os.iso
echo      (см. makeiso.bat или готовый prebuilt\os.iso).
exit /b 0

:fail
echo [ОШИБКА] Сборка не удалась, см. сообщения выше.
exit /b 1
