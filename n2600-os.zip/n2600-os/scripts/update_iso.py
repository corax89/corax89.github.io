#!/usr/bin/env python3
"""Замена kernel.bin и grub.cfg внутри готового os.iso без пересборки GRUB.

Использует pycdlib: открывает ISO9660 (с Rock Ridge и Joliet),
переписывает файлы /boot/kernel.bin и /boot/grub/grub.cfg на новые.
"""
import sys
import os

import pycdlib
from pycdlib import pycdlibexception

ISO_IN  = "prebuilt/os.iso"
ISO_OUT = "os.iso"
NEW_KERNEL = "kernel.bin"
NEW_GRUBCFG = "grub/grub.cfg"

def main():
    base = os.path.dirname(os.path.abspath(__file__))
    proj = os.path.normpath(os.path.join(base, ".."))
    iso_in   = os.path.join(proj, ISO_IN)
    iso_out  = os.path.join(proj, ISO_OUT)
    new_kern = os.path.join(proj, NEW_KERNEL)
    new_grub = os.path.join(proj, NEW_GRUBCFG)

    if not os.path.exists(iso_in):
        print(f"ERROR: {iso_in} не найден", file=sys.stderr); return 1
    if not os.path.exists(new_kern):
        print(f"ERROR: {new_kern} не найден — сначала соберите build.sh",
              file=sys.stderr); return 1

    print(f"Открываю образ {iso_in} ...")
    iso = pycdlib.PyCdlib()
    iso.open(iso_in)

    # --- Обновляем kernel.bin ---
    try:
        iso.rm_file("/boot/kernel.bin;1",
                     rr_name="kernel.bin",
                     joliet_path="/boot/kernel.bin")
        print("Старый kernel.bin удалён из образа")
    except pycdlibexception.PyCdlibInvalidInput as e:
        print(f"Старого kernel.bin нет ({e}) — добавляем как новый файл")
    except Exception as e:
        print(f"Предупреждение (rm kernel): {e!r}")

    iso.add_file(new_kern,
                 "/boot/KERNEL.BIN;1",
                 rr_name="kernel.bin",
                 joliet_path="/boot/kernel.bin")
    print(f"Новый kernel.bin ({os.path.getsize(new_kern)} байт) добавлен в образ")

    # --- Обновляем grub.cfg (если есть) ---
    if os.path.exists(new_grub):
        try:
            iso.rm_file("/boot/grub/grub.cfg;1",
                         rr_name="grub.cfg",
                         joliet_path="/boot/grub/grub.cfg")
            print("Старый grub.cfg удалён из образа")
        except pycdlibexception.PyCdlibInvalidInput:
            pass
        except Exception as e:
            print(f"Предупреждение (rm grub.cfg): {e!r}")

        try:
            iso.add_file(new_grub,
                         "/boot/grub/GRUB.CFG;1",
                         rr_name="grub.cfg",
                         joliet_path="/boot/grub/grub.cfg")
            print(f"Новый grub.cfg ({os.path.getsize(new_grub)} байт) добавлен в образ")
        except Exception as e:
            print(f"Предупреждение (add grub.cfg): {e!r}")

    iso.write(iso_out)
    iso.close()
    print(f"Готов образ: {iso_out} ({os.path.getsize(iso_out)} байт)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
