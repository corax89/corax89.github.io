#!/bin/bash
# Запуск N2600-OS в QEMU с E1000 NIC и user-mode сетью
# (10.0.2.x — QEMU user-net диапазон, шлюз 10.0.2.2)
# Цель — проверить, что:
#   1) ядро грузится;
#   2) e1000_init() находит Intel NIC и читает MAC из EEPROM;
#   3) net_poll() крутится в главном цикле;
#   4) команда `ipconfig` показывает IP/MAC/шлюз;
#   5) команда `ping 10.0.2.2` отправляет ICMP Echo Request,
#      QEMU user-net отвечает, наш стек принимает Echo Reply.
#
# Запуск: bash /home/z/my-project/n2600-os/scripts/run_qemu.sh

export LD_LIBRARY_PATH=/tmp/qemu-extract/usr/lib/x86_64-linux-gnu:/tmp/qemu-extract/usr/lib:$LD_LIBRARY_PATH
# Указываем оба пути BIOS: seabios для bios.bin/vgabios.bin и qemu для pxe-*.rom
QEMU=/tmp/qemu-extract/usr/bin/qemu-system-i386
BIOS_PATH="-L /tmp/qemu-extract/usr/share/seabios -L /tmp/qemu-extract/usr/share/qemu"

# Звук отключаем, VGA не нужен (берём из ISO), память 512 МиБ.
# E1000 с user networking (-netdev user) — QEMU выдаёт IP через DHCP,
# но мы используем статический 10.0.2.15. Это ожидаемый адрес.
exec $QEMU \
    $BIOS_PATH \
    -m 512 \
    -cdrom /home/z/my-project/n2600-os/os.iso \
    -boot d \
    -netdev user,id=net0 \
    -device e1000,netdev=net0 \
    -serial stdio \
    -no-reboot \
    "$@"
