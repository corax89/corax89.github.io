/* gdt.h */
#ifndef GDT_H
#define GDT_H

void gdt_init(void);

#endif
