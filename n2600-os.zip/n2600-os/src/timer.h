/* timer.h — системный таймер PIT */
#ifndef TIMER_H
#define TIMER_H

#include "types.h"

void timer_init(int hz);          /* IRQ0 */
u32  timer_ticks(void);           /* тики (hz в секунду) */
u32  uptime_sec(void);            /* секунд с загрузки */

#endif
