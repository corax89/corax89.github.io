/* wm.h — оконный менеджер: окна, таскбар, меню, курсор, композитинг.
 * Это публичный API для приложений N2600-OS (см. apps_example.c и README). */
#ifndef WM_H
#define WM_H

#include "types.h"
#include "kbd.h"

#define WM_MAX_WINDOWS 12

#define TBAR_H   28   /* высота таскбара */
#define TITLE_H  24   /* высота заголовка окна */

struct window;

typedef void (*win_draw_fn)(struct window *);
typedef void (*win_key_fn)(struct window *, const key_event_t *);
typedef void (*win_mouse_fn)(struct window *, int mx, int my, u8 buttons, u8 changed);
typedef void (*win_tick_fn)(struct window *);
typedef void (*win_close_fn)(struct window *);

typedef struct window {
    int x, y, w, h;        /* геометрия вместе с рамкой */
    char title[40];
    void *data;            /* состояние приложения (malloc/free) */
    win_draw_fn   draw;     /* отрисовка содержимого (клип уже установлен) */
    win_key_fn    on_key;   /* клавиатура (только у окна в фокусе) */
    win_mouse_fn  on_mouse; /* мышь: координаты относительно содержимого */
    win_tick_fn   on_tick;  /* вызывается 2 раза в секунду */
    win_close_fn  on_close; /* освободить data перед закрытием */
} window_t;

/* создать окно (добавляется поверх остальных, окно в фокусе) */
window_t *win_create(const char *title, int x, int y, int w, int h,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data);

/* пометить окно к закрытию (безопасно вызывать из любого колбэка) */
void win_close(window_t *w);

/* запросить перерисовку содержимого окна */
void win_invalidate(window_t *w);

int  win_content_w(window_t *w);
int  win_content_h(window_t *w);

void wm_init(void);
void wm_key(const key_event_t *ev);
void wm_mouse_poll(void);   /* обработать накопившиеся события мыши */
void wm_halfsec(void);      /* тик 2 Гц (мигание курсора, on_tick, часы) */
void wm_frame(void);        /* композитинг и вывод помеченных областей */

int  wm_blink(void);        /* 0/1 для мигающего курсора */
int  wm_window_count(void);
const char *wm_window_title(int i);

#endif /* WM_H */
