/* ata.h — чтение секторов через ATA PIO и ATAPI */
#ifndef ATA_H
#define ATA_H

#include "types.h"

int   ata_init(void);          /* 1 = диск найден */
int   ata_present(void);
int   ata_is_cdrom(void);      /* 1 = это ATAPI CD-ROM (ISO-образ) */

/* Для HDD count = кол-во секторов по 512 байт. 
   Для CD-ROM count = кол-во блоков по 2048 байт. */
int   ata_read(u32 lba, u8 count, void *buf); /* ИСПРАВЛЕНО: добавлена * */

u32   ata_sectors(void);       /* полный размер в секторах (для HDD) */
const char *ata_model(void);

u16   ata_base_port(void);     /* реальный порт найденного устройства (0x1F0/0x170) */
u8    ata_drive_sel(void);     /* 0xA0=master, 0xB0=slave — селектор найденного устройства */

#endif