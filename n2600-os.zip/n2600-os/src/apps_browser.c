/* apps_browser.c — минимальный веб-браузер для N2600-OS.
 *
 * Возможности:
 *   - HTTP GET запрос (через net_http_get)
 *   - HTML → Markdown конвертер (упрощённый)
 *   - Рендеринг Markdown на экран
 *   - Просмотр .md файлов из RAMFS
 *   - Прокрутка (PgUp/PgDn/стрелки/колёсико)
 *
 * HTML→Markdown конвертер:
 *   <h1>-<h6> → # ## ### #### #####
 *   <p> → пустая строка
 *   <a href="X">Y</a> → [Y](X)
 *   <b>/<strong> → **text**
 *   <i>/<em> → *text*
 *   <code> → `text`
 *   <pre> → ```text```
 *   <ul>/<li> → - item
 *   <br> → \n
 *   <hr> → ---
 *   Остальные теги — содержимое сохраняется, теги удаляются
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"

#define BR_COLS 96
#define BR_ROWS 100
#define BR_HDR 22

typedef struct {
    char lines[BR_ROWS][BR_COLS + 1];
    int  nlines;
    int  scroll;
    int  loading;
    char url[128];
    char status[80];
} browser_t;

/* ---------- HTML → Markdown конвертер ---------- */
static int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    int mi = 0;
    int i = 0;
    int in_tag = 0;
    char tag[32];
    int tag_i = 0;
    int pre_mode = 0;
    int list_mode = 0;

    while (i < html_len && mi < md_max - 2) {
        char c = html[i];

        if (c == '<') {
            in_tag = 1;
            tag_i = 0;
            i++;
            /* Читаем имя тега */
            while (i < html_len && html[i] != '>' && tag_i < 31) {
                if (html[i] == '/' || html[i] == ' ') {
                    if (tag_i == 0 && html[i] == '/') i++;
                    else break;
                }
                tag[tag_i++] = html[i++];
            }
            tag[tag_i] = 0;
            /* Пропускаем до > */
            while (i < html_len && html[i] != '>') i++;
            if (i < html_len) i++;

            /* Обрабатываем тег */
            if (!strcmp(tag, "h1") || !strcmp(tag, "H1")) {
                md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h2") || !strcmp(tag, "H2")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h3") || !strcmp(tag, "H3")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "h4") || !strcmp(tag, "H4")) {
                md[mi++] = '#'; md[mi++] = '#'; md[mi++] = '#'; md[mi++] = '#'; md[mi++] = ' ';
            } else if (!strcmp(tag, "p") || !strcmp(tag, "P")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "br") || !strcmp(tag, "BR") ||
                       !strcmp(tag, "br/") || !strcmp(tag, "br /")) {
                md[mi++] = '\n';
            } else if (!strcmp(tag, "hr") || !strcmp(tag, "HR")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '-'; md[mi++] = '-'; md[mi++] = '-';
                md[mi++] = '\n';
            } else if (!strcmp(tag, "b") || !strcmp(tag, "B") ||
                       !strcmp(tag, "strong") || !strcmp(tag, "STRONG")) {
                md[mi++] = '*'; md[mi++] = '*';
            } else if (!strcmp(tag, "i") || !strcmp(tag, "I") ||
                       !strcmp(tag, "em") || !strcmp(tag, "EM")) {
                md[mi++] = '*';
            } else if (!strcmp(tag, "code") || !strcmp(tag, "CODE")) {
                md[mi++] = '`';
            } else if (!strcmp(tag, "pre") || !strcmp(tag, "PRE")) {
                pre_mode = !pre_mode;
                if (pre_mode) {
                    md[mi++] = '`'; md[mi++] = '`'; md[mi++] = '`';
                    md[mi++] = '\n';
                } else {
                    md[mi++] = '`'; md[mi++] = '`'; md[mi++] = '`';
                    md[mi++] = '\n';
                }
            } else if (!strcmp(tag, "ul") || !strcmp(tag, "UL") ||
                       !strcmp(tag, "ol") || !strcmp(tag, "OL")) {
                list_mode = !list_mode;
                if (list_mode) md[mi++] = '\n';
            } else if (!strcmp(tag, "li") || !strcmp(tag, "LI")) {
                if (mi > 0 && md[mi-1] != '\n') md[mi++] = '\n';
                md[mi++] = '-'; md[mi++] = ' ';
            } else if (!strcmp(tag, "a") || !strcmp(tag, "A")) {
                md[mi++] = '[';
            } else if (!strcmp(tag, "/a") || !strcmp(tag, "/A")) {
                md[mi++] = ']';
                md[mi++] = '(';
                md[mi++] = ')'; /* URL не извлекаем — упрощение */
            }
            /* Закрывающие теги форматирования */
            else if (!strcmp(tag, "/b") || !strcmp(tag, "/B") ||
                     !strcmp(tag, "/strong") || !strcmp(tag, "/STRONG")) {
                md[mi++] = '*'; md[mi++] = '*';
            } else if (!strcmp(tag, "/i") || !strcmp(tag, "/I") ||
                       !strcmp(tag, "/em") || !strcmp(tag, "/EM")) {
                md[mi++] = '*';
            } else if (!strcmp(tag, "/code") || !strcmp(tag, "/CODE")) {
                md[mi++] = '`';
            }
            /* script/style — пропускаем содержимое */
            else if (!strcmp(tag, "script") || !strcmp(tag, "SCRIPT") ||
                     !strcmp(tag, "style") || !strcmp(tag, "STYLE")) {
                while (i < html_len) {
                    if (html[i] == '<' && i+1 < html_len &&
                        (html[i+1] == '/' || html[i+1] == 'S' || html[i+1] == 's')) {
                        /* Проверяем закрывающий тег */
                        int save_i = i;
                        int save_tag_i = tag_i;
                        i++;
                        tag_i = 0;
                        while (i < html_len && html[i] != '>' && tag_i < 31)
                            tag[tag_i++] = html[i++];
                        tag[tag_i] = 0;
                        if (i < html_len) i++;
                        if (tag[0] == '/') break;
                        i = save_i;
                        tag_i = save_tag_i;
                        i++;
                    } else i++;
                }
            }
            continue;
        }

        if (in_tag) continue;

        /* Преобразуем HTML entities */
        if (c == '&') {
            if (i+5 < html_len && !strncmp(html+i, "&amp;", 5)) {
                md[mi++] = '&'; i += 5; continue;
            }
            if (i+5 < html_len && !strncmp(html+i, "&lt;", 4)) {
                md[mi++] = '<'; i += 4; continue;
            }
            if (i+5 < html_len && !strncmp(html+i, "&gt;", 4)) {
                md[mi++] = '>'; i += 4; continue;
            }
            if (i+6 < html_len && !strncmp(html+i, "&quot;", 6)) {
                md[mi++] = '"'; i += 6; continue;
            }
            if (i+6 < html_len && !strncmp(html+i, "&nbsp;", 6)) {
                md[mi++] = ' '; i += 6; continue;
            }
            if (i+5 < html_len && !strncmp(html+i, "&#39;", 5)) {
                md[mi++] = '\''; i += 5; continue;
            }
        }

        /* В pre mode сохраняем всё как есть */
        if (pre_mode) {
            md[mi++] = c;
            i++;
            continue;
        }

        /* Сжимаем пробелы и переводы строк вне pre */
        if (c == '\n' || c == '\r') {
            if (mi > 0 && md[mi-1] != '\n' && md[mi-1] != ' ')
                md[mi++] = ' ';
            i++;
            continue;
        }
        if (c == '\t') {
            if (mi > 0 && md[mi-1] != ' ')
                md[mi++] = ' ';
            i++;
            continue;
        }
        if (c == ' ' && mi > 0 && md[mi-1] == ' ') {
            i++;
            continue;
        }

        md[mi++] = c;
        i++;
    }
    md[mi] = 0;
    return mi;
}

/* ---------- Разбивка Markdown на строки ---------- */
static void md_to_lines(const char *md, int md_len, browser_t *b)
{
    b->nlines = 0;
    int i = 0;
    while (i < md_len && b->nlines < BR_ROWS) {
        int start = i;
        while (i < md_len && md[i] != '\n' && (i - start) < BR_COLS) i++;
        int len = i - start;
        if (len > BR_COLS) len = BR_COLS;
        memcpy(b->lines[b->nlines], md + start, len);
        b->lines[b->nlines][len] = 0;
        b->nlines++;
        if (i < md_len && md[i] == '\n') i++;
    }
}

/* ---------- Рендеринг ---------- */
static void br_draw(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка */
    fb_fill_rect(0, 0, cw, BR_HDR, fb_rgb(0x1E, 0x4A, 0x73));
    fb_text(4, 4, b->url[0] ? b->url : "(no URL)", fb_rgb(0xE6, 0xEA, 0xEE), -1);
    fb_text(4, 14, b->status, fb_rgb(0x9A, 0xA3, 0xAC), -1);

    /* Контент */
    int area_y = BR_HDR;
    int area_h = ch - BR_HDR - 14;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;

    fb_fill_rect(0, area_y, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    int max_scroll = b->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (b->scroll > max_scroll) b->scroll = max_scroll;
    if (b->scroll < 0) b->scroll = 0;

    int start = b->scroll;
    int end = start + vis;
    if (end > b->nlines) end = b->nlines;

    int y = area_y + 2;
    for (int i = start; i < end; i++, y += 16) {
        u32 color = fb_rgb(0xE6, 0xEA, 0xEE);
        /* Заголовки (#, ##) — жёлтым */
        if (b->lines[i][0] == '#') color = fb_rgb(0xFF, 0xE0, 0x60);
        /* Ссылки [text](url) — голубым */
        else if (b->lines[i][0] == '[') color = fb_rgb(0x6F, 0xB3, 0xF2);
        /* Списки (-) — серым */
        else if (b->lines[i][0] == '-') color = fb_rgb(0x9A, 0xA3, 0xAC);

        /* Обрезаем строку под ширину окна */
        int max_chars = (cw - 8) / 8;
        char tmp[BR_COLS + 1];
        int sl = (int)strlen(b->lines[i]);
        if (sl > max_chars) sl = max_chars;
        memcpy(tmp, b->lines[i], sl);
        tmp[sl] = 0;
        fb_text(4, y, tmp, color, -1);
    }

    /* Полоса прокрутки */
    if (max_scroll > 0) {
        int sb_x = cw - 6;
        int sb_h = area_h - 4;
        fb_fill_rect(sb_x, area_y + 2, 4, sb_h, fb_rgb(0x1E, 0x22, 0x28));
        int thumb_h = sb_h * vis / b->nlines;
        if (thumb_h < 8) thumb_h = 8;
        int thumb_y = area_y + 2 + (sb_h - thumb_h) * (max_scroll - b->scroll) / max_scroll;
        fb_fill_rect(sb_x, thumb_y, 4, thumb_h, fb_rgb(0x6F, 0xB3, 0xF2));
    }

    /* Статус-бар */
    fb_fill_rect(0, ch - 14, cw, 14, fb_rgb(0x12, 0x16, 0x1B));
    char st[96];
    snprintf(st, sizeof(st), "Lines: %d  Scroll: %d/%d  %s",
             b->nlines, b->scroll, max_scroll, b->loading ? "Loading..." : "Ready");
    fb_text(4, ch - 12, st, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void br_key(window_t *w, const key_event_t *ev)
{
    browser_t *b = (browser_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    int ch = win_content_h(w);
    int vis = (ch - BR_HDR - 14) / 16;
    int max_scroll = b->nlines - vis;
    if (max_scroll < 0) max_scroll = 0;

    if (ev->code == 0x49 || ev->code == KBD_UP) { /* PgUp/↑ */
        if (b->scroll < max_scroll) b->scroll++;
        win_invalidate(w);
    } else if (ev->code == 0x51 || ev->code == KBD_DOWN) { /* PgDn/↓ */
        if (b->scroll > 0) b->scroll--;
        win_invalidate(w);
    } else if (ev->code == 0x47) { /* Home */
        b->scroll = max_scroll;
        win_invalidate(w);
    } else if (ev->code == 0x4F) { /* End */
        b->scroll = 0;
        win_invalidate(w);
    } else if (ev->ch == 0x1B || ev->code == 0x01) {
        win_close(w);
    }
}

static void br_close(window_t *w)
{
    browser_t *b = (browser_t *)w->data;
    if (b) free(b);
}

/* ---------- Загрузка контента и конвертация ---------- */
static void browser_load_content(browser_t *b, const char *url,
                                  const char *content, int len)
{
    strncpy(b->url, url ? url : "", sizeof(b->url) - 1);
    b->url[sizeof(b->url) - 1] = 0;
    b->loading = 0;

    /* Проверяем: это HTML или уже Markdown? */
    int is_html = 0;
    for (int i = 0; i < len && i < 200; i++) {
        if (content[i] == '<') { is_html = 1; break; }
    }

    static char md[8192];
    int md_len;
    if (is_html) {
        snprintf(b->status, sizeof(b->status), "Converting HTML→Markdown (%d bytes)", len);
        md_len = html_to_md(content, len, md, sizeof(md));
    } else {
        /* Уже Markdown — копируем как есть */
        md_len = len < (int)sizeof(md) ? len : (int)sizeof(md) - 1;
        memcpy(md, content, md_len);
        md[md_len] = 0;
        snprintf(b->status, sizeof(b->status), "Markdown (%d bytes)", len);
    }

    /* Разбиваем на строки */
    md_to_lines(md, md_len, b);
    b->scroll = 0;
    snprintf(b->status, sizeof(b->status), "Loaded: %d lines", b->nlines);
}

void app_browser_open(void)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return;
    memset(b, 0, sizeof(*b));
    strcpy(b->url, "(empty)");
    strcpy(b->status, "Enter URL via curl, or load .md file");

    /* Тестовый контент — краткая справка */
    static const char *help_md =
        "# N2600-OS Browser\n\n"
        "## Возможности\n"
        "- `curl <url>` — HTTP GET запрос\n"
        "- Открытие .md файлов из RAMFS\n"
        "- HTML → Markdown конвертация\n\n"
        "## Команды терминала\n"
        "- `curl http://example.com/` — загрузить страницу\n"
        "- `spawn browser` — открыть браузер\n\n"
        "## Поддержка Markdown\n"
        "- **Жирный** текст\n"
        "- *Курсив* текст\n"
        "- `Код`\n"
        "- Заголовки разных уровней\n"
        "- Списки\n\n"
        "---\n"
        "Прокрутка: PgUp/PgDn, стрелки, колёсико мыши\n";
    browser_load_content(b, "help", help_md, (int)strlen(help_md));

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 400;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Браузер", (int)W/2 - ww/2, 16, ww, wh,
               br_draw, br_key, NULL, NULL, br_close, b);
}

void app_browser_open_with(const char *url, const char *content, int len)
{
    browser_t *b = (browser_t *)malloc(sizeof(browser_t));
    if (!b) return;
    memset(b, 0, sizeof(*b));
    browser_load_content(b, url, content, len);

    u32 W = fb_width(), H = fb_height();
    int ww = 700;
    int wh = 400;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Браузер", (int)W/2 - ww/2, 16, ww, wh,
               br_draw, br_key, NULL, NULL, br_close, b);
}
