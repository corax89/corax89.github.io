/* e1000.c — драйвер Intel 82540EM (E1000) Gigabit Ethernet.
 *
 * Реализация минимального polling-драйвера для VMware и QEMU:
 *   1. PCI-сканирование (vendor=0x8086, поддерживаем devices: 0x100E/0x100F/0x1010/0x1011/0x1013/0x1015/0x1016/0x1017/0x1018/0x1019/0x101A/0x101D/0x1076/0x1077/0x1078/0x107C/0x10A0/0x10D3/0x1533)
 *   2. Включение Bus Master + Memory Space
 *   3. Сброс чипа
 *   4. Чтение MAC-адреса из EEPROM (EERD)
 *   5. Настройка TX/RX descriptor rings (legacy mode, 16-byte descriptors)
 *   6. Приём/передача через опрос (polling)
 *
 * Особенности:
 *   - Дескрипторы выделяются статически по 64 приёма/64 передачи (64*16=1024 байта)
 *   - Буферы пакетов выделаются malloc-ом
 *   - Прерывания замаскированы, polling из главного цикла
 *   - Multicast не настроен (BAM бит установлен для broadcast приёма)
 */
#include "e1000.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);
static void serial_putc_local(char c);
static void serial_puthex_local(u32 v);

/* ---------- PCI IDs (Intel) ---------- */
#define INTEL_VENDOR_ID  0x8086
/* Поддерживаемые device IDs. QEMU/VMware обычно 0x100E (82540EM). */
static const u16 e1000_device_ids[] = {
    0x100E, /* 82540EM (QEMU, VMware default) */
    0x100F, /* 82545EM */
    0x1010, /* 82546GB */
    0x1011, /* 82545EM */
    0x1013, /* 82541EI */
    0x1015, /* 82541EI */
    0x1016, /* 82540EP */
    0x1017, /* 82540EP */
    0x101D, /* 82572EI */
    0x1076, /* 82572EI */
    0x1077, /* 82572EI */
    0x1078, /* 82573L */
    0x107C, /* 82573L */
    0x10A0, /* 82574L */
    0x10D3, /* 82574L */
    0x1533, /* I210 */
    0  /* sentinel */
};

/* ---------- E1000 регистры (offsets от MMIO base) ---------- */
#define E1000_CTRL    0x0000
#define E1000_STATUS  0x0008
#define E1000_EECD    0x0010
#define E1000_EERD    0x0014   /* EEPROM Read */
#define E1000_RDBAL   0x2800   /* RX Descriptor Base Low */
#define E1000_RDBAH   0x2804   /* RX Descriptor Base High */
#define E1000_RDLEN   0x2808   /* RX Descriptor Length */
#define E1000_RDH     0x2810   /* RX Descriptor Head */
#define E1000_RDT     0x2818   /* RX Descriptor Tail */
#define E1000_RCTL    0x0100   /* RX Control */
#define E1000_TDBAL   0x3800   /* TX Descriptor Base Low */
#define E1000_TDBAH   0x3804
#define E1000_TDLEN   0x3808
#define E1000_TDH     0x3810
#define E1000_TDT     0x3818
#define E1000_TCTL    0x0400   /* TX Control */
#define E1000_IMC     0x00D8   /* Interrupt Mask Clear */
#define E1000_RAL     0x5400   /* Receive Address Low */
#define E1000_RAH     0x5404   /* Receive Address High */
#define E1000_MTA     0x5200   /* Multicast Table Array */

/* CTRL bits */
#define CTRL_RST       (1u << 3)
#define CTRL_ASRE      (1u << 5)
#define CTRL_LRST      (1u << 7)
#define CTRL_SLU       (1u << 6)   /* Set Link Up */
#define CTRL_FRCSPD    (1u << 11)

/* EECD bits */
#define EECD_EE_PRES   (1u << 8)
#define EECD_SK        (1u << 0)
#define EECD_CS        (1u << 1)
#define EECD_DI        (1u << 2)
#define EECD_DO        (1u << 3)

/* EERD bits */
#define EERD_START     (1u << 0)
#define EERD_DONE      (1u << 1)
#define EERD_ADDR_SHIFT 8
#define EERD_DATA_SHIFT 16

/* RCTL bits */
#define RCTL_EN        (1u << 1)   /* Receiver Enable */
#define RCTL_SBP       (1u << 2)   /* Store Bad Packets */
#define RCTL_UPE       (1u << 3)   /* Unicast Promiscuous */
#define RCTL_MPE       (1u << 4)   /* Multicast Promiscuous */
#define RCTL_BAM       (1u << 10)  /* Broadcast Address Mode */
#define RCTL_BSIZE_2048 0
#define RCTL_BSIZE_1024 (1u << 16)
#define RCTL_BSIZE_512  (1u << 17)
#define RCTL_BSIZE_256  ((1u<<16)|(1u<<17))
#define RCTL_SECRC     (1u << 12)  /* Strip Ethernet CRC */

/* TCTL bits */
#define TCTL_EN        (1u << 1)   /* Transmit Enable */
#define TCTL_PSP       (1u << 3)   /* Pad Short Packets */
#define TCTL_CT_SHIFT  4
#define TCTL_COLD_SHIFT 12

/* Status */
#define STATUS_LU      (1u << 1)   /* Link Up */

/* Legacy descriptor (16 bytes). */
typedef struct __attribute__((packed, aligned(16))) {
    u64 addr;        /* buffer address */
    u16 length;      /* data length */
    u16 csum;        /* checksum (or 0) */
    u8  status;      /* DD=0x01, etc. */
    u8  errors;
    u16 special;     /* VLAN tag (or 0) */
} e1000_desc_t;

#define E1000_RX_COUNT 32
#define E1000_TX_COUNT 32

/* TX descriptor command bits (in legacy mode these are in low byte of special field,
 * but for legacy "Read" descriptor format, status field is at offset 8 and DD bit
 * is the LSB. We use the legacy "legacy" descriptor format. */
#define TXD_CMD_EOP    0x01   /* End of Packet */
#define TXD_CMD_IFCS   0x02
#define TXD_CMD_RS     0x08   /* Report Status (set DD on completion) */

#define RXD_STAT_DD    0x01   /* Descriptor Done */

typedef struct {
    int  present;
    int  bus, dev, func;
    u32  mmio_base;
    u16  device_id;
    char chip_name[40];
    u8   mac[6];
    /* Descriptor rings */
    e1000_desc_t rx_desc[E1000_RX_COUNT] __attribute__((aligned(16)));
    e1000_desc_t tx_desc[E1000_TX_COUNT] __attribute__((aligned(16)));
    u8   *rx_bufs[E1000_RX_COUNT];   /* packet buffers (each 2048 bytes) */
    u8   *tx_bufs[E1000_TX_COUNT];
    u32  rx_tail;
    u32  tx_head;
    u32  tx_tail;
} e1000_state_t;

static e1000_state_t g_e1000;

/* ---------- MMIO helpers ---------- */
static inline u32 e1000_read(u32 reg)
{
    return *(volatile u32 *)(unsigned long)(g_e1000.mmio_base + reg);
}

static inline void e1000_write(u32 reg, u32 val)
{
    *(volatile u32 *)(unsigned long)(g_e1000.mmio_base + reg) = val;
}

/* ---------- Отладка ---------- */
static void serial_putc_local(char c)
{
    while (!(inb(0x3F8 + 5) & 0x20)) { }
    outb(0x3F8, (u8)c);
}

static void serial_puts_local(const char *s)
{
    for (; *s; s++) {
        if (*s == '\n') serial_putc_local('\r');
        serial_putc_local(*s);
    }
}

static void serial_puthex_local(u32 v)
{
    const char *d = "0123456789abcdef";
    serial_puts_local("0x");
    for (int i = 28; i >= 0; i -= 4) serial_putc_local(d[(v >> i) & 0xF]);
}

/* ---------- EEPROM чтение (одного 16-битного слова) ---------- */
static int e1000_eeprom_read(u8 addr, u16 *out)
{
    u32 v = ((u32)addr << EERD_ADDR_SHIFT) | EERD_START;
    e1000_write(E1000_EERD, v);

    /* Ждём DONE до ~1ms (10 тиков по 100Гц = 100ms — с запасом) */
    for (int i = 0; i < 100000; i++) {
        u32 s = e1000_read(E1000_EERD);
        if (s & EERD_DONE) {
            *out = (u16)((s >> EERD_DATA_SHIFT) & 0xFFFF);
            return 1;
        }
    }
    return 0;
}

/* ---------- Сброс чипа ---------- */
static void e1000_reset(void)
{
    u32 ctrl = e1000_read(E1000_CTRL);
    /* Сброс: rst=1, потом ждём очистки RST */
    e1000_write(E1000_CTRL, ctrl | CTRL_RST);
    /* Подождём ~10 мс: IO-задержка (outb 0x80 занимает ~1мкс на старых чипсетах).
     * Не используем timer_ticks(), потому что PIT-прерывания могут быть ещё
     * замаскированы. 10000 итераций — достаточно на любой скорости CPU. */
    for (volatile int i = 0; i < 50000; i++) {
        (void)inb(0x80);
    }
    /* Ждём очистки RST (макс ~1 секунда эмуляции) */
    for (int i = 0; i < 1000000; i++) {
        u32 c = e1000_read(E1000_CTRL);
        if (!(c & (CTRL_RST | CTRL_LRST))) break;
    }
}

/* ---------- Настройка RX ---------- */
static void e1000_setup_rx(void)
{
    /* Выделяем буферы */
    for (int i = 0; i < E1000_RX_COUNT; i++) {
        g_e1000.rx_bufs[i] = (u8 *)malloc(2048);
        if (g_e1000.rx_bufs[i]) {
            memset(g_e1000.rx_bufs[i], 0, 2048);
        }
        g_e1000.rx_desc[i].addr = (u64)(unsigned long)g_e1000.rx_bufs[i];
        g_e1000.rx_desc[i].length = 2048;
        g_e1000.rx_desc[i].status = 0;
        g_e1000.rx_desc[i].errors = 0;
        g_e1000.rx_desc[i].special = 0;
        g_e1000.rx_desc[i].csum = 0;
    }
    g_e1000.rx_tail = 0;

    /* RDBAL/RDBAH */
    u32 addr = (u32)(unsigned long)g_e1000.rx_desc;
    e1000_write(E1000_RDBAL, addr);
    e1000_write(E1000_RDBAH, 0);
    e1000_write(E1000_RDLEN, E1000_RX_COUNT * sizeof(e1000_desc_t));
    e1000_write(E1000_RDH, 0);
    e1000_write(E1000_RDT, E1000_RX_COUNT - 1);

    /* RCTL: enable, broadcast accept, MPE/UPE off (accept own MAC + broadcast),
     * buffer size 2048, strip CRC */
    u32 rctl = RCTL_EN | RCTL_BAM | RCTL_BSIZE_2048 | RCTL_SECRC;
    e1000_write(E1000_RCTL, rctl);
}

/* ---------- Настройка TX ---------- */
static void e1000_setup_tx(void)
{
    /* Очищаем дескрипторы */
    for (int i = 0; i < E1000_TX_COUNT; i++) {
        g_e1000.tx_bufs[i] = (u8 *)malloc(E1000_PKT_MAX);
        if (g_e1000.tx_bufs[i]) {
            memset(g_e1000.tx_bufs[i], 0, E1000_PKT_MAX);
        }
        g_e1000.tx_desc[i].addr = 0;
        g_e1000.tx_desc[i].length = 0;
        g_e1000.tx_desc[i].status = 0;
        g_e1000.tx_desc[i].csum = 0;
        g_e1000.tx_desc[i].errors = 0;
        g_e1000.tx_desc[i].special = 0;
    }
    g_e1000.tx_head = 0;
    g_e1000.tx_tail = 0;

    u32 addr = (u32)(unsigned long)g_e1000.tx_desc;
    e1000_write(E1000_TDBAL, addr);
    e1000_write(E1000_TDBAH, 0);
    e1000_write(E1000_TDLEN, E1000_TX_COUNT * sizeof(e1000_desc_t));
    e1000_write(E1000_TDH, 0);
    e1000_write(E1000_TDT, 0);

    /* TCTL: enable, pad short packets, cold=0x10 (full-duplex), collision threshold = 0x10 */
    u32 tctl = TCTL_EN | TCTL_PSP
             | (0x10 << TCTL_CT_SHIFT)
             | (0x40 << TCTL_COLD_SHIFT);
    e1000_write(E1000_TCTL, tctl);
}

/* ---------- Поиск устройства по PCI ---------- */
static int e1000_find_device(u16 *out_device_id)
{
    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            /* Без multi-function сканирования — но проверим func 0/1 */
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor != INTEL_VENDOR_ID) {
                    if (func == 0) {
                        u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                        if (!(hdr & 0x80)) break;
                    }
                    continue;
                }
                /* Совпадение device id с известными E1000 */
                for (int k = 0; e1000_device_ids[k]; k++) {
                    if (device == e1000_device_ids[k]) {
                        g_e1000.bus = bus;
                        g_e1000.dev = dev;
                        g_e1000.func = func;
                        g_e1000.device_id = device;
                        *out_device_id = device;
                        return 1;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    return 0;
}

/* ---------- Чтение MAC ----------
 * На QEMU EEPROM читается через EERD (legacy mode).
 * На реальном железе/VMware RAL/RAH могут быть уже запрограммированы
 * BIOS/прошивкой — попробуем их сначала. */
static int e1000_read_mac(void)
{
    /* Способ 1: прочитать RAL/RAH (если BIOS уже записал MAC). */
    u32 ral = e1000_read(E1000_RAL);
    u32 rah = e1000_read(E1000_RAH);
    if (ral != 0 && ral != 0xFFFFFFFFu && (rah & 0xFFFF) != 0) {
        g_e1000.mac[0] = (u8)(ral & 0xFF);
        g_e1000.mac[1] = (u8)((ral >> 8) & 0xFF);
        g_e1000.mac[2] = (u8)((ral >> 16) & 0xFF);
        g_e1000.mac[3] = (u8)((ral >> 24) & 0xFF);
        g_e1000.mac[4] = (u8)(rah & 0xFF);
        g_e1000.mac[5] = (u8)((rah >> 8) & 0xFF);
        /* Проверим, что MAC не 00:00:00:00:00:00 и не FF:FF:FF:FF:FF:FF */
        int all_zero = 1, all_ff = 1;
        for (int i = 0; i < 6; i++) {
            if (g_e1000.mac[i] != 0) all_zero = 0;
            if (g_e1000.mac[i] != 0xFF) all_ff = 0;
        }
        if (!all_zero && !all_ff) {
            serial_puts_local("[e1000] MAC read from RAL/RAH\n");
            return 1;
        }
    }

    /* Способ 2: чтение из EEPROM через EERD (legacy 82540EM mode). */
    u16 words[3];
    int ok = 1;
    for (int i = 0; i < 3; i++) {
        if (!e1000_eeprom_read((u8)i, &words[i])) {
            ok = 0;
            break;
        }
    }
    if (ok) {
        g_e1000.mac[0] = (u8)(words[0] & 0xFF);
        g_e1000.mac[1] = (u8)((words[0] >> 8) & 0xFF);
        g_e1000.mac[2] = (u8)(words[1] & 0xFF);
        g_e1000.mac[3] = (u8)((words[1] >> 8) & 0xFF);
        g_e1000.mac[4] = (u8)(words[2] & 0xFF);
        g_e1000.mac[5] = (u8)((words[2] >> 8) & 0xFF);
        /* Проверим валидность */
        int all_zero = 1, all_ff = 1;
        for (int i = 0; i < 6; i++) {
            if (g_e1000.mac[i] != 0) all_zero = 0;
            if (g_e1000.mac[i] != 0xFF) all_ff = 0;
        }
        if (!all_zero && !all_ff) {
            serial_puts_local("[e1000] MAC read from EEPROM\n");
            return 1;
        }
    }
    return 0;
}

/* ---------- Программирование MAC-фильтра (RAL/RAH 0) ---------- */
static void e1000_program_mac(void)
{
    u32 ral = ((u32)g_e1000.mac[0])
            | ((u32)g_e1000.mac[1] << 8)
            | ((u32)g_e1000.mac[2] << 16)
            | ((u32)g_e1000.mac[3] << 24);
    u32 rah = ((u32)g_e1000.mac[4])
            | ((u32)g_e1000.mac[5] << 8)
            | (1u << 31);  /* AV bit — Address Valid */
    e1000_write(E1000_RAL, ral);
    e1000_write(E1000_RAH, rah);

    /* Очистим MTA (multicast) — 128 записей по 4 байта */
    for (int i = 0; i < 128; i++) {
        e1000_write(E1000_MTA + i * 4, 0);
    }
}

/* ---------- Публичный API ---------- */

int e1000_init(void)
{
    g_e1000.present = 0;
    g_e1000.mmio_base = 0;

    serial_puts_local("[e1000] init...\n");

    u16 dev_id = 0;
    if (!e1000_find_device(&dev_id)) {
        serial_puts_local("[e1000] no Intel NIC found\n");
        return 0;
    }

    /* Считаем BAR0 (MMIO base) */
    u32 bar0 = pci_read32(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x10);
    g_e1000.mmio_base = bar0 & 0xFFFFFFF0u;

    /* Включаем Bus Master + Memory Space */
    u16 cmd = pci_read16(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x04);
    cmd |= 0x06;   /* BME | MSE */
    pci_write16(g_e1000.bus, g_e1000.dev, g_e1000.func, 0x04, cmd);

    /* Имя чипа */
    snprintf(g_e1000.chip_name, sizeof(g_e1000.chip_name),
             "Intel 8254x (dev %04x)", (unsigned)dev_id);

    serial_puts_local("[e1000] found device=0x");
    {
        char buf[16];
        const char *h = "0123456789abcdef";
        buf[0]=h[(dev_id>>12)&0xF]; buf[1]=h[(dev_id>>8)&0xF];
        buf[2]=h[(dev_id>>4)&0xF];  buf[3]=h[dev_id&0xF];
        buf[4]=0;
        serial_puts_local(buf);
        serial_puts_local(" mmio=0x");
        serial_puthex_local(g_e1000.mmio_base);
        serial_puts_local("\n");
    }

    /* Сброс */
    serial_puts_local("[e1000] resetting chip...\n");
    e1000_reset();

    /* Отключаем все прерывания (мы работаем в polling) */
    e1000_write(E1000_IMC, 0xFFFFFFFFu);

    /* Установим SLU */
    {
        u32 c = e1000_read(E1000_CTRL);
        c |= CTRL_SLU;
        e1000_write(E1000_CTRL, c);
    }

    /* Чтение MAC из EEPROM */
    if (!e1000_read_mac()) {
        serial_puts_local("[e1000] EEPROM read failed, using fallback MAC\n");
        /* QEMU/VMware fallback: 52:54:00:12:34:56 (QEMU default) */
        g_e1000.mac[0] = 0x52; g_e1000.mac[1] = 0x54; g_e1000.mac[2] = 0x00;
        g_e1000.mac[3] = 0x12; g_e1000.mac[4] = 0x34; g_e1000.mac[5] = 0x56;
    }

    serial_puts_local("[e1000] MAC: ");
    {
        const char *h = "0123456789abcdef";
        for (int i = 0; i < 6; i++) {
            serial_putc_local(h[(g_e1000.mac[i] >> 4) & 0xF]);
            serial_putc_local(h[g_e1000.mac[i] & 0xF]);
            if (i < 5) serial_putc_local(':');
        }
        serial_puts_local("\n");
    }

    /* Программируем MAC в RAL/RAH */
    e1000_program_mac();

    /* Настройка TX и RX колец */
    e1000_setup_tx();
    e1000_setup_rx();

    /* Подождём установки линка */
    u32 t0 = timer_ticks();
    while ((i32)(timer_ticks() - t0) < 50) {
        if (e1000_read(E1000_STATUS) & STATUS_LU) break;
    }
    u32 status = e1000_read(E1000_STATUS);
    serial_puts_local("[e1000] status: 0x");
    serial_puthex_local(status);
    serial_puts_local("\n");

    g_e1000.present = 1;
    serial_puts_local("[e1000] ready\n");
    return 1;
}

int e1000_present(void)
{
    return g_e1000.present;
}

const char *e1000_chip_name(void)
{
    return g_e1000.chip_name[0] ? g_e1000.chip_name : "no NIC";
}

int e1000_get_mac(u8 out_mac[6])
{
    if (!g_e1000.present) return 0;
    memcpy(out_mac, g_e1000.mac, 6);
    return 1;
}

void e1000_set_dest_mac(const u8 mac[6])
{
    (void)mac;
    /* сейчас используется promiscuous + broadcast — заглушка */
}

/* ---------- Отправка пакета ---------- */
int e1000_send(const void *buf, u32 len)
{
    if (!g_e1000.present) return -1;
    if (len == 0 || len > E1000_PKT_MAX) return -1;

    /* Проверим, есть ли свободный дескриптор */
    u32 head = e1000_read(E1000_TDH);
    u32 tail = g_e1000.tx_tail;
    u32 next = (tail + 1) % E1000_TX_COUNT;
    if (next == head) {
        /* Кольцо заполнено — подождём немного */
        for (int i = 0; i < 1000; i++) {
            head = e1000_read(E1000_TDH);
            if (next != head) break;
        }
        if (next == head) return -1;
    }

    /* Копируем данные в наш буфер */
    u8 *tbuf = g_e1000.tx_bufs[tail];
    if (!tbuf) return -1;
    memcpy(tbuf, buf, len);
    /* Если пакет короче 60 байт — дополним нулями (CSMA/CD минимум) */
    if (len < 60) {
        for (u32 i = len; i < 60; i++) tbuf[i] = 0;
        len = 60;
    }

    /* Заполняем дескриптор */
    g_e1000.tx_desc[tail].addr = (u64)(unsigned long)tbuf;
    g_e1000.tx_desc[tail].length = (u16)len;
    g_e1000.tx_desc[tail].csum = 0;
    g_e1000.tx_desc[tail].status = 0;
    g_e1000.tx_desc[tail].errors = 0;
    /* cmd field: EOP | IFCS | RS в special */
    g_e1000.tx_desc[tail].special = TXD_CMD_EOP | TXD_CMD_IFCS | TXD_CMD_RS;

    /* Уведомляем чип: продвигаем tail */
    g_e1000.tx_tail = next;
    e1000_write(E1000_TDT, g_e1000.tx_tail);

    return (int)len;
}

/* ---------- Приём пакета ---------- */
u32 e1000_recv(void *out_buf, u32 out_max)
{
    if (!g_e1000.present) return 0;
    u32 head = e1000_read(E1000_RDH);
    u32 tail = g_e1000.rx_tail;
    if (head == tail) return 0;   /* пусто */

    /* Есть пакет — дескриптор [tail] обработан? */
    e1000_desc_t *d = &g_e1000.rx_desc[tail];
    if (!(d->status & RXD_STAT_DD)) return 0;

    u32 len = d->length;
    if (len > E1000_PKT_MAX) len = E1000_PKT_MAX;
    u32 copy = (len < out_max) ? len : out_max;
    if (g_e1000.rx_bufs[tail]) {
        memcpy(out_buf, g_e1000.rx_bufs[tail], copy);
    }

    /* Возвращаем дескриптор в пул */
    d->status = 0;
    d->errors = 0;
    d->length = 2048;
    d->special = 0;
    g_e1000.rx_tail = (tail + 1) % E1000_RX_COUNT;
    e1000_write(E1000_RDT, (g_e1000.rx_tail == 0) ? (E1000_RX_COUNT - 1) : (g_e1000.rx_tail - 1));

    return len;
}

/* ---------- Polling: проверим наличие пакетов ---------- */
void e1000_poll(void)
{
    /*Polling делается через e1000_recv из главного цикла/стека.
     * Здесь мы только пинаем чип, проверяя состояние ICR (если захотим прерывания). */
    (void)0;
}
