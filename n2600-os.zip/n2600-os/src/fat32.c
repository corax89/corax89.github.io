/* fat32.c — драйвер FAT32 (чтение + запись) с backend-абстракцией.
 *
 * Поддерживает два backend'а:
 *   - ATA (HDD): fat32_init() — использует ata_read для секторов.
 *   - USB (флешка): fat32_init_usb() — использует usb_ehci_read_sector
 *     и usb_ehci_write_sector для секторов.
 *
 * Только один backend активен одновременно. Для переключения вызовите
 * соответствующую init-функцию (она переинициализирует BPB и состояние).
 *
 * Запись (через fat32_write_sector) работает только с USB-флешкой.
 */
#include "fat32.h"
#include "ata.h"
#include "usb_ehci.h"
#include "mem.h"
#include "string.h"

static int  ready = 0;
static int  is_usb = 0;

typedef struct {
    u16 bytes_per_sector;
    u8  sectors_per_cluster;
    u16 reserved_sectors;
    u8  num_fats;
    u32 total_sectors;
    u32 fat_size;
    u32 root_cluster;
} bpb_t;

static bpb_t bpb;
static u32   data_start = 0;
static u32   cluster_size = 0;
static u8   *cluster_buf = NULL;
static char  label[12];

/* Backend-абстракция: функция чтения сектора 512 байт. */
static int (*fat32_read_fn)(u32 lba, void *buf) = NULL;

/* Обёртки для двух backend'ов. */
static int fat32_read_ata(u32 lba, void *buf) { return ata_read(lba, 1, buf); }
static int fat32_read_usb(u32 lba, void *buf) { return usb_ehci_read_sector(lba, buf); }

int fat32_ready(void)       { return ready; }
int fat32_is_usb(void)      { return is_usb; }
u32 fat32_root_cluster(void){ return bpb.root_cluster; }
const char *fat32_label(void) { return label; }

static int read_cluster(u32 cluster, void *buf) {
    if (cluster < 2) return 0;
    u32 lba = data_start + (cluster - 2) * bpb.sectors_per_cluster;
    u8 *p = (u8 *)buf;
    for (u8 i = 0; i < bpb.sectors_per_cluster; i++) {
        if (!fat32_read_fn(lba + i, p + i * 512)) return 0;
    }
    return 1;
}

static u32 next_cluster(u32 cluster) {
    u32 off = cluster * 4;
    u32 sect = bpb.reserved_sectors + off / bpb.bytes_per_sector;
    u32 e    = off % bpb.bytes_per_sector;
    u8 sec[512];
    if (!fat32_read_fn(sect, sec)) return 0x0FFFFFFFu;
    u32 v = (u32)sec[e] | ((u32)sec[e+1] << 8) |
            ((u32)sec[e+2] << 16) | ((u32)sec[e+3] << 24);
    return v & 0x0FFFFFFFu;
}

/* Внутренняя инициализация (читает BPB, настраивает состояние). */
static int fat32_init_internal(void) {
    ready = 0;

    u8 bs[512];
    if (!fat32_read_fn(0, bs)) return 0;
    if (bs[510] != 0x55 || bs[511] != 0xAA) return 0;

    u16 bps = (u16)(bs[11] | (bs[12] << 8));
    if (bps != 512) return 0;
    u8  spc = bs[13];
    if (spc == 0 || (spc & (spc - 1))) return 0;
    u16 rsvd = (u16)(bs[14] | (bs[15] << 8));
    u8  nfat = bs[16];
    u32 tot  = (u32)bs[32] | ((u32)bs[33] << 8) | ((u32)bs[34] << 16) | ((u32)bs[35] << 24);
    u32 fsz  = (u32)bs[36] | ((u32)bs[37] << 8) | ((u32)bs[38] << 16) | ((u32)bs[39] << 24);
    u32 root = (u32)bs[44] | ((u32)bs[45] << 8) | ((u32)bs[46] << 16) | ((u32)bs[47] << 24);

    if (tot == 0 || fsz == 0 || nfat == 0 || root < 2) return 0;
    if (fsz > 0x10000u || nfat > 4 || rsvd < 1 || spc > 128 || tot < 0x10000u) return 0;

    u32 data_secs = tot - (rsvd + nfat * fsz);
    u32 clusters  = data_secs / spc;
    if (clusters < 65525u || root > clusters + 2) return 0;
    if ((u32)bps * spc > 0x10000u) return 0;
    if (memcmp(bs + 82, "FAT32", 5) != 0) return 0;

    bpb.bytes_per_sector    = bps;
    bpb.sectors_per_cluster = spc;
    bpb.reserved_sectors    = rsvd;
    bpb.num_fats            = nfat;
    bpb.total_sectors       = tot;
    bpb.fat_size            = fsz;
    bpb.root_cluster        = root;

    data_start   = rsvd + nfat * fsz;
    cluster_size = bps * spc;

    memcpy(label, bs + 71, 11); label[11] = 0;
    for (int i = 10; i >= 0 && label[i] == ' '; i--) label[i] = 0;

    if (cluster_buf) { free(cluster_buf); cluster_buf = NULL; }
    cluster_buf = (u8 *)malloc(cluster_size);
    if (!cluster_buf) return 0;

    ready = 1;
    return 1;
}

int fat32_init(void) {
    fat32_read_fn = fat32_read_ata;
    is_usb = 0;
    if (!ata_present() || ata_is_cdrom()) return 0;
    return fat32_init_internal();
}

int fat32_init_usb(void) {
    fat32_read_fn = fat32_read_usb;
    is_usb = 1;
    if (!usb_ehci_storage_ready()) return 0;
    return fat32_init_internal();
}

static void u16_to_u8(const u16 *in, int n, char *out, int outmax) {
    int o = 0;
    for (int i = 0; i < n && in[i] && in[i] != 0xFFFF; i++) {
        u32 c = in[i];
        if (c < 0x80) {
            if (o + 1 >= outmax) break;
            out[o++] = (char)c;
        } else if (c < 0x800) {
            if (o + 2 >= outmax) break;
            out[o++] = (char)(0xC0 | (c >> 6));
            out[o++] = (char)(0x80 | (c & 0x3F));
        } else {
            if (o + 3 >= outmax) break;
            out[o++] = (char)(0xE0 | (c >> 12));
            out[o++] = (char)(0x80 | ((c >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (c & 0x3F));
        }
    }
    out[o] = 0;
}

int fat32_list(u32 dir_cluster, fat32_dirent_t *out, int max) {
    if (!ready || !cluster_buf || cluster_size == 0) return 0;
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;

    int n = 0;
    u16 lfn[260];
    int lfn_len = 0;
    u32 cluster = dir_cluster;

    u32 max_iters = (bpb.total_sectors / bpb.sectors_per_cluster) + 2;
    u32 iters = 0;

    while (cluster >= 2 && cluster < 0x0FFFFFF8u && iters++ < max_iters) {
        if (!read_cluster(cluster, cluster_buf)) break;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 *e = cluster_buf + off;
            if (e[0] == 0x00) return n;
            if (e[0] == 0xE5) { lfn_len = 0; continue; }

            u8 attr = e[11];
            if (attr == 0x0F) {
                u8 seq = e[0] & 0x1F;
                if (seq == 0 || seq > 20) { lfn_len = 0; continue; }
                int base = (seq - 1) * 13;
                if (base + 13 > 260) { lfn_len = 0; continue; }
                static const u8 ofs[13] = {1,3,5,7,9, 14,16,18,20,22,24, 28,30};
                for (int i = 0; i < 13; i++)
                    lfn[base + i] = (u16)e[ofs[i]] | ((u16)e[ofs[i]+1] << 8);
                if (base + 13 > lfn_len) lfn_len = base + 13;
                continue;
            }
            if ((attr & 0x08) && !(attr & 0x10)) { lfn_len = 0; continue; }

            fat32_dirent_t tmp;
            memset(&tmp, 0, sizeof(tmp));
            if (lfn_len > 0) {
                int lim = lfn_len;
                for (int i = 0; i < lim; i++)
                    if (lfn[i] == 0 || lfn[i] == 0xFFFF) { lim = i; break; }
                u16_to_u8(lfn, lim, tmp.name, FAT32_NAME_MAX);
                lfn_len = 0;
            } else {
                char n8[9], x3[4];
                memcpy(n8, e, 8); n8[8] = 0;
                memcpy(x3, e + 8, 3); x3[3] = 0;
                int k = 7; while (k >= 0 && n8[k] == ' ') n8[k--] = 0;
                k = 2; while (k >= 0 && x3[k] == ' ') x3[k--] = 0;
                if ((u8)n8[0] == 0x05) n8[0] = (char)0xE5;
                int p = 0;
                for (int i = 0; n8[i] && p < FAT32_NAME_MAX; i++) tmp.name[p++] = n8[i];
                if (x3[0]) {
                    if (p < FAT32_NAME_MAX) tmp.name[p++] = '.';
                    for (int i = 0; x3[i] && p < FAT32_NAME_MAX; i++) tmp.name[p++] = x3[i];
                }
                tmp.name[p] = 0;
            }
            tmp.attr = attr;
            tmp.size = (u32)e[28] | ((u32)e[29] << 8) | ((u32)e[30] << 16) | ((u32)e[31] << 24);
            tmp.first_cluster = (((u32)e[20] | ((u32)e[21] << 8)) << 16) | ((u32)e[26] | ((u32)e[27] << 8));

            if (!strcmp(tmp.name, ".") || !strcmp(tmp.name, "..")) continue;
            if (n < max) out[n++] = tmp;
        }
        cluster = next_cluster(cluster);
    }
    return n;
}

u32 fat32_read_file(u32 first_cluster, u32 size, void *buf, u32 max) {
    if (!ready || !cluster_buf) return 0;
    if (size > max) size = max;

    u8 *p = (u8 *)buf;
    u32 left = size;
    u32 cluster = first_cluster;

    u32 max_iters = (bpb.total_sectors / bpb.sectors_per_cluster) + 2;
    u32 iters = 0;

    while (left > 0 && cluster >= 2 && cluster < 0x0FFFFFF8u && iters++ < max_iters) {
        if (!read_cluster(cluster, cluster_buf)) break;
        u32 n = (left > cluster_size) ? cluster_size : left;
        memcpy(p, cluster_buf, n);
        p += n; left -= n;
        cluster = next_cluster(cluster);
    }
    return size - left;
}
