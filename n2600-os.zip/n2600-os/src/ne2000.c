/* ne2000.c — драйвер NE2000 (8390) PCI Ethernet.
 *
 * Реализация для N2600-OS:
 *   1. PCI-сканирование (vendor 0x10EC RTL8029 или любой 0x0200 класс)
 *   2. I/O BAR активация (I/O Space + Bus Master)
 *   3. 8390 reset и инициализация
 *   4. MAC из PROM (первые 32 байта 8390 PROM = MAC × 16)
 *   5. Установка RX ring buffer
 *   6. Приём/передача через Remote DMA
 *
 * Регистры 8390 (offsets от I/O base):
 *   CR (0x00): Command Register — STOP/START, page select, TX/RX DMA
 *   ISR (0x07): Interrupt Status
 *   IMR (0x0F): Interrupt Mask
 *   DCR (0x0E): Data Configuration (16-bit/8-bit, endianness)
 *   RCR (0x0C): Receive Configuration
 *   TCR (0x0D): Transmit Configuration
 *   BNRY (0x03): Boundary (oldest packet in ring)
 *   PSTART (0x01): Page Start
 *   PSTOP (0x02): Page Stop
 *   TPDR (0x04): Transmit Page Start
 *   TBCR (0x05/0x06): Transmit Byte Count
 *   RSAR (0x08/0x09): Remote Start Address
 *   RBCR (0x0A/0x0B): Remote Byte Count
 *
 * Page 1:
 *   PAR0-PAR5 (0x01-0x06): Physical Address (MAC)
 *   CURR (0x07): Current Page (next RX slot)
 */
#include "ne2000.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* 8390 registers */
#define NE_CR    0x00
#define NE_PSTART 0x01
#define NE_PSTOP  0x02
#define NE_BNRY   0x03
#define NE_TPDR   0x04
#define NE_TBCR0  0x05
#define NE_TBCR1  0x06
#define NE_ISR   0x07
#define NE_RSAR0  0x08
#define NE_RSAR1  0x09
#define NE_RBCR0  0x0A
#define NE_RBCR1  0x0B
#define NE_RCR   0x0C
#define NE_TCR   0x0D
#define NE_DCR   0x0E
#define NE_IMR   0x0F

/* CR bits */
#define CR_STOP  0x01
#define CR_START 0x02
#define CR_TXP   0x04
#define CR_RDC   0x08
#define CR_RD2   0x20  /* no DMA */
#define CR_PAGE0 0x00
#define CR_PAGE1 0x40
#define CR_PAGE2 0x80

#define NE_DATA  0x10  /* Data I/O port (for Remote DMA) */

/* Ring buffer: 16 pages × 256 bytes = 4 KiB */
#define NE_TX_START  0x40  /* TX page = 0x40 (page 64) */
#define NE_RX_START  0x46  /* RX start page */
#define NE_RX_STOP  0x80  /* RX stop page (128 = 32 KiB / 256) */

typedef struct {
    int  present;
    u32  io_base;
    u8   mac[6];
    char chip_name[40];
    u8   next_rx_page;  /* CURR — next RX page to read */
} ne2000_t;

static ne2000_t g_ne;

static inline u8 ne_r(u8 reg) { return inb(g_ne.io_base + reg); }
static inline void ne_w(u8 reg, u8 val) { outb(g_ne.io_base + reg, val); }
static inline u16 ne_rw(u8 reg) { return inw(g_ne.io_base + reg); }
static inline void ne_ww(u8 reg, u16 val) { outw(g_ne.io_base + reg, val); }

static void ne_delay(void)
{
    for (volatile int i = 0; i < 1000; i++) (void)inb(0x80);
}

/* Reset: write 0xFF to reset register (offset 0x1F) */
static void ne_reset(void)
{
    outb(g_ne.io_base + 0x1F, 0xFF);
    ne_delay();
    (void)inb(g_ne.io_base + 0x1F);  /* clear reset */
    ne_delay();
}

/* Read MAC from PROM (first 32 bytes = 16 MAC repeats) */
static void ne_read_mac(void)
{
    /* Set Page 0, Remote DMA to read from address 0 */
    ne_w(NE_CR, CR_STOP | CR_RD2 | CR_PAGE0);
    ne_w(NE_RSAR0, 0);
    ne_w(NE_RSAR1, 0);
    ne_w(NE_RBCR0, 32);  /* read 32 bytes */
    ne_w(NE_RBCR1, 0);
    ne_w(NE_CR, CR_STOP | CR_RDC | CR_PAGE0);

    /* Read 32 bytes from data port */
    u8 prom[32];
    for (int i = 0; i < 32; i++) {
        prom[i] = inb(g_ne.io_base + NE_DATA);
    }

    /* MAC is in first 6 bytes, but verify: prom[0] != prom[1] (not all same) */
    if (prom[0] != prom[1] || prom[0] == 0xFF) {
        /* Maybe 16-bit mode: read words */
        ne_w(NE_CR, CR_STOP | CR_RD2 | CR_PAGE0);
        ne_w(NE_RSAR0, 0);
        ne_w(NE_RSAR1, 0);
        ne_w(NE_RBCR0, 32);
        ne_w(NE_RBCR1, 0);
        ne_w(NE_DCR, 0x49);  /* 8-bit, no DMA burst */
        ne_w(NE_CR, CR_STOP | CR_RDC | CR_PAGE0);
        for (int i = 0; i < 32; i++) {
            prom[i] = inb(g_ne.io_base + NE_DATA);
        }
    }

    memcpy(g_ne.mac, prom, 6);
}

int ne2000_init(void)
{
    g_ne.present = 0;
    g_ne.io_base = 0;

    serial_puts("[ne2000] init...\n");

    /* PCI scan: look for Realtek RTL8029 or any NE2000-compatible */
    int found = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            u8 hdr = pci_read8(bus, dev, 0, 0x0E);
            int max_func = (hdr & 0x80) ? 8 : 1;
            for (int func = 0; func < max_func && !found; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor == 0xFFFF) continue;

                u32 classcc = pci_read32(bus, dev, func, 0x08);
                u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                u8 cc_sub = (u8)((classcc >> 16) & 0xFF);
                u8 prog_if = (u8)((classcc >> 8) & 0xFF);

                /* Ethernet controller (0x0200) or RTL8029 (0x10EC:0x8029) */
                if (cc_base == 0x02 && cc_sub == 0x00) {
                    /* Found Ethernet controller */
                    u32 bar0 = pci_read32(bus, dev, func, 0x10);
                    g_ne.io_base = bar0 & 0xFFFC;  /* I/O space, low 2 bits ignored */

                    /* Enable I/O Space + Bus Master */
                    u16 cmd = pci_read16(bus, dev, func, 0x04);
                    cmd |= 0x05;  /* I/O | BME */
                    pci_write16(bus, dev, func, 0x04, cmd);

                    /* Chip name */
                    if (vendor == 0x10EC && device == 0x8029)
                        strcpy(g_ne.chip_name, "Realtek RTL8029");
                    else
                        strcpy(g_ne.chip_name, "NE2000-compatible");
                    found = 1;
                }

                if (func == 0 && !(hdr & 0x80)) break;
            }
        }
        if (bus > 2) break;
    }

    if (!found) {
        serial_puts("[ne2000] no NE2000-compatible card found\n");
        return 0;
    }

    serial_puts("[ne2000] found: ");
    serial_puts(g_ne.chip_name);
    serial_puts(" I/O=0x");
    {
        const char *h = "0123456789ABCDEF";
        char buf[8];
        for (int i = 4; i >= 0; i -= 4)
            buf[4-i/4] = h[(g_ne.io_base >> i) & 0xF];
        buf[5] = 0;
        serial_puts(buf);
    }
    serial_puts("\n");

    /* Reset */
    ne_reset();
    serial_puts("[ne2000] reset OK\n");

    /* Read MAC */
    ne_read_mac();
    serial_puts("[ne2000] MAC: ");
    {
        const char *h = "0123456789abcdef";
        char buf[4];
        for (int i = 0; i < 6; i++) {
            buf[0] = h[(g_ne.mac[i] >> 4) & 0xF];
            buf[1] = h[g_ne.mac[i] & 0xF];
            buf[2] = (i < 5) ? ':' : 0;
            buf[3] = 0;
            serial_puts(buf);
        }
    }
    serial_puts("\n");

    /* Initialize 8390 */
    ne_w(NE_CR, CR_STOP | CR_RD2 | CR_PAGE0);  /* Stop, Page 0 */
    ne_delay();

    /* Data Configuration: 8-bit, no burst, normal endianness */
    ne_w(NE_DCR, 0x01);

    /* Clear Remote Byte Count */
    ne_w(NE_RBCR0, 0);
    ne_w(NE_RBCR1, 0);

    /* Receive Configuration: accept broadcast + multicast + physical */
    ne_w(NE_RCR, 0x04);  /* AB = accept broadcast */

    /* Transmit Configuration: internal loopback (normal = 0x00 after init) */
    ne_w(NE_TCR, 0x02);  /* internal loopback during init */

    /* Set ring buffer boundaries */
    ne_w(NE_PSTART, NE_RX_START);
    ne_w(NE_PSTOP, NE_RX_STOP);
    ne_w(NE_BNRY, NE_RX_START);

    /* Page 1: set MAC and CURR */
    ne_w(NE_CR, CR_STOP | CR_RD2 | CR_PAGE1);
    for (int i = 0; i < 6; i++)
        ne_w(0x01 + i, g_ne.mac[i]);
    ne_w(0x07, NE_RX_START);  /* CURR = RX start */

    /* Back to Page 0, START */
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0);
    ne_delay();

    /* Clear ISR */
    ne_w(NE_ISR, 0xFF);

    /* Set IMR (no interrupts — polling) */
    ne_w(NE_IMR, 0x00);

    /* Normal TX mode (no loopback) */
    ne_w(NE_TCR, 0x00);

    g_ne.next_rx_page = NE_RX_START;
    g_ne.present = 1;

    serial_puts("[ne2000] ready\n");
    return 1;
}

int ne2000_present(void) { return g_ne.present; }
const char *ne2000_chip_name(void) { return g_ne.chip_name; }

int ne2000_get_mac(u8 out_mac[6])
{
    if (!g_ne.present) return 0;
    memcpy(out_mac, g_ne.mac, 6);
    return 1;
}

int ne2000_send(const void *buf, u32 len)
{
    if (!g_ne.present) return -1;
    if (len > 1514) len = 1514;

    /* Page 0 */
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0);

    /* Set Remote DMA to write TX packet to NIC's internal buffer */
    ne_w(NE_RSAR0, NE_TX_START << 8);  /* actually (NE_TX_START * 256) */
    ne_w(NE_RSAR1, NE_TX_START);
    /* Wait: RSAR0 = low byte of address, RSAR1 = high byte */
    /* Address = NE_TX_START * 256 */
    u16 addr = NE_TX_START * 256;
    ne_w(NE_RSAR0, (u8)(addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(addr >> 8));

    ne_w(NE_RBCR0, (u8)(len & 0xFF));
    ne_w(NE_RBCR1, (u8)(len >> 8));

    /* Start Remote Write DMA */
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0 | 0x10);  /* RD1 = write */

    /* Write data to data port */
    const u8 *p = (const u8 *)buf;
    for (u32 i = 0; i < len; i++)
        outb(g_ne.io_base + NE_DATA, p[i]);

    /* Wait for DMA to complete */
    for (int i = 0; i < 100000; i++) {
        if (ne_r(NE_ISR) & 0x40) break;  /* RDC bit */
    }
    ne_w(NE_ISR, 0x40);  /* clear RDC */

    /* Trigger TX */
    ne_w(NE_TPDR, NE_TX_START);
    ne_w(NE_TBCR0, (u8)(len & 0xFF));
    ne_w(NE_TBCR1, (u8)(len >> 8));
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0 | CR_TXP);

    return (int)len;
}

u32 ne2000_recv(void *out_buf, u32 out_max)
{
    if (!g_ne.present) return 0;

    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0);

    /* Check if there's a packet: BNRY should be < CURR */
    u8 bnry = ne_r(NE_BNRY);
    /* Read CURR from Page 1 */
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE1);
    u8 curr = ne_r(0x07);
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0);

    if (bnry == curr) return 0;  /* no packets */

    /* Read packet header from the ring buffer */
    u16 addr = ((u16)(bnry + 1) * 256) & 0x3FFF;  /* next page after BNRY */
    if (addr >= NE_RX_START * 256) addr -= NE_RX_START * 256;
    addr += NE_RX_START * 256;

    /* Actually: address = (bnry + 1) * 256, but wrap around */
    u16 pkt_addr = ((u16)bnry + 1) * 256;
    if (pkt_addr >= NE_RX_STOP * 256) pkt_addr = NE_RX_START * 256;

    /* Read 4-byte header: status, next_page, length_low, length_high */
    ne_w(NE_RSAR0, (u8)(pkt_addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(pkt_addr >> 8));
    ne_w(NE_RBCR0, 4);
    ne_w(NE_RBCR1, 0);
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0 | CR_RDC);

    u8 hdr[4];
    for (int i = 0; i < 4; i++)
        hdr[i] = inb(g_ne.io_base + NE_DATA);

    u8 status = hdr[0];
    u8 next_page = hdr[1];
    u16 pkt_len = (u16)hdr[2] | ((u16)hdr[3] << 8);

    if (pkt_len < 4 || pkt_len > 1518) {
        /* Bad packet — advance BNRY */
        ne_w(NE_BNRY, next_page);
        return 0;
    }

    /* Read packet data (skip 4-byte header) */
    u16 data_addr = pkt_addr + 4;
    u16 data_len = pkt_len - 4;
    if (data_len > out_max) data_len = (u16)out_max;

    ne_w(NE_RSAR0, (u8)(data_addr & 0xFF));
    ne_w(NE_RSAR1, (u8)(data_addr >> 8));
    ne_w(NE_RBCR0, (u8)(data_len & 0xFF));
    ne_w(NE_RBCR1, (u8)(data_len >> 8));
    ne_w(NE_CR, CR_START | CR_RD2 | CR_PAGE0 | CR_RDC);

    u8 *out = (u8 *)out_buf;
    for (u16 i = 0; i < data_len; i++)
        out[i] = inb(g_ne.io_base + NE_DATA);

    /* Advance BNRY to next_page */
    ne_w(NE_BNRY, next_page);

    (void)status;
    return data_len;
}
