/* net_http.c — простой HTTP/1.0 клиент для N2600-OS.
 *
 * Реализован только метод GET. Запрос:
 *   GET <path> HTTP/1.0\r\n
 *   Host: <hostname>\r\n
 *   User-Agent: N2600-OS/0.1\r\n
 *   Connection: close\r\n
 *   \r\n
 *
 * После отправки ждём ответ через TCP recv callback.
 * Когда сервер закрывает соединение (FIN), возвращаем накопленные данные.
 */
#include "net.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);
extern void net_poll(void);

/* Буфер для накопления HTTP-ответа */
static char *g_http_buf = NULL;
static u32   g_http_buf_len = 0;
static u32   g_http_buf_max = 0;
static int   g_http_sock = -1;
static int   g_http_done = 0;

/* TCP receive callback — копирует данные в буфер */
static void http_tcp_recv(int sock, u32 src_ip, u16 src_port,
                            const void *data, u32 len)
{
    (void)sock; (void)src_ip; (void)src_port;
    if (!g_http_buf || !data || len == 0) return;
    u32 room = g_http_buf_max - g_http_buf_len;
    if (room == 0) return;
    u32 copy = len < room ? len : room;
    memcpy(g_http_buf + g_http_buf_len, data, copy);
    g_http_buf_len += copy;
}

int net_http_get(const char *host, u16 port, const char *path,
                  char *response, u32 max_len, u32 max_ms)
{
    if (!host || !path || !response || max_len == 0) return -1;

    /* 1. Разрешить хост → IP */
    u32 ip = 0;
    /* Сначала пробуем как IP-строку */
    if (!net_aton(host, &ip)) {
        /* Пробуем через DNS */
        if (!net_dns_resolve(host, &ip, max_ms / 2)) {
            serial_puts("[http] cannot resolve host\n");
            return -1;
        }
    }

    /* 2. Подготовить буфер и callback */
    g_http_buf = response;
    g_http_buf_len = 0;
    g_http_buf_max = max_len;
    g_http_done = 0;
    g_http_sock = -1;
    net_tcp_set_callback(http_tcp_recv);

    /* 3. TCP connect */
    int sock = net_tcp_connect(ip, port, 40000 + (g_http_sock & 0xFF));
    if (sock < 0) {
        serial_puts("[http] cannot open TCP socket\n");
        return -1;
    }
    g_http_sock = sock;

    /* Ждём соединения (3-way handshake) — неблокирующее */
    u32 start = timer_ticks();
    u32 need = max_ms / 4 / 10;
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        if (net_tcp_state(sock) == TCP_ESTABLISHED) break;
        if (net_tcp_state(sock) == TCP_CLOSED) {
            serial_puts("[http] connection refused\n");
            return -1;
        }
        net_poll();
        task_yield();
    }
    if (net_tcp_state(sock) != TCP_ESTABLISHED) {
        serial_puts("[http] connect timeout\n");
        net_tcp_close(sock);
        return -1;
    }

    /* 4. Отправить HTTP GET запрос */
    char req[512];
    int rl = 0;
    rl += snprintf(req + rl, sizeof(req) - rl, "GET %s HTTP/1.0\r\n", path);
    rl += snprintf(req + rl, sizeof(req) - rl, "Host: %s\r\n", host);
    rl += snprintf(req + rl, sizeof(req) - rl, "User-Agent: N2600-OS/0.1\r\n");
    rl += snprintf(req + rl, sizeof(req) - rl, "Connection: close\r\n");
    rl += snprintf(req + rl, sizeof(req) - rl, "\r\n");

    int sent = net_tcp_send(sock, req, (u32)rl);
    if (sent < 0) {
        serial_puts("[http] send failed\n");
        net_tcp_close(sock);
        return -1;
    }

    /* 5. Ждём ответ и закрытия соединения — неблокирующее */
    start = timer_ticks();
    need = max_ms / 10;
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        if (net_tcp_state(sock) == TCP_CLOSED) {
            g_http_done = 1;
            break;
        }
        if (g_http_buf_len >= g_http_buf_max - 1) break;
        net_poll();
        task_yield();
    }

    if (!g_http_done && g_http_buf_len == 0) {
        serial_puts("[http] response timeout\n");
        net_tcp_close(sock);
        return -1;
    }

    /* NUL-terminate */
    if (g_http_buf_len < g_http_buf_max) {
        response[g_http_buf_len] = 0;
    } else {
        response[g_http_buf_max - 1] = 0;
        g_http_buf_len = g_http_buf_max - 1;
    }

    /* Закрыть сокет если ещё открыт */
    if (net_tcp_state(sock) != TCP_CLOSED) {
        net_tcp_close(sock);
    }
    return (int)g_http_buf_len;
}
