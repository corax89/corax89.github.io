/* fb.h — фреймбуфер VESA LFB (из Multiboot), двойная буферизация, примитивы */
#ifndef FB_H
#define FB_H

#include "types.h"
#include "boot.h"

int   fb_init(const mb_info_t *mb);
int   fb_ready(void);
u32   fb_rgb(u8 r, u8 g, u8 b);
u32   fb_width(void);
u32   fb_height(void);
u32   fb_bpp(void);
u32   fb_pitch(void);

void  fb_make_bg(void);                     /* построить фон рабочего стола */

void  fb_mark_enable(void);                 /* вкл/выкл накопление dirty-области */
void  fb_mark_disable(void);
void  fb_touch(int x, int y, int w, int h); /* пометить область на вывод */
void  fb_touch_all(void);
void  fb_flush(void);                       /* копировать помеченное в LFB */
int   fb_dirty(int *x0, int *y0, int *x1, int *y1);                       /* копировать помеченное в реальный LFB */

void  fb_set_clip(int x0, int y0, int x1, int y1);
void  fb_set_origin(int ox, int oy);  /* приложения рисуют от левого-верхнего угла содержимого */

void  fb_fill_screen(u32 c);
void  fb_fill_rect(int x, int y, int w, int h, u32 c);
void  fb_rect(int x, int y, int w, int h, u32 c);
void  fb_hline(int x0, int x1, int y, u32 c);
void  fb_vline(int x, int y0, int y1, u32 c);

void  fb_char(int x, int y, unsigned cp, u32 fg, int bg); /* bg=-1: прозрачный фон */
void  fb_char2x(int x, int y, unsigned cp, u32 fg);
void  fb_text(int x, int y, const char *s, u32 fg, int bg);
void  fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg);
u32   fb_text_w(const char *s);
void  fb_blit_bg(int x0, int y0, int x1, int y1);

#endif /* FB_H */
