/* virtio_net.c — драйвер VirtIO-network для N2600-OS.
 *
 * Реализация для legacy VirtIO-net (I/O port mode):
 *   1. PCI-детекция vendor 0x1AF4, class 0x0200 (или device 0x1000)
 *   2. I/O BAR активация
 *   3. Device init: ACKNOWLEDGE → DRIVER → DRIVER_OK
 *   4. Чтение MAC из device config
 *   5. Настройка RX virtqueue (queue 0)
 *   6. Настройка TX virtqueue (queue 1)
 *   7. Приём/передача через descriptors
 */
#include "virtio_net.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* VirtIO vendor/device IDs */
#define VIRTIO_VENDOR_ID  0x1AF4
#define VIRTIO_NET_LEGACY 0x1000
#define VIRTIO_NET_MODERN 0x1041

/* VirtIO legacy I/O register offsets */
#define VIO_DEV_FEAT   0x00  /* R: device features (32-bit) */
#define VIO_GUEST_FEAT 0x04  /* W: guest features (32-bit) */
#define VIO_QUEUE_PFN   0x08  /* W: queue page frame (32-bit) */
#define VIO_QUEUE_SIZE  0x0C  /* R: queue size (16-bit) */
#define VIO_QUEUE_SEL   0x0E  /* W: queue select (16-bit) */
#define VIO_QUEUE_NOTIFY 0x10 /* W: queue notify (16-bit) */
#define VIO_STATUS      0x12  /* R/W: status (8-bit) */
#define VIO_ISR         0x13  /* R: interrupt status (8-bit) */
#define VIO_NET_CFG     0x14  /* R: net config (MAC, etc.) */

/* Status bits */
#define VIO_S_ACK       0x01
#define VIO_S_DRIVER    0x02
#define VIO_S_DRIVER_OK 0x04
#define VIO_S_FEAT_OK   0x08
#define VIO_S_FAILED    0x80

/* VirtIO-net feature bits */
#define VIO_NET_F_MAC  (1 << 5)

/* Descriptor flags */
#define VRING_DESC_F_NEXT  1
#define VRING_DESC_F_WRITE 2

/* Virtqueue ring sizes (power of 2) */
#define VQ_SIZE 8

/* Descriptor (16 bytes) */
typedef struct __attribute__((packed)) {
    u64 addr;
    u32 len;
    u16 flags;
    u16 next;
} vring_desc_t;

/* Available ring (2 + 2*size + 2) */
typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    u16 ring[VQ_SIZE];
} vring_avail_t;

/* Used ring element (8 bytes) */
typedef struct __attribute__((packed)) {
    u32 id;
    u32 len;
} vring_used_elem_t;

/* Used ring (2 + 2 + 2*size + 2) */
typedef struct __attribute__((packed)) {
    u16 flags;
    u16 idx;
    vring_used_elem_t ring[VQ_SIZE];
} vring_used_t;

/* Complete virtqueue layout (page-aligned) */
typedef struct __attribute__((packed, aligned(4096))) {
    vring_desc_t desc[VQ_SIZE];
    vring_avail_t avail;
    u8 pad1[0];  /* avail is variable size, pad to 4096 */
    vring_used_t used;
} vring_t;

/* Buffer for a packet */
typedef struct {
    u8 data[1520];
    u32 len;
} vq_buf_t;

typedef struct {
    int present;
    u32 io_base;
    u8  mac[6];
    char chip_name[40];
    /* Virtqueues */
    vring_t rx_vq;
    vring_t tx_vq;
    vq_buf_t rx_bufs[VQ_SIZE];
    vq_buf_t tx_bufs[VQ_SIZE];
    u16 rx_idx;
    u16 tx_idx;
} virtio_t;

static virtio_t g_vio;

static inline u8 vio_r8(u32 off) { return inb(g_vio.io_base + off); }
static inline u16 vio_r16(u32 off) { return inw(g_vio.io_base + off); }
static inline u32 vio_r32(u32 off) { return inl(g_vio.io_base + off); }
static inline void vio_w8(u32 off, u8 v) { outb(g_vio.io_base + off, v); }
static inline void vio_w16(u32 off, u16 v) { outw(g_vio.io_base + off, v); }
static inline void vio_w32(u32 off, u32 v) { outl(g_vio.io_base + off, v); }

/* Set up a virtqueue: select queue, get size, write PFN */
static int vio_setup_queue(int queue_idx, vring_t *vq)
{
    vio_w16(VIO_QUEUE_SEL, (u16)queue_idx);
    u16 size = vio_r16(VIO_QUEUE_SIZE);
    if (size == 0) return 0;  /* queue not available */
    if (size > VQ_SIZE) size = VQ_SIZE;

    /* Clear the ring */
    memset(vq, 0, sizeof(*vq));

    /* Set up descriptors' next pointers (free list) */
    for (u16 i = 0; i < size - 1; i++) {
        vq->desc[i].next = i + 1;
        vq->desc[i].flags = VRING_DESC_F_NEXT;
    }
    vq->desc[size - 1].next = 0;
    vq->desc[size - 1].flags = VRING_DESC_F_NEXT;

    /* Write PFN (page frame number = physical address / 4096) */
    u32 pfn = (u32)(unsigned long)vq / 4096;
    vio_w32(VIO_QUEUE_PFN, pfn);

    return (int)size;
}

int virtio_net_init(void)
{
    g_vio.present = 0;

    serial_puts("[virtio] init...\n");

    /* PCI scan */
    int found = 0;
    for (int bus = 0; bus < 256 && !found; bus++) {
        for (int dev = 0; dev < 32 && !found; dev++) {
            u8 hdr = pci_read8(bus, dev, 0, 0x0E);
            int max_func = (hdr & 0x80) ? 8 : 1;
            for (int func = 0; func < max_func && !found; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                u16 vendor = (u16)(id & 0xFFFF);
                u16 device = (u16)(id >> 16);
                if (vendor != VIRTIO_VENDOR_ID) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                /* Check: is this a network device? */
                u32 classcc = pci_read32(bus, dev, func, 0x08);
                u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                u8 cc_sub = (u8)((classcc >> 16) & 0xFF);

                /* VirtIO legacy devices may have class 0x00/0x00
                 * Modern have 0x02/0x00 (Ethernet)
                 * Check device ID range: 0x1000-0x103F = legacy,
                 * 0x1040-0x107F = modern */
                int is_net = 0;
                if (cc_base == 0x02 && cc_sub == 0x00) is_net = 1;
                if (device >= 0x1000 && device <= 0x103F) is_net = 1;
                if (device >= 0x1040 && device <= 0x107F) {
                    /* Modern: need subsystem to determine type.
                     * Subsystem ID for net = 0x0001 (legacy) or 0x1041 */
                    u32 ss = pci_read32(bus, dev, func, 0x2C);
                    u16 subsys = (u16)((ss >> 16) & 0xFFFF);
                    if (subsys == 1 || subsys == 0x1041) is_net = 1;
                }
                if (!is_net) {
                    if (func == 0 && !(hdr & 0x80)) break;
                    continue;
                }

                /* Found VirtIO-net! */
                u32 bar0 = pci_read32(bus, dev, func, 0x10);
                g_vio.io_base = bar0 & 0xFFFC;

                /* Enable I/O + Bus Master */
                u16 cmd = pci_read16(bus, dev, func, 0x04);
                cmd |= 0x05;  /* I/O | BME */
                pci_write16(bus, dev, func, 0x04, cmd);

                strcpy(g_vio.chip_name, "VirtIO Network");
                found = 1;
                break;
            }
        }
        if (bus > 2) break;
    }

    if (!found) {
        serial_puts("[virtio] no VirtIO-net device found\n");
        return 0;
    }

    serial_puts("[virtio] found: ");
    serial_puts(g_vio.chip_name);
    serial_puts(" I/O=0x");
    {
        const char *h = "0123456789ABCDEF";
        char buf[8] = "0x";
        buf[2] = h[(g_vio.io_base >> 12) & 0xF];
        buf[3] = h[(g_vio.io_base >> 8) & 0xF];
        buf[4] = h[(g_vio.io_base >> 4) & 0xF];
        buf[5] = h[g_vio.io_base & 0xF];
        buf[6] = 0;
        serial_puts(buf);
    }
    serial_puts("\n");

    /* Device init sequence */
    /* 1. Reset */
    vio_w8(VIO_STATUS, 0);

    /* 2. ACKNOWLEDGE */
    vio_w8(VIO_STATUS, VIO_S_ACK);

    /* 3. DRIVER */
    vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER);

    /* 4. Read device features */
    u32 features = vio_r32(VIO_DEV_FEAT);
    (void)features;

    /* 5. Read MAC from device config */
    for (int i = 0; i < 6; i++)
        g_vio.mac[i] = inb(g_vio.io_base + VIO_NET_CFG + i);

    serial_puts("[virtio] MAC: ");
    {
        const char *h = "0123456789abcdef";
        char buf[4];
        for (int i = 0; i < 6; i++) {
            buf[0] = h[(g_vio.mac[i] >> 4) & 0xF];
            buf[1] = h[g_vio.mac[i] & 0xF];
            buf[2] = (i < 5) ? ':' : 0;
            buf[3] = 0;
            serial_puts(buf);
        }
    }
    serial_puts("\n");

    /* 6. Set up RX and TX virtqueues */
    if (!vio_setup_queue(0, &g_vio.rx_vq)) {  /* RX = queue 0 */
        serial_puts("[virtio] RX queue setup failed\n");
        return 0;
    }
    serial_puts("[virtio] RX queue ready\n");

    if (!vio_setup_queue(1, &g_vio.tx_vq)) {  /* TX = queue 1 */
        serial_puts("[virtio] TX queue setup failed\n");
        return 0;
    }
    serial_puts("[virtio] TX queue ready\n");

    /* 7. Provide RX buffers */
    g_vio.rx_idx = 0;
    for (int i = 0; i < VQ_SIZE; i++) {
        g_vio.rx_vq.desc[i].addr = (u64)(unsigned long)g_vio.rx_bufs[i].data;
        g_vio.rx_vq.desc[i].len = sizeof(g_vio.rx_bufs[i].data);
        g_vio.rx_vq.desc[i].flags = VRING_DESC_F_WRITE;
        g_vio.rx_vq.desc[i].next = 0;
        g_vio.rx_vq.avail.ring[i] = (u16)i;
    }
    g_vio.rx_vq.avail.idx = VQ_SIZE;

    /* Notify RX queue */
    vio_w16(VIO_QUEUE_NOTIFY, 0);

    /* 8. DRIVER_OK — device goes live */
    vio_w8(VIO_STATUS, VIO_S_ACK | VIO_S_DRIVER | VIO_S_DRIVER_OK);

    g_vio.tx_idx = 0;
    g_vio.present = 1;

    serial_puts("[virtio] ready\n");
    return 1;
}

int virtio_net_present(void) { return g_vio.present; }
const char *virtio_net_chip_name(void) { return g_vio.chip_name; }

int virtio_net_get_mac(u8 out_mac[6])
{
    if (!g_vio.present) return 0;
    memcpy(out_mac, g_vio.mac, 6);
    return 1;
}

int virtio_net_send(const void *buf, u32 len)
{
    if (!g_vio.present) return -1;
    if (len > 1514) len = 1514;

    /* Find a free TX descriptor */
    u16 idx = g_vio.tx_idx % VQ_SIZE;
    g_vio.tx_idx++;

    /* Copy packet to TX buffer */
    memcpy(g_vio.tx_bufs[idx].data, buf, len);
    g_vio.tx_bufs[idx].len = len;

    /* Set up descriptor */
    g_vio.tx_vq.desc[idx].addr = (u64)(unsigned long)g_vio.tx_bufs[idx].data;
    g_vio.tx_vq.desc[idx].len = len;
    g_vio.tx_vq.desc[idx].flags = 0;
    g_vio.tx_vq.desc[idx].next = 0;

    /* Add to available ring */
    u16 avail_idx = g_vio.tx_vq.avail.idx % VQ_SIZE;
    g_vio.tx_vq.avail.ring[avail_idx] = idx;
    g_vio.tx_vq.avail.idx++;

    /* Notify TX queue */
    vio_w16(VIO_QUEUE_NOTIFY, 1);

    return (int)len;
}

u32 virtio_net_recv(void *out_buf, u32 out_max)
{
    if (!g_vio.present) return 0;

    /* Check used ring for RX packets */
    u16 last_used = g_vio.rx_vq.used.idx % VQ_SIZE;
    /* Simplified: just check if there's any used entry.
     * In a real driver we'd track last_used vs used.idx. */
    static u16 last_rx_used = 0;
    if (last_rx_used == g_vio.rx_vq.used.idx) return 0;

    u16 used_idx = last_rx_used % VQ_SIZE;
    u32 id = g_vio.rx_vq.used.ring[used_idx].id;
    u32 len = g_vio.rx_vq.used.ring[used_idx].len;

    last_rx_used++;

    if (len > out_max) len = out_max;
    if (len > 0 && id < VQ_SIZE) {
        memcpy(out_buf, g_vio.rx_bufs[id].data, len);
    }

    /* Re-add the buffer to the available ring */
    u16 avail_idx = g_vio.rx_vq.avail.idx % VQ_SIZE;
    g_vio.rx_vq.avail.ring[avail_idx] = (u16)id;
    g_vio.rx_vq.avail.idx++;
    vio_w16(VIO_QUEUE_NOTIFY, 0);

    return len;
}
