/* net_dns.c — DNS resolver для N2600-OS.
 *
 * Простой DNS-клиент:
 *   1. Отправляет DNS-запрос (UDP, src=random, dst=53) на DNS-сервер
 *   2. Получает DNS-ответ с A-записью (IPv4-адрес)
 *   3. Кэширует результат (10 записей, TTL игнорируется)
 *
 * Поддерживается:
 *   - A-записи (IPv4)
 *   - Рекурсивный запрос (флаг RD)
 *   - Один ответ (первая A-запись)
 *
 * Не поддерживается:
 *   - AAAA (IPv6)
 *   - CNAME chasing (если ответ CNAME, не следуем дальше)
 *   - DNS caching with TTL expiry
 */
#include "net.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);
extern void net_poll(void);

/* DNS-сервер (обычно устанавливается через DHCP) */
static u32 g_dns_server = 0x08080808u;  /* 8.8.8.8 по умолчанию */

/* Кэш DNS: 10 записей {hostname → IP} */
#define DNS_CACHE_SIZE 10
typedef struct {
    char hostname[64];
    u32  ip;
} dns_cache_t;
static dns_cache_t g_dns_cache[DNS_CACHE_SIZE];

u32 net_dns_server(void) { return g_dns_server; }
void net_dns_set_server(u32 dns_ip) { g_dns_server = dns_ip; }

/* Буфер для входящего DNS-ответа */
static u8 g_dns_rx_buf[512];
static u32 g_dns_rx_len = 0;
static int g_dns_rx_ready = 0;
static u16 g_dns_tx_id = 0;

/* UDP-сокет для DNS (порт 0 = эфемерный, используем 1024+) */
static int g_dns_sock = -1;

/* Callback для входящих UDP-ответов на наш DNS-сокет */
static void dns_udp_cb(u32 src_ip, u16 src_port, u16 dst_port,
                        const void *data, u32 len)
{
    (void)src_ip; (void)src_port; (void)dst_port;
    if (len > sizeof(g_dns_rx_buf)) len = sizeof(g_dns_rx_buf);
    memcpy(g_dns_rx_buf, data, len);
    g_dns_rx_len = len;
    g_dns_rx_ready = 1;
}

/* Закодировать доменное имя в DNS-формат:
 * "example.com" → \x07example\x03com\x00 (15 байт) */
static u32 encode_name(const char *hostname, u8 *out, u32 out_max)
{
    u32 oi = 0;
    u32 label_start = 0;
    for (u32 i = 0; ; i++) {
        if (hostname[i] == '.' || hostname[i] == 0) {
            u32 label_len = i - label_start;
            if (label_len == 0 && hostname[i] == 0) break;
            if (label_len > 63 || oi + 1 + label_len >= out_max) return 0;
            out[oi++] = (u8)label_len;
            memcpy(out + oi, hostname + label_start, label_len);
            oi += label_len;
            label_start = i + 1;
            if (hostname[i] == 0) break;
        }
    }
    if (oi >= out_max) return 0;
    out[oi++] = 0;  /* root label */
    return oi;
}

/* Парсить DNS-ответ, найти A-запись */
static u32 parse_dns_response(const u8 *buf, u32 len, u16 expected_txid)
{
    if (len < 12) return 0;
    /* Transaction ID (байты 0-1, big-endian) */
    u16 txid = ((u16)buf[0] << 8) | buf[1];
    if (txid != expected_txid) {
        serial_puts("[dns] txid mismatch\n");
        return 0;
    }
    /* Flags (байты 2-3) */
    u16 flags = ((u16)buf[2] << 8) | buf[3];
    if (flags & 0x0002) {  /* response flag */
        serial_puts("[dns] not a response\n");
        return 0;
    }
    if (flags & 0x000F) {  /* rcode != 0 */
        serial_puts("[dns] DNS error\n");
        return 0;
    }
    u16 qdcount = ((u16)buf[4] << 8) | buf[5];
    u16 ancount = ((u16)buf[6] << 8) | buf[7];
    if (ancount == 0) {
        serial_puts("[dns] no answers\n");
        return 0;
    }
    /* Пропускаем question-секцию */
    u32 i = 12;
    for (u16 q = 0; q < qdcount; q++) {
        /* Skip name (labels until 0 or pointer) */
        while (i < len) {
            u8 c = buf[i];
            if (c == 0) { i++; break; }
            if ((c & 0xC0) == 0xC0) { i += 2; break; }
            i += c + 1;
        }
        i += 4;  /* QTYPE (2) + QCLASS (2) */
    }
    /* Проходим answers, ищем A-запись */
    for (u16 a = 0; a < ancount; a++) {
        /* Skip name */
        while (i < len) {
            u8 c = buf[i];
            if (c == 0) { i++; break; }
            if ((c & 0xC0) == 0xC0) { i += 2; break; }
            i += c + 1;
        }
        if (i + 10 > len) break;
        u16 rtype = ((u16)buf[i] << 8) | buf[i+1];
        u16 rclass = ((u16)buf[i+2] << 8) | buf[i+3];
        u16 rdlength = ((u16)buf[i+8] << 8) | buf[i+9];
        i += 10;
        if (rtype == 1 && rclass == 1 && rdlength == 4) {  /* A record, IN class */
            if (i + 4 > len) break;
            u32 ip = ((u32)buf[i] << 24) | ((u32)buf[i+1] << 16)
                   | ((u32)buf[i+2] << 8) | (u32)buf[i+3];
            return ip;
        }
        i += rdlength;
    }
    return 0;
}

int net_dns_resolve(const char *hostname, u32 *out_ip, u32 max_ms)
{
    if (!hostname || !out_ip) return 0;
    if (g_dns_server == 0) {
        serial_puts("[dns] no DNS server configured\n");
        return 0;
    }
    /* Проверяем кэш */
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (g_dns_cache[i].hostname[0] && !strcmp(g_dns_cache[i].hostname, hostname)) {
            *out_ip = g_dns_cache[i].ip;
            return 1;
        }
    }
    /* Если hostname уже IP-строка "a.b.c.d" — парсим и возвращаем */
    if (net_aton(hostname, out_ip)) {
        return 1;
    }

    /* Открываем UDP-сокет */
    if (g_dns_sock < 0) {
        g_dns_sock = net_udp_open(30000 + (g_dns_tx_id & 0xFF));
        if (g_dns_sock < 0) {
            serial_puts("[dns] cannot open UDP socket\n");
            return 0;
        }
        net_udp_set_callback(dns_udp_cb);
    }

    /* Строим DNS-запрос */
    static u8 query[256];
    u32 qi = 0;
    /* Transaction ID */
    g_dns_tx_id++;
    query[qi++] = (u8)((g_dns_tx_id >> 8) & 0xFF);
    query[qi++] = (u8)(g_dns_tx_id & 0xFF);
    /* Flags: 0x0100 = standard query, recursion desired */
    query[qi++] = 0x01; query[qi++] = 0x00;
    /* QDCOUNT=1 */
    query[qi++] = 0; query[qi++] = 1;
    /* ANCOUNT=0, NSCOUNT=0, ARCOUNT=0 */
    query[qi++] = 0; query[qi++] = 0;
    query[qi++] = 0; query[qi++] = 0;
    query[qi++] = 0; query[qi++] = 0;
    /* Question: name + QTYPE(2=A) + QCLASS(1=IN) */
    u32 name_len = encode_name(hostname, query + qi, sizeof(query) - qi - 4);
    if (name_len == 0) {
        serial_puts("[dns] hostname too long\n");
        return 0;
    }
    qi += name_len;
    query[qi++] = 0; query[qi++] = 1;  /* QTYPE = A */
    query[qi++] = 0; query[qi++] = 1;  /* QCLASS = IN */

    /* Отправляем запрос */
    g_dns_rx_ready = 0;
    g_dns_rx_len = 0;
    serial_puts("[dns] sending query...\n");
    int sent = net_udp_send(g_dns_sock, g_dns_server, 53, query, qi);
    if (sent < 0) {
        serial_puts("[dns] send failed\n");
        return 0;
    }

    /* Ждём ответ (неблокирующее ожидание — обрабатываем net_poll) */
    u32 start = timer_ticks();
    u32 need = max_ms / 10;
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        if (g_dns_rx_ready) {
            g_dns_rx_ready = 0;
            u32 ip = parse_dns_response(g_dns_rx_buf, g_dns_rx_len, g_dns_tx_id);
            if (ip != 0) {
                *out_ip = ip;
                /* Кэшируем */
                for (int i = 0; i < DNS_CACHE_SIZE; i++) {
                    if (g_dns_cache[i].hostname[0] == 0) {
                        strncpy(g_dns_cache[i].hostname, hostname, 63);
                        g_dns_cache[i].hostname[63] = 0;
                        g_dns_cache[i].ip = ip;
                        break;
                    }
                }
                return 1;
            }
        }
        net_poll();
        task_yield();
    }
    serial_puts("[dns] timeout\n");
    return 0;
}
