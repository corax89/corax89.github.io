/* mem.c — скан карты памяти Multiboot + простой аллокатор (first-fit со слиянием) */
#include "mem.h"
#include "string.h"
#include "io.h"

/* символы linker-скрипта: в C пишем без подчёркивания, COFF добавит '_' */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

static u32 heap_start = 0, heap_end = 0, heap_pos = 0;
static u64 ram_total = 0;

typedef struct {
    u32 size;   /* полный размер блока, включая заголовок */
    u32 used;
} mblock_t;

#define MBLOCK_HDR sizeof(mblock_t)
#define ALIGN8(x)  (((x) + 7u) & ~7u)

static u32 align_up(u32 v, u32 a) { return (v + a - 1) & ~(a - 1); }

void mem_init(const mb_info_t *mb)
{
    u32 kend = align_up((u32)(unsigned long)bss_end, 4096);
    u32 best_start = 0, best_size = 0;

    ram_total = 0;

    if (mb->flags & MBIF_MMAP) {
        const u8 *p = (const u8 *)(unsigned long)mb->mmap_addr;
        const u8 *endp = p + mb->mmap_length;
        while (p + 4 <= endp) {
            const mb_mmap_t *e = (const mb_mmap_t *)p;
            if (e->size < 20) break;
            if (e->type == 1) {
                u64 reg_end = e->addr + e->len;
                ram_total += e->len;
                /* ищем самый большой пригодный кусок выше конца ядра */
                if (reg_end > (u64)kend + 0x1000000u) { /* >16МБ после ядра */
                    u64 hs = (e->addr > kend) ? e->addr : kend;
                    u64 sz = reg_end - hs;
                    if (sz > (u64)best_size) {
                        best_size = (u32)sz;
                        best_start = (u32)hs;
                    }
                }
            }
            p += e->size + 4;
        }
    }
    if (!best_start && (mb->flags & MBIF_MEM) && mb->mem_upper > 2048) {
        /* запасной путь: mem_upper (КБ выше 1М) */
        u32 top = 0x100000u + mb->mem_upper * 1024u;
        if (top > kend + 0x400000u) {
            best_start = (kend > 0x200000u) ? kend : 0x200000u;
            best_size = top - best_start;
        }
    }
    if (!best_start) {
        /* крайний случай: 32 МиБ начиная с 2М (обычно не сработает лишь на экзотике) */
        best_start = 0x200000u;
        best_size = 0x2000000u;
    }

    heap_start = align_up(best_start, 4096);
    /* не захватываем больше 512 МиБ — на реальном железе за картой могут быть дыры */
    u32 cap = (best_size > 0x20000000u) ? 0x20000000u : best_size;
    heap_end = heap_start + cap;

    /* первый пустой блок на весь регион */
    mblock_t *b = (mblock_t *)heap_start;
    b->size = heap_end - heap_start;
    b->used = 0;
    heap_pos = heap_start;
}

void *malloc(u32 n)
{
    if (!heap_start || n == 0) return NULL;
    u32 need = ALIGN8(n) + MBLOCK_HDR;

    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (!b->used && b->size >= need) {
            /* расщепление, если остаток вмещает ещё один блок */
            if (b->size >= need + MBLOCK_HDR + 16) {
                mblock_t *nb = (mblock_t *)((u8 *)b + need);
                nb->size = b->size - need;
                nb->used = 0;
                b->size = need;
            }
            b->used = 1;
            return (u8 *)b + MBLOCK_HDR;
        }
        b = (mblock_t *)((u8 *)b + b->size);
    }
    return NULL;
}

void free(void *p)
{
    if (!p) return;
    mblock_t *b = (mblock_t *)((u8 *)p - MBLOCK_HDR);
    b->used = 0;

    /* слияние с последующими свободными */
    mblock_t *next;
    for (;;) {
        next = (mblock_t *)((u8 *)b + b->size);
        if ((u32)(unsigned long)next >= heap_end || next->used) break;
        b->size += next->size;
    }
}

u32 mem_used(void)
{
    u32 used = 0;
    mblock_t *b = (mblock_t *)heap_start;
    while ((u32)(unsigned long)b < heap_end) {
        if (b->used) used += b->size;
        b = (mblock_t *)((u8 *)b + b->size);
    }
    return used;
}

u32 mem_heap_size(void) { return heap_end - heap_start; }

u32 mem_ram_mib(void) { return (u32)(ram_total >> 20); }
