/* mem.h — физическая память (по карте Multiboot) и куча */
#ifndef MEM_H
#define MEM_H

#include "types.h"
#include "boot.h"

void  mem_init(const mb_info_t *mb);
void *malloc(u32 n);
void  free(void *p);
u32   mem_used(void);      /* байт занято кучей */
u32   mem_heap_size(void); /* размер кучи, байт */
u32   mem_ram_mib(void);   /* всего доступной RAM, МиБ (по карте) */

#endif /* MEM_H */
