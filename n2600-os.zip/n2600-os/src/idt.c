/* idt.c — IDT, исключения CPU, контроллер прерываний 8259A.
 * Заглушки прерываний генерируются макросами как naked-функции с одной
 * asm-вставкой (pusha/call/iret) — вся диспетчеризация дальше на чистом C. */
#include "idt.h"
#include "io.h"
#include "types.h"
#include "fb.h"

#define IDT_ENTRIES 256

typedef struct {
    u16 lo;
    u16 sel;
    u8  zero;
    u8  flags;
    u16 hi;
} __attribute__((packed)) idt_entry_t;

static idt_entry_t idt[IDT_ENTRIES];
static irq_handler_t irq_handlers[16];

/* ------------------------------- обработка ------------------------------- */

void irq_dispatch(u32 n)
{
    if (n < 16 && irq_handlers[n])
        irq_handlers[n]();
    /* EOI: slave сначала, потом master */
    if (n >= 8) outb(0xA0, 0x20);
    outb(0x20, 0x20);
}

static const char *exc_name(u32 n)
{
    static const char *names[] = {
        "деление на ноль", "отладка", "NMI", "точка останова",
        "переполнение", "границы BOUND", "неверный код", "сопроцессор недоступен",
        "двойная ошибка", "сегмент TSS", "нет сегмента", "ошибка стека",
        "защита", "страничная ошибка", "-", "x87 FPU",
        "проверка выравнивания", "машинная проверка", "SIMD FP", "виртуализация",
        "-", "-", "-", "-",
        "-", "-", "-", "-",
        "-", "безопасность", "-", "-"
    };
    return (n < 32) ? names[n] : "неизвестно";
}

/* паника по исключению — никогда не возвращается (стек CPU не восстанавливаем) */
void exc_panic(u32 n)
{
    cli();
    if (fb_ready()) {
        fb_mark_disable();
        fb_fill_screen(fb_rgb(0x60, 0x10, 0x10));
        fb_text_screen_centered(0, (int)fb_height() / 2 - 32, "ПАНИКА ЯДРА: ИСКЛЮЧЕНИЕ", fb_rgb(255, 255, 255));
        char buf[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(buf, sizeof(buf), "#%u %s", (unsigned)n, exc_name(n));
        fb_text_screen_centered(0, (int)fb_height() / 2, buf, fb_rgb(255, 220, 120));
        fb_text_screen_centered(0, (int)fb_height() / 2 + 32, "Система остановлена.", fb_rgb(255, 255, 255));
        fb_mark_enable();
        fb_touch_all();
        fb_flush();
    } else {
        /* текстовый режим как последний шанс */
        volatile u16 *vt = (volatile u16 *)0xB8000;
        const char *m = "KERNEL PANIC";
        for (int i = 0; m[i]; i++) vt[i] = 0x4F00 | (u8)m[i];
    }
    for (;;) hlt();
}

/* --------------------------- генерация заглушек --------------------------- */

#define IRQ_STUB(n)                                                       \
    __attribute__((naked, used)) void irq_stub_##n(void)                  \
    {                                                                     \
        __asm__ __volatile__("pusha\n\tcld\n\tpushl $" #n                 \
                             "\n\tcall _irq_dispatch\n\taddl $4, %esp"    \
                             "\n\tpopa\n\tiret");                         \
    }

#define EXC_STUB(n)                                                       \
    __attribute__((naked, used)) void exc_stub_##n(void)                  \
    {                                                                     \
        __asm__ __volatile__("pusha\n\tcld\n\tpushl $" #n                 \
                             "\n\tcall _exc_panic\n1:\n\thlt\n\tjmp 1b"); \
    }

IRQ_STUB(0)  IRQ_STUB(1)  IRQ_STUB(2)  IRQ_STUB(3)
IRQ_STUB(4)  IRQ_STUB(5)  IRQ_STUB(6)  IRQ_STUB(7)
IRQ_STUB(8)  IRQ_STUB(9)  IRQ_STUB(10) IRQ_STUB(11)
IRQ_STUB(12) IRQ_STUB(13) IRQ_STUB(14) IRQ_STUB(15)

EXC_STUB(0)  EXC_STUB(1)  EXC_STUB(2)  EXC_STUB(3)
EXC_STUB(4)  EXC_STUB(5)  EXC_STUB(6)  EXC_STUB(7)
EXC_STUB(8)  EXC_STUB(9)  EXC_STUB(10) EXC_STUB(11)
EXC_STUB(12) EXC_STUB(13) EXC_STUB(14) EXC_STUB(15)
EXC_STUB(16) EXC_STUB(17) EXC_STUB(18) EXC_STUB(19)
EXC_STUB(20) EXC_STUB(21) EXC_STUB(22) EXC_STUB(23)
EXC_STUB(24) EXC_STUB(25) EXC_STUB(26) EXC_STUB(27)
EXC_STUB(28) EXC_STUB(29) EXC_STUB(30) EXC_STUB(31)

static void set_gate(int n, void (*fn)(void))
{
    u32 addr = (u32)(unsigned long)fn;
    idt[n].lo    = (u16)(addr & 0xFFFF);
    idt[n].sel   = 0x08;
    idt[n].zero  = 0;
    idt[n].flags = 0x8E; /* present, ring0, 32-bit interrupt gate */
    idt[n].hi    = (u16)(addr >> 16);
}

void irq_install(int n, irq_handler_t fn)
{
    if (n >= 0 && n < 16) irq_handlers[n] = fn;
}

void pic_mask_update(u16 irq_mask)
{
    outb(0x21, (u8)(irq_mask & 0xFF));
    outb(0xA1, (u8)(irq_mask >> 8));
}

void pic_unmask(u16 irq_mask)
{
    pic_mask_update((u16)~irq_mask);
}

void idt_init(void)
{
    static void (*const irq_stubs[16])(void) = {
        irq_stub_0, irq_stub_1, irq_stub_2, irq_stub_3,
        irq_stub_4, irq_stub_5, irq_stub_6, irq_stub_7,
        irq_stub_8, irq_stub_9, irq_stub_10, irq_stub_11,
        irq_stub_12, irq_stub_13, irq_stub_14, irq_stub_15
    };
    static void (*const exc_stubs[32])(void) = {
        exc_stub_0, exc_stub_1, exc_stub_2, exc_stub_3,
        exc_stub_4, exc_stub_5, exc_stub_6, exc_stub_7,
        exc_stub_8, exc_stub_9, exc_stub_10, exc_stub_11,
        exc_stub_12, exc_stub_13, exc_stub_14, exc_stub_15,
        exc_stub_16, exc_stub_17, exc_stub_18, exc_stub_19,
        exc_stub_20, exc_stub_21, exc_stub_22, exc_stub_23,
        exc_stub_24, exc_stub_25, exc_stub_26, exc_stub_27,
        exc_stub_28, exc_stub_29, exc_stub_30, exc_stub_31
    };

    for (int i = 0; i < IDT_ENTRIES; i++) {
        idt[i].lo = idt[i].sel = idt[i].hi = 0;
        idt[i].zero = 0; idt[i].flags = 0;
    }
    for (int i = 0; i < 16; i++) set_gate(32 + i, irq_stubs[i]);
    for (int i = 0; i < 32; i++) set_gate(i, exc_stubs[i]);

    struct dt_ptr p;
    p.limit = (u16)(sizeof(idt) - 1);
    p.base = (u32)(unsigned long)idt;
    lidt_load(&p);

    /* ремап PIC: master 0x20..0x27, slave 0x28..0x2F */
    outb(0x20, 0x11); io_wait();
    outb(0xA0, 0x11); io_wait();
    outb(0x21, 0x20); io_wait();
    outb(0xA1, 0x28); io_wait();
    outb(0x21, 0x04); io_wait();      /* slave на IRQ2 */
    outb(0xA1, 0x02); io_wait();
    outb(0x21, 0x01); io_wait();
    outb(0xA1, 0x01); io_wait();
    pic_mask_update(0xFFFF);          /* всё замаскировано до поры */
    outb(0x20, 0x20);
    outb(0xA0, 0x20);
}
