/* fileman.c — файловый менеджер FAT32 и RAMFS, просмотрщик текста */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "kbd.h"
#include "mouse.h"
#include "fat32.h"
#include "ramfs.h"
#include "usb_ehci.h"
#include "ata.h"
#include "loader.h"

/* ============================ файловый менеджер ============================ */

#define FM_MAX 256
#define FM_ROW 18
#define FM_HDR 22
#define FM_DEVBAR 22    /* высота панели выбора устройства */

typedef struct {
    fat32_dirent_t fat_ents[FM_MAX];
    ramfs_dirent_t ram_ents[FM_MAX];
    int  fat_n, ram_n, sel, scroll, depth;
    int  mode; /* 0 = FAT32(ATA), 1 = RAMFS, 2 = FAT32(USB) */
    int  usb_inited;          /* 1 = fat32_init_usb() уже вызвана */
    int  dev_hover;           /* -1 = none, 0..2 = device button hover */
    struct { u32 cluster; char path[200]; } stk[16];
} fm_t;

static void fm_path_join(char *dst, const char *name)
{
    int l = (int)strlen(dst);
    if (l && dst[l-1] != '/') dst[l++] = '/';
    int i = 0;
    while (name[i] && l < 190) dst[l++] = name[i++];
    dst[l] = 0;
}

static void fm_reload(fm_t *m)
{
    if (m->mode == 0) {
        /* FAT32 ATA режим */
        m->fat_n = fat32_ready() ? fat32_list(m->stk[m->depth].cluster, m->fat_ents, FM_MAX) : 0;
        m->ram_n = 0;
    } else if (m->mode == 2) {
        /* FAT32 USB режим */
        m->fat_n = fat32_ready() ? fat32_list(m->stk[m->depth].cluster, m->fat_ents, FM_MAX) : 0;
        m->ram_n = 0;
    } else {
        /* RAMFS режим */
        m->ram_n = ramfs_ready() ? ramfs_list(m->ram_ents, FM_MAX) : 0;
        m->fat_n = 0;
    }
    m->sel = 0;
    m->scroll = 0;
}

static void fm_draw(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));

    /* === Панель выбора устройства === */
    fb_fill_rect(0, 0, cw, FM_DEVBAR, fb_rgb(0x0C, 0x0F, 0x14));
    fb_hline(0, cw - 1, FM_DEVBAR - 1, fb_rgb(0x2C, 0x31, 0x38));
    {
        const char *names[3] = {"[HDD]", "[RAM]", "[USB]"};
        u32 avail[3] = {0, 0, 0};
        avail[0] = (ata_present() && !ata_is_cdrom()) ? 1 : 0;
        avail[1] = ramfs_ready() ? 1 : 0;
        avail[2] = usb_ehci_storage_ready() ? 1 : 0;
        int bx = 6;
        for (int i = 0; i < 3; i++) {
            int bw = 50;
            int hot = (m->mode == i);
            int hov = (m->dev_hover == i);
            u32 bg = hot ? fb_rgb(0x24, 0x43, 0x5F) :
                    (hov ? fb_rgb(0x1E, 0x33, 0x4A) : fb_rgb(0x14, 0x18, 0x1E));
            u32 fg = avail[i] ? (hot ? fb_rgb(0xE6, 0xEA, 0xEE) : fb_rgb(0x9A, 0xA3, 0xAC))
                   : fb_rgb(0x40, 0x40, 0x40);
            fb_fill_rect(bx, 2, bw, FM_DEVBAR - 4, bg);
            fb_rect(bx, 2, bw, FM_DEVBAR - 4, fb_rgb(0x2C, 0x31, 0x38));
            fb_text(bx + 6, 4, names[i], fg, -1);
            bx += bw + 4;
        }
        /* Информация о выбранном устройстве справа */
        const char *info = "";
        if (m->mode == 0) info = fat32_ready() ? fat32_label() : "нет FAT32";
        else if (m->mode == 1) info = ramfs_ready() ? "RAM disk" : "не инициализирован";
        else info = fat32_ready() ? fat32_label() : "нет флешки";
        fb_text(bx + 8, 4, info, fb_rgb(0x6F, 0xB3, 0xF2), -1);
    }

    /* === Заголовок с путём === */
    {
        int hy = FM_DEVBAR;
        fb_fill_rect(0, hy, cw, FM_HDR, fb_rgb(0x1E, 0x4A, 0x73));
        char title[120];
        const char *mode_name = m->mode == 0 ? "FAT32" :
                                m->mode == 1 ? "RAMFS" : "USB";
        snprintf(title, sizeof(title), "%s: %s",
                 mode_name, m->stk[m->depth].path);
        fb_text(6, hy + (FM_HDR - 16) / 2, title, fb_rgb(0xE6, 0xEA, 0xEE), -1);
    }

    /* Проверка готовности устройства */
    int list_y0 = FM_DEVBAR + FM_HDR;
    if ((m->mode != 1 && !fat32_ready()) || (m->mode == 1 && !ramfs_ready())) {
        const char *msg = m->mode == 2 ? "USB FAT32: флешка не готова" :
                          m->mode == 0 ? "FAT32-раздел не найден." :
                          "RAMFS не инициализирован.";
        fb_text(12, list_y0 + 8, msg, fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, list_y0 + 28, "Кликните на устройство выше", fb_rgb(0x8A, 0x93, 0x9C), -1);
        return;
    }

    int area_h  = ch - list_y0 - 20;
    int vis = area_h / FM_ROW;
    if (vis < 1) vis = 1;
    if (m->sel < m->scroll) m->scroll = m->sel;
    if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;

    int y0 = list_y0 + 2;
    int total = m->mode != 1 ? m->fat_n : m->ram_n;
    
    for (int i = 0; i < vis; i++) {
        int idx = m->scroll + i;
        if (idx >= total) break;
        
        const char *name;
        u32 size;
        int is_dir;
        
        if (m->mode == 0) {
            fat32_dirent_t *e = &m->fat_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = (e->attr & 0x10) ? 1 : 0;
        } else {
            ramfs_dirent_t *e = &m->ram_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        }
        
        int yy = y0 + i * FM_ROW;
        if (idx == m->sel)
            fb_fill_rect(0, yy, cw, FM_ROW, fb_rgb(0x24, 0x43, 0x5F));

        u32 col = is_dir ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0xDD, 0xE2, 0xE6);
        fb_text(6, yy + 1, is_dir ? "[D]" : "   ", col, -1);
        fb_text(6 + 4*8, yy + 1, name, col, -1);

        if (!is_dir) {
            char buf[24];
            if (size < 1024)                 snprintf(buf, sizeof(buf), "%u B",   (unsigned)size);
            else if (size < 1024u*1024)      snprintf(buf, sizeof(buf), "%u KiB", (unsigned)(size/1024));
            else                             snprintf(buf, sizeof(buf), "%u MiB", (unsigned)(size/(1024u*1024)));
            int tw = (int)strlen(buf) * 8;
            fb_text(cw - tw - 8, yy + 1, buf, fb_rgb(0x8A, 0x93, 0x9C), -1);
        }
    }

    char st[64];
    snprintf(st, sizeof(st), "%d / %d | Tab: сменить режим", 
             total ? m->sel + 1 : 0, total);
    fb_text(6, ch - 16, st, fb_rgb(0x8A, 0x93, 0x9C), -1);
}

/* --------- просмотрщик --------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
    int   source; /* 0 = FAT32, 1 = RAMFS */
} viewer_t;

static void viewer_draw(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cols = cw / 8;
    int vis  = ch / 16;

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));

    /* Заголовок с источником */
    const char *src = v->source == 0 ? "FAT32" : "RAMFS";
    u32 src_col = v->source == 0 ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0x90, 0xEE, 0x90);
    fb_text(4, 2, src, src_col, -1);

    int line = 0, i = 0;
    while (i < (int)v->len && line < v->top) {
        if (v->buf[i] == '\n') line++;
        i++;
    }
    int y = 18;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)v->len; r++) {
        int start = i, end = i;
        while (end < (int)v->len && v->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 255)  len = 255;
        memcpy(tmp, v->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        i = end + (end < (int)v->len ? 1 : 0);
        y += 16;
    }
}

static void viewer_key(window_t *w, const key_event_t *ev)
{
    viewer_t *v = (viewer_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == KBD_UP)   { if (v->top > 0) v->top--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { v->top++; win_invalidate(w); }
    if (ev->code == 0x49)     { v->top -= 16; if (v->top < 0) v->top = 0; win_invalidate(w); }
    if (ev->code == 0x51)     { v->top += 16; win_invalidate(w); }
}

static void viewer_close(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    if (v) { if (v->buf) free(v->buf); free(v); }
}

static void viewer_open_fat(const fat32_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = fat32_read_file(e->first_cluster, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [FAT32]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

static void viewer_open_ram(const ramfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 1;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = ramfs_read(e->name, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [RAMFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* --------- события файлового менеджера --------- */

/* Проверить, заканчивается ли имя на .c (без учёта регистра). */
static int name_is_c_source(const char *name)
{
    int L = (int)strlen(name);
    if (L < 2) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    int ext_len = L - dot;
    /* .c → C (c4), .cs → CMScript */
    if (ext_len == 2) {
        char ext = name[dot + 1];
        return (ext == 'c' || ext == 'C');
    }
    if (ext_len == 3) {
        /* .cs check */
        if ((name[dot+1]=='c'||name[dot+1]=='C') && (name[dot+2]=='s'||name[dot+2]=='S'))
            return 1;
    }
    return 0;
}

static int name_is_cs_script(const char *name)
{
    int L = (int)strlen(name);
    if (L < 3) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 3) return 0;
    return (name[dot+1]=='c'||name[dot+1]=='C') && (name[dot+2]=='s'||name[dot+2]=='S');
}

static int name_is_c4_source(const char *name)
{
    int L = (int)strlen(name);
    if (L < 2) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 2) return 0;
    char ext = name[dot + 1];
    return (ext == 'c' || ext == 'C');
}

/* Проверить, заканчивается ли имя на .bin (исполняемое приложение). */
static int name_is_bin_app(const char *name)
{
    int L = (int)strlen(name);
    if (L < 5) return 0;
    int dot = -1;
    for (int i = L - 1; i >= 0; i--) {
        if (name[i] == '.') { dot = i; break; }
    }
    if (dot < 0) return 0;
    if (L - dot != 4) return 0;
    return (name[dot+1]=='b'||name[dot+1]=='B')
        && (name[dot+2]=='i'||name[dot+2]=='I')
        && (name[dot+3]=='n'||name[dot+3]=='N');
}

static void fm_open_selected(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int total = m->mode != 1 ? m->fat_n : m->ram_n;
    if (m->sel < 0 || m->sel >= total) return;

    if (m->mode != 1) {
        /* FAT32 режим (ATA или USB) */
        fat32_dirent_t *e = &m->fat_ents[m->sel];
        if (e->attr & 0x10) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_cluster;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            fm_reload(m);
            win_invalidate(w);
        } else if (name_is_cs_script(e->name)) {
            /* .cs-файл → открыть в CMScript-редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = fat32_read_file(e->first_cluster, e->size, buf, cap);
                buf[got] = 0;
                if (ramfs_ready()) {
                    ramfs_delete(e->name);
                    if (ramfs_create(e->name, got + 1))
                        ramfs_write(e->name, buf, got + 1);
                }
                app_cmscript_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_c4_source(e->name)) {
            viewer_open_fat(e);
        }
    } else {
        /* RAMFS режим */
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        if (e->is_dir) {
            return;
        } else if (name_is_c4_source(e->name)) {
            /* .c-файл из RAMFS → открыть в редакторе C */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(e->name, buf, cap);
                buf[got] = 0;
                app_editor_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_cs_script(e->name)) {
            /* .cs-файл из RAMFS → открыть в CMScript-редакторе */
            u32 cap = 65536;
            if (e->size < cap) cap = e->size;
            char *buf = (char *)malloc(cap + 1);
            if (buf) {
                u32 got = ramfs_read(e->name, buf, cap);
                buf[got] = 0;
                app_cmscript_open_with(e->name, buf, (int)got);
                free(buf);
            }
        } else if (name_is_bin_app(e->name)) {
            /* .bin-файл из RAMFS → запустить как приложение через loader */
            int tid = loader_spawn(e->name, NULL);
            (void)tid;
        } else {
            viewer_open_ram(e);
        }
    }
}

static void fm_up(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    if (m->depth == 0) return;
    m->depth--;
    fm_reload(m);
    win_invalidate(w);
}

static void fm_key(window_t *w, const key_event_t *ev)
{
    fm_t *m = (fm_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    
    if (ev->code == 0x0F) { /* Tab - переключение режима (ATA → RAM → USB → ATA) */
        m->mode = (m->mode + 1) % 3;
        m->depth = 0;
        if (m->mode == 0) {
            /* ATA FAT32 */
            fat32_init();
            m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
            strcpy(m->stk[0].path, "/");
        } else if (m->mode == 2) {
            /* USB FAT32 — инициализируем при первом переключении */
            fat32_init_usb();
            m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
            strcpy(m->stk[0].path, "/");
        } else {
            /* RAMFS */
            m->stk[0].cluster = 0;
            strcpy(m->stk[0].path, "/");
        }
        fm_reload(m);
        win_invalidate(w);
        return;
    }
    
    if (ev->code == KBD_UP)   { if (m->sel > 0)     m->sel--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { 
        int total = m->mode != 1 ? m->fat_n : m->ram_n;
        if (m->sel+1 < total) m->sel++; 
        win_invalidate(w); 
    }
    if (ev->code == 0x1C || ev->ch == '\n') fm_open_selected(w);
    if (ev->code == 0x0E || ev->ch == '\b') fm_up(w);
    if (ev->ch == 'r' || ev->ch == 'R') { fm_reload(m); win_invalidate(w); }
}

static void fm_switch_mode(fm_t *m, int new_mode)
{
    m->mode = new_mode;
    m->depth = 0;
    if (m->mode == 0) {
        fat32_init();
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else if (m->mode == 2) {
        fat32_init_usb();
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    } else {
        m->stk[0].cluster = 0;
    }
    strcpy(m->stk[0].path, "/");
    fm_reload(m);
}

static void fm_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fm_t *m = (fm_t *)w->data;

    /* Обработка кликов по кнопкам устройств */
    if (my < FM_DEVBAR) {
        /* Подсветка наведения */
        int bx = 6;
        int new_hover = -1;
        for (int i = 0; i < 3; i++) {
            if (mx >= bx && mx < bx + 50) { new_hover = i; break; }
            bx += 50 + 4;
        }
        if (new_hover != m->dev_hover) {
            m->dev_hover = new_hover;
            win_invalidate(w);
        }
        /* Клик по кнопке */
        if ((changed & MSB_LEFT) && (btn & MSB_LEFT) && new_hover >= 0) {
            fm_switch_mode(m, new_hover);
            win_invalidate(w);
        }
        return;
    }
    m->dev_hover = -1;

    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return;
    if (my < FM_DEVBAR + FM_HDR + 2) return;
    int row = (my - FM_DEVBAR - FM_HDR - 2) / FM_ROW;
    int idx = m->scroll + row;
    int total = m->mode != 1 ? m->fat_n : m->ram_n;
    if (idx < 0 || idx >= total) return;
    if (idx == m->sel) fm_open_selected(w);
    else { m->sel = idx; win_invalidate(w); }
}

static void fm_close(window_t *w) { free(w->data); }

void app_files_open(void)
{
    fm_t *m = (fm_t *)malloc(sizeof(fm_t));
    if (!m) return;
    memset(m, 0, sizeof(fm_t));

    m->depth = 0;
    m->mode = fat32_ready() ? 0 : (ramfs_ready() ? 1 : 0);
    m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    strcpy(m->stk[0].path, "/");
    fm_reload(m);

    u32 W = fb_width(), H = fb_height();
    int ww = 520, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Файлы", 30, 30, ww, wh, fm_draw, fm_key, fm_mouse, NULL, fm_close, m);
}