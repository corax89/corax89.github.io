/* rtc.h — часы реального времени (CMOS) */
#ifndef RTC_H
#define RTC_H

void rtc_get_time(int *hours, int *mins, int *secs);

#endif
