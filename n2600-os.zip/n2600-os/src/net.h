/* net.h — минимальный TCP/IP стек для N2600-OS.
 *
 * Реализованы нижние уровни:
 *   - Ethernet: parsing/построение кадров (dst MAC, src MAC, EtherType)
 *   - ARP: запрос/ответ, кэш на 16 записей (IP->MAC), разрешение за 1 запрос
 *   - IP: приём/передача пакетов (фрагментация не поддерживается, MTU=1500)
 *   - ICMP: Echo Request / Echo Reply (для ping)
 *
 * Не реализовано:
 *   - TCP (только UDP будет добавлен в следующей итерации)
 *   - Фрагментация IP
 *   - DHCP (статический IP, настраивается командой ipconfig)
 *
 * Драйвер NIC абстрагирован через указатели функций: e1000_send / e1000_recv.
 */
#ifndef NET_H
#define NET_H

#include "types.h"

#define NET_PKT_MAX 1518

/* Ethernet frame */
typedef struct __attribute__((packed)) {
    u8 dst[6];
    u8 src[6];
    u16 ethertype;   /* 0x0806=ARP, 0x0800=IP */
} eth_hdr_t;

#define ETHERTYPE_ARP 0x0806
#define ETHERTYPE_IPV4 0x0800

/* ARP packet (Ethernet/IPv4) */
typedef struct __attribute__((packed)) {
    u16 htype;       /* 1 = Ethernet */
    u16 ptype;       /* 0x0800 = IPv4 */
    u8  hlen;        /* 6 */
    u8  plen;        /* 4 */
    u16 oper;        /* 1=request, 2=reply */
    u8  sha[6];      /* sender hardware addr */
    u8  spa[4];      /* sender protocol addr */
    u8  tha[6];      /* target hardware addr */
    u8  tpa[4];      /* target protocol addr */
} arp_pkt_t;

/* IPv4 header (без опций, 20 байт) */
typedef struct __attribute__((packed)) {
    u8  ver_ihl;     /* version=4, ihl=5 (no options) */
    u8  tos;
    u16 tot_len;     /* total length (header + payload) */
    u16 id;
    u16 flags_frag;  /* flags + fragment offset */
    u8  ttl;
    u8  protocol;    /* 1=ICMP, 17=UDP */
    u16 checksum;
    u8  src_ip[4];
    u8  dst_ip[4];
} ip_hdr_t;

#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP  6
#define IP_PROTO_UDP  17

/* ICMP header (8 байт, далее payload) */
typedef struct __attribute__((packed)) {
    u8  type;        /* 8=Echo Request, 0=Echo Reply, 3=Dest Unreach */
    u8  code;
    u16 checksum;
    u16 id;
    u16 seq;
} icmp_hdr_t;

#define ICMP_TYPE_ECHO_REPLY   0
#define ICMP_TYPE_ECHO_REQUEST 8

/* Инициализация стека (вызывается после e1000_init). */
void net_init(void);

/* Установить наш IP-адрес. Если 0.0.0.0 — стек не отвечает на пакеты. */
void net_set_ip(u32 ip);
u32  net_get_ip(void);

/* Есть ли вообще какой-либо NIC? (E1000 / VirtIO / NE2000) */
int  net_nic_present(void);

/* Имя активного NIC-чипа. */
const char *net_nic_name(void);

/* MAC-адрес NIC. */
void net_get_mac(u8 out_mac[6]);

/* Главная функция обработки: читает пакет из NIC, диспетчеризует его по
 * ethertype (ARP/IP). Должна вызываться из основного цикла. */
void net_poll(void);

/* Отправить ARP-запрос (для определения MAC-адреса по IP). */
int  net_send_arp_request(u32 target_ip);

/* Отправить ICMP Echo Request (ping). */
int  net_send_icmp_echo(u32 target_ip, u16 id, u16 seq, const void *payload, u32 payload_len);

/* Установить шлюз по умолчанию (для IP не в нашей подсети). */
void net_set_gateway(u32 gw);
u32  net_get_gateway(void);

/* Установить сетевую маску (по умолчанию 255.255.255.0). */
void net_set_netmask(u32 mask);
u32  net_get_netmask(void);

/* Парсинг IP-адреса "a.b.c.d" в u32 (host order). Возвращает 1 при успехе. */
int  net_aton(const char *str, u32 *out_ip);

/* Обратное: форматирование IP в "a.b.c.d" — возвращает число записанных байт. */
int  net_ntoa(u32 ip, char *out, u32 out_max);

/* Зарегистрировать callback для ICMP-ответов (для ping). */
typedef void (*net_icmp_cb_t)(u32 src_ip, u16 id, u16 seq,
                               const void *payload, u32 payload_len);
void net_set_icmp_callback(net_icmp_cb_t cb);

/* Получить число отправленных/принятых пакетов (для статистики). */
u32 net_tx_packets(void);
u32 net_rx_packets(void);

/* ---------- ARP кэш ---------- */
typedef struct {
    u32 ip;        /* 0 = пустая запись */
    u8  mac[6];
} net_arp_entry_t;

#define NET_ARP_CACHE_SIZE 16

/* Получить дамп ARP-кэша. Записывает до max_entries в out.
 * Возвращает число активных записей. */
int net_arp_dump(net_arp_entry_t *out, int max_entries);

/* ===================== UDP ===================== */

typedef struct {
    u32 local_ip;        /* наш IP (для фильтра), 0 = любой */
    u16 local_port;      /* локальный порт, 0 = не используется */
    u16 remote_port;     /* удалённый порт (для send — куда шлём) */
    u32 remote_ip;        /* удалённый IP (для send — куда шлём) */
    int  in_use;
} net_udp_socket_t;

#define NET_MAX_UDP_SOCKETS 16

/* Открыть UDP-сокет. Возвращает индекс сокета (>=0) или -1. */
int  net_udp_open(u16 local_port);
void net_udp_close(int sock);
/* Отправить UDP-сообщение. dst_ip/dst_port — куда, data/len — что.
 * Возвращает число отправленных байт или -1. */
int  net_udp_send(int sock, u32 dst_ip, u16 dst_port, const void *data, u32 len);
/* Зарегистрировать callback для входящих UDP-пакетов.
 * cb(src_ip, src_port, dst_port, data, len) — вызывается из net_poll. */
typedef void (*net_udp_recv_cb_t)(u32 src_ip, u16 src_port, u16 dst_port,
                                   const void *data, u32 len);
void net_udp_set_callback(net_udp_recv_cb_t cb);

/* ===================== TCP ===================== */

typedef enum {
    TCP_CLOSED = 0,
    TCP_SYN_SENT,
    TCP_SYN_RECEIVED,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT_1,
    TCP_FIN_WAIT_2,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
    TCP_CLOSING,
    TCP_TIME_WAIT
} tcp_state_t;

typedef struct {
    u32  local_ip;
    u16  local_port;       /* наш порт */
    u32  remote_ip;
    u16  remote_port;      /* удалённый порт */
    u32  seq;              /* наш seq (следующий для отправки) */
    u32  ack;              /* последний ack, который мы отправили */
    tcp_state_t state;
    int  in_use;
    /* TCP options (from peer's SYN) */
    u16  mss;              /* maximum segment size (default 1460) */
    u8   window_scale;     /* window scaling factor (0 = no scaling) */
    /* Retransmission queue */
    u32  retransmit_seq;   /* seq последнего неотправленного сегмента */
    u32  retransmit_tick;  /* когда отправили последний раз */
    u8   retransmit_count; /* число повторных передач */
} net_tcp_socket_t;

#define NET_MAX_TCP_SOCKETS 8

/* Установить TCP-соединение (active open).
 * Возвращает индекс сокета (>=0) или -1. */
int  net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port);

/* Закрыть TCP-соединение (active close — посылает FIN). */
void net_tcp_close(int sock);

/* Отправить данные по TCP-соединению. */
int  net_tcp_send(int sock, const void *data, u32 len);

/* Получить состояние сокета. */
tcp_state_t net_tcp_state(int sock);

/* Зарегистрировать callback для входящих данных TCP. */
typedef void (*net_tcp_recv_cb_t)(int sock, u32 src_ip, u16 src_port,
                                   const void *data, u32 len);
void net_tcp_set_callback(net_tcp_recv_cb_t cb);

/* Текстовое имя состояния TCP. */
const char *tcp_state_name(tcp_state_t s);

/* ===================== TCP Passive LISTEN ===================== */
/* Открыть listening-сокет на порту local_port.
 * При входящем соединении вызывается callback cb(new_sock, remote_ip, remote_port).
 * Возвращает индекс listen-сокета или -1. */
typedef void (*tcp_accept_cb_t)(int new_sock, u32 remote_ip, u16 remote_port);
int  net_tcp_listen(u16 local_port, tcp_accept_cb_t cb);

/* ===================== TCP Retransmission ===================== */
/* Запустить обработку таймеров TCP (вызывается из net_poll). */
void net_tcp_timer(void);

/* ===================== DHCP клиент ===================== */
typedef enum {
    DHCP_INIT = 0,
    DHCP_SELECTING,
    DHCP_REQUESTING,
    DHCP_BOUND,
    DHCP_RENEWING,
    DHCP_REBINDING
} dhcp_state_t;

/* Запустить DHCP-клиент: отправляет DISCOVER, ждёт OFFER, шлёт REQUEST.
 * Блокирует выполнение на max_ms миллисекунд (через task_yield).
 * Возвращает 1 при успехе (IP/gateway/netmask получены), 0 при неудаче. */
int  net_dhcp_acquire(u32 max_ms);

/* Текущее состояние DHCP. */
dhcp_state_t net_dhcp_state(void);

/* ===================== DNS resolver ===================== */
/* Разрешить имя домена в IP-адрес.
 *   hostname    — например "example.com" (NUL-terminated)
 *   out_ip      — куда записать результат (host-order u32)
 *   max_ms      — максимальное время ожидания
 * Возвращает 1 при успехе, 0 при неудаче/таймауте. */
int  net_dns_resolve(const char *hostname, u32 *out_ip, u32 max_ms);

/* Получить DNS-сервер (обычно устанавливается через DHCP). */
u32  net_dns_server(void);
void net_dns_set_server(u32 dns_ip);

/* ===================== HTTP клиент ===================== */
/* HTTP GET-запрос.
 *   host       — имя хоста (например "example.com" или IP-строка)
 *   port       — обычно 80
 *   path       — путь (например "/" или "/index.html")
 *   response   — буфер под HTTP-ответ (заголовки + тело)
 *   max_len    — ёмкость response
 *   max_ms     — таймаут
 * Возвращает длину полученного ответа (байт) или -1 при ошибке. */
int  net_http_get(const char *host, u16 port, const char *path,
                   char *response, u32 max_len, u32 max_ms);

#endif /* NET_H */
