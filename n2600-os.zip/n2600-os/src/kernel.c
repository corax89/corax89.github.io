/* kernel.c — точка входа N2600-OS.
 *
 * Multiboot-заголовок (AOUT_KLUDGE + VIDEO_MODE) лежит в секции .text.mb —
 * в самом начале образа, поэтому GRUB находит его в первых 8 КиБ плоского
 * бинарника, собираемого MinGW. GRUB выставляет VESA-режим по полям
 * заголовка (1280x600x32 + запасные), включает защищённый режим и передаёт
 * управление на kstart.
 */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "gdt.h"
#include "idt.h"
#include "mem.h"
#include "timer.h"
#include "kbd.h"
#include "mouse.h"
#include "fb.h"
#include "wm.h"
#include "apps.h"
#include "string.h"
#include "kernel.h"
#include "ata.h"
#include "fat32.h"
#include "iso9660.h"
#include "ramfs.h"
#include "task.h"
#include "usb.h"
#include "ath9k_wifi.h"
#include "e1000.h"
#include "ne2000.h"
#include "virtio_net.h"
#include "net.h"
#include "font.h"

/* Символы linker-скрипта: в C пишутся без ведущего подчёркивания
 * (COFF MinGW добавит его автоматически, совпадая с именами в скрипте). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------- multiboot-заголовок --------------------- */

void kstart(void);

#define MB_FLAGS (MB_FLAG_ALIGN | MB_FLAG_MEMINFO | MB_FLAG_VIDEO_MODE | MB_FLAG_AOUT_KLUDGE)

/* При флаге VIDEO_MODE GRUB2 читает из заголовка ещё 4 поля (байты 32..47):
 * mode_type (0 = фреймбуфер), width, height, depth.
 * Устанавливаем width=height=depth=0 → GRUB выберет ЛЮБОЙ доступный
 * 32-битный VESA-режим из gfxpayload (см. grub.cfg). Это надёжнее, чем
 * хардкодить 1280x600 — на реальном железе такого режима может не быть. */
__attribute__((section(".text.mb"), used, aligned(4)))
static const u32 mb_header[12] = {
    MB_MAGIC,
    MB_FLAGS,
    (u32)(0u - (MB_MAGIC + MB_FLAGS)),
    (u32)(unsigned long)load_start,   /* header_addr */
    (u32)(unsigned long)load_start,   /* load_addr   */
    (u32)(unsigned long)load_end,     /* load_end_addr */
    (u32)(unsigned long)bss_end,      /* bss_end_addr */
    (u32)(unsigned long)kstart,       /* entry_addr  */
    0,                                /* mode_type: 0 = линейный фреймбуфер */
    0,                                /* width=0: GRUB выберет из gfxpayload */
    0,                                /* height=0 */
    0                                 /* depth=0 */
};

/* ------------------------- входная точка ------------------------- */

/* Единственная asm-вставка потока управления: настраиваем стек и зовём C.
 * naked обязателен — нельзя допустить пролог с обращением к стеку до его настройки. */
__attribute__((naked, section(".text.ks"), used, noinline))
void kstart(void)
{
    __asm__ __volatile__(
        "movl $_stack_top, %esp\n"
        "pushl %ebx\n"      /* multiboot info */
        "pushl %eax\n"      /* magic */
        "call _kmain\n"
        "1:\n"
        "hlt\n"
        "jmp 1b");
}

/* ========================================================================
 * Отладка: COM1 (serial) + экран (после fb_init)
 * ======================================================================== */

/* ---------- COM1 ---------- */
#define COM1 0x3F8

static void serial_init(void)
{
    outb(COM1 + 1, 0x00);   /* отключить прерывания */
    outb(COM1 + 3, 0x80);   /* DLAB=1 */
    outb(COM1 + 0, 0x03);   /* делитель = 3 -> 38400 бод */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);   /* 8N1 */
    outb(COM1 + 2, 0xC7);   /* FIFO 14 байт, очистить */
    outb(COM1 + 4, 0x0B);   /* RTS/DSR */
}

void serial_putc(char c)
{
    while (!(inb(COM1 + 5) & 0x20)) { /* ждём THR empty */ }
    outb(COM1, (u8)c);
}

void serial_puts(const char *s)
{
    while (*s) {
        if (*s == '\n') serial_putc('\r');
        serial_putc(*s++);
    }
}

static void serial_puthex(u32 v)
{
    const char *d = "0123456789abcdef";
    serial_puts("0x");
    for (int i = 28; i >= 0; i -= 4) serial_putc(d[(v >> i) & 0xF]);
}

static void serial_putdec(i32 v)
{
    char buf[12]; int i = 0;
    if (v < 0) { serial_putc('-'); v = -v; }
    if (v == 0) { serial_putc('0'); return; }
    while (v && i < 11) { buf[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) serial_putc(buf[i]);
}

/* ---------- Экранный debug ---------- */

static int  dbg_y = 0;              /* текущая строка вывода на экране */
static u32  dbg_color_ok  = 0;      /* кэшируем цвета после fb_init */
static u32  dbg_color_err = 0;

/* Вывести строку одновременно в serial и на экран (если fb готов). */
static void dbg(const char *s)
{
    /* serial */
    serial_puts("[boot] ");
    serial_puts(s);
    serial_putc('\n');

    /* screen */
    if (fb_ready()) {
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_ok, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
}

/* Вывести ошибку (красным) */
static void dbg_err(const char *s)
{
    serial_puts("[ERR ] ");
    serial_puts(s);
    serial_putc('\n');

    if (fb_ready()) {
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_err, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
}

/* --------------------- ранний вывод (VGA text + LFB) --------------------- */

/* GRUB может выставить VESA-режим ДО прыжка в ядро. В этом случае
 * VGA-текстовый буфер 0xB8000 невидим — visible = linear framebuffer (LFB).
 * Поэтому ранний вывод идёт в ДВА места:
 *   1. VGA text buffer (0xB8000) — работает если GRUB оставил text mode
 *   2. LFB напрямую — работает если GRUB выставил VESA-режим
 * LFB-адрес берётся из multiboot info (framebuffer_addr).
 */

static volatile u16 * const vga_text = (volatile u16 *)0xB8000;
static int early_row = 0;
static int early_col = 0;

/* LFB info — заполняется в early_fb_init() из multiboot info */
static volatile u32 *early_lfb = NULL;
static u32 early_lfb_w = 0;
static u32 early_lfb_h = 0;
static u32 early_lfb_pitch = 0;
static u32 early_lfb_bpp = 0;

/* Инициализация раннего framebuffer-вывода из multiboot info.
 * Вызывается в самом начале kmain — ДО gdt_init. */
static void early_fb_init(const mb_info_t *mb)
{
    if (!mb) return;
    if (!(mb->flags & MBIF_FRAMEBUFFER)) return;
    if (mb->framebuffer_type != MB_FT_RGB) return;
    if (mb->framebuffer_bpp < 16) return;
    if (!mb->framebuffer_addr || !mb->framebuffer_width) return;

    early_lfb = (volatile u32 *)(u32)mb->framebuffer_addr;
    early_lfb_w = mb->framebuffer_width;
    early_lfb_h = mb->framebuffer_height;
    early_lfb_pitch = mb->framebuffer_pitch;
    early_lfb_bpp = mb->framebuffer_bpp;
}

/* Нарисовать один пиксель в LFB. Цвет = 0x00RRGGBB (32-bit). */
static void early_fb_pixel(int x, int y, u32 color)
{
    if (!early_lfb || x < 0 || y < 0 ||
        (u32)x >= early_lfb_w || (u32)y >= early_lfb_h) return;

    if (early_lfb_bpp == 32) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 4;
        dst[off]     = (u8)(color);        /* B */
        dst[off+1]   = (u8)(color >> 8);   /* G */
        dst[off+2]   = (u8)(color >> 16);  /* R */
    }
    else if (early_lfb_bpp == 24) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 3;
        dst[off]     = (u8)(color);
        dst[off+1]   = (u8)(color >> 8);
        dst[off+2]   = (u8)(color >> 16);
    }
    else if (early_lfb_bpp == 16) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 2;
        u8 r = (u8)((color >> 16) & 0xFF);
        u8 g = (u8)((color >> 8) & 0xFF);
        u8 b = (u8)(color & 0xFF);
        u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
        dst[off] = (u8)(c & 0xFF);
        dst[off+1] = (u8)((c >> 8) & 0xFF);
    }
}

/* Нарисовать один символ 8x16 в LFB. */
static void early_fb_char(int x, int y, char c, u32 fg, u32 bg)
{
    if (!early_lfb) return;
    if (c < 0x20 || c > 0x7E) c = '?';
    const unsigned char *glyph = font8x16[(int)c - 0x20];
    for (int row = 0; row < 16; row++) {
        unsigned char bits = glyph[row];
        for (int col = 0; col < 8; col++) {
            u32 color = (bits & (0x80 >> col)) ? fg : bg;
            early_fb_pixel(x + col, y + row, color);
        }
    }
}

/* Очистить экран: заполнить LFB одним цветом + VGA text буфер. */
static void early_clear(void)
{
    /* VGA text buffer */
    for (int i = 0; i < 80 * 25; i++) vga_text[i] = 0x1F00u;
    early_row = 0;
    early_col = 0;

    /* LFB */
    if (early_lfb) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 total = early_lfb_h * early_lfb_pitch;
        /* Цвет фона: тёмно-синий 0x000028 */
        u8 b = 0x28, g = 0x00, r = 0x00;
        if (early_lfb_bpp == 32) {
            for (u32 i = 0; i + 3 < total; i += 4) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r; dst[i+3] = 0;
            }
        }
        else if (early_lfb_bpp == 24) {
            for (u32 i = 0; i + 2 < total; i += 3) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r;
            }
        }
        else if (early_lfb_bpp == 16) {
            u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
            for (u32 i = 0; i + 1 < total; i += 2) {
                dst[i] = (u8)(c & 0xFF);
                dst[i+1] = (u8)((c >> 8) & 0xFF);
            }
        }
    }
}

/* Вывести строку в ОБА буфера: VGA text + LFB. */
#define EARLY_FG 0x00FFFF00u   /* жёлтый текст */
#define EARLY_BG 0x00000028u   /* тёмно-синий фон */

static void early_puts(const char *s)
{
    while (*s) {
        char c = *s++;

        /* --- VGA text buffer (0xB8000) --- */
        if (c == '\n') {
            early_col = 0;
            early_row++;
            if (early_row >= 25) {
                for (int i = 0; i < 80 * 24; i++)
                    vga_text[i] = vga_text[i + 80];
                for (int i = 80 * 24; i < 80 * 25; i++)
                    vga_text[i] = 0x1F00u;
                early_row = 24;
            }
            continue;
        }
        if (early_col >= 80) {
            early_col = 0;
            early_row++;
            if (early_row >= 25) {
                for (int i = 0; i < 80 * 24; i++)
                    vga_text[i] = vga_text[i + 80];
                for (int i = 80 * 24; i < 80 * 25; i++)
                    vga_text[i] = 0x1F00u;
                early_row = 24;
            }
        }
        vga_text[early_row * 80 + early_col] = (u16)(0x1F00u | (u8)c);

        /* --- LFB (если доступен) --- */
        if (early_lfb && early_lfb_w >= 8) {
            int x = early_col * 8;
            int y = early_row * 16;
            if (y + 16 < (int)early_lfb_h) {
                early_fb_char(x, y, c, EARLY_FG, EARLY_BG);
            }
        }

        early_col++;
    }
}

static void early_putc(char c)
{
    char buf[2] = { c, 0 };
    early_puts(buf);
}

static void early_putu(u32 v)
{
    char buf[12];
    int i = 0;
    if (v == 0) { early_putc('0'); return; }
    while (v) { buf[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) early_putc(buf[i]);
}

static void early_puthex(u32 v)
{
    const char *h = "0123456789ABCDEF";
    early_puts("0x");
    for (int i = 28; i >= 0; i -= 4)
        early_putc(h[(v >> i) & 0xF]);
}

static void vga_fail(const char *msg)
{
    /* serial — первым делом */
    serial_puts("[FATAL] ");
    serial_puts(msg);
    serial_puts("\n");

    /* Ранний вывод в VGA + LFB */
    early_clear();
    early_puts("=== N2600-OS FATAL ===\n");
    early_puts(msg);
    early_puts("\n\nSystem halted.");

    /* QEMU debug port */
    for (const char *p = msg; *p; p++) outb(0xE9, (u8)*p);

    for (;;)
        hlt();
}

/* --------------------------- служебное --------------------------- */

static const mb_info_t *g_mbi = NULL;

const mb_info_t *mb_info(void) { return g_mbi; }

void sys_reboot(void)
{
    cli();
    for (u32 i = 0; i < 100000 && (inb(0x64) & 0x02); i++) {}
    outb(0x64, 0xFE);
    for (;;)
        hlt();
}

void sys_poweroff(void)
{
    cli();
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;)
        hlt();
}

/* ------------------------------ kmain ------------------------------ */

void kmain(u32 magic, const mb_info_t *mb)
{
    /* Первым делом — serial, чтобы поймать даже падение до gdt. */
    serial_init();
    serial_puts("\n\n=== N2600-OS boot ===\n");

    /* Инициализируем ранний LFB-вывод из multiboot info.
     * Это позволяет писать текст ПРЯМО в фреймбуфер ДО fb_init,
     * что критично на реальном железе где GRUB уже выставил VESA-режим. */
    early_fb_init(mb);
    early_clear();
    early_puts("N2600-OS boot...\n");

    g_mbi = mb;

    early_puts("magic=");
    early_puthex(magic);
    early_puts("\n");

    if (magic != MB_BOOTLOADER_MAGIC) {
        early_puts("ERROR: bad multiboot magic\n");
        early_puts("expected=0x2BADB002\n");
        vga_fail("bad multiboot magic");
        return;
    }
    early_puts("magic OK\n");

    /* Выводим информацию о framebuffer из multiboot info */
    if (mb->flags & MBIF_FRAMEBUFFER) {
        early_puts("FB: ");
        early_putu(mb->framebuffer_width);
        early_putc('x');
        early_putu(mb->framebuffer_height);
        early_putc('x');
        early_putu(mb->framebuffer_bpp);
        early_puts(" @");
        early_puthex((u32)(u32)mb->framebuffer_addr);
        early_puts("\n");
    } else {
        early_puts("FB: NO framebuffer info!\n");
    }

    early_puts("gdt...");
    serial_puts("[boot] gdt_init...\n");
    gdt_init();
    early_puts("OK\n");

    early_puts("idt...");
    serial_puts("[boot] idt_init...\n");
    idt_init();
    early_puts("OK\n");

    early_puts("mem...");
    serial_puts("[boot] mem_init...\n");
    mem_init(mb);
    early_puts("OK\n");

    /* Фреймбуфер поднимаем как можно раньше — нужен для экранной отладки. */
    early_puts("fb...");
    serial_puts("[boot] fb_init...\n");
    if (!fb_init(mb)) {
        early_puts("FAIL\n");
        vga_fail("no VESA framebuffer (need 16+ bpp mode)");
        return;
    }
    early_puts("OK\n");

    dbg_color_ok  = fb_rgb(0xFF, 0xFF, 0x00);
    dbg_color_err = fb_rgb(0xFF, 0x60, 0x60);

    {
        char buf[80];
        snprintf(buf, sizeof(buf), "fb: %ux%u, %u bpp, pitch %u",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 (unsigned)fb_bpp(), (unsigned)fb_pitch());
        dbg(buf);
    }

    dbg("fb_make_bg...");    fb_make_bg();

    /* =======================================================================
     * ЗАЩИТА: Аппаратное маскирование IRQ 14 и 15 (ATA Primary/Secondary)
     * 0xA1 - порт данных Slave PIC. Биты 6 и 7 отвечают за IRQ 14 и 15.
     * Устанавливаем их в 1, чтобы прерывания от диска физически не дошли до CPU.
     * ======================================================================= */
    outb(0xA1, inb(0xA1) | 0xC0);
    dbg("IRQ14/15 masked");

        /* ---------- ATA ---------- */
    dbg("ata_init...");
    {
        int r = ata_init();
        if (r) {
            char buf[80];
            if (ata_is_cdrom()) {
                snprintf(buf, sizeof(buf),
                         "ata: CD-ROM on port 0x%x, sel 0x%x (%s)",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model());
            } else {
                snprintf(buf, sizeof(buf),
                         "ata: HDD on port 0x%x, sel 0x%x, %s, sectors=%u",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model(), (unsigned)ata_sectors());
            }
            dbg(buf);
        } else {
            dbg_err("ata: NOT present (return 0)");
        }
    }

    /* ---------- FAT32 ---------- */
    dbg("fat32_init...");
    if (fat32_init())
        dbg("fat32: ready");
    else
        dbg_err("fat32: not found (return 0)");

    /* ---------- ISO9660 ---------- */
    dbg("iso9660_init...");
    if (iso9660_init())
        dbg("iso9660: ready");
    else
        dbg_err("iso9660: not found (return 0)");

    /* ---------- RAMFS ---------- */
    dbg("ramfs_init...");
    if (ramfs_init()) {
        char buf[80];
        snprintf(buf, sizeof(buf), "ramfs: ready, %u МиБ",
                 (unsigned)(ramfs_total_space() / (1024 * 1024)));
        dbg(buf);
    } else {
        dbg_err("ramfs: init failed");
    }
    /* ---------- периферия ---------- */
    dbg("timer_init...");    timer_init(100);
    dbg("kbd_init...");      kbd_init();
    dbg("mouse_init...");    mouse_init();
    if (mouse_present())
        dbg("mouse: present");
    else
        dbg_err("mouse: not present");

    /* ---------- USB ---------- */
    /* Инициализируем UHCI-контроллеры и ищем HID-устройства.
     * Реальный опрос HID-отчётов требует полного QH-стека и прерываний —
     * здесь выполняется только детекция (события продолжают приходить
     * через PS/2-эмуляцию BIOS Legacy USB). */
    dbg("usb_init...");     usb_init();
    if (usb_controllers_found())
        dbg("usb: UHCI controller initialized");
    else
        dbg_err("usb: no UHCI controller (используется BIOS Legacy USB)");
    if (usb_devices_found() > 0) {
        char buf[80];
        snprintf(buf, sizeof(buf), "usb: %d device(s) detected", usb_devices_found());
        dbg(buf);
    }

    /* ---------- WiFi ---------- */
    dbg("wifi_init...");     wifi_init();
    if (wifi_present())
        dbg("wifi: adapter present");
    else
        dbg_err("wifi: no adapter found");

    /* ---------- Ethernet (пробуем E1000, VirtIO, NE2000) ---------- */
    dbg("e1000_init...");   e1000_init();
    if (!e1000_present()) {
        dbg("virtio_net_init...");
        virtio_net_init();
    }
    if (!e1000_present() && !virtio_net_present()) {
        dbg("ne2000_init...");
        ne2000_init();
    }

    if (e1000_present() || virtio_net_present() || ne2000_present()) {
        dbg("net_init...");
        net_init();
        /* IP, шлюз, маска (QEMU user-net) */
        net_set_ip(0x0A00020F);        /* 10.0.2.15 */
        net_set_gateway(0x0A000202);  /* 10.0.2.2  */
        net_set_netmask(0xFFFFFF00);  /* 255.255.255.0 */
        dbg("net: 10.0.2.15/24 gw 10.0.2.2");
    } else {
        dbg_err("net: no NIC found (E1000/VirtIO/NE2000)");
    }

    /* ---------- многозадачность ---------- */
    /* task_init() создаёт TCB[0] для главной задачи и регистрирует IRQ0
     * на наш планировщик. Должно идти ДО sti(), чтобы первый IRQ0 уже
     * нашёл готовую таблицу задач. */
    dbg("task_init...");     task_init();

    /* ---------- оконный менеджер ---------- */
    dbg("wm_init...");       wm_init();
    /* При загрузке открываем ТОЛЬКО терминал.
     * Остальные приложения доступны через меню «Меню». */
    dbg("apps_open(terminal)...");
    apps_open(2);   /* Терминал */

    /* ---------- прерывания ---------- */
    dbg("irq setup...");
    mouse_install_irq();
    pic_unmask((u16)((1 << 0) | (1 << 1) | (1 << 2) | (1 << 12)));
    sti();
    dbg("irq on, entering main loop");

    /* главный цикл: события -> композитинг -> hlt до следующего прерывания */
    key_event_t ev;
    u32 last_half = 0;
    for (;;) {
        while (kbd_pop(&ev))
            wm_key(&ev);

        wm_mouse_poll();
        usb_poll();        /* опрос HID (если что-то найдено) */
        wifi_poll();        /* опрос WiFi (сканирование) */
        net_poll();         /* опрос сети: приём и обработка Ethernet/ARP/IP/ICMP */

        u32 t = timer_ticks();
        if (t / 50 != last_half) {   /* 2 раза в секунду */
            last_half = t / 50;
            wm_halfsec();
            /* Ватчдог: kill задач, зависших > 5 секунд (500 тиков).
             * Главная задача (task[0]) не проверяется. */
            int killed = task_watchdog(500);
            if (killed > 0) {
                char buf[64];
                snprintf(buf, sizeof(buf), "[watchdog] killed %d hung task(s)", killed);
                serial_puts(buf);
            }
        }

        wm_frame();
        hlt();
    }
}