/* kernel.c — точка входа N2600-OS.
 *
 * Multiboot-заголовок (AOUT_KLUDGE + VIDEO_MODE) лежит в секции .text.mb —
 * в самом начале образа, поэтому GRUB находит его в первых 8 КиБ плоского
 * бинарника, собираемого MinGW. GRUB выставляет VESA-режим по полям
 * заголовка (1280x600x32 + запасные), включает защищённый режим и передаёт
 * управление на kstart.
 */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "gdt.h"
#include "idt.h"
#include "mem.h"
#include "timer.h"
#include "kbd.h"
#include "mouse.h"
#include "fb.h"
#include "wm.h"
#include "apps.h"
#include "string.h"
#include "kernel.h"

/* Символы linker-скрипта: в C пишутся без ведущего подчёркивания
 * (COFF MinGW добавит его автоматически, совпадая с именами в скрипте). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------- multiboot-заголовок --------------------- */

void kstart(void);

#define MB_FLAGS (MB_FLAG_ALIGN | MB_FLAG_MEMINFO | MB_FLAG_VIDEO_MODE | MB_FLAG_AOUT_KLUDGE)

/* При флаге VIDEO_MODE GRUB2 читает из заголовка ещё 4 поля (байты 32..47):
 * mode_type (0 = фреймбуфер), width, height, depth. Именно они задают
 * желаемый видеорежим: GRUB попробует 1280x600x32, потом запасные. */
__attribute__((section(".text.mb"), used, aligned(4)))
static const u32 mb_header[12] = {
    MB_MAGIC,
    MB_FLAGS,
    (u32)(0u - (MB_MAGIC + MB_FLAGS)),
    (u32)(unsigned long)load_start,   /* header_addr */
    (u32)(unsigned long)load_start,   /* load_addr   */
    (u32)(unsigned long)load_end,     /* load_end_addr */
    (u32)(unsigned long)bss_end,      /* bss_end_addr */
    (u32)(unsigned long)kstart,       /* entry_addr  */
    0,                                /* mode_type: 0 = линейный фреймбуфер */
    1280,                             /* ширина (целевой режим панели) */
    600,                              /* высота */
    32                                /* глубина цвета */
};

/* ------------------------- входная точка ------------------------- */

/* Единственная asm-вставка потока управления: настраиваем стек и зовём C.
 * naked обязателен — нельзя допустить пролог с обращением к стеку до его настройки. */
__attribute__((naked, section(".text.ks"), used, noinline))
void kstart(void)
{
    __asm__ __volatile__(
        "movl $_stack_top, %esp\n"
        "pushl %ebx\n"      /* multiboot info */
        "pushl %eax\n"      /* magic */
        "call _kmain\n"
        "1:\n"
        "hlt\n"
        "jmp 1b");
}

/* --------------------- аварийный вывод без графики --------------------- */

static void vga_fail(const char *msg)
{
    volatile u16 *vt = (volatile u16 *)0xB8000;
    const char *m1 = "N2600-OS: NET VESA-FRAMEBUFERA (NUZHEN REZHIM 32bpp).";
    const char *m2 = "Prover'te grub.cfg: gfxmode + gfxpayload=keep";
    for (int i = 0; m1[i]; i++) vt[i] = 0x4F00u | (u8)m1[i];
    for (int i = 0; m2[i]; i++) vt[80 + i] = 0x4F00u | (u8)m2[i];
    (void)msg;
    for (const char *p = m1; *p; p++) outb(0xE9, (u8)*p);
    for (;;)
        hlt();
}

/* --------------------------- служебное --------------------------- */

static const mb_info_t *g_mbi = NULL;

const mb_info_t *mb_info(void) { return g_mbi; }

void sys_reboot(void)
{
    cli();
    /* 8042: импульс на линию сброса */
    for (u32 i = 0; i < 100000 && (inb(0x64) & 0x02); i++) {}
    outb(0x64, 0xFE);
    for (;;)
        hlt(); /* если контроллер не сбросил — ничего не поделать */
}

void sys_poweroff(void)
{
    cli();
    /* QEMU/Bochs: ACPI PM1a control, S5 */
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;)
        hlt();
}

/* ------------------------------ kmain ------------------------------ */

void kmain(u32 magic, const mb_info_t *mb)
{
    g_mbi = mb;

    if (magic != MB_BOOTLOADER_MAGIC) {
        vga_fail("bad multiboot magic");
        return;
    }

    gdt_init();        /* своя плоская GDT (не полагаемся на GRUB) */
    idt_init();        /* IDT + PIC, все IRQ замаскированы */

    mem_init(mb);      /* куча из карты памяти Multiboot */
    timer_init(100);   /* PIT 100 Гц */
    kbd_init();        /* IRQ1 */
    mouse_init();      /* PS/2 мышь (IRQ12) — до включения прерываний */

    if (!fb_init(mb)) {
        vga_fail("no framebuffer");
        return;
    }
    fb_make_bg();

    wm_init();
    apps_open(2);      /* Системная информация */
    apps_open(1);      /* Терминал — открываем последним, он получает фокус */

    mouse_install_irq();
    pic_unmask((u16)((1 << 0) | (1 << 1) | (1 << 2) | (1 << 12))); /* PIT, KBD, cascade, mouse */
    sti();

    /* главный цикл: события -> композитинг -> hlt до следующего прерывания */
    key_event_t ev;
    u32 last_half = 0;
    for (;;) {
        while (kbd_pop(&ev))
            wm_key(&ev);

        wm_mouse_poll();

        u32 t = timer_ticks();
        if (t / 50 != last_half) {   /* 2 раза в секунду */
            last_half = t / 50;
            wm_halfsec();
        }

        wm_frame();
        hlt();
    }
}
