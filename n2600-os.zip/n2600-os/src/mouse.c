/* mouse.c — драйвер мыши PS/2 (IRQ12, потоковые 3-байтовые пакеты).
 * Работает и с обычной PS/2-мышью, и с тачпадом нетбука (Synaptics/ELAN
 * по умолчанию эмулируют стандартный относительный PS/2-протокол). */
#include "mouse.h"
#include "io.h"
#include "idt.h"
#include "fb.h"

volatile int ms_x = 0, ms_y = 0;
volatile u8  ms_buttons = 0;
volatile int ms_event = 0;

static int present = 0;
static u8 pkt[3];
static int pkt_i = 0;

#define WAIT_TRIES 200000

static int wait_write(void)
{
    for (int i = 0; i < WAIT_TRIES; i++)
        if (!(inb(0x64) & 0x02)) return 1;
    return 0;
}

static int wait_read(void)
{
    for (int i = 0; i < WAIT_TRIES; i++)
        if (inb(0x64) & 0x01) return 1;
    return 0;
}

/* команда устройству на AUX-порту; ждём ACK (0xFA), разрешаем одну повторку */
static int mouse_cmd(u8 cmd)
{
    for (int attempt = 0; attempt < 2; attempt++) {
        if (!wait_write()) return 0;
        outb(0x64, 0xD4);
        if (!wait_write()) return 0;
        outb(0x60, cmd);
        if (wait_read()) {
            u8 ack = inb(0x60);
            if (ack == 0xFA) return 1;
            if (ack == 0xFE) continue; /* надо повторить */
        }
    }
    return 0;
}

/* осушить выходной буфер контроллера (иначе под конфигом можно прочитать данные) */
static void drain_output(void)
{
    for (int i = 0; i < 64 && wait_read(); i++) (void)inb(0x60);
}

void mouse_init(void)
{
    pkt_i = 0;
    present = 0;

    drain_output();

    /* включаем AUX-порт */
    if (!wait_write()) return;
    outb(0x64, 0xA8);
    if (!wait_write()) return;

    /* читаем байт конфигурации: перед чтением обязаны осушить буфер,
       иначе под видом конфигурации прочитаем зависший байт данных */
    drain_output();
    if (!wait_write()) return;
    outb(0x64, 0x20);
    if (!wait_read()) return;
    u8 cfg = inb(0x60);
    cfg |= 0x02;      /* бит 1: разрешить IRQ12 */
    cfg &= (u8)~0x20; /* бит 5: включить тактирование мыши */
    /* бит 6 (трансляция сканкодов клавиатуры) НЕ трогаем */

    if (!wait_write()) return;
    outb(0x64, 0x60);
    if (!wait_write()) return;
    outb(0x60, cfg);

    /* defaults + включение передачи данных */
    if (!mouse_cmd(0xF6)) return;
    if (!mouse_cmd(0xF4)) return;

    /* финальная очистка буфера от случайных байтов */
    drain_output();

    present = 1;
}

int mouse_present(void) { return present; }

static void mouse_irq(void)
{
    if (!present) return;
    u8 b = inb(0x60);

    /* синхронизация: у первого байта всегда установлен бит 3 */
    if (pkt_i == 0 && !(b & 0x08)) return;

    pkt[pkt_i++] = b;
    if (pkt_i < 3) return;
    pkt_i = 0;

    /* переполнение не отбрасываем: значения всё равно полезны
       (реальные устройства почти никогда не выставляют эти биты) */

    int dx = (pkt[0] & 0x10) ? (int)pkt[1] - 256 : (int)pkt[1];
    int dy = (pkt[0] & 0x20) ? (int)pkt[2] - 256 : (int)pkt[2];

    int nx = ms_x + dx;
    int ny = ms_y - dy;             /* в PS/2 плюс по Y — вверх */

    if (nx < 0) nx = 0;
    if (ny < 0) ny = 0;
    if (nx > (int)fb_width() - 1) nx = (int)fb_width() - 1;
    if (ny > (int)fb_height() - 1) ny = (int)fb_height() - 1;

    ms_x = nx;
    ms_y = ny;
    ms_buttons = (u8)(pkt[0] & 0x07);
    ms_event = 1;
}

void mouse_install_irq(void)
{
    irq_install(12, mouse_irq);
}
