/* gdt.c — плоская GDT: нулевой дескриптор, код 0x08, данные 0x10 */
#include "gdt.h"
#include "io.h"
#include "types.h"

static u64 gdt[3];

static u64 make_entry(u32 base, u32 limit, u8 access, u8 flags)
{
    u64 r = 0;
    r |= (u64)(limit & 0xFFFF);
    r |= (u64)((base & 0xFFFFFF)) << 16;
    r |= (u64)access << 40;
    r |= (u64)((limit >> 16) & 0x0F) << 48;
    r |= (u64)(flags & 0x0F) << 52;
    r |= (u64)((base >> 24) & 0xFF) << 56;
    return r;
}

void gdt_init(void)
{
    gdt[0] = 0;
    /* 0x9A: present|ring0|code|readable; 0xCF: 4K granularity, 32-bit */
    gdt[1] = make_entry(0, 0xFFFFF, 0x9A, 0x0C);
    /* 0x92: present|ring0|data|writable */
    gdt[2] = make_entry(0, 0xFFFFF, 0x92, 0x0C);

    struct dt_ptr p;
    p.limit = (u16)(sizeof(gdt) - 1);
    p.base = (u32)(unsigned long)gdt;
    lgdt_load(&p);
}
