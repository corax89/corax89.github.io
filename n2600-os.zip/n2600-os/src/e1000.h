/* e1000.h — драйвер Intel 82540EM (E1000) для N2600-OS.
 *
 * Поддержка:
 *   - PCI-детекция Intel 82540EM (vendor=0x8086, device=0x100E)
 *     также работает 82540EP, 82541PI, 82543GC, 82544GC, 82545EM,
 *     82546PCI, 82547EI, I210 (QEMU emulates 82540EM, VMware emulates 82540EM или 82545EM)
 *   - MMIO доступ к регистрам
 *   - EEPROM read (для MAC)
 *   - Приём и передача через descriptor rings (legacy mode)
 *   - Interrupt masking + polling
 *   - Получение собственного MAC адреса
 *
 * Не поддерживается:
 *   - VLAN, TSO, jumbo frames
 *   - Прерывания (используется polling)
 *   - Multicast фильтрация
 *
 * Драйвер совместим с VMware (где по умолчанию эмулируется 82540EM)
 * и QEMU (где -device e1000 эмулирует 82540EM).
 */
#ifndef E1000_H
#define E1000_H

#include "types.h"

#define E1000_PKT_MAX 1518

/* Инициализация: сканирование PCI, reset, EEPROM, настройка RX/TX колец.
 * Возвращает 1 при успехе, 0 при отсутствии адаптера. */
int  e1000_init(void);

/* Адаптер найден и инициализирован? */
int  e1000_present(void);

/* Имя чипа (для диагностики). */
const char *e1000_chip_name(void);

/* MAC-адрес (6 байт). Возвращает 0 если не инициализирован. */
int  e1000_get_mac(u8 out_mac[6]);

/* Установить MAC-адрес фильтр (для приёма пакетов, адресованных нам).
 * По умолчанию фильтр宽松 - принимает все unicast + broadcast. */
void e1000_set_dest_mac(const u8 mac[6]);

/* Отправить raw Ethernet-кадр (len байт, включая заголовки).
 * Возвращает число отправленных байт или -1 при ошибке. */
int  e1000_send(const void *buf, u32 len);

/* Опросить RX-кольцо. Если есть пакет, копирует до *out_len байт в out_buf.
 * Возвращает длину пакета (1..E1000_PKT_MAX) или 0 если пакетов нет. */
u32  e1000_recv(void *out_buf, u32 out_max);

/* Polling: вызывается из главного цикла для обработки возможных IRQ. */
void e1000_poll(void);

#endif /* E1000_H */
