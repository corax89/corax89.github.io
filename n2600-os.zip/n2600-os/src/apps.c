/* apps.c — реестр приложений + «О программе», «Терминал», «Системная информация» */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "timer.h"
#include "string.h"
#include "mouse.h"
#include "kernel.h"
#include "ramfs.h"
#include "task.h"
#include "loader.h"
#include "usb.h"
#include "usb_ehci.h"
#include "e1000.h"
#include "net.h"
#include "timer.h"
#include "c4.h"
#include "pci.h"
#include "ath9k_wifi.h"
#include "pci_ids.h"
#include <cpuid.h>   /* GCC/MinGW: встроенные обёртки над инструкцией CPUID */

/* ------------------------------ реестр ------------------------------ */
const app_def_t app_table[] = {
    { "О программе",            app_about_open   },
    { "Файлы",                  app_files_open   },
    { "Терминал",               app_term_open    },
    { "Редактор C",             app_editor_open  },
    { "CMScript",               app_cmscript_open },
    { "Диспетчер задач",        app_taskmgr_open },
    { "WiFi Scanner",           app_wifi_open     },
    { "Браузер",                app_browser_open  },
    { "Системная информация",   app_sysinfo_open },
    { "Пример приложения",      app_example_open },
};
const int app_table_count = (int)(sizeof(app_table) / sizeof(app_table[0]));

void apps_open(int idx)
{
    if (idx >= 0 && idx < app_table_count) app_table[idx].open_fn();
}

/* Запустить приложение по имени */
int app_spawn_by_name(const char *name)
{
    if (!name || !*name) return 0;
    for (int i = 0; i < app_table_count; i++) {
        if (strcmp(app_table[i].name, name) == 0) {
            app_table[i].open_fn();
            return 1;
        }
    }
    /* Пробуем по английским именам */
    if (!strcmp(name, "terminal") || !strcmp(name, "term")) {
        app_term_open(); return 1;
    }
    if (!strcmp(name, "files") || !strcmp(name, "fileman")) {
        app_files_open(); return 1;
    }
    if (!strcmp(name, "editor")) {
        app_editor_open(); return 1;
    }
    if (!strcmp(name, "browser")) {
        app_browser_open(); return 1;
    }
    if (!strcmp(name, "sysinfo")) {
        app_sysinfo_open(); return 1;
    }
    if (!strcmp(name, "taskmgr")) {
        app_taskmgr_open(); return 1;
    }
    return 0;
}

/* --------------------------- CPU (CPUID) --------------------------- */
void cpu_get_vendor(char out[16])
{
    unsigned a, b, c, d;
    if (!__get_cpuid(0, &a, &b, &c, &d)) { strcpy(out, "-"); return; }
    memcpy(out, &b, 4);
    memcpy(out + 4, &d, 4);
    memcpy(out + 8, &c, 4);
    out[12] = 0;
}

void cpu_get_brand(char out[52])
{
    unsigned a, b, c, d;
    char *p = out;
    unsigned max_ext = 0;
    if (__get_cpuid(0x80000000,  &a,  &b,  &c,  &d)) max_ext = a;
    if (max_ext  >= 0x80000004) {
        for (unsigned leaf = 0x80000002; leaf  <= 0x80000004; leaf++) {
            __get_cpuid(leaf,  &a,  &b,  &c,  &d);
            memcpy(p,  &a, 4); memcpy(p + 4,  &b, 4);
            memcpy(p + 8,  &c, 4); memcpy(p + 12,  &d, 4);
            p += 16;
        }
        *p = 0;
        /*  обрезаем ведущие пробелы */
        char *s = out;
        while (*s == ' ') s++;
        if (s != out) memmove(out, s, strlen(s) + 1);
        return;
    }
    strcpy(out,  "неизвестный процессор ");
}

int cpu_get_cores(void)
{
    unsigned a, b, c, d;
    if (__get_cpuid(1, &a, &b, &c, &d)) return (int)((b >> 16) & 0xFF);
    return 1;
}

/* ============================== О ПРОГРАММЕ ============================== */
typedef struct {
    char cpu[52];
} about_data_t;

static void about_draw(window_t *w)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)cw; (void)ch;
    fb_fill_rect(0, 0, win_content_w(w), win_content_h(w), fb_rgb(0x12, 0x15, 0x1A));
    fb_fill_rect(0, 0, win_content_w(w), 3, fb_rgb(0x3E, 0x7D, 0xBF));

    const char *name = "N2600-OS";
    int nx = (win_content_w(w) - (int)strlen(name) * 16) / 2;
    u32 c = fb_rgb(0x6F, 0xB3, 0xF2);
    for (const char *p = name; *p; p++, nx += 16)
        fb_char2x(nx, 18, (unsigned char)*p, c);

    fb_text(16, 64, "Простая оконная ОС на чистом C", fb_rgb(0xC6, 0xCD, 0xD5), -1);
    fb_text(16, 84, "Сборка: MinGW (i686), multiboot + GRUB", fb_rgb(0x9A, 0xA3, 0xAC), -1);
    fb_text(16, 104, "Цель: Intel Atom N2600, VESA 1280x600x32", fb_rgb(0x9A, 0xA3, 0xAC), -1);

    about_data_t *d = (about_data_t *)w->data;
    char line[64];
    snprintf(line, sizeof(line), "CPU: %s", d->cpu);
    fb_text(16, 132, line, fb_rgb(0x9A, 0xA3, 0xAC), -1);

    fb_text(16, win_content_h(w) - 24, "Лицензия: MIT, 2026", fb_rgb(0x50, 0x58, 0x62), -1);
}

void app_about_open(void)
{
    about_data_t *d = (about_data_t *)malloc(sizeof(about_data_t));
    if (!d) return;
    cpu_get_brand(d->cpu);
    u32 W = fb_width();
    int ww = 360, wh = 200;
    win_create("О программе", (int)W - ww - 40, 40, ww, wh,
               about_draw, NULL, NULL, NULL, NULL, d);
}

/* =============================== ТЕРМИНАЛ =============================== */
#define TERM_COLS 62
#define TERM_ROWS 17
/* Scrollback: храним историю вывода выше видимой области.
 * TERM_SCROLL_LINES — кольцевой буфер, TERMINAL_SCROLL_BACK строк в прошлом. */
#define TERM_SCROLL_LINES 512

typedef struct {
    char lines[TERM_SCROLL_LINES][TERM_COLS + 1];
    int  nlines;                 /* всего строк в scrollback (включая input) */
    int  top;                    /* индекс верхней видимой строки в scrollback */
    char input[TERM_COLS + 1];
    int  ilen;
    int  scrollback;              /* сколько строк прокручено от конца (0 = хвост) */
} term_t;

static u32 term_bg, term_fg, term_prompt;

/* ---------- Состояние ping (глобальное, т.к. callback статический) ---------- */
typedef struct {
    u32  target_ip;        /* целевой IP (host order) */
    u32  start_tick;       /* время отправки эха */
    u16  seq;              /* ожидаемый seq */
    u16  next_seq;         /* следующий seq для отправки */
    u32  sent;             /* отправлено */
    u32  recv;             /* принято */
    u32  timeout_ms;        /* таймаут ожидания ответа */
    u32  last_send_tick;   /* время последней отправки */
    int  active;           /* 1 = идёт сессия ping */
    int  max_count;        /* ограничение числа пакетов (0 = бесконечно до Ctrl+C) */
    term_t *term;          /* терминал для вывода */
    window_t *win;         /* окно терминала */
    /* Запись о последнем эхо-ответе для отображения в term_tick */
    int   have_reply;       /* 1 = есть ответ */
    u32   reply_rtt_ms;     /* RTT последнего ответа */
    u16   reply_seq;        /* seq последнего ответа */
} ping_state_t;
static ping_state_t g_ping;

/* ---------- ICMP callback для приёма echo reply ---------- */
static void ping_icmp_cb(u32 src_ip, u16 id, u16 seq,
                          const void *payload, u32 payload_len)
{
    (void)id; (void)payload; (void)payload_len;
    if (!g_ping.active) return;
    if (src_ip != g_ping.target_ip) return;
    u32 now = timer_ticks();
    u32 rtt = (now - g_ping.last_send_tick) * 10u;  /* 1 tick = 10 ms */
    g_ping.reply_rtt_ms = rtt;
    g_ping.reply_seq = seq;
    g_ping.have_reply = 1;
    g_ping.recv++;
}

/* ---------- Неблокирующее ожидание ----------
 * Ждёт max_ms миллисекунд, при этом обрабатывает сетевые пакеты
 * (net_poll), события клавиатуры (kbd_pop/wm_key) и события мыши.
 * Это предотвращает зависание системы во время ожидания ответов. */
static void net_wait_poll(u32 max_ms)
{
    u32 start = timer_ticks();
    u32 need = max_ms / 10;  /* 1 tick = 10ms */
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        net_poll();
        /* Обработка клавиатуры — чтобы система не зависала */
        key_event_t ev;
        while (kbd_pop(&ev)) {
            wm_key(&ev);
        }
        wm_mouse_poll();
        task_yield();
    }
}

static void term_print(term_t *t, const char *s)
{
    /* печатаем текст с переносом по ширине окна */
    while (*s) {
        int room = TERM_COLS - 1;
        const char *nl = NULL;
        for (const char *p = s; *p && p < s + room; p++)
            if (*p == '\n') { nl = p; break; }

        u32 slen = strlen(s);
        u32 seg_len = nl ? (u32)(nl - s)
                         : (slen > (u32)room ? (u32)room : slen);

        if (t->nlines >= TERM_SCROLL_LINES) {
            /* Сдвигаем кольцевой буфер: выкидываем первую строку */
            memmove(t->lines[0], t->lines[1], sizeof(t->lines[0]) * (TERM_SCROLL_LINES - 1));
            t->nlines--;
        }
        memcpy(t->lines[t->nlines], s, seg_len);
        t->lines[t->nlines][seg_len] = 0;
        t->nlines++;
        s += seg_len;
        if (nl) s++; /* пропускаем \n */
    }
    /* Если мы были прокручены наверх — при новой выводе остаёмся там.
     * Чтобы пользователь видел новые сообщения, сбросим scrollback в хвост. */
    t->scrollback = 0;
}

static void term_touch(window_t *w) { win_invalidate(w); }

static void term_puts(window_t *w, term_t *t, const char *s)
{
    term_print(t, s);
    term_touch(w);
}

static void term_exec(window_t *w, term_t *t)
{
    char cmd[TERM_COLS + 1];
    strcpy(cmd, t->input);
    t->input[0] = 0;
    t->ilen = 0;

    char *c = cmd;
    while (*c == ' ') c++;
    if (!*c) return;

    if (!strcmp(c, "help")) {
        term_puts(w, t, "Команды:");
        term_puts(w, t, "  help    - этот список");
        term_puts(w, t, "  about   - о системе");
        term_puts(w, t, "  sysinfo - краткие сведения о железе");
        term_puts(w, t, "  mem     - память (RAM и куча)");
        term_puts(w, t, "  uptime  - время работы");
        term_puts(w, t, "  apps    - открытые окна");
        term_puts(w, t, "  echo <текст>");
        term_puts(w, t, "  clear   - очистить экран");
        term_puts(w, t, "  reboot  - перезагрузка");
        term_puts(w, t, "  poweroff- выключение (QEMU)");
        term_puts(w, t, "  --- ПРОКРУТКА ---");
        term_puts(w, t, "  PgUp/PgDn, ↑/↓, Home/End");
        term_puts(w, t, "  --- RAMFS ---");
        term_puts(w, t, "  ramls    - список файлов в RAM");
        term_puts(w, t, "  ramwrite <имя> <текст> - создать файл в RAM");
        term_puts(w, t, "  ramread <имя> - прочитать файл из RAM");
        term_puts(w, t, "  ramdel <имя> - удалить файл из RAM");
        term_puts(w, t, "  raminfo  - информация о RAM disk");
        term_puts(w, t, "  --- МУЛЬТИЗАДАЧНОСТЬ ---");
        term_puts(w, t, "  tasks   - список задач");
        term_puts(w, t, "  --- USB ---");
        term_puts(w, t, "  usbinfo - инфо о USB-контроллерах и флешке");
        term_puts(w, t, "  usbread <сектор> - прочитать сектор 512 байт с флешки");
        term_puts(w, t, "  --- СЕТЬ ---");
        term_puts(w, t, "  ipconfig - IP/MAC/шлюз/маска NIC + ARP cache");
        term_puts(w, t, "  ipset <a.b.c.d> - установить IP");
        term_puts(w, t, "  ping <a.b.c.d|host> [N] - ICMP-эхо (или по имени)");
        term_puts(w, t, "  arping <a.b.c.d> - один ARP-запрос");
        term_puts(w, t, "  udp <ip> <port> <text> - отправить UDP");
        term_puts(w, t, "  tcping <ip> <port> - попытка TCP-соединения");
        term_puts(w, t, "  tcpclose <idx> - закрыть TCP-сокет");
        term_puts(w, t, "  dhcp - получить IP через DHCP");
        term_puts(w, t, "  dns <hostname> - разрешить имя в IP");
        term_puts(w, t, "  http <host> [path] - HTTP GET запрос");
        term_puts(w, t, "  --- ОБОРУДОВАНИЕ ---");
        term_puts(w, t, "  lspci - список всех PCI-устройств");
        term_puts(w, t, "  --- ЗАПУСК ПРИЛОЖЕНИЙ ---");
        term_puts(w, t, "  spawn <имя> - открыть приложение (terminal/files/editor/browser)");
        term_puts(w, t, "  curl <url>  - HTTP GET запрос");
        term_puts(w, t, "  c4test    - тест c4 (массивы, for, #define, printf)");
        term_puts(w, t, "  cc <имя.c>  - скомпилировать .c в .bin (native)");
        term_puts(w, t, "  run <имя>   - запустить .bin с RAM-диска");
    } else if (!strcmp(c, "about")) {
        term_puts(w, t, "N2600-OS 0.1 - оконная ОС на чистом C.");
        term_puts(w, t, "Ядро собирается MinGW, грузится GRUB'ом в VESA LFB.");
    } else if (!strcmp(c, "sysinfo")) {
        char brand[52], line[96];
        cpu_get_brand(brand);
        snprintf(line, sizeof(line), "CPU: %s", brand);
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "Ядер (логических): %d", cpu_get_cores());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "RAM: %u МиБ, экран: %ux%ux32",
                 (unsigned)mem_ram_mib(), (unsigned)fb_width(), (unsigned)fb_height());
        term_puts(w, t, line);
    } else if (!strcmp(c, "mem")) {
        char line[96];
        snprintf(line, sizeof(line), "RAM всего: %u МиБ", (unsigned)mem_ram_mib());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "Куча: занято %u КиБ из %u КиБ",
                 (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
        term_puts(w, t, line);
    } else if (!strcmp(c, "uptime")) {
        u32 up = uptime_sec();
        char line[64];
        snprintf(line, sizeof(line), "Время работы: %02u:%02u:%02u",
                 up / 3600, (up / 60) % 60, up % 60);
        term_puts(w, t, line);
    } else if (!strcmp(c, "apps")) {
        char line[80];
        int n = wm_window_count();
        snprintf(line, sizeof(line), "Открыто окон: %d", n);
        term_puts(w, t, line);
        for (int i = 0; i < n; i++) {
            snprintf(line, sizeof(line), "  [%d] %s", i, wm_window_title(i));
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "echo ", 5)) {
        term_puts(w, t, c + 5);
    } else if (!strcmp(c, "echo")) {
        term_puts(w, t, "");
    } else if (!strcmp(c, "clear")) {
        t->nlines = 0;
        term_touch(w);
    } else if (!strcmp(c, "reboot")) {
        sys_reboot();
    } else if (!strcmp(c, "poweroff")) {
        sys_poweroff();
    } else if (!strcmp(c, "ramls")) {
        ramfs_dirent_t files[32];
        int n = ramfs_list(files, 32);
        if (n == 0) {
            term_puts(w, t, "RAM disk пуст");
        } else {
            char line[128];
            snprintf(line, sizeof(line), "Файлов в RAM: %d", n);
            term_puts(w, t, line);
            for (int i = 0; i < n; i++) {
                snprintf(line, sizeof(line), "  %s (%u байт)", files[i].name, files[i].size);
                term_puts(w, t, line);
            }
        }
    } else if (!strncmp(c, "ramwrite ", 9)) {
        char *name = c + 9;
        char *space = strchr(name, ' ');
        if (!space) {
            term_puts(w, t, "Использование: ramwrite <имя> <текст>");
        } else {
            *space = 0;
            char *text = space + 1;
            u32 len = strlen(text) + 1;
            if (ramfs_create(name, len) && ramfs_write(name, text, len)) {
                char line[128];
                snprintf(line, sizeof(line), "Создан файл '%s' (%u байт)", name, len);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "Ошибка создания файла");
            }
        }
    } else if (!strncmp(c, "ramread ", 8)) {
        char *name = c + 8;
        char buf[256];
        u32 n = ramfs_read(name, buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = 0;
            char line[320];
            snprintf(line, sizeof(line), "Содержимое '%s': %s", name, buf);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Файл не найден");
        }
    } else if (!strncmp(c, "ramdel ", 7)) {
        char *name = c + 7;
        if (ramfs_delete(name)) {
            char line[128];
            snprintf(line, sizeof(line), "Файл '%s' удален", name);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Файл не найден");
        }
    } else if (!strcmp(c, "raminfo")) {
        char line[128];
        snprintf(line, sizeof(line), "RAM disk: %u МиБ всего, %u КиБ свободно",
                 (unsigned)(ramfs_total_space() / (1024 * 1024)),
                 (unsigned)(ramfs_free_space() / 1024));
        term_puts(w, t, line);
    } else if (!strcmp(c, "tasks")) {
        int n = task_count();
        char line[80];
        snprintf(line, sizeof(line), "Активных задач: %d (текущая = %d)",
                 n, task_current());
        term_puts(w, t, line);
        for (int i = 0; i < MAX_TASKS; i++) {
            if (task_name(i)[0]) {
                snprintf(line, sizeof(line), "  [%d] %s", i, task_name(i));
                term_puts(w, t, line);
            }
        }
    } else if (!strncmp(c, "run ", 4)) {
        char *name = c + 4;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: run <имя.bin>");
        } else {
            int tid = loader_spawn(name, NULL);
            if (tid < 0) {
                term_puts(w, t, "Не удалось запустить (файл не найден?)");
            } else {
                char line[80];
                snprintf(line, sizeof(line),
                         "Запущена задача %d: %s", tid, name);
                term_puts(w, t, line);
            }
        }
    } else if (!strcmp(c, "usbinfo")) {
        char line[120];
        snprintf(line, sizeof(line), "UHCI: %s",
                 usb_controllers_found() ? "detected" : "not present");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "EHCI: %s",
                 usb_ehci_present() ? "detected" : "not present");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB devices: %d", usb_devices_found());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB keyboard: %s",
                 usb_keyboard_present() ? "yes" : "no");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB mouse: %s",
                 usb_mouse_present() ? "yes" : "no");
        term_puts(w, t, line);
        if (usb_ehci_storage_ready()) {
            term_puts(w, t, "USB flash drive: READY");
        } else {
            term_puts(w, t, "USB flash drive: not detected");
        }
    } else if (!strncmp(c, "usbread ", 8)) {
        char *p = c + 8;
        while (*p == ' ') p++;
        u32 sector = 0;
        while (*p >= '0' && *p <= '9') {
            sector = sector * 10 + (u32)(*p - '0');
            p++;
        }
        if (!usb_ehci_storage_ready()) {
            term_puts(w, t, "USB flash drive: not detected");
        } else {
            u8 buf[512];
            if (usb_ehci_read_sector(sector, buf)) {
                char line[128];
                /* Дамп первых 32 байт сектора */
                char hex[160];
                int pos = 0;
                for (int k = 0; k < 32 && pos < 140; k++) {
                    pos += snprintf(hex + pos, sizeof(hex) - pos, "%02x ", buf[k]);
                }
                snprintf(line, sizeof(line),
                         "Sector %u: %s", (unsigned)sector, hex);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "Read failed");
            }
        }
    } else if (!strcmp(c, "ipconfig")) {
        if (!net_nic_present()) {
            term_puts(w, t, "NIC: не найден");
        } else {
            char line[96];
            u8 mac[6];
            net_get_mac(mac);
            snprintf(line, sizeof(line),
                     "NIC: %s  MAC: %02x:%02x:%02x:%02x:%02x:%02x",
                     net_nic_name(),
                     mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
            term_puts(w, t, line);
            char ipbuf[16];
            u32 ip = net_get_ip();
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "IP: %s", ipbuf);
            term_puts(w, t, line);
            net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Маска: %s", ipbuf);
            term_puts(w, t, line);
            net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Шлюз: %s", ipbuf);
            term_puts(w, t, line);
            snprintf(line, sizeof(line), "TX пакетов: %u, RX пакетов: %u",
                     (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
            term_puts(w, t, line);
            /* ARP cache dump */
            net_arp_entry_t entries[NET_ARP_CACHE_SIZE];
            int n = net_arp_dump(entries, NET_ARP_CACHE_SIZE);
            if (n > 0) {
                term_puts(w, t, "--- ARP cache ---");
                for (int i = 0; i < n; i++) {
                    char ipbuf2[16];
                    net_ntoa(entries[i].ip, ipbuf2, sizeof(ipbuf2));
                    snprintf(line, sizeof(line), "  %s  %02x:%02x:%02x:%02x:%02x:%02x",
                             ipbuf2,
                             entries[i].mac[0], entries[i].mac[1],
                             entries[i].mac[2], entries[i].mac[3],
                             entries[i].mac[4], entries[i].mac[5]);
                    term_puts(w, t, line);
                }
            }
        }
    } else if (!strncmp(c, "ipset ", 6)) {
        char *p = c + 6;
        while (*p == ' ') p++;
        u32 ip = 0;
        if (!net_aton(p, &ip)) {
            term_puts(w, t, "Неверный IP. Пример: ipset 10.0.2.15");
        } else {
            net_set_ip(ip);
            char line[48];
            char buf[16];
            net_ntoa(ip, buf, sizeof(buf));
            snprintf(line, sizeof(line), "IP установлен: %s", buf);
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "arping ", 7)) {
        char *p = c + 7;
        while (*p == ' ') p++;
        u32 ip = 0;
        if (!net_aton(p, &ip)) {
            term_puts(w, t, "Неверный IP");
        } else if (!net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else if (net_get_ip() == 0) {
            term_puts(w, t, "IP не настроен (см. ipset)");
        } else {
            char buf[16];
            net_ntoa(ip, buf, sizeof(buf));
            char line[64];
            snprintf(line, sizeof(line), "ARP who-has %s tell ", buf);
            net_ntoa(net_get_ip(), buf, sizeof(buf));
            /* Допишем к строке */
            char line2[80];
            snprintf(line2, sizeof(line2), "%s%s", line, buf);
            term_puts(w, t, line2);
            net_send_arp_request(ip);
            net_wait_poll(200);
            term_puts(w, t, "ARP запрос отправлен");
        }
    } else if (!strncmp(c, "ping ", 5)) {
        char *p = c + 5;
        while (*p == ' ') p++;
        /* парсим IP */
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) {
            ipstr[i++] = *p++;
        }
        ipstr[i] = 0;
        while (*p == ' ') p++;
        /* опциональное N (число пакетов) */
        int n = 4;
        if (*p >= '0' && *p <= '9') {
            n = 0;
            while (*p >= '0' && *p <= '9') {
                n = n * 10 + (*p - '0');
                p++;
            }
            if (n < 1) n = 1;
            if (n > 100) n = 100;
        }
        u32 target = 0;
        if (!net_aton(ipstr, &target)) {
            /* Пробуем DNS */
            if (net_dns_server() == 0) {
                term_puts(w, t, "Неверный IP. DNS не настроен.");
                return;
            }
            term_puts(w, t, "Разрешение имени...");
            if (!net_dns_resolve(ipstr, &target, 5000)) {
                term_puts(w, t, "DNS: имя не разрешено");
                return;
            }
            char ipbuf[16];
            net_ntoa(target, ipbuf, sizeof(ipbuf));
            char line2[80];
            snprintf(line2, sizeof(line2), "%s → %s", ipstr, ipbuf);
            term_puts(w, t, line2);
        }
        if (!net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else if (net_get_ip() == 0) {
            term_puts(w, t, "IP не настроен (см. ipset)");
        } else {
            /* Инициализируем сессию ping */
            memset(&g_ping, 0, sizeof(g_ping));
            g_ping.target_ip = target;
            g_ping.timeout_ms = 1000;
            g_ping.max_count = n;
            g_ping.term = t;
            g_ping.win = w;
            g_ping.active = 1;
            g_ping.next_seq = 1;
            net_set_icmp_callback(ping_icmp_cb);   /* приём echo reply */
            char ipbuf[16];
            net_ntoa(target, ipbuf, sizeof(ipbuf));
            char line[80];
            snprintf(line, sizeof(line), "PING %s: %d пакет(ов), 32 байт",
                     ipbuf, n);
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "udp ", 4)) {
        /* udp <ip> <port> <text> — отправить UDP-сообщение */
        char *p = c + 4;
        while (*p == ' ') p++;
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) ipstr[i++] = *p++;
        ipstr[i] = 0;
        while (*p == ' ') p++;
        u32 port = 0;
        while (*p >= '0' && *p <= '9') { port = port * 10 + (u32)(*p - '0'); p++; }
        while (*p == ' ') p++;
        const char *text = p;
        if (!*text) {
            term_puts(w, t, "Использование: udp <ip> <port> <текст>");
        } else {
            u32 dst_ip = 0;
            if (!net_aton(ipstr, &dst_ip)) {
                term_puts(w, t, "Неверный IP");
            } else if (!net_nic_present() || net_get_ip() == 0) {
                term_puts(w, t, "Сеть не настроена (см. ipset)");
            } else {
                int sock = net_udp_open(30000);
                if (sock < 0) {
                    term_puts(w, t, "Не удалось открыть UDP-сокет");
                } else {
                    int n = net_udp_send(sock, dst_ip, (u16)port,
                                          text, (u32)strlen(text));
                    if (n < 0) {
                        term_puts(w, t, "UDP send failed");
                    } else {
                        char line[80];
                        char ipbuf[16];
                        net_ntoa(dst_ip, ipbuf, sizeof(ipbuf));
                        snprintf(line, sizeof(line),
                                 "UDP отправлено: %s:%u (%d байт)",
                                 ipbuf, (unsigned)port, n);
                        term_puts(w, t, line);
                    }
                    /* Подождём возможного ответа (неблокирующее ожидание) */
                    net_wait_poll(300);
                    net_udp_close(sock);
                }
            }
        }
    } else if (!strncmp(c, "tcping ", 7)) {
        /* tcping <ip> <port> — попытка TCP-соединения */
        char *p = c + 7;
        while (*p == ' ') p++;
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) ipstr[i++] = *p++;
        ipstr[i] = 0;
        while (*p == ' ') p++;
        u32 port = 0;
        while (*p >= '0' && *p <= '9') { port = port * 10 + (u32)(*p - '0'); p++; }
        u32 dst_ip = 0;
        if (!net_aton(ipstr, &dst_ip)) {
            term_puts(w, t, "Неверный IP");
        } else if (!net_nic_present() || net_get_ip() == 0) {
            term_puts(w, t, "Сеть не настроена (см. ipset)");
        } else if (port == 0) {
            term_puts(w, t, "Использование: tcping <ip> <port>");
        } else {
            int sock = net_tcp_connect(dst_ip, (u16)port, 40000);
            if (sock < 0) {
                term_puts(w, t, "Нет свободных TCP-сокетов");
            } else {
                char line[96];
                char ipbuf[16];
                net_ntoa(dst_ip, ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line),
                         "TCP connect to %s:%u (sock=%d), ждём...",
                         ipbuf, (unsigned)port, sock);
                term_puts(w, t, line);
                /* Подождём ~3 секунды (неблокирующее ожидание) */
                {
                    u32 t0 = timer_ticks();
                    while ((timer_ticks() - t0) < 300) {
                        net_wait_poll(10);
                        if (net_tcp_state(sock) == TCP_ESTABLISHED) break;
                        if (net_tcp_state(sock) == TCP_CLOSED) break;
                    }
                }
                tcp_state_t st = net_tcp_state(sock);
                snprintf(line, sizeof(line),
                         "Состояние: %s", tcp_state_name(st));
                term_puts(w, t, line);
                if (st == TCP_ESTABLISHED) {
                    net_tcp_send(sock, "hello\n", 6);
                    term_puts(w, t, "Отправлено: hello (6 байт)");
                }
                /* Закрываем если ещё установлен */
                if (net_tcp_state(sock) != TCP_CLOSED) {
                    net_tcp_close(sock);
                }
            }
        }
    } else if (!strncmp(c, "tcpclose ", 9)) {
        char *p = c + 9;
        while (*p == ' ') p++;
        int sock = 0;
        while (*p >= '0' && *p <= '9') { sock = sock * 10 + (*p - '0'); p++; }
        if (sock < 0 || sock >= 8) {
            term_puts(w, t, "Неверный индекс сокета");
        } else {
            net_tcp_close(sock);
            char line[64];
            snprintf(line, sizeof(line), "TCP sock %d закрыт", sock);
            term_puts(w, t, line);
        }
    } else if (!strcmp(c, "dhcp")) {
        if (!net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else {
            term_puts(w, t, "DHCP: DISCOVER → OFFER → REQUEST → ACK...");
            int r = net_dhcp_acquire(10000);
            if (r) {
                term_puts(w, t, "DHCP: успех! Параметры:");
                char line[80];
                char ipbuf[16];
                net_ntoa(net_get_ip(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  IP: %s", ipbuf);
                term_puts(w, t, line);
                net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  Маска: %s", ipbuf);
                term_puts(w, t, line);
                net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  Шлюз: %s", ipbuf);
                term_puts(w, t, line);
                u32 dns = net_dns_server();
                if (dns) {
                    net_ntoa(dns, ipbuf, sizeof(ipbuf));
                    snprintf(line, sizeof(line), "  DNS: %s", ipbuf);
                    term_puts(w, t, line);
                }
            } else {
                term_puts(w, t, "DHCP: нет ответа (таймаут)");
            }
        }
    } else if (!strncmp(c, "dns ", 4)) {
        char *hostname = c + 4;
        while (*hostname == ' ') hostname++;
        if (!*hostname) {
            term_puts(w, t, "Использование: dns <hostname>");
        } else if (net_dns_server() == 0) {
            term_puts(w, t, "DNS-сервер не настроен (см. dhcp или ipset)");
        } else {
            u32 ip = 0;
            term_puts(w, t, "DNS: запрос...");
            if (net_dns_resolve(hostname, &ip, 5000)) {
                char line[80];
                char ipbuf[16];
                net_ntoa(ip, ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "%s → %s", hostname, ipbuf);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "DNS: не удалось разрешить имя");
            }
        }
    } else if (!strncmp(c, "http ", 5)) {
        char *p = c + 5;
        while (*p == ' ') p++;
        char host[128];
        int i = 0;
        while (*p && *p != ' ' && i < 127) host[i++] = *p++;
        host[i] = 0;
        while (*p == ' ') p++;
        const char *path = "/";
        if (*p) path = p;
        if (!*host) {
            term_puts(w, t, "Использование: http <host> [path]");
        } else if (!net_nic_present() || net_get_ip() == 0) {
            term_puts(w, t, "Сеть не настроена (см. dhcp или ipset)");
        } else {
            static char resp[4096];
            term_puts(w, t, "HTTP GET запрос...");
            int n = net_http_get(host, 80, path, resp, sizeof(resp), 10000);
            if (n > 0) {
                char line[80];
                snprintf(line, sizeof(line), "Получено %d байт:", n);
                term_puts(w, t, line);
                /* Вывести первые ~10 строк ответа */
                int shown = 0;
                char *start = resp;
                while (shown < 10 && start < resp + n) {
                    char *nl = start;
                    while (nl < resp + n && *nl != '\n') nl++;
                    int L = nl - start;
                    if (L > TERM_COLS - 1) L = TERM_COLS - 1;
                    char buf[TERM_COLS + 1];
                    memcpy(buf, start, L);
                    buf[L] = 0;
                    term_puts(w, t, buf);
                    start = (nl < resp + n) ? nl + 1 : nl;
                    shown++;
                }
            } else {
                term_puts(w, t, "HTTP: ошибка (нет ответа/таймаут)");
            }
        }
    } else if (!strcmp(c, "lspci")) {
        /* Вывести все PCI-устройства с человекочитаемыми именами */
        term_puts(w, t, "=== PCI Devices ===");
        int found = 0;
        for (int bus = 0; bus < 256; bus++) {
            for (int dev = 0; dev < 32; dev++) {
                u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                int max_func = (hdr & 0x80) ? 8 : 1;
                for (int func = 0; func < max_func; func++) {
                    u32 id = pci_read32(bus, dev, func, 0);
                    u16 vendor = (u16)(id & 0xFFFF);
                    u16 device = (u16)(id >> 16);
                    if (vendor == 0xFFFF) continue;
                    found++;
                    u32 classcc = pci_read32(bus, dev, func, 0x08);
                    u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                    u8 cc_sub = (u8)((classcc >> 16) & 0xFF);
                    u8 rev = (u8)(classcc & 0xFF);
                    const char *vname = pci_vendor_lookup(vendor);
                    const char *dname = pci_id_lookup(vendor, device);
                    char line[96];
                    if (vname && dname) {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %s %s",
                                 bus, dev, func, vname, dname);
                    } else if (vname) {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %s dev:%04x cls:%02x/%02x",
                                 bus, dev, func, vname, device,
                                 cc_base, cc_sub);
                    } else {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %04x:%04x cls:%02x/%02x rev:%02x",
                                 bus, dev, func, vendor, device,
                                 cc_base, cc_sub, rev);
                    }
                    term_puts(w, t, line);
                    if (func == 0 && !(hdr & 0x80)) break;
                }
            }
            if (bus > 2) break;
        }
        {
            char sum[40];
            snprintf(sum, sizeof(sum), "Total: %d devices", found);
            term_puts(w, t, sum);
        }
    } else if (!strncmp(c, "spawn ", 6)) {
        char *name = c + 6;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: spawn <имя>");
            term_puts(w, t, "Доступные: terminal files editor browser sysinfo taskmgr");
        } else if (app_spawn_by_name(name)) {
            term_puts(w, t, "Приложение запущено");
        } else {
            term_puts(w, t, "Приложение не найдено");
        }
    } else if (!strncmp(c, "curl ", 5)) {
        char *url = c + 5;
        while (*url == ' ') url++;
        if (!*url) {
            term_puts(w, t, "Использование: curl <url>");
            term_puts(w, t, "Пример: curl http://example.com/");
        } else if (!net_nic_present() || net_get_ip() == 0) {
            term_puts(w, t, "Сеть не настроена");
        } else {
            /* Парсим URL: http://host/path → host + path */
            char host[128];
            char path[256];
            const char *p = url;
            /* Пропускаем http:// */
            if (!strncmp(p, "http://", 7)) p += 7;
            int hi = 0;
            while (*p && *p != '/' && hi < 127) host[hi++] = *p++;
            host[hi] = 0;
            if (*p == '/') p++;
            else { p = "/"; }
            strncpy(path, p, 255);
            path[255] = 0;
            if (!*path) strcpy(path, "/");

            term_puts(w, t, "Запрос...");
            static char resp[4096];
            int n = net_http_get(host, 80, path, resp, sizeof(resp), 10000);
            if (n > 0) {
                char line[80];
                snprintf(line, sizeof(line), "Получено %d байт:", n);
                term_puts(w, t, line);
                /* Открываем браузер с полученным контентом */
                app_browser_open_with(url, resp, n);
            } else {
                term_puts(w, t, "Ошибка запроса");
            }
        }
    } else if (!strcmp(c, "c4test")) {
        /* Запустить встроенный тест c4 на стандартном примере */
        static const char *test_src =
            "#define MAX 5\n"
            "int main() {\n"
            "    int i;\n"
            "    int sum = 0;\n"
            "    int arr[MAX];\n"
            "    for (i = 0; i < MAX; i = i + 1) {\n"
            "        arr[i] = i * i;\n"
            "        sum = sum + arr[i];\n"
            "    }\n"
            "    for (i = 0; i < MAX; i = i + 1) {\n"
            "        printf(\"arr[%d] = %d\\n\", i, arr[i]);\n"
            "    }\n"
            "    printf(\"sum = %d\\n\", sum);\n"
            "    return 0;\n"
            "}\n";
        char out_buf[8192];
        out_buf[0] = 0;
        int r = c4_run(test_src, out_buf, sizeof(out_buf));
        term_puts(w, t, "=== c4 test (arrays, for, #define, printf) ===");
        /* Разбиваем по строкам */
        char *p = out_buf;
        while (*p) {
            char *nl = p;
            while (*nl && *nl != '\n') nl++;
            int L = nl - p;
            if (L > TERM_COLS - 1) L = TERM_COLS - 1;
            char line[TERM_COLS + 1];
            memcpy(line, p, L);
            line[L] = 0;
            term_puts(w, t, line);
            p = (*nl) ? nl + 1 : nl;
        }
        char sr[32];
        snprintf(sr, sizeof(sr), "exit code: %d", r);
        term_puts(w, t, sr);
    } else if (!strncmp(c, "cc ", 3)) {
        /* cc <name.c> — скомпилировать .c в .bin (native flat-binary) */
        char *p = c + 3;
        while (*p == ' ') p++;
        if (!*p) {
            term_puts(w, t, "Использование: cc <имя.c>");
        } else {
            char fname[64];
            int i = 0;
            while (*p && *p != ' ' && i < 63) fname[i++] = *p++;
            fname[i] = 0;
            char src_buf[8192];
            u32 got = ramfs_read(fname, src_buf, sizeof(src_buf) - 1);
            if (got == 0) {
                term_puts(w, t, "Файл не найден (сначала Save в редакторе)");
            } else {
                src_buf[got] = 0;
                char diag[256];
                diag[0] = 0;
                int r = c4_compile_to_file(fname, src_buf, diag, sizeof(diag));
                if (r == 0 && diag[0]) {
                    term_puts(w, t, diag);
                } else if (r != 0) {
                    char line[300];
                    snprintf(line, sizeof(line), "Ошибка компиляции: %s",
                             diag[0] ? diag : "(нет деталей)");
                    term_puts(w, t, line);
                } else {
                    term_puts(w, t, "cc: неизвестная ошибка");
                }
            }
        }
    } else {
        term_puts(w, t, "Неизвестная команда. Введите help.");
    }
}

static void term_draw(window_t *w)
{
    term_t *t = (term_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, term_bg);

    /* Видимая область: TERM_ROWS-1 строк (последняя для input).
     * Если scrollback = 0, показываем последние строки.
     * Иначе показываем строки начиная с (nlines - (TERM_ROWS-1) - scrollback). */
    int visible = TERM_ROWS - 1;
    int max_scroll = t->nlines - visible;
    if (max_scroll < 0) max_scroll = 0;
    if (t->scrollback > max_scroll) t->scrollback = max_scroll;
    if (t->scrollback < 0) t->scrollback = 0;
    int start = t->nlines - visible - t->scrollback;
    if (start < 0) start = 0;
    int end = start + visible;
    if (end > t->nlines) end = t->nlines;

    int y = 4;
    for (int i = start; i < end; i++, y += 16)
        fb_text(4, y, t->lines[i], term_fg, -1);

    /* строка ввода с курсором */
    fb_text(4, y, "> ", term_prompt, -1);
    fb_text(4 + 16, y, t->input, term_fg, -1);
    if (wm_blink()) {
        int cx = 4 + 16 + t->ilen * 8;
        fb_fill_rect(cx, y, 8, 16, term_fg);
    }

    /* Индикатор прокрутки: если scrollback > 0, показать "↑N" в правом-верхнем углу */
    if (t->scrollback > 0) {
        char buf[16];
        snprintf(buf, sizeof(buf), "^%d", t->scrollback);
        fb_text(cw - 4 - (int)strlen(buf) * 8, 2, buf,
                fb_rgb(0xFF, 0xE0, 0x60), -1);
    } else if (t->nlines > visible) {
        /* Внизу есть ещё строки */
        fb_text(cw - 16, 2, "v",
                fb_rgb(0x9A, 0xA3, 0xAC), -1);
    }
}

static void term_key(window_t *w, const key_event_t *ev)
{
    term_t *t = (term_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* PgUp/PgDn для прокрутки истории */
    if (ev->code == 0x49) {  /* PgUp */
        if (t->scrollback < t->nlines - (TERM_ROWS - 1))
            t->scrollback += (TERM_ROWS - 1);
        if (t->scrollback > t->nlines - (TERM_ROWS - 1))
            t->scrollback = t->nlines - (TERM_ROWS - 1);
        if (t->scrollback < 0) t->scrollback = 0;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x51) {  /* PgDn */
        t->scrollback -= (TERM_ROWS - 1);
        if (t->scrollback < 0) t->scrollback = 0;
        win_invalidate(w);
        return;
    }
    /* Стрелки вверх/вниз — одиночная прокрутка */
    if (ev->code == KBD_UP) {
        if (t->scrollback < t->nlines - (TERM_ROWS - 1))
            t->scrollback++;
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_DOWN) {
        if (t->scrollback > 0) t->scrollback--;
        win_invalidate(w);
        return;
    }
    /* Home — к началу истории, End — к концу (хвосту) */
    if (ev->code == 0x47) {  /* Home */
        t->scrollback = t->nlines - (TERM_ROWS - 1);
        if (t->scrollback < 0) t->scrollback = 0;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x4F) {  /* End */
        t->scrollback = 0;
        win_invalidate(w);
        return;
    }

    if (ev->code == 0x1C || ev->ch == '\n') {
        /* Enter: строка тоже попадает в историю */
        char line[TERM_COLS + 4];
        snprintf(line, sizeof(line), "> %s", t->input);
        term_print(t, line);
        term_exec(w, t);
        term_touch(w);
        return;
    }
    if (ev->ch == '\b' || ev->code == 0x0E) {
        if (t->ilen > 0) t->input[--t->ilen] = 0;
        term_touch(w);
        return;
    }
    if (ev->ch >= 32 && ev->ch < 127) {
        if (t->ilen < TERM_COLS) {
            t->input[t->ilen++] = ev->ch;
            t->input[t->ilen] = 0;
        }
        term_touch(w);
        return;
    }
    /* Стрелки вверх/вниз уже обработаны выше для прокрутки истории */
}

static void term_tick(window_t *w)
{
    win_invalidate(w); /* перерисовка ради мигания курсора */

    /* Двигаем сессию ping. term_tick вызывается 2 раза в секунду
     * (из wm_halfsec), т.е. каждые 500 мс. */
    if (!g_ping.active || g_ping.win != w) return;

    /* Если есть ответ — выведем его */
    if (g_ping.have_reply) {
        char line[80];
        char ipbuf[16];
        net_ntoa(g_ping.target_ip, ipbuf, sizeof(ipbuf));
        snprintf(line, sizeof(line), "  reply from %s: seq=%u  time=%u ms  bytes=32",
                 ipbuf, (unsigned)g_ping.reply_seq, (unsigned)g_ping.reply_rtt_ms);
        term_puts(g_ping.win, g_ping.term, line);
        g_ping.have_reply = 0;
        /* Перейдём к следующему пакету, если ещё не все отправлены */
        if (g_ping.sent >= (u32)g_ping.max_count) {
            goto ping_end;
        }
        goto send_next;
    }

    /* Проверим таймаут */
    {
        u32 now = timer_ticks();
        u32 elapsed_ms = (now - g_ping.last_send_tick) * 10u;  /* 1 tick = 10 ms */
        if (g_ping.last_send_tick != 0 && elapsed_ms > g_ping.timeout_ms) {
            char line[80];
            char ipbuf[16];
            net_ntoa(g_ping.target_ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "  timeout: seq=%u (no reply in %u ms)",
                     g_ping.next_seq - 1, (unsigned)g_ping.timeout_ms);
            term_puts(g_ping.win, g_ping.term, line);
            if (g_ping.sent >= (u32)g_ping.max_count) {
                goto ping_end;
            }
            goto send_next;
        }
    }
    return;

send_next:
    if (g_ping.sent >= (u32)g_ping.max_count) {
        goto ping_end;
    }
    {
        /* Отправляем ICMP Echo Request с уникальным seq */
        u16 seq = g_ping.next_seq++;
        u32 t_send = timer_ticks();
        g_ping.last_send_tick = t_send;
        g_ping.sent++;
        g_ping.have_reply = 0;
        /* Payload — 32 байта */
        u8 payload[32];
        memset(payload, 0xAA, 32);
        net_send_icmp_echo(g_ping.target_ip, 0x1234, seq, payload, 32);
    }
    return;

ping_end:
    {
        char sum[64];
        u32 loss = (g_ping.sent > g_ping.recv) ? (g_ping.sent - g_ping.recv) : 0;
        u32 pct = (g_ping.sent > 0) ? loss * 100 / g_ping.sent : 0;
        snprintf(sum, sizeof(sum), "--- %u sent, %u recv, %u%% loss ---",
                 (unsigned)g_ping.sent, (unsigned)g_ping.recv, (unsigned)pct);
        term_puts(g_ping.win, g_ping.term, sum);
        g_ping.active = 0;
    }
}

void app_term_open(void)
{
    term_t *t = (term_t *)malloc(sizeof(term_t));
    if (!t) return;
    memset(t, 0, sizeof(term_t));
    term_bg = fb_rgb(0x0B, 0x0E, 0x11);
    term_fg = fb_rgb(0xC6, 0xCD, 0xD5);
    term_prompt = fb_rgb(0x6F, 0xB3, 0xF2);

    term_print(t, "N2600-OS 0.1 - терминал");
    term_print(t, "Введите help для списка команд.");
    term_print(t, "");

    int ww = TERM_COLS * 8 + 10;
    int wh = TERM_ROWS * 16 + 8 + TITLE_H + 2;
    int x = 20;
    int y = 16;
    win_create("Терминал", x, y, ww, wh, term_draw, term_key, NULL, term_tick, NULL, t);
}

/* ========================= СИСТЕМНАЯ ИНФОРМАЦИЯ ========================= */
#define SI_LINES 30
#define SI_LINE_W 60

typedef struct {
    char lines[SI_LINES][SI_LINE_W];
    u32  colors[SI_LINES];
    int  scroll;
} sysinfo_t;

static const u32 C_LABEL = 0, C_VALUE = 1, C_ACCENT = 2;

static void si_put(sysinfo_t *d, int row, const char *s, u32 which)
{
    if (row < 0 || row >= SI_LINES) return;
    strncpy(d->lines[row], s, SI_LINE_W - 1);
    d->lines[row][SI_LINE_W - 1] = 0;
    d->colors[row] = which;
}

static void si_draw(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x12, 0x15, 0x19));
    fb_fill_rect(0, 0, cw, 2, fb_rgb(0x3E, 0x7D, 0xBF));

    u32 col_label = fb_rgb(0x8A, 0x93, 0x9C);
    u32 col_value = fb_rgb(0xE6, 0xEA, 0xEE);
    u32 col_accent = fb_rgb(0x6F, 0xB3, 0xF2);
    u32 col_warn = fb_rgb(0xFF, 0xE0, 0x60);

    int vis = ch / 18;
    if (vis < 1) vis = 1;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (d->scroll > max_scroll) d->scroll = max_scroll;
    if (d->scroll < 0) d->scroll = 0;

    int start = d->scroll;
    int end = start + vis;
    if (end > SI_LINES) end = SI_LINES;

    /* Полоса прокрутки (правая граница) */
    int sb_x = cw - 8;
    int sb_h = ch - 8;
    fb_fill_rect(sb_x, 4, 4, sb_h, fb_rgb(0x1E, 0x22, 0x28));
    if (max_scroll > 0) {
        int thumb_h = sb_h * vis / SI_LINES;
        if (thumb_h < 8) thumb_h = 8;
        int thumb_y = 4 + (sb_h - thumb_h) * (max_scroll - d->scroll) / max_scroll;
        fb_fill_rect(sb_x, thumb_y, 4, thumb_h, fb_rgb(0x6F, 0xB3, 0xF2));
    }

    int text_w = cw - 12;  /* оставляем место под скроллбар */
    int y = 12;
    for (int i = start; i < end; i++, y += 18) {
        u32 c;
        if (d->colors[i] == C_LABEL) c = col_label;
        else if (d->colors[i] == C_VALUE) c = col_value;
        else if (d->colors[i] == C_ACCENT) c = col_accent;
        else c = col_warn;
        fb_text(10, y, d->lines[i], c, -1);
        (void)text_w;
    }
}

static void si_key(window_t *w, const key_event_t *ev)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)cw;
    int vis = ch / 18;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (ev->code == 0x49 || ev->code == KBD_UP) {  /* PgUp / ↑ */
        if (d->scroll < max_scroll) d->scroll++;
        win_invalidate(w);
    }
    else if (ev->code == 0x51 || ev->code == KBD_DOWN) {  /* PgDn / ↓ */
        if (d->scroll > 0) d->scroll--;
        win_invalidate(w);
    }
}

static void si_tick(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    u32 up = uptime_sec();
    char line[SI_LINE_W];
    snprintf(line, sizeof(line), "Uptime: %02u:%02u:%02u  Tasks: %d  Heap: %uK/%uK",
             up / 3600, (up / 60) % 60, up % 60,
             task_count(),
             (unsigned)(mem_used() / 1024),
             (unsigned)(mem_heap_size() / 1024));
    strncpy(d->lines[SI_LINES - 1], line, SI_LINE_W - 1);
    win_invalidate(w);
}

void app_sysinfo_open(void)
{
    sysinfo_t *d = (sysinfo_t *)malloc(sizeof(sysinfo_t));
    if (!d) return;
    memset(d, 0, sizeof(sysinfo_t));

    char brand[52], vend[16], line[SI_LINE_W];
    cpu_get_brand(brand);
    cpu_get_vendor(vend);

    int r = 0;
    si_put(d, r++, "=== N2600-OS 0.1 ===", C_ACCENT);
    si_put(d, r++, "", C_VALUE);

    /* CPU */
    si_put(d, r++, "--- CPU ---", C_LABEL);
    snprintf(line, sizeof(line), "Brand: %s", brand);
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Vendor: %s, Cores: %d", vend, cpu_get_cores());
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* Memory */
    si_put(d, r++, "--- Memory ---", C_LABEL);
    snprintf(line, sizeof(line), "RAM: %u MiB", (unsigned)mem_ram_mib());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Heap: %u / %u KiB used",
             (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* Display */
    si_put(d, r++, "--- Display ---", C_LABEL);
    snprintf(line, sizeof(line), "Screen: %ux%u, %u bpp, pitch %u",
             (unsigned)fb_width(), (unsigned)fb_height(),
             (unsigned)fb_bpp(), (unsigned)fb_pitch());
    si_put(d, r++, line, C_VALUE);

    {
        const mb_info_t *mb = mb_info();
        const char *ldr = (mb && (mb->flags & MBIF_BOOTLDR))
            ? (const char *)(unsigned long)mb->boot_loader_name : "n/a";
        snprintf(line, sizeof(line), "Bootloader: %s", ldr);
        si_put(d, r++, line, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Input */
    si_put(d, r++, "--- Input ---", C_LABEL);
    snprintf(line, sizeof(line), "PS/2 Mouse: %s",
             mouse_present() ? "present" : "not found");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB keyboard: %s",
             usb_keyboard_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB mouse: %s",
             usb_mouse_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* USB */
    si_put(d, r++, "--- USB ---", C_LABEL);
    snprintf(line, sizeof(line), "UHCI: %s, EHCI: %s, Devs: %d",
             usb_controllers_found() ? "yes" : "no",
             usb_ehci_present() ? "yes" : "no",
             usb_devices_found());
    si_put(d, r++, line, C_VALUE);
    if (usb_ehci_storage_ready()) {
        si_put(d, r++, "USB flash: READY", C_VALUE);
    } else {
        si_put(d, r++, "USB flash: not detected", C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Network */
    si_put(d, r++, "--- Network ---", C_LABEL);
    if (net_nic_present()) {
        u8 mac[6];
        net_get_mac(mac);
        snprintf(line, sizeof(line), "NIC: %s", net_nic_name());
        si_put(d, r++, line, C_VALUE);
        snprintf(line, sizeof(line), "MAC: %02x:%02x:%02x:%02x:%02x:%02x",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        si_put(d, r++, line, C_VALUE);
        char ipbuf[16];
        u32 ip = net_get_ip();
        if (ip == 0) {
            si_put(d, r++, "IP: not configured", C_ACCENT);
        } else {
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "IP: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Mask: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "GW: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
        }
        snprintf(line, sizeof(line), "TX: %u, RX: %u",
                 (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "NIC: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* WiFi */
    si_put(d, r++, "--- WiFi ---", C_LABEL);
    if (wifi_present()) {
        snprintf(line, sizeof(line), "Chip: %s", wifi_chip_name());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "WiFi: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);
    si_put(d, r++, "Uptime: 00:00:00", C_VALUE);

    u32 W = fb_width(), H = fb_height();
    int ww = 8 * SI_LINE_W + 20;
    int wh = 16 * 18 + 24 + TITLE_H + 2;  /* показываем 16 строк, остальные — скроллом */
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("System Info", 16, 16, ww, wh,
               si_draw, si_key, NULL, si_tick, NULL, d);
}