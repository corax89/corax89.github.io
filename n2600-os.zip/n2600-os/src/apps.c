/* apps.c — реестр приложений + «О программе», «Терминал», «Системная информация» */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "timer.h"
#include "string.h"
#include "mouse.h"
#include "kernel.h"

#include <cpuid.h>   /* GCC/MinGW: встроенные обёртки над инструкцией CPUID */

/* ------------------------------ реестр ------------------------------ */

const app_def_t app_table[] = {
    { "О программе",            app_about_open   },
    { "Терминал",               app_term_open    },
    { "Системная информация",   app_sysinfo_open },
    { "Пример приложения",      app_example_open },
};
const int app_table_count = (int)(sizeof(app_table) / sizeof(app_table[0]));

void apps_open(int idx)
{
    if (idx >= 0 && idx < app_table_count) app_table[idx].open_fn();
}

/* --------------------------- CPU (CPUID) --------------------------- */

void cpu_get_vendor(char out[16])
{
    unsigned a, b, c, d;
    if (!__get_cpuid(0, &a, &b, &c, &d)) { strcpy(out, "-"); return; }
    memcpy(out, &b, 4);
    memcpy(out + 4, &d, 4);
    memcpy(out + 8, &c, 4);
    out[12] = 0;
}

void cpu_get_brand(char out[52])
{
    unsigned a, b, c, d;
    char *p = out;
    unsigned max_ext = 0;
    if (__get_cpuid(0x80000000, &a, &b, &c, &d)) max_ext = a;
    if (max_ext >= 0x80000004) {
        for (unsigned leaf = 0x80000002; leaf <= 0x80000004; leaf++) {
            __get_cpuid(leaf, &a, &b, &c, &d);
            memcpy(p, &a, 4); memcpy(p + 4, &b, 4);
            memcpy(p + 8, &c, 4); memcpy(p + 12, &d, 4);
            p += 16;
        }
        *p = 0;
        /* обрезаем ведущие пробелы */
        char *s = out;
        while (*s == ' ') s++;
        if (s != out) memmove(out, s, strlen(s) + 1);
        return;
    }
    strcpy(out, "неизвестный процессор");
}

int cpu_get_cores(void)
{
    unsigned a, b, c, d;
    if (__get_cpuid(1, &a, &b, &c, &d)) return (int)((b >> 16) & 0xFF);
    return 1;
}

/* ============================== О ПРОГРАММЕ ============================== */

typedef struct {
    char cpu[52];
} about_data_t;

static void about_draw(window_t *w)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)cw; (void)ch;

    fb_fill_rect(0, 0, win_content_w(w), win_content_h(w), fb_rgb(0x12, 0x15, 0x1A));
    fb_fill_rect(0, 0, win_content_w(w), 3, fb_rgb(0x3E, 0x7D, 0xBF));

    const char *name = "N2600-OS";
    int nx = (win_content_w(w) - (int)strlen(name) * 16) / 2;
    u32 c = fb_rgb(0x6F, 0xB3, 0xF2);
    for (const char *p = name; *p; p++, nx += 16)
        fb_char2x(nx, 18, (unsigned char)*p, c);

    fb_text(16, 64, "Простая оконная ОС на чистом C", fb_rgb(0xC6, 0xCD, 0xD5), -1);
    fb_text(16, 84, "Сборка: MinGW (i686), multiboot + GRUB", fb_rgb(0x9A, 0xA3, 0xAC), -1);
    fb_text(16, 104, "Цель: Intel Atom N2600, VESA 1280x600x32", fb_rgb(0x9A, 0xA3, 0xAC), -1);

    about_data_t *d = (about_data_t *)w->data;
    char line[64];
    snprintf(line, sizeof(line), "CPU: %s", d->cpu);
    fb_text(16, 132, line, fb_rgb(0x9A, 0xA3, 0xAC), -1);

    fb_text(16, win_content_h(w) - 24, "Лицензия: MIT, 2026", fb_rgb(0x50, 0x58, 0x62), -1);
}

void app_about_open(void)
{
    about_data_t *d = (about_data_t *)malloc(sizeof(about_data_t));
    if (!d) return;
    cpu_get_brand(d->cpu);

    u32 W = fb_width();
    int ww = 360, wh = 200;
    win_create("О программе", (int)W - ww - 40, 40, ww, wh,
               about_draw, NULL, NULL, NULL, NULL, d);
}

/* =============================== ТЕРМИНАЛ =============================== */

#define TERM_COLS 62
#define TERM_ROWS 17

typedef struct {
    char lines[TERM_ROWS][TERM_COLS + 1];
    int  nlines;
    char input[TERM_COLS + 1];
    int  ilen;
} term_t;

static u32 term_bg, term_fg, term_prompt;

static void term_print(term_t *t, const char *s)
{
    /* печатаем текст с переносом по ширине окна */
    while (*s) {
        int room = TERM_COLS - 1;
        const char *nl = NULL;
        for (const char *p = s; *p && p < s + room; p++)
            if (*p == '\n') { nl = p; break; }

        u32 slen = strlen(s);
        u32 seg_len = nl ? (u32)(nl - s)
                         : (slen > (u32)room ? (u32)room : slen);

        if (t->nlines == TERM_ROWS - 1) {
            memmove(t->lines[0], t->lines[1], sizeof(t->lines[0]) * (TERM_ROWS - 1));
            t->nlines--;
        }
        memcpy(t->lines[t->nlines], s, seg_len);
        t->lines[t->nlines][seg_len] = 0;
        t->nlines++;
        s += seg_len;
        if (nl) s++; /* пропускаем \n */
    }
}

static void term_touch(window_t *w) { win_invalidate(w); }

static void term_puts(window_t *w, term_t *t, const char *s)
{
    term_print(t, s);
    term_touch(w);
}

static void term_exec(window_t *w, term_t *t)
{
    char cmd[TERM_COLS + 1];
    strcpy(cmd, t->input);
    t->input[0] = 0;
    t->ilen = 0;

    /* отрезаем ведущие пробелы */
    char *c = cmd;
    while (*c == ' ') c++;

    if (!*c) return;

    if (!strcmp(c, "help")) {
        term_puts(w, t, "Команды:");
        term_puts(w, t, "  help    - этот список");
        term_puts(w, t, "  about   - о системе");
        term_puts(w, t, "  sysinfo - краткие сведения о железе");
        term_puts(w, t, "  mem     - память (RAM и куча)");
        term_puts(w, t, "  uptime  - время работы");
        term_puts(w, t, "  apps    - открытые окна");
        term_puts(w, t, "  echo <текст>");
        term_puts(w, t, "  clear   - очистить экран");
        term_puts(w, t, "  reboot  - перезагрузка");
        term_puts(w, t, "  poweroff- выключение (QEMU)");
    } else if (!strcmp(c, "about")) {
        term_puts(w, t, "N2600-OS 0.1 - оконная ОС на чистом C.");
        term_puts(w, t, "Ядро собирается MinGW, грузится GRUB'ом в VESA LFB.");
    } else if (!strcmp(c, "sysinfo")) {
        char brand[52], line[96];
        cpu_get_brand(brand);
        snprintf(line, sizeof(line), "CPU: %s", brand);
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "Ядер (логических): %d", cpu_get_cores());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "RAM: %u МиБ, экран: %ux%ux32",
                 (unsigned)mem_ram_mib(), (unsigned)fb_width(), (unsigned)fb_height());
        term_puts(w, t, line);
    } else if (!strcmp(c, "mem")) {
        char line[96];
        snprintf(line, sizeof(line), "RAM всего: %u МиБ", (unsigned)mem_ram_mib());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "Куча: занято %u КиБ из %u КиБ",
                 (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
        term_puts(w, t, line);
    } else if (!strcmp(c, "uptime")) {
        u32 up = uptime_sec();
        char line[64];
        snprintf(line, sizeof(line), "Время работы: %02u:%02u:%02u",
                 up / 3600, (up / 60) % 60, up % 60);
        term_puts(w, t, line);
    } else if (!strcmp(c, "apps")) {
        char line[80];
        int n = wm_window_count();
        snprintf(line, sizeof(line), "Открыто окон: %d", n);
        term_puts(w, t, line);
        for (int i = 0; i < n; i++) {
            snprintf(line, sizeof(line), "  [%d] %s", i, wm_window_title(i));
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "echo ", 5)) {
        term_puts(w, t, c + 5);
    } else if (!strcmp(c, "echo")) {
        term_puts(w, t, "");
    } else if (!strcmp(c, "clear")) {
        t->nlines = 0;
        term_touch(w);
    } else if (!strcmp(c, "reboot")) {
        sys_reboot();
    } else if (!strcmp(c, "poweroff")) {
        sys_poweroff();
    } else {
        term_puts(w, t, "Неизвестная команда. Введите help.");
    }
}

static void term_draw(window_t *w)
{
    term_t *t = (term_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, term_bg);

    int y = 4;
    for (int i = 0; i < t->nlines; i++, y += 16)
        fb_text(4, y, t->lines[i], term_fg, -1);

    /* строка ввода с курсором */
    fb_text(4, y, "> ", term_prompt, -1);
    fb_text(4 + 16, y, t->input, term_fg, -1);
    if (wm_blink()) {
        int cx = 4 + 16 + t->ilen * 8;
        fb_fill_rect(cx, y, 8, 16, term_fg);
    }
}

static void term_key(window_t *w, const key_event_t *ev)
{
    term_t *t = (term_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    if (ev->code == 0x1C || ev->ch == '\n') {
        /* Enter: строка тоже попадает в историю */
        char line[TERM_COLS + 4];
        snprintf(line, sizeof(line), "> %s", t->input);
        term_print(t, line);
        term_exec(w, t);
        term_touch(w);
        return;
    }
    if (ev->ch == '\b' || ev->code == 0x0E) {
        if (t->ilen > 0) t->input[--t->ilen] = 0;
        term_touch(w);
        return;
    }
    if (ev->ch >= 32 && ev->ch < 127) {
        if (t->ilen < TERM_COLS) {
            t->input[t->ilen++] = ev->ch;
            t->input[t->ilen] = 0;
        }
        term_touch(w);
        return;
    }
    if (ev->code == KBD_UP || ev->code == KBD_DOWN) {
        return; /* история не реализована */
    }
}

static void term_tick(window_t *w)
{
    win_invalidate(w); /* перерисовка ради мигания курсора */
}

void app_term_open(void)
{
    term_t *t = (term_t *)malloc(sizeof(term_t));
    if (!t) return;
    memset(t, 0, sizeof(term_t));

    term_bg = fb_rgb(0x0B, 0x0E, 0x11);
    term_fg = fb_rgb(0xC6, 0xCD, 0xD5);
    term_prompt = fb_rgb(0x6F, 0xB3, 0xF2);

    term_print(t, "N2600-OS 0.1 - терминал");
    term_print(t, "Введите help для списка команд.");
    term_print(t, "");

    int ww = TERM_COLS * 8 + 10;
    int wh = TERM_ROWS * 16 + 8 + TITLE_H + 2;
    int x = 20;
    int y = 16;
    win_create("Терминал", x, y, ww, wh, term_draw, term_key, NULL, term_tick, NULL, t);
}

/* ========================= СИСТЕМНАЯ ИНФОРМАЦИЯ ========================= */

#define SI_LINES 12
#define SI_LINE_W 56

typedef struct {
    char lines[SI_LINES][SI_LINE_W];
    u32  colors[SI_LINES];
} sysinfo_t;

static const u32 C_LABEL = 0, C_VALUE = 1, C_ACCENT = 2;

static void si_put(sysinfo_t *d, int row, const char *s, u32 which)
{
    if (row < 0 || row >= SI_LINES) return;
    strncpy(d->lines[row], s, SI_LINE_W - 1);
    d->lines[row][SI_LINE_W - 1] = 0;
    d->colors[row] = which;
}

static void si_draw(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x12, 0x15, 0x19));
    fb_fill_rect(0, 0, cw, 2, fb_rgb(0x3E, 0x7D, 0xBF));

    u32 col_label = fb_rgb(0x8A, 0x93, 0x9C);
    u32 col_value = fb_rgb(0xE6, 0xEA, 0xEE);
    u32 col_accent = fb_rgb(0x6F, 0xB3, 0xF2);

    int y = 12;
    for (int i = 0; i < SI_LINES; i++, y += 18) {
        u32 c = (d->colors[i] == C_LABEL) ? col_label
              : (d->colors[i] == C_VALUE) ? col_value : col_accent;
        fb_text(10, y, d->lines[i], c, -1);
    }
}

static void si_tick(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    u32 up = uptime_sec();
    char line[SI_LINE_W];
    snprintf(line, sizeof(line), "Время работы:     %02u:%02u:%02u",
             up / 3600, (up / 60) % 60, up % 60);
    strncpy(d->lines[SI_LINES - 1], line, SI_LINE_W - 1);
    win_invalidate(w);
}

void app_sysinfo_open(void)
{
    sysinfo_t *d = (sysinfo_t *)malloc(sizeof(sysinfo_t));
    if (!d) return;
    memset(d, 0, sizeof(sysinfo_t));

    char brand[52], vend[16], line[SI_LINE_W];
    cpu_get_brand(brand);
    cpu_get_vendor(vend);

    int r = 0;
    si_put(d, r++, "== N2600-OS 0.1 ==", C_ACCENT);
    si_put(d, r++, "", C_VALUE);
    snprintf(line, sizeof(line), "Процессор: %s", brand);
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Вендор: %s, ядер: %d", vend, cpu_get_cores());
    si_put(d, r++, line, C_VALUE);
    si_put(d, r++, "", C_VALUE);
    snprintf(line, sizeof(line), "RAM: %u МиБ", (unsigned)mem_ram_mib());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Куча: %u из %u КиБ занято",
             (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
    si_put(d, r++, line, C_VALUE);
    si_put(d, r++, "", C_VALUE);
    snprintf(line, sizeof(line), "Экран: %ux%u, %u bpp, pitch %u",
             (unsigned)fb_width(), (unsigned)fb_height(),
             (unsigned)fb_bpp(), (unsigned)fb_pitch());
    si_put(d, r++, line, C_VALUE);
    {
        const mb_info_t *mb = mb_info();
        const char *ldr = (mb && (mb->flags & MBIF_BOOTLDR))
            ? (const char *)(unsigned long)mb->boot_loader_name : "нет данных";
        snprintf(line, sizeof(line), "Загрузчик: %s", ldr);
        si_put(d, r++, line, C_VALUE);
    }
    snprintf(line, sizeof(line), "Мышь PS/2: %s",
             mouse_present() ? "найдена" : "не найдена");
    si_put(d, r++, line, C_VALUE);
    si_put(d, r++, "Время работы:     00:00:00", C_VALUE);

    u32 W = fb_width();
    int ww = 8 * SI_LINE_W + 20;
    int wh = SI_LINES * 18 + 24 + TITLE_H + 2;
    win_create("Системная информация", (int)W - ww - 16, 16, ww, wh,
               si_draw, NULL, NULL, si_tick, NULL, d);
}
