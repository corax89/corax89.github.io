/* ne2000.h — драйвер NE2000-совместимой сетевой карты (8390 PCI) для N2600-OS.
 *
 * Поддержка:
 *   - PCI-детекция Realtek RTL8029 (vendor=0x10EC, device=0x8029)
 *   - Также любые NE2000-клоны (class 0x0200, prog_if 0x00)
 *   - I/O port доступ (не MMIO — 8390 использует порты)
 *   - Приём и передача через internal ring buffer
 *   - Получение MAC адреса из EEPROM/PROM
 *
 * Совместим с QEMU (-device ne2k_pci) и реальными картами.
 */
#ifndef NE2000_H
#define NE2000_H

#include "types.h"

int  ne2000_init(void);
int  ne2000_present(void);
const char *ne2000_chip_name(void);
int  ne2000_get_mac(u8 out_mac[6]);
int  ne2000_send(const void *buf, u32 len);
u32  ne2000_recv(void *out_buf, u32 out_max);

#endif
