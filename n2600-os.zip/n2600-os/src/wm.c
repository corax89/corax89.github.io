/* wm.c — оконный менеджер N2600-OS.
 * Композитинг: backbuffer -> LFB. Перерисовываются только «грязные» области:
 * полный кадр нужен при перетаскивании/изменении z-порядка, в остальных
 * случаях обновляются только прямоугольники (курсор, текст, часы). */
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "mouse.h"
#include "rtc.h"
#include "string.h"
#include "apps.h"

/* --------------------------- палитра интерфейса --------------------------- */
#define COL_ACCENT      fb_rgb(0x3E, 0x7D, 0xBF)
#define COL_BORDER      fb_rgb(0x34, 0x38, 0x3E)
#define COL_TITLE_FOC   fb_rgb(0x1E, 0x4A, 0x73)
#define COL_TITLE       fb_rgb(0x25, 0x2A, 0x30)
#define COL_CLOSE       fb_rgb(0x8C, 0x2E, 0x2E)
#define COL_CLOSE_HOT   fb_rgb(0xB0, 0x38, 0x38)
#define COL_TBAR        fb_rgb(0x12, 0x16, 0x1B)
#define COL_TBAR_LINE   fb_rgb(0x2C, 0x31, 0x38)
#define COL_BTN         fb_rgb(0x1B, 0x21, 0x27)
#define COL_BTN_ACT     fb_rgb(0x24, 0x43, 0x5F)
#define COL_MENU        fb_rgb(0x17, 0x1C, 0x22)
#define COL_MENU_LINE   fb_rgb(0x30, 0x36, 0x3E)
#define COL_MENU_HOT    fb_rgb(0x24, 0x43, 0x5F)
#define COL_TEXT        fb_rgb(0xE6, 0xEA, 0xEE)
#define COL_TEXT_DIM    fb_rgb(0x9A, 0xA3, 0xAC)

static window_t *wins[WM_MAX_WINDOWS];
static int nwin = 0;

static window_t *drag_win = NULL;
static int drag_dx = 0, drag_dy = 0;
static window_t *pending_close = NULL;
static int menu_open = 0, menu_hover = -1;

static int cur_x = 0, cur_y = 0;        /* позиция курсора (последняя отрисованная) */
static int cursor_visible = 0;
static int blink_state = 0;

/* служебные действия (реализованы в kernel.c) */
extern void sys_reboot(void);
extern void sys_poweroff(void);

/* ------------------------------- курсор ------------------------------- */
static const char *cursor_map[19] = {
    "X           ",
    "XX          ",
    "X*X         ",
    "X**X        ",
    "X***X       ",
    "X****X      ",
    "X*****X     ",
    "X******X    ",
    "X*******X   ",
    "X********X  ",
    "X*****XXXXX ",
    "X**X**X     ",
    "X*X X**X    ",
    "XX  X**X    ",
    "X    X**X   ",
    "     X**X   ",
    "      XX    ",
    "            ",
    "            "
};

static void draw_cursor(void)
{
    u32 black = fb_rgb(0, 0, 0), white = fb_rgb(0xFF, 0xFF, 0xFF);
    for (int r = 0; r < 19; r++) {
        for (int c = 0; c < 12; c++) {
            char ch = cursor_map[r][c];
            if (ch == ' ') continue;
            fb_fill_rect(cur_x + c, cur_y + r, 1, 1,
                         (ch == 'X') ? black : white);
        }
    }
}

/* ------------------------------ служебное ------------------------------ */

static int rect_intersect(int ax, int ay, int aw, int ah,
                          int bx, int by, int bw, int bh)
{
    return ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah;
}

static void win_content_rect(window_t *w, int *cx, int *cy, int *cw, int *ch)
{
    *cx = w->x + 1;
    *cy = w->y + TITLE_H + 1;
    *cw = w->w - 2;
    *ch = w->h - TITLE_H - 2;
}

int win_content_w(window_t *w) { return w->w - 2; }
int win_content_h(window_t *w) { return w->h - TITLE_H - 2; }

static int window_at(int x, int y)
{
    for (int i = nwin - 1; i >= 0; i--)
        if (x >= wins[i]->x && x < wins[i]->x + wins[i]->w &&
            y >= wins[i]->y && y < wins[i]->y + wins[i]->h)
            return i;
    return -1;
}

static void raise_window(int idx)
{
    if (idx < 0 || idx == nwin - 1) return;
    window_t *w = wins[idx];
    for (int i = idx; i < nwin - 1; i++) wins[i] = wins[i + 1];
    wins[nwin - 1] = w;
    fb_touch_all(); /* изменился z-порядок — полная перерисовка */
}

/* ------------------------------- меню ------------------------------- */

#define MENU_W 210
#define MENU_ITEM_H 26

static int menu_items(void)
{
    return app_table_count + 3; /* приложения + разделитель + Перезагрузка + Выключение */
}

static int menu_height(void)
{
    return menu_items() * MENU_ITEM_H + 8 + 9;
}

static void menu_rect(int *mx, int *my, int *mw, int *mh)
{
    *mx = 4;
    *mw = MENU_W;
    *mh = menu_height();
    *my = (int)fb_height() - TBAR_H - *mh;
}

/* индекс пункта по экранным координатам (с учётом разделителя) или -1 */
static int menu_hit(int x, int y)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    if (x < mx || x >= mx + mw || y < my || y >= my + mh) return -1;
    int yy = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == app_table_count) { yy += 9; continue; }
        if (y >= yy && y < yy + MENU_ITEM_H) return i;
        yy += MENU_ITEM_H;
    }
    return -1;
}

static void menu_action(int idx)
{
    if (idx < app_table_count) {
        apps_open(idx);
    } else if (idx == app_table_count + 1) {
        sys_reboot();
    } else if (idx == app_table_count + 2) {
        sys_poweroff();
    }
}

/* ------------------------------ заголовки ------------------------------ */

static void draw_close_icon(int bx, int by, u32 col)
{
    for (int k = 0; k < 9; k++) {
        fb_fill_rect(bx + k, by + k, 1, 1, col);
        fb_fill_rect(bx + 8 - k, by + k, 1, 1, col);
    }
}

static void draw_window(window_t *w)
{
    int focused = (nwin > 0 && wins[nwin - 1] == w);
    u32 title_col = focused ? COL_TITLE_FOC : COL_TITLE;
    u32 border_col = focused ? COL_ACCENT : COL_BORDER;

    fb_rect(w->x, w->y, w->w, w->h, border_col);
    fb_fill_rect(w->x + 1, w->y + 1, w->w - 2, TITLE_H - 1, title_col);
    fb_text(w->x + 8, w->y + (TITLE_H - 16) / 2, w->title, COL_TEXT, -1);

    int bx = w->x + w->w - 22, by = w->y + 4;
    fb_fill_rect(bx, by, 18, 16, (pending_close == w) ? COL_CLOSE_HOT : COL_CLOSE);
    draw_close_icon(bx + 4, by + 3, fb_rgb(0xF0, 0xD0, 0xD0));

    int cx, cy, cw, ch;
    win_content_rect(w, &cx, &cy, &cw, &ch);
    fb_set_clip(cx, cy, cx + cw - 1, cy + ch - 1);
    fb_set_origin(cx, cy);
    if (w->draw) w->draw(w);
    fb_set_origin(0, 0);
}

static void draw_taskbar(void)
{
    u32 H = fb_height(), W = fb_width();
    fb_fill_rect(0, (int)H - TBAR_H, (int)W, TBAR_H, COL_TBAR);
    fb_hline(0, (int)W - 1, (int)H - TBAR_H, COL_TBAR_LINE);

    /* кнопка «Меню» */
    fb_fill_rect(4, (int)H - 24, 64, 20, menu_open ? COL_BTN_ACT : COL_BTN);
    fb_rect(4, (int)H - 24, 64, 20, COL_MENU_LINE);
    fb_text(4 + (64 - 4 * 8) / 2, (int)H - 24 + 2, "Меню", COL_TEXT, -1);

    /* часы */
    int h = 0, m = 0, s = 0;
    rtc_get_time(&h, &m, &s);
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", h, m, s);
    fb_text((int)W - 8 - (int)strlen(buf) * 8, (int)H - 22, buf, COL_TEXT_DIM, -1);

    /* подпись ОС рядом с кнопкой */
    fb_text(78, (int)H - 22, "N2600-OS", fb_rgb(0x50, 0x58, 0x62), -1);
}

static void draw_menu(void)
{
    int mx, my, mw, mh;
    menu_rect(&mx, &my, &mw, &mh);
    fb_fill_rect(mx, my, mw, mh, COL_MENU);
    fb_rect(mx, my, mw, mh, COL_MENU_LINE);

    int y = my + 4;
    for (int i = 0; i < menu_items(); i++) {
        if (i == app_table_count) {           /* разделитель */
            fb_hline(mx + 1, mx + mw - 2, y + 4, COL_MENU_LINE);
            y += 9;
            continue;
        }
        int hot = (menu_open && menu_hover == i);
        if (hot) fb_fill_rect(mx + 2, y, mw - 4, MENU_ITEM_H, COL_MENU_HOT);
        const char *name = (i < app_table_count)
            ? app_table[i].name
            : (i == app_table_count ? "Перезагрузка" : "Выключение");
        fb_text(mx + 12, y + (MENU_ITEM_H - 16) / 2, name,
                hot ? COL_TEXT : COL_TEXT_DIM, -1);
        y += MENU_ITEM_H;
    }
}

/* ----------------------------- композитинг ----------------------------- */

static void composite(int rx0, int ry0, int rx1, int ry1)
{
    u32 W = fb_width(), H = fb_height();

    fb_blit_bg(rx0, ry0, rx1, ry1);

    for (int i = 0; i < nwin; i++) {
        window_t *w = wins[i];
        if (!rect_intersect(w->x, w->y, w->w, w->h, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1))
            continue;
        int cx0 = (w->x < rx0) ? rx0 : w->x;
        int cy0 = (w->y < ry0) ? ry0 : w->y;
        int cx1 = (w->x + w->w - 1 > rx1) ? rx1 : w->x + w->w - 1;
        int cy1 = (w->y + w->h - 1 > ry1) ? ry1 : w->y + w->h - 1;
        fb_set_clip(cx0, cy0, cx1, cy1);
        draw_window(w);
        fb_set_clip(rx0, ry0, rx1, ry1);
    }

    if (ry1 >= (int)H - TBAR_H) {
        fb_set_clip(rx0, (int)H - TBAR_H, rx1, (int)H - 1);
        draw_taskbar();
    }

    if (menu_open) {
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        if (rect_intersect(mx, my, mw, mh, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_menu();
        }
    }

    if (cursor_visible) {
        if (rect_intersect(cur_x, cur_y, 12, 19, rx0, ry0, rx1 - rx0 + 1, ry1 - ry0 + 1)) {
            fb_set_clip(rx0, ry0, rx1, ry1);
            draw_cursor();
        }
    }

    fb_set_clip(0, 0, (int)W - 1, (int)H - 1);
}

void wm_frame(void)
{
    /* отложенные закрытия — до отрисовки */
    if (pending_close) {
        for (int i = 0; i < nwin; i++) {
            if (wins[i] == pending_close) {
                for (int j = i; j < nwin - 1; j++) wins[j] = wins[j + 1];
                nwin--;
                break;
            }
        }
        if (pending_close->on_close) pending_close->on_close(pending_close);
        free(pending_close);
        pending_close = NULL;
        fb_touch_all();
    }

    if (!fb_ready()) return;

    int rx0, ry0, rx1, ry1;
    if (!fb_dirty(&rx0, &ry0, &rx1, &ry1)) return;

    fb_mark_disable();
    composite(rx0, ry0, rx1, ry1);
    fb_mark_enable();
    fb_flush();
}

/* ------------------------------- события ------------------------------- */

void wm_key(const key_event_t *ev)
{
    if (nwin == 0) return;
    window_t *w = wins[nwin - 1]; /* верхнее окно в фокусе */
    if (w->on_key) w->on_key(w, ev);
}

static void start_button_rect(int *bx, int *by, int *bw, int *bh)
{
    *bx = 4; *by = (int)fb_height() - 24; *bw = 64; *bh = 20;
}

void wm_mouse_poll(void)
{
    if (!ms_event) return;
    ms_event = 0;

    int x = ms_x, y = ms_y;
    static u8 prev_btn = 0;
    u8 btn = ms_buttons;
    u8 changed = (u8)(btn ^ prev_btn);
    prev_btn = btn;

    /* области курсора: старая и новая */
    if (cursor_visible) fb_touch(cur_x, cur_y, 12, 19);
    cur_x = x; cur_y = y;
    if (cursor_visible) fb_touch(x, y, 12, 19);

    /* --- перетаскивание окна --- */
    if (drag_win && (btn & MSB_LEFT)) {
        int nx = x - drag_dx;
        int ny = y - drag_dy;
        int maxx = (int)fb_width() - 60;
        int maxy = (int)fb_height() - TBAR_H - TITLE_H;
        if (nx > maxx) nx = maxx;
        if (ny > maxy) ny = maxy;
        if (nx < -(drag_win->w - 60)) nx = -(drag_win->w - 60);
        if (ny < 0) ny = 0;
        if (nx != drag_win->x || ny != drag_win->y) {
            fb_touch(drag_win->x, drag_win->y, drag_win->w, drag_win->h);
            fb_touch(nx, ny, drag_win->w, drag_win->h);
            drag_win->x = nx;
            drag_win->y = ny;
        }
        if (changed & MSB_LEFT) { /* отпущено и нажато одновременно — не бывает */ }
        return;
    }
    if (drag_win && !(btn & MSB_LEFT)) {
        drag_win = NULL;
    }

    /* --- нажатие ЛКМ --- */
    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
        /* меню открыто? */
        if (menu_open) {
            int mx, my, mw, mh;
            menu_rect(&mx, &my, &mw, &mh);
            int idx = menu_hit(x, y);
            menu_open = 0;
            menu_hover = -1;
            fb_touch(mx, my, mw, mh);
            if (idx >= 0) {
                menu_action(idx);
                return;
            }
            /* клик вне меню — обрабатывается дальше */
        }

        int bx, by, bw, bh;
        start_button_rect(&bx, &by, &bw, &bh);
        if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
            menu_open = !menu_open;
            menu_hover = -1;
            if (menu_open) {
                int mx, my, mw, mh;
                menu_rect(&mx, &my, &mw, &mh);
                fb_touch(mx, my, mw, mh);
            }
            fb_touch(bx, by, bw, bh);
            return;
        }

        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            raise_window(wi);
            if (y < w->y + TITLE_H) {
                int cbx = w->x + w->w - 22, cby = w->y + 4;
                if (x >= cbx && x < cbx + 18 && y >= cby && y < cby + 16) {
                    pending_close = w;
                    fb_touch(cbx, cby, 18, 16);
                } else {
                    drag_win = w;
                    drag_dx = x - w->x;
                    drag_dy = y - w->y;
                }
                return;
            }
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (w->on_mouse && x >= cx && x < cx + cw && y >= cy && y < cy + ch)
                w->on_mouse(w, x - cx, y - cy, btn, changed);
            return;
        }
        return;
    }

    /* --- отпускание ЛКМ --- */
    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT)) {
        if (pending_close) {
            window_t *w = pending_close;
            int cbx = w->x + w->w - 22, cby = w->y + 4;
            if (x >= cbx && x < cbx + 18 && y >= cby && y < cby + 16 &&
                window_at(x, y) >= 0) {
                win_close(w);
            } else {
                pending_close = NULL;
                fb_touch(cbx, cby, 18, 16);
            }
        }
        /* отдаём отпускание приложению */
        int wi = window_at(x, y);
        if (wi >= 0) {
            window_t *w = wins[wi];
            int cx, cy, cw, ch;
            win_content_rect(w, &cx, &cy, &cw, &ch);
            if (w->on_mouse && x >= cx && x < cx + cw && y >= cy && y < cy + ch)
                w->on_mouse(w, x - cx, y - cy, btn, changed);
        }
        return;
    }

    /* --- просто движение / hover меню --- */
    if (menu_open) {
        int mx, my, mw, mh;
        menu_rect(&mx, &my, &mw, &mh);
        int hov = menu_hit(x, y);
        if (hov != menu_hover) {
            menu_hover = hov;
            fb_touch(mx, my, mw, mh);
        }
        return;
    }

    /* движение над окном — отдаём приложению (для рисования мышью) */
    int wi = window_at(x, y);
    if (wi >= 0) {
        window_t *w = wins[wi];
        int cx, cy, cw, ch;
        win_content_rect(w, &cx, &cy, &cw, &ch);
        if (w->on_mouse && x >= cx && x < cx + cw && y >= cy && y < cy + ch)
            w->on_mouse(w, x - cx, y - cy, btn, changed);
    }
}

void wm_halfsec(void)
{
    blink_state ^= 1;

    for (int i = 0; i < nwin; i++)
        if (wins[i]->on_tick) wins[i]->on_tick(wins[i]);

    /* часы в таскбаре */
    static int last_sec = -1;
    int h, m, s;
    rtc_get_time(&h, &m, &s);
    if (s != last_sec) {
        last_sec = s;
        fb_touch(0, (int)fb_height() - TBAR_H, (int)fb_width(), TBAR_H);
    }
}

/* -------------------------------- API -------------------------------- */

window_t *win_create(const char *title, int x, int y, int ww, int wh,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data)
{
    if (nwin >= WM_MAX_WINDOWS) return NULL;

    window_t *w = (window_t *)malloc(sizeof(window_t));
    if (!w) return NULL;

    memset(w, 0, sizeof(window_t));
    strncpy(w->title, title, sizeof(w->title) - 1);
    w->draw = draw;
    w->on_key = on_key;
    w->on_mouse = on_mouse;
    w->on_tick = on_tick;
    w->on_close = on_close;
    w->data = data;

    /* геометрия: не даём окну выйти за экран */
    u32 W = fb_width(), H = fb_height();
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x + ww > (int)W) x = (int)W - ww;
    if (y + wh > (int)H - TBAR_H) y = (int)H - TBAR_H - wh;
    w->x = x; w->y = y;
    w->w = ww; w->h = wh;

    wins[nwin++] = w;      /* наверх стека */
    fb_touch_all();        /* изменился список окон — полный кадр */
    return w;
}

void win_close(window_t *w)
{
    if (w) pending_close = w;
}

void win_invalidate(window_t *w)
{
    if (w) fb_touch(w->x, w->y, w->w, w->h);
}

void wm_init(void)
{
    nwin = 0;
    drag_win = NULL;
    pending_close = NULL;
    menu_open = 0;
    menu_hover = -1;
    cursor_visible = mouse_present();
    cur_x = (int)fb_width() / 2;
    cur_y = (int)fb_height() / 2;
    ms_x = cur_x;
    ms_y = cur_y;
}

int wm_blink(void) { return blink_state; }

int wm_window_count(void) { return nwin; }

const char *wm_window_title(int i)
{
    return (i >= 0 && i < nwin) ? wins[i]->title : "";
}
