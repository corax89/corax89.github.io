/* apps_wifi.c — графическая утилита сканирования WiFi точек доступа.
 *
 * Показывает список найденных точек доступа (SSID, BSSID, RSSI, канал,
 * безопасность). Кнопка [Scan] запускает сканирование (2.8 секунды
 * на 14 каналов по 200ms на каждый).
 *
 * Данные берутся из ath9k_wifi.c (драйвер Atheros AR9285/AR9485).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "mem.h"
#include "string.h"
#include "ath9k_wifi.h"
#include "timer.h"
#include "task.h"

#define WIFI_ROWS 18
#define WIFI_COLS 76
#define WIFI_HDR 22
#define WIFI_BTN_W 80
#define WIFI_BTN_H 18

typedef struct {
    wifi_ap_t aps[WIFI_MAX_APS];
    int  ap_count;
    int  sel;
    int  scroll;
    int  scanning;
    int  scan_progress;
    int  btn_hot;
    int  btn_pressed;
} wifi_mgr_t;

static void wifi_status(wifi_mgr_t *m, const char *msg) {
    (void)m; (void)msg;  /* пока без status bar */
}

static void wifi_start_scan(wifi_mgr_t *m) {
    if (m->scanning) return;
    if (!wifi_present()) return;
    m->scanning = 1;
    m->scan_progress = 0;
    m->ap_count = 0;
    wifi_scan_start();
}

static void wifi_draw_btn(int idx, const char *label, int hot, int pressed) {
    int bx = 4 + idx * (WIFI_BTN_W + 4);
    int by = 2;
    u32 bg = pressed ? fb_rgb(0x4A, 0x7F, 0xB0) :
             hot ? fb_rgb(0x32, 0x60, 0x8E) :
             fb_rgb(0x25, 0x4A, 0x70);
    fb_fill_rect(bx, by, WIFI_BTN_W, WIFI_BTN_H, bg);
    fb_rect(bx, by, WIFI_BTN_W, WIFI_BTN_H, fb_rgb(0x6F, 0xB3, 0xF2));
    int tw = (int)strlen(label) * 8;
    fb_text(bx + (WIFI_BTN_W - tw) / 2, by + 1, label, fb_rgb(0xE6, 0xEA, 0xEE), -1);
}

static const char *security_str(int encrypted) {
    return encrypted ? "WEP/WPA" : "Open";
}

static void wifi_draw_bars(int x, int y, i8 rssi) {
    int bars = 0;
    if (rssi > -50) bars = 5;
    else if (rssi > -60) bars = 4;
    else if (rssi > -70) bars = 3;
    else if (rssi > -80) bars = 2;
    else bars = 1;
    u32 colors[] = { fb_rgb(0xFF, 0x60, 0x60), fb_rgb(0xFF, 0xA0, 0x60),
                    fb_rgb(0xFF, 0xE0, 0x60), fb_rgb(0x90, 0xEE, 0x90),
                    fb_rgb(0x60, 0xE0, 0x60) };
    for (int i = 0; i < 5; i++) {
        int h = 4 + i * 3;
        u32 c = (i < bars) ? colors[i] : fb_rgb(0x30, 0x30, 0x30);
        fb_fill_rect(x + i * 5, y + (15 - h), 4, h, c);
    }
}

static void wifi_draw(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* Шапка */
    fb_fill_rect(0, 0, cw, WIFI_HDR, fb_rgb(0x1E, 0x4A, 0x73));
    wifi_draw_btn(0, "Scan", m->btn_hot == 0, m->btn_pressed == 0);
    
    const char *chip = wifi_present() ? wifi_chip_name() : "No WiFi adapter";
    fb_text(100, 5, chip, fb_rgb(0xC6, 0xCD, 0xD5), -1);
    
    if (m->scanning) {
        char pbar[80];
        snprintf(pbar, sizeof(pbar), "Scanning... channel %d/14", m->scan_progress + 1);
        fb_text(100, 5 + 8, pbar, fb_rgb(0xFF, 0xE0, 0x60), -1);
        /* Progress bar */
        int pw = (cw - 8) * (m->scan_progress + 1) / 14;
        fb_fill_rect(4, WIFI_HDR - 4, pw, 2, fb_rgb(0x90, 0xEE, 0x90));
    }

    /* Заголовки колонок */
    int y0 = WIFI_HDR;
    fb_fill_rect(0, y0, cw, 18, fb_rgb(0x14, 0x18, 0x1E));
    fb_text(4, y0 + 1, "SSID                  BSSID               RSSI  Ch  Security",
            fb_rgb(0xC6, 0xCD, 0xD5), -1);

    /* Список AP */
    int area_y0 = y0 + 18;
    int area_h = ch - area_y0 - 14;
    int vis = area_h / 18;
    if (vis < 1) vis = 1;
    fb_fill_rect(0, area_y0, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    if (!wifi_present()) {
        fb_text(12, area_y0 + 10, "WiFi adapter not found", fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, area_y0 + 30, "Atheros AR9285/AR9485 required", fb_rgb(0x8A, 0x93, 0x9C), -1);
    } else if (m->ap_count == 0 && !m->scanning) {
        fb_text(12, area_y0 + 10, "No access points found", fb_rgb(0x8A, 0x93, 0x9C), -1);
        fb_text(12, area_y0 + 30, "Click [Scan] to start scanning", fb_rgb(0x6F, 0xB3, 0xF2), -1);
    } else {
        int vis_max = (vis < m->ap_count) ? vis : m->ap_count;
        int y = area_y0 + 2;
        for (int i = 0; i < vis_max; i++) {
            int idx = m->scroll + i;
            if (idx >= m->ap_count) break;
            wifi_ap_t *ap = &m->aps[idx];
            char line[200];
            /* SSID (20 chars max) */
            char ssid[21];
            int sl = (int)strlen(ap->ssid);
            if (sl > 20) sl = 20;
            memcpy(ssid, ap->ssid, sl);
            ssid[sl] = 0;
            /* BSSID */
            char mac[20];
            snprintf(mac, sizeof(mac), "%02x:%02x:%02x:%02x:%02x:%02x",
                     ap->bssid[0], ap->bssid[1], ap->bssid[2],
                     ap->bssid[3], ap->bssid[4], ap->bssid[5]);
            snprintf(line, sizeof(line), "%-20s  %-17s  %4d  %2d  %s",
                     ssid, mac, (int)ap->rssi, (int)ap->channel,
                     security_str(ap->encrypted));
            u32 fg = (ap->encrypted) ? fb_rgb(0xC6, 0xCD, 0xD5) : fb_rgb(0x90, 0xEE, 0x90);
            int is_sel = (i == (m->sel - m->scroll));
            if (is_sel) fb_fill_rect(0, y, cw, 18, fb_rgb(0x24, 0x43, 0x5F));
            fb_text(4, y, line, fg, -1);
            /* Signal bars */
            wifi_draw_bars(cw - 40, y + 1, ap->rssi);
            y += 18;
        }
    }

    /* Статус-строка */
    fb_fill_rect(0, ch - 14, cw, 14, fb_rgb(0x12, 0x16, 0x1B));
    char st[120];
    if (m->scanning)
        snprintf(st, sizeof(st), "Scanning... %d AP found | uptime %u sec",
                 m->ap_count, (unsigned)uptime_sec());
    else
        snprintf(st, sizeof(st), "%d access points | F1=Scan, Up/Dn=navigate, Esc=close",
                 m->ap_count);
    fb_text(4, ch - 12, st, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void wifi_tick(window_t *w) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    if (m->scanning) {
        if (wifi_scan_active()) {
            /* Update progress */
            /* Read current results */
            m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
            /* Estimate progress */
            u32 elapsed = uptime_sec();
            (void)elapsed;
            m->scan_progress = (m->scan_progress + 1) % 14;
        } else {
            /* Scan completed */
            m->scanning = 0;
            m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
        }
    }
    win_invalidate(w);
}

static void wifi_key(window_t *w, const key_event_t *ev) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    
    if (ev->code == 0x3B || ev->ch == 's' || ev->ch == 'S') {  /* F1 or S */
        wifi_start_scan(m);
        win_invalidate(w);
        return;
    }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == KBD_UP) {
        if (m->sel > 0) m->sel--;
        win_invalidate(w);
    }
    if (ev->code == KBD_DOWN) {
        if (m->sel + 1 < m->ap_count) m->sel++;
        win_invalidate(w);
    }
}

static void wifi_mouse(window_t *w, int mx, int my, u8 btn, u8 changed) {
    wifi_mgr_t *m = (wifi_mgr_t *)w->data;
    
    if (my < WIFI_HDR) {
        /* Button area */
        if (my >= 2 && my < 2 + WIFI_BTN_H) {
            int bx = 4;
            for (int i = 0; i < 1; i++) {
                if (mx >= bx && mx < bx + WIFI_BTN_W) {
                    if ((changed & MSB_LEFT) && (btn & MSB_LEFT)) {
                        m->btn_pressed = i;
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT) && m->btn_pressed == i) {
                        m->btn_pressed = -1;
                        wifi_start_scan(m);
                    }
                    if (m->btn_hot != i) {
                        m->btn_hot = i;
                        win_invalidate(w);
                    }
                    if ((changed & MSB_LEFT) && !(btn & MSB_LEFT))
                        win_invalidate(w);
                    return;
                }
                bx += WIFI_BTN_W + 4;
            }
        }
        if (m->btn_hot != -1 || m->btn_pressed != -1) {
            m->btn_hot = -1;
            m->btn_pressed = -1;
            win_invalidate(w);
        }
        return;
    }
}

static void wifi_close(window_t *w) {
    if (w->data) free(w->data);
}

void app_wifi_open(void) {
    wifi_mgr_t *m = (wifi_mgr_t *)malloc(sizeof(wifi_mgr_t));
    if (!m) return;
    memset(m, 0, sizeof(wifi_mgr_t));
    m->btn_hot = -1;
    m->btn_pressed = -1;
    
    /* Загружаем текущие результаты (если драйвер уже отсканировал) */
    m->ap_count = wifi_scan_results(m->aps, WIFI_MAX_APS);
    
    u32 W = fb_width(), H = fb_height();
    int ww = WIFI_COLS * 8 + 12;
    int wh = WIFI_ROWS * 18 + WIFI_HDR + 18 + 14 + 24 + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    
    win_create("WiFi Scanner", 120, 30, ww, wh,
               wifi_draw, wifi_key, wifi_mouse, wifi_tick, wifi_close, m);
}
