/* io.h — минимальные ассемблерные вставки для доступа к портам и привилегированным
 * инструкциям. Это ЕДИНСТВЕННОЕ место в системе с машинными командами вне «чистого C»:
 * в языке C просто не существует инструкций in/out/cli/hlt/lidt. Вся логика ОС — на C.
 */
#ifndef IO_H
#define IO_H

#include "types.h"

static inline void outb(u16 port, u8 val)
{
    __asm__ __volatile__("outb %b0, %w1" :: "a"(val), "Nd"(port));
}

static inline u8 inb(u16 port)
{
    u8 r;
    __asm__ __volatile__("inb %w1, %b0" : "=a"(r) : "Nd"(port));
    return r;
}

static inline void outw(u16 port, u16 val)
{
    __asm__ __volatile__("outw %w0, %w1" :: "a"(val), "Nd"(port));
}

static inline u16 inw(u16 port)
{
    u16 r;
    __asm__ __volatile__("inw %w1, %w0" : "=a"(r) : "Nd"(port));
    return r;
}

/* небольшая задержка для старых чипсетов */
static inline void io_wait(void)
{
    outb(0x80, 0);
}

static inline void cli(void) { __asm__ __volatile__("cli"); }
static inline void sti(void) { __asm__ __volatile__("sti"); }
static inline void hlt(void) { __asm__ __volatile__("hlt"); }

/* регистры таблиц дескрипторов: {u16 лимит; u32 база} */
struct dt_ptr {
    u16 limit;
    u32 base;
} __attribute__((packed));

static inline void lgdt_load(const struct dt_ptr *p)
{
    __asm__ __volatile__("lgdt %0\n"
                         "ljmp $0x08, $1f\n"
                         "1:\n"
                         "movw $0x10, %%ax\n"
                         "movw %%ax, %%ds\n"
                         "movw %%ax, %%es\n"
                         "movw %%ax, %%ss\n"
                         "movw %%ax, %%fs\n"
                         "movw %%ax, %%gs"
                         :: "m"(*p) : "ax", "memory");
}

static inline void lidt_load(const struct dt_ptr *p)
{
    __asm__ __volatile__("lidt %0" :: "m"(*p) : "memory");
}

#endif /* IO_H */
