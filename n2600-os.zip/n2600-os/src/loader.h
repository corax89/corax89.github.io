/* loader.h — запуск приложений с диска (flat binary) */
#ifndef LOADER_H
#define LOADER_H

#include "types.h"
#include "kapi.h"

struct window;

/* Загрузить бинарник из RAMFS и запустить его в новой задаче.
 * Возвращает индекс задачи (>=1) или -1 при ошибке.
 * name — имя файла в RAMFS (например "hello.bin").
 * win  — окно, в которое приложение будет рисовать (передаётся в entry).
 */
int  loader_spawn(const char *name, struct window *win);

/* Загрузить бинарник в память и вернуть адрес точки входа (или NULL).
 * Буфер остаётся выделенным до конца задачи. */
void *loader_load(const char *name, u32 *out_size);

/* Заполнить kapi_t указателями на функции ядра. */
void kapi_fill(kapi_t *k);

#endif
