/* timer.c — PIT (канал 0) на 100 Гц */
#include "timer.h"
#include "io.h"
#include "idt.h"

static volatile u32 ticks = 0;

static void timer_irq(void)
{
    ticks++;
}

void timer_init(int hz)
{
    if (hz < 20) hz = 20;
    if (hz > 1000) hz = 1000;
    u32 div = 1193182u / (u32)hz;
    outb(0x43, 0x36);                 /* канал 0, режим 3, binary */
    outb(0x40, (u8)(div & 0xFF));
    outb(0x40, (u8)(div >> 8));
    irq_install(0, timer_irq);
}

u32 timer_ticks(void) { return ticks; }
u32 uptime_sec(void)  { return ticks / 100; }
