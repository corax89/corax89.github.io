/* loader.c — загрузчик flat-binary приложений с диска.
 *
 * Простая модель: приложение представляет собой скомпилированный
 * в flat-binary машинный код, экспортирующий точку входа:
 *
 *     void entry(kapi_t *k, struct window *w);
 *
 * Загрузчик:
 *   1) читает файл из RAMFS в malloc-буфер (исполняемый, т.к. NX нет на x86-32);
 *   2) валидирует первые байты (должны быть prologue + jmp/call)
 *   3) создаёт kapi_t с указателями на функции ядра;
 *   4) порождает новую задачу через task_spawn();
 *   5) задача вызывает entry(&kapi, win) под защитой setjmp —
 *      если приложение вызывает исключение CPU, задача завершается
 *      корректно, а ядро продолжает работать.
 */
#include "loader.h"
#include "kapi.h"
#include "task.h"
#include "mem.h"
#include "ramfs.h"
#include "string.h"
#include "fb.h"
#include "wm.h"
#include "timer.h"
#include "kernel.h"
#include "c4.h"
#include "kbd.h"
#include "idt.h"

extern void serial_puts(const char *s);

typedef struct {
    void (*entry)(kapi_t *k, void *win);
    kapi_t  kapi;
    void   *win;
    void   *code;     /* загруженный машинный код (освобождается в on_done) */
    u32     code_size;
} loader_ctx_t;

/* ===================== Защита от падения приложений ===================== */
/* Глобальный setjmp-буфер для текущего выполняемого приложения.
 * Если != NULL, exc_panic (в idt.c) делает longjmp сюда вместо halt. */
static void *g_app_jmp[16] = {0};   /* __builtin_jmp_buf */
static int   g_app_active = 0;
static u32   g_app_exc_num = 0;

/* Получить адрес jmp-буфера (для idt.c) */
void **loader_get_app_jmp(void)
{
    return g_app_active ? g_app_jmp : NULL;
}

/* Установить/снять флаг активного приложения */
void loader_set_app_active(int active, u32 exc_num)
{
    g_app_active = active;
    g_app_exc_num = exc_num;
}

/* Заполняем таблицу API ядра для передаваемого приложения. */
void kapi_fill(kapi_t *k)
{
    k->fb_fill_rect  = fb_fill_rect;
    k->fb_rect       = fb_rect;
    k->fb_hline      = fb_hline;
    k->fb_text       = fb_text;
    k->fb_char       = fb_char;
    k->fb_rgb        = fb_rgb;
    k->fb_width      = fb_width;
    k->fb_height     = fb_height;
    k->fb_fill_screen = fb_fill_screen;
    k->win_content_w = win_content_w;
    k->win_content_h = win_content_h;
    k->win_invalidate = win_invalidate;
    k->malloc        = malloc;
    k->free          = free;
    k->uptime_sec    = uptime_sec;
    k->timer_ticks   = timer_ticks;
    k->task_yield    = task_yield;
    k->task_spawn    = task_spawn;
    k->snprintf      = snprintf;
    k->strlen        = strlen;
    k->strcmp        = strcmp;
    k->strcpy        = strcpy;
    k->memcmp        = memcmp;
    k->memset        = memset;
    k->memcpy        = memcpy;
    k->c4_print_str  = c4_print_str;
    k->c4_event_poll = c4_event_poll;
    k->c4_printf_va  = c4_printf_va;
}

void *loader_load(const char *name, u32 *out_size)
{
    if (!ramfs_ready() || !name) return NULL;

    /* Сначала узнаем размер (через list — find-функции в ramfs нет в публичном API). */
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    u32 size = 0;
    int found = 0;
    for (int i = 0; i < n; i++) {
        if (strcmp(ents[i].name, name) == 0) {
            size = ents[i].size;
            found = 1;
            break;
        }
    }
    if (!found || size == 0) return NULL;

    u8 *buf = (u8 *)malloc(size);
    if (!buf) return NULL;
    u32 got = ramfs_read(name, buf, size);
    if (got == 0) {
        free(buf);
        return NULL;
    }
    if (out_size) *out_size = got;
    return buf;
}

/* Валидация первых байтов бинарника.
 * c4_x86 генерирует entry stub:
 *   55              push ebp
 *   89 E5           mov ebp, esp
 *   8B 7D 08        mov edi, [ebp+8]
 *   8B 75 0C        mov esi, [ebp+12]
 *   E9 ?? ?? ?? ??  jmp rel32  (к main body)
 * Проверяем первые 9 байт и 10-й = E9 (jmp) или E8 (call).
 *
 * Если бинарник сгенерирован другим компилятором (GCC flat-binary):
 *   Может начинаться с 55 89 E5 (push ebp; mov ebp,esp) — это тоже валидно. */
static int validate_binary(const u8 *code, u32 size)
{
    if (!code || size < 6) return 0;

    /* Вариант 1: c4_x86 entry stub (push ebp; mov ebp,esp; ...) */
    if (code[0] == 0x55 && code[1] == 0x89 && code[2] == 0xE5) {
        /* Стандартный prologue. Проверим что дальше что-то разумное. */
        if (size >= 10 && (code[9] == 0xE9 || code[9] == 0xE8 ||
                           code[9] == 0x83 || code[9] == 0xC7)) {
            return 1;  /* jmp rel32 / call / sub esp / mov edi */
        }
        /* Или прямой call (GCC-style): 55 89 E5 83 EC XX */
        if (size >= 6 && code[3] == 0x83 && code[4] == 0xEC) {
            return 1;
        }
        /* Минимум: prologue присутствует, дальше любой код */
        return 1;
    }

    /* Вариант 2: сразу jump/call (если бинарник начинается с перехода) */
    if (code[0] == 0xE9 || code[0] == 0xE8) return 1;

    /* Вариант 3: mov edi, imm32 (B8) — тоже валидный старт */
    if (code[0] == 0xB8) return 1;

    /* Вариант 4: первые байты — NOP (90) или push (50-5F) */
    if (code[0] == 0x90) return 1;
    if (code[0] >= 0x50 && code[0] <= 0x5F) return 1;

    return 0;  /* невалидный старт */
}

/* Тело новой задачи: вызвать entry() под защитой setjmp, затем завершить. */
static void loader_task_fn(void *arg)
{
    loader_ctx_t *ctx = (loader_ctx_t *)arg;

    /* Устанавливаем setjmp для перехвата исключений.
     * Если приложение вызовет #GP/#PF/#UD и т.д., exc_panic
     * (в idt.c) сделает __builtin_longjmp(g_app_jmp, 1)
     * вместо halt — и мы попадём сюда, после if. */
    if (__builtin_setjmp(g_app_jmp) == 0) {
        /* Нормальный путь: выполняем приложение */
        loader_set_app_active(1, 0);
        if (ctx->entry) ctx->entry(&ctx->kapi, ctx->win);
        loader_set_app_active(0, 0);
    } else {
        /* Исключение в приложении! exc_panic сделал longjmp сюда. */
        loader_set_app_active(0, g_app_exc_num);
        serial_puts("[loader] app crashed (exception caught)\n");
        /* Выводим сообщение на экран */
        if (fb_ready()) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf), "App crashed: exc #%u", (unsigned)g_app_exc_num);
            fb_fill_rect(0, fb_height() - 60, 400, 20, fb_rgb(0x80, 0x10, 0x10));
            fb_text(4, fb_height() - 56, buf, fb_rgb(0xFF, 0xFF, 0xFF), -1);
            fb_touch_all();
            fb_flush();
        }
    }

    /* Освобождаем выделенную под код память */
    if (ctx->code) free(ctx->code);
    free(ctx);
    task_exit();
}

int loader_spawn(const char *name, struct window *win)
{
    u32 size = 0;
    void *code = loader_load(name, &size);
    if (!code) return -1;

    /* Валидация */
    if (!validate_binary((const u8 *)code, size)) {
        char msg[80];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        serial_puts("[loader] binary validation failed\n");
        /* Покажем первые байты для диагностики */
        {
            char hex[40];
            int p = 0;
            for (int i = 0; i < 8 && i < (int)size; i++)
                p += snprintf(hex + p, sizeof(hex) - p, "%02x ",
                               (unsigned)((u8 *)code)[i]);
            serial_puts("[loader] first bytes: ");
            serial_puts(hex);
            serial_puts("\n");
        }
        free(code);
        return -1;
    }

    loader_ctx_t *ctx = (loader_ctx_t *)malloc(sizeof(loader_ctx_t));
    if (!ctx) {
        free(code);
        return -1;
    }
    kapi_fill(&ctx->kapi);
    ctx->entry = (void (*)(kapi_t *, void *))code;
    ctx->win   = win;
    ctx->code  = code;
    ctx->code_size = size;

    int tid = task_spawn(name, loader_task_fn, ctx);
    if (tid < 0) {
        free(code);
        free(ctx);
        return -1;
    }
    return tid;
}
