/* ath9k_wifi.h — драйвер Atheros AR9285/AR9485 WiFi для N2600-OS.
 *
 * Реализован на основе открытых драйверов:
 *   - Linux ath9k (GPL): drivers/net/wireless/ath/ath9k/
 *   - FreeBSD ath (BSD): sys/dev/ath/
 *
 * Поддерживается:
 *   - PCI-детекция Atheros WiFi (vendor 0x168c)
 *   - AR9285 (device 0x002e): не требует firmware
 *   - AR9485 (device 0x0032): требует firmware (не реализовано)
 *   - Чип reset и инициализация
 *   - Установка канала (2.4 GHz, каналы 1-14)
 *   - Пассивное сканирование (приём beacon-кадров)
 *   - Парсинг beacon: SSID, BSSID, RSSI, канал
 *
 * Что НЕ реализовано:
 *   - Передача данных (TX)
 *   - Аутентификация / ассоциация
 *   - Шифрование (WEP/WPA/WPA2)
 *   - DMA (используется polling PIO вместо DMA)
 *   - Прерывания (polling из основного цикла)
 *   - Firmware для AR9485 (только AR9285 работает полностью)
 *
 * Графическая утилита: apps_wifi.c — список точек доступа.
 */
#ifndef ATH9K_WIFI_H
#define ATH9K_WIFI_H

#include "types.h"

#define WIFI_MAX_APS 32

typedef struct {
    char     ssid[33];       /* SSID (NUL-terminated) */
    u8       bssid[6];       /* BSSID (MAC адрес точки) */
    i8       rssi;           /* Signal strength (dBm, отрицательное) */
    u8       channel;        /* Номер канала (1-14) */
    u8       beacon_interval; /* Интервал beacon (в 1024 us единицах) */
    u16      capability;     /* Capability info */
    u8       encrypted;      /* 1 = сеть зашифрована */
} wifi_ap_t;

void wifi_init(void);
void wifi_scan_start(void);
int  wifi_scan_active(void);
int  wifi_scan_results(wifi_ap_t *out, int max);
int  wifi_present(void);
const char *wifi_chip_name(void);
void wifi_poll(void);

#endif /* ATH9K_WIFI_H */
