/* kernel.h — глобальные службы ядра */
#ifndef KERNEL_H
#define KERNEL_H

#include "types.h"
#include "boot.h"

const mb_info_t *mb_info(void);
void sys_reboot(void);
void sys_poweroff(void);

#endif
