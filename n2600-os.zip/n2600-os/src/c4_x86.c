/* c4_x86.c — x86-кодогенератор: превращает байт-код c4 в настоящий
 * flat-binary исполняемый файл для N2600-OS.
 *
 * Идея:
 *   1) c4.c парсит исходник и строит IR (байт-код) в пуле `e`.
 *   2) Этот файл проходит по IR и эмитит эквивалентный x86 машинный код.
 *   3) Результат — flat-binary с точкой входа void entry(kapi_t *k, void *win),
 *      который запускается через loader_spawn() как обычное приложение.
 *
 * Соглашения по регистрам (32-bit cdecl):
 *   EAX = аккумулятор "a" (в c4 VM)
 *   ESP = виртуальный стек (по 4 байта на ячейку, как в c4)
 *   EBP = base pointer "bp" (для локальных переменных)
 *   EDI = сохранённый указатель kapi_t* (передаётся при entry)
 *   ESI = сохранённый указатель win (передаётся при entry)
 *
 * Вызовы к ядру идут через kapi: для каждого syscall (MALC, KFILL и т.д.)
 * эмитится код, который грузит указатель функции из kapi по смещению
 * и вызывает её. Согпадение по calling convention с c4 VM: аргументы
 * кладутся на стек в обратном порядке (как cdecl).
 *
 * Однопроходная генерация с отложенным патчем jumps:
 *   - Эмитим инструкции последовательно, отслеживая bc_cell → x86_offset.
 *   - При встрече jump/call записываем src_offset (где rel32) и target_bc.
 *   - После прохода патчим все rel32 по известной карте.
 */
#include "c4.h"
#include "kapi.h"
#include "types.h"
#include "string.h"
#include "mem.h"
#include "ramfs.h"
#include "loader.h"

extern void serial_puts(const char *s);

/* ---------- opcode enum (должен совпадать с c4.c) ---------- */
enum {
  LEA, IMM, JMP, JSR, BZ, BNZ, ENT, ADJ, LEV, LI, LC, SI, SC, PSH,
  OR, XOR, AND, EQ, NE, LT, GT, LE, GE, SHL, SHR, ADD, SUB, MUL, DIV, MOD,
  OPEN, READ, CLOS, PRTF, MALC, FREE, MSET, MCMP, EXIT,
  KINIT, KQUIT, KDELAY, KFILL, KTEXT, KFLIP, KRGB, KEVENT,
  KCLEAR, KW, KH, KMTIME,
  STRLEN, STRCPY, STRCMP
};

/* Смещения полей в kapi_t (в байтах, чтобы генерировать [edi+offset]). */
#define KAPI_FB_FILL_RECT    0
#define KAPI_FB_RECT         4
#define KAPI_FB_HLINE        8
#define KAPI_FB_TEXT         12
#define KAPI_FB_CHAR         16
#define KAPI_FB_RGB          20
#define KAPI_FB_WIDTH        24
#define KAPI_FB_HEIGHT       28
#define KAPI_FB_FILL_SCREEN  32
#define KAPI_WIN_CONTENT_W   36
#define KAPI_WIN_CONTENT_H   40
#define KAPI_WIN_INVALIDATE  44
#define KAPI_MALLOC          48
#define KAPI_FREE            52
#define KAPI_UPTIME_SEC      56
#define KAPI_TIMER_TICKS     60
#define KAPI_TASK_YIELD      64
#define KAPI_TASK_SPAWN      68
#define KAPI_SNPRINTF        72
#define KAPI_STRLEN          76
#define KAPI_STRCMP          80
#define KAPI_STRCPY         84
#define KAPI_MEMCMP          88
#define KAPI_MEMSET          92
#define KAPI_MEMCPY          96
#define KAPI_C4_PRINT_STR    100
#define KAPI_C4_EVENT_POLL   104
#define KAPI_C4_PRINTF_VA    108

/* ---------- эмиттер x86 машинного кода ---------- */
typedef struct {
    u8 *buf;
    u32 pos;
    u32 cap;
} emitter_t;

static inline void em1(emitter_t *em, u8 b) {
    if (em->pos < em->cap) em->buf[em->pos++] = b;
}
static inline void em4(emitter_t *em, u32 v) {
    em1(em, v & 0xFF);
    em1(em, (v >> 8) & 0xFF);
    em1(em, (v >> 16) & 0xFF);
    em1(em, (v >> 24) & 0xFF);
}

/* push imm32: 68 imm32 */
static void em_push_imm32(emitter_t *em, u32 val) { em1(em, 0x68); em4(em, val); }
/* push eax: 50 */
static void em_push_eax(emitter_t *em) { em1(em, 0x50); }
/* pop eax: 58 */
static void em_pop_eax(emitter_t *em) { em1(em, 0x58); }
/* pop ecx: 59 */
static void em_pop_ecx(emitter_t *em) { em1(em, 0x59); }
/* mov eax, imm32: B8 imm32 */
static void em_mov_eax_imm32(emitter_t *em, u32 val) { em1(em, 0xB8); em4(em, val); }
/* mov eax, [eax]: 8B 00 (load int through pointer) */
static void em_mov_eax_deref_eax(emitter_t *em) { em1(em, 0x8B); em1(em, 0x00); }
/* movzx eax, byte [eax]: 0F B6 00 (load char through pointer, zero-extended) */
static void em_movzx_eax_byte_deref_eax(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xB6); em1(em, 0x00);
}
/* mov [ecx], eax: 89 01 (store int) */
static void em_mov_deref_ecx_eax(emitter_t *em) { em1(em, 0x89); em1(em, 0x01); }
/* mov [ecx], al: 88 01 (store char) */
static void em_mov_deref_ecx_al(emitter_t *em) { em1(em, 0x88); em1(em, 0x01); }
/* movzx eax, al: 0F B6 C0 (zero-extend al to eax) */
static void em_movzx_eax_al(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xB6); em1(em, 0xC0);
}

/* Арифметика: pop ecx; <op> eax, ecx */
static void em_add_eax_ecx(emitter_t *em) { em1(em, 0x01); em1(em, 0xC8); }
static void em_sub_eax_ecx(emitter_t *em) { em1(em, 0x29); em1(em, 0xC8); }
static void em_imul_eax_ecx(emitter_t *em) { em1(em, 0x0F); em1(em, 0xAF); em1(em, 0xC1); }
static void em_xor_eax_ecx(emitter_t *em) { em1(em, 0x31); em1(em, 0xC8); }
static void em_or_eax_ecx(emitter_t *em) { em1(em, 0x09); em1(em, 0xC8); }
static void em_and_eax_ecx(emitter_t *em) { em1(em, 0x21); em1(em, 0xC8); }
static void em_cdq(emitter_t *em) { em1(em, 0x99); }
static void em_idiv_ecx(emitter_t *em) { em1(em, 0xF7); em1(em, 0xF9); }
static void em_mov_eax_edx(emitter_t *em) { em1(em, 0x89); em1(em, 0xD0); }
static void em_cmp_eax_ecx(emitter_t *em) { em1(em, 0x39); em1(em, 0xC8); }
static void em_setcc_eax(emitter_t *em, u8 op) {
    em1(em, 0x0F); em1(em, op); em1(em, 0xC0);
    em1(em, 0x0F); em1(em, 0xB6); em1(em, 0xC0);
}
static void em_xchg_eax_ecx(emitter_t *em) { em1(em, 0x91); }
static void em_shl_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE0); }
static void em_shr_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE8); }
static void em_test_eax_eax(emitter_t *em) { em1(em, 0x85); em1(em, 0xC0); }

/* jmp rel32: E9 rel32 — возвращает offset поля rel32 для последующего патча */
static u32 em_jmp_rel32(emitter_t *em) {
    em1(em, 0xE9);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jz rel32: 0F 84 rel32 */
static u32 em_jz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x84);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jnz rel32: 0F 85 rel32 */
static u32 em_jnz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x85);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* call rel32: E8 rel32 */
static u32 em_call_rel32(emitter_t *em) {
    em1(em, 0xE8);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* add esp, imm8: 83 C4 imm8 */
static void em_add_esp_imm8(emitter_t *em, u8 v) { em1(em, 0x83); em1(em, 0xC4); em1(em, v); }
/* add esp, imm32: 81 C4 imm32 */
static void em_add_esp_imm32(emitter_t *em, u32 v) { em1(em, 0x81); em1(em, 0xC4); em4(em, v); }

/* enter: push ebp; mov ebp, esp; sub esp, size */
static void em_enter(emitter_t *em, u32 size) {
    em1(em, 0x55);
    em1(em, 0x89); em1(em, 0xE5);
    if (size > 0) {
        if (size <= 127) {
            em1(em, 0x83); em1(em, 0xEC); em1(em, (u8)size);
        } else {
            em1(em, 0x81); em1(em, 0xEC); em4(em, size);
        }
    }
}
/* leave; ret */
static void em_leave_ret(emitter_t *em) { em1(em, 0xC9); em1(em, 0xC3); }

/* lea eax, [ebp + disp32]: 8D 85 disp32 */
static void em_lea_eax_ebp_disp32(emitter_t *em, i32 disp) {
    em1(em, 0x8D); em1(em, 0x85); em4(em, (u32)disp);
}

/* ---------- таблица relocation ---------- */
typedef struct {
    u32 src_x86_offset;      /* где записано rel32 (подлежит патчу) */
    u32 target_bc_cell;      /* индекс int-ячейки в байт-коде */
} reloc_t;

#define MAX_RELOCS 8192
static reloc_t g_relocs[MAX_RELOCS];
static int g_n_relocs = 0;

/* ---------- карта {bc_cell → x86_offset} ---------- */
typedef struct {
    u32 bc_cell;
    u32 x86_offset;
} bc_map_t;

#define MAX_MAPS 16384
static bc_map_t g_map[MAX_MAPS];
static int g_n_maps = 0;

static u32 bc_to_x86(u32 bc_cell) {
    for (int i = 0; i < g_n_maps; i++) {
        if (g_map[i].bc_cell == bc_cell) return g_map[i].x86_offset;
    }
    return 0xFFFFFFFFu;
}

static void bc_map_add(u32 bc_cell, u32 x86_offset) {
    /* Заменяем существующую запись (на случай повторного вызова) */
    for (int i = 0; i < g_n_maps; i++) {
        if (g_map[i].bc_cell == bc_cell) {
            g_map[i].x86_offset = x86_offset;
            return;
        }
    }
    if (g_n_maps < MAX_MAPS) {
        g_map[g_n_maps].bc_cell = bc_cell;
        g_map[g_n_maps].x86_offset = x86_offset;
        g_n_maps++;
    }
}

static void add_reloc(u32 src, u32 target_bc) {
    if (g_n_relocs < MAX_RELOCS) {
        g_relocs[g_n_relocs].src_x86_offset = src;
        g_relocs[g_n_relocs].target_bc_cell = target_bc;
        g_n_relocs++;
    }
}

/* ---------- генерация syscall (вызов через kapi) ---------- */
static void emit_syscall(emitter_t *em, u32 kapi_offset, int n_args) {
    /* mov eax, [edi + kapi_offset] — load function pointer */
    if (kapi_offset <= 127) {
        em1(em, 0x8B); em1(em, 0x87); em1(em, (u8)kapi_offset);
    } else {
        em1(em, 0x8B); em1(em, 0x87); em4(em, kapi_offset);
    }
    /* call eax: FF D0 */
    em1(em, 0xFF); em1(em, 0xD0);
    /* cleanup: add esp, n_args*4 */
    u32 cleanup = (u32)n_args * 4;
    if (cleanup <= 127) em_add_esp_imm8(em, (u8)cleanup);
    else em_add_esp_imm32(em, cleanup);
    /* push eax (return value becomes "a" via subsequent PSH) */
    em_push_eax(em);
}

/* ---------- главный кодогенератор ---------- */
int c4_compile_to_native(const char *src, char *diag, u32 diag_max,
                         void *out_buf, u32 out_max, u32 *out_size)
{
    static int bc_pool[65536];           /* 256КБ — для байт-кода */
    static u8  data_pool[65536];         /* 64КБ — для сегмента данных */
    u32 bc_len_cells = 0;
    u32 data_len = 0;
    u32 entry_cells = 0;

    if (diag && diag_max) diag[0] = 0;

    if (!c4_compile(src, diag, diag_max,
                    bc_pool, sizeof(bc_pool), &bc_len_cells,
                    data_pool, sizeof(data_pool), &data_len,
                    &entry_cells)) {
        return -1;
    }

    emitter_t em = { (u8 *)out_buf, 0, out_max };
    g_n_relocs = 0;
    g_n_maps = 0;

    /* Entry stub: void entry(kapi_t *k, void *win)
     *   55            push ebp
     *   89 E5         mov ebp, esp
     *   8B 7D 08      mov edi, [ebp+8]    ; kapi
     *   8B 75 0C      mov esi, [ebp+12]   ; win
     *   E9 ?? ?? ?? ?? jmp rel32           ; -> main body
     * Total: 14 bytes
     */
    em1(&em, 0x55);                                  /* push ebp */
    em1(&em, 0x89); em1(&em, 0xE5);                   /* mov ebp, esp */
    em1(&em, 0x8B); em1(&em, 0x7D); em1(&em, 0x08);   /* mov edi, [ebp+8] */
    em1(&em, 0x8B); em1(&em, 0x75); em1(&em, 0x0C);   /* mov esi, [ebp+12] */
    u32 entry_jmp_offset = em_jmp_rel32(&em);        /* jmp main_offset (patched later) */

    /* Single pass: emit each c4 opcode as x86 */
    u32 bc = 1;  /* pool[0] is unused in c4 */
    while (bc < bc_len_cells) {
        /* Record map BEFORE emitting (so jump targets at this cell resolve here) */
        bc_map_add(bc, em.pos);

        int op = bc_pool[bc++];
        switch (op) {
            case IMM: {
                u32 val = (u32)bc_pool[bc++];
                em_push_imm32(&em, val);
                break;
            }
            case LEA: {
                i32 offset = (i32)bc_pool[bc++];
                i32 disp = offset * 4;
                em_lea_eax_ebp_disp32(&em, disp);
                em_push_eax(&em);
                break;
            }
            case JMP: {
                u32 target = (u32)bc_pool[bc++];
                u32 src = em_jmp_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case JSR: {
                u32 target = (u32)bc_pool[bc++];
                u32 src = em_call_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BZ: {
                u32 target = (u32)bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BNZ: {
                u32 target = (u32)bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jnz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case ENT: {
                u32 size = (u32)bc_pool[bc++];
                em_enter(&em, size * 4);
                break;
            }
            case ADJ: {
                u32 n = (u32)bc_pool[bc++];
                u32 cleanup = n * 4;
                if (cleanup <= 127) em_add_esp_imm8(&em, (u8)cleanup);
                else em_add_esp_imm32(&em, cleanup);
                break;
            }
            case LEV: {
                em1(&em, 0xC9); em1(&em, 0xC3);   /* leave; ret */
                break;
            }
            case LI: {
                em_mov_eax_deref_eax(&em);
                break;
            }
            case LC: {
                em_movzx_eax_byte_deref_eax(&em);
                break;
            }
            case SI: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_eax(&em);
                break;
            }
            case SC: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_al(&em);
                em_movzx_eax_al(&em);
                break;
            }
            case PSH: {
                em_push_eax(&em);
                break;
            }
            case OR:  em_pop_ecx(&em); em_or_eax_ecx(&em); break;
            case XOR: em_pop_ecx(&em); em_xor_eax_ecx(&em); break;
            case AND: em_pop_ecx(&em); em_and_eax_ecx(&em); break;
            case EQ:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x94); break;
            case NE:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x95); break;
            case LT:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9C); break;
            case GT:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9F); break;
            case LE:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9E); break;
            case GE:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9D); break;
            case SHL:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shl_eax_cl(&em);
                break;
            case SHR:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shr_eax_cl(&em);
                break;
            case ADD: em_pop_ecx(&em); em_add_eax_ecx(&em); break;
            case SUB: em_pop_ecx(&em); em_sub_eax_ecx(&em); break;
            case MUL: em_pop_ecx(&em); em_imul_eax_ecx(&em); break;
            case DIV:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_cdq(&em);
                em_idiv_ecx(&em);
                break;
            case MOD:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_cdq(&em);
                em_idiv_ecx(&em);
                em_mov_eax_edx(&em);
                break;
            case EXIT:
                /* exit(*sp): pop eax (exit code); leave; ret */
                em_pop_eax(&em);
                em1(&em, 0xC9); em1(&em, 0xC3);
                break;
            case OPEN: case READ: case CLOS:
                bc++;  /* skip arg */
                em_mov_eax_imm32(&em, 0xFFFFFFFFu);
                break;
            case PRTF: {
                /* printf(fmt, args...) — с форматированием через kapi->c4_printf_va.
                 * ВАЖНО: в байт-коде c4 PRTF не имеет собственного аргумента!
                 * PRTF «подсматривает» nargs через bc_pool[bc+1] (аргумент ADJ),
                 * не потребляя его. ADJ обработает его на следующей итерации. */
                u32 nargs = (u32)bc_pool[bc + 1];  /* peek, don't consume! */
                /* 1. mov eax, [esp + (nargs-1)*4] — load fmt */
                em1(&em, 0x8B); em1(&em, 0x84); em1(&em, 0x24);
                em4(&em, (u32)((nargs - 1) * 4));   /* mov eax, [esp+disp32] */
                /* 2. push eax (fmt) */
                em_push_eax(&em);
                /* 3. push imm32 (nargs) */
                em_push_imm32(&em, nargs);
                /* 4. lea eax, [esp+8] — pointer to args_reversed[0] */
                em1(&em, 0x8D); em1(&em, 0x44); em1(&em, 0x24); em1(&em, 8);
                /* 5. push eax */
                em_push_eax(&em);
                /* 6. mov eax, [edi + KAPI_C4_PRINTF_VA]; call eax */
                em1(&em, 0x8B); em1(&em, 0x87); em4(&em, (u32)KAPI_C4_PRINTF_VA);
                em1(&em, 0xFF); em1(&em, 0xD0);
                /* 7. cleanup: (nargs + 3) * 4 */
                u32 cleanup = (nargs + 3) * 4;
                if (cleanup <= 127) em_add_esp_imm8(&em, (u8)cleanup);
                else em_add_esp_imm32(&em, cleanup);
                /* 8. push eax (return value) */
                em_push_eax(&em);
                break;
            }
            case MALC:  emit_syscall(&em, KAPI_MALLOC, 1); break;
            case FREE:  emit_syscall(&em, KAPI_FREE, 1); break;
            case MSET:  emit_syscall(&em, KAPI_MEMSET, 3); break;
            case MCMP:  emit_syscall(&em, KAPI_MEMCMP, 3); break;
            case KINIT: case KQUIT:
                em_mov_eax_imm32(&em, 0);
                em_push_eax(&em);
                break;
            case KDELAY: emit_syscall(&em, KAPI_TASK_YIELD, 1); break;
            case KFILL:  emit_syscall(&em, KAPI_FB_FILL_RECT, 5); break;
            case KTEXT:  emit_syscall(&em, KAPI_FB_TEXT, 5); break;
            case KFLIP:
                /* kflip() — call kapi->win_invalidate(esi) */
                em1(&em, 0x56);   /* push esi */
                em1(&em, 0x8B); em1(&em, 0x87); em1(&em, (u8)KAPI_WIN_INVALIDATE);
                em1(&em, 0xFF); em1(&em, 0xD0);
                em_add_esp_imm8(&em, 4);
                em_push_eax(&em);
                break;
            case KRGB:  emit_syscall(&em, KAPI_FB_RGB, 3); break;
            case KEVENT: emit_syscall(&em, KAPI_C4_EVENT_POLL, 1); break;
            case KCLEAR: emit_syscall(&em, KAPI_FB_FILL_SCREEN, 1); break;
            case KW:    emit_syscall(&em, KAPI_FB_WIDTH, 0); break;
            case KH:    emit_syscall(&em, KAPI_FB_HEIGHT, 0); break;
            case KMTIME:
                emit_syscall(&em, KAPI_TIMER_TICKS, 0);
                /* multiply by 10: pop eax; imul eax, 10; push eax */
                em_pop_eax(&em);
                em1(&em, 0x6B); em1(&em, 0xC0); em1(&em, 10);
                em_push_eax(&em);
                break;
            case STRLEN: emit_syscall(&em, KAPI_STRLEN, 1); break;
            case STRCPY: emit_syscall(&em, KAPI_STRCPY, 2); break;
            case STRCMP: emit_syscall(&em, KAPI_STRCMP, 2); break;
            default:
                em1(&em, 0x90);   /* nop */
                break;
        }
    }

    /* Patch entry stub jmp → main_offset */
    u32 main_x86 = bc_to_x86(entry_cells);
    if (main_x86 == 0xFFFFFFFFu) {
        if (diag && diag_max > 0) {
            const char *m = "c4_x86: main offset not found in map";
            u32 L = (u32)strlen(m);
            if (L >= diag_max) L = diag_max - 1;
            memcpy(diag, m, L);
            diag[L] = 0;
        }
        return -1;
    }
    if (main_x86 >= entry_jmp_offset + 4) {
        i32 rel = (i32)main_x86 - (i32)(entry_jmp_offset + 4);
        em.buf[entry_jmp_offset]   = (u8)(rel & 0xFF);
        em.buf[entry_jmp_offset+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[entry_jmp_offset+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[entry_jmp_offset+3] = (u8)((rel >> 24) & 0xFF);
    }

    /* Patch all relocations */
    for (int i = 0; i < g_n_relocs; i++) {
        u32 target_x86 = bc_to_x86(g_relocs[i].target_bc_cell);
        if (target_x86 == 0xFFFFFFFFu) continue;
        u32 src = g_relocs[i].src_x86_offset;
        if (src + 4 > em.cap) continue;
        i32 rel = (i32)target_x86 - (i32)(src + 4);
        em.buf[src]   = (u8)(rel & 0xFF);
        em.buf[src+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[src+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[src+3] = (u8)((rel >> 24) & 0xFF);
    }

    if (out_size) *out_size = em.pos;
    return 0;
}

/* ---------- сохранение в RAMFS ---------- */
int c4_compile_to_file(const char *source_name, const char *src,
                      char *out, u32 out_max)
{
    static u8 out_buf[256 * 1024];
    u32 out_size = 0;
    if (c4_compile_to_native(src, out, out_max, out_buf, sizeof(out_buf), &out_size) != 0) {
        return -1;
    }
    if (out_size == 0) {
        if (out && out_max > 0) {
            const char *m = "c4: compiled output is empty";
            u32 L = (u32)strlen(m);
            if (L >= out_max) L = out_max - 1;
            memcpy(out, m, L);
            out[L] = 0;
        }
        return -1;
    }

    char bin_name[64];
    {
        const char *base = source_name;
        for (const char *p = source_name; *p; p++) {
            if (*p == '/' || *p == '\\') base = p + 1;
        }
        u32 i = 0;
        while (base[i] && base[i] != '.' && i < sizeof(bin_name) - 5) {
            bin_name[i] = base[i];
            i++;
        }
        bin_name[i] = '.'; bin_name[i+1] = 'b'; bin_name[i+2] = 'i';
        bin_name[i+3] = 'n'; bin_name[i+4] = 0;
    }

    if (!ramfs_ready()) {
        if (out && out_max > 0) {
            const char *m = "RAMFS not ready";
            u32 L = (u32)strlen(m);
            if (L >= out_max) L = out_max - 1;
            memcpy(out, m, L);
            out[L] = 0;
        }
        return -1;
    }

    ramfs_delete(bin_name);
    if (!ramfs_create(bin_name, out_size)) {
        if (out && out_max > 0) {
            const char *m = "ramfs_create failed";
            u32 L = (u32)strlen(m);
            if (L >= out_max) L = out_max - 1;
            memcpy(out, m, L);
            out[L] = 0;
        }
        return -1;
    }
    if (!ramfs_write(bin_name, out_buf, out_size)) {
        if (out && out_max > 0) {
            const char *m = "ramfs_write failed";
            u32 L = (u32)strlen(m);
            if (L >= out_max) L = out_max - 1;
            memcpy(out, m, L);
            out[L] = 0;
        }
        return -1;
    }

    if (out && out_max > 0) {
        char msg[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(msg, sizeof(msg),
                 "[c4] native binary saved: %s (%u bytes)",
                 bin_name, (unsigned)out_size);
        u32 L = (u32)strlen(msg);
        if (L >= out_max) L = out_max - 1;
        memcpy(out, msg, L);
        out[L] = 0;
    }
    (void)serial_puts;
    return 0;
}

/* ---------- запуск native c4-бинарника через loader ---------- */
int c4_load_and_run(const char *bin_name, void *win)
{
    return loader_spawn(bin_name, (struct window *)win);
}
