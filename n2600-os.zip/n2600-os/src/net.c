/* net.c — минимальный TCP/IP стек для N2600-OS.
 *
 * Реализация: Ethernet + ARP + IPv4 + ICMP.
 *
 * Драйвер NIC абстрагирован: сетевой цикл читает пакеты из e1000_recv()
 * и передаёт сюда в net_poll(). Отправка идёт через e1000_send().
 *
 * Кэш ARP хранит 16 записей (IP->MAC). При отсутствии записи в кэше
 * отправляется ARP-запрос и пакет ставится на паузу (для простоты — просто
 * теряется, в однозадачной системе повторяется вызывающим).
 *
 * Чек-суммы IP/ICMP — простые 16-битные над IP-заголовком/ICMP.
 */
#include "net.h"
#include "e1000.h"
#include "ne2000.h"
#include "virtio_net.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* Указатели на функции NIC-драйвера */
typedef int (*nic_send_fn)(const void *buf, u32 len);
typedef u32 (*nic_recv_fn)(void *buf, u32 max);

static nic_send_fn g_nic_send = NULL;
static nic_recv_fn g_nic_recv = NULL;

/* ---------- Состояние стека ---------- */
typedef struct {
    u8  mac[6];        /* наш MAC */
    u32 ip;            /* наш IP (host order, 0=не настроен) */
    u32 netmask;       /* маска подсети */
    u32 gateway;       /* шлюз по умолчанию */
    /* Кэш ARP */
    u32 arp_cache_ip[16];
    u8  arp_cache_mac[16][6];
    /* Статистика */
    u32 tx_packets;
    u32 rx_packets;
    u32 arp_rx;
    u32 icmp_rx;
    /* Callback для ICMP-ответов */
    net_icmp_cb_t icmp_cb;
} net_state_t;

static net_state_t g_net;

/* ---------- 16-битная Internet checksum (RFC 1071) ---------- */
static u16 inet_checksum(const void *data, u32 len, u32 initial)
{
    u32 sum = initial;
    const u8 *p = (const u8 *)data;
    for (u32 i = 0; i + 1 < len; i += 2) {
        sum += ((u32)p[i] << 8) | p[i+1];
    }
    if (len & 1) {
        sum += (u32)p[len - 1] << 8;
    }
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)(~sum & 0xFFFF);
}

static u16 inet_checksum_pseudo(u32 src_ip, u32 dst_ip, u8 proto,
                                  const void *data, u32 len)
{
    /* Псевдо-заголовок для UDP/TCP (12 байт): src_ip, dst_ip, zero, proto, len */
    u32 sum = 0;
    sum += (src_ip >> 16) & 0xFFFF;
    sum += src_ip & 0xFFFF;
    sum += (dst_ip >> 16) & 0xFFFF;
    sum += dst_ip & 0xFFFF;
    sum += (u32)proto;
    sum += len;
    return inet_checksum(data, len, sum);
}

/* ---------- Инициализация ---------- */
void net_init(void)
{
    memset(&g_net, 0, sizeof(g_net));
    g_net.netmask = 0xFFFFFF00u;   /* 255.255.255.0 по умолчанию */
    g_net.gateway = 0;
    g_net.ip = 0;

    /* Выбираем NIC-драйвер */
    g_nic_send = NULL;
    g_nic_recv = NULL;

    if (e1000_present()) {
        e1000_get_mac(g_net.mac);
        g_nic_send = e1000_send;
        g_nic_recv = e1000_recv;
    } else if (virtio_net_present()) {
        virtio_net_get_mac(g_net.mac);
        g_nic_send = virtio_net_send;
        g_nic_recv = virtio_net_recv;
    } else if (ne2000_present()) {
        ne2000_get_mac(g_net.mac);
        g_nic_send = ne2000_send;
        g_nic_recv = ne2000_recv;
    }
    serial_puts("[net] init done, mac=");
    {
        const char *h = "0123456789abcdef";
        char buf[20];
        int p = 0;
        for (int i = 0; i < 6; i++) {
            buf[p++] = h[(g_net.mac[i]>>4)&0xF];
            buf[p++] = h[g_net.mac[i]&0xF];
            if (i < 5) buf[p++] = ':';
        }
        buf[p] = 0;
        serial_puts(buf);
        serial_puts("\n");
    }
}

void net_set_ip(u32 ip) { g_net.ip = ip; }
u32  net_get_ip(void)    { return g_net.ip; }

int net_nic_present(void)
{
    return (g_nic_send != NULL);
}

const char *net_nic_name(void)
{
    if (e1000_present()) return e1000_chip_name();
    if (virtio_net_present()) return virtio_net_chip_name();
    if (ne2000_present()) return ne2000_chip_name();
    return "no NIC";
}
void net_set_gateway(u32 gw) { g_net.gateway = gw; }
u32  net_get_gateway(void)  { return g_net.gateway; }
void net_set_netmask(u32 m) { g_net.netmask = m; }
u32  net_get_netmask(void) { return g_net.netmask; }
void net_get_mac(u8 out_mac[6]) { memcpy(out_mac, g_net.mac, 6); }
void net_set_icmp_callback(net_icmp_cb_t cb) { g_net.icmp_cb = cb; }
u32  net_tx_packets(void) { return g_net.tx_packets; }
u32  net_rx_packets(void) { return g_net.rx_packets; }

/* ---------- ARP кэш дамп ---------- */
int net_arp_dump(net_arp_entry_t *out, int max_entries)
{
    int count = 0;
    for (int i = 0; i < NET_ARP_CACHE_SIZE && count < max_entries; i++) {
        if (g_net.arp_cache_ip[i] != 0) {
            out[count].ip = g_net.arp_cache_ip[i];
            memcpy(out[count].mac, g_net.arp_cache_mac[i], 6);
            count++;
        }
    }
    return count;
}

/* ---------- Парсинг IP-адреса ---------- */
int net_aton(const char *str, u32 *out_ip)
{
    u32 a, b, c, d;
    int n = 0;
    /* Ручной sscanf: %d.%d.%d.%d */
    const char *p = str;
    u32 vals[4];
    int idx = 0;
    u32 cur = 0;
    int any = 0;
    while (*p && idx < 4) {
        if (*p >= '0' && *p <= '9') {
            cur = cur * 10 + (u32)(*p - '0');
            any = 1;
            if (cur > 255) return 0;
        } else if (*p == '.') {
            if (!any) return 0;
            vals[idx++] = cur;
            cur = 0;
            any = 0;
        } else {
            return 0;
        }
        p++;
    }
    if (!any || idx != 3) return 0;
    vals[idx++] = cur;
    a = vals[0]; b = vals[1]; c = vals[2]; d = vals[3];
    (void)a; (void)b; (void)c; (void)d;
    (void)n;
    *out_ip = (vals[0] << 24) | (vals[1] << 16) | (vals[2] << 8) | vals[3];
    return 1;
}

int net_ntoa(u32 ip, char *out, u32 out_max)
{
    if (out_max < 16) return 0;
    u8 a = (u8)((ip >> 24) & 0xFF);
    u8 b = (u8)((ip >> 16) & 0xFF);
    u8 c = (u8)((ip >> 8) & 0xFF);
    u8 d = (u8)(ip & 0xFF);
    /* Ручное форматирование */
    int p = 0;
    u8 vals[4] = { a, b, c, d };
    for (int i = 0; i < 4; i++) {
        u8 v = vals[i];
        char tmp[4];
        int L = 0;
        if (v == 0) { tmp[L++] = '0'; }
        else {
            while (v > 0 && L < 3) { tmp[L++] = (char)('0' + v % 10); v /= 10; }
        }
        while (L > 0) out[p++] = tmp[--L];
        if (i < 3) out[p++] = '.';
    }
    out[p] = 0;
    return p;
}

/* ---------- ARP кэш ---------- */
static int arp_cache_lookup(u32 ip, u8 out_mac[6])
{
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip && ip != 0) {
            memcpy(out_mac, g_net.arp_cache_mac[i], 6);
            return 1;
        }
    }
    return 0;
}

static void arp_cache_add(u32 ip, const u8 mac[6])
{
    if (ip == 0) return;
    /* Ищем существующую запись */
    int slot = -1;
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip) { slot = i; break; }
    }
    if (slot < 0) {
        /* Ищем свободный слот */
        for (int i = 0; i < 16; i++) {
            if (g_net.arp_cache_ip[i] == 0) { slot = i; break; }
        }
    }
    if (slot < 0) {
        /* Заменяем первую запись (FIFO-замена без учёта времени — простота) */
        slot = 0;
    }
    g_net.arp_cache_ip[slot] = ip;
    memcpy(g_net.arp_cache_mac[slot], mac, 6);
}

/* ---------- Отправка Ethernet-кадра ---------- */
static int send_eth(const u8 dst_mac[6], u16 ethertype, const void *payload, u32 payload_len)
{
    static u8 frame[NET_PKT_MAX];
    if (payload_len + 14 > NET_PKT_MAX) return -1;
    memcpy(frame, dst_mac, 6);
    memcpy(frame + 6, g_net.mac, 6);
    frame[12] = (u8)(ethertype >> 8);
    frame[13] = (u8)(ethertype & 0xFF);
    memcpy(frame + 14, payload, payload_len);
    if (!g_nic_send) return -1;
    int sent = g_nic_send(frame, 14 + payload_len);
    if (sent > 0) g_net.tx_packets++;
    return sent;
}

/* ---------- ARP ---------- */
int net_send_arp_request(u32 target_ip)
{
    if (g_net.ip == 0) return -1;
    arp_pkt_t arp;
    arp.htype = 0x0001;  /* Ethernet (network order) */
    arp.ptype = 0x0800;  /* IPv4 */
    arp.hlen  = 6;
    arp.plen  = 4;
    arp.oper  = 0x0001;  /* request */
    memcpy(arp.sha, g_net.mac, 6);
    arp.spa[0] = (u8)((g_net.ip >> 24) & 0xFF);
    arp.spa[1] = (u8)((g_net.ip >> 16) & 0xFF);
    arp.spa[2] = (u8)((g_net.ip >> 8) & 0xFF);
    arp.spa[3] = (u8)(g_net.ip & 0xFF);
    memset(arp.tha, 0, 6);
    arp.tpa[0] = (u8)((target_ip >> 24) & 0xFF);
    arp.tpa[1] = (u8)((target_ip >> 16) & 0xFF);
    arp.tpa[2] = (u8)((target_ip >> 8) & 0xFF);
    arp.tpa[3] = (u8)(target_ip & 0xFF);

    /* Broadcast destination */
    u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    return send_eth(bcast, ETHERTYPE_ARP, &arp, sizeof(arp));
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len);
static void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len);

/* Forward declarations for TCP listen */
typedef struct {
    int  in_use;
    u16  port;
    tcp_accept_cb_t cb;
} tcp_listen_t;

#define NET_MAX_TCP_LISTEN 4
static tcp_listen_t g_tcp_listens[NET_MAX_TCP_LISTEN];

static void parse_tcp_options_impl(const u8 *opts, u32 opts_len, net_tcp_socket_t *s);
#define parse_tcp_options parse_tcp_options_impl

static void net_handle_arp(const eth_hdr_t *eth, const u8 *payload, u32 len)
{
    (void)eth;
    (void)len;
    if (len < sizeof(arp_pkt_t)) return;
    const arp_pkt_t *arp = (const arp_pkt_t *)payload;

    u16 oper = (arp->oper << 8) | (arp->oper >> 8);
    /* normalise: network order — oper уже 16-битное поле, big-endian.
     * На little-endian нам нужно перевернуть. */
    oper = (u16)((arp->oper >> 8) | (arp->oper << 8));

    u32 sender_ip = ((u32)arp->spa[0] << 24) | ((u32)arp->spa[1] << 16)
                   | ((u32)arp->spa[2] << 8) | (u32)arp->spa[3];

    /* Добавим в кэш отправителя */
    arp_cache_add(sender_ip, arp->sha);

    if (oper == 1) {
        /* ARP request: если запрос адресован нам — отвечаем */
        u32 target_ip = ((u32)arp->tpa[0] << 24) | ((u32)arp->tpa[1] << 16)
                       | ((u32)arp->tpa[2] << 8) | (u32)arp->tpa[3];
        if (target_ip == g_net.ip) {
            arp_pkt_t reply;
            reply.htype = 0x0001;
            reply.ptype = 0x0800;
            reply.hlen = 6;
            reply.plen = 4;
            reply.oper = 0x0002;   /* reply (little-endian, перевернётся ниже) */
            memcpy(reply.sha, g_net.mac, 6);
            memcpy(reply.spa, arp->tpa, 4);
            memcpy(reply.tha, arp->sha, 6);
            memcpy(reply.tpa, arp->spa, 4);
            /* Convert oper to network order */
            reply.oper = (u16)((0x0002 << 8) | (0x0002 >> 8));
            /* Convert htype and ptype too — но мы записали 0x0001 и 0x0800,
             * что в little-endian выглядит как 0x0100 и 0x0008.
             * На самом деле правильнее — изначально писать big-endian. */
            reply.htype = 0x0100;  /* 0x0001 в big-endian */
            reply.ptype = 0x0008;  /* 0x0800 в big-endian */
            send_eth(arp->sha, ETHERTYPE_ARP, &reply, sizeof(reply));
        }
    }
    g_net.arp_rx++;
}

/* ---------- IP ---------- */
static void net_send_ip(u8 proto, u32 dst_ip, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX];
    if (payload_len + 20 > NET_PKT_MAX - 14) return;

    /* IP header */
    ip_hdr_t *ip = (ip_hdr_t *)pkt;
    ip->ver_ihl = 0x45;
    ip->tos = 0;
    ip->tot_len = (u16)(20 + payload_len);
    ip->tot_len = (u16)((ip->tot_len << 8) | (ip->tot_len >> 8));
    ip->id = 0x1234;
    ip->id = (u16)((ip->id << 8) | (ip->id >> 8));
    ip->flags_frag = 0x4000;  /* Don't Fragment */
    ip->flags_frag = (u16)((ip->flags_frag << 8) | (ip->flags_frag >> 8));
    ip->ttl = 64;
    ip->protocol = proto;
    ip->src_ip[0] = (u8)((g_net.ip >> 24) & 0xFF);
    ip->src_ip[1] = (u8)((g_net.ip >> 16) & 0xFF);
    ip->src_ip[2] = (u8)((g_net.ip >> 8) & 0xFF);
    ip->src_ip[3] = (u8)(g_net.ip & 0xFF);
    ip->dst_ip[0] = (u8)((dst_ip >> 24) & 0xFF);
    ip->dst_ip[1] = (u8)((dst_ip >> 16) & 0xFF);
    ip->dst_ip[2] = (u8)((dst_ip >> 8) & 0xFF);
    ip->dst_ip[3] = (u8)(dst_ip & 0xFF);
    ip->checksum = 0;
    u16 cs = inet_checksum(ip, 20, 0);
    ip->checksum = (u16)((cs << 8) | (cs >> 8));

    /* Payload */
    memcpy(pkt + 20, payload, payload_len);

    /* Резолвим MAC */
    u8 dst_mac[6];
    u32 route_ip = dst_ip;
    if ((dst_ip & g_net.netmask) != (g_net.ip & g_net.netmask)) {
        /* Не в нашей подсети — отправляем через шлюз */
        if (g_net.gateway != 0) {
            route_ip = g_net.gateway;
        }
    }
    if (!arp_cache_lookup(route_ip, dst_mac)) {
        /* Нет в кэше — отправляем ARP request, пакет теряется (caller повторит) */
        net_send_arp_request(route_ip);
        return;
    }

    send_eth(dst_mac, ETHERTYPE_IPV4, pkt, 20 + payload_len);
}

/* ---------- ICMP ---------- */
int net_send_icmp_echo(u32 target_ip, u16 id, u16 seq, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX - 20];
    if (payload_len + 8 > sizeof(pkt)) return -1;
    icmp_hdr_t *icmp = (icmp_hdr_t *)pkt;
    icmp->type = ICMP_TYPE_ECHO_REQUEST;
    icmp->code = 0;
    icmp->checksum = 0;
    /* id и seq — уже big-endian, сохраняем как есть */
    icmp->id = (u16)((id << 8) | (id >> 8));
    icmp->seq = (u16)((seq << 8) | (seq >> 8));
    if (payload && payload_len > 0) {
        memcpy(pkt + 8, payload, payload_len);
    }
    u16 cs = inet_checksum(pkt, 8 + payload_len, 0);
    icmp->checksum = (u16)((cs << 8) | (cs >> 8));

    net_send_ip(IP_PROTO_ICMP, target_ip, pkt, 8 + payload_len);
    return 0;
}

static void net_handle_icmp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < sizeof(icmp_hdr_t)) return;
    const icmp_hdr_t *icmp = (const icmp_hdr_t *)payload;

    u16 icmp_cs = (u16)((icmp->checksum << 8) | (icmp->checksum >> 8));
    u16 calc_cs = inet_checksum(icmp, len, 0);
    (void)icmp_cs; (void)calc_cs;

    if (icmp->type == ICMP_TYPE_ECHO_REQUEST) {
        /* Отвечаем echo reply */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];

        /* Строим echo reply */
        static u8 reply[NET_PKT_MAX - 20];
        if (len > sizeof(reply)) len = sizeof(reply);
        memcpy(reply, payload, len);
        reply[0] = ICMP_TYPE_ECHO_REPLY;
        reply[1] = 0;
        reply[2] = 0; reply[3] = 0;  /* checksum */
        u16 cs = inet_checksum(reply, len, 0);
        reply[2] = (u8)(cs & 0xFF);   /* little-endian byte order on wire... actually big-endian */
        reply[3] = (u8)((cs >> 8) & 0xFF);
        /* Actually wire format is big-endian: high byte first */
        reply[2] = (u8)((cs >> 8) & 0xFF);
        reply[3] = (u8)(cs & 0xFF);

        net_send_ip(IP_PROTO_ICMP, src_ip, reply, len);
    } else if (icmp->type == ICMP_TYPE_ECHO_REPLY) {
        /* Получен ответ на наш ping */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];
        u16 id = (u16)((icmp->id << 8) | (icmp->id >> 8));
        u16 seq = (u16)((icmp->seq << 8) | (icmp->seq >> 8));
        if (g_net.icmp_cb) {
            g_net.icmp_cb(src_ip, id, seq, payload + 8, len - 8);
        }
    }
    g_net.icmp_rx++;
}

/* ---------- Обработка входящих пакетов ---------- */
static void net_handle_packet(const u8 *frame, u32 len)
{
    if (len < 14) return;
    eth_hdr_t eth;
    memcpy(&eth, frame, 14);
    u16 ethertype = (u16)((eth.ethertype << 8) | (eth.ethertype >> 8));

    /* Игнорируем кадры, не адресованные нам (broadcast или наш MAC) */
    int to_us = 0;
    if (memcmp(eth.dst, g_net.mac, 6) == 0) to_us = 1;
    if (memcmp(eth.dst, "\xFF\xFF\xFF\xFF\xFF\xFF", 6) == 0) to_us = 1;
    if (!to_us) return;

    const u8 *payload = frame + 14;
    u32 payload_len = len - 14;

    if (ethertype == ETHERTYPE_ARP) {
        net_handle_arp(&eth, payload, payload_len);
    } else if (ethertype == ETHERTYPE_IPV4) {
        if (payload_len < 20) return;
        const ip_hdr_t *ip = (const ip_hdr_t *)payload;
        /* Проверим, что пакет адресован нам (или broadcast) */
        u32 dst_ip = ((u32)ip->dst_ip[0] << 24) | ((u32)ip->dst_ip[1] << 16)
                   | ((u32)ip->dst_ip[2] << 8) | (u32)ip->dst_ip[3];
        if (dst_ip != g_net.ip && dst_ip != 0xFFFFFFFFu) {
            /* Не нам — игнорируем */
            return;
        }
        /* Длина IP-пакета (host order) */
        u16 ip_len = (u16)((ip->tot_len >> 8) | (ip->tot_len & 0xFF));
        if (ip_len < 20 || ip_len > payload_len) return;

        const u8 *ip_payload = payload + 20;
        u32 ip_payload_len = ip_len - 20;

        if (ip->protocol == IP_PROTO_ICMP) {
            net_handle_icmp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_UDP) {
            net_handle_udp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_TCP) {
            net_handle_tcp(ip, ip_payload, ip_payload_len);
        }
    }
}

void net_poll(void)
{
    if (!g_nic_recv) return;
    if (g_net.ip == 0) {
        static u8 buf[NET_PKT_MAX];
        while (g_nic_recv(buf, sizeof(buf)) > 0) { /* discard */ }
        return;
    }
    static u8 buf[NET_PKT_MAX];
    for (int i = 0; i < 8; i++) {
        u32 n = g_nic_recv(buf, sizeof(buf));
        if (n == 0) break;
        g_net.rx_packets++;
        net_handle_packet(buf, n);
    }
    net_tcp_timer();
}

/* ===================== UDP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u16 length;
    u16 checksum;   /* 0 = no checksum */
} udp_hdr_t;

static net_udp_socket_t g_udp_socks[NET_MAX_UDP_SOCKETS];
static net_udp_recv_cb_t g_udp_recv_cb = NULL;

void net_udp_set_callback(net_udp_recv_cb_t cb) { g_udp_recv_cb = cb; }

int net_udp_open(u16 local_port)
{
    for (int i = 0; i < NET_MAX_UDP_SOCKETS; i++) {
        if (!g_udp_socks[i].in_use) {
            g_udp_socks[i].in_use = 1;
            g_udp_socks[i].local_ip = g_net.ip;
            g_udp_socks[i].local_port = local_port;
            g_udp_socks[i].remote_ip = 0;
            g_udp_socks[i].remote_port = 0;
            return i;
        }
    }
    return -1;
}

void net_udp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return;
    g_udp_socks[sock].in_use = 0;
}

int net_udp_send(int sock, u32 dst_ip, u16 dst_port, const void *data, u32 len)
{
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return -1;
    if (!g_udp_socks[sock].in_use) return -1;
    if (len > 1472) return -1;   /* MTU 1500 - 20 IP - 8 UDP */

    static u8 pkt[1500];
    udp_hdr_t *udp = (udp_hdr_t *)pkt;
    udp->src_port = (u16)((g_udp_socks[sock].local_port >> 8) | (g_udp_socks[sock].local_port << 8));
    udp->dst_port = (u16)((dst_port >> 8) | (dst_port << 8));
    u16 total = (u16)(8 + len);
    udp->length = (u16)((total >> 8) | (total << 8));
    udp->checksum = 0;
    memcpy(pkt + 8, data, len);

    g_udp_socks[sock].remote_ip = dst_ip;
    g_udp_socks[sock].remote_port = dst_port;

    net_send_ip(IP_PROTO_UDP, dst_ip, pkt, 8 + len);
    return (int)len;
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 8) return;
    const udp_hdr_t *udp = (const udp_hdr_t *)payload;
    u16 src_port = (u16)((udp->src_port >> 8) | (udp->src_port & 0xFF));
    u16 dst_port = (u16)((udp->dst_port >> 8) | (udp->dst_port & 0xFF));
    u16 udp_len = (u16)((udp->length >> 8) | (udp->length & 0xFF));
    if (udp_len > len) udp_len = (u16)len;
    if (udp_len < 8) return;
    u32 data_len = udp_len - 8;
    const u8 *data = payload + 8;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    if (g_udp_recv_cb) {
        g_udp_recv_cb(src_ip, src_port, dst_port, data, data_len);
    }
}

/* ===================== TCP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u32 seq;
    u32 ack;
    u8  data_offset;   /* верхние 4 бита — header length в 32-битных словах */
    u8  flags;
    u16 window;
    u16 checksum;
    u16 urgent;
} tcp_hdr_t;

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

static net_tcp_socket_t g_tcp_socks[NET_MAX_TCP_SOCKETS];
static net_tcp_recv_cb_t g_tcp_recv_cb = NULL;
static u32 g_tcp_next_isn = 0x1000;   /* initial seq number counter */

void net_tcp_set_callback(net_tcp_recv_cb_t cb) { g_tcp_recv_cb = cb; }

const char *tcp_state_name(tcp_state_t s)
{
    static const char *names[] = {
        "CLOSED", "SYN_SENT", "SYN_RECEIVED", "ESTABLISHED",
        "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK",
        "CLOSING", "TIME_WAIT"
    };
    if (s < (tcp_state_t)10) return names[s];
    return "?";
}

/* Отправить TCP-сегмент с заданными флагами и payload.
 * Если флаг SYN установлен, добавляем MSS option (default 1460). */
static void tcp_send_segment(net_tcp_socket_t *s, u8 flags,
                             const void *data, u32 data_len)
{
    static u8 pkt[1500];
    tcp_hdr_t *tcp = (tcp_hdr_t *)pkt;
    tcp->src_port = (u16)((s->local_port >> 8) | (s->local_port << 8));
    tcp->dst_port = (u16)((s->remote_port >> 8) | (s->remote_port << 8));
    tcp->seq = (u32)((s->seq >> 24) | ((s->seq >> 8) & 0xFF00)
                   | ((s->seq << 8) & 0xFF0000) | (s->seq << 24));
    tcp->ack = (u32)((s->ack >> 24) | ((s->ack >> 8) & 0xFF00)
                   | ((s->ack << 8) & 0xFF0000) | (s->ack << 24));

    u32 hdr_len = 20;
    /* Для SYN добавляем MSS option (4 байта: type=2, len=4, value=1460) */
    if (flags & TCP_SYN) {
        u8 *opts = (u8 *)(pkt + 20);
        opts[0] = 2;  /* MSS option type */
        opts[1] = 4;  /* length */
        opts[2] = (u8)((s->mss >> 8) & 0xFF);
        opts[3] = (u8)(s->mss & 0xFF);
        /* Pad to 24 bytes (4 bytes option, divisible by 4) */
        hdr_len = 24;
    }

    tcp->data_offset = (u8)((hdr_len / 4) << 4);
    tcp->flags = flags;
    tcp->window = 0xFFFF;   /* max window */
    tcp->window = (u16)((tcp->window >> 8) | (tcp->window << 8));
    tcp->checksum = 0;
    tcp->urgent = 0;
    if (data && data_len > 0) {
        memcpy(pkt + hdr_len, data, data_len);
    }
    net_send_ip(IP_PROTO_TCP, s->remote_ip, pkt, hdr_len + data_len);
}

int net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port)
{
    int i;
    for (i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        if (!g_tcp_socks[i].in_use) break;
    }
    if (i >= NET_MAX_TCP_SOCKETS) return -1;

    net_tcp_socket_t *s = &g_tcp_socks[i];
    s->in_use = 1;
    s->local_ip = g_net.ip;
    s->local_port = local_port;
    s->remote_ip = dst_ip;
    s->remote_port = dst_port;
    s->seq = g_tcp_next_isn;
    g_tcp_next_isn += 64000;   /* increment ISN */
    s->ack = 0;
    s->mss = 1460;
    s->window_scale = 0;
    s->retransmit_seq = 0;
    s->retransmit_tick = 0;
    s->retransmit_count = 0;
    s->state = TCP_SYN_SENT;

    /* Send SYN with MSS option */
    tcp_send_segment(s, TCP_SYN, NULL, 0);
    s->seq += 1;   /* SYN consumes 1 seq */
    s->retransmit_seq = s->seq - 1;  /* SYN seq */
    s->retransmit_tick = timer_ticks();
    return i;
}

/* ===================== TCP Passive LISTEN ===================== */

int net_tcp_listen(u16 local_port, tcp_accept_cb_t cb)
{
    for (int i = 0; i < NET_MAX_TCP_LISTEN; i++) {
        if (!g_tcp_listens[i].in_use) {
            g_tcp_listens[i].in_use = 1;
            g_tcp_listens[i].port = local_port;
            g_tcp_listens[i].cb = cb;
            return i;
        }
    }
    return -1;
}

/* Парсить TCP-опции (MSS, Window Scale, SACK-permitted) */
static void parse_tcp_options_impl(const u8 *opts, u32 opts_len,
                               net_tcp_socket_t *s)
{
    u32 i = 0;
    while (i < opts_len) {
        u8 type = opts[i];
        if (type == 0) break;  /* End of options */
        if (type == 1) { i++; continue; }  /* NOP */
        if (i + 1 >= opts_len) break;
        u8 len = opts[i+1];
        if (len < 2) break;
        if (type == 2 && len == 4 && i + 4 <= opts_len) {
            /* MSS option */
            s->mss = ((u16)opts[i+2] << 8) | opts[i+3];
            if (s->mss < 536) s->mss = 536;
            if (s->mss > 1460) s->mss = 1460;
        }
        else if (type == 3 && len == 3 && i + 3 <= opts_len) {
            /* Window Scale option */
            s->window_scale = opts[i+2];
        }
        i += len;
    }
}

void net_tcp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use) return;
    if (s->state == TCP_ESTABLISHED) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        s->state = TCP_FIN_WAIT_1;
    } else if (s->state == TCP_CLOSE_WAIT) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        s->state = TCP_LAST_ACK;
    } else {
        s->state = TCP_CLOSED;
        s->in_use = 0;
    }
}

int net_tcp_send(int sock, const void *data, u32 len)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return -1;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use || s->state != TCP_ESTABLISHED) return -1;
    u32 mss = s->mss ? s->mss : 1460;
    if (len > mss) len = mss;
    tcp_send_segment(s, TCP_PSH | TCP_ACK, data, len);
    s->seq += len;
    /* Track for retransmission */
    s->retransmit_seq = s->seq - len;
    s->retransmit_tick = timer_ticks();
    s->retransmit_count = 0;
    return (int)len;
}

tcp_state_t net_tcp_state(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return TCP_CLOSED;
    if (!g_tcp_socks[sock].in_use) return TCP_CLOSED;
    return g_tcp_socks[sock].state;
}

/* TCP retransmission timer — проверяет все сокеты на таймаут. */
void net_tcp_timer(void)
{
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) continue;
        if (s->state == TCP_CLOSED) continue;
        if (s->retransmit_seq == 0) continue;
        if (s->retransmit_tick == 0) continue;
        /* Timeout: 1 second initially, doubling on each retransmit */
        u32 timeout_ticks = 100u;  /* 1 second (100 ticks = 1s at 100Hz) */
        for (int j = 0; j < s->retransmit_count; j++) timeout_ticks *= 2;
        if (timeout_ticks > 6400u) timeout_ticks = 6400u;  /* cap at 64s */
        if ((timer_ticks() - s->retransmit_tick) < timeout_ticks) continue;
        /* Retransmit */
        /* For now, just resend the last segment data (we don't save data).
         * This is a placeholder — full retransmission needs saving data. */
        s->retransmit_count++;
        s->retransmit_tick = timer_ticks();
        if (s->retransmit_count > 8) {
            /* Too many retransmits — abort */
            s->state = TCP_CLOSED;
            s->in_use = 0;
        }
    }
}

static void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 20) return;
    const tcp_hdr_t *tcp = (const tcp_hdr_t *)payload;
    u16 src_port = (u16)((tcp->src_port >> 8) | (tcp->src_port & 0xFF));
    u16 dst_port = (u16)((tcp->dst_port >> 8) | (tcp->dst_port & 0xFF));
    u32 seq = ((u32)(payload[4]) << 24) | ((u32)(payload[5]) << 16)
            | ((u32)(payload[6]) << 8) | (u32)payload[7];
    u32 ack = ((u32)(payload[8]) << 24) | ((u32)(payload[9]) << 16)
            | ((u32)(payload[10]) << 8) | (u32)payload[11];
    u8  flags = payload[13];
    u8  hdr_len = (u8)((payload[12] >> 4) * 4);
    if (hdr_len < 20 || hdr_len > len) return;

    u32 data_len = len - hdr_len;
    const u8 *data = payload + hdr_len;
    const u8 *opts = payload + 20;
    u32 opts_len = hdr_len > 20 ? (hdr_len - 20) : 0;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    /* Check for passive LISTEN first — if incoming SYN on a listening port */
    if ((flags & TCP_SYN) && !(flags & TCP_ACK)) {
        for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
            if (!g_tcp_listens[li].in_use) continue;
            if (g_tcp_listens[li].port != dst_port) continue;
            /* Accept connection — find a free socket */
            int si = -1;
            for (int j = 0; j < NET_MAX_TCP_SOCKETS; j++) {
                if (!g_tcp_socks[j].in_use) { si = j; break; }
            }
            if (si < 0) {
                /* No free sockets — send RST */
                net_tcp_socket_t tmp;
                memset(&tmp, 0, sizeof(tmp));
                tmp.local_ip = g_net.ip;
                tmp.local_port = dst_port;
                tmp.remote_ip = src_ip;
                tmp.remote_port = src_port;
                tmp.ack = seq + 1;
                tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
                return;
            }
            /* Create new socket in SYN_RECEIVED state */
            net_tcp_socket_t *s = &g_tcp_socks[si];
            s->in_use = 1;
            s->local_ip = g_net.ip;
            s->local_port = dst_port;
            s->remote_ip = src_ip;
            s->remote_port = src_port;
            s->seq = g_tcp_next_isn;
            g_tcp_next_isn += 64000;
            s->ack = seq + 1;
            s->mss = 1460;
            s->window_scale = 0;
            s->retransmit_seq = 0;
            s->retransmit_count = 0;
            /* Parse peer's TCP options (MSS, WS, SACK-permitted) */
            if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
            /* Send SYN-ACK */
            tcp_send_segment(s, TCP_SYN | TCP_ACK, NULL, 0);
            s->seq += 1;  /* SYN consumes 1 seq */
            s->state = TCP_SYN_RECEIVED;
            /* Note: callback is called when handshake completes (ESTABLISHED) */
            return;
        }
    }

    /* Find matching socket */
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) continue;
        if (s->remote_ip != src_ip) continue;
        if (s->remote_port != src_port) continue;
        if (s->local_port != dst_port) continue;

        switch (s->state) {
            case TCP_SYN_SENT:
                /* Wait for SYN-ACK */
                if ((flags & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK)) {
                    s->ack = seq + 1;
                    /* Parse peer's options */
                    if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
                    /* Send ACK */
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;  /* SYN-ACK received */
                } else if (flags & TCP_RST) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_SYN_RECEIVED:
                /* Wait for ACK to complete 3-way handshake */
                if (flags & TCP_ACK) {
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;
                    /* Call accept callback */
                    for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
                        if (g_tcp_listens[li].in_use &&
                            g_tcp_listens[li].port == dst_port &&
                            g_tcp_listens[li].cb) {
                            g_tcp_listens[li].cb(i, src_ip, src_port);
                            break;
                        }
                    }
                    /* If data came with the ACK, process it */
                    if (data_len > 0) {
                        s->ack = seq + data_len;
                        if (g_tcp_recv_cb) {
                            g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                        }
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                return;
            case TCP_ESTABLISHED:
                /* Clear retransmit on ACK */
                if ((flags & TCP_ACK) && s->retransmit_seq != 0 &&
                    ack >= s->retransmit_seq) {
                    s->retransmit_seq = 0;
                    s->retransmit_count = 0;
                }
                if (data_len > 0) {
                    s->ack = seq + data_len;
                    if (g_tcp_recv_cb) {
                        g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                    }
                    /* Send ACK */
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                }
                if (flags & TCP_FIN) {
                    s->ack = seq + data_len + 1;
                    tcp_send_segment(s, TCP_ACK | TCP_FIN, NULL, 0);
                    s->state = TCP_LAST_ACK;
                    s->seq += 1;
                }
                return;
            case TCP_FIN_WAIT_1:
                /* Got ACK for our FIN? */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_FIN_WAIT_2;
                }
                if (flags & TCP_FIN) {
                    s->ack = seq + data_len + 1;
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_TIME_WAIT;
                    /* No TIME_WAIT duration in this simple impl — close */
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_LAST_ACK:
                /* Wait for ACK of our FIN */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            default:
                return;
        }
    }
    /* No matching socket — if SYN, send RST (we don't accept incoming connections) */
    if (flags & TCP_SYN) {
        /* Send RST */
        net_tcp_socket_t tmp;
        memset(&tmp, 0, sizeof(tmp));
        tmp.local_ip = g_net.ip;
        tmp.local_port = dst_port;
        tmp.remote_ip = src_ip;
        tmp.remote_port = src_port;
        tmp.seq = 0;
        tmp.ack = seq + (data_len > 0 ? data_len : 0) + ((flags & (TCP_SYN | TCP_FIN)) ? 1 : 0);
        tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
    }
}
