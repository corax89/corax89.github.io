/* apps_cmscript.c — CMScript-редактор + интерпретатор.
 *
 * Открывает .cs-файлы (CMScript), позволяет редактировать и запускать.
 * Кнопка [Run] (F9) парсит и выполняет скрипт через CMScript-интерпретатор.
 *
 * Доступные host-функции из .cs-скрипта (см. cmscript_api.c):
 *   print(str)               — вывод текста
 *   print_int(n)             — вывод числа
 *   screen_width() / screen_height()
 *   fill_rect(x,y,w,h,c)    — заливка прямоугольника
 *   draw_text(x,y,str,color) — вывод текста на экран
 *   get_color(r,g,b)        — получить цвет
 *   clear_screen(color)      — очистка экрана
 *   flip()                   — перерисовка
 *   delay(ms)                — задержка
 *   uptime()                 — время работы (сек)
 *   malloc(n) / free(p) / memset / memcmp / strlen
 *   ramfs_read(name, buf, max) / ramfs_write(name, buf, len)
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "kbd.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "cmscript.h"
#include "task.h"
#include "mouse.h"

#define CS_BUF_SIZE 8192
#define CS_COLS 72
#define CS_ROWS 24
#define CS_HEADER_H 22
#define BTN_COUNT 3
#define BTN_W 70
#define BTN_H 18
#define BTN_GAP 4
#define BTN_X0 4
#define BTN_Y0 2

typedef struct {
    char buf[CS_BUF_SIZE];
    int  len;
    int  cursor;
    int  top;
    char filename[32];
    int  dirty;
    int  btn_hot;
    int  btn_pressed;
    int  running;
    char status[80];
    /* Окно вывода */
    char *out_buf;
    u32   out_len;
    int   out_top;
} cs_editor_t;

typedef struct {
    char *buf;
    u32   len;
    int   top;
} cs_outwin_t;

static const char *cs_buttons[BTN_COUNT] = {
    "Save F2", "Run F9", "Esc"
};

static void cs_btn_rect(int idx, int *bx, int *by, int *bw, int *bh) {
    *bx = BTN_X0 + idx * (BTN_W + BTN_GAP);
    *by = BTN_Y0; *bw = BTN_W; *bh = BTN_H;
}

static int cs_btn_at(cs_editor_t *e, int mx, int my) {
    (void)e;
    if (my < BTN_Y0 || my >= BTN_Y0 + BTN_H) return -1;
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh; cs_btn_rect(i, &bx, &by, &bw, &bh);
        if (mx >= bx && mx < bx + bw) return i;
    }
    return -1;
}

/* ---------- окно вывода ---------- */
static void cs_out_draw(window_t *w) {
    cs_outwin_t *o = (cs_outwin_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cols = cw / 8;
    int vis = (ch - 4) / 16;
    if (cols < 1) cols = 1;
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));
    int line = 0, i = 0;
    while (i < (int)o->len && line < o->top) {
        if (o->buf[i] == '\n') line++;
        i++;
    }
    int y = 2;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)o->len; r++) {
        int start = i, end = i;
        while (end < (int)o->len && o->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 254) len = 254;
        memcpy(tmp, o->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        i = end + (end < (int)o->len ? 1 : 0);
        y += 16;
    }
    char st[64];
    snprintf(st, sizeof(st), "CMScript output: %u bytes", (unsigned)o->len);
    fb_text(4, ch - 14, st, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}
static void cs_out_key(window_t *w, const key_event_t *ev) {
    cs_outwin_t *o = (cs_outwin_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == 0x49) { o->top -= 8; if (o->top < 0) o->top = 0; win_invalidate(w); }
    else if (ev->code == 0x51) { o->top += 8; win_invalidate(w); }
    else if (ev->code == KBD_UP) { if (o->top > 0) o->top--; win_invalidate(w); }
    else if (ev->code == KBD_DOWN) { o->top++; win_invalidate(w); }
    else if (ev->ch == 0x1B || ev->code == 0x01) win_close(w);
}
static void cs_out_close(window_t *w) {
    cs_outwin_t *o = (cs_outwin_t *)w->data;
    if (o) { if (o->buf) free(o->buf); free(o); }
}
static void cs_out_open(const char *text, u32 len) {
    cs_outwin_t *o = (cs_outwin_t *)malloc(sizeof(cs_outwin_t));
    if (!o) return;
    o->buf = (char *)malloc(len + 1);
    if (!o->buf) { free(o); return; }
    memcpy(o->buf, text, len);
    o->buf[len] = 0;
    o->len = len;
    o->top = 0;
    u32 W = fb_width(), H = fb_height();
    int ww = 600, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("CMScript: вывод", 90, 70, ww, wh, cs_out_draw, cs_out_key, NULL, NULL, cs_out_close, o);
}

/* ---------- задача запуска ---------- */
typedef struct {
    cs_editor_t *ed;
    char *out;
    u32  out_max;
    int  result;
} cs_run_ctx_t;

static void cs_run_task(void *arg) {
    cs_run_ctx_t *c = (cs_run_ctx_t *)arg;
    c->result = cmscript_run(c->ed->buf, c->out, c->out_max);
    if (c->result == 0) {
        snprintf(c->ed->status, sizeof(c->ed->status), "OK: выполнено");
    } else {
        snprintf(c->ed->status, sizeof(c->ed->status), "Ошибка: код %d", c->result);
    }
    c->ed->running = 0;
    u32 out_len = (u32)strlen(c->out);
    cs_out_open(c->out, out_len);
    free(c);
    task_exit();
}

/* ---------- редактор ---------- */
static void cs_status(cs_editor_t *e, const char *msg) {
    strncpy(e->status, msg, sizeof(e->status) - 1);
    e->status[sizeof(e->status) - 1] = 0;
}

static int cs_line_of(cs_editor_t *e, int pos) {
    int line = 0;
    for (int i = 0; i < pos && i < e->len; i++)
        if (e->buf[i] == '\n') line++;
    return line;
}
static int cs_line_start(cs_editor_t *e, int pos) {
    int i = pos;
    while (i > 0 && e->buf[i - 1] != '\n') i--;
    return i;
}
static int cs_line_end(cs_editor_t *e, int pos) {
    int i = pos;
    while (i < e->len && e->buf[i] != '\n') i++;
    return i;
}

static void cs_insert(cs_editor_t *e, char c) {
    if (e->len >= CS_BUF_SIZE - 1) { cs_status(e, "Буфер полон"); return; }
    for (int i = e->len; i > e->cursor; i--) e->buf[i] = e->buf[i - 1];
    e->buf[e->cursor] = c; e->cursor++; e->len++; e->buf[e->len] = 0; e->dirty = 1;
}
static void cs_backspace(cs_editor_t *e) {
    if (e->cursor == 0) return;
    e->cursor--;
    for (int i = e->cursor; i < e->len; i++) e->buf[i] = e->buf[i + 1];
    e->len--; e->buf[e->len] = 0; e->dirty = 1;
}
static void cs_save(cs_editor_t *e) {
    if (!ramfs_ready()) { cs_status(e, "RAMFS недоступен"); return; }
    if (!e->filename[0]) strcpy(e->filename, "script.cs");
    ramfs_delete(e->filename);
    if (!ramfs_create(e->filename, (u32)(e->len + 1))) { cs_status(e, "Не удалось создать файл"); return; }
    if (!ramfs_write(e->filename, e->buf, (u32)(e->len + 1))) { cs_status(e, "Ошибка записи"); return; }
    e->dirty = 0;
    char msg[80];
    snprintf(msg, sizeof(msg), "Сохранено: %s (%d байт)", e->filename, e->len);
    cs_status(e, msg);
}
static void cs_run(cs_editor_t *e) {
    if (e->running) { cs_status(e, "Уже выполняется..."); return; }
    if (e->len == 0) { cs_status(e, "Буфер пуст"); return; }
    e->buf[e->len] = 0;
    cs_save(e);
    cs_run_ctx_t *c = (cs_run_ctx_t *)malloc(sizeof(cs_run_ctx_t));
    if (!c) { cs_status(e, "Нет памяти"); return; }
    c->ed = e;
    c->out_max = 16384;
    c->out = (char *)malloc(c->out_max);
    if (!c->out) { free(c); cs_status(e, "Нет памяти под вывод"); return; }
    c->out[0] = 0;
    c->result = -1;
    e->running = 1;
    cs_status(e, "Выполнение...");
    int tid = task_spawn("cmscript", cs_run_task, c);
    if (tid < 0) {
        e->running = 0;
        free(c->out); free(c);
        cs_status(e, "Не удалось породить задачу");
    }
}

static const char *cs_template =
    "/* CMScript — пример для N2600-OS */\n"
    "int main() {\n"
    "    int i;\n"
    "    int w = screen_width();\n"
    "    int h = screen_height();\n"
    "    int blue = get_color(0, 0, 40);\n"
    "    int white = get_color(255, 255, 255);\n"
    "    int red = get_color(255, 60, 60);\n"
    "\n"
    "    clear_screen(blue);\n"
    "    for (i = 0; i < 10; i = i + 1) {\n"
    "        int x = (w / 10) * i;\n"
    "        fill_rect(x + 4, 50, (w / 10) - 8, 100, red);\n"
    "        draw_text(x + 8, 160, \"bar\", white);\n"
    "    }\n"
    "    draw_text(10, 10, \"CMScript works!\", white);\n"
    "    flip();\n"
    "    delay(2000);\n"
    "    print(\"Done!\\n\");\n"
    "    return 0;\n"
    "}\n";

static void cs_draw(window_t *w) {
    cs_editor_t *e = (cs_editor_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, CS_HEADER_H, fb_rgb(0x1E, 0x4A, 0x73));
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh; cs_btn_rect(i, &bx, &by, &bw, &bh);
        u32 bg = (e->btn_pressed == i) ? fb_rgb(0x4A, 0x7F, 0xB0)
              : (e->btn_hot == i) ? fb_rgb(0x32, 0x60, 0x8E)
              : fb_rgb(0x25, 0x4A, 0x70);
        fb_fill_rect(bx, by, bw, bh, bg);
        fb_rect(bx, by, bw, bh, fb_rgb(0x6F, 0xB3, 0xF2));
        int tw = (int)strlen(cs_buttons[i]) * 8;
        fb_text(bx + (bw - tw) / 2, by + (bh - 16) / 2 + 1, cs_buttons[i], fb_rgb(0xE6, 0xEA, 0xEE), -1);
    }
    char info[80];
    snprintf(info, sizeof(info), "%s  %d/%d  %s",
             e->filename[0] ? e->filename : "(без имени)",
             e->cursor, e->len, e->dirty ? "*)" : "");
    int ix = BTN_X0 + BTN_COUNT * (BTN_W + BTN_GAP);
    if (ix < cw - 200) fb_text(ix, BTN_Y0 + 3, info, fb_rgb(0xC6, 0xCD, 0xD5), -1);

    int area_y0 = CS_HEADER_H;
    int area_h = ch - CS_HEADER_H - 14;
    int cols = (cw - 4) / 8;
    if (cols < 1) cols = 1;
    int vis = area_h / 16;
    if (vis < 1) vis = 1;
    fb_fill_rect(0, area_y0, cw, area_h, fb_rgb(0x0B, 0x0E, 0x11));

    int line = 0, i = 0;
    while (i < e->len && line < e->top) {
        if (e->buf[i] == '\n') line++;
        i++;
    }
    int y = area_y0 + 2;
    char tmp[256];
    for (int r = 0; r < vis && i < e->len; r++) {
        int start = i, end = i;
        while (end < e->len && e->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 254) len = 254;
        memcpy(tmp, e->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xE6, 0xEA, 0xEE), -1);
        i = end + (end < e->len ? 1 : 0);
        y += 16;
    }
    if (wm_blink() && !e->running) {
        int cl = cs_line_of(e, e->cursor);
        int row = cl - e->top;
        if (row >= 0 && row < vis) {
            int ls = cs_line_start(e, e->cursor);
            int col = e->cursor - ls;
            if (col > cols) col = cols;
            int cx = 4 + col * 8;
            int cy = area_y0 + 2 + row * 16;
            fb_fill_rect(cx, cy, 8, 16, fb_rgb(0x6F, 0xB3, 0xF2));
        }
    }
    fb_fill_rect(0, ch - 14, cw, 14, fb_rgb(0x12, 0x16, 0x1B));
    fb_text(4, ch - 12, e->status, fb_rgb(0x6F, 0xB3, 0xF2), -1);
}

static void cs_key(window_t *w, const key_event_t *ev) {
    cs_editor_t *e = (cs_editor_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == 0x3C) { cs_save(e); win_invalidate(w); return; }
    if (ev->code == 0x43) { cs_run(e); win_invalidate(w); return; }
    if (ev->ch == 0x1B || ev->code == 0x01) { win_close(w); return; }
    if (ev->code == KBD_UP) {
        int ls = cs_line_start(e, e->cursor);
        if (ls > 0) {
            int prev_end = ls - 1, prev_start = cs_line_start(e, prev_end);
            int col = e->cursor - ls;
            int np = prev_start + col;
            if (np > prev_end) np = prev_end;
            e->cursor = np;
            int l = cs_line_of(e, e->cursor);
            if (l < e->top) e->top = l;
            win_invalidate(w);
        }
        return;
    }
    if (ev->code == KBD_DOWN) {
        int ls = cs_line_start(e, e->cursor);
        int le = cs_line_end(e, e->cursor);
        int col = e->cursor - ls;
        if (le < e->len) {
            int ns = le + 1, ne = cs_line_end(e, ns);
            int np = ns + col;
            if (np > ne) np = ne;
            e->cursor = np;
            int l = cs_line_of(e, e->cursor);
            int vis = (win_content_h(w) - CS_HEADER_H - 14) / 16;
            if (l >= e->top + vis) e->top = l - vis + 1;
            win_invalidate(w);
        }
        return;
    }
    if (ev->code == KBD_LEFT) { if (e->cursor > 0) e->cursor--; win_invalidate(w); return; }
    if (ev->code == KBD_RIGHT) { if (e->cursor < e->len) e->cursor++; win_invalidate(w); return; }
    if (ev->code == 0x49) { e->top -= 8; if (e->top < 0) e->top = 0; win_invalidate(w); return; }
    if (ev->code == 0x51) { e->top += 8; win_invalidate(w); return; }
    if (ev->code == 0x47) { e->cursor = cs_line_start(e, e->cursor); win_invalidate(w); return; }
    if (ev->code == 0x4F) { e->cursor = cs_line_end(e, e->cursor); win_invalidate(w); return; }
    if (ev->ch == '\b') { cs_backspace(e); win_invalidate(w); return; }
    if (ev->ch == '\n') { cs_insert(e, '\n'); win_invalidate(w); return; }
    if (ev->ch == '\t') { cs_insert(e, ' '); cs_insert(e, ' '); win_invalidate(w); return; }
    if (ev->ch >= 32 && ev->ch < 127) { cs_insert(e, (char)ev->ch); win_invalidate(w); return; }
}

static void cs_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed) {
    cs_editor_t *e = (cs_editor_t *)w->data;
    int inside = (my < CS_HEADER_H);
    if (inside) {
        int btn = cs_btn_at(e, mx, my);
        if (btn != e->btn_hot) { e->btn_hot = btn; win_invalidate(w); }
        if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
            if (btn >= 0) { e->btn_pressed = btn; win_invalidate(w); }
        }
        if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT)) {
            int wp = e->btn_pressed; e->btn_pressed = -1;
            if (wp >= 0 && btn == wp) {
                if (wp == 0) cs_save(e);
                else if (wp == 1) cs_run(e);
                else if (wp == 2) win_close(w);
            }
            win_invalidate(w);
        }
        return;
    }
    if (e->btn_hot != -1 || e->btn_pressed != -1) { e->btn_hot = -1; e->btn_pressed = -1; win_invalidate(w); }
}

static void cs_close(window_t *w) {
    cs_editor_t *e = (cs_editor_t *)w->data;
    if (e) free(e);
}

static cs_editor_t *cs_new_with(const char *filename, const char *content, int len) {
    cs_editor_t *e = (cs_editor_t *)malloc(sizeof(cs_editor_t));
    if (!e) return NULL;
    memset(e, 0, sizeof(cs_editor_t));
    if (content && len > 0) {
        if (len >= CS_BUF_SIZE) len = CS_BUF_SIZE - 1;
        memcpy(e->buf, content, len);
        e->buf[len] = 0; e->len = len;
    } else {
        int L = (int)strlen(cs_template);
        if (L >= CS_BUF_SIZE) L = CS_BUF_SIZE - 1;
        memcpy(e->buf, cs_template, L);
        e->buf[L] = 0; e->len = L;
    }
    e->cursor = 0; e->top = 0;
    e->btn_hot = -1; e->btn_pressed = -1;
    if (filename && filename[0]) {
        strncpy(e->filename, filename, sizeof(e->filename) - 1);
        e->filename[sizeof(e->filename) - 1] = 0;
    } else { strcpy(e->filename, "script.cs"); }
    cs_status(e, "F9 — выполнить скрипт");
    return e;
}

void app_cmscript_open(void) {
    cs_editor_t *e = cs_new_with(NULL, NULL, 0);
    if (!e) return;
    u32 W = fb_width(), H = fb_height();
    int ww = CS_COLS * 8 + 12;
    int wh = CS_ROWS * 16 + CS_HEADER_H + 16 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("CMScript", 80, 30, ww, wh, cs_draw, cs_key, cs_mouse, NULL, cs_close, e);
}

void app_cmscript_open_with(const char *filename, const char *content, int len) {
    cs_editor_t *e = cs_new_with(filename, content, len);
    if (!e) return;
    u32 W = fb_width(), H = fb_height();
    int ww = CS_COLS * 8 + 12;
    int wh = CS_ROWS * 16 + CS_HEADER_H + 16 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    char title[64];
    snprintf(title, sizeof(title), "CMScript: %s", filename ? filename : "?");
    win_create(title, 80, 30, ww, wh, cs_draw, cs_key, cs_mouse, NULL, cs_close, e);
}
