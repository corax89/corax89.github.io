/* apps_example.c — ШАБЛОН СВОЕГО ПРИЛОЖЕНИЯ для N2600-OS.
 *
 * Как добавить своё приложение:
 *   1. Скопируйте этот файл, например в src/my_app.c.
 *   2. Поменяйте логику (см. комментарии ниже) и заголовок окна.
 *   3. В src/apps.c добавьте в app_table[] строку:
 *          { "Моё приложение", app_my_open },
 *      и объявите функцию в src/apps.h.
 *   4. Запустите build.bat — приложение появится в меню «Пуск».
 *
 * Доступный API:
 *   окно:      win_create(), win_close(), win_invalidate(), win_content_w/h()
 *   графика:   fb_fill_rect(), fb_rect(), fb_hline(), fb_vline(),
 *              fb_char(), fb_text(), fb_rgb()
 *   система:   malloc()/free(), timer_ticks()/uptime_sec(),
 *              rtc_get_time(), cpu_get_brand(), mem_*()
 *   ввод:      on_key (клавиатура, только для окна в фокусе),
 *              on_mouse (мышь: координаты относительно содержимого окна)
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "string.h"
#include "mem.h"
#include "mouse.h"

typedef struct {
    int count;    /* счётчик нажатий */
    int pressed;  /* кнопка зажата (для эффекта нажатия) */
} example_t;

#define BTN_X 24
#define BTN_Y 36
#define BTN_W 96
#define BTN_H 28

static void example_draw(window_t *w)
{
    example_t *d = (example_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    /* фон окна */
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x18, 0x1E));
    fb_fill_rect(0, 0, cw, 2, fb_rgb(0x3E, 0x7D, 0xBF));

    fb_text(12, 10, "Шаблон: так выглядят свои приложения",
            fb_rgb(0x9A, 0xA3, 0xAC), -1);

    /* кнопка */
    u32 btn = d->pressed ? fb_rgb(0x2E, 0x53, 0x77) : fb_rgb(0x1E, 0x4A, 0x73);
    fb_fill_rect(BTN_X, BTN_Y, BTN_W, BTN_H, btn);
    fb_rect(BTN_X, BTN_Y, BTN_W, BTN_H, fb_rgb(0x3E, 0x7D, 0xBF));
    fb_text(BTN_X + (BTN_W - 7 * 8) / 2, BTN_Y + (BTN_H - 16) / 2,
            "Клик +1", fb_rgb(0xE6, 0xEA, 0xEE), -1);

    /* счётчик */
    char buf[48];
    snprintf(buf, sizeof(buf), "Нажатий: %d", d->count);
    fb_text(12, BTN_Y + BTN_H + 14, buf, fb_rgb(0xE6, 0xEA, 0xEE), -1);
}

static void example_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed)
{
    example_t *d = (example_t *)w->data;
    int inside = (mx >= BTN_X && mx < BTN_X + BTN_W &&
                  my >= BTN_Y && my < BTN_Y + BTN_H);

    if ((changed & MSB_LEFT) && inside && (buttons & MSB_LEFT)) {
        d->count++;      /* главное действие */
        d->pressed = 1;
        win_invalidate(w);
    }
    if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT)) {
        d->pressed = 0;
        win_invalidate(w);
    }
}

static void example_close(window_t *w)
{
    /* здесь освобождаем своё состояние */
    free(w->data);
}

void app_example_open(void)
{
    example_t *d = (example_t *)malloc(sizeof(example_t));
    if (!d) return;
    d->count = 0;
    d->pressed = 0;

    u32 W = fb_width(), H = fb_height();
    win_create("Пример приложения",
               (int)W / 2 - 120, (int)H / 2 - 70, 240, 150,
               example_draw, NULL, example_mouse, NULL, example_close, d);
}
