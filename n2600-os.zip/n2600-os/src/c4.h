/* c4.h — встроенный в N2600-OS компилятор/VM c4 (Robert Swierczek, порт).
 *
 * c4 — «C in four functions»: компилятор подмножества C в собственный
 * байт-код + стековая виртуальная машина, исполняющая этот байт-код.
 * Оригинал: https://github.com/rswier/c4
 *
 * В этой версии c4 встроен в ядро N2600-OS: исходник передаётся в память,
 * вывод (printf) направляется в предоставленный вызывающим буфер.
 * Поддерживается подмножество C: char/int/pointer, if/while/return,
 * функции, выражения; из «сискалов» VM — malloc/free/memset/memcmp/printf/
 * exit. Этого достаточно, чтобы компилировать и запускать простые программы.
 */
#ifndef C4_H
#define C4_H

#include "types.h"

/* Скомпилировать и выполнить исходник src.
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер под вывод printf() из выполняемой программы;
 *                 в этот же буфер пишутся сообщения об ошибках компиляции.
 *   out_max     — размер буфера out.
 * Возвращает: 0 при успехе (exit(0) или падение main), иначе -1. */
int c4_run(const char *src, char *out, u32 out_max);

/* Только скомпилировать исходник, не запуская VM.
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер для диагностики ошибок.
 *   out_max     — размер out.
 *   bytecode    — куда записать готовый байт-код (сегмент text).
 *   bytecode_max — ёмкость буфера байт-кода.
 *   bytecode_len — записанная длина байт-кода (в int-ячейках).
 *   data_seg    — куда записать сегмент данных (глобальные переменные).
 *   data_seg_max — ёмкость data_seg.
 *   data_seg_len — записанная длина (в байтах).
 *   entry_offset — смещение main в байт-коде (в int-ячейках от начала).
 * Возвращает: 0 при успехе, -1 при ошибке компиляции. */
int c4_compile(const char *src, char *out, u32 out_max,
               void *bytecode, u32 bytecode_max, u32 *bytecode_len,
               void *data_seg, u32 data_seg_max, u32 *data_seg_len,
               u32 *entry_offset);

/* Сохранить NATIVE x86 flat-binary в RAMFS под именем, полученным из source_name
 * заменой расширения .c на .bin.
 * Бинарник содержит:
 *   - x86 entry stub (точка входа void entry(kapi_t *k, void *win))
 *   - машинный код, сгенерированный из c4 IR (opcodes IMM/JMP/ADD/...)
 *   - сегмент данных
 * Запускается через loader_spawn() как обычное flat-binary приложение.
 *   source_name — имя файла исходника (например "prog.c").
 *   src         — C-исходник (NUL-terminated).
 *   out         — буфер для диагностики.
 *   out_max     — размер out.
 * Возвращает: 0 при успехе, -1 при ошибке. */
int c4_compile_to_file(const char *source_name, const char *src,
                      char *out, u32 out_max);

/* Сгенерировать native x86 flat-binary из c4 исходника.
 *   src         — C-исходник (NUL-terminated).
 *   diag        — буфер для диагностики ошибок.
 *   diag_max    — размер diag.
 *   out_buf     — куда записать машинный код.
 *   out_max     — ёмкость out_buf.
 *   out_size    — записанная длина (в байтах).
 * Возвращает: 0 при успехе, -1 при ошибке компиляции. */
int c4_compile_to_native(const char *src, char *diag, u32 diag_max,
                         void *out_buf, u32 out_max, u32 *out_size);

/* Загрузить c4-бинарник из RAMFS и запустить его как отдельное приложение
 * через loader_spawn(). Бинарник должен быть native flat-binary
 * (сгенерирован c4_compile_to_file).
 *   bin_name    — имя файла в RAMFS (например "prog.bin")
 *   win         — окно для приложения (NULL = создать потом)
 * Возвращает: tid задачи (>=1), или -1 при ошибке. */
int c4_load_and_run(const char *bin_name, void *win);

/* ----- Функции времени выполнения для native c4-программ (экспортируются
 * через kapi_t). Вызываются из сгенерированного x86-кода. ----- */

/* Вывод строки в буфер "текущей программы" — зависит от вызывающего
 * контекста (терминал, редактор). */
void c4_print_str(const char *s, u32 len);

/* Опрос события ввода (клавиатура). Записывает в out_buf[0..2]:
 *   [0]=ch, [1]=code, [2]=flags. Возвращает 0=нет события, 1=клавиша. */
int c4_event_poll(void *out_buf);

/* Formatted print для native c4-программ.
 *   fmt          — форматная строка (с %d/%s/%c/%x)
 *   nargs        — число аргументов ВКЛЮЧАЯ fmt (как в c4 PRTF)
 *   args_reversed — указатель на массив аргументов в ОБРАТНОМ порядке
 *                  (как они лежат на стеке c4: первый элемент = последний
 *                  аргумент в source, и т.д.). fmt НЕ входит в массив.
 * Запись идёт в текущий буфер c4_out (через c4_print_str). */
void c4_printf_va(const char *fmt, int nargs, int *args_reversed);

#endif /* C4_H */
