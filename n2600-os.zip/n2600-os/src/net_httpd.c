/* net_httpd.c — встроенный HTTP-сервер N2600-OS.
 *
 * Цель: «локалхост для теста» — проверка HTTP-клиентов (curl, браузер,
 * HTTP Trace) и сетевой подсистемы без внешней сети: соединение с
 * 127.0.0.1 замыкается внутри стека (loopback-пара в net.c).
 * Доступен снаружи через QEMU hostfwd: -netdev user,hostfwd=tcp::8080-:80
 *
 * Сессия 58 — файловый сервер: GET отдаёт файлы из папки www RAM disk
 * (создаётся автоматически с демо-страницей index.html), порт 80 на
 * всех интерфейсах; галочка «Веб-сервер» в Настройках → Сеть
 * (net_httpd_set_enabled), "httpd=0" в SETTINGS.CFG гасит автостарт.
 *
 * Страницы:
 *   / и /index.html — файл www/index.html (нет файла — статус системы);
 *   /sysinfo, /status — статусная страница системы;
 *   /hello           — text/plain;
 *   прочее           — файл www/<путь>; нет — 404.
 *
 * СЕССИЯ 60 — исправления по отчёту аудита httpd:
 *   CRITICAL:
 *    - сборка статусной страницы через APP-макрос с честными границами
 *      (раньше sizeof(page) - p при p-переполнении давало огромный
 *      size_t и snprintf писал за границу буфера);
 *    - длины ответов больше НЕ берутся как (u32)snprintf(...) (отрицательное
 *      значение даёт 0xFFFFFFFF и net_tcp_send читал resp[] за границей;
 *      Content-Length теперь всегда совпадает с фактической отправкой);
 *   HIGH:
 *    - FSM отправки файлов: один сегмент «в полёте», следующий — только
 *      после ACK (net_tcp_send_pending + net_httpd_poll из главного
 *      цикла); сокет НЕ закрывается, пока файл не дошёл (раньше при
 *      заполненном send-буфере цикл бросал файл недосланным);
 *    - idle-таймаут 30 с: клиент с открытым TCP без запроса (Slowloris)
 *      больше не держит слот вечно;
 *    - Content-Length у 500-ошибок считается честно (sizeof-1);
 *   MEDIUM:
 *    - метод сравнивается целиком: "GETTER"/"GETX" больше не GET
 *      (проверка p[3]==' ');
 *    - HEAD: как GET без тела (заголовки + Content-Length) — curl/браузеры
 *      больше не получают 501 на HEAD-проверки;
 *    - поиск в ramfs — ramfs_stat_ci (прямой, без статического массива
 *      ents[RAMFS_MAX_FILES] ~20 КиБ и без O(N)-копии на каждый запрос);
 *   LOW:
 *    - демо-страница сохраняется без завершающего NUL (sizeof-1);
 *    - SETTINGS.CFG читается целиком (раньше — максимум 255 байт);
 *    - трассировка в UART — только с #define HTTPD_DEBUG;
 *    - %XX-декодирование выполняется на месте (без strcpy-перекладки).
 *
 * Модель: полностью событийная (callback-и из net_poll + net_httpd_poll
 * из главного цикла) — отдельной задачи не нужно. Файлы до 16 КиБ
 * отправляются порциями по MSS «стоп-и-ждём» (буфер ретрансляции в
 * стеке один — retrans_buf; следующий сегмент только после ACK).
 */
#include "net_httpd.h"
#include "net.h"
#include "ramfs.h"
#include "mem.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

/* #define HTTPD_DEBUG — трассировка приёма/отправки в UART */

#define HTTPD_CONNS     4
#define HTTPD_REQ_MAX   1024
#define HTTPD_FILE_MAX  (16 * 1024)
#define HTTPD_CHUNK     1400    /* порция файла (< MSS 1460) */
#define HTTPD_HDR_MAX   256     /* максимум заголовка ответа */
#define HTTPD_PAGE_MAX  1300    /* тело статусной страницы */
#define HTTPD_OUT_MAX   (HTTPD_HDR_MAX + HTTPD_PAGE_MAX + 32)
#define HTTPD_IDLE_MS   30000   /* таймаут неактивности соединения */

typedef struct {
    int  sock;                    /* индекс TCP-сокета или -1 (свободно) */
    char req[HTTPD_REQ_MAX];
    u32  req_len;
    u32  last_activity;           /* тики последней активности (idle-таймаут) */
    /* --- FSM отправки (сессия 60): состояние живёт в слоте соединения,
     * а не в static-буферах функции — безопасно для будущих задач --- */
    char out[HTTPD_OUT_MAX];      /* заголовок (+ тело мелких страниц) */
    u32  out_len, out_off;
    char *fdata;                  /* тело файла (malloc) или NULL */
    u32  fsize, foff;
    /* СЕССИЯ 61: 1 = обработчик запроса выполняется ПРЯМО СЕЙЧАС в
     * контексте задачи-клиента (loopback доставляет recv_cb синхронно,
     * и обработчик может УСНУТЬ в IPC ramfs). Пока флаг поднят,
     * net_httpd_poll (kmain) НЕ трогает слот: прежде kmain-насос видел
     * «нечего слать» и ЗАКРЫВАЛ соединение из-под спящего обработчика —
     * ответ на / (ramfs_stat_ci+read через IPC) терялся целиком
     * («localhost ничего не отдаёт», «response timeout»). */
    int  in_handler;
} httpd_conn_t;

static httpd_conn_t g_conns[HTTPD_CONNS];
static int g_httpd_started = 0;
static int g_httpd_want = 1;      /* автостарт (SETTINGS.CFG "httpd=0" гасит) */

int net_httpd_running(void) { return g_httpd_started; }
int net_httpd_wanted(void)  { return g_httpd_want; }

/* ---------- слоты соединений ---------- */

static httpd_conn_t *httpd_slot_of_sock(int sock)
{
    if (sock < 0) return NULL;
    for (int i = 0; i < HTTPD_CONNS; i++)
        if (g_conns[i].sock == sock) return &g_conns[i];
    return NULL;
}

/* Сбросить слот: освободить тело файла, пометить свободным. */
static void httpd_slot_reset(httpd_conn_t *c)
{
    if (c->fdata) { free(c->fdata); c->fdata = NULL; }
    c->fsize = c->foff = 0;
    c->out_len = c->out_off = 0;
    c->req_len = 0;
    c->in_handler = 0;
    c->sock = -1;
}

/* Принудительно закрыть соединение (ошибка/таймаут/RST). */
static void httpd_conn_drop(httpd_conn_t *c)
{
    if (c->sock >= 0) {
        if (net_tcp_state(c->sock) != TCP_CLOSED)
            net_tcp_close(c->sock);
    }
    httpd_slot_reset(c);
}

/* Всё отправлено: вежливое закрытие (HTTP/1.0, Connection: close). */
static void httpd_conn_finish(httpd_conn_t *c)
{
#ifdef HTTPD_DEBUG
    {
        char dbg[64];
        snprintf(dbg, sizeof(dbg), "[httpd] done sock=%d\n", c->sock);
        serial_puts(dbg);
    }
#endif
    if (c->sock >= 0) net_tcp_close(c->sock);
    httpd_slot_reset(c);
}

/* ---------- FSM отправки (сессия 60) ---------- */

/* Прокачка отправки. Вызывается: (а) из httpd_reply_* сразу после
 * подготовки ответа; (б) из net_httpd_poll, когда предыдущий сегмент
 * получил ACK. Цикл останавливается: нечего слать (→ finish), ждём ACK
 * (→ poll продолжит) или соединение умерло (→ drop). */
static void httpd_pump(httpd_conn_t *c)
{
    while (c->sock >= 0) {
        /* HIGH: пока предыдущий сегмент не подтверждён пиром, следующий
         * слать нельзя — буфер ретрансляции в стеке ОДИН (retrans_buf),
         * потерянный кусок иначе не восстановить, и клиент получал бы
         * «connection reset» (CL обещал больше, чем реально ушло). */
        if (net_tcp_send_pending(c->sock)) return;
        if (net_tcp_state(c->sock) != TCP_ESTABLISHED) {
            httpd_conn_drop(c);
            return;
        }

        if (c->out_off < c->out_len) {
            int s = net_tcp_send(c->sock, c->out + c->out_off,
                                 c->out_len - c->out_off);
            if (s <= 0) { httpd_conn_drop(c); return; }
            c->out_off += (u32)s;
        } else if (c->fdata && c->foff < c->fsize) {
            u32 chunk = c->fsize - c->foff;
            if (chunk > HTTPD_CHUNK) chunk = HTTPD_CHUNK;
            int s = net_tcp_send(c->sock, c->fdata + c->foff, chunk);
            if (s <= 0) { httpd_conn_drop(c); return; }
            c->foff += (u32)s;
        } else {
            /* всё отправлено — закрываем (loopback-клиент мгновенно
             * увидит CLOSED, реальный получит FIN после данных) */
            httpd_conn_finish(c);
            return;
        }
        c->last_activity = timer_ticks();
    }
}

/* ---------- папка www: создать при старте + демо-страница ---------- */

static const char httpd_index_html[] =
    "<html><head><title>N2600-OS www</title></head><body>"
    "<h1>N2600-OS file server</h1>"
    "<p>Эта папка (www в RAM disk) отдаётся по HTTP, порт 80.</p>"
    "<ul>"
    "<li>Кладите файлы в папку www через приложение «Файлы»</li>"
    "<li><a href=\"/sysinfo\">Статус системы (/sysinfo)</a></li>"
    "<li><a href=\"/hello\">Тест (/hello)</a></li>"
    "</ul>"
    "</body></html>";

static void httpd_ensure_www(void)
{
    if (!ramfs_ready()) return;
    ramfs_mkdir("www");                    /* уже есть — ошибка игнорируется */
    ramfs_dirent_t de;
    if (!ramfs_stat_ci("www/index.html", &de)) {
        /* FIX (LOW): sizeof(...) - 1 — без завершающего NUL (раньше NUL
         * сохранялся в файл и попадал в Content-Length) */
        u32 L = (u32)sizeof(httpd_index_html) - 1;
        if (ramfs_create("www/index.html", L))
            ramfs_write("www/index.html", httpd_index_html, L);
    }
}

/* ---------- MIME по расширению ---------- */

static int httpd_ends_with(const char *s, const char *ext)
{
    u32 sl = (u32)strlen(s), el = (u32)strlen(ext);
    if (sl < el) return 0;
    const char *t = s + sl - el;
    for (u32 i = 0; i < el; i++) {
        char a = t[i], b = ext[i];
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b) return 0;
    }
    return 1;
}

static const char *httpd_mime(const char *path)
{
    if (httpd_ends_with(path, ".html") || httpd_ends_with(path, ".htm"))
        return "text/html; charset=utf-8";
    if (httpd_ends_with(path, ".css"))  return "text/css; charset=utf-8";
    if (httpd_ends_with(path, ".js"))   return "application/javascript";
    if (httpd_ends_with(path, ".json")) return "application/json";
    if (httpd_ends_with(path, ".png"))  return "image/png";
    if (httpd_ends_with(path, ".jpg") || httpd_ends_with(path, ".jpeg"))
        return "image/jpeg";
    if (httpd_ends_with(path, ".gif"))  return "image/gif";
    if (httpd_ends_with(path, ".bmp"))  return "image/bmp";
    if (httpd_ends_with(path, ".ico"))  return "image/x-icon";
    if (httpd_ends_with(path, ".svg"))  return "image/svg+xml";
    if (httpd_ends_with(path, ".mp3"))  return "audio/mpeg";
    /* текст/исходники/разметка — как текст */
    if (httpd_ends_with(path, ".txt") || httpd_ends_with(path, ".md") ||
        httpd_ends_with(path, ".log") || httpd_ends_with(path, ".c") ||
        httpd_ends_with(path, ".h")  || httpd_ends_with(path, ".cs") ||
                        httpd_ends_with(path, ".js") ||
        httpd_ends_with(path, ".cfg"))
        return "text/plain; charset=utf-8";
    return "application/octet-stream";
}

/* ---------- сборка ответов (сессия 60) ---------- */

/* Подготовить заголовок (+ мелкое тело) в per-conn буфере и начать
 * отправку. Длины честные: snprintf возвращает ТРЕБУЕМУЮ длину, которая
 * может превышать буфер — результат обрезается вручную до sizeof(out)
 * (FIX CRITICAL: раньше (u32)snprintf уходил за границу resp[]). */
static void httpd_reply_simple(httpd_conn_t *c, int is_head,
                               const char *status, const char *ctype,
                               const char *body, u32 body_len)
{
    int hl = snprintf(c->out, sizeof(c->out),
        "HTTP/1.0 %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %u\r\n"
        "Connection: close\r\n"
        "\r\n", status, ctype, (unsigned)body_len);
    if (hl < 0) hl = 0;
    if (hl > (int)sizeof(c->out)) hl = (int)sizeof(c->out);
    c->out_len = (u32)hl;
    c->out_off = 0;

    if (!is_head && body && body_len) {
        /* тела страниц/ошибок заведомо помещаются (CL совпадает с фактом) */
        u32 room = (u32)sizeof(c->out) - c->out_len;
        if (body_len > room) body_len = room;
        memcpy(c->out + c->out_len, body, body_len);
        c->out_len += body_len;
    }
    c->fdata = NULL;
    httpd_pump(c);
}

/* Тело статусной страницы (без заголовков). Возвращает длину (>=0).
 *
 * FIX (CRITICAL, сессия 60): сборка только через HTTPD_APP:
 *  - граница проверяется КАК INT до вычисления остатка: раньше
 *    sizeof(page) - p (size_t - int) при p >= размера буфера давало
 *    огромный size_t, page + p уходил за границу и следующий snprintf
 *    писал «куда попало»;
 *  - p прижимается к cap-1: snprintf возвращает требуемую длину и
 *    без прижима «переполнял» бы буфер даже без записи;
 *  - cap = 1300 — комментарий «< 1200 байт» больше не врёт. */
static int httpd_page_status(char *page, u32 cap)
{
    int p = 0;
#define HTTPD_APP(...) do { \
        if (p >= 0 && p < (int)cap) { \
            int n_ = snprintf(page + p, (u32)((int)cap - p), __VA_ARGS__); \
            if (n_ > 0) p += n_; \
            if (p > (int)cap - 1) p = (int)cap - 1; \
        } } while (0)

    char ipbuf[16];
    u32 ip = net_get_ip(), gw = net_get_gateway(), dns = net_dns_server();
    u32 mask = net_get_netmask();

    HTTPD_APP("<html><head><title>N2600-OS httpd</title></head><body>");
    HTTPD_APP("<h1>N2600-OS local httpd</h1>");
    HTTPD_APP("<p>Loopback works. Try also /hello</p><ul>");
    HTTPD_APP("<li>NIC: %s</li>",
              net_nic_present() ? net_nic_name() : "none (loopback only)");
    net_ntoa(ip, ipbuf, sizeof(ipbuf));
    HTTPD_APP("<li>IP: %s", ipbuf);
    net_ntoa(mask, ipbuf, sizeof(ipbuf));
    HTTPD_APP(" mask %s", ipbuf);
    net_ntoa(gw, ipbuf, sizeof(ipbuf));
    HTTPD_APP(" gw %s</li>", ipbuf);
    if (dns) {
        net_ntoa(dns, ipbuf, sizeof(ipbuf));
        HTTPD_APP("<li>DNS: %s</li>", ipbuf);
    }
    HTTPD_APP("<li>DHCP: %s</li>",
              net_dhcp_state() == DHCP_BOUND ? "bound" : "not bound");
    HTTPD_APP("<li>File server: /www, files: %d</li>",
              ramfs_ready() ? ramfs_file_count() : 0);
    HTTPD_APP("<li>Packets: tx=%u rx=%u</li>",
              (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
    {
        net_arp_entry_t dump[NET_ARP_CACHE_SIZE];
        int n = net_arp_dump(dump, NET_ARP_CACHE_SIZE);
        HTTPD_APP("<li>ARP cache: %d</li>", n);
    }
    /* Аптайм в секундах (1 тик = 1 мс). Счётчик тиков u32 — заворот
     * через ~49.7 суток (документировано аудитом сессии 60; для
     * статусной страницы принято). */
    HTTPD_APP("<li>Uptime: %u s</li>", (unsigned)(timer_ticks() / 1000u));
    HTTPD_APP("</ul></body></html>");
#undef HTTPD_APP
    if (p < 0) p = 0;
    page[p] = 0;
    return p;
}

static void httpd_reply_status(httpd_conn_t *c, int is_head)
{
    char page[HTTPD_PAGE_MAX];
    int pl = httpd_page_status(page, sizeof(page));
    httpd_reply_simple(c, is_head, "200 OK",
                       "text/html; charset=utf-8", page, (u32)pl);
}

static void httpd_reply_hello(httpd_conn_t *c, int is_head)
{
    static const char body[] = "Hello from N2600-OS local httpd!\n";
    httpd_reply_simple(c, is_head, "200 OK",
                       "text/plain; charset=utf-8", body, (u32)sizeof(body) - 1);
}

static void httpd_reply_404(httpd_conn_t *c)
{
    static const char body[] = "404 Not Found (N2600-OS httpd)\n";
    httpd_reply_simple(c, 0, "404 Not Found", "text/plain",
                       body, (u32)sizeof(body) - 1);
}

static void httpd_reply_500(httpd_conn_t *c, const char *body)
{
    httpd_reply_simple(c, 0, "500 Internal Error", "text/plain",
                       body, (u32)strlen(body));
}

/* ---------- файловый сервер ---------- */

/* Отдать файл из www (rampath — путь в RAM disk, без ведущего '/').
 * FIX (HIGH, сессия 60): файл отправляется через FSM — сокет не
 * закрывается, пока не ушёл целиком; причины отказа различаются и
 * имеют честный Content-Length (раньше был магический «22» при теле
 * в 23 байта). */
static void httpd_reply_file(httpd_conn_t *c, const char *rampath, int is_head)
{
    ramfs_dirent_t de;
    if (!ramfs_stat_ci(rampath, &de) || de.is_dir) {
        httpd_reply_404(c);
        return;
    }
    if (de.size == 0) {
        httpd_reply_500(c, "empty file\n");
        return;
    }
    if (de.size > HTTPD_FILE_MAX) {
        httpd_reply_500(c, "file too large (max 16384 bytes)\n");
        return;
    }

    char *buf = (char *)malloc(de.size);
    if (!buf) {
        httpd_reply_500(c, "out of memory\n");
        return;
    }
    u32 got = ramfs_read(rampath, buf, de.size);
    if (got == 0) {
        free(buf);
        httpd_reply_500(c, "read failed\n");
        return;
    }

    int hl = snprintf(c->out, sizeof(c->out),
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %u\r\n"
        "Connection: close\r\n"
        "\r\n", httpd_mime(rampath), (unsigned)got);
    if (hl < 0) hl = 0;
    if (hl > (int)sizeof(c->out)) hl = (int)sizeof(c->out);
    c->out_len = (u32)hl;
    c->out_off = 0;

    if (is_head) {
        free(buf);          /* HEAD: только заголовки с CL */
        c->fdata = NULL;
    } else {
        c->fdata = buf;     /* тело уйдёт из pump (порциями по ACK) */
        c->fsize = got;
        c->foff = 0;
    }
    httpd_pump(c);
}

/* ---------- обработка запроса ---------- */

/* Безопасность: в пути не должно быть ".." (выход из www). */
static int httpd_path_safe(const char *s)
{
    for (const char *p = s; *p; p++) {
        if (p[0] == '.' && p[1] == '.') return 0;
    }
    return 1;
}

/* Декодировать %XX ('+' как пробел НЕ делаем — путь файловой системы).
 * out_max включает место под NUL. Возвращает длину. Безопасен для
 * вызова с in == out: выходной индекс всегда <= входного. */
static u32 httpd_url_decode(char *inout, u32 out_max)
{
    u32 o = 0;
    for (u32 i = 0; inout[i] && o + 1 < out_max; i++) {
        if (inout[i] == '%' && inout[i + 1] && inout[i + 2]) {
            char h = inout[i + 1], l = inout[i + 2];
            int hv = -1, lv = -1;
            if (h >= '0' && h <= '9') hv = h - '0';
            else if (h >= 'a' && h <= 'f') hv = h - 'a' + 10;
            else if (h >= 'A' && h <= 'F') hv = h - 'A' + 10;
            if (l >= '0' && l <= '9') lv = l - '0';
            else if (l >= 'a' && l <= 'f') lv = l - 'a' + 10;
            else if (l >= 'A' && l <= 'F') lv = l - 'A' + 10;
            if (hv >= 0 && lv >= 0) {
                inout[o++] = (char)((hv << 4) | lv);
                i += 2;
                continue;
            }
        }
        inout[o++] = inout[i];
    }
    inout[o] = 0;
    return o;
}

static void httpd_respond(httpd_conn_t *c)
{
    /* первая строка: "GET <путь> HTTP/x" / "HEAD <путь> HTTP/x".
     * FIX (MEDIUM): метод сравнивается ЦЕЛИКОМ с разделителем —
     * "GETTER"/"GETX" больше не считаются GET (p[3] обязан быть ' ').
     * HEAD обслуживается как GET без тела (MEDIUM). */
    const char *p = c->req;
    while (*p == ' ' || *p == '\t') p++;
    int is_get  = (p[0] == 'G' && p[1] == 'E' && p[2] == 'T' && p[3] == ' ');
    int is_head = (p[0] == 'H' && p[1] == 'E' && p[2] == 'A' && p[3] == 'D'
                   && p[4] == ' ');
    const char *path = p;
    while (*path && *path != ' ') path++;       /* после метода */
    while (*path == ' ') path++;
    u32 path_len = 0;
    while (path[path_len] && path[path_len] != ' ' && path[path_len] != '\r')
        path_len++;

    char url[256];
    u32 ul = path_len < sizeof(url) - 1 ? path_len : (u32)sizeof(url) - 1;
    memcpy(url, path, ul);
    url[ul] = 0;
    /* отрезать query ?... */
    char *q = strchr(url, '?');
    if (q) *q = 0;
    /* FIX (LOW): декодируем на месте — без второго буфера и strcpy */
    httpd_url_decode(url, sizeof(url));

    if (!is_get && !is_head) {
        static const char body501[] = "501 Not Implemented\n";
        httpd_reply_simple(c, 0, "501 Not Implemented", "text/plain",
                           body501, (u32)sizeof(body501) - 1);
    } else if (!httpd_path_safe(url) || url[0] != '/') {
        httpd_reply_404(c);
    } else if (strcmp(url, "/sysinfo") == 0 || strcmp(url, "/status") == 0) {
        httpd_reply_status(c, is_head);
    } else if (strcmp(url, "/hello") == 0) {   /* точное имя: файлы вида
                                                * /hello.txt не перекрывать */
        httpd_reply_hello(c, is_head);
    } else {
        /* файл из www: "/" или "/..." → www<path>; каталог → index.html */
        char rampath[RAMFS_NAME_MAX + 1];
        const char *rel = url + 1;
        if (!*rel || rel[strlen(rel) - 1] == '/') {
            int L = (int)strlen(rel);
            /* FIX (сессия 59): 4 + L + 11 <= sizeof(rampath) */
            if (L + 15 <= (int)sizeof(rampath)) {
                memcpy(rampath, "www/", 4);
                memcpy(rampath + 4, rel, (u32)L);
                memcpy(rampath + 4 + L, "index.html", 11);
                rel = rampath;
            } else {
                rel = NULL;             /* слишком длинный путь — 404 ниже */
            }
        } else {
            int L = (int)strlen(rel);
            if (L + 4 >= (int)sizeof(rampath)) L = sizeof(rampath) - 5;
            memcpy(rampath, "www/", 4);
            memcpy(rampath + 4, rel, (u32)L);
            rampath[4 + L] = 0;
            rel = rampath;
        }
        ramfs_dirent_t de;
        if (rel == NULL) {
            httpd_reply_404(c);
        } else if (strcmp(url, "/") == 0 && !ramfs_stat_ci(rel, &de)) {
            /* "/" без www/index.html — статусная страница */
            httpd_reply_status(c, is_head);
        } else {
            httpd_reply_file(c, rel, is_head);
        }
    }
}

/* per-socket приём: данные запроса */
static void httpd_recv(int sock, u32 src_ip, u16 src_port,
                       const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    httpd_conn_t *c = httpd_slot_of_sock(sock);
    if (!c) return;   /* соединение уже закрыто нами — игнорируем */

    c->last_activity = timer_ticks();

    /* копим запрос */
    u32 room = HTTPD_REQ_MAX - 1 - c->req_len;
    u32 copy = len < room ? len : room;
#ifdef HTTPD_DEBUG
    {
        char dbg[64];
        snprintf(dbg, sizeof(dbg), "[httpd] recv sock=%d len=%u (total %u)\n",
                 sock, (unsigned)len, (unsigned)(c->req_len + copy));
        serial_puts(dbg);
    }
#endif
    memcpy(c->req + c->req_len, data, copy);
    c->req_len += copy;
    c->req[c->req_len] = 0;

    /* конец заголовков или переполнение → ответ */
    if (strstr(c->req, "\r\n\r\n") || strstr(c->req, "\n\n") ||
        c->req_len >= HTTPD_REQ_MAX - 1) {
        /* СЕССИЯ 61: помечаем слот «обработчик жив» — пока respond идёт
         * (в т.ч. УСЫПАЯ задачу-клиента в IPC ramfs), net_httpd_poll из
         * kmain не имеет права закрывать/прокачивать это соединение. */
        int sock0 = c->sock;
        c->in_handler = 1;
        httpd_respond(c);
        /* слот мог быть освобождён (finish при полной отправке) или
         * даже переиспользован новым accept — трогаем флаг только если
         * это ТО ЖЕ соединение */
        if (c->sock == sock0) c->in_handler = 0;
    }
}

/* входящее соединение */
static void httpd_accept(int new_sock, u32 remote_ip, u16 remote_port)
{
    (void)remote_ip; (void)remote_port;
    for (int i = 0; i < HTTPD_CONNS; i++) {
        if (g_conns[i].sock < 0) {
            httpd_conn_t *c = &g_conns[i];
            c->sock = new_sock;
            c->req_len = 0;
            c->req[0] = 0;
            c->out_len = c->out_off = 0;
            c->fdata = NULL;
            c->fsize = c->foff = 0;
            c->in_handler = 0;
            c->last_activity = timer_ticks();
            return;
        }
    }
    /* слотов нет — отказ */
    net_tcp_close(new_sock);
}

/* Сессия 60: вызывается из главного цикла ядра рядом с net_poll().
 * 1) FSM отправки: предыдущий сегмент получил ACK — шлём следующий кусок
 *    файла (сокет НЕ закрыт, пока файл не ушёл целиком);
 * 2) idle-таймаут: соединение без активности дольше HTTPD_IDLE_MS
 *    закрывается — клиент с открытым TCP и без запроса (Slowloris)
 *    больше не занимает слот вечно (4 таких соединения «съедали»
 *    сервер целиком). */
void net_httpd_poll(void)
{
    if (!g_httpd_started) return;
    u32 now = timer_ticks();
    for (int i = 0; i < HTTPD_CONNS; i++) {
        httpd_conn_t *c = &g_conns[i];
        if (c->sock < 0) continue;
        /* СЕССИЯ 61: обработчик запроса выполняется в задаче-клиенте
         * (возможно, уснул в IPC ramfs) — слот не трогаем ни насосом,
         * ни idle-таймаутом (см. комментарий в httpd_conn_t). */
        if (c->in_handler) continue;
        if (now - c->last_activity > HTTPD_IDLE_MS) {
            httpd_conn_drop(c);
            continue;
        }
        httpd_pump(c);
    }
}

/* Строка "httpd=0" в SETTINGS.CFG отключает автостарт.
 * FIX (LOW, сессия 60): файл читается ЦЕЛИКОМ (раньше — максимум
 * 255 байт: "httpd=0" во второй половине SETTINGS.CFG молча
 * игнорировался, а проверка n >= sizeof(buf) была мёртвым кодом). */
static void httpd_load_cfg(void)
{
    static int loaded = 0;
    if (loaded) return;
    loaded = 1;
    if (!ramfs_ready()) return;
    ramfs_dirent_t de;
    if (!ramfs_stat_ci("SETTINGS.CFG", &de) || de.is_dir) return;
    if (de.size == 0 || de.size > 8192) return;
    char *buf = (char *)malloc(de.size + 1);
    if (!buf) return;
    u32 n = ramfs_read("SETTINGS.CFG", buf, de.size);
    if (n == 0) { free(buf); return; }
    buf[n] = 0;
    for (char *p = buf; *p; ) {
        char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char save = *e; *e = 0;
        if (strncmp(p, "httpd=", 6) == 0) {
            if (strcmp(p + 6, "0") == 0) g_httpd_want = 0;
            else if (strcmp(p + 6, "1") == 0) g_httpd_want = 1;
        }
        *e = save;
        p = (*e) ? e + 1 : e;
    }
    free(buf);
}

void net_httpd_start(void)
{
    if (g_httpd_started) return;
    httpd_load_cfg();
    if (!g_httpd_want) {
        serial_puts("[httpd] отключён настройками (httpd=0 в SETTINGS.CFG)\n");
        return;
    }
    for (int i = 0; i < HTTPD_CONNS; i++) {
        httpd_slot_reset(&g_conns[i]);
        g_conns[i].req[0] = 0;
    }
    if (net_tcp_listen(80, httpd_accept, httpd_recv) < 0) {
        serial_puts("[httpd] cannot listen :80\n");
        return;
    }
    httpd_ensure_www();
    g_httpd_started = 1;
    serial_puts("[httpd] listening on :80 (все интерфейсы; файлы из www RAM disk)\n");
}

void net_httpd_stop(void)
{
    if (!g_httpd_started) return;
    for (int i = 0; i < HTTPD_CONNS; i++) {
        if (g_conns[i].sock >= 0) httpd_conn_drop(&g_conns[i]);
    }
    net_tcp_unlisten(80);
    g_httpd_started = 0;
    serial_puts("[httpd] остановлен\n");
}

/* Галочка в Настройках → Сеть. on=1 — запустить, 0 — остановить. */
void net_httpd_set_enabled(int on)
{
    g_httpd_want = on ? 1 : 0;
    if (on) net_httpd_start();
    else    net_httpd_stop();
}
