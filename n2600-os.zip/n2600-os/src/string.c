/* string.c — реализация минимальной библиотеки строк */
#include "string.h"

void *memset(void *dst, int c, u32 n)
{
    u8 *d = (u8 *)dst;
    while (n--) *d++ = (u8)c;
    return dst;
}

void *memcpy(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    while (n--) *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else if (d > s) {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

int memcmp(const void *a, const void *b, u32 n)
{
    const u8 *pa = (const u8 *)a, *pb = (const u8 *)b;
    while (n--) {
        if (*pa != *pb) return (int)*pa - (int)*pb;
        pa++; pb++;
    }
    return 0;
}

u32 strlen(const char *s)
{
    u32 n = 0;
    while (*s++) n++;
    return n;
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)(u8)*a - (int)(u8)*b;
}

int strncmp(const char *a, const char *b, u32 n)
{
    while (n && *a && *a == *b) { a++; b++; n--; }
    return n ? (int)(u8)*a - (int)(u8)*b : 0;
}

char *strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++) != 0) {}
    return dst;
}

char *strncpy(char *dst, const char *src, u32 n)
{
    char *d = dst;
    while (n && *src) { *d++ = *src++; n--; }
    while (n--) *d++ = 0;
    return dst;
}

/* ---- мини-vsnprintf: %s %c %d %u %x %X %p %%, флаг '0', ширина до 2 цифр ---- */

static int put_char(char *out, u32 n, u32 *pos, char c)
{
    if (*pos + 1 < n) out[*pos] = c;
    (*pos)++;
    return 1;
}

static int put_str(char *out, u32 n, u32 *pos, const char *s)
{
    while (*s) put_char(out, n, pos, *s++);
    return 1;
}

static int put_num(char *out, u32 n, u32 *pos, u32 val, int base, int upper,
                   int neg, char pad, int width)
{
    char buf[12];
    const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int i = 0, cnt = 0;
    if (val == 0) buf[i++] = '0';
    while (val) { buf[i++] = digits[val % (u32)base]; val /= (u32)base; }
    if (neg) { put_char(out, n, pos, '-'); cnt++; width--; }
    while (width > i) { put_char(out, n, pos, pad); cnt++; width--; }
    while (i--) { put_char(out, n, pos, buf[i]); cnt++; }
    return cnt;
}

int vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap)
{
    u32 pos = 0;
    if (n) out[0] = 0;

    while (*fmt) {
        if (*fmt != '%') { put_char(out, n, &pos, *fmt++); continue; }
        fmt++;
        if (*fmt == 0) break;

        char pad = ' ';
        int width = 0;
        if (*fmt == '0') { pad = '0'; fmt++; }
        while (*fmt >= '0' && *fmt <= '9' && width < 99) {
            width = width * 10 + (*fmt - '0');
            fmt++;
        }
        if (*fmt == 'l') fmt++; /* игнорируем 'l' (мы не печатаем 64-бит) */

        switch (*fmt) {
        case 's': {
            const char *s = __builtin_va_arg(ap, const char *);
            put_str(out, n, &pos, s ? s : "(null)");
            break;
        }
        case 'c':
            put_char(out, n, &pos, (char)__builtin_va_arg(ap, int));
            break;
        case 'd': {
            i32 v = __builtin_va_arg(ap, i32);
            u32 uv = (v < 0) ? (u32)(-v) : (u32)v;
            put_num(out, n, &pos, uv, 10, 0, v < 0, pad, width);
            break;
        }
        case 'u':
            put_num(out, n, &pos, __builtin_va_arg(ap, u32), 10, 0, 0, pad, width);
            break;
        case 'x':
            put_num(out, n, &pos, __builtin_va_arg(ap, u32), 16, 0, 0, pad, width);
            break;
        case 'X':
            put_num(out, n, &pos, __builtin_va_arg(ap, u32), 16, 1, 0, pad, width);
            break;
        case 'p': {
            put_str(out, n, &pos, "0x");
            put_num(out, n, &pos, (u32)(unsigned long)__builtin_va_arg(ap, void *),
                    16, 0, 0, '0', 8);
            break;
        }
        case '%':
            put_char(out, n, &pos, '%');
            break;
        default:
            put_char(out, n, &pos, '%');
            put_char(out, n, &pos, *fmt);
            break;
        }
        fmt++;
    }
    if (n) out[(pos < n) ? pos : n - 1] = 0;
    return (int)pos;
}

int snprintf(char *out, u32 n, const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(out, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

unsigned utf8_next(const char **ps)
{
    const unsigned char *s = (const unsigned char *)*ps;
    unsigned c;
    if (s[0] < 0x80) {
        c = s[0];
        *ps += 1;
    } else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        c = ((unsigned)(s[0] & 0x1F) << 6) | (s[1] & 0x3F);
        *ps += 2;
    } else {
        c = '?';
        do { *ps += 1; } while (((**ps) & 0xC0) == 0x80);
    }
    return c;
}
