/* Изолированные кейсы с корректным порядком page_url ДО brjs_start */
#define HOST_TEST 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef unsigned int  u32;
typedef unsigned char u8;
typedef short i16;

#include "../src/mquickjs.h"
#include "../src/brform.h"
#include "mqjs_host_stubs.h"
#include "../src/brjs.h"
#include "../src/mqjs_stdlib_os64.h"

/* FIX (Task 65): база brjs-функций в таблице = N - 11 (6 brjs_* + 5
 * js_ti_* из Task 64, замыкают таблицу) — как MQJS_BR_CFUNC_BASE_VALUE
 * в mquickjs_api.c. Прежнее "-6" после Task 64 указывало на js_ti_*:
 * alert/document.write связывались с чужими cfunc (P0b/P6 фейлы). */
#define CFUNC_BASE ((int)(sizeof(js_c_function_table) / sizeof(js_c_function_table[0])) - 14) /* Task 67: 9 brjs + 5 ti */

unsigned int brjs_host_ticks(void) { static unsigned t; return t += 10; }
int brjs_host_stack_range(unsigned int *lo, unsigned int *hi)
{ *lo = 0x10000000u; *hi = 0x7F000000u; return 1; }

static brjs_env_t e;

/* Task 67: заглушка fetch для XHR-теста T6 */
static int t67_fetch(void *ud, const char *url, char *out, int out_max)
{
    (void)ud;
    const char *d = (url && !strcmp(url, "/api/data")) ? "DATA-OK" : "";
    int n = (int)strlen(d);
    if (n > out_max) n = out_max;
    memcpy(out, d, (size_t)n);
    return n;
}

static void fresh(void)
{
    if (e.alive) brjs_stop(&e);
    memset(&e, 0, sizeof(e));
    if (brjs_start(&e, (const JSSTDLibraryDef *)&js_stdlib, CFUNC_BASE) != 0) {
        printf("brjs_start FAIL\n");
        exit(1);
    }
    brjs_set_page_url(&e, "https://test.example/page.html");  /* ПОСЛЕ start */
}

int main(void)
{
    int fails = 0;
#define CHECK(c, m) do { printf("%s: %s\n", (c) ? "OK" : "FAIL", m); if (!(c)) fails++; } while (0)

    /* P0: href изначально = page_url; скрипт без навигации не даёт nav */
    fresh();
    brjs_eval(&e, "var x = 1;", "p0");
    CHECK(!e.nav_pending, "P0: скрипт без навигации — nav нет");
    brjs_eval(&e, "alert(':' + location.href + ':');", "p0b");
    CHECK(strcmp(e.alert, ":https://test.example/page.html:") == 0,
           "P0b: href == page_url");

    /* P1: String() в MicroQuickJS возвращает undefined (особенность
     * движка, НЕ баг фикса) — фикс нигде String не использует */
    fresh();
    brjs_eval(&e, "alert(typeof String + '/' + String('ab'));", "p1");
    printf("   p1 (info) alert='%s'\n", e.alert);

    /* P2: location.href= */
    fresh();
    brjs_eval(&e, "location.href = 'https://go.example/next';", "p2");
    CHECK(e.nav_pending && strcmp(e.nav_url, "https://go.example/next") == 0,
          "P2: location.href=");

    /* P3: location.replace() */
    fresh();
    brjs_eval(&e, "location.replace('/relative/one');", "p3");
    if (!e.nav_pending || strcmp(e.nav_url, "/relative/one") != 0)
        printf("   p3 err='%s'\n", e.last_err);
    CHECK(e.nav_pending && strcmp(e.nav_url, "/relative/one") == 0,
          "P3: location.replace()");

    /* P4: window.location.href= */
    fresh();
    brjs_eval(&e, "window.location.href = 'https://go.example/w';", "p4");
    if (!e.nav_pending || strcmp(e.nav_url, "https://go.example/w") != 0)
        printf("   p4 err='%s'\n", e.last_err);
    CHECK(e.nav_pending && strcmp(e.nav_url, "https://go.example/w") == 0,
          "P4: window.location.href=");

    /* P5: window.location.replace() */
    fresh();
    brjs_eval(&e, "window.location.replace('/r2');", "p5");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/r2") == 0,
          "P5: window.location.replace()");

    /* P6: document.write/alert без навигации */
    fresh();
    brjs_eval(&e, "document.write('<b>hi</b>'); alert('ok');", "p6");
    CHECK(!e.nav_pending && e.wlen > 0 &&
          strcmp(e.wbuf_static, "<b>hi</b>") == 0, "P6: write+alert, nav нет");

    /* P7: self-href без навигации */
    fresh();
    brjs_eval(&e, "location.href = 'https://test.example/page.html';", "p7");
    CHECK(!e.nav_pending, "P7: self-href — nav нет");

    /* P8: document.location.href= */
    fresh();
    brjs_eval(&e, "document.location.href = '/d1';", "p8");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/d1") == 0,
          "P8: document.location.href=");

    /* P9: исключение до присвоения — nav нет */
    fresh();
    brjs_eval(&e, "undefined_fn(); location.href='/never';", "p9");
    CHECK(!e.nav_pending, "P9: исключение прерывает до присвоения");

    /* P10: fetch жив */
    fresh();
    brjs_eval(&e, "var r = fetch('u');", "p10");
    CHECK(!e.nav_pending, "P10: fetch, nav нет");

    /* Task 65 [JS-NAV2]: document.location = СТРОКА — подмена свойства
     * документа, глобальный объект location остаётся прежним. Раньше
     * детекция смотрела document.location только при ПУСТОМ nu — а он
     * всегда равен page_url, переход ТЕРЯЛСЯ (кнопка
     * <button onclick="document.location='/habrmirror/'">Перейти</button>). */
    fresh();
    brjs_eval(&e, "document.location = '/habrmirror/';", "p11");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/habrmirror/") == 0,
          "P11: document.location='/x/' (строка)");

    fresh();
    brjs_eval(&e, "document.location = 'https://go.example/d3';", "p12");
    CHECK(e.nav_pending && strcmp(e.nav_url, "https://go.example/d3") == 0,
          "P12: document.location='https://...' (строка)");

    /* self-присвоение строкой — перехода нет */
    fresh();
    brjs_eval(&e, "document.location = 'https://test.example/page.html';", "p13");
    CHECK(!e.nav_pending, "P13: document.location=self — nav нет");

    /* location = строка (глобальная подмена) — по-прежнему работает */
    fresh();
    brjs_eval(&e, "location = '/s1';", "p14");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/s1") == 0,
          "P14: location='/x/' (глобальная строка)");

    /* href объекта остался page_url, но document.location подменён —
     * переход берётся из document.location */
    fresh();
    brjs_eval(&e, "document.title='t'; document.location = '/after-title';", "p15");
    CHECK(e.nav_pending && strcmp(e.nav_url, "/after-title") == 0,
          "P15: document.location после document.title");

    /* ---------- Task 67: navigator / console / setTimeout / XHR ---------- */

    /* T1: navigator.userAgent — фича-детект больше не падает */
    fresh();
    {
        int rc = brjs_eval(&e,
            "var ua = navigator.userAgent;"
            "alert(typeof navigator + ':' + (ua.indexOf('N2600') >= 0));",
            "t1");
        CHECK(rc == 0 && strcmp(e.alert, "object:true") == 0,
              "T1: navigator.userAgent жив");
    }

    /* T2: console.log — без ReferenceError, сообщение доходит до env */
    fresh();
    {
        int rc = brjs_eval(&e, "console.log('hello', 42);", "t2");
        CHECK(rc == 0 && e.console_n >= 1 &&
              strcmp(e.console_last, "hello") == 0,
              "T2: console.log не убивает скрипт");
    }

    /* T3: setTimeout(fn, 0) — колбэк исполняется в конце eval */
    fresh();
    {
        int rc = brjs_eval(&e,
            "var hit = 0;"
            "setTimeout(function(){ hit = 1; }, 0);"
            "alert('s' + hit);",
            "t3");
        /* alert показывает hit ДО догона (0), колбэк — после */
        CHECK(rc == 0 && strcmp(e.alert, "s0") == 0,
              "T3a: setTimeout не мешает основному eval");
        brjs_eval(&e, "alert('e' + hit);", "t3b");
        /* колбэк уже исполнен при первом eval; hit — глобал */
        CHECK(strcmp(e.alert, "e1") == 0, "T3b: колбэк setTimeout исполнен");
    }

    /* T4: clearTimeout отменяет колбэк */
    fresh();
    {
        brjs_eval(&e,
            "var hit = 0;"
            "var id = setTimeout(function(){ hit = 1; }, 0);"
            "clearTimeout(id);",
            "t4");
        brjs_eval(&e, "alert('h' + hit);", "t4b");
        CHECK(strcmp(e.alert, "h0") == 0, "T4: clearTimeout отменяет");
    }

    /* T5: setTimeout(function(){ location.href=... }) — переход ловится */
    fresh();
    {
        brjs_eval(&e,
            "setTimeout(function(){ location.href = '/from-timer'; }, 0);",
            "t5");
        CHECK(e.nav_pending && strcmp(e.nav_url, "/from-timer") == 0,
              "T5: переход из setTimeout-колбэка");
    }

    /* T6: XHR shim поверх синхронного fetch */
    fresh();
    {
        e.fetch_ud = NULL;
        e.fetch_fn = t67_fetch;
        int rc = brjs_eval(&e,
            "var x = new XMLHttpRequest();"
            "var done = 0;"
            "x.onload = function(){ done = 1; };"
            "x.open('GET', '/api/data');"
            "x.send(null);"
            "alert(x.status + ':' + x.responseText + ':' + done);",
            "t6");
        CHECK(rc == 0 && strcmp(e.alert, "200:DATA-OK:1") == 0,
              "T6: XMLHttpRequest send/onload/responseText");
    }

    /* T7: location.search/hash/pathname разбираются */
    brjs_stop(&e);
    memset(&e, 0, sizeof(e));
    if (brjs_start(&e, (const JSSTDLibraryDef *)&js_stdlib, CFUNC_BASE) != 0) {
        printf("brjs_start FAIL (t7)\n");
        return 1;
    }
    brjs_set_page_url(&e, "https://test.example/dir/page.html?q=1&x=2#frag");
    brjs_eval(&e,
        "alert(location.pathname + '|' + location.search + '|' + location.hash);",
        "t7");
    CHECK(strcmp(e.alert, "/dir/page.html|?q=1&x=2|#frag") == 0,
          "T7: location.search/hash/pathname");

    /* T8: таймеры снимаются при смене страницы */
    fresh();
    brjs_eval(&e, "var hit = 0; setTimeout(function(){ hit = 1; }, 60000);", "t8");
    brjs_set_page_url(&e, "https://test.example/other.html");
    brjs_eval(&e, "alert('h' + hit);", "t8b");
    CHECK(strcmp(e.alert, "h0") == 0,
          "T8: смена страницы снимает таймеры");

    brjs_stop(&e);
    printf(fails ? "\n%d FAILURES\n" : "\nALL ISOLATED CASES PASSED\n", fails);
    return fails != 0;
}
