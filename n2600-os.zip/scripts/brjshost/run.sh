#!/bin/sh
# brjshost/run.sh — изолированные кейсы моста JS (test_brjs_cases.c).
# Линковка с mquickjs.c + mquickjs_api.c ЦЕЛИКОМ (не стабы): проверяет
# навигацию location=, таймеры, XHR-обёртку, console, navigator.
# Task 67: добавлен в run_all_host_tests.sh набором 9.
set -e
cd "$(dirname "$0")"
SRC=../../src
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
CFLAGS="-DHOST_TEST=1 -D_GNU_SOURCE -g -O1 -fsanitize=address,undefined -I. -I$SRC"
LD="-Wl,-allow-multiple-definition"

gcc $CFLAGS -c -o $TMP/mq.o   $SRC/mquickjs.c
gcc $CFLAGS -c -o $TMP/mqa.o  $SRC/mquickjs_api.c
gcc $CFLAGS -c -o $TMP/ks.o   kernel_stubs.c
gcc -g -O1 -fsanitize=address,undefined $LD -o $TMP/t_cases \
    ../test_brjs_cases.c $TMP/mq.o $TMP/mqa.o $TMP/ks.o -lm
ASAN_OPTIONS=detect_leaks=0:detect_odr_violation=0 timeout 60 $TMP/t_cases | tail -1
