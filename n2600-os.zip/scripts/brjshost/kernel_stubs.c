/* kernel_stubs.c — хост-заглушки ядерных символов для test_brjs_cases.
 * Task 67: изолированные кейсы моста (test_brjs_cases.c) линкуются с
 * mquickjs_api.c ЦЕЛИКОМ — он тянет fb/wm/task/ramfs/img/ti/c4 API,
 * которого на хосте нет. Все функции — no-ops; сигнатуры сверены
 * с src/*.h (fb.h, wm.h, task.h, timer.h, ramfs.h, imgsvc.h,
 * clipboard.h, textinput.h, c4.h). serial_puts печатает в stdout. */
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

typedef uint8_t      u8;
typedef uint32_t     u32;

/* serial.h */
void serial_puts(const char *s) { fputs(s, stdout); fflush(stdout); }

/* fb.h */
u32  fb_width(void)  { return 800; }
u32  fb_height(void) { return 600; }
u32  fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
void fb_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_fill_screen(u32 c) { (void)c; }
void fb_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_text(int x, int y, const char *s, u32 fg, int bg) { (void)x;(void)y;(void)s;(void)fg;(void)bg; }
void fb_blit_rgba(const u8 *rgba, int sw, int sh, int dx, int dy, int dw, int dh)
{ (void)rgba;(void)sw;(void)sh;(void)dx;(void)dy;(void)dw;(void)dh; }
void fb_flush(void) {}
void fb_touch_all(void) {}

/* wm.h: окно — непрозрачный указатель; тесты графику не трогают */
static int fake_win;
void *win_create(const char *title, int x, int y, int w, int h,
                 void *on_input, void *on_tick, void *on_close, void *data)
{ (void)title;(void)x;(void)y;(void)w;(void)h;(void)on_input;(void)on_tick;(void)on_close;(void)data;
  return &fake_win; }
void win_close(void *w) { (void)w; }
void win_invalidate(void *w) { (void)w; }
int  win_content_w(void *w) { (void)w; return 640; }
int  win_content_h(void *w) { (void)w; return 400; }
u32  wm_theme_win_bg(void)  { return 0xFFFFFF; }
u32  wm_theme_text(void)    { return 0x000000; }
u32  wm_theme_accent(void)  { return 0x0563C1; }

/* task.h */
int  task_spawn(const char *name, void (*fn)(void *), void *arg)
{ (void)name;(void)fn;(void)arg; return 0; }
const char *task_name(int i) { (void)i; return ""; }
int  task_used(int i) { (void)i; return 0; }
int  task_stack_range(int i, u32 *lo, u32 *hi) { (void)i; *lo = 0; *hi = 0; return 0; }
void task_yield(void) {}
void task_exit(void) {}
int  task_current(void) { return 0; }
int  task_finished(int t) { (void)t; return 1; }

/* timer.h */
u32  timer_ticks(void) { static u32 t; return t += 10; }
u32  uptime_sec(void)  { static u32 s; return ++s; }

/* ramfs.h (ramfs_dirent_t непрозрачен для теста — только по указателю) */
int  ramfs_create(const char *name, u32 size) { (void)name;(void)size; return 0; }
int  ramfs_write(const char *name, const void *buf, u32 size) { (void)name;(void)buf;(void)size; return 0; }
u32  ramfs_read(const char *name, void *buf, u32 max) { (void)name;(void)buf;(void)max; return 0; }
int  ramfs_delete(const char *name) { (void)name; return 0; }
int  ramfs_list(void *out, int max) { (void)out;(void)max; return 0; }
int  ramfs_stat_ci(const char *name, void *out) { (void)name;(void)out; return 0; }

/* imgsvc.h (img_t — по указателю) */
int  img_decode_url(const char *url, const char *base_url, void *out)
{ (void)url;(void)base_url;(void)out; return 0; }
int  img_scale(const void *src, int dw, int dh, void *out) { (void)src;(void)dw;(void)dh;(void)out; return 0; }
void img_dispose(void *t) { (void)t; }
int  img_open(const void *t) { (void)t; return 0; }
int  img_retain(int id) { (void)id; return 0; }
void img_release(int id) { (void)id; }
int  img_get(int id, void *out) { (void)id;(void)out; return 0; }

/* clipboard.h */
const char *clip_text_get(void) { return ""; }

/* textinput.h (рисование бокса — no-op) */
void ti_draw_box(void *ti, int x, int y, int w, int h)
{ (void)ti;(void)x;(void)y;(void)w;(void)h; }

/* c4.h: таблица GUI-колбэков интерпретатора c4 — в тестах не зовётся */
const void *const c4_gui_api = 0;
