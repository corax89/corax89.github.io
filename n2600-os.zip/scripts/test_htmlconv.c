/* test_htmlconv.c — ХОСТОВОЙ тест HTML->Markdown конвертера (src/htmlconv.c).
 *
 * Компилируется на Linux (Task 60: конвертер использует html_parser.c,
 * его нужно линковать тоже):
 *   gcc -DHOST_TEST -fsanitize=address,undefined \
 *       test_htmlconv.c ../src/htmlconv.c ../src/html_parser.c -o test_htmlconv
 * Запуск:                  timeout 10 ./test_htmlconv
 *   (timeout ловит регрессию бесконечного цикла FIX [H1] — старый код
 *    зависал намертво; ASAN ловит выход за границы буфера).
 *
 * Покрывает:
 *   [H1] регресс: текст после закрытого тега (раньше — infinite loop)
 *   [H3] entities в КОНЦЕ файла (&lt; требует ровно 4 байта остатка)
 *   [H4] закрывающие теги: </a>, </pre>, </ul> раньше читались как
 *        открывающие и ломали разметку
 *   переполнение буфера назначения (маленький md_max)
 *   двухоконную независимость (FIX [H2] на уровне API: буфер caller-а)
 *   Task 60 [HC-DOM]: конвертер на DOM-парсере — прежние ожидания
 *   сохранены, добавлены маркерные тесты (скрипты/формы) и [HC-PAIR]:
 *   гарантия парности \x01SCRIPT при обрезке буфера
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#undef HOST_TEST

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int fails = 0, total = 0;

static void expect(const char *name, const char *in, const char *want)
{
    char md[4096];
    int n = html_to_md(in, (int)strlen(in), md, (int)sizeof(md));
    total++;
    if (strcmp(md, want) == 0) {
        printf("PASS %-34s -> \"%.60s\"\n", name, md);
        (void)n;
    } else {
        fails++;
        printf("FAIL %s\n   got : \"%s\"\n   want: \"%s\"\n", name, md, want);
    }
}

/* подсчёт вхождений подстроки */
static int count_sub(const char *hay, const char *needle)
{
    int n = 0;
    int nl = (int)strlen(needle);
    for (const char *p = hay; (p = strstr(p, needle)) != NULL; p += nl)
        n++;
    return n;
}

int main(void)
{
    printf("=== htmlconv host test ===\n");

    /* --- базовые теги --- */
    /* закрывающие теги дают ENSURE_NL — хвостовой \n в конце вывода
     * нормален (браузер рисует построчно, хвостовой \n не виден) */
    expect("h1+p", "<h1>Title</h1><p>para one</p><p>two</p>",
           "# Title\n\npara one\n\ntwo\n");
    expect("h2", "<h2>Sub</h2>", "## Sub\n");
    expect("h4", "<h4>Deep</h4>", "#### Deep\n");
    expect("br", "a<br>b", "a\nb");
    expect("hr", "a<hr>b", "a\n---\nb");
    expect("bold/italic/code",
           "<b>bold</b> <i>it</i> <code>c</code>",
           "**bold** *it* `c`");
    expect("strong/em", "<strong>s</strong><em>e</em>", "**s***e*");
    /* ^ "**s**" от <strong>/</strong> + "*e*" от <em>/</em> */

    /* --- FIX [H1]: текст после закрытого тега (бывший infinite loop) --- */
    expect("text-after-close [H1]", "<b>x</b>tail", "**x**tail");
    expect("two tags then text [H1]",
           "<p>a</p><p>b</p>plain text after tags",
           "a\n\nb\nplain text after tags");
    /* ^ <p> при mi==0 даёт один \n (первые "if" опущены), затем "a";
     *   второй <p> при md[...]="a" даёт "\n\n" + "b"; далее обычный
     *   текст сразу после тега — раньше именно здесь зависали. */

    /* --- entities --- */
    expect("ents mix",
           "&quot;q&quot;&nbsp;&#39;s&#39;&gt;",
           "\"q\" 's'>");
    expect("amp mid", "x &amp; y", "x & y");
    expect("lt mid", "1 &lt; 2", "1 < 2");
    expect("gt mid", "2 &gt; 1", "2 > 1");
    /* FIX [H3]: entity ровно в конце файла */
    expect("lt at EOF [H3]", "a&lt;", "a<");
    expect("gt at EOF [H3]", "a&gt;", "a>");
    expect("amp at EOF [H3]", "a&amp;", "a&");
    expect("nbsp at EOF [H3]", "e&nbsp;", "e ");
    expect("quot at EOF [H3]", "q&quot;", "q\"");
    expect("39 at EOF [H3]", "s&#39;", "s'");
    /* неизвестный entity остаётся как есть */
    expect("unknown entity", "a&foo;b", "a&foo;b");
    /* Task 60: парсер даёт и именные мнемоники (UTF-8) */
    expect("named entity mdash", "a&mdash;b", "a\xE2\x80\x94""b");

    /* --- FIX [H4]: закрывающие теги --- */
    /* сессия 55: <a href> теперь даёт ПОЛНУЮ markdown-ссылку */
    expect("link [H4]", "See <a href=\"page.html\">docs</a> now",
           "See [docs](page.html) now");
    expect("link nohref", "See <a>docs</a> now",
           "See [docs]() now");
    expect("link anchor", "<a name=\"x\">top</a>", "[top]()");
    /* сессия 55: <img src> — строка-маркер ![alt](src) */
    expect("img marker", "before <img src=\"p/logo.png\" alt=\"logo\"> after",
           "before\n![logo](p/logo.png)\nafter");
    expect("img noalt", "<img src='x.png'>", "\n![](x.png)\n");
    expect("img nosrc", "<img alt=\"x\"> keep", "keep");
    /* сессия 55 (FIX залипания '=' в html_attr): второй атрибут ищется
     * после перепрыгивания значения первого */
    expect("img src+alt", "<img alt=\"A\" src=\"s.png\">", "\n![A](s.png)\n");
    expect("a href+rel", "<a rel=\"n\" href=\"h.html\">d</a>", "[d](h.html)");
    expect("pre close [H4]", "<pre>a  b</pre>after",
           "```\na  b\n```\nafter");
    expect("ul close [H4]", "<ul><li>one</li><li>two</li></ul>text",
           "- one\n- two\ntext");
    /* Task 60: содержимое <script> — маркеры для brform.h (не удаляется) */
    expect("script markers",
           "<script>var a = 1 < 2;</script>ok",
           "\x01SCRIPT\nvar a = 1 < 2;\n\x01/SCRIPT\nok");
    expect("style skip", "<style>.x{a:b}</style>ok", "ok");
    /* Task 60: внешний скрипт — SCRIPTSRC, поддерево пропущено */
    expect("scriptsrc",
           "<script src=\"a.js\"></script>ok",
           "\x01SCRIPTSRC src=\"a.js\"\nok");
    /* Task 60: textarea — RCDATA, значение сырое (entities декодированы) */
    expect("textarea",
           "<textarea name=\"t\">hi &amp; bye</textarea>",
           "\x01TEXTAREA name=\"t\"\nhi & bye\n\x01/TEXTAREA\n");
    /* Task 60 [HC-PH-JS]: input пишет ph=/js= ( brf_attr их читает),
     * прежде писались placeholder=/onclick= и терялись */
    expect("input ph/js",
           "<input type=\"text\" name=\"q\" placeholder=\"Poisk\" onclick=\"go()\">",
           "\x01INPUT type=\"text\" name=\"q\" ph=\"Poisk\" js=\"go()\"\n");
    expect("input checked",
           "<input type=\"checkbox\" name=\"c\" checked>",
           "\x01INPUT type=\"checkbox\" name=\"c\" checked\n");
    expect("meta refresh",
           "<meta http-equiv=\"Refresh\" content=\"3; url=/next\">",
           "\x01" "REFRESH content=\"3; url=/next\"\n");
    expect("form/select/option/button",
           "<form action=\"/s\" method=\"post\">"
           "<select name=\"s\"><option value=\"1\" selected>One</option></select>"
           "<button onclick=\"f()\">Go</button></form>",
           "\x01" "FORM action=\"/s\" method=\"post\"\n"
           "\x01" "SELECT name=\"s\"\n"
           "\x01" "OPT value=\"1\" selected label=\"One\"\n"
           "\x01" "/SELECT\n"
           "\x01" "BUTTON js=\"f()\" label=\"Go\"\n"
           "\x01" "/FORM\n");
    /* Task 60: нумерованный список и вложенность */
    expect("ol numbering", "<ol><li>a</li><li>b</li></ol>",
           "1. a\n2. b\n");
    expect("nested ul", "<ul><li>x<ul><li>y</li></ul></li></ul>",
           "- x\n  - y\n");
    /* атрибут с кавычкой внутри — экранируется в маркере */
    expect("attr quot escape",
           "<input type=\"text\" name=\"q\" value=\"a&quot;b\">",
           "\x01" "INPUT type=\"text\" name=\"q\" value=\"a&quot;b\"\n");

    /* --- незакрытый тег в конце файла (не виснет, добирает до EOF) --- */
    expect("unclosed tag EOF", "abc<div tail", "abc");
    /* ^ <div ...> читает имя до EOF, тега '>' нет -> элемент без детей;
     *   вывод только "abc". Главное — возврат за конечное время. */

    /* --- <script> без </script>: хвост уходит в код, блок ЗАКРЫТ --- */
    expect("unclosed script [B]",
           "<p>A</p><script>var x = 1; tail...",
           "A\n\x01SCRIPT\nvar x = 1; tail...\n\x01/SCRIPT\n");

    /* --- пробелы/переводы строк вне pre сжимаются --- */
    expect("ws squeeze", "a \t\n  b", "a b");
    /* Task 60 [HC-NOTRIM]: пробел на стыке инлайн-тегов сохраняется */
    expect("space between inline", "<b>bold</b> <i>it</i>", "**bold** *it*");

    /* --- FIX [H2]: буферы вызова независимы (два «окна») --- */
    {
        char w1[512], w2[512];
        const char *doc = "<h1>T</h1><ul><li>x &lt; y</li></ul><p>e</p>";
        html_to_md(doc, (int)strlen(doc), w1, (int)sizeof(w1));
        html_to_md(doc, (int)strlen(doc), w2, (int)sizeof(w2));
        total++;
        if (strcmp(w1, w2) == 0)
            printf("PASS two-windows independent       -> \"%s\"\n", w1);
        else {
            fails++;
            printf("FAIL two-windows: \"%s\" != \"%s\"\n", w1, w2);
        }
    }

    /* --- переполнение: маленький md_max --- */
    {
        char small[16];
        const char *big =
            "<h1>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</h1>";
        int tr = 0;
        int n = html_to_md2(big, (int)strlen(big), small, (int)sizeof(small), &tr);
        total++;
        if (n <= (int)sizeof(small) - 1 && small[n] == 0 &&
            n <= 15 && tr == 1) {
            printf("PASS truncation                    -> len=%d (<=15, tr=1)\n", n);
        } else {
            fails++;
            printf("FAIL truncation: n=%d tr=%d (md_max=16)\n", n, tr);
        }
    }

    /* --- Task 60 [HC-PAIR]: обрыв посреди <script> не даёт висячего
     *     маркера: блок закрывается или откатывается ЦЕЛИКОМ --- */
    {
        char small[32];
        int tr = 0;
        const char *doc =
            "<p>hello</p><script>var verylongcode = 123456;</script>tail";
        int n = html_to_md2(doc, (int)strlen(doc), small,
                            (int)sizeof(small), &tr);
        total++;
        if (tr == 1 &&
            count_sub(small, "\x01SCRIPT") ==
            count_sub(small, "\x01/SCRIPT") &&
            strchr(small, '\x01') == NULL) {
            printf("PASS [HC-PAIR] rollback, no dangling marker -> \"%s\"\n",
                   small);
            (void)n;
        } else {
            fails++;
            printf("FAIL [HC-PAIR]: tr=%d opens=%d closes=%d md=\"%s\"\n",
                   tr, count_sub(small, "\x01SCRIPT"),
                   count_sub(small, "\x01/SCRIPT"), small);
        }
    }

    /* --- [HC-PAIR]: буфер достаточен — блок закрыт честно --- */
    {
        char buf[256];
        int tr = 0;
        const char *doc = "<script>var x=1;</script>ok";
        html_to_md2(doc, (int)strlen(doc), buf, (int)sizeof(buf), &tr);
        total++;
        if (tr == 0 &&
            count_sub(buf, "\x01SCRIPT") == 1 &&
            count_sub(buf, "\x01/SCRIPT") == 1)
            printf("PASS [HC-PAIR] closed block\n");
        else {
            fails++;
            printf("FAIL [HC-PAIR] closed: tr=%d md=\"%s\"\n", tr, buf);
        }
    }

    /* --- дегенерированные входы --- */
    {
        char out[8];
        total++;
        if (html_to_md(NULL, 10, out, 8) == 0 && out[0] == 0) {
            printf("PASS null input\n");
        } else {
            fails++;
            printf("FAIL null input\n");
        }
        total++;
        if (html_to_md("x", 0, out, 8) == 0 && out[0] == 0) {
            printf("PASS zero len\n");
        } else {
            fails++;
            printf("FAIL zero len\n");
        }
        total++;
        /* md_max < 4 — отказ без записи */
        if (html_to_md("x", 1, out, 2) == 0) {
            printf("PASS tiny md_max\n");
        } else {
            fails++;
            printf("FAIL tiny md_max\n");
        }
    }

    /* --- большой документ: дымовой тест (ASAN ловит порчу) --- */
    {
        char *doc = (char *)malloc(1 << 20);
        char *out = (char *)malloc(2 << 20);
        int n, tr = 0;
        int doc_len = 0;
        doc_len += snprintf(doc + doc_len, 4096,
                            "<html><head><title>Big</title>"
                            "<meta http-equiv=\"refresh\" content=\"0\">"
                            "<style>.x{color:red}</style></head><body>");
        for (int i = 0; i < 400; i++) {
            doc_len += snprintf(doc + doc_len, 2048,
                                "<h2>Section %d</h2>"
                                "<p>Para <b>bold</b> <a href=\"/l?i=%d&amp;x=1\">link</a>.</p>"
                                "<ul><li>item one</li><li>item two</li></ul>"
                                "<script>var a%d = %d; location.reload;</script>"
                                "<img src=\"/img/%d.png\" alt=\"i%d\">",
                                i, i, i, i, i, i);
        }
        doc_len += snprintf(doc + doc_len, 64, "</body></html>");
        n = html_to_md2(doc, doc_len, out, (2 << 20), &tr);
        total++;
        if (n > 0 && n < (2 << 20) && out[n] == 0 && tr == 0 &&
            count_sub(out, "\x01SCRIPT") == 400 &&
            count_sub(out, "\x01/SCRIPT") == 400 &&
            count_sub(out, "![i") == 400) {
            printf("PASS big page smoke: %d bytes out\n", n);
        } else {
            fails++;
            printf("FAIL big page smoke: n=%d tr=%d opens=%d closes=%d imgs=%d\n",
                   n, tr, count_sub(out, "\x01SCRIPT"),
                   count_sub(out, "\x01/SCRIPT"), count_sub(out, "![i"));
        }
        free(doc);
        free(out);
    }

    /* ---------- Task 66 [HC-TRANSPARENT]: элементы внутри <pre> ----------
     * hc_close_frame не должен выдавать закрывающие эффекты для кадров,
     * открытых «прозрачным» спуском (прежде </code> давал лишний '`',
     * </b> — хвост '**'). */
    {
        char md[1024];
        expect("pre>code [HC-TRANSPARENT]",
               "<pre><code>x</code></pre>", "```\nx\n```\n");
        expect("pre>b [HC-TRANSPARENT]",
               "<pre><b>t</b></pre>", "```\nt\n```\n");
        expect("pre>a [HC-TRANSPARENT]",
               "<pre><a href=\"u\">t</a></pre>", "```\nt\n```\n");
        expect("script>span transparent",
               "<script>var x = 1;</script>after",
               "\x01SCRIPT\nvar x = 1;\n\x01/SCRIPT\nafter");
        /* обычный code вне pre — маркер работает как раньше */
        expect("code outside pre intact",
               "<p>a<code>c</code></p>", "a`c`\n");
    }

    /* ---------- Task 66 [HC-OPT-NOVALUE]: option без value ---------- */
    {
        char md[1024];
        const char *in = "<select name=\"s\"><option>Один</option>"
                         "<option value=\"2\">Два</option></select>";
        int n = html_to_md(in, (int)strlen(in), md, (int)sizeof(md));
        total++;
        if (n > 0 &&
            count_sub(md, "\x01OPT") == 2 &&
            strstr(md, "label=\"Один\"") != NULL &&
            strstr(md, "value=\"2\"") != NULL) {
            printf("PASS option без value -> маркер с label\n");
        } else {
            fails++;
            printf("FAIL option без value: OPT=%d md=\"%.90s\"\n",
                   count_sub(md, "\x01OPT"), md);
        }
    }

    /* ---------- Task 66 [HP-SKIP-VISUAL]: <svg> не просачивается ------- */
    {
        char md[1024];
        const char *in1 = "<p>до</p>"
            "<svg width=\"10\" height=\"10\"><path d=\"M68-.427.65-.928c.282\"/></svg>"
            "<p>после</p>";
        html_to_md(in1, (int)strlen(in1), md, (int)sizeof(md));
        total++;
        if (strstr(md, "до") != NULL && strstr(md, "после") != NULL &&
            strstr(md, "M68") == NULL && strstr(md, ".427") == NULL) {
            printf("PASS svg скрыт, контент вокруг цел\n");
        } else {
            fails++;
            printf("FAIL svg: md=\"%.90s\"\n", md);
        }
        /* iframe/object/canvas тоже не рисуются */
        const char *in2 = "<p>x</p><iframe src=\"z\">fallback text</iframe>"
                          "<p>y</p>";
        html_to_md(in2, (int)strlen(in2), md, (int)sizeof(md));
        total++;
        if (strstr(md, "x") != NULL && strstr(md, "y") != NULL &&
            strstr(md, "fallback") == NULL) {
            printf("PASS iframe скрыт\n");
        } else {
            fails++;
            printf("FAIL iframe: md=\"%.90s\"\n", md);
        }
    }

    /* ---------- Task 66: метки-ссылки, начинающиеся с 'h' --------------- */
    {
        char md[1024];
        html_to_md("<p>a: <a href=\"u\">h</a></p>",
                   25, md, (int)sizeof(md));
        total++;
        if (strcmp(md, "a: [h](u)\n") == 0)
            printf("PASS метка 'h' в ссылке\n");
        else {
            fails++;
            printf("FAIL метка 'h': md=\"%.60s\"\n", md);
        }
    }

    /* ---------- Task 67 [HC-HIDDEN]: hidden и display:none -------------- */
    expect("hidden attr [HC-HIDDEN]",
           "<p>виден</p><div hidden>секретное меню</div><p>и это</p>",
           "виден\n\nи это\n");
    expect("style display:none с пробелом [HC-HIDDEN]",
           "<p>a</p><span style=\"display: none\">счётчик 12345</span><p>b</p>",
           "a\n\nb\n");
    expect("style display:none без пробела [HC-HIDDEN]",
           "<p>a</p><div style=\"display:none\">x</div>b",
           "a\nb");
    expect("style visibility:hidden [HC-HIDDEN]",
           "<p>a</p><span style=\"visibility:hidden\">y</span>b",
           "a\nb");
    expect("не скрытый style не режется [HC-HIDDEN]",
           "<span style=\"color:red\">видно</span>",
           "видно");
    {
        /* aria-hidden БЕЗ CSS-движка не распознаётся (осознанное
         * ограничение [HC-HIDDEN]) — контент остаётся */
        char md[512];
        html_to_md("<div aria-hidden=\"true\">текст</div>",
                   (int)strlen("<div aria-hidden=\"true\">текст</div>"), md, (int)sizeof(md));
        total++;
        if (strstr(md, "текст") != NULL)
            printf("PASS aria-hidden остаётся (документировано)\n");
        else {
            fails++;
            printf("FAIL aria-hidden: md=\"%.60s\"\n", md);
        }
    }

    /* ---------- Task 67 [HC-BQ]: blockquote ------------------------------ */
    expect("blockquote [HC-BQ]",
           "<p>до</p><blockquote>цитата здесь</blockquote><p>после</p>",
           "до\n> цитата здесь\n\nпосле\n");

    /* ---------- Task 67 [HC-DL]: dl/dt/dd -------------------------------- */
    expect("dl/dt/dd [HC-DL]",
           "<dl><dt>Термин</dt><dd>Определение его</dd></dl>",
           "**Термин**\n  Определение его\n");

    /* ---------- Task 67 [HC-TBL]: таблица -> TSV ------------------------- */
    expect("table td [HC-TBL]",
           "<table><tr><td>A1</td><td>B1</td></tr>"
           "<tr><td>A2</td><td>B2</td></tr></table>",
           "A1\tB1\nA2\tB2\n");
    expect("table th/td [HC-TBL]",
           "<table><tr><th>Имя</th><th>Возраст</th></tr>"
           "<tr><td>Иван</td><td>30</td></tr></table>",
           "Имя\tВозраст\nИван\t30\n");

    /* ---------- Task 67 [HC-SUM]: summary/details ------------------------ */
    expect("summary как h3 [HC-SUM]",
           "<details><summary>Подробнее</summary>тело</details>",
           "### Подробнее\nтело\n");

    /* ---------- Task 67 [HC-ENC29]: ')' в href/img ----------------------- */
    {
        char md[512];
        html_to_md("<a href=\"http://en.wikipedia.org/wiki/Foo_(bar)\">wiki</a>",
                   (int)strlen("<a href=\"http://en.wikipedia.org/wiki/Foo_(bar)\">wiki</a>"), md, (int)sizeof(md));
        total++;
        if (strcmp(md,
                   "[wiki](http://en.wikipedia.org/wiki/Foo_%28bar%29)") == 0)
            printf("PASS href ')' -> %%29 [HC-ENC29]\n");
        else {
            fails++;
            printf("FAIL href %%29: md=\"%.80s\"\n", md);
        }
    }
    {
        char md[512];
        html_to_md("<img src=\"http://s/x(1).png\" alt=\"i\">",
                   (int)strlen("<img src=\"http://s/x(1).png\" alt=\"i\">"), md, (int)sizeof(md));
        total++;
        if (strstr(md, "x%281%29.png") != NULL)
            printf("PASS img src ')' -> %%29 [HC-ENC29]\n");
        else {
            fails++;
            printf("FAIL img %%29: md=\"%.80s\"\n", md);
        }
    }

    /* ---------- Task 67 [HC-AGGR]: флаг по умолчанию ВЫКЛ ---------------- */
    {
        char md[512];
        htmlconv_set_aggressive(0);
        html_to_md("<nav>меню</nav><p>статья</p>",
                   (int)strlen("<nav>меню</nav><p>статья</p>"), md, (int)sizeof(md));
        total++;
        if (strstr(md, "меню") != NULL && strstr(md, "статья") != NULL)
            printf("PASS aggressive=0: nav сохранён\n");
        else {
            fails++;
            printf("FAIL aggressive=0: md=\"%.60s\"\n", md);
        }
        htmlconv_set_aggressive(1);
        html_to_md("<nav>меню</nav><p>статья</p>",
                   (int)strlen("<nav>меню</nav><p>статья</p>"), md, (int)sizeof(md));
        total++;
        if (strstr(md, "меню") == NULL && strstr(md, "статья") != NULL)
            printf("PASS aggressive=1: nav выкинут\n");
        else {
            fails++;
            printf("FAIL aggressive=1: md=\"%.60s\"\n", md);
        }
        htmlconv_set_aggressive(0);   /* вернуть состояние по умолчанию */
    }

    /* ---------- Task 67 [HC-FUZZ]: инварианты на случайном HTML ----------
     * Детерминированный (xorshift32) генератор «супа тегов»: вложенные/
     * битые теги, pre/script/style/table/option, скрытый контент,
     * entities, 2- и 4-байтный UTF-8, длинные атрибуты, глубокая
     * вложенность. Проверяются ИНВАРИАНТЫ контракта html_to_md/html_to_md2:
     *   1) возврат в [0, md_max-1];
     *   2) md[ret] == 0 (NUL ровно на возвращённой длине);
     *   3) strlen(md) == ret (нет промежуточных NUL);
     *   4) байты за ret (канарка) не тронуты;
     *   5) при md_max < 4 — возврат 0 и md[0] == 0;
     *   6) повторный вызов на том же входе даёт тот же вывод (нет
     *      протечки состояния между вызовами). */
    {
        static const char *tok[] = {
            "<p>", "</p>", "<b>", "</b>", "<i>x</i>", "<br>", "<li>",
            "<pre>", "</pre>", "<code>", "</code>", "<script>",
            "</script>", "<style>", "</style>", "<table>", "<tr>",
            "<td>", "</td>", "</tr>", "</table>", "<select>",
            "<option>", "</option>", "</select>", "<blockquote>",
            "</blockquote>", "<dl><dt>t", "<dd>d", "</dl>", "<figure>",
            "<figcaption>f</figcaption>", "</figure>", "<details>",
            "<summary>s", "</summary>", "</details>", "<h1>", "</h1>",
            "<a href=\"http://x/y_(z)\">l</a>", "<img src=//c/p.png>",
            "<input onclick=\"", "\">", "<div hidden>hid</div>",
            "<span style=\"display:none\">inv</span>",
            "<nav>n</nav>", "<!-- comment -->", "</p>", "</div>",
            "<", ">", "&lt;", "&amp;", "&#65;", "&nbsp;", "текст",
            "кириллица", "\xF0\x9F\x98\x80", "a", " ", "\n",
            "style=\"visibility:hidden\"", "<noscript>ns</noscript>",
            "<iframe src=\"//i/x\"></iframe>", "<button>b</button>",
            "<textarea>t</textarea>", "<svg><path d=\"M0 0\"/></svg>",
        };
        const int NTOK = (int)(sizeof(tok) / sizeof(tok[0]));
        u32 seed = 0x67452301u;    /* детерминизм: падение воспроизводимо */
        char buf[8192];
        char *md = (char *)malloc(8192 + 64);
        char *first = (char *)malloc(8192 + 64);
#ifdef HC_FUZZ_ITERS
        long iters = HC_FUZZ_ITERS;
#else
        long iters = 2000;
#endif
        int fuzz_fail = 0;

        srand(12345);              /* независимый поток для md_max */
#define XS(s) ((*((s)) += 0x9E3779B9u),                       \
               (*(s) ^= *(s) << 13, *(s) ^= *(s) >> 17,       \
                *(s) ^= *(s) << 5), *(s))
        for (long it = 0; it < iters && !fuzz_fail; it++) {
            int ntok = 3 + (int)(XS(&seed) % 60);
            int bl = 0;
            buf[0] = 0;
            for (int k = 0; k < ntok; k++) {
                const char *t = tok[XS(&seed) % (u32)NTOK];
                int tl = (int)strlen(t);
                if (bl + tl + 1 >= (int)sizeof(buf)) break;
                memcpy(buf + bl, t, (size_t)tl);
                bl += tl;
                buf[bl] = 0;
            }
            for (int variant = 0; variant < 3 && !fuzz_fail; variant++) {
                int md_max;
                int ret, ret2, canary;
                char *can;

                if (variant == 2) {
                    md_max = 4 + (int)((unsigned)rand() % 300);
                } else {
                    md_max = 8192;
                }
                can = md + md_max;          /* канарка сразу за буфером */
                canary = 0x5A;
                *can = (char)canary;

                if (variant == 1)
                    ret = html_to_md(buf, bl, md, md_max);
                else
                    ret = html_to_md2(buf, bl, md, md_max, NULL);

                if (ret < 0 || ret > md_max - 1) {
                    printf("FAIL fuzz inv1: ret=%d md_max=%d it=%ld\n",
                           ret, md_max, it);
                    fuzz_fail = 1;
                    break;
                }
                if (md[ret] != 0) {
                    printf("FAIL fuzz inv2: md[ret]!=0 it=%ld\n", it);
                    fuzz_fail = 1;
                    break;
                }
                if ((int)strlen(md) != ret) {
                    printf("FAIL fuzz inv3: strlen!=ret it=%ld\n", it);
                    fuzz_fail = 1;
                    break;
                }
                if ((unsigned char)*can != (unsigned char)canary) {
                    printf("FAIL fuzz inv4: canary затёрт it=%ld\n", it);
                    fuzz_fail = 1;
                    break;
                }
                /* повтор — тот же вход, тот же результат (состояние
                 * конвертера не течёт между вызовами) */
                memcpy(first, md, (size_t)ret + 1);
                if (variant == 1)
                    ret2 = html_to_md(buf, bl, md, md_max);
                else
                    ret2 = html_to_md2(buf, bl, md, md_max, NULL);
                if (ret2 != ret ||
                    (ret > 0 && memcmp(md, first, (size_t)ret) != 0)) {
                    printf("FAIL fuzz inv6: нестабильный вывод it=%ld\n", it);
                    fuzz_fail = 1;
                    break;
                }
            }
            /* md_max < 4: контракт — 0 и md[0]=0 */
            if (!fuzz_fail && (it % 97) == 0) {
                int ret = html_to_md2(buf, bl, md, 2, NULL);
                if (ret != 0 || md[0] != 0) {
                    printf("FAIL fuzz inv5: md_max<4 ret=%d\n", ret);
                    fuzz_fail = 1;
                }
            }
        }
#undef XS
        free(md);
        free(first);
        total++;
        if (fuzz_fail) fails++;
        else printf("PASS fuzz: %ld итераций x 3 варианта, инварианты 1-6\n",
                    iters);
    }

    /* ---------- Task 67 [HP-ROOT-NOMATCH]: регресс стека парсера --------
     * Закрывающий тег с НЕИЗВЕСТНЫМ именем раньше «закрывал» корень
     * (stack[0], tag=UNKNOWN): depth обнулялся, следующий <script>/
     * <style>/<textarea> читал stack[-1] (UB/SEGV). Найдено фаззером
     * [HC-FUZZ]. */
    {
        char md[1024];
        const char *h1 = "</foobar><script>var a=1;</script><p>текст</p>";
        html_to_md(h1, (int)strlen(h1), md, (int)sizeof(md));
        total++;
        /* Маркер \x01SCRIPT...\x01/SCRIPT — штатный вывод конвертера
         * (вырезается brf_parse в браузере); регрессия — сам факт,
         * что стек НЕ обнулился: текст ПОСЛЕ </foobar> и скрипта
         * выживает, маркер парный. */
        if (strstr(md, "текст") != NULL &&
            count_sub(md, "\x01SCRIPT") == 1 &&
            count_sub(md, "\x01/SCRIPT") == 1)
            printf("PASS unknown-close: стек не обнулился\n");
        else {
            fails++;
            printf("FAIL unknown-close: md=\"%.60s\"\n", md);
        }
        const char *h2 = "</my-widget><style>.x{}</style><div>после</div>";
        html_to_md(h2, (int)strlen(h2), md, (int)sizeof(md));
        total++;
        if (strstr(md, "после") != NULL && strstr(md, ".x{}") == NULL)
            printf("PASS unknown-close+style: контент после сохранён\n");
        else {
            fails++;
            printf("FAIL unknown-close+style: md=\"%.60s\"\n", md);
        }
    }

    printf("=== %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
