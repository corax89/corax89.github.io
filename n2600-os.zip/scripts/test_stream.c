/* test_stream.c — ХОСТОВОЙ тест потоковой конвертации [HC-STREAM]
 * (src/htmlconv.c: hc_stream_begin / hc_stream_feed / hc_stream_finish /
 * hc_stream_abort / hc_stream_free + grow-хук).
 *
 * Компиляция:
 *   gcc -DHOST_TEST -D_GNU_SOURCE -g -O1 -fsanitize=address,undefined \
 *       test_stream.c ../src/htmlconv.c ../src/html_parser.c -o test_stream
 *
 * Покрывает:
 *   [ST1] эквивалентность: поток (кусками) == html_to_md2 (целиком)
 *   [ST2] куски ЛЮБОГО размера: 1..N байт, граница посреди тега/
 *         сущности/скрипта/стиля/комментария
 *   [ST3] grow-хук: старт с малого буфера, рост по мере надобности
 *   [ST4] hard_max: честная обрезка + truncated=1 (без порчи)
 *   [ST5] большой документ (~3 МБ HTML со скриптами/стилями):
 *         полный вывод, БЕЗ обреза — главный смысл Task 68
 *   [ST6] abort/free на полпути: без утечек и крашей (ASAN)
 *   [ST7] дегенеративные случаи: пустой feed, NULL, len<=0,
 *         feed после finish (no-op)
 */
#ifndef HOST_TEST
#define HOST_TEST
#endif
#include "../src/htmlconv.c"
#undef HOST_TEST

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

static int fails = 0, total = 0;

/* число вхождений байта-маркера \x01 (маркерные блоки всегда парны) */
static int count_eq(const char *s, char c)
{
    int n = 0;
    for (; *s; s++)
        if (*s == c) n++;
    return n;
}

static void ok(int cond, const char *fmt, ...)
{
    total++;
    if (cond) {
        printf("PASS ");
        va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap);
        printf("\n");
    } else {
        fails++;
        printf("FAIL ");
        va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap);
        printf("\n");
    }
}

/* ---------- grow-хук как в браузере (malloc+копия+free) ---------- */

struct gbuf { char *buf; int cap; int hard; int grows; };

static int test_grow(void *ud, char **md, int *max, int want)
{
    struct gbuf *g = (struct gbuf *)ud;
    if (want > g->hard) return 0;             /* потолок: отказ */
    char *nb = (char *)malloc((size_t)want);
    if (!nb) return 0;
    memcpy(nb, g->buf, (size_t)*max);
    free(g->buf);
    g->buf = nb;
    g->cap = want;
    g->grows++;
    *md = nb;
    *max = want;
    return 1;
}

/* Прогнать поток с куском размера chunk и (опционально) grow-хуком.
 * Возвращает md (malloc, владение у вызывателя) и *trunc. */
static char *stream_run(const char *html, int len, int chunk,
                        int start_cap, int hard_max, int *trunc,
                        int *grows_out, int *md_cap_out)
{
    struct gbuf g;
    memset(&g, 0, sizeof(g));
    g.cap = start_cap;
    g.hard = hard_max;
    g.buf = (char *)malloc((size_t)start_cap);

    hc_stream_t *hs = hc_stream_begin(g.buf, start_cap, hard_max,
                                      test_grow, &g);
    if (!hs) { free(g.buf); *trunc = 1; return NULL; }

    for (int i = 0; i < len; i += chunk) {
        int take = len - i < chunk ? len - i : chunk;
        hc_stream_feed(hs, html + i, take);
    }
    int md_len = hc_stream_finish(hs, trunc);
    hc_stream_free(hs);

    if (grows_out) *grows_out = g.grows;
    if (md_cap_out) *md_cap_out = g.cap;
    (void)md_len;
    return g.buf;                              /* NUL-терминирован finish'ем */
}

int main(void)
{
    printf("=== hc_stream host test ===\n");

    /* ---------- [ST1]/[ST2]: эквивалентность на репрезентативных
     * документах, куски 1/2/3/7/13/4096 байт ---------- */
    static const char *docs[] = {
        /* простой документ */
        "<html><head><title>T</title></head>"
        "<body><h1>Hello</h1><p>World &amp; more</p>"
        "<a href=\"/x?a=1&amp;b=2\">link</a></body></html>",
        /* скрипт/стиль в голове, текст в теле */
        "<html><head><style>body{color:red;background:url('x.png')}"
        "</style><script>var a=1;if(a<2){document.write('<b>hi</b>');}"
        "</script></head><body><p>after</p></body></html>",
        /* comment + условный IE + pre + таблица + список */
        "<body><!-- c <b>omment</b> --><!--[if IE]<p>old</p><![endif]-->"
        "<pre>line1\n  line2   &lt;tag&gt;</pre>"
        "<table><tr><td>a</td><td>b</td></tr></table>"
        "<ul><li>one</li><li>two</li></ul>",
        /* entities, разорванные по границам кусков */
        "<p>&lt;p&gt;&amp;&quot;&#39;&nbsp;end</p>",
        /* script в конце без закрывающего тега (обрыв сети) */
        "<html><body><p>t</p><script>var x='unterminated",
        /* форма/опции */
        "<form action=\"/go\"><select name=\"s\">"
        "<option value=\"1\">One</option><option>Two</option></select>"
        "<input type=\"text\" name=\"q\" placeholder=\"Search...\">"
        "</form>",
    };
    int nd = (int)(sizeof(docs) / sizeof(docs[0]));
    int chunks[] = { 1, 2, 3, 7, 13, 4096 };

    for (int d = 0; d < nd; d++) {
        const char *html = docs[d];
        int len = (int)strlen(html);

        /* эталон: буферизованный html_to_md2 с запасом */
        int ref_cap = len * 3 + 8192;
        char *ref = (char *)malloc((size_t)ref_cap);
        int rt = 0;
        int ref_len = html_to_md2(html, len, ref, ref_cap, &rt);

        for (int c = 0; c < (int)(sizeof(chunks) / sizeof(chunks[0])); c++) {
            int chunk = chunks[c];
            int trunc = 0, grows = 0, cap_out = 0;
            /* стартовый буфер МАЛЕНЬКИЙ (64) — заставляем grow-хук работать */
            char *got = stream_run(html, len, chunk, 64,
                                   ref_cap + 1024, &trunc, &grows, &cap_out);
            char name[80];
            snprintf(name, sizeof(name),
                     "[ST1] doc%d chunk=%d эквивалент (grows=%d)",
                     d, chunk, grows);
            int same = got && ref_len >= 0 &&
                       (int)strlen(got) == ref_len &&
                       memcmp(got, ref, (size_t)ref_len) == 0;
            ok(same && !trunc, "%s", name);
            if (!same) {
                printf("   ref(%d): \"%.120s\"\n", ref_len, ref);
                if (got) printf("   got(%u): \"%.120s\"\n",
                                (unsigned)strlen(got), got);
            }
            free(got);
        }
        free(ref);
    }

    /* ---------- [ST3]: grow-хук реально рос ---------- */
    {
        const char *big =
            "<p>" "abcdefghij" "</p>";
        for (int i = 0; i < 40; i++) { /* ~500 байт md при старте 64 */
            /* дублируем абзацы, чтобы точно превысить стартовую ёмкость */
        }
        char *html = (char *)malloc(1 << 16);
        html[0] = 0;
        for (int i = 0; i < 40; i++)
            strcat(html, "<p>abcdefghij0123456789</p>");
        int trunc = 0, grows = 0;
        char *got = stream_run(html, (int)strlen(html), 7, 64,
                               1 << 20, &trunc, &grows, NULL);
        ok(got && grows >= 3 && !trunc,
           "[ST3] grow-хук сработал (grows=%d, len=%u)",
           grows, got ? (unsigned)strlen(got) : 0u);
        free(got);
        free(html);
    }

    /* ---------- [ST4]: hard_max — честная обрезка ---------- */
    {
        char *html = (char *)malloc(1 << 16);
        html[0] = 0;
        for (int i = 0; i < 200; i++)
            strcat(html, "<p>abcdefghij0123456789</p>");
        int trunc = 0, grows = 0;
        char *got = stream_run(html, (int)strlen(html), 13, 256,
                               1024, &trunc, &grows, NULL);
        ok(got && trunc && (int)strlen(got) <= 1024,
           "[ST4] hard_max: trunc=%d len=%u (<=1024)",
           trunc, got ? (unsigned)strlen(got) : 0u);
        /* маркеры парные даже при обрезке */
        ok(!got || count_eq(got, '\x01') % 2 == 0,
           "[ST4] маркерные блоки парны при обрезке");
        free(got);
        free(html);
    }

    /* ---------- [ST5]: ~3 МБ HTML со скриптами/стилями — БЕЗ обреза ---------- */
    {
        int reps = 24000;                      /* ~3.1 МБ HTML */
        size_t unit_cap = 128;
        char *unit = (char *)malloc(unit_cap);
        snprintf(unit, unit_cap,
                 "<div class=\"c%d\"><script>var v%d=%d;f('%d');</script>"
                 "<style>.c%d{color:#%06x}</style>"
                 "<p>Пункт %d — текст абзаца для проверки.</p></div>",
                 0, 0, 0, 0, 0, 0, 0);
        size_t total_cap = (size_t)reps * strlen(unit) + 64;
        char *html = (char *)malloc(total_cap);
        html[0] = 0;
        char *w = html;
        for (int i = 0; i < reps; i++) {
            snprintf(unit, unit_cap,
                     "<div class=\"c%d\"><script>var v%d=%d;f('%d');</script>"
                     "<style>.c%d{color:#%06x}</style>"
                     "<p>Пункт %d — текст абзаца для проверки.</p></div>",
                     i, i, i, i, i, i & 0xffffff, i);
            memcpy(w, unit, strlen(unit));
            w += strlen(unit);
        }
        *w = 0;
        int len = (int)(w - html);

        int trunc = 0, grows = 0, cap_out = 0;
        char *got = stream_run(html, len, 1500, 256 * 1024,
                               8 * 1024 * 1024, &trunc, &grows, &cap_out);
        unsigned gl = got ? (unsigned)strlen(got) : 0u;
        ok(got && !trunc && gl > 100000,
           "[ST5] 3МБ HTML: поток -> %u б md, trunc=%d (html=%d, "
           "grows=%d, cap=%d)", gl, trunc, len, grows, cap_out);
        /* маркеры SCRIPT закрыты попарно */
        ok(!got || count_eq(got, '\x01') % 2 == 0,
           "[ST5] маркерные блоки парны на большом документе");
        free(got);
        free(html);
        free(unit);
    }

    /* ---------- [ST6]: abort на полпути (ASAN: без утечек/крашей) ---------- */
    {
        struct gbuf g;
        memset(&g, 0, sizeof(g));
        g.cap = 128;
        g.hard = 1 << 20;
        g.buf = (char *)malloc((size_t)g.cap);
        hc_stream_t *hs = hc_stream_begin(g.buf, g.cap, g.hard,
                                          test_grow, &g);
        ok(hs != NULL, "[ST6] begin на полпути");
        if (hs) {
            hc_stream_feed(hs, "<html><body><p>abc", 18);
            hc_stream_feed(hs, "<script>var x=1;</scr", 21);
            hc_stream_abort(hs);               /* без finish */
        }
        free(g.buf);                           /* владение у вызывателя */
        ok(1, "[ST6] abort прошёл (ASAN молчит = чисто)");
    }

    /* ---------- [ST7]: дегенеративные случаи ---------- */
    {
        /* NULL-стрим */
        hc_stream_feed(NULL, "x", 1);
        hc_stream_finish(NULL, NULL);
        hc_stream_abort(NULL);
        hc_stream_free(NULL);
        ok(1, "[ST7] NULL-стрим: no-op");

        /* begin с мусорными параметрами */
        ok(hc_stream_begin(NULL, 64, 0, NULL, NULL) == NULL,
           "[ST7] begin(NULL) -> NULL");
        char small[2];
        ok(hc_stream_begin(small, 2, 0, NULL, NULL) == NULL,
           "[ST7] begin(md_max<4) -> NULL");

        /* нормальный стрим: пустой feed / len<=0 / feed после finish */
        char buf[256];
        hc_stream_t *hs = hc_stream_begin(buf, (int)sizeof(buf), 0,
                                          NULL, NULL);
        ok(hs != NULL, "[ST7] begin без grow");
        if (hs) {
            hc_stream_feed(hs, "<p>x</p>", 8);
            hc_stream_feed(hs, "<p>y</p>", 0);      /* len=0 — no-op */
            hc_stream_feed(hs, NULL, 5);          /* NULL — no-op */
            int t = 0;
            int n = hc_stream_finish(hs, &t);
            ok(n > 0 && !t, "[ST7] finish вернул %d б", n);
            hc_stream_feed(hs, "<p>z</p>", 8);    /* после finish — no-op */
            int n2 = hc_stream_finish(hs, &t);    /* повторный finish */
            ok(n2 == n, "[ST7] повторный finish стабилен (%d)", n2);
            hc_stream_free(hs);
        }
    }

    printf("\n=== %d/%d passed, %d failed ===\n", total - fails, total, fails);
    return fails ? 1 : 0;
}
