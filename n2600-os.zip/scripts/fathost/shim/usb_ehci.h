#ifndef SHIM_USB_H
#define SHIM_USB_H
#include "types.h"
int  usb_ehci_read_sector(u32 lba, void *buf);
int  usb_ehci_write_sector(u32 lba, const void *buf);
int  usb_ehci_storage_ready(void);
/* Task 66 [USB-MULTI]: хост-шим — накопитель один (заглушки) */
int  usb_ehci_storage_count(void);
int  usb_ehci_storage_select(int idx);
int  usb_ehci_storage_active(void);
#endif
