/* fat32.c — драйвер FAT32 (чтение + запись) с backend-абстракцией.
 *
 * Поддерживает два backend'а:
 *   - ATA (HDD): fat32_init() — использует ata_read для секторов.
 *   - USB (флешка): fat32_init_usb() — использует usb_ehci_read_sector
 *     и usb_ehci_write_sector для секторов.
 *
 * Только один backend активен одновременно. Для переключения вызовите
 * соответствующую init-функцию (она переинициализирует BPB и состояние).
 *
 * Запись (через fat32_write_sector) работает только с USB-флешкой.
 */
#include "fat32.h"
#include "exfat.h"
#include "sync.h"

extern void serial_puts(const char *s);
#include "ata.h"
#include "disk.h"
#include "usb_ehci.h"
#include "mem.h"
#include "string.h"

static int  ready = 0;
static int  is_usb = 0;
/* СЕССИЯ 75: «личность» смонтированного тома. 1 = exFAT: все публичные
 * операции fat32_* прозрачно уходят в exfat.c (файловый менеджер,
 * диалоги и Настройки работают без изменений). */
static int  g_is_exfat = 0;

typedef struct {
    u16 bytes_per_sector;
    u8  sectors_per_cluster;
    u16 reserved_sectors;
    u8  num_fats;
    u32 total_sectors;
    u32 fat_size;
    u32 root_cluster;
} bpb_t;

static bpb_t bpb;
static u32   data_start = 0;
static u32   cluster_size = 0;
static u8   *cluster_buf = NULL;
static char  label[12];
static u32   g_base_lba = 0;     /* база раздела (0 = весь диск/superfloppy) */

/* Backend-абстракция: функция чтения сектора 512 байт. */
static int (*fat32_read_fn)(u32 lba, void *buf) = NULL;

/* Сессия 14: backend записи (объявлен ЗДЕСЬ — используется в fat32_init). */
static int (*fat32_write_fn)(u32 lba, const void *buf) = NULL;
static u32 g_free_hint = 2;   /* скользящий hint поиска свободного кластера */

static int fat32_write_ata(u32 lba, const void *buf) { return disk_hdd_write(g_base_lba + lba, 1, buf); }
/* FIX (запрос: флешка 8 ГБ не появляется в Файловом): + база раздела —
 * как у ATA. Прежде чтение/запись USB игнорировали g_base_lba: у флешки
 * с MBR (ЛЮБАЯ штатная флешка, отформатированная Windows) монтирование
 * «суперфлоппи» LBA0 всегда проваливалось, а смонтировать РАЗДЕЛ было
 * невозможно — база раздела не применялась к чтению. */
static int fat32_write_usb(u32 lba, const void *buf) { return usb_ehci_write_sector(g_base_lba + lba, buf); }

/* Обёртки для двух backend'ов. FIX [A1]: ATA-бэкенд читает НЖМД ЧЕРЕЗ
 * ata_read_hdd() — на машинах, где есть и HDD, и CD-ROM, активным
 * устройством ata_read() является CD (для iso9660), а FAT32 живёт
 * на НЖМД. Без этого fat32 не находил диск при подключённом CD.
 * Сессия 11: + база MBR-раздела (диск с таблицей разделов). */
static int fat32_read_ata(u32 lba, void *buf) { return disk_hdd_read(g_base_lba + lba, 1, buf); }
/* ФИКС (сессия 73): + база раздела — фикс потерялся при переносе:
 * правку получили fat32_write_usb и fat32_init_usb (перебор MBR), но
 * САМО ЧТЕНИЕ осталось сырым LBA — fat32_init_internal() с
 * g_base_lba = pstart читала MBR вместо загрузочного сектора раздела,
 * BPB-валидация проваливалась, кнопка [USB] не появлялась. */
static int fat32_read_usb(u32 lba, void *buf) { return usb_ehci_read_sector(g_base_lba + lba, buf); }

/* ================== [FAT-CACHE] ленивый кэш FAT в RAM ==================
 * Причина «копирование 15 секунд грузит CPU и только потом быстро
 * копирует»: прежний слой ходил на диск за КАЖДОЙ записью FAT —
 * next_cluster (шаг цепочки) = 1 сектор, fat32_set_fat = 1 чтение +
 * запись во все копии, а fat32_alloc_cluster сканировал свободные
 * кластеры ПО ОДНОЙ записи за вызов (каждая проба = чтение сектора).
 * На заполненном томе свободные кластеры далеко от hint — тысячи-
 * десятки тысяч секторных PIO/EHCI-операций с поллингом (100% CPU)
 * ДО начала записи данных.
 *
 * Решение: первая копия FAT кэшируется в RAM посекторно и ЛЕНИВО
 * (загружаются только реально затронутые сектора; монтирование не
 * дорожает), запись — сквозь кэш во ВСЕ копии FAT. Цепочки,
 * выделение и освобождение кластеров становятся memory-only. При
 * FAT больше FAT_CACHE_MAX или нехватке памяти — прежний дисковый
 * путь (без деградации). Все вызовы — под fat32_io_lock (все
 * прежние пользователи next_cluster/set_fat уже под ним). */
#define FAT_CACHE_MAX (32u * 1024u * 1024u)      /* FAT до 32 МиБ кэшируем */
static u8  *g_fatc      = NULL;   /* данные FAT1 (fsz секторов по 512)  */
static u8  *g_fatc_map  = NULL;   /* карта загруженных секторов         */
static u32  g_fatc_secs = 0;      /* fsz в секторах; >0 при g_fatc==NULL =
                                   * «не кэшируем» (решено, не пробовать) */
static int  s_fatc_logged = 0;    /* однократный лог-статус кэша        */

static void fatc_free(void)
{
    if (g_fatc)     { free(g_fatc);     g_fatc     = NULL; }
    if (g_fatc_map) { free(g_fatc_map); g_fatc_map = NULL; }
    g_fatc_secs   = 0;
    s_fatc_logged = 0;
}

/* 1 = кэш активен; 0 = нет (тогда дисковый путь). Выделяется при первом
 * обращении — bpb уже заполнен успешным монтированием. */
static int fatc_ensure(void)
{
    if (g_fatc) return 1;
    if (g_fatc_secs) return 0;
    u32 fsz   = bpb.fat_size;
    u32 bytes = fsz * 512u;
    if (!fsz || bytes > FAT_CACHE_MAX) { g_fatc_secs = fsz ? fsz : 1; }
    else {
        g_fatc = (u8 *)malloc(bytes);
        if (g_fatc) {
            g_fatc_map = (u8 *)malloc(fsz / 8 + 1);
            if (g_fatc_map) {
                memset(g_fatc_map, 0, fsz / 8 + 1);
                g_fatc_secs = fsz;
            } else {
                free(g_fatc); g_fatc = NULL; g_fatc_secs = fsz;
            }
        } else g_fatc_secs = fsz;
    }
    if (!s_fatc_logged) {
        s_fatc_logged = 1;
        char b[80];
        if (g_fatc)
            snprintf(b, sizeof(b),
                     "[fat32] кэш FAT: %u секторов (%u КиБ) в RAM\n",
                     g_fatc_secs, (unsigned)(bytes / 1024u));
        else
            snprintf(b, sizeof(b),
                     "[fat32] FAT без кэша (%u МиБ) — дисковый путь\n",
                     (unsigned)(bytes >> 20));
        serial_puts(b);
    }
    return g_fatc != NULL;
}

/* Сектор FAT1 по индексу: из кэша либо ленивая загрузка с диска.
 * NULL = ошибка чтения/вне диапазона. */
static u8 *fatc_sector(u32 idx)
{
    if (!g_fatc || idx >= g_fatc_secs) return NULL;
    u8 *p = g_fatc + idx * 512u;
    if (g_fatc_map[idx >> 3] & (u8)(1u << (idx & 7))) return p;
    if (!fat32_read_fn(bpb.reserved_sectors + idx, p)) return NULL;
    g_fatc_map[idx >> 3] |= (u8)(1u << (idx & 7));
    return p;
}

int fat32_ready(void)       { return ready; }
int fat32_is_usb(void)      { return is_usb; }
u32 fat32_root_cluster(void){
    if (g_is_exfat) return exfat_root_cluster();
    return bpb.root_cluster;
}
const char *fat32_label(void) {
    if (g_is_exfat) return exfat_label();
    return label;
}
/* СЕССИЯ 75: имя ФС смонтированного тома («FAT32» / «exFAT») — для
 * файлового менеджера и Настроек. */
const char *fat32_fsname(void) { return g_is_exfat ? "exFAT" : "FAT32"; }

static int read_cluster(u32 cluster, void *buf) {
    if (cluster < 2) return 0;
    u32 lba = data_start + (cluster - 2) * bpb.sectors_per_cluster;
    /* [FAT-BATCH] ATA/AHCI читают кластер ОДНОЙ командой (до 128 секторов):
     * прежний посекторный цикл на PIO занимал в разы дольше (drq-поллинг
     * на каждый 512-байтный сектор). USB-бэкенд остаётся посекторным. */
    if (!is_usb)
        return disk_hdd_read(g_base_lba + lba, bpb.sectors_per_cluster, buf);
    u8 *p = (u8 *)buf;
    for (u8 i = 0; i < bpb.sectors_per_cluster; i++) {
        if (!fat32_read_fn(lba + i, p + i * 512)) return 0;
    }
    return 1;
}

static u32 next_cluster(u32 cluster) {
    if (cluster < 2) return 0x0FFFFFFFu;
    /* [FAT-CACHE] шаг цепочки — из RAM (сектор грузится лениво один раз) */
    if (fatc_ensure()) {
        u32 off = cluster * 4;
        u8 *p = fatc_sector(off >> 9);
        if (!p) return 0x0FFFFFFFu;
        u32 e = off & 511u;
        return ((u32)p[e] | ((u32)p[e + 1] << 8) |
                ((u32)p[e + 2] << 16) | ((u32)p[e + 3] << 24)) & 0x0FFFFFFFu;
    }
    u32 off = cluster * 4;
    u32 sect = bpb.reserved_sectors + off / bpb.bytes_per_sector;
    u32 e    = off % bpb.bytes_per_sector;
    u8 sec[512];
    if (!fat32_read_fn(sect, sec)) return 0x0FFFFFFFu;
    u32 v = (u32)sec[e] | ((u32)sec[e+1] << 8) |
            ((u32)sec[e+2] << 16) | ((u32)sec[e+3] << 24);
    return v & 0x0FFFFFFFu;
}

/* Внутренняя инициализация (читает BPB, настраивает состояние). */
static int fat32_init_internal(void) {
    ready = 0;
    g_is_exfat = 0;
    fatc_free();          /* [FAT-CACHE] смена тома/бэкенда — кэш недействителен */

    u8 bs[512];
    if (!fat32_read_fn(0, bs)) {
        serial_puts("[fat32] LBA0 read failed\n");
        return 0;
    }
    if (bs[510] != 0x55 || bs[511] != 0xAA) {
        serial_puts("[fat32] no 55AA signature\n");
        return 0;
    }

    /* СЕССИЯ 75: exFAT-том? Сигнатура "EXFAT   " @3, BPB-поля на других
     * смещениях (bs[11] у exFAT — нули). Монтируем через exfat.c. */
    if (exfat_probe(bs)) {
        ready = 0;
        g_is_exfat = 1;
        if (exfat_mount(fat32_read_fn, fat32_write_fn)) {
            ready = 1;
            return 1;
        }
        g_is_exfat = 0;
        return 0;
    }
    g_is_exfat = 0;

    u16 bps = (u16)(bs[11] | (bs[12] << 8));
    if (bps != 512) {
        /* СЕССИЯ 73: причина отказа в serial — раньше молча return 0, и
         * по логу было не понять, почему флешка не появляется */
        char rb[64];
        snprintf(rb, sizeof(rb), "[fat32] BPB: bps=%u (нужен 512)\n", bps);
        serial_puts(rb);
        return 0;
    }
    u8  spc = bs[13];
    if (spc == 0 || (spc & (spc - 1))) {
        serial_puts("[fat32] BPB: spc не степень двойки\n");
        return 0;
    }
    u16 rsvd = (u16)(bs[14] | (bs[15] << 8));
    u8  nfat = bs[16];
    u32 tot  = (u32)bs[32] | ((u32)bs[33] << 8) | ((u32)bs[34] << 16) | ((u32)bs[35] << 24);
    u32 fsz  = (u32)bs[36] | ((u32)bs[37] << 8) | ((u32)bs[38] << 16) | ((u32)bs[39] << 24);
    u32 root = (u32)bs[44] | ((u32)bs[45] << 8) | ((u32)bs[46] << 16) | ((u32)bs[47] << 24);

    if (tot == 0 || fsz == 0 || nfat == 0 || root < 2) {
        serial_puts("[fat32] BPB: нулевые tot/fsz/nfat/root — не FAT32\n");
        return 0;
    }
    if (fsz > 0x10000u || nfat > 4 || rsvd < 1 || spc > 128 || tot < 0x10000u) {
        serial_puts("[fat32] BPB: нереалистичные поля — не FAT32\n");
        return 0;
    }

    u32 data_secs = tot - (rsvd + nfat * fsz);
    u32 clusters  = data_secs / spc;
    if (clusters < 65525u || root > clusters + 2) {
        serial_puts("[fat32] too few clusters for FAT32\n");
        return 0;
    }
    if ((u32)bps * spc > 0x10000u) {
        serial_puts("[fat32] BPB: bps*spc > 64К — не FAT32\n");
        return 0;
    }
    /* Сигнатура «FAT32» в BPB — НЕ обязательна: некоторые форматтеры
     * (камеры, Android, старые утилиты) её не пишут. Настоящий признак
     * FAT32 — clusters >= 65525 (проверено выше). Прежде жёсткий отказ
     * здесь отбрасывал корректные флешки. */
    if (memcmp(bs + 82, "FAT32", 5) != 0)
        serial_puts("[fat32] сигнатура FAT32 в BPB отсутствует — пропускаю проверку\n");

    bpb.bytes_per_sector    = bps;
    bpb.sectors_per_cluster = spc;
    bpb.reserved_sectors    = rsvd;
    bpb.num_fats            = nfat;
    bpb.total_sectors       = tot;
    bpb.fat_size            = fsz;
    bpb.root_cluster        = root;

    data_start   = rsvd + nfat * fsz;
    cluster_size = bps * spc;

    memcpy(label, bs + 71, 11); label[11] = 0;
    for (int i = 10; i >= 0 && label[i] == ' '; i--) label[i] = 0;

    if (cluster_buf) { free(cluster_buf); cluster_buf = NULL; }
    cluster_buf = (u8 *)malloc(cluster_size);
    if (!cluster_buf) {
        serial_puts("[fat32] нет памяти под cluster_buf\n");
        return 0;
    }

    ready = 1;
    return 1;
}

static volatile int fat32_io_lock = 0;   /* объявлена ниже, до первой use */

/* Сессия 12: снять монтирование (форматирование диска из Настроек).
 * Потокам-читателям отдаёт «не готово», чтобы не читать полу-стёртый FAT. */
void fat32_deinit(void)
{
    s_lock(&fat32_io_lock);
    ready = 0;
    g_base_lba = 0;
    g_is_exfat = 0;
    exfat_detach();
    fatc_free();          /* [FAT-CACHE] том снят — освободить кэш */
    s_unlock(&fat32_io_lock);
}

int fat32_init(void);
static int fat32_init_internal(void);

/* Сессия 11: диск может иметь MBR — FAT32 живёт в разделе. Пробуем
 * весь диск (superfloppy, все прежние тест-образцы), затем каждый
 * FAT32-раздел из MBR. Инициализация сериализована: её зовут и
 * фоновая задача sata, и файловый менеджер по клику [HDD]. */
int fat32_init(void) {
    int rc;
    s_lock(&fat32_io_lock);
    fat32_read_fn = fat32_read_ata;
    fat32_write_fn = fat32_write_ata;   /* сессия 14: запись на ATA (disk_hdd_write) */
    g_free_hint = 2;
    is_usb = 0;
    /* FIX [A1]: НЖМД может существовать ОТДЕЛЬНО от активного устройства
     * (если есть ATAPI CD, активен он). Проверяем ata_hdd_present(). */
    rc = 0;
    if (disk_hdd_present()) {
        g_base_lba = 0;
        rc = fat32_init_internal();
        if (!rc) {
            for (int i = 0; i < disk_part_count() && !rc; i++) {
                const char *ft = disk_part_fstype(i);
                if (strcmp(ft, "FAT32") != 0 && strcmp(ft, "exFAT") != 0)
                    continue;   /* СЕССИЯ 75: + exFAT-разделы */
                g_base_lba = disk_part(i)->start_lba;
                rc = fat32_init_internal();
            }
            if (!rc) g_base_lba = 0;
        }
    }
    s_unlock(&fat32_io_lock);
    return rc;
}

/* Сессия 25: смонтировать КОНКРЕТНЫЙ раздел (индекс в disk_part()).
 * Вызывается файловым менеджером при выборе тома-кнопки. Бэкенд — ATA.
 * 1 = успех (раздел смонтирован, прежнее монтирование заменено). */
int fat32_init_part(int part_index) {
    int rc;
    if (part_index < 0 || part_index >= disk_part_count()) return 0;
    s_lock(&fat32_io_lock);
    fat32_read_fn = fat32_read_ata;
    fat32_write_fn = fat32_write_ata;
    g_free_hint = 2;
    is_usb = 0;
    rc = 0;
    {
        const char *ft = disk_part_fstype(part_index);
        /* СЕССИЯ 75: принимаются разделы FAT32 И exFAT (0x07) */
        if (disk_hdd_present() &&
            (strcmp(ft, "FAT32") == 0 || strcmp(ft, "exFAT") == 0)) {
            g_base_lba = disk_part(part_index)->start_lba;
            rc = fat32_init_internal();
        }
    }
    if (!rc) g_base_lba = 0;
    s_unlock(&fat32_io_lock);
    return rc;
}

int fat32_init_usb(void) {
    int rc;
    s_lock(&fat32_io_lock);
    /* СЕССИЯ 61: состояние смонтированной FAT32 (НЖМД) сохраняем.
     * Прежде переключение read_fn/is_usb было глобальным и НЕОБРАТИМЫМ:
     * неудачное монтирование флешки (флешка NTFS/exFAT, не читается и
     * т.п.) оставляло ready=0 — и в Настройках «ФС: не распознана»
     * появлялось и у НЖМД («отваливается sata»), хотя SATA ни при чём.
     * Теперь при неудаче прежний том перемонтируется. */
    int (*saved_rfn)(u32, void *)       = fat32_read_fn;
    int (*saved_wfn)(u32, const void *) = fat32_write_fn;
    u32  saved_base   = g_base_lba;
    int  saved_is_usb = is_usb;
    int  was_ready    = ready;

    fat32_read_fn = fat32_read_usb;
    fat32_write_fn = fat32_write_usb;  /* сессия 14: запись на USB-флешке */
    g_free_hint = 2;
    is_usb = 1;
    rc = 0;
    /* СЕССИЯ 73: лог попытки — по нему видно, что автомонтаж ВООБЩЕ
     * запускался (раньше тихий провал выглядел как «флешки нет») */
    serial_puts(usb_ehci_storage_ready()
                ? "[fat32] usb: попытка монтирования\n"
                : "[fat32] usb: попытка монтирования — storage НЕ готов\n");
    if (usb_ehci_storage_ready()) {
        g_base_lba = 0;
        rc = fat32_init_internal();        /* суперфлоппи (FAT32 с LBA 0) */
        if (!rc) {
            /* FIX (запрос): флешки с MBR — как у ATA (fat32_init).
             * Штатно отформатированная флешка имеет таблицу разделов:
             * LBA 0 — MBR, а FAT32 сидит в разделе. Прежде перебора не
             * было вовсе, поэтому «флешка не появляется в Файловом».
             * Проход 1: типы FAT32 (0x0B/0x0C); проход 2: остальные
             * непустые записи (тип иногда врут; валидация BPB отсечёт
             * не-FAT). Расширенные разделы (0x05/0x0F) не читаем. */
            u8 mbr[512];
            if (fat32_read_usb(0, mbr) && mbr[510] == 0x55 && mbr[511] == 0xAA) {
                serial_puts("[fat32] usb: MBR есть — перебор разделов\n");
                for (int pass = 0; pass < 2 && !rc; pass++) {
                    for (int i = 0; i < 4 && !rc; i++) {
                        const u8 *e = mbr + 446 + i * 16;
                        u32 ptype  = e[4];
                        u32 pstart = (u32)e[8] | ((u32)e[9] << 8) |
                                     ((u32)e[10] << 16) | ((u32)e[11] << 24);
                        u32 psize  = (u32)e[12] | ((u32)e[13] << 8) |
                                     ((u32)e[14] << 16) | ((u32)e[15] << 24);
                        if (ptype == 0 || psize == 0) continue;   /* пустая запись */
                        int fat32ty = (ptype == 0x0B || ptype == 0x0C);
                        if (pass == 0 && !fat32ty) continue;
                        if (pass == 1 && fat32ty) continue;       /* уже пробовали */
                        if (ptype == 0x05 || ptype == 0x0F) continue; /* extended */
                        /* СЕССИЯ 84: лог на каждую пробуемую запись MBR —
                         * по нему на реальной флешке видно, ЧТО и ОТКУДА
                         * пробуем (запрос: «добавь больше логов»). */
                        {
                            char b[80];
                            extern int snprintf(char *o, u32 n, const char *f, ...);
                            snprintf(b, sizeof(b),
                                     "[fat32] usb: пробуем раздел %d (тип %02x) @ LBA %u\n",
                                     i, ptype, pstart);
                            serial_puts(b);
                        }
                        g_base_lba = pstart;
                        rc = fat32_init_internal();
                        if (rc) {
                            char b[80];
                            extern int snprintf(char *o, u32 n, const char *f, ...);
                            snprintf(b, sizeof(b),
                                     "[fat32] usb: раздел %d (тип %02x) @ LBA %u смонтирован\n",
                                     i, ptype, pstart);
                            serial_puts(b);
                        }
                    }
                }
            }
            if (!rc) g_base_lba = 0;    /* не смонтировалось — сброс базы */
        }
    }

    if (!rc) {
        /* Флешка не FAT32 / не читается — вернуть прежнюю ФС */
        serial_puts("[fat32] usb: не смонтирована (не FAT32 или ошибки чтения)\n");
        fat32_read_fn  = saved_rfn ? saved_rfn : fat32_read_ata;
        fat32_write_fn = saved_wfn ? saved_wfn : fat32_write_ata;
        is_usb     = saved_is_usb;
        g_base_lba = saved_base;
        if (was_ready) {
            /* fat32_init_internal сбросил ready — перемонтировать том */
            if (!fat32_init_internal()) {
                /* прежний том тоже не читается — честно пометить */
                ready = 0;
                g_base_lba = 0;
                is_usb = 0;
                fat32_read_fn  = fat32_read_ata;
                fat32_write_fn = fat32_write_ata;
            }
        }
    }
    s_unlock(&fat32_io_lock);
    return rc;
}

/* Task 66 [USB-MULTI]: смонтировать ПЕРВЫЙ ЧИТАЕМЫЙ USB-накопитель.
 * Раньше монтировался только ПОСЛЕДНИЙ перечисленный (единый слот),
 * и вторая флешка «не отображалась» (карта FAT32 + флешка exFAT). */
int fat32_init_usb_all(void)
{
    int n = usb_ehci_storage_count();
    if (n <= 0) return 0;
    if (usb_ehci_storage_active() < 0) usb_ehci_storage_select(0);
    if (fat32_init_usb()) return 1;
    for (int i = 0; i < n; i++) {
        if (i == usb_ehci_storage_active()) continue;
        usb_ehci_storage_select(i);
        if (fat32_init_usb()) {
            char b[64];
            snprintf(b, sizeof(b),
                     "[fat32] usb: смонтирован накопитель #%d\n", i);
            serial_puts(b);
            return 1;
        }
    }
    return 0;
}

/* Task 66 [USB-MULTI]: смонтировать СЛЕДУЮЩИЙ по кругу USB-накопитель
 * (пункт меню файлового менеджера «Другой USB-накопитель»). */
int fat32_init_usb_next(void)
{
    int n = usb_ehci_storage_count();
    if (n <= 0) return 0;
    int cur = usb_ehci_storage_active();
    if (cur < 0) cur = 0;
    for (int k = 1; k <= n; k++) {
        int i = (cur + k) % n;
        usb_ehci_storage_select(i);
        if (fat32_init_usb()) {
            char b[64];
            snprintf(b, sizeof(b),
                     "[fat32] usb: активен накопитель #%d\n", i);
            serial_puts(b);
            return 1;
        }
    }
    return 0;
}

static void u16_to_u8(const u16 *in, int n, char *out, int outmax) {
    int o = 0;
    for (int i = 0; i < n && in[i] && in[i] != 0xFFFF; i++) {
        u32 c = in[i];
        if (c < 0x80) {
            if (o + 1 >= outmax) break;
            out[o++] = (char)c;
        } else if (c < 0x800) {
            if (o + 2 >= outmax) break;
            out[o++] = (char)(0xC0 | (c >> 6));
            out[o++] = (char)(0x80 | (c & 0x3F));
        } else {
            if (o + 3 >= outmax) break;
            out[o++] = (char)(0xE0 | (c >> 12));
            out[o++] = (char)(0x80 | ((c >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (c & 0x3F));
        }
    }
    out[o] = 0;
}

/* FIX (многозадачность): список/чтение используют ОБЩИЙ cluster_buf и
 * кэш FAT — раньше их вызывал только kmain, теперь потоки приложений
 * (файловый менеджер, диалоги). Обёртки ниже сериализуют доступ.
 * (сам lock объявлен выше, рядом с fat32_init) */
int fat32_list(u32 dir_cluster, fat32_dirent_t *out, int max);
static int fat32_list_impl(u32 dir_cluster, fat32_dirent_t *out, int max);

static int fat32_list_impl(u32 dir_cluster, fat32_dirent_t *out, int max) {
    if (!ready || !cluster_buf || cluster_size == 0) return 0;
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;

    int n = 0;
    u16 lfn[260];
    int lfn_len = 0;
    u32 cluster = dir_cluster;

    u32 max_iters = (bpb.total_sectors / bpb.sectors_per_cluster) + 2;
    u32 iters = 0;

    while (cluster >= 2 && cluster < 0x0FFFFFF8u && iters++ < max_iters) {
        if (!read_cluster(cluster, cluster_buf)) break;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 *e = cluster_buf + off;
            if (e[0] == 0x00) return n;
            if (e[0] == 0xE5) { lfn_len = 0; continue; }

            u8 attr = e[11];
            if (attr == 0x0F) {
                u8 seq = e[0] & 0x1F;
                if (seq == 0 || seq > 20) { lfn_len = 0; continue; }
                int base = (seq - 1) * 13;
                if (base + 13 > 260) { lfn_len = 0; continue; }
                static const u8 ofs[13] = {1,3,5,7,9, 14,16,18,20,22,24, 28,30};
                for (int i = 0; i < 13; i++)
                    lfn[base + i] = (u16)e[ofs[i]] | ((u16)e[ofs[i]+1] << 8);
                if (base + 13 > lfn_len) lfn_len = base + 13;
                continue;
            }
            if ((attr & 0x08) && !(attr & 0x10)) { lfn_len = 0; continue; }

            fat32_dirent_t tmp;
            memset(&tmp, 0, sizeof(tmp));
            if (lfn_len > 0) {
                int lim = lfn_len;
                for (int i = 0; i < lim; i++)
                    if (lfn[i] == 0 || lfn[i] == 0xFFFF) { lim = i; break; }
                u16_to_u8(lfn, lim, tmp.name, FAT32_NAME_MAX);
                lfn_len = 0;
            } else {
                char n8[9], x3[4];
                memcpy(n8, e, 8); n8[8] = 0;
                memcpy(x3, e + 8, 3); x3[3] = 0;
                int k = 7; while (k >= 0 && n8[k] == ' ') n8[k--] = 0;
                k = 2; while (k >= 0 && x3[k] == ' ') x3[k--] = 0;
                if ((u8)n8[0] == 0x05) n8[0] = (char)0xE5;
                int p = 0;
                for (int i = 0; n8[i] && p < FAT32_NAME_MAX; i++) tmp.name[p++] = n8[i];
                if (x3[0]) {
                    if (p < FAT32_NAME_MAX) tmp.name[p++] = '.';
                    for (int i = 0; x3[i] && p < FAT32_NAME_MAX; i++) tmp.name[p++] = x3[i];
                }
                tmp.name[p] = 0;
            }
            tmp.attr = attr;
            tmp.size = (u32)e[28] | ((u32)e[29] << 8) | ((u32)e[30] << 16) | ((u32)e[31] << 24);
            tmp.first_cluster = (((u32)e[20] | ((u32)e[21] << 8)) << 16) | ((u32)e[26] | ((u32)e[27] << 8));

            if (!strcmp(tmp.name, ".") || !strcmp(tmp.name, "..")) continue;
            if (n < max) out[n++] = tmp;
        }
        cluster = next_cluster(cluster);
    }
    return n;
}

u32 fat32_read_file(u32 first_cluster, u32 size, void *buf, u32 max);
static u32 fat32_read_file_impl(u32 first_cluster, u32 size, void *buf, u32 max,
                                fs_progress_fn cb, void *ctx);

static u32 fat32_read_file_impl(u32 first_cluster, u32 size, void *buf, u32 max,
                                fs_progress_fn cb, void *ctx) {
    if (!ready || !cluster_buf) return 0;
    if (size > max) size = max;

    u8 *p = (u8 *)buf;
    u32 left = size;
    u32 cluster = first_cluster;

    u32 max_iters = (bpb.total_sectors / bpb.sectors_per_cluster) + 2;
    u32 iters = 0;

    while (left > 0 && cluster >= 2 && cluster < 0x0FFFFFF8u && iters++ < max_iters) {
        if (!read_cluster(cluster, cluster_buf)) break;
        u32 n = (left > cluster_size) ? cluster_size : left;
        memcpy(p, cluster_buf, n);
        p += n; left -= n;
        /* [FM-PROG]: прогресс после каждого кластера (один проход) */
        if (cb) cb(ctx, size - left, size);
        cluster = next_cluster(cluster);
    }
    return size - left;
}

/* Публичные обёртки: сериализация доступа к общим буферам FAT32. */
int fat32_list(u32 dir_cluster, fat32_dirent_t *out, int max) {
    int rc;
    s_lock(&fat32_io_lock);
    rc = g_is_exfat ? exfat_list(dir_cluster, out, max)
                    : fat32_list_impl(dir_cluster, out, max);
    s_unlock(&fat32_io_lock);
    return rc;
}

u32 fat32_read_file(u32 first_cluster, u32 size, void *buf, u32 max) {
    u32 rc;
    s_lock(&fat32_io_lock);
    rc = g_is_exfat ? exfat_read_file(first_cluster, size, buf, max)
                    : fat32_read_file_impl(first_cluster, size, buf, max, NULL, NULL);
    s_unlock(&fat32_io_lock);
    return rc;
}

/* [FM-PROG]: чтение с колбэком прогресса (fat32.h) */
u32 fat32_read_file_prog(u32 first_cluster, u32 size, void *buf, u32 max,
                         fs_progress_fn cb, void *cb_ctx) {
    u32 rc;
    s_lock(&fat32_io_lock);
    rc = g_is_exfat ? exfat_read_file_prog(first_cluster, size, buf, max,
                                           (exfat_progress_fn)cb, cb_ctx)
                    : fat32_read_file_impl(first_cluster, size, buf, max,
                                           cb, cb_ctx);
    s_unlock(&fat32_io_lock);
    return rc;
}

/* ===================== СЕССИЯ 14: ЗАПИСЬ В FAT32 =====================
 * (бэкенды и объявления — в начале файла; здесь — высокоуровневый слой.)
 * Запросы пользователя: «файлы создаются только в корне, но не в папках»
 * и «в пустом диске FAT32 не могу создавать файлы и каталоги».
 * Реализовано: set_fat (обе копии FAT), alloc/free цепочек, вставка
 * записей с LFN (UTF-8→UTF-16, кириллица) + генерация 8.3 (N2600~N),
 * рост каталога, mkdir с "."/"..", удаление, запись файла целиком.
 * Всё под fat32_io_lock, общий cluster_buf. */

static u32 fat32_total_clusters(void)
{
    /* FIX [FAT32-CLSTFIX] (анализ task57, критично): total_sectors — это
     * ВСЕ сектора тома, включая reserved + FAT-копии. Реальное число
     * кластеров области данных = (total − data_start) / spc. Прежнее
     * завышение на data_start/spc позволяло alloc/next_cluster выйти
     * за пределы FAT1: set_fat писал в первый сектор FAT2 и в начало
     * области данных (корневой каталог), write_cluster — за пределы тома
     * (порча соседних структур/за конец диска при заполнении диска). */
    if (!ready || g_is_exfat) return 0;
    if (bpb.total_sectors <= data_start) return 0;
    return (bpb.total_sectors - data_start) / (u32)bpb.sectors_per_cluster;
}

static int write_cluster(u32 cluster, const void *buf)
{
    if (cluster < 2) return 0;
    u32 lba = data_start + (cluster - 2) * bpb.sectors_per_cluster;
    /* [FAT-BATCH] запись кластера одной командой (ATA/AHCI) */
    if (!is_usb)
        return disk_hdd_write(g_base_lba + lba, bpb.sectors_per_cluster, buf);
    const u8 *p = (const u8 *)buf;
    for (u8 i = 0; i < bpb.sectors_per_cluster; i++) {
        if (!fat32_write_fn(lba + i, p + i * 512)) return 0;
    }
    return 1;
}

/* ---- модификация FAT: значение entry кластера cluster во ВСЕХ копиях ---- */
static u8  s_fat_sec[512];

static int fat32_set_fat(u32 cluster, u32 value)
{
    if (cluster < 2) return 0;
    u32 off  = cluster * 4;
    u32 idx  = off >> 9;
    u32 e    = off & 511u;
    /* [FAT-CACHE] правим копию в RAM и пишем сектор во ВСЕ копии FAT
     * прямо из кэша — предварительное чтение с диска не нужно */
    if (fatc_ensure()) {
        u8 *p = fatc_sector(idx);
        if (!p) return 0;
        p[e]     = (u8)(value & 0xFF);
        p[e + 1] = (u8)((value >> 8) & 0xFF);
        p[e + 2] = (u8)((value >> 16) & 0xFF);
        p[e + 3] = (u8)((value >> 24) & 0xFF);
        for (u8 i = 0; i < bpb.num_fats; i++) {
            if (!fat32_write_fn(bpb.reserved_sectors + i * bpb.fat_size + idx,
                                p))
                return 0;
        }
        return 1;
    }
    u32 sect = bpb.reserved_sectors + idx;
    if (!fat32_read_fn(sect, s_fat_sec)) return 0;
    s_fat_sec[e]     = (u8)(value & 0xFF);
    s_fat_sec[e + 1] = (u8)((value >> 8) & 0xFF);
    s_fat_sec[e + 2] = (u8)((value >> 16) & 0xFF);
    s_fat_sec[e + 3] = (u8)((value >> 24) & 0xFF);
    for (u8 i = 0; i < bpb.num_fats; i++) {
        if (!fat32_write_fn(bpb.reserved_sectors + i * bpb.fat_size + idx,
                            s_fat_sec))
            return 0;
    }
    return 1;
}

/* ---- выделение кластера (значение EOC), 0 = нет свободных ---- */
static u32 fat32_alloc_cluster(void)
{
    u32 total = fat32_total_clusters();
    if (total < 2) return 0;
    for (u32 tried = 0; tried < total; tried++) {
        if (g_free_hint < 2 || g_free_hint >= total + 2) g_free_hint = 2;
        u32 c = g_free_hint;
        u32 v = next_cluster(c);
        if (v == 0) {                       /* свободен */
            if (!fat32_set_fat(c, 0x0FFFFFF8u)) return 0;
            g_free_hint = c + 1;
            return c;
        }
        g_free_hint = c + 1;
    }
    return 0;
}

/* ---- освобождение всей цепочки ---- */
static void fat32_free_chain(u32 first)
{
    if (first < 2) return;
    u32 guard = fat32_total_clusters() + 2;
    u32 c = first;
    while (c >= 2 && c < 0x0FFFFFF8u && guard-- > 0) {
        u32 nx = next_cluster(c);
        fat32_set_fat(c, 0);
        if (nx == 0 || nx >= 0x0FFFFFF8u) break;
        c = nx;
    }
}

/* ---- сравнение имён без учёта регистра (ASCII; прочее байт-в-байт) ---- */
static int fat32_name_eq(const char *a, const char *b)
{
    while (*a && *b) {
        char x = *a, y = *b;
        if (x >= 'A' && x <= 'Z') x += 32;
        if (y >= 'A' && y <= 'Z') y += 32;
        if (x != y) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

/* ---- позиция записи в каталоге ---- */
typedef struct {
    u32 dir_cluster;   /* кластер каталога со слотом 8.3 */
    u32 dir_off;       /* смещение слота 8.3 в кластере */
    int lfn_count;     /* LFN-записей перед слотом (для delete) */
    u32 first_cluster;
    u32 size;
    u8  attr;
    int found;
} fat32_slot_t;

/* ---- поиск записи по имени (регистронезависимо, LFN и 8.3) ---- */
static int fat32_find_slot(u32 dir_cluster, const char *name, fat32_slot_t *out)
{
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;
    memset(out, 0, sizeof(*out));

    u16 lfn[260];
    int lfn_len = 0;
    u32 cluster = dir_cluster;
    u32 guard = fat32_total_clusters() + 2;

    while (cluster >= 2 && cluster < 0x0FFFFFF8u && guard-- > 0) {
        if (!read_cluster(cluster, cluster_buf)) break;
        int lfn_cnt = 0;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 *e = cluster_buf + off;
            if (e[0] == 0x00) break;
            if (e[0] == 0xE5) { lfn_len = 0; lfn_cnt = 0; continue; }
            u8 attr = e[11];
            if (attr == 0x0F) {
                lfn_cnt++;
                u8 seq = e[0] & 0x1F;
                if (seq == 0 || seq > 20) { lfn_len = 0; lfn_cnt = 0; continue; }
                int base = (seq - 1) * 13;
                if (base + 13 > 260) { lfn_len = 0; lfn_cnt = 0; continue; }
                static const u8 ofs[13] = {1,3,5,7,9, 14,16,18,20,22,24, 28,30};
                for (int i = 0; i < 13; i++)
                    lfn[base + i] = (u16)e[ofs[i]] | ((u16)e[ofs[i]+1] << 8);
                if (base + 13 > lfn_len) lfn_len = base + 13;
                continue;
            }
            if ((attr & 0x08) && !(attr & 0x10)) { lfn_len = 0; lfn_cnt = 0; continue; }

            /* имя записи */
            char nm[FAT32_NAME_MAX + 1];
            if (lfn_len > 0) {
                int lim = lfn_len;
                for (int i = 0; i < lim; i++)
                    if (lfn[i] == 0 || lfn[i] == 0xFFFF) { lim = i; break; }
                u16_to_u8(lfn, lim, nm, FAT32_NAME_MAX);
                lfn_len = 0;
            } else {
                char n8[9], x3[4];
                memcpy(n8, e, 8); n8[8] = 0;
                memcpy(x3, e + 8, 3); x3[3] = 0;
                int k = 7; while (k >= 0 && n8[k] == ' ') n8[k--] = 0;
                k = 2; while (k >= 0 && x3[k] == ' ') x3[k--] = 0;
                if ((u8)n8[0] == 0x05) n8[0] = (char)0xE5;
                int p = 0;
                for (int i = 0; n8[i] && p < FAT32_NAME_MAX; i++) nm[p++] = n8[i];
                if (x3[0]) {
                    if (p < FAT32_NAME_MAX) nm[p++] = '.';
                    for (int i = 0; x3[i] && p < FAT32_NAME_MAX; i++) nm[p++] = x3[i];
                }
                nm[p] = 0;
            }
            if (!strcmp(nm, ".") || !strcmp(nm, "..")) { lfn_cnt = 0; continue; }

            if (fat32_name_eq(nm, name)) {
                out->dir_cluster = cluster;
                out->dir_off = off;
                out->lfn_count = lfn_cnt;
                out->first_cluster = (((u32)e[20] | ((u32)e[21] << 8)) << 16) |
                                      ((u32)e[26] | ((u32)e[27] << 8));
                out->size = (u32)e[28] | ((u32)e[29] << 8) |
                            ((u32)e[30] << 16) | ((u32)e[31] << 24);
                out->attr = attr;
                out->found = 1;
                return 1;
            }
            lfn_cnt = 0;
        }
        cluster = next_cluster(cluster);
    }
    return 0;
}

/* ---- генерация 8.3-имени (кандидат № try) ---- */
static int sfn_safe(char c)
{
    return (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
           c == '_' || c == '$' || c == '-' || c == '{' || c == '}';
}
static void fat32_sfn_candidate(const char *lfn, int try, u8 out11[11])
{
    memset(out11, ' ', 11);
    int L = (int)strlen(lfn);
    int dot = -1;
    for (int i = L - 1; i > 0; i--)
        if (lfn[i] == '.') { dot = i; break; }

    /* base: до последней точки; ext: после */
    int blen = dot > 0 ? dot : L;
    int elen = dot > 0 ? L - dot - 1 : 0;
    if (blen > 8) blen = 8;               /* верхняя граница (без ~N) */

    char base[16];
    int bn = 0;
    int lossy = 0;
    for (int i = 0; i < blen && bn < 8; i++) {
        char c = lfn[i];
        if (c >= 'a' && c <= 'z') c -= 32;
        if (sfn_safe(c)) base[bn++] = c;
        else lossy = 1;
    }
    /* потеря символов или усечение → нужен ~N */
    int need_num = lossy || (dot > 0 && blen == 8) ||
                   (int)strlen(lfn) > (dot > 0 ? dot : L) + 1 + (elen > 3 ? 3 : elen);

    if (try > 0 || need_num) {
        int keep = bn > 6 ? 6 : bn;
        if (keep < 1) { base[0] = 'N'; keep = 1; bn = 1; lossy = 1; }
        char tail[8];
        int tn = snprintf(tail, sizeof(tail), "~%d", try + 1);
        int total = keep + tn;
        while (total > 8 && keep > 1) { keep--; total--; }
        bn = keep;
        for (int i = 0; i < tn; i++) base[bn++] = tail[i];
    }
    for (int i = 0; i < bn && i < 8; i++) out11[i] = (u8)base[i];

    /* расширение: до 3 safe-символов после точки */
    if (dot > 0) {
        int en = 0;
        for (int i = dot + 1; i < L && en < 3; i++) {
            char c = lfn[i];
            if (c >= 'a' && c <= 'z') c -= 32;
            if (sfn_safe(c)) out11[8 + en++] = (u8)c;
        }
    }
}

static u8 fat32_lfn_checksum(const u8 sfn[11])
{
    u8 sum = 0;
    for (int i = 0; i < 11; i++)
        sum = (u8)(((sum & 1) << 7) + (sum >> 1) + sfn[i]);
    return sum;
}

/* ---- UTF-8 → UTF-16 (для LFN) ---- */
static int fat32_utf8_to_utf16(const char *in, u16 *out, int out_max)
{
    int n = 0;
    const unsigned char *p = (const unsigned char *)in;
    while (*p && n < out_max) {
        u32 c; int len;
        if (p[0] < 0x80) { c = p[0]; len = 1; }
        else if ((p[0] & 0xE0) == 0xC0) { c = p[0] & 0x1F; len = 2; }
        else if ((p[0] & 0xF0) == 0xE0) { c = p[0] & 0x0F; len = 3; }
        else { c = '?'; len = 1; }
        int ok = 1;
        for (int k = 1; k < len; k++) {
            if ((p[k] & 0xC0) != 0x80) { ok = 0; break; }
            c = (c << 6) | (p[k] & 0x3F);
        }
        if (!ok || (len > 1 && c < 0x80)) c = '?';
        out[n++] = (u16)(c & 0xFFFF);
        p += len;
    }
    return n;
}

/* ---- есть ли уже такое 8.3-имя в каталоге (для уникальности ~N) ---- */
static int fat32_sfn_exists(u32 dir_cluster, const u8 sfn[11])
{
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;
    u32 cluster = dir_cluster;
    u32 guard = fat32_total_clusters() + 2;
    while (cluster >= 2 && cluster < 0x0FFFFFF8u && guard-- > 0) {
        if (!read_cluster(cluster, cluster_buf)) break;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 *e = cluster_buf + off;
            if (e[0] == 0x00) break;
            if (e[0] == 0xE5) continue;
            if (e[11] == 0x0F) continue;
            if (memcmp(e, sfn, 11) == 0) return 1;
        }
        cluster = next_cluster(cluster);
    }
    return 0;
}

/* ---- найти need свободных слотов подряд; при нехватке — расти ----
 * Возвращает 1 и позицию (кластер+смещение). Слоты 0xE5/0x00 годятся;
 * последовательность не пересекает границу кластера. */
static int fat32_find_free_slots(u32 dir_cluster, int need,
                                 u32 *out_cluster, u32 *out_off,
                                 u32 *out_last_in_chain)
{
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;
    u32 cluster = dir_cluster;
    u32 last = cluster;
    u32 guard = fat32_total_clusters() + 2;
    while (cluster >= 2 && cluster < 0x0FFFFFF8u && guard-- > 0) {
        last = cluster;
        if (!read_cluster(cluster, cluster_buf)) return 0;
        int run_start = -1, run_len = 0;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 b0 = cluster_buf[off];
            if (b0 == 0x00) {
                /* конец каталога: до конца кластера всё свободно */
                if (run_start < 0) run_start = (int)off;
                if ((u32)((cluster_size - (u32)run_start) / 32) >= (u32)need) {
                    *out_cluster = cluster;
                    *out_off = (u32)run_start;
                    *out_last_in_chain = last;
                    return 1;
                }
                run_start = -1; run_len = 0;
                break;                        /* в этом кластере не выйдет */
            }
            if (b0 == 0xE5) {
                if (run_start < 0) run_start = (int)off;
                if (++run_len >= need) {
                    *out_cluster = cluster;
                    *out_off = (u32)run_start;
                    *out_last_in_chain = last;
                    return 1;
                }
            } else {
                run_start = -1; run_len = 0;
            }
        }
        cluster = next_cluster(cluster);
    }
    (void)last;
    /* не нашли в существующих кластерах — расти */
    u32 tail = 0;
    /* повторный проход ради «хвоста» цепочки: дешёвая альтернатива —
       пройтись с самого начала (уже сделано выше, last потерян при
       выходе) — вместо этого ищем хвост от dir_cluster */
    {
        u32 c2 = dir_cluster;
        u32 g2 = fat32_total_clusters() + 2;
        while (c2 >= 2 && c2 < 0x0FFFFFF8u && g2-- > 0) {
            tail = c2;
            c2 = next_cluster(c2);
        }
    }
    u32 nc = fat32_alloc_cluster();
    if (!nc) return 0;
    if (tail && tail != nc) {
        if (!fat32_set_fat(tail, nc)) {
            /* FIX [FAT-LEAK] (анализ task57): nc уже помечен EOC, но не
             * привязан — вернуть в FAT, иначе кластер утекал при
             * I/O-ошибке записи хвоста. */
            fat32_set_fat(nc, 0);
            return 0;
        }
    }
    memset(cluster_buf, 0, cluster_size);
    if (!write_cluster(nc, cluster_buf)) {
        /* FIX [FAT-LEAK]: откат всей операции: хвост цепочки снова EOC
         * (его next уже указывает на nc), новый кластер освобождаем. */
        if (tail && tail != nc) fat32_set_fat(tail, 0x0FFFFFF8u);
        fat32_set_fat(nc, 0);
        return 0;
    }
    *out_cluster = nc;
    *out_off = 0;
    *out_last_in_chain = nc;
    return 1;
}

/* ---- вставка записи (LFN + 8.3) ---- */
static int fat32_insert_entry(u32 dir_cluster, const char *name, u8 attr,
                              u32 first_cluster, u32 size, fat32_slot_t *out)
{
    u16 lfn16[130];
    int nl = fat32_utf8_to_utf16(name, lfn16, 130);
    if (nl <= 0) return 0;
    int lfn_cnt = (nl + 12) / 13;
    int need = lfn_cnt + 1;
    if (need < 1) return 0;

    /* уникальное 8.3-имя */
    u8 sfn[11];
    int found_sfn = 0;
    for (int try = 0; try < 100; try++) {
        fat32_sfn_candidate(name, try, sfn);
        if (!fat32_sfn_exists(dir_cluster, sfn)) { found_sfn = 1; break; }
    }
    if (!found_sfn) return 0;

    u32 slot_cluster, slot_off, tail;
    if (!fat32_find_free_slots(dir_cluster, need, &slot_cluster, &slot_off, &tail))
        return 0;

    if (!read_cluster(slot_cluster, cluster_buf)) return 0;
    u8 *e = cluster_buf + slot_off;
    u8 csum = fat32_lfn_checksum(sfn);

    /* LFN-записи: физический порядок — старшая seq первой (бит 0x40) */
    static const u8 lofs[13] = {1,3,5,7,9, 14,16,18,20,22,24, 28,30};
    for (int k = 0; k < lfn_cnt; k++) {
        u8 *le = e + (u32)k * 32;
        int seq = lfn_cnt - k;              /* k=0 → старшая */
        memset(le, 0, 32);
        /* FIX [FAT-LFN40] (анализ task57, критично): бит 0x40 («последняя
         * LFN-запись») ставится ТОЛЬКО на первой физически записи — она
         * же имеет наибольший seq (k=0). Раньше 0x40 был на ВСЕХ записях:
         * собственный листинг маскирует seq через & 0x1F и потому не
         * ломался, но Windows/Linux трактуют несколько 0x40-записей как
         * повреждение каталога (несовместимость при переносе флешки). */
        le[0]  = (u8)((k == 0 ? 0x40u : 0u) | (u32)seq);
        le[11] = 0x0F;
        le[12] = 0;
        le[13] = csum;
        le[26] = 0; le[27] = 0;
        int base = (seq - 1) * 13;
        for (int i = 0; i < 13; i++) {
            u16 ch;
            int ci = base + i;
            if (ci < nl) ch = lfn16[ci];
            else if (ci == nl) ch = 0x0000;
            else ch = 0xFFFF;
            le[lofs[i]]     = (u8)(ch & 0xFF);
            le[lofs[i] + 1] = (u8)(ch >> 8);
        }
    }
    /* 8.3-слот */
    {
        u8 *se = e + (u32)lfn_cnt * 32;
        memset(se, 0, 32);
        memcpy(se, sfn, 11);
        se[11] = attr;
        se[12] = 0;
        se[26] = (u8)(first_cluster & 0xFF);
        se[27] = (u8)((first_cluster >> 8) & 0xFF);
        se[20] = (u8)((first_cluster >> 16) & 0xFF);
        se[21] = (u8)((first_cluster >> 24) & 0xFF);
        se[28] = (u8)(size & 0xFF);
        se[29] = (u8)((size >> 8) & 0xFF);
        se[30] = (u8)((size >> 16) & 0xFF);
        se[31] = (u8)((size >> 24) & 0xFF);
    }
    if (!write_cluster(slot_cluster, cluster_buf)) return 0;

    if (out) {
        memset(out, 0, sizeof(*out));
        out->dir_cluster = slot_cluster;
        out->dir_off = slot_off + (u32)lfn_cnt * 32;
        out->lfn_count = lfn_cnt;
        out->first_cluster = first_cluster;
        out->size = size;
        out->attr = attr;
        out->found = 1;
    }
    return 1;
}

/* ---- патч полей существующего 8.3-слота ---- */
static int fat32_patch_entry(const fat32_slot_t *slot, u32 first_cluster, u32 size)
{
    if (!read_cluster(slot->dir_cluster, cluster_buf)) return 0;
    u8 *se = cluster_buf + slot->dir_off;
    se[26] = (u8)(first_cluster & 0xFF);
    se[27] = (u8)((first_cluster >> 8) & 0xFF);
    se[20] = (u8)((first_cluster >> 16) & 0xFF);
    se[21] = (u8)((first_cluster >> 24) & 0xFF);
    se[28] = (u8)(size & 0xFF);
    se[29] = (u8)((size >> 8) & 0xFF);
    se[30] = (u8)((size >> 16) & 0xFF);
    se[31] = (u8)((size >> 24) & 0xFF);
    return write_cluster(slot->dir_cluster, cluster_buf);
}

/* ---- запись данных в цепочку (выделенную заранее) ---- */
static int fat32_write_data(u32 first, const void *buf, u32 len)
{
    if (len == 0) return 1;
    if (first < 2) return 0;
    const u8 *src = (const u8 *)buf;
    u32 done = 0;
    u32 c = first;
    u32 guard = fat32_total_clusters() + 2;
    while (c >= 2 && c < 0x0FFFFFF8u && guard-- > 0) {
        u32 n = (len - done > cluster_size) ? cluster_size : (len - done);
        memset(cluster_buf, 0, cluster_size);
        memcpy(cluster_buf, src + done, n);
        if (!write_cluster(c, cluster_buf)) return 0;
        done += n;
        if (done >= len) return 1;
        c = next_cluster(c);
    }
    return done >= len;
}

/* ---- выделить цепочку под len байт; голова в *out_first (EOC на конце) ---- */
static int fat32_alloc_chain(u32 len, u32 *out_first, u32 *out_clusters)
{
    if (len == 0) { *out_first = 0; *out_clusters = 0; return 1; }
    u32 need = (len + cluster_size - 1) / cluster_size;
    u32 total = fat32_total_clusters();
    if (need > total) return 0;
    u32 head = 0, prev = 0;
    for (u32 i = 0; i < need; i++) {
        u32 c = fat32_alloc_cluster();
        if (!c) {
            if (head) fat32_free_chain(head);
            return 0;
        }
        if (prev) {
            /* FIX [FAT-LEAK]: неудача связывания — освободить и новый
             * (EOC, ни к кому не привязан), и уже собранную голову. */
            if (!fat32_set_fat(prev, c)) {
                fat32_set_fat(c, 0);
                if (head) fat32_free_chain(head);
                return 0;
            }
        }
        else head = c;
        prev = c;
    }
    *out_first = head;
    *out_clusters = need;
    return 1;
}

/* ---- каталог пуст? (только . .. и мусор) ---- */
static int fat32_dir_empty(u32 dir_cluster)
{
    if (dir_cluster < 2) dir_cluster = bpb.root_cluster;
    u32 cluster = dir_cluster;
    u32 guard = fat32_total_clusters() + 2;
    while (cluster >= 2 && cluster < 0x0FFFFFF8u && guard-- > 0) {
        if (!read_cluster(cluster, cluster_buf)) return 0;
        for (u32 off = 0; off + 32 <= cluster_size; off += 32) {
            u8 *e = cluster_buf + off;
            if (e[0] == 0x00) return 1;
            if (e[0] == 0xE5) continue;
            u8 attr = e[11];
            if (attr == 0x0F) continue;
            /* "." / ".." — пропустить: 11 байт, точка+пробелы */
            int is_dot = (e[0] == '.' && e[1] == ' ');
            int is_dotdot = (e[0] == '.' && e[1] == '.' && e[2] == ' ');
            if (is_dot || is_dotdot) continue;
            return 0;
        }
        cluster = next_cluster(cluster);
    }
    return 1;
}

/* ================= публичный API записи (сериализован) ================= */

int fat32_writable(void)
{
    if (g_is_exfat) return exfat_writable();
    return ready && fat32_write_fn != NULL;
}

int fat32_mkdir(u32 dir_cluster, const char *name)
{
    if (!name || !name[0] || strchr(name, '/')) return 0;
    if (g_is_exfat) {
        s_lock(&fat32_io_lock);
        int rc = exfat_mkdir(dir_cluster, name);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    s_lock(&fat32_io_lock);
    int rc = 0;
    do {
        if (!ready) break;
        fat32_slot_t ex;
        if (fat32_find_slot(dir_cluster, name, &ex)) break;   /* занято */

        u32 nc = fat32_alloc_cluster();
        if (!nc) break;

        /* содержимое нового каталога: "." и ".." */
        if (!read_cluster(nc, cluster_buf)) { fat32_free_chain(nc); break; }
        memset(cluster_buf, 0, cluster_size);
        u8 *dot = cluster_buf;
        memcpy(dot, ".          ", 11);
        dot[11] = 0x10;
        dot[26] = (u8)(nc & 0xFF); dot[27] = (u8)((nc >> 8) & 0xFF);
        dot[20] = (u8)((nc >> 16) & 0xFF); dot[21] = (u8)((nc >> 24) & 0xFF);
        u8 *dd = cluster_buf + 32;
        memcpy(dd, "..         ", 11);
        dd[11] = 0x10;
        u32 parent = (dir_cluster < 2) ? bpb.root_cluster : dir_cluster;
        dd[26] = (u8)(parent & 0xFF); dd[27] = (u8)((parent >> 8) & 0xFF);
        dd[20] = (u8)((parent >> 16) & 0xFF); dd[21] = (u8)((parent >> 24) & 0xFF);
        if (!write_cluster(nc, cluster_buf)) { fat32_free_chain(nc); break; }

        if (!fat32_insert_entry(dir_cluster, name, 0x10, nc, 0, NULL)) {
            fat32_free_chain(nc);
            break;
        }
        rc = 1;
    } while (0);
    s_unlock(&fat32_io_lock);
    return rc;
}

int fat32_create_file(u32 dir_cluster, const char *name)
{
    if (!name || !name[0] || strchr(name, '/')) return 0;
    if (g_is_exfat) {
        s_lock(&fat32_io_lock);
        int rc = exfat_create_file(dir_cluster, name);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    s_lock(&fat32_io_lock);
    int rc = 0;
    do {
        if (!ready) break;
        fat32_slot_t ex;
        if (fat32_find_slot(dir_cluster, name, &ex)) break;
        rc = fat32_insert_entry(dir_cluster, name, 0x20, 0, 0, NULL);
    } while (0);
    s_unlock(&fat32_io_lock);
    return rc;
}

int fat32_find_entry(u32 dir_cluster, const char *name, fat32_dirent_t *out)
{
    if (g_is_exfat) {
        s_lock(&fat32_io_lock);
        int rc = exfat_find_entry(dir_cluster, name, out);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    s_lock(&fat32_io_lock);
    fat32_slot_t slot;
    int rc = 0;
    if (ready && fat32_find_slot(dir_cluster, name, &slot) && out) {
        strncpy(out->name, name, FAT32_NAME_MAX);
        out->name[FAT32_NAME_MAX] = 0;
        out->attr = slot.attr;
        out->size = slot.size;
        out->first_cluster = slot.first_cluster;
        rc = 1;
    }
    s_unlock(&fat32_io_lock);
    return rc;
}

u32 fat32_read_file_by_name(u32 dir_cluster, const char *name, void *buf, u32 max)
{
    s_lock(&fat32_io_lock);
    u32 rc = 0;
    if (g_is_exfat) {
        fat32_dirent_t de;
        if (exfat_find_entry(dir_cluster, name, &de))
            rc = exfat_read_file(de.first_cluster, de.size, buf, max);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    fat32_slot_t slot;
    if (ready && fat32_find_slot(dir_cluster, name, &slot)) {
        rc = fat32_read_file_impl(slot.first_cluster, slot.size, buf, max, NULL, NULL);
    }
    s_unlock(&fat32_io_lock);
    return rc;
}

u32 fat32_write_file(u32 dir_cluster, const char *name, const void *buf, u32 len)
{
    if (!name || !name[0] || strchr(name, '/')) return 0;
    /* СЕССИЯ 75: exFAT-том — запись через exfat.c (лимит 4 МиБ там) */
    if (g_is_exfat) {
        s_lock(&fat32_io_lock);
        u32 rc = exfat_write_file(dir_cluster, name, buf, len);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    if (len > 128u * 1024u) return 0;
    s_lock(&fat32_io_lock);
    u32 rc = 0;
    do {
        if (!ready) break;

        fat32_slot_t slot;
        int existed = fat32_find_slot(dir_cluster, name, &slot);
        if (!existed) {
            if (!fat32_insert_entry(dir_cluster, name, 0x20, 0, 0, &slot))
                break;
        }

        /* FIX [FAT-SAFEWRITE] (поиск по соседям, task57): новая цепочка
         * выделяется и заполняется ДО освобождения старой — при неудаче
         * выделения или записи старое содержимое файла остаётся
         * на месте. Раньше free шёл первым: неудача дальше оставляла
         * в 8.3-слоте указатель на УЖЕ освобождённую цепочку (файл
         * «терял» содержимое без ошибки записи). */
        u32 first = 0, ncl = 0;
        if (len > 0) {
            if (!fat32_alloc_chain(len, &first, &ncl)) break;
            if (!fat32_write_data(first, buf, len)) {
                fat32_free_chain(first);
                break;
            }
        }
        if (existed && slot.first_cluster >= 2)
            fat32_free_chain(slot.first_cluster);
        if (!fat32_patch_entry(&slot, first, len)) break;
        rc = len;
    } while (0);
    s_unlock(&fat32_io_lock);
    return rc;
}

int fat32_delete(u32 dir_cluster, const char *name)
{
    if (!name || !name[0]) return 0;
    if (g_is_exfat) {
        s_lock(&fat32_io_lock);
        int rc = exfat_delete(dir_cluster, name);
        s_unlock(&fat32_io_lock);
        return rc;
    }
    s_lock(&fat32_io_lock);
    int rc = 0;
    do {
        if (!ready) break;
        fat32_slot_t slot;
        if (!fat32_find_slot(dir_cluster, name, &slot)) break;

        if (slot.attr & 0x10) {
            if (!fat32_dir_empty(slot.first_cluster)) break;  /* не пуст */
            fat32_free_chain(slot.first_cluster);
        } else if (slot.first_cluster >= 2) {
            fat32_free_chain(slot.first_cluster);
        }

        /* пометить слоты удалёнными */
        if (!read_cluster(slot.dir_cluster, cluster_buf)) break;
        u8 *base = cluster_buf + slot.dir_off;
        base[0] = 0xE5;
        /* LFN-слоты стоят ПЕРЕД 8.3 (по убыванию seq): dir_off-32, -64... */
        for (int k = 0; k < slot.lfn_count; k++) {
            u8 *le = base - (k + 1) * 32;
            le[0] = 0xE5;
        }
        if (!write_cluster(slot.dir_cluster, cluster_buf)) break;
        rc = 1;
    } while (0);
    s_unlock(&fat32_io_lock);
    return rc;
}
