/* hostdisk.c — RAM-диск 64 МиБ + учёт доступа + фолт-инжекция (хост-тест). */
#include "disk.h"
#include "mem.h"
#include "string.h"
#include <stdarg.h>
#include <unistd.h>

extern void exit(int);   /* libc, без <stdlib.h> (конфликт malloc) */

/* glibc vsnprintf без <stdio.h> (не тянем glibc snprintf(size_t)):
 * unsigned long == size_t на x86_64 — ABI тот же */
extern int vsnprintf(char *s, unsigned long n, const char *fmt, ...);

static void serr(const char *s) { (void)!write(2, s, strlen(s)); }

#define IMG_SECTORS (64u * 1024u * 1024u / 512u)   /* 64 МиБ */

static u8  *g_img = NULL;
static u32  g_writes = 0;
static int  g_oob = 0;
static int  g_fault_skip = -1, g_fault_left = 0;

static void img_init(void)
{
    if (!g_img) {
        g_img = (u8 *)malloc(IMG_SECTORS * 512u);       /* 64 МиБ */
        if (!g_img) { serr("нет памяти под образ\n"); exit(1); }
        memset(g_img, 0, IMG_SECTORS * 512u);
    }
}

int disk_hdd_present(void) { img_init(); return 1; }
u32 disk_hdd_sectors(void) { img_init(); return IMG_SECTORS; }

int disk_hdd_read(u32 lba, u8 count, void *buf)
{
    img_init();
    if (count == 0 || lba >= IMG_SECTORS ||
        (u64)lba + count > IMG_SECTORS) { g_oob = 1; return 0; }
    memcpy(buf, g_img + (u64)lba * 512, (u64)count * 512);
    return 1;
}

int disk_hdd_write(u32 lba, u8 count, const void *buf)
{
    img_init();
    if (count == 0 || lba >= IMG_SECTORS ||
        (u64)lba + count > IMG_SECTORS) { g_oob = 1; return 0; }
    if (g_fault_skip >= 0) {
        if (g_fault_skip > 0) g_fault_skip--;
        else if (g_fault_left > 0) { g_fault_left--; return 0; }
    }
    memcpy(g_img + (u64)lba * 512, buf, (u64)count * 512);
    g_writes++;
    return 1;
}

const disk_part_t *disk_part(int i) { (void)i; return NULL; }
int  disk_part_count(void) { return 0; }
const char *disk_part_fstype(int i) { (void)i; return ""; }

/* ata/usb — маршрутизируем в тот же образ */
int ata_hdd_present(void) { return 1; }
int ata_read(u32 lba, u8 count, void *buf)          { return disk_hdd_read(lba, count, buf); }
int ata_read_hdd(u32 lba, u8 count, void *buf)      { return disk_hdd_read(lba, count, buf); }
int usb_ehci_read_sector(u32 lba, void *buf)        { return disk_hdd_read(lba, 1, buf); }
int usb_ehci_write_sector(u32 lba, const void *buf) { return disk_hdd_write(lba, 1, buf); }
int usb_ehci_storage_ready(void) { return 0; }
int usb_ehci_storage_count(void)  { return 0; }
int usb_ehci_storage_select(int idx) { (void)idx; return 0; }
int usb_ehci_storage_active(void) { return -1; }

/* прочие ядровые символы */
void serial_puts(const char *s) { serr(s); }
void task_yield(void) {}
u32  timer_ticks(void) { static u32 t = 1234; return ++t; }

/* ядровая сигнатура snprintf (u32); в этом TU НЕТ <stdio.h> — конфликта нет */
int snprintf(char *out, u32 n, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    int r = vsnprintf(out, (unsigned long)n, fmt, ap);
    va_end(ap);
    return r;
}

/* mem.h: bump-аллокатор на mmap (не libc — конфликт сигнатур u32/size_t);
 * free — no-op (утечки в тесте не критичны). */
#include <sys/mman.h>
static char *g_heap = 0;
static unsigned long g_heap_off = 0;
#define HEAP_CAP (256ul * 1024 * 1024)
void *malloc(u32 n)
{
    if (!g_heap) {
        g_heap = (char *)mmap(0, HEAP_CAP, PROT_READ | PROT_WRITE,
                              MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (g_heap == (char *)-1) return 0;
    }
    unsigned long off = (g_heap_off + 15ul) & ~15ul;
    if (off + n > HEAP_CAP) return 0;
    g_heap_off = off + n;
    return g_heap + off;
}
void free(void *p) { (void)p; }


/* exfat.c: метки времени — стаб (не влияет на проверяемые инварианты) */
void rtc_get_time(int *h, int *mi, int *s)  { *h = 12; *mi = 30; *s = 0; }
void rtc_get_date(int *y, int *mo, int *d)  { *y = 2026; *mo = 10; *d = 29; }

/* хуки */
void hd_reset_stats(void) { g_writes = 0; g_oob = 0; }
u32  hd_writes(void)      { return g_writes; }
int  hd_oob_seen(void)    { return g_oob; }
void hd_fault_arm(int skip, int fails) { g_fault_skip = skip; g_fault_left = fails; }
void hd_fault_disarm(void) { g_fault_skip = -1; g_fault_left = 0; }

u8 *test_image(void) { img_init(); return g_img; }
