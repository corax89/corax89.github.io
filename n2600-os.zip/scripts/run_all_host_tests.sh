#!/bin/sh
# run_all_host_tests.sh — все хост-тесты Task 65 (браузерный конвейер+сеть).
# Запуск: sh scripts/run_all_host_tests.sh
set -e
cd "$(dirname "$0")"
SRC=../src
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
CFLAGS="-DHOST_TEST -D_GNU_SOURCE -g -O1 -fsanitize=address,undefined"
LD="-Wl,-allow-multiple-definition"

# --- регенерация вырезки декодера chunked для test_chunked.c ---
python3 - << 'PYEOF'
src = open('../src/net_http.c').read()
r1a = src.index('#define CH_SIZE  0')
r1b = src.index('static int  g_chunk_end = 0;')
r1b = src.index('\n', r1b) + 1
reg1 = src[r1a:r1b]
r2a = src.index('/* Один байт ДЕКОДИРОВАННОГО тела в буфер вызывающего. */')
r2b = src.index('/* Обнаружить Transfer-Encoding: chunked')
reg2 = src[r2a:r2b]
hdr = ('/* generated_chunked.inc — ВЫРЕЗКА ИЗ src/net_http.c (FIX [HTTP-CHUNKED]).\n'
       ' * Регенерируется этим скриптом; тест проверяет НАСТОЯЩИЙ код. */\n'
       '#define g_http_buf        t_buf\n'
       '#define g_http_buf_len    t_len\n'
       '#define g_http_buf_max    t_max\n'
       '#define g_http_truncated  t_trunc\n'
       '#define g_http_done       t_done\n'
       '/* Task 69 [HTTP-LASTDEL]: ch_put_out* считает доставленное (не gzip) */\n'
       '#define g_stream_delivered t_deliv\n'
       '#define g_gz_mode          t_gzmode\n'
       'static u32 t_deliv;\n'
       'static int t_gzmode;\n'
       '\n')
open('generated_chunked.inc','w').write(hdr + reg1 + '\n' + reg2)
PYEOF

echo "=== 1. test_htmlconv (81, вкл. фаззинг) ==="
gcc $CFLAGS -I$TMP -o $TMP/t_htmlconv test_htmlconv.c $SRC/htmlconv.c $SRC/html_parser.c $LD
ASAN_OPTIONS=detect_leaks=0 timeout 60 $TMP/t_htmlconv | tail -1

echo "=== 2. test_e2e_task60 (16) ==="
gcc $CFLAGS -Ibrhost/shim -Ibrhost -o $TMP/t_e60 test_e2e_task60.c $SRC/htmlconv.c $SRC/html_parser.c $LD
ASAN_OPTIONS=detect_leaks=0 timeout 60 $TMP/t_e60 | tail -1

echo "=== 3. test_brform ==="
gcc $CFLAGS -o $TMP/t_brform test_brform.c $LD
ASAN_OPTIONS=detect_leaks=0 timeout 60 $TMP/t_brform | tail -1

echo "=== 4. test_chunked (10) ==="
gcc $CFLAGS -I. -o $TMP/t_chunked test_chunked.c $LD
ASAN_OPTIONS=detect_leaks=0 timeout 60 $TMP/t_chunked | tail -1

echo "=== 4b. test_httpstream (53, Task 69: HDRCB/TAIL/GZSINK/FINHOLE) ==="
gcc $CFLAGS -I../src -o $TMP/t_httpstream test_httpstream.c $LD
ASAN_OPTIONS=detect_leaks=0 timeout 60 $TMP/t_httpstream | tail -1

echo "=== 5. brhost (URL-логика, 73) ==="
sh brhost/run.sh 2>&1 | tail -1

echo "=== 6. gzhost (gunzip, 41) ==="
sh gzhost/run.sh 2>&1 | tail -2

echo "=== 7. httpdhost (27) ==="
sh httpdhost/run.sh 2>&1 | tail -2

echo "=== 8. kbdhost (48) ==="
sh kbdhost/run.sh 2>&1 | tail -2

echo "=== 9. brjshost (мост JS: location/таймеры/XHR, изолированные) ==="
sh brjshost/run.sh 2>&1 | tail -1

echo
echo "ВСЕ ХОСТ-ТЕСТЫ ЗАВЕРШЕНЫ"
