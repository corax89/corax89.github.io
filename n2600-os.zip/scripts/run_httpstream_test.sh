#!/bin/sh
# run_httpstream_test.sh — хост-тест приёмного пути HTTP-клиента Task 69
# ([HTTP-HDRCB] / [HTTP-TAIL] / [HTTP-GZSINK] / [HTTP-LASTSTAT] /
#  [TCP-FINHOLE]) — net_http.c и net_tcp.c целиком, фейк-сервер.
cd "$(dirname "$0")"
gcc -DHOST_TEST -D_GNU_SOURCE -g -O1 -fsanitize=address,undefined \
    -I../src -o /tmp/t_httpstream test_httpstream.c \
    -Wl,-allow-multiple-definition 2>&1 | grep -v "conflicting types" | head -30
rc=$?
[ -x /tmp/t_httpstream ] || { echo "СБОРКА ПРОВАЛЕНА"; exit 1; }
ASAN_OPTIONS=detect_leaks=0 timeout 60 /tmp/t_httpstream
exit $?
