/* test_httpstream.c — хост-тест ПРИЁМНОГО пути HTTP-клиента Task 69:
 *
 *   [HTTP-HDRCB] hdr-колбэк (br_stream_hdr) теперь ВЫЗЫВАЕТСЯ при
 *                первом найденном конце заголовков (прежде — никогда:
 *                сохранялся, но не звался → редиректы/Content-Type/
 *                TLS-up в потоковом режиме были мертвы);
 *   [HTTP-TAIL]  тело, пришедшее В ОДНОМ СЕГМЕНТЕ с заголовками,
 *                отдаётся приёмнику (прежде навсегда застревало в
 *                буфере заголовков — «пустые» страницы, «обрезанный
 *                код»);
 *   [HTTP-GZSINK] Content-Encoding: gzip → приёмник переключается на
 *                накопитель, в конце транзакции распаковка и отдача
 *                колбэку (прежде сжатые байты шли конвертеру как есть);
 *   [HTTP-LASTSTAT] net_http_raw_received()/net_http_content_length()
 *                возвращают цифры ЗАВЕРШЁННОЙ транзакции (прежде — 0);
 *   [TCP-FINHOLE] FIN при дыре в данных НЕ подтверждает неполученное:
 *                ретрансмиссия доставляется, ответ не обрезается
 *                («сервер закрыл соединение, принято 144 б»).
 *
 * net_http.c и net_tcp.c включаются ЦЕЛИКОМ (боевой код); фейк-сервер
 * шлёт настоящие IP/TCP-пакеты через net_handle_tcp. Ответы — реплики
 * ya.ru/habr.com/example.com (HTTP/1.0, UA N2600-OS/0.1,
 * Connection: close), снятые с живых серверов.
 *
 * Сборка/запуск: sh scripts/run_httpstream_test.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>    /* strncasecmp */

#include "types.h"
#include "net.h"          /* типы/прототипы — боевые */

/* флаги TCP определены в net_tcp.c — до его включения нужны литералы */
#define TCPF_FIN 0x01
#define TCPF_SYN 0x02

/* ---------- серийный порт: копим вывод для проверок ---------- */
static char ser_buf[65536];
static int  ser_len = 0;
void serial_puts(const char *s)
{
    int n = (int)strlen(s);
    if (ser_len + n < (int)sizeof(ser_buf) - 1) {
        memcpy(ser_buf + ser_len, s, (size_t)n);
        ser_len += n;
        ser_buf[ser_len] = 0;
    }
}
static void ser_reset(void) { ser_len = 0; ser_buf[0] = 0; }
static int  ser_count(const char *sub)
{
    int n = 0;
    const char *p = ser_buf;
    while ((p = strstr(p, sub)) != NULL) { n++; p++; }
    return n;
}

/* ---------- таймер: тикает ТОЛЬКО в net_poll (нет самопроизвольных
 * таймаутов, но и вечных циклов нет) ---------- */
static unsigned int fake_ticks = 100;
unsigned int timer_ticks(void) { return fake_ticks; }
void task_yield(void) { }

/* ---------- захват исходящих пакетов клиента ---------- */
static u32  cli_seq_last = 0;     /* последний seq клиента */
static int  cli_syn_seen = 0;
static u32  cli_isn      = 0;
static u16  cli_lport    = 0;
static char cli_last_req[2048];
static int  cli_last_req_len = 0;

void net_send_ip(u8 proto, u32 dst_ip, const void *payload, u32 payload_len)
{
    (void)dst_ip;
    if (proto == IP_PROTO_TCP && payload && payload_len >= 20) {
        const u8 *p = (const u8 *)payload;
        u32 seq = ((u32)p[4] << 24) | ((u32)p[5] << 16) |
                  ((u32)p[6] << 8)  | (u32)p[7];
        u8 fl = p[13];
        cli_seq_last = seq;
        if (!cli_lport) cli_lport = (u16)(((u32)p[0] << 8) | p[1]);
        if (fl & TCPF_SYN) {
            cli_syn_seen = 1;
            cli_isn = seq;
        }
        if (payload_len > 20) {
            u32 dl = payload_len - 20;
            if (dl > sizeof(cli_last_req) - 1) dl = sizeof(cli_last_req) - 1;
            memcpy(cli_last_req, p + 20, dl);
            cli_last_req[dl] = 0;
            cli_last_req_len = (int)dl;
        }
    }
}

/* ---------- заглушки окружения для net_tcp.c / net_http.c ---------- */
int   net_dhcp_txn_active(void) { return 0; }
u32   net_get_ip(void) { return 0x0A000202u; }          /* 10.0.2.15 */
u16   inet_checksum_pseudo(u32 src, u32 dst, u8 proto,
                           const void *d, u32 n)
{ (void)src; (void)dst; (void)proto; (void)d; (void)n; return 0; }
int   net_ntoa(u32 ip, char *out, u32 out_max)
{ (void)ip; if (out && out_max > 0) out[0] = 0; return 0; }
int   net_aton(const char *s, u32 *out)
{ (void)s; *out = 0x0A000202u; return 1; }
int   net_dns_resolve(const char *h, u32 *ip, u32 max_ms)
{ (void)h; (void)max_ms; *ip = 0x0A000202u; return 1; }
int   net_wait_arp(u32 ip, u32 max_ms) { (void)ip; (void)max_ms; return 1; }
int   net_host_is_loopback(const char *h) { (void)h; return 0; }
int   net_is_loopback(u32 ip) { (void)ip; return 0; }
void  klog_puts(const char *s) { serial_puts(s); }

/* ---------- заглушки TLS (порт != 443 — не вызываются) ---------- */
void tls_set_sink(void (*sink)(const void *, u32)) { (void)sink; }
int  tls_start(int sock, const char *host, u32 max_ms)
{ (void)sock; (void)host; (void)max_ms; return 0; }
int  tls_send_all(const void *d, u32 n) { (void)d; (void)n; return 0; }
void tls_pump(void) { }
void tls_shutdown(void) { }
const char *tls_errstr(void) { return "ok"; }
void tls_tcp_recv(int sock, u32 src_ip, u16 src_port,
                  const void *data, u32 len)
{ (void)sock; (void)src_ip; (void)src_port; (void)data; (void)len; }

/* ---------- боевой код ---------- */
#include "../src/net_tcp.c"
#include "../src/gunzip.c"
#include "../src/net_http.c"

/* ---------- фейк-сервер: настоящие IP+TCP пакеты ---------- */
static u32 srv_seq = 0x90000000u;
static u8  ev_pkts[32][1700];
static int ev_len[32];
static int ev_n = 0, ev_pos = 0;

static void ev_reset(void)
{
    ev_n = 0; ev_pos = 0;
    srv_seq = 0x90000000u;
    /* локальный порт клиента РОТАЦИОННЫЙ (lport++ на транзакцию) —
     * сброс: перезахват из SYN следующего сценария */
    cli_lport = 0;
    cli_seq_last = 0;
    cli_isn = 0;
    cli_syn_seen = 0;
    /* SYN-ACK всегда первый (ack проставится при проигрывании) */
    {
        u8 *pkt = ev_pkts[0];
        ip_hdr_t *ip = (ip_hdr_t *)pkt;
        u8 *tcp = pkt + 20;
        memset(pkt, 0, 40);
        ip->ver_ihl = 0x45;
        ip->tot_len = 40;
        ip->ttl = 64;
        ip->protocol = IP_PROTO_TCP;
        ip->src_ip[0] = 10; ip->src_ip[1] = 0;
        ip->src_ip[2] = 2;  ip->src_ip[3] = 2;
        ip->dst_ip[0] = 10; ip->dst_ip[1] = 0;
        ip->dst_ip[2] = 2;  ip->dst_ip[3] = 15;
        tcp[0] = 0; tcp[1] = 0x50;                    /* src port 80 */
        /* dst port проставит ev_play (cli_lport) */
        tcp[4]  = (u8)(srv_seq >> 24); tcp[5]  = (u8)(srv_seq >> 16);
        tcp[6]  = (u8)(srv_seq >> 8);  tcp[7]  = (u8)srv_seq;
        tcp[12] = (u8)((20 / 4) << 4);
        tcp[13] = (u8)(TCP_SYN | TCP_ACK);
        tcp[14] = 0xFF; tcp[15] = 0xFF;               /* окно 65535 */
        srv_seq += 1;
        ev_len[0] = 40;
        ev_n = 1;
    }
}

/* сегмент данных/FIN от сервера (после SYN-ACK) */
static void ev_push_seg(u8 flags, const char *payload, int plen)
{
    if (ev_n >= 31) return;
    u8 *pkt = ev_pkts[ev_n];
    ip_hdr_t *ip = (ip_hdr_t *)pkt;
    u8 *tcp = pkt + 20;
    int tot = 40 + (plen > 0 ? plen : 0);
    memset(pkt, 0, (size_t)tot);
    ip->ver_ihl = 0x45;
    ip->tot_len = (u16)tot;
    ip->ttl = 64;
    ip->protocol = IP_PROTO_TCP;
    ip->src_ip[0] = 10; ip->src_ip[1] = 0;
    ip->src_ip[2] = 2;  ip->src_ip[3] = 2;
    ip->dst_ip[0] = 10; ip->dst_ip[1] = 0;
    ip->dst_ip[2] = 2;  ip->dst_ip[3] = 15;
    tcp[0] = 0; tcp[1] = 0x50;
    tcp[4] = (u8)(srv_seq >> 24); tcp[5] = (u8)(srv_seq >> 16);
    tcp[6] = (u8)(srv_seq >> 8);  tcp[7] = (u8)srv_seq;
    tcp[12] = (u8)((20 / 4) << 4);
    tcp[13] = flags;
    tcp[14] = 0xFF; tcp[15] = 0xFF;
    if (plen > 0) memcpy(tcp + 20, payload, (size_t)plen);
    if (flags & TCP_FIN) srv_seq += (u32)plen + 1;
    else srv_seq += (u32)plen;
    ev_len[ev_n] = tot;
    ev_n++;
}

/* проигрывание: 1 пакет за вызов; ack всех пакетов = cli_seq_last+1 */
void net_poll(void)
{
    fake_ticks++;
    if (ev_pos >= ev_n) { net_tcp_timer(); return; }
    u8 *pkt = ev_pkts[ev_pos];
    {
        u32 ack = cli_seq_last + 1;
        pkt[28] = (u8)(ack >> 24); pkt[29] = (u8)(ack >> 16);
        pkt[30] = (u8)(ack >> 8);  pkt[31] = (u8)ack;
        pkt[22] = (u8)(cli_lport >> 8);               /* dst port */
        pkt[23] = (u8)(cli_lport & 0xFF);
    }
    net_handle_tcp((ip_hdr_t *)pkt, pkt + 20, (u32)(ev_len[ev_pos] - 20));
    ev_pos++;
    net_tcp_timer();
}

/* ---------- HTTP-колбэки теста (мимикрия под br_stream_*) ---------- */
static int  cb_verdict;         /* 0 ок; -2 редирект; -4 https-only */
static int  cb_hdr_calls;
static int  cb_hdr_status;
static char cb_loc[512];
static int  cb_body_calls;
static char cb_body[32768];
static int  cb_body_len;

static void cb_reset(void)
{
    cb_verdict = 0; cb_hdr_calls = 0; cb_hdr_status = 0; cb_loc[0] = 0;
    cb_body_calls = 0; cb_body_len = 0; cb_body[0] = 0;
}

static const char *hdr_find(const char *hdrs, u32 hlen, const char *name,
                            int *vlen)
{
    u32 nl = (u32)strlen(name);
    for (u32 i = 0; i + nl + 1 < hlen; i++) {
        if ((i == 0 || hdrs[i-1] == '\n') &&
            strncasecmp(hdrs + i, name, nl) == 0 && hdrs[i + nl] == ':') {
            u32 j = i + nl + 1;
            while (j < hlen && (hdrs[j] == ' ' || hdrs[j] == '\t')) j++;
            u32 s = j;
            while (j < hlen && hdrs[j] != '\r' && hdrs[j] != '\n') j++;
            *vlen = (int)(j - s);
            return hdrs + s;
        }
    }
    *vlen = 0;
    return NULL;
}

static int test_hdr_cb(void *ud, int status, const char *hdrs, u32 hlen)
{
    int *verdict = (int *)ud;
    cb_hdr_calls++;
    cb_hdr_status = status;
    int vl = 0;
    const char *v = hdr_find(hdrs, hlen, "Location", &vl);
    if (v && vl > 0 && (size_t)vl < sizeof(cb_loc) - 1) {
        memcpy(cb_loc, v, (size_t)vl);
        cb_loc[vl] = 0;
    }
    if (status == 301 || status == 302 || status == 303 ||
        status == 307 || status == 308) {
        if (cb_loc[0]) { *verdict = -2; return -1; }
    }
    if (status == 400 || status == 403 || status == 426) {
        *verdict = -4;
        return -1;
    }
    return 0;
}

static int test_body_cb(void *ud, const char *data, u32 len)
{
    (void)ud;
    cb_body_calls++;
    if (cb_body_len + (int)len < (int)sizeof(cb_body) - 1) {
        memcpy(cb_body + cb_body_len, data, len);
        cb_body_len += (int)len;
        cb_body[cb_body_len] = 0;
    }
    return 0;
}

/* ---------- сборщики ответов (реплики живых серверов) ---------- */
static char resp[4096];

/* habr.com:80 — 301, CL 162, один сегмент (675 б) */
static int mk_habr80(void)
{
    const char *hdrs =
        "HTTP/1.1 301 Moved Permanently\r\n"
        "Server: QRATOR\r\n"
        "Date: Thu, 29 Oct 2026 18:00:00 GMT\r\n"
        "Content-Type: text/html\r\n"
        "Content-Length: 162\r\n"
        "Connection: close\r\n"
        "Location: https://habr.com/\r\n"
        "\r\n";
    const char *body =
        "<html>\r\n<head><title>301 Moved Permanently</title></head>\r\n"
        "<body>\r\n<center><h1>301 Moved Permanently</h1></center>\r\n"
        "<hr><center>nginx</center>\r\n</body>\r\n</html>\r\n";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, body, strlen(body));
    return hl + (int)strlen(body);
}

/* habr.com:443 — 302, CL 47, Location /ru/feed/ */
static int mk_habr443(void)
{
    const char *hdrs =
        "HTTP/1.1 302 Found\r\n"
        "Server: QRATOR\r\n"
        "Date: Thu, 29 Oct 2026 18:00:00 GMT\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        "Content-Length: 47\r\n"
        "Connection: close\r\n"
        "Location: https://habr.com/ru/feed/\r\n"
        "\r\n";
    const char *body = "Found. Redirecting to https://habr.com/ru/feed/";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, body, strlen(body));
    return hl + (int)strlen(body);
}

/* ya.ru:80 — 301, БЕЗ Content-Length, ТОЛЬКО заголовки (~1400 б) */
static int mk_ya80(void)
{
    const char *hdrs =
        "HTTP/1.1 301 Moved permanently\r\n"
        "X-Yandex-Req-Id: 1793348823577132-4364949540789377592-qre75ap2fgrdyive-BAL\r\n"
        "Cache-Control: max-age=86400,private\r\n"
        "Date: Fri, 30 Oct 2026 08:27:03 GMT\r\n"
        "Portal: Home\r\n"
        "Location: https://ya.ru/\r\n"
        "set-cookie: is_gdpr=0; Path=/; Domain=.ya.ru; Expires=Sun, 29 Oct 2028 08:27:03 GMT\r\n"
        "set-cookie: _yasc=2k74d9VRGSVGZRMzNhFHIzLbWqaYZwfu3QGHuGNjqSFa8TzEOpStyBXv8jjXv/EGOMq9PQ==; domain=.ya.ru; path=/; expires=Mon, 27 Oct 2036 08:27:03 GMT; SameSite=None; Secure\r\n"
        "set-cookie: bh=YNepkdcGagOLsQM=; Path=/; Domain=.ya.ru; Expires=Sat, 04 Dec 2027 08:27:03 GMT\r\n"
        "NEL: {\"report_to\": \"network-errors\", \"max_age\": 100}\r\n"
        "Accept-CH: Sec-CH-UA-Platform-Version, Sec-CH-UA-Mobile, Sec-CH-UA-Model\r\n"
        "X-Content-Type-Options: nosniff\r\n"
        "P3P: policyref=\"/w3c/p3p.xml\", CP=\"NON DSP ADM DEV PSD IVDo OUR IND STP PHY PRE NAV UNI\"\r\n"
        "\r\n";
    memcpy(resp, hdrs, strlen(hdrs));
    return (int)strlen(hdrs);
}

/* example.com — 200, text/html, БЕЗ CL, заголовки+тело одним сегментом */
static int mk_example(void)
{
    const char *hdrs =
        "HTTP/1.1 200 OK\r\n"
        "Date: Fri, 30 Oct 2026 08:29:06 GMT\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Connection: close\r\n"
        "\r\n";
    const char *body =
        "<!doctype html><html lang=en><head><meta charset=utf-8>"
        "<title>Example Domain</title></head>"
        "<body><h1>Example Domain</h1>"
        "<p>This domain is for use in illustrative examples in documents."
        " You may use this domain in literature without prior coordination"
        " or asking for permission.</p>"
        "<p><a href=\"https://www.iana.org/domains/example\">More information...</a></p>"
        "</body></html>";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, body, strlen(body));
    return hl + (int)strlen(body);
}

/* gzip-ответ: 200 + Content-Encoding: gzip (тело 116 б, сжатое 110) */
/* html 116 б, gzip 110 б */
static const unsigned char gz_blob[] = {
    0x1f,0x8b,0x08,0x00,0x00,0x00,0x00,0x00,0x02,0x03,0x25,0x8d,
    0x41,0x0e,0x80,0x20,0x0c,0x04,0xbf,0xc2,0x0f,0x1a,0xef,0x4d,
    0xaf,0x3e,0x40,0x4f,0xde,0x4a,0x68,0xa4,0x09,0x0a,0x81,0x5e,
    0xe4,0xf5,0xa2,0x5c,0x67,0x67,0x77,0x31,0xda,0x95,0x08,0xa3,
    0x70,0x20,0x34,0xb5,0x24,0xb4,0x1e,0x5a,0xdc,0x2e,0xcd,0x10,
    0x26,0x40,0x98,0xb1,0xcf,0xe1,0x19,0xea,0x42,0x5b,0x8f,0x6c,
    0x2a,0xae,0xb2,0xcf,0xc6,0x32,0xc4,0x01,0xb1,0xd0,0x66,0x95,
    0x6f,0xb5,0xc6,0xae,0x7d,0x06,0xbb,0xb3,0x6b,0x41,0x28,0x63,
    0x61,0x76,0xe1,0x7f,0x7b,0x01,0x17,0x9c,0x44,0xcd,0x74,0x00,
    0x00,0x00,
};
#define GZ_BLOB_LEN ((int)sizeof(gz_blob))
#define GZ_HTML_LEN 116

static int mk_gzip(void)
{
    const char *hdrs =
        "HTTP/1.1 200 OK\r\n"
        "Date: Fri, 30 Oct 2026 08:29:06 GMT\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Content-Encoding: gzip\r\n"
        "Connection: close\r\n"
        "\r\n";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, gz_blob, (size_t)GZ_BLOB_LEN);
    return hl + GZ_BLOB_LEN;
}

/* chunked-ответ */
static int mk_chunked(void)
{
    const char *hdrs =
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/html\r\n"
        "Transfer-Encoding: chunked\r\n"
        "Connection: close\r\n"
        "\r\n";
    const char *body = "5\r\nhello\r\n6\r\n world\r\n0\r\n\r\n";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, body, strlen(body));
    return hl + (int)strlen(body);
}

/* nginx 400: plain HTTP на HTTPS-порт */
static int mk_400(void)
{
    const char *hdrs =
        "HTTP/1.1 400 Bad Request\r\n"
        "Server: nginx\r\n"
        "Date: Fri, 30 Oct 2026 08:29:00 GMT\r\n"
        "Content-Type: text/html\r\n"
        "Content-Length: 247\r\n"
        "Connection: close\r\n"
        "\r\n";
    const char *body =
        "<html>\r\n<head><title>400 The plain HTTP request was sent to HTTPS port</title></head>\r\n"
        "<body>\r\n<center><h1>400 Bad Request</h1></center>\r\n"
        "<center>The plain HTTP request was sent to HTTPS port</center>\r\n"
        "<hr><center>nginx</center>\r\n</body>\r\n</html>\r\n";
    int hl = (int)strlen(hdrs);
    memcpy(resp, hdrs, (size_t)hl);
    memcpy(resp + hl, body, strlen(body));
    return hl + (int)strlen(body);
}

/* ---------- проверка ---------- */
static int fails = 0, total = 0;

#define CHECK(name, cond) do { \
    total++; \
    if (cond) printf("  PASS %s\n", name); \
    else { fails++; printf("  FAIL %s\n", name); \
           printf("  [serial] %s\n", ser_buf); } \
} while (0)

/* запустить потоковый GET: ответ n_len байт, разрезан на сегменты
 * (split_at <= 0 — одним сегментом с FIN) */
static int run_stream_1seg(int n_len, int split_at)
{
    ev_reset();
    cb_reset();
    ser_reset();
    cli_last_req_len = 0;

    if (split_at > 0 && n_len - split_at > 0) {
        ev_push_seg(TCP_PSH | TCP_ACK, resp, split_at);
        ev_push_seg(TCP_PSH | TCP_FIN, resp + split_at, n_len - split_at);
    } else {
        ev_push_seg(TCP_PSH | TCP_FIN, resp, n_len);
    }
    ev_push_seg(TCP_ACK, NULL, 0);        /* ACK клиентского FIN */

    int verdict = 0;
    int rc = net_http_get_stream("test", 80, "/", 15000, 1,
                                 test_hdr_cb, test_body_cb, &verdict);
    cb_verdict = verdict;
    return rc;
}

int main(void)
{
    int n, rc;

    printf("=== [HTTP-HDRCB]+[HTTP-TAIL]: habr.com:80 — 301, CL 162, один сегмент ===\n");
    n = mk_habr80();
    rc = run_stream_1seg(n, 0);
    CHECK("hdr-колбэк вызван 1 раз", cb_hdr_calls == 1);
    CHECK("статус 301", cb_hdr_status == 301);
    CHECK("Location = https://habr.com/", strcmp(cb_loc, "https://habr.com/") == 0);
    CHECK("verdict -2 (редирект)", cb_verdict == -2);
    CHECK("тело НЕ отдавалось (аборт по колбэку)", cb_body_calls == 0);
    CHECK("rc == -2", rc == -2);
    CHECK("запрос ушёл с Connection: close",
          strstr(cli_last_req, "Connection: close") != NULL);

    printf("=== habr.com:443 — 302, CL 47, Location /ru/feed/ ===\n");
    n = mk_habr443();
    rc = run_stream_1seg(n, 0);
    CHECK("hdr-колбэк вызван", cb_hdr_calls == 1);
    CHECK("Location = https://habr.com/ru/feed/",
          strcmp(cb_loc, "https://habr.com/ru/feed/") == 0);
    CHECK("verdict -2", cb_verdict == -2);
    CHECK("rc == -2", rc == -2);

    printf("=== ya.ru:80 — 301 БЕЗ CL, только заголовки, одним сегментом ===\n");
    n = mk_ya80();
    rc = run_stream_1seg(n, 0);
    CHECK("hdr-колбэк вызван", cb_hdr_calls == 1);
    CHECK("Location = https://ya.ru/", strcmp(cb_loc, "https://ya.ru/") == 0);
    CHECK("verdict -2", cb_verdict == -2);
    CHECK("rc == -2", rc == -2);

    printf("=== ya.ru:80 — заголовки РАЗБИТЫ на 144 б + хвост (реплика лога) ===\n");
    n = mk_ya80();
    CHECK("ответ > 144 б", n > 144);
    rc = run_stream_1seg(n, 144);
    CHECK("hdr-колбэк вызван (на хвостовом сегменте)", cb_hdr_calls == 1);
    CHECK("Location = https://ya.ru/", strcmp(cb_loc, "https://ya.ru/") == 0);
    CHECK("verdict -2", cb_verdict == -2);
    CHECK("rc == -2", rc == -2);

    printf("=== example.com — 200 text/html, заголовки+тело ОДНИМ сегментом ===\n");
    n = mk_example();
    {
        /* длина заголовочного блока — по факту (\r\n\r\n в ответе) */
        const char *e = strstr(resp, "\r\n\r\n");
        int hl = e ? (int)(e - resp) + 4 : 0;
        rc = run_stream_1seg(n, 0);
        CHECK("hdr-колбэк вызван, статус 200",
              cb_hdr_calls == 1 && cb_hdr_status == 200);
        CHECK("[HTTP-TAIL] тело доставлено целиком",
              cb_body_calls >= 1 && cb_body_len == n - hl);
        CHECK("rc == длине тела", rc == n - hl);
        CHECK("[HTTP-LASTSTAT] raw_received == телу",
              net_http_raw_received() == (u32)(n - hl));
        CHECK("[HTTP-LASTSTAT] CL == 0 (нет заголовка)",
              net_http_content_length() == 0);
        CHECK("тело осмысленное", strstr(cb_body, "Example Domain") != NULL);
    }

    printf("=== gzip — 200 + Content-Encoding: gzip ===\n");
    n = mk_gzip();
    {
        rc = run_stream_1seg(n, 0);
        CHECK("hdr-колбэк вызван, статус 200",
              cb_hdr_calls == 1 && cb_hdr_status == 200);
        CHECK("[HTTP-GZSINK] тело РАСПАКОВАНО (116 б)", cb_body_len == GZ_HTML_LEN);
        CHECK("распакованное — html", strstr(cb_body, "<html>") != NULL);
        CHECK("rc == 116 (распакованное)", rc == GZ_HTML_LEN);
        CHECK("[HTTP-LASTSTAT] raw == сжатому (110 б)",
              net_http_raw_received() == (u32)GZ_BLOB_LEN);
        CHECK("[HTTP-LASTSTAT] CL == распакованному",
              net_http_content_length() == (u32)GZ_HTML_LEN);
    }

    printf("=== chunked — декодирование хвоста в одном сегменте ===\n");
    n = mk_chunked();
    rc = run_stream_1seg(n, 0);
    CHECK("тело декодировано ('hello world')",
          cb_body_len == 11 && strcmp(cb_body, "hello world") == 0);
    CHECK("rc == 11", rc == 11);

    printf("=== nginx 400 (plain на HTTPS-порт) — verdict -4 ===\n");
    n = mk_400();
    rc = run_stream_1seg(n, 0);
    CHECK("hdr-колбэк вызван, статус 400",
          cb_hdr_calls == 1 && cb_hdr_status == 400);
    CHECK("verdict -4", cb_verdict == -4);
    CHECK("тело не отдавалось", cb_body_calls == 0);
    CHECK("rc == -2 (аборт)", rc == -2);

    printf("=== EOF до конца заголовков — честная ошибка ===\n");
    {
        const char *frag = "HTTP/1.1 200 OK\r\nDate: Fri, 30 Oct 2026\r\nX-Ya";
        int fl = (int)strlen(frag);
        ev_reset();
        cb_reset();
        ser_reset();
        ev_push_seg(TCP_PSH | TCP_ACK, frag, fl);
        ev_push_seg(TCP_FIN, NULL, 0);
        ev_push_seg(TCP_ACK, NULL, 0);
        int verdict = 0;
        rc = net_http_get_stream("test", 80, "/", 15000, 1,
                                 test_hdr_cb, test_body_cb, &verdict);
        CHECK("hdr-колбэк НЕ вызывался", cb_hdr_calls == 0);
        CHECK("rc == -1", rc == -1);
        CHECK("errstr 'пустой ответ'",
              strstr(net_http_errstr(), "пустой") != NULL);
    }

    printf("=== [TCP-FINHOLE]: FIN при дыре — ACK не прыгает, ретрансмиссия спасает ===\n");
    {
        n = mk_ya80();
        ev_reset();
        ser_reset();
        int s = net_tcp_connect(0x0A000202u, 80, 40123);
        CHECK("клиент подключился", s >= 0);
        net_poll();                              /* SYN-ACK -> ESTABLISHED */
        CHECK("ESTABLISHED", net_tcp_state(s) == TCP_ESTABLISHED);

        /* 1. первый сегмент 144 б (как в логе) */
        ev_push_seg(TCP_PSH | TCP_ACK, resp, 144);
        net_poll();
        /* 2. FIN, перепрыгнув середину (сегмент [144..n) потерян) */
        {
            u32 save = srv_seq;
            srv_seq = 0x90000001u + (u32)n;
            ev_push_seg(TCP_FIN | TCP_ACK, NULL, 0);
            srv_seq = save;
            net_poll();
        }
        CHECK("дыра: состояние ещё ESTABLISHED (не LAST_ACK)",
              net_tcp_state(s) == TCP_ESTABLISHED);

        /* 3. ретрансмиссия потерянного сегмента */
        ev_push_seg(TCP_PSH | TCP_ACK, resp + 144, n - 144);
        net_poll();
        CHECK("после ретрансмиссии всё ещё ждём FIN",
              net_tcp_state(s) == TCP_ESTABLISHED);

        /* 4. FIN повторно — уже по порядку */
        ev_push_seg(TCP_FIN | TCP_ACK, NULL, 0);
        net_poll();
        CHECK("FIN по порядку -> LAST_ACK", net_tcp_state(s) == TCP_LAST_ACK);

        /* 5. сервер подтверждает наш FIN */
        ev_push_seg(TCP_ACK, NULL, 0);
        net_poll();
        CHECK("закрыто", net_tcp_state(s) == TCP_CLOSED);
        /* Главный эффект [TCP-FINHOLE] — п.2/п.3: прежде client слепо
         * улетал в LAST_ACK на шаге 2, и сегмент шага 3 отбрасывался
         * навсегда (ответ = 144 б). */
    }

    printf("=== [TCP-FINHOLE]: FIN+данные одним сегментом по порядку ===\n");
    {
        ev_reset();
        int s = net_tcp_connect(0x0A000202u, 80, 40124);
        net_poll();
        CHECK("ESTABLISHED", s >= 0 && net_tcp_state(s) == TCP_ESTABLISHED);
        ev_push_seg(TCP_PSH | TCP_FIN, "HTTP/1.1 200 OK\r\n\r\nbody", 23);
        net_poll();
        CHECK("FIN+данные по порядку -> LAST_ACK",
              net_tcp_state(s) == TCP_LAST_ACK);
    }

    printf("=== буферизованный GET (не-потоковый) не сломан ===\n");
    {
        static char buf[8192];
        n = mk_example();
        ev_reset();
        ser_reset();
        ev_push_seg(TCP_PSH | TCP_FIN, resp, n);
        ev_push_seg(TCP_ACK, NULL, 0);
        rc = net_http_get("test", 80, "/", buf, sizeof(buf), 15000);
        CHECK("rc == полный ответ (заголовки+тело)", rc == n);
        CHECK("тело на месте", strstr(buf, "Example Domain") != NULL);
    }

    printf("=== [HTTP-LASTSTAT] у буферизованного CL-ответа CL честный ===\n");
    {
        static char buf[8192];
        n = mk_400();
        ev_reset();
        ev_push_seg(TCP_PSH | TCP_FIN, resp, n);
        ev_push_seg(TCP_ACK, NULL, 0);
        rc = net_http_get("test", 80, "/", buf, sizeof(buf), 15000);
        CHECK("rc == полному ответу", rc == n);
        CHECK("content_length == 247 (по заголовку)",
              net_http_content_length() == 247);
    }

    (void)cli_last_req_len;
    (void)cli_syn_seen;
    printf("\n%s: %d/%d passed, %d failed\n",
           fails ? "ПРОВАЛ" : "УСПЕХ", total - fails, total, fails);
    return fails ? 1 : 0;
}
