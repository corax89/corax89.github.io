/* test_chunked.c — хост-тест декодера Transfer-Encoding: chunked
 * (FIX [HTTP-CHUNKED], net_http.c).
 *
 * Код ch_put_out/ch_broken/ch_feed ВЫРЕЗАЕТСЯ из src/net_http.c при
 * сборке (scripts/generated_chunked.inc — см. gen-команду в
 * scripts/run_all_host_tests.sh) — тест проверяет НАСТОЯЩИЙ код
 * декодера, а не ручную копию.
 *
 * Границы: чанк разбит между сегментами (размер/данные/CRLF/трейлер
 * по 1 байту), расширение ";ext", trailer-блок, 0-чанк без trailer,
 * битый размер, переполнение буфера вызывающего, чанк 64 КБ кусками
 * по 1 КБ.
 *
 * Сборка/запуск: sh scripts/run_chunked_test.sh
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Task 65 [CH-LOG]: ch_broken() пишет диагностику в serial — на хосте глотаем */
static void serial_puts(const char *s) { (void)s; }

typedef unsigned int u32;
typedef unsigned char u8;

/* --- подмена окружения ядра для вырезанного кода --- */
static char  *t_buf;
static u32   t_len, t_max;
static int   t_trunc, t_done;

#include "generated_chunked.inc"

static int fails = 0, total = 0;

static void reset(void)
{
    free(t_buf);
    t_buf = (char *)malloc(65536);
    t_len = 0; t_max = 65536; t_trunc = 0; t_done = 0;
    g_chunked = 0; g_ch_state = CH_SIZE; g_ch_rem = 0;
    g_ch_line_len = 0; g_chunk_end = 0; g_ch_sol = 1;
}

/* скормить тело куском(ами) заданного размера (имитация TCP-сегментов) */
static void feed_n(const char *raw, u32 n, u32 seg)
{
    u32 off = 0;
    while (off < n) {
        u32 take = seg < n - off ? seg : n - off;
        ch_feed((const unsigned char *)raw + off, take);
        off += take;
    }
}
#define FEED_ALL(raw, seg) feed_n((raw), (u32)strlen(raw), (seg))

static void expect(const char *name, const char *want,
                   int want_done, int want_trunc)
{
    total++;
    u32 wn = (u32)strlen(want);
    int ok = (wn == t_len) && (wn == 0 || memcmp(t_buf, want, wn) == 0)
             && (t_done == want_done) && (t_trunc == want_trunc);
    if (ok) printf("PASS %s\n", name);
    else {
        fails++;
        printf("FAIL %s: got %u bytes (want %u), done=%d/%d trunc=%d/%d\n",
               name, t_len, wn, t_done, want_done, t_trunc, want_trunc);
        printf("      got : \"%.50s\"\n      want: \"%.50s\"\n",
               t_len ? t_buf : "(empty)", want);
    }
}

int main(void)
{
    printf("=== chunked decoder host test ===\n");

    /* 1. один чанк одним сегментом */
    reset(); g_chunked = 1;
    FEED_ALL("5\r\nhello\r\n0\r\n\r\n", 4096);
    expect("single chunk", "hello", 1, 0);

    /* 2. несколько чанков */
    reset(); g_chunked = 1;
    FEED_ALL("3\r\nabc\r\n2\r\nde\r\n4\r\nfghi\r\n0\r\n\r\n", 4096);
    expect("multi chunk", "abcdefghi", 1, 0);

    /* 3. поток по 1 байту (худший сегментации) */
    reset(); g_chunked = 1;
    FEED_ALL("3\r\nabc\r\n0\r\n\r\n", 1);
    expect("byte-per-byte segments", "abc", 1, 0);

    /* 4. расширение чанка ";ext=1" */
    reset(); g_chunked = 1;
    FEED_ALL("5;ext=1\r\nworld\r\n0\r\n\r\n", 4096);
    expect("chunk extension", "world", 1, 0);

    /* 5. trailer-блок */
    reset(); g_chunked = 1;
    FEED_ALL("2\r\nhi\r\n0\r\nX-Trailer: v\r\n\r\n", 4096);
    expect("trailer block", "hi", 1, 0);

    /* 6. 0-чанк без trailer (сервер закрыл соединение) */
    reset(); g_chunked = 1;
    FEED_ALL("4\r\ntail\r\n0\r\n", 4096);
    expect("no trailer (close)", "tail", 0, 0);

    /* 7. 0-чанк завершает: хвост глотается как trailer, пустая строка
     * завершает ответ (как и закрытие соединения) */
    reset(); g_chunked = 1;
    FEED_ALL("2\r\nab\r\n0\r\n2\r\ncd\r\n\r\n", 4096);
    expect("0-chunk + trailers", "ab", 1, 0);

    /* 8. битый размер (не hex) — молча глотаем */
    reset(); g_chunked = 1;
    FEED_ALL("zz\r\nabc\r\n", 4096);
    expect("broken size -> swallow", "", 1, 0);

    /* 9. переполнение буфера вызывающего */
    reset(); t_max = 8;   /* влезет 7 байт (max-1) */
    g_chunked = 1;
    FEED_ALL("10\r\n0123456789ABCDEF\r\n0\r\n\r\n", 4096);
    /* декодер доходит до конца потока (done=1), флаг обреза честный */
    expect("buffer full -> trunc", "0123456", 1, 1);

    /* 10. чанк 64 КБ сегментами по 1 КБ (буфер с запасом на NUL) */
    {
        reset(); t_max = 65537;
        g_chunked = 1;
        char *raw = (char *)malloc(70000 + 64);
        int rn = snprintf(raw, 70000 + 64, "10000\r\n");
        for (int i = 0; i < 65536; i++) raw[rn++] = (char)('A' + (i % 26));
        rn += snprintf(raw + rn, 16, "\r\n0\r\n\r\n");
        FEED_ALL(raw, 1024);
        int ok = (t_len == 65536) && (t_buf[0] == 'A') &&
                 (t_buf[65535] == (char)('A' + (65535 % 26))) &&
                 t_done && !t_trunc;
        total++;
        if (ok) printf("PASS 64K chunk in 1K segments\n");
        else { fails++; printf("FAIL 64K chunk: len=%u done=%d trunc=%d\n",
                                t_len, t_done, t_trunc); }
        free(raw);
    }

    printf("=== %d/%d passed, %d failed ===\n",
           total - fails, total, fails);
    free(t_buf);
    return fails != 0;
}
