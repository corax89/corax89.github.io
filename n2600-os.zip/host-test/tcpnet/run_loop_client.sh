#!/bin/bash
# run_loop_client.sh — репро «localhost ничего не отдаёт» (сессия 61/63)
# + ASan. Использует ту же связку, что и httpd60: fake_nic + build_host/*.
# Каталог общий с run_tcpnet.sh — сначала убираем его libc-редиректы
# (их quoted-include побеждает заглушки stubs_net и ломает malloc(u32)).
cd "$(dirname "$0")"
SRC=${SRC:-../../src}
rm -f mem.h string.h sync.h task.h timer.h limits.h ramfs.h \
      net.c net.h net_http.c net_httpd.c net_tls.h net_httpd.h types.h \
      e1000.h ne2000.h virtio_net.h ath9k_wifi.h atl1c.h
mkdir -p build_host
ln -sf "$(pwd)/$SRC/net.c"        build_host/net.c
ln -sf "$(pwd)/$SRC/net_http.c"   build_host/net_http.c
ln -sf "$(pwd)/$SRC/net_dns.c"    build_host/net_dns.c
ln -sf "$(pwd)/$SRC/net_httpd.c"  build_host/net_httpd.c
cp -f stubs_net/sync_host.h       build_host/sync.h

COMMON="-std=c99 -Wall -Wextra -I stubs_net -I $SRC"
FILES="loop_client_test.c fake_nic.c stubs_net/tls_stubs.c stubs_net/fake_server_stub.c build_host/net.c \
       build_host/net_http.c build_host/net_dns.c build_host/net_httpd.c $SRC/string.c"

FAIL=0
gcc $COMMON -g -O1 $FILES -o loop_client_test 2>build_lc.log || { grep error build_lc.log | head; exit 1; }
W=$(grep -c warning build_lc.log); echo "предупреждений: $W"
./loop_client_test || FAIL=1

if gcc $COMMON -g -O1 -fsanitize=address,undefined $FILES \
      -o loop_client_test_asan 2>>build_lc.log; then
    ./loop_client_test_asan >/dev/null 2>asan_lc.log
    RC=$?
    if [ $RC -ne 0 ] && grep -q "AddressSanitizer\|runtime error" asan_lc.log; then
        echo "=== ASAN/UBSAN НАШЁЛ ПРОБЛЕМЫ ==="; head -25 asan_lc.log; FAIL=1
    else
        echo "ASan/UBSan: чисто"
    fi
fi
exit $FAIL
