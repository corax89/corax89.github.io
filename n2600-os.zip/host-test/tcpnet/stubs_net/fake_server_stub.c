/* fake_server_stub.c — заглушка модели сервера для харнесов, которым
 * она не нужна (loop_client): fake_nic.c зовёт её на каждый TX. */
#include "types.h"
void fake_server_on_tx(const u8 *frame, u32 len) { (void)frame; (void)len; }
