/* mqjs_libc.h — хост-вариант (настоящая libc) для хост-харнесса mqjs. */
#ifndef MQJS_LIBC_H
#define MQJS_LIBC_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <assert.h>
#include <inttypes.h>
#include <setjmp.h>
#include <stdarg.h>
#endif
