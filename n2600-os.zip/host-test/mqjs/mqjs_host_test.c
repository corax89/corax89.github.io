/* mqjs_host_test.c — хост-харнес моста MicroQuickJS (сессия 64).
 *
 * Проверяет ВСЕ механики, которые использует ядро N2600-OS, до сборки ядра:
 *   1. расширенная таблица C-функций (копия js_c_function_table + свои),
 *      создание функций через JS_NewCFunctionParams(ctx, idx, JS_UNDEFINED)
 *      и установка в global через JS_SetPropertyStr;
 *   2. name = JS_UNDEFINED в JSCFunctionDef — безопасно для GC
 *      (Function.prototype.name undefined, ничего не падает);
 *   3. вывод через JS_SetLogFunc (write_func) — так мост ловит и print(),
 *      и дампы ошибок JS_PrintValueF;
 *   4. обработчик прерываний (кооперативная вытеска + опциональный break);
 *   5. ошибки: SyntaxError/TypeError — извлечение message;
 *   6. GC-стресс и нехватка памяти — аккуратный JS_ThrowOutOfMemory;
 *   7. семантика будущих примеров ramdisk (CALC.JS/DEMO.JS/IMG.JS).
 *
 * Сборка: ./run_mqjs.sh
 */
#include "mqjs.h"
#include "mqjs_priv.h"   /* JS_MTAG_*, JS_ROM_VALUE, js_global_isNaN/isFinite */
#include "mqjs_libm.h"  /* js_sin/js_pow/... для Math.* в таблице стандарта */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Функции из CLI mqjs.c, на которые ссылается таблица стандарта
 * (mqjs_stdlib.h включается ПОСЛЕ этих прототипов). */
static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);

#include "mqjs_stdlib.h"

#define REGION_SIZE (512 * 1024)
#define OUT_MAX 65536

static int tests_failed = 0;
static int checks_total = 0;

#define CHECK(cond, msg) do { \
    checks_total++; \
    if (!(cond)) { \
        printf("FAIL [%d]: %s\n", checks_total, msg); \
        printf("  at %s:%d\n", __FILE__, __LINE__); \
        tests_failed++; \
    } \
} while (0)

/* ---------- фейковая ОС-состояния ---------- */
static int   os_screen_w = 800, os_screen_h = 600;
static int   os_rects = 0, os_texts = 0, os_flips = 0;
static int   os_wins_open = 0, os_wins_alive = 1;
static int   os_btn_seq[8] = { 0, 5, 14, 12, -1 };
static int   os_btn_seq_pos = 0;
static int   os_img_loaded = 0;
static long  os_delay_ms = 0;
static int   os_yields = 0;
static int   os_break_after = -1;      /* прервать скрипт после N yield'ов */

/* ---------- вывод (write_func) ---------- */
static char out_buf[OUT_MAX];
static size_t out_pos = 0;

static void mq_write(void *opaque, const void *buf, size_t len) {
    (void)opaque;
    if (out_pos + len < sizeof(out_buf)) {
        memcpy(out_buf + out_pos, buf, len);
        out_pos += len;
        out_buf[out_pos] = 0;
    }
}

/* ---------- обработчик прерываний (кооперативность) ---------- */
static int mq_interrupt(JSContext *ctx, void *opaque) {
    (void)ctx; (void)opaque;
    os_yields++;                            /* в ядре здесь task_yield() */
    if (os_break_after > 0 && os_yields >= os_break_after) return 1;
    return 0;
}

/* ---------- host-функции (те же имена, что в ядре) ---------- */
static void out_puts(const char *s) {
    mq_write(NULL, s, strlen(s));
}

static JSValue mq_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;
    for (int i = 0; i < argc; i++) {
        if (i) mq_write(NULL, " ", 1);
        JSValue s = JS_ToString(ctx, argv[i]);
        if (JS_IsException(s)) return s;
        JSCStringBuf sb;
        size_t len;
        const char *str = JS_ToCStringLen(ctx, &len, s, &sb);
        if (!str) return JS_EXCEPTION;
        mq_write(NULL, str, len);
        /* JSValue строки после GC может уехать — копия уже сделана */
    }
    out_puts("\n");
    return JS_UNDEFINED;
}

static JSValue mq_screen_width(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_NewInt32(c, os_screen_w);
}
static JSValue mq_screen_height(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_NewInt32(c, os_screen_h);
}
static JSValue mq_fill_rect(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t; (void)a; os_rects++;
    int x, y, w, h, col;
    JS_ToInt32Sat(c, &x, v[0]); JS_ToInt32Sat(c, &y, v[1]);
    JS_ToInt32Sat(c, &w, v[2]); JS_ToInt32Sat(c, &h, v[3]);
    JS_ToInt32Sat(c, &col, v[4]);
    (void)x;(void)y;(void)w;(void)h;(void)col;
    return JS_UNDEFINED;
}
static JSValue mq_draw_text(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t; (void)a; os_texts++;
    JSCStringBuf sb;
    const char *s = JS_ToCString(c, v[2], &sb);
    if (s) { (void)s; }
    return JS_UNDEFINED;
}
static JSValue mq_get_color(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    int r, g, b;
    JS_ToInt32Sat(c, &r, v[0]); JS_ToInt32Sat(c, &g, v[1]); JS_ToInt32Sat(c, &b, v[2]);
    return JS_NewInt32(c, (r << 16) | (g << 8) | b);
}
static JSValue mq_clear_screen(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; os_rects++; return JS_UNDEFINED;
}
static JSValue mq_flip(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; os_flips++; return JS_UNDEFINED;
}
static JSValue mq_delay(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    int ms; JS_ToInt32Sat(c, &ms, v[0]);
    if (ms < 1) ms = 1;
    os_delay_ms += ms;
    return JS_UNDEFINED;
}
static JSValue mq_uptime(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; return JS_NewInt32(c, (int)(os_delay_ms / 1000));
}
static JSValue mq_win_open(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v;
    if (!os_wins_alive) return JS_NewInt32(c, -1);
    os_wins_open++;
    return JS_NewInt32(c, 0);
}
static JSValue mq_win_close(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; os_wins_alive = 0; return JS_UNDEFINED;
}
static JSValue mq_win_alive(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; return JS_NewBool(os_wins_alive);
}
static JSValue mq_win_clear(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_win_rect(JSContext *c, JSValue *t, int a, JSValue *v) {
    return mq_fill_rect(c, t, a, v);
}
static JSValue mq_win_text(JSContext *c, JSValue *t, int a, JSValue *v) {
    return mq_draw_text(c, t, a, v);
}
static JSValue mq_win_update(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_btn_add(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
/* кнопки по сценарию: 0,5,14,12,-1 (см. os_btn_seq) */
static JSValue mq_btn_clicked(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v;
    int b = -1;
    if (os_btn_seq_pos < 8 && os_btn_seq[os_btn_seq_pos] != -1) {
        b = os_btn_seq[os_btn_seq_pos];
    }
    if (os_btn_seq_pos < 8) os_btn_seq_pos++;
    return JS_NewInt32(c, b);
}
static JSValue mq_btn_set_label(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_img_load(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v;
    if (os_img_loaded) return JS_NewInt32(c, -1);   /* второй вызов — ошибка */
    os_img_loaded = 1;
    return JS_NewInt32(c, 1);
}
static JSValue mq_img_free(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; os_img_loaded = 0; return JS_UNDEFINED;
}
static JSValue mq_img_w(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; return JS_NewInt32(c, os_img_loaded ? 240 : 0);
}
static JSValue mq_img_h(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; return JS_NewInt32(c, os_img_loaded ? 100 : 0);
}
static JSValue mq_img_pixel(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;(void)v; return JS_NewInt32(c, os_img_loaded ? 0x336699 : -1);
}
static JSValue mq_img_draw(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_img_draw_scaled(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_win_img(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
static JSValue mq_win_img_scaled(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v; return JS_UNDEFINED;
}
/* ramfs_read/write — строка + Uint8Array */
static char ram_file[4096];
static int  ram_len = 0;
static JSValue mq_ramfs_write(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    JSCStringBuf sb;
    const char *name = JS_ToCString(c, v[0], &sb);
    if (!name) return JS_EXCEPTION;
    JSValue data = v[1];
    size_t len = 0;
    const char *str = JS_ToCStringLen(c, &len, data, &sb);
    if (str && len < sizeof(ram_file)) {
        memcpy(ram_file, str, len);
        ram_len = (int)len;
    }
    return JS_NewBool(ram_len > 0);
}
static JSValue mq_ramfs_read(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    JSCStringBuf sb;
    const char *name = JS_ToCString(c, v[0], &sb);
    if (!name) return JS_EXCEPTION;
    return JS_NewStringLen(c, ram_file, (size_t)ram_len);
}
static JSValue mq_ramfs_list(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)c;(void)t;(void)a;(void)v;
    JSValue arr = JS_NewArray(c, 1);
    JS_SetPropertyUint32(c, arr, 0, JS_NewString(c, "DEMO.JS"));
    return arr;
}
/* strlen/malloc/free/memset/memcmp — C-API нет смысла тянуть в JS,
 * но имена оставлены совместимыми со старыми скриптами: */
static JSValue mq_strlen(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    JSCStringBuf sb;
    const char *s = JS_ToCString(c, v[0], &sb);
    return JS_NewInt32(c, s ? (int)strlen(s) : 0);
}
static JSValue mq_print_int(JSContext *c, JSValue *t, int a, JSValue *v) {
    (void)t;(void)a;
    int n; JS_ToInt32Sat(c, &n, v[0]);
    char b[16]; snprintf(b, sizeof(b), "%d", n);
    out_puts(b);
    return JS_UNDEFINED;
}

/* ---------- функции из CLI mqjs.c, на которые ссылается таблица стандарта.
 * В ядре их реализует мост (mqjs_api.c) — здесь те же имена/семантика. */
static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    return mq_print(ctx, this_val, argc, argv);
}
static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;(void)argc;(void)argv;
    JS_GC(ctx);
    return JS_UNDEFINED;
}
static JSValue js_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;(void)argc;(void)argv;
    return JS_ThrowTypeError(ctx, "load() is not supported in N2600-OS");
}
static long host_uptime_ms(void) {
    return os_delay_ms + os_yields;   /* в ядре — timer_ticks() */
}
static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;
    double val;
    argc &= ~FRAME_CF_CTOR;
    if (argc == 0) {
        val = (double)host_uptime_ms();
    } else if (argc == 1 && JS_IsNumber(ctx, argv[0])) {
        if (JS_ToNumber(ctx, &val, argv[0])) return JS_EXCEPTION;
    } else {
        return JS_ThrowTypeError(ctx, "unsupported Date() parameter");
    }
    return JS_NewDate(ctx, val);
}
static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;(void)argc;(void)argv;
    return JS_NewInt64(ctx, host_uptime_ms());
}
static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;(void)argc;(void)argv;
    return JS_NewInt64(ctx, host_uptime_ms());
}
static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    /* в N2600-OS нет событийного цикла: таймеров нет (возвращаем 0) */
    (void)this_val;(void)argc;(void)argv;
    return JS_NewInt32(ctx, 0);
}
static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv) {
    (void)this_val;(void)argc;(void)argv;
    return JS_UNDEFINED;
}

/* ---------- расширенная таблица C-функций ---------- */
#define NDEFAULT (sizeof(js_c_function_table) / sizeof(js_c_function_table[0]))

#define UFE(fn, nargs) { { .generic = (fn) }, JS_UNDEFINED, JS_CFUNC_generic, (nargs), 0 }

static const JSCFunctionDef mq_user_funcs[] = {
    UFE(mq_print,            1),
    UFE(mq_print_int,        1),
    UFE(mq_screen_width,     0),
    UFE(mq_screen_height,    0),
    UFE(mq_fill_rect,        5),
    UFE(mq_draw_text,        4),
    UFE(mq_get_color,        3),
    UFE(mq_clear_screen,     1),
    UFE(mq_flip,             0),
    UFE(mq_delay,            1),
    UFE(mq_uptime,           0),
    UFE(mq_strlen,           1),
    UFE(mq_ramfs_read,       3),
    UFE(mq_ramfs_write,      2),
    UFE(mq_ramfs_list,       0),
    UFE(mq_win_open,         5),
    UFE(mq_win_close,        1),
    UFE(mq_win_alive,        1),
    UFE(mq_win_clear,        2),
    UFE(mq_win_rect,         6),
    UFE(mq_win_text,         5),
    UFE(mq_win_update,       1),
    UFE(mq_btn_add,          6),
    UFE(mq_btn_clicked,      1),
    UFE(mq_btn_set_label,    3),
    UFE(mq_img_load,         1),
    UFE(mq_img_free,         1),
    UFE(mq_img_w,            1),
    UFE(mq_img_h,            1),
    UFE(mq_img_pixel,        3),
    UFE(mq_img_draw,         3),
    UFE(mq_img_draw_scaled,  5),
    UFE(mq_win_img,          4),
    UFE(mq_win_img_scaled,   6),
};

static const char *const mq_user_names[sizeof(mq_user_funcs) / sizeof(mq_user_funcs[0])] = {
    "print", "print_int", "screen_width", "screen_height",
    "fill_rect", "draw_text", "get_color", "clear_screen", "flip",
    "delay", "uptime", "strlen",
    "ramfs_read", "ramfs_write", "ramfs_list",
    "win_open", "win_close", "win_alive", "win_clear", "win_rect",
    "win_text", "win_update", "btn_add", "btn_clicked", "btn_set_label",
    "img_load", "img_free", "img_w", "img_h", "img_pixel",
    "img_draw", "img_draw_scaled", "win_img", "win_img_scaled",
};

static JSCFunctionDef mq_table[NDEFAULT + 64];
static JSSTDLibraryDef mq_stdlib;
static int mq_table_ready = 0;

static void mq_build_table(void) {
    int nuser = (int)(sizeof(mq_user_funcs) / sizeof(mq_user_funcs[0]));
    if (mq_table_ready) return;
    memcpy(mq_table, js_c_function_table, sizeof(js_c_function_table));
    memcpy(mq_table + NDEFAULT, mq_user_funcs, sizeof(mq_user_funcs));
    mq_stdlib = js_stdlib;
    mq_stdlib.c_function_table = mq_table;
    mq_table_ready = 1;
    CHECK(NDEFAULT + nuser <= sizeof(mq_table) / sizeof(mq_table[0]),
          "user funcs fit in extended table");
}

/* ---------- запуск скрипта (как mqjs_run в ядре) ---------- */
static char last_error[256];

static int mq_run(const char *src, const char *name) {
    out_pos = 0; out_buf[0] = 0;
    last_error[0] = 0;
    os_yields = 0;
    mq_build_table();

    void *region = malloc(REGION_SIZE);
    if (!region) { strcpy(last_error, "no memory for region"); return -1; }
    memset(region, 0, REGION_SIZE);
    JSContext *ctx = JS_NewContext(region, REGION_SIZE, &mq_stdlib);
    CHECK(ctx != NULL, "JS_NewContext");
    if (!ctx) { free(region); return -1; }
    JS_SetLogFunc(ctx, mq_write);
    JS_SetInterruptHandler(ctx, mq_interrupt);
    JS_SetRandomSeed(ctx, 12345);

    JSValue global = JS_GetGlobalObject(ctx);
    int nuser = (int)(sizeof(mq_user_funcs) / sizeof(mq_user_funcs[0]));
    for (int i = 0; i < nuser; i++) {
        JSValue f = JS_NewCFunctionParams(ctx, (int)NDEFAULT + i, JS_UNDEFINED);
        if (JS_SetPropertyStr(ctx, global, mq_user_names[i], f) < 0) {
            snprintf(last_error, sizeof(last_error),
                     "install %s failed", mq_user_names[i]);
            JS_FreeContext(ctx);
            free(region);
            return -1;
        }
    }

    JSValue val = JS_Eval(ctx, src, strlen(src), name, 0);
    int rc = 0;
    if (JS_IsException(val)) {
        rc = -1;
        JSValue exc = JS_GetException(ctx);
        JSValue msg = JS_GetPropertyStr(ctx, exc, "message");
        if (!JS_IsUndefined(msg) && !JS_IsNull(msg)) {
            JSCStringBuf sb;
            const char *m = JS_ToCString(ctx, msg, &sb);
            snprintf(last_error, sizeof(last_error), "%s", m ? m : "?");
        } else {
            /* не Error-объект — дампим значение через write_func */
            JS_PrintValueF(ctx, exc, JS_DUMP_LONG);
        }
    }

    JS_FreeContext(ctx);
    free(region);
    if (getenv("MQJS_DEBUG")) {
        printf("--- out_buf (%zu bytes) ---\n%s---\n", out_pos, out_buf);
        printf("--- last_error: %s ---\n", last_error);
    }
    return rc;
}

/* ---------- тесты ---------- */
static void reset_os(void) {
    os_rects = os_texts = os_flips = 0;
    os_wins_open = 0; os_wins_alive = 1;
    os_btn_seq_pos = 0;
    os_img_loaded = 0;
    os_delay_ms = 0;
    os_yields = 0;
    os_break_after = -1;
    ram_len = 0; ram_file[0] = 0;
}

static void test_arith(void) {
    reset_os();
    int rc = mq_run(
        "var a = 2 + 2 * 2;\n"
        "print(a);\n"
        "print(\"hi\" + \" \" + \"N2600\");\n"
        "print(\"tpl \" + a + \" end\");\n"
        "print(Math.sqrt(144), Math.sin(0), Math.pow(2, 10));\n"
        "print(JSON.parse('[1,2,3]')[1]);\n"
        "print(JSON.stringify({x: 5}));\n"
        "print((1234.5).toFixed(1));\n"
        "print(Math.max(3, 7, 1), Math.abs(-5), Math.floor(2.7));\n",
        "arith.js");
    CHECK(rc == 0, "arith: run ok");
    CHECK(strstr(out_buf, "6\n"), "arith: 2+2*2 == 6");
    CHECK(strstr(out_buf, "hi N2600\n"), "arith: strings");
    CHECK(strstr(out_buf, "tpl 6 end\n"), "arith: template literal");
    CHECK(strstr(out_buf, "12 0 1024\n"), "arith: math fns");
    CHECK(strstr(out_buf, "2\n"), "arith: JSON array");
    CHECK(strstr(out_buf, "{\"x\":5}"), "arith: JSON stringify");
    CHECK(strstr(out_buf, "1234.5\n"), "arith: toFixed");
    CHECK(strstr(out_buf, "7 5 2\n"), "arith: Math.max/abs/floor");
}

/* калькулятор — семантика будущего шаблона QuickJS */
static void test_calculator(void) {
    reset_os();
    int rc = mq_run(
        "function apply(acc, cur, op) {\n"
        "    if (op === 1) return acc + cur;\n"
        "    if (op === 2) return acc - cur;\n"
        "    if (op === 3) return acc * cur;\n"
        "    if (op === 4) return cur === 0 ? NaN : acc / cur;\n"
        "    return cur;\n"
        "}\n"
        "var win = win_open(\"Калькулятор\", 240, 160, 240, 286);\n"
        "print(\"win\", win);\n"
        "var acc = 0, cur = 0, op = 0, fresh = 1;\n"
        "var frames = 0;\n"
        "while (win_alive(win)) {\n"
        "    frames++;\n"
        "    if (frames > 5) { win_close(win); break; }\n"
        "    var b = btn_clicked(win);\n"
        "    if (b >= 0) {\n"
        "        if (b === 14) { cur = apply(acc, cur, op); op = 0; fresh = 1; }\n"
        "        else if (b === 12) { acc = 0; cur = 0; op = 0; fresh = 1; }\n"
        "        else if (b % 4 === 3) { acc = cur; op = b === 3 ? 4 : (b === 7 ? 3 : (b === 11 ? 2 : 1)); fresh = 1; }\n"
        "        else {\n"
        "            var d = [7,8,9,0,4,5,6,0,1,2,3,0,0,0,0,0][b];\n"
        "            if (fresh) { cur = d; fresh = 0; } else cur = cur * 10 + d;\n"
        "        }\n"
        "    }\n"
        "    win_clear(win, 0x1e2028);\n"
        "    win_text(win, 10, 20, String(cur), 0xebeeF5);\n"
        "    win_update(win);\n"
        "    delay(30);\n"
        "}\n"
        "print(\"done\", cur);\n",
        "calc.js");
    CHECK(rc == 0, "calc: run ok");
    CHECK(strstr(out_buf, "win 0"), "calc: win_open -> 0");
    /* сценарий кнопок: 0(=7),5(=5),14(= apply: 0+5? op=0 -> cur=5)... */
    CHECK(strstr(out_buf, "done"), "calc: loop finished (window closed)");
    CHECK(os_delay_ms >= 120, "calc: delay() accumulates ms");
    CHECK(os_yields > 0, "calc: interrupt handler yields");
}

/* GC-стресс: тысячи объектов/строк/массивов */
static void test_gc_stress(void) {
    reset_os();
    int rc = mq_run(
        "var total = 0;\n"
        "for (var i = 0; i < 20000; i++) {\n"
        "    var o = {n: i, s: \"str\" + i, arr: [i, i+1, i+2]};\n"
        "    total = (total + o.arr[2]) % 1000000;\n"
        "    if (i % 5000 === 0) gc();\n"
        "}\n"
        "print(\"total\", total);\n"
        "var s = \"\";\n"
        "for (var i = 0; i < 300; i++) s += \"абвгд\";\n"
        "print(s.length);\n",
        "gc.js");
    CHECK(rc == 0, "gc: run ok");
    CHECK(strstr(out_buf, "total ") != NULL, "gc: accumulation printed");
    CHECK(strstr(out_buf, "1500\n"), "gc: string concat + UTF-8 length");
}

/* нехватка памяти — аккуратное исключение, а не крах */
static void test_oom(void) {
    reset_os();
    int rc = mq_run(
        "var a = [];\n"
        "for (;;) { a.push(new Array(1000).fill(1.1)); }\n"
        "print(\"never\");\n",
        "oom.js");
    CHECK(rc != 0, "oom: run fails");
    CHECK(strlen(last_error) > 0, "oom: error message extracted");
    CHECK(strstr(out_buf, "never") == NULL, "oom: unreachable not printed");
}

/* бесконечный цикл без delay: кооперативный yield + принудительный break */
static void test_interrupt(void) {
    reset_os();
    os_break_after = 3;
    int rc = mq_run(
        "var i = 0;\n"
        "while (true) { i++; }\n",
        "spin.js");
    CHECK(rc != 0, "spin: interrupted");
    CHECK(os_yields >= 3, "spin: yields happened");
    CHECK(strstr(last_error, "interrupted") != NULL, "spin: 'interrupted' error");
}

/* ошибки: синтаксис + рантайм */
static void test_errors(void) {
    reset_os();
    int rc = mq_run("var x = ;\n", "syntax.js");
    CHECK(rc != 0, "syntax: run fails");
    CHECK(strlen(last_error) > 0, "syntax: message exists");

    reset_os();
    rc = mq_run("print(nope_var);\n", "ref.js");
    CHECK(rc != 0, "ref: run fails");
    CHECK(strstr(last_error, "nope_var") != NULL, "ref: mentions variable");

    reset_os();
    rc = mq_run("var o = null; print(o.f);\n", "type.js");
    CHECK(rc != 0, "type: run fails");
}

/* пример IMG.JS — работа с картинками (моки) */
static void test_img_demo(void) {
    reset_os();
    int rc = mq_run(
        "var pic = img_load(\"LOGO.PNG\");\n"
        "if (pic < 0) { print(\"no image\"); } else {\n"
        "    print(\"LOGO.PNG: \" + img_w(pic) + \"x\" + img_h(pic));\n"
        "    print(\"pixel(0,0): \" + img_pixel(pic, 0, 0).toString(16));\n"
        "    var win = win_open(\"IMG.JS\", 90, 70, 280, 170);\n"
        "    for (var s = 60; s <= 240 && win_alive(win); s += 30) {\n"
        "        win_clear(win, get_color(24, 28, 36));\n"
        "        win_img(win, pic, 12, 8);\n"
        "        var dh = Math.floor(s * img_h(pic) / img_w(pic));\n"
        "        win_img_scaled(win, pic, 12 + (240 - s) / 2, 96, s, dh);\n"
        "        win_text(win, 12, 148, \"масштаб: \" + s + \"px\", get_color(200, 214, 228));\n"
        "        win_update(win);\n"
        "        delay(90);\n"
        "    }\n"
        "    win_close(win);\n"
        "    img_free(pic);\n"
        "}\n"
        "print(\"готово\");\n",
        "img.js");
    CHECK(rc == 0, "img: run ok");
    CHECK(strstr(out_buf, "LOGO.PNG: 240x100"), "img: dimensions");
    CHECK(strstr(out_buf, "pixel(0,0): 336699"), "img: pixel hex");
    CHECK(strstr(out_buf, "готово"), "img: cyrillic output");
}

/* ramfs: строка + цикл списков */
static void test_ramfs(void) {
    reset_os();
    int rc = mq_run(
        "ramfs_write(\"test.txt\", \"привал от QuickJS\");\n"
        "var data = ramfs_read(\"test.txt\");\n"
        "print(\"read:\", data);\n"
        "print(\"len:\", data.length);\n"
        "var files = ramfs_list();\n"
        "print(\"files:\", files.join(\",\"));\n"
        "print(\"strlen:\", strlen(data));\n",
        "ramfs.js");
    CHECK(rc == 0, "ramfs: run ok");
    CHECK(strstr(out_buf, "read: привал от QuickJS"), "ramfs: roundtrip");
    CHECK(strstr(out_buf, "files: DEMO.JS"), "ramfs: list join");
    CHECK(strstr(out_buf, "strlen: 25"), "ramfs: strlen (utf8 bytes)");
}

/* несколько запусков подряд — каждый раз новый контекст */
static void test_multiple_runs(void) {
    reset_os();
    int ok = 0;
    for (int i = 0; i < 5; i++) {
        char src[64];
        snprintf(src, sizeof(src), "print(\"iter %d\", %d * 2);", i, i);
        if (mq_run(src, "multi.js") == 0) ok++;
    }
    CHECK(ok == 5, "multi: 5 sequential runs ok");
    CHECK(strstr(out_buf, "iter 4 8"), "multi: last output");
}

/* встроенный print/gc/load стандлибы не конфликтуют с нашими именами */
static void test_stdlib_present(void) {
    reset_os();
    int rc = mq_run(
        "print(typeof Object, typeof Array, typeof Math, typeof JSON);\n"
        "print(typeof ArrayBuffer, typeof Uint8Array);\n"
        "var u8 = new Uint8Array(4); u8[0] = 65; u8[1] = 66;\n"
        "print(String.fromCharCode(u8[0], u8[1]));\n"
        "print([3,1,2].sort().join(\"-\"));\n"
        "print(\"ABC\".toLowerCase(), \"\\u0410\\u0411\");\n",
        "stdlib.js");
    CHECK(rc == 0, "stdlib: run ok");
    CHECK(strstr(out_buf, "function function object object"), "stdlib: globals");
    CHECK(strstr(out_buf, "function function") != NULL, "stdlib: typed arrays");
    CHECK(strstr(out_buf, "AB"), "stdlib: Uint8Array");
    CHECK(strstr(out_buf, "1-2-3"), "stdlib: array sort/join");
    CHECK(strstr(out_buf, "abc АБ"), "stdlib: case conv + cyrillic literal");
}

int main(void) {
    printf("=== mqjs host test ===\n");
    test_arith();
    test_calculator();
    test_gc_stress();
    test_oom();
    test_interrupt();
    test_errors();
    test_img_demo();
    test_ramfs();
    test_multiple_runs();
    test_stdlib_present();

    printf("\n=== %d checks, %d failed ===\n", checks_total, tests_failed);
    return tests_failed ? 1 : 0;
}
