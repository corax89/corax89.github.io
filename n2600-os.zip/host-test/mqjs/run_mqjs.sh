#!/bin/sh
# run_mqjs.sh — хост-харнес моста MicroQuickJS (сессия 64).
# Использование: ./run_mqjs.sh [asan]
set -e
cd "$(dirname "$0")"
SRC=${SRC:-../../src}

cp $SRC/mqjs_engine.c $SRC/mqjs.h $SRC/mqjs_priv.h $SRC/mqjs_libm.h $SRC/mqjs_stdlib.h .

gcc -O2 -g -w -o mqjs_host_test mqjs_engine.c mqjs_host_test.c -lm
./mqjs_host_test
