/* wm.h — оконный менеджер: окна, таскбар, меню, курсор, композитинг.
 * Это публичный API для приложений N2600-OS (см. src/apps_*.c и README). */
#ifndef WM_H
#define WM_H

#include "types.h"
#include "kbd.h"

#define WM_MAX_WINDOWS 32

#define TBAR_H   28   /* высота таскбара */
#define TITLE_H  24   /* высота заголовка окна */

struct window;

typedef void (*win_draw_fn)(struct window *);
typedef void (*win_key_fn)(struct window *, const key_event_t *);
typedef void (*win_mouse_fn)(struct window *, int mx, int my, u8 buttons, u8 changed);
typedef void (*win_tick_fn)(struct window *);
typedef void (*win_close_fn)(struct window *);

typedef struct window {
    int x, y, w, h;        /* геометрия вместе с рамкой */
    int minimized;          /* 1 = свёрнуто (не отрисовывается) */
    int maximized;          /* 1 = развёрнуто на весь экран (кроме таскбара) */
    int prev_x, prev_y, prev_w, prev_h;  /* геометрия до сворачивания/разворота */
    u32 serial;             /* порядковый номер создания (стабильный порядок
                             * кнопок на таскбаре — FIX [W1]) */
    char title[40];
    void *data;            /* состояние приложения (malloc/free) */
    win_draw_fn   draw;     /* отрисовка содержимого (клип уже установлен) */
    win_key_fn    on_key;   /* клавиатура (только у окна в фокусе) */
    win_mouse_fn  on_mouse; /* мышь: координаты относительно содержимого */
    win_tick_fn   on_tick;  /* вызывается 2 раза в секунду */
    win_close_fn  on_close; /* освободить data перед закрытием */

    /* ---- многопоточный WM (внутреннее, приложения не используют) ----
     * КАЖДОЕ окно работает в собственном потоке: все колбэки (draw/
     * on_key/on_mouse/on_tick/on_close) выполняются в нём и рисуют в
     * собственный canvas. Зависание одного приложения больше не
     * останавливает систему и остальные окна. */
    int   task;            /* индекс задачи потока окна, -1 = нет */
    u32  *canvas;          /* пиксельный буфер содержимого (cvs_w x cvs_h) */
    int   cvs_w, cvs_h;
    int   fixed_size;      /* 1 = resize/maximize запрещены (canvas рисует
                            * ВНЕШНЯЯ задача — realloc canvas отвалил бы её
                            * указатель; см. c4gfx.c) */
    int   resize_defer;    /* ПЕРФ (wm-внутреннее): кадров до следующей
                            * попытки пересоздания canvas. При интерактивном
                            * resize malloc+заливка+trash каждый кадр
                            * фрагментировали кучу — теперь раз в 3 кадра */
    void  *thr;            /* wm-внутренность: очередь событий, блокировки */

    /* ---- виджеты (сессия 15, wm-внутреннее) ---- */
    void  *widgets;        /* массив wm_widget_t или NULL */
    int   nwidgets;

    /* ---- ПЕРФ/UX: анимация разворачивания окна (wm-внутреннее) ----
     * Пока anim_active==1, геометрия окна интерполируется от стартовой
     * (anim_s*) к конечной (anim_t*) шагами по ~20 мс; wm_frame НЕ
     * пересоздаёт canvas (anim_hold) — финальный размер подгоняется
     * обычным resize-циклом после завершения. */
    int   anim_active;     /* 1 = идёт анимация геометрии */
    int   anim_steps;      /* осталось шагов */
    int   anim_total;      /* всего шагов */
    int   anim_sx, anim_sy, anim_sw, anim_sh;  /* стартовый прямоугольник */
    int   anim_tx, anim_ty, anim_tw, anim_th;  /* конечный прямоугольник */
    u32   anim_next_tick;  /* тик следующего шага (1 тик = 1 мс) */
    int   anim_hold;       /* 1 = resize-цикл wm_frame пропускает окно */
    int   anim_to_min;     /* 1 = анимация СВЁРТЫВАНИЯ в кнопку таскбара:
                            * по завершении окно получает minimized=1
                            * (до этого остаётся видимым и рисуется) */
} window_t;

/* создать окно (добавляется поверх остальных, окно в фокусе) */
window_t *win_create(const char *title, int x, int y, int w, int h,
                     win_draw_fn draw, win_key_fn on_key, win_mouse_fn on_mouse,
                     win_tick_fn on_tick, win_close_fn on_close, void *data);

/* пометить окно к закрытию (безопасно вызывать из любого колбэка) */
void win_close(window_t *w);
void win_set_no_canvas(window_t *w);   /* сессия 12: canvas вне потока (c4gfx) */

/* ==================== окно-сообщение (сессия 22) ====================
 * Маленькое диалоговое окно (до 5 строк текста, кнопка «ОК», закрытие
 * по Esc/Enter/Space). Текст режется по символам UTF-8. */
void wm_msgbox(const char *title, const char *text);

/* Сообщить пользователю о неудаче запуска приложения: kind 0 — нехватка
 * памяти (покажет свободную кучу), 1 — лимит окон, -1 — определить
 * автоматически. Подавляет повторы (кулдаун 10 с), при невозможности
 * показать окно пишет в serial-лог. */
void wm_oom_report(int kind);

/* Число открытых окон (для контроля результата запуска приложения). */
int  wm_window_count(void);

/* запросить перерисовку содержимого окна */
void win_invalidate(window_t *w);

/* НЕМЕДЛЕННАЯ отрисовка canvas окна. Должна вызываться ПОТОКОМ САМОГО
 * окна (из колбэка): под rlock (vs realloc при resize). Нужна, когда
 * приложение хочет показать статус ДО долгой блокирующей работы
 * (напр. сетевой запрос в браузере). */
void win_draw_now(window_t *w);

/* свернуть/восстановить окно */
void win_minimize(window_t *w);
void win_restore(window_t *w);
int  win_is_minimized(window_t *w);

/* развернуть на весь экран (заголовок и таскбар сохраняются) /
 * вернуть прежний размер. Двойной клик по заголовку — тоже переключает. */
void win_maximize(window_t *w);
void win_unmaximize(window_t *w);
void win_toggle_maximize(window_t *w);
int  win_is_maximized(window_t *w);

int  win_content_w(window_t *w);
int  win_content_h(window_t *w);

void wm_init(void);
void wm_key(const key_event_t *ev);
void wm_mouse_poll(void);   /* обработать накопившиеся события мыши */
void wm_halfsec(void);      /* тик 2 Гц (мигание курсора, on_tick, часы) */
void wm_frame(void);        /* композитинг и вывод помеченных областей */

int  wm_blink(void);        /* 0/1 для мигающего курсора */
int  wm_window_count(void);          /* общее число (включая свёрнутые) */
int  wm_window_visible_count(void);  /* видимые (не свёрнутые) */
const char *wm_window_title(int i);
int  wm_window_minimized(int i);
int  wm_window_focused(int i);
window_t *wm_window_at(int i);

/* ---- многопоточный WM: служебное (для диспетчера задач и ядра) ---- */
int  wm_task_of(window_t *w);          /* индекс задачи потока окна или -1 */
window_t *wm_find_by_task(int task_idx); /* окно по задаче или NULL */
void wm_request_kill(int task_idx);   /* убить поток окна и окно (мягко:
                                         просим kmain — обработается в
                                         ближайшем wm_frame) */
void wm_pump_kills(void);             /* обработать отложенные kill (из
                                         главного цикла/kmain) */
int  wm_test_glock_spin(void);        /* ТЕСТ живучести (команда spinlock):
                                         задача берёт wm_glock и зависает;
                                         система должна ожить через ~20 с */
void wm_test_kmain_fault(void);       /* ТЕСТ (команда kmainfault, сессия 81):
                                         следующий кадр композитора падает
                                         с #0 под glock — KMAIN-RECOVER
                                         обязан вернуть цикл без паники */
void wm_glock_panic_release(void);    /* [KMAIN-RECOVER] внешний отпуск glock
                                         (из exc_panic, BSP) */

/* ===================== контекстное меню (сессия 13) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент для ЛЮБЫХ приложений. Открытие — из on_mouse
 * потока окна (обычно по правой кнопке):
 *     wm_menu_open(w, mx, my, items, n, cb, uctx);
 * mx,my — координаты ОТНОСИТЕЛЬНО содержимого окна w. Выбор пункта
 * доставляется потоку окна-владельца (WEV_MENU): колбэк cb(id, uctx)
 * исполняется в ЕГО потоке — данные приложения защищены от гонок.
 * Закрытие: выбор пункта, Esc, клик мимо меню. item.label == NULL —
 * разделитель. disabled=1 — пункт серый и не выбирается. */
typedef struct {
    const char *label;        /* NULL = разделитель */
    int  id;                  /* идентификатор в колбэке */
    u8   disabled;            /* 1 = недоступен */
} wm_menu_item_t;
typedef void (*wm_menu_fn)(int id, void *uctx);
void wm_menu_open(window_t *owner, int content_x, int content_y,
                  const wm_menu_item_t *items, int n,
                  wm_menu_fn cb, void *uctx);
void wm_menu_close(void);
int  wm_menu_active(void);

/* ===================== checkboxes (session 14) =====================
 * REUSABLE component for any applications (request: "add universal
 * checkboxes to the system so they can be reused"). The state is stored
 * by the APPLICATION — the component only draws and hit-tests:
 *
 *   draw:  wm_checkbox_draw(x, y, "Full formatting", d->full, color);
 *   click: if ((changed & MSB_LEFT) && wm_checkbox_hit(mx, my, x, y, label))
 *              { d->full = !d->full; win_invalidate(w); }
 *
 * A mutually exclusive pair ("radio") is assembled from two checkboxes:
 * when one is clicked, BOTH are redrawn — the choice is visible. */
void wm_checkbox_draw(int x, int y, const char *label, int checked, u32 text_color);
int  wm_checkbox_hit(int mx, int my, int x, int y, const char *label);

/* ===================== вписанный текст и кнопки (сессия 20) =====================
 * ГАРАНТИЯ «ТЕКСТ ВНУТРИ»: ширина считается по ВИДИМЫМ СИМВОЛАМ
 * (fb_text_w, UTF-8), а не по байтам strlen — кириллица больше не
 * раздувает расчётную ширину вдвое (раньше «Новая»/«Сохранить»
 * уезжали за пределы кнопок). Не помещающийся текст ОБРЕЗАЕТСЯ по
 * символам (символы не рвутся посередине) с «..» в конце.
 *
 *   draw:  wm_button_draw(x, y, w, h, "Новая", bg, fg, border);
 *   hit:   if ((changed & MSB_LEFT) && wm_button_hit(mx,my, x,y,w,h)) ...
 */
int  wm_text_fit(int x, int y, const char *s, int max_w, u32 color,
                 int center);   /* center: центрировать в [x, x+max_w];
                                 * возвращает фактическую ширину в px */
void wm_button_draw(int x, int y, int w, int h, const char *label,
                    u32 bg, u32 fg, u32 border);
int  wm_button_hit(int mx, int my, int x, int y, int w, int h);

/* ===================== виджеты (сессия 15) =====================
 * ЧЕКБОКСЫ И РАДИОБОКСЫ, ПОЛУЧАЮЩИЕ СОБЫТИЯ МЫШИ ОТ WM АВТОМАТИЧЕСКИ.
 * Запрос пользователя: «чекбоксы/радиобоксы должны получать события от
 * нажатий мыши». Приложение один раз объявляет массив виджетов:
 *
 *   static wm_widget_t ws[] = {
 *     { WM_WIDGET_CHECK,  20, 60, "Считать контрольные суммы", &chk },
 *     { WM_WIDGET_RADIO,  20, 84, "Быстрое (оглавление)",     &mode, 0 },
 *     { WM_WIDGET_RADIO,  20,106, "Полное (очистка)",         &mode, 1 },
 *   };
 *   win_widgets_set(w, ws, 3);            // при создании
 *   ...  wm_widgets_draw(w);              // в draw
 *
 * Дальше WM сам: клик ЛЕВОЙ кнопкой по виджету меняет *value
 * (чекбокс — 0/1; радиобокс — radio_value в общую переменную группы),
 * вызывает on_change(idx) В ПОТОКЕ ОКНА и перерисовывает окно.
 * Событие мыши, съеденное виджетом, в on_mouse окна НЕ попадает.
 * Координаты — относительно СОДЕРЖИМОГО окна. value == NULL или
 * enabled == 0 — виджет неактивен (рисуется серым, клики игнорируются).*/
#define WM_WIDGET_CHECK  1
#define WM_WIDGET_RADIO  2

typedef void (*wm_widget_fn)(window_t *w, int idx, void *uctx);

typedef struct {
    u8   type;               /* WM_WIDGET_CHECK / WM_WIDGET_RADIO */
    u8   enabled;            /* 0 = серый, клики игнорируются */
    u8   hidden;             /* 1 = не рисуется и не кликается
                             * (диалог скрыт — состояние живёт) */
    i16  x, y;               /* левый верхний угол (коорд. содержимого) */
    char label[56];          /* подпись (UTF-8) */
    int *value;              /* CHECK: 0/1; RADIO: значение группы */
    int  radio_value;        /* RADIO: что записать в *value при выборе */
    wm_widget_fn on_change;  /* опционально; вызывается в потоке окна */
    void *uctx;              /* пользовательский контекст для on_change */
} wm_widget_t;

void win_widgets_set(window_t *w, wm_widget_t *widgets, int count);
void win_widgets_clear(window_t *w);
void wm_widgets_draw(window_t *w);
/* 1 = клик съеден виджетом; из приложений не вызывается */
int  wm_widgets_dispatch(window_t *w, int mx, int my, u8 btn, u8 changed);

/* ===================== полоса прокрутки (сессия 17) =====================
 * ПЕРЕИСПОЛЬЗУЕМЫЙ компонент для ЛЮБЫХ приложений (запрос: «полоса
 * прокрутки переиспользуется и её цвет регулируется темой»). Состояние
 * скролла живёт у ПРИЛОЖЕНИЯ (pos: первая видимая строка), компонент
 * рисует полосу из ТЕМЫ (желоб — win_bg_alt, ползунок — accent, при
 * перетаскивании ярче) и обрабатывает мышь:
 *
 *   draw:  wm_scrollbar_draw(&d->sb, x, y, w, h, pos, max, vis);
 *   mouse: int np = wm_scrollbar_mouse(&d->sb, mx, my, buttons, changed);
 *          if (np >= 0) { d->scroll = np; win_invalidate(w); }
 *
 * semantика pos/max/vis одинакова во всех приложениях ОС: pos — номер
 * первой видимой строки, max = всего_строк - vis. Клик по желобу выше/
 * ниже ползунка — страница вверх/вниз, drag ползунка — пропорционально.
 * Реализация — src/wm_scrollbar.c (отдельный файл: компилируется и в
 * хост-тестах editor_test). */
typedef struct {
    /* геометрия последней отрисовки (для hit-теста при drag) */
    int x, y, w, h;
    int thumb_y, thumb_h;    /* вычисляется в wm_scrollbar_draw */
    int pos, max, vis;       /* текущие значения */
    int dragging;            /* 1 = тащим ползунок */
    int drag_off;            /* смещение курсора от верха ползунка */
} wm_scrollbar_t;

void wm_scrollbar_draw(wm_scrollbar_t *sb, int x, int y, int w, int h,
                       int pos, int max, int vis);
/* возвращает НОВОЕ pos (>= 0), если оно изменилось, иначе -1 */
int  wm_scrollbar_mouse(wm_scrollbar_t *sb, int mx, int my,
                        u8 buttons, u8 changed);

/* ГОРИЗОНТАЛЬНАЯ полоса (сессия 19): те же желоб/ползунок/тема, оси
 * поменяны (позиция считается по X, «страница» — влево/вправо).
 * pos/max/vis — в колонках/символах. Для editor.c — прокрутка по
 * coloff (байты). */
void wm_scrollbar_hdraw(wm_scrollbar_t *sb, int x, int y, int w, int h,
                        int pos, int max, int vis);
int  wm_scrollbar_hmouse(wm_scrollbar_t *sb, int mx, int my,
                         u8 buttons, u8 changed);

/* ===================== тема оформления (сессия 15) =====================
 * Глобальные цвета ОКОН, ТЕКСТА и ЗАГОЛОВКОВ. Запрос пользователя:
 * «вкладка с темой, где можно настроить цвет окон, текста и заголовков
 * (должно распространяться на все приложения)». Все приложения рисуют
 * фон/текст через wm_theme_*() — смена темы применяется ко всем окнам
 * немедленно. Сохраняется в THEME.CFG на RAM disk (автозагрузка).
 *
 * Три БАЗОВЫХ цвета (настраиваются): win_bg / text / title.
 * Производные вычисляются смешением (dim-текст, неактивный заголовок,
 * акцент-рамка, фон выделения) — тема остаётся контрастной при любом
 * выборе пользователя. */
u32 wm_theme_win_bg(void);        /* фон содержимого окон */
u32 wm_theme_win_bg_alt(void);    /* фон шапок/подвалов ВНУТРИ окна */
u32 wm_theme_text(void);          /* основной текст */
u32 wm_theme_text_dim(void);      /* приглушённый текст (подписи) */
u32 wm_theme_text_info(void);     /* акцентный текст (значения) */
u32 wm_theme_title(void);         /* заголовок активного окна */
u32 wm_theme_title_unfoc(void);   /* заголовок неактивного окна */
u32 wm_theme_title_text(void);    /* текст заголовка */
u32 wm_theme_accent(void);        /* акцент: галочки, вкладки, ручка resize */
u32 wm_theme_border(void);        /* рамка АКТИВНОГО окна (отдельный цвет) */
u32 wm_theme_sel_bg(void);        /* фон выделенных строк/подсветки */
u32 wm_theme_get_accent(void);    /* текущий акцент (галочки, вкладки, каретка) */
u32 wm_theme_get_dim(void);       /* текущий приглушённый текст */
void wm_theme_set_accent(u32 c);  /* задать акцент вручную (палитра Настроек),
                                   * сохраняется в THEME.CFG (accent=) */
void wm_theme_set_dim(u32 c);     /* задать приглушённый текст вручную (dim=);
                                   * wm_theme_reset() возвращает авто-значения */

/* применить новую тему + сохранить THEME.CFG + перерисовать все окна */
void wm_theme_set(u32 win_bg, u32 text, u32 title);
void wm_theme_reset(void);        /* вернуть стандартную тёмную тему */
void wm_theme_get_rgb(u32 *win_bg, u32 *text, u32 *title);  /* ARGB */
int  wm_theme_load(void);         /* THEME.CFG при загрузке (wm_init) */
void wm_invalidate_all(void);     /* перерисовать все окна (смена темы) */

/* ================= настройки интерфейса (WM.CFG на RAM disk) =================
 * Два переключателя из Настроек → [4] Система:
 *   - «рисовать содержимое окна при перетаскивании»: 1 = канвас окна
 *     блитится при каждом шаге перетаскивания (как раньше); 0 = БЫСТРЫЙ
 *     режим для медленных CPU — тело окна во время перетаскивания
 *     заливается однотонным фоном, содержимое возвращается при
 *     отпускании кнопки;
 *   - «анимации»: 1 = плавное разворачивание меню Пуск и окон
 *     (maximize/unmaximize, 3 шага по ~20 мс); 0 = мгновенно.
 * Значения сохраняются в WM.CFG и загружаются в wm_init(). */
int  wm_opt_drag_content(void);          /* 1 = рисовать содержимое при drag */
void wm_opt_set_drag_content(int on);
int  wm_opt_animations(void);            /* 1 = анимации меню/разворачивания */
void wm_opt_set_animations(int on);

#endif /* WM_H */
