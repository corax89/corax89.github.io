/* net.c — минимальный TCP/IP стек для N2600-OS.
 *
 * Реализация: Ethernet + ARP + IPv4 + ICMP.
 *
 * Драйвер NIC абстрагирован: сетевой цикл читает пакеты из e1000_recv()
 * и передаёт сюда в net_poll(). Отправка идёт через e1000_send().
 *
 * Кэш ARP хранит 16 записей (IP->MAC). При отсутствии записи в кэше
 * отправляется ARP-запрос и пакет ставится на паузу (для простоты — просто
 * теряется, в однозадачной системе повторяется вызывающим).
 *
 * Чек-суммы IP/ICMP — простые 16-битные над IP-заголовком/ICMP.
 *
 * Сессия 12 (стабильность IP при DHCP): у стека появился «транзакционный»
 * режим DHCP (net_dhcp_txn_begin/end): на время DISCOVER/REQUEST исходящий
 * IP-адрес считается 0.0.0.0 (как требует RFC 2131 фаза INIT), но
 * g_net.ip — видимый приложениям/Настройкам адрес — НЕ обнуляется.
 * Раньше каждые ~5 с повтор DHCP стирал IP: «адрес теряется каждые
 * несколько секунд». Теперь адрес остаётся до успешной замены/сброса.
 */
#include "net.h"
#include "sync.h"
#include "e1000.h"
#include "ne2000.h"
#include "virtio_net.h"
#include "atl1c.h"
#include "ath9k_wifi.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);

/* ---------- Реестр NIC-адаптеров (сессия 11) ----------
 * Раньше активный NIC выбирался ЖЁСТКО: e1000 → virtio → ne2000 → atl1c,
 * а WiFi вообще не участвовал. На X101CH это давало «приоритет у lan,
 * хотя он никуда не подключен»: стек сидел на atl1c без линка, а WiFi
 * не мог получить IP. Теперь все NIC регистрируются в реестре, а выбор
 * идёт по СОСТОЯНИЮ ЛИНКА: ethernet с линком > WiFi (ассоциирован) >
 * первый найденный. Ручной выбор (Настройки/терминал) перекрывает авто. */
typedef int (*nic_send_fn)(const void *buf, u32 len);
typedef u32 (*nic_recv_fn)(void *buf, u32 max);
typedef int (*nic_link_fn)(void);
typedef void (*nic_mac_fn)(u8 *);

/* get_mac у драйверов возвращает разное (int/void) — выравниваем
 * сигнатуры обёртками, чтобы реестр был однородным. */
static void nm_e1000_mac(u8 *m)  { e1000_get_mac(m); }
static void nm_virtio_mac(u8 *m) { virtio_net_get_mac(m); }
static void nm_ne2000_mac(u8 *m) { ne2000_get_mac(m); }
static void nm_atl1c_mac(u8 *m)  { atl1c_get_mac(m); }
static void nm_wifi_mac(u8 *m)   { wifi_net_get_mac(m); }

typedef struct {
    const char *name;         /* имя в Настройках/терминале */
    nic_send_fn send;
    nic_recv_fn recv;
    nic_link_fn link;         /* NULL = линк всегда есть (эмулированные) */
    nic_mac_fn  get_mac;
    int wired;                /* 1 = ethernet: приоритет при равном линке */
} net_nic_def_t;

#define NET_MAX_NICS 5
static const net_nic_def_t g_nic_defs[NET_MAX_NICS] = {
    { "e1000",  e1000_send,     e1000_recv,     e1000_link_up,  nm_e1000_mac,  1 },
    { "virtio", virtio_net_send,virtio_net_recv,NULL,           nm_virtio_mac, 1 },
    { "ne2000", ne2000_send,    ne2000_recv,    NULL,           nm_ne2000_mac, 1 },
    { "atl1c",  atl1c_send,     atl1c_recv,     atl1c_link_up,  nm_atl1c_mac,  1 },
    { "wifi",   wifi_net_send,  wifi_net_recv,  wifi_net_link,  nm_wifi_mac,   0 },
};

static int g_nic_present[NET_MAX_NICS];    /* найден при init */
static int g_nic_count = 0;
static int g_active = -1;                  /* индекс активного адаптера */
static nic_send_fn g_nic_send = NULL;
static nic_recv_fn g_nic_recv = NULL;

/* режим приоритета: 0 = авто (по линку), 1..N = ручной (индекс+1) */
static int g_adapter_mode = 0;
static volatile int g_adapter_lock = 0;
/* callback смены адаптера: ядро перезапускает DHCP (netmon) */
static void (*g_adapter_change_cb)(void) = NULL;

/* ---------- состояние стека ---------- */
typedef struct {
    u8  mac[6];        /* наш MAC */
    u32 ip;            /* наш IP (host order, 0=не настроен) */
    u32 netmask;       /* маска подсети */
    u32 gateway;       /* шлюз по умолчанию */
    /* Кэш ARP */
    u32 arp_cache_ip[16];
    u8  arp_cache_mac[16][6];
    /* Статистика */
    u32 tx_packets;
    u32 rx_packets;
    u32 tx_bytes;    /* байт отправлено (кадры целиком, для графиков) */
    u32 rx_bytes;    /* байт принято (кадры целиком, для графиков) */
    u32 arp_rx;
    u32 icmp_rx;
    /* Callback для ICMP-ответов */
    net_icmp_cb_t icmp_cb;
    /* Сессия 12: транзакция DHCP идёт — исходящий IP = 0.0.0.0 */
    int dhcp_txn;
} net_state_t;

static net_state_t g_net;

/* отложенный пакет (объявлен ниже, в секции FIX сессии 7) */
static u32 g_pending_len;
static u32 g_pending_dst_ip;

/* ---------- 16-битная Internet checksum (RFC 1071) ---------- */
static u16 inet_checksum(const void *data, u32 len, u32 initial)
{
    u32 sum = initial;
    const u8 *p = (const u8 *)data;
    for (u32 i = 0; i + 1 < len; i += 2) {
        sum += ((u32)p[i] << 8) | p[i+1];
    }
    if (len & 1) {
        sum += (u32)p[len - 1] << 8;
    }
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)(~sum & 0xFFFF);
}

static u16 inet_checksum_pseudo(u32 src_ip, u32 dst_ip, u8 proto,
                                  const void *data, u32 len)
{
    /* Псевдо-заголовок для UDP/TCP (12 байт): src_ip, dst_ip, zero, proto, len */
    u32 sum = 0;
    sum += (src_ip >> 16) & 0xFFFF;
    sum += src_ip & 0xFFFF;
    sum += (dst_ip >> 16) & 0xFFFF;
    sum += dst_ip & 0xFFFF;
    sum += (u32)proto;
    sum += len;
    return inet_checksum(data, len, sum);
}

/* ---------- Реестр адаптеров: публичный API ---------- */

int net_adapter_count(void) { return g_nic_count; }

int net_adapter_present(int i)
{
    return (i >= 0 && i < NET_MAX_NICS) ? g_nic_present[i] : 0;
}

const char *net_adapter_name(int i)
{
    if (i < 0 || i >= NET_MAX_NICS) return "?";
    if (i == NET_MAX_NICS - 1 && g_nic_present[i]) return "wifi";
    return g_nic_defs[i].name;
}

/* Состояние линка адаптера (для таблицы в Настройках). */
int net_adapter_link(int i)
{
    if (i < 0 || i >= NET_MAX_NICS || !g_nic_present[i]) return 0;
    return g_nic_defs[i].link ? g_nic_defs[i].link() : 1;
}

int net_adapter_active(void) { return g_active; }

/* Режим приоритета: 0 = авто, 1..N = ручной (индекс+1). */
int net_adapter_mode(void) { return g_adapter_mode; }
int net_adapter_manual_idx(void) { return g_adapter_mode - 1; }

void net_adapter_set_change_cb(void (*cb)(void)) { g_adapter_change_cb = cb; }

/* Установить режим приоритета ДО net_init (из SETTINGS.CFG при загрузке):
 * только сохраняет режим — применение произойдёт в net_init. */
void net_settings_set_adapter(int mode)
{
    if (mode >= 0 && mode <= NET_MAX_NICS)
        g_adapter_mode = mode;
}

/* Поиск адаптера по имени ("e1000".."atl1c", "wifi") — индекс или -1. */
int net_adapter_find(const char *name)
{
    if (!name) return -1;
    for (int i = 0; i < NET_MAX_NICS; i++)
        if (strcmp(g_nic_defs[i].name, name) == 0) return i;
    return -1;
}

/* Выбор лучшего адаптера (авто-политика):
 * 1) ethernet с линком (в порядке регистрации);
 * 2) WiFi с линком (ассоциирован);
 * 3) любой найденный (без линка — ждём в netmon). */
static int net_adapter_pick(void)
{
    int best = -1;
    for (int i = 0; i < NET_MAX_NICS; i++) {
        if (!g_nic_present[i] || !g_nic_defs[i].wired) continue;
        if (!g_nic_defs[i].link || g_nic_defs[i].link())
            return i;
    }
    for (int i = 0; i < NET_MAX_NICS; i++) {
        if (!g_nic_present[i] || g_nic_defs[i].wired) continue;
        if (g_nic_defs[i].link && g_nic_defs[i].link())
            best = i;
    }
    if (best >= 0) return best;
    for (int i = 0; i < NET_MAX_NICS; i++)
        if (g_nic_present[i]) return i;
    return -1;
}

/* Очистить ARP-кэш и отложенный пакет (при смене адаптера старые записи
 * чужого сегмента недействительны). */
static void arp_cache_clear(void)
{
    memset(g_net.arp_cache_ip, 0, sizeof(g_net.arp_cache_ip));
    g_pending_len = 0;
    g_pending_dst_ip = 0;
}

/* Применить адаптер idx как активный (MAC, send/recv, чистка кэша). */
static void net_adapter_apply(int idx, const char *why)
{
    if (idx < 0 || idx >= NET_MAX_NICS || !g_nic_present[idx]) return;
    s_lock(&g_adapter_lock);
    g_active = idx;
    g_nic_send = g_nic_defs[idx].send;
    g_nic_recv = g_nic_defs[idx].recv;
    g_nic_defs[idx].get_mac(g_net.mac);
    arp_cache_clear();
    s_unlock(&g_adapter_lock);
    {
        char b[80];
        snprintf(b, sizeof(b), "[net] активный адаптер: %s (%s)",
                 g_nic_defs[idx].name, why);
        serial_puts(b);
        serial_puts("\n");
    }
}

/* Установить режим приоритета: mode=0 (авто) или 1..N (ручной, индекс+1).
 * Возвращает 1, если активный адаптер ИЗМЕНИЛСЯ (надо перезапустить DHCP). */
int net_adapter_set_mode(int mode)
{
    if (mode < 0 || mode > NET_MAX_NICS) return 0;
    if (mode > 0 && !g_nic_present[mode - 1]) return 0;
    g_adapter_mode = mode;
    int old = g_active;
    if (mode == 0)
        net_adapter_apply(net_adapter_pick(), "авто-приоритет");
    else
        net_adapter_apply(mode - 1, "выбор пользователя");
    if (g_active != old) {
        if (g_adapter_change_cb) g_adapter_change_cb();
        return 1;
    }
    return 0;
}

/* Периодическая проверка (netmon): в авто-режиме переключиться, если
 * текущий адаптер потерял линк, а другой — поднял. Возвращает 1 при
 * переключении. Избавляет от «DHCP ушёл в мёртвый lan». */
int net_adapter_check(void)
{
    if (g_adapter_mode != 0 || g_active < 0) return 0;
    if (net_adapter_link(g_active)) return 0;    /* работает — не трогаем */
    int best = net_adapter_pick();
    if (best >= 0 && best != g_active) {
        net_adapter_apply(best, "потеря линка, авто");
        if (g_adapter_change_cb) g_adapter_change_cb();
        return 1;
    }
    return 0;
}

/* СЕССИЯ 15: пересканировать реестр адаптеров. WiFi инициализируется
 * ФОНОВОЙ задачей ПОСЛЕ старта ОС (нетбук больше не ждёт адаптер при
 * загрузке) — в момент net_init его ещё не было. Когда адаптер стал
 * ready, ядро вызывает эту функцию: wifi появляется в реестре, и
 * netmon сам переключится на него по линку (net_adapter_check).
 * Ethernet-флаги после загрузки не меняются — добавляем только wifi. */
int net_adapter_rescan(void)
{
    if (wifi_present() && wifi_ready() && !g_nic_present[4]) {
        g_nic_present[4] = 1;
        g_nic_count++;
        serial_puts("[net] адаптер wifi зарегистрирован (фон. init завершён)\n");
    }
    return g_nic_count;
}

/* ---------- Инициализация ---------- */
void net_init(void)
{
    memset(&g_net, 0, sizeof(g_net));
    g_net.netmask = 0xFFFFFF00u;   /* 255.255.255.0 по умолчанию */
    g_net.gateway = 0;
    g_net.ip = 0;

    /* Регистрируем ВСЕ найденные NIC-драйверы (сессия 11: WiFi тоже) */
    g_nic_count = 0;
    memset(g_nic_present, 0, sizeof(g_nic_present));
    if (e1000_present())     g_nic_present[0] = 1;
    if (virtio_net_present())g_nic_present[1] = 1;
    if (ne2000_present())    g_nic_present[2] = 1;
    if (atl1c_present())     g_nic_present[3] = 1;
    if (wifi_present() && wifi_ready()) g_nic_present[4] = 1;
    for (int i = 0; i < NET_MAX_NICS; i++) g_nic_count += g_nic_present[i];

    g_nic_send = NULL;
    g_nic_recv = NULL;
    g_active = -1;

    if (g_nic_count == 0) {
        serial_puts("[net] init done, NIC не найден\n");
        return;
    }

    /* Режим из настроек (SETTINGS.CFG): "adapter=auto" или "adapter=<имя>";
     * загрузчик вызвал net_settings_load() до net_init. При отсутствии — авто. */
    if (g_adapter_mode > 0 && !g_nic_present[g_adapter_mode - 1])
        g_adapter_mode = 0;    /* настроенного адаптера нет — авто */

    if (g_adapter_mode == 0)
        net_adapter_apply(net_adapter_pick(), "авто-приоритет");
    else
        net_adapter_apply(g_adapter_mode - 1, "настройки");

    serial_puts("[net] init done, адаптеров: ");
    {
        char b[16];
        snprintf(b, sizeof(b), "%d, mac=", g_nic_count);
        serial_puts(b);
        const char *h = "0123456789abcdef";
        char buf[20];
        int p = 0;
        for (int i = 0; i < 6; i++) {
            buf[p++] = h[(g_net.mac[i]>>4)&0xF];
            buf[p++] = h[g_net.mac[i]&0xF];
            if (i < 5) buf[p++] = ':';
        }
        buf[p] = 0;
        serial_puts(buf);
        serial_puts("\n");
    }
}

void net_set_ip(u32 ip) { g_net.ip = ip; }
u32  net_get_ip(void)    { return g_net.ip; }

/* Сессия 12: транзакция DHCP — исходящий src-IP 0.0.0.0 без стирания
 * настроенного адреса (см. комментарий в шапке файла). */
void net_dhcp_txn_begin(void) { g_net.dhcp_txn = 1; }
void net_dhcp_txn_end(void)   { g_net.dhcp_txn = 0; }

int net_nic_present(void)
{
    return (g_active >= 0);
}

const char *net_nic_name(void)
{
    if (g_active >= 0) return g_nic_defs[g_active].name;
    if (g_nic_count > 0) return "нет активного";
    return "no NIC";
}
void net_set_gateway(u32 gw) { g_net.gateway = gw; }
u32  net_get_gateway(void)  { return g_net.gateway; }
void net_set_netmask(u32 m) { g_net.netmask = m; }
u32  net_get_netmask(void) { return g_net.netmask; }

/* ---------- Loopback (127.0.0.1 / свой IP) ---------- */
int net_is_loopback(u32 ip)
{
    if ((ip >> 24) == 127) return 1;          /* 127.0.0.0/8 */
    if (g_net.ip != 0 && ip == g_net.ip) return 1;  /* на себя */
    return 0;
}

/* СЕССИЯ 63: loopback-хост по ИМЕНИ — "localhost" (или "localhost.")
 * и IP-литерал 127.x.x.x. Приложения (браузер, curl, ping, imgsvc,
 * nettrace) обязаны пускать такие адреса БЕЗ NIC и без настроенного IP:
 * TCP/ICMP для них замыкается внутри стека (net_is_loopback), провода
 * и ARP не требуется — иначе «Сеть не настроена» на 127.0.0.1. */
int net_host_is_loopback(const char *host)
{
    if (!host || !host[0]) return 0;
    if (!strcmp(host, "localhost") || !strcmp(host, "localhost."))
        return 1;
    u32 ip;
    if (net_aton(host, &ip) && (ip >> 24) == 127) return 1;
    return 0;
}
void net_get_mac(u8 out_mac[6]) { memcpy(out_mac, g_net.mac, 6); }
void net_set_icmp_callback(net_icmp_cb_t cb) { g_net.icmp_cb = cb; }
u32  net_tx_packets(void) { return g_net.tx_packets; }
u32  net_rx_packets(void) { return g_net.rx_packets; }
u32  net_tx_bytes(void)  { return g_net.tx_bytes; }
u32  net_rx_bytes(void)  { return g_net.rx_bytes; }

/* ---------- ARP кэш дамп ---------- */
int net_arp_dump(net_arp_entry_t *out, int max_entries)
{
    int count = 0;
    for (int i = 0; i < NET_ARP_CACHE_SIZE && count < max_entries; i++) {
        if (g_net.arp_cache_ip[i] != 0) {
            out[count].ip = g_net.arp_cache_ip[i];
            memcpy(out[count].mac, g_net.arp_cache_mac[i], 6);
            count++;
        }
    }
    return count;
}

/* ---------- Парсинг IP-адреса ---------- */
int net_aton(const char *str, u32 *out_ip)
{
    u32 a, b, c, d;
    int n = 0;
    /* Ручной sscanf: %d.%d.%d.%d */
    const char *p = str;
    u32 vals[4];
    int idx = 0;
    u32 cur = 0;
    int any = 0;
    while (*p && idx < 4) {
        if (*p >= '0' && *p <= '9') {
            cur = cur * 10 + (u32)(*p - '0');
            any = 1;
            if (cur > 255) return 0;
        } else if (*p == '.') {
            if (!any) return 0;
            vals[idx++] = cur;
            cur = 0;
            any = 0;
        } else {
            return 0;
        }
        p++;
    }
    if (!any || idx != 3) return 0;
    vals[idx++] = cur;
    a = vals[0]; b = vals[1]; c = vals[2]; d = vals[3];
    (void)a; (void)b; (void)c; (void)d;
    (void)n;
    *out_ip = (vals[0] << 24) | (vals[1] << 16) | (vals[2] << 8) | vals[3];
    return 1;
}

int net_ntoa(u32 ip, char *out, u32 out_max)
{
    if (out_max < 16) return 0;
    u8 a = (u8)((ip >> 24) & 0xFF);
    u8 b = (u8)((ip >> 16) & 0xFF);
    u8 c = (u8)((ip >> 8) & 0xFF);
    u8 d = (u8)(ip & 0xFF);
    /* Ручное форматирование */
    int p = 0;
    u8 vals[4] = { a, b, c, d };
    for (int i = 0; i < 4; i++) {
        u8 v = vals[i];
        char tmp[4];
        int L = 0;
        if (v == 0) { tmp[L++] = '0'; }
        else {
            while (v > 0 && L < 3) { tmp[L++] = (char)('0' + v % 10); v /= 10; }
        }
        while (L > 0) out[p++] = tmp[--L];
        if (i < 3) out[p++] = '.';
    }
    out[p] = 0;
    return p;
}

/* ---------- Отложенный пакет (FIX сессия 7) ----------
 * Первый пакет к НОВОМУ адресату отправляется ДО ARP-разрешения и
 * раньше МОЛЧА ТЕРЯЛСЯ (в net_send_ip: нет записи → только ARP-запрос).
 * Это роняло SYN-ACK сервера: клиент повторял SYN, создавался ВТОРОЙ
 * сокет — и соединение зависало на чужом seq. Теперь пакет (один слот)
 * сохраняется и уходит сразу после ARP-ответа (flush в arp_cache_add). */
static u8  g_pending_pkt[NET_PKT_MAX];
/* g_pending_len / g_pending_dst_ip объявлены выше (используются
 * arp_cache_clear в реестре адаптеров) */
static volatile int pending_lock = 0;
static int send_eth(const u8 dst[6], u16 ethertype, const void *payload, u32 len);

/* ---------- ARP кэш ---------- */
static int arp_cache_lookup(u32 ip, u8 out_mac[6])
{
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip && ip != 0) {
            memcpy(out_mac, g_net.arp_cache_mac[i], 6);
            return 1;
        }
    }
    return 0;
}

static void arp_cache_add(u32 ip, const u8 mac[6])
{
    if (ip == 0) return;
    /* Ищем существующую запись */
    int slot = -1;
    for (int i = 0; i < 16; i++) {
        if (g_net.arp_cache_ip[i] == ip) { slot = i; break; }
    }
    if (slot < 0) {
        /* Ищем свободный слот */
        for (int i = 0; i < 16; i++) {
            if (g_net.arp_cache_ip[i] == 0) { slot = i; break; }
        }
    }
    if (slot < 0) {
        /* Заменяем первую запись (FIFO-замена без учёта времени — простота) */
        slot = 0;
    }
    g_net.arp_cache_ip[slot] = ip;
    memcpy(g_net.arp_cache_mac[slot], mac, 6);

    /* FIX сессия 7: отложенный пакет, ждавший ЭТОГО адресата, — в сеть */
    if (g_pending_len && g_pending_dst_ip == ip) {
        u8  pcopy[NET_PKT_MAX];
        u32 plen;
        s_lock(&pending_lock);
        plen = g_pending_len;
        memcpy(pcopy, g_pending_pkt, plen);
        g_pending_len = 0;
        g_pending_dst_ip = 0;
        s_unlock(&pending_lock);
        if (plen)
            send_eth(mac, ETHERTYPE_IPV4, pcopy, plen);
    }
}

/* ---------- Отправка Ethernet-кадра ---------- */
/* FIX (многозадачность): frame — СТАТИЧЕСКИЙ буфер, общий для всех задач
 * (раньше все отправки шли из kmain — теперь и из потоков приложений).
 * То же для pkt в net_send_ip. Две отдельные блокировки (без вложенного
 * ожидания друг на друга: порядок всегда send_ip -> send_eth). */
static volatile int net_eth_lock = 0;
static volatile int net_ip_lock = 0;

static int send_eth(const u8 dst_mac[6], u16 ethertype, const void *payload, u32 payload_len)
{
    static u8 frame[NET_PKT_MAX];
    int rc;
    if (payload_len + 14 > NET_PKT_MAX) return -1;
    s_lock(&net_eth_lock);
    memcpy(frame, dst_mac, 6);
    memcpy(frame + 6, g_net.mac, 6);
    frame[12] = (u8)(ethertype >> 8);
    frame[13] = (u8)(ethertype & 0xFF);
    memcpy(frame + 14, payload, payload_len);
    /* FIX (сессия 57): ДОБИТЬ кадр до минимума Ethernet 60 байт.
     * Наши SYN = 58 байт (14+20+24 с MSS), ACK = 54 байт. Кадры короче
     * 60 байт настоящие мосты/NIC (в т.ч. часть точек доступа и USB-
     * свистков) молча отбрасывают — хендшейк не завершается, а стек
     * видит «сервер молчит». ARP (42 байта) выживал только потому, что
     * broadcast-кадры мосты пропускают охотнее unicast. */
    u32 flen = 14 + payload_len;
    if (flen < 60) {
        memset(frame + flen, 0, 60 - flen);
        flen = 60;
    }
    if (!g_nic_send) { s_unlock(&net_eth_lock); return -1; }
    rc = g_nic_send(frame, flen);
    if (rc > 0) { g_net.tx_packets++; g_net.tx_bytes += flen; }
    s_unlock(&net_eth_lock);
    return rc;
}

/* ---------- ARP ---------- */
int net_send_arp_request(u32 target_ip)
{
    if (g_net.ip == 0) return -1;
    arp_pkt_t arp;
    /* FIX [N2] (ARP-запросы игнорировались всеми стеками): htype/ptype/oper
     * писались как НАТИВНЫЕ LE-числа: 0x0001 превращалось в байты [01,00],
     * а на проводе нужно [00,01]. QEMU/slirp и реальные стеки читают
     * ar_op = 0x0100 вместо 1 (REQUEST) и молча отбрасывали запрос —
     * ARP-таблица не заполнялась НИКОГДА (поэтому же «вис» TCP-connect).
     * Пишем поля сразу сетевым порядком байт (как в reply ниже). */
    arp.htype = 0x0100;   /* 0x0001 BE: байты [00,01] = Ethernet */
    arp.ptype = 0x0008;   /* 0x0800 BE: байты [08,00] = IPv4 */
    arp.hlen  = 6;
    arp.plen  = 4;
    arp.oper  = 0x0100;   /* 0x0001 BE: request */
    memcpy(arp.sha, g_net.mac, 6);
    arp.spa[0] = (u8)((g_net.ip >> 24) & 0xFF);
    arp.spa[1] = (u8)((g_net.ip >> 16) & 0xFF);
    arp.spa[2] = (u8)((g_net.ip >> 8) & 0xFF);
    arp.spa[3] = (u8)(g_net.ip & 0xFF);
    memset(arp.tha, 0, 6);
    arp.tpa[0] = (u8)((target_ip >> 24) & 0xFF);
    arp.tpa[1] = (u8)((target_ip >> 16) & 0xFF);
    arp.tpa[2] = (u8)((target_ip >> 8) & 0xFF);
    arp.tpa[3] = (u8)(target_ip & 0xFF);

    /* Broadcast destination */
    u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    return send_eth(bcast, ETHERTYPE_ARP, &arp, sizeof(arp));
}

/* FIX [N1c]: дождаться разрешения MAC-адреса для IP (с учётом шлюза).
 *
 * Проблема: net_send_ip() при отсутствии записи в ARP-кэше МОЛЧА теряет
 * пакет (посылается только ARP-запрос). ping это переживает — команда
 * повторяет запрос; TCP-connect — нет: единственный SYN терялся,
 * ретрансляции не было → «Ошибка запроса» при первом обращении к любому
 * новому адресу. Функция посылает ARP-запросы с интервалом и ждёт ответа
 * (net_poll обрабатывает входящие, task_yield отдаёт CPU). */
int net_wait_arp(u32 ip, u32 max_ms)
{
    u8 mac[6];
    if (net_is_loopback(ip)) return 1;   /* loopback — без ARP */
    if (g_net.ip == 0) return 0;

    /* Куда реально пойдёт пакет: напрямую или через шлюз */
    u32 route = ip;
    if ((ip & g_net.netmask) != (g_net.ip & g_net.netmask)) {
        if (g_net.gateway == 0) return 0;
        route = g_net.gateway;
    }
    if (arp_cache_lookup(route, mac)) return 1;

    u32 start = timer_ticks();
    u32 need = max_ms;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    for (;;) {
        net_send_arp_request(route);
        /* 100 мс между ARP-запросами */
        u32 t0 = timer_ticks();
        while (timer_ticks() - t0 < 100) {
            net_poll();
            task_yield();
            if (arp_cache_lookup(route, mac)) return 1;
        }
        if (timer_ticks() - start >= need) break;
    }
    return arp_cache_lookup(route, mac);
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len);
static void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len);

/* Forward declarations for TCP listen */
typedef struct {
    int  in_use;
    u16  port;
    tcp_accept_cb_t cb;
    net_tcp_recv_cb_t recv_cb;   /* per-socket приём принятых соединений */
} tcp_listen_t;

#define NET_MAX_TCP_LISTEN 4
static tcp_listen_t g_tcp_listens[NET_MAX_TCP_LISTEN];

static void parse_tcp_options_impl(const u8 *opts, u32 opts_len, net_tcp_socket_t *s);
#define parse_tcp_options parse_tcp_options_impl

static void net_handle_arp(const eth_hdr_t *eth, const u8 *payload, u32 len)
{
    (void)eth;
    (void)len;
    if (len < sizeof(arp_pkt_t)) return;
    const arp_pkt_t *arp = (const arp_pkt_t *)payload;

    u16 oper = (arp->oper << 8) | (arp->oper >> 8);
    /* normalise: network order — oper уже 16-битное поле, big-endian.
     * На little-endian нам нужно перевернуть. */
    oper = (u16)((arp->oper >> 8) | (arp->oper << 8));

    u32 sender_ip = ((u32)arp->spa[0] << 24) | ((u32)arp->spa[1] << 16)
                   | ((u32)arp->spa[2] << 8) | (u32)arp->spa[3];

    /* Добавим в кэш отправителя */
    arp_cache_add(sender_ip, arp->sha);

    if (oper == 1) {
        /* ARP request: если запрос адресован нам — отвечаем */
        u32 target_ip = ((u32)arp->tpa[0] << 24) | ((u32)arp->tpa[1] << 16)
                       | ((u32)arp->tpa[2] << 8) | (u32)arp->tpa[3];
        if (target_ip == g_net.ip) {
            arp_pkt_t reply;
            reply.htype = 0x0001;
            reply.ptype = 0x0800;
            reply.hlen = 6;
            reply.plen = 4;
            reply.oper = 0x0002;   /* reply (little-endian, перевернётся ниже) */
            memcpy(reply.sha, g_net.mac, 6);
            memcpy(reply.spa, arp->tpa, 4);
            memcpy(reply.tha, arp->sha, 6);
            memcpy(reply.tpa, arp->spa, 4);
            /* Convert oper to network order */
            reply.oper = (u16)((0x0002 << 8) | (0x0002 >> 8));
            /* Convert htype and ptype too — но мы записали 0x0001 и 0x0800,
             * что в little-endian выглядит как 0x0100 и 0x0008.
             * На самом деле правильнее — изначально писать big-endian. */
            reply.htype = 0x0100;  /* 0x0001 в big-endian */
            reply.ptype = 0x0008;  /* 0x0800 в big-endian */
            send_eth(arp->sha, ETHERTYPE_ARP, &reply, sizeof(reply));
        }
    }
    g_net.arp_rx++;
}

/* ---------- IP ---------- */
static void net_send_ip(u8 proto, u32 dst_ip, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX];
    if (payload_len + 20 > NET_PKT_MAX - 14) return;

    /* loopback: на провод не идёт — данные доставляет слой выше
     * (TCP-пара в net_tcp_send / ICMP-эхо в net_send_icmp_echo) */
    if (net_is_loopback(dst_ip)) return;

    s_lock(&net_ip_lock);

    /* IP header */
    ip_hdr_t *ip = (ip_hdr_t *)pkt;
    ip->ver_ihl = 0x45;
    ip->tos = 0;
    ip->tot_len = (u16)(20 + payload_len);
    ip->tot_len = (u16)((ip->tot_len << 8) | (ip->tot_len >> 8));
    /* Сессия 21: уникальный ID на пакет вместо жёсткого 0x1234 —
     * одинаковый id на всех пакетах портит фрагментацию-дефрагментацию
     * промежуточных узлов и выглядит как крафтовый трафик для IDS. */
    {
        static u16 g_ip_id = 0;
        g_ip_id++;
        ip->id = (u16)((g_ip_id << 8) | (g_ip_id >> 8));
    }
    ip->flags_frag = 0x4000;  /* Don't Fragment */
    ip->flags_frag = (u16)((ip->flags_frag << 8) | (ip->flags_frag >> 8));
    ip->ttl = 64;
    ip->protocol = proto;
    {
        u32 src = g_net.dhcp_txn ? 0 : g_net.ip;   /* сессия 12: DHCP шлёт с 0.0.0.0 */
        ip->src_ip[0] = (u8)((src >> 24) & 0xFF);
        ip->src_ip[1] = (u8)((src >> 16) & 0xFF);
        ip->src_ip[2] = (u8)((src >> 8) & 0xFF);
        ip->src_ip[3] = (u8)(src & 0xFF);
    }
    ip->dst_ip[0] = (u8)((dst_ip >> 24) & 0xFF);
    ip->dst_ip[1] = (u8)((dst_ip >> 16) & 0xFF);
    ip->dst_ip[2] = (u8)((dst_ip >> 8) & 0xFF);
    ip->dst_ip[3] = (u8)(dst_ip & 0xFF);
    ip->checksum = 0;
    u16 cs = inet_checksum(ip, 20, 0);
    ip->checksum = (u16)((cs << 8) | (cs >> 8));

    /* Payload */
    memcpy(pkt + 20, payload, payload_len);

    /* Резолвим MAC */
    u8 dst_mac[6];
    if (dst_ip == 0xFFFFFFFFu) {
        /* FIX [DHCP-1]: ограниченный broadcast (255.255.255.255) —
         * НИКОГДА не через шлюз и без ARP: напрямую в L2-broadcast.
         * Раньше такой пакет «маршрутизировался» через шлюз, ARP для
         * шлюза при нашем ip=0.0.0.0 отказывал (см. net_send_arp_request)
         * — DHCP DISCOVER МОЛЧА терялся, ничего не выходило в сеть. */
        u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
        send_eth(bcast, ETHERTYPE_IPV4, pkt, 20 + payload_len);
        s_unlock(&net_ip_lock);
        return;
    }
    u32 route_ip = dst_ip;
    if ((dst_ip & g_net.netmask) != (g_net.ip & g_net.netmask)) {
        /* Не в нашей подсети — отправляем через шлюз */
        if (g_net.gateway != 0) {
            route_ip = g_net.gateway;
        }
    }
    if (!arp_cache_lookup(route_ip, dst_mac)) {
        /* Нет в кэше — ARP-запрос; пакет раньше ТЕРЯЛСЯ (первый SYN-ACK
         * сервера, первый ответ UDP/ICMP). FIX сессия 7: откладываем
         * (один слот) — arp_cache_add отправит его сразу после ответа. */
        net_send_arp_request(route_ip);
        if (g_pending_len == 0 && 20 + payload_len <= sizeof(g_pending_pkt)) {
            s_lock(&pending_lock);
            if (g_pending_len == 0) {
                memcpy(g_pending_pkt, pkt, 20 + payload_len);
                g_pending_len = 20 + payload_len;
                g_pending_dst_ip = route_ip;
            }
            s_unlock(&pending_lock);
        }
        s_unlock(&net_ip_lock);
        return;
    }

    send_eth(dst_mac, ETHERTYPE_IPV4, pkt, 20 + payload_len);
    s_unlock(&net_ip_lock);
}

/* ---------- ICMP ---------- */
int net_send_icmp_echo(u32 target_ip, u16 id, u16 seq, const void *payload, u32 payload_len)
{
    static u8 pkt[NET_PKT_MAX - 20];
    static volatile int icmp_lock = 0;
    if (payload_len + 8 > sizeof(pkt)) return -1;
    s_lock(&icmp_lock);
    icmp_hdr_t *icmp = (icmp_hdr_t *)pkt;
    icmp->type = ICMP_TYPE_ECHO_REQUEST;
    icmp->code = 0;
    icmp->checksum = 0;
    /* id и seq — уже big-endian, сохраняем как есть */
    icmp->id = (u16)((id << 8) | (id >> 8));
    icmp->seq = (u16)((seq << 8) | (seq >> 8));
    if (payload && payload_len > 0) {
        memcpy(pkt + 8, payload, payload_len);
    }
    u16 cs = inet_checksum(pkt, 8 + payload_len, 0);
    icmp->checksum = (u16)((cs << 8) | (cs >> 8));

    if (net_is_loopback(target_ip)) {
        /* loopback ping: эхо-ответ формируется мгновенно —
         * пакет никуда не уходит, сразу дёргаем callback ping-а */
        s_unlock(&icmp_lock);
        if (g_net.icmp_cb)
            g_net.icmp_cb(target_ip, id, seq, payload, payload_len);
        return 1;
    }

    net_send_ip(IP_PROTO_ICMP, target_ip, pkt, 8 + payload_len);
    s_unlock(&icmp_lock);
    return 0;
}

static void net_handle_icmp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < sizeof(icmp_hdr_t)) return;
    const icmp_hdr_t *icmp = (const icmp_hdr_t *)payload;

    u16 icmp_cs = (u16)((icmp->checksum << 8) | (icmp->checksum >> 8));
    u16 calc_cs = inet_checksum(icmp, len, 0);
    (void)icmp_cs; (void)calc_cs;

    if (icmp->type == ICMP_TYPE_ECHO_REQUEST) {
        /* Отвечаем echo reply */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];

        /* Строим echo reply */
        static u8 reply[NET_PKT_MAX - 20];
        if (len > sizeof(reply)) len = sizeof(reply);
        memcpy(reply, payload, len);
        reply[0] = ICMP_TYPE_ECHO_REPLY;
        reply[1] = 0;
        reply[2] = 0; reply[3] = 0;  /* checksum */
        u16 cs = inet_checksum(reply, len, 0);
        reply[2] = (u8)(cs & 0xFF);   /* little-endian byte order on wire... actually big-endian */
        reply[3] = (u8)((cs >> 8) & 0xFF);
        /* Actually wire format is big-endian: high byte first */
        reply[2] = (u8)((cs >> 8) & 0xFF);
        reply[3] = (u8)(cs & 0xFF);

        net_send_ip(IP_PROTO_ICMP, src_ip, reply, len);
    } else if (icmp->type == ICMP_TYPE_ECHO_REPLY) {
        /* Получен ответ на наш ping */
        u32 src_ip = ((u32)ip->src_ip[0] << 24)
                   | ((u32)ip->src_ip[1] << 16)
                   | ((u32)ip->src_ip[2] << 8)
                   | (u32)ip->src_ip[3];
        u16 id = (u16)((icmp->id << 8) | (icmp->id >> 8));
        u16 seq = (u16)((icmp->seq << 8) | (icmp->seq >> 8));
        if (g_net.icmp_cb) {
            g_net.icmp_cb(src_ip, id, seq, payload + 8, len - 8);
        }
    }
    g_net.icmp_rx++;
}

/* ---------- Обработка входящих пакетов ---------- */
static void net_handle_packet(const u8 *frame, u32 len)
{
    if (len < 14) return;
    eth_hdr_t eth;
    memcpy(&eth, frame, 14);
    u16 ethertype = (u16)((eth.ethertype << 8) | (eth.ethertype >> 8));

    /* Игнорируем кадры, не адресованные нам (broadcast или наш MAC) */
    int to_us = 0;
    if (memcmp(eth.dst, g_net.mac, 6) == 0) to_us = 1;
    if (memcmp(eth.dst, "\xFF\xFF\xFF\xFF\xFF\xFF", 6) == 0) to_us = 1;
    if (!to_us) return;

    const u8 *payload = frame + 14;
    u32 payload_len = len - 14;

    if (ethertype == ETHERTYPE_ARP) {
        net_handle_arp(&eth, payload, payload_len);
    } else if (ethertype == ETHERTYPE_IPV4) {
        if (payload_len < 20) return;
        const ip_hdr_t *ip = (const ip_hdr_t *)payload;
        /* Проверим, что пакет адресован нам (или broadcast) */
        u32 dst_ip = ((u32)ip->dst_ip[0] << 24) | ((u32)ip->dst_ip[1] << 16)
                   | ((u32)ip->dst_ip[2] << 8) | (u32)ip->dst_ip[3];
        if (dst_ip != g_net.ip && dst_ip != 0xFFFFFFFFu) {
            /* FIX [DHCP-2]: пока наш IP не настроен (0.0.0.0, фаза DHCP),
             * принимаем unicast-пакеты: часть DHCP-серверов (в т.ч.
             * slirp) шлёт OFFER/ACK на ПРЕДЛАГАЕМЫЙ адрес, а не в
             * broadcast — фильтр молча съедал их.
             * Сессия 12: то же и ВО ВРЕМЯ транзакции DHCP, когда старый
             * адрес ещё виден (не обнуляем его) — OFFER приходит на
             * предлагаемый НОВЫЙ адрес, который != нашему текущему. */
            if (g_net.ip != 0 && !g_net.dhcp_txn) {
                /* Не нам — игнорируем */
                return;
            }
        }
        /* Длина IP-пакета (host order) */
        u16 ip_len = (u16)((ip->tot_len >> 8) | (ip->tot_len << 8)); /* FIX [N3] */
        if (ip_len < 20 || ip_len > payload_len) return;

        /* Сессия 21: ИСПРАВНАЯ длина заголовка (IHL). Раньше payload
         * всегда брался с offset 20: IP-пакеты с опциями (IHL>5 —
         * встречаются у роутеров/фаерволов) парсились по СМЕЩЁННОМУ
         * заголовку и молча терялись протокольными обработчиками. */
        u8 ihl = (u8)((ip->ver_ihl & 0x0F) * 4);
        if (ihl < 20 || ihl > ip_len) return;

        const u8 *ip_payload = payload + ihl;
        u32 ip_payload_len = ip_len - ihl;

        if (ip->protocol == IP_PROTO_ICMP) {
            net_handle_icmp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_UDP) {
            net_handle_udp(ip, ip_payload, ip_payload_len);
        }
        else if (ip->protocol == IP_PROTO_TCP) {
            net_handle_tcp(ip, ip_payload, ip_payload_len);
        }
    }
}

void net_poll(void)
{
    /* FIX (гонка приёма): net_poll вызывают ОДНОВРЕМЕННО kmain (главный
     * цикл) и потоки окон (wait-циклы http-клиента: browser/curl/nettrace).
     * Раньше буфер приёма был static — общий на всех: два concurrent
     * net_poll калечили пакеты друг друга и состояние TCP-сокетов
     * («браузер не получает ответ»). Теперь всё тело под блокировкой;
     * ожидающий спит (hlt) и не жжёт CPU. */
    static volatile int net_poll_lock = 0;
    if (!g_nic_recv) return;
    s_lock(&net_poll_lock);
    /* FIX [DHCP-3]: ветка «ip == 0 → все пакеты в корзину» ломала DHCP:
     * клиент на время DISCOVER ставит 0.0.0.0 (net_set_ip(0)) — и все
     * OFFER/ACK немедленно выбрасывались прямо из кольца NIC. Пакеты
     * обрабатываем всегда; фильтр по dst-IP в net_handle_packet сам
     * решает, наши они или нет (при ip=0 принимает всё — фаза DHCP). */
    static u8 buf[NET_PKT_MAX];
    for (int i = 0; i < 8; i++) {
        u32 n = g_nic_recv(buf, sizeof(buf));
        if (n == 0) break;
        g_net.rx_packets++;
        g_net.rx_bytes += n;
        net_handle_packet(buf, n);
    }
    net_tcp_timer();
    s_unlock(&net_poll_lock);
}

/* ===================== UDP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u16 length;
    u16 checksum;   /* 0 = no checksum */
} udp_hdr_t;

static net_udp_socket_t g_udp_socks[NET_MAX_UDP_SOCKETS];
static net_udp_recv_cb_t g_udp_recv_cb = NULL;   /* fallback: нет сокета под порт */
static int g_udp_last_open = -1;                 /* Сессия 21: последний открытый */

/* Сессия 21 (demux UDP): callback привязывается к ПОСЛЕДНЕМУ открытому
 * сокету. Раньше был ОДИН глобальный cb: DNS-сокет получал DHCP-пакеты
 * и LAN-шум (NetBIOS/mDNS/SSDP) — «[dns] txid mismatch»; DHCP-клиент
 * после первого net_dns_resolve() вообще переставал получать ответы
 * (его cb перетирали) — продление/повтор DHCP висели. Теперь каждый
 * сокет получает только пакеты на СВОЙ порт. */
void net_udp_set_callback(net_udp_recv_cb_t cb)
{
    if (g_udp_last_open >= 0 && g_udp_last_open < NET_MAX_UDP_SOCKETS &&
        g_udp_socks[g_udp_last_open].in_use) {
        g_udp_socks[g_udp_last_open].cb = cb;
        return;
    }
    g_udp_recv_cb = cb;   /* сокетов нет — глобальный fallback */
}

int net_udp_open(u16 local_port)
{
    for (int i = 0; i < NET_MAX_UDP_SOCKETS; i++) {
        if (!g_udp_socks[i].in_use) {
            g_udp_socks[i].in_use = 1;
            g_udp_socks[i].local_ip = g_net.ip;
            g_udp_socks[i].local_port = local_port;
            g_udp_socks[i].remote_ip = 0;
            g_udp_socks[i].remote_port = 0;
            g_udp_socks[i].cb = NULL;
            g_udp_last_open = i;
            return i;
        }
    }
    return -1;
}

void net_udp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return;
    g_udp_socks[sock].in_use = 0;
    g_udp_socks[sock].cb = NULL;
    if (g_udp_last_open == sock) g_udp_last_open = -1;
}

int net_udp_send(int sock, u32 dst_ip, u16 dst_port, const void *data, u32 len)
{
    static u8 pkt[1500];
    static volatile int udp_lock = 0;
    if (sock < 0 || sock >= NET_MAX_UDP_SOCKETS) return -1;
    if (!g_udp_socks[sock].in_use) return -1;
    if (len > 1472) return -1;   /* MTU 1500 - 20 IP - 8 UDP */
    s_lock(&udp_lock);
    udp_hdr_t *udp = (udp_hdr_t *)pkt;
    udp->src_port = (u16)((g_udp_socks[sock].local_port >> 8) | (g_udp_socks[sock].local_port << 8));
    udp->dst_port = (u16)((dst_port >> 8) | (dst_port << 8));
    u16 total = (u16)(8 + len);
    udp->length = (u16)((total >> 8) | (total << 8));
    udp->checksum = 0;
    memcpy(pkt + 8, data, len);

    g_udp_socks[sock].remote_ip = dst_ip;
    g_udp_socks[sock].remote_port = dst_port;

    net_send_ip(IP_PROTO_UDP, dst_ip, pkt, 8 + len);
    s_unlock(&udp_lock);
    return (int)len;
}

static void net_handle_udp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 8) return;
    const udp_hdr_t *udp = (const udp_hdr_t *)payload;
    u16 src_port = (u16)((udp->src_port >> 8) | (udp->src_port << 8)); /* FIX [N3] */
    u16 dst_port = (u16)((udp->dst_port >> 8) | (udp->dst_port << 8)); /* FIX [N3] */
    u16 udp_len = (u16)((udp->length >> 8) | (udp->length << 8)); /* FIX [N3] */
    if (udp_len > len) udp_len = (u16)len;
    if (udp_len < 8) return;
    u32 data_len = udp_len - 8;
    const u8 *data = payload + 8;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    /* Сессия 21: demux по dst_port — пакет идёт СОКЕТУ с этим портом
     * (и только ему). Нет сокета — глобальный fallback (обычно NULL:
     * LAN-шум на чужие порты больше не будит ни DNS, ни DHCP). */
    for (int i = 0; i < NET_MAX_UDP_SOCKETS; i++) {
        if (g_udp_socks[i].in_use && g_udp_socks[i].local_port == dst_port) {
            if (g_udp_socks[i].cb)
                g_udp_socks[i].cb(src_ip, src_port, dst_port, data, data_len);
            return;
        }
    }
    if (g_udp_recv_cb) {
        g_udp_recv_cb(src_ip, src_port, dst_port, data, data_len);
    }
}

/* ===================== TCP ===================== */

typedef struct {
    u16 src_port;
    u16 dst_port;
    u32 seq;
    u32 ack;
    u8  data_offset;   /* верхние 4 бита — header length в 32-битных словах */
    u8  flags;
    u16 window;
    u16 checksum;
    u16 urgent;
} tcp_hdr_t;

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10
#define TCP_URG 0x20

static net_tcp_socket_t g_tcp_socks[NET_MAX_TCP_SOCKETS];
static net_tcp_recv_cb_t g_tcp_recv_cb = NULL;
static u32 g_tcp_next_isn = 0x1000;   /* initial seq number counter */

/* Сессия 72 [GEN]: поколение слота — +1 при каждом захвате. Владельцы
 * (httpd_conn_t.gen) сверяют его с net_tcp_gen(sock): не совпало —
 * слот после захвата ссылки был освобождён и занят заново, ссылка
 * мертва (чужой сокет закрывать/слать нельзя). */
static u32 g_tcp_gen[NET_MAX_TCP_SOCKETS];
/* Сессия 72 [PIN]: слот закреплён владельцем (httpd принял соединение
 * и ещё не отдал его слоту обратно). Захватчики (net_tcp_connect,
 * loopback/wire accept) слоты с пином не берут — даже если пир или
 * таймер уже снял in_use, а владелец ещё не знает о смерти сокета.
 * Пин снимает только владелец (net_tcp_unpin_gen в httpd_slot_reset). */
static u8  g_tcp_pinned[NET_MAX_TCP_SOCKETS];

void net_tcp_pin(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    g_tcp_pinned[sock] = 1;
}

void net_tcp_unpin(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    g_tcp_pinned[sock] = 0;
}

/* Снять пин ТОЛЬКО своего поколения: ссылка, пережившая
 * переиспользование слота, не снимет чужой (новый) пин. */
void net_tcp_unpin_gen(int sock, u32 gen)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    if (g_tcp_gen[sock] == gen) g_tcp_pinned[sock] = 0;
}

u32 net_tcp_gen(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    return g_tcp_gen[sock];
}

/* Слот доступен для захвата: свободен И не закреплён владельцем. */
static int tcp_slot_free(int k)
{
    if (k < 0 || k >= NET_MAX_TCP_SOCKETS) return 0;
    return !g_tcp_socks[k].in_use && !g_tcp_pinned[k];
}

void net_tcp_set_callback(net_tcp_recv_cb_t cb) { g_tcp_recv_cb = cb; }

const char *tcp_state_name(tcp_state_t s)
{
    static const char *names[] = {
        "CLOSED", "SYN_SENT", "SYN_RECEIVED", "ESTABLISHED",
        "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT", "LAST_ACK",
        "CLOSING", "TIME_WAIT"
    };
    if (s < (tcp_state_t)10) return names[s];
    return "?";
}

/* Отправить TCP-сегмент с заданными флагами и payload.
 * Если флаг SYN установлен, добавляем MSS option (default 1460).
 *
 * FIX [N1] (браузер не открывал http://<IP>): чексумма TCP НЕ считалась
 * (поле оставалось 0). В TCP (в отличие от UDP) нулевая чексумма НЕ
 * легитимна — серверы молча сбрасывают такие сегменты, включая SYN:
 * connect «висел» до таймаута → «Ошибка запроса». Теперь считаем
 * чексумму по псевдозаголовку (inet_checksum_pseudo — уже была в файле,
 * но не использовалась). */
static void tcp_send_segment(net_tcp_socket_t *s, u8 flags,
                             const void *data, u32 data_len)
{
    static u8 pkt[1500];
    static volatile int tcpseg_lock = 0;
    s_lock(&tcpseg_lock);
    tcp_hdr_t *tcp = (tcp_hdr_t *)pkt;
    tcp->src_port = (u16)((s->local_port >> 8) | (s->local_port << 8));
    tcp->dst_port = (u16)((s->remote_port >> 8) | (s->remote_port << 8));
    tcp->seq = (u32)((s->seq >> 24) | ((s->seq >> 8) & 0xFF00)
                   | ((s->seq << 8) & 0xFF0000) | (s->seq << 24));
    tcp->ack = (u32)((s->ack >> 24) | ((s->ack >> 8) & 0xFF00)
                   | ((s->ack << 8) & 0xFF0000) | (s->ack << 24));

    u32 hdr_len = 20;
    /* Для SYN добавляем MSS option (4 байта: type=2, len=4, value=1460) */
    if (flags & TCP_SYN) {
        u8 *opts = (u8 *)(pkt + 20);
        opts[0] = 2;  /* MSS option type */
        opts[1] = 4;  /* length */
        opts[2] = (u8)((s->mss >> 8) & 0xFF);
        opts[3] = (u8)(s->mss & 0xFF);
        /* Pad to 24 bytes (4 bytes option, divisible by 4) */
        hdr_len = 24;
    }

    tcp->data_offset = (u8)((hdr_len / 4) << 4);
    tcp->flags = flags;
    tcp->window = 0xFFFF;   /* max window */
    tcp->window = (u16)((tcp->window >> 8) | (tcp->window << 8));
    tcp->checksum = 0;
    tcp->urgent = 0;
    if (data && data_len > 0) {
        memcpy(pkt + hdr_len, data, data_len);
    }
    /* FIX [N1]: чексумма TCP — псевдозаголовок + заголовок + данные */
    {
        u16 cs = inet_checksum_pseudo(s->local_ip, s->remote_ip,
                                      IP_PROTO_TCP, pkt, hdr_len + data_len);
        tcp->checksum = (u16)((cs << 8) | (cs >> 8));
    }
    net_send_ip(IP_PROTO_TCP, s->remote_ip, pkt, hdr_len + data_len);
    s_unlock(&tcpseg_lock);
}

/* FIX [N1b]: повторная отправка SYN, пока соединение не установлено.
 * Раньше net_tcp_timer() «ретранслировал» только счётчики (заглушка),
 * а первый SYN терялся при отсутствии ARP-записи (пакет молча
 * отбрасывался в net_send_ip) — ping выживал повторами, TCP — нет. */
void net_tcp_kick(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use || s->state != TCP_SYN_SENT) return;
    u32 cur = s->seq;             /* seq уже учёл +1 за SYN */
    s->seq = cur - 1;
    tcp_send_segment(s, TCP_SYN, NULL, 0);
    s->seq = cur;
    s->retransmit_tick = timer_ticks();
    s->retransmit_count++;
}

int net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port)
{
    int i;
    for (i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        if (tcp_slot_free(i)) break;   /* [PIN]: закреплённые не трогаем */
    }
    if (i >= NET_MAX_TCP_SOCKETS) {
        /* диагностика в serial: какие состояния заняли все слоты
         * (утёкшие сокеты раньше были невидимы) */
        char msg[128];
        extern void serial_puts(const char *);
        int pos = 0;
        pos += snprintf(msg + pos, sizeof(msg) - pos,
                        "[net] tcp: нет свободных сокетов (%d занято):",
                        NET_MAX_TCP_SOCKETS);
        for (int k = 0; k < NET_MAX_TCP_SOCKETS && pos < (int)sizeof(msg) - 8; k++) {
            if (g_tcp_socks[k].in_use)
                pos += snprintf(msg + pos, sizeof(msg) - pos, " %d",
                                (int)g_tcp_socks[k].state);
        }
        serial_puts(msg);
        serial_puts("\n");
        return -1;
    }

    net_tcp_socket_t *s = &g_tcp_socks[i];
    s->in_use = 1;
    /* [C-STATE] [GEN]: живое состояние СРАЗУ после захвата. Раньше
     * между in_use=1 и назначением состояния вытеснение по IRQ0
     * оставляло слот с мусорным state==TCP_CLOSED — таймер считал его
     * «застрявшим» и освобождал, а серверная сторона loopback-пары
     * занимала ТОТ ЖЕ слот → пара замыкалась на себя. SYN_SENT даёт
     * таймеру лимит 15 с на handshake. */
    g_tcp_gen[i]++;                 /* [GEN]: новое поколение слота */
    s->state = TCP_SYN_SENT;
    s->local_ip = g_net.ip;
    s->local_port = local_port;
    s->remote_ip = dst_ip;
    s->remote_port = dst_port;
    s->seq = g_tcp_next_isn;
    g_tcp_next_isn += 64000;   /* increment ISN */
    {
        extern void serial_puts(const char *);
        char b[80];
        snprintf(b, sizeof(b), "[tcp] connect idx=%d isn=%u dst=%08x:%u\n",
                 i, (unsigned)(s->seq), (unsigned)dst_ip, (unsigned)dst_port);
        serial_puts(b);
    }
    s->ack = 0;
    s->mss = 1460;
    s->window_scale = 0;
    s->retransmit_seq = 0;
    s->retransmit_tick = 0;
    s->retransmit_count = 0;
    s->retrans_len = 0;       /* FIX [TCP-R1]: без мусора от прошлого сокета */
    s->was_reset = 0;         /* FIX [TCP-R2]: сброс флага RST нового соединения */
    s->rst_ip = 0;            /* сессия 56: данные RST прошлого соединения */
    s->rst_port = 0;
    s->rst_ttl = 0;
    s->peer = -1;
    s->recv_cb = NULL;

    /* ---------- Loopback: 127.x / на себя ----------
     * Соединение замыкается внутри стека: если порт слушает локальный
     * сервер (например httpd) — создаем пару сокетов и «проигрываем»
     * handshake; нет слушателя — мгновенный «connection refused». */
    if (net_is_loopback(dst_ip)) {
        for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
            if (!g_tcp_listens[li].in_use) continue;
            if (g_tcp_listens[li].port != dst_port) continue;

            /* свободный сокет под серверную сторону */
            int j = -1;
            for (int k = 0; k < NET_MAX_TCP_SOCKETS; k++) {
                if (tcp_slot_free(k)) { j = k; break; }   /* [PIN] */
            }
            if (j < 0) break;   /* слотов нет — refuse */

            net_tcp_socket_t *srv = &g_tcp_socks[j];
            srv->in_use = 1;
            /* [C-STATE] [GEN]: живое состояние сразу (см. выше) —
             * вытеснение между захватом и ESTABLISHED не отдаст слот
             * таймеру и не подставит под пару чужой захватчик. */
            g_tcp_gen[j]++;
            srv->state = TCP_SYN_RECEIVED;
            srv->local_ip = dst_ip;
            srv->local_port = dst_port;
            srv->remote_ip = 0x7F000001u;       /* 127.0.0.1 */
            srv->remote_port = local_port;
            srv->seq = g_tcp_next_isn;
            g_tcp_next_isn += 64000;
            srv->ack = s->seq + 1;              /* SYN клиента */
            srv->mss = 1460;
            srv->window_scale = 0;
            srv->retransmit_seq = 0;
            srv->retransmit_tick = 0;
            srv->retransmit_count = 0;
            srv->retrans_len = 0;
            srv->was_reset = 0;
            srv->peer = i;
            srv->recv_cb = g_tcp_listens[li].recv_cb;

            /* клиентская сторона: SYN + SYN-ACK + ACK «состоялись» */
            s->seq += 1;
            s->ack = srv->seq + 1;
            s->peer = j;
            s->state = TCP_ESTABLISHED;
            srv->state = TCP_ESTABLISHED;

            /* уведомить сервер о входящем соединении */
            if (g_tcp_listens[li].cb)
                g_tcp_listens[li].cb(j, srv->remote_ip, local_port);
            return i;
        }
        /* слушателя нет — соединение отвергнуто */
        s->state = TCP_CLOSED;   /* клиент увидит «connection refused» */
        return i;
    }

    s->state = TCP_SYN_SENT;

    /* Send SYN with MSS option */
    tcp_send_segment(s, TCP_SYN, NULL, 0);
    s->seq += 1;   /* SYN consumes 1 seq */
    s->retransmit_seq = s->seq - 1;  /* SYN seq */
    s->retransmit_tick = timer_ticks();
    return i;
}

/* ===================== TCP Passive LISTEN ===================== */

int net_tcp_listen(u16 local_port, tcp_accept_cb_t cb,
                   net_tcp_recv_cb_t recv_cb)
{
    for (int i = 0; i < NET_MAX_TCP_LISTEN; i++) {
        if (!g_tcp_listens[i].in_use) {
            g_tcp_listens[i].in_use = 1;
            g_tcp_listens[i].port = local_port;
            g_tcp_listens[i].cb = cb;
            g_tcp_listens[i].recv_cb = recv_cb;
            return i;
        }
    }
    return -1;
}

/* Сессия 58: снять слушатель (Настройки → галочка «Веб-сервер»). */
void net_tcp_unlisten(u16 local_port)
{
    for (int i = 0; i < NET_MAX_TCP_LISTEN; i++) {
        if (g_tcp_listens[i].in_use && g_tcp_listens[i].port == local_port)
            g_tcp_listens[i].in_use = 0;
    }
}

/* Парсить TCP-опции (MSS, Window Scale, SACK-permitted) */
static void parse_tcp_options_impl(const u8 *opts, u32 opts_len,
                               net_tcp_socket_t *s)
{
    u32 i = 0;
    while (i < opts_len) {
        u8 type = opts[i];
        if (type == 0) break;  /* End of options */
        if (type == 1) { i++; continue; }  /* NOP */
        if (i + 1 >= opts_len) break;
        u8 len = opts[i+1];
        if (len < 2) break;
        if (type == 2 && len == 4 && i + 4 <= opts_len) {
            /* MSS option */
            s->mss = ((u16)opts[i+2] << 8) | opts[i+3];
            if (s->mss < 536) s->mss = 536;
            if (s->mss > 1460) s->mss = 1460;
        }
        else if (type == 3 && len == 3 && i + 3 <= opts_len) {
            /* Window Scale option */
            s->window_scale = opts[i+2];
        }
        i += len;
    }
}

void net_tcp_close(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use) return;

    /* ---------- loopback-пара ---------- */
    if (s->peer >= 0) {
        net_tcp_socket_t *p = &g_tcp_socks[s->peer];
        if (p->in_use && p->peer == sock) {
            /* Партнёр получает FIN: для наших клиентов это конец
             * данных — переводим его в CLOSED (приём уже доставлен
             * инлайн, HTTP/1.0-клиенты после FIN ничего не ждут). */
            p->peer = -1;
            p->state = TCP_CLOSED;   /* in_use остаётся: сокет закроет своё приложение */
        }
        s->peer = -1;
        s->state = TCP_CLOSED;
        s->in_use = 0;
        return;
    }

    if (s->state == TCP_ESTABLISHED) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        s->state = TCP_FIN_WAIT_1;
    } else if (s->state == TCP_CLOSE_WAIT) {
        tcp_send_segment(s, TCP_FIN | TCP_ACK, NULL, 0);
        s->seq += 1;
        s->state = TCP_LAST_ACK;
    } else {
        s->state = TCP_CLOSED;
        s->in_use = 0;
    }
}

int net_tcp_send(int sock, const void *data, u32 len)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return -1;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use || s->state != TCP_ESTABLISHED) return -1;

    /* ---------- loopback-пара: доставка партнёру без провода ---------- */
    if (s->peer >= 0) {
        net_tcp_socket_t *p = &g_tcp_socks[s->peer];
        if (!p->in_use || p->state != TCP_ESTABLISHED) return -1;
        int pidx = s->peer;
        if (p->recv_cb)
            p->recv_cb(s->peer, s->local_ip ? s->local_ip : 0x7F000001u,
                       s->local_port, data, len);
        else if (g_tcp_recv_cb)
            g_tcp_recv_cb(s->peer, s->local_ip ? s->local_ip : 0x7F000001u,
                          s->local_port, data, len);
        /* СЕССИЯ 61: колбэк мог ЗАКРЫТЬ/переиспользовать слоты (httpd
         * завершает соединение прямо внутри синхронной обработки
         * запроса; параллельная задача может занять освободившийся
         * индекс). Бухгалтерию seq/ack ведём только по живой паре. */
        if (s->in_use && s->peer == pidx) {
            s->seq += len;
            net_tcp_socket_t *p2 = &g_tcp_socks[pidx];
            if (p2->in_use && p2->peer == sock)
                p2->ack = s->seq;    /* партнёр подтверждает наши данные */
        }
        return (int)len;
    }

    u32 mss = s->mss ? s->mss : 1460;
    if (len > mss) len = mss;
    tcp_send_segment(s, TCP_PSH | TCP_ACK, data, len);
    s->seq += len;
    /* Track for retransmission */
    s->retransmit_seq = s->seq - len;
    s->retransmit_tick = timer_ticks();
    s->retransmit_count = 0;
    /* FIX [TCP-R1]: сохранить сегмент — таймер сможет его реально
     * переслать (раньше «ретрансмиссия» была только счётчиком). */
    if (data && len > 0) {
        u32 save = len < TCP_RETRANS_MAX ? len : TCP_RETRANS_MAX;
        memcpy(s->retrans_buf, data, save);
        s->retrans_len = (u16)save;
    }
    return (int)len;
}

tcp_state_t net_tcp_state(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return TCP_CLOSED;
    if (!g_tcp_socks[sock].in_use) return TCP_CLOSED;
    return g_tcp_socks[sock].state;
}

/* Сессия 60 (FSM httpd): есть ли сегмент данных, ещё не подтверждённый
 * пиром. Пока pending == 1, следующий кусок слать нельзя: буфер
 * ретрансляции один (retrans_buf), потерянный кусок больше не
 * восстановить — отправка файла идёт «стоп-и-ждём» по одному сегменту,
 * следующий — только после ACK (сброс retransmit_seq в tcp_input). */
int net_tcp_send_pending(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    const net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->in_use) return 0;
    return (s->retransmit_seq != 0) ? 1 : 0;
}

/* FIX [TCP-R2]: признак сброса соединения. Читается и после того, как
 * сокет переведён в CLOSED (в том числе когда net_tcp_timer уже
 * освободил слот): флаг живёт до следующего net_tcp_connect. */
int net_tcp_was_reset(int sock)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    return g_tcp_socks[sock].was_reset;
}

/* Сессия 56: источник последнего RST (для сообщений браузера/клиента).
 * was_reset живёт до следующего net_tcp_connect на этот слот. */
int net_tcp_rst_info(int sock, u32 *ip, u16 *port, u8 *ttl)
{
    if (sock < 0 || sock >= NET_MAX_TCP_SOCKETS) return 0;
    net_tcp_socket_t *s = &g_tcp_socks[sock];
    if (!s->was_reset) return 0;
    if (ip)   *ip   = s->rst_ip;
    if (port) *port = s->rst_port;
    if (ttl)  *ttl  = s->rst_ttl;
    return 1;
}

/* TCP retransmission timer — проверяет все сокеты на таймаут.
 *
 * FIX [утечка сокетов, реальное железо]: сокет, застрявший в любом
 * промежуточном состоянии, раньше жил ВЕЧНО. Каждый неудачный connect
 * (например, при невалидном адресе источника до фикса DHCP) навсегда
 * занимал слот из 8 — после нескольких попыток net_tcp_connect()
 * мгновенно возвращал -1 («connect 0 мс, сокет -1» в HTTP Trace).
 * Теперь каждое переходное состояние имеет возрастной лимит: смена
 * состояния фиксируется в теневом массиве, просроченное — сброс. */
void net_tcp_timer(void)
{
    static u32 shadow_state[NET_MAX_TCP_SOCKETS];
    static u32 shadow_tick[NET_MAX_TCP_SOCKETS];
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) {
            shadow_state[i] = 0;
            continue;
        }
        if (s->state != shadow_state[i]) {
            shadow_state[i] = s->state;
            shadow_tick[i] = timer_ticks();
        }
        u32 age = timer_ticks() - shadow_tick[i];
        int aged_out = 0;
        switch (s->state) {
            case TCP_SYN_SENT:
            case TCP_SYN_RECEIVED:
                if (age >= 15000) aged_out = 1;   /* 15 с на handshake (1 тик = 1 мс) */
                break;
            case TCP_FIN_WAIT_1:
            case TCP_FIN_WAIT_2:
            case TCP_LAST_ACK:
                /* [FIN-TO] (отчёт, баг 5): было 30 с — при 8 слотах
                 * NET_MAX_TCP_SOCKETS мёртвый пир (FIN уходит в пустоту,
                 * ACK не приходит никогда; ретрансмиссия FIN в стеке
                 * не делается — только данные в ESTABLISHED) занимал
                 * слот полминуты: четыре неудачных fetch = половина
                 * пула в подвешенном состоянии. Живой пир ACK-ает FIN
                 * за <100 мс; 3 с — это ~30 RTT, дальше сидеть
                 * бессмысленно. FIN_WAIT_2 сюда же: приложение уже
                 * сказало close() — дочитывать серверу больше нечего. */
                if (age >= 3000) aged_out = 1;    /* 3 с на закрытие (1 тик = 1 мс) */
                break;
            case TCP_TIME_WAIT:
                if (age >= 10000) aged_out = 1;   /* 10 с (2×MSL упрощённо; 1 тик = 1 мс) */
                break;
            case TCP_CLOSE_WAIT:
                if (age >= 60000) aged_out = 1;   /* 60 с грейс на дочитку (1 тик = 1 мс) */
                break;
            default:
                break;
        }
        if (aged_out) {
            s->state = TCP_CLOSED;
            s->in_use = 0;
            continue;
        }
        if (s->state == TCP_CLOSED) {
            /* застрявший CLOSED (в т.ч. loopback-refuse): приложение
             * уже увидело отказ — освобождаем слот, иначе утечка */
            s->in_use = 0;
            continue;
        }
        if (s->retransmit_seq == 0) continue;
        if (s->retransmit_tick == 0) continue;
        /* Timeout: 1 second initially, doubling on each retransmit */
        u32 timeout_ticks = 1000u;  /* 1 с (1 тик = 1 мс, сессия 33) */
        for (int j = 0; j < s->retransmit_count; j++) timeout_ticks *= 2;
        if (timeout_ticks > 64000u) timeout_ticks = 64000u;  /* cap at 64s */
        if ((timer_ticks() - s->retransmit_tick) < timeout_ticks) continue;
        /* FIX [TCP-R1]: РЕАЛЬНАЯ ретрансмиссия последнего сегмента данных.
         * Раньше здесь только инкрементировался счётчик, а данные НЕ
         * пересылались: потерянный GET не восстанавливался — сервер
         * молчал, клиент висел до «response timeout». */
        if (s->retrans_len > 0 && s->state == TCP_ESTABLISHED) {
            u32 cur = s->seq;
            s->seq = s->retransmit_seq;
            tcp_send_segment(s, TCP_PSH | TCP_ACK, s->retrans_buf,
                             s->retrans_len);
            s->seq = cur;
        }
        s->retransmit_count++;
        s->retransmit_tick = timer_ticks();
        if (s->retransmit_count > 8) {
            /* Too many retransmits — abort */
            s->was_reset = 1;   /* для клиента это выглядит как сброс */
            s->state = TCP_CLOSED;
            s->in_use = 0;
        }
    }
}

static void net_handle_tcp(const ip_hdr_t *ip, const u8 *payload, u32 len)
{
    if (len < 20) return;
    /* FIX (сессия 60): порты читаем БАЙТАМИ — payload начинается на
     * нечётном смещении (Ethernet 14 + IP 20 = 34), доступ к u16 через
     * packed tcp_hdr_t — невыровненный (UBSan хост-харнесса ругался).
     * На i386 это работало, но байтовое чтение корректно везде. */
    u16 src_port = (u16)(((u32)payload[0] << 8) | payload[1]);
    u16 dst_port = (u16)(((u32)payload[2] << 8) | payload[3]);
    u32 seq = ((u32)(payload[4]) << 24) | ((u32)(payload[5]) << 16)
            | ((u32)(payload[6]) << 8) | (u32)payload[7];
    u32 ack = ((u32)(payload[8]) << 24) | ((u32)(payload[9]) << 16)
            | ((u32)(payload[10]) << 8) | (u32)payload[11];
    u8  flags = payload[13];
    u8  hdr_len = (u8)((payload[12] >> 4) * 4);
    if (hdr_len < 20 || hdr_len > len) return;

    u32 data_len = len - hdr_len;
    const u8 *data = payload + hdr_len;
    const u8 *opts = payload + 20;
    u32 opts_len = hdr_len > 20 ? (hdr_len - 20) : 0;

    u32 src_ip = ((u32)ip->src_ip[0] << 24) | ((u32)ip->src_ip[1] << 16)
               | ((u32)ip->src_ip[2] << 8) | (u32)ip->src_ip[3];

    /* Check for passive LISTEN first — if incoming SYN on a listening port */
    if ((flags & TCP_SYN) && !(flags & TCP_ACK)) {
        for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
            if (!g_tcp_listens[li].in_use) continue;
            if (g_tcp_listens[li].port != dst_port) continue;

            /* FIX сессия 7 (двойной accept): повторный SYN (ретрансмиссия
             * клиента после потери нашего SYN-ACK) раньше создавал ВТОРОЙ
             * сокет того же соединения: handshake завершался по одному
             * сокету, а данные матчились в ДРУГОЙ (с чужим seq) —
             * «сервер не отвечает». Теперь повторный SYN только повторяет
             * SYN-ACK на УЖЕ существующем сокете. */
            for (int j = 0; j < NET_MAX_TCP_SOCKETS; j++) {
                net_tcp_socket_t *es = &g_tcp_socks[j];
                if (!es->in_use) continue;
                if (es->local_port != dst_port) continue;
                if (es->remote_ip != src_ip) continue;
                if (es->remote_port != src_port) continue;
                if (es->state == TCP_SYN_RECEIVED || es->state == TCP_ESTABLISHED) {
                    tcp_send_segment(es, TCP_SYN | TCP_ACK, NULL, 0);
                    return;
                }
            }

            /* Accept connection — find a free socket */
            int si = -1;
            for (int j = 0; j < NET_MAX_TCP_SOCKETS; j++) {
                if (tcp_slot_free(j)) { si = j; break; }   /* [PIN] */
            }
            if (si < 0) {
                /* No free sockets — send RST */
                net_tcp_socket_t tmp;
                memset(&tmp, 0, sizeof(tmp));
                tmp.local_ip = g_net.ip;
                tmp.local_port = dst_port;
                tmp.remote_ip = src_ip;
                tmp.remote_port = src_port;
                tmp.ack = seq + 1;
                tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
                return;
            }
            /* Create new socket in SYN_RECEIVED state */
            net_tcp_socket_t *s = &g_tcp_socks[si];
            s->in_use = 1;
            /* [C-STATE] [GEN]: живое состояние сразу после захвата
             * (см. net_tcp_connect) — SYN_RECEIVED даёт таймеру лимит
             * 15 с на завершение handshake. */
            g_tcp_gen[si]++;
            s->state = TCP_SYN_RECEIVED;
            s->local_ip = g_net.ip;
            s->local_port = dst_port;
            s->remote_ip = src_ip;
            s->remote_port = src_port;
            s->seq = g_tcp_next_isn;
            g_tcp_next_isn += 64000;
            s->ack = seq + 1;
            s->mss = 1460;
            s->window_scale = 0;
            s->retransmit_seq = 0;
            s->retransmit_count = 0;
            s->retrans_len = 0;
            s->was_reset = 0;
            s->peer = -1;
            s->recv_cb = g_tcp_listens[li].recv_cb;  /* per-socket приём */
            {
                extern void serial_puts(const char *);
                char b[80];
                snprintf(b, sizeof(b), "[tcp] accept idx=%d isn=%u from %08x:%u\n",
                         si, (unsigned)s->seq, (unsigned)src_ip, (unsigned)src_port);
                serial_puts(b);
            }
            /* Parse peer's TCP options (MSS, WS, SACK-permitted) */
            if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
            /* Send SYN-ACK */
            tcp_send_segment(s, TCP_SYN | TCP_ACK, NULL, 0);
            s->seq += 1;  /* SYN consumes 1 seq */
            s->state = TCP_SYN_RECEIVED;
            /* Note: callback is called when handshake completes (ESTABLISHED) */
            return;
        }
    }

    /* Find matching socket */
    for (int i = 0; i < NET_MAX_TCP_SOCKETS; i++) {
        net_tcp_socket_t *s = &g_tcp_socks[i];
        if (!s->in_use) continue;
        if (s->remote_ip != src_ip) continue;
        if (s->remote_port != src_port) continue;
        if (s->local_port != dst_port) continue;

        /* FIX [TCP-R2]: RST в ЛЮБОМ состоянии означает, что соединения
         * больше нет. Раньше сегмент с RST молча игнорировался в
         * TCP_ESTABLISHED: клиент висел до полного таймаута
         * («response timeout» при живом отказе сервера/шлюза — так
         * выглядел «пропавший ответ» в браузере). */
        if (flags & TCP_RST) {
            /* Сессия 53: КТО сбросил соединение. TTL подсказывает
             * источник: ~64 — наша же сеть (роутер/фильтр/локальная
             * машина), заметно меньше — интернет-хост за NAT. */
            {
                extern void serial_puts(const char *);
                char ipb[20], msg[96];
                net_ntoa(src_ip, ipb, sizeof(ipb));
                snprintf(msg, sizeof(msg),
                         "[tcp] RST from %s ttl=%u (%08x:%u)\n",
                         ipb, ip->ttl, (unsigned)src_ip, (unsigned)src_port);
                serial_puts(msg);
            }
            s->was_reset = 1;
            s->retrans_len = 0;
            /* сессия 56: запомнить источник для net_tcp_rst_info() */
            s->rst_ip = src_ip;
            s->rst_port = src_port;
            s->rst_ttl = ip->ttl;
            s->state = TCP_CLOSED;
            return;
        }

        switch (s->state) {
            case TCP_SYN_SENT:
                /* Wait for SYN-ACK */
                if ((flags & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK)) {
                    s->ack = seq + 1;
                    /* Parse peer's options */
                    if (opts_len > 0) parse_tcp_options(opts, opts_len, s);
                    /* Send ACK */
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;  /* SYN-ACK received */
                } else if (flags & TCP_RST) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_SYN_RECEIVED:
                /* Wait for ACK to complete 3-way handshake */
                if (flags & TCP_ACK) {
                    s->state = TCP_ESTABLISHED;
                    s->retransmit_seq = 0;
                    /* Call accept callback */
                    for (int li = 0; li < NET_MAX_TCP_LISTEN; li++) {
                        if (g_tcp_listens[li].in_use &&
                            g_tcp_listens[li].port == dst_port &&
                            g_tcp_listens[li].cb) {
                            g_tcp_listens[li].cb(i, src_ip, src_port);
                            break;
                        }
                    }
                    /* If data came with the ACK, process it */
                    if (data_len > 0) {
                        s->ack = seq + data_len;
                        if (s->recv_cb)
                            s->recv_cb(i, src_ip, src_port, data, data_len);
                        else if (g_tcp_recv_cb)
                            g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                return;
            case TCP_ESTABLISHED:
                /* Clear retransmit on ACK */
                if ((flags & TCP_ACK) && s->retransmit_seq != 0 &&
                    ack >= s->retransmit_seq) {
                    s->retransmit_seq = 0;
                    s->retransmit_count = 0;
                    s->retrans_len = 0;   /* FIX [TCP-R1]: данные подтверждены */
                }
                if (data_len > 0) {
                    /* FIX [T-ord]: приём ТОЛЬКО сегментов по порядку.
                     * Раньше принимался ЛЮБОЙ сегмент: повторная передача
                     * сервера (наш ACK потерялся — обычное дело на реальной
                     * сети) продублировала данные в буфер HTTP-клиента,
                     * а дыра в последовательности пропускалась молча —
                     * браузер получал битый ответ. Теперь:
                     *   seq == s->ack         — новый сегмент, принять;
                     *   seq+len <= s->ack     — старый дубль, повторный ACK;
                     *   seq > s->ack          — дыра, ACK текущего
                     *                           (сервер перешлёт сегмент). */
                    if (seq == s->ack) {
                        s->ack = seq + data_len;
                        if (s->recv_cb)
                            s->recv_cb(i, src_ip, src_port, data, data_len);
                        else if (g_tcp_recv_cb)
                            g_tcp_recv_cb(i, src_ip, src_port, data, data_len);
                        /* Send ACK */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    } else {
                        /* дубль или дыра — подтверждаем текущий ack */
                        tcp_send_segment(s, TCP_ACK, NULL, 0);
                    }
                }
                if (flags & TCP_FIN) {
                    /* FIN: подтверждаем только ВПЕРЁД (если FIN-сегмент
                     * оказался дублем, ack не должен откатываться назад) */
                    u32 fin_ack = seq + data_len + 1;
                    if (fin_ack > s->ack) s->ack = fin_ack;
                    tcp_send_segment(s, TCP_ACK | TCP_FIN, NULL, 0);
                    s->state = TCP_LAST_ACK;
                    s->seq += 1;
                }
                return;
            case TCP_FIN_WAIT_1:
                /* Got ACK for our FIN? */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_FIN_WAIT_2;
                }
                if (flags & TCP_FIN) {
                    s->ack = seq + data_len + 1;
                    tcp_send_segment(s, TCP_ACK, NULL, 0);
                    s->state = TCP_TIME_WAIT;
                    /* No TIME_WAIT duration in this simple impl — close */
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            case TCP_LAST_ACK:
                /* Wait for ACK of our FIN */
                if ((flags & TCP_ACK) && ack == s->seq) {
                    s->state = TCP_CLOSED;
                    s->in_use = 0;
                }
                return;
            default:
                return;
        }
    }
    /* No matching socket — if SYN, send RST (we don't accept incoming connections) */
    if (flags & TCP_SYN) {
        /* Send RST */
        net_tcp_socket_t tmp;
        memset(&tmp, 0, sizeof(tmp));
        tmp.local_ip = g_net.ip;
        tmp.local_port = dst_port;
        tmp.remote_ip = src_ip;
        tmp.remote_port = src_port;
        tmp.seq = 0;
        tmp.ack = seq + (data_len > 0 ? data_len : 0) + ((flags & (TCP_SYN | TCP_FIN)) ? 1 : 0);
        tcp_send_segment(&tmp, TCP_RST | TCP_ACK, NULL, 0);
    }
    /* FIX (сессия 57): RST, к которому НЕ нашлось сокета, раньше молча
     * игнорировался — «connection refused» в логе выглядел беспричинным
     * (RST приходил, но его источник/порт не совпадали с 4-tuple нашего
     * сокета: чужой MAC в ARP-кэше, ротация портов, RST от роутера/точки
     * доступа). Теперь видно КТО и КУДА шлёт сброс — сравниваем с dst
     * из строки «[tcp] connect». */
    else if (flags & TCP_RST) {
        extern void serial_puts(const char *);
        char ipb[20], msg[112];
        net_ntoa(src_ip, ipb, sizeof(ipb));
        snprintf(msg, sizeof(msg),
                 "[tcp] RST from %s:%u ttl=%u — нет сокета (несовпал 4-tuple)\n",
                 ipb, (unsigned)src_port, (unsigned)ip->ttl);
        serial_puts(msg);
    }
}
