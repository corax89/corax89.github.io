/* gdt.c — Инициализация GDT (Null, Code, Data) 
 * Используем pushl + lret для безопасной перезагрузки CS в MinGW */
#include "gdt.h"
#include "types.h"

/* Структура дескриптора GDT (ровно 8 байт) */
typedef struct {
    u16 limit_low;
    u16 base_low;
    u8  base_middle;
    u8  access;
    u8  granularity;
    u8  base_high;
} __attribute__((packed)) gdt_entry_t;

/* Таблица GDT на 3 записи */
static gdt_entry_t gdt[3];

void gdt_init(void)
{
    /* Локальная packed-структура для команды lgdt (защита от выравнивания) */
    struct {
        u16 limit;
        u32 base;
    } __attribute__((packed)) gp;

    gp.limit = (u16)(sizeof(gdt) - 1);
    gp.base  = (u32)(unsigned long)gdt;

    /* 0x00: Null Descriptor */
    gdt[0].limit_low   = 0; gdt[0].base_low    = 0;
    gdt[0].base_middle = 0; gdt[0].access      = 0;
    gdt[0].granularity = 0; gdt[0].base_high   = 0;

    /* 0x08: Kernel Code Segment (Лимит 4 ГБ, 32-бит) */
    gdt[1].limit_low   = 0xFFFF; gdt[1].base_low    = 0;
    gdt[1].base_middle = 0;      gdt[1].access      = 0x9A;
    gdt[1].granularity = 0xCF;   gdt[1].base_high   = 0; /* 0xCF = 4K гранулярность + 32-бит + лимит 0xF */

    /* 0x10: Kernel Data Segment (Лимит 4 ГБ, 32-бит) */
    gdt[2].limit_low   = 0xFFFF; gdt[2].base_low    = 0;
    gdt[2].base_middle = 0;      gdt[2].access      = 0x92;
    gdt[2].granularity = 0xCF;   gdt[2].base_high   = 0;

    /* 
     * БЕЗОПАСНАЯ ЗАГРУЗКА GDT И ПЕРЕЗАГРУЗКА СЕГМЕНТОВ:
     * 1. lgdt загружает таблицу.
     * 2. Обновляем регистры данных (DS, ES, FS, GS, SS).
     * 3. Используем pushl + lret вместо ljmp для обновления CS.
     *    Это обходит баги MinGW и гарантирует применение лимита 4 ГБ.
     */
    __asm__ __volatile__(
        "lgdt %0\n\t"             /* Загружаем GDT */
        "mov $0x10, %%ax\n\t"     /* Селектор данных = 0x10 */
        "mov %%ax, %%ds\n\t"
        "mov %%ax, %%es\n\t"
        "mov %%ax, %%fs\n\t"
        "mov %%ax, %%gs\n\t"
        "mov %%ax, %%ss\n\t"
        "pushl $0x08\n\t"         /* Селектор кода = 0x08 в стек */
        "pushl $1f\n\t"           /* Адрес следующей метки в стек */
        "lret\n\t"                /* Дальний возврат: обновляет CS и EIP */
        "1:\n\t"                  /* Метка, куда мы прыгаем */
        : 
        : "m"(gp)                 /* Ограничение "m" читает структуру прямо из памяти */
        : "eax", "memory"
    );
}