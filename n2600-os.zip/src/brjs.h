/* brjs.h — JavaScript в браузере N2600-OS (Task 47). Header-only:
 * включается из mquickjs_api.c (ядро, ДО таблицы стдлиба — тела
 * js_br_* нужны c_function_table) и из хост-теста.
 *
 * Что даёт странице (поверх стандартной библиотеки MicroQuickJS):
 *   document.write(html)        — дописать HTML в страницу (вставляется
 *                                 на месте скрипта после его завершения);
 *   document.title              — чтение/запись (браузер забирает после);
 *   document.location.href      — адрес страницы (чтение);
 *   document.getElementById(id) — снимок поля формы: {id, value, type,
 *                                 name} (plain object, НЕ живой);
 *   document.setFieldValue(id, v) — записать значение поля обратно
 *                                 (текст/textarea; "1"/"true" у checkbox
 *                                 ставит галочку). Компенсация отсутствия
 *                                 в mquickjs C-аксессоров свойств;
 *   alert(text)                 — текст попадает в статус-строку браузера;
 *   fetch(url) / httpGet(url)   — СИНХРОННЫЙ GET (страница грузится в
 *                                 потоке окна — блокирует только его).
 *                                 Возвращает тело строкой, при ошибке —
 *                                 исключение. Отличие от стандарта:
 *                                 без Promise (в движке нет событийного
 *                                 цикла);
 *   setTimeout/clearTimeout     — заглушки (нет событийного цикла).
 *
 * onclick/js-атрибуты и javascript:-ссылки исполняются тем же контекстом
 * (brjs_eval после загрузки страницы). Дедлайн eval — защита от
 * зависших скриптов (окно живо, скрипт прерывается исключением).
 *
 * Привязка нативов: движок создаёт C-функции ТОЛЬКО по индексам
 * скомпилированной c_function_table (см. mqjs_stdlib_os.h, добавленные
 * в конце записи) — brjs_start() принимает базовый индекс и привязывает
 * функции к глобальному объекту по именам через JS_SetPropertyStr.
 *
 * Память: собственный пул (BRJS_POOL) с канарейками; порча пула ->
 * raw-free без JS_FreeContext (политика mquickjs_api.c). */
#ifndef BRJS_H
#define BRJS_H

#include "mquickjs.h"
#include "brform.h"

#ifdef HOST_TEST
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
unsigned int brjs_host_ticks(void);
int brjs_host_stack_range(unsigned int *lo, unsigned int *hi);
#define BRJS_TICKS()           brjs_host_ticks()
#define BRJS_STACK_RANGE(lo, hi) brjs_host_stack_range(lo, hi)
#define BRJS_YIELD()           ((void)0)
#else
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#define BRJS_TICKS()           timer_ticks()
#define BRJS_STACK_RANGE(lo, hi) task_stack_range(lo, hi)
#define BRJS_YIELD()           task_yield()
#endif

#ifndef NULL
#define NULL ((void *)0)
#endif

#ifndef HOST_TEST
extern void serial_puts(const char *s);   /* Task 67 [JS-CONSOLE]: лог в serial */
#endif

#define BRJS_POOL       (256u * 1024u)   /* основной пул контекста */
#define BRJS_GROW_CHUNK (64u * 1024u)    /* сегменты динамического роста */
#define BRJS_GROW_MAX   (512u * 1024u)
#define BRJS_WBUF_MAX   16384            /* буфер document.write */
#define BRJS_EVAL_MS    3000u            /* дедлайн одного eval */
/* Task 66 [BRJS-FETCH64]: было 16 КиБ — практически любой внешний скрипт
 * современного сайта больше; обрезанный код гарантированно давал
 * «syntax error». 64 КиБ = бюджет сборки одного скрипта (BRJ_CODE_MAX),
 * больший объём всё равно не исполняется. */
#define BRJS_FETCH_MAX  65536

/* Task 67 [JS-TIMER]: догоняющие setTimeout-колбэки. Очередь — значения
 * functions, ЗАКОРЕНЁННЫЕ через JSGCRef (как в mquickjs_api.c). Полноценный
 * событийный цикл в браузере по-прежнему отсутствует: все КОЛБЭКИ,
 * поставленные скриптом страницы, исполняются в конце brjs_eval
 * (brjs_timers_run) — «отложенная инициализация после DOM-ready»
 * покрывает большинство реальных скриптов. */
#define BRJS_TIMERS_MAX 16
#define BRJS_TIMER_MS_MAX 60000       /* задержка ограничена минутой */
#define BRJS_TIMER_RUN_MAX 64         /* не более колбэков за один догон */
#define BRJS_TIMER_BUDGET_MS 2000u    /* общий бюджет догоняющего прогона */

typedef struct {
    /* — предоставляется браузером — */
    void       *forms;             /* brf_forms_t* */
    /* Task 67 [JS-URLCPY]: прежний const char* page_url был АЛИАСОМ на
     * b->url браузера: копия безопаснее — строка гарантированно не
     * «оживает» под другим адресом при перезаписи буфера страницы. */
    char        page_url[BRF_URL_MAX];
    /* document.write (raw HTML; конвертирует браузер после eval) */
    char        wbuf_static[BRJS_WBUF_MAX];
    int         wlen;
    int         wovf;              /* буфер переполнялся */
    /* alert */
    char        alert[96];
    int         alert_n;
    /* Task 67 [JS-CONSOLE]: последнее сообщение console.* (для статуса)
     * и общее число сообщений (полный лог идёт в serial) */
    char        console_last[96];
    int         console_n;
    /* синхронный GET (браузер даёт колбэк: URL разрешает сам) */
    int  (*fetch_fn)(void *ud, const char *url, char *out, int out_max);
    void       *fetch_ud;
    char        fetch_err[48];
    /* — внутреннее — */
    JSContext  *ctx;
    void       *pool;              /* пул + канарейки вокруг */
    u32         pool_size;
    u32         deadline;          /* тик дедлайна текущего eval */
    int         timed_out;         /* 1 = текущий eval прерван по таймауту */
    char        last_err[96];      /* сообщение исключения (для статуса) */
    char        title[64];         /* document.title после eval */
    /* FIX [JS-NAV]: навигация из скрипта (location.href=, location=,
     * location.replace/assign, window.location.*, document.location=).
     * brjs_eval после каждого eval сравнивает href с page_url и кладёт
     * новый адрес сюда; браузер делает переход. */
    char        nav_url[BRF_URL_MAX];
    int         nav_pending;
    /* Task 67 [JS-TIMER]: очередь setTimeout */
    struct {
        JSGCRef fn;                /* закоренённая функция */
        u32     when;              /* тик исполнения */
        int     used;
    } timers[BRJS_TIMERS_MAX];
    int         alive;
} brjs_env_t;

/* ---------------- нативные функции (индексы c_function_table) ----------------
 * Порядок ОБЯЗАН совпадать с добавленными записями в mqjs_stdlib_os.h
 * и mqjs_stdlib_os64.h:
 *   0 br_write   1 br_getelem   2 br_setfield   3 br_alert
 *   4 br_fetch   5 br_stub      6 br_settimeout 7 br_cleartimeout
 *   8 br_console
 */
#define BRJS_FN_WRITE     0
#define BRJS_FN_GETELEM   1
#define BRJS_FN_SETFIELD  2
#define BRJS_FN_ALERT     3
#define BRJS_FN_FETCH     4
#define BRJS_FN_STUB      5
#define BRJS_FN_SETTIMEOUT 6
#define BRJS_FN_CLEARTIMEOUT 7
#define BRJS_FN_CONSOLE   8
#define BRJS_FN_COUNT     9

static JSValue js_br_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_getelem(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_setfield(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_alert(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_fetch(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_stub(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_settimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_cleartimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_br_console(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);

/* Тела js_br_* реально используются только в TU таблицы c_function_table
 * (mquickjs_api.c: brjs.h включается ДО mqjs_stdlib_os*.h). В прочих
 * включениях (apps_browser.c) они не используются — гасим
 * -Wunused-function атрибутом (безвреден и для использующего TU). */
#define BRJS_FN_UNUSED __attribute__((unused))

static int brjs_interrupt(JSContext *ctx, void *opaque)
{
    (void)ctx;                    /* сигнатура движка; дедлайн — через opaque */
    brjs_env_t *e = (brjs_env_t *)opaque;
    BRJS_YIELD();
    if (e && e->deadline && BRJS_TICKS() > e->deadline) {
        e->timed_out = 1;
        return 1;                    /* движок бросит исключение */
    }
    return 0;
}

static void *brjs_heap_alloc(size_t size)
{
    return malloc((u32)size);
}

static void brjs_heap_free(void *p)
{
    free(p);
}

/* ---------------- нативы ---------------- */

static brjs_env_t *brjs_env(JSContext *ctx)
{
    return (brjs_env_t *)JS_GetContextOpaque(ctx);
}

static BRJS_FN_UNUSED JSValue js_br_write(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    for (int i = 0; i < argc; i++) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, argv[i], &sb);
        if (!s) return JS_EXCEPTION;
        if (e->wlen + (int)sl >= BRJS_WBUF_MAX - 1) {
            e->wovf = 1;
        } else {
            memcpy(e->wbuf_static + e->wlen, s, sl);
            e->wlen += (int)sl;
            e->wbuf_static[e->wlen] = 0;
        }
    }
    return JS_UNDEFINED;
}

static brf_field_t *brjs_field_by_id(brjs_env_t *e, const char *id)
{
    brf_forms_t *f = (brf_forms_t *)e->forms;
    if (!f || !id || !id[0]) return NULL;
    for (int i = 0; i < f->nfields; i++) {
        brf_field_t *fl = &f->fields[i];
        if (!strcmp(fl->id, id) || !strcmp(fl->name, id))
            return fl;
    }
    return NULL;
}

static BRJS_FN_UNUSED JSValue js_br_getelem(JSContext *ctx, JSValue *this_val,
                             int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 1) return JS_NULL;
    size_t sl = 0;
    JSCStringBuf sb;
    const char *id = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
    if (!id) return JS_EXCEPTION;
    brf_field_t *fl = brjs_field_by_id(e, id);
    if (!fl) return JS_NULL;
    JSValue o = JS_NewObject(ctx);
    if (JS_IsException(o)) return o;
    JS_SetPropertyStr(ctx, o, "id", JS_NewString(ctx, fl->id));
    JS_SetPropertyStr(ctx, o, "name", JS_NewString(ctx, fl->name));
    JS_SetPropertyStr(ctx, o, "type", JS_NewString(ctx, fl->type));
    JS_SetPropertyStr(ctx, o, "value", JS_NewString(ctx, fl->value));
    return o;
}

static BRJS_FN_UNUSED JSValue js_br_setfield(JSContext *ctx, JSValue *this_val,
                              int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 2) return JS_UNDEFINED;
    size_t il = 0, vl = 0;
    JSCStringBuf sb1, sb2;
    const char *id = JS_ToCStringLen(ctx, &il, argv[0], &sb1);
    const char *val = JS_ToCStringLen(ctx, &vl, argv[1], &sb2);
    if (!id || !val) return JS_EXCEPTION;
    brf_field_t *fl = brjs_field_by_id(e, id);
    if (!fl) return JS_UNDEFINED;
    if (!strcmp(fl->type, "checkbox") || !strcmp(fl->type, "radio")) {
        fl->checked = (!strcmp(val, "1") || !strcmp(val, "true") ||
                       !strcmp(val, "checked") || !strcmp(val, "on"));
    } else if (!strcmp(fl->type, "select")) {
        /* выбрать вариант по value или label */
        for (int i = 0; i < fl->nopts; i++) {
            if (!strcmp(fl->opts[i], val)) { fl->opt_sel = i; break; }
        }
    } else {
        strncpy(fl->value, val, sizeof(fl->value) - 1);
        fl->value[sizeof(fl->value) - 1] = 0;
    }
    return JS_UNDEFINED;
}

static BRJS_FN_UNUSED JSValue js_br_alert(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc >= 1) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
        if (s) {
            strncpy(e->alert, s, sizeof(e->alert) - 1);
            e->alert[sizeof(e->alert) - 1] = 0;
            e->alert_n++;
        }
    }
    return JS_UNDEFINED;
}

static BRJS_FN_UNUSED JSValue js_br_fetch(JSContext *ctx, JSValue *this_val,
                           int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 1 || !e->fetch_fn)
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch: нет адреса/канала");
    size_t sl = 0;
    JSCStringBuf sb;
    const char *url = JS_ToCStringLen(ctx, &sl, argv[0], &sb);
    if (!url || !url[0])
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch: пустой адрес");

    char *resp = (char *)malloc(BRJS_FETCH_MAX + 1);
    if (!resp)
        return JS_ThrowOutOfMemory(ctx);
    int n = e->fetch_fn(e->fetch_ud, url, resp, BRJS_FETCH_MAX);
    if (n < 0) {
        free(resp);
        return JS_ThrowError(ctx, JS_CLASS_ERROR, "fetch failed: %s",
                             e->fetch_err[0] ? e->fetch_err : "ошибка сети");
    }
    JSValue r = JS_NewStringLen(ctx, resp, (size_t)n);
    free(resp);
    return r;
}

static BRJS_FN_UNUSED JSValue js_br_stub(JSContext *ctx, JSValue *this_val,
                          int argc, JSValue *argv)
{
    (void)this_val;
    (void)argc;
    (void)argv;
    (void)ctx;
    return JS_UNDEFINED;      /* setTimeout/clearTimeout — заглушки */
}

/* Task 67 [JS-TIMER]: setTimeout(fn, ms) — колбэк встаёт в очередь и
 * исполняется в конце текущего brjs_eval (brjs_timers_run). Возвращает
 * id (для clearTimeout). Раньше — пустышка: `setTimeout(fn,0)` для
 * отложенной инициализации НЕ ВЫПОЛНЯЛСЯ вовсе (формы, lazy-load,
 * DOM-ready-хуки молча пропадали). */
static BRJS_FN_UNUSED JSValue js_br_settimeout(JSContext *ctx, JSValue *this_val,
                                int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    if (argc < 1 || !JS_IsFunction(ctx, argv[0]))
        return JS_ThrowTypeError(ctx, "setTimeout: not a function");
    u32 delay = 0;
    if (argc >= 2 && JS_IsNumber(ctx, argv[1])) {
        double d = 0;
        if (!JS_ToNumber(ctx, &d, argv[1]) && d > 0)
            delay = (u32)d;
    }
    if (delay > BRJS_TIMER_MS_MAX) delay = BRJS_TIMER_MS_MAX;
    for (int i = 0; i < BRJS_TIMERS_MAX; i++) {
        if (e->timers[i].used) continue;
        JSValue *p = JS_AddGCRef(ctx, &e->timers[i].fn);
        if (!p) return JS_ThrowOutOfMemory(ctx);
        *p = argv[0];
        e->timers[i].when = BRJS_TICKS() + delay;
        e->timers[i].used = 1;
        return JS_NewInt32(ctx, i + 1);
    }
    return JS_ThrowInternalError(ctx, "setTimeout: слишком много таймеров");
}

static BRJS_FN_UNUSED JSValue js_br_cleartimeout(JSContext *ctx, JSValue *this_val,
                                  int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    int id = -1;
    if (argc >= 1 && JS_IsNumber(ctx, argv[0])) {
        double d = -1;
        if (!JS_ToNumber(ctx, &d, argv[0])) id = (int)d;
    }
    if (id >= 1 && id <= BRJS_TIMERS_MAX && e->timers[id - 1].used) {
        JS_DeleteGCRef(ctx, &e->timers[id - 1].fn);
        e->timers[id - 1].used = 0;
    }
    return JS_UNDEFINED;
}

/* Task 67 [JS-CONSOLE]: console.log/warn/error/info. Прежде console был
 * undefined — ЛЮБОЙ лог-вызов в скрипте давал ReferenceError и УБИВАЛ
 * скрипт (а логи есть в 90% реального кода). Последнее сообщение хранится
 * в env (браузер может показать в статусе), полный лог — в serial. */
static BRJS_FN_UNUSED JSValue js_br_console(JSContext *ctx, JSValue *this_val,
                             int argc, JSValue *argv)
{
    brjs_env_t *e = brjs_env(ctx);
    (void)this_val;
    if (!e) return JS_ThrowInternalError(ctx, "no env");
    for (int i = 0; i < argc && i < 3; i++) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, argv[i], &sb);
        if (!s || !s[0]) continue;
        if (i == 0) {
            strncpy(e->console_last, s, sizeof(e->console_last) - 1);
            e->console_last[sizeof(e->console_last) - 1] = 0;
        }
        e->console_n++;
#ifdef HOST_TEST
        fprintf(stderr, "[js-console] %s\n", s);
#else
        serial_puts("[js-console] ");
        serial_puts(s);
        serial_puts("\n");
#endif
    }
    return JS_UNDEFINED;
}

/* Исполнить ПОГАЖЕННЫЕ колбэки setTimeout (вызывается в конце brjs_eval).
 * Новые таймеры, поставленные самими колбэками, тоже догоняются —
 * до исчерпания очереди, лимита вызовов или бюджета времени. Ошибки
 * внутри колбэков глотаются (скрипт уже отработал; здесь только догон). */
static BRJS_FN_UNUSED void brjs_timers_run(brjs_env_t *e)
{
    if (!e->alive || !e->ctx) return;
    u32 budget_end = BRJS_TICKS() + BRJS_TIMER_BUDGET_MS;
    int ran = 0;
    for (;;) {
        int idx = -1;
        u32 now = BRJS_TICKS();
        if (ran >= BRJS_TIMER_RUN_MAX || now > budget_end) break;
        for (int i = 0; i < BRJS_TIMERS_MAX; i++) {
            if (e->timers[i].used && (u32)(now - e->timers[i].when) < 0x80000000u)
                { idx = i; break; }          /* when <= now (без гонок u32) */
        }
        if (idx < 0) break;
        JSValue fn = e->timers[idx].fn.val;
        JS_DeleteGCRef(e->ctx, &e->timers[idx].fn);
        e->timers[idx].used = 0;
        if (JS_StackCheck(e->ctx, 3)) {
            JS_GetException(e->ctx);         /* стек переполнен — теряем */
            continue;
        }
        JS_PushArg(e->ctx, fn);              /* func */
        JS_PushArg(e->ctx, JS_NULL);         /* this */
        JSValue ret = JS_Call(e->ctx, 0);
        if (JS_IsException(ret)) {
            JSValue ex = JS_GetException(e->ctx);   /* проглотить */
            (void)ex;
        }
        ran++;
    }
}

/* Снять ВСЕ таймеры (смена страницы: колбэки старого скрипта более
 * недействительны). Вызывается из brjs_set_page_url. */
static BRJS_FN_UNUSED void brjs_timers_clear(brjs_env_t *e)
{
    if (!e->alive || !e->ctx) return;
    for (int i = 0; i < BRJS_TIMERS_MAX; i++) {
        if (e->timers[i].used) {
            JS_DeleteGCRef(e->ctx, &e->timers[i].fn);
            e->timers[i].used = 0;
        }
    }
}

/* ---------------- запуск/останов ---------------- */

/* Задать адрес страницы ПОСЛЕ brjs_start (brjs_start делает memset
 * окружения — page_url до него задать нельзя). Обновляет location.*:
 * href + Task 67 [JS-LOC] search/hash/pathname/host/hostname/protocol —
 * многие скрипты роутятся по location.search/pathname. Таймеры старой
 * страницы снимаются ([JS-TIMER]: колбэки прежнего скрипта недействительны).
 * Строка маршрутизируется через GCRef (JS_SetPropertyStr может аллоцировать
 * рост таблицы свойств — незакоренённая строка была бы собрана GC). */
static BRJS_FN_UNUSED void brjs_set_page_url(brjs_env_t *e, const char *url)
{
    if (!e->alive || !e->ctx) return;
    /* Task 67 [JS-URLCPY]: копия (был алиас на b->url браузера) */
    strncpy(e->page_url, url ? url : "", sizeof(e->page_url) - 1);
    e->page_url[sizeof(e->page_url) - 1] = 0;

    /* Task 67 [JS-LOC]: разбор href на компоненты (наивно, без punycode) */
    char protocol[16] = "", hostname[128] = "", port[8] = "";
    char pathname[BRF_URL_MAX] = "/", search[160] = "", hash[80] = "";
    {
        const char *p = e->page_url;
        const char *cs = strstr(p, "://");
        if (cs) {
            int n = (int)(cs - p);
            if (n > 0 && n < (int)sizeof(protocol) - 1) {
                memcpy(protocol, p, (size_t)n);
                protocol[n] = 0;
            }
            p = cs + 3;
            int hn = 0;
            while (*p && *p != '/' && *p != '?' && *p != '#' &&
                   hn < (int)sizeof(hostname) - 1)
                hostname[hn++] = *p++;
            hostname[hn] = 0;
            /* порт отделить от хоста */
            char *colon = strchr(hostname, ':');
            if (colon) {
                strncpy(port, colon + 1, sizeof(port) - 1);
                port[sizeof(port) - 1] = 0;
                *colon = 0;
            }
        }
        /* путь: от '/' до '?'/ '#' */
        if (*p == '/') {
            int pn = 0;
            while (*p && *p != '?' && *p != '#' &&
                   pn < (int)sizeof(pathname) - 1)
                pathname[pn++] = *p++;
            pathname[pn] = 0;
        }
        const char *q = strchr(p, '?');
        const char *hh = strchr(p, '#');
        if (q && (!hh || q < hh)) {
            int sn = 0;
            for (const char *t = q; *t && *t != '#' &&
                 sn < (int)sizeof(search) - 1; t++)
                search[sn++] = *t;
            search[sn] = 0;
        }
        if (hh) {
            strncpy(hash, hh, sizeof(hash) - 1);
            hash[sizeof(hash) - 1] = 0;
        }
    }

    brjs_timers_clear(e);

    {
        JSValue g = JS_GetGlobalObject(e->ctx);
        if (JS_IsException(g)) return;
        JSValue L = JS_GetPropertyStr(e->ctx, g, "location");
        if (JS_IsPtr(L)) {
            JSGCRef sv_ref;   /* макрос JS_PUSH_VALUE требует v##_ref */
            JSValue sv = JS_NewString(e->ctx, e->page_url);
            JS_PUSH_VALUE(e->ctx, sv);
            JS_SetPropertyStr(e->ctx, L, "href", sv);
            JS_POP_VALUE(e->ctx, sv);
            sv = JS_NewString(e->ctx, search);
            JS_PUSH_VALUE(e->ctx, sv);
            JS_SetPropertyStr(e->ctx, L, "search", sv);
            JS_POP_VALUE(e->ctx, sv);
            sv = JS_NewString(e->ctx, hash);
            JS_PUSH_VALUE(e->ctx, sv);
            JS_SetPropertyStr(e->ctx, L, "hash", sv);
            JS_POP_VALUE(e->ctx, sv);
            sv = JS_NewString(e->ctx, pathname);
            JS_PUSH_VALUE(e->ctx, sv);
            JS_SetPropertyStr(e->ctx, L, "pathname", sv);
            JS_POP_VALUE(e->ctx, sv);
            sv = JS_NewString(e->ctx, hostname);
            JS_PUSH_VALUE(e->ctx, sv);
            JS_SetPropertyStr(e->ctx, L, "hostname", sv);
            JS_POP_VALUE(e->ctx, sv);
            {
                char hostport[136];
                snprintf(hostport, sizeof(hostport), "%s%s%s", hostname,
                         port[0] ? ":" : "", port);
                sv = JS_NewString(e->ctx, hostport);
                JS_PUSH_VALUE(e->ctx, sv);
                JS_SetPropertyStr(e->ctx, L, "host", sv);
                JS_POP_VALUE(e->ctx, sv);
            }
            {
                char proto[18];
                snprintf(proto, sizeof(proto), "%s:", protocol);
                sv = JS_NewString(e->ctx, proto);
                JS_PUSH_VALUE(e->ctx, sv);
                JS_SetPropertyStr(e->ctx, L, "protocol", sv);
                JS_POP_VALUE(e->ctx, sv);
            }
        }
    }
}

/* Создать контекст и привязать глобальные объекты. cfunc_base — индекс
 * первой из BRJS_FN_COUNT записей brjs в c_function_table (см.
 * mqjs_stdlib_os.h / mqjs_br_cfunc_base()). 0 = успех. */
static BRJS_FN_UNUSED int brjs_start(brjs_env_t *e, const JSSTDLibraryDef *stdlib,
                      int cfunc_base)
{
    memset(e, 0, sizeof(*e));
    /* Task 51 [BRJS-CANARY]: раньше маллочилось BRJS_POOL + 4*16 — запас
     * только под ОДНУ канарейку (64 Б), а писались ОБЕ (pre перед пулом и
     * post СРАЗУ ЗА КОНЦОМ блока): 64 байта ЗА ГРАНИЦЕЙ аллокации на
     * КАЖДОМ brjs_start — порча заголовка соседнего блока кучи (в логах
     * это «ПОРЧА КУЧИ: блок size=0» и каскад «нет памяти» после страниц
     * с JS). Эталонный расчёт — mqjs_sess_alloc_pool: size + 2*16*4. */
    e->pool_size = BRJS_POOL + 8 * 16;      /* + канарейки с ОБОИХ краёв */
    e->pool = malloc(e->pool_size);
    if (!e->pool) return -1;

    /* канарейки (16 слов с каждой стороны пула) — как в mquickjs_api */
    u32 *pre = (u32 *)e->pool;
    u8 *mem = (u8 *)e->pool + 64;
    u32 *post = (u32 *)(mem + BRJS_POOL);
    for (int i = 0; i < 16; i++) {
        pre[i] = 0xB5F0CAFEu;
        post[i] = 0xB5F0CAFEu;
    }

    e->ctx = JS_NewContext(mem, BRJS_POOL, stdlib);
    if (!e->ctx) {
        free(e->pool);
        e->pool = NULL;
        return -1;
    }
    JS_EnableHeapGrowth(e->ctx, BRJS_GROW_CHUNK, BRJS_GROW_MAX,
                        brjs_heap_alloc, brjs_heap_free);
    JS_SetContextOpaque(e->ctx, e);
    JS_SetInterruptHandler(e->ctx, brjs_interrupt);
    {
        u32 lo = 0, hi = 0;
        if (BRJS_STACK_RANGE(&lo, &hi))
            JS_SetStackGuard(e->ctx, (void *)(unsigned long)(lo + 4096));
    }
    e->alive = 1;
    e->deadline = 0;

    /* привязать нативы и глобальные объекты */
    JSValue glob = JS_GetGlobalObject(e->ctx);
    if (JS_IsException(glob)) return -1;

    /* document */
    JSValue doc = JS_NewObject(e->ctx);
    if (!JS_IsException(doc)) {
        int idxs[3] = { BRJS_FN_WRITE, BRJS_FN_GETELEM, BRJS_FN_SETFIELD };
        const char *dn[3] = { "write", "getElementById", "setFieldValue" };
        for (int i = 0; i < 3; i++) {
            JSValue f = JS_NewCFunctionParams(e->ctx, cfunc_base + idxs[i],
                                              JS_UNDEFINED);
            if (!JS_IsException(f))
                JS_SetPropertyStr(e->ctx, doc, dn[i], f);
        }
        /* FIX [JS-NAV]: location — ОДИН объект и в document.location, и
         * в глобальной переменной location (раньше был только
         * document.location как объект с plain-свойством href —
         * присвоение href просто меняло строку, переход НЕ происходил,
         * а location/window были undefined: скрипт-редиректы падали с
         * ReferenceError). Начальный href="" — реальный адрес ставит
         * brjs_set_page_url() ПОСЛЕ start (см. выше: memset). После
         * eval браузер читает href обратно и сравнивает с page_url —
         * изменился => переход. */
        JSValue loc = JS_NewObject(e->ctx);
        if (!JS_IsException(loc)) {
            JS_SetPropertyStr(e->ctx, loc, "href",
                              JS_NewString(e->ctx, ""));
            JS_SetPropertyStr(e->ctx, doc, "location", loc);
            JS_SetPropertyStr(e->ctx, glob, "location", loc);
        }
        JS_SetPropertyStr(e->ctx, doc, "title", JS_NewString(e->ctx, ""));
        JS_SetPropertyStr(e->ctx, glob, "document", doc);
    }

    /* Task 67 [JS-NAVIG]: navigator.userAgent — фича-детекты сайта
     * (`navigator.userAgent.indexOf(...)`) падали с ReferenceError и
     * убивали скрипт. Честный User-Agent: маскироваться под десктопный
     * браузер НЕ будем (иначе сайты отдают тяжёлый ES6-код, который
     * движок всё равно не осилит). */
    {
        JSValue nav = JS_NewObject(e->ctx);
        if (!JS_IsException(nav)) {
            JS_SetPropertyStr(e->ctx, nav, "userAgent",
                              JS_NewString(e->ctx,
                                           "Mozilla/5.0 (N2600-OS) "
                                           "N2600/0.1"));
            JS_SetPropertyStr(e->ctx, nav, "language",
                              JS_NewString(e->ctx, "ru-RU"));
            JS_SetPropertyStr(e->ctx, nav, "platform",
                              JS_NewString(e->ctx, "N2600"));
            JS_SetPropertyStr(e->ctx, glob, "navigator", nav);
        }
    }

    /* Task 67 [JS-CONSOLE]: console.log/warn/error/info — один натив */
    {
        JSValue con = JS_NewObject(e->ctx);
        if (!JS_IsException(con)) {
            const char *mn[4] = { "log", "warn", "error", "info" };
            for (int i = 0; i < 4; i++) {
                JSValue f = JS_NewCFunctionParams(
                    e->ctx, cfunc_base + BRJS_FN_CONSOLE, JS_UNDEFINED);
                if (!JS_IsException(f))
                    JS_SetPropertyStr(e->ctx, con, mn[i], f);
            }
            JS_SetPropertyStr(e->ctx, glob, "console", con);
        }
    }

    /* FIX [JS-NAV]: window — синоним глобального объекта. В MicroQuickJS
     * `this` в глобальном eval НЕ глобал (проверено хост-тестом:
     * window.__m=42 не виден как глобал), поэтому только так. */
    JS_SetPropertyStr(e->ctx, glob, "window", glob);

    /* alert / fetch / httpGet; Task 67 [JS-TIMER]: setTimeout/clearTimeout
     * — РЕАЛЬНЫЕ нативы (колбэки исполняются в конце brjs_eval; раньше —
     * пустышка BRJS_FN_STUB, и отложенная инициализация скриптов молча
     * пропадала) */
    {
        struct { int idx; const char *name; } binds[] = {
            { BRJS_FN_ALERT, "alert" },
            { BRJS_FN_FETCH, "fetch" },
            { BRJS_FN_FETCH, "httpGet" },
            { BRJS_FN_SETTIMEOUT, "setTimeout" },
            { BRJS_FN_CLEARTIMEOUT, "clearTimeout" },
        };
        for (unsigned i = 0; i < sizeof(binds) / sizeof(binds[0]); i++) {
            JSValue f = JS_NewCFunctionParams(e->ctx,
                                              cfunc_base + binds[i].idx,
                                              JS_UNDEFINED);
            if (!JS_IsException(f))
                JS_SetPropertyStr(e->ctx, glob, binds[i].name, f);
        }
    }

    /* FIX [JS-NAV]: бустстрап — методы location.replace/assign
     * (приравнивают href; переход ловит послевычислительная проверка
     * href в brjs_eval). ВНИМАНИЕ: без String() — в MicroQuickJS вызов
     * String(u) возвращает undefined (проверено хост-тестом) и
     * location.href=undefined ломал replace. Ошибки бустстрапа не
     * критичны (без replace скрипт сработает через href). */
    /* Task 67 [JS-XHR]: XMLHttpRequest как обёртка над синхронным fetch()
     * (старые скрипты комментариев/простых форм). Полусинхронно:
     * onload/onreadystatechange вызываются ИЗ send() — без событийного
     * цикла иначе нельзя. readyState после send — 4.
     * ВНИМАНИЕ (проверено хост-тестом): в MicroQuickJS у ПОЛЬЗОВАТЕЛЬСКИХ
     * функций нет .prototype («typeof f.prototype» == undefined) —
     * классический prototype-шим невозможен, методы вешаются на ЭКЗЕМПЛЯР
     * внутри конструктора. */
    {
        static const char xhr_bootstrap[] =
            "location.replace=function(u){location.href=u;};"
            "location.assign=location.replace;"
            "function XMLHttpRequest(){"
            "this.readyState=0;this.status=0;this.responseText='';"
            "this.onload=null;this.onerror=null;this.onreadystatechange=null;"
            "this.open=function(m,u){this._u=u;this.readyState=1;};"
            "this.setRequestHeader=function(k,v){};"
            "this.getAllResponseHeaders=function(){return '';};"
            "this.abort=function(){};"
            "this.send=function(b){"
            "this.readyState=4;"
            "try{this.responseText=fetch(this._u);this.status=200;}"
            "catch(e){this.status=0;this.responseText='';"
            "if(this.onerror)this.onerror(e);}"
            "if(this.onload)this.onload();"
            "if(this.onreadystatechange)this.onreadystatechange();};}";
        JS_Eval(e->ctx, xhr_bootstrap,
                sizeof(xhr_bootstrap) - 1,
                "brjs-bootstrap", 0);
    }
    return 0;
}

/* Прочитать location-значение (строка или объект с href) в buf.
 * FIX [JS-NAV2] (Task 65): helper вместо дублированных веток — нужно
 * читать и ГЛОБАЛЬНЫЙ location, и document.location НЕЗАВИСИМО: скрипт
 * `document.location='/x/'` ПОДМЕНЯЕТ свойство document.location строкой
 * (глобальный объект location остаётся прежним, href == page_url), и
 * прежняя проверка `if (!nu[0])` (document.location смотрели ТОЛЬКО
 * если глобальный location пуст) такой переход теряла. */
static BRJS_FN_UNUSED void brjs_loc_read(JSContext *ctx, JSValue v,
                                         char *buf, int bufsz)
{
    buf[0] = 0;
    if (JS_IsString(ctx, v)) {
        size_t sl = 0;
        JSCStringBuf sb;
        const char *s = JS_ToCStringLen(ctx, &sl, v, &sb);
        if (s) {
            strncpy(buf, s, (size_t)bufsz - 1);
            buf[bufsz - 1] = 0;
        }
    } else if (JS_IsPtr(v)) {
        JSValue h = JS_GetPropertyStr(ctx, v, "href");
        if (JS_IsString(ctx, h)) {
            size_t sl = 0;
            JSCStringBuf sb;
            const char *s = JS_ToCStringLen(ctx, &sl, h, &sb);
            if (s) {
                strncpy(buf, s, (size_t)bufsz - 1);
                buf[bufsz - 1] = 0;
            }
        }
    }
}

/* Исполнить код (страницы/onclick/javascript:). 0 = ок, -1 = ошибка JS
 * (текст в e->last_err), -2 = прерван по дедлайну. */
static BRJS_FN_UNUSED int brjs_eval(brjs_env_t *e, const char *code, const char *name)
{
    if (!e->alive || !code || !code[0]) return 0;
    e->timed_out = 0;
    e->deadline = BRJS_TICKS() + BRJS_EVAL_MS;
    size_t len = strlen(code);
    JSValue r = JS_Eval(e->ctx, code, len, name ? name : "page", 0);
    e->deadline = 0;
    int rc = 0;
    if (e->timed_out) {
        snprintf(e->last_err, sizeof(e->last_err),
                 "JS прерван по таймауту (%u мс)", (unsigned)BRJS_EVAL_MS);
        rc = -2;
    } else if (JS_IsException(r)) {
        JSValue ex = JS_GetException(e->ctx);
        size_t sl = 0;
        JSCStringBuf sb;
        const char *msg = JS_IsNull(ex) ? NULL
                          : JS_ToCStringLen(e->ctx, &sl, ex, &sb);
        snprintf(e->last_err, sizeof(e->last_err), "JS: %s",
                 msg && msg[0] ? msg : "исключение");
        rc = -1;
    }
    /* Task 67 [JS-TIMER]: догоняющий прогон setTimeout-колбэков —
     * ДО чтения title/детекции навигации (колбэки могут писать title
     * и менять location — всё это должно попасть в проверки ниже). */
    brjs_timers_run(e);

    /* document.title -> env (браузер покажет в статусе) */
    {
        JSValue doc = JS_GetPropertyStr(e->ctx,
                                        JS_GetGlobalObject(e->ctx), "document");
        if (!JS_IsException(doc) && !JS_IsUndefined(doc)) {
            size_t tl = 0;
            JSCStringBuf sb;
            JSValue t = JS_GetPropertyStr(e->ctx, doc, "title");
            const char *ts = JS_ToCStringLen(e->ctx, &tl, t, &sb);
            if (ts) {
                strncpy(e->title, ts, sizeof(e->title) - 1);
                e->title[sizeof(e->title) - 1] = 0;
            }
        }
    }
    /* FIX [JS-NAV]/[JS-NAV2]: детекция навигации. location — строка
     * (присвоение location="URL") или объект (href/replace/assign);
     * document.location проверяется ВСЕГДА (см. brjs_loc_read):
     * присвоение document.location="URL" подменяет свойство строкой,
     * не трогая глобальный объект location. #фрагмент и отсутствие
     * изменений переходом не считаются. */
    if (!e->nav_pending) {
        char nu[BRF_URL_MAX];
        char nu_d[BRF_URL_MAX];
        nu[0] = 0;
        nu_d[0] = 0;
        {
            JSValue g = JS_GetGlobalObject(e->ctx);
            if (!JS_IsException(g)) {
                JSValue L = JS_GetPropertyStr(e->ctx, g, "location");
                brjs_loc_read(e->ctx, L, nu, (int)sizeof(nu));
                JSValue d = JS_GetPropertyStr(e->ctx, g, "document");
                if (JS_IsPtr(d)) {
                    JSValue dl = JS_GetPropertyStr(e->ctx, d, "location");
                    brjs_loc_read(e->ctx, dl, nu_d, (int)sizeof(nu_d));
                }
            }
        }
        const char *cand = NULL;
        if (nu[0] && nu[0] != '#' &&
            strcmp(nu, e->page_url) != 0)
            cand = nu;
        else if (nu_d[0] && nu_d[0] != '#' &&
                 strcmp(nu_d, e->page_url) != 0)
            cand = nu_d;
        if (cand) {
            strncpy(e->nav_url, cand, sizeof(e->nav_url) - 1);
            e->nav_url[sizeof(e->nav_url) - 1] = 0;
            e->nav_pending = 1;
        }
    }
    return rc;
}

/* Канарейки целы? 1 = да. */
static int brjs_pool_ok(brjs_env_t *e)
{
    if (!e->pool) return 1;
    u32 *pre = (u32 *)e->pool;
    u8 *mem = (u8 *)e->pool + 64;
    u32 *post = (u32 *)(mem + BRJS_POOL);
    for (int i = 0; i < 16; i++)
        if (pre[i] != 0xB5F0CAFEu || post[i] != 0xB5F0CAFEu)
            return 0;
    return 1;
}

/* Останов (порча пула -> raw-free, как в mquickjs_api). */
static BRJS_FN_UNUSED void brjs_stop(brjs_env_t *e)
{
    if (!e->alive) return;
    if (e->ctx && brjs_pool_ok(e)) {
        JS_FreeContext(e->ctx);
    }
    e->ctx = NULL;
    e->alive = 0;
    if (e->pool) free(e->pool);
    e->pool = NULL;
}

#endif /* BRJS_H */
