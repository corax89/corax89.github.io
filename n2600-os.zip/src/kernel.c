/* kernel.c — точка входа N2600-OS.
 *
 * Multiboot-заголовок (AOUT_KLUDGE + VIDEO_MODE) лежит в секции .text.mb —
 * в самом начале образа, поэтому GRUB находит его в первых 8 КиБ плоского
 * бинарника, собираемого MinGW. GRUB выставляет VESA-режим по полям
 * заголовка (1280x600x32 + запасные), включает защищённый режим и передаёт
 * управление на kstart.
 */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "gdt.h"
#include "idt.h"
#include "mem.h"
#include "timer.h"
#include "kbd.h"
#include "mouse.h"
#include "fb.h"
#include "wm.h"
#include "apps.h"
#include "string.h"
#include "kernel.h"
#include "ata.h"
#include "fat32.h"
#include "iso9660.h"
#include "ramfs.h"

/* Символы linker-скрипта: в C пишутся без ведущего подчёркивания
 * (COFF MinGW добавит его автоматически, совпадая с именами в скрипте). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------- multiboot-заголовок --------------------- */

void kstart(void);

#define MB_FLAGS (MB_FLAG_ALIGN | MB_FLAG_MEMINFO | MB_FLAG_VIDEO_MODE | MB_FLAG_AOUT_KLUDGE)

/* При флаге VIDEO_MODE GRUB2 читает из заголовка ещё 4 поля (байты 32..47):
 * mode_type (0 = фреймбуфер), width, height, depth. Именно они задают
 * желаемый видеорежим: GRUB попробует 1280x600x32, потом запасные. */
__attribute__((section(".text.mb"), used, aligned(4)))
static const u32 mb_header[12] = {
    MB_MAGIC,
    MB_FLAGS,
    (u32)(0u - (MB_MAGIC + MB_FLAGS)),
    (u32)(unsigned long)load_start,   /* header_addr */
    (u32)(unsigned long)load_start,   /* load_addr   */
    (u32)(unsigned long)load_end,     /* load_end_addr */
    (u32)(unsigned long)bss_end,      /* bss_end_addr */
    (u32)(unsigned long)kstart,       /* entry_addr  */
    0,                                /* mode_type: 0 = линейный фреймбуфер */
    1280,                             /* ширина (целевой режим панели) */
    600,                              /* высота */
    32                                /* глубина цвета */
};

/* ------------------------- входная точка ------------------------- */

/* Единственная asm-вставка потока управления: настраиваем стек и зовём C.
 * naked обязателен — нельзя допустить пролог с обращением к стеку до его настройки. */
__attribute__((naked, section(".text.ks"), used, noinline))
void kstart(void)
{
    __asm__ __volatile__(
        "movl $_stack_top, %esp\n"
        "pushl %ebx\n"      /* multiboot info */
        "pushl %eax\n"      /* magic */
        "call _kmain\n"
        "1:\n"
        "hlt\n"
        "jmp 1b");
}

/* ========================================================================
 * Отладка: COM1 (serial) + экран (после fb_init)
 * ======================================================================== */

/* ---------- COM1 ---------- */
#define COM1 0x3F8

static void serial_init(void)
{
    outb(COM1 + 1, 0x00);   /* отключить прерывания */
    outb(COM1 + 3, 0x80);   /* DLAB=1 */
    outb(COM1 + 0, 0x03);   /* делитель = 3 -> 38400 бод */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);   /* 8N1 */
    outb(COM1 + 2, 0xC7);   /* FIFO 14 байт, очистить */
    outb(COM1 + 4, 0x0B);   /* RTS/DSR */
}

void serial_putc(char c)
{
    while (!(inb(COM1 + 5) & 0x20)) { /* ждём THR empty */ }
    outb(COM1, (u8)c);
}

void serial_puts(const char *s)
{
    while (*s) {
        if (*s == '\n') serial_putc('\r');
        serial_putc(*s++);
    }
}

static void serial_puthex(u32 v)
{
    const char *d = "0123456789abcdef";
    serial_puts("0x");
    for (int i = 28; i >= 0; i -= 4) serial_putc(d[(v >> i) & 0xF]);
}

static void serial_putdec(i32 v)
{
    char buf[12]; int i = 0;
    if (v < 0) { serial_putc('-'); v = -v; }
    if (v == 0) { serial_putc('0'); return; }
    while (v && i < 11) { buf[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) serial_putc(buf[i]);
}

/* ---------- Экранный debug ---------- */

static int  dbg_y = 0;              /* текущая строка вывода на экране */
static u32  dbg_color_ok  = 0;      /* кэшируем цвета после fb_init */
static u32  dbg_color_err = 0;

/* Вывести строку одновременно в serial и на экран (если fb готов). */
static void dbg(const char *s)
{
    /* serial */
    serial_puts("[boot] ");
    serial_puts(s);
    serial_putc('\n');

    /* screen */
    if (fb_ready()) {
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_ok, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
}

/* Вывести ошибку (красным) */
static void dbg_err(const char *s)
{
    serial_puts("[ERR ] ");
    serial_puts(s);
    serial_putc('\n');

    if (fb_ready()) {
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_err, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
}

/* --------------------- аварийный вывод без графики --------------------- */

static void vga_fail(const char *msg)
{
    /* serial — первым делом, чтобы точно было видно */
    serial_puts("[FATAL] ");
    serial_puts(msg);
    serial_puts("\n");

    /* VGA-текст (если GRUB оставил режим в 03h — увидим; в VESA — нет) */
    volatile u16 *vt = (volatile u16 *)0xB8000;
    const char *m1 = "N2600-OS: NET VESA-FRAMEBUFERA (NUZHEN REZHIM 32bpp).";
    const char *m2 = "Prover'te grub.cfg: gfxmode + gfxpayload=keep";
    for (int i = 0; m1[i]; i++) vt[i] = 0x4F00u | (u8)m1[i];
    for (int i = 0; m2[i]; i++) vt[80 + i] = 0x4F00u | (u8)m2[i];

    /* QEMU debug port */
    for (const char *p = m1; *p; p++) outb(0xE9, (u8)*p);

    for (;;)
        hlt();
}

/* --------------------------- служебное --------------------------- */

static const mb_info_t *g_mbi = NULL;

const mb_info_t *mb_info(void) { return g_mbi; }

void sys_reboot(void)
{
    cli();
    for (u32 i = 0; i < 100000 && (inb(0x64) & 0x02); i++) {}
    outb(0x64, 0xFE);
    for (;;)
        hlt();
}

void sys_poweroff(void)
{
    cli();
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;)
        hlt();
}

/* ------------------------------ kmain ------------------------------ */

void kmain(u32 magic, const mb_info_t *mb)
{
    /* Первым делом — serial, чтобы поймать даже падение до gdt. */
    serial_init();
    serial_puts("\n\n=== N2600-OS boot ===\n");

    g_mbi = mb;

    dbg("kmain entered");
    if (magic != MB_BOOTLOADER_MAGIC) {
        vga_fail("bad multiboot magic");
        return;
    }
    dbg("multiboot magic ok");

    dbg("gdt_init...");      gdt_init();
    dbg("idt_init...");      idt_init();
    dbg("mem_init...");      mem_init(mb);

    /* Фреймбуфер поднимаем как можно раньше — нужен для экранной отладки.
     * mem_init уже отработал (fb_init использует malloc). */
    dbg("fb_init...");
    if (!fb_init(mb)) {
        vga_fail("no fb (fb_init failed)");
        return;
    }
    dbg_color_ok  = fb_rgb(0xFF, 0xFF, 0x00);
    dbg_color_err = fb_rgb(0xFF, 0x60, 0x60);

    {
        char buf[80];
        snprintf(buf, sizeof(buf), "fb: %ux%u, %u bpp, pitch %u",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 (unsigned)fb_bpp(), (unsigned)fb_pitch());
        dbg(buf);
    }

    dbg("fb_make_bg...");    fb_make_bg();

    /* =======================================================================
     * ЗАЩИТА: Аппаратное маскирование IRQ 14 и 15 (ATA Primary/Secondary)
     * 0xA1 - порт данных Slave PIC. Биты 6 и 7 отвечают за IRQ 14 и 15.
     * Устанавливаем их в 1, чтобы прерывания от диска физически не дошли до CPU.
     * ======================================================================= */
    outb(0xA1, inb(0xA1) | 0xC0);
    dbg("IRQ14/15 masked");

        /* ---------- ATA ---------- */
    dbg("ata_init...");
    {
        int r = ata_init();
        if (r) {
            char buf[80];
            if (ata_is_cdrom()) {
                snprintf(buf, sizeof(buf), "ata: CD-ROM detected (%s)", ata_model());
            } else {
                snprintf(buf, sizeof(buf), "ata: HDD present, %s, sectors=%u",
                         ata_model(), (unsigned)ata_sectors());
            }
            dbg(buf);
        } else {
            dbg_err("ata: NOT present (return 0)");
        }
    }

    /* ---------- FAT32 ---------- */
    dbg("fat32_init...");
    if (fat32_init())
        dbg("fat32: ready");
    else
        dbg_err("fat32: not found (return 0)");

    /* ---------- ISO9660 ---------- */
    dbg("iso9660_init...");
    if (iso9660_init())
        dbg("iso9660: ready");
    else
        dbg_err("iso9660: not found (return 0)");
	
	/* ---------- RAMFS ---------- */
	dbg("ramfs_init...");
	if (ramfs_init()) {
		char buf[80];
		snprintf(buf, sizeof(buf), "ramfs: ready, %u МиБ", 
				 (unsigned)(ramfs_total_space() / (1024 * 1024)));
		dbg(buf);
	} else {
		dbg_err("ramfs: init failed");
	}
    /* ---------- периферия ---------- */
    dbg("timer_init...");    timer_init(100);
    dbg("kbd_init...");      kbd_init();
    dbg("mouse_init...");    mouse_init();
    if (mouse_present())
        dbg("mouse: present");
    else
        dbg_err("mouse: not present");

    /* ---------- оконный менеджер ---------- */
    dbg("wm_init...");       wm_init();
    dbg("apps_open(2)...");  apps_open(2);   /* Терминал */
    dbg("apps_open(1)...");  apps_open(1);   /* Файлы */

    /* ---------- прерывания ---------- */
    dbg("irq setup...");
    mouse_install_irq();
    pic_unmask((u16)((1 << 0) | (1 << 1) | (1 << 2) | (1 << 12)));
    sti();
    dbg("irq on, entering main loop");

    /* главный цикл: события -> композитинг -> hlt до следующего прерывания */
    key_event_t ev;
    u32 last_half = 0;
    for (;;) {
        while (kbd_pop(&ev))
            wm_key(&ev);

        wm_mouse_poll();

        u32 t = timer_ticks();
        if (t / 50 != last_half) {   /* 2 раза в секунду */
            last_half = t / 50;
            wm_halfsec();
        }

        wm_frame();
        hlt();
    }
}