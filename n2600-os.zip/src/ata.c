/* ata.c — безопасный ATA PIO + ATAPI (CD-ROM) */
#include "ata.h"
#include "io.h"
#include "string.h"

extern void serial_puts(const char *s);

#define ATA_DATA    0x1F0
#define ATA_SECCNT  0x1F2
#define ATA_LBA0    0x1F3
#define ATA_LBA1    0x1F4
#define ATA_LBA2    0x1F5
#define ATA_DRIVE   0x1F6
#define ATA_CMD     0x1F7
#define ATA_STATUS  0x1F7
#define ATA_ALTSTAT 0x3F6

#define ST_BSY  0x80
#define ST_DRDY 0x40
#define ST_DRQ  0x08
#define ST_ERR  0x01
#define ST_DF   0x20

static int  present = 0;
static int  is_cdrom = 0;      /* 1 = ATAPI (CD-ROM/ISO), 0 = ATA (HDD) */
static u32  total_sectors = 0;
static char model[41];

#define TRY 200000

static void io_delay4(void) { for (int i = 0; i < 4; i++) (void)inb(ATA_ALTSTAT); }

static int wait_ready(void) {
    for (u32 i = 0; i < TRY; i++) {
        u8 s = inb(ATA_STATUS);
        if (s == 0x00 || s == 0xFF) return 0;
        if (s & (ST_ERR | ST_DF)) return -1;
        if (!(s & ST_BSY) && (s & ST_DRDY)) return 1;
    }
    return 0;
}

static int wait_drq(void) {
    for (u32 i = 0; i < TRY; i++) {
        u8 s = inb(ATA_STATUS);
        if (s == 0x00 || s == 0xFF) return 0;
        if (s & (ST_ERR | ST_DF)) return 0;
        if (!(s & ST_BSY) && (s & ST_DRQ)) return 1;
    }
    return 0;
}

static void copy_ident(char *dst, const u16 *src, int words) {
    int j = 0;
    for (int i = 0; i < words; i++) {
        dst[j++] = (char)(src[i] >> 8);
        dst[j++] = (char)(src[i] & 0xFF);
    }
    dst[j] = 0;
    while (j > 0 && (dst[j-1] == ' ' || dst[j-1] == 0)) dst[--j] = 0;
}

/* Проверка устройства на указанном порту и селекторе */
static int probe_drive(u16 base_port, u8 drive_sel) {
    outb(base_port + 0x206, 0x02); /* Маскируем IRQ */
    outb(base_port + 6, drive_sel);
    io_delay4();
    for (int i = 0; i < 4; i++) (void)inb(base_port + 7);
    
    u8 s = inb(base_port + 7);
    if (s == 0x00 || s == 0xFF) return 0;

    /* Проверяем сигнатуру ATAPI (CD-ROM) ДО отправки IDENTIFY */
    u8 lba_mid  = inb(base_port + 4);
    u8 lba_high = inb(base_port + 5);
    
    if (lba_mid == 0x14 && lba_high == 0xEB) {
        is_cdrom = 1;
        strcpy(model, "ATAPI CD-ROM");
        return 1; /* Это CD-ROM */
    }
    
    if (lba_mid != 0x00 || lba_high != 0x00) return 0;

    /* Отправляем IDENTIFY */
    outb(base_port + 2, 0);
    outb(base_port + 3, 0);
    outb(base_port + 4, 0);
    outb(base_port + 5, 0);
    outb(base_port + 7, 0xEC);
    io_delay4();
    
    s = inb(base_port + 7);
    if (s == 0x00 || s == 0xFF) return 0;
    if (s & (ST_ERR | ST_DF)) return 0;
    if (!wait_drq()) return 0;

    u16 id[256];
    for (int i = 0; i < 256; i++) id[i] = inw(base_port);
    
    copy_ident(model, id + 27, 20);
    
    total_sectors = ((u32)id[61] << 16) | id[60];
    if (total_sectors == 0) total_sectors = ((u32)id[101] << 16) | id[100];
    if (total_sectors > 0x0FFFFFFF) total_sectors = 0x0FFFFFFF;
    if (total_sectors == 0) return 0;
    
    is_cdrom = 0;
    return 1;
}

int ata_init(void) {
    present = 0;
    is_cdrom = 0;
    total_sectors = 0;
    model[0] = 0;

    /* Таблица всех 4 возможных IDE-каналов */
    struct {
        u16 port;
        u8 drive;
        const char *name;
    } configs[4] = {
        { 0x1F0, 0xA0, "Primary Master" },
        { 0x1F0, 0xB0, "Primary Slave" },
        { 0x170, 0xA0, "Secondary Master" },
        { 0x170, 0xB0, "Secondary Slave" }
    };

    for (int i = 0; i < 4; i++) {
        serial_puts("[ata] probing ");
        serial_puts(configs[i].name);
        serial_puts("...\n");
        
        if (probe_drive(configs[i].port, configs[i].drive)) {
            present = 1;
            serial_puts("[ata] FOUND!\n");
            return 1;
        }
    }

    serial_puts("[ata] no device found on any IDE channel\n");
    return 0;
}

int ata_present(void)         { return present; }
int ata_is_cdrom(void)        { return is_cdrom; }
u32 ata_sectors(void)         { return total_sectors; }
const char *ata_model(void)   { return model; }

/* --- Чтение секторов HDD --- */
static int ata_read_hdd(u32 lba, u8 count, void *buf) {
    if (lba >= total_sectors) return 0;
    outb(ATA_ALTSTAT, 0x02);
    if (!wait_ready()) return 0;
    outb(ATA_DRIVE, (u8)(0xE0 | ((lba >> 24) & 0x0F)));
    io_delay4();
    outb(ATA_SECCNT, count);
    outb(ATA_LBA0, (u8)( lba        & 0xFF));
    outb(ATA_LBA1, (u8)((lba >> 8)  & 0xFF));
    outb(ATA_LBA2, (u8)((lba >> 16) & 0xFF));
    outb(ATA_CMD, 0x20);
    io_delay4();
    u16 *out = (u16 *)buf;
    for (int s = 0; s < count; s++) {
        if (!wait_drq()) return 0;
        for (int i = 0; i < 256; i++) *out++ = inw(ATA_DATA);
    }
    return 1;
}

/* --- Чтение секторов CD-ROM (ATAPI) --- */
static int ata_read_cd(u32 lba, u32 count, void *buf) {
    if (!wait_ready()) return 0;
    outb(ATA_DRIVE, 0xA0);
    outb(ATA_SECCNT, 0x00);
    outb(ATA_LBA0, 0x00);
    outb(ATA_LBA1, 0x00);
    outb(ATA_LBA2, 0x00);
    outb(ATA_CMD, 0xA0); /* Команда PACKET */
    io_delay4();
    if (!wait_drq()) return 0;
    
    u8 cdb[12] = {0};
    cdb[0] = 0x28; /* READ 10 */
    cdb[2] = (lba >> 24) & 0xFF;
    cdb[3] = (lba >> 16) & 0xFF;
    cdb[4] = (lba >> 8)  & 0xFF;
    cdb[5] = (lba)       & 0xFF;
    cdb[7] = (count >> 8) & 0xFF;
    cdb[8] = (count)      & 0xFF;
    u16 *cdb_w = (u16 *)cdb;
    for (int i = 0; i < 6; i++) outw(ATA_DATA, cdb_w[i]);
    
    u8 *p = (u8 *)buf;
    if (!wait_drq()) return 0;
    u16 byte_count = ((u16)inb(ATA_LBA1)) | (((u16)inb(ATA_LBA2)) << 8);
    u32 words_to_read = byte_count / 2;
    for (u32 i = 0; i < words_to_read; i++) {
        *(u16 *)p = inw(ATA_DATA);
        p += 2;
    }
    return 1;
}

/* --- Универсальная функция чтения --- */
int ata_read(u32 lba, u8 count, void *buf) {
    if (!present || count == 0 || !buf) return 0;
    if (is_cdrom) {
        return ata_read_cd(lba, (u32)count, buf);
    } else {
        return ata_read_hdd(lba, count, buf);
    }
}