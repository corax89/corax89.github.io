/* htmlconv.c — HTML -> Markdown конвертер N2600-OS.
 *
 * Task 60 [HC-DOM]: ПОЛНОЕ ПЕРЕПИСЫВАНИЕ на базе DOM-парсера
 * html_parser.c (html_parse_begin/stream/end). Прежняя версия разбирала
 * HTML ручными эвристиками (сканирование '<', кавычек в атрибутах,
 * прыжки через <script>/<style>, комментарии) — на сложных страницах
 * эвристики расходились с реальной структурой, что вместе с тихой
 * обрезкой по ENSURE/PUT давало «просачивание скриптов» и потерю
 * контента (см. разбор Task 60: сценарии A/B/E/F).
 *
 * Теперь: html_parser строит дерево (теги, атрибуты с декодированными
 * entities, сырой код <script>/<textarea>, пропуск <style>/<template>),
 * а этот модуль ОБХОДИТ дерево итеративно (стек кадров в куче — стек
 * задачи не расходуется) и выдаёт тот же формат, что раньше:
 *
 *   Поддерживаемые теги (формат вывода НЕ менялся — brform.h/brpage.h
 *   и тесты продолжают читать прежние маркеры):
 *   <h1>-<h6> -> #..######; <p> -> пустая строка; <br> -> \n;
 *   <hr> -> ---; <b>/<strong> -> **; <i>/<em> -> *; <code> -> `;
 *   <pre> -> ```; <ul>/<ol>/<li> -> списки с нумерацией;
 *   <a href> -> [текст](href); <img src> -> строка ![alt](src);
 *   формы/скрипты -> маркеры \x01 (разбирает brform.h):
 *     \x01FORM action=".." method=".."
 *     \x01INPUT type=".." name=".." value=".." id=".." ph=".." js=".." [checked]
 *     \x01TEXTAREA .. \n сырой текст \n \x01/TEXTAREA
 *     \x01SELECT name=".." / \x01OPT value=".." label=".." / \x01/SELECT
 *     \x01BUTTON .. label=".."
 *     \x01SCRIPTSRC src="U"  /  \x01SCRIPT \n КОД \n \x01/SCRIPT
 *     \x01REFRESH content="N; url=U"
 *
 * Ключевые исправления Task 60:
 *   [HC-PAIR]  Маркерные строки пишутся АТОМАРНО (влезла строка целиком
 *              или не пишется вовсе — никаких полумаркетов «\x01INPUT
 *              type="te» при обрезке). Блоки \x01SCRIPT/\x01TEXTAREA
 *              резервируют место под закрывающий маркер ЗАРАНЕЕ; если
 *              буфер кончился посреди кода — закрывающий маркер
 *              дописывается, а при невозможности ВСЯ открывашка
 *              откатывается (mi = позиция до маркера). «Висячих»
 *              \x01SCRIPT больше не бывает (сценарий A из разбора).
 *   [HC-TRUNC] html_to_md2 сообщает обрезку через out-параметр
 *              truncated — браузер показывает «страница обрезана»,
 *              раньше статус выглядел как норма (сценарий 1.4/1.5).
 *   [HC-PH-JS] INPUT-маркер теперь пишет ph=".." и js=".." (как ожидает
 *              brf_attr); прежний код писал placeholder=".."/onclick="..",
 *              которые brf_attr НЕ читал — placeholder и onclick полей
 *              молча терялись.
 *   [HC-NOTRIM] Пробелы на стыках текстовых узлов сохраняются
 *              (парсер их больше не режет, нормализация — здесь).
 *
 * Task 67 (улучшения после Task 66):
 *   [HC-HIDDEN] Скрытый контент больше не рисуется: <el hidden>,
 *              style="display:none"/"display: none"/"visibility:hidden"
 *              -> поддерево пропускается (меню-бургеры, скрытые
 *              модалки, счётчики; на живых сайтах их много).
 *   [HC-BQ]     <blockquote> -> префикс "> " (цитата больше не сливается
 *              с основным текстом; многострочность — префикс на первой).
 *   [HC-DL]     <dl>/<dt>/<dd>: термин — **жирным**, определение — с
 *              отступом (прежде сливались с текстом).
 *   [HC-TBL]    Таблицы: наивный TSV — конец ячейки \t, конец строки \n
 *              (прежде структура терялась ПОЛНОСТЬЮ; wiki/доки/прайсы
 *              стали читаемыми). TH/колонки/выравнивание — позже.
 *   [HC-SUM]    <summary> -> '### ' (заголовок раскрытия);
 *              <details>/<figure>/<figcaption> — блочные (ensure_nl).
 *   [HC-AGGR]   Флаг htmlconv_set_aggressive(): 1 = выкидывать
 *              <nav>/<footer>/<aside>/<noscript>. По умолчанию ВЫКЛ
 *              (в <nav> бывает основной контент).
 *   [HC-ENC29]  ')' в href/img-src пишется как %29: раньше URL вида
 *              .../Foo_(bar) обрезался до .../Foo_ (обрыв на первой ')'
 *              — пользователь попадал на неверную страницу).
 *
 * Не поддерживается: выравнивание/объединение ячеек таблиц (TSV —
 * плоский), полная таблица entities (расширенные мнемоники даёт
 * html_parser.c: copy, mdash, laquo и т.д. — уже UTF-8).
 */

#ifdef HOST_TEST
#include <string.h>   /* хостовой тест: стандартная библиотека */
#include <stdio.h>
#include <stdlib.h>
#include "types.h"    /* u32; тест-харнессы кладут копию types.h рядом */
#else
#include "string.h"   /* ядро: freestanding-версия (src/string.c) */
#include "types.h"
#include "mem.h"
#endif

#include "htmlconv.h"
#include "html_parser.h"

/* FIX [HC-HEXESC] (Task 65): маркеры в СТРОКОВЫХ литералах пишутся как
 * "\x01" "FORM" (КОНКАТЕНАЦИЯ), а не "\x01FORM". Причина: в C hex-escape
 * ЖАДНЫЙ — "\x01FORM" это ОДИН байт 0x01F=31 (0x1F) + "ORM", а "\x01BUTTON"
 * — 0x01B=27 (0x1B) + "UTTON" ('F' и 'B' — hex-цифры!). GCC молчит
 * (0x01F < 256), байт в бинарнике портится, brform.h (ждёт 0x01) маркер
 * не узнаёт: формы не работают, строки "ORM action=..."/"UTTON ..."
 * РИСУЮТСЯ как текст страницы (гutenberg, habr и любые страницы с
 * <form>/<button>). Символьная константа HC_MARK не страдает (max 2 цифры). */
#define HC_MARK '\x01'   /* первый символ строки-маркера формы/скрипта */

/* Task 67 [HC-AGGR]: «читательский» режим. 0 = ВЫКЛ (поведение
 * прежнее); 1 = <nav>/<footer>/<aside>/<noscript> выкидываются целиком.
 * Включается вызывающим через htmlconv_set_aggressive() (см. htmlconv.h). */
static int hc_aggressive = 0;

void htmlconv_set_aggressive(int on)
{
    hc_aggressive = on ? 1 : 0;
}

/* лимиты формата маркеров (согласованы с brform.h) */
#define HC_JS_MAX 96          /* onclick в маркере (BRF_JS_MAX) */
#define HC_LB_MAX 512         /* строковый конструктор маркера */
#define HC_LIST_MAX 16        /* максимальная глубина списков */
#define HC_HREF_MAX 300       /* href <a> (Task 66: было 220 — согласовано
                              * с BRP_URL_MAX; длинные URL трекинга
                              * обрезались и вели не туда) */
/* Глубина дерева ограничена парсером 128 уровнями (MAX_PARSE_DEPTH в
 * html_parser.c) + виртуальный корень; запас +4. */
#define HC_MAX_DEPTH 132

/* ---- кадры итеративного обхода дерева ---- */

enum {
    HC_K_PLAIN = 0,   /* обычный контейнер: текст нормализуем */
    HC_K_PRE,         /* внутри <pre>: текст сырой, элементы прозрачны */
    HC_K_SCRIPT,      /* внутри <script>: сырой код */
    HC_K_TA,          /* внутри <textarea>: сырое значение */
    HC_K_OPT,         /* внутри <option>: копим подпись */
    HC_K_BTN          /* внутри <button>: копим подпись */
};

typedef struct {
    HtmlElement *el;              /* элемент, чьи дети обходим */
    HtmlElement *next;            /* следующий необработанный ребёнок */
    int          kind;            /* HC_K_* */
    int          transparent;     /* Task 66 [HC-TRANSPARENT]: кадр создан
                                  * «прозрачным» спуском внутри pre/script/ta/
                                  * opt/btn — hc_open_tag НЕ звался, его
                                  * закрывающие эффекты НЕ нужны. Без флага
                                  * hc_close_frame смотрит только el->tag и
                                  * для <pre><code>x</code></pre> пишет лишний
                                  * '`' от </code> (и '**' от </b> в pre). */
    int          pre_first;       /* HC_K_PRE: пропустить ведущий \n */
    int          li_count;        /* UL/OL: счётчик номеров <li> */
    char         href[HC_HREF_MAX];   /* <a>: отложенный href */
    int          a_open_mi;       /* <a>: позиция '[' в md (FIX [HC-A-NL]) */
    char         pend_attrs[128]; /* option/button: атрибуты маркера */
    char         label[64];       /* option/button: подпись */
    int          label_len;
} hc_frame_t;

typedef struct {
    char *md;
    int   md_max;
    int   mi;
    int   trunc;                  /* FIX [HC-TRUNC]: буфер исчерпан */
    /* FIX [HC-PAIR]: состояние открытых блоков */
    int   sc_open;                /* открыт \x01SCRIPT без закрытия */
    int   sc_pos;                 /* mi ДО открывающего маркера */
    int   ta_open;
    int   ta_pos;
    int   pre_depth;              /* вложенность <pre> */
    char  lb[HC_LB_MAX];          /* конструктор маркерной строки */
    int   lb_len;
    /* Task 68 [HC-GROW]: потоковый режим (hc_stream_*) может расширять
     * буфер вызывателя по мере роста страницы — заранее неизвестной.
     * grow = NULL (обычный html_to_md2) — поведение прежнее. Индексы
     * (sc_pos/ta_pos/a_open_mi) переживают realloc — указателей на md
     * вне ctx никто не хранит. */
    int (*grow)(void *ud, char **md, int *max, int want);
    void *grow_ud;
    int   hard_max;               /* потолок роста (0 = без роста) */
} hc_ctx_t;

/* ================= примитивы вывода ================= */
static int hc_room(hc_ctx_t *ctx, int n)
{
    if (ctx->trunc) return 0;
    if (ctx->md_max - 1 - ctx->mi >= n) return 1;
    /* Task 68 [HC-GROW]: потоковая конвертация — буфер растёт вдвое до
     * hard_max; не хватило (или grow == NULL) — честный trunc. */
    if (ctx->grow && ctx->hard_max > ctx->md_max) {
        int want = ctx->md_max * 2;
        if (want > ctx->hard_max) want = ctx->hard_max;
        if (want < ctx->mi + n + 2) want = ctx->mi + n + 2;
        if (want <= ctx->hard_max &&
            ctx->grow(ctx->grow_ud, &ctx->md, &ctx->md_max, want))
            return (ctx->md_max - 1 - ctx->mi >= n);
    }
    return 0;
}

static void hc_put(hc_ctx_t *ctx, char c)
{
    if (ctx->trunc) return;
    if (!hc_room(ctx, 1)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    ctx->md[ctx->mi++] = c;
}

/* n байт целиком или ничего (с выставлением trunc) */
static void hc_put_n(hc_ctx_t *ctx, const char *s, int n)
{
    if (ctx->trunc || n <= 0) return;
    if (!hc_room(ctx, n)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    memcpy(ctx->md + ctx->mi, s, (u32)n);
    ctx->mi += n;
}

static void hc_put2(hc_ctx_t *ctx, char a, char b)
{
    if (ctx->trunc) return;
    if (!hc_room(ctx, 2)) { ctx->trunc = 1; return; }   /* [HC-GROW] */
    ctx->md[ctx->mi++] = a;
    ctx->md[ctx->mi++] = b;
}

/* удалить пробелы перед переводом строки, чтобы не было " \n" */
static void hc_trim_sp(hc_ctx_t *ctx)
{
    while (ctx->mi > 0 && ctx->md[ctx->mi - 1] == ' ')
        ctx->mi--;
}

/* перевод строки с удалением хвостовых пробелов (старый EMIT_NL) */
static void hc_brk(hc_ctx_t *ctx)
{
    hc_trim_sp(ctx);
    hc_put(ctx, '\n');
}

/* гарантировать перевод строки в конце (старый ENSURE_NL; в старом
 * коде ВСЕ вызовы, кроме <img>, стояли под if (mi > 0) — пустой вывод
 * ведущего \n не даёт; для <img> — hc_brk напрямую) */
static void hc_ensure_nl(hc_ctx_t *ctx)
{
    if (ctx->mi == 0) return;
    if (ctx->md[ctx->mi - 1] != '\n')
        hc_brk(ctx);
}

/* как hc_ensure_nl, но без удаления пробелов (закрытие <pre>) */
static void hc_ensure_nl_raw(hc_ctx_t *ctx)
{
    if (ctx->mi == 0 || ctx->md[ctx->mi - 1] != '\n')
        hc_put(ctx, '\n');
}

/* гарантировать пустую строку (старый ENSURE_BLANK) */
static void hc_ensure_blank(hc_ctx_t *ctx)
{
    if (ctx->mi > 0) {
        hc_ensure_nl(ctx);
        if (ctx->mi < 2 || ctx->md[ctx->mi - 2] != '\n')
            hc_put(ctx, '\n');
    }
}

/* ================= строковый конструктор маркера ================= */

static void hc_lb_reset(hc_ctx_t *ctx)
{
    ctx->lb_len = 0;
    ctx->lb[0] = 0;
}

static void hc_lb_put(hc_ctx_t *ctx, char c)
{
    if (ctx->lb_len < HC_LB_MAX - 1) {
        ctx->lb[ctx->lb_len++] = c;
        ctx->lb[ctx->lb_len] = 0;
    }
}

static void hc_lb_str(hc_ctx_t *ctx, const char *s)
{
    while (*s) hc_lb_put(ctx, *s++);
}

/* значение атрибута маркера: '"' -> &quot;, \n/\r/\x01 -> ' ' */
static void hc_lb_attr(hc_ctx_t *ctx, const char *s)
{
    for (; *s; s++) {
        if (*s == '"')
            hc_lb_str(ctx, "&quot;");
        else if (*s == '\n' || *s == '\r' || *s == HC_MARK)
            hc_lb_put(ctx, ' ');
        else
            hc_lb_put(ctx, *s);
    }
}

/* Task 66 [HC-JS-CAP]: то же с обрезкой значения до max символов.
 * Прежде onclick длиннее HC_LB_MAX-1 молча резался hc_lb_put — маркер
 * уходил в md УСЕЧЁННЫМ ("js=\"...." без закрывающей кавычки), brf_attr
 * читал мусор. BRF_JS_MAX всё равно режет при разборе — режем ЗАРАНЕЕ,
 * чтобы маркер оставался корректным (и комментарий про HC_JS_MAX стал
 * правдой). */
static void hc_lb_attr_cap(hc_ctx_t *ctx, const char *s, int max)
{
    int n = 0;
    for (; *s && n < max; s++, n++) {
        if (*s == '"')
            hc_lb_str(ctx, "&quot;");
        else if (*s == '\n' || *s == '\r' || *s == HC_MARK)
            hc_lb_put(ctx, ' ');
        else
            hc_lb_put(ctx, *s);
    }
}

/* Атомарная маркерная строка: конец текущей строки (с чисткой
 * хвостовых пробелов) + lb + '\n'. Строка целиком или trunc. */
static void hc_flush_line(hc_ctx_t *ctx)
{
    if (ctx->trunc) return;
    if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n') {
        hc_trim_sp(ctx);
        hc_put(ctx, '\n');
        if (ctx->trunc) return;
    }
    /* FIX [HC-GROW2]: было прямое «не влезло -> trunc» мимо grow-хука:
     * потоковая конвертация замирала на первой маркерной строке, не
     * влезшей в стартовый буфер (OPT/SELECT/INPUT исчезали после 63 б).
     * Теперь — hc_room: рост через хук, при отказе — честный trunc. */
    if (!hc_room(ctx, ctx->lb_len + 1)) {
        ctx->trunc = 1;
        return;
    }
    memcpy(ctx->md + ctx->mi, ctx->lb, (u32)ctx->lb_len);
    ctx->mi += ctx->lb_len;
    ctx->md[ctx->mi++] = '\n';
}

/* ================= утилиты ================= */

/* значение атрибута элемента по ключу (уже декодировано парсером) */
static const char *hc_attr(const HtmlElement *el, HtmlAttribKey key)
{
    const HtmlAttrib *a;
    for (a = el->attrib; a; a = a->next)
        if (a->key == key)
            return a->value;
    return NULL;
}

/* сравнение без регистра (для http-equiv="refresh") */
static int hc_ci_eq(const char *a, const char *b)
{
    for (;;) {
        char ca = *a, cb = *b;
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca | 0x20);
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb | 0x20);
        if (ca != cb) return 0;
        if (!ca) return 1;
        a++;
        b++;
    }
}

/* Task 67 [HC-HIDDEN]: подстрока БЕЗ УЧЁТА регистра и БЕЗ УЧЁТА
 * пробелов в haystack (CSS-значения пишут и "display:none", и
 * "display: none", и "display : none"). Пропуски whitespace в HAY
 * разрешены в любых позициях — идентификаторы CSS пробелы внутрь не
 * содержат, ложных срабатываний это не даёт. */
static int hc_ci_strstr(const char *hay, const char *needle)
{
    for (const char *h = hay; *h; h++) {
        const char *p = h;
        const char *q = needle;
        for (;;) {
            while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
            if (!*q) return 1;                  /* весь needle сошёлся */
            if (!*p) break;                     /* hay кончился */
            char a = *p, b = *q;
            if (a >= 'A' && a <= 'Z') a = (char)(a | 0x20);
            if (b >= 'A' && b <= 'Z') b = (char)(b | 0x20);
            if (a != b) break;
            p++; q++;
        }
    }
    return 0;
}

/* ---------------- текст ---------------- */

/* нормализованный текст: '\n'/\r/\t -> ' ', пробелы схлопываются,
 * \x01 (мусор из страницы) -> ' ' — как старое «сжатие пробелов» */
/* Task 68 [HC-SAX]: текст приходит (указатель, длина) — событийный
 * режим парсера не обязан NUL-терминировать буфер. */
static void hc_text_norm(hc_ctx_t *ctx, const char *s, int n)
{
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == HC_MARK) c = ' ';
        if (c == ' ' && (ctx->mi == 0 ||
                         ctx->md[ctx->mi - 1] == ' ' ||
                         ctx->md[ctx->mi - 1] == '\n'))
            continue;
        hc_put(ctx, c);
    }
}

/* сырой текст (код скрипта, значение textarea, содержимое <pre>) */
static void hc_text_raw(hc_ctx_t *ctx, const char *s, int n)
{
    for (int i = 0; i < n && s[i]; i++)
        hc_put(ctx, s[i]);
}

/* подпись option/button: переносы/табы -> пробел, пробелы схлопываются */
static void hc_label_add(hc_frame_t *fr, const char *s, int n)
{
    for (int i = 0; i < n && s[i]; i++) {
        char c = s[i];
        if (c == '\n' || c == '\r' || c == '\t') c = ' ';
        if (c == ' ' && (fr->label_len == 0 ||
                         fr->label[fr->label_len - 1] == ' '))
            continue;
        if (fr->label_len < (int)sizeof(fr->label) - 1)
            fr->label[fr->label_len++] = c;
    }
    fr->label[fr->label_len] = 0;
}

/* дописать " name=\"..\""-фрагмент в pend_attrs option/button */
static void hc_pa_add(hc_frame_t *nf, const char *name, const char *val,
                      int lower)
{
    char tmp[96];
    int k = 0;
    int l;
    if (!val || !*val) return;
    for (; val[k] && k < 94; k++)
        tmp[k] = (lower && val[k] >= 'A' && val[k] <= 'Z')
                 ? (char)(val[k] | 0x20) : val[k];
    tmp[k] = 0;
    l = (int)strlen(nf->pend_attrs);
    snprintf(nf->pend_attrs + l, sizeof(nf->pend_attrs) - (u32)l,
             " %s=\"%s\"", name, tmp);
}

/* ================= открытие/закрытие элементов ================= */

/* Открытие: выдаёт открывающую разметку/маркер. kind — режим кадра для
 * детей. Возврат: 1 = спуститься в детей (кадр создаётся даже для
 * пустого элемента — закрывающие эффекты обязаны сработать),
 * 0 = лист (спуск не нужен), -1 = поддерево пропустить (маркер уже
 * выдан: <script src>). frames/depth — для вычисления уровня <li>. */
static int hc_open_tag(hc_ctx_t *ctx, hc_frame_t *frames, int depth,
                       HtmlElement *el, hc_frame_t *nf, int *kind)
{
    const char *av;

    *kind = HC_K_PLAIN;

    /* Task 67 [HC-AGGR]: «читательский» режим (по умолчанию ВЫКЛ).
     * До всех остальных веток: поддерево пропускается ЦЕЛИКОМ. */
    if (hc_aggressive) {
        switch (el->tag) {
        case HTML_TAG_NAV:
        case HTML_TAG_FOOTER:
        case HTML_TAG_ASIDE:
        case HTML_TAG_NOSCRIPT:
            return -1;
        default:
            break;
        }
    }

    /* Task 67 [HC-HIDDEN]: скрытый контент не рисуем (в реальных
     * браузерах он невидим): булев hidden, display:none (в т.ч.
     * с пробелами/регистром), visibility:hidden. БЕЗ CSS остальные
     * стили разобрать нельзя — проверяем только эти три признака. */
    if (hc_attr(el, HTML_ATTRIB_HIDDEN))
        return -1;
    {
        const char *st = hc_attr(el, HTML_ATTRIB_STYLE);
        if (st && *st &&
            (hc_ci_strstr(st, "display:none") ||
             hc_ci_strstr(st, "visibility:hidden")))
            return -1;
    }

    switch (el->tag) {

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6: {
        /* теги H1..H6 идут подряд в enum html_parser.h */
        int v = (int)(el->tag - HTML_TAG_H1) + 1;
        hc_ensure_nl(ctx);
        for (int i = 0; i < v; i++) hc_put(ctx, '#');
        hc_put(ctx, ' ');
        return 1;
    }

    case HTML_TAG_P:
        hc_ensure_blank(ctx);
        return 1;

    case HTML_TAG_BR:
        hc_brk(ctx);
        return 0;

    case HTML_TAG_HR:
        hc_ensure_nl(ctx);
        hc_put_n(ctx, "---\n", 4);
        return 0;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        return 1;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        return 1;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        return 1;

    case HTML_TAG_PRE:
        if (ctx->pre_depth == 0) {
            hc_ensure_nl(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        ctx->pre_depth++;
        *kind = HC_K_PRE;
        nf->pre_first = 1;
        return 1;

    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        nf->li_count = 0;
        return 1;

    case HTML_TAG_LI: {
        int lvl = 0;
        hc_frame_t *lf = NULL;
        for (int k = 0; k <= depth; k++) {
            HtmlTag t = frames[k].el->tag;
            if (t == HTML_TAG_UL || t == HTML_TAG_OL) {
                lvl++;
                lf = &frames[k];
            }
        }
        hc_ensure_nl(ctx);
        {
            int ind = lvl > 0 ? lvl - 1 : 0;
            if (ind > HC_LIST_MAX) ind = HC_LIST_MAX;
            for (int i = 0; i < ind; i++) hc_put2(ctx, ' ', ' ');
        }
        if (lvl > 0 && lf && lf->el->tag == HTML_TAG_OL) {
            int v = ++lf->li_count;
            char num[12];
            int n = 0;
            if (v <= 0) {
                hc_put(ctx, '0');
            } else {
                while (v > 0 && n < (int)sizeof(num)) {
                    num[n++] = (char)('0' + (v % 10));
                    v /= 10;
                }
                while (n > 0) hc_put(ctx, num[--n]);
            }
            hc_put(ctx, '.');
            hc_put(ctx, ' ');
        } else {
            hc_put2(ctx, '-', ' ');
        }
        return 1;
    }

    case HTML_TAG_A: {
        const char *h = hc_attr(el, HTML_ATTRIB_HREF);
        nf->href[0] = 0;
        if (h && *h) {
            int k = 0;
            for (; h[k] && k < HC_HREF_MAX - 1; k++) nf->href[k] = h[k];
            nf->href[k] = 0;
        }
        hc_put(ctx, '[');
        /* FIX [HC-A-NL]: запомнить позицию '[' — при закрытии проверим,
         * не разбило ли текст ссылки на строки (картинка/блочный child
         * внутри <a>). У такой "многострочной" ссылки разметку [..](..)
         * придётся снять: brp_analyze ищет '](' на ОДНОЙ строке, иначе
         * пользователь видел мусор "](https://...)" в тексте (Hacker
         * News: [\n![](y18.svg)\n](https://news.ycombinator.com)). */
        nf->a_open_mi = ctx->trunc ? -1 : ctx->mi - 1;
        return 1;
    }

    case HTML_TAG_IMG: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        const char *alt;
        if (!src || !*src) return 0;          /* без src — пропуск */
        alt = hc_attr(el, HTML_ATTRIB_ALT);
        hc_brk(ctx);                          /* старый unguarded ENSURE_NL */
        hc_lb_reset(ctx);
        hc_lb_put(ctx, '!');
        hc_lb_put(ctx, '[');
        if (alt) {
            for (int k = 0; alt[k] && k < 48; k++) {
                if (alt[k] == ']' || alt[k] == '\n' || alt[k] == '\r') break;
                hc_lb_put(ctx, alt[k]);
            }
        }
        hc_lb_put(ctx, ']');
        hc_lb_put(ctx, '(');
        /* Task 67 [HC-ENC29]: ')' и '(' в URL пишутся как %29/%28 —
         * раньше .../Foo_(bar).png обрезался до .../Foo_ (обрыв на
         * первой скобке), картинка/ссылка вели не туда. Обе скобки:
         * иначе разборщик [T](U) в brpage.h находит ')' внутри URL. */
        for (const char *u = src; *u; u++) {
            if (*u == '\n' || *u == '\r' || *u == '"' || *u == '<')
                break;
            if (*u == ')')
                hc_lb_str(ctx, "%29");
            else if (*u == '(')
                hc_lb_str(ctx, "%28");
            else
                hc_lb_put(ctx, *u);
        }
        hc_lb_put(ctx, ')');
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_INPUT: {
        /* FIX [HC-PH-JS]: маркер пишет ph=/js= — имена, которые реально
         * читает brf_attr (прежде писались placeholder=/onclick= и
         * молча терялись). */
        char ttype[16];
        hc_ensure_nl(ctx);
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av) {
            int k = 0;
            for (; av[k] && k < 15; k++)
                ttype[k] = (av[k] >= 'A' && av[k] <= 'Z')
                           ? (char)(av[k] | 0x20) : av[k];
            ttype[k] = 0;
        } else {
            strcpy(ttype, "text");
        }
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "INPUT type=\"");
        hc_lb_str(ctx, ttype);
        hc_lb_put(ctx, '"');
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av) {
            hc_lb_str(ctx, " value=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if (!strcmp(ttype, "text") || !strcmp(ttype, "password") ||
            !strcmp(ttype, "search") || !strcmp(ttype, "email") ||
            !strcmp(ttype, "url") || !strcmp(ttype, "number") ||
            !strcmp(ttype, "tel")) {
            /* Task 66: placeholder есть у всех текстоподобных типов */
            if ((av = hc_attr(el, HTML_ATTRIB_PLACEHOLDER)) && *av) {
                hc_lb_str(ctx, " ph=\""); hc_lb_attr(ctx, av);
                hc_lb_put(ctx, '"');
            }
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av) {
            hc_lb_str(ctx, " js=\""); hc_lb_attr_cap(ctx, av, HC_JS_MAX);
            hc_lb_put(ctx, '"');
        }
        if (hc_attr(el, HTML_ATTRIB_CHECKED))
            hc_lb_str(ctx, " checked");
        hc_flush_line(ctx);
        return 0;
    }

    case HTML_TAG_TEXTAREA: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "TEXTAREA");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_ID)) && *av) {
            hc_lb_str(ctx, " id=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        /* FIX [HC-PAIR]: резерв под закрывающий "\n\x01/TEXTAREA\n" */
        if (!hc_room(ctx, ctx->lb_len + 11 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: текст пойдёт обычным */
        }
        ctx->ta_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->ta_open = 1;
        *kind = HC_K_TA;
        return 1;
    }

    case HTML_TAG_SELECT: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "SELECT");
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av) {
            hc_lb_str(ctx, " name=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_OPTION: {
        const char *ov = hc_attr(el, HTML_ATTRIB_VALUE);
        nf->pend_attrs[0] = 0;
        if (ov && *ov) hc_pa_add(nf, "value", ov, 0);
        if (hc_attr(el, HTML_ATTRIB_SELECTED)) {
            int l = (int)strlen(nf->pend_attrs);
            if (l + 10 < (int)sizeof(nf->pend_attrs))
                strcpy(nf->pend_attrs + l, " selected");
        }
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_OPT;
        return 1;
    }

    /* Task 66 [HC-OPT-NOVALUE]: <option>Label</option> без value раньше
     * терялся ЦЕЛИКОМ (close писал маркер только при непустых
     * pend_attrs). По HTML5 value по умолчанию — ТЕКСТ опции: brform.h
     * сам подставит label в значение, если value пуст. */
    case HTML_TAG_BUTTON: {
        nf->pend_attrs[0] = 0;
        if ((av = hc_attr(el, HTML_ATTRIB_TYPE)) && *av)
            hc_pa_add(nf, "type", av, 1);
        if ((av = hc_attr(el, HTML_ATTRIB_NAME)) && *av)
            hc_pa_add(nf, "name", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_VALUE)) && *av)
            hc_pa_add(nf, "value", av, 0);
        if ((av = hc_attr(el, HTML_ATTRIB_ONCLICK)) && *av)
            hc_pa_add(nf, "js", av, 0);
        nf->label[0] = 0;
        nf->label_len = 0;
        *kind = HC_K_BTN;
        return 1;
    }

    case HTML_TAG_FORM: {
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "FORM");
        if ((av = hc_attr(el, HTML_ATTRIB_ACTION)) && *av) {
            hc_lb_str(ctx, " action=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        if ((av = hc_attr(el, HTML_ATTRIB_METHOD)) && *av) {
            hc_lb_str(ctx, " method=\""); hc_lb_attr(ctx, av);
            hc_lb_put(ctx, '"');
        }
        hc_flush_line(ctx);
        return 1;
    }

    case HTML_TAG_META: {
        /* FIX [META-REFRESH]: только http-equiv=refresh */
        const char *he = hc_attr(el, HTML_ATTRIB_HTTP_EQUIV);
        const char *co = hc_attr(el, HTML_ATTRIB_CONTENT);
        if (he && co && *co && hc_ci_eq(he, "refresh")) {
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01" "REFRESH content=\"");
            hc_lb_attr(ctx, co);
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
        }
        return 0;
    }

    case HTML_TAG_SCRIPT: {
        const char *src = hc_attr(el, HTML_ATTRIB_SRC);
        if (src && *src) {
            /* внешний код: маркер-строка, поддерево пропускаем */
            hc_ensure_nl(ctx);
            hc_lb_reset(ctx);
            hc_lb_str(ctx, "\x01" "SCRIPTSRC src=\"");
            for (const char *u = src; *u; u++) {
                if (*u == '"' || *u == ' ' || *u == '\n' || *u == '\r' ||
                    *u == HC_MARK)
                    break;
                hc_lb_put(ctx, *u);
            }
            hc_lb_put(ctx, '"');
            hc_flush_line(ctx);
            return -1;
        }
        /* инлайн: маркер + сырой код + закрытие. FIX [HC-PAIR]: резерв
         * под закрывающий "\n\x01/SCRIPT\n" ЗАРАНЕЕ — блок либо
         * открывается с гарантией закрытия, либо не открывается. */
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "SCRIPT");
        if (!hc_room(ctx, ctx->lb_len + 10 + 2)) {
            ctx->trunc = 1;
            return 1;              /* без маркера: остаток — обычный текст */
        }
        ctx->sc_pos = ctx->mi;
        hc_flush_line(ctx);
        if (ctx->trunc) return 1;
        ctx->sc_open = 1;
        *kind = HC_K_SCRIPT;
        return 1;
    }

    case HTML_TAG_BLOCKQUOTE:
        /* Task 67 [HC-BQ]: цитата — с префиксом "> ". Многострочные
         * цитаты префиксуют только первую строку (полная блок-цитата
         * требует перестройки уже выведенного текста — позже). */
        hc_ensure_nl(ctx);
        hc_put_n(ctx, "> ", 2);
        return 1;

    case HTML_TAG_DT:
        /* Task 67 [HC-DL]: термин списка определений — **жирным** */
        hc_ensure_nl(ctx);
        hc_put2(ctx, '*', '*');
        return 1;

    case HTML_TAG_DD:
        /* определение — с отступом */
        hc_ensure_nl(ctx);
        hc_put2(ctx, ' ', ' ');
        return 1;

    case HTML_TAG_TABLE:
        /* Task 67 [HC-TBL]: таблица -> наивный TSV (конец ячейки \t,
         * конец строки \n — сепараторы пишут close TD/TH/TR) */
        hc_ensure_nl(ctx);
        return 1;

    case HTML_TAG_TR:
        hc_ensure_nl(ctx);
        return 1;

    case HTML_TAG_TD:
    case HTML_TAG_TH:
        /* содержимое ячейки течёт обычным текстом; сепаратор — в close */
        return 1;

    case HTML_TAG_SUMMARY:
        /* Task 67 [HC-SUM]: заголовок раскрытия — как h3 */
        hc_ensure_nl(ctx);
        hc_put_n(ctx, "### ", 4);
        return 1;

    case HTML_TAG_DETAILS:
    case HTML_TAG_FIGURE:
    case HTML_TAG_FIGCAPTION:
        hc_ensure_nl(ctx);
        return 1;

    default:
        /* нейтральные/неизвестные теги (html/head/div/span/table/title,
         * label, nav, ...) — разметку не выдаём, содержимое сохраняем */
        return 1;
    }
}

/* Закрытие элемента (кадр завершён) */
static void hc_close_frame(hc_ctx_t *ctx, hc_frame_t *fr)
{
    HtmlElement *el = fr->el;

    /* Task 66 [HC-TRANSPARENT]: «прозрачный» кадр (спуск внутри pre/
     * script/textarea/option/button) открывался БЕЗ hc_open_tag — любые
     * закрывающие эффекты по tag здесь ЛОЖНЫЕ (лишний '`' от </code>
     * внутри <pre>, '**' от </b>, ']' от </a>...). */
    if (fr->transparent) return;

    switch (el->tag) {

    case HTML_TAG_A: {
        hc_put(ctx, ']');
        /* FIX [HC-A-NL]: многострочная ссылка (child-элемент с разрывом
         * строки — картинка, заголовок) — снимаем разметку: '[' и ']'
         * затираем пробелами, (href) НЕ пишем. Текст/картинки остаются
         * видимыми, мусор "](url)" в текст не попадает. */
        if (fr->a_open_mi >= 0 && fr->a_open_mi < ctx->mi) {
            int has_nl = 0;
            for (int q = fr->a_open_mi; q < ctx->mi; q++)
                if (ctx->md[q] == '\n') { has_nl = 1; break; }
            if (has_nl) {
                ctx->md[fr->a_open_mi] = ' ';
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] == ']')
                    ctx->md[ctx->mi - 1] = ' ';
                break;                /* (href) не пишем */
            }
        }
        if (fr->href[0]) {
            /* Task 67 [HC-ENC29]: ')' внутри URL пишется как %29 —
             * раньше href резался на ПЕРВОЙ ')': .../Foo_(bar) ->
             * .../Foo_ (пользователь попадал на неверную страницу).
             * Сначала считаем точную ёмкость (скобка расширяется x3). */
            int need = 2;
            for (const char *u = fr->href; *u; u++)
                need += (*u == ')' || *u == '(') ? 3 : 1;
            if (hc_room(ctx, need)) {
                hc_put(ctx, '(');
                for (const char *u = fr->href; *u; u++) {
                    if (*u == ')') hc_put_n(ctx, "%29", 3);
                    else if (*u == '(') hc_put_n(ctx, "%28", 3);
                    else hc_put(ctx, *u);
                }
                hc_put(ctx, ')');
            } else {
                ctx->trunc = 1;
            }
        } else if (hc_room(ctx, 2)) {
            hc_put(ctx, '(');
            hc_put(ctx, ')');
        } else {
            ctx->trunc = 1;
        }
        break;
    }

    case HTML_TAG_DT:
        /* Task 67 [HC-DL]: закрывающие '**' термина */
        hc_put2(ctx, '*', '*');
        break;

    case HTML_TAG_TD:
    case HTML_TAG_TH:
        /* Task 67 [HC-TBL]: конец ячейки — табулятор */
        hc_put(ctx, '\t');
        break;

    case HTML_TAG_DD:
        /* Task 67 [HC-DL]: блок завершается строкой (как P) */
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_TR:
        /* Task 67 [HC-TBL]: конец строки таблицы; хвостовой '\t' после
         * ПОСЛЕДНЕЙ ячейки убираем (иначе TSV с висячим сепаратором) */
        while (ctx->mi > 0 && ctx->md[ctx->mi - 1] == '\t')
            ctx->mi--;
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_TABLE:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_DETAILS:
    case HTML_TAG_FIGURE:
    case HTML_TAG_FIGCAPTION:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_SUMMARY:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
    case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6:
    case HTML_TAG_P:
    case HTML_TAG_LI:
    case HTML_TAG_UL:
    case HTML_TAG_OL:
        hc_ensure_nl(ctx);
        break;

    case HTML_TAG_B:
    case HTML_TAG_STRONG:
        hc_put2(ctx, '*', '*');
        break;

    case HTML_TAG_I:
    case HTML_TAG_EM:
        hc_put(ctx, '*');
        break;

    case HTML_TAG_CODE:
        hc_put(ctx, '`');
        break;

    case HTML_TAG_PRE:
        ctx->pre_depth--;
        if (ctx->pre_depth == 0) {
            hc_ensure_nl_raw(ctx);
            hc_put_n(ctx, "```\n", 4);
        }
        break;

    case HTML_TAG_FORM:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "/FORM");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SELECT:
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "/SELECT");
        hc_flush_line(ctx);
        break;

    case HTML_TAG_OPTION:
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "OPT");
        hc_lb_str(ctx, fr->pend_attrs);       /* может быть пусто — ок */
        hc_lb_str(ctx, " label=\"");
        for (int i = 0; i < fr->label_len; i++) {
            if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
            else hc_lb_put(ctx, fr->label[i]);
        }
        hc_lb_put(ctx, '"');
        hc_flush_line(ctx);
        break;

    case HTML_TAG_BUTTON:
        hc_ensure_nl(ctx);
        hc_lb_reset(ctx);
        hc_lb_str(ctx, "\x01" "BUTTON");
        hc_lb_str(ctx, fr->pend_attrs);
        hc_lb_str(ctx, " label=\"");
        for (int i = 0; i < fr->label_len; i++) {
            if (fr->label[i] == '"') hc_lb_str(ctx, "&quot;");
            else hc_lb_put(ctx, fr->label[i]);
        }
        hc_lb_put(ctx, '"');
        hc_flush_line(ctx);
        break;

    case HTML_TAG_SCRIPT:
        /* FIX [HC-PAIR]: закрывашка влезла (резерв был) — пишем; при
         * обрыве посреди кода (trunc) закрывашку допишет finish либо
         * блок откатится целиком. */
        if (ctx->sc_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 9;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/SCRIPT\n", 9);
                ctx->mi += 9;
                ctx->sc_open = 0;
            }
        }
        break;

    case HTML_TAG_TEXTAREA:
        if (ctx->ta_open && !ctx->trunc) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 11;
            if (ctx->md_max - 1 - ctx->mi >= need) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/TEXTAREA\n", 11);
                ctx->mi += 11;
                ctx->ta_open = 0;
            }
        }
        break;

    default:
        break;
    }
}

/* инициализация кадра (перед hc_open_tag, чтобы он мог заполнить
 * href/pend_attrs нового кадра) */
static void hc_frame_init(hc_frame_t *nf, HtmlElement *el, int kind)
{
    nf->el = el;
    nf->next = el->child;
    nf->kind = kind;
    nf->transparent = 0;
    nf->pre_first = 0;
    nf->li_count = 0;
    nf->href[0] = 0;
    nf->pend_attrs[0] = 0;
    nf->label[0] = 0;
    nf->label_len = 0;
}

/* ═══════════════════════════════════════════════════════
   Task 68 [HC-SAX]: событийная конвертация (без построения DOM)
   ═══════════════════════════════════════════════════════
   Парсер (html_parser.c, режим [HP-EVENT]) присылает open/text/close
   В ПОРЯДКЕ ДОКУМЕНТА; конвертер ведёт СВОЙ стек кадров — тот же, что
   был у обхода дерева (hc_frame_t), поэтому формат вывода не меняется
   вовсе. Элементы освобождаются парсером сразу после on_close —
   память пропорциональна ОТКРЫТЫМ элементам, а не всему документу. */

typedef struct {
    hc_ctx_t    ctx;
    hc_frame_t *frames;
    int         depth;
    int         skip_depth;   /* внутри поддерева с r==-1 (hidden/svg/...) */
} hc_sax_t;

static void hc_sax_open(void *ud, HtmlElement *el)
{
    hc_sax_t *s = (hc_sax_t *)ud;
    hc_ctx_t *ctx = &s->ctx;

    if (s->skip_depth) { s->skip_depth++; return; }
    if (ctx->trunc) { s->skip_depth++; return; }   /* структуру гасим */

    /* элемент внутри «сырого»/копящего контейнера: прозрачный спуск */
    int k = s->frames[s->depth].kind;
    if (k == HC_K_PRE || k == HC_K_SCRIPT || k == HC_K_TA ||
        k == HC_K_OPT || k == HC_K_BTN) {
        if (s->depth + 1 < HC_MAX_DEPTH) {
            hc_frame_init(&s->frames[s->depth + 1], el, k);
            s->frames[s->depth + 1].transparent = 1;   /* [HC-TRANSPARENT] */
            s->depth++;
        }
        return;
    }

    if (s->depth + 1 < HC_MAX_DEPTH) {
        int r;
        hc_frame_init(&s->frames[s->depth + 1], el, HC_K_PLAIN);
        r = hc_open_tag(ctx, s->frames, s->depth, el,
                        &s->frames[s->depth + 1],
                        &s->frames[s->depth + 1].kind);
        if (r == 1)
            s->depth++;            /* кадр остаётся: закроется на close */
        else if (r == -1)
            s->skip_depth = 1;     /* поддерево пропущено (эффекты выданы) */
        /* r == 0: лист — кадра нет, close(el) пройдёт мимо */
    } else {
        /* глубина исчерпана (не бывает: парсер ограничен 128) */
        int kind = HC_K_PLAIN;
        hc_frame_t tmp;
        memset(&tmp, 0, sizeof(tmp));
        (void)hc_open_tag(ctx, s->frames, s->depth, el, &tmp, &kind);
    }
}

static void hc_sax_text(void *ud, const char *tx, int len)
{
    hc_sax_t *s = (hc_sax_t *)ud;
    hc_ctx_t *ctx = &s->ctx;

    if (s->skip_depth || ctx->trunc || !tx || len <= 0) return;

    hc_frame_t *fr = &s->frames[s->depth];
    switch (fr->kind) {
    case HC_K_PRE:
        if (fr->pre_first) {
            fr->pre_first = 0;
            if (tx[0] == '\n') { tx++; len--; }   /* HTML5: первый \n
                                                   * после <pre> игнорируется */
        }
        hc_text_raw(ctx, tx, len);
        break;
    case HC_K_SCRIPT:
    case HC_K_TA:
        hc_text_raw(ctx, tx, len);
        break;
    case HC_K_OPT:
    case HC_K_BTN:
        hc_label_add(fr, tx, len);
        break;
    default:
        hc_text_norm(ctx, tx, len);
        break;
    }
}

static void hc_sax_close(void *ud, HtmlElement *el)
{
    hc_sax_t *s = (hc_sax_t *)ud;

    if (s->skip_depth) { s->skip_depth--; return; }

    /* снять кадры до элемента (неявные закрытия приходят СОБЫТИЯМИ по
     * одному, так что совпадение — обычно верхний кадр; цикл — защита) */
    while (s->depth > 0 && s->frames[s->depth].el != el) {
        hc_close_frame(&s->ctx, &s->frames[s->depth]);
        s->depth--;
    }
    if (s->depth > 0 && s->frames[s->depth].el == el) {
        hc_close_frame(&s->ctx, &s->frames[s->depth]);
        s->depth--;
    }
}

static const HtmlParseEvents hc_events = {
    NULL, hc_sax_open, hc_sax_text, hc_sax_close
};

/* ═══════════════════════════════════════════════════════
   Task 68 [HC-STREAM]: потоковая конвертация
   ═══════════════════════════════════════════════════════
   Браузер кормит куски сети, не накапливая весь HTML: конвертация
   идёт синхронно с приёмом, память О(текущий md + открытые элементы).
   Буфер md принадлежит ВЫЗЫВАТЕЛЮ и расширяется его же grow-хуком
   (в ядре нет realloc — malloc+копия+free). */

struct hc_stream {
    hc_sax_t        sax;
    HtmlParseState *st;
    HtmlElement     root_el;      /* фиктивный корень для frames[0] (LI-
                                   * уровню нужен валидный el у КАЖДОГО
                                   * кадра ниже depth) */
    int (*grow_cb)(void *ud, char **md, int *max, int want);
    void           *grow_ud;
    int             finished;
};

/* grow-хук для hc_room: расширение делает колбэк вызывателя — он
 * перевыделяет СВОЙ буфер и обновляет *md/*max (указатели ctx); в ядре
 * realloc нет — malloc+копия+free внутри колбэка браузера. */
static int hc_stream_grow(void *ud, char **md, int *max, int want)
{
    hc_stream_t *hs = (hc_stream_t *)ud;
    if (!hs->grow_cb) return 0;
    /* колбэк обязан обновить *md (новый буфер) и *max (новая ёмкость) */
    return hs->grow_cb(hs->grow_ud, md, max, want);
}

hc_stream_t *hc_stream_begin(char *md, int md_max, int hard_max,
                             int (*grow_cb)(void *ud, char **md, int *max,
                                            int want),
                             void *grow_ud)
{
    if (!md || md_max < 4) return NULL;

    /* calloc в ядре нет — malloc + обнуление (поле за полем не нужно:
     * SAX/ctx заполняются ниже, но обнулим всё сразу для безопасности) */
    hc_stream_t *hs = (hc_stream_t *)malloc((u32)sizeof(hc_stream_t));
    if (!hs) return NULL;
    memset(hs, 0, sizeof(hc_stream_t));

    hs->grow_cb = grow_cb;
    hs->grow_ud = grow_ud;

    hs->sax.frames = (hc_frame_t *)malloc((u32)sizeof(hc_frame_t)
                                          * (u32)HC_MAX_DEPTH);
    if (!hs->sax.frames) { free(hs); return NULL; }

    memset(&hs->root_el, 0, sizeof(hs->root_el));
    hs->root_el.tag = HTML_TAG_UNKNOWN;      /* как корень DOM-режима */
    hs->root_el.display = DISPLAY_BLOCK;
    hc_frame_init(&hs->sax.frames[0], &hs->root_el, HC_K_PLAIN);

    memset(&hs->sax.ctx, 0, sizeof(hs->sax.ctx));
    hs->sax.ctx.md = md;
    hs->sax.ctx.md_max = md_max;
    hs->sax.ctx.grow = grow_cb ? hc_stream_grow : NULL;
    hs->sax.ctx.grow_ud = hs;
    hs->sax.ctx.hard_max = grow_cb ? hard_max : 0;
    md[0] = 0;

    hs->st = html_parse_begin();
    if (!hs->st) { free(hs->sax.frames); free(hs); return NULL; }
    html_parse_set_events(hs->st, &hc_events, &hs->sax);
    return hs;
}

void hc_stream_feed(hc_stream_t *hs, const char *data, int len)
{
    if (!hs || hs->finished || !data || len <= 0) return;
    html_parse_stream(hs->st, NULL, data, (size_t)len);
}

int hc_stream_finish(hc_stream_t *hs, int *truncated)
{
    if (!hs) return 0;
    hc_ctx_t *ctx = &hs->sax.ctx;

    if (!hs->finished) {
        hs->finished = 1;
        html_parse_end(hs->st);       /* хвост/закрытия; state освобождён */
        hs->st = NULL;

        /* FIX [HC-PAIR]: блоки, оборванные исчерпанием буфера посреди
         * кода: закрывашка дописывается, при нехватке места ВЕСЬ блок
         * (включая открывашку) откатывается — «висячий» маркер
         * невозможен. (Как в прежнем html_to_md2.) */
        if (ctx->sc_open) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 9;
            if (hc_room(ctx, need)) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/SCRIPT\n", 9);
                ctx->mi += 9;
            } else {
                ctx->mi = ctx->sc_pos;
            }
        }
        if (ctx->ta_open) {
            int need = (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n' ? 1 : 0)
                       + 11;
            if (hc_room(ctx, need)) {
                if (ctx->mi > 0 && ctx->md[ctx->mi - 1] != '\n')
                    ctx->md[ctx->mi++] = '\n';
                memcpy(ctx->md + ctx->mi, "\x01" "/TEXTAREA\n", 11);
                ctx->mi += 11;
            } else {
                ctx->mi = ctx->ta_pos;
            }
        }
        if (ctx->mi < ctx->md_max)
            ctx->md[ctx->mi] = 0;
        else if (ctx->md_max > 0)
            ctx->md[ctx->md_max - 1] = 0;
        if (ctx->trunc && truncated) *truncated = 1;
    }
    return ctx->mi;
}

void hc_stream_abort(hc_stream_t *hs)
{
    if (!hs) return;
    /* оборвать парсер, НЕ трогая буфер вызывателя (он освободит сам) */
    if (hs->st) { html_parse_end(hs->st); hs->st = NULL; }
    free(hs->sax.frames);
    free(hs);
}

/* освободить состояние конвертера ПОСЛЕ finish (буфер вызывателя — не
 * здесь). finish сам не освобождает: браузер читает md_len из возврата. */
void hc_stream_free(hc_stream_t *hs)
{
    if (!hs) return;
    if (hs->st) { html_parse_end(hs->st); hs->st = NULL; }
    free(hs->sax.frames);
    free(hs);
}

int html_to_md2(const char *html, int html_len, char *md, int md_max,
                int *truncated)
{
    if (truncated) *truncated = 0;
    if (!md || md_max < 4) {
        if (md && md_max > 0) md[0] = 0;
        return 0;
    }
    md[0] = 0;
    if (!html || html_len <= 0) return 0;

    /* Task 68: прежний обход DOM заменён событийной конвертацией —
     * вход тот же, формат вывода тот же, памяти меньше (без дерева). */
    hc_stream_t *hs = hc_stream_begin(md, md_max, 0, NULL, NULL);
    if (!hs) return 0;
    hc_stream_feed(hs, html, html_len);
    int md_len = hc_stream_finish(hs, truncated);
    hc_stream_free(hs);
    return md_len;
}

int html_to_md(const char *html, int html_len, char *md, int md_max)
{
    return html_to_md2(html, html_len, md, md_max, NULL);
}

