/* ramfs.c — виртуальная файловая система в оперативной памяти */
#include "ramfs.h"
#include "mem.h"
#include "string.h"

/* Структура суперблока */
typedef struct {
    u32 magic;           /* 0x52414D46 = "RAMF" */
    u32 total_size;      /* общий размер в байтах */
    u32 data_offset;     /* смещение начала области данных */
    u32 file_count;      /* количество файлов */
    u32 free_offset;     /* смещение первого свободного байта в данных */
} ramfs_super_t;

#define RAMFS_MAGIC 0x52414D46u

static int ready = 0;
static u8 *ramdisk = NULL;
static u32 ramdisk_size = 0;
static ramfs_super_t *super = NULL;

/* Получить указатель на таблицу файлов (сразу после суперблока) */
static ramfs_dirent_t *file_table(void) {
    return (ramfs_dirent_t *)(ramdisk + sizeof(ramfs_super_t));
}

/* Получить указатель на область данных */
static u8 *data_area(void) {
    return ramdisk + super->data_offset;
}

/* Найти файл по имени (возвращает индекс или -1) */
static int find_file(const char *name) {
    ramfs_dirent_t *ft = file_table();
    for (u32 i = 0; i < super->file_count; i++) {
        if (strcmp(ft[i].name, name) == 0) {
            return (int)i;
        }
    }
    return -1;
}

int ramfs_init(void) {
    ready = 0;
    
    /* Выделяем 10% от доступной RAM (но не меньше 1 МиБ и не больше 64 МиБ) */
    u32 ram_mib = mem_ram_mib();
    u32 size_mib = ram_mib / 10;
    if (size_mib < 1) size_mib = 1;
    if (size_mib > 64) size_mib = 64;
    
    ramdisk_size = size_mib * 1024 * 1024;
    
    /* Выделяем память через наш аллокатор */
    ramdisk = (u8 *)malloc(ramdisk_size);
    if (!ramdisk) return 0;
    
    /* Очищаем всю область */
    memset(ramdisk, 0, ramdisk_size);
    
    /* Инициализируем суперблок */
    super = (ramfs_super_t *)ramdisk;
    super->magic = RAMFS_MAGIC;
    super->total_size = ramdisk_size;
    super->data_offset = sizeof(ramfs_super_t) + RAMFS_MAX_FILES * sizeof(ramfs_dirent_t);
    super->file_count = 0;
    super->free_offset = 0;
    
    ready = 1;
    return 1;
}

int ramfs_ready(void) {
    return ready;
}

int ramfs_create(const char *name, u32 size) {
    if (!ready || !name || !ramdisk) return 0;
    if (strlen(name) > RAMFS_NAME_MAX) return 0;
    
    /* Проверяем, нет ли уже такого файла */
    if (find_file(name) >= 0) return 0;
    
    /* Проверяем, есть ли место */
    u32 needed = super->free_offset + size;
    if (needed > (ramdisk_size - super->data_offset)) return 0;
    
    /* Проверяем, есть ли место в таблице файлов */
    if (super->file_count >= RAMFS_MAX_FILES) return 0;
    
    /* Добавляем запись в таблицу */
    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[super->file_count];
    
    strncpy(entry->name, name, RAMFS_NAME_MAX);
    entry->name[RAMFS_NAME_MAX] = 0;
    entry->size = size;
    entry->offset = super->free_offset;
    entry->is_dir = 0;
    
    /* Обновляем суперблок */
    super->file_count++;
    super->free_offset += size;
    
    return 1;
}

int ramfs_write(const char *name, const void *buf, u32 size) {
    if (!ready || !name || !buf) return 0;
    
    int idx = find_file(name);
    if (idx < 0) return 0;
    
    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[idx];
    
    /* Проверяем размер */
    if (size > entry->size) size = entry->size;
    
    /* Копируем данные */
    u8 *data = data_area() + entry->offset;
    memcpy(data, buf, size);
    
    /* Обновляем размер (если записали меньше, чем выделено) */
    entry->size = size;
    
    return 1;
}

u32 ramfs_read(const char *name, void *buf, u32 max) {
    if (!ready || !name || !buf) return 0;
    
    int idx = find_file(name);
    if (idx < 0) return 0;
    
    ramfs_dirent_t *ft = file_table();
    ramfs_dirent_t *entry = &ft[idx];
    
    /* Ограничиваем чтение размером файла и буфера */
    u32 to_read = entry->size;
    if (to_read > max) to_read = max;
    
    /* Копируем данные */
    u8 *data = data_area() + entry->offset;
    memcpy(buf, data, to_read);
    
    return to_read;
}

int ramfs_delete(const char *name) {
    if (!ready || !name) return 0;
    
    int idx = find_file(name);
    if (idx < 0) return 0;
    
    ramfs_dirent_t *ft = file_table();
    
    /* Сдвигаем все последующие записи влево */
    for (u32 i = (u32)idx; i < super->file_count - 1; i++) {
        ft[i] = ft[i + 1];
    }
    
    /* Очищаем последнюю запись */
    memset(&ft[super->file_count - 1], 0, sizeof(ramfs_dirent_t));
    super->file_count--;
    
    /* Примечание: память данных не освобождается (упрощение) */
    
    return 1;
}

int ramfs_list(ramfs_dirent_t *out, int max) {
    if (!ready || !out) return 0;
    
    ramfs_dirent_t *ft = file_table();
    int count = 0;
    
    for (u32 i = 0; i < super->file_count && count < max; i++) {
        out[count++] = ft[i];
    }
    
    return count;
}

u32 ramfs_free_space(void) {
    if (!ready) return 0;
    return ramdisk_size - super->data_offset - super->free_offset;
}

u32 ramfs_total_space(void) {
    if (!ready) return 0;
    return ramdisk_size - super->data_offset;
}