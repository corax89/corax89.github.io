/* filedlg.h — стандартные диалоги открытия и сохранения файлов N2600-OS.
 *
 * Общие диалоги в стиле «классического» файлового диалога: панель источников
 * (RAM disk / HDD / USB), навигация по каталогам FAT32, список файлов с
 * фильтром расширений, поле ввода имени, кнопки. Диалог открытия умеет
 * читать со всех смонтированных источников; диалог сохранения работает
 * с RAM disk — единственной перезаписываемой ФС (FAT32/ISO доступны
 * только для чтения), с подтверждением перезаписи.
 *
 * Диалоги асинхронны (event-driven, как весь WM): результат доставляется
 * колбэком. Пока диалог открыт, вызывающему окну следует игнорировать
 * ввод — проверяйте свой флаг «диалог открыт» (см. apps_editor.c).
 *
 * Буфер content в on_open_ok передаётся во владение вызывающему —
 * он обязан free() его после использования.
 *
 * Пример:
 *   static void my_open_ok(void *ctx, const fd_pick_t *pick,
 *                          char *content, int len) {
 *       my_app_t *a = (my_app_t *)ctx;
 *       ... скопировать content в буфер приложения ...
 *       free(content);
 *       a->dlg = 0;              \* диалог закрылся, ввод снова активен *\
 *   }
 *   static void my_cancel(void *ctx) {
 *       my_app_t *a = (my_app_t *)ctx;
 *       a->dlg = 0;
 *   }
 *   ...
 *   a->dlg = 1;
 *   filedlg_open("Открыть файл", ".c,.js,.txt", NULL,
 *                my_open_ok, my_cancel, a);
 */
#ifndef FILEDLG_H
#define FILEDLG_H

#include "types.h"

/* Источники файлов для диалога открытия. */
typedef enum {
    FD_SRC_RAMFS = 0,   /* RAM disk (перезаписываемый)   */
    FD_SRC_ATA    = 1,  /* HDD: FAT32 через ATA (чтение) */
    FD_SRC_USB    = 2   /* USB-флешка: FAT32 (чтение)    */
} fd_source_t;

#define FD_NAME_MAX 64        /* как RAMFS_NAME_MAX */

/* Результат выбора файла в диалоге открытия. */
typedef struct {
    fd_source_t source;          /* источник, из которого прочитан файл */
    char        name[FD_NAME_MAX + 1];   /* имя файла (без пути) */
    char        path[200];       /* полный путь (FAT32) или имя (RAMFS) */
    char        dir[200];        /* СЕССИЯ 14: каталог (без имени) — цель обратного сохранения */
    u32         cluster;         /* СЕССИЯ 14: FAT32 — кластер каталога */
} fd_pick_t;

/* СЕССИЯ 14: результат диалога сохранения — КУДА сохранить.
 * Запрос пользователя: «диалог сохранения/загрузки должен использовать
 * диски так же, как файловый менеджер». Теперь источник выбирается
 * кнопками [RAM]/[HDD]/[USB] (навигация по подкаталогам), а колбэк
 * получает полное назначение. */
typedef struct {
    fd_source_t source;          /* RAM / HDD(FAT32) / USB(FAT32) */
    char        path[200];       /* каталог назначения (без имени) */
    u32         cluster;         /* FAT32: кластер каталога назначения */
    char        name[FD_NAME_MAX + 1];
} fd_save_t;

/* Диалог открытия файла.
 *   title       — заголовок окна;
 *   filter      — список расширений через запятую, напр. ".c,.js,.txt";
 *                 каталоги показываются всегда; "*" или NULL — все файлы;
 *   default_name— имя, подставляемое в поле ввода (NULL = пустое);
 *   on_open_ok  — вызывается, когда файл прочитан: pick — откуда и что,
 *                 content — содержимое (malloc, до FD_READ_MAX байт),
 *                 владение буфером переходит к вызывающему (он free()ит);
 *   on_cancel   — вызывается при Esc/«Отмена»/закрытии окна диалога
 *                 (может быть NULL);
 *   ctx         — указатель, транслируемый в колбэки (обычно состояние app).
 * Диалог закрывается сам; повторный вызов из on_* допустим. */
void filedlg_open(const char *title, const char *filter, const char *default_name,
                  void (*on_open_ok)(void *ctx, const fd_pick_t *pick,
                                     char *content, int len),
                  void (*on_cancel)(void *ctx),
                  void *ctx);

/* Диалог сохранения файла (СЕССИЯ 14: любой перезаписываемый источник —
 * RAM disk или FAT32 на HDD/USB — с навигацией по подкаталогам,
 * как в файловом менеджере).
 *   title        — заголовок окна;
 *   default_name — имя, подставляемое в поле ввода (NULL = пустое);
 *   default_src  — источник при открытии (FD_SRC_RAMFS/ATA/USB);
 *   on_save_ok   — вызывается после подтверждения (в т.ч. перезаписи):
 *                  save — КУДА сохранить (источник+путь+кластер+имя);
 *   on_cancel    — Esc/«Отмена»/закрытие (может быть NULL);
 *   ctx          — контекст для колбэков.
 * Подтверждение перезаписи встроено и работает для каждого источника. */
void filedlg_save(const char *title, const char *default_name, fd_source_t default_src,
                  void (*on_save_ok)(void *ctx, const fd_save_t *save),
                  void (*on_cancel)(void *ctx),
                  void *ctx);

/* Лимит чтения файла в диалоге открытия. */
#define FD_READ_MAX 65536

/* Task 66 [FD-DETACH]: отвязать колбэки у ВСЕХ живых диалогов с данным
 * ctx (владелец закрывается — use-after-free в колбэках невозможен).
 * Вызывать ПЕРЕД освобождением состояния-владельца. */
void filedlg_detach_ctx(void *ctx);

#endif /* FILEDLG_H */

/* ================= диалог ввода имени (сессия 13) =================
 * Переиспользуемый модальный ввод одной строки (имя папки/файла).
 * Как и все диалоги — асинхронный: результат приходит в колбэк окну-
 * вызывающему; окну-владельцу следует игнорировать ввод, пока открыт
 * (флаг dlg у приложения). Enter — OK, Esc — отмена, клик по кнопкам. */
typedef void (*fd_input_ok_fn)(void *ctx, const char *name);
typedef void (*fd_input_cancel_fn)(void *ctx);

/* title — заголовок окна; prompt — подсказка (над полем); defname —
 * значение по умолчанию (может быть NULL); maxlen — лимит ввода. */
void filedlg_input_open(const char *title, const char *prompt,
                         const char *defname, int maxlen,
                         fd_input_ok_fn ok, fd_input_cancel_fn cancel,
                         void *ctx);
