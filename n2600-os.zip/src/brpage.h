/* brpage.h — разбор страницы браузера N2600-OS: картинки и ссылки.
 * Header-only (ядро и хост-тест включают один и тот же код).
 *
 * Сессия 55. Конвейер страницы:
 *   1. htmlconv.c даёт Markdown, где
 *        <a href="U">T</a> -> [T](U)      (полная ссылка)
 *        <img src="U" alt="A"> -> ![A](U) (СТРОКА-маркер отдельным абзацем)
 *   2. brp_analyze() сканирует исходник (md):
 *        - каждую СТРОКУ-маркер ![...](...) заменяет односимвольным
 *          якорем BRP_IMG_MARK и запоминает запись картинки
 *          (сжатие md "на месте", индексы строк честные);
 *   Сессия 56 (ссылки выглядят как ссылки):
 *        - собирает ссылки [T](U), затем ВЫРЕЗАЕТ разметку из md:
 *          остаётся только видимый текст T, а в записи ссылки — байтовый
 *          интервал T в НОВОМ md (b_abs..t_end_abs). Браузер рисует T
 *          синим с подчёркиванием (brp_link_segs) и открывает URL по
 *          клику (brp_click_link). Раньше пользователь видел сырую
 *          разметку [example.com](http://example.com/).
 *        - строит таблицу смещений строк line_off[] (ДО вырезания —
 *          после вырезания смещения строк пересчитывать не нужно:
 *          line_off нужен только кликам, а клики переводят
 *          (строка отображения, колонка) -> байт НОВОГО md... но line_off
 *          заполнен на старом md! Поэтому line_off корректируется по ходу
 *          вырезания: каждая строка с номером >= строки вырезания
 *          сдвигается на дельту. Проще: line_off строится ПОСЛЕ
 *          вырезания вторым проходом по финальному md.)
 *   3. brl_wrap() (brlines.h) переносит md; каждая строка отображения
 *      знает srcidx/srcoff (кусок какой строки и с какого байта).
 *   4. Браузер вставляет пустые строки под высоту картинок, рисует
 *      сегменты ссылок и по клику зовёт brp_click_link():
 *      (srcidx, srcoff, колонка) -> URL.
 *
 * Зависимости: malloc/free/memcpy/strncpy/strlen (ядро: mem.h/string.h),
 * utf8_next (string.h). */
#ifndef BRPAGE_H
#define BRPAGE_H

#ifndef BRP_IMG_MARK
#define BRP_IMG_MARK '\002'   /* односимвольный якорь картинки в md */
#endif

/* FIX [BR-LONGPAGE]: раньше 12 картинок / 48 ссылок — на длинных
 * страницах всё, что дальше, молча терялось (не кликалось, не грузилось).
 * 24/128: brp_page_t живёт в heap-структуре браузера (+~36 КиБ на окно
 * — приемлемо при куче 512 МБ). */
#define BRP_MAX_IMGS  48   /* Task 68: было 24 — фоновая загрузка делает
                            * больше картинок осмысленными (+~8 КиБ на окно) */
#define BRP_MAX_LINKS 128
#define BRP_URL_MAX   300   /* Task 66: было 220 — длинные URL трекинга
                            * (согласовано с HC_HREF_MAX) */

typedef struct {
    int  src_idx;              /* индекс исходной строки md (якорь) */
    int  state;                /* 0 = ждёт, 1 = готова, -1 = ошибка */
    char url[BRP_URL_MAX];
    int  w, h;                 /* декодированный размер */
    u8  *rgba;                 /* готовый к blit буфер (масштабированный) */
    int  dw, dh;               /* размер отрисовки */
    int  row, rows;            /* layout: строка-якорь и высота в строках */
    int  noauto;               /* Task 68 [BR-BGIMG]: выгружена по бюджету —
                                * НЕ перезагружать автоматически (луп);
                                * снимается новой страницей / F5 */
} brp_img_t;

typedef struct {
    int  src_idx;              /* исходная строка */
    /* Сессия 56: интервал ВИДИМОГО текста ссылки в финальном md
     * (разметка [T](U) вырезана): b_abs = байт первого байта T,
     * t_end_abs = байт ЗА последним байтом T. p_end_abs == t_end_abs
     * (оставлено для совместимости). */
    int  b_abs;
    int  t_end_abs;
    int  p_end_abs;
    char url[BRP_URL_MAX];
} brp_link_t;

typedef struct {
    brp_img_t  imgs[BRP_MAX_IMGS];
    int        nimgs;
    brp_link_t links[BRP_MAX_LINKS];
    int        nlinks;
    int       *line_off;       /* смещение байта каждой строки md */
    int        nlines;
    int        line_cap;
} brp_page_t;

/* Освободить пиксельные буферы картинок (сам md НЕ здесь). */
static void brp_free_images(brp_page_t *p)
{
    if (!p) return;
    for (int i = 0; i < p->nimgs; i++) {
        if (p->imgs[i].rgba) free(p->imgs[i].rgba);
        p->imgs[i].rgba = NULL;
        p->imgs[i].state = 0;
    }
    p->nimgs = 0;
}

static void brp_reset(brp_page_t *p)
{
    if (!p) return;
    brp_free_images(p);
    p->nlinks = 0;
    p->nlines = 0;
}

/* Сколько байт занимает col-й СИМВОЛ строки s[0..len)? Без выхода за len. */
static int brp_byte_of_col(const char *s, int len, int col)
{
    const char *p = s;
    const char *end = s + len;
    int c = 0;
    while (p < end && c < col) {
        utf8_next(&p);
        c++;
    }
    return (int)(p - s);
}

/* Вставка: удалить [d_from, d_to) и вписать repl[0..rlen) (со сдвигом
 * хвоста). Возвращает новую длину. len — текущая длина. */
static int brp_splice(char *md, int len, int d_from, int d_to,
                      const char *repl, int rlen)
{
    if (d_from < 0 || d_to > len || d_from > d_to) return len;
    if (rlen > d_to - d_from) {
        int extra = rlen - (d_to - d_from);
        for (int i = len; i >= d_to; i--)
            md[i + extra] = md[i];
    } else if (rlen < d_to - d_from) {
        int shift = (d_to - d_from) - rlen;
        for (int i = d_to; i <= len; i++)
            md[i - shift] = md[i];
    }
    for (int i = 0; i < rlen; i++)
        md[d_from + i] = repl[i];
    return len - (d_to - d_from) + rlen;
}

/* Записать смещение строки idx (массив line_off растёт удвоением). */
static int brp_line_off_put(brp_page_t *p, int idx, int off)
{
    if (idx >= p->line_cap) {
        int ncap = p->line_cap ? p->line_cap * 2 : 128;
        while (ncap <= idx) ncap *= 2;
        int *nl = (int *)malloc((u32)ncap * sizeof(int));
        if (!nl) return 0;
        if (p->line_off) {
            memcpy(nl, p->line_off, (u32)p->nlines * sizeof(int));
            free(p->line_off);
        }
        p->line_off = nl;
        p->line_cap = ncap;
    }
    p->line_off[idx] = off;
    if (idx + 1 > p->nlines) p->nlines = idx + 1;
    return 1;
}

/* Добавить ссылку (место кончилось — молча игнор). */
static void brp_add_link(brp_page_t *p, int src_idx, int b_abs,
                         int t_end_abs, int p_end_abs,
                         const char *url, int url_len)
{
    if (p->nlinks >= BRP_MAX_LINKS) return;
    if (url_len <= 0 || url_len >= BRP_URL_MAX) return;
    brp_link_t *l = &p->links[p->nlinks++];
    l->src_idx = src_idx;
    l->b_abs = b_abs;
    l->t_end_abs = t_end_abs;
    l->p_end_abs = p_end_abs;
    memcpy(l->url, url, (u32)url_len);
    l->url[url_len] = 0;
}

/* Сколько СИМВОЛОВ в s[0..byte_limit) байтах (без выхода за len). */
static int brp_col_of_byte(const char *s, int len, int byte_limit)
{
    const char *p = s;
    const char *end = s + len;
    const char *lim = s + byte_limit;
    int c = 0;
    while (p < end && p < lim) {
        utf8_next(&p);
        c++;
    }
    return c;
}

/* Ссылки на строке: СОБРАТЬ ВСЕ "[T](U)" (без '!' перед '['). URL без
 * '\n'. Пустой U ("]()") — НЕ ссылка. Возвращает число найденных.
 * Смещения — на ТЕКУЩИЙ md (вырезание выполняет brp_analyze). */
static int brp_line_links(brp_page_t *p, int src_idx, const char *ls,
                          int llen, int base)
{
    int found = 0;
    for (int i = 0; i < llen; i++) {
        if (ls[i] != '[') continue;
        if (i > 0 && ls[i - 1] == '!') { i++; continue; }
        /* ищем "](" */
        int j = i + 1;
        while (j < llen && ls[j] != ']') {
            if (ls[j] == '\n') break;
            j++;
        }
        if (j >= llen || ls[j] != ']' || j + 1 >= llen || ls[j + 1] != '(')
            continue;
        int k = j + 2;
        while (k < llen && ls[k] != ')') {
            if (ls[k] == '\n') break;
            k++;
        }
        if (k < llen && ls[k] == ')' && k > j + 2) {
            int ulen = k - (j + 2);
            brp_add_link(p, src_idx, base + i, base + j + 1, base + k + 1,
                         ls + (j + 2), ulen);
            found++;
            i = k;   /* продолжаем ПОСЛЕ ')': соседние ссылки тоже собираем */
        } else {
            i = k > i ? k : i;
        }
    }
    return found;
}

/* РАЗБОР СТРАНИЦЫ. md МОДИФИЦИРУЕТСЯ (маркеры картинок -> якоря).
 * md_len — длина полезных данных; md должен иметь запас +1 байт в конце
 * (NUL терминатор вызывающего). Возвращает новую длину. */
static int brp_analyze(brp_page_t *p, char *md, int md_len)
{
    brp_reset(p);

    /* --- проход 1: картинки --- */
    int li = 0;                 /* индекс строки */
    int pos = 0;                /* байт начала строки */
    while (pos < md_len) {
        int nl = pos;
        while (nl < md_len && md[nl] != '\n') nl++;
        int llen = nl - pos;
        if (llen > 0 && md[llen - 1] == '\r') llen--;

        /* маркер: [пробелы] "![" ... "](" ... ")" */
        int s = 0;
        while (s < llen && (md[pos + s] == ' ' || md[pos + s] == '\t')) s++;
        if (s + 1 < llen && md[pos + s] == '!' && md[pos + s + 1] == '[') {
            int j = s + 2;
            while (j + 1 < llen && !(md[pos + j] == ']' && md[pos + j + 1] == '('))
                j++;
            if (j + 1 < llen) {
                int us = j + 2;
                int ue = us;
                while (ue < llen && md[pos + ue] != ')') ue++;
                if (ue < llen && ue > us) {
                    int ulen = ue - us;
                    if (ulen < BRP_URL_MAX && p->nimgs < BRP_MAX_IMGS) {
                        brp_img_t *im = &p->imgs[p->nimgs++];
                        im->src_idx = li;
                        im->state = 0;
                        im->w = im->h = 0;
                        im->rgba = NULL;
                        im->dw = im->dh = 0;
                        im->row = im->rows = 0;
                        im->noauto = 0;   /* Task 68 */
                        memcpy(im->url, md + pos + us, (u32)ulen);
                        im->url[ulen] = 0;
                        /* строка -> якорь */
                        md_len = brp_splice(md, md_len, pos, nl,
                                            "\002", 1);
                        nl = pos + 1;
                        llen = 1;
                    }
                }
            }
        }

        if (!brp_line_off_put(p, li, pos)) break;

        li++;
        if (nl >= md_len) break;
        pos = nl + 1;
    }

    /* --- проход 2: собрать ВСЕ ссылки на текущий md ---
     * (line_off здесь НЕ трогаем: после вырезания он перестроится
     * третьим проходом по финальному md.) */
    pos = 0;
    for (li = 0; li < p->nlines; li++) {
        int nl = pos;
        while (nl < md_len && md[nl] != '\n') nl++;
        int llen = nl - pos;
        if (llen > 0 && md[llen - 1] == '\r') llen--;
        brp_line_links(p, li, md + pos, llen, pos);
        if (nl >= md_len) break;
        pos = nl + 1;
    }

    /* --- проход 3: вырезать разметку [T](U) -> T (СПРАВА НАЛЕВО) ---
     * Вырезаем [b_abs, p_end) и оставляем текст T (он внутри диапазона,
     * source > dest при копировании вперёд — как memmove влево, читаем
     * всегда ПЕРЕД записью). Смещения ещё не обработанных (левых)
     * ссылок не меняются. */
    for (int i = p->nlinks - 1; i >= 0; i--) {
        brp_link_t *l = &p->links[i];
        /* T занимает байты [b_abs+1, t_end_abs-1): t_end_abs указывает
         * ЗА ']' — отсюда -2 (FIX: раньше -1 давало лишний байт). */
        int t_len = l->t_end_abs - l->b_abs - 2;
        int span = l->p_end_abs - l->b_abs;
        if (t_len < 0 || span < 0 || l->p_end_abs > md_len) continue;
        /* ВАЖНО: НЕ brp_splice — его сдвиг хвоста идёт ДО копирования
         * и при перекрытии затирал ПОСЛЕДНИЙ байт T (хвост писался в
         * [p_end-drop, ...) поверх исходника T). Порядок здесь: сначала
         * текст влево на 1 ('[' удаляется; читаем ВСЕГДА впереди
         * записи), затем хвост строки влево на (span - t_len). */
        for (int k = 0; k < t_len; k++)
            md[l->b_abs + k] = md[l->b_abs + 1 + k];
        int drop = span - t_len;
        for (int k = l->p_end_abs; k <= md_len; k++)
            md[k - drop] = md[k];
        md_len -= drop;
        l->t_end_abs = l->b_abs + t_len;   /* '[' удалён: T теперь с b_abs */
        l->p_end_abs = l->t_end_abs;
        /* уже обработанные (ПРАВЕЕ) ссылки тоже сдвинулись влево */
        for (int k = i + 1; k < p->nlinks; k++) {
            p->links[k].b_abs -= drop;
            p->links[k].t_end_abs -= drop;
            p->links[k].p_end_abs -= drop;
        }
    }

    /* --- проход 4: line_off по ФИНАЛЬНОМУ md (сброс и перестройка) --- */
    p->nlines = 0;
    pos = 0;
    li = 0;
    while (pos < md_len) {
        if (!brp_line_off_put(p, li, pos)) break;
        while (pos < md_len && md[pos] != '\n') pos++;
        if (pos >= md_len) break;
        pos++;
        li++;
    }

    return md_len;
}

/* Сессия 56: СЕГМЕНТЫ ссылок для отрисовки. Для куска отображения
 * (байты [piece_abs0, piece_abs0+piece_len) финального md, строка
 * src_idx) возвращает пересечения с интервалами видимого текста
 * ссылок в КОЛОНКАХ куска (символы, 1 колонка = 8 px). Сегменты
 * отсортированы по col0 (ссылки собирались слева направо).
 * Возвращает число сегментов (максимум out_max). */
typedef struct { int col0, col1; } brp_seg_t;

static int brp_link_segs(brp_page_t *p, int src_idx, int piece_abs0,
                         const char *piece, int piece_len,
                         brp_seg_t *out, int out_max)
{
    int n = 0;
    if (!p || !piece || piece_len <= 0 || !out) return 0;
    int piece_abs1 = piece_abs0 + piece_len;
    for (int i = 0; i < p->nlinks; i++) {
        const brp_link_t *l = &p->links[i];
        if (l->src_idx != src_idx) continue;
        int a = l->b_abs, b = l->t_end_abs;
        if (a < piece_abs0) a = piece_abs0;
        if (b > piece_abs1) b = piece_abs1;
        if (b <= a) continue;
        if (n >= out_max) break;
        out[n].col0 = brp_col_of_byte(piece, piece_len, a - piece_abs0);
        out[n].col1 = brp_col_of_byte(piece, piece_len, b - piece_abs0);
        n++;
    }
    return n;
}

/* КЛИК -> ссылка.
 *   srcidx/srcoff — поля строки отображения (brlines.h): кусок какой
 *                   исходной строки и с какого байта;
 *   piece/piece_len — текст куска (строка отображения);
 *   col           — колонка клика в СИМВОЛАХ куска;
 *   allow_tail    — 1: попадание в ЛЮБУЮ колонку куска, если в этой
 *                   исходной строке ровно одна ссылка (хвост переноса).
 * Возвращает URL или NULL (мимо). Точное попадание — байт клика внутри
 * ВИДИМОГО текста ссылки [b_abs, t_end_abs) (сессия 56: разметка
 * вырезана, интервалы — по финальному md). */
static const char *brp_click_link(brp_page_t *p, const char *md,
                                   int srcidx, int srcoff,
                                   const char *piece, int piece_len,
                                   int col, int allow_tail)
{
    if (!p || !md || srcidx < 0 || srcidx >= p->nlines || !p->line_off)
        return NULL;
    int line_base = p->line_off[srcidx];

    /* позиция клика внутри исходной строки (байты) */
    int in_piece = brp_byte_of_col(piece, piece_len, col);
    int bytepos = line_base + srcoff + in_piece;

    int hits = 0;
    const brp_link_t *only = NULL;
    for (int i = 0; i < p->nlinks; i++) {
        const brp_link_t *l = &p->links[i];
        if (l->src_idx != srcidx) continue;
        hits++;
        only = l;
        /* видимый текст ссылки (сессия 56: разметка вырезана) */
        if (bytepos >= l->b_abs && bytepos < l->t_end_abs)
            return l->url;
    }
    if (allow_tail && hits == 1 && only)
        return only->url;          /* перенос ссылки на соседнюю строку */
    return NULL;
}

#endif /* BRPAGE_H */
