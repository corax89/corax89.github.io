/* string.h — минимальная freestanding-библиотека строк (GCC сам вызывает
 * memcpy/memset/memmove даже в freestanding-режиме, поэтому имена стандартные) */
#ifndef STRING_H
#define STRING_H

#include "types.h"

void  *memset(void *dst, int c, u32 n);
void  *memcpy(void *dst, const void *src, u32 n);
void  *memmove(void *dst, const void *src, u32 n);
int    memcmp(const void *a, const void *b, u32 n);
u32    strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, u32 n);
char  *strcpy(char *dst, const char *src);
char  *strncpy(char *dst, const char *src, u32 n);
char *strchr(const char *s, int c);

int    snprintf(char *out, u32 n, const char *fmt, ...);
int    vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap);

/* чтение следующего UTF-8 символа (1-2 байта; 3+ байта -> '?').
   Возвращает кодовую позицию, сдвигает *ps. */
unsigned utf8_next(const char **ps);

#endif /* STRING_H */
