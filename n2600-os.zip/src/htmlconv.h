/* htmlconv.h — HTML -> Markdown конвертер N2600-OS.
 *
 * Выделен из apps_browser.c в отдельный модуль:
 *   1) конвертер нужен и браузеру, и терминалу (curl), и хостовому тесту
 *      (scripts/test_htmlconv.c) — единая точка правды;
 *   2) буфер результата передаётся ВЫЗЫВАЮЩИМ (раньше был static char
 *      md[8192] внутри браузера — общий на все окна, см. FIX [H2]).
 *
 * Соглашения:
 *   html_to_md2(html, html_len, md, md_max, *truncated) — все границы
 *   проверяются, результат НЕ выходит за md_max-2, всегда
 *   NUL-терминирован (md[len]=0). Возвращает длину результата. При
 *   нехватке места — обрезка, *truncated (если не NULL) = 1: вызыватель
 *   (браузер) обязан показать «страница обрезана» вместо молчаливой
 *   потери хвоста (FIX [HC-TRUNC], Task 60).
 *   html_to_md(...) — обёртка над html_to_md2 (truncated == NULL).
 *
 * Task 60 [HC-DOM]: разбор входа выполняет html_parser.c (DOM-парсер),
 * htmlconv обходит дерево и выдаёт Markdown/маркеры. Прежние ручные
 * эвристики (сканирование '<', кавычек, комментариев, прыжков через
 * script/style) убраны. Маркерные строки \x01... пишутся АТОМАРНО
 * (строка целиком или никак), блоки \x01SCRIPT/\x01TEXTAREA
 * гарантированно закрываются либо откатываются целиком — «висячих»
 * маркеров больше не бывает (FIX [HC-PAIR], Task 60).
 */
#ifndef HTMLCONV_H
#define HTMLCONV_H

#ifdef __cplusplus
extern "C" {
#endif

int html_to_md(const char *html, int html_len, char *md, int md_max);
int html_to_md2(const char *html, int html_len, char *md, int md_max,
                int *truncated);

/* Task 67 [HC-AGGR]: «читательский» режим (по умолчанию ВЫКЛЮЧЕН).
 * 1 = выкидывать поддеревья <nav>/<footer>/<aside>/<noscript>
 * (навигация-дубли, счётчики, «включите JavaScript»). Рискованно: в
 * <nav> иногда лежит основной контент, поэтому по умолчанию off —
 * вызывающий включает осознанно (Reader Mode). */
void htmlconv_set_aggressive(int on);

/* ═══ Task 68 [HC-STREAM]: потоковая конвертация ═══
 * Мотивация: страницы-многомегабайтики (инлайн-скрипты/стили) не
 * влезают в буфер HTTP-ответа — приходилось обрезать. Потоковый режим
 * принимает куски сети по мере приёма: НИКАКОГО полного HTML в памяти,
 * конвертация синхронна с загрузкой. md НЕ обязан вмещать «3x входа»:
 * буфер растит САМ вызыватель через grow-хук (в ядре нет realloc —
 * malloc+копия+free; hc_ctx хранит только ИНДЕКСЫ, поэтому перенос
 * буфера безопасен). Элементы DOM не строятся вовсе (режим [HP-EVENT]
 * парсера): память О(текст md + открытые элементы).
 *
 *   hs = hc_stream_begin(md, cap, HARD_MAX, br_md_grow, b);
 *   ... hc_stream_feed(hs, chunk, n);      // каждый кусок тела
 *   md_len = hc_stream_finish(hs, &trunc);
 *   hc_stream_free(hs);                    // буфер md остаётся за браузером
 *
 * При ошибке сети вместо finish — hc_stream_abort (буфер освободит
 * браузер). Формат вывода ИДЕНТИЧЕН html_to_md2 (один код эффектов). */
typedef struct hc_stream hc_stream_t;

hc_stream_t *hc_stream_begin(char *md, int md_max, int hard_max,
                             int (*grow)(void *ud, char **md, int *max, int want),
                             void *grow_ud);
void hc_stream_feed(hc_stream_t *hs, const char *data, int len);
int  hc_stream_finish(hc_stream_t *hs, int *truncated);
void hc_stream_abort(hc_stream_t *hs);
void hc_stream_free(hc_stream_t *hs);

#ifdef __cplusplus
}
#endif

#endif /* HTMLCONV_H */
