/* gma3600.c — нативный режим 1024x600 на LVDS-панели нетбука с графикой
 * GMA3600/GMA3650 (Cedarview = CDV; Atom N2600/D2550 + SGX545).
 *
 * Зачем: VBIOS GMA3600 по VBE отдаёт очень короткий список режимов
 * (пользовательский нетбук: GRUB с цепочкой вплоть до 1024x600x32
 * сваливается на 800x600x32) — нативное 1024x600 нужно программировать
 * самому, как это делает Linux-драйвер gma500.
 *
 * Эталон (GPL-2.0), все значения сверены с torvalds/linux v6.1:
 *   drivers/gpu/drm/gma500/cdv_intel_display.c  — последовательность
 *     mode_set: DPLL(без VCO) -> sideband M/N/P -> udelay(150) ->
 *     LVDS -> DPLL|VCO_ENABLE -> udelay(150) -> проверка DPLL_LOCK ->
 *     dpll_md=0 -> pipe timings -> size/pos/src -> pipeconf ->
 *     vblank(20мс) -> plane cntr -> base-flush -> vblank -> watermarks
 *   psb_intel_reg.h — адреса и биты (см. G_* ниже)
 *   cdv_device.c   — cdv_regmap (per-pipe смещения), PCI ID 0x0be0..0bef
 *   cdv_intel_lvds.c — выбор pipe по LVDS_PIPEB_SELECT
 *   drm_modes.c drm_gtf_mode_complex — GTF-модлайн (порт)
 *
 * КЛЮЧЕВАЯ особенность CDV: параметры DPLL лежат не в FP-регистрах
 * (i915-наследие), а за sideband-шиной DPIO (SB_PCKT/SB_ADDR/SB_DATA),
 * причём p2 для LVDS single = 14, m = m2+2, vco = ref*m/n, dot = vco/p.
 *
 * Безопасность: перед любыми записями снимок каждого регистра; при
 * неудаче (DPLL_LOCK не пришёл) — восстановление в обратном порядке и
 * возврат 0: экран остаётся в режиме загрузчика. BASE плоскости не
 * трогаем вообще — VBIOS уже направил развёртку в LFB, который
 * сообщил GRUB (multiboot); меняются только timings/stride/размер.
 *
 * Задержки: udelay — чтения порта 0x80 (≈1 мкс/шт); mdelay — по
 * timer_ticks() (1000 Гц). */
#include "gma3600.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "io.h"
#include "kernel.h"

/* ---------------- регистры (psb_intel_reg.h, cdv_device.c) ----------------
 * pipe-зависимые: HTOTAL_A 0x60000 .. VSYNC_A 0x60014, PIPEASRC 0x6001c;
 * pipe B = +0x1000. PIPEACONF 0x70008 / PIPEBCONF 0x71008;
 * DSPACNTR 0x70180 / DSPBCNTR 0x71180, BASE/LINOFF 0x70184/0x71184,
 * STRIDE 0x70188/0x71188, POS 0x7018c/0x7118c, SIZE 0x70190/0x71190.
 * DPLL_A 0x6014 / DPLL_B 0x6018; DPLL_A_MD 0x601c / DPLL_B_MD 0x6020.
 * LVDS 0x61180 (!не 0x61120 как в i915). PFIT_CONTROL 0x61230.
 * DSPFW1 0x70034, DSPFW2 0x70038, DSPFW3 0x7003c, DSPFW5 0x70054,
 * DSPFW6 0x70058. FW_BLC_SELF 0x20e0. OV_OVADD 0x30000.
 * Sideband: SB_PCKT 0x2100, SB_DATA 0x2104, SB_ADDR 0x2108,
 * DPIO_CFG 0x2110; SB_M 0x8008/0x8028, SB_N_VCO 0x8014/0x8034,
 * SB_REF_DPLLA 0x8010, SB_REF_DPLLB 0x8030, SB_REF_SFR 0x8018/0x8038,
 * SB_P 0x801c/0x803c. */
#define G_HTOTAL(pipe)   (0x60000u + (pipe) * 0x1000u)
#define G_HBLANK(pipe)   (0x60004u + (pipe) * 0x1000u)
#define G_HSYNC(pipe)    (0x60008u + (pipe) * 0x1000u)
#define G_VTOTAL(pipe)   (0x6000cu + (pipe) * 0x1000u)
#define G_VBLANK(pipe)   (0x60010u + (pipe) * 0x1000u)
#define G_VSYNC(pipe)    (0x60014u + (pipe) * 0x1000u)
#define G_SRC(pipe)      (0x6001cu + (pipe) * 0x1000u)
#define G_CONF(pipe)     (0x70008u + (pipe) * 0x1000u)
#define G_CNTR(pipe)     (0x70180u + (pipe) * 0x1000u)
#define G_STRIDE(pipe)   (0x70188u + (pipe) * 0x1000u)
#define G_POS(pipe)      (0x7018cu + (pipe) * 0x1000u)
#define G_SIZE(pipe)     (0x70190u + (pipe) * 0x1000u)
#define G_BASE(pipe)     (0x70184u + (pipe) * 0x1000u)   /* только чтение/флаш */
#define G_DPLL(pipe)     ((pipe) ? 0x6018u : 0x6014u)
#define G_DPLL_MD(pipe)  ((pipe) ? 0x6020u : 0x601cu)
#define G_SB_M(pipe)     ((pipe) ? 0x8028u : 0x8008u)
#define G_SB_NVCO(pipe)  ((pipe) ? 0x8034u : 0x8014u)
#define G_SB_REFCLK(pipe) ((pipe) ? 0x8030u : 0x8010u)
#define G_SB_REFSFR(pipe) ((pipe) ? 0x8038u : 0x8018u)
#define G_SB_P(pipe)     ((pipe) ? 0x803cu : 0x801cu)

/* биты (psb_intel_reg.h) */
#define G_DPLL_VCO        (1u << 31)   /* DPLL_VCO_ENABLE */
#define G_DPLL_SYNCLOCK   (1u << 29)
#define G_DPLL_VGADIS     (1u << 28)
#define G_DPLL_LOCK       (1u << 15)   /* CDV: статус захвата */
#define G_PIPE_ENABLE     (1u << 31)   /* PIPEACONF_ENABLE */
#define G_BPC_MASK        (7u << 5)    /* PIPE_BPC_MASK */
#define G_BPC_8           (0u << 5)    /* PIPE_8BPC */
#define G_BPC_6           (2u << 5)    /* PIPE_6BPC */
#define G_PLANE_ENABLE    (1u << 31)   /* DISPLAY_PLANE_ENABLE */
#define G_PIXFMT_MASK     (0xfu << 26)
#define G_PIXFMT_32       (0x6u << 26) /* DISPPLANE_32BPP_NO_ALPHA */
#define G_SEL_PIPE_B      (1u << 24)   /* DISPPLANE_SEL_PIPE_B */
#define G_LVDS_PORT_EN    (1u << 31)
#define G_LVDS_PIPEB      (1u << 30)   /* LVDS_PIPEB_SELECT */
#define G_LVDS_CLKA_UP    (3u << 8)    /* LVDS_A0A2_CLKA_POWER_UP */
#define G_LVDS_A3_MASK    (3u << 6)    /* 24-бит панель, если UP */
#define G_LVDS_A3_UP      (3u << 6)
#define G_LVDS_CLKB_UP    (3u << 4)    /* второй канал (dual) — нам не нужен */
#define G_LVDS_B0B3_UP    (3u << 2)
#define G_PFIT_ENABLE     (1u << 31)   /* PFIT_CONTROL */
#define G_SELF_REF_EN     (1u << 15)   /* FW_BLC_SELF_EN */

/* sideband-коды (psb_intel_reg.h) */
#define G_SB_OPCODE_WRITE (1u << 16)
#define G_SB_DEST_DPLL    (0x88u << 8)
#define G_SB_BYTES        (0xfu << 4)
#define G_SB_BUSY         (1u << 0)
#define G_DPIO_MODE0      (1u << 2)    /* DPIO_MODE_SELECT_0 */
#define G_DPIO_RESET_N    (1u << 0)    /* DPIO_CMN_RESET_N, reset активен НИЗКИМ */
#define G_SB_M_MASK       (0xFFu << 24)
#define G_SB_NVCO_SEL     (3u << 30)
#define G_SB_N_DIV        (0xFu << 26)
#define G_SB_CB_TUNE      (3u << 24)
#define G_REFCLK_MASK     (0x3u << 13)
#define G_REFCLK_DPLL     (1u << 13)   /* «their own DPLL» для LVDS */
#define G_SB_P2_MASK      (3u << 30)
#define G_SB_P2_14        (2u << 30)   /* LVDS single-channel */
#define G_SB_P1_MASK      (0xFu << 12)

/* ---------------- режим цели ---------------- */
#define G_MODE_W 1024
#define G_MODE_H 600
#define G_MODE_BPP 32
#define G_MODE_PITCH (G_MODE_W * 4)

/* частоты: kHz везде, как в gma500 (clock->dot в kHz) */
#define G_REFCLK_CANDIDATES { 96000, 100000 }  /* low-end SKU: 96/100 МГц;
 * 27 МГц — high-end (CRT/HDMI/DP), нетбуку не подходит */

static u32 g_mmio = 0;                 /* BAR0 */
static char g_status[192] = "gma3600: не вызывался";

static inline u32 reg32(u32 off)     { return *(volatile u32 *)(unsigned long)(g_mmio + off); }
static inline void regw(u32 off, u32 v) { *(volatile u32 *)(unsigned long)(g_mmio + off) = v; (void)reg32(off); }

/* udelay: чтение порта 0x80 ≈ 1 мкс (как в ath9k w_udelay без калибровки);
 * mdelay — по тикам таймера (1000 Гц) */
static void g_udelay(int us) {
    while (us-- > 0) { int i; for (i = 0; i < 20; i++) (void)inb(0x80); }
}
static void g_mdelay(int ms) {
    u32 t0 = timer_ticks();
    while ((int)(timer_ticks() - t0) < ms) g_udelay(50);
}

/* ---------------- sideband DPIO (cdv_sb_*) ---------------- */
static int sb_wait_idle(int ms) {
    int t = 0;
    while (reg32(0x2100) & G_SB_BUSY) {   /* SB_PCKT */
        g_udelay(10); t += 10;
        if (t > ms * 1000) return 0;
    }
    return 1;
}
static int sb_read(u32 sbaddr, u32 *out) {
    if (!sb_wait_idle(20)) return 0;
    regw(0x2108, sbaddr);                  /* SB_ADDR */
    /* пакет чтения: opcode 0, dest DPLL, байты 0xf (эталон SB_OPCODE_READ) */
    regw(0x2100, G_SB_DEST_DPLL | G_SB_BYTES);
    if (!sb_wait_idle(20)) return 0;
    *out = reg32(0x2104);                  /* SB_DATA */
    return 1;
}
static int sb_write(u32 sbaddr, u32 val) {
    if (!sb_wait_idle(20)) return 0;
    regw(0x2108, sbaddr);                  /* SB_ADDR */
    regw(0x2104, val);                     /* SB_DATA */
    regw(0x2100, G_SB_OPCODE_WRITE | G_SB_DEST_DPLL | G_SB_BYTES); /* SB_PCKT */
    return sb_wait_idle(20);
}
/* cdv_sb_reset: DPIO_CFG=0 -> DPIO_MODE_SELECT_0|CMN_RESET_N */
static void sb_reset(void) {
    regw(0x2110, 0);
    regw(0x2110, G_DPIO_MODE0 | G_DPIO_RESET_N);
}

/* ---------------- GTF 1024x600@60 (порт drm_gtf_mode_complex) ----------------
 * Параметры по умолчанию (drm_gtf_mode): M=600, 2C=80, K=128, 2J=40;
 * margins=0, interlace=0. Для 1024x600@60 получается
 * 1024 1064 1168 1312 / 600 601 604 622, пиксель ~48.9 МГц. */
typedef struct {
    u32 hdisplay, hsync_start, hsync_end, htotal;
    u32 vdisplay, vsync_start, vsync_end, vtotal;
    u32 clock_khz;                        /* пиксельная частота, кГц */
} gtf_mode_t;

static int gtf_1024x600(gtf_mode_t *m) {
    const int GTF_M = 600, GTF_2C = 80, GTF_K = 128, GTF_2J = 40;
    const int CELL_GRAN = 8, MIN_V_PORCH = 1, V_SYNC_RQD = 3;
    const int H_SYNC_PCT = 8, MIN_VSYNC_BP = 550;
    const int refresh = 60;
    const int C_PRIME = (((GTF_2C - GTF_2J) * GTF_K / 256) + GTF_2J) / 2;
    const int M_PRIME = (GTF_K * GTF_M / 256);
    u32 hdisplay = (G_MODE_W + CELL_GRAN / 2) / CELL_GRAN * CELL_GRAN;
    u32 vdisplay = G_MODE_H;
    u32 vfieldrate = (u32)refresh;

    /* 7. оценка строчной частоты */
    u32 tmp1 = (1000000u - (u32)MIN_VSYNC_BP * vfieldrate) / 500;
    u32 tmp2 = (vdisplay + 2 * 0 + (u32)MIN_V_PORCH) * 2 + 0;
    u32 hfreq_est = tmp2 * 1000u * vfieldrate / tmp1;

    /* 8. строки в VSYNC+BP; 10. всего строк */
    u32 vsync_bp = (u32)MIN_VSYNC_BP * hfreq_est / 1000;
    vsync_bp = (vsync_bp + 500) / 1000;
    u32 vtotal = vdisplay + 0 + 0 + vsync_bp + (u32)MIN_V_PORCH;

    /* 18-19. идеальный duty cycle -> hblank (кратен 2*CELL_GRAN) */
    u32 total_active = hdisplay;
    u32 ideal_duty = (u32)C_PRIME * 1000u - (u32)M_PRIME * 1000000u / hfreq_est;
    u32 hblank = total_active * ideal_duty / (100000u - ideal_duty);
    hblank = (hblank + CELL_GRAN) / (2 * CELL_GRAN) * (2 * CELL_GRAN);

    u32 total_pixels = total_active + hblank;
    u32 pixel_khz = total_pixels * hfreq_est / 1000;

    u32 hsync = (u32)H_SYNC_PCT * total_pixels / 100;
    hsync = (hsync + CELL_GRAN / 2) / CELL_GRAN * CELL_GRAN;
    u32 hfront = hblank / 2 - hsync;

    m->hdisplay = hdisplay;
    m->hsync_start = hdisplay + hfront;
    m->hsync_end = m->hsync_start + hsync;
    m->htotal = total_pixels;
    m->vdisplay = vdisplay;
    m->vsync_start = vdisplay + (u32)MIN_V_PORCH;
    m->vsync_end = m->vsync_start + (u32)V_SYNC_RQD;
    m->vtotal = vtotal;
    m->clock_khz = pixel_khz;
    return (m->htotal > m->hdisplay && m->vtotal > m->vdisplay && m->clock_khz > 20000) ? 1 : 0;
}

/* ---------------- подбор DPLL (gma_find_best_pll для LVDS) ----------------
 * Лимиты CDV_LIMIT_SINGLE_LVDS_96: dot 20..115.5 МГц, vco 1800..3600 МГц,
 * n 2..6, m2 58..158, p1 2..10, p2=14 (single LVDS).
 * cdv_intel_clock: m=m2+2; p=p1*p2; vco=ref*m/n; dot=vco/p. */
typedef struct {
    u32 refclk, m2, n, p1, p2, vco_khz, dot_khz;
} g_pll_t;

static int pll_find(u32 refclk, u32 target_khz, g_pll_t *best) {
    u32 bestdiff = 0xFFFFFFFFu;
    int found = 0;
    for (u32 n = 2; n <= 6; n++) {
        for (u32 m2 = 58; m2 <= 158; m2++) {
            u32 m = m2 + 2;
            u32 vco = refclk * m / n;         /* kHz */
            if (vco < 1800000u || vco > 3600000u) continue;
            for (u32 p1 = 2; p1 <= 10; p1++) {
                u32 p = p1 * 14u;             /* p2 = 14 (LVDS single) */
                u32 dot = vco / p;
                if (dot < 20000u || dot > 115500u) continue;
                u32 diff = dot > target_khz ? dot - target_khz : target_khz - dot;
                if (diff < bestdiff) {
                    bestdiff = diff;
                    best->refclk = refclk; best->m2 = m2; best->n = n;
                    best->p1 = p1; best->p2 = 14u;
                    best->vco_khz = vco; best->dot_khz = dot;
                    found = 1;
                }
            }
        }
    }
    return found;
}

/* ---------------- снимок/восстановление ---------------- */
#define G_SAVE_MAX 40
static struct { u32 mmio_off; u32 val; } g_save[G_SAVE_MAX];
static int g_save_n = 0;
static struct { u32 sb_off; u32 val; } g_sbsave[8];
static int g_sbsave_n = 0;

static void snap_mmio(u32 off) {
    if (g_save_n >= G_SAVE_MAX) return;
    g_save[g_save_n].mmio_off = off;
    g_save[g_save_n].val = reg32(off);
    g_save_n++;
}
static void snap_sb(u32 sb_off) {
    u32 v = 0;
    if (!sb_read(sb_off, &v)) return;
    if (g_sbsave_n >= 8) return;
    g_sbsave[g_sbsave_n].sb_off = sb_off;
    g_sbsave[g_sbsave_n].val = v;
    g_sbsave_n++;
}
static void restore_all(void) {
    for (int i = g_sbsave_n - 1; i >= 0; i--)
        sb_write(g_sbsave[i].sb_off, g_sbsave[i].val);
    for (int i = g_save_n - 1; i >= 0; i--)
        regw(g_save[i].mmio_off, g_save[i].val);
}

/* ---------------- watermark (cdv_update_wm, single-pipe ветка) ---------------- */
static void wm_apply(int pipe) {
    u32 v;
    /* cdv_disable_sr: если self-refresh включён — погасить, vblank, OV_OVADD=0 */
    if (reg32(0x20e0) & G_SELF_REF_EN) {           /* FW_BLC_SELF */
        regw(0x20e0, reg32(0x20e0) & ~G_SELF_REF_EN);
        g_mdelay(20);
        regw(0x30000, 0);                          /* OV_OVADD (CDV MAX_FIFO workaround) */
        g_mdelay(20);
    }
    /* DSPFW1: SR watermark 0x7e<<23, cursor B 0x4<<16 */
    v = reg32(0x70034);
    v &= ~0xFF800000u; v |= 0x7eu << 23;
    v &= ~0x003F0000u; v |= 0x4u << 16;
    regw(0x70034, v);
    /* DSPFW2: cursor A 0x6<<8, plane C 0x8 */
    v = reg32(0x70038);
    v &= ~0x3F00u; v |= 0x6u << 8;
    v &= ~0x7Fu;   v |= 0x8u;
    regw(0x70038, v);
    regw(0x7003c, 0x36000000u);                    /* DSPFW3 (HW team) */
    /* DSPFW5: LVDS на pipe B — 0x00040330, иначе общая формула */
    regw(0x70054, (pipe == 1) ? 0x00040330u
                              : (3u << 24) | (4u << 16) | (3u << 8) | 4u);
    regw(0x70058, 0x10u);                          /* DSPFW6 */
    g_mdelay(20);
    /* включить self-refresh обратно (RMW, сохраняя прочие биты) */
    regw(0x20e0, reg32(0x20e0) | G_SELF_REF_EN);
}

/* ---------------- основной вход ---------------- */
int gma3600_init(const mb_info_t *mb, u32 *out_w, u32 *out_h, u32 *out_pitch) {
    int pipe = -1;
    u32 lvds, a3_24bit;
    gtf_mode_t mode;
    static const u32 ref_candidates[] = G_REFCLK_CANDIDATES;

    if (out_w) *out_w = 0;
    if (out_h) *out_h = 0;
    if (out_pitch) *out_pitch = 0;
    if (!mb || !mb->framebuffer_addr) {
        snprintf(g_status, sizeof(g_status), "gma3600: нет LFB от загрузчика");
        return 0;
    }

    /* 1. PCI: 8086:0be0..0bef (psb_drv.c pciidlist) */
    {
        int found = 0;
        for (int bus = 0; bus < 256 && !found; bus++) {
            for (int dev = 0; dev < 32 && !found; dev++) {
                for (int fn = 0; fn < 8; fn++) {
                    u32 id = pci_read32(bus, dev, fn, 0);
                    if ((id & 0xFFFFu) != 0x8086u) {
                        if (fn == 0) { u8 hdr = pci_read8(bus, dev, 0, 0x0E); if (!(hdr & 0x80)) break; }
                        continue;
                    }
                    u32 did = (id >> 16) & 0xFFFFu;
                    if (did < 0x0be0u || did > 0x0befu) continue;
                    g_mmio = pci_read32(bus, dev, fn, 0x10) & 0xFFFFFFF0u;
                    u16 cmd = pci_read16(bus, dev, fn, 0x04);
                    pci_write16(bus, dev, fn, 0x04, cmd | 0x0006u);
                    found = 1;
                    break;
                }
            }
        }
        if (!found || !g_mmio) {
            snprintf(g_status, sizeof(g_status), "gma3600: Cedarview не найден (не это устройство)");
            return 0;
        }
    }

    /* 2. выбор pipe: порт LVDS уже кем-то настроен — ведём ту же трубу
     * (cdv_intel_lvds.c: pipe = (lvds & LVDS_PIPEB_SELECT) ? 1 : 0) */
    lvds = reg32(0x61180);
    if (lvds & G_LVDS_PORT_EN)   pipe = (lvds & G_LVDS_PIPEB) ? 1 : 0;
    else if (reg32(0x71008) & G_PIPE_ENABLE) pipe = 1;   /* активна труба B */
    else if (reg32(0x70008) & G_PIPE_ENABLE) pipe = 0;   /* активна труба A */
    else                        pipe = 1;   /* как в эталоне: LVDS ведётся от B */
    a3_24bit = ((lvds & G_LVDS_A3_MASK) == G_LVDS_A3_UP);

    /* 3. GTF-модлайн */
    if (!gtf_1024x600(&mode)) {
        snprintf(g_status, sizeof(g_status), "gma3600: GTF не собрался");
        return 0;
    }

    /* 4. снимок всего, что будем трогать (MMIO + sideband) */
    g_save_n = 0; g_sbsave_n = 0;
    snap_mmio(G_DPLL(pipe));  snap_mmio(G_DPLL_MD(pipe));
    snap_mmio(G_HTOTAL(pipe)); snap_mmio(G_HBLANK(pipe)); snap_mmio(G_HSYNC(pipe));
    snap_mmio(G_VTOTAL(pipe)); snap_mmio(G_VBLANK(pipe)); snap_mmio(G_VSYNC(pipe));
    snap_mmio(G_SRC(pipe));   snap_mmio(G_CONF(pipe));
    snap_mmio(G_CNTR(pipe));  snap_mmio(G_STRIDE(pipe));
    snap_mmio(G_POS(pipe));   snap_mmio(G_SIZE(pipe));
    snap_mmio(0x61180);       /* LVDS */
    snap_mmio(0x61230);       /* PFIT_CONTROL */
    snap_mmio(0x70034); snap_mmio(0x70038); snap_mmio(0x7003c);
    snap_mmio(0x70054); snap_mmio(0x70058);
    snap_mmio(0x20e0);        /* FW_BLC_SELF */
    snap_sb(G_SB_REFSFR(pipe)); snap_sb(G_SB_REFCLK(pipe));
    snap_sb(G_SB_M(pipe)); snap_sb(G_SB_NVCO(pipe)); snap_sb(G_SB_P(pipe));

    /* 5. попытки по опорникам: программирование и захват DPLL */
    for (unsigned ri = 0; ri < sizeof(ref_candidates) / sizeof(ref_candidates[0]); ri++) {
        u32 refclk = ref_candidates[ri];
        g_pll_t pll;
        memset(&pll, 0, sizeof(pll));   /* GCC: поля «могут быть не инициализированы» */
        if (!pll_find(refclk, mode.clock_khz, &pll)) continue;

        /* --- как cdv_intel_crtc_mode_set --- */
        u32 v = reg32(G_DPLL(pipe));
        regw(G_DPLL(pipe), (v & ~(G_DPLL_VCO | G_DPLL_LOCK)) |
                            (G_DPLL_SYNCLOCK | G_DPLL_VGADIS));
        sb_reset();
        sb_write(G_SB_REFSFR(pipe), 0x68A701u);   /* «follow the BIOS», эталон */
        if (!sb_read(G_SB_REFCLK(pipe), &v)) goto fail;
        v &= ~G_REFCLK_MASK;
        v |= G_REFCLK_DPLL;                       /* LVDS: свой DPLL */
        sb_write(G_SB_REFCLK(pipe), v);
        if (!sb_read(G_SB_M(pipe), &v)) goto fail;
        v &= ~G_SB_M_MASK;
        v |= pll.m2 << 24;
        sb_write(G_SB_M(pipe), v);
        if (!sb_read(G_SB_NVCO(pipe), &v)) goto fail;
        v &= 0xFFFFu; v |= 0x107u;
        v &= ~(G_SB_NVCO_SEL | G_SB_N_DIV | G_SB_CB_TUNE);
        v |= pll.n << 26;
        if (pll.vco_khz < 2250000u)      v |= (2u << 24) | (0u << 30);
        else if (pll.vco_khz < 2750000u) v |= (1u << 24) | (1u << 30);
        else if (pll.vco_khz < 3300000u) v |= (0u << 24) | (2u << 30);
        else                            v |= (0u << 24) | (3u << 30);
        sb_write(G_SB_NVCO(pipe), v);
        if (!sb_read(G_SB_P(pipe), &v)) goto fail;
        v &= ~(G_SB_P2_MASK | G_SB_P1_MASK);
        v |= pll.p1 << 12;
        v |= G_SB_P2_14;                          /* LVDS single: p2=14 */
        sb_write(G_SB_P(pipe), v);
        g_udelay(150);

        /* LVDS: включить порт, CLKA; один канал (p2=14); pipe по выбору */
        v = lvds;
        v |= G_LVDS_PORT_EN | G_LVDS_CLKA_UP;
        if (pipe == 1) v |= G_LVDS_PIPEB; else v &= ~G_LVDS_PIPEB;
        v &= ~(G_LVDS_B0B3_UP | G_LVDS_CLKB_UP);  /* single channel */
        regw(0x61180, v);

        /* panel fitter выключить (у нас 1:1, без масштабирования) */
        if (reg32(0x61230) & G_PFIT_ENABLE) regw(0x61230, 0);

        /* DPLL: VCO on, ждать захвата */
        v = reg32(G_DPLL(pipe));
        regw(G_DPLL(pipe), (v & ~G_DPLL_LOCK) | G_DPLL_VCO);
        g_udelay(150);
        if (!(reg32(G_DPLL(pipe)) & G_DPLL_LOCK)) continue;   /* следующий refclk */

        /* захват есть — трубы/плоскость/тайминги */
        regw(G_DPLL_MD(pipe), 0);                /* UDI divider/multiplier = 1:1 */
        regw(G_HTOTAL(pipe), ((mode.htotal - 1) << 16) | (mode.hdisplay - 1));
        regw(G_HBLANK(pipe), ((mode.htotal - 1) << 16) | (mode.hdisplay - 1));
        regw(G_HSYNC(pipe),  ((mode.hsync_end - 1) << 16) | (mode.hsync_start - 1));
        regw(G_VTOTAL(pipe), ((mode.vtotal - 1) << 16) | (mode.vdisplay - 1));
        regw(G_VBLANK(pipe), ((mode.vtotal - 1) << 16) | (mode.vdisplay - 1));
        regw(G_VSYNC(pipe),  ((mode.vsync_end - 1) << 16) | (mode.vsync_start - 1));
        regw(G_SIZE(pipe),   ((mode.vdisplay - 1) << 16) | (mode.hdisplay - 1));
        regw(G_POS(pipe), 0);
        regw(G_SRC(pipe),   ((mode.hdisplay - 1) << 16) | (mode.vdisplay - 1));

        v = reg32(G_CONF(pipe));
        v &= ~G_BPC_MASK;
        v |= a3_24bit ? G_BPC_8 : G_BPC_6;
        v |= G_PIPE_ENABLE;
        regw(G_CONF(pipe), v);
        g_mdelay(20);                             /* gma_wait_for_vblank */

        v = reg32(G_CNTR(pipe));
        v &= ~G_PIXFMT_MASK;
        v |= G_PIXFMT_32;
        if (pipe == 1) v |= G_SEL_PIPE_B; else v &= ~G_SEL_PIPE_B;
        v |= G_PLANE_ENABLE;
        regw(G_CNTR(pipe), v);

        regw(G_STRIDE(pipe), G_MODE_PITCH);       /* 4096 */
        /* base НЕ меняем (VBIOS уже разворачивает в этот LFB); двойная
         * запись того же значения флашит конфигурацию плоскости */
        regw(G_BASE(pipe), reg32(G_BASE(pipe)));
        g_mdelay(20);

        wm_apply(pipe);

        /* итог */
        {
            u32 hz = pll.dot_khz * 1000u / (mode.htotal * mode.vtotal);
            snprintf(g_status, sizeof(g_status),
                     "gma3600: 1024x600, %u Гц, pipe %c, LVDS %s; DPLL: "
                     "ref %u кГц, m2=%u n=%u p1=%u p2=14 (vco %u МГц), "
                     "пиксель %u кГц — захват DPLL ок",
                     hz, pipe ? 'B' : 'A',
                     a3_24bit ? "24 бит" : "18 бит",
                     pll.refclk, pll.m2, pll.n, pll.p1,
                     pll.vco_khz / 1000, pll.dot_khz);
        }
        if (out_w) *out_w = G_MODE_W;
        if (out_h) *out_h = G_MODE_H;
        if (out_pitch) *out_pitch = G_MODE_PITCH;
        return 1;
    }

fail:
    restore_all();
    snprintf(g_status, sizeof(g_status),
             "gma3600: DPLL не захвачен (пробованы 96/100 МГц) — откат, "
             "экран остаётся в режиме загрузчика");
    return 0;
}

const char *gma3600_status(void) { return g_status; }
