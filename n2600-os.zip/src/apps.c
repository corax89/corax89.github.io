/* apps.c — реестр приложений + «О программе», «Терминал», «Системная информация» */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "gfx2d.h"   /* СЕССИЯ 85: GPU в системной информации */
#include "mem.h"
#include "timer.h"
#include "string.h"
#include "mouse.h"
#include "kernel.h"
#include "utf8.h"
#include "ramfs.h"
#include "mqjs_os.h"   /* QuickJS: REPL и запуск .js (замена CMScript) */
#include "task.h"
#include "mouse.h"
#include "sound.h"
extern void serial_puts(const char *s);

#include "loader.h"
#include "usb.h"
#include "usb_ehci.h"
#include "e1000.h"
#include "net.h"
#include "ne2000.h"
#include "timer.h"
#include "c4.h"
#include "c4gfx.h"
#include "pci.h"
#include "ath9k_wifi.h"
#include "wpa2.h"
#include "pci_ids.h"
#include "hwinfo.h"  /* сессия 90: hwdet-подобная диагностика ACPI/DSDT/SMBIOS/CPU */
#include "apipc.h"   /* SMP-rework: ap_syscall_do (тест mailbox/IPI) */
#include "smp.h"     /* SMP-rework: smp_current_cpu */
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "iso9660.h"
#include "fat32.h"
#include "ntfs.h"
#include "smp.h"
#include <cpuid.h>   /* GCC/MinGW: встроенные обёртки над инструкцией CPUID */

/* ------------------------------ реестр ------------------------------ */
const app_def_t app_table[] = {
    { "О программе",            app_about_open   },
    { "Файлы",                  app_files_open   },
    { "Терминал",               app_term_open    },
    { "Редактор C",             app_editor_open  },
    { "QuickJS",                app_quickjs_open },
    { "Диспетчер задач",        app_taskmgr_open },
    { "WiFi Scanner",           app_wifi_open     },
    { "Браузер",                app_browser_open  },
    { "HTTP Trace",             app_nettrace_open },
    { "Системная информация",   app_sysinfo_open },
    { "Настройки",              app_settings_open },
    { "MP3 плеер",              app_mp3_open      },   /* сессия 60 */
    { "Просмотр",               app_imgview_open  },   /* сессия 60 */
    { "Игры",                   app_games_open    },
};
const int app_table_count = (int)(sizeof(app_table) / sizeof(app_table[0]));

void apps_open(int idx)
{
    if (idx >= 0 && idx < app_table_count)
        apps_launch(app_table[idx].open_fn);
}

/* Сессия 22 (запрос пользователя): «на системах с небольшим количеством
 * оперативной памяти, когда памяти не хватает на запуск приложения, оно
 * просто молча не запускается — добавь окно с информацией».
 *
 * Все ЗАПУСКИ приложений идут через apps_launch: если после open_fn()
 * ни одного нового окна не появилось — выделить память не удалось
 * (или превышен лимит окон) и мы показываем окно-сообщение вместо
 * молчания. Внутри самого open_fn свои отказы (если вдруг будут) уже
 * сообщает wm_oom_report из win_create, а повтор тут гасится кулдауном. */
void apps_launch(void (*fn)(void))
{
    if (!fn) return;
    int before = wm_window_count();
    fn();
    if (wm_window_count() == before)
        wm_oom_report(-1);
}

/* Запустить приложение по имени */
int app_spawn_by_name(const char *name)
{
    if (!name || !*name) return 0;
    for (int i = 0; i < app_table_count; i++) {
        if (strcmp(app_table[i].name, name) == 0) {
            apps_launch(app_table[i].open_fn);
            return 1;
        }
    }
    /* Пробуем по английским именам */
    if (!strcmp(name, "terminal") || !strcmp(name, "term")) {
        apps_launch(app_term_open); return 1;
    }
    if (!strcmp(name, "files") || !strcmp(name, "fileman")) {
        apps_launch(app_files_open); return 1;
    }
    if (!strcmp(name, "editor")) {
        apps_launch(app_editor_open); return 1;
    }
    if (!strcmp(name, "browser")) {
        apps_launch(app_browser_open); return 1;
    }
    if (!strcmp(name, "nettrace") || !strcmp(name, "trace") ||
        !strcmp(name, "httptrace")) {
        apps_launch(app_nettrace_open); return 1;
    }
    if (!strcmp(name, "sysinfo")) {
        apps_launch(app_sysinfo_open); return 1;
    }
    if (!strcmp(name, "taskmgr")) {
        apps_launch(app_taskmgr_open); return 1;
    }
    if (!strcmp(name, "settings") || !strcmp(name, "настройки")) {
        apps_launch(app_settings_open); return 1;
    }
    if (!strcmp(name, "games") || !strcmp(name, "игры")) {
        apps_launch(app_games_open); return 1;
    }
    if (!strcmp(name, "mines") || !strcmp(name, "minesweeper") ||
        !strcmp(name, "сапер") || !strcmp(name, "сапёр")) {
        apps_launch(app_mines_open); return 1;
    }
    return 0;
}

/* --------------------------- CPU (CPUID) --------------------------- */
void cpu_get_vendor(char out[16])
{
    unsigned a, b, c, d;
    if (!__get_cpuid(0, &a, &b, &c, &d)) { strcpy(out, "-"); return; }
    memcpy(out, &b, 4);
    memcpy(out + 4, &d, 4);
    memcpy(out + 8, &c, 4);
    out[12] = 0;
}

void cpu_get_brand(char out[52])
{
    unsigned a, b, c, d;
    char *p = out;
    unsigned max_ext = 0;
    if (__get_cpuid(0x80000000,  &a,  &b,  &c,  &d)) max_ext = a;
    if (max_ext  >= 0x80000004) {
        for (unsigned leaf = 0x80000002; leaf  <= 0x80000004; leaf++) {
            __get_cpuid(leaf,  &a,  &b,  &c,  &d);
            memcpy(p,  &a, 4); memcpy(p + 4,  &b, 4);
            memcpy(p + 8,  &c, 4); memcpy(p + 12,  &d, 4);
            p += 16;
        }
        *p = 0;
        /*  обрезаем ведущие пробелы */
        char *s = out;
        while (*s == ' ') s++;
        if (s != out) memmove(out, s, strlen(s) + 1);
        return;
    }
    strcpy(out,  "неизвестный процессор ");
}

int cpu_get_cores(void)
{
    unsigned a, b, c, d;
    if (__get_cpuid(1, &a, &b, &c, &d)) return (int)((b >> 16) & 0xFF);
    return 1;
}

/* ============================== О ПРОГРАММЕ ============================== */
typedef struct {
    char cpu[52];
} about_data_t;

static void about_draw(window_t *w)
{
    int cw = win_content_w(w), ch = win_content_h(w);
    (void)cw; (void)ch;
    fb_fill_rect(0, 0, win_content_w(w), win_content_h(w), fb_rgb(0x12, 0x15, 0x1A));
    fb_fill_rect(0, 0, win_content_w(w), 3, fb_rgb(0x3E, 0x7D, 0xBF));

    const char *name = "N2600-OS";
    int nx = (win_content_w(w) - (int)strlen(name) * 16) / 2;
    u32 c = wm_theme_accent();
    for (const char *p = name; *p; p++, nx += 16)
        fb_char2x(nx, 18, (unsigned char)*p, c);

    fb_text(16, 64, "Простая оконная ОС на чистом C", wm_theme_text(), -1);
    fb_text(16, 84, "Сборка: MinGW (i686), multiboot + GRUB", wm_theme_text_dim(), -1);
    fb_text(16, 104, "Цель: Intel Atom N2600, VESA 1280x600x32", wm_theme_text_dim(), -1);

    about_data_t *d = (about_data_t *)w->data;
    char line[64];
    snprintf(line, sizeof(line), "CPU: %s", d->cpu);
    fb_text(16, 132, line, wm_theme_text_dim(), -1);

    fb_text(16, win_content_h(w) - 24, "Лицензия: MIT, 2026", fb_rgb(0x50, 0x58, 0x62), -1);
}

void app_about_open(void)
{
    about_data_t *d = (about_data_t *)malloc(sizeof(about_data_t));
    if (!d) return;
    cpu_get_brand(d->cpu);
    u32 W = fb_width();
    int ww = 360, wh = 200;
    win_create("О программе", (int)W - ww - 40, 40, ww, wh,
               about_draw, NULL, NULL, NULL, NULL, d);
}

/* =============================== ТЕРМИНАЛ =============================== */
/* Сессия 7: геометрия ДИНАМИЧЕСКАЯ — по фактическому размеру окна
 * (resize/maximize меняют cols/rows). Раньше площадь была жёстко
 * 62×17 и не зависела от окна. */
#define TERM_INIT_COLS 62     /* стартовый размер окна (как раньше) */
#define TERM_INIT_ROWS 17
#define TERM_MAX_COLS  128    /* ёмкость хранилища строк */
/* Scrollback: храним историю вывода выше видимой области.
 * TERM_SCROLL_LINES — кольцевой буфер, TERMINAL_SCROLL_BACK строк в прошлом. */
#define TERM_SCROLL_LINES 512

/* ---- [TERM-VT] итерация 7: эмулятор терминала (VT100/xterm-подобный,
 * по мотивам libtmt/tmt.c) + telnet-клиент ----
 * В обычном режиме терминал строковый (term_print). В VT-режиме
 * (команда telnet) вывод идёт в СЕТКУ cells: полный курсор (CUP),
 * очистка (ED/EL), цвета (SGR 16/256), вставка/удаление строк и
 * символов (IL/DL/ICH/DCH/ECH), прокрутка (SU/SD/IND/RI/NEL),
 * альтернативный экран (?1049/?47 — vim/less), ответы на DSR/DA.
 * Хранение: строка-байты UTF-8 (до 192 байт = 96 символов) + атрибут
 * на БАЙТ (0xFF = умолчания темы). Атрибуты — индексы в таблицу 16
 * комбинаций fg/bg/bold/reverse. */
#define VT_ROWS_MAX 48
#define VT_COLS_MAX 96
#define VT_ROW_BYTES (VT_COLS_MAX * 2 + 2)   /* 96 символов UTF-8 = 192 байта */
#define VT_RX_SIZE   16384                   /* приёмный буфер сокета */
#define VT_ATTR_DEF  0xFF                    /* ячейка без явных атрибутов */

typedef struct term_s {
    char lines[TERM_SCROLL_LINES][TERM_MAX_COLS + 1];
    int  nlines;                 /* всего строк в scrollback (включая input) */
    char input[TERM_MAX_COLS + 1];
    int  ilen;
    int  scrollback;              /* сколько строк прокручено от конца (0 = хвост) */
    int  cols, rows;              /* текущая геометрия окна (обновляется в draw) */
    int  repl;                    /* 1 = режим REPL JavaScript (команда js) */
    /* ---- [TERM-SINK] вывод вместо экрана (telnet-сервер) ----
     * Если задан sink_put, term_print перенаправляет ВЕСЬ вывод
     * команды туда (headless-терминал telnetd). */
    void (*sink_put)(void *ctx, const char *s);
    void *sink_ctx;
    /* ---- VT-режим ---- */
    int  vt;                      /* 1 = сетка активна (telnet-сессия) */
    int  vt_sock;                 /* TCP-сокет, -1 = нет */
    u32  vt_gen;                  /* поколение слота TCP [GEN] */
    volatile int vt_rx_n;         /* байт в vt_rx */
    volatile int vt_rx_lock;
    char vt_rx[VT_RX_SIZE];
    int  vt_x, vt_y;              /* курсор (колонка/строка, 0-based) */
    unsigned char vt_at;          /* текущий атрибут (индекс таблицы/0xFF) */
    int  vt_curvis;               /* ?25: курсор видим */
    int  vt_pst;                  /* состояние парсера: 0 ground,1 ESC,2 CSI,3 OSC,4 charset */
    int  vt_priv;                 /* CSI: 1 = '?', 2 = '>' */
    int  vt_n[16];                /* параметры CSI */
    int  vt_nn;                   /* число параметров */
    int  vt_havenum;              /* цифры вообще были */
    char vt_fin;                  /* финальный байт CSI */
    int  vt_osc_esc;              /* внутри OSC видели ESC */
    char vt_utf[8]; int vt_utf_n; /* накопление UTF-8 символа */
    int  vt_save_x, vt_save_y;    /* DECSC/ANSI.SYS s */
    unsigned char vt_save_at;
    int  vt_alt;                  /* альтернативный экран активен */
    int  vt_lw, vt_lh;            /* геометрия прошлой отрисовки (resize→clear) */
    /* сетка (или содержимое основного экрана при активном alt) */
    char          gr[VT_ROWS_MAX][VT_ROW_BYTES];
    unsigned char ga[VT_ROWS_MAX][VT_ROW_BYTES];
    /* копия основного экрана на время alt (?1049) */
    char          alt_gr[VT_ROWS_MAX][VT_ROW_BYTES];
    unsigned char alt_ga[VT_ROWS_MAX][VT_ROW_BYTES];
    int  alt_x, alt_y;
    unsigned char alt_at;
    int  alt_curvis;
    /* таблица атрибутов (до 16 комбинаций) */
    struct vt_attr_s { unsigned char fg, bg, bold, rev; } vt_at_tab[16];
    int  vt_at_n;
    int  vt_at_rr;                /* слот вытеснения по кругу */
} term_t;

static void term_print(term_t *t, const char *s);  /* определение ниже */

/* ---------- QuickJS REPL (команда `js`; см. mquickjs_api.c) ----------
 * Строка исполняется в отдельной задаче (WM не блокируется); вывод
 * забирается mqjs_repl_poll в начале отрисовки. Ctrl+C прерывает
 * выполняющуюся строку (interrupt-обработчик движка), при пустом вводе
 * выходит из REPL. Многострочный ввод (незакрытые скобки/строки)
 * накапливается: приглашение меняется на "...". */
static void term_repl_tick(term_t *t)
{
    static char rbuf[2048];
    if (!t->repl) return;
    int n;
    int guard = 0;
    while ((n = mqjs_repl_poll(rbuf, sizeof(rbuf))) > 0 && guard++ < 32) {
        term_print(t, rbuf);      /* term_print понимает '\n' внутри */
    }
}

/* js <файл.js>: запустить скрипт из RAM disk (вывод — в окно QuickJS) */
typedef struct {
    char *src;
    char *out;
    u32   out_max;
} js_file_ctx_t;

static void js_file_task(void *arg)
{
    js_file_ctx_t *c = (js_file_ctx_t *)arg;
    int rc = mquickjs_run(c->src, c->out, c->out_max);
    (void)rc;
    u32 out_len = (u32)strlen(c->out);
    app_outwin_open("QuickJS: вывод", c->out, out_len);
    free(c->src);
    free(c->out);
    free(c);
    task_exit();
}

static u32 term_bg, term_fg, term_prompt;

/* ---------- Задача-«вечный цикл» (команда spin: тест живучести) ----------
 * Имитирует зависший процесс: плотный цикл без hlt. Планировщик
 * вытесняет её по IRQ0 каждые 1 мс (сессия 33: PIT 1000 Гц) — остальные задачи (окна, kmain)
 * продолжают работать. Убить: kill <N> в терминале или Del в диспетчере. */
static void spin_task_fn(void *arg)
{
    (void)arg;
    volatile u32 x = 0;
    for (;;) {
        x++;               /* плотный цикл: НИКАКИХ hlt/yield */
        if (x == 0xFFFFFFFFu) x = 0;
    }
}

/* СЕССИЯ 81 [DIVZERO-TEST]: задача с ГАРАНТИРОВАННЫМ CPU-исключением
 * #0 (деление на ноль) в КОНТЕКСТЕ ЗАДАЧИ. Проверка изоляции по
 * запросу пользователя («такие исключения должны ронять только
 * приложение, не ядро с GUI»): ожидаем в serial «[exc] в задаче N
 * 'divzero' (eip=...) — задача снята, ОС продолжает работу», после
 * чего рабочий стол/мышь/терминал продолжают работать. volatile —
 * чтобы оптимизатор не выкинул деление. */
static void divzero_task_fn(void *arg)
{
    (void)arg;
    volatile int zero = 0;
    volatile int one = 1;
    volatile int r = one / zero;   /* idiv -> вектор #0 */
    (void)r;
    task_exit();                   /* не достигается: задачу снимет exc_panic */
}

/* ---------- SMP-REWORK: тесты межъядерной инфраструктуры ---------- */

/* [APIPI-TEST] ШАГ 4: задача гоняет серию «syscall» в mailbox BSP.
 * Планировщик (task_pick_core) ставит обычную задачу на наименее
 * загруженное ядро — как правило AP, где ap_syscall_do идёт по
 * настоящему пути: mailbox + IPI 0x62 + ожидание результата.
 * NOP-серия проверяет арифметику пути, malloc/free — передачу
 * владения кучей. Итог в serial: «[apipitest] cpu=N: ok/total».
 * cpu=1 = путь IPI реально exercised; cpu=0 = задача попала на BSP
 * и syscall исполнился локально (тоже корректно, но путь молчит). */
static void apipitest_task_fn(void *arg)
{
    (void)arg;
    char b[96];
    u32 ok = 0, total = 0;
    for (int i = 0; i < 200; i++) {
        u32 r = ap_syscall_do(APIPC_NOP, (u32)i, 7, 11);
        if (r == (u32)i + 18) ok++;
        total++;
    }
    for (int i = 0; i < 50; i++) {
        u32 p = ap_syscall_do(APIPC_MALLOC, 64, 0, 0);
        total++;
        if (p) {
            u32 f = ap_syscall_do(APIPC_FREE, p, 0, 0);
            if (f == 0) ok++;
        }
    }
    snprintf(b, sizeof(b),
             "[apipitest] cpu=%d: mailbox/IPI %u/%u ok\n",
             smp_current_cpu(), (unsigned)ok, (unsigned)total);
    serial_puts(b);
    task_exit();
}

/* [KLOCKHANG-TEST] ШАГ 1: детерминированная проверка FATAL-пути.
 * Задача входит под klock (его выдаёт планировщик), глушит прерывания
 * и крутится вечно: LAPIC-таймер не вытеснит (IF=0) — замок не
 * вернётся никогда. Ожидаемое поведение (выбор при SMP-rework):
 * через 2 с ждущий на BSP печатает «[klock] FATAL: klock stuck >2s —
 * kernel panic» и останавливает систему. Паника с диагнозом вместо
 * порчи кучи параллельными ядрами — это НЕ регрессия. */
static void klockhang_task_fn(void *arg)
{
    (void)arg;
    serial_puts("[klockhang] cli + вечный спин под klock: через ~2 с жду [klock] FATAL\n");
    __asm__ __volatile__("cli");
    for (;;) __asm__ __volatile__("pause");
}

/* ---------- Состояние ping (глобальное, т.к. callback статический) ---------- */
typedef struct {
    u32  target_ip;        /* целевой IP (host order) */
    u32  start_tick;       /* время отправки эха */
    u16  seq;              /* ожидаемый seq */
    u16  next_seq;         /* следующий seq для отправки */
    u32  sent;             /* отправлено */
    u32  recv;             /* принято */
    u32  timeout_ms;        /* таймаут ожидания ответа */
    u32  last_send_tick;   /* время последней отправки */
    int  active;           /* 1 = идёт сессия ping */
    int  max_count;        /* ограничение числа пакетов (0 = бесконечно до Ctrl+C) */
    term_t *term;          /* терминал для вывода */
    window_t *win;         /* окно терминала */
    /* Запись о последнем эхо-ответе для отображения в term_tick */
    int   have_reply;       /* 1 = есть ответ */
    u32   reply_rtt_ms;     /* RTT последнего ответа */
    u16   reply_seq;        /* seq последнего ответа */
} ping_state_t;
static ping_state_t g_ping;

/* ---------- ICMP callback для приёма echo reply ---------- */
static void ping_icmp_cb(u32 src_ip, u16 id, u16 seq,
                          const void *payload, u32 payload_len)
{
    (void)id; (void)payload; (void)payload_len;
    if (!g_ping.active) return;
    if (src_ip != g_ping.target_ip) return;
    u32 now = timer_ticks();
    u32 rtt = now - g_ping.last_send_tick;  /* 1 тик = 1 мс (сессия 33) */
    g_ping.reply_rtt_ms = rtt;
    g_ping.reply_seq = seq;
    g_ping.have_reply = 1;
    g_ping.recv++;
}

/* ---------- Неблокирующее ожидание ----------
 * Ждёт max_ms миллисекунд, при этом обрабатывает сетевые пакеты
 * (net_poll), события клавиатуры (kbd_pop/wm_key) и события мыши.
 * Это предотвращает зависание системы во время ожидания ответов. */
static void net_wait_poll(u32 max_ms)
{
    u32 start = timer_ticks();
    u32 need = max_ms;               /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        net_poll();
        /* Обработка клавиатуры — чтобы система не зависала */
        key_event_t ev;
        while (kbd_pop(&ev)) {
            wm_key(&ev);
        }
        wm_mouse_poll();
        task_yield();
    }
}

/* ---------- UTF-8 утилиты терминала ----------
 * Все глифы шрифта (включая кириллицу) — 8px, т.е. 1 СИМВОЛ = 1
 * колонка, но в UTF-8 кириллица занимает 2 БАЙТА. Перенос строк и
 * ширина ввода считаются по СИМВОЛАМ — иначе разрезались бы буквы.
 * Праймитивы общесистемные: utf8.h (utf8_take_bytes/utf8_clamp_bytes). */

#define utf8_take(s, max_chars) \
    ((u32)utf8_take_bytes((s), -1, (max_chars)))
#define utf8_clamp(s, len, max) \
    (utf8_clamp_bytes((s), (len), (max)))

/* добавить строку в scrollback (с переносом при переполнении хранилища
 * и разрезанием слишком длинных кусков по границе символов) */
static void term_push_text(term_t *t, const char *s, u32 len)
{
    while (len > 0) {
        /* ≤ TERM_MAX_COLS байт, не рвать UTF-8 символ */
        u32 take = (u32)utf8_clamp(s, (int)len, TERM_MAX_COLS);
        if (take == 0) take = 1;
        if (t->nlines >= TERM_SCROLL_LINES) {
            /* Сдвигаем кольцевой буфер: выкидываем первую строку */
            memmove(t->lines[0], t->lines[1],
                    sizeof(t->lines[0]) * (TERM_SCROLL_LINES - 1));
            t->nlines--;
        }
        memcpy(t->lines[t->nlines], s, take);
        t->lines[t->nlines][take] = 0;
        t->nlines++;
        s += take;
        len -= take;
    }
}

static void term_print(term_t *t, const char *s)
{
    /* [TERM-SINK] headless-режим (telnet-сервер): вывод команды уходит
     * в sink (TCP-соединение), а не в строковое хранилище окна. */
    if (t->sink_put) {
        t->sink_put(t->sink_ctx, s);
        return;
    }
    /* печатаем текст с переносом по ТЕКУЩЕЙ ширине окна (по символам) */
    int cols = t->cols > 0 ? t->cols : TERM_INIT_COLS;
    while (*s) {
        int room = cols - 1;
        const char *p = s;
        int nch = 0;
        while (*p && nch < room) {
            if (*p == '\n') break;
            (void)utf8_next(&p);
            nch++;
        }
        u32 seg_len = (u32)(p - s);
        term_push_text(t, s, seg_len);
        s += seg_len;
        if (*s == '\n') s++;   /* пропускаем \n */
    }
    /* Если мы были прокручены наверх — при новой выводе остаёмся там.
     * Чтобы пользователь видел новые сообщения, сбросим scrollback в хвост. */
    t->scrollback = 0;
}

/* ================ [TERM-VT] эмулятор терминала (telnet) ================
 * Машина состояний в духе libtmt (deadpixi/tmt.c): GROUND → ESC → CSI/
 * OSC, обработка C0 в GROUND. Вывод — в сетку t->gr/ga. Работает
 * ТОЛЬКО пока t->vt=1 (telnet-сессия); локальный вывод команд идёт
 * мимо (term_print в строковое хранилище). */

static void telnet_send_bytes(term_t *t, const void *data, u32 len);

/* палитра 16 цветов (xterm/VS Code — хорошо читается на тёмной теме) */
static const u32 vt_pal16[16] = {
    0x000000, 0xCD3131, 0x0DBC79, 0xE5E510,
    0x2472C8, 0xBC3FBC, 0x11A8CD, 0xE5E5E5,
    0x666666, 0xF14C4C, 0x23D18B, 0xF5F543,
    0x3B8EEA, 0xD670D6, 0x29B8DB, 0xFFFFFF
};

/* уровни куба 256-цветной палитры xterm */
static const u8 vt_cube[6] = { 0, 95, 135, 175, 215, 255 };

static int vt_rgb_dist(u32 a, u32 b)
{
    int dr = (int)((a >> 16) & 0xFF) - (int)((b >> 16) & 0xFF);
    int dg = (int)((a >> 8) & 0xFF) - (int)((b >> 8) & 0xFF);
    int db = (int)(a & 0xFF) - (int)(b & 0xFF);
    return dr * dr + dg * dg + db * db;
}

static int vt_nearest16(u32 rgb)
{
    int best = 0, bd = vt_rgb_dist(rgb, vt_pal16[0]);
    for (int i = 1; i < 16; i++) {
        int d = vt_rgb_dist(rgb, vt_pal16[i]);
        if (d < bd) { bd = d; best = i; }
    }
    return best;
}

/* 256-цвет xterm → наш 16-цветный атрибут */
static int vt_256_to16(int n)
{
    if (n < 16)  return n;
    if (n < 232) {
        int k = n - 16;
        int r = vt_cube[k / 36], g = vt_cube[(k % 36) / 6], b = vt_cube[k % 6];
        return vt_nearest16(((u32)r << 16) | ((u32)g << 8) | (u32)b);
    }
    int v = 8 + (n - 232) * 10;           /* 8..238 */
    return vt_nearest16(((u32)v << 16) | ((u32)v << 8) | (u32)v);
}

/* найти/завести атрибут в таблице; полный — заменить по кругу */
static unsigned char vt_attr_get(term_t *t, unsigned char fg, unsigned char bg,
                                 unsigned char bold, unsigned char rev)
{
    for (int i = 0; i < t->vt_at_n; i++) {
        if (t->vt_at_tab[i].fg == fg && t->vt_at_tab[i].bg == bg &&
            t->vt_at_tab[i].bold == bold && t->vt_at_tab[i].rev == rev)
            return (unsigned char)i;
    }
    int slot;
    if (t->vt_at_n < 16) {
        slot = t->vt_at_n++;
    } else {
        t->vt_at_rr = (t->vt_at_rr + 1) & 15;   /* вытеснение по кругу */
        slot = t->vt_at_rr;
    }
    t->vt_at_tab[slot].fg = fg;
    t->vt_at_tab[slot].bg = bg;
    t->vt_at_tab[slot].bold = bold;
    t->vt_at_tab[slot].rev = rev;
    return (unsigned char)slot;
}

static void vt_attr_reset(term_t *t)
{
    t->vt_at_n = 0;
    t->vt_at_rr = -1;
    t->vt_at = VT_ATTR_DEF;
}

/* курсор/атрибуты в пределах сетки */
static void vt_clamp_cur(term_t *t)
{
    int cols = t->cols > 0 ? t->cols : TERM_INIT_COLS;
    int rows = t->rows > 0 ? t->rows : TERM_INIT_ROWS;
    if (cols > VT_COLS_MAX) cols = VT_COLS_MAX;
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    if (t->vt_x >= cols) t->vt_x = cols - 1;
    if (t->vt_x < 0) t->vt_x = 0;
    if (t->vt_y >= rows) t->vt_y = rows - 1;
    if (t->vt_y < 0) t->vt_y = 0;
}

static void vt_clear_row(term_t *t, int r)
{
    if (r < 0 || r >= VT_ROWS_MAX) return;
    t->gr[r][0] = 0;
    memset(t->ga[r], VT_ATTR_DEF, sizeof(t->ga[r]));
}

static void vt_clear_all(term_t *t)
{
    for (int r = 0; r < VT_ROWS_MAX; r++) vt_clear_row(t, r);
}

/* прокрутка вверх: строки уходят за верх, снизу пустые */
static void vt_scroll_up(term_t *t, int n)
{
    int rows = t->rows > 0 ? t->rows : TERM_INIT_ROWS;
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    if (n < 1) n = 1;
    if (n > rows) n = rows;
    if (n < rows)
        memmove(t->gr[0], t->gr[n], sizeof(t->gr[0]) * (u32)(rows - n));
    for (int r = rows - n; r < rows; r++) vt_clear_row(t, r);
}

static void vt_scroll_down(term_t *t, int n)
{
    int rows = t->rows > 0 ? t->rows : TERM_INIT_ROWS;
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    if (n < 1) n = 1;
    if (n > rows) n = rows;
    if (n < rows)
        memmove(t->gr[n], t->gr[0], sizeof(t->gr[0]) * (u32)(rows - n));
    for (int r = 0; r < n; r++) vt_clear_row(t, r);
}

static void vt_lf(term_t *t)
{
    int rows = t->rows > 0 ? t->rows : TERM_INIT_ROWS;
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    if (t->vt_y >= rows - 1) vt_scroll_up(t, 1);
    else t->vt_y++;
}

/* байтовое смещение колонки col в строке (граница UTF-8 символа) */
static int vt_col_off(const char *row, int col)
{
    int off = 0, c = 0;
    while (row[off] && c < col) {
        const char *p = row + off;
        (void)utf8_next(&p);
        off = (int)(p - row);
        c++;
    }
    return off;
}

/* записать символ (1..4 байта UTF-8) в текущую позицию с автопереносом */
static void vt_putc(term_t *t, const char *ch, int chlen)
{
    int cols = t->cols > 0 ? t->cols : TERM_INIT_COLS;
    if (cols > VT_COLS_MAX) cols = VT_COLS_MAX;
    if (t->vt_x >= cols) {           /* автоперенос (DECAWM) */
        t->vt_x = 0;
        vt_lf(t);
    }
    if (t->vt_y < 0 || t->vt_y >= VT_ROWS_MAX) { t->vt_y = 0; return; }
    char *row = t->gr[t->vt_y];
    unsigned char *at = t->ga[t->vt_y];
    int off = vt_col_off(row, t->vt_x);
    int suf = vt_col_off(row, t->vt_x + 1);      /* конец прежнего символа */
    if (suf < off) suf = off;
    /* вместимость: не писать за VT_ROW_BYTES-1 */
    if (off + chlen >= VT_ROW_BYTES) {           /* строка-хвост заполнена */
        t->vt_x = cols;                          /* заставит перенос в следующий раз */
        return;
    }
    int suflen = (int)strlen(row + suf);
    int shift = chlen - (suf - off);
    /* атрибуты хвоста сдвигаем (memmove сам обрабатывает перекрытие) */
    if (suflen > 0 && shift != 0) {
        memmove(at + suf + shift, at + suf, (u32)suflen);
        memmove(row + off + chlen, row + suf, (u32)suflen + 1u);
    }
    memcpy(row + off, ch, (u32)chlen);
    for (int i = 0; i < chlen; i++)
        at[off + i] = t->vt_at;
    t->vt_x++;
}

static void vt_save_cur(term_t *t)
{
    t->vt_save_x = t->vt_x;
    t->vt_save_y = t->vt_y;
    t->vt_save_at = t->vt_at;
}

static void vt_restore_cur(term_t *t)
{
    t->vt_x = t->vt_save_x;
    t->vt_y = t->vt_save_y;
    t->vt_at = t->vt_save_at;
    vt_clamp_cur(t);
}

/* параметр i (0, если не задан) */
static int vt_p(term_t *t, int i, int def)
{
    if (i >= t->vt_nn || !t->vt_havenum) return def;
    if (i < 0) i = 0;
    return t->vt_n[i] > 0 ? t->vt_n[i] : def;
}

static void vt_csi_exec(term_t *t, char f)
{
    int cols = t->cols > 0 ? t->cols : TERM_INIT_COLS;
    int rows = t->rows > 0 ? t->rows : TERM_INIT_ROWS;
    if (cols > VT_COLS_MAX) cols = VT_COLS_MAX;
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    vt_clamp_cur(t);
    int p1 = vt_p(t, 0, 1);

    switch (f) {
    case 'A':                                   /* CUU вверх */
        t->vt_y -= p1;
        vt_clamp_cur(t);
        break;
    case 'B':                                   /* CUD вниз */
    case 'e':
        t->vt_y += p1;
        vt_clamp_cur(t);
        break;
    case 'C':                                   /* CUF вправо */
    case 'a':
        t->vt_x += p1;
        vt_clamp_cur(t);
        break;
    case 'D':                                   /* CUB влево */
        t->vt_x -= p1;
        vt_clamp_cur(t);
        break;
    case 'E':                                   /* CNL: вниз + колонка 0 */
        t->vt_y += p1;
        t->vt_x = 0;
        vt_clamp_cur(t);
        break;
    case 'F':                                   /* CPL: вверх + колонка 0 */
        t->vt_y -= p1;
        t->vt_x = 0;
        vt_clamp_cur(t);
        break;
    case 'G':                                   /* CHA: колонка */
    case '`':
        t->vt_x = p1 - 1;
        vt_clamp_cur(t);
        break;
    case 'd':                                   /* VPA: строка */
        t->vt_y = p1 - 1;
        vt_clamp_cur(t);
        break;
    case 'H':                                   /* CUP/HVP (1-based) */
    case 'f':
        t->vt_y = p1 - 1;
        t->vt_x = vt_p(t, 1, 1) - 1;
        vt_clamp_cur(t);
        break;
    case 'J': {                                 /* ED */
        int m = vt_p(t, 0, 0);
        if (m == 1) {
            for (int r = 0; r < t->vt_y; r++) vt_clear_row(t, r);
            vt_clear_row(t, t->vt_y);           /* упрощение: строка целиком */
        }
        if (m == 0 || m == 3) {
            for (int r = t->vt_y + 1; r < rows; r++) vt_clear_row(t, r);
            /* от курсора до конца строки */
            int roff = vt_col_off(t->gr[t->vt_y], t->vt_x);
            t->gr[t->vt_y][roff] = 0;
            memset(t->ga[t->vt_y] + roff, VT_ATTR_DEF,
                   (u32)(VT_ROW_BYTES - roff));
        }
        if (m == 2 || m == 3)
            for (int r = 0; r < rows; r++) vt_clear_row(t, r);
        break;
    }
    case 'K': {                                 /* EL */
        int m = vt_p(t, 0, 0);
        char *row = t->gr[t->vt_y];
        unsigned char *at = t->ga[t->vt_y];
        if (m == 0) {
            int off = vt_col_off(row, t->vt_x);
            row[off] = 0;
            memset(at + off, VT_ATTR_DEF, (u32)(VT_ROW_BYTES - off));
        } else if (m == 1) {
            int off = vt_col_off(row, t->vt_x + 1);
            memset(at, VT_ATTR_DEF, (u32)off);
            /* стираем символы: строку сохраняем, но содержимое до
             * курсора заменяем пробелами с атрибутом по умолчанию */
            char tmp[VT_ROW_BYTES];
            snprintf(tmp, sizeof(tmp), "%s", row + off);
            memset(row, ' ', (u32)off);
            row[off] = 0;
            snprintf(row + off, (u32)(VT_ROW_BYTES - off), "%s", tmp);
        } else {
            vt_clear_row(t, t->vt_y);
        }
        break;
    }
    case 'L': {                                 /* IL: вставить строки */
        int n = p1;
        for (int k = 0; k < n; k++) {
            for (int r = rows - 1; r > t->vt_y; r--) {
                memcpy(t->gr[r], t->gr[r - 1], sizeof(t->gr[0]));
                memcpy(t->ga[r], t->ga[r - 1], sizeof(t->ga[0]));
            }
            vt_clear_row(t, t->vt_y);
        }
        break;
    }
    case 'M': {                                 /* DL: удалить строки */
        int n = p1;
        for (int k = 0; k < n; k++) {
            for (int r = t->vt_y; r < rows - 1; r++) {
                memcpy(t->gr[r], t->gr[r + 1], sizeof(t->gr[0]));
                memcpy(t->ga[r], t->ga[r + 1], sizeof(t->ga[0]));
            }
            vt_clear_row(t, rows - 1);
        }
        break;
    }
    case 'P': {                                 /* DCH: удалить символы */
        char *row = t->gr[t->vt_y];
        unsigned char *at = t->ga[t->vt_y];
        int off = vt_col_off(row, t->vt_x);
        int noff = vt_col_off(row, t->vt_x + p1);
        int rest = (int)strlen(row + noff);
        if (rest > 0) {
            memmove(row + off, row + noff, (u32)rest + 1u);
            memmove(at + off, at + noff, (u32)rest);
        }
        row[off + (rest > 0 ? rest : 0)] = 0;
        break;
    }
    case '@': {                                 /* ICH: вставить пробелы */
        char *row = t->gr[t->vt_y];
        unsigned char *at = t->ga[t->vt_y];
        int off = vt_col_off(row, t->vt_x);
        int rest = (int)strlen(row + off);
        if (rest > VT_ROW_BYTES - 8 - off) rest = VT_ROW_BYTES - 8 - off;
        if (rest > 0) {
            char tb[VT_ROW_BYTES];
            unsigned char ta[VT_ROW_BYTES];
            memcpy(tb, row + off, (u32)rest + 1u);
            memcpy(ta, at + off, (u32)rest);
            int bl = p1;
            if (bl > VT_COLS_MAX) bl = VT_COLS_MAX;
            if (off + bl + rest >= VT_ROW_BYTES)
                bl = VT_ROW_BYTES - 1 - off - rest;
            if (bl > 0) {
                memset(row + off, ' ', (u32)bl);
                memset(at + off, VT_ATTR_DEF, (u32)bl);
                memcpy(row + off + bl, tb, (u32)rest + 1u);
                memcpy(at + off + bl, ta, (u32)rest);
            }
        }
        break;
    }
    case 'X': {                                 /* ECH: стереть N символов */
        char *row = t->gr[t->vt_y];
        unsigned char *at = t->ga[t->vt_y];
        int off = vt_col_off(row, t->vt_x);
        int noff = vt_col_off(row, t->vt_x + p1);
        if (noff > off) {
            memset(row + off, ' ', (u32)(noff - off));
            memset(at + off, VT_ATTR_DEF, (u32)(noff - off));
        }
        break;
    }
    case 'S': vt_scroll_up(t, p1); break;       /* SU */
    case 'T': vt_scroll_down(t, p1); break;     /* SD */
    case 'Z':                                   /* CBT: табуляция назад */
        t->vt_x = (t->vt_x / 8 - p1) * 8;
        if (t->vt_x < 0) t->vt_x = 0;
        break;
    case 's': vt_save_cur(t); break;            /* ANSI.SYS */
    case 'u': vt_restore_cur(t); break;
    case 'h':                                   /* SM/RM */
    case 'l':
        if (t->vt_priv == 1) {
            int m = vt_p(t, 0, 0);
            if (m == 25) t->vt_curvis = (f == 'h');
            else if (m == 1047 || m == 1049 || m == 47) {
                if (f == 'h' && !t->vt_alt) {
                    /* основной экран → в буфер, сетка пустая */
                    memcpy(t->alt_gr, t->gr, sizeof(t->gr));
                    memcpy(t->alt_ga, t->ga, sizeof(t->ga));
                    t->alt_x = t->vt_x;  t->alt_y = t->vt_y;
                    t->alt_at = t->vt_at;
                    t->alt_curvis = t->vt_curvis;
                    vt_clear_all(t);
                    t->vt_x = t->vt_y = 0;
                    t->vt_alt = 1;
                } else if (f == 'l' && t->vt_alt) {
                    memcpy(t->gr, t->alt_gr, sizeof(t->gr));
                    memcpy(t->ga, t->alt_ga, sizeof(t->ga));
                    t->vt_x = t->alt_x;  t->vt_y = t->alt_y;
                    t->vt_at = t->alt_at;
                    t->vt_curvis = t->alt_curvis;
                    t->vt_alt = 0;
                    vt_clamp_cur(t);
                }
            }
            /* ?7 (autowrap), ?1000 (мышь) и пр. — принимаем молча */
        }
        break;
    case 'n': {                                 /* DSR */
        int m = vt_p(t, 0, 0);
        if (m == 6) {                           /* позиция курсора */
            char rbuf[24];
            snprintf(rbuf, sizeof(rbuf), "\x1b[%d;%dR",
                     t->vt_y + 1, t->vt_x + 1);
            telnet_send_bytes(t, rbuf, (u32)strlen(rbuf));
        } else if (m == 5) {
            telnet_send_bytes(t, "\x1b[0n", 4);
        }
        break;
    }
    case 'c':                                   /* DA: «я VT102» */
        if (!t->vt_priv)
            telnet_send_bytes(t, "\x1b[?6c", 5);
        break;
    case 'm':                                   /* SGR */
    {
        unsigned char fg = 30, bg = 40, bold = 0, rev = 0;   /* 30/40 = «тема» */
        if (t->vt_at != VT_ATTR_DEF) {
            fg = t->vt_at_tab[t->vt_at].fg;
            bg = t->vt_at_tab[t->vt_at].bg;
            bold = t->vt_at_tab[t->vt_at].bold;
            rev = t->vt_at_tab[t->vt_at].rev;
        }
        if (!t->vt_nn || !t->vt_havenum) {      /* ESC[m = сброс */
            t->vt_at = VT_ATTR_DEF;
            break;
        }
        for (int i = 0; i < t->vt_nn; i++) {
            int v = t->vt_n[i];
            if (v == 38 || v == 48) {
                int col = -1;
                if (i + 1 < t->vt_nn && t->vt_n[i + 1] == 5 &&
                    i + 2 < t->vt_nn) {
                    col = vt_256_to16(t->vt_n[i + 2]);
                    i += 2;
                } else if (i + 1 < t->vt_nn && t->vt_n[i + 1] == 2 &&
                           i + 4 < t->vt_nn) {
                    u32 rgb = ((u32)t->vt_n[i + 2] << 16) |
                              ((u32)t->vt_n[i + 3] << 8) |
                               (u32)t->vt_n[i + 4];
                    col = vt_nearest16(rgb);
                    i += 4;
                }
                if (col >= 0) {
                    if (v == 38) fg = (unsigned char)col;
                    else         bg = (unsigned char)col;
                    continue;
                }
            }
            if (v == 0)      { fg = 30; bg = 40; bold = 0; rev = 0; }
            else if (v == 1)  bold = 1;
            else if (v == 2)  bold = 0;
            else if (v == 7)  rev = 1;
            else if (v == 21 || v == 22) bold = 0;
            else if (v == 27) rev = 0;
            else if (v >= 30 && v <= 37)  fg = (unsigned char)(v - 30);
            else if (v >= 90 && v <= 97)  { fg = (unsigned char)(v - 90 + 8); bold = 1; }
            else if (v == 39) fg = 30;
            else if (v >= 40 && v <= 47)  bg = (unsigned char)(v - 40);
            else if (v >= 100 && v <= 107) bg = (unsigned char)(v - 100 + 8);
            else if (v == 49) bg = 40;
        }
        if (fg == 30 && bg == 40 && !bold && !rev)
            t->vt_at = VT_ATTR_DEF;
        else {
            /* bold для цветов 0..7 — яркая пара (8..15) при отрисовке */
            t->vt_at = vt_attr_get(t, fg, bg, bold, rev);
        }
        break;
    }
    case 'r':                                   /* DECSTBM — принимаем молча */
    case 'g':                                   /* TBC */
    case 'q':                                   /* DECLL */
    default:
        break;
    }
}

/* один байт потока в парсер */
static void vt_byte(term_t *t, unsigned char b)
{
    switch (t->vt_pst) {
    case 3:                                     /* OSC — до BEL/ST */
        if (b == 0x07) { t->vt_pst = 0; t->vt_osc_esc = 0; }
        else if (b == 0x1B) t->vt_osc_esc = 1;
        else if (t->vt_osc_esc && b == '\\') { t->vt_pst = 0; t->vt_osc_esc = 0; }
        else t->vt_osc_esc = 0;
        return;
    case 4:                                     /* после ESC ( / ) — 1 символ */
        t->vt_pst = 0;
        return;
    case 1:                                     /* после ESC */
        switch (b) {
        case '[':
            t->vt_pst = 2;
            t->vt_priv = 0; t->vt_nn = 0; t->vt_havenum = 0;
            for (int i = 0; i < 16; i++) t->vt_n[i] = 0;
            t->vt_fin = 0;
            return;
        case ']': t->vt_pst = 3; t->vt_osc_esc = 0; return;
        case '(': case ')': t->vt_pst = 4; return;
        case 'D': vt_lf(t); t->vt_pst = 0; return;          /* IND */
        case 'E': t->vt_x = 0; vt_lf(t); t->vt_pst = 0; return;  /* NEL */
        case 'M':                                           /* RI */
            if (t->vt_y == 0) vt_scroll_down(t, 1);
            else t->vt_y--;
            t->vt_pst = 0;
            return;
        case 'c':                                           /* RIS */
            vt_clear_all(t);
            vt_attr_reset(t);
            t->vt_x = t->vt_y = 0;
            t->vt_curvis = 1;
            t->vt_alt = 0;
            t->vt_pst = 0;
            return;
        case '7': vt_save_cur(t); t->vt_pst = 0; return;
        case '8': vt_restore_cur(t); t->vt_pst = 0; return;
        case '=': case '>': t->vt_pst = 0; return;          /* keypad */
        default:  t->vt_pst = 0; return;
        }
    case 2:                                     /* CSI */
        if (b >= '0' && b <= '9') {
            int *v = &t->vt_n[t->vt_nn < 16 ? t->vt_nn : 15];
            *v = *v * 10 + (b - '0');
            t->vt_havenum = 1;
            return;
        }
        if (b == ';' || b == ':') {
            if (t->vt_nn < 15) t->vt_nn++;
            t->vt_havenum = 1;
            return;
        }
        if (b == '?') { t->vt_priv = 1; return; }
        if (b == '>') { t->vt_priv = 2; return; }
        if (b == 0x1B) { t->vt_pst = 1; return; }    /* прерванная CSI */
        if (b >= 0x40 && b <= 0x7E) {
            if (t->vt_havenum && t->vt_nn < 15) t->vt_nn++;
            t->vt_fin = (char)b;
            vt_csi_exec(t, (char)b);
            t->vt_pst = 0;
            return;
        }
        return;                                      /* промежуточные байты */
    default:                                         /* GROUND */
        break;
    }

    if (b == 0x1B) { t->vt_pst = 1; return; }
    if (t->vt_utf_n > 0 && (b & 0xC0) == 0x80) {
        /* продолжение UTF-8 */
        t->vt_utf[t->vt_utf_n++] = (char)b;
        if (t->vt_utf_n >= 2 &&
            ((unsigned char)t->vt_utf[0] & 0xE0) == 0xC0 && t->vt_utf_n == 2) {
            t->vt_utf[t->vt_utf_n] = 0;
            vt_putc(t, t->vt_utf, 2);
            t->vt_utf_n = 0;
        } else if (t->vt_utf_n >= 3 &&
                   ((unsigned char)t->vt_utf[0] & 0xF0) == 0xE0 &&
                   t->vt_utf_n == 3) {
            t->vt_utf[t->vt_utf_n] = 0;
            vt_putc(t, t->vt_utf, 3);
            t->vt_utf_n = 0;
        } else if (t->vt_utf_n >= (int)sizeof(t->vt_utf) - 1) {
            t->vt_utf_n = 0;                        /* мусор — сброс */
        }
        return;
    }
    t->vt_utf_n = 0;

    switch (b) {
    case '\r': t->vt_x = 0; return;
    case '\n': case '\v': case '\f': vt_lf(t); return;
    case '\b': if (t->vt_x > 0) t->vt_x--; return;
    case '\t': {
        int cols = t->cols > 0 ? t->cols : TERM_INIT_COLS;
        if (cols > VT_COLS_MAX) cols = VT_COLS_MAX;
        t->vt_x = ((t->vt_x / 8) + 1) * 8;
        if (t->vt_x >= cols) t->vt_x = cols - 1;
        return;
    }
    case 0x07: return;                            /* BEL */
    case 0x00: case 0x0E: case 0x0F: case 0x7F: return;
    default:
        if (b < 0x20) return;
        if ((b & 0xE0) == 0xC0 || (b & 0xF0) == 0xE0 || (b & 0xF8) == 0xF0) {
            /* начало многобайтового UTF-8 */
            t->vt_utf[0] = (char)b;
            t->vt_utf_n = 1;
            return;
        }
        {
            char ch1 = (char)b;
            vt_putc(t, &ch1, 1);
        }
        return;
    }
}

static void vt_feed(term_t *t, const char *data, u32 len)
{
    for (u32 i = 0; i < len; i++)
        vt_byte(t, (unsigned char)data[i]);
}

/* сброс сессии в строковый режим */
static void vt_detach(term_t *t)
{
    t->vt = 0;
    t->vt_sock = -1;
    t->vt_rx_n = 0;
    t->vt_pst = 0;
    t->vt_utf_n = 0;
    t->vt_alt = 0;
    t->vt_curvis = 1;
    t->scrollback = 0;
}

static void term_touch(window_t *w) { if (w) win_invalidate(w); }

static void term_puts(window_t *w, term_t *t, const char *s)
{
    term_print(t, s);
    term_touch(w);
}

/* [TCLIENT] telnet-клиент — реализация в секции перед term_draw */
typedef struct {
    term_t   *t;      /* терминал-владелец сессии (NULL = нет) */
    window_t *w;
} telnet_sess_t;
static telnet_sess_t g_tel = { NULL, NULL };
static void telnet_start(window_t *w, term_t *t, const char *host, int port);

static void term_exec(window_t *w, term_t *t)
{
    char cmd[TERM_MAX_COLS + 1];
    strcpy(cmd, t->input);
    t->input[0] = 0;
    t->ilen = 0;

    char *c = cmd;
    while (*c == ' ') c++;
    if (!*c) return;

    /* ---- режим REPL JavaScript: строки идут движку, не командам ---- */
    if (t->repl) {
        if (!strcmp(c, ".exit") || !strcmp(c, ".quit") || !strcmp(c, "exit()")) {
            mqjs_repl_stop();           /* при активной строке прервёт её */
            t->repl = 0;
            term_puts(w, t, "REPL завершён.");
            return;
        }
        int r = mqjs_repl_eval(c);
        if (r == 1)
            term_puts(w, t, "(занято — дождитесь завершения или Ctrl+C)");
        else if (r == 2)
            term_puts(w, t, "... (незакрытый блок — продолжайте ввод, пустая строка: выполнить)");
        else if (r < 0)
            term_puts(w, t, "Ошибка REPL (нет памяти?)");
        /* r == 0: строка принята, вывод появится при завершении задачи */
        return;
    }

    if (!strcmp(c, "help")) {
        term_puts(w, t, "Команды:");
        term_puts(w, t, "  help    - этот список");
        term_puts(w, t, "  about   - о системе");
        term_puts(w, t, "  sysinfo - краткие сведения о железе");
        term_puts(w, t, "  mem     - память (RAM и куча)");
        term_puts(w, t, "  uptime  - время работы");
        term_puts(w, t, "  apps    - открытые окна");
        term_puts(w, t, "  echo <текст>");
        term_puts(w, t, "  clear   - очистить экран");
        term_puts(w, t, "  reboot  - перезагрузка");
        term_puts(w, t, "  poweroff- выключение (QEMU)");
        term_puts(w, t, "  --- ПРОКРУТКА ---");
        term_puts(w, t, "  PgUp/PgDn, ↑/↓, Home/End");
        term_puts(w, t, "  --- RAMFS ---");
        term_puts(w, t, "  ramls    - список файлов в RAM");
        term_puts(w, t, "  ramwrite <имя> <текст> - создать файл в RAM");
        term_puts(w, t, "  ramread <имя> - прочитать файл из RAM");
        term_puts(w, t, "  ramdel <имя> - удалить файл из RAM");
        term_puts(w, t, "  raminfo  - информация о RAM disk");
        term_puts(w, t, "  --- МУЛЬТИЗАДАЧНОСТЬ ---");
        term_puts(w, t, "  tasks   - список задач");
        term_puts(w, t, "  spin    - тест: задача с вечным циклом (система должна жить)");
        term_puts(w, t, "  apipitest - тест: 250 syscall AP->BSP (mailbox+IPI, итог в serial)");
        term_puts(w, t, "  klockhang - тест: зависание ПОД klock (через ~2с [klock] FATAL + halt)");
        term_puts(w, t, "  spinlock- тест: задача зависает, ДЕРЖА блокировку (оживание ~20 c)");
        term_puts(w, t, "  kill <N>- завершить задачу #N (кроме системных)");
        term_puts(w, t, "  --- ЗАГРУЗКА И ДИСКИ ---");
        term_puts(w, t, "  dmesg   - журнал процесса загрузки");
        term_puts(w, t, "  dmesgdump [имя] - дамп журнала в RAM disk (DMESG.TXT)");
        term_puts(w, t, "  disks   - все диски/устройства хранения");
        term_puts(w, t, "  --- USB ---");
        term_puts(w, t, "  usbinfo - инфо о USB-контроллерах и флешке");
        term_puts(w, t, "  usbread <сектор> - прочитать сектор 512 байт с флешки");
        term_puts(w, t, "  --- СЕТЬ ---");
        term_puts(w, t, "  ipconfig - IP/MAC/шлюз/маска NIC + ARP cache");
        term_puts(w, t, "  ipset <a.b.c.d> - установить IP");
        term_puts(w, t, "  ping <a.b.c.d|host> [N] - ICMP-эхо (или по имени)");
        term_puts(w, t, "  arping <a.b.c.d> - один ARP-запрос");
        term_puts(w, t, "  udp <ip> <port> <text> - отправить UDP");
        term_puts(w, t, "  tcping <ip> <port> - попытка TCP-соединения");
        term_puts(w, t, "  tcpclose <idx> - закрыть TCP-сокет");
        term_puts(w, t, "  telnet <хост> [порт] - подключение к другому устройству");
        term_puts(w, t, "     (VT100: цвета, курсор; выход Ctrl+] или Ctrl+Q)");
        term_puts(w, t, "  dhcp - получить IP через DHCP");
        term_puts(w, t, "  dns <hostname> - разрешить имя в IP");
        term_puts(w, t, "  http <host> [path] - HTTP GET запрос");
        term_puts(w, t, "  --- ОБОРУДОВАНИЕ ---");
        term_puts(w, t, "  lspci - список всех PCI-устройств");
        term_puts(w, t, "  --- ЗАПУСК ПРИЛОЖЕНИЙ ---");
        term_puts(w, t, "  <имя> - открыть приложение напрямую");
        term_puts(w, t, "    terminal files editor browser games mines");
        term_puts(w, t, "    nettrace sysinfo taskmgr settings");
        term_puts(w, t, "  spawn <имя> - то же самое, явно");
        term_puts(w, t, "  curl <url>  - HTTP GET запрос");
        term_puts(w, t, "  c4test    - тест c4 (массивы, for, #define, printf)");
        term_puts(w, t, "  cc <имя.c>  - скомпилировать .c в .bin (native)");
        term_puts(w, t, "  run <имя>   - запустить .bin с RAM-диска");
        term_puts(w, t, "  --- JAVASCRIPT (MicroQuickJS) ---");
        term_puts(w, t, "  js          - JS REPL (интерактивный режим, .exit - выход)");
        term_puts(w, t, "  js <имя.js> - выполнить .js-скрипт из RAM-диска");
    } else if (!strcmp(c, "about")) {
        term_puts(w, t, "N2600-OS 0.1 - оконная ОС на чистом C.");
        term_puts(w, t, "Ядро собирается MinGW, грузится GRUB'ом в VESA LFB.");
    } else if (!strcmp(c, "sysinfo")) {
        char brand[52], line[96];
        cpu_get_brand(brand);
        snprintf(line, sizeof(line), "CPU: %s", brand);
        term_puts(w, t, line);
        /* сессия 74: онлайн-ядра из SMP-инициализации (реально запущено
         * через INIT-SIPI), не просто счёт CPUID */
        snprintf(line, sizeof(line), "Ядер: %d логических, %d онлайн (SMP)",
                 smp_cpu_count(), smp_online_count());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "RAM: %u МиБ, экран: %ux%ux32",
                 (unsigned)mem_ram_mib(), (unsigned)fb_width(), (unsigned)fb_height());
        term_puts(w, t, line);
        /* сессия 90: hwdet-подобная диагностика (SMBIOS/ACPI) */
        if (hwinfo_dmi_system()[0]) {
            snprintf(line, sizeof(line), "Система: %s (BIOS %s)",
                     hwinfo_dmi_system(),
                     hwinfo_dmi_bios()[0] ? hwinfo_dmi_bios() : "n/a");
            term_puts(w, t, line);
        }
        if (hwinfo_dev_hid()) {
            char ab[64];
            hwinfo_acpi_summary(ab, sizeof(ab));
            snprintf(line, sizeof(line), "%s; устройств с _HID: %d",
                     ab, hwinfo_dev_hid());
            term_puts(w, t, line);
        }
    } else if (!strcmp(c, "mem")) {
        char line[96];
        snprintf(line, sizeof(line), "RAM всего: %u МиБ", (unsigned)mem_ram_mib());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "Куча: занято %u КиБ из %u КиБ",
                 (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
        term_puts(w, t, line);
    } else if (!strcmp(c, "uptime")) {
        u32 up = uptime_sec();
        char line[64];
        snprintf(line, sizeof(line), "Время работы: %02u:%02u:%02u",
                 up / 3600, (up / 60) % 60, up % 60);
        term_puts(w, t, line);
    } else if (!strcmp(c, "apps")) {
        char line[80];
        int n = wm_window_count();
        snprintf(line, sizeof(line), "Открыто окон: %d", n);
        term_puts(w, t, line);
        for (int i = 0; i < n; i++) {
            snprintf(line, sizeof(line), "  [%d] %s", i, wm_window_title(i));
            term_puts(w, t, line);
        }
    } else if (!strcmp(c, "wpa2test")) {
        /* Сессия 12: тест-векторы WPA2-криптографии на целевой машине.
         * Те же векторы, что в scripts/test_wpa2_host.c (хост-сборка):
         * SHA-1, PBKDF2, AES-128, AES-Unwrap, PRF. Если всё ОК —
         * рукопожатие WPA2 на этом железе считает те же ключи, что
         * и wpa_supplicant. */
        int ok = 0, total = 0;
        u8 d[32];
        /* SHA-1("abc") */
        total++;
        wpa2_sha1("abc", 3, d);
        {
            static const u8 want[20] = {0xa9,0x99,0x3e,0x36,0x47,0x06,0x81,
                0x6a,0xba,0x3e,0x25,0x71,0x78,0x50,0xc2,0x6c,0x9c,0xd0,0xd8,0x9d};
            if (memcmp(d, want, 20) == 0) ok++;
        }
        /* PBKDF2("password","salt",1,20) */
        total++;
        wpa2_pbkdf2_sha1((const u8 *)"password", 8, (const u8 *)"salt", 4,
                         1, d, 20);
        {
            static const u8 want[20] = {0x0c,0x60,0xc8,0x0f,0x96,0x1f,0x0e,
                0x71,0xf3,0xa9,0xb5,0x24,0xaf,0x60,0x12,0x06,0x2f,0xe0,0x37,0xa6};
            if (memcmp(d, want, 20) == 0) ok++;
        }
        /* AES-128 (FIPS-197 C.1) */
        total++;
        {
            u8 key[16], in[16], out[16];
            for (int i = 0; i < 16; i++) { key[i] = (u8)i; in[i] = (u8)(i * 0x11); }
            wpa2_aes128_encrypt(key, in, out);
            static const u8 want[16] = {0x69,0xc4,0xe0,0xd8,0x6a,0x7b,0x04,
                0x30,0xd8,0xcd,0xb7,0x80,0x70,0xb4,0xc5,0x5a};
            if (memcmp(out, want, 16) == 0) ok++;
        }
        /* AES-Unwrap (RFC 3394 4.1): wrap->unwrap roundtrip */
        total++;
        {
            u8 kek[16], pt[16], wr[24], unw[16];
            for (int i = 0; i < 16; i++) { kek[i] = (u8)i; pt[i] = (u8)(i * 0x11); }
            wpa2_aes_wrap(kek, pt, 16, wr);
            if (wpa2_aes_unwrap(kek, wr, 24, unw) && memcmp(unw, pt, 16) == 0)
                ok++;
        }
        /* PRF: hostap-вектор (первые 8 байт) */
        total++;
        {
            u8 out[80];
            wpa2_prf((const u8 *)"secret", 6, "prefix",
                     (const u8 *)"this is a test of the emergency broadcast system",
                     48, out, 80);
            static const u8 want[8] = {0x3d,0x20,0x3d,0xfa,0xac,0x17,0x27,0x80};
            if (memcmp(out, want, 8) == 0) ok++;
        }
        char line[96];
        snprintf(line, sizeof(line), "wpa2test: %d/%d векторов OK %s",
                 ok, total, ok == total ? "(криптография WPA2 исправна)" : "(ОШИБКА!)");
        term_puts(w, t, line);
    } else if (!strncmp(c, "open ", 5)) {
        /* Сессия 12: открыть приложение по номеру из меню
         * (пример: open 10 — Настройки). Удобно и в тестах. */
        char *arg = c + 5;
        while (*arg == ' ') arg++;
        int idx = -1;
        if (arg[0] >= '0' && arg[0] <= '9') {
            idx = 0;
            for (; *arg >= '0' && *arg <= '9'; arg++)
                idx = idx * 10 + (*arg - '0');
        }
        if (idx >= 0 && idx < app_table_count) {
            term_puts(w, t, app_table[idx].name);
            apps_open(idx);
        } else {
            term_puts(w, t, "open <номер> — номер из меню «Меню» (0..N)");
        }
    } else if (!strncmp(c, "echo ", 5)) {
        term_puts(w, t, c + 5);
    } else if (!strcmp(c, "echo")) {
        term_puts(w, t, "");
    } else if (!strcmp(c, "clear")) {
        t->nlines = 0;
        term_touch(w);
    } else if (!strcmp(c, "reboot")) {
        sys_reboot();
    } else if (!strcmp(c, "poweroff")) {
        sys_poweroff();
    } else if (!strncmp(c, "ramls", 5) && (c[5] == 0 || c[5] == ' ')) {
        ramfs_dirent_t files[32];
        int n = ramfs_list(files, 32);
        if (n == 0) {
            term_puts(w, t, "RAM disk пуст");
        } else {
            char line[128];
            snprintf(line, sizeof(line), "Файлов в RAM: %d", n);
            term_puts(w, t, line);
            for (int i = 0; i < n; i++) {
                snprintf(line, sizeof(line), "  %s (%u байт)", files[i].name, files[i].size);
                term_puts(w, t, line);
            }
        }
    } else if (!strcmp(c, "ataprobe")) {
        extern void ata_probe_diag(void);
        ata_probe_diag();
        term_puts(w, t, "ATA-регистры — в serial");
    } else if (!strncmp(c, "mkdir ", 6) || !strncmp(c, "touch ", 6) ||
               !strncmp(c, "rmdir ", 6) || !strncmp(c, "rm ", 3)) {
        /* FIX: "rm " сравнивается по 3 байта — strncmp(.., 4) заходил
         * за NUL литерала ('q' != '\0') и rm <файл> НЕ совпадал вовсе */
        /* Сессия 13: работа с иерархией RAM disk из терминала
         * (и автотесты через AUTORUN). rm удаляет файлы, rmdir — пустые
         * каталоги (полный путь без ведущего '/'; корень = "/"). */
        int is_mkdir = (c[0] == 'm');
        int is_touch = (c[0] == 't');
        int is_rmdir = (c[0] == 'r' && c[1] == 'm' && c[2] == 'd');
        int is_rm = (c[0] == 'r' && c[1] == 'm' && c[2] == ' ');
        /* FIX: touch — тоже смещение 6 (раньше 4: «touch dir1/x»
         * обрезался до «h» — имя из первой буквы) */
        char *arg = c + ((is_mkdir || is_rmdir || is_touch) ? 6 : 3); /* rm: смещение 3 */
        while (*arg == ' ') arg++;
        if (!*arg) {
            term_puts(w, t, "Использование: mkdir|rmdir|rm|touch <путь>");
        } else if (is_mkdir) {
            if (ramfs_mkdir(arg)) {
                char l[96]; snprintf(l, sizeof(l), "Каталог создан: %s", arg);
                term_puts(w, t, l);
                serial_puts("[term] mkdir ok: ");
                serial_puts(arg);
                serial_puts("\n");
            } else { term_puts(w, t, "Не удалось (родителя нет/имя занято)");
                     serial_puts("[term] mkdir FAIL\n"); }
        } else if (is_rmdir || is_rm) {
            if (ramfs_delete(arg)) {
                char l[96]; snprintf(l, sizeof(l), "Удалено: %s", arg);
                term_puts(w, t, l);
                serial_puts("[term] delete ok: ");
                serial_puts(arg);
                serial_puts("\n");
            } else {
                term_puts(w, t, is_rmdir ? "Каталог не пуст (или не найден)"
                                         : "Не удалось удалить (не найден?)");
                serial_puts("[term] delete FAIL: ");
                serial_puts(arg);
                serial_puts("\n");
            }
        } else {
            ramfs_delete(arg);
            if (ramfs_create(arg, 1) && ramfs_write(arg, "", 1)) {
                char l[96]; snprintf(l, sizeof(l), "Файл создан: %s (0 байт)", arg);
                term_puts(w, t, l);
                serial_puts("[term] touch ok: ");
                serial_puts(arg);
                serial_puts("\n");
            } else { term_puts(w, t, "Не удалось создать");
                     serial_puts("[term] touch FAIL\n"); }
        }
    } else if (!strcmp(c, "ramtree")) {
        /* Плоский список с полными путями — проверка иерархии в тестах */
        static ramfs_dirent_t ents[64];   /* сессия 13: 9.7КБ НЕ на стеке */
        int n = ramfs_list(ents, 64);
        char l[96];
        snprintf(l, sizeof(l), "RAM disk: %d записей", n);
        term_puts(w, t, l);
        for (int i = 0; i < n; i++) {
            snprintf(l, sizeof(l), "  %s%s (%u)", ents[i].name,
                     ents[i].is_dir ? "/" : "", (unsigned)ents[i].size);
            term_puts(w, t, l);
            serial_puts("[ramtree] ");
            serial_puts(ents[i].name);
            serial_puts(ents[i].is_dir ? "/ " : " ");
            {
                char nb[16];
                snprintf(nb, sizeof(nb), "%u\n", (unsigned)ents[i].size);
                serial_puts(nb);
            }
        }
    } else if (!strcmp(c, "heapdump")) {
        /* Сессия 13: дамп блоков кучи в serial (addr/size/owner) */
        extern void serial_puts(const char *s);
        extern u32  mem_debug_walk(u32 *largest, u32 *nfree);
        extern u32  mem_heap_size(void);
        {
            char l[96];
            u32 lg = 0, nf = 0;
            u32 fr = mem_debug_walk(&lg, &nf);
            snprintf(l, sizeof(l), "heapdump: %u байт, своб. %u (%u блок., макс %u)",
                     (unsigned)mem_heap_size(), (unsigned)fr,
                     (unsigned)nf, (unsigned)lg);
            term_puts(w, t, l);
            serial_puts("[heapdump] ");
            serial_puts(l);
            serial_puts("\n");
        }
        extern void mem_dump_blocks(void);
        mem_dump_blocks();
    } else if (!strncmp(c, "bindump ", 8)) {
        /* bindump <файл> — шестнадцатеричный дамп файла из RAM disk в
         * serial (диагностика c4-бинарников: разбор на хосте objdump'ом).
         * Формат: BINHEX <имя> <размер>; строки «aaaaaaaa: bb bb ...»; END. */
        char *name = c + 8;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: bindump <имя.bin>");
        } else {
            static ramfs_dirent_t ents[64];   /* сессия 13: 4.8КБ НЕ на стеке */
            int n = ramfs_list(ents, 64);
            u32 sz = 0;
            int found = 0;
            for (int i = 0; i < n; i++)
                if (!strcmp(ents[i].name, name)) { sz = ents[i].size; found = 1; break; }
            if (!found) {
                term_puts(w, t, "Файл не найден");
            } else {
                u8 *buf = (u8 *)malloc(sz);
                if (!buf) { term_puts(w, t, "Нет памяти"); return; }
                u32 got = ramfs_read(name, buf, sz);
                if (got != sz) { free(buf); term_puts(w, t, "Ошибка чтения"); return; }
                char hdr[96], line[80];
                extern void serial_puts(const char *s);
                snprintf(hdr, sizeof(hdr), "BINHEX %s %u", name, (unsigned)sz);
                serial_puts(hdr);
                serial_puts("\n");
                for (u32 off = 0; off < got; off += 16) {
                    u32 n1 = (got - off < 16) ? (got - off) : 16;
                    int p = snprintf(line, sizeof(line), "%08x:", (unsigned)off);
                    for (u32 j = 0; j < n1; j++)
                        p += snprintf(line + p, sizeof(line) - p, " %02x", buf[off + j]);
                    serial_puts(line);
                    serial_puts("\n");
                }
                serial_puts("BINHEX-END\n");
                snprintf(line, sizeof(line), "Дамп %s (%u байт) — в serial", name, (unsigned)got);
                term_puts(w, t, line);
                free(buf);
            }
        }
    } else if (!strncmp(c, "ramwrite ", 9)) {
        char *name = c + 9;
        char *space = strchr(name, ' ');
        if (!space) {
            term_puts(w, t, "Использование: ramwrite <имя> <текст>");
        } else {
            *space = 0;
            char *text = space + 1;
            u32 len = strlen(text) + 1;
            if (ramfs_create(name, len) && ramfs_write(name, text, len)) {
                char line[128];
                snprintf(line, sizeof(line), "Создан файл '%s' (%u байт)", name, len);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "Ошибка создания файла");
            }
        }
    } else if (!strncmp(c, "ramread ", 8)) {
        char *name = c + 8;
        char buf[256];
        u32 n = ramfs_read(name, buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = 0;
            char line[320];
            snprintf(line, sizeof(line), "Содержимое '%s': %s", name, buf);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Файл не найден");
        }
    } else if (!strncmp(c, "ramdel ", 7)) {
        char *name = c + 7;
        if (ramfs_delete(name)) {
            char line[128];
            snprintf(line, sizeof(line), "Файл '%s' удален", name);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Файл не найден");
        }
    } else if (!strcmp(c, "raminfo")) {
        char line[128];
        snprintf(line, sizeof(line), "RAM disk: %u МиБ всего, %u КиБ свободно",
                 (unsigned)(ramfs_total_space() / (1024 * 1024)),
                 (unsigned)(ramfs_free_space() / 1024));
        term_puts(w, t, line);
    } else if (!strcmp(c, "tasks")) {
        int n = task_count();
        char line[80];
        snprintf(line, sizeof(line), "Активных задач: %d (текущая = %d)",
                 n, task_current());
        term_puts(w, t, line);
        for (int i = 0; i < MAX_TASKS; i++) {
            /* завершённые задачи не показываем: их слот ещё занят до
             * переиспользования (stack freed в task_spawn), выводить
             * их как «активные» вводило в заблуждение */
            if (task_name(i)[0] && !task_finished(i)) {
                snprintf(line, sizeof(line), "  [%d] cpu%d %s%s", i,
                         task_cpu(i), task_name(i),
                         task_is_system(i) ? " (системная)" : "");
                term_puts(w, t, line);
            }
        }
    } else if (!strcmp(c, "spin")) {
        /* ТЕСТ ЖИВУЧЕСТИ: породить задачу с вечным занятым циклом.
         * Раньше такое (или зависшее приложение, убитое диспетчером
         * в неудачный момент) могло повесить ВСЮ систему — блокировки
         * теперь хранят владельца и восстанавливаются (sync.h).
         * Система обязана остаться живой; убить — kill <N> или Del
         * в диспетчере задач. */
        int tid = task_spawn("spin", spin_task_fn, NULL);
        if (tid > 0) {
            char line[96];
            snprintf(line, sizeof(line),
                     "Задача #%d (spin) запущена: вечный цикл. Система должна жить; kill %d",
                     tid, tid);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Не удалось создать задачу");
        }
    } else if (!strcmp(c, "divzero")) {
        /* ТЕСТ ИЗОЛЯЦИИ ИСКЛЮЧЕНИЙ (сессия 81): задача падает с #0.
         * Ожидание: serial «[exc] в задаче N 'divzero' (eip=...) —
         * задача снята, ОС продолжает работу»; GUI жив. */
        int tid = task_spawn("divzero", divzero_task_fn, NULL);
        if (tid > 0) {
            char line[96];
            snprintf(line, sizeof(line),
                     "Задача #%d (divzero) запущена: деление на ноль."
                     " Ожидание: только задача погибнет, ОС жива", tid);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Не удалось создать задачу");
        }
    } else if (!strcmp(c, "kmainfault")) {
        /* ТЕСТ KMAIN-RECOVER (сессия 81): следующий кадр композитора
         * падает с #0 ПОД wm_glock. До фикса — красный экран и мёртвая
         * система; теперь: кадр пропускается, рабочий стол жив. */
        wm_test_kmain_fault();
        term_puts(w, t, "Следующий кадр композитора упадёт с #0 (под glock).");
        term_puts(w, t, "Ожидание: [exc] kmain пережил #0 ... — GUI жив, кадр пропущен");
    } else if (!strcmp(c, "apipitest")) {
        /* SMP-REWORK ШАГ 4: проверка mailbox/IPI AP->BSP (250 запросов:
         * 200 NOP-арифметика + 50 malloc/free через кучу BSP).
         * Итог печатается в serial: «[apipitest] cpu=N: ... ok». */
        int tid = task_spawn("apipitest", apipitest_task_fn, NULL);
        if (tid > 0) {
            char line[96];
            snprintf(line, sizeof(line),
                     "Задача #%d (apipitest): 250 syscall AP->BSP, итог в serial", tid);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Не удалось создать задачу");
        }
    } else if (!strcmp(c, "klockhang")) {
        /* SMP-rework ШАГ 1: ДЕТЕРМИНИРОВАННЫЙ тест FATAL-пути klock.
         * Задача берёт klock, глушит прерывания и висит: через ~2 с
         * любой ждущий на BSP обязан напечатать [klock] FATAL и
         * остановить систему (выбор при SMP-rework: паника с диагнозом
         * лучше порчи кучи двумя ядрами). СИСТЕМА ОСТАНОВИТСЯ — тест!
         * После него — перезапуск QEMU. */
        term_puts(w, t, "Задача берёт klock и глушит прерывания.");
        term_puts(w, t, "Через ~2 с: [klock] FATAL + halt (ЭТО ТЕСТ, система остановится).");
        (void)task_spawn("klockhang", klockhang_task_fn, NULL);
    } else if (!strcmp(c, "spinlock")) {
        /* ЖЁСТКИЙ тест: задача берёт блокировку оконного менеджера
         * и зависает. До фикса — полный фриз UI навсегда; теперь
         * система обязана ожить через ~20 с (SLOCK_STALE_TICKS). */
        term_puts(w, t, "Задача берёт glock и зависает: UI замрёт ~20 c,");
        term_puts(w, t, "затем обязан ожить (блокировка отобрана). kill <N> после.");
        int tid = wm_test_glock_spin();
        if (tid > 0) {
            char line[96];
            snprintf(line, sizeof(line), "Задача #%d (spinlock) запущена", tid);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Не удалось создать задачу");
        }
    } else if (!strncmp(c, "kill ", 5)) {
        /* Завершить задачу по индексу (как Del в диспетчере задач). */
        int idx = -1;
        for (const char *p = c + 5; *p >= '0' && *p <= '9'; p++)
            idx = (idx < 0 ? 0 : idx) * 10 + (*p - '0');
        if (idx < 0) {
            term_puts(w, t, "Использование: kill <номер задачи> (см. tasks)");
        } else if (idx == 0) {
            term_puts(w, t, "Задачу #0 (система) убивать нельзя");
        } else if (task_is_system(idx)) {
            char line[96];
            snprintf(line, sizeof(line),
                     "Задача #%d (%s) — системная, убийство запрещено",
                     idx, task_name(idx));
            term_puts(w, t, line);
        } else {
            int r = task_kill(idx);
            wm_request_kill(idx);   /* убрать окно, если это поток окна */
            char line[96];
            snprintf(line, sizeof(line), r ? "Задача #%d убита" : "Задача #%d не найдена", idx);
            term_puts(w, t, line);
        }
    } else if (!strcmp(c, "adapters")) {
        /* Сессия 11: реестр адаптеров + приоритет */
        char line[112];
        snprintf(line, sizeof(line), "Режим: %s, адаптеров: %d",
                 net_adapter_mode() == 0 ? "АВТО (по линку)" : "ручной",
                 net_adapter_count());
        term_puts(w, t, line);
        for (int i = 0; i < 5; i++) {
            if (!net_adapter_present(i)) continue;
            const char *nm = net_adapter_name(i);
            int act = (net_adapter_active() == i);
            if (i == 4 && wifi_present()) {
                snprintf(line, sizeof(line), "  %-8s %-10s %s   %s",
                         nm, act ? "[АКТИВЕН]" : "",
                         wifi_conn_state_name(), wifi_conn_ssid());
            } else {
                snprintf(line, sizeof(line), "  %-8s %-10s link:%s",
                         nm, act ? "[АКТИВЕН]" : "",
                         net_adapter_link(i) ? "up" : "down");
            }
            term_puts(w, t, line);
        }
        term_puts(w, t, "Команда: adapter auto | adapter <имя> (см. Настройки)");
    } else if (!strcmp(c, "ne2000")) {
        /* Сессия 12: диагностика драйвера ne2000 — состояние кольца
         * приёма и счётчики (для разбора «RX всегда 0 / сеть рвётся»). */
        char line[128];
        if (ne2000_diag(line, (int)sizeof(line)) > 0)
            term_puts(w, t, line);
        else
            term_puts(w, t, "ne2000 не найден");
    } else if (!strncmp(c, "adapter ", 8)) {
        char *name = c + 8;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: adapter auto|e1000|virtio|ne2000|atl1c|wifi");
        } else if (strcmp(name, "auto") == 0) {
            net_adapter_set_mode(0);
            term_puts(w, t, "Приоритет: АВТО (по состоянию линка)");
        } else {
            int idx = net_adapter_find(name);
            if (idx < 0)
                term_puts(w, t, "Нет такого адаптера (adapters — список)");
            else {
                net_adapter_set_mode(idx + 1);
                char line[96];
                snprintf(line, sizeof(line),
                         "Приоритет: %s (ручной) — DHCP перезапущен", name);
                term_puts(w, t, line);
            }
        }
    } else if (!strcmp(c, "dmesg")) {
        /* Журнал процесса загрузки: все вехи kmain (железо, диски,
         * ramdisk-сидинг, сеть, задачи) — то, что пролетело на экране. */
        const char *klog = klog_get();
        if (!klog || !klog[0]) {
            term_puts(w, t, "Журнал загрузки пуст");
        } else {
            char line[96];
            snprintf(line, sizeof(line), "=== Журнал загрузки (%d строк) ===",
                     klog_line_count());
            term_puts(w, t, line);
            /* klog — '\n'-разделённые строки; term_print сама переносит
             * длинные по ширине окна */
            const char *p = klog;
            while (*p) {
                const char *nl = p;
                while (*nl && *nl != '\n') nl++;
                int L = (int)(nl - p);
                if (L > 90) L = 90;
                char buf[92];
                memcpy(buf, p, (u32)L);
                buf[L] = 0;
                term_puts(w, t, buf);
                p = (*nl) ? nl + 1 : nl;
            }
            term_puts(w, t, "=== конец журнала ===");
        }
    } else if (!strncmp(c, "dmesgdump", 9) && (c[9] == 0 || c[9] == ' ')) {
        /* СЕССИЯ 61: дамп журнала загрузки в файл RAM disk — журнал
         * легко переслать/открыть в «Файлах», не пересказывая по памяти.
         * Формат: dmesgdump [имя] (по умолчанию DMESG.TXT). */
        const char *klog = klog_get();
        const char *arg = c + 9;
        while (*arg == ' ') arg++;
        char name[FD_NAME_MAX + 1];
        if (*arg) {
            int ni = 0;
            for (const char *p = arg; *p && ni < FD_NAME_MAX; p++)
                if (*p != '/') name[ni++] = *p;
            name[ni] = 0;
        } else {
            strcpy(name, "DMESG.TXT");
        }
        if (!ramfs_ready()) {
            term_puts(w, t, "RAM disk недоступен");
        } else if (!klog || !klog[0]) {
            term_puts(w, t, "Журнал загрузки пуст — писать нечего");
        } else {
            u32 len = (u32)strlen(klog);
            ramfs_delete(name);
            if (!ramfs_create(name, len)) {
                term_puts(w, t, "Не удалось создать файл (место?)");
            } else if (!ramfs_write(name, klog, len)) {
                ramfs_delete(name);
                term_puts(w, t, "Ошибка записи файла");
            } else {
                char line[96];
                snprintf(line, sizeof(line),
                         "Дамп журнала: %s (%u байт, %d строк) — RAM disk",
                         name, (unsigned)len, klog_line_count());
                term_puts(w, t, line);
            }
        }
    } else if (!strcmp(c, "disks")) {
        /* Полный обзор устройств хранения: что нашлось, что смонтировано,
         * где видно в «Файлах» ([CD][HDD][RAM][USB]). */
        char line[112];
        term_puts(w, t, "=== Устройства хранения ===");
        /* CD / ISO9660 */
        if (ata_present() && ata_is_cdrom()) {
            iso9660_dirent_t root[8];
            int rn = iso9660_ready() ? iso9660_list_root(root, 8) : -1;
            snprintf(line, sizeof(line),
                     "CD  : %s (ATAPI, порт 0x%x)%s",
                     ata_model(), (unsigned)ata_base_port(),
                     iso9660_ready() ? ", ISO9660 готов" : ", ISO не читается");
            term_puts(w, t, line);
            if (rn >= 0) {
                snprintf(line, sizeof(line),
                         "      корень ISO: %d записей (Файлы -> [CD])", rn);
                term_puts(w, t, line);
            }
        } else {
            term_puts(w, t, "CD  : не найден (нет ATAPI)");
        }
        /* AHCI-контроллер (SATA) — теперь виден отдельно */
        if (ahci_present()) {
            snprintf(line, sizeof(line),
                     "SATA: AHCI-контроллер (%s%s%s)",
                     ahci_hdd_present() ? "диск" : "",
                     ahci_hdd_present() && ahci_cd_present() ? ", " : "",
                     ahci_cd_present() ? "CD" : "");
            term_puts(w, t, line);
        }
        /* HDD: через единый слой (AHCI или ATA) */
        if (disk_hdd_present()) {
            /* сессия 11: показываем смонтированную ФС (FAT32 или NTFS) */
            const char *fs = fat32_ready() ? "FAT32" :
                             (ntfs_ready() ? "NTFS" : NULL);
            snprintf(line, sizeof(line),
                     "HDD : [%s] %s, %u МиБ (%u секторов), %s",
                     disk_hdd_bus(),
                     disk_hdd_model(),
                     (unsigned)(disk_hdd_sectors() / 2048u),
                     (unsigned)disk_hdd_sectors(),
                     fs ? fs : "ФС не смонтирована");
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "HDD : не найден (пусто в AHCI и ATA)");
        }
        /* USB */
        snprintf(line, sizeof(line), "USB : %s",
                 usb_ehci_storage_ready()
                     ? "флешка готова (FAT32)" : "не найдено хранилища");
        term_puts(w, t, line);
        /* RAM disk */
        if (ramfs_ready()) {
            int stid = ramfs_server_task();
            snprintf(line, sizeof(line),
                     "RAM : ramfs, %u МиБ, занято %u КиБ, файлов %d",
                     (unsigned)(ramfs_total_space() / (1024u * 1024u)),
                     (unsigned)((ramfs_total_space() - ramfs_free_space()) / 1024u),
                     ramfs_file_count());
            term_puts(w, t, line);
            snprintf(line, sizeof(line),
                     "      процесс: задача %d%s, память: %u КиБ",
                     stid,
                     stid >= 0 ? " (системная, отдельный поток)" : "",
                     stid >= 0 ? (unsigned)(mem_task_used(stid) / 1024u) : 0u);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "RAM : ramfs не инициализирован");
        }
        term_puts(w, t, "Смотрите также: Файлы (кнопки CD/HDD/RAM/USB), dmesg");
    } else if (!strncmp(c, "run ", 4)) {
        char *name = c + 4;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: run <имя.bin>");
        } else {
            int tid = loader_spawn(name, NULL);
            if (tid < 0) {
                term_puts(w, t, "Не удалось запустить (файл не найден?)");
            } else {
                char line[80];
                snprintf(line, sizeof(line),
                         "Запущена задача %d: %s", tid, name);
                term_puts(w, t, line);
            }
        }
    } else if ((!strcmp(c, "js") || !strncmp(c, "js ", 3)) && t->sink_put) {
        /* [TERM-SINK] REPL глобален — через telnet не даём */
        term_puts(w, t, "js: REPL недоступен через telnet (глобальное состояние движка)");
    } else if (!strcmp(c, "js") || !strncmp(c, "js ", 3)) {
        /* QuickJS: `js` — REPL, `js <файл.js>` — выполнить скрипт */
        char *arg = c + 2;
        while (*arg == ' ') arg++;
        if (!*arg) {
            if (mqjs_repl_start() == 0) {
                t->repl = 1;
                mqjs_repl_set_window((struct window *)w);
                term_puts(w, t, "MicroQuickJS REPL (bellard/mquickjs, MIT).");
                term_puts(w, t, "Ввод: незакрытые { ( [ продолжаются со строки '...' ;");
                term_puts(w, t, "Ctrl+C — прервать выполняющийся код / выйти; .exit — выход.");
            } else {
                term_puts(w, t, "Нет памяти под REPL");
            }
        } else {
            /* [CC-BUF] (отчёт, баг 1, тот же класс): static-буфер 32КБ
             * делился между всеми окнами терминала — куча на вызов */
            char *js_src_buf = (char *)malloc(32768);
            if (!js_src_buf) {
                term_puts(w, t, "Нет памяти");
                return;
            }
            u32 got = ramfs_read(arg, js_src_buf, 32768 - 1);
            if (got == 0) {
                free(js_src_buf);
                term_puts(w, t, "Файл не найден в RAM disk (сохраните скрипт в редакторе)");
            } else {
                js_src_buf[got] = 0;
                char *src_copy = (char *)malloc(got + 1);
                if (!src_copy) {
                    free(js_src_buf);
                    term_puts(w, t, "Нет памяти");
                    return;
                }
                memcpy(src_copy, js_src_buf, got + 1);
                free(js_src_buf);
                js_file_ctx_t *jc = (js_file_ctx_t *)malloc(sizeof(js_file_ctx_t));
                if (!jc) {
                    free(src_copy);
                    term_puts(w, t, "Нет памяти");
                } else {
                    jc->out_max = 16384;
                    jc->out = (char *)malloc(jc->out_max);
                    jc->src = src_copy;
                    if (!jc->out || !jc->src) {
                        if (jc->out) free(jc->out);
                        if (jc->src) free(jc->src);
                        free(jc);
                        term_puts(w, t, "Нет памяти");
                    } else {
                        int tid = task_spawn("jsfile", js_file_task, jc);
                        if (tid < 0) {
                            free(jc->src); free(jc->out); free(jc);
                            term_puts(w, t, "Не удалось породить задачу");
                        } else {
                            char line[96];
                            snprintf(line, sizeof(line),
                                     "Запущена задача %d: %s", tid, arg);
                            term_puts(w, t, line);
                        }
                    }
                }
            }
        }
    } else if (!strcmp(c, "usbinfo")) {
        char line[120];
        snprintf(line, sizeof(line), "UHCI: %s",
                 usb_controllers_found() ? "detected" : "not present");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "EHCI: %s",
                 usb_ehci_present() ? "detected" : "not present");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB devices: %d", usb_devices_found());
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB keyboard: %s",
                 usb_keyboard_present() ? "yes" : "no");
        term_puts(w, t, line);
        snprintf(line, sizeof(line), "USB mouse: %s",
                 usb_mouse_present() ? "yes" : "no");
        term_puts(w, t, line);
        if (usb_ehci_storage_ready()) {
            term_puts(w, t, "USB flash drive: READY");
        } else {
            term_puts(w, t, "USB flash drive: not detected");
        }
    } else if (!strncmp(c, "usbread ", 8)) {
        char *p = c + 8;
        while (*p == ' ') p++;
        u32 sector = 0;
        while (*p >= '0' && *p <= '9') {
            sector = sector * 10 + (u32)(*p - '0');
            p++;
        }
        if (!usb_ehci_storage_ready()) {
            term_puts(w, t, "USB flash drive: not detected");
        } else {
            u8 buf[512];
            if (usb_ehci_read_sector(sector, buf)) {
                char line[128];
                /* Дамп первых 32 байт сектора */
                char hex[160];
                int pos = 0;
                for (int k = 0; k < 32 && pos < 140; k++) {
                    pos += snprintf(hex + pos, sizeof(hex) - pos, "%02x ", buf[k]);
                }
                snprintf(line, sizeof(line),
                         "Sector %u: %s", (unsigned)sector, hex);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "Read failed");
            }
        }
    } else if (!strcmp(c, "ipconfig")) {
        if (!net_nic_present()) {
            term_puts(w, t, "NIC: не найден");
        } else {
            char line[96];
            u8 mac[6];
            net_get_mac(mac);
            snprintf(line, sizeof(line),
                     "NIC: %s  MAC: %02x:%02x:%02x:%02x:%02x:%02x",
                     net_nic_name(),
                     mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
            term_puts(w, t, line);
            char ipbuf[16];
            u32 ip = net_get_ip();
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "IP: %s", ipbuf);
            term_puts(w, t, line);
            net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Маска: %s", ipbuf);
            term_puts(w, t, line);
            net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Шлюз: %s", ipbuf);
            term_puts(w, t, line);
            snprintf(line, sizeof(line), "TX пакетов: %u, RX пакетов: %u",
                     (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
            term_puts(w, t, line);
            /* ARP cache dump */
            net_arp_entry_t entries[NET_ARP_CACHE_SIZE];
            int n = net_arp_dump(entries, NET_ARP_CACHE_SIZE);
            if (n > 0) {
                term_puts(w, t, "--- ARP cache ---");
                for (int i = 0; i < n; i++) {
                    char ipbuf2[16];
                    net_ntoa(entries[i].ip, ipbuf2, sizeof(ipbuf2));
                    snprintf(line, sizeof(line), "  %s  %02x:%02x:%02x:%02x:%02x:%02x",
                             ipbuf2,
                             entries[i].mac[0], entries[i].mac[1],
                             entries[i].mac[2], entries[i].mac[3],
                             entries[i].mac[4], entries[i].mac[5]);
                    term_puts(w, t, line);
                }
            }
        }
    } else if (!strncmp(c, "ipset ", 6)) {
        char *p = c + 6;
        while (*p == ' ') p++;
        u32 ip = 0;
        if (!net_aton(p, &ip)) {
            term_puts(w, t, "Неверный IP. Пример: ipset 10.0.2.15");
        } else {
            net_set_ip(ip);
            char line[48];
            char buf[16];
            net_ntoa(ip, buf, sizeof(buf));
            snprintf(line, sizeof(line), "IP установлен: %s", buf);
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "arping ", 7)) {
        char *p = c + 7;
        while (*p == ' ') p++;
        u32 ip = 0;
        if (!net_aton(p, &ip)) {
            term_puts(w, t, "Неверный IP");
        } else if (!net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else if (net_get_ip() == 0) {
            term_puts(w, t, "IP не настроен (см. ipset)");
        } else {
            char buf[16];
            net_ntoa(ip, buf, sizeof(buf));
            char line[64];
            snprintf(line, sizeof(line), "ARP who-has %s tell ", buf);
            net_ntoa(net_get_ip(), buf, sizeof(buf));
            /* Допишем к строке */
            char line2[80];
            snprintf(line2, sizeof(line2), "%s%s", line, buf);
            term_puts(w, t, line2);
            net_send_arp_request(ip);
            net_wait_poll(200);
            term_puts(w, t, "ARP запрос отправлен");
        }
    } else if (!strncmp(c, "ping ", 5) && t->sink_put) {
        /* [TERM-SINK] вывод ping привязан к term_tick окна — через telnet
         * ответ не доходит; синхронной версии нет */
        term_puts(w, t, "ping: недоступен через telnet (выполняйте в локальном терминале)");
    } else if (!strncmp(c, "ping ", 5)) {
        char *p = c + 5;
        while (*p == ' ') p++;
        /* парсим IP */
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) {
            ipstr[i++] = *p++;
        }
        ipstr[i] = 0;
        while (*p == ' ') p++;
        /* опциональное N (число пакетов) */
        int n = 4;
        if (*p >= '0' && *p <= '9') {
            n = 0;
            while (*p >= '0' && *p <= '9') {
                n = n * 10 + (*p - '0');
                p++;
            }
            if (n < 1) n = 1;
            if (n > 100) n = 100;
        }
        u32 target = 0;
        if (!net_aton(ipstr, &target)) {
            /* СЕССИЯ 63: localhost → 127.0.0.1 без DNS-сервера
             * (net_dns_resolve знает его и так, но ниже стоял
             * досрочный отказ «DNS не настроен» до вызова резолва) */
            if (net_host_is_loopback(ipstr)) {
                target = 0x7F000001u;
            } else if (net_dns_server() == 0) {
                term_puts(w, t, "Неверный IP. DNS не настроен.");
                return;
            } else {
            term_puts(w, t, "Разрешение имени...");
            if (!net_dns_resolve(ipstr, &target, 5000)) {
                term_puts(w, t, "DNS: имя не разрешено");
                return;
            }
            char ipbuf[16];
            net_ntoa(target, ipbuf, sizeof(ipbuf));
            char line2[80];
            snprintf(line2, sizeof(line2), "%s → %s", ipstr, ipbuf);
            term_puts(w, t, line2);
            }
        }
        /* СЕССИЯ 63: loopback-цель пингуется без NIC и без IP —
         * эхо-ответ стек формирует мгновенно (net_send_icmp_echo),
         * пакет не покидает машину. */
        if (!net_is_loopback(target) && !net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else if (!net_is_loopback(target) && net_get_ip() == 0) {
            term_puts(w, t, "IP не настроен (см. ipset)");
        } else if (g_ping.active && g_ping.win != w) {
            /* [PING-OWN] (отчёт, баг 2): g_ping один на систему — второй
             * терминал memset'ом сбрасывал сессию первого (его эхо-ответы
             * уводились в чужое окно / терялись вовсе). Параллельный ping
             * в другом окне — отказ; колбэк один, поэтому и не может быть
             * двух сессий. Окончившись/закрыв окно, сессию можно запускать
             * снова. */
            term_puts(w, t, "ping: сессия уже идёт в другом окне");
        } else {
            /* Инициализируем сессию ping */
            memset(&g_ping, 0, sizeof(g_ping));
            g_ping.target_ip = target;
            g_ping.timeout_ms = 1000;
            g_ping.max_count = n;
            g_ping.term = t;
            g_ping.win = w;
            g_ping.active = 1;
            g_ping.next_seq = 1;
            net_set_icmp_callback(ping_icmp_cb);   /* приём echo reply */
            /* FIX [P2] (ping замирал после заголовка): первый пакет не
             * отправлялся нигде — старт только ставил active=1, а
             * таймаут-ветка term_tick требует last_send_tick != 0.
             * Итог: ни пакетов, ни таймаутов — ping «висел» навсегда.
             * Теперь первый echo уходит немедленно. */
            {
                u16 seq = g_ping.next_seq++;
                g_ping.last_send_tick = timer_ticks();
                g_ping.sent++;
                u8 payload[32];
                memset(payload, 0xAA, 32);
                net_send_icmp_echo(g_ping.target_ip, 0x1234, seq, payload, 32);
            }
            char ipbuf[16];
            net_ntoa(target, ipbuf, sizeof(ipbuf));
            char line[80];
            snprintf(line, sizeof(line), "PING %s: %d пакет(ов), 32 байт",
                     ipbuf, n);
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "udp ", 4)) {
        /* udp <ip> <port> <text> — отправить UDP-сообщение */
        char *p = c + 4;
        while (*p == ' ') p++;
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) ipstr[i++] = *p++;
        ipstr[i] = 0;
        while (*p == ' ') p++;
        u32 port = 0;
        while (*p >= '0' && *p <= '9') { port = port * 10 + (u32)(*p - '0'); p++; }
        while (*p == ' ') p++;
        const char *text = p;
        if (!*text) {
            term_puts(w, t, "Использование: udp <ip> <port> <текст>");
        } else {
            u32 dst_ip = 0;
            if (!net_aton(ipstr, &dst_ip)) {
                term_puts(w, t, "Неверный IP");
            } else if (!net_nic_present() || net_get_ip() == 0) {
                term_puts(w, t, "Сеть не настроена (см. ipset)");
            } else {
                int sock = net_udp_open(30000);
                if (sock < 0) {
                    term_puts(w, t, "Не удалось открыть UDP-сокет");
                } else {
                    int n = net_udp_send(sock, dst_ip, (u16)port,
                                          text, (u32)strlen(text));
                    if (n < 0) {
                        term_puts(w, t, "UDP send failed");
                    } else {
                        char line[80];
                        char ipbuf[16];
                        net_ntoa(dst_ip, ipbuf, sizeof(ipbuf));
                        snprintf(line, sizeof(line),
                                 "UDP отправлено: %s:%u (%d байт)",
                                 ipbuf, (unsigned)port, n);
                        term_puts(w, t, line);
                    }
                    /* Подождём возможного ответа (неблокирующее ожидание) */
                    net_wait_poll(300);
                    net_udp_close(sock);
                }
            }
        }
    } else if (!strncmp(c, "tcping ", 7)) {
        /* tcping <ip> <port> — попытка TCP-соединения */
        char *p = c + 7;
        while (*p == ' ') p++;
        char ipstr[32];
        int i = 0;
        while (*p && *p != ' ' && i < 31) ipstr[i++] = *p++;
        ipstr[i] = 0;
        while (*p == ' ') p++;
        u32 port = 0;
        while (*p >= '0' && *p <= '9') { port = port * 10 + (u32)(*p - '0'); p++; }
        u32 dst_ip = 0;
        if (!net_aton(ipstr, &dst_ip)) {
            term_puts(w, t, "Неверный IP");
        } else if (!net_nic_present() || net_get_ip() == 0) {
            term_puts(w, t, "Сеть не настроена (см. ipset)");
        } else if (port == 0) {
            term_puts(w, t, "Использование: tcping <ip> <port>");
        } else {
            int sock = net_tcp_connect(dst_ip, (u16)port, 40000);
            if (sock < 0) {
                term_puts(w, t, "Нет свободных TCP-сокетов");
            } else {
                char line[96];
                char ipbuf[16];
                net_ntoa(dst_ip, ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line),
                         "TCP connect to %s:%u (sock=%d), ждём...",
                         ipbuf, (unsigned)port, sock);
                term_puts(w, t, line);
                /* Подождём ~3 секунды (неблокирующее ожидание) */
                {
                    u32 t0 = timer_ticks();
                    while ((timer_ticks() - t0) < 3000) {   /* 3 с (1 тик = 1 мс) */
                        net_wait_poll(10);
                        if (net_tcp_state(sock) == TCP_ESTABLISHED) break;
                        if (net_tcp_state(sock) == TCP_CLOSED) break;
                    }
                }
                tcp_state_t st = net_tcp_state(sock);
                snprintf(line, sizeof(line),
                         "Состояние: %s", tcp_state_name(st));
                term_puts(w, t, line);
                if (st == TCP_ESTABLISHED) {
                    net_tcp_send(sock, "hello\n", 6);
                    term_puts(w, t, "Отправлено: hello (6 байт)");
                }
                /* Закрываем если ещё установлен */
                if (net_tcp_state(sock) != TCP_CLOSED) {
                    net_tcp_close(sock);
                }
            }
        }
    } else if (!strncmp(c, "tcpclose ", 9)) {
        char *p = c + 9;
        while (*p == ' ') p++;
        int sock = 0;
        while (*p >= '0' && *p <= '9') { sock = sock * 10 + (*p - '0'); p++; }
        if (sock < 0 || sock >= 8) {
            term_puts(w, t, "Неверный индекс сокета");
        } else {
            net_tcp_close(sock);
            char line[64];
            snprintf(line, sizeof(line), "TCP sock %d закрыт", sock);
            term_puts(w, t, line);
        }
    } else if (!strncmp(c, "telnet", 6) && (c[6] == 0 || c[6] == ' ')) {
        /* [TCLIENT] итерация 7: telnet-клиент — подключение к другому
         * устройству; вывод хоста идёт в VT-эмулятор (см. [TERM-VT]) */
        if (t->vt) {
            term_puts(w, t, "telnet: сессия уже активна (Ctrl+] — завершить)");
        } else if (t->sink_put) {
            term_puts(w, t, "telnet: доступен только в локальном терминале");
        } else if (!c[6]) {
            term_puts(w, t, "Использование: telnet <хост> [порт]   (порт по умолчанию 23)");
        } else if (g_tel.t && g_tel.t->vt) {
            term_puts(w, t, "telnet: сессия уже открыта в другом окне терминала");
        } else {
            char host[64];
            int port = 23;
            char *p = c + 6;
            while (*p == ' ') p++;
            int hi = 0;
            while (*p && *p != ' ' && hi < 63) host[hi++] = *p++;
            host[hi] = 0;
            while (*p == ' ') p++;
            if (*p >= '0' && *p <= '9') {
                port = 0;
                while (*p >= '0' && *p <= '9') {
                    port = port * 10 + (*p - '0');
                    p++;
                }
            }
            if (port <= 0 || port > 65535) port = 23;
            telnet_start(w, t, host, port);
        }
    } else if (!strcmp(c, "ifconfig")) {
        char ipbuf[16];
        term_puts(w, t, "Сеть:");
        net_ntoa(net_get_ip(), ipbuf, sizeof(ipbuf));
        char line[80];
        snprintf(line, sizeof(line), "  IP:      %s", ipbuf);
        term_puts(w, t, line);
        net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
        snprintf(line, sizeof(line), "  Маска:   %s", ipbuf);
        term_puts(w, t, line);
        net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
        snprintf(line, sizeof(line), "  Шлюз:    %s", ipbuf);
        term_puts(w, t, line);
        u32 dns = net_dns_server();
        if (dns) {
            net_ntoa(dns, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "  DNS:     %s", ipbuf);
            term_puts(w, t, line);
        }
        u8 mac[6];
        net_get_mac(mac);
        snprintf(line, sizeof(line), "  MAC:     %02x:%02x:%02x:%02x:%02x:%02x",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        term_puts(w, t, line);
        term_puts(w, t, "Ручная настройка: ifconfig <ip> <маска> <шлюз>");
    } else if (!strncmp(c, "ifconfig ", 9)) {
        u32 ip = 0, mask = 0xFFFFFF00, gw = 0;
        /* парсим вручную: до 12 октетов (ip mask gw) */
        u32 parts[12]; int np = 0;
        for (const char *p = c + 9; *p && np < 12; ) {
            while (*p == ' ') p++;
            u32 v = 0; int got = 0;
            while (*p >= '0' && *p <= '9') { v = v * 10 + (*p - '0'); p++; got = 1; }
            if (*p == '.') p++;
            if (got) parts[np++] = v;
            else if (*p) p++;
        }
        if (np >= 4) {
            ip = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3];
            if (np >= 8)
                mask = (parts[4] << 24) | (parts[5] << 16) | (parts[6] << 8) | parts[7];
            if (np >= 12)
                gw = (parts[8] << 24) | (parts[9] << 16) | (parts[10] << 8) | parts[11];
            net_set_ip(ip);
            net_set_netmask(mask);
            if (gw) net_set_gateway(gw);
            char ipbuf[16];
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            char line[80];
            snprintf(line, sizeof(line), "Настроено: ip %s", ipbuf);
            term_puts(w, t, line);
        } else {
            term_puts(w, t, "Использование: ifconfig <ip> <маска> <шлюз>");
        }
    } else if (!strcmp(c, "dhcp")) {
        if (!net_nic_present()) {
            term_puts(w, t, "NIC не найден");
        } else {
            term_puts(w, t, "DHCP: DISCOVER → OFFER → REQUEST → ACK...");
            int r = net_dhcp_acquire(10000);
            if (r) {
                term_puts(w, t, "DHCP: успех! Параметры:");
                char line[80];
                char ipbuf[16];
                net_ntoa(net_get_ip(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  IP: %s", ipbuf);
                term_puts(w, t, line);
                net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  Маска: %s", ipbuf);
                term_puts(w, t, line);
                net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "  Шлюз: %s", ipbuf);
                term_puts(w, t, line);
                u32 dns = net_dns_server();
                if (dns) {
                    net_ntoa(dns, ipbuf, sizeof(ipbuf));
                    snprintf(line, sizeof(line), "  DNS: %s", ipbuf);
                    term_puts(w, t, line);
                }
            } else {
                term_puts(w, t, "DHCP: нет ответа (таймаут)");
            }
        }
    } else if (!strncmp(c, "dns ", 4)) {
        char *hostname = c + 4;
        while (*hostname == ' ') hostname++;
        if (!*hostname) {
            term_puts(w, t, "Использование: dns <hostname>");
        } else if (net_dns_server() == 0) {
            term_puts(w, t, "DNS-сервер не настроен (см. dhcp или ipset)");
        } else {
            u32 ip = 0;
            term_puts(w, t, "DNS: запрос...");
            if (net_dns_resolve(hostname, &ip, 5000)) {
                char line[80];
                char ipbuf[16];
                net_ntoa(ip, ipbuf, sizeof(ipbuf));
                snprintf(line, sizeof(line), "%s → %s", hostname, ipbuf);
                term_puts(w, t, line);
            } else {
                term_puts(w, t, "DNS: не удалось разрешить имя");
            }
        }
    } else if (!strncmp(c, "http ", 5) || !strncmp(c, "https ", 6)) {
        /* http/https <host> [path] — TLS включается автоматически при
         * порте 443 (см. net_http_get_impl); https-команда — порт 443 */
        int use_tls = (c[4] == 's');
        char *p = c + (use_tls ? 6 : 5);
        while (*p == ' ') p++;
        char host[128];
        int i = 0;
        while (*p && *p != ' ' && i < 127) host[i++] = *p++;
        host[i] = 0;
        while (*p == ' ') p++;
        const char *path = "/";
        if (*p) path = p;
        if (!*host) {
            term_puts(w, t, "Использование: http|https <host> [path]");
        } else if (!net_host_is_loopback(host) &&
                   (!net_nic_present() || net_get_ip() == 0)) {
            /* СЕССИЯ 63: loopback (127.0.0.1, localhost) — без сети */
            term_puts(w, t, "Сеть не настроена (см. dhcp или ipset)");
        } else {
            /* FIX (многозадачность): было static char resp[4096] — ОБЩИЙ
             * буфер на все окна терминала (та же болезнь, что md[8192]
             * в браузере). Теперь — на каждый вызов. */
            char *resp = (char *)malloc(4096);
            term_puts(w, t, use_tls ? "HTTPS GET запрос..." : "HTTP GET запрос...");
            u16 port = use_tls ? 443 : 80;
            int n = resp ? net_http_get(host, port, path, resp, 4096, 10000) : -1;
            /* Сессия 58: авто-fallback на HTTPS (как в браузере) —
             * большинство сайтов сегодня только по TLS, http:80 часто
             * режется на пути (connection refused/таймаут).
             * Сессия 63: для loopback не повторяем — локальный httpd
             * отвечает только по plain HTTP. */
            if (n <= 0 && !use_tls && resp && !net_host_is_loopback(host)) {
                const char *why0 = net_http_errstr();
                if (strncmp(why0, "connection", 10) == 0 ||
                    strncmp(why0, "connect timeout", 15) == 0) {
                    char line[96];
                    snprintf(line, sizeof(line), "HTTP: %s — пробую HTTPS...",
                             why0);
                    term_puts(w, t, line);
                    use_tls = 1;
                    port = 443;
                    n = net_http_get(host, port, path, resp, 4096, 10000);
                }
            }
            if (n > 0) {
                char line[80];
                snprintf(line, sizeof(line), "Получено %d байт%s:", n,
                         use_tls ? " (https)" : "");
                term_puts(w, t, line);
                /* Вывести первые ~10 строк ответа */
                int shown = 0;
                char *start = resp;
                while (shown < 10 && start < resp + n) {
                    char *nl = start;
                    while (nl < resp + n && *nl != '\n') nl++;
                    int L = nl - start;
                    L = utf8_clamp(start, L, TERM_MAX_COLS - 1);
                    char buf[TERM_MAX_COLS + 1];
                    memcpy(buf, start, L);
                    buf[L] = 0;
                    term_puts(w, t, buf);
                    start = (nl < resp + n) ? nl + 1 : nl;
                    shown++;
                }
            } else {
                term_puts(w, t, "HTTP(S): ошибка (нет ответа/таймаут)");
            }
            if (resp) free(resp);
        }
    } else if (!strcmp(c, "lspci")) {
        /* Вывести все PCI-устройства с человекочитаемыми именами */
        term_puts(w, t, "=== PCI Devices ===");
        int found = 0;
        for (int bus = 0; bus < 256; bus++) {
            for (int dev = 0; dev < 32; dev++) {
                u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                int max_func = (hdr & 0x80) ? 8 : 1;
                for (int func = 0; func < max_func; func++) {
                    u32 id = pci_read32(bus, dev, func, 0);
                    u16 vendor = (u16)(id & 0xFFFF);
                    u16 device = (u16)(id >> 16);
                    if (vendor == 0xFFFF) continue;
                    found++;
                    u32 classcc = pci_read32(bus, dev, func, 0x08);
                    u8 cc_base = (u8)((classcc >> 24) & 0xFF);
                    u8 cc_sub = (u8)((classcc >> 16) & 0xFF);
                    u8 rev = (u8)(classcc & 0xFF);
                    const char *vname = pci_vendor_lookup(vendor);
                    const char *dname = pci_id_lookup(vendor, device);
                    char line[96];
                    if (vname && dname) {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %s %s",
                                 bus, dev, func, vname, dname);
                    } else if (vname) {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %s dev:%04x cls:%02x/%02x",
                                 bus, dev, func, vname, device,
                                 cc_base, cc_sub);
                    } else {
                        snprintf(line, sizeof(line),
                                 "%d:%d.%d %04x:%04x cls:%02x/%02x rev:%02x",
                                 bus, dev, func, vendor, device,
                                 cc_base, cc_sub, rev);
                    }
                    term_puts(w, t, line);
                    if (func == 0 && !(hdr & 0x80)) break;
                }
            }
            if (bus > 2) break;
        }
        {
            char sum[40];
            snprintf(sum, sizeof(sum), "Total: %d devices", found);
            term_puts(w, t, sum);
        }
    } else if (!strncmp(c, "spawn ", 6)) {
        char *name = c + 6;
        while (*name == ' ') name++;
        if (!*name) {
            term_puts(w, t, "Использование: spawn <имя>");
            term_puts(w, t, "Доступные: terminal files editor browser sysinfo taskmgr");
        } else if (app_spawn_by_name(name)) {
            term_puts(w, t, "Приложение запущено");
        } else {
            term_puts(w, t, "Приложение не найдено");
        }
    } else if (!strcmp(c, "e1000dbg")) {
        /* отладка: дамп состояния NIC в serial */
        {
            extern void e1000_debug_dump(void);
            e1000_debug_dump();
            term_puts(w, t, "e1000 dump -> serial");
        }
    } else if (!strncmp(c, "curl ", 5)) {
        char *url = c + 5;
        while (*url == ' ') url++;
        if (!*url) {
            term_puts(w, t, "Использование: curl <url>");
            term_puts(w, t, "Пример: curl http://example.com/");
        } else {
            /* Парсим URL: http://host[:port]/path → host, port, path.
             * FIX [N1e]: слэш перед путём больше НЕ съедается — раньше
             * "http://host/" давала запрос "GET  HTTP/1.0" (без '/')
             * и серверы отвечали 400. Теперь как в браузере: путь целиком.
             * Поддержан порт: http://10.0.2.2:8080/ */
            char host[128];
            char path[256];
            u16 port = 80;
            const char *p = url;
            if (!strncmp(p, "http://", 7)) p += 7;
            int hi = 0;
            while (*p && *p != '/' && hi < 127) host[hi++] = *p++;
            host[hi] = 0;
            {
                char *colon = strchr(host, ':');
                if (colon) {
                    *colon = 0;
                    u32 pv = 0;
                    for (const char *q = colon + 1; *q; q++) {
                        if (*q < '0' || *q > '9') { pv = 0; break; }
                        pv = pv * 10 + (u32)(*q - '0');
                        if (pv > 65535) { pv = 0; break; }
                    }
                    if (pv == 0) {
                        term_puts(w, t, "Неверный порт в URL");
                        return;
                    }
                    port = (u16)pv;
                }
            }
            if (!*p) p = "/";
            strncpy(path, p, 255);
            path[255] = 0;

            /* СЕССИЯ 63: проверка сети — ПОСЛЕ парсинга хоста (раньше
             * стояла ДО него и блокировала даже 127.0.0.1/localhost:
             * loopback замыкается внутри стека без NIC и без IP). */
            if (!net_host_is_loopback(host) &&
                (!net_nic_present() || net_get_ip() == 0)) {
                term_puts(w, t, "Сеть не настроена");
                return;
            }
            if (!*path) strcpy(path, "/");

            term_puts(w, t, "Запрос...");
            /* FIX: было static char resp[4096] — общий на все терминалы */
            char *resp = (char *)malloc(4096);
            int n = resp ? net_http_get(host, port, path, resp, 4096, 10000) : -1;
            /* Сессия 58: авто-fallback на HTTPS (как в браузере).
             * Сессия 63: для loopback не повторяем — локальный httpd
             * говорит только по plain HTTP. */
            if (n <= 0 && resp && port != 443 && !net_host_is_loopback(host)) {
                const char *why0 = net_http_errstr();
                if (strncmp(why0, "connection", 10) == 0 ||
                    strncmp(why0, "connect timeout", 15) == 0) {
                    char line[96];
                    snprintf(line, sizeof(line), "HTTP: %s — пробую HTTPS...",
                             why0);
                    term_puts(w, t, line);
                    port = 443;
                    n = net_http_get(host, port, path, resp, 4096, 10000);
                }
            }
            if (n > 0) {
                char line[80];
                snprintf(line, sizeof(line), "Получено %d байт:", n);
                term_puts(w, t, line);
                {
                    /* отладка в serial: результат curl виден в логе QEMU */
                    extern void serial_puts(const char *s);
                    serial_puts("[curl] ");
                    serial_puts(host);
                    {
                        char b[32];
                        snprintf(b, sizeof(b), ":%u -> %d bytes\n",
                                 (unsigned)port, n);
                        serial_puts(b);
                    }
                }
                /* Открываем браузер с полученным контентом */
                app_browser_open_with(url, resp, n);
            } else {
                /* FIX [N1d]: показываем ПРИЧИНУ сбоя, а не безликий код */
                char line[96];
                snprintf(line, sizeof(line), "Ошибка запроса: %s",
                         net_http_errstr());
                term_puts(w, t, line);
            }
            if (resp) free(resp);
        }
    } else if (!strcmp(c, "c4test")) {
        /* Запустить встроенный тест c4 на стандартном примере */
        static const char *test_src =
            "#define MAX 5\n"
            "int twice(int x);\n"             /* прототип: вызов до определения */
            "int main() {\n"
            "    int i;\n"
            "    int sum = 0;\n"
            "    int arr[MAX];\n"              /* локальный массив */
            "    unsigned int u;\n"
            "    int d2;\n"
            "    for (i = 0; i < MAX; i = i + 1) {\n"
            "        arr[i] = i * i;\n"
            "        sum = sum + arr[i];\n"
            "    }\n"
            "    for (i = 0; i < MAX; i = i + 1) {\n"
            "        printf(\"arr[%d] = %d\\n\", i, arr[i]);\n"
            "    }\n"
            "    printf(\"sum = %d\\n\", sum);\n"
            "    u = 0x80000000; u >>= 28; sum >>= 1; sum += 1;\n"
            "    printf(\"shift: half+1=%d u28=%08x\\n\", sum, u);\n"
            "    d2 = 0;\n"
            "    for (i = 0, sum = 0; i < 3; i = i + 1, sum += i) d2 += 10;\n"  /* запятая */
            "    printf(\"comma: d2=%d sum=%d\\n\", d2, sum);\n"
            "    switch (sum) {\n"             /* switch + fallthrough + default */
            "    case 6: printf(\"switch: six\\n\"); break;\n"
            "    case 3: case 4: case 5:\n"
            "        printf(\"switch: 3-5\\n\"); break;\n"
            "    default: printf(\"switch: other %d\\n\", sum); break;\n"
            "    }\n"
            "    printf(\"twice(21) = %d\\ttab-ok\\n\", twice(21));\n"
            "    return 0;\n"
            "}\n"
            "int twice(int x) { return x + x; }\n";
        char out_buf[8192];
        out_buf[0] = 0;
        c4_gfx_set_name("c4test");
        int r = c4_run(test_src, out_buf, sizeof(out_buf));
        c4_gfx_detach();
        term_puts(w, t, "=== c4 test (arrays, for, #define, printf) ===");
        /* Разбиваем по строкам */
        char *p = out_buf;
        while (*p) {
            char *nl = p;
            while (*nl && *nl != '\n') nl++;
            int L = nl - p;
            L = utf8_clamp(p, L, TERM_MAX_COLS - 1);
            char line[TERM_MAX_COLS + 1];
            memcpy(line, p, L);
            line[L] = 0;
            term_puts(w, t, line);
            p = (*nl) ? nl + 1 : nl;
        }
        char sr[32];
        snprintf(sr, sizeof(sr), "exit code: %d", r);
        term_puts(w, t, sr);
    } else if (!strcmp(c, "c4gfx")) {
        /* Графический тест VM: полосы + текст через c4gfx-окно */
        static const char *gfx_src =
            "int main() {\n"
            "    kfill(20, 20, 200, 60, krgb(255, 0, 0));\n"
            "    kfill(20, 90, 200, 60, krgb(0, 200, 0));\n"
            "    kfill(20, 160, 200, 60, krgb(0, 80, 255));\n"
            "    ktext(30, 180, \"C4 GFX OK\", 0xFFFFFF, -1);\n"
            "    kflip();\n"
            "    printf(\"gfx done\\n\");\n"
            "    return 7;\n"
            "}\n";
        char out_buf[2048];
        out_buf[0] = 0;
        c4_gfx_set_name("c4gfx");
        int r = c4_run(gfx_src, out_buf, sizeof(out_buf));
        c4_gfx_detach();
        char sr[64];
        snprintf(sr, sizeof(sr), "c4gfx: exit code %d, %s", r,
                 out_buf[0] ? out_buf : "(без вывода)");
        term_puts(w, t, sr);
        term_puts(w, t, "  (окно C4: c4gfx показывает полосы; Esc — закрыть)");
    } else if (!strncmp(c, "cc ", 3)) {
        /* cc <name.c> — скомпилировать .c в .bin (native flat-binary) */
        char *p = c + 3;
        while (*p == ' ') p++;
        if (!*p) {
            term_puts(w, t, "Использование: cc <имя.c>");
        } else {
            char fname[64];
            int i = 0;
            while (*p && *p != ' ' && i < 63) fname[i++] = *p++;
            fname[i] = 0;
            /* Сессия 13: буфер УБРАН со стека — 8КБ в кадре term_exec
             * (вместе с ramtree:ents[128]) переполняли 16КБ-стек потока
             * и портили кучу (см. task.c).
             * [CC-BUF] (отчёт, баг 1): «терминал один — static безопасен»
             * — НЕВЕРНО: каждое окно терминала — своя задача, два окна
             * с одновременным cc A.c и cc B.c гонялись за один буфер
             * (T1 читал A.c, T2 перезаписывал содержимым B.c, T1
             * компилировал B.c как A.bin). Буфер — в куче, на вызов. */
            char *src_buf = (char *)malloc(8192);
            if (!src_buf) {
                term_puts(w, t, "Нет памяти");
            } else {
            u32 got = ramfs_read(fname, src_buf, 8192 - 1);
            if (got == 0) {
                term_puts(w, t, "Файл не найден (сначала Save в редакторе)");
            } else {
                src_buf[got] = 0;
                char diag[256];
                diag[0] = 0;
                int r = c4_compile_to_file(fname, src_buf, diag, sizeof(diag));
                if (r == 0 && diag[0]) {
                    extern void serial_puts(const char *s);
                    term_puts(w, t, diag);
                    serial_puts("[cc] ");
                    serial_puts(diag);
                    serial_puts("\n");
                } else if (r != 0) {
                    char line[300];
                    snprintf(line, sizeof(line), "Ошибка компиляции: %s",
                             diag[0] ? diag : "(нет деталей)");
                    term_puts(w, t, line);
                } else {
                    term_puts(w, t, "cc: неизвестная ошибка");
                }
            }
            free(src_buf);
            }
        }
    } else if (app_spawn_by_name(c)) {
        /* СЕССИЯ 82: help рекламировал «taskmgr sysinfo settings» как
         * команды, но финальный else знал только «spawn <имя>» —
         * «taskmgr» падал в «Неизвестная команда». Теперь имя
         * приложения работает напрямую (spawn <имя> тоже остался). */
        term_puts(w, t, "Приложение запущено");
    } else {
        term_puts(w, t, "Неизвестная команда. Введите help.");
    }
}

/* ============ [TCLIENT] итерация 7: telnet-клиент ============
 * Одна активная сессия на систему (как ping). Данные сокета приходят
 * в per-socket callback (контекст net_poll) → буфер vt_rx → дренаж
 * в term_tick/term_draw → VT-парсер → сетка. Клавиатура VT-режима
 * уходит хосту (vt_key). Завершение — Ctrl+] / Ctrl+Q, закрытие
 * удалённой стороной или RST. Состояние g_tel объявлено перед
 * term_exec (нужно ветке команды telnet). */

/* приём из сокета (контекст net_poll): в буфер терминала.
 * Переполнение — новые байты теряются (16 КиБ хватает на всплеск
 * вывода между кадрами отрисовки; дренаж идёт и в draw, и в tick). */
static void telnet_recv_cb(int sock, u32 src_ip, u16 src_port,
                           const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    term_t *t = g_tel.t;
    if (!t || !t->vt || sock != t->vt_sock || !data || len == 0) return;
    u32 f;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(f) :: "memory");
    for (u32 i = 0; i < len; i++) {
        if (t->vt_rx_n < VT_RX_SIZE)
            t->vt_rx[t->vt_rx_n++] = ((const char *)data)[i];
    }
    if (f & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* забрать кусок из приёмного буфера (критическая секция) */
static int telnet_rx_take(term_t *t, char *dst, int max)
{
    int n;
    u32 f;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(f) :: "memory");
    n = t->vt_rx_n;
    if (n > max) n = max;
    if (n > 0) {
        memcpy(dst, t->vt_rx, (u32)n);
        memmove(t->vt_rx, t->vt_rx + n, (u32)(t->vt_rx_n - n));
        t->vt_rx_n -= n;
    }
    if (f & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return n;
}

/* отправка в сокет с ожиданием ACK предыдущего сегмента (стек держит
 * один неотправленный сегмент — net_tcp_send_pending) */
static void telnet_send_raw(term_t *t, const char *buf, u32 n)
{
    if (t->vt_sock < 0) return;
    if (net_tcp_gen(t->vt_sock) != t->vt_gen) return;   /* слот потерян [GEN] */
    net_tcp_send(t->vt_sock, buf, n);
    int guard = 0;
    while (net_tcp_send_pending(t->vt_sock) && guard++ < 2000) {
        net_poll();
        task_yield();
    }
}

/* отправка с экранированием telnet-IAC (0xFF → FF FF) */
static void telnet_send_bytes(term_t *t, const void *data, u32 len)
{
    if (!t || !t->vt || t->vt_sock < 0) return;
    const unsigned char *p = (const unsigned char *)data;
    char out[600];
    u32 on = 0;
    for (u32 i = 0; i < len; i++) {
        if (on >= sizeof(out) - 2) { telnet_send_raw(t, out, on); on = 0; }
        out[on++] = (char)p[i];
        if (p[i] == 0xFF) out[on++] = (char)0xFF;
    }
    if (on) telnet_send_raw(t, out, on);
}

/* завершение сессии (сокет + VT-режим) */
static void telnet_finish(term_t *t, window_t *w, const char *why)
{
    if (g_tel.t == t) { g_tel.t = NULL; g_tel.w = NULL; }
    if (t->vt_sock >= 0) {
        net_tcp_unpin(t->vt_sock);
        net_tcp_close(t->vt_sock);
        t->vt_sock = -1;
    }
    vt_detach(t);
    if (why && *why) {
        char line[96];
        snprintf(line, sizeof(line), "telnet: %s", why);
        term_print(t, line);
    }
    term_touch(w);
}

/* опрос сокета из term_tick: закрытие + дренаж приёмного буфера */
static void vt_sock_poll(window_t *w, term_t *t)
{
    int s = t->vt_sock;
    if (s < 0) { telnet_finish(t, w, NULL); return; }
    if (net_tcp_was_reset(s)) {
        telnet_finish(t, w, "соединение сброшено (RST)");
        return;
    }
    tcp_state_t st = net_tcp_state(s);
    if (st == TCP_CLOSE_WAIT || st == TCP_LAST_ACK || st == TCP_CLOSED) {
        telnet_finish(t, w, "удалённая сторона закрыла соединение");
        return;
    }
    char tmp[1024];
    int n, got = 0;
    while ((n = telnet_rx_take(t, tmp, (int)sizeof(tmp))) > 0) {
        vt_feed(t, tmp, (u32)n);
        got += n;
        if (got > 32 * 1024) break;      /* за кадр — не больше */
    }
    if (got) win_invalidate(w);
}

/* клавиши VT-режима: уходят хосту */
static void vt_key(window_t *w, term_t *t, const key_event_t *ev)
{
    char b[8];
    int n = 0;
    if ((ev->flags & KF_CTRL) && (ev->ch == ']' || ev->ch == ']')) {
        telnet_finish(t, w, "отключено (Ctrl+])");
        return;
    }
    if ((ev->flags & KF_CTRL) && (ev->ch == 'q' || ev->ch == 'Q')) {
        telnet_finish(t, w, "отключено (Ctrl+Q)");
        return;
    }
    if (ev->flags & KF_CTRL) {
        char cc = (char)(ev->ch | 0x20);
        if (cc >= 'a' && cc <= 'z') { b[0] = (char)(cc - 'a' + 1); n = 1; }
        else if (ev->ch == ' ' || ev->ch == '@') { b[0] = 0; n = 1; }
        else if (ev->ch == '[')  { b[0] = 0x1B; n = 1; }
        else if (ev->ch == '\\') { b[0] = 0x1C; n = 1; }
        else if (ev->ch == '^')  { b[0] = 0x1E; n = 1; }
        else if (ev->ch == '_')  { b[0] = 0x1F; n = 1; }
        if (n) telnet_send_bytes(t, b, (u32)n);
        return;
    }
    switch (ev->code) {
    case KBD_UP:    memcpy(b, "\x1b[A", 3);  n = 3; break;
    case KBD_DOWN:  memcpy(b, "\x1b[B", 3);  n = 3; break;
    case KBD_RIGHT: memcpy(b, "\x1b[C", 3);  n = 3; break;
    case KBD_LEFT:  memcpy(b, "\x1b[D", 3);  n = 3; break;
    case 0x47:      memcpy(b, "\x1b[H", 3);  n = 3; break;   /* Home */
    case 0x4F:      memcpy(b, "\x1b[F", 3);  n = 3; break;   /* End */
    case 0x49:      memcpy(b, "\x1b[5~", 4); n = 4; break;   /* PgUp */
    case 0x51:      memcpy(b, "\x1b[6~", 4); n = 4; break;   /* PgDn */
    case 0x52:      memcpy(b, "\x1b[2~", 4); n = 4; break;   /* Ins */
    case 0x53:      memcpy(b, "\x1b[3~", 4); n = 4; break;   /* Del */
    case 0x3B:      memcpy(b, "\x1bOP", 3);  n = 3; break;   /* F1 */
    case 0x3C:      memcpy(b, "\x1bOQ", 3);  n = 3; break;   /* F2 */
    case 0x3D:      memcpy(b, "\x1bOR", 3);  n = 3; break;   /* F3 */
    case 0x3E:      memcpy(b, "\x1bOS", 3);  n = 3; break;   /* F4 */
    case 0x0F:      b[0] = '\t';  n = 1; break;              /* Tab */
    case 0x01:      b[0] = 0x1B;  n = 1; break;              /* Esc */
    case 0x1C:      b[0] = '\r';  n = 1; break;              /* Enter */
    case 0x0E:      b[0] = 0x7F;  n = 1; break;              /* Backspace */
    default:
        if (ev->ch == '\n')      { b[0] = '\r';  n = 1; }
        else if (ev->ch == '\b') { b[0] = 0x7F;  n = 1; }
        else if (ev->ch >= 32 && ev->ch < 127) { b[0] = ev->ch; n = 1; }
        break;
    }
    if (n) telnet_send_bytes(t, b, (u32)n);
}

/* отрисовка сетки (контекст term_draw). fg/bg конкретизируем ДО
 * инверсии (reverse), иначе путаются маркеры «тема» (30/40). */
static void vt_draw_screen(term_t *t, int cols, int rows)
{
    if (rows > VT_ROWS_MAX) rows = VT_ROWS_MAX;
    if (cols > VT_COLS_MAX) cols = VT_COLS_MAX;
    /* resize окна: сетка пересоздаётся, курсор домой */
    if (t->vt_lw != cols || t->vt_lh != rows) {
        vt_clear_all(t);
        t->vt_x = t->vt_y = 0;
        t->vt_lw = cols;
        t->vt_lh = rows;
    }
    for (int r = 0; r < rows; r++) {
        const char *row = t->gr[r];
        const unsigned char *at = t->ga[r];
        int y = 4 + r * 16;
        int x = 0, off = 0;
        while (row[off] && x < cols) {
            unsigned char a = at[off];
            char run[400];
            int rn = 0, runx = x;
            while (row[off] && x < cols && at[off] == a) {
                const char *p = row + off;
                (void)utf8_next(&p);
                int bl = (int)(p - (row + off));
                if (rn + bl >= (int)sizeof(run) - 1) break;
                memcpy(run + rn, row + off, (u32)bl);
                rn += bl;
                off += bl;
                x++;
            }
            run[rn] = 0;
            u32 fg = term_fg, bgc = term_bg;
            int have_bg = 0;
            if (a != VT_ATTR_DEF) {
                const struct vt_attr_s *ta = &t->vt_at_tab[a & 15];
                int f = ta->fg, bcol = ta->bg;
                if (ta->bold && f < 8) f += 8;
                fg = (f != 30)
                     ? fb_rgb((int)((vt_pal16[f] >> 16) & 0xFF),
                              (int)((vt_pal16[f] >> 8) & 0xFF),
                              (int)(vt_pal16[f] & 0xFF))
                     : term_fg;
                if (bcol != 40) {
                    bgc = fb_rgb((int)((vt_pal16[bcol] >> 16) & 0xFF),
                                 (int)((vt_pal16[bcol] >> 8) & 0xFF),
                                 (int)(vt_pal16[bcol] & 0xFF));
                    have_bg = 1;
                } else
                    bgc = term_bg;
                if (ta->rev) {
                    u32 tmp2 = fg;
                    fg = bgc;
                    bgc = tmp2;
                    have_bg = 1;
                }
            }
            /* fb_text заливает фон только внутри строк глифа — для
             * цветных ячеек заливаем ячейки целиком */
            if (have_bg)
                fb_fill_rect(4 + runx * 8, y, rn * 8, 16, bgc);
            fb_text(4 + runx * 8, y, run, fg, -1);
        }
    }
    /* курсор-блок */
    if (t->vt_curvis && wm_blink() && t->vt_x < cols && t->vt_y < rows) {
        int cx = 4 + t->vt_x * 8, cy = 4 + t->vt_y * 16;
        fb_fill_rect(cx, cy, 8, 16, term_fg);
        const char *row = t->gr[t->vt_y];
        int off = vt_col_off(row, t->vt_x);
        if (row[off]) {
            char cb[8];
            const char *p = row + off;
            (void)utf8_next(&p);
            int bl = (int)(p - (row + off));
            if (bl > 7) bl = 7;
            memcpy(cb, row + off, (u32)bl);
            cb[bl] = 0;
            fb_text(cx, cy, cb, term_bg, -1);
        }
    }
}

/* соединение и вход в VT-режим (контекст term_exec — задача окна) */
static void telnet_start(window_t *w, term_t *t, const char *host, int port)
{
    char line[96];
    u32 ip = 0;
    if (!net_dns_resolve(host, &ip, 5000)) {
        snprintf(line, sizeof(line), "telnet: не удалось разрешить \"%s\"", host);
        term_puts(w, t, line);
        return;
    }
    int sock = net_tcp_connect(ip, (u16)port, 40001);
    if (sock < 0) {
        term_puts(w, t, "telnet: нет свободных TCP-сокетов");
        return;
    }
    net_tcp_pin(sock);                       /* [PIN]: слот закреплён за нами */
    net_tcp_set_sock_callback(sock, telnet_recv_cb);
    snprintf(line, sizeof(line), "telnet: соединение с %s:%d ...", host, port);
    term_puts(w, t, line);
    u32 t0 = timer_ticks();
    while (net_tcp_state(sock) == TCP_SYN_SENT &&
           (timer_ticks() - t0) < 8000) {
        net_tcp_kick(sock);                  /* повтор SYN при рассинхроне ARP */
        net_wait_poll(50);
    }
    if (net_tcp_state(sock) != TCP_ESTABLISHED) {
        net_tcp_unpin(sock);
        net_tcp_close(sock);
        term_puts(w, t, "telnet: подключиться не удалось (таймаут или отказ)");
        return;
    }
    g_tel.t = t;
    g_tel.w = w;
    t->vt = 1;
    t->vt_sock = sock;
    t->vt_gen = net_tcp_gen(sock);           /* [GEN] */
    t->vt_rx_n = 0;
    t->vt_x = t->vt_y = 0;
    t->vt_curvis = 1;
    t->vt_pst = 0;
    t->vt_utf_n = 0;
    t->vt_alt = 0;
    t->vt_lw = t->vt_lh = 0;
    vt_attr_reset(t);
    vt_clear_all(t);
    t->scrollback = 0;
    snprintf(line, sizeof(line),
             "telnet: подключено к %s:%d. Ctrl+] / Ctrl+Q — отключение.",
             host, port);
    term_print(t, line);                     /* в строковую историю, не в сетку */
    term_touch(w);
}

/* ---- [TERM-SINK] headless-терминал для telnet-сервера (telnetd.c) ----
 * Полноценный term_t без окна: term_print уводит вывод в sink, ввод —
 * term_shell_exec (та же таблица команд, что в локальном терминале). */
term_t *term_headless_create(void)
{
    term_t *t = (term_t *)malloc(sizeof(term_t));
    if (!t) return NULL;
    memset(t, 0, sizeof(term_t));
    t->cols = TERM_INIT_COLS;
    t->rows = TERM_INIT_ROWS;
    t->vt_sock = -1;
    t->vt_curvis = 1;
    t->vt_at_rr = -1;
    return t;
}

void term_headless_free(term_t *t)
{
    if (t) free(t);
}

void term_headless_sink(term_t *t, void (*put)(void *, const char *), void *ctx)
{
    if (!t) return;
    t->sink_put = put;
    t->sink_ctx = ctx;
}

/* исполнить строку как команду (без окна; вывод — в sink) */
void term_shell_exec(term_t *t, const char *line)
{
    if (!t || !line) return;
    strncpy(t->input, line, TERM_MAX_COLS);
    t->input[TERM_MAX_COLS] = 0;
    t->ilen = (int)strlen(t->input);
    term_exec(NULL, t);
}

static void term_draw(window_t *w)
{
    term_t *t = (term_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    /* СЕССИЯ 15: цвета берём из темы ПРИ КАЖДОЙ отрисовке — смена темы
     * применяется и к УЖЕ ОТКРЫТЫМ терминалам (term_bg/term_fg — лишь
     * значения по умолчанию при создании). */
    term_bg = wm_theme_win_bg();
    term_fg = wm_theme_text();
    term_prompt = wm_theme_accent();
    fb_fill_rect(0, 0, cw, ch, term_bg);

    /* ---- СЕССИЯ 7: геометрия по фактическому РАЗМЕРУ ОКНА ----
     * (раньше — всегда 62×17). 8x16 px на символ. */
    int cols = (cw - 8) / 8;
    int rows = (ch - 8) / 16;
    if (cols < 16) cols = 16;
    if (cols > 96) cols = 96;         /* больше 96 колонок не отрисовываем */
    if (rows < 2) rows = 2;
    if (rows > 48) rows = 48;
    t->cols = cols;
    t->rows = rows;

    /* QuickJS REPL: забираем готовый вывод ДО выборки видимых строк,
     * чтобы новые строки появились в этом же кадре (задача eval будит
     * нас invalidate'ом). */
    term_repl_tick(t);

    /* [TERM-VT] telnet-сессия: рисуем сетку вместо строкового режима.
     * Дренаж приёмного буфера здесь же — отрисовка кадра чаще тика. */
    if (t->vt) {
        vt_sock_poll(w, t);
        vt_draw_screen(t, cols, rows);
        return;
    }

    int visible = rows - 1;           /* последняя строка — ввод */

    /* Каждая хранимая строка разбивается по cols СИМВОЛОВ (UTF-8) —
     * «визуальные» строки. Собираем видимое окно с конца: пропускаем
     * scrollback визуальных строк, берём visible штук. */
    typedef struct { const char *p; u32 len; } vseg_t;
    vseg_t segs[48];
    int nsegs = 0;

    int skip = t->scrollback;         /* сколько визуальных строк с конца пропустить */
    int need = visible;               /* сколько нужно набрать */
    for (int i = t->nlines - 1; i >= 0 && need > 0; i--) {
        const char *ln = t->lines[i];
        u32 blen = (u32)strlen(ln);
        /* сколько визуальных сегментов в этой строке */
        int k = 1;
        if (blen > 0) {
            /* быстрый путь: если весь кусок влезает в cols символов */
            u32 fast = utf8_take(ln, cols);
            if (fast < blen) {
                k = 0;
                u32 off = 0;
                while (off < blen && k < 64) {
                    off += utf8_take(ln + off, cols);
                    k++;
                }
                if (k < 1) k = 1;
            }
        }
        if (skip >= k) { skip -= k; continue; }
        /* берём последние (k - skip) сегментов строки, но не больше need */
        int take = k - skip;
        if (take > need) take = need;
        /* сегменты с индексами [k - skip - take .. k - skip - 1] */
        for (int j = k - skip - take; j < k - skip; j++) {
            u32 off = 0;
            for (int q = 0; q < j; q++)
                off += utf8_take(ln + off, cols);
            u32 slen = utf8_take(ln + off, cols);
            segs[nsegs].p = ln + off;
            segs[nsegs].len = slen;
            nsegs++;
            need--;
        }
        skip = 0;
    }
    /* сегменты идут «снизу вверх» — разворачиваем при выводе.
     * Классическая раскладка терминала: текст растёт СВЕРХУ ВНИЗ;
     * пока строк меньше высоты окна — ввод идёт сразу за текстом. */
    int y = 4;
    char segbuf[TERM_MAX_COLS + 1];
    for (int i = nsegs - 1; i >= 0; i--, y += 16) {
        u32 slen = segs[i].len;
        if (slen > TERM_MAX_COLS) slen = TERM_MAX_COLS;
        memcpy(segbuf, segs[i].p, slen);
        segbuf[slen] = 0;
        fb_text(4, y, segbuf, term_fg, -1);
    }

    /* строка ввода с курсором (REPL: приглашение "js> " / "... ") */
    const char *pfx = t->repl ? (mqjs_repl_pending() ? "... " : "js> ") : "> ";
    int pfx_len = (int)strlen(pfx);
    fb_text(4, y, pfx, term_prompt, -1);
    fb_text(4 + pfx_len * 8, y, t->input, term_fg, -1);
    if (wm_blink()) {
        int cx = 4 + pfx_len * 8 + t->ilen * 8;
        if (cx > cw - 12) cx = cw - 12;
        fb_fill_rect(cx, y, 8, 16, term_fg);
    }

    /* Индикатор прокрутки: если scrollback > 0, показать "↑N" в правом-верхнем углу */
    if (t->scrollback > 0) {
        char buf[16];
        snprintf(buf, sizeof(buf), "^%d", t->scrollback);
        fb_text(cw - 4 - (int)strlen(buf) * 8, 2, buf,
                fb_rgb(0xFF, 0xE0, 0x60), -1);
    } else if (t->nlines > 1) {
        /* Внизу есть ещё строки */
        fb_text(cw - 16, 2, "v",
                wm_theme_text_dim(), -1);
    }
}

static void term_key(window_t *w, const key_event_t *ev)
{
    term_t *t = (term_t *)w->data;
    if (ev->flags & KF_RELEASED) return;

    /* [TERM-VT] telnet-сессия: клавиши — хосту, прокрутки нет */
    if (t->vt) {
        vt_key(w, t, ev);
        return;
    }

    int page = (t->rows > 1 ? t->rows : TERM_INIT_ROWS) - 1;
    if (page < 1) page = 1;

    /* PgUp/PgDn для прокрутки истории (страница = текущая высота окна) */
    if (ev->code == 0x49) {  /* PgUp */
        t->scrollback += page;
        if (t->scrollback > TERM_SCROLL_LINES) t->scrollback = TERM_SCROLL_LINES;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x51) {  /* PgDn */
        t->scrollback -= page;
        if (t->scrollback < 0) t->scrollback = 0;
        win_invalidate(w);
        return;
    }
    /* Стрелки вверх/вниз — одиночная прокрутка */
    if (ev->code == KBD_UP) {
        t->scrollback++;
        if (t->scrollback > TERM_SCROLL_LINES) t->scrollback = TERM_SCROLL_LINES;
        win_invalidate(w);
        return;
    }
    if (ev->code == KBD_DOWN) {
        if (t->scrollback > 0) t->scrollback--;
        win_invalidate(w);
        return;
    }
    /* Home — к началу истории, End — к концу (хвосту) */
    if (ev->code == 0x47) {  /* Home */
        t->scrollback = TERM_SCROLL_LINES;
        win_invalidate(w);
        return;
    }
    if (ev->code == 0x4F) {  /* End */
        t->scrollback = 0;
        win_invalidate(w);
        return;
    }

    /* Ctrl+C в режиме REPL: прервать выполняющуюся строку / выйти */
    if (t->repl && (ev->flags & KF_CTRL) && (ev->ch == 'c' || ev->ch == 'C')) {
        if (mqjs_repl_busy()) {
            mqjs_repl_abort();
            term_puts(w, t, "^Cпрерывание...");
        } else if (mqjs_repl_pending()) {
            mqjs_repl_reset_input();
            term_puts(w, t, "^Cввод сброшен");
        } else {
            mqjs_repl_stop();
            t->repl = 0;
            term_puts(w, t, "REPL завершён.");
        }
        win_invalidate(w);
        return;
    }

    if (ev->code == 0x1C || ev->ch == '\n') {
        /* Enter: строка тоже попадает в историю */
        char line[TERM_MAX_COLS + 8];
        snprintf(line, sizeof(line), "%s %s", t->repl ? "js>" : ">", t->input);
        term_print(t, line);
        term_exec(w, t);
        term_touch(w);
        return;
    }
    if (ev->ch == '\b' || ev->code == 0x0E) {
        if (t->ilen > 0) t->input[--t->ilen] = 0;
        term_touch(w);
        return;
    }
    if (ev->ch >= 32 && ev->ch < 127) {
        /* лимит — ширина окна минус приглашение ("> " / "js> ") */
        int max_in = (t->cols > 0 ? t->cols : TERM_INIT_COLS)
                     - (t->repl ? 4 : 2);
        if (max_in > TERM_MAX_COLS) max_in = TERM_MAX_COLS;
        if (t->ilen < max_in) {
            t->input[t->ilen++] = ev->ch;
            t->input[t->ilen] = 0;
        }
        term_touch(w);
        return;
    }
    /* Стрелки вверх/вниз уже обработаны выше для прокрутки истории */
}

/* ---------- AUTORUN.TXT: сценарий автозапуска терминала ----------
 * Сессия 13. Если в RAM disk есть файл AUTORUN.TXT, терминал исполняет
 * его построчно: одна команда каждые 3 тика (1.5 с), строки с '#' и
 * пустые — пропускаются. Назначение: автоматические тесты в эмуляторах
 * без ввода с клавиатуры (Bochs не умеет посылать клавиши, PS/2-мышь
 * в QEMU нестабильна) и удобство пользователя (автозапуск команд).
 * Исполняет ПЕРВЫЙ терминал (окно фиксируется при первой подаче). */
typedef struct {
    window_t *win;      /* терминал-исполнитель (NULL = не начато) */
    char     *buf;      /* содержимое файла (malloc) */
    u32       pos;      /* позиция чтения в buf */
    int       wait;     /* тиков до следующей строки */
    char      line[TERM_MAX_COLS + 1];
} autorun_t;
static autorun_t g_autorun;

static void autorun_tick(window_t *w, term_t *t)
{
    /* Ленивая инициализация: первый тик любого терминала читает файл. */
    if (!g_autorun.win && !g_autorun.buf) {
        static char file[2048];
        /* сидинг из ISO кладёт имена в lowercase — пробуем оба варианта */
        u32 got = ramfs_read("AUTORUN.TXT", file, sizeof(file) - 1);
        if (got == 0)
            got = ramfs_read("autorun.txt", file, sizeof(file) - 1);
        if (got == 0) {
            /* нет файла — включаем «нет сценария»: buf="" (не NULL) */
            g_autorun.buf = (char *)malloc(1);
            if (g_autorun.buf) g_autorun.buf[0] = 0;
            return;
        }
        file[got] = 0;
        g_autorun.buf = (char *)malloc(got + 1);
        if (!g_autorun.buf) { g_autorun.buf = (char *)1; return; /* ="" */ }
        memcpy(g_autorun.buf, file, got + 1);
        g_autorun.win = w;   /* этот терминал исполняет сценарий */
        g_autorun.pos = 0;
        g_autorun.wait = 6; /* 3 с на подготовку после загрузки */
        term_puts(w, t, "[autorun] найден AUTORUN.TXT — исполнение...");
        serial_puts("[autorun] сценарий найден, исполнение\n");
    }
    if (w != g_autorun.win || !g_autorun.buf) return;
    if (g_autorun.buf == (char *)1) return;   /* сценарий пуст/ошибка */

    if (g_autorun.wait > 0) { g_autorun.wait--; return; }
    g_autorun.wait = 3;   /* 1.5 с между командами */

    /* Читаем следующую строку */
    char *b = g_autorun.buf;
    u32 n = 0;
    while (b[g_autorun.pos] && b[g_autorun.pos] != '\n' &&
           n < TERM_MAX_COLS)
        g_autorun.line[n++] = b[g_autorun.pos++];
    if (b[g_autorun.pos] == '\n') g_autorun.pos++;
    g_autorun.line[n] = 0;

    /* Конец файла */
    if (n == 0 && !b[g_autorun.pos]) {
        term_puts(w, t, "[autorun] сценарий завершён");
        free(g_autorun.buf);
        g_autorun.buf = (char *)1;
        return;
    }
    /* Пропуск пустых строк и комментариев */
    {
        int i = 0;
        while (g_autorun.line[i] == ' ' || g_autorun.line[i] == '\t') i++;
        if (!g_autorun.line[i] || g_autorun.line[i] == '#' ||
            g_autorun.line[i] == '\r')
            return;
    }
    /* Эхо + исполнение как будто введено с клавиатуры */
    {
        char echo[TERM_MAX_COLS + 4];
        snprintf(echo, sizeof(echo), "> %s", g_autorun.line);
        term_print(t, echo);
        serial_puts("[autorun] > ");
        serial_puts(g_autorun.line);
        serial_puts("\n");
        strcpy(t->input, g_autorun.line);
        t->ilen = (int)strlen(g_autorun.line);
        term_exec(w, t);
        term_touch(w);
    }
}

static void term_tick(window_t *w)
{
    win_invalidate(w); /* перерисовка ради мигания курсора */

    autorun_tick(w, (term_t *)w->data);

    /* [TERM-VT] telnet: статус сокета + дренаж приёма (500 мс тик —
     * основной дренаж идёт в term_draw на каждом кадре) */
    if (((term_t *)w->data)->vt) {
        vt_sock_poll(w, (term_t *)w->data);
        return;
    }

    /* Двигаем сессию ping. term_tick вызывается 2 раза в секунду
     * (из wm_halfsec), т.е. каждые 500 мс. */
    if (!g_ping.active || g_ping.win != w) return;

    /* Если есть ответ — выведем его */
    if (g_ping.have_reply) {
        char line[80];
        char ipbuf[16];
        net_ntoa(g_ping.target_ip, ipbuf, sizeof(ipbuf));
        snprintf(line, sizeof(line), "  reply from %s: seq=%u  time=%u ms  bytes=32",
                 ipbuf, (unsigned)g_ping.reply_seq, (unsigned)g_ping.reply_rtt_ms);
        term_puts(g_ping.win, g_ping.term, line);
        g_ping.have_reply = 0;
        /* Перейдём к следующему пакету, если ещё не все отправлены */
        if (g_ping.sent >= (u32)g_ping.max_count) {
            goto ping_end;
        }
        goto send_next;
    }

    /* Проверим таймаут */
    {
        u32 now = timer_ticks();
        u32 elapsed_ms = now - g_ping.last_send_tick;   /* 1 тик = 1 мс (сессия 33) */
        if (g_ping.last_send_tick != 0 && elapsed_ms > g_ping.timeout_ms) {
            char line[80];
            char ipbuf[16];
            net_ntoa(g_ping.target_ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "  timeout: seq=%u (no reply in %u ms)",
                     g_ping.next_seq - 1, (unsigned)g_ping.timeout_ms);
            term_puts(g_ping.win, g_ping.term, line);
            if (g_ping.sent >= (u32)g_ping.max_count) {
                goto ping_end;
            }
            goto send_next;
        }
    }
    return;

send_next:
    if (g_ping.sent >= (u32)g_ping.max_count) {
        goto ping_end;
    }
    {
        /* Отправляем ICMP Echo Request с уникальным seq */
        u16 seq = g_ping.next_seq++;
        u32 t_send = timer_ticks();
        g_ping.last_send_tick = t_send;
        g_ping.sent++;
        g_ping.have_reply = 0;
        /* Payload — 32 байта */
        u8 payload[32];
        memset(payload, 0xAA, 32);
        net_send_icmp_echo(g_ping.target_ip, 0x1234, seq, payload, 32);
    }
    return;

ping_end:
    {
        char sum[64];
        u32 loss = (g_ping.sent > g_ping.recv) ? (g_ping.sent - g_ping.recv) : 0;
        u32 pct = (g_ping.sent > 0) ? loss * 100 / g_ping.sent : 0;
        snprintf(sum, sizeof(sum), "--- %u sent, %u recv, %u%% loss ---",
                 (unsigned)g_ping.sent, (unsigned)g_ping.recv, (unsigned)pct);
        term_puts(g_ping.win, g_ping.term, sum);
        g_ping.active = 0;
    }
}

/* [PING-OWN] (отчёт, баг 2): окно-владелец ping закрылось — сессию
 * погасить, иначе она навсегда остаётся active (term_tick мёртвого
 * окна не вызывается) и блокирует все новые ping. Данные term_t
 * освобождает сам WM (wm.c: free(w->data)) — здесь только ping. */
static void term_close(window_t *w)
{
    if (g_ping.active && g_ping.win == w)
        g_ping.active = 0;
    /* [TCLIENT] telnet-сессия этого окна — закрыть сокет (данные term_t
     * освобождает WM) */
    if (g_tel.t == (term_t *)w->data)
        telnet_finish((term_t *)w->data, NULL, NULL);
}

void app_term_open(void)
{
    term_t *t = (term_t *)malloc(sizeof(term_t));
    if (!t) return;
    memset(t, 0, sizeof(term_t));
    t->cols = TERM_INIT_COLS;    /* стартовая геометрия; при resize — по окну */
    t->rows = TERM_INIT_ROWS;
    t->vt_sock = -1;             /* [TERM-VT] telnet-сессии нет */
    t->vt_curvis = 1;
    t->vt_at_rr = -1;
    term_bg = wm_theme_win_bg();
    term_fg = wm_theme_text();
    term_prompt = wm_theme_accent();

    term_print(t, "N2600-OS 0.1 - терминал");
    term_print(t, "Введите help для списка команд.");
    term_print(t, "");

    int ww = TERM_INIT_COLS * 8 + 10;
    int wh = TERM_INIT_ROWS * 16 + 8 + TITLE_H + 2;
    int x = 20;
    int y = 16;
    win_create("Терминал", x, y, ww, wh, term_draw, term_key, NULL, term_tick, term_close, t);
}

/* ========================= СИСТЕМНАЯ ИНФОРМАЦИЯ ========================= */
#define SI_LINES 64    /* сессия 90: +DMI/ACPI/устройства/кэш/TSC */
#define SI_LINE_W 60

typedef struct {
    char lines[SI_LINES][SI_LINE_W];
    u32  colors[SI_LINES];
    int  scroll;
    wm_scrollbar_t sb;         /* общий виджет полосы прокрутки */
    /* сессия 57: тесты по кнопкам (CPU-скорость, звук) */
    char cpu_res[SI_LINE_W];   /* результат бенчмарка */
    char snd_res[SI_LINE_W];   /* результат звукового теста */
    int  busy;                 /* 1 = тест выполняется */
} sysinfo_t;

static const u32 C_LABEL = 0, C_VALUE = 1, C_ACCENT = 2;

static void si_put(sysinfo_t *d, int row, const char *s, u32 which)
{
    if (row < 0 || row >= SI_LINES) return;
    strncpy(d->lines[row], s, SI_LINE_W - 1);
    d->lines[row][SI_LINE_W - 1] = 0;
    d->colors[row] = which;
}

static void si_draw(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x12, 0x15, 0x19));
    fb_fill_rect(0, 0, cw, 2, fb_rgb(0x3E, 0x7D, 0xBF));

    u32 col_label = wm_theme_text_dim();
    u32 col_value = wm_theme_text();
    u32 col_accent = wm_theme_accent();
    u32 col_warn = fb_rgb(0xFF, 0xE0, 0x60);

    /* сессия 57: нижняя панель кнопок — фиксированная, не скроллится */
    int btn_h = 20;
    int list_h = ch - btn_h - 8;

    int vis = list_h / 18;
    if (vis < 1) vis = 1;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;
    if (d->scroll > max_scroll) d->scroll = max_scroll;
    if (d->scroll < 0) d->scroll = 0;

    int start = d->scroll;
    int end = start + vis;
    if (end > SI_LINES) end = SI_LINES;

    /* Полоса прокрутки — общий виджет wm_scrollbar (цвет из темы).
     * ПОРЯДОК ПОНЯТЕН (ФИКС сессии 17): pos=0 — верх списка
     * (раньше формула была инвертирована — ползунок ехал наоборот). */
    wm_scrollbar_draw(&d->sb, cw - 7, 4, 5, list_h - 4, d->scroll,
                      max_scroll, vis);

    int text_w = cw - 12;  /* оставляем место под скроллбар */
    int y = 12;
    for (int i = start; i < end; i++, y += 18) {
        u32 c;
        if (d->colors[i] == C_LABEL) c = col_label;
        else if (d->colors[i] == C_VALUE) c = col_value;
        else if (d->colors[i] == C_ACCENT) c = col_accent;
        else c = col_warn;
        fb_text(10, y, d->lines[i], c, -1);
        (void)text_w;
    }

    /* --- кнопки тестов (сессия 57) --- */
    int by = ch - btn_h - 4;
    fb_hline(0, cw - 1, by - 4, fb_rgb(0x2C, 0x31, 0x38));
    int busy = d->busy;
    /* [Тест CPU] */
    fb_fill_rect(8, by, 92, btn_h, busy ? fb_rgb(0x1E, 0x26, 0x30)
                                        : fb_rgb(0x24, 0x30, 0x40));
    fb_rect(8, by, 92, btn_h, col_accent);
    fb_text(18, by + 5, busy ? "Измеряю..." : "Тест CPU",
            busy ? col_label : col_value, -1);
    /* [Тест звука] */
    fb_fill_rect(106, by, 104, btn_h, busy ? fb_rgb(0x1E, 0x26, 0x30)
                                           : fb_rgb(0x24, 0x30, 0x40));
    fb_rect(106, by, 104, btn_h, col_accent);
    fb_text(116, by + 5, busy ? "Играю..." : "Тест звука",
            busy ? col_label : col_value, -1);
    /* результаты справа/на строке выше кнопок */
    if (d->cpu_res[0])
        fb_text(220, by, d->cpu_res, col_accent, -1);
    if (d->snd_res[0])
        fb_text(220, by + 10, d->snd_res, col_accent, -1);
}

static void si_key(window_t *w, const key_event_t *ev)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    int chh = win_content_h(w);
    int list_h = chh - 20 - 8;
    int vis = list_h / 18;
    if (vis < 1) vis = 1;
    int max_scroll = SI_LINES - vis;
    if (max_scroll < 0) max_scroll = 0;

    /* ФИКС сессии 17: scroll — первая видимая строка. Раньше PgUp
     * увеличивал его (листало ВНИЗ), Home/End вели себя наоборот. */
    if (ev->code == 0x49 || ev->code == KBD_UP) {  /* PgUp / вверх */
        d->scroll--;
        if (d->scroll < 0) d->scroll = 0;
        win_invalidate(w);
    }
    else if (ev->code == 0x51 || ev->code == KBD_DOWN) {  /* PgDn / вниз */
        d->scroll += vis;
        if (d->scroll > max_scroll) d->scroll = max_scroll;
        win_invalidate(w);
    }
}

static u32 si_bench_mips(u32 ms);   /* fwd: определения после si_tick */
static u32 si_bench_mem(u32 ms);

static void si_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    int cw = win_content_w(w), chh = win_content_h(w);

    /* --- сессия 57: кнопки тестов --- */
    int by = chh - 20 - 4;
    if (mx >= 0 && my >= by) {
        if ((changed & MSB_LEFT) && !d->busy) {
            if (wm_button_hit(mx, my, 8, by, 92, 20)) {
                d->busy = 1;
                snprintf(d->cpu_res, sizeof(d->cpu_res), "CPU: считаю...");
                win_invalidate(w);
                u32 mips = si_bench_mips(500);
                u32 mbps = si_bench_mem(400);
                snprintf(d->cpu_res, sizeof(d->cpu_res),
                         "CPU: %u.%02u MIPS, mem %u МБ/с",
                         mips / 1000, (mips % 1000) / 10, mbps);
                d->busy = 0;
                win_invalidate(w);
                return;
            }
            if (wm_button_hit(mx, my, 106, by, 104, 20)) {
                d->busy = 1;
                snprintf(d->snd_res, sizeof(d->snd_res), "Звук: играю...");
                win_invalidate(w);
                if (!sound_present()) {
                    snprintf(d->snd_res, sizeof(d->snd_res),
                             "Звук: %s", sound_last_error());
                } else {
                    int rc = sound_test_melody();
                    snprintf(d->snd_res, sizeof(d->snd_res),
                             rc == 0 ? "Звук: ок — %s" : "Звук: ошибка — %s",
                             sound_device_name());
                }
                d->busy = 0;
                win_invalidate(w);
                return;
            }
        }
        return;   /* ниже кнопок список не скроллится */
    }

    if (mx < 0 || my < 0) {
        /* сессия 20 (захват мыши): отпускание за пределами окна — полосе */
        if (d->sb.dragging)
            wm_scrollbar_mouse(&d->sb, mx, my, btn, changed);
        return;
    }
    if (mx >= cw - 9 || d->sb.dragging) {
        int np = wm_scrollbar_mouse(&d->sb, mx, my, btn, changed);
        if (np >= 0) { d->scroll = np; win_invalidate(w); }
    }
}

/* сессия 57: компактный бенчмарк CPU (ЦЕЛОЧИСЛЕННЫЙ — x87 не
 * сохраняется между задачами). MIPS через LCG-конвейер
 * (умножение+сложение+xor — типичная целочисленная нагрузка)
 * и memcpy-пропускная способность памяти (МБ/с). */
static u32 si_bench_mips(u32 ms)
{
    u32 t0 = timer_ticks();
    u32 iters = 0;
    volatile u32 x = 0x12345678u;
    while ((u32)(timer_ticks() - t0) < ms) {
        for (int i = 0; i < 20000; i++) {
            x = x * 1664525u + 1013904223u;
            x ^= x >> 13;
        }
        iters += 20000;
    }
    u32 dt = timer_ticks() - t0;
    if (dt == 0) dt = 1;
    return iters / dt;        /* кило-итераций/мс ≈ млн оп/с */
}

static u32 si_bench_mem(u32 ms)
{
    enum { N = 128 * 1024 };
    static u8 *a = 0, *b = 0;
    if (!a) { a = (u8 *)malloc(N); b = (u8 *)malloc(N); }
    if (!a || !b) return 0;
    for (int i = 0; i < N; i++) a[i] = (u8)i;
    u32 t0 = timer_ticks();
    u32 copies = 0;
    while ((u32)(timer_ticks() - t0) < ms) {
        memcpy(b, a, N);
        copies++;
    }
    u32 dt = timer_ticks() - t0;
    if (dt == 0) dt = 1;
    return (u32)(((u64)copies * (u64)N) / (u64)dt / 1024);  /* МБ/с */
}

static void si_tick(window_t *w)
{
    sysinfo_t *d = (sysinfo_t *)w->data;
    u32 up = uptime_sec();
    char line[SI_LINE_W];
    snprintf(line, sizeof(line), "Uptime: %02u:%02u:%02u  Tasks: %d  Heap: %uK/%uK",
             up / 3600, (up / 60) % 60, up % 60,
             task_count(),
             (unsigned)(mem_used() / 1024),
             (unsigned)(mem_heap_size() / 1024));
    strncpy(d->lines[SI_LINES - 1], line, SI_LINE_W - 1);
    win_invalidate(w);
}

void app_sysinfo_open(void)
{
    sysinfo_t *d = (sysinfo_t *)malloc(sizeof(sysinfo_t));
    if (!d) return;
    memset(d, 0, sizeof(sysinfo_t));

    char brand[52], vend[16], line[SI_LINE_W];
    cpu_get_brand(brand);
    cpu_get_vendor(vend);

    int r = 0;
    si_put(d, r++, "=== N2600-OS 0.1 ===", C_ACCENT);
    si_put(d, r++, "", C_VALUE);

    /* Система (SMBIOS/DMI) — сессия 90, по мотивам hwdet */
    si_put(d, r++, "--- Система (SMBIOS) ---", C_LABEL);
    if (hwinfo_dmi_bios()[0] || hwinfo_dmi_system()[0]) {
        if (hwinfo_dmi_bios()[0]) {
            snprintf(line, sizeof(line), "BIOS: %s", hwinfo_dmi_bios());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_system()[0]) {
            snprintf(line, sizeof(line), "Система: %s", hwinfo_dmi_system());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_board()[0]) {
            snprintf(line, sizeof(line), "Плата: %s", hwinfo_dmi_board());
            si_put(d, r++, line, C_VALUE);
        }
        if (hwinfo_dmi_cpu()[0]) {
            snprintf(line, sizeof(line), "Сокет: %s", hwinfo_dmi_cpu());
            si_put(d, r++, line, C_VALUE);
        }
    } else {
        si_put(d, r++, "SMBIOS не найден", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* CPU */
    si_put(d, r++, "--- CPU ---", C_LABEL);
    snprintf(line, sizeof(line), "Brand: %s", brand);
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Vendor: %s, лог. ЦП: %d (%d онлайн)",
             vend, smp_cpu_count(), smp_online_count());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Топология: %d %s / %d %s на ядро",
             smp_topo_cores(),
             (smp_topo_cores() % 10 == 1 && smp_topo_cores() % 100 != 11) ? "ядро" : "ядра",
             smp_topo_threads(),
             (smp_topo_threads() % 10 == 1 && smp_topo_threads() % 100 != 11) ? "поток" : "потока");
    si_put(d, r++, line, C_VALUE);
    /* сессия 90: частота TSC (калибровка по PIT) + кэш + фичи */
    {
        unsigned mhz = hwinfo_tsc_mhz();
        if (mhz) {
            snprintf(line, sizeof(line), "TSC: ~%u МГц", mhz);
            si_put(d, r++, line, C_VALUE);
        }
        char cb[48];
        hwinfo_cpu_cache(cb, sizeof(cb));
        snprintf(line, sizeof(line), "Кэш: %s", cb);
        si_put(d, r++, line, C_VALUE);
        char fb[56];
        hwinfo_cpu_features(fb, sizeof(fb));
        snprintf(line, sizeof(line), "Фичи: %s", fb);
        si_put(d, r++, line, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Memory */
    si_put(d, r++, "--- Memory ---", C_LABEL);
    snprintf(line, sizeof(line), "RAM: %u MiB", (unsigned)mem_ram_mib());
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "Heap: %u / %u KiB used",
             (unsigned)(mem_used() / 1024), (unsigned)(mem_heap_size() / 1024));
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* ACPI (сессия 90: hwdet-подобный разбор таблиц + устройств DSDT) */
    si_put(d, r++, "--- ACPI (hwdet) ---", C_LABEL);
    {
        char sb[64];
        hwinfo_acpi_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_acpi_tables(sb, sizeof(sb));
        if (sb[0] && strcmp(sb, "-")) {
            snprintf(line, sizeof(line), "Таблицы: %s", sb);
            si_put(d, r++, line, C_VALUE);
        }
        hwinfo_acpi_dsdt(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        snprintf(line, sizeof(line), "Устройств в DSDT: %d (с _HID: %d)",
                 hwinfo_dev_total(), hwinfo_dev_hid());
        si_put(d, r++, line, C_VALUE);
        for (int i = 0; i < hwinfo_dev_hid() && i < 8; i++) {
            char db[64];
            if (hwinfo_dev_get(i, db, sizeof(db))) {
                snprintf(line, sizeof(line), " %s", db);
                si_put(d, r++, line, C_VALUE);
            }
        }
        hwinfo_madt_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_fadt_summary(sb, sizeof(sb));
        si_put(d, r++, sb, C_VALUE);
        hwinfo_hpet_summary(sb, sizeof(sb));
        if (sb[0]) si_put(d, r++, sb, C_VALUE);
        hwinfo_mcfg_summary(sb, sizeof(sb));
        if (sb[0]) si_put(d, r++, sb, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Display */
    si_put(d, r++, "--- Display ---", C_LABEL);
    snprintf(line, sizeof(line), "Screen: %ux%u, %u bpp, pitch %u",
             (unsigned)fb_width(), (unsigned)fb_height(),
             (unsigned)fb_bpp(), (unsigned)fb_pitch());
    si_put(d, r++, line, C_VALUE);
    /* СЕССИЯ 85: GPU (запрос пользователя) */
    snprintf(line, sizeof(line), "GPU: %s", gfx2d_gpu_info());
    si_put(d, r++, line, C_VALUE);

    {
        const mb_info_t *mb = mb_info();
        const char *ldr = (mb && (mb->flags & MBIF_BOOTLDR))
            ? (const char *)(unsigned long)mb->boot_loader_name : "n/a";
        snprintf(line, sizeof(line), "Bootloader: %s", ldr);
        si_put(d, r++, line, C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Input */
    si_put(d, r++, "--- Input ---", C_LABEL);
    snprintf(line, sizeof(line), "PS/2 Mouse: %s",
             mouse_present() ? "present" : "not found");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB keyboard: %s",
             usb_keyboard_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);
    snprintf(line, sizeof(line), "USB mouse: %s",
             usb_mouse_present() ? "yes" : "no");
    si_put(d, r++, line, C_VALUE);

    si_put(d, r++, "", C_VALUE);

    /* USB */
    si_put(d, r++, "--- USB ---", C_LABEL);
    snprintf(line, sizeof(line), "UHCI: %s, EHCI: %s, Devs: %d",
             usb_controllers_found() ? "yes" : "no",
             usb_ehci_present() ? "yes" : "no",
             usb_devices_found());
    si_put(d, r++, line, C_VALUE);
    if (usb_ehci_storage_ready()) {
        si_put(d, r++, "USB flash: READY", C_VALUE);
    } else {
        si_put(d, r++, "USB flash: not detected", C_VALUE);
    }

    si_put(d, r++, "", C_VALUE);

    /* Network */
    si_put(d, r++, "--- Network ---", C_LABEL);
    if (net_nic_present()) {
        u8 mac[6];
        net_get_mac(mac);
        snprintf(line, sizeof(line), "NIC: %s", net_nic_name());
        si_put(d, r++, line, C_VALUE);
        snprintf(line, sizeof(line), "MAC: %02x:%02x:%02x:%02x:%02x:%02x",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        si_put(d, r++, line, C_VALUE);
        char ipbuf[16];
        u32 ip = net_get_ip();
        if (ip == 0) {
            si_put(d, r++, "IP: not configured", C_ACCENT);
        } else {
            net_ntoa(ip, ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "IP: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_netmask(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "Mask: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
            net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
            snprintf(line, sizeof(line), "GW: %s", ipbuf);
            si_put(d, r++, line, C_VALUE);
        }
        snprintf(line, sizeof(line), "TX: %u, RX: %u",
                 (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "NIC: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* WiFi */
    si_put(d, r++, "--- WiFi ---", C_LABEL);
    if (wifi_present()) {
        snprintf(line, sizeof(line), "Chip: %s", wifi_chip_name());
        si_put(d, r++, line, C_VALUE);
    } else {
        si_put(d, r++, "WiFi: not found", C_ACCENT);
    }

    si_put(d, r++, "", C_VALUE);

    /* Sound (сессия 57; сессия 58: подробнее + причина если нет) */
    si_put(d, r++, "--- Sound ---", C_LABEL);
    if (sound_present()) {
        snprintf(line, sizeof(line), "Device: %s", sound_device_name());
        si_put(d, r++, line, C_VALUE);
        si_put(d, r++, "PCI, playback 16-bit stereo (тест ниже)", C_VALUE);
    } else {
        si_put(d, r++, "Device: not found", C_VALUE);
        snprintf(line, sizeof(line), "Причина: %s", sound_last_error());
        si_put(d, r++, line, C_ACCENT);
    }
    si_put(d, r++, "Тесты — кнопки внизу окна (CPU/звук)", C_ACCENT);

    si_put(d, r++, "", C_VALUE);
    si_put(d, r++, "Uptime: 00:00:00", C_VALUE);

    u32 W = fb_width(), H = fb_height();
    int ww = 8 * SI_LINE_W + 20;
    int wh = 16 * 18 + 24 + TITLE_H + 2;  /* показываем 16 строк, остальные — скроллом */
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("System Info", 16, 16, ww, wh,
               si_draw, si_key, si_mouse, si_tick, NULL, d);
}