/* fileman.c — файловый менеджер FAT32 и RAMFS, просмотрщик текста */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "mem.h"
#include "string.h"
#include "kbd.h"
#include "mouse.h"
#include "fat32.h"
#include "ramfs.h"

/* ============================ файловый менеджер ============================ */

#define FM_MAX 256
#define FM_ROW 18
#define FM_HDR 22

typedef struct {
    fat32_dirent_t fat_ents[FM_MAX];
    ramfs_dirent_t ram_ents[FM_MAX];
    int  fat_n, ram_n, sel, scroll, depth;
    int  mode; /* 0 = FAT32, 1 = RAMFS */
    struct { u32 cluster; char path[200]; } stk[16];
} fm_t;

static void fm_path_join(char *dst, const char *name)
{
    int l = (int)strlen(dst);
    if (l && dst[l-1] != '/') dst[l++] = '/';
    int i = 0;
    while (name[i] && l < 190) dst[l++] = name[i++];
    dst[l] = 0;
}

static void fm_reload(fm_t *m)
{
    if (m->mode == 0) {
        /* FAT32 режим */
        m->fat_n = fat32_ready() ? fat32_list(m->stk[m->depth].cluster, m->fat_ents, FM_MAX) : 0;
        m->ram_n = 0;
    } else {
        /* RAMFS режим */
        m->ram_n = ramfs_ready() ? ramfs_list(m->ram_ents, FM_MAX) : 0;
        m->fat_n = 0;
    }
    m->sel = 0;
    m->scroll = 0;
}

static void fm_draw(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x14, 0x17, 0x1C));
    
    /* Заголовок с режимом */
    fb_fill_rect(0, 0, cw, FM_HDR, fb_rgb(0x1E, 0x4A, 0x73));
    char title[120];
    snprintf(title, sizeof(title), "%s: %s", 
             m->mode == 0 ? "FAT32" : "RAMFS",
             m->stk[m->depth].path);
    fb_text(6, (FM_HDR - 16) / 2, title, fb_rgb(0xE6, 0xEA, 0xEE), -1);

    /* Индикатор режима */
    const char *mode_text = m->mode == 0 ? "FAT32" : "RAMFS";
    u32 mode_color = m->mode == 0 ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0x90, 0xEE, 0x90);
    fb_text(cw - 60, (FM_HDR - 16) / 2, mode_text, mode_color, -1);

    if ((m->mode == 0 && !fat32_ready()) || (m->mode == 1 && !ramfs_ready())) {
        const char *msg = m->mode == 0 ? "FAT32-раздел не найден." : "RAMFS не инициализирован.";
        fb_text(12, FM_HDR + 8, msg, fb_rgb(0xE0, 0x9A, 0x9A), -1);
        fb_text(12, FM_HDR + 28, "Нажмите Tab для переключения режима", fb_rgb(0x8A, 0x93, 0x9C), -1);
        return;
    }

    int vis = (ch - FM_HDR - 20) / FM_ROW;
    if (vis < 1) vis = 1;
    if (m->sel < m->scroll) m->scroll = m->sel;
    if (m->sel >= m->scroll + vis) m->scroll = m->sel - vis + 1;

    int y0 = FM_HDR + 2;
    int total = m->mode == 0 ? m->fat_n : m->ram_n;
    
    for (int i = 0; i < vis; i++) {
        int idx = m->scroll + i;
        if (idx >= total) break;
        
        const char *name;
        u32 size;
        int is_dir;
        
        if (m->mode == 0) {
            fat32_dirent_t *e = &m->fat_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = (e->attr & 0x10) ? 1 : 0;
        } else {
            ramfs_dirent_t *e = &m->ram_ents[idx];
            name = e->name;
            size = e->size;
            is_dir = e->is_dir;
        }
        
        int yy = y0 + i * FM_ROW;
        if (idx == m->sel)
            fb_fill_rect(0, yy, cw, FM_ROW, fb_rgb(0x24, 0x43, 0x5F));

        u32 col = is_dir ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0xDD, 0xE2, 0xE6);
        fb_text(6, yy + 1, is_dir ? "[D]" : "   ", col, -1);
        fb_text(6 + 4*8, yy + 1, name, col, -1);

        if (!is_dir) {
            char buf[24];
            if (size < 1024)                 snprintf(buf, sizeof(buf), "%u B",   (unsigned)size);
            else if (size < 1024u*1024)      snprintf(buf, sizeof(buf), "%u KiB", (unsigned)(size/1024));
            else                             snprintf(buf, sizeof(buf), "%u MiB", (unsigned)(size/(1024u*1024)));
            int tw = (int)strlen(buf) * 8;
            fb_text(cw - tw - 8, yy + 1, buf, fb_rgb(0x8A, 0x93, 0x9C), -1);
        }
    }

    char st[64];
    snprintf(st, sizeof(st), "%d / %d | Tab: сменить режим", 
             total ? m->sel + 1 : 0, total);
    fb_text(6, ch - 16, st, fb_rgb(0x8A, 0x93, 0x9C), -1);
}

/* --------- просмотрщик --------- */

typedef struct {
    char *buf;
    u32   len;
    int   top;
    int   source; /* 0 = FAT32, 1 = RAMFS */
} viewer_t;

static void viewer_draw(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);
    int cols = cw / 8;
    int vis  = ch / 16;

    fb_fill_rect(0, 0, cw, ch, fb_rgb(0x0B, 0x0E, 0x11));

    /* Заголовок с источником */
    const char *src = v->source == 0 ? "FAT32" : "RAMFS";
    u32 src_col = v->source == 0 ? fb_rgb(0x8F, 0xC8, 0xFF) : fb_rgb(0x90, 0xEE, 0x90);
    fb_text(4, 2, src, src_col, -1);

    int line = 0, i = 0;
    while (i < (int)v->len && line < v->top) {
        if (v->buf[i] == '\n') line++;
        i++;
    }
    int y = 18;
    char tmp[256];
    for (int r = 0; r < vis && i < (int)v->len; r++) {
        int start = i, end = i;
        while (end < (int)v->len && v->buf[end] != '\n') end++;
        int len = end - start;
        if (len > cols) len = cols;
        if (len > 255)  len = 255;
        memcpy(tmp, v->buf + start, len);
        tmp[len] = 0;
        fb_text(4, y, tmp, fb_rgb(0xC6, 0xCD, 0xD5), -1);
        i = end + (end < (int)v->len ? 1 : 0);
        y += 16;
    }
}

static void viewer_key(window_t *w, const key_event_t *ev)
{
    viewer_t *v = (viewer_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (ev->code == KBD_UP)   { if (v->top > 0) v->top--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { v->top++; win_invalidate(w); }
    if (ev->code == 0x49)     { v->top -= 16; if (v->top < 0) v->top = 0; win_invalidate(w); }
    if (ev->code == 0x51)     { v->top += 16; win_invalidate(w); }
}

static void viewer_close(window_t *w)
{
    viewer_t *v = (viewer_t *)w->data;
    if (v) { if (v->buf) free(v->buf); free(v); }
}

static void viewer_open_fat(const fat32_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 0;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = fat32_read_file(e->first_cluster, e->size, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [FAT32]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

static void viewer_open_ram(const ramfs_dirent_t *e)
{
    viewer_t *v = (viewer_t *)malloc(sizeof(viewer_t));
    if (!v) return;
    memset(v, 0, sizeof(viewer_t));
    v->source = 1;

    u32 cap = 65536;
    if (e->size < cap) cap = e->size;
    v->buf = (char *)malloc(cap + 1);
    if (!v->buf) { free(v); return; }
    v->len = ramfs_read(e->name, v->buf, cap);
    v->buf[v->len] = 0;

    char title[80];
    snprintf(title, sizeof(title), "%s [RAMFS]", e->name);

    u32 W = fb_width(), H = fb_height();
    int ww = 640, wh = 420;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 50, ww, wh, viewer_draw, viewer_key, NULL, NULL, viewer_close, v);
}

/* --------- события файлового менеджера --------- */

static void fm_open_selected(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    int total = m->mode == 0 ? m->fat_n : m->ram_n;
    if (m->sel < 0 || m->sel >= total) return;

    if (m->mode == 0) {
        /* FAT32 режим */
        fat32_dirent_t *e = &m->fat_ents[m->sel];
        if (e->attr & 0x10) {
            if (m->depth + 1 >= 16) return;
            m->depth++;
            m->stk[m->depth].cluster = e->first_cluster;
            strcpy(m->stk[m->depth].path, m->stk[m->depth-1].path);
            fm_path_join(m->stk[m->depth].path, e->name);
            fm_reload(m);
            win_invalidate(w);
        } else {
            viewer_open_fat(e);
        }
    } else {
        /* RAMFS режим */
        ramfs_dirent_t *e = &m->ram_ents[m->sel];
        if (e->is_dir) {
            /* В текущей реализации RAMFS нет вложенных каталогов */
            return;
        } else {
            viewer_open_ram(e);
        }
    }
}

static void fm_up(window_t *w)
{
    fm_t *m = (fm_t *)w->data;
    if (m->depth == 0) return;
    m->depth--;
    fm_reload(m);
    win_invalidate(w);
}

static void fm_key(window_t *w, const key_event_t *ev)
{
    fm_t *m = (fm_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    
    if (ev->code == 0x0F) { /* Tab - переключение режима */
        m->mode = 1 - m->mode;
        m->depth = 0;
        m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
        strcpy(m->stk[0].path, "/");
        fm_reload(m);
        win_invalidate(w);
        return;
    }
    
    if (ev->code == KBD_UP)   { if (m->sel > 0)     m->sel--; win_invalidate(w); }
    if (ev->code == KBD_DOWN) { 
        int total = m->mode == 0 ? m->fat_n : m->ram_n;
        if (m->sel+1 < total) m->sel++; 
        win_invalidate(w); 
    }
    if (ev->code == 0x1C || ev->ch == '\n') fm_open_selected(w);
    if (ev->code == 0x0E || ev->ch == '\b') fm_up(w);
    if (ev->ch == 'r' || ev->ch == 'R') { fm_reload(m); win_invalidate(w); }
}

static void fm_mouse(window_t *w, int mx, int my, u8 btn, u8 changed)
{
    fm_t *m = (fm_t *)w->data;
    (void)mx;
    if (!(changed & MSB_LEFT) || !(btn & MSB_LEFT)) return;
    if (my < FM_HDR + 2) return;
    int row = (my - FM_HDR - 2) / FM_ROW;
    int idx = m->scroll + row;
    int total = m->mode == 0 ? m->fat_n : m->ram_n;
    if (idx < 0 || idx >= total) return;
    if (idx == m->sel) fm_open_selected(w);
    else { m->sel = idx; win_invalidate(w); }
}

static void fm_close(window_t *w) { free(w->data); }

void app_files_open(void)
{
    fm_t *m = (fm_t *)malloc(sizeof(fm_t));
    if (!m) return;
    memset(m, 0, sizeof(fm_t));

    m->depth = 0;
    m->mode = fat32_ready() ? 0 : (ramfs_ready() ? 1 : 0);
    m->stk[0].cluster = fat32_ready() ? fat32_root_cluster() : 0;
    strcpy(m->stk[0].path, "/");
    fm_reload(m);

    u32 W = fb_width(), H = fb_height();
    int ww = 520, wh = 380;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create("Файлы", 30, 30, ww, wh, fm_draw, fm_key, fm_mouse, NULL, fm_close, m);
}