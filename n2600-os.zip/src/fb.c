/* fb.c — вывод в VESA-фреймбуфер: backbuffer -> LFB, dirty-область, шрифт.
 * Размер и адрес фреймбуфера берутся из Multiboot (GRUB сам выставляет
 * видеорежим VESA согласно grub.cfg, включая 1280x600x32). */
#include "fb.h"
#include "font.h"
#include "mem.h"
#include "string.h"

static u32 fbw = 0, fbh = 0, fbpitch = 0, fbbpp = 0;
static u32 *lfb = NULL;       /* реальный фреймбуфер */
static u32 *back = NULL;      /* Backbuffer (рисуем сюда) */
static u32 *bg = NULL;        /* фон рабочего стола */

static int clip_x0, clip_y0, clip_x1, clip_y1;
static int org_x = 0, org_y = 0;   /* смещение начала координат для содержимого окна */

/* dirty-область кадра */
static int d_x0, d_y0, d_x1, d_y1;
static int marking = 1;

static int glyph_index(unsigned cp)
{
    if (cp >= 0x20 && cp <= 0x7E)  return (int)cp - 0x20;
    if (cp >= 0x410 && cp <= 0x44F) return 95 + (int)cp - 0x410;
    switch (cp) {
    case 0x401: return 159; /* Ё */
    case 0x451: return 160; /* ё */
    case 0x0AB: return 161; /* « */
    case 0x0BB: return 162; /* » */
    case 0x0B0: return 163; /* ° */
    }
    return -1;
}

int fb_init(const mb_info_t *mb)
{
    if (!(mb->flags & MBIF_FRAMEBUFFER)) return 0;
    if (mb->framebuffer_type != MB_FT_RGB) return 0;
    if (mb->framebuffer_bpp != 32) return 0;
    if (!mb->framebuffer_addr || !mb->framebuffer_width) return 0;

    fbw = mb->framebuffer_width;
    fbh = mb->framebuffer_height;
    fbpitch = mb->framebuffer_pitch;
    fbbpp = mb->framebuffer_bpp;
    lfb = (u32 *)(u32)mb->framebuffer_addr;

    back = (u32 *)malloc(fbw * fbh * 4);
    bg = (u32 *)malloc(fbw * fbh * 4);
    if (!back || !bg) return 0;

    fb_set_clip(0, 0, (int)fbw - 1, (int)fbh - 1);
    fb_touch_all();
    return 1;
}

int fb_ready(void) { return back != NULL; }
u32 fb_rgb(u8 r, u8 g, u8 b) { return 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | b; }
u32 fb_width(void)  { return fbw; }
u32 fb_height(void) { return fbh; }
u32 fb_bpp(void)    { return fbbpp; }
u32 fb_pitch(void)  { return fbpitch; }

/* ------------------------------ фон стола ------------------------------ */

void fb_make_bg(void)
{
    u32 top = fb_rgb(0x21, 0x26, 0x2D);
    u32 bot = fb_rgb(0x0B, 0x0D, 0x10);
    for (u32 y = 0; y < fbh; y++) {
        u32 t = (y * 256u) / (fbh ? fbh : 1);
        u32 r = ((top >> 16) & 0xFF) + ((((bot >> 16) & 0xFF) - ((top >> 16) & 0xFF)) * t) / 256;
        u32 g = ((top >> 8) & 0xFF) + ((((bot >> 8) & 0xFF) - ((top >> 8) & 0xFF)) * t) / 256;
        u32 b = (top & 0xFF) + (((bot & 0xFF) - (top & 0xFF)) * t) / 256;
        u32 c = fb_rgb((u8)r, (u8)g, (u8)b);
        u32 *row = bg + (u32)y * fbw;
        for (u32 x = 0; x < fbw; x++) row[x] = c;
    }
    /* едва заметный водяной знак */
    const char *wm = "N2600-OS";
    u32 wc = fb_rgb(0x19, 0x1E, 0x25);
    u32 tw = fb_text_w(wm);
    fb_text((int)fbw - tw - 24, (int)fbh - 28 - 16 - 24, wm, wc, -1);
}

/* ---------------------------- dirty-область ---------------------------- */

void fb_mark_enable(void)  { marking = 1; }
void fb_mark_disable(void) { marking = 0; }

void fb_touch(int x, int y, int w, int h)
{
    if (!marking || !back) return;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > (int)fbw) w = (int)fbw - x;
    if (y + h > (int)fbh) h = (int)fbh - y;
    if (w <= 0 || h <= 0) return;
    if (x < d_x0) d_x0 = x;
    if (y < d_y0) d_y0 = y;
    if (x + w - 1 > d_x1) d_x1 = x + w - 1;
    if (y + h - 1 > d_y1) d_y1 = y + h - 1;
}

void fb_touch_all(void)
{
    if (!marking || !back) return;
    d_x0 = 0; d_y0 = 0; d_x1 = (int)fbw - 1; d_y1 = (int)fbh - 1;
}

int fb_dirty(int *x0, int *y0, int *x1, int *y1)
{
    if (d_x0 > d_x1 || d_y0 > d_y1 || !back) return 0;
    if (x0) *x0 = d_x0;
    if (y0) *y0 = d_y0;
    if (x1) *x1 = d_x1;
    if (y1) *y1 = d_y1;
    return 1;
}

void fb_flush(void)
{
    if (!lfb || !back || d_x0 > d_x1 || d_y0 > d_y1) {
        d_x0 = d_y0 = 0x7FFFFFFF; d_x1 = d_y1 = -0x7FFFFFFF;
        return;
    }
    u8 *dst = (u8 *)lfb;
    const u8 *src = (const u8 *)back;
    for (int y = d_y0; y <= d_y1; y++) {
        memcpy(dst + (u32)y * fbpitch + (u32)d_x0 * 4,
               src + ((u32)y * fbw + (u32)d_x0) * 4,
               (u32)(d_x1 - d_x0 + 1) * 4);
    }
    d_x0 = d_y0 = 0x7FFFFFFF; d_x1 = d_y1 = -0x7FFFFFFF;
}

/* ------------------------------ примитивы ------------------------------ */

void fb_set_clip(int x0, int y0, int x1, int y1)
{
    /* Жёстко зажимаем область отсечения в границах фреймбуфера.
     * Иначе при выходе окна за экран координаты x >= fbw (или y >= fbh)
     * пишутся в back[] со «сдвигом на следующую строку» — содержимое
     * окна визуально появляется с противоположной стороны экрана. */
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)fbw - 1) x1 = (int)fbw - 1;
    if (y1 > (int)fbh - 1) y1 = (int)fbh - 1;

    clip_x0 = x0; clip_y0 = y0; clip_x1 = x1; clip_y1 = y1;
}

void fb_set_origin(int ox, int oy)
{
    org_x = ox; org_y = oy;
}

static inline void raw_pixel(int x, int y, u32 c)
{
    back[(u32)y * fbw + (u32)x] = c;
}

void fb_fill_screen(u32 c) { fb_fill_rect(0, 0, (int)fbw, (int)fbh, c); }

void fb_fill_rect(int x, int y, int w, int h, u32 c)
{
    x += org_x; y += org_y;
    if (x < clip_x0) { w -= clip_x0 - x; x = clip_x0; }
    if (y < clip_y0) { h -= clip_y0 - y; y = clip_y0; }
    if (x + w - 1 > clip_x1) w = clip_x1 - x + 1;
    if (y + h - 1 > clip_y1) h = clip_y1 - y + 1;
    if (w <= 0 || h <= 0 || !back) return;
    for (int yy = y; yy < y + h; yy++) {
        u32 *row = back + (u32)yy * fbw + (u32)x;
        for (int xx = 0; xx < w; xx++) row[xx] = c;
    }
    fb_touch(x, y, w, h);
}

void fb_rect(int x, int y, int w, int h, u32 c)
{
    fb_hline(x, x + w - 1, y, c);
    fb_hline(x, x + w - 1, y + h - 1, c);
    fb_vline(x, y, y + h - 1, c);
    fb_vline(x + w - 1, y, y + h - 1, c);
}

void fb_hline(int x0, int x1, int y, u32 c)
{
    x0 += org_x; x1 += org_x; y += org_y;
    if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
    if (x0 < clip_x0) x0 = clip_x0;
    if (x1 > clip_x1) x1 = clip_x1;
    if (y < clip_y0 || y > clip_y1 || x0 > x1 || !back) return;
    u32 *row = back + (u32)y * fbw;
    for (int x = x0; x <= x1; x++) row[x] = c;
    fb_touch(x0, y, x1 - x0 + 1, 1);
}

void fb_vline(int x, int y0, int y1, u32 c)
{
    x += org_x; y0 += org_y; y1 += org_y;
    if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
    if (y0 < clip_y0) y0 = clip_y0;
    if (y1 > clip_y1) y1 = clip_y1;
    if (x < clip_x0 || x > clip_x1 || y0 > y1 || !back) return;
    for (int y = y0; y <= y1; y++) back[(u32)y * fbw + (u32)x] = c;
    fb_touch(x, y0, 1, y1 - y0 + 1);
}

void fb_char(int x, int y, unsigned cp, u32 fg, int bg)
{
    x += org_x; y += org_y;
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];
    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (!bits) continue;
        for (int rx = 0; rx < 8; rx++) {
            if (bits & (0x80 >> rx)) {
                if (x + rx >= clip_x0 && x + rx <= clip_x1 &&
                    y + ry >= clip_y0 && y + ry <= clip_y1)
                    raw_pixel(x + rx, y + ry, fg);
            } else if (bg >= 0) {
                if (x + rx >= clip_x0 && x + rx <= clip_x1 &&
                    y + ry >= clip_y0 && y + ry <= clip_y1)
                    raw_pixel(x + rx, y + ry, (u32)bg);
            }
        }
    }
    fb_touch(x, y, 8, 16);
}

void fb_char2x(int x, int y, unsigned cp, u32 fg)
{
    int gi = glyph_index(cp);
    if (gi < 0) gi = glyph_index('?');
    const unsigned char *g = font8x16[gi];
    for (int ry = 0; ry < 16; ry++) {
        u8 bits = g[ry];
        if (!bits) continue;
        for (int rx = 0; rx < 8; rx++) {
            if (bits & (0x80 >> rx)) {
                fb_fill_rect(x + rx * 2, y + ry * 2, 2, 2, fg);
            }
        }
    }
}

void fb_text(int x, int y, const char *s, u32 fg, int bg)
{
    int cx = x;
    while (*s) {
        unsigned cp = utf8_next(&s);
        if (cp == '\n') break;
        fb_char(cx, y, cp, fg, bg);
        cx += 8;
    }
}

void fb_text_screen_centered(int clip_y0, int y, const char *s, u32 fg)
{
    int x = (int)(fbw - fb_text_w(s)) / 2;
    fb_set_clip(0, clip_y0, (int)fbw - 1, (int)fbh - 1);
    fb_text(x, y, s, fg, -1);
}

u32 fb_text_w(const char *s)
{
    return (u32)strlen(s) * 8;
}

void fb_blit_bg(int x0, int y0, int x1, int y1)
{
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 >= (int)fbw) x1 = (int)fbw - 1;
    if (y1 >= (int)fbh) y1 = (int)fbh - 1;
    if (x0 > x1 || y0 > y1 || !bg || !back) return;
    for (int y = y0; y <= y1; y++) {
        memcpy(back + (u32)y * fbw + (u32)x0,
               bg + (u32)y * fbw + (u32)x0,
               (u32)(x1 - x0 + 1) * 4);
    }
}
