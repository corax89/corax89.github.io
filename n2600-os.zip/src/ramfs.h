/* ramfs.h — виртуальная файловая система в оперативной памяти */
#ifndef RAMFS_H
#define RAMFS_H

#include "types.h"

#define RAMFS_NAME_MAX 64
#define RAMFS_MAX_FILES 256

typedef struct {
    char name[RAMFS_NAME_MAX + 1];
    u32  size;
    u32  offset;  /* смещение в области данных */
    u8   is_dir;  /* 1 = каталог, 0 = файл */
} ramfs_dirent_t;

/* Инициализация RAM disk (10% от доступной памяти) */
int  ramfs_init(void);
int  ramfs_ready(void);

/* Создать файл (возвращает 1 при успехе) */
int  ramfs_create(const char *name, u32 size);

/* Записать данные в файл */
int  ramfs_write(const char *name, const void *buf, u32 size);

/* Прочитать файл (возвращает количество прочитанных байт) */
u32  ramfs_read(const char *name, void *buf, u32 max);

/* Удалить файл */
int  ramfs_delete(const char *name);

/* Список файлов в корневом каталоге */
int  ramfs_list(ramfs_dirent_t *out, int max);

/* Получить размер свободного места */
u32  ramfs_free_space(void);

/* Получить общий размер RAM disk */
u32  ramfs_total_space(void);

#endif