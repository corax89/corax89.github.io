/* apps.h — реестр приложений N2600-OS.
 *
 * КАК ДОБАВИТЬ СВОЁ ПРИЛОЖЕНИЕ:
 *   1) создайте src/my_app.c по образцу src/apps_example.c;
 *   2) добавьте строку в app_table[] ниже (src/apps.c);
 *   3) соберите проект build.bat — всё, приложение появится в меню.
 */
#ifndef APPS_H
#define APPS_H

typedef struct {
    const char *name;   /* название в меню «Пуск» */
    void (*open_fn)(void);
} app_def_t;

extern const app_def_t app_table[];
extern const int app_table_count;

void apps_open(int idx);

/* встроенные приложения */
void app_about_open(void);
void app_term_open(void);
void app_sysinfo_open(void);
void app_files_open(void);   /* файловый менеджер FAT32 */
void app_example_open(void);   /* шаблон нового приложения */

/* информация о CPU для приложений (заполняется лениво) */
void cpu_get_brand(char out[52]);
void cpu_get_vendor(char out[16]);
int  cpu_get_cores(void);

#endif /* APPS_H */
