/* net.h — минимальный TCP/IP стек для N2600-OS.
 *
 * Реализованы нижние уровни:
 *   - Ethernet: parsing/построение кадров (dst MAC, src MAC, EtherType)
 *   - ARP: запрос/ответ, кэш на 16 записей (IP->MAC), разрешение за 1 запрос
 *   - IP: приём/передача пакетов (фрагментация не поддерживается, MTU=1500)
 *   - ICMP: Echo Request / Echo Reply (для ping)
 *
 * Не реализовано:
 *   - TCP (только UDP будет добавлен в следующей итерации)
 *   - Фрагментация IP
 *   - DHCP (статический IP, настраивается командой ipconfig)
 *
 * Драйвер NIC абстрагирован через указатели функций: e1000_send / e1000_recv.
 */
#ifndef NET_H
#define NET_H

#include "types.h"

#define NET_PKT_MAX 1518

/* Ethernet frame */
typedef struct __attribute__((packed)) {
    u8 dst[6];
    u8 src[6];
    u16 ethertype;   /* 0x0806=ARP, 0x0800=IP */
} eth_hdr_t;

#define ETHERTYPE_ARP 0x0806
#define ETHERTYPE_IPV4 0x0800

/* ARP packet (Ethernet/IPv4) */
typedef struct __attribute__((packed)) {
    u16 htype;       /* 1 = Ethernet */
    u16 ptype;       /* 0x0800 = IPv4 */
    u8  hlen;        /* 6 */
    u8  plen;        /* 4 */
    u16 oper;        /* 1=request, 2=reply */
    u8  sha[6];      /* sender hardware addr */
    u8  spa[4];      /* sender protocol addr */
    u8  tha[6];      /* target hardware addr */
    u8  tpa[4];      /* target protocol addr */
} arp_pkt_t;

/* IPv4 header (без опций, 20 байт) */
typedef struct __attribute__((packed)) {
    u8  ver_ihl;     /* version=4, ihl=5 (no options) */
    u8  tos;
    u16 tot_len;     /* total length (header + payload) */
    u16 id;
    u16 flags_frag;  /* flags + fragment offset */
    u8  ttl;
    u8  protocol;    /* 1=ICMP, 17=UDP */
    u16 checksum;
    u8  src_ip[4];
    u8  dst_ip[4];
} ip_hdr_t;

#define IP_PROTO_ICMP 1
#define IP_PROTO_TCP  6
#define IP_PROTO_UDP  17

/* ICMP header (8 байт, далее payload) */
typedef struct __attribute__((packed)) {
    u8  type;        /* 8=Echo Request, 0=Echo Reply, 3=Dest Unreach */
    u8  code;
    u16 checksum;
    u16 id;
    u16 seq;
} icmp_hdr_t;

#define ICMP_TYPE_ECHO_REPLY   0
#define ICMP_TYPE_ECHO_REQUEST 8

/* Инициализация стека (вызывается после e1000_init). */
void net_init(void);

/* Установить наш IP-адрес. Если 0.0.0.0 — стек не отвечает на пакеты. */
void net_set_ip(u32 ip);
u32  net_get_ip(void);

/* Есть ли вообще какой-либо активный NIC? (E1000/VirtIO/NE2000/atl1c/WiFi) */
int  net_nic_present(void);

/* Имя активного NIC-чипа. */
const char *net_nic_name(void);

/* MAC-адрес активного NIC. */
void net_get_mac(u8 out_mac[6]);

/* =========== реестр адаптеров + приоритет (сессия 11) ===========
 * Все найденные NIC регистрируются в реестре; активный выбирается
 * по состоянию линка (ethernet-линк > WiFi-ассоциация > любой),
 * либо вручную (Настройки / команда adapter). */

/* Число найденных адаптеров и информация о каждом. */
int  net_adapter_count(void);
int  net_adapter_present(int i);
const char *net_adapter_name(int i);   /* "e1000".."atl1c", "wifi" */
int  net_adapter_link(int i);          /* 1 = линк есть */
int  net_adapter_active(void);         /* индекс активного или -1 */

/* Режим приоритета: 0 = авто, 1..N = ручной (индекс адаптера + 1).
 * net_adapter_set_mode возвращает 1, если активный адаптер сменился
 * (вызову предшествует DHCP-перезапуск через callback). */
int  net_adapter_mode(void);
int  net_adapter_manual_idx(void);     /* -1 = авто-режим */
int  net_adapter_set_mode(int mode);

/* Периодический контроль (netmon): авто-переключение при потере линка.
 * Возвращает 1, если переключились. */
int  net_adapter_check(void);

/* Сессия 15: пересканировать реестр (wifi инициализируется фоном после
 * старта ОС). Возвращает текущее число адаптеров. */
int  net_adapter_rescan(void);

/* Callback смены активного адаптера (ядру: перезапустить DHCP). */
void net_adapter_set_change_cb(void (*cb)(void));

/* Установить режим ДО net_init (из файла настроек при загрузке). */
void net_settings_set_adapter(int mode);

/* Поиск адаптера по имени — индекс или -1. */
int  net_adapter_find(const char *name);

/* Главная функция обработки: читает пакет из NIC, диспетчеризует его по
 * ethertype (ARP/IP). Должна вызываться из основного цикла. */
void net_poll(void);

/* Отправить ARP-запрос (для определения MAC-адреса по IP). */
int  net_send_arp_request(u32 target_ip);

/* FIX [N1c]: дождаться разрешения MAC для IP (учитывая шлюз) —
 * до max_ms мс. Шлёт ARP-запросы, обрабатывает ответы (net_poll),
 * отдаёт CPU. Возвращает 1 при успехе, 0 по таймауту. Вызывать
 * ПЕРЕД отправкой TCP-сегментов новому адресату (первый пакет
 * иначе молча теряется в net_send_ip). */
int  net_wait_arp(u32 ip, u32 max_ms);

/* Отправить ICMP Echo Request (ping). */
int  net_send_icmp_echo(u32 target_ip, u16 id, u16 seq, const void *payload, u32 payload_len);

/* Установить шлюз по умолчанию (для IP не в нашей подсети). */
void net_set_gateway(u32 gw);
u32  net_get_gateway(void);

/* Установить сетевую маску (по умолчанию 255.255.255.0). */
void net_set_netmask(u32 mask);
u32  net_get_netmask(void);

/* Парсинг IP-адреса "a.b.c.d" в u32 (host order). Возвращает 1 при успехе. */
int  net_aton(const char *str, u32 *out_ip);

/* Обратное: форматирование IP в "a.b.c.d" — возвращает число записанных байт. */
int  net_ntoa(u32 ip, char *out, u32 out_max);

/* Зарегистрировать callback для ICMP-ответов (для ping). */
typedef void (*net_icmp_cb_t)(u32 src_ip, u16 id, u16 seq,
                               const void *payload, u32 payload_len);
void net_set_icmp_callback(net_icmp_cb_t cb);

/* Получить число отправленных/принятых пакетов (для статистики). */
u32 net_tx_packets(void);
u32 net_rx_packets(void);

/* Число отправленных/принятых БАЙТ (кадры целиком; счётчики u32 —
 * вычитание двух снимков корректно и при завороте). Для графиков
 * трафика: дельта за интервал = скорость. */
u32 net_tx_bytes(void);
u32 net_rx_bytes(void);

/* ---------- ARP кэш ---------- */
typedef struct {
    u32 ip;        /* 0 = пустая запись */
    u8  mac[6];
} net_arp_entry_t;

#define NET_ARP_CACHE_SIZE 16

/* Получить дамп ARP-кэша. Записывает до max_entries в out.
 * Возвращает число активных записей. */
int net_arp_dump(net_arp_entry_t *out, int max_entries);

/* ===================== UDP ===================== */

typedef void (*net_udp_recv_cb_t)(u32 src_ip, u16 src_port, u16 dst_port,
                                   const void *data, u32 len);

typedef struct {
    u32 local_ip;        /* наш IP (для фильтра), 0 = любой */
    u16 local_port;      /* локальный порт, 0 = не используется */
    u16 remote_port;     /* удалённый порт (для send — куда шлём) */
    u32 remote_ip;        /* удалённый IP (для send — куда шлём) */
    int  in_use;
    /* Сессия 21: СОБСТВЕННЫЙ callback на сокет. Раньше был ОДИН
     * глобальный (последний зарегистрировавший забирал ВСЕ UDP-пакеты):
     * DNS-сокет получал DHCP-продления и сетевой шум
     * (NetBIOS/mDNS/SSDP-бродкасты) -> «[dns] txid mismatch»,
     * а DHCP-клиент после регистрации DNS-сокета вообще переставал
     * видеть свои ответы. Теперь net_udp_set_callback привязывает cb
     * к ПОСЛЕДНЕМУ открытому сокету, доставка — по dst_port. */
    net_udp_recv_cb_t cb;
} net_udp_socket_t;

#define NET_MAX_UDP_SOCKETS 16

/* Открыть UDP-сокет. Возвращает индекс сокета (>=0) или -1. */
int  net_udp_open(u16 local_port);
void net_udp_close(int sock);
/* Отправить UDP-сообщение. dst_ip/dst_port — куда, data/len — что.
 * Возвращает число отправленных байт или -1. */
int  net_udp_send(int sock, u32 dst_ip, u16 dst_port, const void *data, u32 len);
/* Зарегистрировать callback для входящих UDP-пакетов.
 * cb(src_ip, src_port, dst_port, data, len) — вызывается из net_poll.
 * Сессия 21: callback привязывается к ПОСЛЕДНЕМУ ОТКРЫТОМУ сокету
 * (net_udp_open) и доставляется только пакетам с его dst_port;
 * если сокетов нет — сохраняется как глобальный fallback. */
void net_udp_set_callback(net_udp_recv_cb_t cb);

/* ===================== TCP ===================== */

/* Callback приёма данных TCP (глобальный по умолчанию; слушатели
 * могут назначить СОБСТВЕННЫЙ per-socket callback — см. net_tcp_listen). */
typedef void (*net_tcp_recv_cb_t)(int sock, u32 src_ip, u16 src_port,
                                   const void *data, u32 len);

typedef enum {
    TCP_CLOSED = 0,
    TCP_SYN_SENT,
    TCP_SYN_RECEIVED,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT_1,
    TCP_FIN_WAIT_2,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
    TCP_CLOSING,
    TCP_TIME_WAIT
} tcp_state_t;

typedef struct {
    u32  local_ip;
    u16  local_port;       /* наш порт */
    u32  remote_ip;
    u16  remote_port;      /* удалённый порт */
    u32  seq;              /* наш seq (следующий для отправки) */
    u32  ack;              /* последний ack, который мы отправили */
    tcp_state_t state;
    int  in_use;
    /* TCP options (from peer's SYN) */
    u16  mss;              /* maximum segment size (default 1460) */
    u8   window_scale;     /* window scaling factor (0 = no scaling) */
    /* Retransmission queue */
    u32  retransmit_seq;   /* seq последнего неотправленного сегмента */
    u32  retransmit_tick;  /* когда отправили последний раз */
    u8   retransmit_count; /* число повторных передач */
    /* FIX [TCP-R1]: буфер последнего сегмента — реальная ретрансмиссия.
     * Раньше таймер только считал повторы, но НЕ пересылал данные:
     * потерянный GET не восстанавливался никогда — сервер молчал,
     * клиент висел до полного таймаута («response timeout»). */
#define TCP_RETRANS_MAX 1460                 /* = максимальный MSS */
    u8   retrans_buf[TCP_RETRANS_MAX];
    u16  retrans_len;      /* 0 = нечего пересылать */
    /* FIX [TCP-R2]: соединение сброшено (RST). Раньше RST в
     * TCP_ESTABLISHED молча игнорировался: клиент висел все 10 с
     * и получал «response timeout» вместо «connection reset». */
    u8   was_reset;
    /* ---- loopback (сессия 7) ---- */
    int  peer;             /* >=0: сокет-партнёр локальной пары
                             * (соединение 127.0.0.1 / на себя) */
    net_tcp_recv_cb_t recv_cb; /* per-socket приём (NULL = глобальный) */
    /* Сессия 56: КТО сбросил соединение — заполняется при приёме RST.
     * ttl подсказывает источник: ~64 — наша же сеть (роутер/фильтр/
     * DNS-синкхол), заметно меньше — хост в интернете за NAT.
     * Читается net_tcp_rst_info() для понятных сообщений в браузере. */
    u32 rst_ip;
    u16 rst_port;
    u8  rst_ttl;
    /* [IP-CHG2] (Task 41): сокет создан/жил под ДРУГИМ адресом, чем
     * текущий g_net.ip (миграция после DHCP). Чексуммы сегментов всё
     * равно считают текущий адрес ([IP-CHG1]) — флаг информационный. */
    u8  ip_migrated;
} net_tcp_socket_t;

#define NET_MAX_TCP_SOCKETS 8

/* Установить TCP-соединение (active open).
 * Возвращает индекс сокета (>=0) или -1. */
int  net_tcp_connect(u32 dst_ip, u16 dst_port, u16 local_port);

/* Повторно отправить SYN, если сокет всё ещё в SYN_SENT (рассинхрон
 * ARP / потеря пакета). Безопасен в любом состоянии. */
void net_tcp_kick(int sock);

/* Закрыть TCP-соединение (active close — посылает FIN). */
void net_tcp_close(int sock);

/* Отправить данные по TCP-соединению. */
int  net_tcp_send(int sock, const void *data, u32 len);

/* Сессия 60 (FSM httpd): 1 = предыдущий сегмент ещё не подтверждён
 * пиром (следующий кусок слать нельзя — ждём ACK/net_poll). */
int  net_tcp_send_pending(int sock);

/* Сессия 72 [PIN]/[GEN]: защита слотов TCP от кражи между владельцем
 * (httpd) и захватчиками (connect/accept).
 *   PIN — слот закреплён: владелец принял соединение и ещё не закрыл
 *         его со своей стороны. Захватчики слот с пином не берут,
 *         даже если пир/таймер уже снял in_use (владелец ещё не знает).
 *   GEN — поколение слота: +1 при каждом захвате. Владелец запоминает
 *         gen при pin и сверяет перед каждой операцией: не совпало —
 *         слот после ссылки был освобождён и занят заново (ссылка
 *         мертва, чужой сокет трогать нельзя). */
void net_tcp_pin(int sock);
void net_tcp_unpin(int sock);
void net_tcp_unpin_gen(int sock, u32 gen);   /* только своё поколение */
u32  net_tcp_gen(int sock);

/* Получить состояние сокета. */
tcp_state_t net_tcp_state(int sock);

/* Сброшено ли соединение сервером/шлюзом (RST). Читается и после
 * перевода сокета в TCP_CLOSED — флаг живёт до следующего connect. */
int  net_tcp_was_reset(int sock);

/* Сессия 56: данные последнего RST по сокету (источник/порт/TTL).
 * Возвращает 1, если RST приходил (was_reset), и заполняет out-поля. */
int  net_tcp_rst_info(int sock, u32 *ip, u16 *port, u8 *ttl);

/* Зарегистрировать callback для входящих данных TCP (по умолчанию,
 * для сокетов без собственного recv_cb — клиентские соединения). */
void net_tcp_set_callback(net_tcp_recv_cb_t cb);

/* Итерация 7 [TCLIENT]: назначить callback приёма КОНКРЕТНОМУ сокету
 * (например, соединению после net_tcp_connect — telnet-клиент). Данные
 * этого сокета больше не попадают в глобальный callback. */
void net_tcp_set_sock_callback(int sock, net_tcp_recv_cb_t cb);

/* Текстовое имя состояния TCP. */
const char *tcp_state_name(tcp_state_t s);

/* ===================== TCP Passive LISTEN ===================== */
/* Открыть listening-сокет на порту local_port.
 * При входящем соединении вызывается callback cb(new_sock, remote_ip, remote_port).
 * Возвращает индекс listen-сокета или -1. */
typedef void (*tcp_accept_cb_t)(int new_sock, u32 remote_ip, u16 remote_port);
/* recv_cb — per-socket приём данных для принятых соединений (NULL =
 * глобальный callback net_tcp_set_callback). */
int  net_tcp_listen(u16 local_port, tcp_accept_cb_t cb,
                    net_tcp_recv_cb_t recv_cb);
/* Снять слушатель порта (сессия 58: галочка «Веб-сервер» в Настройках). */
void net_tcp_unlisten(u16 local_port);

/* ===================== Loopback (127.0.0.1) ===================== */
/* 127.0.0.0/8 или наш собственный IP — доставка без провода:
 * TCP-соединение замыкается на локального слушателя (httpd),
 * ICMP-эхо отвечает мгновенно. */
int  net_is_loopback(u32 ip);
/* Сессия 63: loopback-хост по имени — "localhost"/"localhost." или
 * IP-литерал 127.x.x.x. Приложения не должны требовать NIC/настроенный
 * IP для таких адресов (соединение не покидает стек). */
int  net_host_is_loopback(const char *host);

/* ===================== TCP Retransmission ===================== */
/* Запустить обработку таймеров TCP (вызывается из net_poll). */
void net_tcp_timer(void);

/* ===================== DHCP клиент ===================== */
typedef enum {
    DHCP_INIT = 0,
    DHCP_SELECTING,
    DHCP_REQUESTING,
    DHCP_BOUND,
    DHCP_RENEWING,
    DHCP_REBINDING
} dhcp_state_t;

/* Запустить DHCP-клиент: отправляет DISCOVER, ждёт OFFER, шлёт REQUEST.
 * Блокирует выполнение на max_ms миллисекунд (через task_yield).
 * Возвращает 1 при успехе (IP/gateway/netmask получены), 0 при неудаче. */
int  net_dhcp_acquire(u32 max_ms);

/* Текущее состояние DHCP. */
dhcp_state_t net_dhcp_state(void);

/* Сброс транзакции DHCP (при смене адаптера). */
void net_dhcp_reset(void);

/* Сессия 12: транзакционный режим — на время DHCP исходящий IP-адрес
 * считается 0.0.0.0, но видимый приложениями адрес НЕ стирается
 * (fix «IP теряется каждые несколько секунд» при повторах DHCP). */
void net_dhcp_txn_begin(void);
void net_dhcp_txn_end(void);

/* ===================== DNS resolver ===================== */
/* Разрешить имя домена в IP-адрес.
 *   hostname    — например "example.com" (NUL-terminated)
 *   out_ip      — куда записать результат (host-order u32)
 *   max_ms      — максимальное время ожидания
 * Возвращает 1 при успехе, 0 при неудаче/таймауте. */
int  net_dns_resolve(const char *hostname, u32 *out_ip, u32 max_ms);

/* Получить DNS-сервер (обычно устанавливается через DHCP). */
u32  net_dns_server(void);
void net_dns_set_server(u32 dns_ip);

/* ===================== HTTP клиент ===================== */
/* HTTP/HTTPS GET-запрос.
 *   host       — имя хоста (например "example.com" или IP-строка)
 *   port       — обычно 80; порт 443 => TLS-сессия (BearSSL, TLS 1.2,
 *                проверка цепочки по встроенным корням tls_anchors.h)
 *   path       — путь (например "/" или "/index.html")
 *   response   — буфер под HTTP-ответ (заголовки + тело)
 *   max_len    — ёмкость response
 *   max_ms     — таймаут
 * Возвращает длину полученного ответа (байт) или -1 при ошибке. */
int  net_http_get(const char *host, u16 port, const char *path,
                   char *response, u32 max_len, u32 max_ms);

/* Task 67 [HTTP-GZIP]: то же, но запрос идёт с Accept-Encoding: gzip и
 * gzip-ответ распаковывается НА МЕСТЕ. Буфер вызывающего должен вмещать
 * РАСПАКОВАННЫЙ ответ (браузер: BR_FETCH_MAX); curl/imgsvc в маленькие
 * буферы продолжают звать net_http_get. */
int  net_http_get_gzip(const char *host, u16 port, const char *path,
                       char *response, u32 max_len, u32 max_ms);

/* Task 47: POST (формы браузера). body — закодированное тело
 * (application/x-www-form-urlencoded, brf_serialize в brform.h);
 * content_type NULL = "application/x-www-form-urlencoded".
 * Возвращает длину ответа (байт) или -1 при ошибке. */
int  net_http_post(const char *host, u16 port, const char *path,
                    const char *body, const char *content_type,
                    char *response, u32 max_len, u32 max_ms);

/* Task 62 [POST-LEN]: POST с телом ЯВНОЙ длины — multipart/form-data
 * с нулями (загрузка файлов на httpd). Тело уходит порциями по MSS
 * с ожиданием ACK. Остальное — как net_http_post. */
int  net_http_post_len(const char *host, u16 port, const char *path,
                       const char *body, u32 body_len, const char *content_type,
                       char *response, u32 max_len, u32 max_ms);

/* Текст последней ошибки net_http_get (для статуса браузера/терминала):
 * "connect timeout", "connection refused", "no ARP", ... */
const char *net_http_errstr(void);

/* Task 60 [HTTP-TRUNC]: честная диагностика сетевого обреза.
 * net_http_content_length() — Content-Length последнего ответа
 * (0 = заголовка не было). net_http_truncated() — 1, если ответ НЕ
 * влез в буфер вызывающего (получено max_len-1 байт, хвост потерян;
 * раньше n == max_len-1 был неотличим от полного ответа). Оба значения
 * валидны сразу после net_http_get/net_http_post до старта следующей
 * транзакции. */
u32 net_http_content_length(void);
int net_http_truncated(void);

/* ═══ Task 68 [HTTP-STREAM]: потоковый GET ═══
 * Страница не накапливается в буфере: тело (после декодирования
 * chunked, а для gzip — после распаковки в конце) отдаётся колбэком
 * по мере приёма. НИКАКОГО лимита «3 МиБ на ответ»: единственные
 * ограничения — буфер ЗАГОЛОВКОВ (16 КиБ внутри клиента) и бюджет
 * gzip-накопителя (GZ_STREAM_ACC_MAX: сжатый ответ больше — отказ).
 *
 *   hdr_cb(ud, status, hdrs, hlen) — вызывается ОДИН раз, как только
 *       блок заголовков собран (до первого байта тела). Возврат != 0 —
 *       прервать транзакцию (редирект/переход на HTTPS/отказ от типа
 *       содержимого); net_http_get_stream вернёт -2.
 *   body_cb(ud, data, len) — куски тела. Возврат != 0 — прервать (-2).
 *       Для gzip: один вызов с РАСПАКОВАННЫМ телом в конце приёма;
 *       без gzip — куски по мере приёма (порции до ~1.5 КиБ).
 *
 * Возврат: суммарно отдано байт тела (>=0), -1 = сетевая ошибка
 * (net_http_errstr), -2 = прервано колбэком. Сразу после вызова
 * валидны net_http_truncated() / net_http_content_length() (CL —
 * СЖАТЫЙ размер при gzip; полный приём = raw-байты, см.
 * net_http_raw_received()) и net_http_raw_received() — сколько сырых
 * байт тела пришло по сети (для «получено X из Y»). */
typedef int (*net_http_hdr_fn)(void *ud, int status,
                               const char *hdrs, u32 hlen);
typedef int (*net_http_body_fn)(void *ud, const char *data, u32 len);
int  net_http_get_stream(const char *host, u16 port, const char *path,
                         u32 max_ms, int allow_gzip,
                         net_http_hdr_fn hdr_cb, net_http_body_fn body_cb,
                         void *ud);
u32  net_http_raw_received(void);

/* ===================== HTTP Trace (диагностика) ===================== */
/* Структура заполняется net_http_get_traced(): точные байты запроса,
 * копия сырого ответа и тайминги каждой фазы. Приложение HTTP Trace
 * показывает её содержимое — видно, НА ЧЬЕЙ стадии запрос отвалился
 * (DNS / ARP / SYN / connect / отправка / приём данных). */
typedef struct {
    /* --- заполняет вызывающий (буферы для копий) --- */
    char *req_copy;        /* куда скопировать байты запроса (NULL = не надо) */
    u32   req_max;
    char *resp_copy;       /* куда копировать сырой ответ (NULL = не надо) */
    u32   resp_max;
    /* --- заполняет net_http_get_traced --- */
    u32   resolved_ip;     /* IP после DNS/литерала (0 = не разрешён) */
    u32   t_dns_ms;        /* разрешение имени (литерал = 0) */
    u32   t_arp_ms;        /* ожидание ARP (кэш = ~0) */
    u32   t_connect_ms;    /* SYN -> ESTABLISHED */
    int   syn_kicks;       /* сколько раз доотправляли SYN */
    u32   t_first_ms;      /* от старта до первого байта ответа */
    u32   t_total_ms;      /* общее время транзакции */
    u32   req_len;         /* байт отправлено (запрос) */
    u32   resp_len;        /* байт получено (сырой ответ) */
    int   sock;            /* индекс сокета (-1 = не открыт) */
    int   result;          /* возвращаемое значение net_http_get_traced */
    char  stage[24];       /* последняя достигнутая стадия:
                              "dns","arp","connect","sent","recv","done" */
    char  error[40];       /* текст ошибки ("" = нет) */
} http_trace_t;

/* То же, что net_http_get, но с записью полной трассировки в tr.
 * tr == NULL — эквивалентно net_http_get. */
int  net_http_get_traced(const char *host, u16 port, const char *path,
                          char *response, u32 max_len, u32 max_ms,
                          http_trace_t *tr);

#endif /* NET_H */
