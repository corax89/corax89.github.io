/* sound.c — ядро звуковой подсистемы: выбор драйвера + синтез тона.
 *
 * Синтез БЕЗ FPU (x87 не сохраняется при переключении задач): четверть-
 * волновая таблица Q15 + фазовый аккумулятор. Формат вывода у всех
 * драйверов одинаковый: 16-bit stereo, правый = левый.
 *
 * Драйверы (сессия 58):
 *   1) ES1371/ES1373 (PCI 1274:1371, 1274:5880, 1102:8938/5880) —
 *      VMware «Sound Blaster AudioPCI», 86Box/PCem «Sound Blaster PCI 128»;
 *   2) ES1370 (PCI 1274:5000) — QEMU `-device es1370`;
 *   3) Intel HDA (класс 0x0403) — VMware «hdaudio» + Realtek ALC269VB.
 *
 * Кольцевой буфер содержит ЦЕЛОЕ число периодов тона — стык при
 * зацикливании бесшовный, щелчков нет.
 */
#include "sound.h"
#include "types.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"

extern void serial_puts(const char *s);

/* probes/players от драйверов */
int snd_es1371_probe(void);                       /* 1 = найден */
const char *snd_es1371_name(void);
int snd_es1371_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
void snd_es1371_codec_init(void);
/* поток (сессия 60) */
int  snd_es1371_stream(const i16 *samples, u32 frames, u32 rate);
void snd_es1371_stream_pause(int on);
void snd_es1371_stream_stop(void);

int snd_es1370_probe(void);                       /* QEMU -device es1370 */
const char *snd_es1370_name(void);
int snd_es1370_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
int  snd_es1370_stream(const i16 *samples, u32 frames, u32 rate);
void snd_es1370_stream_pause(int on);
void snd_es1370_stream_stop(void);

int snd_hda_probe(void);
const char *snd_hda_name(void);
int snd_hda_play(const i16 *samples, u32 frames, u32 rate, u32 ms);
int snd_hda_init(void);
int  snd_hda_stream(const i16 *samples, u32 frames, u32 rate);
void snd_hda_stream_pause(int on);
void snd_hda_stream_stop(void);

static int         g_driver = 0;   /* 0 = нет, 1 = es1371, 2 = es1370, 3 = hda */
static const char *g_err = "нет HDA/ES137x на PCI";

const char *sound_last_error(void) { return g_err; }
const char *sound_device_name(void)
{
    if (g_driver == 1) return snd_es1371_name();
    if (g_driver == 2) return snd_es1370_name();
    if (g_driver == 3) return snd_hda_name();
    return "нет";
}
int sound_present(void) { return g_driver != 0; }

int sound_init(void)
{
    if (snd_es1371_probe()) {
        g_driver = 1;
        snd_es1371_codec_init();
        serial_puts("[sound] ES1371/1373 готов — ");
        serial_puts(snd_es1371_name());
        serial_puts("\n");
        return 1;
    }
    if (snd_es1370_probe()) {
        g_driver = 2;
        serial_puts("[sound] ES1370 готов — ");
        serial_puts(snd_es1370_name());
        serial_puts("\n");
        return 1;
    }
    if (snd_hda_probe()) {
        if (snd_hda_init()) {
            g_driver = 3;
            serial_puts("[sound] Intel HDA готов — ");
            serial_puts(snd_hda_name());
            serial_puts("\n");
            return 1;
        }
        g_err = "HDA: кодек не ответил";
        serial_puts("[sound] HDA-контроллер есть, кодек не ответил\n");
        return 0;
    }
    g_err = "нет HDA/ES137x на PCI";
    serial_puts("[sound] звуковых устройств не найдено (PCI)\n");
    return 0;
}

/* ---------- четверть-волновая таблица: sin(i*pi/512), Q15 ---------- */
static const i16 g_sin_q15[129] = {
    0, 201, 402, 603, 804, 1005, 1206, 1407, 1608,
    1809, 2009, 2210, 2410, 2611, 2811, 3012, 3212, 3412,
    3612, 3811, 4011, 4210, 4410, 4609, 4808, 5007, 5205,
    5404, 5602, 5800, 5998, 6195, 6393, 6590, 6786, 6983,
    7179, 7375, 7571, 7767, 7962, 8157, 8351, 8545, 8739,
    8933, 9126, 9319, 9512, 9704, 9896, 10087, 10278, 10469,
    10659, 10849, 11039, 11228, 11417, 11605, 11793, 11980, 12167,
    12353, 12539, 12725, 12910, 13094, 13279, 13462, 13645, 13828,
    14010, 14191, 14372, 14553, 14732, 14912, 15090, 15269, 15446,
    15623, 15800, 15976, 16151, 16325, 16499, 16673, 16846, 17018,
    17189, 17360, 17530, 17700, 17869, 18037, 18204, 18371, 18537,
    18703, 18868, 19032, 19195, 19357, 19519, 19680, 19841, 20000,
    20159, 20317, 20475, 20631, 20787, 20942, 21096, 21250, 21403,
    21554, 21705, 21856, 22005, 22154, 22301, 22448, 22594, 22739,
    22884, 23027, 23170
};

/* один отсчёт синуса: phase 0..2^32 отображается в 0..2*pi */
static inline i16 sine_at(u32 phase)
{
    u32 idx = phase >> 23;              /* 0..511 (512 четвертей по 128) */
    i16 v;
    switch (idx >> 7) {                 /* квадрант */
    default:
    case 0: v =  g_sin_q15[idx & 127]; break;
    case 1: v =  g_sin_q15[128 - (idx & 127)]; break;
    case 2: v = -g_sin_q15[idx & 127]; break;
    case 3: v = -g_sin_q15[128 - (idx & 127)]; break;
    }
    return (i16)((v * 14000) >> 15);    /* ~43% полной шкалы (комфортно) */
}

/* Заполнить кольцо: ЦЕЛОЕ число периодов => бесшовный луп.
 * frames выбирается вызывающим (sound_beep: rate/freq округлённо). */
static void fill_tone(i16 *buf, u32 frames, u32 rate, u32 freq)
{
    u32 dphase = (u32)(((u64)freq << 32) / rate);
    u32 phase = 0;
    for (u32 i = 0; i < frames; i++) {
        i16 v = sine_at(phase);
        buf[2 * i]     = v;
        buf[2 * i + 1] = v;
        phase += dphase;
    }
}

int sound_beep(u32 freq_hz, u32 ms)
{
    if (g_driver == 0) { g_err = "нет HDA/ES137x на PCI"; return -1; }
    if (freq_hz < 20 || freq_hz > 15000) freq_hz = 440;
    if (ms == 0) ms = 100;

    /* ES1371/ES1370 работают на 44100, HDA — на 48000 (оба — целые
     * периоды) */
    u32 rate = (g_driver == 3) ? 48000 : 44100;
    u32 frames = (rate + freq_hz / 2) / freq_hz;
    if (frames < 16) frames = 16;
    if (frames > rate) frames = rate;
    /* Сессия 58: кольцо драйвера не больше 64 КиБ (16384 фрейма) —
     * усечение ДО заполнения, чтобы в кольце осталось ЦЕЛОЕ число
     * периодов (иначе щелчок на стыке лупа) */
    if (frames > 16384) frames = 16384;

    u32 bytes = frames * 4;               /* 16-bit stereo */
    i16 *buf = (i16 *)malloc(bytes);
    if (!buf) { g_err = "нет памяти под буфер"; return -1; }
    fill_tone(buf, frames, rate, freq_hz);

    int rc;
    if (g_driver == 1)
        rc = snd_es1371_play(buf, frames, rate, ms);
    else if (g_driver == 2)
        rc = snd_es1370_play(buf, frames, rate, ms);
    else
        rc = snd_hda_play(buf, frames, rate, ms);
    free(buf);
    if (rc == 0) g_err = "ok";
    return rc;
}

int sound_test_melody(void)
{
    /* Ноты подобраны так, что при обоих rate (44100 и 48000) в кольцо
     * помещается ЦЕЛОЕ число кадров периода (например 480 Гц: 92 кадра
     * при 44100, 100 кадров при 48000) — стык лупа бесшовный. */
    static const struct { u32 f, ms; } notes[] = {
        { 480, 160 },    /* A4 */
        { 600, 160 },    /* ~D5 */
        { 800, 160 },    /* ~G5 */
        { 960, 240 },    /* ~B5 */
    };
    for (int i = 0; i < 4; i++) {
        int rc = sound_beep(notes[i].f, notes[i].ms);
        if (rc != 0) return rc;
        task_msleep(30);
    }
    return 0;
}

/* ================= потоковое воспроизведение (сессия 60) ================= */

u32 sound_stream_rate(void)
{
    if (g_driver == 1 || g_driver == 2) return 44100;   /* ES1371/ES1370 */
    if (g_driver == 3) return 48000;                    /* Intel HDA */
    return 0;
}

int sound_stream_chunk(const i16 *stereo, u32 frames)
{
    if (g_driver == 0 || !stereo || frames < 8) {
        g_err = "нет HDA/ES137x на PCI";
        return -1;
    }
    int rc;
    if (g_driver == 1)
        rc = snd_es1371_stream(stereo, frames, 44100);
    else if (g_driver == 2)
        rc = snd_es1370_stream(stereo, frames, 44100);
    else
        rc = snd_hda_stream(stereo, frames, 48000);
    if (rc == 0) g_err = "ok";
    return rc;
}

void sound_stream_pause(int on)
{
    if (g_driver == 1)      snd_es1371_stream_pause(on);
    else if (g_driver == 2) snd_es1370_stream_pause(on);
    else if (g_driver == 3) snd_hda_stream_pause(on);
}

void sound_stream_stop(void)
{
    if (g_driver == 1)      snd_es1371_stream_stop();
    else if (g_driver == 2) snd_es1370_stream_stop();
    else if (g_driver == 3) snd_hda_stream_stop();
}
