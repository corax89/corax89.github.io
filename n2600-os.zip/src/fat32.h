/* fat32.h — чтение FAT32-раздела */
#ifndef FAT32_H
#define FAT32_H

#include "types.h"

#define FAT32_NAME_MAX 255

typedef struct {
    char name[FAT32_NAME_MAX + 1];  /* UTF-8, длинное имя если есть */
    u8   attr;                       /* 0x10 — каталог */
    u32  size;
    u32  first_cluster;
} fat32_dirent_t;

int  fat32_init(void);
int  fat32_ready(void);
u32  fat32_root_cluster(void);

/* Перечислить содержимое каталога (без "." и ".."), до max записей. */
int  fat32_list(u32 dir_cluster, fat32_dirent_t *out, int max);

/* Прочитать файл (не более max байт). Возвращает число прочитанных байт. */
u32  fat32_read_file(u32 first_cluster, u32 size, void *buf, u32 max);

const char *fat32_label(void);

#endif