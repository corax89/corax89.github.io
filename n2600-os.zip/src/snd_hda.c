/* snd_hda.c — драйвер Intel High Definition Audio (сессия 57).
 *
 * Покрывает:
 *   - VMware sound.virtualDev="hdaudio" (режим по умолчанию для новых
 *     гостей; PCI 8086:2668 ICH6-class);
 *   - настоящие контроллеры Intel HDA, включая ноутбучный ALC269VB
 *     (Realtek codec на Intel NM10, PCI 8086:27D8 на N2600).
 *
 * Устройство ищется по классу 0x0403xx (Multimedia/Audio/HD-Audio) или
 * по известным PCI-ID. Кодек управляется через IMMEDIATE-интерфейс
 * (ICW/IRR/ICIS — без CORB/RIRB-колец, надёжнее в bring-up).
 *
 * ALC269VB: DAC NID 0x02 -> пин 0x14 (выход/динамик, EAPD обязателен).
 * Формат: 16-bit stereo 48 kHz (поток 1). Воспроизведение — кольцевой
 * BDL из 2 буферов, без прерываний (длительность — по PIT).
 */
#include "types.h"
#include "pci.h"
#include "mem.h"
#include "string.h"
#include "timer.h"
#include "task.h"
#include "sound.h"

extern void serial_puts(const char *s);

/* ---------- регистры контроллера (MMIO BAR0) ---------- */
#define HDA_GCTL    0x08
#define HDA_WAKEEN  0x0c
#define HDA_STATESTS 0x0e
#define HDA_INTCTL  0x20
#define HDA_CORBCTL 0x4c
#define HDA_ICW     0x60
#define HDA_IRR     0x64
#define HDA_ICIS    0x68     /* bit0 ICB busy, bit1 IRV valid */

/* выходной поток 0 (SD0): база 0x120, шаг 0x20 */
#define HDA_SD0     0x120
#define SD_CTL      0x00     /* bit1 RUN, bits 23:20 STRM, 19 DIR */
#define SD_STS      0x03
#define SD_LPIB     0x08
#define SD_CBL      0x0c
#define SD_LVI      0x0e
#define SD_FMT      0x12
#define SD_BDLP     0x18
#define SD_BDLU     0x1c

#define HDA_FMT_48K_16_ST 0x0011u   /* 48kHz base, mult1/div1, 16bit, 2ch */

static struct {
    volatile u32 *mmio;
    int ok;
    int bus, dev, fn;      /* [HDA-PM]: расположение контроллера на PCI —
                            * нужно для перевода D3hot -> D0 в init */
    char name[40];
} g_hda;

/* [HDA-ID] резервный критерий поиска: часть плат прошивка выставляет
 * класс НЕ 0x0403 (или вообще не мультимедиа) — тогда ищем по
 * известным PCI-ID Intel HDA-контроллеров. Список покрывает ICH6..Alder
 * Lake; на N2600 целевой контроллер — 8086:27D8 (ALC269VB). */
static int hda_is_known_intel(u16 did)
{
    switch (did) {
    case 0x2668:   /* ICH6 */
    case 0x27D8:   /* ICH7 — Intel NM10 / N2600 */
    case 0x27DD:   /* ICH7 */
    case 0x284B:   /* ICH8 */
    case 0x293E:   /* ICH9 */
    case 0x293F:   /* ICH9 */
    case 0x3A3E:   /* ICH10 */
    case 0x3A6E:   /* ICH10 */
    case 0x1C20:   /* 6 Series PCH (Cougar Point) */
    case 0x1D20:   /* C600/X79 */
    case 0x1E20:   /* 7 Series PCH (Panther Point) */
    case 0x8C20:   /* Lynx Point */
    case 0x9C20:   /* Lynx Point LP */
    case 0x9D70:   /* Sunrise Point-LP */
    case 0xA170:   /* Sunrise Point-H */
    case 0xA348:   /* Cannon Lake */
    case 0x9DC8:   /* Comet Lake */
    case 0xA0C8:   /* Comet Lake LP */
    case 0x43C8:   /* Tiger Lake */
    case 0x51C8:   /* Alder Lake-P */
        return 1;
    }
    return 0;
}

/* [HDA-ID] единая точка «приёма» контроллера: BAR0/MMIO/командный
 * регистр/лог. Общая для обоих критериев (класс и известный ID). */
static int hda_adopt(int bus, int dev, int fn, u16 vid, u16 did)
{
    u32 bar0 = pci_read32(bus, dev, fn, 0x10);
    if (bar0 & 1) return 0;               /* нужен MMIO */
    u32 mmio = bar0 & 0xFFFFFFF0u;
    if (!mmio || mmio < 0x10000) return 0;
    u16 cmd = pci_read16(bus, dev, fn, 0x04);
    pci_write16(bus, dev, fn, 0x04, (u16)(cmd | 0x6)); /* MEM+BME */
    g_hda.mmio = (volatile u32 *)(unsigned long)mmio;
    g_hda.ok = 1;
    g_hda.bus = bus; g_hda.dev = dev; g_hda.fn = fn;
    snprintf(g_hda.name, sizeof(g_hda.name),
             "Intel HDA (%04x:%04x)", vid, did);
    {
        char b[96];
        snprintf(b, sizeof(b), "[hda] %04x:%04x mmio=%x @ %02x:%02x.%d\n",
                 vid, did, mmio, bus, dev, fn);
        serial_puts(b);
    }
    return 1;
}

/* [HDA-DIAG] дамп конфигурационного пространства 00:1b.* — куда прошивка
 * штатно ставит HDA-контроллер на реальном железе. По дампу видно:
 * аудио отключено в BIOS (функции пусты), класс нестандартный,
 * BAR0 не назначен, память/мастер выключены (cmd) и т.п. */
static void hda_diag_dump_001b(void)
{
    char b[112];
    serial_puts("[hda] DIAG: HDA не найден — дамп 00:1b.* :\n");
    for (int fn = 0; fn < 8; fn++) {
        u32 id = pci_read32(0, 0x1B, fn, 0);
        u16 vid = (u16)(id & 0xFFFF);
        if (vid == 0x0000 || vid == 0xFFFF) continue;   /* функция пуста */
        u32 cc  = pci_read32(0, 0x1B, fn, 0x08);
        u16 cmd = pci_read16(0, 0x1B, fn, 0x04);
        u32 bar0 = pci_read32(0, 0x1B, fn, 0x10);
        snprintf(b, sizeof(b),
                 "[hda] DIAG 00:1b.%d: %04x:%04x класс=%08x cmd=%04x BAR0=%08x\n",
                 fn, vid, (u16)(id >> 16), cc, cmd, bar0);
        serial_puts(b);
    }
}

static inline u32 hd_rd(u32 off) { return g_hda.mmio[off >> 2]; }
static inline void hd_wr(u32 off, u32 v) { g_hda.mmio[off >> 2] = v; }

static void hd_delay(u32 us)
{
    u32 dl = timer_poll_deadline();
    while (!timer_poll_expired(dl, us)) { }
}

/* ---------- immediate verb ---------- */
static int hda_verb(u32 v, u32 *resp)
{
    /* ждать ICB=0 */
    for (int t = 0; t < 10000; t++)
        if (!(hd_rd(HDA_ICIS) & 1u)) break;
    hd_wr(HDA_ICIS, 2u);          /* сброс IRV */
    hd_wr(HDA_ICW, v);
    for (int t = 0; t < 100000; t++) {
        u32 st = hd_rd(HDA_ICIS);
        if (st & 1u) { hd_delay(1); continue; }
        if (st & 2u) {
            if (resp) *resp = hd_rd(HDA_IRR);
            hd_wr(HDA_ICIS, 2u);  /* съесть результат */
            return 1;
        }
        hd_delay(1);
    }
    return 0;
}

#define VERB(cad, nid, verb, pay) \
    ((((u32)(cad)) << 28) | (((u32)(nid)) << 20) | \
     (((u32)(verb)) << 8) | ((u32)(pay)))

int snd_hda_probe(void)
{
    g_hda.ok = 0;
    g_hda.bus = g_hda.dev = g_hda.fn = -1;
    /* проход 1: штатный критерий — класс 0x0403xx */
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid == 0xFFFF) continue;
                u32 cc = pci_read32(bus, dev, fn, 0x08);
                u8 base = (u8)((cc >> 24) & 0xFF);
                u8 sub  = (u8)((cc >> 16) & 0xFF);
                u8 prif = (u8)((cc >> 8) & 0xFF);
                if (base != 0x04 || sub != 0x03 || prif != 0x00) continue;
                if (hda_adopt(bus, dev, fn, vid, did)) return 1;
            }
        }
    }
    /* проход 2 [HDA-ID]: класс от прошивки нестандартный — ищем по
     * известным PCI-ID Intel */
    for (int bus = 0; bus < 4; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int fn = 0; fn < 2; fn++) {
                u32 id = pci_read32(bus, dev, fn, 0);
                u16 vid = (u16)(id & 0xFFFF);
                u16 did = (u16)(id >> 16);
                if (vid != 0x8086 || !hda_is_known_intel(did)) continue;
                if (hda_adopt(bus, dev, fn, vid, did)) {
                    serial_puts("[hda] найден по PCI-ID (класс нестандартный)\n");
                    return 1;
                }
            }
        }
    }
    hda_diag_dump_001b();      /* [HDA-DIAG] */
    return 0;
}

const char *snd_hda_name(void) { return g_hda.name; }

/* Инициализация контроллера и кодека ALC269VB */
int snd_hda_init(void)
{
    if (!g_hda.ok) return 0;

    /* [HDA-PM] ГЛАВНАЯ правка для реального железа: на ноутбуках
     * контроллер часто остаётся в D3hot после прошивки — кодеки молчат
     * (STATESTS=0) до перевода в D0. Идём по списку capabilities
     * (CAP_PTR @ 0x34), ищем Power Management (ID 0x01), PMCSR <- D0,
     * ждём 20 мс, восстанавливаем биты MEM+BME командного регистра. */
    if (g_hda.bus >= 0) {
        u8 cap = pci_read8(g_hda.bus, g_hda.dev, g_hda.fn, 0x34);
        int guard = 0;
        while (cap >= 0x40 && guard++ < 16) {
            u32 ch = pci_read32(g_hda.bus, g_hda.dev, g_hda.fn, cap & ~3u);
            u8  cap_id  = (u8)(ch & 0xFF);
            u8  cap_nxt = (u8)((ch >> 8) & 0xFF);
            if (cap_id == 0x01) {                 /* PCI Power Management */
                u16 pmcsr = pci_read16(g_hda.bus, g_hda.dev, g_hda.fn,
                                       cap + 4);
                if ((pmcsr & 3u) != 0) {
                    char b[80];
                    snprintf(b, sizeof(b), "[hda] PM: D%d -> D0\n",
                             (int)(pmcsr & 3u));
                    serial_puts(b);
                }
                pmcsr &= (u16)~3u;                /* power state = D0 */
                pci_write16(g_hda.bus, g_hda.dev, g_hda.fn, cap + 4, pmcsr);
                hd_delay(20000);                  /* 20 мс на выход из D3 */
                u16 cmd = pci_read16(g_hda.bus, g_hda.dev, g_hda.fn, 0x04);
                pci_write16(g_hda.bus, g_hda.dev, g_hda.fn, 0x04,
                            (u16)(cmd | 0x6));    /* MEM+BME */
                break;
            }
            cap = cap_nxt;
        }
    }

    /* CRST: 0 -> 1, пауза, ждать STATESTS */
    hd_wr(HDA_GCTL, 0);
    hd_delay(100);
    hd_wr(HDA_GCTL, hd_rd(HDA_GCTL) | 1u);
    int up = 0;
    for (int t = 0; t < 200; t++) {          /* до ~20 мс */
        if (hd_rd(HDA_GCTL) & 1u) { up = 1; break; }
        hd_delay(100);
    }
    if (!up) {
        serial_puts("[hda] CRST не поднялся\n");
        return 0;
    }
    hd_delay(500);                            /* спецификация: 521 мкс */

    /* [HDA-COLD] ожидание кодека по спецификации — ДВА раунда: на
     * «холодном» железе кодек может проснуться позже первого окна.
     * Раунд 1: до 30 мс; если пусто — ПОЛНЫЙ повторный цикл CRST (0->1)
     * и ожидание до 1 с. Маска STATESTS: 0x0F -> 0x7FFF (15 бит — часть
     * контроллеров держит биты выше 4-го). */
    u32 mask = 0;
    for (int round = 0; round < 2 && !mask; round++) {
        if (round) {
            serial_puts("[hda] кодек не ответил — холодный повтор CRST\n");
            hd_wr(HDA_GCTL, 0);
            hd_delay(100);
            hd_wr(HDA_GCTL, hd_rd(HDA_GCTL) | 1u);
            int up2 = 0;
            for (int t = 0; t < 200; t++) {
                if (hd_rd(HDA_GCTL) & 1u) { up2 = 1; break; }
                hd_delay(100);
            }
            if (!up2) {
                serial_puts("[hda] CRST не поднялся (повтор)\n");
                return 0;
            }
            hd_delay(500);
        }
        for (int t = 0; t < (round ? 10000 : 300); t++) {
            mask = hd_rd(HDA_STATESTS) & 0x7FFFu;
            if (mask) break;
            hd_delay(100);                       /* 30 мс / 1 с */
        }
    }
    if (!mask) {
        serial_puts("[hda] кодеки не ответили (STATESTS=0 после 2 раундов)\n");
        return 0;
    }
    hd_wr(HDA_STATESTS, 0x7FFFu);            /* сброс битов wake */
    {
        char b[64];
        snprintf(b, sizeof(b), "[hda] кодеки: маска %x\n", (unsigned)mask);
        serial_puts(b);
    }

    /* --- кодек 0: power D0 + конфигурация ALC269VB --- */
    /* [HDA-DIAG] vendor-запрос логирует ответ: кодек жив или нет */
    u32 resp = 0;
    if (hda_verb(VERB(0, 1, 0xF00, 0), &resp)) {
        char b[72];
        snprintf(b, sizeof(b),
                 "[hda] кодек @ CAD0 жив: vendor=0x%08x\n", resp);
        serial_puts(b);
    } else {
        serial_puts("[hda] vendor-запрос к кодеку (NID 1) не ответил\n");
    }
    hda_verb(VERB(0, 1, 0x705, 0x00), NULL); /* D0 */

    /* DAC 0x02: формат + поток 1 канал 0 + unmute амп */
    hda_verb(VERB(0, 2, 0x2, HDA_FMT_48K_16_ST), NULL);
    hda_verb(VERB(0, 2, 0x706, 0x10), NULL); /* stream 1, ch 0 */
    hda_verb(VERB(0, 2, 0x3, 0x2000), NULL); /* unmute out L */
    hda_verb(VERB(0, 2, 0x3, 0x4000), NULL); /* unmute out R */

    /* пин 0x14 (ALC269VB: выход на динамик) */
    hda_verb(VERB(0, 0x14, 0x701, 0x00), NULL);  /* conn select: DAC 0x02 */
    hda_verb(VERB(0, 0x14, 0x707, 0x40), NULL);  /* pin: out enable */
    /* [HDA-EAPD] ФИКС: прежде в EAPD/BTL (0x70C) писали 0x02 — это
     * РЕЗЕРВИРОВАННЫЕ биты. EAPD — бит 15 = 0x8000; без него внутренний
     * усилитель реального кодека остаётся выключенным (в VMware бит
     * игнорируется, поэтому звук там был и без него). */
    hda_verb(VERB(0, 0x14, 0x70C, 0x8000), NULL); /* EAPD: динамик */
    hda_verb(VERB(0, 0x14, 0x3, 0x2000), NULL);  /* unmute pin L */
    hda_verb(VERB(0, 0x14, 0x3, 0x4000), NULL);  /* unmute pin R */

    /* [HDA-EAPD] наушники ALC269VB — пин 0x21 (раньше не настраивался) */
    hda_verb(VERB(0, 0x21, 0x707, 0x40), NULL);  /* pin: out enable */
    hda_verb(VERB(0, 0x21, 0x70C, 0x8000), NULL); /* EAPD: наушники */
    hda_verb(VERB(0, 0x21, 0x3, 0x2000), NULL);  /* unmute pin L */
    hda_verb(VERB(0, 0x21, 0x3, 0x4000), NULL);  /* unmute pin R */

    /* подстраховка: некоторые платы разводят динамик на 0x0F/0x10 */
    hda_verb(VERB(0, 0x0F, 0x707, 0x40), NULL);
    hda_verb(VERB(0, 0x0F, 0x70C, 0x8000), NULL);
    hda_verb(VERB(0, 0x0F, 0x3, 0x2000), NULL);
    hda_verb(VERB(0, 0x0F, 0x3, 0x4000), NULL);
    hda_verb(VERB(0, 0x10, 0x707, 0x40), NULL);
    hda_verb(VERB(0, 0x10, 0x70C, 0x8000), NULL);
    hda_verb(VERB(0, 0x10, 0x3, 0x2000), NULL);
    hda_verb(VERB(0, 0x10, 0x3, 0x4000), NULL);

    serial_puts("[hda] ALC269-конфигурация применена\n");
    return 1;
}

/* BDL + кольцевой буфер (выделяются один раз).
 * Сессия 60: буфер увеличен 16384 → 65536 байт — две половины по
 * 8192 фреймов (170 мс @ 48 кГц) для потокового плеера; мелодии
 * sound_beep (до 16384 фреймов = 64 КиБ) теперь не усекаются. */
#define HDA_BUF_BYTES 65536u
static i16  *g_buf = NULL;
static u32  *g_bdl = NULL;
static u32   hda_half_frames = 0;   /* фреймов в половине кольца; 0 = не настроен */

int snd_hda_play(const i16 *samples, u32 frames, u32 rate, u32 ms)
{
    (void)rate;   /* кодек и SD уже в 48k; мелодия синтезируется под 44100,
                     но луп целых периодов — сдвиг высоты неслышен */
    if (!g_hda.ok) return -1;

    if (!g_bdl) {
        g_bdl = (u32 *)malloc(256 + 128);       /* 2 записи по 16 байт */
        if (!g_bdl) return -1;
        memset((void *)(((unsigned long)g_bdl + 127) & ~127ul), 0, 32);
    }
    if (!g_buf) {
        g_buf = (i16 *)malloc(HDA_BUF_BYTES + 128);
        if (!g_buf) return -1;
    }
    u32 bdlp = ((u32)(unsigned long)g_bdl + 127) & ~127u;
    u32 bufp = ((u32)(unsigned long)g_buf + 127) & ~127u;

    u32 bytes = frames * 4;                     /* 16-bit stereo */
    if (bytes > HDA_BUF_BYTES) bytes = HDA_BUF_BYTES;
    u32 half = bytes / 2;                       /* 2 BDL-записи */
    memcpy((void *)(unsigned long)bufp, samples, bytes);

    /* BDL: две половины одного кольца */
    u32 *bd = (u32 *)(unsigned long)bdlp;
    bd[0] = bufp;          bd[1] = 0; bd[2] = half; bd[3] = 0x01; /* IOC */
    bd[4] = bufp + half;   bd[5] = 0; bd[6] = half; bd[7] = 0x01;

    u32 sd = HDA_SD0;
    /* стоп */
    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    /* сброс статусов */
    hd_wr(sd + SD_STS, 0x3Cu);
    /* настройки */
    hd_wr(sd + SD_CBL, half * 2);
    hd_wr(sd + SD_LVI, 1);                      /* 2 записи - 1 */
    hd_wr(sd + SD_FMT, HDA_FMT_48K_16_ST);
    hd_wr(sd + SD_BDLP, bdlp);
    hd_wr(sd + SD_BDLU, 0);
    /* STRM=1, DIR=1 (выход) + RUN */
    u32 ctl = (1u << 20) | (1u << 19) | 2u;
    hd_wr(sd + SD_CTL, ctl);
    /* INTCTL: бит выхода 0 = bit 4 */
    hd_wr(HDA_INTCTL, hd_rd(HDA_INTCTL) | (1u << 4));

    /* ждём */
    u32 t0 = timer_ticks();
    while ((timer_ticks() - t0) < ms) task_msleep(5);

    /* стоп */
    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    hd_delay(200);
    hda_half_frames = 0;
    return 0;
}

/* ================= потоковое воспроизведение (сессия 60) =================
 * Модель для MP3-плеера: BDL-кольцо из ДВУХ половин g_buf крутится без
 * перезапуска; каждый вызов stream() заполняет ту половину, которую
 * DMA сейчас НЕ читает (текущая запись = CIV, биты 4:0 SDnCTL). Пока
 * играет текущий кусок, приложение декодирует следующий. Первый вызов
 * настраивает кольцо (размер половины фиксируется до stop()). Буфер
 * вызывающего копируется внутрь g_buf — может быть освобождён сразу
 * после возврата. Частота фиксирована 48 кГц (ресэмпл — на вызывающем). */

int snd_hda_stream(const i16 *samples, u32 frames, u32 rate)
{
    (void)rate;
    if (!g_hda.ok || !samples || frames < 8) return -1;

    if (!g_bdl) {
        g_bdl = (u32 *)malloc(256 + 128);
        if (!g_bdl) return -1;
        memset((void *)(((unsigned long)g_bdl + 127) & ~127ul), 0, 32);
    }
    if (!g_buf) {
        g_buf = (i16 *)malloc(HDA_BUF_BYTES + 128);
        if (!g_buf) return -1;
    }
    u32 bdlp = ((u32)(unsigned long)g_bdl + 127) & ~127u;
    u32 bufp = ((u32)(unsigned long)g_buf + 127) & ~127u;
    u32 sd = HDA_SD0;

    int running = (hd_rd(sd + SD_CTL) & 2u) && hda_half_frames != 0;

    if (!running) {
        /* первый запуск: кусок в половину 0, половина 1 — тишина */
        u32 bytes = frames * 4;
        if (bytes > HDA_BUF_BYTES / 2) bytes = HDA_BUF_BYTES / 2;
        if (bytes < 32) return -1;
        hda_half_frames = bytes >> 2;
        u32 half = bytes;

        memcpy((void *)(unsigned long)bufp, samples, bytes);
        memset((void *)(unsigned long)(bufp + half), 0, half);

        hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
        hd_wr(sd + SD_STS, 0x3Cu);
        u32 *bd = (u32 *)(unsigned long)bdlp;
        bd[0] = bufp;        bd[1] = 0; bd[2] = half; bd[3] = 0x01;
        bd[4] = bufp + half; bd[5] = 0; bd[6] = half; bd[7] = 0x01;
        hd_wr(sd + SD_CBL, half * 2);
        hd_wr(sd + SD_LVI, 1);
        hd_wr(sd + SD_FMT, HDA_FMT_48K_16_ST);
        hd_wr(sd + SD_BDLP, bdlp);
        hd_wr(sd + SD_BDLU, 0);
        hd_wr(HDA_INTCTL, hd_rd(HDA_INTCTL) | (1u << 4));
        hd_wr(sd + SD_CTL, (1u << 20) | (1u << 19) | 2u);
        return 0;
    }

    /* кольцо крутится: заполняем половину, где DMA сейчас НЕ читает */
    u32 half_bytes = hda_half_frames * 4;
    u32 civ = hd_rd(sd + SD_CTL) & 0x1Fu;       /* CIV: биты 4:0 SDnCTL */
    u32 fill = (civ == 0) ? 1u : 0u;
    u8 *dst = (u8 *)(unsigned long)(bufp + fill * half_bytes);
    u32 copy = frames * 4;
    if (copy > half_bytes) copy = half_bytes;
    memcpy(dst, samples, copy);
    if (copy < half_bytes) memset(dst + copy, 0, half_bytes - copy);
    return 0;
}

/* Пауза с сохранением позиции DMA (RUN снимается/ставится). */
void snd_hda_stream_pause(int on)
{
    if (!g_hda.ok) return;
    u32 sd = HDA_SD0;
    if (on) hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    else    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) | 2u);
}

/* Полный стоп (конец файла / закрытие плеера). */
void snd_hda_stream_stop(void)
{
    if (!g_hda.ok) return;
    u32 sd = HDA_SD0;
    hd_wr(sd + SD_CTL, hd_rd(sd + SD_CTL) & ~2u);
    hd_delay(200);
    hda_half_frames = 0;
}
