/* iso9660.h — начальная поддержка файловой системы ISO 9660 (только чтение) */
#ifndef ISO9660_H
#define ISO9660_H

#include "types.h"

#define ISO9660_NAME_MAX 255

typedef struct {
    char name[ISO9660_NAME_MAX + 1];
    u8   is_dir;      /* 1 = каталог, 0 = файл */
    u32  size;
    u32  first_lba;   /* Логический адрес (LBA) первого блока (2048 байт) */
} iso9660_dirent_t;

/* Инициализация ISO 9660. Читает PVD и проверяет сигнатуру "CD001". */
int  iso9660_init(void);
int  iso9660_ready(void);

/* Прочитать корневой каталог. Возвращает количество найденных записей. */
int  iso9660_list_root(iso9660_dirent_t *out, int max);

/* Прочитать файл в буфер. Возвращает количество прочитанных байт. */
u32  iso9660_read_file(u32 first_lba, u32 size, void *buf, u32 max);

#endif