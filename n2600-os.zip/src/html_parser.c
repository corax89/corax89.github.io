/*
 * html_parser.c — Простой парсер HTML с низким потреблением памяти
 *
 * Архитектура:
 *   - Потоковый (streaming) парсинг через html_parse_begin/stream/end
 *   - In-place модификация буфера: текстовые узлы ссылаются прямо в буфер
 *     (zero-copy), строки атрибутов — через strdup
 *   - Компактный парсер: один проход по данным, O(depth) стек
 *   - Поддержка: теги, атрибуты, комментарии, DOCTYPE, CDATA,
 *     self-closing теги, незакрытые теги (авто-закрытие)
 *
 * [OPT] Внесены оптимизации для укладки в 16 МБ ОЗУ:
 *   - текстовые узлы забирают владение буфером (без strdup);
 *   - <script>/<style> не порождают дочерних узлов;
 *   - атрибуты не копируются дважды;
 *   - <template> и HTML5-void-теги распознаются по имени;
 *   - <pre> даёт один текстовый узел с \n (без <br> на строку);
 *   - статические visited-массивы вынесены за #ifdef HTML_DEBUG;
 *   - MAX_PARSE_DEPTH увеличен с 64 до 128.
 */

#include "html_parser.h"

/* ── Task 60 [HP-KERNEL]: портирование на freestanding-ядро N2600-OS.
 * Исходная версия собиралась только на хосте (<stdio.h>/<stdlib.h>/
 * <ctype.h>). В ядре: malloc/free — mem.h, строки — string.h; недостающие
 * calloc/realloc/strncasecmp/isspace/strdup — локальные шимы (тот же
 * приём, что ed_xrealloc в editor.c и stbi_krealloc в stb_image.c). */
#ifdef HOST_TEST
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>   /* strncasecmp (POSIX; в glibc не всегда виден из <string.h>) */
#include <ctype.h>
#else /* freestanding ядро N2600-OS */
#include "mem.h"
#include "string.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

static int hp_isspace(int c)
{
    return c == ' ' || c == '\t' || c == '\n' ||
           c == '\r' || c == '\v' || c == '\f';
}
#define isspace(c) hp_isspace((unsigned char)(c))

static int hp_strncasecmp(const char *a, const char *b, u32 n)
{
    for (u32 i = 0; i < n; i++) {
        unsigned char ca = (unsigned char)a[i];
        unsigned char cb = (unsigned char)b[i];
        if (ca >= 'A' && ca <= 'Z') ca = (unsigned char)(ca | 0x20);
        if (cb >= 'A' && cb <= 'Z') cb = (unsigned char)(cb | 0x20);
        if (ca != cb) return (int)ca - (int)cb;
        if (ca == 0) return 0;
    }
    return 0;
}
#define strncasecmp hp_strncasecmp

static char *hp_strdup(const char *s)
{
    u32 n = (u32)strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (p) memcpy(p, s, n);
    return p;
}
#define strdup hp_strdup

static void *hp_calloc(u32 n, u32 sz)
{
    char *p = (char *)malloc(n * sz);
    if (p) memset(p, 0, n * sz);
    return p;
}
#define calloc hp_calloc

/* realloc нет в mem.h — как в editor.c: malloc+копия+free. p == NULL —
 * как malloc; new_n == 0 — как free (NULL). ВАЖНО: old_n обязан быть
 * РЕАЛЬНОЙ старой ёмкостью блока (копируем min(old_n,new_n) — меньше
 * нельзя, больше — чтение за границей блока). */
static void *hp_realloc(void *p, u32 old_n, u32 new_n)
{
    void *q;
    if (new_n == 0) {
        if (p) free(p);
        return NULL;
    }
    q = malloc(new_n);
    if (!q) return NULL;
    if (p) {
        u32 cp = old_n < new_n ? old_n : new_n;
        memcpy(q, p, cp);
        free(p);
    }
    return q;
}
#define HP_REALLOC(p, old_n, new_n) hp_realloc((p), (u32)(old_n), (u32)(new_n))

#endif /* HOST_TEST */

/* Единая точка realloc: в HOST_TEST — libc, в ядре — hp_realloc с явной
 * старой ёмкостью (см. шим выше). */
#ifndef HP_REALLOC
#define HP_REALLOC(p, old_n, new_n) realloc((p), (size_t)(new_n))
#endif
/* ═══════════════════════════════════════════════════════
   Внутренние структуры парсера
   ═══════════════════════════════════════════════════════ */

/* [OPT] 64 → 128: SPA-разметка (React/Vue/Angular) часто уходит глубже 64. */
#define MAX_PARSE_DEPTH 128

/* Task 66 [HP-STYLE-EOF]: лимит поиска закрывающего тега для
 * <style>/<template> и прочих skip-тегов УБРАН (был 64 КиБ):
 * ya.ru несёт <style> на 120 КиБ — парсер «сдавался» посреди CSS,
 * и хвост стиля (включая background-image:url("data:image/svg+xml,...")
 * с path-данными) РИСОВАЛСЯ как текст страницы («просачивание кода»).
 * Семантика HTML5: raw-text-элемент без закрытия длится ДО EOF —
 * реальные браузеры тоже прячут хвост. Скрытие до конца входа —
 * корректное поведение, а не потеря контента. */

struct HtmlParseState {
    HtmlElement*   root;          /* корень дерева (виртуальный) */
    HtmlElement*   current;       /* текущий открытый элемент */
    int            depth;         /* текущая глубина вложенности */
    HtmlElement*   stack[MAX_PARSE_DEPTH]; /* стек открытых элементов */

    /* Буфер для накопления текста между тегами */
    char*          text_buf;
    int            text_buf_len;
    int            text_buf_cap;

    /* Ссылка на оригинальный буфер потока (для zero-copy текста) */
    char*          stream_buffer;

    /* Счётчик глубины pre/code — когда > 0, пробелы сохраняются как есть */
    int            preserve_ws;

    /* ═══ Task 68 [HP-STREAM]: инкрементальная подача ═══
     * pend — ОДНА незавершённая конструкция от прошлого куска (тег без
     * '>', комментарий, <!DOCTYPE...): NUL-терминирована, достроится
     * следующим куском. raw_* — захват сырого содержимого
     * <script>/<textarea>/<style>/<template>... через границы кусков:
     * содержимое копится в raw_buf (script/textarea) или выбрасывается
     * (skip: 120-КиБ CSS ya.ru в память не попадает вовсе); raw_tail —
     * хвост до (T-1) байт, где может начинаться терминатор, рвущийся
     * на границе кусков. */
    char          *pend;
    int            pend_len;
    int            pend_cap;

    int            raw_kind;      /* HP_RAW_* */
    HtmlElement   *raw_el;        /* script/textarea: элемент-владелец */
    char           raw_tag[24];   /* skip: имя тега для </name> */
    char           raw_tail[32];  /* не-commitнутый хвост (поиск термин.) */
    int            raw_tail_len;
    char          *raw_buf;       /* script/textarea: накопленный код */
    int            raw_len;
    int            raw_cap;

    /* ═══ Task 68 [HP-EVENT]: событийный режим (без DOM) ═══ */
    const HtmlParseEvents *ev;
    void          *ev_ud;
};

/* режимы захвата сырого содержимого ([HP-STREAM]) */
#define HP_RAW_NONE      0
#define HP_RAW_SCRIPT    1   /* до "</script" + разделитель/'>' */
#define HP_RAW_TEXTAREA  2   /* до "</textarea" + разделитель/'>' */
#define HP_RAW_SKIP      3   /* до "</имя>" ТОЧНО (style/template/svg...) */

/* ═══════════════════════════════════════════════════════
   Таблицы имён тегов и атрибутов
   ═══════════════════════════════════════════════════════ */

typedef struct {
    const char* name;
    HtmlTag     tag;
} TagEntry;

static const TagEntry tag_table[] = {
    {"html",       HTML_TAG_HTML},
    {"head",       HTML_TAG_HEAD},
    {"title",      HTML_TAG_TITLE},
    {"body",       HTML_TAG_BODY},
    {"div",        HTML_TAG_DIV},
    {"span",       HTML_TAG_SPAN},
    {"p",          HTML_TAG_P},
    {"br",         HTML_TAG_BR},
    {"hr",         HTML_TAG_HR},
    {"h1",         HTML_TAG_H1},
    {"h2",         HTML_TAG_H2},
    {"h3",         HTML_TAG_H3},
    {"h4",         HTML_TAG_H4},
    {"h5",         HTML_TAG_H5},
    {"h6",         HTML_TAG_H6},
    {"a",          HTML_TAG_A},
    {"img",        HTML_TAG_IMG},
    {"table",      HTML_TAG_TABLE},
    {"thead",      HTML_TAG_THEAD},
    {"tbody",      HTML_TAG_TBODY},
    {"tfoot",      HTML_TAG_TFOOT},
    {"tr",         HTML_TAG_TR},
    {"td",         HTML_TAG_TD},
    {"th",         HTML_TAG_TH},
    {"ul",         HTML_TAG_UL},
    {"ol",         HTML_TAG_OL},
    {"li",         HTML_TAG_LI},
    {"form",       HTML_TAG_FORM},
    {"input",      HTML_TAG_INPUT},
    {"button",     HTML_TAG_BUTTON},
    {"select",     HTML_TAG_SELECT},
    {"option",     HTML_TAG_OPTION},
    {"textarea",   HTML_TAG_TEXTAREA},
    {"script",     HTML_TAG_SCRIPT},
    {"style",      HTML_TAG_STYLE},
    {"link",       HTML_TAG_LINK},
    {"meta",       HTML_TAG_META},
    {"pre",        HTML_TAG_PRE},
    {"code",       HTML_TAG_CODE},
    {"blockquote", HTML_TAG_BLOCKQUOTE},
    {"address",    HTML_TAG_ADDRESS},
    {"strong",     HTML_TAG_STRONG},
    {"em",         HTML_TAG_EM},
    {"b",          HTML_TAG_B},
    {"i",          HTML_TAG_I},
    {"u",          HTML_TAG_U},
    {"s",          HTML_TAG_S},
    {"sub",        HTML_TAG_SUB},
    {"sup",        HTML_TAG_SUP},
    {"label",      HTML_TAG_LABEL},
    {"canvas",     HTML_TAG_CANVAS},
    {"iframe",     HTML_TAG_IFRAME},
    {"kbd",        HTML_TAG_KBD},
    {"var",        HTML_TAG_VAR},
    {"samp",       HTML_TAG_SAMP},
    {"abbr",       HTML_TAG_ABBR},
    {"cite",       HTML_TAG_CITE},
    {"q",          HTML_TAG_Q},
    {"dfn",        HTML_TAG_DFN},
    {"small",      HTML_TAG_SMALL},
    {"big",        HTML_TAG_BIG},
    {"del",        HTML_TAG_DEL},
    {"ins",        HTML_TAG_INS},
    {"center",     HTML_TAG_CENTER},
    {"font",       HTML_TAG_FONT},
    {"base",       HTML_TAG_BASE},
    {"noscript",   HTML_TAG_NOSCRIPT},
    {"dt",         HTML_TAG_DT},
    {"dd",         HTML_TAG_DD},
    {"header",     HTML_TAG_HEADER},
    {"footer",     HTML_TAG_FOOTER},
    {"nav",        HTML_TAG_NAV},
    {"main",       HTML_TAG_MAIN},
    {"section",    HTML_TAG_SECTION},
    {"article",    HTML_TAG_ARTICLE},
    {"aside",      HTML_TAG_ASIDE},
    {"figure",     HTML_TAG_FIGURE},
    {"figcaption", HTML_TAG_FIGCAPTION},
    {"details",    HTML_TAG_DETAILS},
    {"summary",    HTML_TAG_SUMMARY},
    {"object",     HTML_TAG_OBJECT},
    /* [OPT] HTML5-теги без своих enum-значений: проходят как generic-
       контейнеры (HTML_TAG_UNKNOWN). Template обрабатывается по имени. */
    {"picture",    HTML_TAG_UNKNOWN},
    {"source",     HTML_TAG_UNKNOWN},
    {"template",   HTML_TAG_UNKNOWN},
    {"video",      HTML_TAG_UNKNOWN},
    {"audio",      HTML_TAG_UNKNOWN},
    {"track",      HTML_TAG_UNKNOWN},
    {"slot",       HTML_TAG_UNKNOWN},
    {"mark",       HTML_TAG_UNKNOWN},
    {"wbr",        HTML_TAG_UNKNOWN},
    {"time",       HTML_TAG_UNKNOWN},
    {"menu",       HTML_TAG_UNKNOWN},
    {"fieldset",   HTML_TAG_UNKNOWN},
    {"legend",     HTML_TAG_UNKNOWN},
    {"output",     HTML_TAG_UNKNOWN},
    {"progress",   HTML_TAG_UNKNOWN},
    {"meter",      HTML_TAG_UNKNOWN},
    {"ruby",       HTML_TAG_UNKNOWN},
    {"rt",         HTML_TAG_UNKNOWN},
    {"rp",         HTML_TAG_UNKNOWN},
    {"col",        HTML_TAG_UNKNOWN},
    {"area",       HTML_TAG_UNKNOWN},
    {"embed",      HTML_TAG_UNKNOWN},
    {"param",      HTML_TAG_UNKNOWN},
    /* SVG elements */
    {"svg",        HTML_TAG_SVG},
    {"rect",       HTML_TAG_RECT},
    {"circle",     HTML_TAG_CIRCLE},
    {"ellipse",    HTML_TAG_ELLIPSE},
    {"line",       HTML_TAG_LINE},
    {"polyline",   HTML_TAG_POLYLINE},
    {"polygon",    HTML_TAG_POLYGON},
    {"path",       HTML_TAG_PATH},
    {"g",          HTML_TAG_G},
    {"text",       HTML_TAG_TEXT},
    {"tspan",      HTML_TAG_TSPAN},
    {"defs",       HTML_TAG_DEFS},
    {"use",        HTML_TAG_USE},
    {NULL,         HTML_TAG_UNKNOWN}
};

typedef struct {
    const char*   name;
    HtmlAttribKey key;
} AttribEntry;

static const AttribEntry attrib_table[] = {
    {"id",          HTML_ATTRIB_ID},
    {"class",       HTML_ATTRIB_CLASS},
    {"style",       HTML_ATTRIB_STYLE},
    {"href",        HTML_ATTRIB_HREF},
    {"src",         HTML_ATTRIB_SRC},
    {"onclick",     HTML_ATTRIB_ONCLICK},
    {"onload",      HTML_ATTRIB_ONLOAD},
    {"onerror",     HTML_ATTRIB_ONERROR},
    {"width",       HTML_ATTRIB_WIDTH},
    {"height",      HTML_ATTRIB_HEIGHT},
    {"alt",         HTML_ATTRIB_ALT},
    {"title",       HTML_ATTRIB_TITLE},
    {"type",        HTML_ATTRIB_TYPE},
    {"name",        HTML_ATTRIB_NAME},
    {"value",       HTML_ATTRIB_VALUE},
    {"placeholder", HTML_ATTRIB_PLACEHOLDER},
    {"disabled",    HTML_ATTRIB_DISABLED},
    {"checked",     HTML_ATTRIB_CHECKED},
    {"selected",    HTML_ATTRIB_SELECTED},
    {"multiple",    HTML_ATTRIB_MULTIPLE},
    {"size",        HTML_ATTRIB_SIZE},
    {"maxlength",   HTML_ATTRIB_MAXLENGTH},
    {"min",         HTML_ATTRIB_MIN},
    {"max",         HTML_ATTRIB_MAX},
    {"step",        HTML_ATTRIB_STEP},
    {"rows",        HTML_ATTRIB_ROWS},
    {"cols",        HTML_ATTRIB_COLS},
    {"colspan",     HTML_ATTRIB_COLSPAN},
    {"rowspan",     HTML_ATTRIB_ROWSPAN},
    {"border",      HTML_ATTRIB_BORDER},
    {"cellpadding", HTML_ATTRIB_CELLPADDING},
    {"cellspacing", HTML_ATTRIB_CELLSPACING},
    {"align",       HTML_ATTRIB_ALIGN},
    {"valign",      HTML_ATTRIB_VALIGN},
    {"bgcolor",     HTML_ATTRIB_BGCOLOR},
    {"color",       HTML_ATTRIB_COLOR},
    {"rel",         HTML_ATTRIB_REL},
    {"content",     HTML_ATTRIB_CONTENT},
    {"charset",     HTML_ATTRIB_CHARSET},
    {"http-equiv",  HTML_ATTRIB_HTTP_EQUIV},
    {"target",      HTML_ATTRIB_TARGET},
    {"download",    HTML_ATTRIB_DOWNLOAD},
    {"action",      HTML_ATTRIB_ACTION},
    {"method",      HTML_ATTRIB_METHOD},
    {"data",        HTML_ATTRIB_DATA},
    {"hidden",      HTML_ATTRIB_HIDDEN},   /* Task 67 [HC-HIDDEN] */
    {NULL,          HTML_ATTRIB_NONE}
};

/* Self-closing (void) теги по спецификации HTML5 */
static const HtmlTag void_tags[] = {
    HTML_TAG_BR, HTML_TAG_HR, HTML_TAG_IMG, HTML_TAG_INPUT,
    HTML_TAG_META, HTML_TAG_LINK, HTML_TAG_BASE,
};

/* [OPT] Void-теги, которых нет в enum: распознаём по имени. */
static int tag_name_is_void(const char* name, int len)
{
    static const char* voids[] = {
        "source", "track", "wbr", "col", "area", "embed", "param", NULL
    };
    for (int i = 0; voids[i]; i++) {
        int vl = (int)strlen(voids[i]);
        if (vl == len && strncasecmp(name, voids[i], len) == 0) return 1;
    }
    return 0;
}

/* [OPT] Теги, чьё поддерево целиком пропускается в read-режиме. */
static int tag_name_is_skip(const char* name, int len)
{
    /* <template>: содержимое — скрытый плейсхолдер (Web Components/SPA).
     * Task 66 [HP-SKIP-VISUAL]: содержимое этих тегов НЕ показывается в
     * реальных браузерах, а прежде становилось ТЕКСТОМ страницы:
     *  - <svg>: d="M68-.427.65-.928c..." — path-данные заливали рендер
     *    мусором (ya.ru, habr, вики — «просачивание кода»);
     *  - <iframe>/<object>/<canvas>/<noembed>/<noframes>: резервный
     *    контент для браузеров без поддержки — нам тоже не нужен;
     *  - <math>: TeX-подобная разметка. */
    static const char* skips[] = {
        "template", "svg", "iframe", "object", "canvas",
        "noembed", "noframes", "math", NULL
    };
    for (int i = 0; skips[i]; i++) {
        int vl = (int)strlen(skips[i]);
        if (vl == len && strncasecmp(name, skips[i], len) == 0) return 1;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════
   Декодирование HTML-мнемоник (entities)
   ═══════════════════════════════════════════════════════ */

typedef struct {
    const char* name;   /* entity name without & and ; e.g. "amp", "lt" */
    int          len;   /* length of name */
    const char*  repl;  /* replacement string */
    int          rlen;  /* length of replacement */
} HtmlEntity;

static const HtmlEntity entity_table[] = {
    {"amp",     3, "&",  1},
    {"lt",      2, "<",  1},
    {"gt",      2, ">",  1},
    {"quot",    4, "\"", 1},
    {"apos",    4, "'",  1},
    {"nbsp",    4, " ",  1},
    {"copy",    4, "\xC2\xA9",       2},
    {"reg",     3, "\xC2\xAE",       2},
    {"trade",   5, "\xE2\x84\xA2",   3},
    {"mdash",   5, "\xE2\x80\x94",   3},
    {"ndash",   5, "\xE2\x80\x93",   3},
    {"laquo",   5, "\xC2\xAB",       2},
    {"raquo",   5, "\xC2\xBB",       2},
    {"hellip",  6, "\xE2\x80\xA6",   3},
    {"bull",    4, "\xE2\x80\xA2",   3},
    {"middot",  6, "\xC2\xB7",       2},
    {"deg",     3, "\xC2\xB0",       2},
    {"plusmn",  6, "\xC2\xB1",       2},
    {"times",   5, "\xC3\x97",       2},
    {"divide",  6, "\xC3\xB7",       2},
    {"euro",    4, "\xE2\x82\xAC",   3},
    {"pound",   5, "\xC2\xA3",       2},
    {"yen",     3, "\xC2\xA5",       2},
    {"cent",    4, "\xC2\xA2",       2},
    {"para",    4, "\xC2\xB6",       2},
    {"sect",    4, "\xC2\xA7",       2},
    {"rarr",    4, "\xE2\x86\x92",   3},
    {"larr",    4, "\xE2\x86\x90",   3},
    {"uarr",    4, "\xE2\x86\x91",   3},
    {"darr",    4, "\xE2\x86\x93",   3},
    {"lsquo",   5, "\xE2\x80\x98",   3},
    {"rsquo",   5, "\xE2\x80\x99",   3},
    {"ldquo",   5, "\xE2\x80\x9C",   3},
    {"rdquo",   5, "\xE2\x80\x9D",   3},
    {NULL,      0, NULL, 0}
};

int html_decode_entities(char* str) {
    if (!str) return 0;
    char* src = str;
    char* dst = str;

    while (*src) {
        if (*src == '&') {
            const char* ent_start = src + 1;
            const char* ent_end = NULL;

            const char* p = ent_start;
            int max_scan = 12;
            while (*p && *p != ';' && max_scan-- > 0) p++;
            if (*p == ';') {
                ent_end = p;
            }

            if (ent_end) {
                int ent_len = (int)(ent_end - ent_start);

                if (ent_len > 1 && ent_start[0] == '#') {
                    unsigned long codepoint = 0;
                    if (ent_start[1] == 'x' || ent_start[1] == 'X') {
                        for (int i = 2; i < ent_len; i++) {
                            char c = ent_start[i];
                            int v = -1;
                            if (c >= '0' && c <= '9') v = c - '0';
                            else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
                            else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
                            if (v < 0) { codepoint = 0; break; }
                            codepoint = codepoint * 16 + (unsigned long)v;
                        }
                    } else {
                        for (int i = 1; i < ent_len; i++) {
                            char c = ent_start[i];
                            if (c < '0' || c > '9') { codepoint = 0; break; }
                            codepoint = codepoint * 10 + (unsigned long)(c - '0');
                        }
                    }
                    if (codepoint > 0 && codepoint < 0x110000) {
                        if (codepoint < 0x80) {
                            *dst++ = (char)codepoint;
                        } else if (codepoint < 0x800) {
                            *dst++ = (char)(0xC0 | (codepoint >> 6));
                            *dst++ = (char)(0x80 | (codepoint & 0x3F));
                        } else if (codepoint < 0x10000) {
                            *dst++ = (char)(0xE0 | (codepoint >> 12));
                            *dst++ = (char)(0x80 | ((codepoint >> 6) & 0x3F));
                            *dst++ = (char)(0x80 | (codepoint & 0x3F));
                        } else {
                            *dst++ = (char)(0xF0 | (codepoint >> 18));
                            *dst++ = (char)(0x80 | ((codepoint >> 12) & 0x3F));
                            *dst++ = (char)(0x80 | ((codepoint >> 6) & 0x3F));
                            *dst++ = (char)(0x80 | (codepoint & 0x3F));
                        }
                        src = (char*)(ent_end + 1);
                        continue;
                    }
                }

                for (int i = 0; entity_table[i].name; i++) {
                    if (entity_table[i].len == ent_len &&
                        strncasecmp(ent_start, entity_table[i].name, ent_len) == 0) {
                        memcpy(dst, entity_table[i].repl, entity_table[i].rlen);
                        dst += entity_table[i].rlen;
                        src = (char*)(ent_end + 1);
                        goto next_char;
                    }
                }
            }
            *dst++ = *src++;
            continue;
        next_char:
            continue;
        }
        *dst++ = *src++;
    }
    *dst = '\0';
    return (int)(dst - str);
}

/* ═══════════════════════════════════════════════════════
   Вспомогательные функции
   ═══════════════════════════════════════════════════════ */

HtmlTag html_tag_from_string(const char* name, int len) {
    if (!name || len <= 0) return HTML_TAG_UNKNOWN;
    for (int i = 0; tag_table[i].name; i++) {
        int nlen = (int)strlen(tag_table[i].name);
        if (nlen == len && strncasecmp(name, tag_table[i].name, len) == 0)
            return tag_table[i].tag;
    }
    return HTML_TAG_UNKNOWN;
}

const char* html_tag_to_string(HtmlTag tag) {
    for (int i = 0; tag_table[i].name; i++) {
        if (tag_table[i].tag == tag) return tag_table[i].name;
    }
    return "unknown";
}

HtmlAttribKey html_attrib_key_from_string(const char* name, int len) {
    if (!name || len <= 0) return HTML_ATTRIB_NONE;
    for (int i = 0; attrib_table[i].name; i++) {
        int nlen = (int)strlen(attrib_table[i].name);
        if (nlen == len && strncasecmp(name, attrib_table[i].name, len) == 0)
            return attrib_table[i].key;
    }
    return HTML_ATTRIB_CUSTOM;
}

int html_tag_is_void(HtmlTag tag) {
    for (int i = 0; i < (int)(sizeof(void_tags)/sizeof(void_tags[0])); i++) {
        if (void_tags[i] == tag) return 1;
    }
    return 0;
}

int html_tag_is_inline(HtmlTag tag) {
    switch (tag) {
        case HTML_TAG_SPAN:
        case HTML_TAG_A:
        case HTML_TAG_STRONG: case HTML_TAG_EM:
        case HTML_TAG_B: case HTML_TAG_I:
        case HTML_TAG_U: case HTML_TAG_S:
        case HTML_TAG_SUB: case HTML_TAG_SUP:
        case HTML_TAG_LABEL:
        case HTML_TAG_CODE:
        case HTML_TAG_KBD: case HTML_TAG_VAR: case HTML_TAG_SAMP:
        case HTML_TAG_ABBR: case HTML_TAG_CITE: case HTML_TAG_Q:
        case HTML_TAG_DFN: case HTML_TAG_SMALL: case HTML_TAG_BIG:
        case HTML_TAG_DEL: case HTML_TAG_INS:
        case HTML_TAG_IMG:
        case HTML_TAG_BR:
        case HTML_TAG_INPUT:
        case HTML_TAG_BUTTON:
        case HTML_TAG_SELECT:
        case HTML_TAG_TEXTAREA:
        case HTML_TAG_FONT:
        case HTML_TAG_SVG:
        case HTML_TAG_NONE:
            return 1;
        default:
            return 0;
    }
}

/* ═══════════════════════════════════════════════════════
   Создание / освобождение элементов
   ═══════════════════════════════════════════════════════ */

HtmlElement* html_new_element(HtmlTag tag, HtmlElement* parent,
                              const char* id, const char* text,
                              HtmlAttrib* attrib, HtmlElement* sibling) {
    HtmlElement* el = (HtmlElement*)calloc(1, sizeof(HtmlElement));
    if (!el) return NULL;

    el->tag       = tag;
    el->id        = id ? (char*)id : NULL;
    el->text      = text ? strdup(text) : NULL;
    el->attrib    = attrib;
    el->parent    = parent;
    el->child     = NULL;
    el->sibling   = sibling;
    el->display   = DISPLAY_INLINE;

    return el;
}

/* [OPT] Текстовый узел БЕЗ копирования: забирает владение строкой.
   Используется только внутри парсера (flush_text), где буфер уже
   выделен под точный размер. Экономит один malloc+memcpy на узел. */
static HtmlElement* html_new_text_owned(HtmlElement* parent, char* text) {
    HtmlElement* el = (HtmlElement*)calloc(1, sizeof(HtmlElement));
    if (!el) {
        if (text) free(text);   /* caller передал владение — убираем за собой */
        return NULL;
    }
    el->tag       = HTML_TAG_NONE;
    el->id        = NULL;
    el->text      = text;       /* владение перешло к элементу */
    el->attrib    = NULL;
    el->parent    = parent;
    el->child     = NULL;
    el->sibling   = NULL;
    el->display   = DISPLAY_INLINE;
    return el;
}

HtmlAttrib* html_new_attrib(HtmlAttribKey key, const char* key_name, const char* value) {
    HtmlAttrib* attrib = (HtmlAttrib*)calloc(1, sizeof(HtmlAttrib));
    if (!attrib) return NULL;

    attrib->key      = key;
    attrib->key_name = key_name ? strdup(key_name) : NULL;
    attrib->value    = value ? strdup(value) : NULL;
    attrib->user_data = NULL;
    attrib->next     = NULL;

    return attrib;
}

/* [OPT] Атрибут с владением значением: не копирует value.
   Значение уже подготовлено вызывающим (malloc). */
static HtmlAttrib* html_new_attrib_owned(HtmlAttribKey key, char* value) {
    HtmlAttrib* attrib = (HtmlAttrib*)calloc(1, sizeof(HtmlAttrib));
    if (!attrib) {
        if (value) free(value);
        return NULL;
    }
    attrib->key      = key;
    attrib->key_name = NULL;
    attrib->value    = value;
    attrib->user_data = NULL;
    attrib->next     = NULL;
    return attrib;
}

void html_free_attribs(HtmlAttrib* attrib) {
    while (attrib) {
        HtmlAttrib* next = attrib->next;
        if (attrib->key_name) free(attrib->key_name);
        if (attrib->value)    free(attrib->value);
        free(attrib);
        attrib = next;
    }
}

HtmlElement *html_find_element(HtmlElement *element, const char *id) {
    if (!element || !id) return NULL;
    while (element) {
        if (element->id && strcmp(element->id, id) == 0) return element;
        HtmlElement *found = html_find_element(element->child, id);
        if (found) return found;
        element = element->sibling;
    }
    return NULL;
}

void html_free_element(HtmlElement* el) {
    if (!el) return;
    if (el->child) {
        HtmlElement* c = el->child;
        el->child = NULL;
        while (c) {
            HtmlElement* next = c->sibling;
            c->sibling = NULL;
            html_free_element(c);
            c = next;
        }
    }
    if (el->text) free(el->text);
    html_free_attribs(el->attrib);
    free(el);
}

void html_free_document(HtmlDocument* doc) {
    if (!doc) return;
    if (doc->root_element) html_free_element(doc->root_element);
    free(doc);
}

/* ═══════════════════════════════════════════════════════
   Внутренние функции парсера
   ═══════════════════════════════════════════════════════ */

static void append_child(HtmlElement* parent, HtmlElement* child) {
    if (!parent || !child) return;
    child->parent = parent;
    if (!parent->child) {
        parent->child = child;
    } else {
        HtmlElement* last = parent->child;
        while (last->sibling) last = last->sibling;
        last->sibling = child;
    }
}

static int find_open_tag(HtmlParseState* state, HtmlTag tag);

/* ═══════════════════════════════════════════════════════
   Task 68 [HP-EVENT]/[HP-STREAM]: помощники событийного режима
   ═══════════════════════════════════════════════════════ */

void html_parse_set_events(HtmlParseState *state, const HtmlParseEvents *ev,
                           void *ud)
{
    if (!state) return;
    state->ev = ev;
    state->ev_ud = ud;
}

/* Открыть/текст/закрыть — события (в DOM-режиме no-op). */
static void hp_emit_open(HtmlParseState *st, HtmlElement *el)
{
    if (st->ev && st->ev->on_open) st->ev->on_open(st->ev_ud, el);
}

static void hp_emit_text(HtmlParseState *st, const char *s, int len)
{
    if (st->ev && st->ev->on_text && s && len > 0)
        st->ev->on_text(st->ev_ud, s, len);
}

static void hp_free_el(HtmlParseState *st, HtmlElement *el)
{
    /* [HP-EVENT]: дерево не строится — элемент отдаётся конвертеру
     * только на время событий и освобождается здесь же. */
    if (st->ev) html_free_element(el);
}

/* Снять ВЕРХНИЙ открытый элемент: событие close + освобождение
 * (event-режим). Корень (stack[0]) не снимается НИКОГДА. */
static void hp_pop_one(HtmlParseState *state)
{
    if (state->depth <= 1) return;
    HtmlElement *el = state->stack[state->depth - 1];
    state->depth--;
    state->current = state->stack[state->depth - 1];
    if (state->ev && state->ev->on_close) state->ev->on_close(state->ev_ud, el);
    hp_free_el(state, el);
}

/* Снять всё ВЫШЕ idx (неявные закрытия): idx сам остаётся открытым. */
static void hp_pop_to(HtmlParseState *state, int idx)
{
    while (state->depth > idx) hp_pop_one(state);
}

/* ─── pend: незавершённая конструкция ([HP-STREAM]) ─── */

static int hp_pend_reserve(HtmlParseState *st, int need)
{
    if (st->pend_cap >= need) return 1;
    int ncap = st->pend_cap ? st->pend_cap : 256;
    while (ncap < need) ncap *= 2;
    char *np = (char *)HP_REALLOC(st->pend, st->pend_cap, ncap);
    if (!np) return 0;
    st->pend = np;
    st->pend_cap = ncap;
    return 1;
}

static void hp_pend_save(HtmlParseState *st, const char *data, size_t len)
{
    if (!hp_pend_reserve(st, (int)len + 1)) return;   /* нет памяти: хвост теряется */
    memcpy(st->pend, data, len);
    st->pend_len = (int)len;
    st->pend[st->pend_len] = '\0';
}

static void hp_pend_append(HtmlParseState *st, const char *data, size_t len)
{
    if (!hp_pend_reserve(st, st->pend_len + (int)len + 1)) return;
    memcpy(st->pend + st->pend_len, data, len);
    st->pend_len += (int)len;
    st->pend[st->pend_len] = '\0';
}

static void hp_pend_consume(HtmlParseState *st, size_t n)
{
    if (n <= 0) return;
    if ((int)n >= st->pend_len) { st->pend_len = 0; if (st->pend) st->pend[0] = '\0'; return; }
    memmove(st->pend, st->pend + n, (size_t)st->pend_len - n);
    st->pend_len -= (int)n;
    st->pend[st->pend_len] = '\0';
}

/* ─── raw-захват через границы кусков ([HP-STREAM]) ───
 * Максимальная длина терминатора: "</textarea" (10) + ">" = 11;
 * "</template>" = 11. raw_tail хранит до 31 байта — хватит с запасом
 * при подаче кусков любой длины. */

static void hp_raw_buf_put(HtmlParseState *st, const char *s, int n, int drop_cr)
{
    if (n <= 0) return;
    if (st->raw_len + n + 1 > st->raw_cap) {
        int ncap = st->raw_cap ? st->raw_cap : 256;
        while (ncap < st->raw_len + n + 1) ncap *= 2;
        char *np = (char *)HP_REALLOC(st->raw_buf, st->raw_cap, ncap);
        if (!np) return;                     /* нет памяти: код обрезан */
        st->raw_buf = np;
        st->raw_cap = ncap;
    }
    for (int i = 0; i < n; i++) {
        char c = s[i];
        if (drop_cr && c == '\r') continue;
        st->raw_buf[st->raw_len++] = c;
    }
    st->raw_buf[st->raw_len] = '\0';   /* ёмкость резервировалась с +1:
                                        * html_decode_entities ищет NUL */
}

/* Завершить захват: содержимое -> текстовый ребёнок (DOM) / on_text
 * (event); buffer освобождается. */
static void hp_raw_finish(HtmlParseState *st)
{
    int kind = st->raw_kind;
    HtmlElement *el = st->raw_el;
    st->raw_kind = HP_RAW_NONE;
    st->raw_el = NULL;
    st->raw_tail_len = 0;

    if (kind == HP_RAW_SKIP || !st->raw_buf) {
        if (st->raw_buf) { free(st->raw_buf); st->raw_buf = NULL; }
        st->raw_len = st->raw_cap = 0;
        return;
    }
    if (kind == HP_RAW_TEXTAREA)
        html_decode_entities(st->raw_buf);
    st->raw_buf[st->raw_len] = '\0';

    if (st->ev) {
        hp_emit_text(st, st->raw_buf, st->raw_len);
        free(st->raw_buf);
    } else if (st->raw_len > 0) {
        /* ужать до точного размера (как flush_text) */
        if (st->raw_cap > st->raw_len + 1) {
            char *shrunk = (char *)HP_REALLOC(st->raw_buf, st->raw_cap,
                                              st->raw_len + 1);
            if (shrunk) st->raw_buf = shrunk;
        }
        HtmlElement *t = html_new_text_owned(el, st->raw_buf);
        if (t) append_child(el, t);
        else free(st->raw_buf);
    } else {
        free(st->raw_buf);
    }
    st->raw_buf = NULL;
    st->raw_len = st->raw_cap = 0;
}

/* Терминатор raw-режима, начинающийся в виртуальной позиции pos
 * (pos < 0 — внутри raw_tail: -1 = ПОСЛЕДНИЙ байт хвоста). Окно =
 * raw_tail || data. Возвращает длину терминатора (0 = не тут). */
static int hp_raw_term_at(const HtmlParseState *st, const char *data,
                          size_t len, long pos, int *tlen)
{
    /* доступ к байту виртуального окна */
    #define HP_WIN(i) ((i) < 0 ? st->raw_tail[st->raw_tail_len + (i)] \
                              : (i) >= (long)len ? '\0' : data[i])
    long wend = (long)st->raw_tail_len + (long)len;

    if (st->raw_kind == HP_RAW_SKIP) {
        /* ТОЧНО "</имя>" (как skip_raw_content: strncasecmp полного
         * "</name>", '>' обязана быть сразу после имени) */
        int tl = (int)strlen(st->raw_tag);
        int need = 2 + tl + 1;
        if (pos + need > wend) return 0;
        if (HP_WIN(pos) != '<' || HP_WIN(pos + 1) != '/') return 0;
        for (int k = 0; k < tl; k++) {
            char a = HP_WIN(pos + 2 + k), b = st->raw_tag[k];
            if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
            if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
            if (a != b) return 0;
        }
        if (HP_WIN(pos + 2 + tl) != '>') return 0;
        *tlen = need;
        return 1;
    }

    /* SCRIPT / TEXTAREA: "</имя" + разделитель ('>' ' ' '\t' '\n' '\r'
     * '/'), затем потребляется всё до '>' включительно */
    static const char nm_s[] = "script";
    static const char nm_t[] = "textarea";
    const char *nm = (st->raw_kind == HP_RAW_SCRIPT) ? nm_s : nm_t;
    int nl = (st->raw_kind == HP_RAW_SCRIPT) ? 6 : 8;
    int need_name = 2 + nl;
    if (pos + need_name > wend) return 0;
    if (HP_WIN(pos) != '<' || HP_WIN(pos + 1) != '/') return 0;
    for (int k = 0; k < nl; k++) {
        char a = HP_WIN(pos + 2 + k), b = nm[k];
        if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if (a != b) return 0;
    }
    char delim = (pos + need_name < wend) ? HP_WIN(pos + need_name) : '\0';
    /* '\0' = окно кончилось ровно на имени: ждём продолжения (поток);
     * на EOF финализирует hp_raw_finish_eof без этого условия. */
    if (delim == '\0') return 0;
    if (!(delim == '>' || delim == ' ' || delim == '\t' ||
          delim == '\n' || delim == '\r' || delim == '/')) return 0;
    /* потребление: до '>' включительно — '>' обязана быть в окне */
    long q = pos + need_name;
    while (q < wend && HP_WIN(q) != '>') q++;
    if (q >= wend) return 0;                 /* '>' ещё не пришла */
    *tlen = (int)(q - pos + 1);
    return 1;
    #undef HP_WIN
}

/* Прокормить raw-режим куском [data, data+len). Инвариант: raw_tail —
 * последние (<=31) байт потока, ещё НЕ commitнутые; всё до них — уже в
 * raw_buf/выброшено. Возвращает число байт data, потреблённых этим
 * вызовом: len (raw активен) или позицию ЗА терминатором (raw завершён
 * внутри куска; хвост после терминатора — обычная разметка). */
static size_t hp_raw_feed(HtmlParseState *st, const char *data, size_t len)
{
    int drop_cr = (st->raw_kind == HP_RAW_TEXTAREA);
    int discard = (st->raw_kind == HP_RAW_SKIP);   /* skip: контент не копим */
    int T = st->raw_tail_len;
    long total = (long)T + (long)len;

    /* окно W = tail[T] || data[N]; индекс w<0 — tail[T+w], w>=0 — data[w] */
    for (long w = -T; w < total; w++) {
        int tlen = 0;
        if (!hp_raw_term_at(st, data, len, w, &tlen)) continue;

        /* контент ДО терминатора: W[-T .. w) */
        if (!discard) {
            if (w >= 0) {
                if (T > 0) hp_raw_buf_put(st, st->raw_tail, T, drop_cr);
                if (w > 0) hp_raw_buf_put(st, data, (int)w, drop_cr);
            } else {
                /* терминатор начинается внутри tail: контент — его префикс */
                if (T + w > 0)
                    hp_raw_buf_put(st, st->raw_tail, (int)(T + w), drop_cr);
            }
        }
        st->raw_tail_len = 0;
        hp_raw_finish(st);
        /* терминатор заканчивается в ОКОННОЙ позиции w+tlen; для w+tlen>=0
         * это и есть индекс в data (хвост занимает отрицательные индексы) */
        long e = w + (long)tlen;
        return e > 0 ? (size_t)e : 0;
    }

    /* терминатора нет: commit всё, кроме последних keep<=10 байт окна
     * (10 = len("</textarea") — самый длинный ПРЕФИКС терминатора,
     * способный перейти на следующий кусок) */
    int keep = 10;
    if (total < keep) keep = (int)total;
    long commit = total - keep;
    if (commit >= T) {
        if (!discard) {
            if (T > 0) hp_raw_buf_put(st, st->raw_tail, T, drop_cr);
            if (commit - T > 0)
                hp_raw_buf_put(st, data, (int)(commit - T), drop_cr);
        }
        /* новый tail — последние keep байт data (T <= commit => N >= keep) */
        int n = 0;
        for (long i = total - keep; i < total; i++)
            st->raw_tail[n++] = data[i - T];
        st->raw_tail_len = n;
    } else {
        /* commit умещается в tail: часть tail + весь data */
        if (!discard && commit > 0)
            hp_raw_buf_put(st, st->raw_tail, (int)commit, drop_cr);
        int n = 0;
        for (long i = commit; i < T; i++)
            st->raw_tail[n++] = st->raw_tail[i];
        for (long i = 0; i < (long)len && n < (int)sizeof(st->raw_tail); i++)
            st->raw_tail[n++] = data[i];
        st->raw_tail_len = n;
    }
    return len;
}

/* EOF при незакрытом raw: содержимое до конца входа (HTML5) */
static void hp_raw_finish_eof(HtmlParseState *st)
{
    if (st->raw_kind != HP_RAW_SKIP && st->raw_tail_len > 0)
        hp_raw_buf_put(st, st->raw_tail, st->raw_tail_len,
                       st->raw_kind == HP_RAW_TEXTAREA);
    st->raw_tail_len = 0;
    hp_raw_finish(st);
    /* элемент закрывается (событие/дерево) */
    hp_pop_one(st);
}

/* Task 68 [HP-EVENT]: все снятия элементов идут через hp_pop_one/
 * hp_pop_to — событие close и освобождение (event-режим) не забываются. */
static void auto_close_tags(HtmlParseState* state, HtmlTag new_tag) {
    /* Task 67 [HP-ROOT-NOMATCH]: защита от current == NULL (не бывает
     * при инварианте depth >= 1, но auto_close зовётся на каждом теге). */
    if (!state || !state->current) return;
    switch (new_tag) {
        case HTML_TAG_P:
            if (state->current->tag == HTML_TAG_P)
                hp_pop_one(state);
            break;
        case HTML_TAG_DIV:
        case HTML_TAG_BLOCKQUOTE:
        case HTML_TAG_H1: case HTML_TAG_H2: case HTML_TAG_H3:
        case HTML_TAG_H4: case HTML_TAG_H5: case HTML_TAG_H6:
        case HTML_TAG_HR:
        case HTML_TAG_PRE:
        case HTML_TAG_UL:
        case HTML_TAG_OL:
        case HTML_TAG_TABLE:
        case HTML_TAG_FORM:
        case HTML_TAG_NOSCRIPT:
        case HTML_TAG_CENTER:
        case HTML_TAG_FIGURE:
        case HTML_TAG_SECTION:
        case HTML_TAG_ARTICLE:
        case HTML_TAG_HEADER:
        case HTML_TAG_FOOTER:
        case HTML_TAG_NAV:
        case HTML_TAG_MAIN:
        case HTML_TAG_ASIDE:
        case HTML_TAG_DETAILS:
            if (state->current->tag == HTML_TAG_P)
                hp_pop_one(state);
            break;
        case HTML_TAG_LI:
            if (state->current->tag == HTML_TAG_LI)
                hp_pop_one(state);
            break;
        case HTML_TAG_TR:
            while (state->depth > 1 &&
                   (state->current->tag == HTML_TAG_TR ||
                    state->current->tag == HTML_TAG_TD ||
                    state->current->tag == HTML_TAG_TH))
                hp_pop_one(state);
            break;
        case HTML_TAG_TD:
        case HTML_TAG_TH:
            if (state->current->tag == HTML_TAG_TD ||
                state->current->tag == HTML_TAG_TH)
                hp_pop_one(state);
            break;
        case HTML_TAG_THEAD:
        case HTML_TAG_TBODY:
        case HTML_TAG_TFOOT:
            while (state->depth > 1 &&
                   (state->current->tag == HTML_TAG_THEAD ||
                    state->current->tag == HTML_TAG_TBODY ||
                    state->current->tag == HTML_TAG_TFOOT ||
                    state->current->tag == HTML_TAG_TR ||
                    state->current->tag == HTML_TAG_TD ||
                    state->current->tag == HTML_TAG_TH))
                hp_pop_one(state);
            break;
        case HTML_TAG_DT:
        case HTML_TAG_DD:
            if (state->current->tag == HTML_TAG_DT ||
                state->current->tag == HTML_TAG_DD)
                hp_pop_one(state);
            break;
        case HTML_TAG_A:
            {
                int a_idx = find_open_tag(state, HTML_TAG_A);
                /* Task 67 [HP-ROOT-NOMATCH]: a_idx >= 1 — корень (stack[0])
                 * не <a>; глубже нуля стек не роняем. */
                if (a_idx >= 1)
                    hp_pop_to(state, a_idx);
            }
            break;
        case HTML_TAG_BR:
            if (state->current->tag == HTML_TAG_A)
                hp_pop_one(state);
            break;
        default:
            break;
    }
}

static int find_open_tag(HtmlParseState* state, HtmlTag tag) {
    /* Task 67 [HP-ROOT-NOMATCH]: поиск С НУЛЁМ исключён (i >= 1).
     * stack[0] — КОРЕНЬ документа (tag = HTML_TAG_UNKNOWN); раньше
     * закрывающий тег с НЕИЗВЕСТНЫМ именем (</foobar> -> UNKNOWN)
     * «находил» корень: idx = 0 -> state->depth = 0 -> следующий
     * открывающий <script>/<textarea>/<style> после захвата делал
     * stack[depth-1] == stack[-1] (UB, мусор в current, SEGV в
     * auto_close_tags при первом же вложенном блочном теге). */
    for (int i = state->depth - 1; i >= 1; i--) {
        if (state->stack[i]->tag == tag) return i;
    }
    return -1;
}

/* [OPT] Перевод накопленного текста в текстовый узел.
   - pre-режим: один узел с встроенными \n (без <br> на строку);
   - normal:   trim + decode + точный размер (без strdup).
   Буфер передаётся элементу по владению; следующий append аллоцирует
   новый — так мы платим один malloc на узел, а не malloc+strdup. */
static void flush_text(HtmlParseState* state) {
    if (!state->text_buf || state->text_buf_len == 0 || !state->current) {
        if (state->text_buf) state->text_buf_len = 0;
        return;
    }
    state->text_buf[state->text_buf_len] = '\0';

    /* Task 60 [HC-NOTRIM]: концевые пробелы НЕ обрезаем. Пробелы на
     * стыках текстовых узлов ("</b> <i>") нужны конвертеру: без них
     * "</b> <i>it</i>" давало бы "bold*it*" вместо "bold *it*".
     * Нормализация (схлопывание пробелов, '\n'->' ') — работа
     * ВЫЗЫВАЮЩЕГО (htmlconv.c). Декодирование entities и ужатие
     * буфера — как раньше. Ветви preserve_ws/normal давали один и
     * тот же код (различие только в НАКОПЛЕНИИ text_buf_append). */
    html_decode_entities(state->text_buf);
    int slen = (int)strlen(state->text_buf);

    /* Task 68 [HP-EVENT]: событие вместо текстового узла — конвертер
     * получает текст БЕЗ malloc'а узла; дерево в этом режиме пусто. */
    if (state->ev) {
        if (slen > 0)
            state->ev->on_text(state->ev_ud, state->text_buf, slen);
        free(state->text_buf);
        state->text_buf     = NULL;
        state->text_buf_len = 0;
        state->text_buf_cap = 0;
        return;
    }

    if (slen > 0) {
        /* Ужать до точного размера — экономия памяти на узел. */
        if (state->text_buf_cap > slen + 1) {
            char* shrunk = (char*)HP_REALLOC(state->text_buf,
                                             state->text_buf_cap, slen + 1);
            if (shrunk) state->text_buf = shrunk;
        }
        HtmlElement* text_el = html_new_text_owned(state->current, state->text_buf);
        if (text_el) {
            append_child(state->current, text_el);
            state->text_buf = NULL;      /* владение передано */
            state->text_buf_cap = 0;
        } else {
            free(state->text_buf);
        }
    } else {
        free(state->text_buf);
    }

    state->text_buf     = NULL;
    state->text_buf_len = 0;
    state->text_buf_cap = 0;
}

static void text_buf_append(HtmlParseState* state, char ch) {
    if (state->text_buf_len >= state->text_buf_cap - 1) {
        int new_cap = state->text_buf_cap ? state->text_buf_cap * 2 : 256;
        char* new_buf = (char*)HP_REALLOC(state->text_buf, state->text_buf_cap, new_cap);
        if (!new_buf) return;
        state->text_buf = new_buf;
        state->text_buf_cap = new_cap;
    }
    state->text_buf[state->text_buf_len++] = ch;
}

/* [OPT] Разбор атрибутов: использует html_new_attrib_owned — значение
   атрибута не копируется повторно. */
static const char* parse_attributes(const char* p, HtmlElement* el, int* is_closing) {
    *is_closing = 0;

    while (*p && *p != '>' && !(*p == '/' && *(p+1) == '>')) {
        while (*p && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
        if (!*p || *p == '>' || (*p == '/' && *(p+1) == '>')) break;

        const char* attr_name_start = p;
        while (*p && *p != '=' && *p != ' ' && *p != '\t' &&
               *p != '\n' && *p != '\r' && *p != '>' &&
               !(*p == '/' && *(p+1) == '>'))
            p++;

        int attr_name_len = (int)(p - attr_name_start);
        if (attr_name_len <= 0) { p++; continue; }

        while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;

        char* attr_value = NULL;

        if (*p == '=') {
            p++;
            while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;

            if (*p == '"') {
                p++;
                const char* val_start = p;
                while (*p && *p != '"') p++;
                int val_len = (int)(p - val_start);
                if (val_len > 0) {
                    attr_value = (char*)malloc((size_t)val_len + 1);
                    if (attr_value) {
                        memcpy(attr_value, val_start, (size_t)val_len);
                        attr_value[val_len] = '\0';
                    }
                }
                if (*p == '"') p++;
            } else if (*p == '\'') {
                p++;
                const char* val_start = p;
                while (*p && *p != '\'') p++;
                int val_len = (int)(p - val_start);
                if (val_len > 0) {
                    attr_value = (char*)malloc((size_t)val_len + 1);
                    if (attr_value) {
                        memcpy(attr_value, val_start, (size_t)val_len);
                        attr_value[val_len] = '\0';
                    }
                }
                if (*p == '\'') p++;
            } else {
                const char* val_start = p;
                while (*p && *p != ' ' && *p != '\t' && *p != '>' &&
                       *p != '\n' && *p != '\r' &&
                       !(*p == '/' && *(p+1) == '>'))
                    p++;
                int val_len = (int)(p - val_start);
                if (val_len > 0) {
                    attr_value = (char*)malloc((size_t)val_len + 1);
                    if (attr_value) {
                        memcpy(attr_value, val_start, (size_t)val_len);
                        attr_value[val_len] = '\0';
                    }
                }
            }
        } else {
            /* Boolean attribute: value = name */
            attr_value = (char*)malloc((size_t)attr_name_len + 1);
            if (attr_value) {
                memcpy(attr_value, attr_name_start, (size_t)attr_name_len);
                attr_value[attr_name_len] = '\0';
            }
        }

        HtmlAttribKey key = html_attrib_key_from_string(attr_name_start, attr_name_len);
        if (attr_value) html_decode_entities(attr_value);

        /* [OPT] Владение attr_value переходит к атрибуту (без второго strdup). */
        HtmlAttrib* attrib = html_new_attrib_owned(key, attr_value);

        if (attrib) {
            if (key == HTML_ATTRIB_CUSTOM) {
                attrib->key_name = (char*)malloc((size_t)attr_name_len + 1);
                if (attrib->key_name) {
                    memcpy(attrib->key_name, attr_name_start, (size_t)attr_name_len);
                    attrib->key_name[attr_name_len] = '\0';
                }
            }

            attrib->next = el->attrib;
            el->attrib = attrib;

            if (key == HTML_ATTRIB_ID && attrib->value) {
                el->id = attrib->value;
            }
        }
        /* attr_value больше не освобождаем — владение ушло в attrib
           (или было освобождено внутри html_new_attrib_owned при сбое). */
    }

    if (*p == '/' && *(p+1) == '>') {
        *is_closing = 1;
        p += 2;
    } else if (*p == '>') {
        p++;
    }

    return p;
}

/* [OPT] Пропуск содержимого special-тега (<style>, <template>, <svg>...).
   Дочерний узел НЕ создаётся: в read-режиме CSS не нужен, а его
   сохранение в DOM — сотни КБ выброшенной памяти на современной странице.
   Возвращает указатель ПОСЛЕ закрывающего тега (или в конец буфера).
   Task 66 [HP-STYLE-EOF]: поиск закрывающего тега до КОНЦА входа (end).
   Прежний лимит 64 КиБ (Task 60 [HP-STYLE-LIMIT]) заставлял парсер
   «сдаваться» посреди большого стиля (ya.ru: <style> 120 КиБ) — хвост
   CSS рендерился как текст («просачивание кода»). Семантика HTML5:
   raw-text-элемент без закрытия длится до EOF — прячем до конца. */
static const char* skip_raw_content(const char* p, const char* end,
                                    const char* tag_name, int tag_len) {
    char close_tag[80];
    int nt = tag_len;
    if (nt > (int)sizeof(close_tag) - 5) nt = (int)sizeof(close_tag) - 5;
    snprintf(close_tag, sizeof(close_tag), "</%.*s>", nt, tag_name);
    int close_len = (int)strlen(close_tag);

    while (p + close_len <= end) {
        if (strncasecmp(p, close_tag, (size_t)close_len) == 0) {
            return p + close_len;
        }
        p++;
    }
    return end;   /* закрытия нет: raw-элемент длится до EOF (HTML5) */
}

/* Task 60 [HP-SCRIPT-CAPTURE]: содержимое <script> НЕ пропускаем, а
 * забираем ОДНИМ текстовым ребёнком (сырой код, БЕЗ декодирования
 * entities — "a &amp;&amp; b" в JS может быть валидным кодом, а не
 * мнемоникой). Конвертер htmlconv.c оборачивает узел в маркеры
 * \x01SCRIPT ... \x01/SCRIPT и исполняет через MicroQuickJS.
 * Условие закрытия — как в прежнем htmlconv: "</script" (без регистра),
 * за именем — разделитель '>' ' ' '\t' '\n' '\r' '/'. Без закрытия код
 * идёт до конца потока (весь хвост уходит в «код» — потеря контента,
 * но НЕ утечка в рендер; прежнее поведение сохранено). */
static const char* capture_script_content(const char* p, const char* end,
                                          HtmlElement* el) {
    const char* start = p;
    const char* q = p;
    while (q < end) {
        if (*q == '<' && q + 1 < end && q[1] == '/') {
            static const char nm[] = "script";
            int k = 0;
            const char* r = q + 2;
            while (k < 6 && r < end) {
                char c = *r;
                if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
                if (c != nm[k]) break;
                r++; k++;
            }
            if (k == 6) {
                char delim = (r < end) ? *r : '>';
                if (delim == '>' || delim == ' ' || delim == '\t' ||
                    delim == '\n' || delim == '\r' || delim == '/') {
                    while (r < end && *r != '>') r++;
                    if (r < end) r++;
                    {
                        int len = (int)(q - start);
                        if (len > 0) {
                            char* raw = (char*)malloc((size_t)len + 1);
                            if (raw) {
                                memcpy(raw, start, (size_t)len);
                                raw[len] = '\0';
                                HtmlElement* t = html_new_text_owned(el, raw);
                                if (t) append_child(el, t);
                                else free(raw);
                            }
                        }
                    }
                    return r;
                }
            }
        }
        q++;
    }
    /* </script> не найден — весь остаток потока считается кодом. */
    {
        int len = (int)(end - start);
        if (len > 0) {
            char* raw = (char*)malloc((size_t)len + 1);
            if (raw) {
                memcpy(raw, start, (size_t)len);
                raw[len] = '\0';
                HtmlElement* t = html_new_text_owned(el, raw);
                if (t) append_child(el, t);
                else free(raw);
            }
        }
    }
    return end;
}

/* Task 60 [HP-TA-CAPTURE]: <textarea> — RCDATA по спецификации: теги
 * внутри НЕ разбираются. Забираем сырой текст одним узлом до
 * </textarea (без регистра), '\r' выбрасываем, entities декодируем.
 * Без закрытия — до конца потока (как в htmlconv ta_mode). */
static const char* capture_textarea_content(const char* p, const char* end,
                                            HtmlElement* el) {
    const char* start = p;
    const char* q = p;
    int done = 0;
    while (q < end) {
        if (*q == '<' && q + 1 < end && q[1] == '/') {
            static const char nm[] = "textarea";
            int k = 0;
            const char* r = q + 2;
            while (k < 8 && r < end) {
                char c = *r;
                if (c >= 'A' && c <= 'Z') c = (char)(c | 0x20);
                if (c != nm[k]) break;
                r++; k++;
            }
            if (k == 8) {
                char delim = (r < end) ? *r : '>';
                if (delim == '>' || delim == ' ' || delim == '\t' ||
                    delim == '\n' || delim == '\r' || delim == '/') {
                    while (r < end && *r != '>') r++;
                    if (r < end) r++;
                    done = 1;
                    break;
                }
            }
        }
        q++;
    }
    {
        int len = (int)((done ? q : end) - start);
        if (len > 0) {
            char* raw = (char*)malloc((size_t)len + 1);
            if (raw) {
                int o = 0;
                for (int i = 0; i < len; i++)
                    if (start[i] != '\r') raw[o++] = start[i];
                raw[o] = '\0';
                html_decode_entities(raw);
                HtmlElement* t = html_new_text_owned(el, raw);
                if (t) append_child(el, t);
                else free(raw);
            }
        }
    }
    if (!done) return end;
    /* прокрутить до конца закрывающего тега */
    {
        const char* r = q;
        while (r < end && *r != '>') r++;
        return (r < end) ? r + 1 : end;
    }
}

/* ═══════════════════════════════════════════════════════
   Публичный API парсера
   ═══════════════════════════════════════════════════════ */

HtmlParseState* html_parse_begin(void) {
    HtmlParseState* state = (HtmlParseState*)calloc(1, sizeof(HtmlParseState));
    if (!state) return NULL;

    state->root = (HtmlElement*)calloc(1, sizeof(HtmlElement));
    if (!state->root) { free(state); return NULL; }
    state->root->tag = HTML_TAG_UNKNOWN;
    state->root->display = DISPLAY_BLOCK;

    state->current = state->root;
    state->depth = 0;
    state->stack[0] = state->root;
    state->depth = 1;

    state->text_buf = NULL;
    state->text_buf_len = 0;
    state->text_buf_cap = 0;

    return state;
}

/* ═══════════════════════════════════════════════════════
   Task 68 [HP-STREAM]: инкрементальный сканер конструкций
   ═══════════════════════════════════════════════════════ */

/* Конец открывающего тега ('>' ВНЕ кавычек-значений) в [p, end).
 * Семантика кавычек — ТОЧНО как у parse_attributes: кавычка значима
 * только как ограничитель значения после '='. Возвращает позицию '>'
 * или NULL (тег не завершён в этом куске). */
static const char *hp_tag_end(const char *p, const char *end)
{
    while (p < end) {
        while (p < end && *p != '=' && *p != '>' &&
               !(*p == '/' && p + 1 < end && p[1] == '>'))
            p++;
        if (p >= end) return NULL;
        if (*p == '>') return p;
        if (*p == '/' && p + 1 < end && p[1] == '>') return p + 1;
        p++;                                   /* '=' */
        while (p < end && (*p == ' ' || *p == '\t' ||
                           *p == '\n' || *p == '\r'))
            p++;
        if (p < end && (*p == '"' || *p == '\'')) {
            char q = *p++;
            while (p < end && *p != q) p++;
            if (p >= end) return NULL;         /* кавычка не закрыта */
            p++;
        } else {
            while (p < end && *p != ' ' && *p != '\t' && *p != '\n' &&
                   *p != '\r' && *p != '>' &&
                   !(*p == '/' && p + 1 < end && p[1] == '>'))
                p++;
        }
    }
    return NULL;
}

/* Начать захват сырого содержимого (script/textarea/skip) с позиции p.
 * Терминатор в этом куске -> захват завершён (элемент закрыт), возврат
 * позиции ЗА терминатором. Нет -> raw-режим остаётся активен, возврат
 * end (ВЫЗЫВАЮЩИЙ выходит: все байты потреблены). eof: содержимое до
 * конца входа (HTML5) и закрытие. */
static const char *hp_capture_start(HtmlParseState *st, const char *p,
                                    const char *end, int kind, int eof,
                                    const char *tag_name, int tag_len)
{
    st->raw_kind = kind;
    st->raw_el = (st->depth > 0) ? st->stack[st->depth - 1] : st->root;
    st->raw_tail_len = 0;
    st->raw_len = 0;
    st->raw_cap = 0;
    st->raw_buf = NULL;
    if (kind == HP_RAW_SKIP) {
        int n = tag_len;
        if (n > (int)sizeof(st->raw_tag) - 1)
            n = (int)sizeof(st->raw_tag) - 1;
        memcpy(st->raw_tag, tag_name, (size_t)n);
        st->raw_tag[n] = '\0';
    }
    size_t avail = (size_t)(end - p);
    size_t used = hp_raw_feed(st, p, avail);
    if (st->raw_kind == HP_RAW_NONE) {
        hp_pop_one(st);                        /* захват целиком здесь */
        return p + used;
    }
    if (eof) {
        hp_raw_finish_eof(st);                 /* контент до EOF + закрытие */
        return end;
    }
    return end;                                /* raw активен */
}

/* Сканер: обработать [data, data+len) настолько, насколько безопасно
 * БЕЗ риска разорвать конструкцию на границе. Возвращает число
 * обработанных байт; хвост [ret, len) — одна незавершённая конструкция
 * (уходит в pend) ЛИБО пусто. eof=1: хвост обрабатывается с семантикой
 * конца входа (ВЫЗЫВАЕТСЯ ТОЛЬКО для NUL-терминированного pend).
 * Активный raw-захват потребляет всё до конца куска (ret == len). */
static size_t hp_process(HtmlParseState *state, const char *data,
                         size_t len, int eof)
{
    const char *start = data;
    const char *p = data;
    const char *end = data + len;

    while (p < end) {
        if (*p == '<') {
            flush_text(state);

            /* ── комментарий ── */
            if (p + 3 < end && p[1] == '!' && p[2] == '-' && p[3] == '-') {
                const char *q = p + 4;
                while (q + 2 < end) {
                    if (q[0] == '-' && q[1] == '-' && q[2] == '>')
                        break;
                    q++;
                }
                if (q + 2 < end) { p = q + 3; continue; }
                if (!eof) return (size_t)(p - start);   /* ждать хвост */
                p = end;                                /* EOF: глотаем */
                continue;
            }

            /* ── DOCTYPE ── */
            if (p + 8 < end && strncasecmp(p, "<!DOCTYPE", 9) == 0) {
                const char *q = p + 9;
                while (q < end && *q != '>') q++;
                if (q < end) { p = q + 1; continue; }
                if (!eof) return (size_t)(p - start);
                p = end;
                continue;
            }

            /* ── CDATA ── */
            if (p + 8 < end && strncmp(p, "<![CDATA[", 9) == 0) {
                const char *q = p + 9;
                while (q + 2 < end) {
                    if (q[0] == ']' && q[1] == ']' && q[2] == '>')
                        break;
                    q++;
                }
                if (q + 2 < end) { p = q + 3; continue; }
                if (!eof) return (size_t)(p - start);
                p = end;
                continue;
            }

            /* ── прочее <!...> ── */
            if (p + 1 < end && p[1] == '!') {
                const char *q = p + 2;
                while (q < end && *q != '>') q++;
                if (q < end) { p = q + 1; continue; }
                if (!eof) return (size_t)(p - start);
                p = end;
                continue;
            }

            /* ── закрывающий тег </...> ── */
            if (p + 1 < end && p[1] == '/') {
                p += 2;
                const char *tag_start = p;
                while (p < end && *p != '>' && *p != ' ' && *p != '\t' &&
                       *p != '\n' && *p != '\r')
                    p++;
                int tag_len = (int)(p - tag_start);
                const char *q = p;
                while (q < end && *q != '>') q++;
                if (q >= end) {
                    if (!eof) return (size_t)((tag_start - 2) - start);
                    p = end;                    /* EOF: закрываем без '>' */
                } else {
                    p = q + 1;
                }
                if (tag_len > 0) {
                    HtmlTag close_tag = html_tag_from_string(tag_start,
                                                             tag_len);
                    /* [OPT] preserve_ws: </pre> и </code> синхронны с
                       открывающими (включая <pre><code>). */
                    if (close_tag == HTML_TAG_PRE ||
                        close_tag == HTML_TAG_CODE) {
                        if (state->preserve_ws > 0) state->preserve_ws--;
                    }
                    int idx = find_open_tag(state, close_tag);
                    /* Task 67 [HP-ROOT-NOMATCH]: idx >= 1 — закрывающий
                     * тег не может «закрыть» корень документа. */
                    if (idx >= 1)
                        hp_pop_to(state, idx);
                }
                continue;
            }

            /* ── открывающий тег <...> ── */
            p++;
            const char *tag_start = p;
            while (p < end && *p != '>' && *p != ' ' && *p != '\t' &&
                   *p != '\n' && *p != '\r' &&
                   !(*p == '/' && p + 1 < end && *(p + 1) == '>'))
                p++;

            int tag_len = (int)(p - tag_start);
            if (tag_len <= 0) {
                /* [HP-STREAM]: '<' в самом конце куска — конструкция
                 * ещё не начата: ждать продолжения (прежде '<' просто
                 * выбрасывался — на границе кусков терял тег). */
                if (p >= end && !eof)
                    return (size_t)((tag_start - 1) - start);
                continue;
            }

            /* [HP-STREAM]: тег обязан ЗАВЕРШИТЬСЯ '>' (вне кавычек) в
             * этом куске — иначе конструкция уходит в pend и достроится
             * следующим куском (на EOF разбирается до NUL — pend
             * терминирован, семантика прежнего парсера). */
            const char *te = hp_tag_end(p, end);
            if (!te) {
                if (!eof) return (size_t)((tag_start - 1) - start);
                /* EOF: parse_attributes остановится на NUL pend */
            }

            HtmlTag tag = html_tag_from_string(tag_start, tag_len);

            auto_close_tags(state, tag);

            HtmlElement *el = (HtmlElement *)calloc(1, sizeof(HtmlElement));
            if (!el) {
                /* нет памяти: пропускаем тег ЦЕЛИКОМ (до '>'), не
                 * превращая атрибуты в текст страницы */
                p = te ? te + 1 : end;
                continue;
            }
            el->tag = tag;
            el->display = DISPLAY_INLINE;
            el->parent = state->current;

            int is_closing = 0;
            p = parse_attributes(p, el, &is_closing);

            /* [HP-EVENT]: дерево не строим — события вместо узлов */
            if (!state->ev)
                append_child(state->current, el);

            int is_void = html_tag_is_void(tag) ||
                          tag_name_is_void(tag_start, tag_len);
            int is_skip = (tag == HTML_TAG_SCRIPT) ||
                          (tag == HTML_TAG_STYLE) ||
                          tag_name_is_skip(tag_start, tag_len);

            if (!is_closing && !is_void && state->depth < MAX_PARSE_DEPTH) {
                state->stack[state->depth++] = el;
                state->current = el;
                hp_emit_open(state, el);

                if (tag == HTML_TAG_PRE || tag == HTML_TAG_CODE)
                    state->preserve_ws++;

                if (tag == HTML_TAG_SCRIPT) {
                    /* [HP-SCRIPT-CAPTURE]: код — сырой текст БЕЗ
                     * декодирования entities; через границы кусков */
                    p = hp_capture_start(state, p, end, HP_RAW_SCRIPT,
                                         eof, NULL, 0);
                    if (state->raw_kind != HP_RAW_NONE)
                        return (size_t)len;
                } else if (tag == HTML_TAG_TEXTAREA) {
                    /* [HP-TA-CAPTURE]: RCDATA, '\r' выбрасываются */
                    p = hp_capture_start(state, p, end, HP_RAW_TEXTAREA,
                                         eof, NULL, 0);
                    if (state->raw_kind != HP_RAW_NONE)
                        return (size_t)len;
                } else if (is_skip) {
                    /* [OPT]/[HP-SKIP-VISUAL]: содержимое пропускается
                     * БЕЗ создания узлов (CSS ya.ru не попадает в
                     * память вовсе); закрытие — через границы кусков */
                    p = hp_capture_start(state, p, end, HP_RAW_SKIP,
                                         eof, tag_start, tag_len);
                    if (state->raw_kind != HP_RAW_NONE)
                        return (size_t)len;
                }
            } else {
                /* void-тег, самозакрытый или переполнение глубины:
                 * пара open/close (эффекты листа конвертера) */
                hp_emit_open(state, el);
                if (state->ev && state->ev->on_close)
                    state->ev->on_close(state->ev_ud, el);
                hp_free_el(state, el);
            }
        } else {
            /* ── текстовое содержимое ── */
            char ch = *p;
            if (state->preserve_ws > 0) {
                if (ch == '\r') {
                    p++;
                    continue;
                }
                if (ch == '\t') {
                    /* Expand tab to 4 spaces (как в оригинале). */
                    text_buf_append(state, ' ');
                    text_buf_append(state, ' ');
                    text_buf_append(state, ' ');
                    text_buf_append(state, ' ');
                    p++;
                    continue;
                }
                text_buf_append(state, ch);
            } else {
                if (ch == '\r') {
                    p++;
                    continue;
                }
                if (ch == '\t') ch = ' ';
                if (ch == ' ' && state->text_buf_len > 0) {
                    char prev = state->text_buf[state->text_buf_len - 1];
                    if (prev == ' ' || prev == '\n') {
                        p++;
                        continue;
                    }
                }
                if (ch == '\n' && state->text_buf_len > 0) {
                    char prev = state->text_buf[state->text_buf_len - 1];
                    if (prev == '\n') {
                        p++;
                        continue;
                    }
                }
                text_buf_append(state, ch);
            }
            p++;
        }
    }
    return (size_t)(p - start);
}

void html_parse_stream(HtmlParseState* state, char* buffer, const char* data, size_t len) {
    if (!state || !data || len == 0) return;
    state->stream_buffer = buffer;

    const char *p = data;
    size_t left = len;

    /* активный raw-захват: кусок — продолжение содержимого */
    if (state->raw_kind != HP_RAW_NONE) {
        size_t used = hp_raw_feed(state, p, left);
        p += used;
        left -= used;
        if (state->raw_kind != HP_RAW_NONE) return;
        /* захват завершился В ЭТОМ куске: закрыть элемент (внутри
         * hp_process это делает hp_capture_start — здесь некому) */
        hp_pop_one(state);
        if (left == 0) return;
    }

    if (state->pend_len > 0) {
        /* [HP-STREAM]: достроить конструкцию прошлого куска */
        hp_pend_append(state, p, left);
        size_t used = hp_process(state, state->pend,
                                 (size_t)state->pend_len, 0);
        hp_pend_consume(state, used);
        return;
    }

    size_t used = hp_process(state, p, left, 0);
    if (used < left)
        hp_pend_save(state, p + used, left - used);
}

HtmlDocument* html_parse_end(HtmlParseState* state) {
    if (!state) return NULL;

    /* Task 68 [HP-STREAM]: добить незавершённую конструкцию прошлого
     * куска (pend NUL-терминирован — семантика EOF прежнего парсера:
     * сырой вход вызывателя всегда был NUL-терминирован). */
    if (state->pend_len > 0) {
        hp_process(state, state->pend, (size_t)state->pend_len, 1);
        state->pend_len = 0;
    }
    /* raw-захват без закрытия: содержимое до EOF (HTML5) + закрытие */
    if (state->raw_kind != HP_RAW_NONE)
        hp_raw_finish_eof(state);

    flush_text(state);

    /* Task 68 [HP-EVENT]: событийный режим — закрыть оставшиеся
     * открытые элементы (LIFO), дерево не строилось, DOM нет. */
    if (state->ev) {
        while (state->depth > 1) hp_pop_one(state);
        html_free_element(state->root);
        if (state->pend) free(state->pend);
        if (state->raw_buf) free(state->raw_buf);
        free(state);
        return NULL;
    }

    HtmlDocument* doc = (HtmlDocument*)calloc(1, sizeof(HtmlDocument));
    if (!doc) {
        html_free_element(state->root);
        if (state->text_buf) free(state->text_buf);
        if (state->pend) free(state->pend);
        if (state->raw_buf) free(state->raw_buf);
        free(state);
        return NULL;
    }

    doc->root_element = state->root;

    if (state->text_buf) free(state->text_buf);
    if (state->pend) free(state->pend);
    if (state->raw_buf) free(state->raw_buf);
    free(state);

    return doc;
}


/* ═══════════════════════════════════════════════════════
   Утилиты для отладки / тестирования
   ═══════════════════════════════════════════════════════ */

#ifdef HTML_DEBUG

/* [OPT] Статический visited-массив (64 КБ BSS) вынесен за #ifdef.
   В production-сборке (без HTML_DEBUG) он не занимает места и не
   ломает thread-safety при нескольких окнах браузера. */
#define HTML_VISITED_CAP 16384
static const void* html_visited_ptrs[HTML_VISITED_CAP];
static int html_visited_count = 0;

static int html_was_visited(const void* p) {
    for (int i = 0; i < html_visited_count; i++)
        if (html_visited_ptrs[i] == p) return 1;
    return 0;
}
static void html_mark_visited(const void* p) {
    if (html_visited_count < HTML_VISITED_CAP)
        html_visited_ptrs[html_visited_count++] = p;
}
static void html_clear_visited(void) {
    html_visited_count = 0;
}

static int html_count_elements_impl(HtmlElement* el) {
    if (!el) return 0;
    if (html_was_visited(el)) return 0;
    html_mark_visited(el);
    int count = 1;
    count += html_count_elements_impl(el->child);
    count += html_count_elements_impl(el->sibling);
    return count;
}

int html_count_elements(HtmlElement* el) {
    html_clear_visited();
    int result = html_count_elements_impl(el);
    html_clear_visited();
    return result;
}

static int html_count_text_nodes_impl(HtmlElement* el) {
    if (!el) return 0;
    if (html_was_visited(el)) return 0;
    html_mark_visited(el);
    int count = (el->tag == HTML_TAG_NONE && el->text) ? 1 : 0;
    count += html_count_text_nodes_impl(el->child);
    count += html_count_text_nodes_impl(el->sibling);
    return count;
}

int html_count_text_nodes(HtmlElement* el) {
    html_clear_visited();
    int result = html_count_text_nodes_impl(el);
    html_clear_visited();
    return result;
}

void html_print_tree(HtmlElement* el, int indent) {
    if (!el) return;
    for (int i = 0; i < indent; i++) fprintf(stderr, "  ");
    if (el->tag == HTML_TAG_NONE) {
        fprintf(stderr, "\"%s\"\n", el->text ? el->text : "");
    } else {
        fprintf(stderr, "<%s", html_tag_to_string(el->tag));
        if (el->id) fprintf(stderr," id=\"%s\"", el->id);
        HtmlAttrib* a = el->attrib;
        while (a) {
            if (a->key == HTML_ATTRIB_CLASS) fprintf(stderr," class=\"%s\"", a->value);
            if (a->key == HTML_ATTRIB_HREF) fprintf(stderr," href=\"%s\"", a->value);
            if (a->key == HTML_ATTRIB_SRC) fprintf(stderr," src=\"%s\"", a->value);
            if (a->key == HTML_ATTRIB_STYLE) fprintf(stderr," style=\"%s\"", a->value);
            a = a->next;
        }
        fprintf(stderr, ">\n");
    }
    html_print_tree(el->child, indent + 1);
    html_print_tree(el->sibling, indent);
}

static int html_dump_tree_impl(HtmlElement* el, int indent, int* total_elements, int* total_text) {
    if (!el) return indent - 1;
    if (html_was_visited(el)) {
        for (int i = 0; i < indent; i++) fprintf(stderr, "  ");
        fprintf(stderr, "*** CYCLE DETECTED: tag=%s ptr=%p ***\n",
               html_tag_to_string(el->tag), (void*)el);
        return indent;
    }
    html_mark_visited(el);

    if (el->tag == HTML_TAG_NONE) {
        (*total_text)++;
    } else {
        (*total_elements)++;
    }

    if (el->tag == HTML_TAG_NONE) {
        const char* txt = el->text ? el->text : "";
        int txt_len = (int)strlen(txt);
        for (int i = 0; i < indent; i++) fprintf(stderr, "  ");
        if (txt_len <= 77) {
            fprintf(stderr, "TEXT: \"%s\"\n", txt);
        } else {
            fprintf(stderr, "TEXT: \"%.77s...\"\n", txt);
        }
    } else {
        for (int i = 0; i < indent; i++) fprintf(stderr, "  ");
        fprintf(stderr, "<%s", html_tag_to_string(el->tag));
        if (el->id) fprintf(stderr," id=\"%s\"", el->id);
        HtmlAttrib* a = el->attrib;
        while (a) {
            const char* key_str = a->key_name ? a->key_name : "";
            if (a->key == HTML_ATTRIB_CLASS) key_str = "class";
            else if (a->key == HTML_ATTRIB_STYLE) key_str = "style";
            else if (a->key == HTML_ATTRIB_HREF) key_str = "href";
            else if (a->key == HTML_ATTRIB_SRC) key_str = "src";
            else if (a->key == HTML_ATTRIB_ID) key_str = "id";
            else if (a->key == HTML_ATTRIB_TYPE) key_str = "type";
            else if (a->key == HTML_ATTRIB_NAME) key_str = "name";
            else if (a->key == HTML_ATTRIB_VALUE) key_str = "value";
            else if (a->key == HTML_ATTRIB_ALT) key_str = "alt";
            else if (a->key == HTML_ATTRIB_TITLE) key_str = "title";
            else if (a->key == HTML_ATTRIB_WIDTH) key_str = "width";
            else if (a->key == HTML_ATTRIB_HEIGHT) key_str = "height";
            else if (a->key == HTML_ATTRIB_REL) key_str = "rel";
            else if (a->key == HTML_ATTRIB_CONTENT) key_str = "content";
            else if (a->key == HTML_ATTRIB_CHARSET) key_str = "charset";
            else if (a->key == HTML_ATTRIB_ACTION) key_str = "action";
            else if (a->key == HTML_ATTRIB_METHOD) key_str = "method";
            else if (a->key == HTML_ATTRIB_PLACEHOLDER) key_str = "placeholder";
            else if (a->key == HTML_ATTRIB_ALIGN) key_str = "align";
            else if (a->key == HTML_ATTRIB_TARGET) key_str = "target";
            else if (a->key == HTML_ATTRIB_ONCLICK) key_str = "onclick";
            else if (a->key == HTML_ATTRIB_ONLOAD) key_str = "onload";
            else if (a->key == HTML_ATTRIB_ONERROR) key_str = "onerror";
            else if (a->key == HTML_ATTRIB_COLSPAN) key_str = "colspan";
            else if (a->key == HTML_ATTRIB_ROWSPAN) key_str = "rowspan";
            else if (a->key == HTML_ATTRIB_BORDER) key_str = "border";
            else if (a->key == HTML_ATTRIB_DISABLED) key_str = "disabled";
            else if (a->key == HTML_ATTRIB_CHECKED) key_str = "checked";

            if (a->value && (int)strlen(a->value) > 60) {
                fprintf(stderr, " %s=\"%.57s...\"", key_str, a->value);
            } else {
                fprintf(stderr, " %s=\"%s\"", key_str, a->value ? a->value : "");
            }
            a = a->next;
        }
        fprintf(stderr, "> [parent=%s]\n",
               (el->parent && el->parent->tag != HTML_TAG_NONE) ?
               html_tag_to_string(el->parent->tag) : "root");
    }

    int child_depth = html_dump_tree_impl(el->child, indent + 1, total_elements, total_text);
    int sib_depth = html_dump_tree_impl(el->sibling, indent, total_elements, total_text);
    return (child_depth > sib_depth) ? child_depth : sib_depth;
}

void html_dump_tree(HtmlElement* el) {
    html_clear_visited();
    int total_elements = 0, total_text = 0;
    fprintf(stderr, "=== DOM TREE DUMP ===\n");
    int max_depth = html_dump_tree_impl(el, 0, &total_elements, &total_text);
    fprintf(stderr, "=== STATS: %d element nodes, %d text nodes, max depth %d ===\n",
           total_elements, total_text, max_depth);
    html_clear_visited();
}

#else /* !HTML_DEBUG */

/* В production-сборке debug-функции не занимают BSS и не ломают
   thread-safety. Заглушки для совместимости линковки, если они где-то
   вызываются (обычно нет). */
int html_count_elements(HtmlElement* el)              { (void)el; return 0; }
int html_count_text_nodes(HtmlElement* el)            { (void)el; return 0; }
void html_print_tree(HtmlElement* el, int indent)     { (void)el; (void)indent; }
void html_dump_tree(HtmlElement* el)                  { (void)el; }

#endif /* HTML_DEBUG */