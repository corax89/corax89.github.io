/* task.c — вытесняющая многозадачность N2600-OS.
 *
 * Архитектура переключения контекста:
 *   1. PIT генерирует IRQ0 каждые 1 мс (СЕССИЯ 33: 1000 Гц — было 100 Гц).
 *      Зачем: точные короткие паузы (task_msleep(1) раньше длил 10 мс —
 *      все тайминги USB/WiFi/скана раздувались кратно), плавнее UI,
 *      быстрее реакция горячей замены задач.
 *   2. CPU входит в irq_stub_0 (naked-функция), который:
 *        pusha                  — сохраняет 8 general regs в стеке текущей задачи;
 *        cld; pushl %esp; call _task_schedule
 *                               — передаёт C-функции указатель на pusha-кадр;
 *        movl %eax, %esp        — переключает стек на сохранённый кадр новой задачи;
 *        popa; iret             — восстанавливает regs и EIP/CS/EFLAGS новой задачи.
 *
 *   3. task_schedule():
 *        - инкрементирует системные тики (ticks);
 *        - шлёт EOI master PIC;
 *        - сохраняет tasks[cur].esp = saved_esp;
 *        - инкрементирует uptime задачи, которая только что работала;
 *        - round-robin выбирает следующую активную задачу;
 *        - возвращает tasks[next].esp.
 *
 * Для новой задачи fabricate-стек: на вершине выделенного стека
 * кладётся фейковый кадр iret (EIP=task_trampoline, CS=0x08, EFLAGS=IF=1)
 * и под ним — pusha-кадр из нулей. Первое переключение на новую задачу
 * popa-нет нули и iret-ом прыгает в task_trampoline, который зовёт fn(arg).
 *
 * Главная задача (kmain) — task[0]; её стек не fabricate-ится, так как
 * она уже работает на системном стеке _stack_top.
 *
 * Лимит задач: 256 (увеличен с 8). Каждый слот задаёт имя, статус,
 * стек (16 КиБ), uptime (число тиков, в которых задача исполнялась).
 */
#include "task.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "gdt.h"   /* песочница: gdt_clear_task_region при переиспользовании слота */

#define TASK_STACK_SIZE (32 * 1024)
/* Сессия 13: 16 -> 32 КиБ. КОРНЕВАЯ ПРИЧИНА порчи кучи (см. apps.c):
 * кадр term_exec (ramtree: ents[128]=9.7КБ + cc: src_buf[8КБ]) плюс
 * loader_load (ents[64]=4.8КБ) переваливали за 16КБ — поток писал ниже
 * своего стекового блока в кучу, затирая заголовок соседнего блока
 * (size=0 -> malloc зависал под cli). 32КБ даёт запас; большие массивы
 * к тому же уведены со стека (apps.c: static). */

/* СЕССИЯ 59: КАНАРЕЙКИ СТЕКОВ. Порча кучи вернулась (лог fixed58:
 * «ПОРЧА КУЧИ: блок size=0» — заголовок блока, ИДУЩЕГО СРАЗУ ЗА
 * чьим-то стеком, побит значениями {4,0}). Стек растёт ВНИЗ, поэтому
 * переполнение пишёт сначала в СВОИ нижние байты, потом в заголовок
 * соседнего блока. Канарейка в нижних 8 байтах ЛОВИТ переполнение
 * ДО порчи кучи и называет задачу по имени. */
#define TASK_STACK_CANARY0 0xC7194A5Bu
#define TASK_STACK_CANARY1 0x5BA419C7u

/* Селектор данных ядра (flat 4 ГБ) — синхронизирован с gdt.c */
#define KERNEL_DS 0x10

/* Таймаут по умолчанию для IRQ-ватчдога: 5 секунд (5000 тиков по 1 мс).
 * Должен быть определён ДО task_schedule() (используется там). */
#define TASK_WATCHDOG_TICKS 5000

typedef struct {
    int  used;
    int  finished;
    u32 *esp;
    u8  *stack;
    u32  stack_size;
    char name[16];
    void (*fn)(void *);
    void *arg;
    u32  uptime;
    u32  last_active_tick;  /* последний тик, когда задача работала */
    u32  watchdog_timeout;  /* 0 = нет ватчдога, иначе макс тиков без активности */
    u32  last_uptime;       /* предыдущее значение uptime (для детекции зависания) */
    int  waiting;           /* 1 = задача спит, ждёт события (не «зависла») */
    int  system;            /* 1 = системная задача (ramfs-сервер и т.п.):
                              * kill запрещён — иначе умрёт подсистема ОС */
    int  lock_wait;         /* 1 = задача ждёт блокировку в s_lock (sync.h):
                              * ватчдог такие НЕ убивает — ими управляет
                              * таймаут отбора зависшей блокировки (20 с) */
    int  prio;              /* СЕССИЯ 34: приоритет (0=UI, 1=NORMAL, 2=BG) */
    int  canary;            /* СЕССИЯ 59: 1 = в НИЖНИЕ 8 байт стека записана
                              * канарейка (только собственные стеки; у
                              * песочницы stack = регион — там kapi-копия) */
} task_t;

static task_t tasks[MAX_TASKS];

static inline int task_prio_of(int i, u32 now)
{
    /* Эффективный приоритет: задача, не получавшая CPU дольше
     * TASK_STARVE_TICKS, временно планируется как UI (анти-голодание
     * фона при постоянной готовности UI-задач). */
    int p = tasks[i].prio;
    if (p < 0) p = 0;
    if (p >= TASK_PRIO_LEVELS) p = TASK_PRIO_LEVELS - 1;
    if (p > 0 && (u32)(now - tasks[i].last_active_tick) > TASK_STARVE_TICKS)
        p = 0;
    return p;
}
/* Защита памяти (песочница нативных c4-программ): линейная база региона
 * задачи; 0 = обычная задача ядра (сегменты flat). Массив НЕ static — на
 * него ссылается irq_stub_0 (пересчёт ESP при смене базы SS), поэтому
 * менять тип/порядок нельзя. */
u32 task_region_base[MAX_TASKS];
int cur_task = 0;   /* глобальный: читается из irq_stub_0 (asm) */
static int   n_tasks  = 0;

/* Хук очистки слота: вызывается при переиспользовании слота задачи,
 * у которой был регион песочницы (kill/ватчдог — loader_task_fn не
 * дошёл до своего free). Loader устанавливает. */
static void (*task_slot_cleanup_cb)(int tid);

void task_set_slot_cleanup_hook(void (*cb)(int tid)) { task_slot_cleanup_cb = cb; }

u32 task_get_region_base(int tid)
{
    return (tid >= 0 && tid < MAX_TASKS) ? task_region_base[tid] : 0;
}

void task_set_region_base(int tid, u32 base)
{
    if (tid >= 0 && tid < MAX_TASKS) task_region_base[tid] = base;
}
static u32   last_sched_tick = 0;   /* тик, когда последний раз вызывался scheduler */

/* Системные тики — теперь инкрементируются из task_schedule (раньше timer_irq). */
static volatile u32 ticks = 0;

u32 timer_ticks(void) { return ticks; }
u32 uptime_sec(void)  { return ticks / 1000; }   /* СЕССИЯ 33: 1 тик = 1 мс */

extern void task_trampoline(void);

/* ---------- IRQ0 stub: переключение контекста ----------
 *
 * Защита памяти: кадр задачи теперь включает DS/ES/SS — задача,
 * работающая в песочнице (сегментный лимит, см. loader.c/gdt.c),
 * после вытеснения продолжает с СВОИМИ сегментами. Планировщик
 * работает с сегментами ядра (flat): задачи с лимитами не могут
 * покалечить таблицу tasks[] через чужое прерывание. */
__attribute__((naked, used)) void irq_stub_0(void)
{
    __asm__ __volatile__(
        "pusha\n\t"                  /* сохранить EAX,ECX,EDX,EBX,ESP_orig,EBP,ESI,EDI */
        "pushl %ss\n\t"             /* сегменты прерванной задачи (в её стеке) */
        "pushl %ds\n\t"
        "pushl %es\n\t"
        /* ЗАЩИТА ПАМЯТИ: сначала сегменты ДАННЫХ на ядро (читать
         * cur_task под песочницей нельзя — #GP), и лишь потом
         * пересчёт ESP. ECX после pusha мёртв. */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ds\n\t"
        "movw %cx, %es\n\t"
        /* Если прервана задача в песочнице: её SS имеет базу = регион,
         * ESP — смещение. Переводим ESP в абсолютный (регистр), чтобы
         * после смены SS планировщик работал на том же линейном стеке. */
        "movl cur_task, %eax\n\t"
        "movl task_region_base(,%eax,4), %eax\n\t"
        "addl %eax, %esp\n\t"
        "movw %cx, %ss\n\t"
        "cld\n\t"
        "pushl %esp\n\t"             /* arg: указатель на кадр (es,ds,ss,pusha) */
        "call _task_schedule\n\t"   /* планировщик: вернуть новый ESP в %eax */
        "movl %eax, %esp\n\t"        /* переключение стека (абсолютный адрес кадра) */
        /* DS здесь ещё ядро: читаем регион НОВОЙ задачи до восстановления
         * её сегментов (после popl %ds чтение ядра станет невозможным). */
        "movl cur_task, %eax\n\t"   /* scheduler уже обновил cur_task */
        "movl task_region_base(,%eax,4), %ecx\n\t"
        "popl %es\n\t"               /* сегменты НОВОЙ задачи */
        "popl %ds\n\t"
        "popl %eax\n\t"              /* слот SS новой задачи */
        "movw %ax, %ss\n\t"          /* SS = сегмент новой задачи (база региона) */
        "subl %ecx, %esp\n\t"       /* ESP = смещение в регионе (ядро: -0) */
        "popa\n\t"                   /* восстановить regs новой задачи */
        "iret\n\t"                   /* EIP/CS/EFLAGS новой задачи */
    );
}

/* ---------- планировщик ---------- */

/* FIX [T3]: вызывается из task_schedule (IRQ0-контекст) — см. ниже */
int task_watchdog_irq(u32 timeout_ticks);

u32 *task_schedule(u32 *saved_esp)
{
    u32 now = ticks + 1;
    ticks = now;
    outb(0x20, 0x20);                /* EOI master PIC (IRQ0 — на master) */

    if (n_tasks == 0) return saved_esp;   /* задач нет — остаёмся */

    /* Сохранить контекст текущей задачи */
    tasks[cur_task].esp = saved_esp;

    /* Инкремент uptime и обновление last_active_tick */
    u32 delta = now - last_sched_tick;
    tasks[cur_task].uptime += delta;
    tasks[cur_task].last_active_tick = now;
    last_sched_tick = now;

    /* FIX [T3]: ВАТЧДОГ В КОНТЕКСТЕ ПРЕРЫВАНИЯ. Раньше task_watchdog()
     * вызывался только из главного цикла kmain — если kmain зависал
     * (все приложения выполняются в task[0]!), ватчдог вообще не
     * запускался и зависала ВСЯ система. Здесь мы в IRQ0: прерывания
     * уже запрещены (interrupt gate), поэтому доступ к таблице задач
     * и куче атомарен по определению. Проверяем каждые 512 тиков (~0.5 с). */
    if ((now & 511u) == 0) {         /* ~ каждые 512 тиков (~0.5 с при 1000 Гц) */
        task_watchdog_irq(TASK_WATCHDOG_TICKS);
    }

    /* Поиск следующей активной задачи. СЕССИЯ 34: приоритетное
     * планирование — среди готовых выбираем минимальный эффективный
     * приоритет (с учётом анти-голодания), внутри уровня — round-robin
     * (пропуская завершённые и СПЯЩИЕ — задача в waiting сознательно
     * ждёт события, она не «зависла» и не должна есть слоты). */
    int next = cur_task;
    int found = 0;
    {
        int best = TASK_PRIO_LEVELS;
        for (int i = 0; i < MAX_TASKS; i++) {
            if (!tasks[i].used || tasks[i].finished || tasks[i].waiting)
                continue;
            int p = task_prio_of(i, now);
            if (p < best) best = p;
            if (best == 0) break;
        }
        if (best < TASK_PRIO_LEVELS) {
            for (int t = 0; t < MAX_TASKS; t++) {
                int j = (cur_task + 1 + t) % MAX_TASKS;
                if (!tasks[j].used || tasks[j].finished || tasks[j].waiting)
                    continue;
                if (task_prio_of(j, now) == best) {
                    next = j;
                    found = 1;
                    break;
                }
            }
        }
    }
    if (!found) {
        /* Все задачи завершены/спят — продолжаем текущую (должна быть task[0]) */
        next = 0;
    }
    /* FIX (многопоточный WM): подкачать контекст рендера fb новой задачи
     * (canvas окна или экран). Вызов из IRQ0 — атомарен по определению. */
    fb_task_switch(cur_task, next);
    cur_task = next;
    return tasks[cur_task].esp;
}

/* ---------- API ---------- */

void task_init(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].used = 0;
        tasks[i].finished = 0;
        tasks[i].esp = NULL;
        tasks[i].stack = NULL;
        tasks[i].stack_size = 0;
        tasks[i].name[0] = 0;
        tasks[i].fn = NULL;
        tasks[i].arg = NULL;
        tasks[i].uptime = 0;
        tasks[i].system = 0;
        tasks[i].lock_wait = 0;
    }
    /* task[0] — главная задача (контекст kmain), стек — системный */
    tasks[0].used = 1;
    tasks[0].finished = 0;
    tasks[0].stack = NULL;
    tasks[0].esp = NULL;
    tasks[0].fn = NULL;
    tasks[0].arg = NULL;
    tasks[0].uptime = 0;
    tasks[0].prio = TASK_PRIO_UI;   /* kmain — отзывчивость интерфейса */
    strncpy(tasks[0].name, "main", sizeof(tasks[0].name) - 1);
    tasks[0].name[sizeof(tasks[0].name) - 1] = 0;

    cur_task = 0;
    n_tasks = 1;
    last_sched_tick = 0;
}

static int task_spawn_impl(const char *name, void (*fn)(void *), void *arg,
                           u8 *stack_mem, u32 stack_size, int spawn_prio)
{
    /* Сохраняем IF: task_spawn теперь вызывается и ДО sti() в kmain
     * (создание окон на этапе загрузки) — не должен включать прерывания
     * раньше времени. */
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

    /* Ищем свободный слот (1..MAX_TASKS-1; 0 — главная задача) */
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return -1;
    }

    /* Освобождаем память, если слот уже использовался (завершённая задача).
     * Для внешних стеков (песочница) это ВЕСЬ регион задачи — освобождение
     * отложено до переиспользования слота, потому что задача ещё может
     * стоять на этом стеке в hlt-цикле task_exit().
     * Песочница (kill/ватчдог): loader_task_fn не дошёл до своего free —
     * регион чистим хуком, GDT-запись гасим здесь же. */
    if (tasks[slot].stack) {
        free(tasks[slot].stack);
        tasks[slot].stack = NULL;
    }
    if (task_region_base[slot]) {
        gdt_clear_task_region(slot);
        task_region_base[slot] = 0;
        if (task_slot_cleanup_cb) task_slot_cleanup_cb(slot);
    }

    u8 *stack = stack_mem;
    if (!stack) {
        stack = (u8 *)malloc(TASK_STACK_SIZE);
        if (!stack) {
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            return -1;
        }
        stack_size = TASK_STACK_SIZE;
    }
    if (stack_size == 0) stack_size = TASK_STACK_SIZE;

    /* СЕССИЯ 59: канарейки в НИЖНИЕ 8 байт собственного стека
     * (только для malloc-стеков: у песочницы stack = регион,
     * там по смещению 0 лежит kapi-копия). */
    if (!stack_mem && stack_size >= 16) {
        ((u32 *)stack)[0] = TASK_STACK_CANARY0;
        ((u32 *)stack)[1] = TASK_STACK_CANARY1;
        tasks[slot].canary = 1;
    } else {
        tasks[slot].canary = 0;
    }

    /* Строим кадр: iret (EFLAGS, CS, EIP) + pusha (8 regs) + ss/ds/es.
     * Стек растёт вниз, поэтому кладём с вершины.
     * Сегменты новой задачи — ЯДРА (flat): песочницу (если нужно)
     * loader включает только вокруг вызова entry() — см. sandbox_call. */
    u32 *sp = (u32 *)(stack + stack_size);
    sp -= 1; *sp = 0x00000202;                       /* EFLAGS: reserved bit + IF=1 */
    sp -= 1; *sp = 0x08;                             /* CS */
    sp -= 1; *sp = (u32)(unsigned long)task_trampoline;  /* EIP */
    /* pusha order: EAX, ECX, EDX, EBX, ESP_orig, EBP, ESI, EDI */
    sp -= 1; *sp = 0;                                /* EAX */
    sp -= 1; *sp = 0;                                /* ECX */
    sp -= 1; *sp = 0;                                /* EDX */
    sp -= 1; *sp = 0;                                /* EBX */
    sp -= 1; *sp = (u32)(unsigned long)sp;            /* ESP_orig (игнорируется popa) */
    sp -= 1; *sp = 0;                                /* EBP */
    sp -= 1; *sp = 0;                                /* ESI */
    sp -= 1; *sp = 0;                                /* EDI */
    sp -= 1; *sp = KERNEL_DS;                        /* SS (восстановит stub) */
    sp -= 1; *sp = KERNEL_DS;                        /* DS */
    sp -= 1; *sp = KERNEL_DS;                        /* ES — после fabricate ESP указывает сюда */

    tasks[slot].used = 1;
    tasks[slot].finished = 0;
    tasks[slot].esp = sp;
    tasks[slot].stack = stack;
    tasks[slot].stack_size = stack_size;
    tasks[slot].fn = fn;
    tasks[slot].arg = arg;
    tasks[slot].uptime = 0;
    tasks[slot].last_active_tick = ticks;
    tasks[slot].watchdog_timeout = 0;
    tasks[slot].last_uptime = 0;
    tasks[slot].waiting = 0;
    tasks[slot].system = 0;
    tasks[slot].lock_wait = 0;
    tasks[slot].prio = spawn_prio;
    strncpy(tasks[slot].name, name ? name : "?", sizeof(tasks[slot].name) - 1);
    tasks[slot].name[sizeof(tasks[slot].name) - 1] = 0;
    /* Учёт памяти: стек выделен в контексте ПОРОЖДАЮЩЕЙ задачи —
     * переносим владение на новую (диспетчер задач покажет честные цифры) */
    mem_reassign(stack, slot);
    n_tasks++;

    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return slot;
}

void task_yield(void)
{
    /* Простая уступка: ждём следующего IRQ0. */
    __asm__ __volatile__("hlt");
}

/* Сон на ms миллисекунд с уступкой CPU (СЕССИЯ 33: 1 тик = 1 мс при
 * 1000 Гц — точность ±1 мс вместо ±10 мс).
 * Экспортируется в приложения через kapi->msleep — это честная
 * семантика kdelay(ms) из c4 VM (раньше native-кодогенератор
 * эмитил один task_yield и анимации превращались в один кадр). */
void task_msleep(u32 ms)
{
    u32 start = timer_ticks();
    u32 need = ms;                   /* 1 тик = 1 мс (PIT 1000 Гц) */
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        __asm__ __volatile__("hlt");
    }
}

int task_spawn_ext(const char *name, void (*fn)(void *), void *arg,
                   u8 *stack_mem, u32 stack_size)
{
    return task_spawn_impl(name, fn, arg, stack_mem, stack_size,
                           TASK_PRIO_NORMAL);
}

int task_spawn(const char *name, void (*fn)(void *), void *arg)
{
    return task_spawn_impl(name, fn, arg, NULL, 0, TASK_PRIO_NORMAL);
}

/* СЕССИЯ 34: spawn с приоритетом (wifi/usb/sata/netmon = BG,
 * потоки окон WM = UI). Приложениям и ramfs — обычный task_spawn. */
int task_spawn_prio(const char *name, void (*fn)(void *), void *arg, int prio)
{
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) prio = TASK_PRIO_NORMAL;
    return task_spawn_impl(name, fn, arg, NULL, 0, prio);
}

void task_set_priority(int idx, int prio)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    tasks[idx].prio = prio;
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int task_priority(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return TASK_PRIO_NORMAL;
    if (!tasks[idx].used) return TASK_PRIO_NORMAL;
    return tasks[idx].prio;
}

void task_exit(void)
{
    cli();
    if (tasks[cur_task].used) {
        tasks[cur_task].finished = 1;
        if (n_tasks > 0) n_tasks--;
    }
    sti();
    /* Больше не вернёмся — ждём переключения на другую задачу. */
    for (;;) __asm__ __volatile__("hlt");
}

/* Завершить задачу по индексу. Если задача уже не используется или это
 * текущая задача — для текущей работает как task_exit().
 * Параметр idx может быть любым (проверяется валидность слота).
 * Возвращает 1 при успехе, 0 если слот не используется или задача уже завершена.
 * Стек задачи будет освобождён при следующем task_spawn() в этот слот.
 * СИСТЕМНЫЕ задачи (ramfs-сервер) убивать НЕЛЬЗЯ — их смерть намертво
 * блокирует файловые операции всей ОС; task_kill возвращает 0. */
int task_kill(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (idx == 0) return 0;             /* главную задачу (kmain) убивать нельзя */
    if (!tasks[idx].used) return 0;
    if (tasks[idx].finished) return 0;
    if (tasks[idx].system) return 0;    /* системная задача — под защитой */

    cli();
    tasks[idx].finished = 1;
    if (n_tasks > 0) n_tasks--;
    /* Если убили текущую — уступить CPU */
    if (idx == cur_task) {
        sti();
        for (;;) __asm__ __volatile__("hlt");
    }
    sti();
    return 1;
}

int task_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].used && !tasks[i].finished) n++;
    return n;
}

int task_current(void) { return cur_task; }

/* Пометить задачу как системную (kill запрещён, ватчдог не трогает).
 * Используется для ramfs-сервера и других подсистем ядра. */
void task_set_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].system = 1;
}

int task_is_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].system;
}

const char *task_name(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return "";
    if (!tasks[idx].used) return "";
    return tasks[idx].name;
}

int task_used(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].used;
}

int task_finished(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 1;
    return tasks[idx].finished;
}

u32 task_uptime(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].uptime;
}

/* ---------- trampoline для новых задач ---------- */

void task_trampoline(void)
{
    int me = cur_task;
    if (tasks[me].fn) tasks[me].fn(tasks[me].arg);
    task_exit();
    for (;;) __asm__ __volatile__("hlt");
}

/* ---------------- сон и пробуждение (многопоточный WM) ---------------- */

/* Пометить задачу как спящую (вызывается ПОД cli из task_wait_event). */
void task_set_waiting_me(void)
{
    if (cur_task >= 0 && cur_task < MAX_TASKS)
        tasks[cur_task].waiting = 1;
}

/* Разбудить задачу по индексу: снять waiting — следующий тик IRQ0
 * вернёт её в планирование. Безопасно из любого контекста.
 * FIX (ватчдог убивал разбуженные задачи): одновременно ОБНУЛЯЕМ
 * last_active_tick. Сценарий бага: задача спала 20 с (например, пока
 * держатель блокировки завис) — kmain будит её (waiting=0), но до
 * первого слота планировщика ватчдог видел «не планировалась 20 с»
 * и УБИВАЛ её. Теперь будение = отсчёт простоя заново (5 с форы,
 * а полный цикл планировщика ≤ 256×10 мс = 2.6 с). */
void task_wake(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used || tasks[idx].finished) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (tasks[idx].used && !tasks[idx].finished) {
        tasks[idx].waiting = 0;
        tasks[idx].last_active_tick = ticks;   /* сброс счётчика простоя */
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int task_is_waiting(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].waiting;
}

/* Пометить/снять признак «жду блокировку» для ТЕКУЩЕЙ задачи.
 * Вызывается из s_lock (sync.h) ПОД cli — атомарно. Задача в ожидании
 * блокировки — НЕ «зависла»: ватчдог её не трогает, её судьбу решает
 * таймаут отбора блокировки (SLOCK_STALE_TICKS). Иначе ватчдог убивал
 * ждущие задачи через 5 с — и при зависании держателя выкашивал все
 * окна ДО срабатывания отбора блокировки. */
void task_set_lockwait_me(int on)
{
    if (cur_task < 0 || cur_task >= MAX_TASKS) return;
    tasks[cur_task].lock_wait = on ? 1 : 0;
}

int task_is_lockwait(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].lock_wait;
}

/* ---------- Ватчдог ---------- */

void task_set_watchdog(int idx, u32 timeout_ticks)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].watchdog_timeout = timeout_ticks;
    tasks[idx].last_uptime = tasks[idx].uptime;
}

u32 task_get_watchdog(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].watchdog_timeout;
}

/* FIX [T3b]: версия для вызова ИЗ ПРЕРЫВАНИЯ (уже с IF=0 — без cli/sti).
 * Критерий: задача не получала CPU дольше limit тиков. Заметим честно:
 * задача, зависшая в плотном цикле while(1){} БЕЗ hlt, всё равно
 * получает CPU по round-robin и этим критерием не ловится — для этого
 * нужны счётчики команд/привилегии (нет в x86 без MMU/PIT-профилирования).
 * Но главный сценарий пользователя (зависает kmain с приложениями,
 * либо задача навсегда теряет CPU) теперь отрабатывается: если task[0]
 * (kmain с браузером/терминалом) не планировался дольше таймаута —
 * зависшие вложенные задачи убиваются, система продолжает жить.
 * Стек НЕ освобождаем немедленно (esp задачи может указывать в него,
 * а free() из IRQ-контекста опасен) — отложено до task_spawn в этот слот. */
int task_watchdog_irq(u32 timeout_ticks)
{
    int killed = 0;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) continue;
        /* Системные задачи (ramfs-сервер) ватчдог НЕ убивает: их гибель
         * блокирует файловые операции навсегда. Они почти всегда спят
         * (waiting), а активными бывают microseconds при копировании. */
        if (tasks[i].system) continue;
        /* FIX (многопоточный WM): спящая задача (waiting) — это НЕ
         * зависание: она ждёт события. Иначе ватчдог убивал бы каждое
         * простаивающее окно через 5 секунд. */
        if (tasks[i].waiting) continue;
        /* Задача в ожидании блокировки (s_lock) — тоже НЕ зависание:
         * пока держатель жив, ждущий честно спит в hlt. Раньше ватчдог
         * убивал такие задачи через 5 с — и при 20-секундном зависании
         * держателя выкашивал ВСЕ окна до отбора блокировки. */
        if (tasks[i].lock_wait) continue;

        u32 idle = ticks - tasks[i].last_active_tick;
        u32 limit = tasks[i].watchdog_timeout ? tasks[i].watchdog_timeout
                                              : timeout_ticks;
        if (limit == 0) continue;

        if (idle > limit) {
            /* диагностика в serial: КТО убит (имя + возраст) */
            {
                extern void serial_puts(const char *s);
                char b[64];
                snprintf(b, sizeof(b), "[watchdog] kill #%d '%s' idle=%u\n",
                         i, tasks[i].name, idle);
                serial_puts(b);
            }
            tasks[i].finished = 1;
            if (n_tasks > 0) n_tasks--;
            killed++;
            /* Стек НЕ трогаем: tasks[i].stack освобождается в task_spawn() */
        }
    }
    return killed;
}

/* Публичная версия — с защитой cli/sti (FIX [T3c]: раньше меняла
 * таблицу задач и звала free() без запрета прерываний — гонка с IRQ0
 * и порча кучи). */
int task_watchdog(u32 timeout_ticks)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int killed = task_watchdog_irq(timeout_ticks);
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return killed;
}

/* СЕССИЯ 59: проверка канареек стеков (зовётся раз в секунду из
 * главного цикла). Переполнение стека задачи — единственный известный
 * механизм порчи кучи «заголовок соседнего блока» (сессии 13 и 59);
 * канарейка бьётся РАНЬШЕ заголовка и называет виновника. */
void task_check_stack_canaries(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].canary != 1 || !tasks[i].stack) continue;
        u32 c0 = ((u32 *)tasks[i].stack)[0];
        u32 c1 = ((u32 *)tasks[i].stack)[1];
        if (c0 == TASK_STACK_CANARY0 && c1 == TASK_STACK_CANARY1) continue;
        tasks[i].canary = 2;              /* доложить ОДИН раз */
        extern void serial_puts(const char *s);
        char b[96];
        snprintf(b, sizeof(b),
                 "[task] СТЕК ПЕРЕПОЛНЕН: #%d '%s' — кадр ушёл ниже блока "
                 "(портит кучу)\n", i, tasks[i].name);
        serial_puts(b);
    }
}
