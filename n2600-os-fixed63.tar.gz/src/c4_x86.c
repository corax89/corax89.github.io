/* c4_x86.c — x86-кодогенератор: превращает байт-код c4 в настоящий
 * flat-binary исполняемый файл для N2600-OS.
 *
 *   1) c4.c парсит исходник и строит IR (байт-код) в пуле `e`.
 *   2) Этот файл проходит по IR и эмитит эквивалентный x86 машинный код.
 *   3) Результат — flat-binary с точкой входа int entry(kapi_t *k, void *win),
 *      который запускается через loader_spawn() как обычное приложение.
 *
 * Соглашения по регистрам (32-bit cdecl):
 *   EAX = аккумулятор "a" (в c4 VM) — НЕ пушится результатами операций
 *   ESP = виртуальный стек (по 4 байта на ячейку, как в c4)
 *   EBP = base pointer "bp" (для локальных переменных)
 *   EDI = сохранённый указатель kapi_t* (передаётся при entry)
 *   ESI = сохранённый указатель win (передаётся при entry)
 *   EBX = кадр entry() — для unwind из exit() с любой глубины вызовов
 *
 * СООТВЕТСТВИЕ МОДЕЛИ c4 VM (главное после фиксов):
 *   - IMM/LEA кладут результат в EAX (a), ПУШ делает только PSH;
 *   - бинарные операторы: pop ecx (ЛЕВЫЙ операнд), xchg для
 *     некоммутативных, результат в EAX;
 *   - syscall: аргументы на стеке в c4-порядке ([ESP]=последний),
 *     перед вызовом копируются в cdecl-порядок ([ESP]=первый),
 *     оригиналы снимает следующий в байт-коде ADJ;
 *   - результат syscall'а остаётся в EAX (= "a"), БЕЗ пуша.
 *
 * Формат .bin (C4N1): [magic 'C4N1'][u32 code_size][u32 data_size]
 *   [u32 n_relocs][code][data][relocs: u32 code_off...].
 * Сегмент данных у каждого бинарника СВОЙ: loader выделяет отдельный
 * блок, копирует данные и патчит imm32-адреса данных (relocs) —
 * перекомпиляция одной программы больше НЕ затирает данные другой.
 */
#include "c4.h"
#include "kapi.h"
#include "types.h"
#include "string.h"
#include "mem.h"
#include "sync.h"
#include "ramfs.h"
#include "loader.h"
#include "boot.h"

extern void serial_puts(const char *s);

/* ---------- opcode enum (должен совпадать с c4.c) ---------- */
enum {
  LEA, IMM, JMP, JSR, BZ, BNZ, ENT, ADJ, LEV, LI, LC, SI, SC, PSH,
  OR, XOR, AND, EQ, NE, LT, GT, LE, GE, SHL, SHR, ADD, SUB, MUL, DIV, MOD,
  OPEN, READ, CLOS, PRTF, MALC, FREE, MSET, MCMP, EXIT,
  KINIT, KQUIT, KDELAY, KFILL, KTEXT, KFLIP, KRGB, KEVENT,
  KCLEAR, KW, KH, KMTIME,
  STRLEN, STRCPY, STRCMP,
  /* Логический (беззнаковый) сдвиг вправо — должен совпадать с c4.c
   * (добавлять только в конец, см. комментарий там) */
  USHR,
  /* CMScript GUI API (окна/кнопки) — ТОЛЬКО В КОНЦЕ, в порядке c4.c */
  WOPEN, WCLOSE, WALIVE, WCLEAR, WRECT, WTEXT, WUPD, BADD, BCLICK, BSETLB
};

/* Смещения полей в kapi_t (в байтах, чтобы генерировать [edi+offset]).
 * Контролируются STATIC_ASSERT-ами ниже — при изменении kapi_t сборка
 * упадёт сразу, а не «вызовы уйдут в чужие поля» в рантайме. */
#define KAPI_FB_FILL_RECT    0
#define KAPI_FB_RECT         4
#define KAPI_FB_HLINE        8
#define KAPI_FB_TEXT         12
#define KAPI_FB_CHAR         16
#define KAPI_FB_RGB          20
#define KAPI_FB_WIDTH        24
#define KAPI_FB_HEIGHT       28
#define KAPI_FB_FILL_SCREEN  32
#define KAPI_WIN_CONTENT_W   36
#define KAPI_WIN_CONTENT_H   40
#define KAPI_WIN_INVALIDATE  44
#define KAPI_MALLOC          48
#define KAPI_FREE            52
#define KAPI_UPTIME_SEC      56
#define KAPI_TIMER_TICKS     60
#define KAPI_TASK_YIELD      64
#define KAPI_TASK_SPAWN      68
#define KAPI_SNPRINTF        72
#define KAPI_STRLEN          76
#define KAPI_STRCMP          80
#define KAPI_STRCPY         84
#define KAPI_MEMCMP          88
#define KAPI_MEMSET          92
#define KAPI_MEMCPY          96
#define KAPI_C4_PRINT_STR    100
#define KAPI_C4_EVENT_POLL   104
#define KAPI_C4_PRINTF_VA    108
#define KAPI_MSLEEP          112

/* CMScript GUI API (окна/кнопки) — поля kapi_t добавлены В КОНЕЦ;
 * имена в c4-программах: win_open/win_close/win_alive/win_clear/
 * win_rect/win_text/win_update/btn_add/btn_clicked/btn_set_label */
#define KAPI_WIN_OPEN        116
#define KAPI_WIN_CLOSE       120
#define KAPI_WIN_ALIVE       124
#define KAPI_WIN_CLEAR       128
#define KAPI_WIN_RECT        132
#define KAPI_WIN_TEXT        136
#define KAPI_WIN_UPDATE      140
#define KAPI_BTN_ADD         144
#define KAPI_BTN_CLICKED     148
#define KAPI_BTN_SET_LABEL   152

/* сессия 60: MP3-декодер dr_mp3 (mp3svc.c) — поля kapi_t зарезервированы
 * для приложений c4/CMScript; пока без intrinsics в c4-компиляторе,
 * смещения зафиксированы для стабильности ABI. */
#define KAPI_MP3_OPEN_MEM    156
#define KAPI_MP3_CLOSE       160
#define KAPI_MP3_CHANNELS    164
#define KAPI_MP3_RATE        168
#define KAPI_MP3_READ_S16    172
#define KAPI_MP3_SEEK        176
#define KAPI_MP3_TOTAL       180

/* Если layout kapi_t разъехался с константами — сборка обязана упасть. */
STATIC_ASSERT(__builtin_offsetof(kapi_t, fb_fill_rect)   == KAPI_FB_FILL_RECT,   kapi_off_0);
STATIC_ASSERT(__builtin_offsetof(kapi_t, fb_text)        == KAPI_FB_TEXT,        kapi_off_12);
STATIC_ASSERT(__builtin_offsetof(kapi_t, win_invalidate) == KAPI_WIN_INVALIDATE, kapi_off_44);
STATIC_ASSERT(__builtin_offsetof(kapi_t, malloc)         == KAPI_MALLOC,         kapi_off_48);
STATIC_ASSERT(__builtin_offsetof(kapi_t, memset)         == KAPI_MEMSET,         kapi_off_92);
STATIC_ASSERT(__builtin_offsetof(kapi_t, c4_print_str)   == KAPI_C4_PRINT_STR,   kapi_off_100);
STATIC_ASSERT(__builtin_offsetof(kapi_t, c4_printf_va)   == KAPI_C4_PRINTF_VA,   kapi_off_108);
STATIC_ASSERT(__builtin_offsetof(kapi_t, msleep)         == KAPI_MSLEEP,         kapi_off_112);
STATIC_ASSERT(__builtin_offsetof(kapi_t, win_open)       == KAPI_WIN_OPEN,       kapi_off_116);
STATIC_ASSERT(__builtin_offsetof(kapi_t, btn_set_label)  == KAPI_BTN_SET_LABEL,  kapi_off_152);
STATIC_ASSERT(__builtin_offsetof(kapi_t, mp3_open_mem)   == KAPI_MP3_OPEN_MEM,   kapi_off_156);
STATIC_ASSERT(__builtin_offsetof(kapi_t, mp3_total_frames) == KAPI_MP3_TOTAL,    kapi_off_180);

/* ---------- эмиттер x86 машинного кода ---------- */
/* FIX: em1 при переполнении буфера раньше МОЛЧАВО терял байты — получался
 * «тихо» обрезанный мусорный код. Теперь переполнение фиксируется флагом
 * и кодогенерация заканчивается ошибкой. */
typedef struct {
    u8 *buf;
    u32 pos;
    u32 cap;
    int of;      /* 1 = было переполнение */
} emitter_t;

static inline void em1(emitter_t *em, u8 b) {
    if (em->pos < em->cap) em->buf[em->pos++] = b;
    else em->of = 1;
}
static inline void em4(emitter_t *em, u32 v) {
    em1(em, v & 0xFF);
    em1(em, (v >> 8) & 0xFF);
    em1(em, (v >> 16) & 0xFF);
    em1(em, (v >> 24) & 0xFF);
}

/* push imm32: 68 imm32 */
static void em_push_imm32(emitter_t *em, u32 val) { em1(em, 0x68); em4(em, val); }
/* push eax: 50 */
static void em_push_eax(emitter_t *em) { em1(em, 0x50); }
/* pop eax: 58 */
static void em_pop_eax(emitter_t *em) { em1(em, 0x58); }
/* pop ecx: 59 */
static void em_pop_ecx(emitter_t *em) { em1(em, 0x59); }
/* mov eax, imm32: B8 imm32 */
static void em_mov_eax_imm32(emitter_t *em, u32 val) { em1(em, 0xB8); em4(em, val); }
/* mov eax, [eax]: 8B 00 (load int through pointer, LI) */
static void em_mov_eax_deref_eax(emitter_t *em) { em1(em, 0x8B); em1(em, 0x00); }
/* movsx eax, byte [eax]: 0F BE 00 (load SIGNED char through pointer, LC) */
static void em_movsx_eax_byte_deref_eax(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xBE); em1(em, 0x00);
}
/* mov [ecx], eax: 89 01 (store int, SI) */
static void em_mov_deref_ecx_eax(emitter_t *em) { em1(em, 0x89); em1(em, 0x01); }
/* mov [ecx], al: 88 01 (store char, SC) */
static void em_mov_deref_ecx_al(emitter_t *em) { em1(em, 0x88); em1(em, 0x01); }
/* movsx eax, al: 0F BE C0 (sign-extend al to eax — char знаковый в c4) */
static void em_movsx_eax_al(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0xBE); em1(em, 0xC0);
}

/* Арифметика: pop ecx; <op> eax, ecx */
static void em_add_eax_ecx(emitter_t *em) { em1(em, 0x01); em1(em, 0xC8); }
static void em_sub_eax_ecx(emitter_t *em) { em1(em, 0x29); em1(em, 0xC8); }
static void em_imul_eax_ecx(emitter_t *em) { em1(em, 0x0F); em1(em, 0xAF); em1(em, 0xC1); }
static void em_xor_eax_ecx(emitter_t *em) { em1(em, 0x31); em1(em, 0xC8); }
static void em_or_eax_ecx(emitter_t *em)  { em1(em, 0x09); em1(em, 0xC8); }
static void em_and_eax_ecx(emitter_t *em) { em1(em, 0x21); em1(em, 0xC8); }
static void em_cdq(emitter_t *em) { em1(em, 0x99); }
static void em_idiv_ecx(emitter_t *em) { em1(em, 0xF7); em1(em, 0xF9); }
static void em_mov_eax_edx(emitter_t *em) { em1(em, 0x89); em1(em, 0xD0); }
static void em_cmp_eax_ecx(emitter_t *em) { em1(em, 0x39); em1(em, 0xC8); }
static void em_setcc_eax(emitter_t *em, u8 op) {
    em1(em, 0x0F); em1(em, op); em1(em, 0xC0);
    em1(em, 0x0F); em1(em, 0xB6); em1(em, 0xC0);
}
static void em_xchg_eax_ecx(emitter_t *em) { em1(em, 0x91); }
static void em_shl_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE0); }
/* SHR в c4 — АРИФМЕТИЧЕСКИЙ сдвиг (int знаковый): sar eax, cl = D3 F8.
 * USHR — ЛОГИЧЕСКИЙ сдвиг (unsigned): shr eax, cl = D3 E8 */
static void em_sar_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xF8); }
static void em_shr_eax_cl(emitter_t *em) { em1(em, 0xD3); em1(em, 0xE8); }
static void em_test_eax_eax(emitter_t *em) { em1(em, 0x85); em1(em, 0xC0); }
static void em_test_ecx_ecx(emitter_t *em) { em1(em, 0x85); em1(em, 0xC9); }

/* jmp rel32: E9 rel32 — возвращает offset поля rel32 для последующего патча */
static u32 em_jmp_rel32(emitter_t *em) {
    em1(em, 0xE9);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jz rel32: 0F 84 rel32 */
static u32 em_jz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x84);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* jnz rel32: 0F 85 rel32 */
static u32 em_jnz_rel32(emitter_t *em) {
    em1(em, 0x0F); em1(em, 0x85);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* call rel32: E8 rel32 */
static u32 em_call_rel32(emitter_t *em) {
    em1(em, 0xE8);
    u32 off = em->pos;
    em4(em, 0);
    return off;
}
/* add esp, imm8: 83 C4 imm8 */
static void em_add_esp_imm8(emitter_t *em, u8 v) { em1(em, 0x83); em1(em, 0xC4); em1(em, v); }
/* add esp, imm32: 81 C4 imm32 */
static void em_add_esp_imm32(emitter_t *em, u32 v) { em1(em, 0x81); em1(em, 0xC4); em4(em, v); }

/* enter: push ebp; mov ebp, esp; sub esp, size */
static void em_enter(emitter_t *em, u32 size) {
    em1(em, 0x55);
    em1(em, 0x89); em1(em, 0xE5);
    if (size > 0) {
        if (size <= 127) {
            em1(em, 0x83); em1(em, 0xEC); em1(em, (u8)size);
        } else {
            em1(em, 0x81); em1(em, 0xEC); em4(em, size);
        }
    }
}
/* leave; ret (зарезервировано для будущих путей — не использовано) */
__attribute__((unused)) static void em_leave_ret(emitter_t *em) { em1(em, 0xC9); em1(em, 0xC3); }

/* lea eax, [ebp + disp32]: 8D 85 disp32 */
static void em_lea_eax_ebp_disp32(emitter_t *em, i32 disp) {
    em1(em, 0x8D); em1(em, 0x85); em4(em, (u32)disp);
}

/* ---------- таблица relocation (переходы байт-код → x86) ---------- */
typedef struct {
    u32 src_x86_offset;      /* где записано rel32 (подлежит патчу) */
    u32 target_bc_cell;      /* индекс int-ячейки в байт-коде */
} reloc_t;

#define MAX_RELOCS 8192
static reloc_t g_relocs[MAX_RELOCS];
static int g_n_relocs = 0;

/* Фикспейсы переходов на эпилог деления на ноль (jmp divzero) */
#define MAX_DIVFIX 512
static u32 g_divfix[MAX_DIVFIX];
static int g_n_divfix = 0;

/* Релокации сегмента данных: x86-offset imm32, значение = смещение
 * в сегменте данных (loader добавит базу выделенного блока данных). */
#define MAX_DATA_RELOCS 8192
static u32 g_data_relocs[MAX_DATA_RELOCS];
static int g_n_data_relocs = 0;

/* ---------- карта {bc_cell → x86_offset} ---------- */
typedef struct {
    u32 bc_cell;
    u32 x86_offset;
} bc_map_t;

#define MAX_MAPS 16384
static bc_map_t g_map[MAX_MAPS];
static int g_n_maps = 0;

static u32 bc_to_x86(u32 bc_cell) {
    for (int i = 0; i < g_n_maps; i++) {
        if (g_map[i].bc_cell == bc_cell) return g_map[i].x86_offset;
    }
    return 0xFFFFFFFFu;
}

static void bc_map_add(u32 bc_cell, u32 x86_offset) {
    /* Заменяем существующую запись (на случай повторного вызова) */
    for (int i = 0; i < g_n_maps; i++) {
        if (g_map[i].bc_cell == bc_cell) {
            g_map[i].x86_offset = x86_offset;
            return;
        }
    }
    if (g_n_maps < MAX_MAPS) {
        g_map[g_n_maps].bc_cell = bc_cell;
        g_map[g_n_maps].x86_offset = x86_offset;
        g_n_maps++;
    }
}

/* Цели переходов в байт-коде — АБСОЛЮТНЫЕ указатели (le + cell);
 * карта построена на индексах ячеек. Пересчёт по базе текст-пула.
 * FIX [C42]: без этого ни один переход не находился в карте
 * (rel32 оставались нулями — циклы/ветвления прыгали на следующую
 * инструкцию, программы зацикливались или выполнялись один раз). */
static u32 bc_norm_target(u32 target) {
    extern u32 c4_compile_text_base;
    u32 base = c4_compile_text_base;
    if (base && target >= base && target < base + 65536u * 4u) {
        return (target - base) >> 2;   /* / sizeof(int) */
    }
    return target;   /* уже индекс (или что-то странное — пусть карта решит) */
}

static void add_reloc(u32 src, u32 target_bc) {
    if (g_n_relocs < MAX_RELOCS) {
        g_relocs[g_n_relocs].src_x86_offset = src;
        g_relocs[g_n_relocs].target_bc_cell = bc_norm_target(target_bc);
        g_n_relocs++;
    }
}

/* Является ли ячейка байт-кода операндом IMM, ссылающимся на сегмент
 * данных (строки/глобалы)? Метки ставит компилятор c4.c. */
__attribute__((unused)) static int imm_cell_is_data(u32 operand_cell) {
    extern u32 c4_imm_data_cells[];
    extern int  c4_n_imm_data_cells;
    for (int i = 0; i < c4_n_imm_data_cells; i++) {
        if (c4_imm_data_cells[i] == operand_cell) return 1;
    }
    return 0;
}

/* ---------- генерация syscall (вызов через kapi) ----------
 *
 * Аргументы лежат на стеке в ПОРЯДКЕ c4: [ESP] = последний аргумент,
 * [ESP+4*(n-1)] = первый. cdecl ждёт [ESP] = первый аргумент.
 *
 * Реверс: последовательность push [esp + 8*(k-1)] для k=1..n кладёт
 * копии аргументов в правильном cdecl-порядке ПОВЕРХ оригиналов
 * (доказано индукцией: на шаге k читается [esp0 + 4*(k-1)] = аргумент
 * n-k+1; последний пуш — первый аргумент → он на вершине).
 *
 * После вызова КОПИИ снимаются здесь; оригиналы снимает следующий в
 * байт-коде ADJ. Результат остаётся в EAX (= "a" виртуальной машины),
 * БЕЗ пуша (в VM syscall не кладёт результат на стек). */
static void emit_syscall(emitter_t *em, u32 kapi_offset, int n_args) {
    /* 1. Реверс аргументов */
    for (int k = 1; k <= n_args; k++) {
        u32 d = 8u * (u32)(k - 1);
        if (d <= 127) {
            em1(em, 0xFF); em1(em, 0x74); em1(em, 0x24); em1(em, (u8)d);
        } else {
            em1(em, 0xFF); em1(em, 0xB4); em1(em, 0x24); em4(em, d);
        }
    }
    /* 2. mov eax, [edi + kapi_offset] — FIX(Баг 1): disp8 требует
     * ModRM 0x47 (mod=01), а не 0x87 (mod=10 = disp32, декодер
     * съедал 4 байта и весь последующий код превращался в мусор). */
    if (kapi_offset <= 127) {
        em1(em, 0x8B); em1(em, 0x47); em1(em, (u8)kapi_offset);
    } else {
        em1(em, 0x8B); em1(em, 0x87); em4(em, kapi_offset);
    }
    /* call eax */
    em1(em, 0xFF); em1(em, 0xD0);
    /* 3. Снять только КОПИИ (n_args*4); оригиналы снимет ADJ */
    if (n_args > 0) {
        u32 cleanup = (u32)n_args * 4u;
        if (cleanup <= 127) em_add_esp_imm8(em, (u8)cleanup);
        else em_add_esp_imm32(em, cleanup);
    }
    /* 4. Результат в EAX; НЕ пушим (FIX Баг 5: раньше текли 4 байта
     * на каждый вызов → ESP уезжал → ret по мусору). */
}

static void set_diag(char *diag, u32 diag_max, const char *m) {
    if (diag && diag_max) {
        u32 L = (u32)strlen(m);
        if (L >= diag_max) L = diag_max - 1;
        memcpy(diag, m, L);
        diag[L] = 0;
    }
}

/* ---------- главный кодогенератор ---------- */
int c4_compile_to_native(const char *src, char *diag, u32 diag_max,
                         void *out_buf, u32 out_max, u32 *out_size)
{
    static int bc_pool[65536];           /* 256КБ — для байт-кода */
    static u8  data_pool[65536];         /* 64КБ — для сегмента данных */
    u32 bc_len_cells = 0;
    u32 data_len = 0;
    u32 entry_cells = 0;

    /* Сериализация: c4_compile (внутри) берёт c4_run_lock, но СТАТИЧЕСКИЕ
     * пулы/карты/фикспейсы ЭТОГО модуля живут и после его释放 — без
     * второй блокировки два окна-редактора, компилирующие одновременно,
     * калечили бы байт-код друг друга. */
    static volatile int c4_codegen_lock = 0;
    s_lock(&c4_codegen_lock);

    if (diag && diag_max) diag[0] = 0;

    if (!c4_compile(src, diag, diag_max,
                    bc_pool, sizeof(bc_pool), &bc_len_cells,
                    data_pool, sizeof(data_pool), &data_len,
                    &entry_cells)) {
        s_unlock(&c4_codegen_lock);
        return -1;
    }

    emitter_t em = { (u8 *)out_buf, 0, out_max, 0 };
    g_n_relocs = 0;
    g_n_maps = 0;
    g_n_divfix = 0;
    g_n_data_relocs = 0;

    /* База сегмента данных на момент компиляции — IMM-операнды строк и
     * глобалов содержат абсолютные адреса data_pool компилятора; мы
     * переписываем их на смещения и релоцируем при загрузке. */
    extern u32 c4_compile_data_base;
    u32 data_base = c4_compile_data_base;

    /* Entry stub: int entry(kapi_t *k, void *win)
     *   55            push ebp
     *   89 E5         mov ebp, esp
     *   53            push ebx                 ; сохранить EBX вызывателя (cdecl)
     *   89 EB         mov ebx, ebp             ; EBX = кадр entry (unwind для exit)
     *   8B 7D 08      mov edi, [ebp+8]         ; kapi
     *   8B 75 0C      mov esi, [ebp+12]        ; win
     *   E8 rel32      call main                ; НАСТОЯЩИЙ адрес возврата
     *   5B            pop ebx                  ; восстановить EBX вызывателя
     *   C9            leave                    ; esp=entry ebp; pop ebp
     *   C3            ret                      ; → в loader (EAX = код возврата)
     *
     * FIX(Баг 6, ревизия 2): в первой версии вход в main шёл через
     * `push imm32 lret; jmp main` — но lret прошивался СМЕЩЕНИЕМ в буфере,
     * а код грузится по произвольному адресу кучи: main возвращался по
     * адресу 0x16 (мусор) вместо эпилога. call rel32 кладёт НАСТОЯЩИЙ
     * адрес возврата — релокация не нужна, код остаётся position-independent.
     * unwind из exit() (mov esp,ebx; ...; ret) не зависит от способа входа.
     */
    em1(&em, 0x55);                                  /* push ebp */
    em1(&em, 0x89); em1(&em, 0xE5);                   /* mov ebp, esp */
    em1(&em, 0x53);                                   /* push ebx */
    em1(&em, 0x89); em1(&em, 0xEB);                   /* mov ebx, ebp */
    em1(&em, 0x8B); em1(&em, 0x7D); em1(&em, 0x08);   /* mov edi, [ebp+8] */
    em1(&em, 0x8B); em1(&em, 0x75); em1(&em, 0x0C);   /* mov esi, [ebp+12] */
    u32 entry_call_offset = em_call_rel32(&em);       /* call main (patched later) */
    em1(&em, 0x5B);                                   /* pop ebx */
    em1(&em, 0xC9);                                   /* leave */
    em1(&em, 0xC3);                                   /* ret */

    /* Single pass: emit each c4 opcode as x86 */
    u32 bc = 1;  /* pool[0] is unused in c4 */
    while (bc < bc_len_cells) {
        /* Record map BEFORE emitting (jump targets at this cell resolve here) */
        bc_map_add(bc, em.pos);

        int op = bc_pool[bc++];
        switch (op) {
            case IMM: {
                u32 val = (u32)bc_pool[bc++];
                /* Ссылка на сегмент данных (строка/глобал): превратим в
                 * смещение и запишем релокацию — loader подставит базу
                 * выделенного блок данных. FIX: раньше здесь прошивался
                 * адрес data_pool КОМПИЛЯТОРА — любая перекомпиляция
                 * затирала данные всех запущенных бинарников. */
                if (data_base != 0 && val >= data_base && val < data_base + data_len) {
                    u32 x86_imm_off = em.pos + 1;   /* поле imm32 после B8 */
                    if (g_n_data_relocs < MAX_DATA_RELOCS)
                        g_data_relocs[g_n_data_relocs++] = x86_imm_off;
                    val = val - data_base;           /* смещение в сегменте данных */
                }
                /* FIX(Баг 2): IMM кладёт значение в EAX (аккумулятор "a"),
                 * НЕ в стек — пуш в c4 делает только PSH. */
                em_mov_eax_imm32(&em, val);
                break;
            }
            case LEA: {
                i32 offset = (i32)bc_pool[bc++];
                i32 disp = offset * 4;
                /* FIX(Баг 2): LEA = a = &local, БЕЗ пуша (лишний push
                 * сдвигал стек — SI брал не тот адрес и писал по диким
                 * указателям). */
                em_lea_eax_ebp_disp32(&em, disp);
                break;
            }
            case JMP: {
                u32 target = (u32)bc_pool[bc++];
                u32 src = em_jmp_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case JSR: {
                u32 target = (u32)bc_pool[bc++];
                u32 src = em_call_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BZ: {
                u32 target = (u32)bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case BNZ: {
                u32 target = (u32)bc_pool[bc++];
                em_test_eax_eax(&em);
                u32 src = em_jnz_rel32(&em);
                add_reloc(src, target);
                break;
            }
            case ENT: {
                u32 size = (u32)bc_pool[bc++];
                em_enter(&em, size * 4);
                break;
            }
            case ADJ: {
                u32 n = (u32)bc_pool[bc++];
                u32 cleanup = n * 4;
                if (cleanup <= 127) em_add_esp_imm8(&em, (u8)cleanup);
                else em_add_esp_imm32(&em, cleanup);
                break;
            }
            case LEV: {
                em1(&em, 0xC9); em1(&em, 0xC3);   /* leave; ret */
                break;
            }
            case LI: {
                em_mov_eax_deref_eax(&em);
                break;
            }
            case LC: {
                /* char в c4 ЗНАКОВЫЙ: movsx, а не movzx */
                em_movsx_eax_byte_deref_eax(&em);
                break;
            }
            case SI: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_eax(&em);
                break;
            }
            case SC: {
                em_pop_ecx(&em);
                em_mov_deref_ecx_al(&em);
                em_movsx_eax_al(&em);
                break;
            }
            case PSH: {
                em_push_eax(&em);
                break;
            }
            case OR:  em_pop_ecx(&em); em_or_eax_ecx(&em); break;
            case XOR: em_pop_ecx(&em); em_xor_eax_ecx(&em); break;
            case AND: em_pop_ecx(&em); em_and_eax_ecx(&em); break;
            case EQ:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x94); break;
            case NE:  em_pop_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x95); break;
            /* FIX(Баг 3): в c4 a = *sp++ OP a — pop это ЛЕВЫЙ операнд,
             * EAX — правый. Для некоммутативных операций нужен xchg,
             * иначе 10-x превращался в x-10, а i<10 в 10<i (циклы
             * умирали или зависали навсегда). */
            case LT:  em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9C); break;
            case GT:  em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9F); break;
            case LE:  em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9E); break;
            case GE:  em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_cmp_eax_ecx(&em); em_setcc_eax(&em, 0x9D); break;
            case SHL:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shl_eax_cl(&em);
                break;
            case SHR:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_sar_eax_cl(&em);   /* арифметический сдвиг: int знаковый */
                break;
            case USHR:
                /* логический сдвиг: unsigned >> n (флаг UNSIGNED в c4.c) */
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_shr_eax_cl(&em);
                break;
            case ADD: em_pop_ecx(&em); em_add_eax_ecx(&em); break;
            case SUB: em_pop_ecx(&em); em_xchg_eax_ecx(&em); em_sub_eax_ecx(&em); break;
            case MUL: em_pop_ecx(&em); em_imul_eax_ecx(&em); break;
            case DIV:
                /* Делитель — правый операнд (после xchg в ECX).
                 * FIX: idiv по нулю — #DE → паника ВСЕЙ системы; в VM
                 * программа завершается с ошибкой. Эмитим guard:
                 * нулевой делитель → печать + exit(-1). */
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);          /* eax=делимое, ecx=делитель */
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05); /* jnz +5 (мимо jmp divzero) */
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                }
                em_cdq(&em);
                em_idiv_ecx(&em);
                break;
            case MOD:
                em_pop_ecx(&em);
                em_xchg_eax_ecx(&em);
                em_test_ecx_ecx(&em);
                em1(&em, 0x75); em1(&em, 0x05);
                {
                    u32 src = em_jmp_rel32(&em);
                    if (g_n_divfix < MAX_DIVFIX) g_divfix[g_n_divfix++] = src;
                }
                em_cdq(&em);
                em_idiv_ecx(&em);
                em_mov_eax_edx(&em);
                break;
            case EXIT:
                /* exit(code): unwind на кадр entry с ЛЮБОЙ глубины
                 * вызовов (EBX = кадр entry) и возврат в loader.
                 * EAX = код возврата.
                 *   pop eax; mov esp,ebx; mov ebx,[ebx-4]; pop ebp; ret */
                em_pop_eax(&em);
                em1(&em, 0x89); em1(&em, 0xDC);   /* mov esp, ebx */
                em1(&em, 0x8B); em1(&em, 0x5B); em1(&em, 0xFC); /* mov ebx,[ebx-4] */
                em1(&em, 0x5D);                    /* pop ebp */
                em1(&em, 0xC3);                    /* ret */
                break;
            case OPEN: case READ: case CLOS:
                /* Одноячеечные опкоды VM (как PRTF): FIX(Баг 8) — не
                 * съедаем следующую ячейку (это ADJ!). VM возвращает -1. */
                em_mov_eax_imm32(&em, 0xFFFFFFFFu);
                break;
            case PRTF: {
                /* printf(fmt, args...) через kapi->c4_printf_va.
                 * В байт-коде PRTF одноячеечный; nargs подсматриваем в
                 * аргументе следующего ADJ (не потребляя).
                 * cdecl: c4_printf_va(fmt, nargs, args_reversed):
                 *   args_reversed[0] = последний аргумент source = [esp]
                 *   fmt (первый аргумент, глубже всех) = [esp+4*(n-1)] */
                u32 nargs = (u32)bc_pool[bc + 1];  /* peek, don't consume! */
                /* 1. lea eax,[esp] — указатель на аргументы (в ОБРАТНОМ
                 *    порядке, как лежат на стеке c4) */
                em1(&em, 0x8D); em1(&em, 0x04); em1(&em, 0x24);
                /* 2. push args_ptr (аргумент 3) */
                em_push_eax(&em);
                /* 3. push imm32 nargs (аргумент 2) */
                em_push_imm32(&em, nargs);
                /* 4. mov eax, [esp + 8 + (nargs-1)*4] — fmt (аргумент 1):
                 *    8 байт сверху — только что запушенные args_ptr+nargs */
                em1(&em, 0x8B); em1(&em, 0x84); em1(&em, 0x24);
                em4(&em, 8u + (nargs - 1u) * 4u);
                /* 5. push fmt */
                em_push_eax(&em);
                /* 6. mov eax, [edi+KAPI_C4_PRINTF_VA]; call eax */
                em1(&em, 0x8B); em1(&em, 0x47); em1(&em, (u8)KAPI_C4_PRINTF_VA);
                em1(&em, 0xFF); em1(&em, 0xD0);
                /* 7. Снять ТОЛЬКО 3 временных (12 байт) — аргументы
                 *    снимет следующий ADJ (FIX Баг 5: раньше чистились и
                 *    аргументы — двойная очистка рвала стек).
                 *    Результат (число символов) в EAX = "a", не пушим. */
                em_add_esp_imm8(&em, 12);
                break;
            }
            case MALC:  emit_syscall(&em, KAPI_MALLOC, 1); break;
            case FREE:  emit_syscall(&em, KAPI_FREE, 1); break;
            case MSET:  emit_syscall(&em, KAPI_MEMSET, 3); break;
            case MCMP:  emit_syscall(&em, KAPI_MEMCMP, 3); break;
            case KINIT: case KQUIT:
                /* a = 0; стек не трогаем (FIX Баг 5: был лишний push) */
                em_mov_eax_imm32(&em, 0);
                break;
            case KDELAY:
                /* kdelay(ms): уступить CPU на ms миллисекунд.
                 * FIX: раньше — один task_yield (семантика потерялась,
                 * анимации превращались в один кадр). Теперь честный
                 * sleep через kapi->msleep. */
                emit_syscall(&em, KAPI_MSLEEP, 1);
                break;
            case KFILL:  emit_syscall(&em, KAPI_FB_FILL_RECT, 5); break;
            case KTEXT:  emit_syscall(&em, KAPI_FB_TEXT, 5); break;
            case KFLIP: {
                /* kflip(): перерисовать окно — win_invalidate(win).
                 * Результат: a = 0 (как в VM), БЕЗ пуша. */
                em1(&em, 0x56);   /* push esi (win) */
                em1(&em, 0x8B); em1(&em, 0x47); em1(&em, (u8)KAPI_WIN_INVALIDATE);
                em1(&em, 0xFF); em1(&em, 0xD0);
                em_add_esp_imm8(&em, 4);
                em1(&em, 0x31); em1(&em, 0xC0);   /* xor eax, eax (a = 0) */
                break;
            }
            case KRGB:  emit_syscall(&em, KAPI_FB_RGB, 3); break;
            case KEVENT: emit_syscall(&em, KAPI_C4_EVENT_POLL, 1); break;
            case KCLEAR: emit_syscall(&em, KAPI_FB_FILL_SCREEN, 1); break;
            case KW:    emit_syscall(&em, KAPI_FB_WIDTH, 0); break;
            case KH:    emit_syscall(&em, KAPI_FB_HEIGHT, 0); break;
            case KMTIME:
                /* a = timer_ticks() * 10; без стека */
                emit_syscall(&em, KAPI_TIMER_TICKS, 0);
                em1(&em, 0x6B); em1(&em, 0xC0); em1(&em, 10);  /* imul eax,10 */
                break;
            case STRLEN: emit_syscall(&em, KAPI_STRLEN, 1); break;
            case STRCPY: emit_syscall(&em, KAPI_STRCPY, 2); break;
            case STRCMP: emit_syscall(&em, KAPI_STRCMP, 2); break;
            /* CMScript GUI API: win_open(title,x,y,w,h) и т.д.
             * Порядок аргументов на стеке c4: sp[0] = последний. */
            case WOPEN:  emit_syscall(&em, KAPI_WIN_OPEN, 5); break;
            case WCLOSE: emit_syscall(&em, KAPI_WIN_CLOSE, 1); break;
            case WALIVE: emit_syscall(&em, KAPI_WIN_ALIVE, 1); break;
            case WCLEAR: emit_syscall(&em, KAPI_WIN_CLEAR, 2); break;
            case WRECT:  emit_syscall(&em, KAPI_WIN_RECT, 6); break;
            case WTEXT:  emit_syscall(&em, KAPI_WIN_TEXT, 5); break;
            case WUPD:   emit_syscall(&em, KAPI_WIN_UPDATE, 1); break;
            case BADD:   emit_syscall(&em, KAPI_BTN_ADD, 6); break;
            case BCLICK: emit_syscall(&em, KAPI_BTN_CLICKED, 1); break;
            case BSETLB: emit_syscall(&em, KAPI_BTN_SET_LABEL, 3); break;
            default:
                /* Неизвестный опкод — падаем на месте, а не эмитим nop
                 * (тихое расхождение с VM хуже явной ошибки). */
                set_diag(diag, diag_max, "c4_x86: unknown opcode in bytecode");
                s_unlock(&c4_codegen_lock);
                return -1;
        }
        if (em.of) {
            set_diag(diag, diag_max, "c4_x86: output buffer overflow");
            s_unlock(&c4_codegen_lock);
            return -1;
        }
    }

    /* ---------- эпилог деления на ноль ----------
     * Печать "divide by zero\n" через kapi->c4_print_str (строка
     * встроена в код — адрес получаем трюком call $+5/pop) и
     * exit(-1): unwind в loader. Кадр: EBX (entry) жив — его не
     * трогаем до самого выхода. */
    if (g_n_divfix > 0) {
        u32 divzero_pos = em.pos;
        em1(&em, 0xE8); em4(&em, 0);            /* call $+5 */
        u32 pop_pos __attribute__((unused)) = em.pos;
        em1(&em, 0x58);                          /* pop eax (адрес pop) */
        /* Расстояние от ЗНАЧЕНИЯ в EAX (адрес самой инструкции pop —
         * его кладёт call $+5 как адрес возврата) до строки = байты
         * самой pop(1) и всего стаба ниже:
         * pop(1) add(5) push(2) push(1) mov(3) call(2) add(3) mov(5)
         * mov(2) mov(3) pop(1) ret(1) = 29.
         * ВНИМАНИЕ: забытый байт самой pop — классическая ошибка
         * off-by-one (получится "ivide by zero"); 28 — НЕВЕРНО. */
        em1(&em, 0x05);
        em4(&em, 29u);                           /* add eax, 29 → адрес строки */
        em1(&em, 0x6A); em1(&em, 15);            /* push 15 (len) */
        em1(&em, 0x50);                          /* push eax (строка) */
        em1(&em, 0x8B); em1(&em, 0x47); em1(&em, (u8)KAPI_C4_PRINT_STR);
        em1(&em, 0xFF); em1(&em, 0xD0);          /* call c4_print_str */
        em_add_esp_imm8(&em, 8);
        em_mov_eax_imm32(&em, 0xFFFFFFFFu);      /* eax = -1 (код выхода) */
        em1(&em, 0x89); em1(&em, 0xDC);          /* mov esp, ebx */
        em1(&em, 0x8B); em1(&em, 0x5B); em1(&em, 0xFC); /* mov ebx,[ebx-4] */
        em1(&em, 0x5D);                          /* pop ebp */
        em1(&em, 0xC3);                          /* ret */
        /* строка "divide by zero\n" */
        {
            static const char dz[] = "divide by zero\n";
            for (int i = 0; dz[i]; i++) em1(&em, (u8)dz[i]);
        }
        /* патчим все jmp divzero */
        for (int i = 0; i < g_n_divfix; i++) {
            u32 src = g_divfix[i];
            if (src + 4 > em.cap) continue;
            i32 rel = (i32)divzero_pos - (i32)(src + 4);
            em.buf[src]   = (u8)(rel & 0xFF);
            em.buf[src+1] = (u8)((rel >> 8) & 0xFF);
            em.buf[src+2] = (u8)((rel >> 16) & 0xFF);
            em.buf[src+3] = (u8)((rel >> 24) & 0xFF);
        }
    }

    /* Patch entry stub call → main_offset */
    u32 main_x86 = bc_to_x86(entry_cells);
    if (main_x86 == 0xFFFFFFFFu) {
        set_diag(diag, diag_max, "c4_x86: main offset not found in map");
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    if (main_x86 >= entry_call_offset + 4) {
        i32 rel = (i32)main_x86 - (i32)(entry_call_offset + 4);
        em.buf[entry_call_offset]   = (u8)(rel & 0xFF);
        em.buf[entry_call_offset+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[entry_call_offset+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[entry_call_offset+3] = (u8)((rel >> 24) & 0xFF);
    } else {
        set_diag(diag, diag_max, "c4_x86: bad main offset");
        s_unlock(&c4_codegen_lock);
        return -1;
    }

    /* Patch all relocations */
    for (int i = 0; i < g_n_relocs; i++) {
        u32 target_x86 = bc_to_x86(g_relocs[i].target_bc_cell);
        if (target_x86 == 0xFFFFFFFFu) continue;
        u32 src = g_relocs[i].src_x86_offset;
        if (src + 4 > em.cap) continue;
        i32 rel = (i32)target_x86 - (i32)(src + 4);
        em.buf[src]   = (u8)(rel & 0xFF);
        em.buf[src+1] = (u8)((rel >> 8) & 0xFF);
        em.buf[src+2] = (u8)((rel >> 16) & 0xFF);
        em.buf[src+3] = (u8)((rel >> 24) & 0xFF);
    }

    if (em.of) {
        set_diag(diag, diag_max, "c4_x86: output buffer overflow");
        s_unlock(&c4_codegen_lock);
        return -1;
    }
    if (out_size) *out_size = em.pos;

    /* Копия сегмента данных и reloc-списка — вызывающий (c4_compile_to_file)
     * кладёт их в C4N1-контейнер. */
    extern u8  c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int  c4_x86_n_data_relocs_out;
    c4_x86_data_out_len = 0;
    if (data_len > sizeof(c4_x86_data_out)) data_len = sizeof(c4_x86_data_out);
    if (data_len) memcpy(c4_x86_data_out, data_pool, data_len);
    c4_x86_data_out_len = data_len;
    c4_x86_n_data_relocs_out = g_n_data_relocs;
    for (int i = 0; i < g_n_data_relocs; i++)
        c4_x86_data_relocs_out[i] = g_data_relocs[i];

    s_unlock(&c4_codegen_lock);
    return 0;
}

/* Выходные данные последней компиляции (сегмент данных + релокации).
 * Заполняются под c4_codegen_lock — читать сразу после успешного
 * c4_compile_to_native. */
u8  c4_x86_data_out[65536];
u32 c4_x86_data_out_len = 0;
u32 c4_x86_data_relocs_out[8192];
int c4_x86_n_data_relocs_out = 0;

/* ---------- сохранение в RAMFS (формат C4N1) ---------- */
int c4_compile_to_file(const char *source_name, const char *src,
                      char *out, u32 out_max)
{
    /* FIX: буфер был static — две одновременные компиляции калечили
     * друг друга. Теперь heap-аллокация. */
    u8 *out_buf = (u8 *)malloc(256 * 1024);
    u32 out_size = 0;
    if (!out_buf) {
        set_diag(out, out_max, "c4: no memory for codegen buffer");
        return -1;
    }
    if (c4_compile_to_native(src, out, out_max, out_buf, 256 * 1024, &out_size) != 0) {
        free(out_buf);
        return -1;
    }
    if (out_size == 0) {
        free(out_buf);
        set_diag(out, out_max, "c4: compiled output is empty");
        return -1;
    }

    extern u8  c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int  c4_x86_n_data_relocs_out;
    u32 data_len = c4_x86_data_out_len;
    u32 n_rel = (u32)c4_x86_n_data_relocs_out;
    if (n_rel > 8192) n_rel = 8192;

    /* C4N1: magic | code_size | data_size | n_relocs | code | data | relocs */
    u32 total = 16 + out_size + data_len + n_rel * 4;
    u8 *bin = (u8 *)malloc(total);
    if (!bin) {
        free(out_buf);
        set_diag(out, out_max, "c4: no memory for binary image");
        return -1;
    }
    bin[0] = 'C'; bin[1] = '4'; bin[2] = 'N'; bin[3] = '1';
    bin[4] = (u8)(out_size & 0xFF);         bin[5]  = (u8)((out_size >> 8) & 0xFF);
    bin[6] = (u8)((out_size >> 16) & 0xFF); bin[7]  = (u8)((out_size >> 24) & 0xFF);
    bin[8] = (u8)(data_len & 0xFF);         bin[9]  = (u8)((data_len >> 8) & 0xFF);
    bin[10] = (u8)((data_len >> 16) & 0xFF); bin[11] = (u8)((data_len >> 24) & 0xFF);
    bin[12] = (u8)(n_rel & 0xFF);           bin[13] = (u8)((n_rel >> 8) & 0xFF);
    bin[14] = (u8)((n_rel >> 16) & 0xFF);   bin[15] = (u8)((n_rel >> 24) & 0xFF);
    memcpy(bin + 16, out_buf, out_size);
    if (data_len) memcpy(bin + 16 + out_size, c4_x86_data_out, data_len);
    for (u32 i = 0; i < n_rel; i++) {
        u32 v = c4_x86_data_relocs_out[i];
        u8 *p = bin + 16 + out_size + data_len + i * 4;
        p[0] = (u8)(v & 0xFF); p[1] = (u8)((v >> 8) & 0xFF);
        p[2] = (u8)((v >> 16) & 0xFF); p[3] = (u8)((v >> 24) & 0xFF);
    }
    free(out_buf);

    char bin_name[64];
    {
        const char *base = source_name;
        for (const char *p = source_name; *p; p++) {
            if (*p == '/' || *p == '\\') base = p + 1;
        }
        u32 i = 0;
        while (base[i] && base[i] != '.' && i < sizeof(bin_name) - 5) {
            bin_name[i] = base[i];
            i++;
        }
        bin_name[i] = '.'; bin_name[i+1] = 'b'; bin_name[i+2] = 'i';
        bin_name[i+3] = 'n'; bin_name[i+4] = 0;
    }

    if (!ramfs_ready()) {
        free(bin);
        set_diag(out, out_max, "RAMFS not ready");
        return -1;
    }

    ramfs_delete(bin_name);
    if (!ramfs_create(bin_name, total)) {
        free(bin);
        set_diag(out, out_max, "ramfs_create failed");
        return -1;
    }
    if (!ramfs_write(bin_name, bin, total)) {
        free(bin);
        set_diag(out, out_max, "ramfs_write failed");
        return -1;
    }
    free(bin);

    if (out && out_max) {
        char msg[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(msg, sizeof(msg),
                 "[c4] native binary saved: %s (code %u + data %u + %u relocs)",
                 bin_name, (unsigned)out_size, (unsigned)data_len, (unsigned)n_rel);
        u32 L = (u32)strlen(msg);
        if (L >= out_max) L = out_max - 1;
        memcpy(out, msg, L);
        out[L] = 0;
    }
    (void)serial_puts;
    return 0;
}

/* ---------- запуск native c4-бинарника через loader ---------- */
int c4_load_and_run(const char *bin_name, void *win)
{
    return loader_spawn(bin_name, (struct window *)win);
}
