/* imgsvc.h — сервис изображений N2600-OS (Session 55).
 *
 * Единая точка декодирования PNG/JPEG/BMP/GIF (stb_image, см.
 * src/stb_image.c) для ВСЕХ приложений:
 *   - браузер  (apps_browser.c): картинки страниц;
 *   - CMScript (cmscript_api.c): img_load/img_draw/... из .cs-скриптов;
 *   - будущие приложения: фон рабочего стола, просмотрщик и т.п.
 *
 * Потоки: stb не реентерабелен, а x87-состояние ядра НЕ сохраняется
 * планировщиком (в ядре нет save/restore FPU) — поэтому ВСЁ декодирование
 * и билинейное масштабирование (float) выполняются под глобальным
 * спящим локом imgsvc (sync.h: секция прерываема, конкурент спит в hlt).
 * Отрисовка (fb_blit_rgba) — целочисленная и может идти из любого
 * потока без лока.
 *
 * Дескрипторы (img_open/img_retain/img_release/img_get) — для
 * интерпретатора и окон, где рисование происходит в ДРУГОМ потоке,
 * чем владелец: refcount гарантирует, что данные не исчезнут между
 * retain и release. */
#ifndef IMGSVC_H
#define IMGSVC_H

#include "types.h"

typedef struct {
    int  w;        /* ширина, пиксели */
    int  h;        /* высота, пиксели */
    u8  *rgba;     /* w*h*4 байт, формат RGBA8; malloc'нутая кучей ядра */
} img_t;

/* Ограничения (куча ОС общая; декомпрессионные бомбы отсекаем заранее) */
#define IMG_MAX_PIXELS   (1600 * 1200)   /* максимум пикселей декодированной картинки */
#define IMG_FETCH_MAX    (512 * 1024)    /* максимум байт по сети на картинку */
#define IMG_MAX_HANDLES  16              /* дескрипторов одновременно */

/* ---------- декодирование (0 = успех, -1 = ошибка; img_errstr) ---------- */

/* Из памяти (любой поддержанный формат). *out получает w/h/rgba. */
int  img_decode_mem(const u8 *data, u32 len, img_t *out);

/* Из RAM disk по имени (без учёта регистра — как браузер). */
int  img_decode_file(const char *ramfs_name, img_t *out);

/* По ссылке:
 *   http(s)://host[:port]/path          — сеть (net_http_get, TLS на 443);
 *   имя файла                           — RAM disk;
 *   относительный путь + base_url       — разрешается относительно
 *                                         страницы (тот же хост);
 *   base_url без схемы (локальная
 *   страница из RAM disk)               — имя ищется в RAM disk.
 * Фрагменты (#...) отбрасываются. */
int  img_decode_url(const char *url, const char *base_url, img_t *out);

/* Текст последней ошибки декодирования/загрузки (для статуса браузера). */
const char *img_errstr(void);

/* Разрешить относительную ссылку против базового URL страницы:
 *   "/..."   — от корня хоста;
 *   "..."    — относительно каталога страницы;
 *   base_url без "://" (локальная страница RAM disk) — имя файла как есть.
 * Вынесено в imgsvc, чтобы браузер и декодер картинок имели ОДНУ логику. */
void img_url_resolve(const char *base_url, const char *rel,
                     char *out, int out_max);

/* ---------- преобразования ---------- */

/* Билинейное масштабирование (float — под глобальным локом).
 * out->rgba — новый malloc-блок; dispose через img_dispose. */
int  img_scale(const img_t *src, int dw, int dh, img_t *out);

/* Освободить пиксельный буфер (rgba=NULL, безопасно для пустой). */
void img_dispose(img_t *t);

/* ---------- дескрипторы (refcount) ---------- */

/* Зарегистрировать картинку: ref=1, id 1..IMG_MAX_HANDLES или -1. */
int  img_open(const img_t *t);

/* +1 ссылка (0 = успех, -1 = нет такого id). */
int  img_retain(int id);

/* -1 ссылка; при нуле данные освобождаются. */
void img_release(int id);

/* Копия полей под локом. Вызывающий обязан держать ref (retain) —
 * иначе rgba может быть освобождён параллельным img_release. */
int  img_get(int id, img_t *out);

/* ---------- общий FPU-лок (сессия 60) ----------
 * Планировщик ядра НЕ сохраняет x87-состояние, а синтезатор dr_mp3 и
 * масштабирование stb_image используют float. ВСЕ float-библиотеки
 * ядра работают под этим ОДНИМ спящим локом (секция прерываема,
 * конкурент спит в hlt — CPU не жжётся):
 *   img_fpu_lock();    -- декодирование/масштабирование float
 *   ... float-работа ...
 *   img_fpu_unlock(); */

void img_fpu_lock(void);
void img_fpu_unlock(void);

#endif /* IMGSVC_H */
