/* imgsvc.c — сервис изображений N2600-OS (см. imgsvc.h).
 *
 * Session 55. Декодирование — stb_image (src/stb_image.c), форматы
 * PNG/JPEG/BMP/GIF. Все long-running операции (stb-декодирование,
 * билинейное масштабирование) — под глобальным спящим локом: stb не
 * реентерабелен, x87-состояние ядра не сохраняется планировщиком.
 */
#include "types.h"
#include "mem.h"
#include "string.h"
#include "sync.h"
#include "ramfs.h"
#include "net.h"
#include "timer.h"
#include "task.h"
#include "imgsvc.h"

/* stb_image.h — только объявления (реализация в stb_image.c) */
#define STBI_NO_STDIO
#define STBI_NO_SIMD
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_BMP
#define STBI_ONLY_GIF
#include "stb_image.h"

#ifndef NULL
#define NULL ((void *)0)
#endif

/* ---------------- глобальный лок (спящий, sync.h) ---------------- */

static volatile int img_lock_v = 0;

static void img_lk(void)    { s_lock(&img_lock_v); }
static void img_unlk(void)  { s_unlock(&img_lock_v); }

/* Сессия 60: общий FPU-лок для всех float-библиотек ядра
 * (stb_image — здесь, dr_mp3 — в mp3svc). См. imgsvc.h. */
void img_fpu_lock(void)   { img_lk(); }
void img_fpu_unlock(void) { img_unlk(); }

/* ---------------- ошибки ---------------- */

static char img_err[96];

static void img_seterr(const char *msg)
{
    if (msg) {
        strncpy(img_err, msg, sizeof(img_err) - 1);
        img_err[sizeof(img_err) - 1] = 0;
    }
}

const char *img_errstr(void) { return img_err[0] ? img_err : "unknown"; }

/* ---------------- декодирование ---------------- */

void img_dispose(img_t *t)
{
    if (!t) return;
    if (t->rgba) { free(t->rgba); t->rgba = NULL; }
    t->w = 0; t->h = 0;
}

int img_decode_mem(const u8 *data, u32 len, img_t *out)
{
    int w = 0, h = 0, comp = 0;
    u8 *px;
    u32 npix;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!data || len < 8) { img_seterr("img: пустые данные"); return -1; }

    img_lk();
    /* 4 компоненты (RGBA): альфа нужна GIF/PNG с прозрачностью
     * (fb_blit_rgba пропускает прозрачные пиксели); в остальных
     * случаях stb сам дольёт 0xFF. */
    px = stbi_load_from_memory(data, (int)len, &w, &h, &comp, 4);
    img_unlk();

    if (!px) { img_seterr("img: формат не распознан/битый"); return -1; }
    if (w <= 0 || h <= 0) { free(px); img_seterr("img: нулевые размеры"); return -1; }

    npix = (u32)w * (u32)h;
    if (npix > IMG_MAX_PIXELS) {
        free(px);
        img_seterr("img: слишком большая картинка");
        return -1;
    }

    out->w = w;
    out->h = h;
    out->rgba = px;
    return 0;
}

/* Поиск в RAM disk без учёта регистра (как apps_browser.c ramfs_lookup) */
static int img_ramfs_lookup(const char *name, u32 *out_size)
{
    ramfs_dirent_t ents[64];
    int n = ramfs_list(ents, 64);
    for (int i = 0; i < n; i++) {
        const char *a = ents[i].name, *b = name;
        while (*a && *b) {
            char ca = *a, cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca += 32;
            if (cb >= 'A' && cb <= 'Z') cb += 32;
            if (ca != cb) break;
            a++; b++;
        }
        if (*a == 0 && *b == 0) {
            if (out_size) *out_size = ents[i].size;
            return 1;
        }
    }
    return 0;
}

int img_decode_file(const char *ramfs_name, img_t *out)
{
    u32 fsize = 0;
    u8 *buf;
    u32 got;
    int rc;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!ramfs_name || !ramfs_name[0]) { img_seterr("img: пустое имя файла"); return -1; }
    if (!img_ramfs_lookup(ramfs_name, &fsize)) {
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    if (fsize == 0 || fsize > IMG_FETCH_MAX) {
        img_seterr("img: размер файла вне лимита");
        return -1;
    }
    buf = (u8 *)malloc(fsize);
    if (!buf) { img_seterr("img: нет памяти под файл"); return -1; }
    got = ramfs_read(ramfs_name, buf, fsize);
    if (got == 0) { free(buf); img_seterr("img: ошибка чтения RAM disk"); return -1; }
    rc = img_decode_mem(buf, got, out);
    free(buf);
    return rc;
}

/* ---------- разбор ссылок ---------- */

static int ci_starts_with(const char *s, const char *pre)
{
    while (*pre) {
        char a = *s, b = *pre;
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b) return 0;
        s++; pre++;
    }
    return 1;
}

/* host[:port] -> host, port; path = остаток (начинается с '/'). */
static int img_parse_http(const char *p, int https, char *host, int host_max,
                          u16 *port, char *path, int path_max)
{
    int hi = 0;
    *port = https ? 443 : 80;
    while (*p && *p != '/' && hi < host_max - 1) host[hi++] = *p++;
    host[hi] = 0;
    {
        char *colon = strchr(host, ':');
        if (colon) {
            u32 pv = 0;
            *colon = 0;
            for (const char *q = colon + 1; *q; q++) {
                if (*q < '0' || *q > '9') return 0;
                pv = pv * 10 + (u32)(*q - '0');
                if (pv > 65535) return 0;
            }
            if (pv == 0) return 0;
            *port = (u16)pv;
        }
    }
    if (!host[0]) return 0;
    if (!*p) p = "/";
    if ((int)strlen(p) >= path_max) return 0;
    strcpy(path, p);
    return 1;
}

/* Относительная ссылка -> абсолютная (наивно): тот же хост;
 * "/..." — от корня, иначе — каталог текущей страницы.
 * Публичная (imgsvc.h): браузер разрешает ею и ссылки, и картинки. */
void img_url_resolve(const char *base_url, const char *rel,
                     char *out, int out_max)
{
    const char *h, *hend, *slash;
    int pos = 0;

    out[0] = 0;
    if (!rel || !rel[0]) {
        if (base_url) { strncpy(out, base_url, (u32)out_max - 1); out[out_max - 1] = 0; }
        return;
    }

    /* Сессия 56: АБСОЛЮТНЫЙ адрес в rel — вернуть как есть. Раньше
     * клик по <a href="http://другой.хост/"> со сетевой страницы
     * склеивался с хостом страницы ("http://страница/http://другой")
     * и вёл в никуда; то же с Location: из 302-ответов. */
    if (!strncmp(rel, "http://", 7) || !strncmp(rel, "https://", 8)) {
        strncpy(out, rel, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return;
    }
    if (rel[0] == '/' && rel[1] == '/') {
        /* схемо-относительный //host/path -> http://host/path */
        char tmp[300];
        snprintf(tmp, sizeof(tmp), "http:%s", rel);
        strncpy(out, tmp, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return;
    }

    if (!base_url || !base_url[0]) {
        /* нет базы — считаем имя файла RAM disk */
        strncpy(out + pos, rel, (u32)out_max - 1 - (u32)pos);
        out[out_max - 1] = 0;
        return;
    }

    h = strstr(base_url, "://");
    if (!h) {
        strncpy(out, rel, (u32)out_max - 1);
        out[out_max - 1] = 0;
        return;
    }
    h += 3;
    hend = h;
    while (*hend && *hend != '/') hend++;

    for (const char *q = base_url; q < hend && pos < out_max - 1; q++)
        out[pos++] = *q;

    if (*rel == '/') {
        /* от корня */
    } else {
        /* каталог страницы: обрезаем path после последнего '/' */
        slash = strrchr(hend, '/');
        if (slash) {
            for (const char *q = hend; q <= slash && pos < out_max - 1; q++)
                out[pos++] = *q;
        } else if (pos < out_max - 1) {
            out[pos++] = '/';
        }
    }
    for (const char *q = rel; *q && pos < out_max - 1; q++)
        out[pos++] = *q;
    out[pos] = 0;
}

int img_decode_url(const char *url, const char *base_url, img_t *out)
{
    char clean[300];
    int ci = 0;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!url || !url[0]) { img_seterr("img: пустой адрес"); return -1; }

    /* фрагменты #... отбрасываем, пробелы убираем */
    for (const char *q = url; *q && ci < (int)sizeof(clean) - 1; q++) {
        if (*q == '#') break;
        if (*q != ' ') clean[ci++] = *q;
    }
    clean[ci] = 0;
    if (!clean[0]) { img_seterr("img: пустой адрес"); return -1; }

    if (ci_starts_with(clean, "http://") || ci_starts_with(clean, "https://")) {
        int https = (clean[4] == 's');
        const char *p = clean + (https ? 8 : 7);
        char host[128], path[256];
        u16 port;
        char *resp;
        int n, rc;
        const char *body;
        int blen;
        const char *enc;

        if (!img_parse_http(p, https, host, (int)sizeof(host), &port,
                            path, (int)sizeof(path))) {
            img_seterr("img: неверный адрес");
            return -1;
        }
        /* СЕССИЯ 63: картинки с loopback (страница с 127.0.0.1, картинки
         * с localhost) грузим без NIC/IP — стек замыкает соединение сам. */
        if (!net_host_is_loopback(host) &&
            (!net_nic_present() || net_get_ip() == 0)) {
            img_seterr("img: сеть не настроена");
            return -1;
        }
        resp = (char *)malloc(IMG_FETCH_MAX);
        if (!resp) { img_seterr("img: нет памяти под ответ"); return -1; }
        n = net_http_get(host, port, path, resp, IMG_FETCH_MAX, 15000);
        if (n <= 0) {
            snprintf(img_err, sizeof(img_err), "img: сеть: %s", net_http_errstr());
            free(resp);
            return -1;
        }
        /* gzip/deflate не умеем — честно отказываемся */
        enc = NULL;
        for (const char *q = resp; q < resp + n - 20; q++) {
            if ((*q == 'C' || *q == 'c') &&
                !strncmp(q, "ontent-encoding:", 16)) {
                enc = q + 16;
                break;
            }
        }
        if (enc) {
            while (enc < resp + n && (*enc == ' ' || *enc == '\t')) enc++;
            if (!strncmp(enc, "gzip", 4) || !strncmp(enc, "deflate", 7)) {
                img_seterr("img: сжатый ответ (gzip) не поддержан");
                free(resp);
                return -1;
            }
        }
        /* тело: после \r\n\r\n (или \n\n) */
        body = resp;
        blen = n;
        for (int i = 0; i < n && i < 4096; i++) {
            if (i + 3 < n && resp[i] == '\r' && resp[i+1] == '\n' &&
                resp[i+2] == '\r' && resp[i+3] == '\n') {
                body = resp + i + 4;
                blen = n - (i + 4);
                break;
            }
            if (i + 1 < n && resp[i] == '\n' && resp[i+1] == '\n') {
                body = resp + i + 2;
                blen = n - (i + 2);
                break;
            }
        }
        if (blen <= 0) {
            img_seterr("img: пустое тело ответа");
            free(resp);
            return -1;
        }
        rc = img_decode_mem((const u8 *)body, (u32)blen, out);
        free(resp);
        return rc;
    }

    if (ci_starts_with(clean, "file://")) {
        return img_decode_file(clean + 7, out);
    }

    /* без схемы: сначала RAM disk (короткое имя), иначе — относительный путь */
    if (!base_url || !base_url[0] || !strstr(base_url, "://")) {
        if (img_ramfs_lookup(clean, NULL))
            return img_decode_file(clean, out);
        img_seterr("img: файла нет в RAM disk");
        return -1;
    }
    {
        char abs[400];
        img_url_resolve(base_url, clean, abs, (int)sizeof(abs));
        return img_decode_url(abs, NULL, out);
    }
}

/* ---------------- масштабирование (билинейное, float, под локом) ---------------- */

int img_scale(const img_t *src, int dw, int dh, img_t *out)
{
    u8 *dst;
    int sw, sh;

    if (!out) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    if (!src || !src->rgba || src->w <= 0 || src->h <= 0) {
        img_seterr("img: пустой источник");
        return -1;
    }
    if (dw <= 0 || dh <= 0 || dw > 4096 || dh > 4096) {
        img_seterr("img: неверные размеры");
        return -1;
    }
    sw = src->w; sh = src->h;
    dst = (u8 *)malloc((u32)dw * (u32)dh * 4);
    if (!dst) { img_seterr("img: нет памяти под масштаб"); return -1; }

    img_lk();
    if (dw == sw && dh == sh) {
        memcpy(dst, src->rgba, (u32)dw * (u32)dh * 4);
    } else {
        for (int dy = 0; dy < dh; dy++) {
            /* центр исходного пикселя по вертикали */
            float fy = ((float)dy + 0.5f) * (float)sh / (float)dh - 0.5f;
            int y0 = (int)fy;
            float wy = fy - (float)y0;
            if (y0 < 0) { y0 = 0; wy = 0.0f; }
            if (y0 >= sh - 1) { y0 = sh - 1; wy = 0.0f; }
            int y1 = (y0 + 1 < sh) ? y0 + 1 : y0;

            u8 *drow = dst + (u32)dy * (u32)dw * 4;
            for (int dx = 0; dx < dw; dx++) {
                float fx = ((float)dx + 0.5f) * (float)sw / (float)dw - 0.5f;
                int x0 = (int)fx;
                float wx = fx - (float)x0;
                if (x0 < 0) { x0 = 0; wx = 0.0f; }
                if (x0 >= sw - 1) { x0 = sw - 1; wx = 0.0f; }
                int x1 = (x0 + 1 < sw) ? x0 + 1 : x0;

                const u8 *p00 = src->rgba + ((u32)y0 * (u32)sw + (u32)x0) * 4;
                const u8 *p10 = src->rgba + ((u32)y0 * (u32)sw + (u32)x1) * 4;
                const u8 *p01 = src->rgba + ((u32)y1 * (u32)sw + (u32)x0) * 4;
                const u8 *p11 = src->rgba + ((u32)y1 * (u32)sw + (u32)x1) * 4;
                float w00 = (1.0f - wx) * (1.0f - wy);
                float w10 = wx * (1.0f - wy);
                float w01 = (1.0f - wx) * wy;
                float w11 = wx * wy;

                drow[dx * 4 + 0] = (u8)(p00[0] * w00 + p10[0] * w10 +
                                        p01[0] * w01 + p11[0] * w11);
                drow[dx * 4 + 1] = (u8)(p00[1] * w00 + p10[1] * w10 +
                                        p01[1] * w01 + p11[1] * w11);
                drow[dx * 4 + 2] = (u8)(p00[2] * w00 + p10[2] * w10 +
                                        p01[2] * w01 + p11[2] * w11);
                drow[dx * 4 + 3] = (u8)(p00[3] * w00 + p10[3] * w10 +
                                        p01[3] * w01 + p11[3] * w11);
            }
        }
    }
    img_unlk();

    out->w = dw;
    out->h = dh;
    out->rgba = dst;
    return 0;
}

/* ---------------- дескрипторы ---------------- */

typedef struct {
    int   used;
    int   ref;
    img_t t;
} img_handle_t;

static img_handle_t g_handles[IMG_MAX_HANDLES];

int img_open(const img_t *t)
{
    int id = -1;
    if (!t || !t->rgba || t->w <= 0 || t->h <= 0) {
        img_seterr("img: пустая картинка для img_open");
        return -1;
    }
    img_lk();
    for (int i = 0; i < IMG_MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            g_handles[i].used = 1;
            g_handles[i].ref = 1;
            g_handles[i].t = *t;
            id = i + 1;
            break;
        }
    }
    img_unlk();
    if (id < 0) img_seterr("img: таблица дескрипторов полна");
    return id;
}

int img_retain(int id)
{
    int rc = -1;
    if (id <= 0 || id > IMG_MAX_HANDLES) return -1;
    img_lk();
    if (g_handles[id - 1].used) {
        g_handles[id - 1].ref++;
        rc = 0;
    }
    img_unlk();
    return rc;
}

void img_release(int id)
{
    if (id <= 0 || id > IMG_MAX_HANDLES) return;
    img_lk();
    if (g_handles[id - 1].used && g_handles[id - 1].ref > 0) {
        g_handles[id - 1].ref--;
        if (g_handles[id - 1].ref == 0) {
            img_dispose(&g_handles[id - 1].t);
            g_handles[id - 1].used = 0;
        }
    }
    img_unlk();
}

int img_get(int id, img_t *out)
{
    int rc = -1;
    if (!out || id <= 0 || id > IMG_MAX_HANDLES) return -1;
    out->w = 0; out->h = 0; out->rgba = NULL;
    img_lk();
    if (g_handles[id - 1].used) {
        *out = g_handles[id - 1].t;
        rc = 0;
    }
    img_unlk();
    return rc;
}
