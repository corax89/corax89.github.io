#!/bin/sh
# run_setnet.sh — сборка и прогон хост-теста приложения «Настройки»
# (настоящий src/apps_settings.c против заглушек; заголовки — настоящие).
# Использование: ./run_setnet.sh          (обычный)
#                ./run_setnet.sh asan     (AddressSanitizer + UBSan)
set -e
cd "$(dirname "$0")"

# 1) свежие копии src-файлов и НАСТОЯЩИХ заголовков (quoted-include
#    резолвится локально; -I не используем, чтобы не перекрыть libc)
HDRS="types.h boot.h kbd.h mouse.h fb.h wm.h net.h wifi_core.h \
ne2000.h ath9k_wifi.h disk.h fat32.h fat32_format.h ntfs.h kernel.h \
ramfs.h timer.h task.h iso9660.h usb_ehci.h filedlg.h apps.h"
for f in apps_settings.c $HDRS; do
    SRC=${SRC:-../../src}; cp $SRC/$f .
done
# string.h/mem.h — редиректы на libc (настоящий string.h объявляет snprintf
# с u32, mem.h — malloc(u32); конфликты с libc-прототипами; tmfmt решал так же)
printf '#include <string.h>\n#include <stdio.h>\n#include <stdlib.h>\n' > string.h
printf '#include <stdlib.h>\n' > mem.h

# 2) компиляция
FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter \
-Wno-builtin-declaration-mismatch"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address,undefined -fno-omit-frame-pointer"
    BIN=setnet_test_asan
else
    BIN=setnet_test
fi
gcc $FLAGS setnet_test.c -o $BIN

echo "== Запуск $BIN =="
if [ "$1" = "asan" ]; then
    ASAN_OPTIONS=detect_leaks=1 ./$BIN
else
    ./$BIN
fi
