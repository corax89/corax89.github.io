/* net.h — хост-заглушка: сети нет */
#ifndef NET_H
#define NET_H
typedef unsigned short u16_;
static inline int net_nic_present(void) { return 0; }
static inline unsigned net_get_ip(void) { return 0; }
static inline int net_http_get(const char *h, unsigned short p, const char *pa,
                               char *r, unsigned m, unsigned ms) {
    (void)h; (void)p; (void)pa; (void)r; (void)m; (void)ms; return -1; }
static inline const char *net_http_errstr(void) { return "host test: нет сети"; }
#endif
