/* ramfs.h — хост-заглушка: RAM disk пуст */
#ifndef RAMFS_H
#define RAMFS_H
typedef struct { char name[65]; unsigned size; unsigned offset; unsigned char is_dir; } ramfs_dirent_t;
static inline int ramfs_init(void) { return 1; }
static inline int ramfs_ready(void) { return 1; }
static inline int ramfs_list(ramfs_dirent_t *out, int max) { (void)out; (void)max; return 0; }
static inline unsigned ramfs_read(const char *n, void *b, unsigned m) { (void)n; (void)b; (void)m; return 0; }
#endif
