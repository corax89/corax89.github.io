/* brpage.h — разбор страницы браузера N2600-OS: картинки и ссылки.
 * Header-only (ядро и хост-тест включают один и тот же код).
 *
 * Сессия 55. Конвейер страницы:
 *   1. htmlconv.c даёт Markdown, где
 *        <a href="U">T</a> -> [T](U)      (полная ссылка)
 *        <img src="U" alt="A"> -> ![A](U) (СТРОКА-маркер отдельным абзацем)
 *   2. brp_analyze() сканирует исходник (md):
 *        - каждую СТРОКУ-маркер ![...](...) заменяет односимвольным
 *          якорем BRP_IMG_MARK и запоминает запись картинки
 *          (сжатие md "на месте", индексы строк честные);
 *        - собирает ссылки [T](U) с АБСОЛЮТНЫМИ смещениями в md
 *          ([ = b_abs, конец текста = t_end_abs, конец ) = p_end_abs);
 *        - строит таблицу смещений строк line_off[].
 *   3. brl_wrap() (brlines.h) переносит md; каждая строка отображения
 *      знает srcidx/srcoff (кусок какой строки и с какого байта).
 *   4. Браузер вставляет пустые строки под высоту картинок и по клику
 *      зовёт brp_click_link(): (srcidx, srcoff, колонка) -> URL.
 *
 * Зависимости: malloc/free/memcpy/strncpy/strlen (ядро: mem.h/string.h),
 * utf8_next (string.h). */
#ifndef BRPAGE_H
#define BRPAGE_H

#ifndef BRP_IMG_MARK
#define BRP_IMG_MARK '\002'   /* односимвольный якорь картинки в md */
#endif

#define BRP_MAX_IMGS  12
#define BRP_MAX_LINKS 48
#define BRP_URL_MAX   220

typedef struct {
    int  src_idx;              /* индекс исходной строки md (якорь) */
    int  state;                /* 0 = ждёт, 1 = готова, -1 = ошибка */
    char url[BRP_URL_MAX];
    int  w, h;                 /* декодированный размер */
    u8  *rgba;                 /* готовый к blit буфер (масштабированный) */
    int  dw, dh;               /* размер отрисовки */
    int  row, rows;            /* layout: строка-якорь и высота в строках */
} brp_img_t;

typedef struct {
    int  src_idx;              /* исходная строка */
    int  b_abs;                /* байт '[' в md */
    int  t_end_abs;            /* байт ЗА ']' */
    int  p_end_abs;            /* байт ЗА ')' */
    char url[BRP_URL_MAX];
} brp_link_t;

typedef struct {
    brp_img_t  imgs[BRP_MAX_IMGS];
    int        nimgs;
    brp_link_t links[BRP_MAX_LINKS];
    int        nlinks;
    int       *line_off;       /* смещение байта каждой строки md */
    int        nlines;
    int        line_cap;
} brp_page_t;

/* Освободить пиксельные буферы картинок (сам md НЕ здесь). */
static void brp_free_images(brp_page_t *p)
{
    if (!p) return;
    for (int i = 0; i < p->nimgs; i++) {
        if (p->imgs[i].rgba) free(p->imgs[i].rgba);
        p->imgs[i].rgba = NULL;
        p->imgs[i].state = 0;
    }
    p->nimgs = 0;
}

static void brp_reset(brp_page_t *p)
{
    if (!p) return;
    brp_free_images(p);
    p->nlinks = 0;
    p->nlines = 0;
}

/* Сколько байт занимает col-й СИМВОЛ строки s[0..len)? Без выхода за len. */
static int brp_byte_of_col(const char *s, int len, int col)
{
    const char *p = s;
    const char *end = s + len;
    int c = 0;
    while (p < end && c < col) {
        utf8_next(&p);
        c++;
    }
    return (int)(p - s);
}

/* Вставка: удалить [d_from, d_to) и вписать repl[0..rlen) (со сдвигом
 * хвоста). Возвращает новую длину. len — текущая длина. */
static int brp_splice(char *md, int len, int d_from, int d_to,
                      const char *repl, int rlen)
{
    if (d_from < 0 || d_to > len || d_from > d_to) return len;
    if (rlen > d_to - d_from) {
        int extra = rlen - (d_to - d_from);
        for (int i = len; i >= d_to; i--)
            md[i + extra] = md[i];
    } else if (rlen < d_to - d_from) {
        int shift = (d_to - d_from) - rlen;
        for (int i = d_to; i <= len; i++)
            md[i - shift] = md[i];
    }
    for (int i = 0; i < rlen; i++)
        md[d_from + i] = repl[i];
    return len - (d_to - d_from) + rlen;
}

/* Записать смещение строки idx (массив line_off растёт удвоением). */
static int brp_line_off_put(brp_page_t *p, int idx, int off)
{
    if (idx >= p->line_cap) {
        int ncap = p->line_cap ? p->line_cap * 2 : 128;
        while (ncap <= idx) ncap *= 2;
        int *nl = (int *)malloc((u32)ncap * sizeof(int));
        if (!nl) return 0;
        if (p->line_off) {
            memcpy(nl, p->line_off, (u32)p->nlines * sizeof(int));
            free(p->line_off);
        }
        p->line_off = nl;
        p->line_cap = ncap;
    }
    p->line_off[idx] = off;
    if (idx + 1 > p->nlines) p->nlines = idx + 1;
    return 1;
}

/* Добавить ссылку (место кончилось — молча игнор). */
static void brp_add_link(brp_page_t *p, int src_idx, int b_abs,
                         int t_end_abs, int p_end_abs,
                         const char *url, int url_len)
{
    if (p->nlinks >= BRP_MAX_LINKS) return;
    if (url_len <= 0 || url_len >= BRP_URL_MAX) return;
    brp_link_t *l = &p->links[p->nlinks++];
    l->src_idx = src_idx;
    l->b_abs = b_abs;
    l->t_end_abs = t_end_abs;
    l->p_end_abs = p_end_abs;
    memcpy(l->url, url, (u32)url_len);
    l->url[url_len] = 0;
}

/* Ссылка на строку: "[T](U)" (без '!' перед '['). URL без '\n'.
 * Пустой U ("]()") — НЕ ссылка. Возвращает 1, если нашлась. */
static int brp_line_link(brp_page_t *p, int src_idx, const char *ls,
                         int llen, int base)
{
    for (int i = 0; i < llen; i++) {
        if (ls[i] != '[') continue;
        if (i > 0 && ls[i - 1] == '!') { i++; continue; }
        /* ищем "](" */
        int j = i + 1;
        while (j < llen && ls[j] != ']') {
            if (ls[j] == '\n') break;
            j++;
        }
        if (j >= llen || ls[j] != ']' || j + 1 >= llen || ls[j + 1] != '(')
            continue;
        int k = j + 2;
        while (k < llen && ls[k] != ')') {
            if (ls[k] == '\n') break;
            k++;
        }
        if (k < llen && ls[k] == ')' && k > j + 2) {
            int ulen = k - (j + 2);
            brp_add_link(p, src_idx, base + i, base + j + 1, base + k + 1,
                         ls + (j + 2), ulen);
            return 1;
        }
        i = k > i ? k : i;
    }
    return 0;
}

/* РАЗБОР СТРАНИЦЫ. md МОДИФИЦИРУЕТСЯ (маркеры картинок -> якоря).
 * md_len — длина полезных данных; md должен иметь запас +1 байт в конце
 * (NUL терминатор вызывающего). Возвращает новую длину. */
static int brp_analyze(brp_page_t *p, char *md, int md_len)
{
    brp_reset(p);

    /* --- проход 1: картинки --- */
    int li = 0;                 /* индекс строки */
    int pos = 0;                /* байт начала строки */
    while (pos < md_len) {
        int nl = pos;
        while (nl < md_len && md[nl] != '\n') nl++;
        int llen = nl - pos;
        if (llen > 0 && md[llen - 1] == '\r') llen--;

        /* маркер: [пробелы] "![" ... "](" ... ")" */
        int s = 0;
        while (s < llen && (md[pos + s] == ' ' || md[pos + s] == '\t')) s++;
        if (s + 1 < llen && md[pos + s] == '!' && md[pos + s + 1] == '[') {
            int j = s + 2;
            while (j + 1 < llen && !(md[pos + j] == ']' && md[pos + j + 1] == '('))
                j++;
            if (j + 1 < llen) {
                int us = j + 2;
                int ue = us;
                while (ue < llen && md[pos + ue] != ')') ue++;
                if (ue < llen && ue > us) {
                    int ulen = ue - us;
                    if (ulen < BRP_URL_MAX && p->nimgs < BRP_MAX_IMGS) {
                        brp_img_t *im = &p->imgs[p->nimgs++];
                        im->src_idx = li;
                        im->state = 0;
                        im->w = im->h = 0;
                        im->rgba = NULL;
                        im->dw = im->dh = 0;
                        im->row = im->rows = 0;
                        memcpy(im->url, md + pos + us, (u32)ulen);
                        im->url[ulen] = 0;
                        /* строка -> якорь */
                        md_len = brp_splice(md, md_len, pos, nl,
                                            "\002", 1);
                        nl = pos + 1;
                        llen = 1;
                    }
                }
            }
        }

        if (!brp_line_off_put(p, li, pos)) break;

        li++;
        if (nl >= md_len) break;
        pos = nl + 1;
    }

    /* --- проход 2: ссылки (offsets по ФИНАЛЬНОМУ md) --- */
    pos = 0;
    for (li = 0; li < p->nlines; li++) {
        int nl = pos;
        while (nl < md_len && md[nl] != '\n') nl++;
        int llen = nl - pos;
        if (llen > 0 && md[llen - 1] == '\r') llen--;
        brp_line_link(p, li, md + pos, llen, pos);
        if (nl >= md_len) break;
        pos = nl + 1;
    }

    return md_len;
}

/* КЛИК -> ссылка.
 *   srcidx/srcoff — поля строки отображения (brlines.h): кусок какой
 *                   исходной строки и с какого байта;
 *   piece/piece_len — текст куска (строка отображения);
 *   col           — колонка клика в СИМВОЛАХ куска;
 *   allow_tail    — 1: попадание в ЛЮБУЮ колонку куска, если в этой
 *                   исходной строке ровно одна ссылка (хвост переноса).
 * Возвращает URL или NULL (мимо). */
static const char *brp_click_link(brp_page_t *p, const char *md,
                                   int srcidx, int srcoff,
                                   const char *piece, int piece_len,
                                   int col, int allow_tail)
{
    if (!p || !md || srcidx < 0 || srcidx >= p->nlines || !p->line_off)
        return NULL;
    int line_base = p->line_off[srcidx];

    /* позиция клика внутри исходной строки (байты) */
    int in_piece = brp_byte_of_col(piece, piece_len, col);
    int bytepos = line_base + srcoff + in_piece;

    int hits = 0;
    const brp_link_t *only = NULL;
    for (int i = 0; i < p->nlinks; i++) {
        const brp_link_t *l = &p->links[i];
        if (l->src_idx != srcidx) continue;
        hits++;
        only = l;
        /* текст ссылки или зона ](url) */
        if (bytepos >= l->b_abs && bytepos < l->p_end_abs)
            return l->url;
    }
    if (allow_tail && hits == 1 && only)
        return only->url;          /* перенос ссылки на соседнюю строку */
    return NULL;
}

#endif /* BRPAGE_H */
