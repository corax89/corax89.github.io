/* imgres.h — встроенные ресурсы RAM disk (сессия 55).
 * Логика засева — imgres_seed() (imgres.c), вызывается из kernel.c
 * после сидинга ISO (файлы пользователя приоритетны). */
#ifndef IMGRES_H
#define IMGRES_H

extern const unsigned char imgres_logo_png[];
extern const unsigned int  imgres_logo_png_len;
extern const char          imgres_img_cs[];
extern const unsigned int  imgres_img_cs_len;

/* Засеять LOGO.PNG и IMG.CS в RAM disk, если их там ещё нет. */
void imgres_seed(void);

#endif /* IMGRES_H */
