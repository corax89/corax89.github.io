/* cmscript_api.c — мост между CMScript и API N2600-OS.
 *
 * Регистрирует host-функции, доступные из .cs-скриптов:
 *   print(str)               — вывод текста в буфер run'а
 *   print_int(n)             — вывод числа
 *   screen_width() / screen_height()
 *   fill_rect(x,y,w,h,c)     — заливка прямоугольника на экране
 *   draw_text(x,y,str,color) — текст на экране
 *   get_color(r,g,b)         — цвет
 *   clear_screen(color)      — очистка экрана
 *   flip()                   — перерисовка экрана
 *   delay(ms)                — задержка (кооперативная, task_yield)
 *   uptime()                 — время работы в секундах
 *   strlen(s) / malloc(n) / free(p) / memset(p,val,n) / memcmp(a,b,n)
 *   ramfs_read(name, buf, max) / ramfs_write(name, buf, len) / ramfs_list()
 *
 * НОВОЕ (сессия 55) — КАРТИНКИ (stb_image через imgsvc):
 *   img_load(path)            -> дескриптор картинки или -1 (RAM disk
 *                                или http(s)://; блокирующая сеть)
 *   img_w(id) / img_h(id)     -> размеры (0 — нет картинки)
 *   img_pixel(id,x,y)         -> 0xRRGGBB (или -1)
 *   img_draw(id,x,y)          — нарисовать (в текущую цель fb, как
 *                                fill_rect; размер оригинала)
 *   img_draw_scaled(id,x,y,w,h) — нарисовать с масштабом (nearest)
 *   img_free(id)              — освободить
 *   win_img(id,id2,x,y)       — картинка в окно (id2 — дескриптор)
 *   win_img_scaled(id,id2,x,y,w,h) — в окно с масштабом
 *
 * НОВОЕ — GUI из скрипта (окна и кнопки, см. секцию SCRIPT GUI ниже):
 *   win_open(title, x, y, w, h)     -> id окна или -1
 *   win_close(id)                    — закрыть окно
 *   win_alive(id)                    -> 1, пока окно открыто
 *   win_clear(id, color)             — очистить окно и сбросить вывод
 *   win_rect(id, x, y, w, h, color)  — прямоугольник в окне
 *   win_text(id, x, y, text, color)  — текст в окне (шрифт 8x16)
 *   win_update(id)                   — перерисовать сейчас
 *   btn_add(id, x, y, w, h, label)   -> номер кнопки или -1
 *   btn_clicked(id)                  -> номер нажатой кнопки или -1
 *      (семантика "pop": нажатие сбрасывается после чтения)
 *   btn_set_label(id, btn, label)    — сменить надпись кнопки
 *
 * ИСПРАВЛЕНИЯ против версии из старого src.zip:
 *   1. Аргументы читаются в ПРЯМОМ порядке: argv[0] — первый аргумент
 *      вызова (build_host_args в cmscript.c кладёт их именно так; старый
 *      файл читал в обратном — fill_rect/draw_text/get_color/memset/
 *      memcmp/ramfs_* получали перепутанные параметры).
 *   2. Константы типов приведены к enum интерпретатора:
 *      CDM_TYPE_INT=0, FLOAT=1, PTR=2, STRUCT=3, ARRAY=4, STRING=5, REF=6.
 *      Было CDM_TYPE_INT 1 — из-за этого print_int(int) молча не работал.
 *   3. Аргументы-переменные приходят обёрнутыми в REF (build_host_args
 *      передаёт идентификаторы по ссылке) — все читатели аргументов
 *      снимают обёртку через arg_deref(), иначе print(str_var) и т.п.
 *      получали пустоту.
 *   4. cs_register_all() вызывается один раз (раньше каждый запуск
 *      скрипта съедал слоты CDM_MAX_HOST_EX, и после нескольких Run
 *      функции молча пропадали).
 *   5. draw_text брал текст из слота координаты y — работал как no-op.
 */
#include "cmscript.h"
#include "sync.h"
#include "types.h"
#include "mem.h"
#include "string.h"
#include "fb.h"
#include "wm.h"       /* окна из скрипта: win_create/win_invalidate/... */
#include "mouse.h"    /* MSB_LEFT */
#include "timer.h"
#include "task.h"
#include "ramfs.h"
#include "imgsvc.h"   /* сессия 55: картинки (stb_image) */

/* во freestanding нет <stddef.h> */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* CMScript internal types — ТОЧНАЯ копия enum из cmscript.c.
 * Не менять: от этих значений зависит разбор argv в функциях ниже. */
#define CDM_TYPE_INT     0
#define CDM_TYPE_FLOAT   1
#define CDM_TYPE_PTR     2
#define CDM_TYPE_STRUCT  3
#define CDM_TYPE_ARRAY   4
#define CDM_TYPE_STRING  5
#define CDM_TYPE_REF     6

typedef struct {
    int type;
    int struct_id;
    int array_len;
    int array_dim;
    int array_sizes[4];
    int array_elem_type;
    int array_elem_struct_id;
    int owned;
    int from_new;
    union {
        long long i;
        double f;
        void *p;
    } v;
} CDM_Value_t;

typedef CDM_Value_t (*CDM_HostFuncEx_t)(int argc, CDM_Value_t* argv);
extern void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);
extern char* CDM_Preprocess(const char* source);   /* ★ препроцессор */
extern void *CDM_Parse(const char* source);
extern int CDM_Execute(void *root);
extern void CDM_FreeAST(void *root);
extern int CDM_GetErrorCount(void);
extern void CDM_ClearErrors(void);
/* Структура ошибки — точная копия из cmscript.c (для показа #error) */
typedef struct { int line; int col; char message[80]; } CDM_Error_t;
extern const CDM_Error_t* CDM_GetError(int idx);
/* Регистрирует 69 std-функций интерпретатора (sprintf/strlen/strcmp/...).
 * БЕЗ этого вызова в ОС не работал ни sprintf, ни строковые функции:
 * калькулятор на шаблоне рисовал пустой дисплей (скрипт падал на первом
 * sprintf с "undefined function", текст в ops не попадал). */
extern void CMScript_Init(void);

/* Выводной буфер — заполняется host-функциями print/print_int */
static char *g_cs_out = 0;
static u32   g_cs_out_pos = 0;
static u32   g_cs_out_max = 0;

static void cs_putc(char c) {
    if (g_cs_out_pos + 1 < g_cs_out_max)
        g_cs_out[g_cs_out_pos++] = c;
}
static void cs_puts(const char *s) {
    while (*s) cs_putc(*s++);
}
static void cs_putint(int v) {
    char b[12]; int i = 0;
    if (v < 0) { cs_putc('-'); v = -v; }
    if (v == 0) { cs_putc('0'); return; }
    while (v) { b[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) cs_putc(b[i]);
}

static CDM_Value_t make_int(int v) {
    CDM_Value_t r;
    memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT;
    r.v.i = v;
    return r;
}

/* ---------- Чтение аргументов (прямой порядок + снятие REF) ---------- */

/* Идентификаторы в вызове приходят как REF-обёртки над слотами значений
 * (см. build_host_args в cmscript.c). Снимаем обёртку. */
static const CDM_Value_t *arg_deref(const CDM_Value_t *v) {
    if (v && v->type == CDM_TYPE_REF && v->v.p)
        return (const CDM_Value_t *)v->v.p;
    return v;
}
static int arg_int(const CDM_Value_t *v, int def) {
    v = arg_deref(v);
    if (!v) return def;
    if (v->type == CDM_TYPE_INT)   return (int)v->v.i;
    if (v->type == CDM_TYPE_FLOAT) return (int)v->v.f;
    return def;
}
static const char *arg_str(const CDM_Value_t *v, const char *def) {
    v = arg_deref(v);
    if (v && v->type == CDM_TYPE_STRING && v->v.p)
        return (const char *)v->v.p;
    return def;
}

/* ---------- Host-функции для .cs-скриптов ---------- */

static CDM_Value_t cs_print(int argc, CDM_Value_t* argv) {
    (void)argc;
    cs_puts(arg_str(&argv[0], ""));
    return make_int(0);
}

static CDM_Value_t cs_print_int(int argc, CDM_Value_t* argv) {
    (void)argc;
    cs_putint(arg_int(&argv[0], 0));
    return make_int(0);
}

static CDM_Value_t cs_screen_width(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)fb_width());
}

static CDM_Value_t cs_screen_height(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)fb_height());
}

static CDM_Value_t cs_fill_rect(int argc, CDM_Value_t* argv) {
    (void)argc;
    fb_fill_rect(arg_int(&argv[0], 0), arg_int(&argv[1], 0),
                 arg_int(&argv[2], 0), arg_int(&argv[3], 0),
                 (u32)arg_int(&argv[4], 0));
    return make_int(0);
}

static CDM_Value_t cs_draw_text(int argc, CDM_Value_t* argv) {
    (void)argc;
    fb_text(arg_int(&argv[0], 0), arg_int(&argv[1], 0),
            arg_str(&argv[2], ""), (u32)arg_int(&argv[3], 0), -1);
    return make_int(0);
}

static CDM_Value_t cs_get_color(int argc, CDM_Value_t* argv) {
    (void)argc;
    return make_int((int)fb_rgb((u8)arg_int(&argv[0], 0),
                                (u8)arg_int(&argv[1], 0),
                                (u8)arg_int(&argv[2], 0)));
}

static CDM_Value_t cs_clear_screen(int argc, CDM_Value_t* argv) {
    (void)argc;
    fb_fill_screen((u32)arg_int(&argv[0], 0));
    return make_int(0);
}

static CDM_Value_t cs_flip(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    fb_touch_all();
    fb_flush();
    return make_int(0);
}

static CDM_Value_t cs_delay(int argc, CDM_Value_t* argv) {
    (void)argc;
    u32 start = timer_ticks();
    u32 need = (u32)arg_int(&argv[0], 0);   /* 1 тик = 1 мс (сессия 33) */
    if (need == 0) need = 1;
    while (timer_ticks() - start < need) task_yield();
    return make_int(0);
}

static CDM_Value_t cs_uptime(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    return make_int((int)uptime_sec());
}

static CDM_Value_t cs_strlen(int argc, CDM_Value_t* argv) {
    (void)argc;
    return make_int((int)strlen(arg_str(&argv[0], "")));
}

static CDM_Value_t cs_malloc(int argc, CDM_Value_t* argv) {
    (void)argc;
    void *p = malloc((u32)arg_int(&argv[0], 0));
    CDM_Value_t r = make_int(0);
    r.v.p = p;
    return r;
}

static CDM_Value_t cs_free(int argc, CDM_Value_t* argv) {
    (void)argc;
    free(argv[0].v.p);
    return make_int(0);
}

static CDM_Value_t cs_memset(int argc, CDM_Value_t* argv) {
    (void)argc;
    /* memset(ptr, val, n) — как в C */
    memset(arg_deref(&argv[0])->v.p, arg_int(&argv[1], 0),
           (u32)arg_int(&argv[2], 0));
    return make_int(0);
}

static CDM_Value_t cs_memcmp(int argc, CDM_Value_t* argv) {
    (void)argc;
    return make_int(memcmp(arg_deref(&argv[0])->v.p,
                           arg_deref(&argv[1])->v.p,
                           (u32)arg_int(&argv[2], 0)));
}

static CDM_Value_t cs_ramfs_read(int argc, CDM_Value_t* argv) {
    (void)argc;
    /* ramfs_read(name, buf, max) */
    const char *name = arg_str(&argv[0], NULL);
    if (name && arg_deref(&argv[1])->v.p)
        return make_int((int)ramfs_read(name, arg_deref(&argv[1])->v.p,
                                        (u32)arg_int(&argv[2], 0)));
    return make_int(0);
}

static CDM_Value_t cs_ramfs_write(int argc, CDM_Value_t* argv) {
    (void)argc;
    /* ramfs_write(name, buf, len) */
    const char *name = arg_str(&argv[0], NULL);
    if (name && arg_deref(&argv[1])->v.p) {
        u32 len = (u32)arg_int(&argv[2], 0);
        ramfs_delete(name);
        if (ramfs_create(name, len + 1)) {
            ramfs_write(name, arg_deref(&argv[1])->v.p, len + 1);
            return make_int(1);
        }
    }
    return make_int(0);
}

static CDM_Value_t cs_ramfs_list(int argc, CDM_Value_t* argv) {
    (void)argc; (void)argv;
    /* TODO: list files */
    return make_int(0);
}

/* ===== SCRIPT GUI: окна и кнопки из .cs-скрипта =====
 *
 * Дескрипторы — индексы в статической таблице (без heap). Окно рисуется
 * колбэком sg_draw (фон + список примитивов + кнопки), клики от мыши
 * ловит sg_mouse, Esc закрывает окно. Скрипт опрашивает btn_clicked()
 * в цикле while (win_alive(id)) { ... delay(30); }.
 *
 * Потоки: sg_draw/sg_mouse/sg_key зовутся из задачи WM, скриптовые
 * sgf_* — из задачи run'а (cs_run_task). Общий доступ к таблице
 * сериализуется s_lock(sg_lock); отрисовка идёт без блокировки —
 * допускаем мгновенный "рваный" кадр, но не дедлок.
 *
 * ВАЖНО: win_close()/win_create() вызываются ВНЕ блокировки — WM может
 * вызвать sg_close синхронно, и вложенный s_lock заклинил бы спинлок. */

#define SG_MAX_WINS   4
#define SG_MAX_BTNS   16
#define SG_MAX_OPS    64
#define SG_TITLE_MAX  48
#define SG_LABEL_MAX  24
#define SG_TEXT_MAX   40

typedef struct {
    int  type;                      /* 0 = rect, 1 = text,
                                     * 2 = img (дескриптор imgsvc),
                                     * 3 = img_scaled (свой буфер ptr) */
    int  x, y, w, h;
    u32  color;
    char text[SG_TEXT_MAX];
    /* сессия 55: картинки */
    int  img_id;                    /* type 2: дескриптор imgsvc */
    void *ptr;                      /* type 3: буфер RGBA (владелец — op) */
} sg_op_t;

typedef struct {
    int  used;
    int  x, y, w, h;
    char label[SG_LABEL_MAX];
    int  hot;                       /* курсор над кнопкой */
    int  pressed;                   /* зажата */
} sg_btn_t;

typedef struct {
    int        used;
    window_t  *win;                 /* NULL после закрытия */
    int        want_close;
    u32        bg;
    char       title[SG_TITLE_MAX];
    sg_btn_t   btns[SG_MAX_BTNS];
    sg_op_t    ops[SG_MAX_OPS];
    int        op_count;
    int        last_click;          /* номер нажатой кнопки или -1 */
} sg_win_t;

static sg_win_t g_sgw[SG_MAX_WINS];
static volatile int sg_lock = 0;

/* Взять окно под блокировкой (если слот жив). Разблокирует вызывающий. */
static sg_win_t *sg_lock_win(int id) {
    if (id < 0 || id >= SG_MAX_WINS) return NULL;
    s_lock(&sg_lock);
    if (!g_sgw[id].used) { s_unlock(&sg_lock); return NULL; }
    return &g_sgw[id];
}
static void sg_unlock_win(void) {
    s_unlock(&sg_lock);
}
static void sg_repaint(sg_win_t *g) {
    if (g && g->win) win_invalidate(g->win);
}
static void sg_copy_str(char *dst, int cap, const char *src) {
    int i = 0;
    if (src) for (; src[i] && i < cap - 1; i++) dst[i] = src[i];
    dst[i] = 0;
}

/* Освободить ресурсы ops (сессия 55): буферы type-3 (масштабированные
 * копии) принадлежат op'ам. type-2 держат ссылку через img_retain —
 * отпускаем здесь же. */
static void sg_free_ops(sg_win_t *g) {
    for (int i = 0; i < g->op_count && i < SG_MAX_OPS; i++) {
        sg_op_t *o = &g->ops[i];
        if (o->type == 3 && o->ptr) { free(o->ptr); o->ptr = NULL; }
        else if (o->type == 2 && o->img_id > 0) {
            img_release(o->img_id);
            o->img_id = 0;
        }
    }
    g->op_count = 0;
}

/* ---------- колбэки окна (задача WM) ---------- */

static void sg_draw(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, g->bg);

    /* СНИМОК списка ops под sg_lock: скриптовая задача (sgf_win_text и
     * др.) перестраивает список ПАР АЛЛЕЛЬНО отрисовке — без снимка
     * sg_draw мог увидеть полусобранный кадр (текст без фона и т.п.).
     * Копия дешёвая: до SG_MAX_OPS * sizeof(sg_op_t) ~ 3.5 КБ на стеке
     * потока окна (стек 16 КБ — помещается). */
    sg_op_t snap[SG_MAX_OPS];
    int snap_n = 0;
    s_lock(&sg_lock);
    snap_n = g->op_count;
    if (snap_n > SG_MAX_OPS) snap_n = SG_MAX_OPS;
    for (int i = 0; i < snap_n; i++) snap[i] = g->ops[i];
    s_unlock(&sg_lock);

    for (int i = 0; i < snap_n; i++) {
        sg_op_t *o = &snap[i];
        if (o->type == 0) {
            int x = o->x, y = o->y, ww = o->w, hh = o->h;
            if (x < 0) { ww += x; x = 0; }
            if (y < 0) { hh += y; y = 0; }
            if (x + ww > cw) ww = cw - x;
            if (y + hh > ch) hh = ch - y;
            if (ww > 0 && hh > 0) fb_fill_rect(x, y, ww, hh, o->color);
        } else if (o->type == 1) {
            if (o->y > -16 && o->y < ch && o->x < cw)
                fb_text(o->x, o->y, o->text, o->color, -1);
        } else if (o->type == 2 && o->img_id > 0) {
            /* сессия 55: картинка по дескриптору (refcount: живёт,
             * пока скрипт не позвал img_free — тогда op рискует быть
             * пустым, но не падает) */
            img_t t;
            if (img_retain(o->img_id) == 0 && img_get(o->img_id, &t) == 0) {
                if (t.rgba && t.w > 0 && t.h > 0)
                    fb_blit_rgba(t.rgba, t.w, t.h, o->x, o->y, t.w, t.h);
                img_release(o->img_id);
            }
        } else if (o->type == 3 && o->ptr) {
            /* масштабированная копия — собственность op'а */
            if (o->w > 0 && o->h > 0)
                fb_blit_rgba((const u8 *)o->ptr, o->w, o->h,
                             o->x, o->y, o->w, o->h);
        }
    }

    /* кнопки — как в редакторе CMScript */
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (!b->used) continue;
        u32 bgc = b->pressed ? fb_rgb(0x4A, 0x7F, 0xB0)
                : b->hot     ? fb_rgb(0x32, 0x60, 0x8E)
                : fb_rgb(0x25, 0x4A, 0x70);
        fb_fill_rect(b->x, b->y, b->w, b->h, bgc);
        fb_rect(b->x, b->y, b->w, b->h, wm_theme_accent());
        int tw = (int)strlen(b->label) * 8;
        int tx = (tw > b->w - 4) ? b->x + 2 : b->x + (b->w - tw) / 2;
        int ty = b->y + (b->h - 16) / 2 + 1;
        fb_text(tx, ty, b->label, wm_theme_text(), -1);
    }
}

static void sg_key(window_t *w, const key_event_t *ev) {
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) {   /* Esc */
        sg_win_t *g = (sg_win_t *)w->data;
        if (g) g->want_close = 1;
        win_close(w);
    }
}

static void sg_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;

    int btn = -1;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (b->used && mx >= b->x && mx < b->x + b->w &&
            my >= b->y && my < b->y + b->h) { btn = i; break; }
    }

    int redraw = 0;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        int h2 = (i == btn) ? 1 : 0;
        int p2 = (i == btn && (buttons & MSB_LEFT)) ? 1 : 0;
        if (b->hot != h2 || b->pressed != p2) {
            b->hot = h2; b->pressed = p2; redraw = 1;
        }
    }

    if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT) && btn >= 0) {
        s_lock(&sg_lock);
        g->last_click = btn;        /* ждёт btn_clicked() скрипта */
        s_unlock(&sg_lock);
    }
    if (redraw) win_invalidate(w);
}

static void sg_close(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    s_lock(&sg_lock);
    g->win = NULL;
    g->want_close = 1;
    s_unlock(&sg_lock);
    /* слот останется used до закрытия окна, чтобы дескриптор скрипта
     * оставался валидным для win_alive/btn_clicked (они вернут 0/-1) */
}

/* ---------- скриптовые функции (задача run'а) ---------- */

static CDM_Value_t sgf_win_open(int argc, CDM_Value_t* argv) {
    (void)argc;
    const char *title = arg_str(&argv[0], "Script window");
    int x = arg_int(&argv[1], 100), y = arg_int(&argv[2], 80);
    int w = arg_int(&argv[3], 240), h = arg_int(&argv[4], 200);
    if (w < 60) w = 60;
    if (h < 40) h = 40;
    if (w > 800) w = 800;
    if (h > 600) h = 600;

    int id = -1;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++)
        if (!g_sgw[k].used) { id = k; break; }
    if (id >= 0) {
        sg_win_t *g = &g_sgw[id];
        memset(g, 0, sizeof(*g));
        g->used = 1;
        g->last_click = -1;
        g->bg = wm_theme_win_bg();
        sg_copy_str(g->title, SG_TITLE_MAX, title);
        g->win = win_create(g->title, x, y, w, h,
                            sg_draw, sg_key, sg_mouse, NULL, sg_close, g);
        if (!g->win) { g->used = 0; id = -1; }
    }
    s_unlock(&sg_lock);
    return make_int(id);
}

static CDM_Value_t sgf_win_close(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    window_t *w = NULL;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used) {
        g_sgw[id].want_close = 1;
        w = g_sgw[id].win;
    }
    s_unlock(&sg_lock);
    if (w) win_close(w);            /* ВНЕ блокировки — см. шапку секции */
    return make_int(0);
}

static CDM_Value_t sgf_win_alive(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int alive = 0;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used &&
        g_sgw[id].win && !g_sgw[id].want_close)
        alive = 1;
    s_unlock(&sg_lock);
    return make_int(alive);
}

static CDM_Value_t sgf_win_clear(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        g->bg = (u32)arg_int(&argv[1], 0);
        sg_free_ops(g);              /* сессия 55: буферы картинок */
        g->last_click = -1;
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

static CDM_Value_t sgf_win_rect(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 0;
            o->x = arg_int(&argv[1], 0);
            o->y = arg_int(&argv[2], 0);
            o->w = arg_int(&argv[3], 0);
            o->h = arg_int(&argv[4], 0);
            o->color = (u32)arg_int(&argv[5], 0);
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

static CDM_Value_t sgf_win_text(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 1;
            o->x = arg_int(&argv[1], 0);
            o->y = arg_int(&argv[2], 0);
            o->w = o->h = 0;
            o->color = (u32)arg_int(&argv[4], 0);
            sg_copy_str(o->text, SG_TEXT_MAX, arg_str(&argv[3], ""));
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

static CDM_Value_t sgf_win_update(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    window_t *w = NULL;
    if (g) { w = g->win; sg_unlock_win(); }
    if (w) win_invalidate(w);
    return make_int(0);
}

static CDM_Value_t sgf_btn_add(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int ret = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        for (int i = 0; i < SG_MAX_BTNS; i++) {
            if (!g->btns[i].used) {
                sg_btn_t *b = &g->btns[i];
                b->used = 1;
                b->x = arg_int(&argv[1], 0);
                b->y = arg_int(&argv[2], 0);
                b->w = arg_int(&argv[3], 20);
                b->h = arg_int(&argv[4], 16);
                if (b->w < 8) b->w = 8;
                if (b->h < 8) b->h = 8;
                sg_copy_str(b->label, SG_LABEL_MAX, arg_str(&argv[5], "?"));
                b->hot = 0;
                b->pressed = 0;
                ret = i;
                break;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(ret);
}

static CDM_Value_t sgf_btn_clicked(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int r = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        r = g->last_click;
        g->last_click = -1;         /* pop: читается один раз */
        sg_unlock_win();
    }
    return make_int(r);
}

static CDM_Value_t sgf_btn_set_label(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int bi = arg_int(&argv[1], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (bi >= 0 && bi < SG_MAX_BTNS && g->btns[bi].used) {
            sg_copy_str(g->btns[bi].label, SG_LABEL_MAX,
                        arg_str(&argv[2], "?"));
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

/* ---------- КАРТИНКИ (сессия 55, stb_image через imgsvc) ---------- */

/* img_load(path) -> дескриптор или -1. path — имя файла RAM disk или
 * http(s)://адрес. ВНИМАНИЕ: сетевая загрузка блокирующая (до 15 с),
 * как и вся сеть в этой ОС — скриптовая задача на это время спит. */
static CDM_Value_t csf_img_load(int argc, CDM_Value_t* argv) {
    (void)argc;
    const char *path = arg_str(&argv[0], NULL);
    img_t t;
    if (!path || !path[0] || img_decode_url(path, NULL, &t) != 0)
        return make_int(-1);
    int id = img_open(&t);          /* владение rgba переходит дескриптору */
    if (id < 0) img_dispose(&t);
    return make_int(id);
}

static CDM_Value_t csf_img_free(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_release(arg_int(&argv[0], -1));
    return make_int(0);
}

static CDM_Value_t csf_img_w(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_t t;
    if (img_get(arg_int(&argv[0], -1), &t) != 0) return make_int(0);
    return make_int(t.w);
}

static CDM_Value_t csf_img_h(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_t t;
    if (img_get(arg_int(&argv[0], -1), &t) != 0) return make_int(0);
    return make_int(t.h);
}

/* img_pixel(id,x,y) -> 0xRRGGBB (альфа отброшена) или -1 */
static CDM_Value_t csf_img_pixel(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_t t;
    int x = arg_int(&argv[1], 0), y = arg_int(&argv[2], 0);
    if (img_get(arg_int(&argv[0], -1), &t) != 0 || !t.rgba)
        return make_int(-1);
    if (x < 0 || y < 0 || x >= t.w || y >= t.h)
        return make_int(-1);
    const u8 *p = t.rgba + ((u32)y * (u32)t.w + (u32)x) * 4;
    return make_int(((int)p[0] << 16) | ((int)p[1] << 8) | (int)p[2]);
}

/* img_draw(id,x,y) — оригинальный размер, в текущую цель fb
 * (та же семантика, что у fill_rect/draw_text) */
static CDM_Value_t csf_img_draw(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_t t;
    if (img_get(arg_int(&argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     arg_int(&argv[1], 0), arg_int(&argv[2], 0), t.w, t.h);
    }
    return make_int(0);
}

/* img_draw_scaled(id,x,y,w,h) — масштаб (nearest, целочисленный:
 * безопасно без лока imgsvc) */
static CDM_Value_t csf_img_draw_scaled(int argc, CDM_Value_t* argv) {
    (void)argc;
    img_t t;
    int w = arg_int(&argv[3], 0), h = arg_int(&argv[4], 0);
    if (img_get(arg_int(&argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0 && w > 0 && h > 0 && w <= 4096 && h <= 4096) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     arg_int(&argv[1], 0), arg_int(&argv[2], 0), w, h);
    }
    return make_int(0);
}

/* win_img(id, img_id, x, y) — картинка в окно (op держит ссылку
 * img_retain; img_free скриптом до win_clear просто оставит дырку) */
static CDM_Value_t sgf_win_img(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int iid = arg_int(&argv[1], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && img_retain(iid) == 0) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 2;
            o->x = arg_int(&argv[2], 0);
            o->y = arg_int(&argv[3], 0);
            o->w = o->h = 0;
            o->color = 0;
            o->text[0] = 0;
            o->img_id = iid;
            o->ptr = NULL;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

/* win_img_scaled(id, img_id, x, y, w, h) — op владеет масштабированной
 * копией (билинейной, под локом imgsvc) — оригинал можно img_free */
static CDM_Value_t sgf_win_img_scaled(int argc, CDM_Value_t* argv) {
    (void)argc;
    int id = arg_int(&argv[0], -1);
    int iid = arg_int(&argv[1], -1);
    int w = arg_int(&argv[4], 0), h = arg_int(&argv[5], 0);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && w > 0 && h > 0 &&
            w <= 4096 && h <= 4096) {
            img_t t, s;
            if (img_get(iid, &t) == 0 && t.rgba &&
                img_scale(&t, w, h, &s) == 0) {
                sg_op_t *o = &g->ops[g->op_count++];
                o->type = 3;
                o->x = arg_int(&argv[2], 0);
                o->y = arg_int(&argv[3], 0);
                o->w = s.w;
                o->h = s.h;
                o->color = 0;
                o->text[0] = 0;
                o->img_id = 0;
                o->ptr = s.rgba;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return make_int(0);
}

/* ---------- Регистрация host-функций ---------- */

static int g_cs_registered = 0;

static void cs_register_all(void) {
    /* Один раз за жизнь ОС: повторная регистрация тех же имён не падает
     * (найти функцию можно, дубликаты безвредны), но съедает слоты
     * CDM_MAX_HOST_EX — после нескольких запусков скриптов функции
     * молча пропадали. */
    if (g_cs_registered) return;
    g_cs_registered = 1;

    /* 69 std-функций интерпретатора (sprintf/snprintf/printf/strlen/
     * strcmp/...) — без них скрипт падает на первом sprintf: у шаблона
     * калькулятора от этого был пустой дисплей. Идемпотентность защиты
     * от двойной регистрации обеспечивается однократным вызовом отсюда
     * (29 OS-функций + 69 std = 98 < CDM_MAX_HOST_EX 128). */
    CMScript_Init();

    CDM_RegisterHostFuncEx("print",        cs_print);
    CDM_RegisterHostFuncEx("print_int",    cs_print_int);
    CDM_RegisterHostFuncEx("screen_width", cs_screen_width);
    CDM_RegisterHostFuncEx("screen_height", cs_screen_height);
    CDM_RegisterHostFuncEx("fill_rect",    cs_fill_rect);
    CDM_RegisterHostFuncEx("draw_text",    cs_draw_text);
    CDM_RegisterHostFuncEx("get_color",    cs_get_color);
    CDM_RegisterHostFuncEx("clear_screen", cs_clear_screen);
    CDM_RegisterHostFuncEx("flip",         cs_flip);
    CDM_RegisterHostFuncEx("delay",        cs_delay);
    CDM_RegisterHostFuncEx("uptime",       cs_uptime);
    CDM_RegisterHostFuncEx("strlen",       cs_strlen);
    CDM_RegisterHostFuncEx("malloc",       cs_malloc);
    CDM_RegisterHostFuncEx("free",         cs_free);
    CDM_RegisterHostFuncEx("memset",       cs_memset);
    CDM_RegisterHostFuncEx("memcmp",       cs_memcmp);
    CDM_RegisterHostFuncEx("ramfs_read",   cs_ramfs_read);
    CDM_RegisterHostFuncEx("ramfs_write",  cs_ramfs_write);
    CDM_RegisterHostFuncEx("ramfs_list",   cs_ramfs_list);

    /* Script GUI */
    CDM_RegisterHostFuncEx("win_open",      sgf_win_open);
    CDM_RegisterHostFuncEx("win_close",     sgf_win_close);
    CDM_RegisterHostFuncEx("win_alive",     sgf_win_alive);
    CDM_RegisterHostFuncEx("win_clear",     sgf_win_clear);
    CDM_RegisterHostFuncEx("win_rect",      sgf_win_rect);
    CDM_RegisterHostFuncEx("win_text",      sgf_win_text);
    CDM_RegisterHostFuncEx("win_update",    sgf_win_update);
    CDM_RegisterHostFuncEx("btn_add",       sgf_btn_add);
    CDM_RegisterHostFuncEx("btn_clicked",   sgf_btn_clicked);
    CDM_RegisterHostFuncEx("btn_set_label", sgf_btn_set_label);

    /* Картинки (сессия 55): 98 + 8 = 106 < CDM_MAX_HOST_EX 128 */
    CDM_RegisterHostFuncEx("img_load",       csf_img_load);
    CDM_RegisterHostFuncEx("img_free",       csf_img_free);
    CDM_RegisterHostFuncEx("img_w",          csf_img_w);
    CDM_RegisterHostFuncEx("img_h",          csf_img_h);
    CDM_RegisterHostFuncEx("img_pixel",      csf_img_pixel);
    CDM_RegisterHostFuncEx("img_draw",       csf_img_draw);
    CDM_RegisterHostFuncEx("img_draw_scaled", csf_img_draw_scaled);
    CDM_RegisterHostFuncEx("win_img",        sgf_win_img);
    CDM_RegisterHostFuncEx("win_img_scaled", sgf_win_img_scaled);
}

/* ---------- Публичный API ---------- */

/* FIX (многозадачность): интерпретатор CMScript — на глобалах
 * (g_cs_out и VM). Вызывается задачей запуска (cs_run_task), а таких
 * может быть несколько одновременно. Обёртка сериализует. */
static volatile int cms_run_lock = 0;

int cmscript_run(const char *src, char *out, u32 out_max);
static int cmscript_run_impl(const char *src, char *out, u32 out_max);

int cmscript_run(const char *src, char *out, u32 out_max) {
    int rc;
    s_lock(&cms_run_lock);
    rc = cmscript_run_impl(src, out, out_max);
    s_unlock(&cms_run_lock);
    return rc;
}

static int cmscript_run_impl(const char *src, char *out, u32 out_max) {
    g_cs_out = out;
    g_cs_out_pos = 0;
    g_cs_out_max = out_max;
    if (out && out_max) out[0] = 0;

    cs_register_all();
    CDM_ClearErrors();

    /* ★ Препроцессор подключен к запуску скриптов: работают #define
     * (в т.ч. многострочные с \), #if/#ifdef, #error, __LINE__/__FILE__,
     * предопределённые NULL/TRUE/FALSE/EOF. Ошибка #error ловится
     * ПОСЛЕ препроцессора, ДО разбора. */
    char *pre = CDM_Preprocess(src);
    if (!pre) {
        if (out && out_max > 0) {
            const char *err = "CMScript: out of memory (preprocess)\n";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        return -1;
    }

    if (CDM_GetErrorCount() > 0) {          /* например, сработал #error */
        if (out && out_max > 0) {
            const CDM_Error_t *e = CDM_GetError(0);
            const char *err = (e && e->message[0]) ? e->message
                                                   : "CMScript: preprocess error";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        free(pre);
        return -1;
    }

    void *ast = CDM_Parse(pre);
    free(pre);
    if (!ast) {
        if (out && out_max > 0) {
            const char *err = "CMScript: parse error\n";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        return -1;
    }

    if (CDM_GetErrorCount() > 0) {
        if (out && out_max > 0) {
            const char *err = "CMScript: parse errors detected\n";
            int n = (int)strlen(err);
            if (n >= (int)out_max) n = (int)out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        CDM_FreeAST(ast);
        return -1;
    }

    int ret = CDM_Execute(ast);
    CDM_FreeAST(ast);

    if (g_cs_out && g_cs_out_pos < g_cs_out_max)
        g_cs_out[g_cs_out_pos] = 0;

    return ret;
}
