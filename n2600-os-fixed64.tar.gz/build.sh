#!/bin/sh
# N2600-OS: сборка ядра (Linux/macOS).
# Использует тот же MinGW-тулчейн, что и Windows (i686-w64-mingw32-*),
# а при его отсутствии — системный gcc -m32.
set -e
cd "$(dirname "$0")"

if command -v i686-w64-mingw32-gcc >/dev/null 2>&1; then
    CC=i686-w64-mingw32-gcc
    OBJCOPY=i686-w64-mingw32-objcopy
elif command -v gcc >/dev/null 2>&1; then
    CC=gcc
    OBJCOPY=objcopy
else
    echo "Не найден компилятор (нужен i686-w64-mingw32-gcc или gcc)" >&2
    exit 1
fi
echo "Использую: $CC"

CFLAGS="-m32 -mtune=atom -ffreestanding -fno-pic -fno-pie -fno-stack-protector \
-fno-asynchronous-unwind-tables -fno-stack-check -mno-stack-arg-probe \
-O2 -Wall -Wextra -Isrc"

mkdir -p build

echo "[1/3] Компиляция..."
for f in src/*.c; do
    # mqjs_engine.c (MicroQuickJS, сторонний код ~27k строк) — без ворнингов
    EXTRA=""
    case "$f" in
        *mqjs_engine.c) EXTRA="-w -fno-math-errno -fno-trapping-math" ;;
    esac
    echo "  CC $f"
    $CC $CFLAGS $EXTRA -c "$f" -o "build/$(basename "${f%.c}").o"
done

echo "[2/3] Линковка..."
# -no-pie: gcc по умолчанию линкует PIE — появляются .rel.dyn/.dynamic,
# и абсолютные адреса остаются НЕприменёнными релокациями (для bare-metal
# ядра это ломает указатели: релокации некому применять).
$CC -m32 -nostdlib -no-pie -Wl,-T,linker.ld -Wl,--image-base=0x100000 \
    -o build/kernel.tmp.exe build/*.o

echo "[3/3] Плоский бинарник..."
# --only-section=.text: в .bss лежат статические пулы (~1 МиБ) — их НЕ нужно
# писать в файл: GRUB обнуляет bss сам по AOUT_KLUDGE (bss_end_addr в
# multiboot-заголовке). Без флага objcopy раздувает kernel.bin нулями.
$OBJCOPY -O binary --only-section=.text build/kernel.tmp.exe kernel.bin

echo "[OK] Готово: kernel.bin"
