/* kapi.h — таблица API ядра для приложений, загружаемых с диска.
 *
 * Загружаемый .bin-файл должен экспортировать точку входа:
 *   void entry(kapi_t *k, void *win);
 *
 * Все обращения к ядру идут через указатели в этой таблице — это позволяет
 * не делать полноценный динамический линковщик в простом ядре.
 *
 * Формат таблицы стабилен: новые функции добавляются только в конец,
 * существующие — без изменения сигнатуры.
 */
#ifndef KAPI_H
#define KAPI_H

#include "types.h"

struct window;

typedef struct {
    /* ---- Графика ---- */
    void (*fb_fill_rect)(int x, int y, int w, int h, u32 c);
    void (*fb_rect)(int x, int y, int w, int h, u32 c);
    void (*fb_hline)(int x0, int x1, int y, u32 c);
    void (*fb_text)(int x, int y, const char *s, u32 fg, int bg);
    void (*fb_char)(int x, int y, unsigned cp, u32 fg, int bg);
    u32  (*fb_rgb)(u8 r, u8 g, u8 b);
    u32  (*fb_width)(void);
    u32  (*fb_height)(void);
    void (*fb_fill_screen)(u32 c);
    int  (*win_content_w)(struct window *w);
    int  (*win_content_h)(struct window *w);
    void (*win_invalidate)(struct window *w);

    /* ---- Память ---- */
    void *(*malloc)(u32 n);
    void  (*free)(void *p);

    /* ---- Система ---- */
    u32  (*uptime_sec)(void);
    u32  (*timer_ticks)(void);
    void (*task_yield)(void);
    int  (*task_spawn)(const char *name, void (*fn)(void *), void *arg);

    /* ---- Строки ---- */
    int  (*snprintf)(char *out, u32 n, const char *fmt, ...);
    u32  (*strlen)(const char *s);
    int  (*strcmp)(const char *a, const char *b);
    char *(*strcpy)(char *dst, const char *src);
    int  (*memcmp)(const void *a, const void *b, u32 n);
    void *(*memset)(void *dst, int c, u32 n);
    void *(*memcpy)(void *dst, const void *src, u32 n);

    /* ---- c4 runtime (для запуска c4-программ, сгенерированных в x86) ---- */
    void (*c4_print_str)(const char *s, u32 len);  /* вывод строки в c4_out */
    int  (*c4_event_poll)(void *out_buf);            /* 0=нет, 1=клавиша, 2=мышь */
    int  (*c4_printf_va)(const char *fmt, int nargs, int *args_reversed);  /* formatted print, возвращает число символов */

    /* ---- Сон (для kdelay в native c4-программах) ----
     * ДОБАВЛЯТЬ ТОЛЬКО В КОНЕЦ: смещения полей зашиты в генерируемый
     * код (c4_x86 KAPI_*), STATIC_ASSERT-ы в c4_x86.c проверяют. */
    void (*msleep)(u32 ms);                          /* уступить CPU на ms мс */

    /* ---- CMScript GUI для c4-программ (обновление c4, сессия 56) ----
     * Имена в c4-программах: win_open/win_close/win_alive/win_clear/
     * win_rect/win_text/win_update/btn_add/btn_clicked/btn_set_label.
     * Смещения 116..152 зашиты в c4_x86.c (KAPI_WIN_OPEN..KAPI_BTN_SET_LABEL).
     * Реализации — c4k_* в mqjs_api.c (тот же движок окон, что у
     * CMScript: до 4 окон, до 16 кнопок; Esc закрывает окно). */
    int  (*win_open)(const char *title, int x, int y, int w, int h);
    void (*win_close)(int id);
    int  (*win_alive)(int id);
    void (*win_clear)(int id, u32 color);
    void (*win_rect)(int id, int x, int y, int w, int h, u32 color);
    void (*win_text)(int id, int x, int y, const char *s, u32 color);
    void (*win_update)(int id);
    int  (*btn_add)(int id, int x, int y, int w, int h, const char *label);
    int  (*btn_clicked)(int id);
    void (*btn_set_label)(int id, int btn, const char *label);

    /* ---- MP3-декодер dr_mp3 (сессия 60; ДОБАВЛЯТЬ ТОЛЬКО В КОНЕЦ: ----
     * смещения зафиксированы в c4_x86.c (KAPI_MP3_*), STATIC_ASSERT-ы
     * проверяют. Приложение выделяет контекст malloc(MP3_CTX_SIZE)
     * (см. mp3svc.h); данные файла должны жить, пока контекст открыт.
     * Декодирование идёт под общим FPU-локом (внутри mp3svc). */
    int  (*mp3_open_mem)(const void *data, u32 len, void *ctx);  /* 1 = ок */
    void (*mp3_close)(void *ctx);
    u32  (*mp3_channels)(const void *ctx);     /* 1..2 */
    u32  (*mp3_rate)(const void *ctx);         /* Гц */
    u32  (*mp3_read_s16)(void *ctx, i16 *pcm, u32 frames); /* фреймов */
    u32  (*mp3_seek)(void *ctx, u32 frame);    /* 1 = ок */
    u32  (*mp3_total_frames)(const void *ctx); /* оценка, фреймов */
} kapi_t;

/* ---- c4 GUI: реализации (mqjs_api.c) ----
 * Отдельные C-функции: их адреса идут и в kapi_t (native-путь c4_x86),
 * и в таблицу c4_gui_api (VM-путь c4.c). */
int  c4k_win_open(const char *title, int x, int y, int w, int h);
void c4k_win_close(int id);
int  c4k_win_alive(int id);
void c4k_win_clear(int id, u32 color);
void c4k_win_rect(int id, int x, int y, int w, int h, u32 color);
void c4k_win_text(int id, int x, int y, const char *s, u32 color);
void c4k_win_update(int id);
int  c4k_btn_add(int id, int x, int y, int w, int h, const char *label);
int  c4k_btn_clicked(int id);
void c4k_btn_set_label(int id, int btn, const char *label);

/* Заполнить таблицу API указателями на функции ядра. */
void kapi_fill(kapi_t *k);

#endif /* KAPI_H */
