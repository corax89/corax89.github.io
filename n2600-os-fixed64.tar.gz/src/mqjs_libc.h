/* mqjs_libc.h — фристендинг-шим libc для MicroQuickJS в ядре N2600-OS.
 *
 * Сессия 64: CMScript заменён на MicroQuickJS (bellard/mquickjs, MIT).
 * Движок (mqjs_engine.c, сгенерирован scripts/gen_mqjs.py) рассчитан на
 * hosted-среду; здесь недостающее сводится к службам ядра:
 *
 *   malloc/free      -> куча ядра (mem.h); realloc ядром не нужен — движок
 *                       всю память держит в переданном регионе (JS_NewContext)
 *   printf           -> serial-порт (отладочные дампы движка: JS_DumpValue и
 *                       др. — в нормальной работе не вызываются)
 *   assert           -> паника (сбой инварианта движка = порча VM)
 *   abort            -> паника (недостижимые ветки движка)
 *   ctype            -> инлайны (isspace/tolower нужны dtoa)
 *   math             -> builtins (вся математика движка — в его libm.c;
 *                       напрямую движок зовёт только fabs)
 *   setjmp/longjmp   -> своя i386-реализация (движок выходит из рекурсивного
 *                       парсера longjmp'ом; libc в ядре нет, __builtin_setjmp
 *                       накладывает ограничения на размер буфера)
 *   inttypes         -> PRI-макросы (GCC freestanding даёт только stdint.h)
 *
 * Хост-харнессы (host-test/mqjs) подставляют СВОЙ mqjs_libc.h с настоящей
 * libc — как это принято в остальных хост-тестах проекта.
 */
#ifndef MQJS_LIBC_H
#define MQJS_LIBC_H

#include <stddef.h>    /* size_t (GCC freestanding) */
#include <stdint.h>    /* uint*_t, INT*_MAX (GCC freestanding) */
#include <stdarg.h>    /* va_list (GCC freestanding) */

#include "types.h"
#include "string.h"    /* memcpy/memmove/memset/memcmp/strlen/strcmp (u32 == size_t на i386) */
#include "mem.h"       /* malloc/free (куча ядра) */
#include "kernel.h"    /* klog_puts */
#include "sync.h"      /* serial_puts */

/* ---------------- inttypes: PRI-макросы (i386: long long = 64 бита) ----- */
#define PRId8  "d"
#define PRIi8  "i"
#define PRIo8  "o"
#define PRIu8  "u"
#define PRIx8  "x"
#define PRIX8  "X"
#define PRId16 "d"
#define PRIi16 "i"
#define PRIo16 "o"
#define PRIu16 "u"
#define PRIx16 "x"
#define PRIX16 "X"
#define PRId32 "d"
#define PRIi32 "i"
#define PRIo32 "o"
#define PRIu32 "u"
#define PRIx32 "x"
#define PRIX32 "X"
#define PRId64 "lld"
#define PRIi64 "lli"
#define PRIo64 "llo"
#define PRIu64 "llu"
#define PRIx64 "llx"
#define PRIX64 "llX"
#define PRIdPTR "d"
#define PRIuPTR "u"
#define PRIxPTR "x"

/* ---------------- stdlib ------------------------------------------------ */
void  *realloc(void *p, size_t n);   /* реализация в mqjs_api.c (не движком) */
void   abort(void);
void   exit(int code);               /* только декларация (CLI исключён) */
int    printf(const char *fmt, ...); /* реализация в mqjs_api.c -> serial */
int    abs(int x);

/* ---------------- assert -> паника -------------------------------------- */
void mqjs_assert_fail(const char *expr, const char *file, int line);
#ifdef NDEBUG
#define assert(x) ((void)0)
#else
#define assert(x) do { if (!(x)) mqjs_assert_fail(#x, __FILE__, __LINE__); } while (0)
#endif

/* ---------------- ctype (инлайны; нужны dtoa) --------------------------- */
static inline int isspace(int c) {
    return c == ' ' || c == '\t' || c == '\n' ||
           c == '\r' || c == '\f' || c == '\v';
}
static inline int isdigit(int c)  { return c >= '0' && c <= '9'; }
static inline int isxdigit(int c) {
    return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
}
static inline int islower(int c)  { return c >= 'a' && c <= 'z'; }
static inline int isupper(int c)  { return c >= 'A' && c <= 'Z'; }
static inline int isalpha(int c)  { return islower(c) || isupper(c); }
static inline int isalnum(int c)  { return isalpha(c) || isdigit(c); }
static inline int tolower(int c)  { return isupper(c) ? c - 'A' + 'a' : c; }
static inline int toupper(int c)  { return islower(c) ? c - 'a' + 'A' : c; }

/* ---------------- math (вся математика — в libm.c движка) ---------------- */
#define fabs(x)  __builtin_fabs((double)(x))
#define floor(x) __builtin_floor((double)(x))
#define ceil(x)  __builtin_ceil((double)(x))
#define sqrt(x)  __builtin_sqrt((double)(x))
#define NAN      __builtin_nan("")
#define INFINITY __builtin_inf()
#define isnan(x)    __builtin_isnan((double)(x))
#define isinf(x)    __builtin_isinf((double)(x))
#define isfinite(x) __builtin_isfinite((double)(x))
#define signbit(x)  __builtin_signbit((double)(x))
#define copysign(x, y) __builtin_copysign((double)(x), (double)(y))

/* ---------------- setjmp/longjmp (i386) ---------------------------------- *
 * jmp_buf: ebx, esi, edi, ebp, esp(вызвавшего), eip(возврата из setjmp).
 * setjmp обязана быть noinline: точка возобновления — «возврат из вызова
 * setjmp», при инлайнинге сместился бы esp кадра вызвавшей функции.
 * Использование движком ровно одно: longjmp(env, 1) из js_parse_error. */
typedef int jmp_buf[7];

int setjmp(jmp_buf buf);              /* реализации в mqjs_api.c */
void longjmp(jmp_buf buf, int val);

#endif /* MQJS_LIBC_H */
