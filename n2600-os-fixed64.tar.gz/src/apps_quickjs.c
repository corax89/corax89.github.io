/* apps_quickjs.c — редактор + интерпретатор QuickJS (сессия 64).
 *
 * СЕССИЯ 64: CMScript заменён на MicroQuickJS (bellard/mquickjs, MIT).
 * Скриптовый язык — JavaScript (диалект ES5.1 движка: var/function,
 * без let/const/стрелок/template literals), со стандартной библиотекой
 * движка (Object/Array/String/JSON/Math/TypedArray) и host-функциями ОС
 * (см. mqjs_api.c). Редактор и привязки к файлам не изменились.
 *
 * СЕССИЯ 17: редактирование через библиотеку src/editor.c (порт kilo):
 * построчное хранилище, скроллинг, Delete, поиск Ctrl+F, подсветка
 * синтаксиса (C-подобная, JS тоже ею покрывается), номера строк, мышь,
 * полоса прокрутки. Окно вывода — общий app_outwin_open.
 *
 * Открывает .js-файлы, позволяет редактировать и запускать.
 * Кнопка [Run] (F9) выполняет скрипт через mqjs_run (mqjs_api.c).
 *
 * Шаблон нового скрипта — калькулятор на GUI-API (win_/btn_).
 */
#include "apps.h"
#include "wm.h"
#include "fb.h"
#include "editor.h"
#include "kbd.h"
#include "mem.h"
#include "string.h"
#include "ramfs.h"
#include "mqjs_os.h"
#include "task.h"
#include "mouse.h"
#include "filedlg.h"
#include "fat32.h"    /* сессия 14: сохранение скрипта на любой диск */

#define QJ_HEADER_H 22
#define BTN_COUNT 4
#define BTN_W 70
#define BTN_H 18
#define BTN_GAP 4
#define BTN_X0 4
#define BTN_Y0 2

/* окно редактора: 80 колонок, 24 строки (шрифт 8x16) */
#define QJ_COLS 80
#define QJ_ROWS 24

typedef struct {
    ed_t   *ed;                /* редактор-библиотека (kilo) */
    char    filename[FD_NAME_MAX + 1];
    int     compiling;         /* 1 = идёт задача выполнения скрипта */
    int     orphan;            /* окно закрыто во время выполнения:
                                * qj_editor_t освободит задачу */
    int     dlg;               /* 1 = открыт файловый диалог — игнорировать ввод */
    int     btn_hot;
    int     btn_pressed;
    char    status[80];
} qj_editor_t;

static const char *qj_buttons[BTN_COUNT] = {
    "Save F2", "Load F4", "Run F9", "Esc"
};

static void qj_btn_rect(int idx, int *bx, int *by, int *bw, int *bh) {
    *bx = BTN_X0 + idx * (BTN_W + BTN_GAP);
    *by = BTN_Y0; *bw = BTN_W; *bh = BTN_H;
}

static int qj_btn_at(qj_editor_t *e, int mx, int my) {
    (void)e;
    if (my < BTN_Y0 || my >= BTN_Y0 + BTN_H) return -1;
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh; qj_btn_rect(i, &bx, &by, &bw, &bh);
        if (mx >= bx && mx < bx + bw) return i;
    }
    return -1;
}

static void qj_status(qj_editor_t *e, const char *msg) {
    strncpy(e->status, msg, sizeof(e->status) - 1);
    e->status[sizeof(e->status) - 1] = 0;
}

/* ---------- задача запуска ---------- */
typedef struct {
    qj_editor_t *ed;           /* редактор-владелец (см. orphan) */
    char *src;                 /* СНИМОК текста на момент F9 */
    char *out;
    u32   out_max;
    int   result;
} qj_run_ctx_t;

static void qj_run_task(void *arg) {
    qj_run_ctx_t *c = (qj_run_ctx_t *)arg;
    /* Запуск по СНИМКУ: правки пользователя во время выполнения
     * интерпретатора не влияют на него. */
    c->result = mqjs_run(c->src, c->out, c->out_max);

    if (c->ed) {
        if (!c->ed->orphan) {
            if (c->result == 0)
                snprintf(c->ed->status, sizeof(c->ed->status), "OK: выполнено");
            else
                snprintf(c->ed->status, sizeof(c->ed->status),
                         "Ошибка: код %d (смотри вывод)", c->result);
            c->ed->compiling = 0;
        } else {
            ed_free(c->ed->ed);  /* окно закрыто при активной задачи */
            free(c->ed);
            c->ed = NULL;
        }
    }

    u32 out_len = (u32)strlen(c->out);
    app_outwin_open("QuickJS: вывод", c->out, out_len);
    free(c->src);
    free(c->out);
    free(c);
    task_exit();
}

/* ---------- сохранение ---------- */
/* Выгрузить текст и записать в RAM disk под именем name. */
static int qj_save_text(qj_editor_t *e, const char *name, char *text, int len) {
    if (!ramfs_ready()) { qj_status(e, "RAM disk недоступен"); return 0; }
    if (!name || !name[0]) name = "script.js";
    ramfs_delete(name);
    if (!ramfs_create(name, (u32)(len + 1))) { qj_status(e, "Не удалось создать файл"); return 0; }
    if (!ramfs_write(name, text, (u32)(len + 1))) { qj_status(e, "Ошибка записи"); return 0; }
    strncpy(e->filename, name, sizeof(e->filename) - 1);
    e->filename[sizeof(e->filename) - 1] = 0;
    ed_mark_clean(e->ed);
    char msg[96];
    snprintf(msg, sizeof(msg), "Сохранено: %s (%d байт)", e->filename, len);
    qj_status(e, msg);
    return 1;
}

static int qj_save_current(qj_editor_t *e) {
    int len = 0;
    char *text = ed_get_text_alloc(e->ed, &len);
    if (!text) { qj_status(e, "Нет памяти для выгрузки текста"); return 0; }
    int ok = qj_save_text(e, e->filename[0] ? e->filename : "script.js",
                          text, len);
    free(text);
    return ok;
}

/* ----- колбэки стандартных диалогов ----- */
static void qj_dlg_save_ok(void *ctx, const fd_save_t *save) {
    qj_editor_t *e = (qj_editor_t *)ctx;
    e->dlg = 0;
    if (!save->name[0]) { qj_status(e, "Пустое имя"); return; }

    int len = 0;
    char *text = ed_get_text_alloc(e->ed, &len);
    if (!text) { qj_status(e, "Нет памяти для выгрузки текста"); return; }

    if (save->source == FD_SRC_RAMFS) {
        /* сессия 14: иерархия — полный путь каталога + имя */
        char full[232];
        const char *base = save->path;
        if (base[0] == '/' && !base[1]) snprintf(full, sizeof(full), "%s", save->name);
        else snprintf(full, sizeof(full), "%s/%s", base, save->name);
        qj_save_text(e, full, text, len);
    } else {
        /* HDD/USB FAT32 (сессия 14): как в файловом менеджере */
        if (!fat32_ready()) {
            qj_status(e, "FAT32 не смонтирована");
        } else if (fat32_write_file(save->cluster, save->name,
                                    text, (u32)(len + 1))) {
            strncpy(e->filename, save->name, sizeof(e->filename) - 1);
            e->filename[sizeof(e->filename) - 1] = 0;
            ed_mark_clean(e->ed);
            char msg[96];
            const char *d = save->source == FD_SRC_ATA ? "HDD" : "USB";
            snprintf(msg, sizeof(msg), "Сохранено: %s:%s/%s (%d байт)",
                     d, save->path, e->filename, len);
            qj_status(e, msg);
        } else {
            qj_status(e, "Ошибка записи на диск");
        }
    }
    free(text);
}
static void qj_dlg_open_ok(void *ctx, const fd_pick_t *pick, char *content, int len) {
    qj_editor_t *e = (qj_editor_t *)ctx;
    e->dlg = 0;
    if (!content || len <= 0) { qj_status(e, "Пустой файл"); return; }
    ed_set_text(e->ed, content, len);
    free(content);
    ed_mark_clean(e->ed);
    strncpy(e->filename, pick->name, sizeof(e->filename) - 1);
    e->filename[sizeof(e->filename) - 1] = 0;
    char msg[96];
    const char *src = pick->source == FD_SRC_RAMFS ? "RAM disk"
                   : pick->source == FD_SRC_ATA ? "HDD" : "USB";
    snprintf(msg, sizeof(msg), "Загружено: %s (%d байт, %s)", e->filename, len, src);
    qj_status(e, msg);
}
static void qj_dlg_cancel(void *ctx) {
    qj_editor_t *e = (qj_editor_t *)ctx;
    e->dlg = 0;
    qj_status(e, "Отменено");
}

static void qj_save_as(qj_editor_t *e) {
    if (e->dlg) return;
    e->dlg = 1;
    qj_status(e, "Сохранение: выберите диск и имя (Tab — диск)");
    filedlg_save("Сохранить скрипт как", e->filename[0] ? e->filename : "script.js",
                 FD_SRC_RAMFS,
                 qj_dlg_save_ok, qj_dlg_cancel, e);
}
static void qj_open_file(qj_editor_t *e) {
    if (e->dlg) return;
    e->dlg = 1;
    qj_status(e, "Открытие: выберите файл...");
    filedlg_open("Открыть скрипт", ".js,.txt",
                 e->filename[0] ? e->filename : NULL,
                 qj_dlg_open_ok, qj_dlg_cancel, e);
}
static void qj_run(qj_editor_t *e) {
    if (e->compiling) { qj_status(e, "Уже выполняется..."); return; }
    if (ed_len_bytes(e->ed) == 0) { qj_status(e, "Буфер пуст"); return; }
    qj_save_current(e);   /* автосейв перед запуском */

    qj_run_ctx_t *c = (qj_run_ctx_t *)malloc(sizeof(qj_run_ctx_t));
    if (!c) { qj_status(e, "Нет памяти"); return; }
    memset(c, 0, sizeof(*c));
    c->ed = e;
    c->out_max = 16384;
    c->out = (char *)malloc(c->out_max);
    c->src = ed_get_text_alloc(e->ed, NULL);   /* снимок текста */
    if (!c->out || !c->src) {
        if (c->out) free(c->out);
        if (c->src) free(c->src);
        free(c);
        qj_status(e, "Нет памяти под вывод");
        return;
    }
    c->out[0] = 0;
    c->result = -1;
    e->compiling = 1;
    qj_status(e, "Выполнение...");
    int tid = task_spawn("quickjs", qj_run_task, c);
    if (tid < 0) {
        e->compiling = 0;
        free(c->src); free(c->out); free(c);
        qj_status(e, "Не удалось породить задачу");
    }
}

/* Шаблон нового скрипта — калькулятор на GUI-API (функции win_ и btn_).
 * Диалект — ES5.1 движка mquickjs: var/function (без let/const/стрелок/
 * template literals — парсер движка их не поддерживает). */
static const char *qj_template =
    "/* QuickJS — калькулятор на GUI-API (окна и кнопки).\n"
    " *\n"
    " * Функции ОС (см. mqjs_api.c):\n"
    " *   win_open(title, x, y, w, h)      -> дескриптор окна или -1\n"
    " *   win_alive(id)                    -> true, пока окно открыто\n"
    " *   win_close(id)                    — закрыть окно\n"
    " *   win_clear(id, color)             — очистить окно цветом\n"
    " *   win_rect(id, x, y, w, h, color)  — прямоугольник\n"
    " *   win_text(id, x, y, text, color)  — текст (шрифт 8x16)\n"
    " *   win_update(id)                   — перерисовать сейчас\n"
    " *   btn_add(id, x, y, w, h, label)   -> номер кнопки или -1\n"
    " *   btn_clicked(id)                  -> номер нажатой кнопки или -1\n"
    " *\n"
    " * Диалект: ES5.1 (var/function — без let/const/стрелок).\n"
    " */\n"
    "\n"
    "function apply(acc, cur, op) {\n"
    "    if (op === 1) return acc + cur;\n"
    "    if (op === 2) return acc - cur;\n"
    "    if (op === 3) return acc * cur;\n"
    "    if (op === 4) return cur === 0 ? NaN : acc / cur;\n"
    "    return cur;\n"
    "}\n"
    "\n"
    "var win = win_open(\"Калькулятор\", 240, 160, 240, 286);\n"
    "if (win < 0) {\n"
    "    print(\"Нет свободных окон\");\n"
    "} else {\n"
    "    var col_bg    = get_color(30, 32, 40);\n"
    "    var col_panel = get_color(44, 48, 62);\n"
    "    var col_fg    = get_color(235, 238, 245);\n"
    "    var col_dim   = get_color(120, 126, 140);\n"
    "    var col_acc   = get_color(232, 118, 66);\n"
    "\n"
    "    var WW = 240, WH = 286, M = 10, BW = 50, BH = 38, G = 5, dy = 52;\n"
    "    var x0 = M, y0 = M + dy + G;\n"
    "\n"
    "    /* сетка 4x4, id кнопок 0..15:\n"
    "     *   7  8  9  /\n"
    "     *   4  5  6  *\n"
    "     *   1  2  3  -\n"
    "     *   C  0  =  + */\n"
    "    var keys = \"789/456*123-C0=+\";\n"
    "    for (var i = 0; i < 16; i++) {\n"
    "        var cx = i % 4, cy = (i / 4) | 0;\n"
    "        btn_add(win, x0 + cx * (BW + G), y0 + cy * (BH + G),\n"
    "                BW, BH, keys.charAt(i));\n"
    "    }\n"
    "\n"
    "    var acc = 0, cur = 0, op = 0, fresh = 1, err = 0;\n"
    "    while (win_alive(win)) {\n"
    "        var b = btn_clicked(win);\n"
    "        if (b >= 0) {\n"
    "            if (b === 12) {              /* C — полный сброс */\n"
    "                acc = 0; cur = 0; op = 0; fresh = 1; err = 0;\n"
    "            } else if (b === 14) {       /* = — вычислить */\n"
    "                if (op === 4 && cur === 0) err = 1;\n"
    "                else if (op > 0) cur = apply(acc, cur, op);\n"
    "                op = 0; fresh = 1;\n"
    "            } else if (b === 3 || b === 7 || b === 11 || b === 15) {\n"
    "                var nop = 1;             /* / * - + */\n"
    "                if (b === 3) nop = 4;\n"
    "                else if (b === 7) nop = 3;\n"
    "                else if (b === 11) nop = 2;\n"
    "                if (op === 4 && cur === 0) {\n"
    "                    err = 1;             /* деление на ноль */\n"
    "                } else {\n"
    "                    if (op > 0) cur = apply(acc, cur, op);\n"
    "                    acc = cur; op = nop; fresh = 1;\n"
    "                }\n"
    "            } else {                     /* цифры */\n"
    "                var d = [7,8,9,0,4,5,6,0,1,2,3,0,0,0,0,0][b];\n"
    "                if (err) { err = 0; cur = 0; }\n"
    "                if (fresh) { cur = d; fresh = 0; }\n"
    "                else cur = cur * 10 + d;\n"
    "            }\n"
    "        }\n"
    "\n"
    "        /* экран калькулятора */\n"
    "        win_clear(win, col_bg);\n"
    "        win_rect(win, M, M, WW - 2 * M, dy, col_panel);\n"
    "        if (err) win_text(win, M + 10, M + 18, \"Err\", col_acc);\n"
    "        else win_text(win, M + 10, M + 18, String(cur), col_fg);\n"
    "        win_text(win, M, WH - 46, \"QuickJS calculator\", col_dim);\n"
    "        win_update(win);\n"
    "        delay(30);\n"
    "    }\n"
    "}\n"
    "\n"
    "print(\"Калькулятор закрыт\");\n";

static void qj_draw(window_t *w) {
    qj_editor_t *e = (qj_editor_t *)w->data;
    int cw = win_content_w(w), ch = win_content_h(w);

    fb_fill_rect(0, 0, cw, QJ_HEADER_H, wm_theme_title());
    for (int i = 0; i < BTN_COUNT; i++) {
        int bx, by, bw, bh; qj_btn_rect(i, &bx, &by, &bw, &bh);
        u32 bg = (e->btn_pressed == i) ? fb_rgb(0x4A, 0x7F, 0xB0)
              : (e->btn_hot == i) ? fb_rgb(0x32, 0x60, 0x8E)
              : fb_rgb(0x25, 0x4A, 0x70);
        /* сессия 20: подпись гарантированно внутри кнопки */
        wm_button_draw(bx, by, bw, bh, qj_buttons[i],
                       bg, wm_theme_text(), wm_theme_accent());
    }
    char info[112];
    {
        int ln1 = 0, col1 = 0, nrows = 0;
        ed_cursor_pos(e->ed, &ln1, &col1, &nrows);
        snprintf(info, sizeof(info), "%s%s  Стр %d, Кол %d из %d",
                 e->filename[0] ? e->filename : "(без имени)",
                 ed_dirty(e->ed) ? " *" : "", ln1, col1, nrows);
    }
    int ix = BTN_X0 + BTN_COUNT * (BTN_W + BTN_GAP);
    if (ix < cw - 260) fb_text(ix, BTN_Y0 + 3, info, wm_theme_text(), -1);

    /* текстовая область — вся правка в библиотеке editor.c */
    ed_draw(e->ed, 0, QJ_HEADER_H, cw, ch - QJ_HEADER_H - 14);

    fb_fill_rect(0, ch - 14, cw, 14, wm_theme_win_bg_alt());
    fb_text(4, ch - 12, e->status, wm_theme_text_info(), -1);
}

static void qj_key(window_t *w, const key_event_t *ev) {
    qj_editor_t *e = (qj_editor_t *)w->data;
    if (ev->flags & KF_RELEASED) return;
    if (e->dlg) return;                      /* открыт диалог — игнорируем ввод */
    if (ev->code == 0x3C) { qj_save_as(e); win_invalidate(w); return; }
    if (ev->code == 0x3E) { qj_open_file(e); win_invalidate(w); return; }
    if (ev->code == 0x43) { qj_run(e); win_invalidate(w); return; }
    if ((ev->ch == 0x1B || ev->code == 0x01) && !ed_in_find(e->ed)) {
        win_close(w);
        return;
    }
    ed_key(e->ed, ev, win_content_w(w), win_content_h(w) - QJ_HEADER_H - 14);
    win_invalidate(w);
}

static void qj_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed) {
    qj_editor_t *e = (qj_editor_t *)w->data;
    if (e->dlg) return;
    int inside = (my < QJ_HEADER_H);
    if (inside) {
        int btn = qj_btn_at(e, mx, my);
        if (btn != e->btn_hot) { e->btn_hot = btn; win_invalidate(w); }
        if ((changed & MSB_LEFT) && (buttons & MSB_LEFT)) {
            if (btn >= 0) { e->btn_pressed = btn; win_invalidate(w); }
        }
        if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT)) {
            int wp = e->btn_pressed; e->btn_pressed = -1;
            if (wp >= 0 && btn == wp) {
                if (wp == 0) qj_save_as(e);
                else if (wp == 1) qj_open_file(e);
                else if (wp == 2) qj_run(e);
                else if (wp == 3) win_close(w);
            }
            win_invalidate(w);
        }
        return;
    }
    int area_h = win_content_h(w) - QJ_HEADER_H - 14;
    int eaten = ed_mouse(e->ed, mx, my - QJ_HEADER_H,
                         buttons, changed, win_content_w(w), area_h);
    if (eaten) {
        win_invalidate(w);
        return;
    }
    if (e->btn_hot != -1 || e->btn_pressed != -1) {
        e->btn_hot = -1; e->btn_pressed = -1; win_invalidate(w);
    }
}

static void qj_close(window_t *w) {
    qj_editor_t *e = (qj_editor_t *)w->data;
    if (!e) return;
    if (e->compiling) {
        /* задача выполнения держит указатель — память освободит она */
        e->orphan = 1;
    } else {
        ed_free(e->ed);
        free(e);
    }
}

static qj_editor_t *qj_new_with(const char *filename, const char *content, int len) {
    qj_editor_t *e = (qj_editor_t *)malloc(sizeof(qj_editor_t));
    if (!e) return NULL;
    memset(e, 0, sizeof(qj_editor_t));
    e->ed = ed_create(1);       /* C-подобная подсветка: JS тоже покрывается */
    if (!e->ed) { free(e); return NULL; }
    if (content && len > 0) {
        ed_set_text(e->ed, content, len);
    } else {
        int tl = (int)strlen(qj_template);
        ed_set_text(e->ed, qj_template, tl);
    }
    e->btn_hot = -1; e->btn_pressed = -1;
    if (filename && filename[0]) {
        strncpy(e->filename, filename, sizeof(e->filename) - 1);
        e->filename[sizeof(e->filename) - 1] = 0;
    } else { strcpy(e->filename, "script.js"); }
    qj_status(e, "F2 — сохранить, F4 — открыть, F9 — выполнить, Ctrl+F — поиск");
    return e;
}

/* единая геометрия окна */
static void qj_create_window(qj_editor_t *e, const char *title) {
    u32 W = fb_width(), H = fb_height();
    int ww = QJ_COLS * 8 + 20;
    int wh = QJ_ROWS * 16 + QJ_HEADER_H + 14 + TITLE_H + 2;
    if (ww > (int)W) ww = (int)W;
    if (wh > (int)H - TBAR_H) wh = (int)H - TBAR_H;
    win_create(title, 80, 30, ww, wh, qj_draw, qj_key, qj_mouse, NULL, qj_close, e);
}

void app_quickjs_open(void) {
    qj_editor_t *e = qj_new_with(NULL, NULL, 0);
    if (!e) return;
    qj_create_window(e, "QuickJS");
}

void app_quickjs_open_with(const char *filename, const char *content, int len) {
    qj_editor_t *e = qj_new_with(filename, content, len);
    if (!e) return;
    char title[64];
    snprintf(title, sizeof(title), "QuickJS: %s", filename ? filename : "?");
    qj_create_window(e, title);
}
