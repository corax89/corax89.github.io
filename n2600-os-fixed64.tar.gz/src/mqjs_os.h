/* mqjs_os.h — публичный вход интерпретатора QuickJS в N2600-OS (сессия 64).
 *
 * CMScript заменён на MicroQuickJS (bellard/mquickjs, MIT). Скриптовый
 * язык — JavaScript (диалект ES5.1: var/function, без let/const/стрелок/
 * template literals), плюс API ОС (см. mqjs_api.c):
 *   print/print_int, screen_width/height, fill_rect, draw_text,
 *   get_color, clear_screen, flip, delay, uptime, strlen,
 *   ramfs_read/ramfs_write/ramfs_list,
 *   win_open/win_close/win_alive/win_clear/win_rect/win_text/win_update,
 *   btn_add/btn_clicked/btn_set_label,
 *   img_load/img_free/img_w/img_h/img_pixel/img_draw/img_draw_scaled,
 *   win_img/win_img_scaled.
 */
#ifndef MQJS_OS_H
#define MQJS_OS_H

#include "types.h"

/* Запустить .js-скрипт. Возвращает 0 при успехе, -1 при ошибке
 * (текст ошибки и весь вывод print() попадают в out).
 * src     — NUL-terminated исходник.
 * out     — буфер под вывод (print/ошибки).
 * out_max — размер буфера out. */
int mqjs_run(const char *src, char *out, u32 out_max);

#endif /* MQJS_OS_H */
