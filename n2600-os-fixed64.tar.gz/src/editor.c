/* editor.c — переиспользуемый текстовый редактор N2600-OS.
 *
 * Порт kilo 0.0.1 (antirez, BSD) с терминала на фреймбуфер ОС:
 *   - терминал/ANSI заменён на fb_* и канвас окна;
 *   - key_event_t ОС вместо escape-последовательностей;
 *   - размер экрана = прямоугольник, переданный приложением;
 *   - добавлены: номера строк, ДВЕ полосы прокрутки — вертикальная и
 *     ГОРИЗОНТАЛЬНАЯ (общий виджет wm_scrollbar, цвет из темы),
 *     клик мышью, полноценный Delete, режим поиска внутри области,
 *     ПОСТОЯННАЯ рамка-курсор (мигающий блок часто не перерисовывался
 *     и его не было видно — wm_halfsec даёт тики только окнам с
 *     on_tick, а редакторские окна его не ставят).
 * Хранилище, операции со строками, скроллинг, подсветка и поиск —
 * построчный перенос алгоритмов kilo (см. комментарии ED-KILO).
 *
 * КООРДИНАТЫ ПОЛОС И МЫШИ: wm_scrollbar_draw запоминает геометрию в ТЕХ
 * координатах, что ему передали, а wm_scrollbar_mouse сравнивает их с
 * координатами мыши. Приложения рисуют редактор со смещением
 * (ed_draw(ed, 0, HEADER_H, ...)), а мышь отдают ОТНОСИТЕЛЬНО области
 * (my - HEADER_H) — раньше сравнение шло в разных системах координат:
 * клики по полосе работали как «страница», а drag ползунка не двигал
 * его вовсе. Теперь ed_draw запоминает свой угол (ox/oy), и ed_mouse
 * переводит мышь в систему координат отрисовки перед вызовом
 * wm_scrollbar_mouse (FIX, сессия 19).
 */
#include "editor.h"
#include "wm.h"
#include "fb.h"
#include "mouse.h"    /* MSB_LEFT (клики по тексту) */
#include "string.h"
#include "mem.h"
#include "utf8.h"

/* ---------- геометрия ---------- */
#define CHAR_W   8      /* шрифт ОС: 8x16, моноширинный (кириллица тоже 8) */
#define CHAR_H   16
#define SB_W     8      /* ширина колонки полосы прокрутки (бар 6 px) */
#define PAD_L    4      /* отступ текста слева */

/* ---------- цвета подсветки (фиксированные, как в любом редакторе;
 * фон/текст/курсор/комментарии берутся из темы) ---------- */
#define HL_COL_KEYWORD1  0xFFE8B44Au   /* янтарный   */
#define HL_COL_KEYWORD2  0xFF7FC866u   /* зелёный    */
#define HL_COL_STRING    0xFFD080E0u   /* розовый    */
#define HL_COL_NUMBER    0xFFE06C50u   /* красный    */
#define HL_COL_MATCH     0xFFFFE060u   /* жёлтый     */

/* классы подсветки (номера как в kilo) */
#define HL_NORMAL    0
#define HL_NONPRINT  1
#define HL_COMMENT   2
#define HL_MLCOMMENT 3
#define HL_KEYWORD1  4
#define HL_KEYWORD2  5
#define HL_STRING    6
#define HL_NUMBER    7
#define HL_MATCH     8

#define HL_HIGHLIGHT_STRINGS (1 << 0)
#define HL_HIGHLIGHT_NUMBERS (1 << 1)

/* строка файла */
typedef struct ed_row {
    int idx;                 /* номер строки в файле */
    int size;                /* байт в chars (без '\0') */
    int rsize;               /* байт в render (табы расширены) */
    char *chars;             /* содержимое */
    char *render;            /* содержимое для экрана (табы -> пробелы) */
    unsigned char *hl;       /* класс подсветки каждого символа render */
    int hl_oc;               /* 1 = строка кончается открытым комментарием */
} ed_row_t;

struct editor {
    /* курсор в ЭКРАННЫХ координатах (как в kilo: cx/cy относительно
     * coloff/rowoff); позиция в файле = (rowoff+cy, coloff+cx) */
    int cx, cy;
    int rowoff, coloff;
    int numrows;
    ed_row_t *row;
    int dirty;
    int syntax;              /* 0 = обычный текст, 1 = C/CMScript */

    /* геометрия области (обновляется в ed_key/ed_draw/ed_mouse) */
    int area_w, area_h;

    /* режим поиска (Ctrl+F) */
    int  find_mode;
    char query[ED_QUERY_MAX + 1];
    int  qlen;
    int  find_dir;           /* +1 вперёд / -1 назад */
    int  last_match;         /* строка последнего совпадения или -1 */
    int  saved_hl_line;      /* сохранённая подсветка строки совпадения */
    unsigned char *saved_hl;
    int  saved_cx, saved_cy, saved_rowoff, saved_coloff;

    wm_scrollbar_t sb;       /* вертикальная полоса (общий виджет) */
    wm_scrollbar_t sbh;      /* горизонтальная полоса (сессия 19) */

    /* угол последней отрисовки в канвасе окна: мышь приходит
     * ОТНОСИТЕЛЬНО области, полосы живут в координатах канваса —
 * переводим (см. шапку файла) */
    int ox, oy;
};

/* ======================= служебное ======================= */

/* realloc без libc: malloc+копия+free (куча ОС не даёт realloc) */
static void *ed_xrealloc(void *p, u32 old_n, u32 new_n)
{
    void *n = malloc(new_n ? new_n : 1);
    if (!n) return NULL;
    if (p) {
        u32 keep = old_n < new_n ? old_n : new_n;
        memcpy(n, p, keep);
        free(p);
    }
    return n;
}

static int ed_is_digit(int c) { return c >= '0' && c <= '9'; }
static int ed_isspace(int c)  { return c == ' ' || (c >= 0x09 && c <= 0x0D); }

/* ---------- UTF-8 (FIX: кириллица = 2 байта, 1 символ) ----------
 * Модель редактора: cx/coloff — смещения в БАЙТАХ внутри chars, но:
 *  - шаги курсора влево/вправо, Backspace/Delete двигаются на ЦЕЛЫЙ
 *    символ (не на байт — иначе разрезали букву и получали «?»);
 *  - экранная колонка (rx) считается по СИМВОЛАМ, табы — до упора;
 *  - coloff всегда держится на границе символа;
 *  - отрисовка не отрезает половину последовательности. */

/* длина последовательности UTF-8 в chars по смещению at */
static int ed_char_len(const ed_row_t *row, int at)
{
    if (at < 0 || at >= row->size) return 1;
    return utf8_seq_len((unsigned char)row->chars[at]);
}

/* начало последовательности, предшествующей смещению off */
static int ed_prev_boundary(const ed_row_t *row, int off)
{
    if (off <= 0) return 0;
    return utf8_align_back(row->chars, off - 1);
}

/* экранная колонка (символы, табы — до следующей позиции табуляции)
 * для отрезка [coloff, coloff+cx) строки */
static int ed_cursor_rx(const ed_row_t *row, int coloff, int cx)
{
    int rx = 0;
    int j = coloff;
    int end = coloff + cx;
    if (end > row->size) end = row->size;
    while (j < end) {
        if (row->chars[j] == '\t') {
            rx += ED_TAB_STOP - (rx % ED_TAB_STOP);
            j++;
        } else {
            j += utf8_seq_len((unsigned char)row->chars[j]);
            rx++;
        }
    }
    return rx;
}

/* ED-KILO: is_separator() */
static int ed_is_separator(int c)
{
    return c == '\0' || ed_isspace(c) ||
           (c && strchr(",.()+-/*=~%[];", c) != NULL);
}

/* ==================== подсветка синтаксиса ==================== */

/* ключевые слова C (ED-KILO: C_HL_keywords; '|' — второй цвет) */
/* Общий список для C-редактора и QuickJS (сессия 64): JS-ключевые слова
 * добавлены вторым блоком (в C-коде такие идентификаторы редки, ложная
 * подсветка безвредна). '|' — второй цвет (типы/литералы). */
static const char *ed_c_keywords[] = {
    "auto","break","case","continue","default","do","else","enum",
    "extern","for","goto","if","register","return","sizeof","static",
    "struct","switch","typedef","union","volatile","while","NULL",
    "int|","long|","double|","float|","char|","unsigned|","signed|",
    "void|","const|","bool|",
    /* JavaScript (диалект mquickjs) */
    "function","var","let","new","this","typeof","instanceof","in",
    "delete","throw","try","catch","finally","class","extends","yield",
    "true|","false|","null|","undefined|","NaN|","Infinity|",
    NULL
};

/* ED-KILO: editorRowHasOpenComment() */
static int ed_row_has_open_comment(ed_row_t *row)
{
    if (row->hl && row->rsize && row->hl[row->rsize - 1] == HL_MLCOMMENT &&
        (row->rsize < 2 || (row->render[row->rsize - 2] != '*' ||
                            row->render[row->rsize - 1] != '/')))
        return 1;
    return 0;
}

/* ED-KILO: editorUpdateSyntax() — класс каждого символа render */
static void ed_update_syntax(ed_t *E, ed_row_t *row)
{
    /* В kilo здесь realloc(row->hl, rsize) — старое содержимое всё равно
     * сразу затирается memset'ом HL_NORMAL, поэтому в куче без realloc
     * просто перевыделяем с нуля. */
    if (row->hl) { free(row->hl); row->hl = NULL; }
    row->hl = (unsigned char *)malloc((u32)row->rsize + 1);
    if (row->hl && row->rsize > 0)
        memset(row->hl, HL_NORMAL, (u32)row->rsize);
    if (!E->syntax || row->rsize == 0) return;

    const char **keywords = ed_c_keywords;
    const char *scs = "//";
    const char *mcs = "/*";
    const char *mce = "*/";

    int i = 0, prev_sep = 1, in_string = 0, in_comment = 0;
    const char *p = row->render;

    while (*p && ed_isspace((unsigned char)*p)) { p++; i++; }

    if (row->idx > 0 && ed_row_has_open_comment(&E->row[row->idx - 1]))
        in_comment = 1;

    while (*p) {
        /* // комментарий — до конца строки */
        if (prev_sep && *p == scs[0] && p[1] == scs[1]) {
            memset(row->hl + i, HL_COMMENT, (u32)(row->rsize - i));
            return;
        }
        /* многострочные комментарии */
        if (in_comment) {
            row->hl[i] = HL_MLCOMMENT;
            if (*p == mce[0] && p[1] == mce[1]) {
                row->hl[i + 1] = HL_MLCOMMENT;
                p += 2; i += 2;
                in_comment = 0;
                prev_sep = 1;
                continue;
            }
            prev_sep = 0; p++; i++;
            continue;
        }
        if (*p == mcs[0] && p[1] == mcs[1]) {
            row->hl[i] = HL_MLCOMMENT;
            row->hl[i + 1] = HL_MLCOMMENT;
            p += 2; i += 2;
            in_comment = 1;
            prev_sep = 0;
            continue;
        }
        /* строки */
        if (in_string) {
            row->hl[i] = HL_STRING;
            if (*p == '\\') {
                if (i + 1 < row->rsize) row->hl[i + 1] = HL_STRING;
                p += 2; i += 2;
                prev_sep = 0;
                continue;
            }
            if (*p == in_string) in_string = 0;
            p++; i++;
            continue;
        }
        if (*p == '"' || *p == '\'') {
            in_string = *p;
            row->hl[i] = HL_STRING;
            p++; i++;
            prev_sep = 0;
            continue;
        }
        /* непечатные */
        if ((unsigned char)*p < 32) {
            row->hl[i] = HL_NONPRINT;
            p++; i++;
            prev_sep = 0;
            continue;
        }
        /* числа */
        if ((ed_is_digit(*p) && (prev_sep ||
             (i > 0 && row->hl[i - 1] == HL_NUMBER))) ||
            (*p == '.' && i > 0 && row->hl[i - 1] == HL_NUMBER)) {
            row->hl[i] = HL_NUMBER;
            p++; i++;
            prev_sep = 0;
            continue;
        }
        /* ключевые слова */
        if (prev_sep) {
            int j;
            for (j = 0; keywords[j]; j++) {
                int klen = (int)strlen(keywords[j]);
                int kw2 = keywords[j][klen - 1] == '|';
                if (kw2) klen--;
                if (!strncmp(p, keywords[j], (u32)klen) &&
                    ed_is_separator((unsigned char)p[klen])) {
                    memset(row->hl + i, kw2 ? HL_KEYWORD2 : HL_KEYWORD1,
                           (u32)klen);
                    p += klen;
                    i += klen;
                    break;
                }
            }
            if (keywords[j]) {
                prev_sep = 0;
                continue;
            }
        }
        prev_sep = ed_is_separator((unsigned char)*p);
        p++; i++;
    }

    /* открытый комментарий тянется на следующие строки */
    {
        int oc = ed_row_has_open_comment(row);
        if (row->hl_oc != oc && row->idx + 1 < E->numrows)
            ed_update_syntax(E, &E->row[row->idx + 1]);
        row->hl_oc = oc;
    }
}

/* ED-KILO: editorUpdateRow() — render (табы) + подсветка */
static void ed_update_row(ed_row_t *row)
{
    int tabs = 0, j, idx = 0;

    for (j = 0; j < row->size; j++)
        if (row->chars[j] == '\t') tabs++;

    if (row->render) free(row->render);
    row->render = (char *)malloc((u32)row->size + (u32)tabs * ED_TAB_STOP + 1);
    if (!row->render) { row->rsize = 0; row->hl_oc = 0; return; }

    for (j = 0; j < row->size; j++) {
        if (row->chars[j] == '\t') {
            row->render[idx++] = ' ';
            while ((idx + 1) % ED_TAB_STOP != 0) row->render[idx++] = ' ';
        } else {
            row->render[idx++] = row->chars[j];
        }
    }
    row->render[idx] = '\0';
    row->rsize = idx;
}

/* ==================== операции со строками ==================== */

/* ED-KILO: editorInsertRow() */
static int ed_insert_row(ed_t *E, int at, const char *s, int len)
{
    if (at < 0 || at > E->numrows) return 0;

    /* сначала выделяем содержимое: при нехватке памяти состояние
     * редактора не меняется вовсе */
    char *chars = (char *)malloc((u32)len + 1);
    if (!chars) return 0;
    if (len > 0 && s) memcpy(chars, s, (u32)len);
    chars[len] = 0;

    ed_row_t *nr = (ed_row_t *)ed_xrealloc(
        E->row, (u32)E->numrows * sizeof(ed_row_t),
        (u32)(E->numrows + 1) * sizeof(ed_row_t));
    if (!nr) { free(chars); return 0; }
    E->row = nr;

    if (at != E->numrows) {
        memmove(E->row + at + 1, E->row + at,
                sizeof(ed_row_t) * (u32)(E->numrows - at));
        for (int j = at + 1; j <= E->numrows; j++) E->row[j].idx++;
    }
    E->row[at].size = len;
    E->row[at].chars = chars;
    E->row[at].hl = NULL;
    E->row[at].hl_oc = 0;
    E->row[at].render = NULL;
    E->row[at].rsize = 0;
    E->row[at].idx = at;
    ed_update_row(&E->row[at]);
    ed_update_syntax(E, &E->row[at]);
    E->numrows++;
    E->dirty = 1;
    return 1;
}

/* ED-KILO: editorFreeRow() + editorDelRow() */
static void ed_free_row(ed_row_t *row)
{
    if (row->render) free(row->render);
    if (row->chars) free(row->chars);
    if (row->hl) free(row->hl);
}

static void ed_del_row(ed_t *E, int at)
{
    if (at < 0 || at >= E->numrows) return;
    ed_free_row(&E->row[at]);
    memmove(E->row + at, E->row + at + 1,
            sizeof(ed_row_t) * (u32)(E->numrows - at - 1));
    for (int j = at; j < E->numrows - 1; j++) E->row[j].idx++;
    E->numrows--;
    E->dirty = 1;
}

/* ED-KILO: editorRowInsertChar() */
static void ed_row_insert_char(ed_t *E, ed_row_t *row, int at, int c)
{
    if (at > row->size) {
        int padlen = at - row->size;
        char *nc = (char *)ed_xrealloc(row->chars, (u32)row->size + 1,
                                       (u32)row->size + (u32)padlen + 2);
        if (!nc) return;
        row->chars = nc;
        memset(row->chars + row->size, ' ', (u32)padlen);
        row->size += padlen;
    } else {
        char *nc = (char *)ed_xrealloc(row->chars, (u32)row->size + 1,
                                       (u32)row->size + 2);
        if (!nc) return;
        row->chars = nc;
        memmove(row->chars + at + 1, row->chars + at,
                (u32)(row->size - at + 1));
        row->size++;
    }
    row->chars[at] = (char)c;
    row->chars[row->size] = 0;
    ed_update_row(row);
    ed_update_syntax(E, row);
    E->dirty = 1;
}

/* ED-KILO: editorRowAppendString() */
static void ed_row_append_string(ed_t *E, ed_row_t *row,
                                 const char *s, int len)
{
    char *nc = (char *)ed_xrealloc(row->chars, (u32)row->size + 1,
                                   (u32)row->size + (u32)len + 1);
    if (!nc) return;
    row->chars = nc;
    memcpy(row->chars + row->size, s, (u32)len);
    row->size += len;
    row->chars[row->size] = 0;
    ed_update_row(row);
    ed_update_syntax(E, row);
    E->dirty = 1;
}

/* удалить len байт начиная с at (ЦЕЛЫЕ символы; для UTF-8 len берётся
 * через ed_char_len — чтобы не оставить половину буквы). FIX UTF-8.
 * Заменяет ed_row_del_char из kilo (там удалялся ровно 1 байт). */
static void ed_row_del_span(ed_t *E, ed_row_t *row, int at, int len)
{
    if (at < 0 || at >= row->size || len <= 0) return;
    if (at + len > row->size) len = row->size - at;
    memmove(row->chars + at, row->chars + at + len,
            (u32)(row->size - at - len + 1));
    row->size -= len;
    row->chars[row->size] = 0;
    ed_update_row(row);
    ed_update_syntax(E, row);
    E->dirty = 1;
}

/* ==================== раскладка области ==================== */

static int ed_linenr_px(const ed_t *E)
{
    if (!E || !E->row || E->numrows <= 0) return 2 * CHAR_W;
    int n = E->numrows, digits = 1;
    while (n >= 10) { n /= 10; digits++; }
    if (digits > 5) digits = 5;
    return (digits + 1) * CHAR_W;
}

/* видимых строк в области высотой h */
static int ed_vis_rows(int area_h)
{
    int v = area_h / CHAR_H;
    return v < 1 ? 1 : v;
}

/* видимых колонок текста (без номеров строк и полосы прокрутки) */
static int ed_vis_cols(const ed_t *E, int area_w)
{
    int w = area_w - SB_W - ed_linenr_px(E) - PAD_L;
    int c = w / CHAR_W;
    return c < 4 ? 4 : c;
}

/* верх горизонтальной полосы (в координатах ОБЛАСТИ): обычный режим —
 * нижняя кромка; в режиме поиска — над строкой «Поиск: …» */
static int ed_hbar_top(const ed_t *E, int area_h)
{
    int t = area_h - SB_W;
    if (E->find_mode) t -= CHAR_H;
    return t > 0 ? t : 0;
}

/* самая длинная строка файла (байт render) — предел горизонтальной
 * прокрутки */
static int ed_maxlen(const ed_t *E)
{
    int m = 0;
    for (int j = 0; j < E->numrows; j++)
        if (E->row[j].rsize > m) m = E->row[j].rsize;
    return m;
}

/* максимум coloff (в байтах): длиннейшая строка минус видимая ширина,
 * +1 — курсор в КОНЦЕ длиннейшей строки (rx = maxlen) требует
 * coloff = maxlen - vis_c + 1, чтобы попасть в кадр (rx < vis_c).
 * vis_c в СИМВОЛАХ, coloff в БАЙТАХ: на чистой кириллице окно из
 * vis_c байт показывает МЕНЬШЕ символов, чем vis_c, поэтому «+1 в
 * байтах» запас по видимости не съедает (доказано в editor_test). */
static int ed_hmax(const ed_t *E, int area_w)
{
    int hmax = ed_maxlen(E) - ed_vis_cols(E, area_w) + 1;
    return hmax > 0 ? hmax : 0;
}

/* Приведение скролла/курсора: курсор всегда в пределах видимости.
 * Вызывается после каждой операции (заменяет inline-подстройки kilo). */
static void ed_fix_scroll(ed_t *E)
{
    int vis_r = ed_vis_rows(E->area_h);
    int vis_c = ed_vis_cols(E, E->area_w);

    if (E->cy >= vis_r) { E->rowoff += E->cy - (vis_r - 1); E->cy = vis_r - 1; }
    if (E->cy < 0)      { E->rowoff += E->cy;               E->cy = 0; }
    if (E->rowoff < 0) E->rowoff = 0;
    if (E->numrows > 0 && E->rowoff > E->numrows - 1)
        E->rowoff = E->numrows - 1;

    /* курсор не дальше конца строки */
    int filerow = E->rowoff + E->cy;
    ed_row_t *row = (filerow >= 0 && filerow < E->numrows) ? &E->row[filerow] : NULL;

    /* FIX UTF-8: coloff всегда на границе символа (после смещений на
     * колонки мог попасть на продолжающий байт — экран начинался
     * с «?») */
    if (row) {
        int nc = utf8_align_back(row->chars, E->coloff);
        if (nc != E->coloff) {
            E->cx += E->coloff - nc;   /* абсолютная позиция курсора неизменна */
            E->coloff = nc;
        }
    }

    int filecol = E->coloff + E->cx;
    int rowlen = row ? row->size : 0;
    if (filecol > rowlen) {
        E->cx -= filecol - rowlen;
        if (E->cx < 0) { E->coloff += E->cx; E->cx = 0; }
    }

    /* горизонтальная видимость: rx курсора в СИМВОЛАХ (FIX UTF-8:
     * прежде байты считались колонками — на кириллице прокрутка
     * срабатывала вдвое позже, а курсор уезжал за экран) */
    if (row) {
        int rx = ed_cursor_rx(row, E->coloff, E->cx);
        if (rx >= vis_c) {
            int nc = E->coloff + (rx - (vis_c - 1));
            E->coloff = utf8_align_back(row->chars, nc);
        }
        if (E->coloff < 0) E->coloff = 0;
    }

    /* предел от drag'а горизонтальной полосы: coloff не дальше
     * ed_hmax (дальше конца длиннейшей строки смысла нет); стоит
     * ПОСЛЕ блока видимости — он покрывает и курсор в конце строки,
     * так что дребезга с ним нет */
    if (E->coloff > ed_hmax(E, E->area_w)) E->coloff = ed_hmax(E, E->area_w);
    if (E->coloff < 0) E->coloff = 0;
}

/* ==================== правка (ED-KILO) ==================== */

/* ED-KILO: editorInsertChar() */
static void ed_insert_char(ed_t *E, int c)
{
    int filerow = E->rowoff + E->cy;
    int filecol = E->coloff + E->cx;
    if (filerow >= E->numrows) {
        while (E->numrows <= filerow)
            if (!ed_insert_row(E, E->numrows, "", 0)) return;
    }
    ed_row_insert_char(E, &E->row[filerow], filecol, c);
    E->cx++;
}

/* ED-KILO: editorInsertNewline() */
static void ed_insert_newline(ed_t *E)
{
    int filerow = E->rowoff + E->cy;
    int filecol = E->coloff + E->cx;

    if (filerow >= E->numrows) {
        if (filerow == E->numrows) {
            if (!ed_insert_row(E, filerow, "", 0)) return;
        } else {
            return;
        }
    } else {
        ed_row_t *row = &E->row[filerow];
        if (filecol >= row->size) filecol = row->size;
        if (filecol == 0) {
            if (!ed_insert_row(E, filerow, "", 0)) return;
        } else {
            if (!ed_insert_row(E, filerow + 1,
                               row->chars + filecol, row->size - filecol))
                return;
            row = &E->row[filerow];
            row->chars[filecol] = 0;
            row->size = filecol;
            ed_update_row(row);
            ed_update_syntax(E, row);
        }
    }
    E->cy++;
    E->cx = 0;
    E->coloff = 0;
}

/* Удалить символ ПЕРЕД курсором (Backspace). ED-KILO: editorDelChar().
 * FIX UTF-8: удаляем ЦЕЛЫЙ символ (прежде — 1 байт: от русской буквы
 * оставался хвост-продолжение, и строка «съезжала» на «?»). */
static void ed_backspace(ed_t *E)
{
    int filerow = E->rowoff + E->cy;
    int filecol = E->coloff + E->cx;

    if (filerow >= E->numrows) return;
    if (filecol == 0 && filerow == 0) return;

    if (filecol == 0) {
        int prev_size = E->row[filerow - 1].size;
        ed_row_append_string(E, &E->row[filerow - 1],
                             E->row[filerow].chars, E->row[filerow].size);
        ed_del_row(E, filerow);
        if (E->cy == 0) E->rowoff--;
        else E->cy--;
        E->cx = prev_size;
        E->coloff = 0;
    } else {
        ed_row_t *row = &E->row[filerow];
        int from = ed_prev_boundary(row, filecol);
        int removed = filecol - from;
        if (removed > 0)
            ed_row_del_span(E, row, from, removed);
        if (E->cx >= removed) E->cx -= removed;
        else {
            /* символ начинался левее экрана */
            E->coloff -= removed - E->cx;
            if (E->coloff < 0) E->coloff = 0;
            E->cx = 0;
        }
    }
}

/* Удалить символ В КУРСОРЕ (Delete; в kilo объединён с Backspace —
 * здесь полноценный forward-delete; FIX UTF-8: целый символ). */
static void ed_forward_delete(ed_t *E)
{
    int filerow = E->rowoff + E->cy;
    int filecol = E->coloff + E->cx;

    if (filerow >= E->numrows) return;
    ed_row_t *row = &E->row[filerow];

    if (filecol < row->size) {
        ed_row_del_span(E, row, filecol, ed_char_len(row, filecol));
    } else if (filerow + 1 < E->numrows) {
        /* конец строки: присоединить следующую */
        ed_row_append_string(E, row,
                             E->row[filerow + 1].chars,
                             E->row[filerow + 1].size);
        ed_del_row(E, filerow + 1);
    }
}

/* ED-KILO: editorMoveCursor(). FIX UTF-8: шаг на ЦЕЛЫЙ символ —
 * прежде cx++/-- двигали на байт, курсор вставал в середину русской
 * буквы (и следующие отрисовки показывали «?»). */
static void ed_move_cursor(ed_t *E, int dir)
{
    int filerow = E->rowoff + E->cy;
    int filecol = E->coloff + E->cx;
    ed_row_t *row = (filerow >= 0 && filerow < E->numrows) ? &E->row[filerow] : NULL;
    int vis_r = ed_vis_rows(E->area_h);

    switch (dir) {
    case KBD_LEFT: {
        int na = E->coloff + E->cx;
        if (na > 0) {
            if (row)
                na = ed_prev_boundary(row, na);
            else
                na--;
            if (na >= E->coloff) E->cx = na - E->coloff;
            else { E->coloff = na; E->cx = 0; }
        } else if (filerow > 0) {
            /* к концу предыдущей строки */
            E->cy--;
            E->cx = E->row[filerow - 1].size;
            E->coloff = 0;
        }
        break;
    }
    case KBD_RIGHT: {
        if (row) {
            int na = E->coloff + E->cx;
            if (na < row->size) {
                na += ed_char_len(row, na);
                if (na > row->size) na = row->size;
                E->cx = na - E->coloff;
            } else if (filerow < E->numrows - 1) {
                E->cx = 0;
                E->coloff = 0;
                E->cy++;
            }
        } else if (filerow < E->numrows - 1) {
            E->cy++;
        }
        break;
    }
    case KBD_UP:
        if (E->cy == 0) {
            if (E->rowoff) E->rowoff--;
        } else {
            E->cy--;
        }
        break;
    case KBD_DOWN:
        if (filerow < E->numrows - 1 || (row && filecol < row->size)) {
            if (E->cy == vis_r - 1) E->rowoff++;
            else E->cy++;
        }
        break;
    }
}

/* Сдвинуть вид по горизонтали в newcol (байт; от drag'а полосы или
 * клика по желобу). Курсор остаётся на месте, ЕСЛИ остался в кадре;
 * уехавший влево курсор прижимается к левому краю вида — иначе
 * следующий ed_fix_scroll вернул бы вид обратно (дребезг).
 * coloff общий для всех строк — границу символа берём по строке
 * курсора. */
static void ed_hscroll_to(ed_t *E, int newcol)
{
    if (newcol < 0) newcol = 0;
    int filerow = E->rowoff + E->cy;
    if (filerow >= 0 && filerow < E->numrows) {
        ed_row_t *row = &E->row[filerow];
        int absc = E->coloff + E->cx;              /* абсолютная позиция курсора */
        if (newcol > row->size) newcol = row->size;
        newcol = utf8_align_back(row->chars, newcol);
        E->coloff = newcol;
        if (absc < E->coloff) absc = E->coloff;    /* курсор — в кадр */
        E->cx = absc - E->coloff;
    } else {
        E->coloff = newcol;
        E->cx = 0;
    }
    if (E->cx < 0) E->cx = 0;
}

/* ==================== поиск (ED-KILO: editorFind) ==================== */

#define ED_FIND_RESTORE_HL(E) do { \
    if ((E)->saved_hl) { \
        if ((E)->saved_hl_line >= 0 && (E)->saved_hl_line < (E)->numrows) { \
            ed_row_t *r = &(E)->row[(E)->saved_hl_line]; \
            if (r->hl) memcpy(r->hl, (E)->saved_hl, (u32)r->rsize); \
        } \
        free((E)->saved_hl); (E)->saved_hl = NULL; \
    } \
    (E)->saved_hl_line = -1; \
} while (0)

/* Одношаговый поиск (общий для режима Ctrl+F и ed_find()).
 * dir: +1/-1. Возвращает 1, если найдено. */
static int ed_search_once(ed_t *E, int dir)
{
    if (E->qlen == 0) return 0;

    int current = E->last_match;
    int found = -1;
    int match_off = 0;

    for (int i = 0; i < E->numrows; i++) {
        current += dir;
        if (current == -1) current = E->numrows - 1;
        else if (current == E->numrows) current = 0;
        char *m = strstr(E->row[current].render ? E->row[current].render
                                                : "", E->query);
        if (m) {
            found = current;
            match_off = (int)(m - E->row[current].render);
            break;
        }
    }
    if (found < 0) return 0;

    ED_FIND_RESTORE_HL(E);

    ed_row_t *row = &E->row[found];
    E->last_match = found;
    if (row->hl && row->rsize > 0) {
        E->saved_hl = (unsigned char *)malloc((u32)row->rsize);
        if (E->saved_hl) {
            E->saved_hl_line = found;
            memcpy(E->saved_hl, row->hl, (u32)row->rsize);
            int len = E->qlen;
            if (match_off + len > row->rsize) len = row->rsize - match_off;
            if (len > 0) memset(row->hl + match_off, HL_MATCH, (u32)len);
        }
    }

    /* курсор на совпадение */
    E->cy = found - E->rowoff;
    E->cx = match_off;
    E->coloff = 0;
    ed_fix_scroll(E);
    return 1;
}

static void ed_find_reset_query(ed_t *E)
{
    E->query[0] = 0;
    E->qlen = 0;
    E->last_match = -1;
}

/* Клавиши режима поиска. 1 = событие съедено. */
static int ed_find_key(ed_t *E, const key_event_t *ev)
{
    int c = ev->ch;

    if (ev->ch == 0x1B || ev->code == 0x01) {            /* Esc — отмена */
        ED_FIND_RESTORE_HL(E);
        E->cx = E->saved_cx; E->cy = E->saved_cy;
        E->rowoff = E->saved_rowoff; E->coloff = E->saved_coloff;
        E->find_mode = 0;
        return 1;
    }
    if (ev->code == 0x1C || c == '\n' || c == '\r') {    /* Enter — выход */
        E->find_mode = 0;
        return 1;
    }
    if (c == '\b' || ev->code == 0x0E) {                 /* Backspace */
        if (E->qlen > 0) E->query[--E->qlen] = 0;
        E->last_match = -1;
        ed_search_once(E, 1);
        return 1;
    }
    if (ev->code == KBD_RIGHT || ev->code == KBD_DOWN ||
        ev->code == 0x51) {
        ed_search_once(E, 1);
        return 1;
    }
    if (ev->code == KBD_LEFT || ev->code == KBD_UP || ev->code == 0x49) {
        ed_search_once(E, -1);
        return 1;
    }
    if (c >= 32 && c < 127 && E->qlen < ED_QUERY_MAX) {
        E->query[E->qlen++] = (char)c;
        E->query[E->qlen] = 0;
        E->last_match = -1;
        ed_search_once(E, 1);
        return 1;
    }
    return 1;   /* остальные клавиши в режиме поиска игнорируются */
}

/* ==================== публичный API: текст ==================== */

ed_t *ed_create(int syntax)
{
    ed_t *E = (ed_t *)malloc(sizeof(ed_t));
    if (!E) return NULL;
    memset(E, 0, sizeof(*E));
    E->syntax = syntax ? 1 : 0;
    E->last_match = -1;
    E->saved_hl_line = -1;
    E->area_w = 80 * CHAR_W;
    E->area_h = 24 * CHAR_H;
    /* одна пустая строка, чтобы можно было сразу печатать */
    ed_insert_row(E, 0, "", 0);
    E->dirty = 0;
    return E;
}

void ed_free(ed_t *E)
{
    if (!E) return;
    for (int j = 0; j < E->numrows; j++) ed_free_row(&E->row[j]);
    if (E->row) free(E->row);
    if (E->saved_hl) free(E->saved_hl);
    free(E);
}

void ed_set_text(ed_t *E, const char *text, int len)
{
    if (!E) return;
    for (int j = 0; j < E->numrows; j++) ed_free_row(&E->row[j]);
    E->numrows = 0;
    E->cx = E->cy = E->rowoff = E->coloff = 0;
    E->dirty = 0;
    ed_find_reset_query(E);
    E->find_mode = 0;
    ED_FIND_RESTORE_HL(E);

    if (len > 0 && text) {
        int start = 0;
        for (int i = 0; i <= len; i++) {
            if (i == len || text[i] == '\n') {
                /* '\r' в конце строки убираем (CRLF-файлы) */
                int l = i - start;
                if (l > 0 && text[start + l - 1] == '\r') l--;
                if (!ed_insert_row(E, E->numrows, text + start, l)) break;
                start = i + 1;
            }
        }
    }
    if (E->numrows == 0) ed_insert_row(E, 0, "", 0);
    E->dirty = 0;
}

/* ED-KILO: editorRowsToString() */
int ed_get_text(ed_t *E, char *out, int out_max)
{
    if (!E) return -1;
    int totlen = 0;
    for (int j = 0; j < E->numrows; j++) totlen += E->row[j].size + 1;
    /* строки дают totlen байт с завершающей '\n' на конце; текст без неё
     * занимает totlen-1 байт + '\0' = totlen — ровно столько нужно out_max */
    if (totlen > out_max) return -1;

    char *p = out;
    for (int j = 0; j < E->numrows; j++) {
        memcpy(p, E->row[j].chars, (u32)E->row[j].size);
        p += E->row[j].size;
        *p++ = '\n';
    }
    if (totlen > 0) p--;      /* последнюю '\n' заменяем терминатором */
    *p = 0;
    return totlen > 0 ? totlen - 1 : 0;
}

char *ed_get_text_alloc(ed_t *E, int *out_len)
{
    if (!E) return NULL;
    int totlen = 0;
    for (int j = 0; j < E->numrows; j++) totlen += E->row[j].size + 1;

    char *buf = (char *)malloc((u32)totlen + 1);
    if (!buf) return NULL;
    char *p = buf;
    for (int j = 0; j < E->numrows; j++) {
        memcpy(p, E->row[j].chars, (u32)E->row[j].size);
        p += E->row[j].size;
        *p++ = '\n';
    }
    if (totlen > 0) p--;
    *p = 0;
    if (out_len) *out_len = totlen > 0 ? totlen - 1 : 0;
    return buf;
}

int ed_len_bytes(ed_t *E)
{
    if (!E) return 0;
    int tot = 0;
    for (int j = 0; j < E->numrows; j++) tot += E->row[j].size + 1;
    return tot > 0 ? tot - 1 : 0;   /* завершающая '\n' не входит */
}
int ed_numrows(ed_t *E)   { return E ? E->numrows : 0; }
int ed_dirty(ed_t *E)     { return E ? E->dirty : 0; }
void ed_mark_clean(ed_t *E) { if (E) E->dirty = 0; }

void ed_cursor_pos(ed_t *E, int *line1, int *col1, int *numrows)
{
    if (!E) return;
    if (line1) *line1 = E->rowoff + E->cy + 1;
    if (col1) {
        /* FIX UTF-8: колонка в СИМВОЛАХ (прежде — байты: на кириллице
         * номер колонки был вдвое больше фактического) */
        int filerow = E->rowoff + E->cy;
        int col_bytes = E->coloff + E->cx;
        if (filerow >= 0 && filerow < E->numrows) {
            ed_row_t *row = &E->row[filerow];
            if (col_bytes > row->size) col_bytes = row->size;
            if (col_bytes < 0) col_bytes = 0;
            *col1 = utf8_count_chars(row->chars, col_bytes) + 1;
        } else {
            *col1 = col_bytes + 1;
        }
    }
    if (numrows) *numrows = E->numrows;
}

int ed_find(ed_t *E, const char *query, int dir)
{
    if (!E || !query || !query[0]) return 0;
    ED_FIND_RESTORE_HL(E);
    snprintf(E->query, sizeof(E->query), "%s", query);
    E->qlen = (int)strlen(E->query);
    E->last_match = E->rowoff + E->cy;   /* искать от курсора */
    int ok = ed_search_once(E, dir);
    if (!ok) E->last_match = -1;
    return ok;
}

void ed_find_clear(ed_t *E)
{
    if (!E) return;
    ED_FIND_RESTORE_HL(E);
    ed_find_reset_query(E);
    E->find_mode = 0;
}

int ed_in_find(ed_t *E)
{
    return E ? E->find_mode : 0;
}

/* ==================== события ==================== */

void ed_key(ed_t *E, const key_event_t *ev, int area_w, int area_h)
{
    if (!E || !ev || (ev->flags & KF_RELEASED)) return;

    E->area_w = area_w;
    E->area_h = area_h;

    if (E->find_mode) {
        ed_find_key(E, ev);
        ed_fix_scroll(E);
        return;
    }

    /* Ctrl+F — поиск (как в kilo Ctrl-F) */
    if ((ev->flags & KF_CTRL) &&
        (ev->ch == 'f' || ev->ch == 'F' || ev->code == 0x21)) {
        E->find_mode = 1;
        ed_find_reset_query(E);
        E->saved_cx = E->cx; E->saved_cy = E->cy;
        E->saved_rowoff = E->rowoff; E->saved_coloff = E->coloff;
        return;
    }

    if (ev->code == 0x47) {                 /* Home */
        E->cx = 0;
        E->coloff = 0;
    } else if (ev->code == 0x4F) {          /* End */
        int filerow = E->rowoff + E->cy;
        if (filerow >= 0 && filerow < E->numrows)
            E->cx = E->row[filerow].size - E->coloff;
        if (E->cx < 0) E->cx = 0;
    } else if (ev->code == 0x49) {          /* PgUp: ровно страница вверх */
        int vis_r = ed_vis_rows(area_h);
        int filerow = E->rowoff + E->cy - vis_r;
        if (filerow < 0) filerow = 0;
        E->cy = filerow - E->rowoff;
        if (E->cy < 0) { E->rowoff = filerow; E->cy = 0; }
    } else if (ev->code == 0x51) {          /* PgDn: ровно страница вниз */
        int vis_r = ed_vis_rows(area_h);
        int maxf = E->numrows > 0 ? E->numrows - 1 : 0;
        int filerow = E->rowoff + E->cy + vis_r;
        if (filerow > maxf) filerow = maxf;
        E->cy = filerow - E->rowoff;
        if (E->cy > vis_r - 1) { E->rowoff = filerow - (vis_r - 1); E->cy = vis_r - 1; }
    } else if (ev->code == 0x53) {          /* Delete (вперёд) */
        ed_forward_delete(E);
    } else if (ev->code == 0x0E) {          /* Backspace (скан) */
        ed_backspace(E);
    } else if (ev->code == KBD_UP) {
        ed_move_cursor(E, KBD_UP);
    } else if (ev->code == KBD_DOWN) {
        ed_move_cursor(E, KBD_DOWN);
    } else if (ev->code == KBD_LEFT) {
        ed_move_cursor(E, KBD_LEFT);
    } else if (ev->code == KBD_RIGHT) {
        ed_move_cursor(E, KBD_RIGHT);
    } else if (ev->ch == '\b') {
        ed_backspace(E);
    } else if (ev->ch == '\n' || ev->ch == '\r' || ev->code == 0x1C) {
        ed_insert_newline(E);
    } else if (ev->ch == '\t') {
        ed_insert_char(E, '\t');
    } else if (ev->ch >= 32 && ev->ch < 127) {
        ed_insert_char(E, ev->ch);
    }
    ed_fix_scroll(E);
}

int ed_mouse(ed_t *E, int mx, int my, u8 buttons, u8 changed,
             int area_w, int area_h)
{
    if (!E) return 0;
    E->area_w = area_w;
    E->area_h = area_h;

    if (mx < 0 || my < 0) {
        /* Сессия 20 (неявный захват мыши): события за пределами окна
         * приходят с отрицательными координатами. Отпускание кнопки
         * (и сам drag) обязано дойти до полос — иначе drag «залипал»
         * бы до первого события внутри окна. Остальное игнорируем. */
        int cmxn = mx + E->ox, cmyn = my + E->oy;
        if (E->sb.dragging)
            wm_scrollbar_mouse(&E->sb, cmxn, cmyn, buttons, changed);
        if (E->sbh.dragging)
            wm_scrollbar_hmouse(&E->sbh, cmxn, cmyn, buttons, changed);
        return 0;
    }

    /* КООРДИНАТЫ (см. шапку файла): полосы запомнены в системе
     * ОТРИСОВКИ (канвас), мышь приходит ОТНОСИТЕЛЬНО ОБЛАСТИ.
     * Переводим мышь в систему отрисовки один раз. До первой
     * отрисовки ox=oy=0 и геометрия полос нулевая —
     * wm_scrollbar_mouse безопасно вернёт -1. */
    int cmx = mx + E->ox;
    int cmy = my + E->oy;

    int hbar_top = ed_hbar_top(E, area_h);   /* верх h-полосы (область) */
    int hbar_bot = hbar_top + SB_W;

    /* вертикальная полоса (не достаёт до h-полосы; угол — ниже).
     * При начатом drag'е полосу не отпускаем, даже если курсор ушёл
     * из колонки — иначе drag обрывался бы от малейшего сдвига вбок,
     * а отпускание кнопки вне полосы навсегда залипало бы в dragging */
    if ((mx >= area_w - SB_W && my < hbar_top) || E->sb.dragging) {
        int np = wm_scrollbar_mouse(&E->sb, cmx, cmy, buttons, changed);
        if (np >= 0) {
            int filerow = E->rowoff + E->cy;
            E->rowoff = np;
            int vis_r = ed_vis_rows(area_h);
            E->cy = filerow - E->rowoff;
            if (E->cy < 0) E->cy = 0;
            if (E->cy > vis_r - 1) E->cy = vis_r - 1;
            ed_fix_scroll(E);
        }
        return 1;   /* вся колонка — зона полосы */
    }

    /* горизонтальная полоса (нижний ряд; правый угол — мёртвая зона,
     * клики туда съедаются, чтобы не ставить курсор под полосами) */
    if ((my >= hbar_top && my < hbar_bot) || E->sbh.dragging) {
        if (mx < area_w - SB_W || E->sbh.dragging) {
            int np = wm_scrollbar_hmouse(&E->sbh, cmx, cmy, buttons, changed);
            if (np >= 0)
                ed_hscroll_to(E, np);
        }
        return 1;
    }

    /* клик/драг по тексту — курсор (координаты — той же системы
     * отрисовки: cmy ложится на нарисованные строки при любом oy).
     * FIX UTF-8 (и колонок): прежде смещение считалось в байтах
     * ((mx - ...)/8 + coloff) — на кириллице курсор прыгал в середину
     * буквы. Теперь: пиксели → бюджет СИМВОЛОВ → байтовое смещение
     * проходом по строке (табы — до следующей позиции табуляции). */
    if (buttons & MSB_LEFT) {
        if (E->find_mode) { E->find_mode = 0; }   /* клик выходит из поиска */

        int filerow = E->rowoff + cmy / CHAR_H;
        if (filerow > E->numrows - 1) filerow = E->numrows - 1;
        if (filerow < 0) filerow = 0;
        ed_row_t *row = &E->row[filerow];

        int budget = (cmx - PAD_L - ed_linenr_px(E)) / CHAR_W;
        if (budget < 0) budget = 0;

        int j = E->coloff;
        int off = E->coloff;
        int rx = 0;
        while (j < row->size && rx < budget) {
            if (row->chars[j] == '\t') {
                int adv = ED_TAB_STOP - (rx % ED_TAB_STOP);
                if (rx + adv > budget) break;  /* клик внутри таба — перед ним */
                rx += adv;
                j++;
            } else {
                j += utf8_seq_len((unsigned char)row->chars[j]);
                rx++;
            }
            off = j;
        }
        if (off > row->size) off = row->size;

        E->cy = filerow - E->rowoff;
        if (E->cy < 0) E->cy = 0;
        E->cx = off - E->coloff;
        if (E->cx < 0) E->cx = 0;   /* off >= coloff по построению */
        ed_fix_scroll(E);
        return 1;
    }
    return 0;
}

/* ==================== отрисовка ==================== */

static u32 ed_hl_color(int hl)
{
    switch (hl) {
    case HL_COMMENT:
    case HL_MLCOMMENT: return 0;                 /* из темы (dim) */
    case HL_KEYWORD1:  return HL_COL_KEYWORD1;
    case HL_KEYWORD2:  return HL_COL_KEYWORD2;
    case HL_STRING:    return HL_COL_STRING;
    case HL_NUMBER:    return HL_COL_NUMBER;
    case HL_MATCH:     return HL_COL_MATCH;
    default:           return 0;                 /* из темы (text) */
    }
}

/* отрисовать видимый кусок строки с раскраской по классам.
 * Не рвёт UTF-8:
 *  - видимая ширина — utf8_take_bytes (cols СИМВОЛОВ, не байт);
 *  - продолжающие байты (0x80..0xBF) клеятся к предыдущему классу;
 *  - x-смещение куска — по СИМВОЛАМ (прежде считались байты: текст
 *    с кириллицей рисовался с наложением/дырами);
 *  - длинный кусок режется по границе символа (tmp[256]). */
static void ed_draw_row_text(int tx, int ty, ed_row_t *row,
                             int coloff, int cols, u32 col_text)
{
    if (!row->render || row->rsize <= coloff) return;

    char tmp[256];
    int run_start = coloff;
    int run_hl = row->hl ? row->hl[coloff] : HL_NORMAL;
    int avail = row->rsize - coloff;
    int total = utf8_take_bytes(row->render + coloff, avail, cols);
    int end = coloff + total;

    int i = coloff + 1;
    for (;;) {
        int flush = 0;
        int cur_hl = run_hl;
        if (i < end) {
            cur_hl = row->hl ? row->hl[i] : HL_NORMAL;
            /* продолжающий байт UTF-8 — тот же класс, не рвём символ */
            if (((unsigned char)row->render[i] & 0xC0) == 0x80)
                cur_hl = run_hl;
            if (cur_hl != run_hl) flush = 1;
        } else {
            flush = 1;
        }
        if (flush) {
            int pend = i - run_start;
            /* x куска — число СИМВОЛОВ от начала видимой области */
            int xoff = utf8_count_chars(row->render + coloff,
                                        run_start - coloff) * CHAR_W;
            while (pend > 0) {
                int take = utf8_clamp_bytes(row->render + run_start, pend,
                                            (int)sizeof(tmp) - 1);
                if (take <= 0) break;
                memcpy(tmp, row->render + run_start, (u32)take);
                tmp[take] = 0;
                u32 col = ed_hl_color(run_hl);
                if (run_hl == HL_NONPRINT) col = col_text;
                fb_text(tx + xoff, ty, tmp, col ? col : col_text, -1);
                xoff += utf8_count_chars(tmp, -1) * CHAR_W;
                run_start += take;
                pend -= take;
            }
            run_start = i;
            run_hl = cur_hl;
            if (i >= end) break;
        }
        i++;
    }
}

void ed_draw(ed_t *E, int x, int y, int w, int h)
{
    if (!E) return;
    E->area_w = w;
    E->area_h = h;
    E->ox = x;                     /* запоминаем угол: ed_mouse переводит
                                    * мышь в эту же систему (FIX координат
                                    * полос — см. шапку файла) */
    E->oy = y;

    int vis_r = ed_vis_rows(h);
    int vis_c = ed_vis_cols(E, w);
    int ln_px = ed_linenr_px(E);
    int text_x = x + PAD_L + ln_px;
    int hbar_top = ed_hbar_top(E, h);   /* верх h-полосы (коорд. области) */

    int max_scroll = E->numrows - vis_r;
    if (max_scroll < 0) max_scroll = 0;
    if (E->rowoff > max_scroll) E->rowoff = max_scroll;
    if (E->rowoff < 0) E->rowoff = 0;

    fb_fill_rect(x, y, w, h, wm_theme_win_bg());

    int cur_filerow = E->rowoff + E->cy;

    /* подложка строки с курсором + номера строк */
    for (int r = 0; r < vis_r; r++) {
        int fy = y + r * CHAR_H;
        int filerow = E->rowoff + r;
        if (filerow >= E->numrows) break;
        if (filerow == cur_filerow)
            fb_fill_rect(x, fy, w, CHAR_H, wm_theme_win_bg_alt());
        if (ln_px) {
            /* %*d может не поддерживаться системным snprintf — паддинг вручную */
            char ln[16];
            int width = ln_px / CHAR_W - 1;
            int val = filerow + 1, nd = 0;
            do { nd++; val /= 10; } while (val > 0);
            int pad = width - nd;
            if (pad < 0) pad = 0;
            if (pad > 6) pad = 6;
            for (int k = 0; k < pad; k++) ln[k] = ' ';
            snprintf(ln + pad, (u32)(sizeof(ln) - (u32)pad), "%d",
                     (filerow + 1) & 0xFFFFF);
            fb_text(x + 2, fy + 1, ln, wm_theme_text_dim(), -1);
        }
    }

    /* текст */
    for (int r = 0; r < vis_r; r++) {
        int filerow = E->rowoff + r;
        if (filerow >= E->numrows) break;
        ed_draw_row_text(text_x, y + r * CHAR_H + 1, &E->row[filerow],
                         E->coloff, vis_c, wm_theme_text());
    }

    /* курсор — ПОСТОЯННАЯ РАМКА (запрос: мигающий блок часто не
     * перерисовывался и его не было видно: тики wm_halfsec получают
     * только окна с on_tick, редакторские их не ставят; рамка же
     * рисуется при КАЖДОЙ перерисовке). Колонка — в СИМВОЛАХ
     * (FIX UTF-8: прежде байты считались колонками, а rxv вычитал
     * coloff второй раз — при горизонтальной прокрутке курсор
     * исчезал). Рамка, а не блок: символ под курсором остаётся виден. */
    if (cur_filerow >= 0 && cur_filerow < E->numrows) {
        ed_row_t *row = &E->row[cur_filerow];
        int rx = ed_cursor_rx(row, E->coloff, E->cx);
        if (rx >= 0 && rx < vis_c)
            fb_rect(text_x + rx * CHAR_W,
                    y + E->cy * CHAR_H + 1,
                    CHAR_W, CHAR_H - 2, wm_theme_accent());
    }

    /* полосы прокрутки (общесистемный виджет, цвет из темы):
     * вертикальная — правый край ВЫШЕ h-полосы, горизонтальная —
 * нижний ряд ЛЕВЕЕ v-полосы; правый нижний угол 8x8 — мёртвая зона */
    wm_scrollbar_draw(&E->sb, x + w - SB_W + 1, y + 1, SB_W - 2,
                      hbar_top - 2,
                      E->rowoff, max_scroll, vis_r);

    {
        int hmax = ed_hmax(E, w);
        int cpos = E->coloff;
        if (cpos > hmax) cpos = hmax;
        if (cpos < 0) cpos = 0;
        wm_scrollbar_hdraw(&E->sbh, x + 1, y + hbar_top + 1,
                           w - SB_W - 2, SB_W - 2,
                           cpos, hmax, vis_c);
    }

    /* строка поиска внутри области */
    if (E->find_mode) {
        int py = y + h - CHAR_H;
        fb_fill_rect(x, py, w, CHAR_H, wm_theme_win_bg_alt());
        char pl[ED_QUERY_MAX + 96];
        snprintf(pl, sizeof(pl), "Поиск: %s (Enter/стрелки/Esc)",
                 E->query);
        fb_text(x + PAD_L, py + 1, pl, wm_theme_text_info(), -1);
    }
}
