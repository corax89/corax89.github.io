/* kernel.c — точка входа N2600-OS.
 *
 * Multiboot-заголовок (AOUT_KLUDGE + VIDEO_MODE) лежит в секции .text.mb —
 * в самом начале образа, поэтому GRUB находит его в первых 8 КиБ плоского
 * бинарника, собираемого MinGW. GRUB выставляет VESA-режим по полям
 * заголовка (1280x600x32 + запасные), включает защищённый режим и передаёт
 * управление на kstart.
 */
#include "types.h"
#include "io.h"
#include "boot.h"
#include "gdt.h"
#include "idt.h"
#include "mem.h"
#include "timer.h"
#include "kbd.h"
#include "mouse.h"
#include "fb.h"
#include "wm.h"
#include "apps.h"
#include "string.h"
#include "kernel.h"
#include "ata.h"
#include "ahci.h"
#include "disk.h"
#include "fat32.h"
#include "ntfs.h"
#include "iso9660.h"
#include "ramfs.h"
#include "imgres.h"  /* сессия 55: LOGO.PNG/IMG.JS в RAM disk */
#include "task.h"
#include "usb.h"
#include "usb_ehci.h"   /* usb_ehci_hotplug_service (hot-plug wifi-задачи) */
#include "ath9k_wifi.h"
#include "e1000.h"
#include "ne2000.h"
#include "atl1c.h"
#include "virtio_net.h"
#include "net.h"
#include "net_httpd.h"
#include "sound.h"
#include "font.h"
#include "sync.h"
#include "pci.h"
#include <cpuid.h>   /* __get_cpuid: проверка поддержки MTRR */

/* Символы linker-скрипта: в C пишутся без ведущего подчёркивания
 * (COFF MinGW добавит его автоматически, совпадая с именами в скрипте). */
extern unsigned char load_start[];
extern unsigned char load_end[];
extern unsigned char bss_end[];

/* --------------------- multiboot-заголовок --------------------- */

void kstart(void);

#define MB_FLAGS (MB_FLAG_ALIGN | MB_FLAG_MEMINFO | MB_FLAG_VIDEO_MODE | MB_FLAG_AOUT_KLUDGE)

/* При флаге VIDEO_MODE GRUB2 читает из заголовка ещё 4 поля (байты 32..47):
 * mode_type (0 = фреймбуфер), width, height, depth.
 * Устанавливаем width=height=depth=0 → GRUB выберет ЛЮБОЙ доступный
 * 32-битный VESA-режим из gfxpayload (см. grub.cfg). Это надёжнее, чем
 * хардкодить 1280x600 — на реальном железе такого режима может не быть. */
__attribute__((section(".text.mb"), used, aligned(4)))
static const u32 mb_header[12] = {
    MB_MAGIC,
    MB_FLAGS,
    (u32)(0u - (MB_MAGIC + MB_FLAGS)),
    (u32)(unsigned long)load_start,   /* header_addr */
    (u32)(unsigned long)load_start,   /* load_addr   */
    (u32)(unsigned long)load_end,     /* load_end_addr */
    (u32)(unsigned long)bss_end,      /* bss_end_addr */
    (u32)(unsigned long)kstart,       /* entry_addr  */
    0,                                /* mode_type: 0 = линейный фреймбуфер */
    0,                                /* width=0: GRUB выберет из gfxpayload */
    0,                                /* height=0 */
    0                                 /* depth=0 */
};

/* ------------------------- входная точка ------------------------- */

/* Единственная asm-вставка потока управления: настраиваем стек и зовём C.
 * naked обязателен — нельзя допустить пролог с обращением к стеку до его настройки. */
__attribute__((naked, section(".text.ks"), used, noinline))
void kstart(void)
{
    __asm__ __volatile__(
        "movl $_stack_top, %esp\n"
        "pushl %ebx\n"      /* multiboot info */
        "pushl %eax\n"      /* magic */
        "call _kmain\n"
        "1:\n"
        "hlt\n"
        "jmp 1b");
}

/* ========================================================================
 * Отладка: COM1 (serial) + экран (после fb_init)
 * ======================================================================== */

/* ---------- COM1 ---------- */
#define COM1 0x3F8

static void serial_init(void)
{
    outb(COM1 + 1, 0x00);   /* отключить прерывания */
    outb(COM1 + 3, 0x80);   /* DLAB=1 */
    outb(COM1 + 0, 0x03);   /* делитель = 3 -> 38400 бод */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);   /* 8N1 */
    outb(COM1 + 2, 0xC7);   /* FIFO 14 байт, очистить */
    outb(COM1 + 4, 0x0B);   /* RTS/DSR */
}

void serial_putc(char c)
{
    while (!(inb(COM1 + 5) & 0x20)) { /* ждём THR empty */ }
    outb(COM1, (u8)c);
}

void serial_puts(const char *s)
{
    /* Сессия 13: АТОМАРНАЯ печать строки. Раньше несколько потоков
     * печатали ПОСИМВОЛЬНО вперемешку (boot-лог и [term]-строки резались
     * друг по другу: "em]" вместо "[mem]") — тесты не находили свои
     * маркеры. Гасим прерывания на время строки. */
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    while (*s) {
        if (*s == '\n') serial_putc('\r');
        serial_putc(*s++);
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* ---------- Экранный debug ---------- */

static int  dbg_y = 0;              /* текущая строка вывода на экране */
static u32  dbg_color_ok  = 0;      /* кэшируем цвета после fb_init */
static u32  dbg_color_err = 0;

/* ---------- Журнал загрузки (klog) ----------
 * Кольцевое хранилище строк: переполнение выбрасывает САМЫЕ СТАРЫЕ
 * строки (memmove). Читается командой dmesg в терминале — это и есть
 * «процесс загрузки», который пролетает на экране слишком быстро. */
#define KLOG_SIZE 16384  /* сессия 11: фоновые задачи (sata/netmon) добавили строки — ранние вехи выталкивались из 8КБ-кольца */
static char  klog_buf[KLOG_SIZE];
static int   klog_len = 0;
static volatile int klog_lock = 0;

void klog_puts(const char *s)
{
    if (!s) return;
    /* klog зовётся и из dbg (однопоточно, до sti()) и из потоков после.
     * s_lock: значение = владелец+1, мёртвый/зависший владелец
     * восстанавливается ждущим — раньше busy-wait под cli намертво
     * фризил систему, если держателя убивали посреди записи. */
    s_lock(&klog_lock);

    u32 sl = (u32)strlen(s);
    if (sl > 200) sl = 200;               /* защита от ошибочных вызовов */
    /* освободить место: выкидываем старые строки целиком */
    while (klog_len + (int)sl + 1 >= KLOG_SIZE) {
        char *nl = (char *)memchr(klog_buf, '\n', (u32)klog_len);
        if (!nl) { klog_len = 0; break; }  /* ни одной полной строки — сброс */
        int drop = (int)(nl - klog_buf) + 1;
        memmove(klog_buf, klog_buf + drop, (u32)(klog_len - drop));
        klog_len -= drop;
    }
    memcpy(klog_buf + klog_len, s, sl);
    klog_len += (int)sl;
    klog_buf[klog_len++] = '\n';
    klog_buf[klog_len] = 0;

    s_unlock(&klog_lock);
}

const char *klog_get(void) { return klog_buf; }

int klog_line_count(void)
{
    int n = 0;
    for (int i = 0; i < klog_len; i++)
        if (klog_buf[i] == '\n') n++;
    return n;
}

/* Вывести строку одновременно в serial, на экран (если fb готов)
 * и в журнал загрузки (dmesg).
 * Сессия 11: dbg зовут и ФОНОВЫЕ задачи (sata/netmon) — сериализуем,
 * чтобы строки из разных потоков не калечили друг друга. */
static volatile int dbg_lock = 0;

/* Сессия 11: после старта WM экранный вывод dbg ОТКЛЮЧАЕМ — иначе
 * фоновые задачи (sata/netmon) рисовали бы свой лог ПОВЕРХ окон.
 * serial + klog (dmesg) продолжают работать. */
static volatile int g_screen_log_off = 0;

static void dbg(const char *s)
{
    s_lock(&dbg_lock);
    /* serial */
    serial_puts("[boot] ");
    serial_puts(s);
    serial_putc('\n');

    /* klog — чтобы dmesg показал процесс загрузки */
    klog_puts(s);

    /* screen: у нижнего края — ПРОКРУТКА ВВЕРХ, чтобы начальный лог
     * всегда был читаем (раньше строки уходили за экран снизу) */
    if (fb_ready() && !g_screen_log_off) {
        if (dbg_y + 16 > (int)fb_height()) {
            fb_scroll_up(16);
            dbg_y = (int)fb_height() - 16;
        }
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_ok, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
    s_unlock(&dbg_lock);
}

/* Вывести ошибку (красным) */
static void dbg_err(const char *s)
{
    s_lock(&dbg_lock);
    serial_puts("[ERR ] ");
    serial_puts(s);
    serial_putc('\n');

    klog_puts(s);

    if (fb_ready() && !g_screen_log_off) {
        if (dbg_y + 16 > (int)fb_height()) {
            fb_scroll_up(16);
            dbg_y = (int)fb_height() - 16;
        }
        fb_fill_rect(0, dbg_y, 900, 16, fb_rgb(0x00, 0x00, 0x00));
        fb_text(4, dbg_y, s, dbg_color_err, -1);
        fb_touch_all();
        fb_flush();
        dbg_y += 16;
    }
    s_unlock(&dbg_lock);
}

/* --------------------- ранний вывод (VGA text + LFB) --------------------- */

/* GRUB может выставить VESA-режим ДО прыжка в ядро. В этом случае
 * VGA-текстовый буфер 0xB8000 невидим — visible = linear framebuffer (LFB).
 * Поэтому ранний вывод идёт в ДВА места:
 *   1. VGA text buffer (0xB8000) — работает если GRUB оставил text mode
 *   2. LFB напрямую — работает если GRUB выставил VESA-режим
 * LFB-адрес берётся из multiboot info (framebuffer_addr).
 */

static volatile u16 * const vga_text = (volatile u16 *)0xB8000;
static int early_row = 0;
static int early_col = 0;

/* LFB info — заполняется в early_fb_init() из multiboot info */
static volatile u32 *early_lfb = NULL;
static u32 early_lfb_w = 0;
static u32 early_lfb_h = 0;
static u32 early_lfb_pitch = 0;
static u32 early_lfb_bpp = 0;

/* Инициализация раннего framebuffer-вывода из multiboot info.
 * Вызывается в самом начале kmain — ДО gdt_init. */
static void early_fb_init(const mb_info_t *mb)
{
    if (!mb) return;
    if (!(mb->flags & MBIF_FRAMEBUFFER)) return;
    if (mb->framebuffer_type != MB_FT_RGB) return;
    if (mb->framebuffer_bpp < 16) return;
    if (!mb->framebuffer_addr || !mb->framebuffer_width) return;

    early_lfb = (volatile u32 *)(u32)mb->framebuffer_addr;
    early_lfb_w = mb->framebuffer_width;
    early_lfb_h = mb->framebuffer_height;
    early_lfb_pitch = mb->framebuffer_pitch;
    early_lfb_bpp = mb->framebuffer_bpp;
}

/* Нарисовать один пиксель в LFB. Цвет = 0x00RRGGBB (32-bit). */
static void early_fb_pixel(int x, int y, u32 color)
{
    if (!early_lfb || x < 0 || y < 0 ||
        (u32)x >= early_lfb_w || (u32)y >= early_lfb_h) return;

    if (early_lfb_bpp == 32) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 4;
        dst[off]     = (u8)(color);        /* B */
        dst[off+1]   = (u8)(color >> 8);   /* G */
        dst[off+2]   = (u8)(color >> 16);  /* R */
    }
    else if (early_lfb_bpp == 24) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 3;
        dst[off]     = (u8)(color);
        dst[off+1]   = (u8)(color >> 8);
        dst[off+2]   = (u8)(color >> 16);
    }
    else if (early_lfb_bpp == 16) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 off = (u32)y * early_lfb_pitch + (u32)x * 2;
        u8 r = (u8)((color >> 16) & 0xFF);
        u8 g = (u8)((color >> 8) & 0xFF);
        u8 b = (u8)(color & 0xFF);
        u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
        dst[off] = (u8)(c & 0xFF);
        dst[off+1] = (u8)((c >> 8) & 0xFF);
    }
}

/* Нарисовать один символ 8x16 в LFB. */
static void early_fb_char(int x, int y, char c, u32 fg, u32 bg)
{
    if (!early_lfb) return;
    if (c < 0x20 || c > 0x7E) c = '?';
    const unsigned char *glyph = font8x16[(int)c - 0x20];
    for (int row = 0; row < 16; row++) {
        unsigned char bits = glyph[row];
        for (int col = 0; col < 8; col++) {
            u32 color = (bits & (0x80 >> col)) ? fg : bg;
            early_fb_pixel(x + col, y + row, color);
        }
    }
}

/* Очистить экран: заполнить LFB одним цветом + VGA text буфер. */
static void early_clear(void)
{
    /* VGA text buffer */
    for (int i = 0; i < 80 * 25; i++) vga_text[i] = 0x1F00u;
    early_row = 0;
    early_col = 0;

    /* LFB */
    if (early_lfb) {
        volatile u8 *dst = (volatile u8 *)early_lfb;
        u32 total = early_lfb_h * early_lfb_pitch;
        /* Цвет фона: ЧЁРНЫЙ (сессия 56: пользователь просил заливать
         * весь экран чёрным, т.к. лог пишется поверх мусора от GRUB;
         * тёмно-синий 0x000028 меняли на чистый чёрный) */
        u8 b = 0x00, g = 0x00, r = 0x00;
        if (early_lfb_bpp == 32) {
            for (u32 i = 0; i + 3 < total; i += 4) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r; dst[i+3] = 0;
            }
        }
        else if (early_lfb_bpp == 24) {
            for (u32 i = 0; i + 2 < total; i += 3) {
                dst[i] = b; dst[i+1] = g; dst[i+2] = r;
            }
        }
        else if (early_lfb_bpp == 16) {
            u16 c = (u16)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));
            for (u32 i = 0; i + 1 < total; i += 2) {
                dst[i] = (u8)(c & 0xFF);
                dst[i+1] = (u8)((c >> 8) & 0xFF);
            }
        }
    }
}

/* Вывести строку в ОБА буфера: VGA text + LFB. */
#define EARLY_FG 0x00FFFF00u   /* жёлтый текст */
#define EARLY_BG 0x00000000u   /* сессия 56: ЧЁРНЫЙ фон (был тёмно-синий) */

/* Прокрутить ранний LFB-экран на одну текстовую строку (16 px) вверх.
 * Работает при любом bpp (16/24/32): строка = early_lfb_pitch байт. */
static void early_fb_scroll(void)
{
    if (!early_lfb) return;
    u32 shift = 16u * early_lfb_pitch;
    u32 total = early_lfb_h * early_lfb_pitch;
    if (shift >= total) return;
    volatile u8 *base = (volatile u8 *)early_lfb;
    for (u32 i = 0; i < total - shift; i++) base[i] = base[i + shift];
    /* нижние 16 строк — цвет фона раннего вывода (сессия 56: чёрный) */
    int bppb = (int)(early_lfb_bpp / 8);
    if (bppb < 2) bppb = 2;
    for (u32 i = total - shift; i + 2 < total; i += (u32)bppb) {
        base[i]     = 0x00;   /* B */
        base[i + 1] = 0x00;   /* G */
        base[i + 2] = 0x00;   /* R */
        if (bppb == 4) base[i + 3] = 0;
    }
}

/* Последняя видимая текстовая строка: VGA — 25, LFB может быть меньше
 * (например 600px / 16 = 37 → ограничиваем 25, чтобы оба буфера
 * прокручивались синхронно одним счётчиком early_row). */
static int early_max_row(void)
{
    int mr = 25;
    if (early_lfb && early_lfb_h >= 48) {
        int lr = (int)(early_lfb_h / 16) - 1;
        if (lr < mr) mr = lr;
    }
    return mr;
}

/* Перевод строки ранней консоли: скролл обоих буферов при выходе
 * за последнюю строку (раньше LFB просто переставал рисовать —
 * «начальный лог уходит за низ экрана» в VESA-режиме GRUB). */
static void early_nl(void)
{
    early_col = 0;
    early_row++;
    int mr = early_max_row();
    if (early_row >= mr) {
        /* VGA text buffer */
        for (int i = 0; i < 80 * 24; i++)
            vga_text[i] = vga_text[i + 80];
        for (int i = 80 * 24; i < 80 * 25; i++)
            vga_text[i] = 0x1F00u;
        /* LFB */
        early_fb_scroll();
        early_row = mr - 1;
    }
}

static void early_puts(const char *s)
{
    while (*s) {
        char c = *s++;

        /* --- перевод строки: оба буфера + прокрутка --- */
        if (c == '\n') {
            early_nl();
            continue;
        }
        if (early_col >= 80) {
            early_nl();
        }

        vga_text[early_row * 80 + early_col] = (u16)(0x1F00u | (u8)c);

        /* --- LFB (если доступен) --- */
        if (early_lfb && early_lfb_w >= 8) {
            int x = early_col * 8;
            int y = early_row * 16;
            early_fb_char(x, y, c, EARLY_FG, EARLY_BG);
        }

        early_col++;
    }
}

static void early_putc(char c)
{
    char buf[2] = { c, 0 };
    early_puts(buf);
}

static void early_putu(u32 v)
{
    char buf[12];
    int i = 0;
    if (v == 0) { early_putc('0'); return; }
    while (v) { buf[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) early_putc(buf[i]);
}

static void early_puthex(u32 v)
{
    const char *h = "0123456789ABCDEF";
    early_puts("0x");
    for (int i = 28; i >= 0; i -= 4)
        early_putc(h[(v >> i) & 0xF]);
}

static void vga_fail(const char *msg)
{
    /* serial — первым делом */
    serial_puts("[FATAL] ");
    serial_puts(msg);
    serial_puts("\n");

    /* Ранний вывод в VGA + LFB */
    early_clear();
    early_puts("=== N2600-OS FATAL ===\n");
    early_puts(msg);
    early_puts("\n\nSystem halted.");

    /* QEMU debug port */
    for (const char *p = msg; *p; p++) outb(0xE9, (u8)*p);

    for (;;)
        hlt();
}

/* --------------------------- служебное --------------------------- */

static const mb_info_t *g_mbi = NULL;

const mb_info_t *mb_info(void) { return g_mbi; }

void sys_reboot(void)
{
    cli();
    for (u32 i = 0; i < 100000 && (inb(0x64) & 0x02); i++) {}
    outb(0x64, 0xFE);
    for (;;)
        hlt();
}

void sys_poweroff(void)
{
    cli();
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;)
        hlt();
}

/* ------------------------------ kmain ------------------------------ */

/* ================= Рамфс-сидинг: /boot/ramdisk из ISO =================
 * Каталог рядом с ядром в ISO (/boot/ramdisk) копируется в RAM disk при
 * загрузке — каждый файл, если хватает места (ramfs_free_space).
 * Не поместившиеся/слишком большие файлы пропускаются с сообщением.
 * Выполняется однопоточно до sti() — без блокировок.
 *
 * FIX [R1] (пустой ramfs без сообщений): раньше ВСЕ причины пропуска
 * (нет ISO, нет /boot, нет /boot/ramdisk) сообщались ТОЛЬКО в serial
 * или молча — на экране не было ничего, ramfs оставался пустым «без
 * объяснений». Теперь каждая причина видна на экране (dbg_err).
 * Дополнительно: если с ISO ничего не скопировано, пробуем каталог
 * \RAMDISK на FAT32-диске (НЖМД) — см. ramfs_seed_from_fat32. */
#define RAMSEED_MAX_FILE (256 * 1024)

static int rs_ci_eq(char a, char b)
{
    if (a >= 'A' && a <= 'Z') a += 32;
    if (b >= 'A' && b <= 'Z') b += 32;
    return a == b;
}

static int rs_ci_same(const char *a, const char *b)
{
    while (*a && *b) {
        if (!rs_ci_eq(*a, *b)) return 0;
        a++; b++;
    }
    return *a == 0 && *b == 0;
}

static void rs_lower(char *dst, const char *src, int dstsz)
{
    int i = 0;
    while (src[i] && i < dstsz - 1) {
        char c = src[i];
        if (c >= 'A' && c <= 'Z') c += 32;
        dst[i++] = c;
    }
    dst[i] = 0;
}

/* Общая часть: скопировать один файл объёмом sz в RAM disk. */
static int rs_put_file(const char *name, u8 *data, u32 sz)
{
    char lname[80];
    rs_lower(lname, name, sizeof(lname));
    if (ramfs_create(lname, sz)) {
        ramfs_write(lname, data, sz);
        return 1;
    }
    return 0;
}

static void ramfs_seed_from_iso(void)
{
    if (!iso9660_ready() || !ramfs_ready()) {
        dbg_err("ramdisk: ISO/CD не найден — сидинг из ISO пропущен");
        return;
    }

    /* / -> boot */
    iso9660_dirent_t root[32];
    int n = iso9660_list_root(root, 32);
    u32 boot_lba = 0, boot_size = 0;
    int have_boot = 0;
    for (int i = 0; i < n; i++) {
        if (root[i].is_dir && rs_ci_same(root[i].name, "boot")) {
            boot_lba = root[i].first_lba;
            boot_size = root[i].size;
            have_boot = 1;
            break;
        }
    }
    if (!have_boot) {
        dbg_err("ramdisk: /boot не найден в ISO — сидинг пропущен");
        return;
    }

    /* /boot -> ramdisk */
    iso9660_dirent_t bd[64];
    int m = iso9660_list_dir(boot_lba, boot_size, 0, bd, 64);
    u32 rd_lba = 0, rd_size = 0;
    int have_rd = 0;
    for (int i = 0; i < m; i++) {
        if (bd[i].is_dir && rs_ci_same(bd[i].name, "ramdisk")) {
            rd_lba = bd[i].first_lba;
            rd_size = bd[i].size;
            have_rd = 1;
            break;
        }
    }
    if (!have_rd) {
        dbg_err("ramdisk: /boot/ramdisk не найден в ISO — сидинг пропущен");
        return;
    }

    /* файлы /boot/ramdisk -> RAM disk (имена с расширением, в нижнем регистре) */
    iso9660_dirent_t files[64];
    int k = iso9660_list_dir(rd_lba, rd_size, 1, files, 64);
    int copied = 0, skipped = 0;
    u32 total = 0;

    for (int i = 0; i < k; i++) {
        if (files[i].is_dir) continue;
        u32 sz = files[i].size;
        if (sz == 0) continue;

        if (sz > RAMSEED_MAX_FILE) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "[ramseed] %s: %u KiB > лимита, пропущен",
                     files[i].name, (unsigned)(sz / 1024));
            dbg_err(buf);
            skipped++;
            continue;
        }
        if (sz > ramfs_free_space()) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "[ramseed] %s: не хватает места в RAM disk (нужно %u, свободно %u)",
                     files[i].name, (unsigned)sz, (unsigned)ramfs_free_space());
            dbg_err(buf);
            skipped++;
            continue;
        }

        u8 *tmp = (u8 *)malloc(sz);
        if (!tmp) { skipped++; continue; }
        u32 got = iso9660_read_file(files[i].first_lba, sz, tmp, sz);
        if (got == 0) {
            free(tmp);
            skipped++;
            continue;
        }

        if (rs_put_file(files[i].name, tmp, sz)) {
            copied++;
            total += sz;
            /* Процесс загрузки: каждый скопированный файл виден на
             * экране И в dmesg (раньше — только итоговая строка). */
            {
                char b[96];
                snprintf(b, sizeof(b), "[ramdisk] + %s (%u байт)",
                         files[i].name, (unsigned)sz);
                dbg(b);
            }
        } else {
            skipped++;
        }
        free(tmp);
    }

    {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "ramdisk: /boot/ramdisk -> RAM disk: %d файлов, %u байт%s",
                 copied, (unsigned)total,
                 skipped ? ", часть пропущена" : "");
        if (copied) dbg(buf);
        else dbg_err(buf);
    }
}

/* FIX [R2]: сидинг из каталога \\RAMDISK на FAT32 (НЖМД).
 * Если ОС загружена БЕЗ ATAPI CD (например, с USB-флешки, которую
 * ядро читать не умеет), файлы для RAM disk можно положить на
 * FAT32-раздел жёсткого диска в каталог RAMDISK — они скопируются
 * отсюда. Вызывается только если из ISO не скопировано ни одного файла. */
static void ramfs_seed_from_fat32(void)
{
    if (!fat32_ready() || !ramfs_ready()) {
        dbg_err("ramdisk: FAT32-диск тоже недоступен — RAM disk пуст");
        return;
    }

    /* корень FAT32 -> каталог RAMDISK */
    fat32_dirent_t root[32];
    int n = fat32_list(fat32_root_cluster(), root, 32);
    u32 rd_cluster = 0;
    int have_rd = 0;
    for (int i = 0; i < n; i++) {
        if ((root[i].attr & 0x10) && rs_ci_same(root[i].name, "ramdisk")) {
            rd_cluster = root[i].first_cluster;
            have_rd = 1;
            break;
        }
    }
    if (!have_rd) {
        dbg_err("ramdisk: каталог RAMDISK на FAT32 не найден — сидинг пропущен");
        return;
    }

    fat32_dirent_t files[32];
    int k = fat32_list(rd_cluster, files, 32);
    int copied = 0, skipped = 0;
    u32 total = 0;

    for (int i = 0; i < k; i++) {
        if (files[i].attr & 0x10) continue;
        u32 sz = files[i].size;
        if (sz == 0 || sz > RAMSEED_MAX_FILE) { skipped++; continue; }
        if (sz > ramfs_free_space()) { skipped++; continue; }

        u8 *tmp = (u8 *)malloc(sz);
        if (!tmp) { skipped++; continue; }
        u32 got = fat32_read_file(files[i].first_cluster, sz, tmp, sz);
        if (got == 0) {
            free(tmp);
            skipped++;
            continue;
        }
        if (rs_put_file(files[i].name, tmp, sz)) {
            copied++;
            total += sz;
            {
                char b[96];
                snprintf(b, sizeof(b), "[ramdisk] + %s (%u байт)",
                         files[i].name, (unsigned)sz);
                dbg(b);
            }
        } else {
            skipped++;
        }
        free(tmp);
    }

    {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "ramdisk: FAT32 \\RAMDISK -> RAM disk: %d файлов, %u байт%s",
                 copied, (unsigned)total,
                 skipped ? ", часть пропущена" : "");
        if (copied) dbg(buf);
        else dbg_err(buf);
    }
}

/* ---------- настройки сети (RAM disk SETTINGS.CFG) ----------
 * Формат: строки "ключ=значение":
 *   adapter=auto|<имя NIC>            — приоритет адаптера (сессия 11)
 *   netmode=dhcp|static               — режим IP (сессия 27)
 *   ip=/mask=/gw=/dns=a.b.c.d         — статические адреса (сессия 27)
 * Загружаются ДО net_init (режим приоритета); статические адреса
 * netmon применяет к активному адаптеру, когда появится линк. */
#define SETTINGS_FILE "SETTINGS.CFG"

/* g_netmon_dhcp_redo объявлен здесь (выше), т.к. netcfg_use_static
 * и net_request_dhcp управляют им, а net_settings_load читает
 * статические адреса до запуска netmon. */
static volatile int g_netmon_dhcp_redo = 1;   /* 1 = нужен цикл DHCP */

/* Публичное: перезапросить DHCP (кнопка в Настройках, команда в терминале) */
void net_request_dhcp(void)
{
    net_dhcp_reset();
    g_netmon_dhcp_redo = 1;
}

/* ---------- статическая настройка IP (сессия 27) ----------
 * Настройки → Сеть: режим DHCP или статический (IP/маска/шлюз/DNS).
 * Значения хранятся здесь; netmon применяет их к активному адаптеру
 * (шаг 2) вместо DHCP — и повторно после смены адаптера
 * (netmon_adapter_changed снова взводит g_netmon_dhcp_redo).
 * Сохраняются в SETTINGS.CFG приложением «Настройки». */
static volatile int g_netcfg_static = 0;   /* 0 = DHCP, 1 = статический */
static u32 g_stat_ip, g_stat_mask, g_stat_gw, g_stat_dns;

int  netcfg_static_mode(void) { return g_netcfg_static; }

void netcfg_static_get(u32 *ip, u32 *mask, u32 *gw, u32 *dns)
{
    if (ip)   *ip   = g_stat_ip;
    if (mask) *mask = g_stat_mask;
    if (gw)   *gw   = g_stat_gw;
    if (dns)  *dns  = g_stat_dns;
}

void netcfg_use_static(int on)
{
    if (on) {
        g_netcfg_static = 1;
        net_dhcp_reset();             /* прервать текущую транзакцию */
        g_netmon_dhcp_redo = 1;       /* netmon применит статику */
    } else if (g_netcfg_static) {
        g_netcfg_static = 0;
        net_request_dhcp();           /* возврат к DHCP */
    }
}

void netcfg_set_static(u32 ip, u32 mask, u32 gw, u32 dns)
{
    g_stat_ip = ip;
    g_stat_mask = mask ? mask : 0xFFFFFF00u;   /* пусто → /24 */
    g_stat_gw = gw;
    g_stat_dns = dns;
    netcfg_use_static(1);
}

static void net_settings_load(void)
{
    if (!ramfs_ready()) return;
    char buf[256];
    u32 n = ramfs_read(SETTINGS_FILE, buf, sizeof(buf) - 1);
    if (n == 0 || n >= sizeof(buf)) return;
    buf[n] = 0;
    char *p = buf;
    while (*p) {
        char *e = p;
        while (*e && *e != '\n' && *e != '\r') e++;
        char saved = *e;
        *e = 0;
        if (memcmp(p, "adapter=", 8) == 0) {
            const char *v = p + 8;
            int mode = 0;                     /* "auto" */
            if (strcmp(v, "auto") != 0) {
                int idx = net_adapter_find(v);
                if (idx >= 0) mode = idx + 1;
            }
            net_settings_set_adapter(mode);
            {
                char b[80];
                snprintf(b, sizeof(b), "net: настройки: адаптер %s",
                         mode == 0 ? "авто" : v);
                dbg(b);
            }
        } else if (memcmp(p, "netmode=", 8) == 0) {
            const char *v = p + 8;
            g_netcfg_static = (strcmp(v, "static") == 0) ? 1 : 0;
            dbg(g_netcfg_static ? "net: настройки: режим статический"
                                : "net: настройки: режим DHCP");
        } else if (memcmp(p, "ip=", 3) == 0) {
            u32 v;
            if (net_aton(p + 3, &v)) g_stat_ip = v;
        } else if (memcmp(p, "mask=", 5) == 0) {
            u32 v;
            if (net_aton(p + 5, &v)) g_stat_mask = v;
        } else if (memcmp(p, "gw=", 3) == 0) {
            u32 v;
            if (net_aton(p + 3, &v)) g_stat_gw = v;
        } else if (memcmp(p, "dns=", 4) == 0) {
            u32 v;
            if (net_aton(p + 4, &v)) g_stat_dns = v;
        }
        *e = saved;
        p = (*e) ? e + 1 : e;
    }
}

/* ---------- фоновая задача сети netmon (сессия 11) ----------
 * Замена одноразового netcfg: теперь задача ПОСТОЯННАЯ.
 *   1) ждёт адаптер с линком (WiFi-ассоциация занимает секунды);
 *   2) получает адреса по DHCP на активном адаптере;
 *   3) следит за линком: адаптер потерял линк → авто-переключение
 *      на лучший (например lan без кабеля → wifi) и повтор DHCP.
 * Раньше DHCP безусловно уходил в ПЕРВЫЙ найденный NIC: на X101CH
 * это atl1c без кабеля — «не могу проверить работу сети», хотя WiFi
 * ассоциирован. */
static void netmon_adapter_changed(void)
{
    /* активный адаптер сменился (авто-переключение или выбор в Настройках):
     * сбрасываем адреса — они принадлежали другому сегменту */
    net_set_ip(0);
    net_set_gateway(0);
    net_dhcp_reset();
    g_netmon_dhcp_redo = 1;
}

static void netmon_task_fn(void *arg)
{
    (void)arg;
    char ipbuf[16];
    u32 quiet_until = 0;                      /* анти-спам повторов DHCP */
    u32 backoff_ms = 5000;                    /* сессия 12: пауза между
                 * неудачами растёт 5→10→20→30 с (потолок), вместо
                 * безостановочного молотка DISCOVER каждые ~5 с.
                 * После успеха сбрасывается. */

    for (;;) {
        /* 1) ждать адаптер с линком (до 60 с, затем цикл повторится) */
        int waited = 0;
        while (!net_nic_present() ||
               !net_adapter_link(net_adapter_active())) {
            net_adapter_check();              /* автопереключение на лучший */
            if (g_netmon_dhcp_redo) break;    /* смена адаптера — наверх */
            task_msleep(20);
            if (++waited > 3000) break;
        }

        int link_up = net_nic_present() &&
                      net_adapter_link(net_adapter_active());

        /* 2) адреса на активном адаптере: статика (сессия 27) или DHCP */
        if (link_up && g_netmon_dhcp_redo) {
            g_netmon_dhcp_redo = 0;
            if (g_netcfg_static) {
                /* Статический режим: DHCP не запускаем, применяем
                 * сохранённые адреса (при пустой маске — /24). */
                net_set_ip(g_stat_ip);
                net_set_netmask(g_stat_mask ? g_stat_mask : 0xFFFFFF00u);
                net_set_gateway(g_stat_gw);
                if (g_stat_dns) net_dns_set_server(g_stat_dns);
                {
                    char b[96], ib[16];
                    net_ntoa(g_stat_ip, ib, sizeof(ib));
                    snprintf(b, sizeof(b), "netcfg: статический IP %s применён", ib);
                    dbg(b);
                }
                quiet_until = 0;
                backoff_ms = 5000;
                continue;                 /* к шагу 3 (монитор линка) */
            }
            dbg("netcfg: DHCP DISCOVER...");
            if (net_dhcp_acquire(8000)) {
                char b[96];
                net_ntoa(net_get_ip(), ipbuf, sizeof(ipbuf));
                snprintf(b, sizeof(b), "netcfg: DHCP ok, ip %s", ipbuf);
                dbg(b);
                net_ntoa(net_get_gateway(), ipbuf, sizeof(ipbuf));
                snprintf(b, sizeof(b), "netcfg: gw %s", ipbuf);
                dbg(b);
                u32 dns = net_dns_server();
                if (dns) {
                    net_ntoa(dns, ipbuf, sizeof(ipbuf));
                    snprintf(b, sizeof(b), "netcfg: dns %s", ipbuf);
                    dbg(b);
                }
                quiet_until = 0;
                backoff_ms = 5000;            /* успех — сброс backoff */
            } else {
                /* логируем неудачу не чаще раза в 30 с (анти-спам serial) */
                if (quiet_until == 0 ||
                    (i32)(timer_ticks() - quiet_until) >= 0) {
                    dbg("netcfg: DHCP не ответил — адреса по умолчанию");
                    quiet_until = timer_ticks() + 3000;
                }
                task_msleep(backoff_ms);      /* пауза растёт с каждой неудачей */
                if (backoff_ms < 30000) backoff_ms *= 2;
                g_netmon_dhcp_redo = 1;       /* повторим позже */
            }
        }

        /* 3) монитор линка: 100 мс шаг, авто-переключение */
        for (int i = 0; i < 10 && !g_netmon_dhcp_redo; i++) {
            task_msleep(100);
            net_adapter_check();
        }
    }
}

/* ---------- фоновая задача WiFi (СЕССИЯ 15) ----------
 * Запрос пользователя: «на нетбуке долгая загрузка из-за ожидания wifi,
 * нужно вынести его после загрузки ОС». Раньше wifi_init() шёл
 * В БЛОКИРУЮЩЕМ режиме до рабочего стола: PCI-скан + cold reset +
 * INI-записи + калибровки AGC/NF (AR9485) занимают СЕКУНДЫ — как
 * COMRESET у SATA (сессия 11). Теперь инициализация идёт фоновой
 * задачей ПОСЛЕ старта ОС: рабочий стол поднимается сразу, адаптер
 * «доезжает» позже, WiFi-приложение/Настройки показывают статус
 * (wifi_pending()). Сеть достраивается сама:
 *   - ethernet есть при загрузке — net_init как раньше, wifi позже
 *     добавляется в реестр (net_adapter_rescan), netmon переключается
 *     по линку (авто) или вручную;
 *   - wifi — ЕДИНСТВЕННЫЙ NIC (нет ethernet-порта) — задача сама
 *     поднимает net_init + netmon, когда адаптер готов. */
static volatile int g_wifi_state = 0;   /* 0=не начата, 1=идёт, 2=готово */
static volatile int g_netmon_started = 0;

int wifi_pending(void) { return g_wifi_state != 2; }

/* Поднятие сети после того, как wifi-адаптер стал готов (общий код
 * для пути «найден при загрузке» и пути «подключён по hot-plug»). */
static void wifi_net_up(void)
{
    if (net_adapter_count() == 0) {
        /* единственный NIC: сеть ещё не поднята — поднимаем
         * (то же, что kmain делает при ethernet при загрузке) */
        net_settings_load();
        net_init();
        net_adapter_set_change_cb(netmon_adapter_changed);
        net_set_ip(0x0A00020F);
        net_set_gateway(0x0A000202);
        net_set_netmask(0xFFFFFF00);
    } else {
        /* ethernet уже поднял сеть — добавляем wifi в реестр:
         * netmon переключится по линку (авто-режим) */
        net_adapter_rescan();
    }
    /* netmon ещё не запущен? (при загрузке не было НИ ОДНОГО
     * адаптера — теперь есть) */
    if (!g_netmon_started && net_adapter_count() > 0) {
        int tid = task_spawn_prio("netmon", netmon_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_netmon_started = 1;
            dbg("wifi: netmon запущен (сеть поднята фоном)");
        }
    }
}

/* ---------- СЕССИЯ 35: hot-plug EHCI — отдельная фоновая задача ----------
 * Раньше порты EHCI обслуживала ТОЛЬКО wifi-задача (раз в 500 мс, ПОСЛЕ
 * wifi_init). Если probe-фаза (два полных PCI-скана + bring-up) шла
 * долго, CSC донгла оставался необслуженным — «адаптер не находится»
 * при живом железе. Теперь главный цикл раз в 500 мс проверяет CSC/работу
 * портов (два чтения PORTSC — копейки) и спавнит короткую BG-задачу.
 * Одновременно работает не более одной скан-задачи; на время bring-up
 * RTL8192EU (probe из wifi-задачи) скан замолкает — оба трогают один
 * async-список EHCI. */
static volatile int g_usb_scan_running = 0;

/* СЕССИЯ 40: жива ли wifi-задача (для повторного спавна восстановления):
 * инкремент на входе, декремент перед выходом в готовом состоянии;
 * цикл ожидания адаптера держит счётчик навсегда (задача жива). */
static volatile int g_wifi_task_alive = 0;
static volatile int g_wifi_spawn_pending = 0;

static void wifi_task_fn(void *arg);   /* сессия 40: forward — спавн ниже по коду */

static void wifi_task_spawn(void)
{
    g_wifi_spawn_pending = 1;
    task_spawn_prio("wifi", wifi_task_fn, NULL, TASK_PRIO_UI);
}

static void usb_hotplug_task_fn(void *arg)
{
    (void)arg;
    dbg("usb: скан портов EHCI (hot-plug)...");
    for (int i = 0; i < 60; i++) {                 /* до ~18 с */
        if (rtl8192eu_attached() && !rtl8192eu_ready())
            break;   /* wifi-задача поднимает адаптер — не лезть в async-список */
        (void)usb_ehci_hotplug_service();
        if (rtl8192eu_ready()) break;
        if (!usb_ehci_work_pending()) break;       /* все порты пусты/обработаны */
        task_msleep(300);
    }
    if (rtl8192eu_attached())
        dbg("usb: WiFi-устройство зааттачено — wifi-задача выполнит bring-up");
    dbg("usb: скан портов EHCI завершён");
    g_usb_scan_running = 0;
}

static void wifi_task_fn(void *arg)
{
    (void)arg;
    g_wifi_task_alive++;
    g_wifi_spawn_pending = 0;
    /* СЕССИЯ 40: адаптер клин (перестал отвечать по USB) — сначала сброс
     * ПОРТА и переперечисление (прошивку грузить бесполезно: клинит
     * USB-движок чипа), полный bring-up выполнится после нового attach. */
    if (rtl8192eu_wedged())
        rtl8192eu_recover_device();
    g_wifi_state = 1;
    dbg("wifi: фоновая инициализация Atheros...");
    /* СЕССИЯ 37 — КОРЕНЬ «адаптер не находится» (наблюдалось с сессии 34):
     * kmain (приоритет UI) готов ВСЕГДА — hlt() не снимает готовность
     * задачи, поэтому планировщик на КАЖДОМ тике видит best=0 и выбирает
     * UI-уровень; BG-задачи получают ровно 1 тик из TASK_STARVE_TICKS=250
     * (анти-голодание), хотя CPU всё это время простаивает в hlt. На таких
     * крошках PCI-скан Atheros (~30 мс чистого CPU) растягивался на ~8 с
     * wall-времени, а bring-up RTL8192EU (busy-задержки rtl_udelay/mdelay +
     * ~250 control-трансферов прошивки 32 КБ) — на МИНУТЫ: GUI всё это
     * время честно показывал «поиск адаптера», хотя enumeration была ОК.
     * Probe+bring-up — разовая операция на секунды: поднимаем задачу до UI
     * (round-robin с kmain — оба получают каждый второй тик), в цикле
     * ожидания hot-plug возвращаем BG. */
    task_set_priority(task_current(), TASK_PRIO_UI);
    wifi_init();
    g_wifi_state = 2;

    if (wifi_present() && wifi_ready()) {
        dbg("wifi: адаптер готов (фон)");
        wifi_net_up();
        g_wifi_task_alive--;
        return;
    }

    /* Сессия 30 (hot-plug USB WiFi): в VMware адаптер часто подключают
     * ПОСЛЕ старта ВМ (VM -> Removable Devices -> Connect).
     * СЕССИЯ 35: перечисление портов EHCI живёт ОТДЕЛЬНО (usb_hotplug_task_fn,
     * спавнится главным циклом по CSC) — раньше оно было здесь, за
     * wifi_init, и CSC донгла не обслуживался, пока шли PCI-сканы/probe.
     * Эта задача теперь единственный prober: ждёт attach, раз в 2 с
     * пробует bring-up. Цикл бесконечный (спит 99.9% времени).
     * Сессия 57: сердцебиение «ждём USB-адаптер …» раз в 15 с убрано по
     * просьбе пользователя — серийный лог замусоривался. */
    {
        task_set_priority(task_current(), TASK_PRIO_BG);
        dbg("wifi: жду USB-адаптер (скан портов EHCI идёт в фоновой задаче)");
        int probes = 0;
        for (;;) {
            task_msleep(500);
            /* СЕССИЯ 40: ватчдог клина сработал во время ожидания —
             * сбрасываем порт и ждём переперечисления здесь же */
            if (rtl8192eu_wedged()) {
                rtl8192eu_recover_device();
                probes = 0;
                continue;
            }
            if (rtl8192eu_attached()) {
                if ((probes & 3) == 0) {
                    /* bring-up снова на UI — см. комментарий выше */
                    task_set_priority(task_current(), TASK_PRIO_UI);
                    int ok = rtl8192eu_probe();
                    task_set_priority(task_current(), TASK_PRIO_BG);
                    if (ok) {
                        dbg("wifi: адаптер подключён (hot-plug)");
                        wifi_net_up();
                        g_wifi_task_alive--;
                        return;
                    }
                    dbg("wifi: bring-up не удался — повтор через 2 с");
                }
                probes++;
            }
        }
    }
}

/* ---------- фоновая задача SATA (сессия 11) ----------
 * Раньше ahci_init выполнялся В БЛОКИРУЮЩЕМ режиме при загрузке:
 * на реальном железе (N2600 + HDD) COMRESET + раскрутка + IDENTIFY
 * занимали десятки секунд — рабочий стол появлялся только после.
 * Теперь инициализация SATA/НЖМД/файловых систем идёт в фоновой
 * задаче ПОСЛЕ старта ОС: UI поднимается сразу, диск «доезжает»
 * позже (кнопка [HDD] в Файлах активируется сама). Ядро пока
 * однопроцёрное (без SMP), поэтому «на другом ядре» выполнить
 * нельзя — фоновая задача с вытеснением даёт тот же эффект. */
static volatile int g_sata_state = 0;   /* 0=не запускалась, 1=идёт, 2=готово */

int sata_pending(void) { return g_sata_state != 2; }

static void sata_task_fn(void *arg)
{
    (void)arg;
    g_sata_state = 1;
    ahci_set_async(1);            /* ожидания с task_yield, не busy-loop */

    dbg("sata: фоновая инициализация AHCI...");
    if (ahci_init())
        dbg("sata: AHCI-контроллер найден");
    else
        dbg("sata: AHCI-контроллер не найден (IDE-only система)");

    if (disk_hdd_init()) {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "disk: НЖМД через %s: %s, %u МиБ",
                 disk_hdd_bus(), disk_hdd_model(),
                 (unsigned)(disk_hdd_sectors() / 2048u));
        dbg(buf);
    } else {
        dbg("disk: НЖМД не найден ни через AHCI, ни через ATA");
    }

    /* файловые системы: FAT32 (раздел или superfloppy), затем NTFS */
    dbg("fat32_init (фон)...");
    if (fat32_init())
        dbg("fat32: ready");
    else
        dbg_err("fat32: not found");

    dbg("ntfs_init (фон)...");
    if (ntfs_init()) {
        char b[80];
        snprintf(b, sizeof(b), "ntfs: %s", ntfs_label());
        dbg(b);
    } else {
        dbg("ntfs: раздел не найден");
    }

    /* сидинг RAM disk с FAT32 (\RAMDISK) — если ещё пуст */
    {
        ramfs_dirent_t chk[8];
        if (ramfs_ready() && ramfs_list(chk, 8) == 0)
            ramfs_seed_from_fat32();
    }

    /* AHCI ATAPI CD: монтируем ISO, если при загрузке не смонтировали */
    if (!iso9660_ready() && ahci_cd_present())
        if (iso9660_init())
            dbg("iso9660: SATA CD смонтирован (фоново)");

    g_sata_state = 2;
    dbg("sata: инициализация дисков завершена");
    task_exit();
}

/* ==================== MTRR: Write-Combining для LFB (ПЕРФ) ====================
 * При типе памяти UC/WT каждая запись в LFB тянет за собой чтение строки
 * кэша из RAM (read-for-ownership): кадр 1280x600x32 = 3 МиБ — это ~6 МиБ
 * лишнего трафика на каждый flush. Тип WC разрешает процессору объединять
 * записи пакетами по 64 байта — fb_flush_rects (копия compose→LFB) ускоряется
 * в разы, перетаскивание окон становится плавным.
 *
 * БЕЗОПАСНОСТЬ: если хоть одна проверка не проходит, WC просто НЕ
 * включается (ядро работает как раньше):
 *   1) CPUID подтверждает MTRR;
 *   2) диапазон после выравнивания целиком внутри MMIO-дыры
 *      [0xC0000000, 0xFEC00000) — не задевает RAM (ниже) и
 *      IOAPIC/LAPIC/HPET (0xFEC00000+);
 *   3) диапазон не пересекает MMIO BAR устройств (WC объединяет записи и
 *      допускает упреждающие чтения — для регистров устройств это поломка).
 *      BAR'ы измеряются штатным sizing'ом; сам BAR фреймбуфера (тот, что
 *      СОДЕРЖИТ LFB) исключением разрешён;
 *   4) есть свободный переменный MTRR (PHYSMASK без valid-бита).
 * Всё выполняется ДО инициализации драйверов (BAR'ы устройств неактивны,
 * sizing безопасен). Fixed-range MTRR не трогаются вовсе. */

static void msr_write(u32 msr, u64 v)
{
    __asm__ __volatile__("wrmsr"
                         :: "c"(msr), "a"((u32)v), "d"((u32)(v >> 32))
                         : "memory");
}

static u64 msr_read(u32 msr)
{
    u32 lo, hi;
    __asm__ __volatile__("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((u64)hi << 32) | (u64)lo;
}

/* Размер MMIO BAR (штатный sizing: записать 0xFFFFFFFF, прочитать маску,
 * восстановить). Устройства в этот момент ещё не инициализированы. */
static u64 mtrr_bar_size(int bus, int dev, int fn, u32 reg, int is64)
{
    u32 olo = pci_read32(bus, dev, fn, reg);
    u32 ohi = is64 ? pci_read32(bus, dev, fn, reg + 4) : 0;
    pci_write32(bus, dev, fn, reg, 0xFFFFFFFFu);
    u32 mlo = pci_read32(bus, dev, fn, reg);
    u64 size;
    if (is64) {
        pci_write32(bus, dev, fn, reg + 4, 0xFFFFFFFFu);
        u32 mhi = pci_read32(bus, dev, fn, reg + 4);
        pci_write32(bus, dev, fn, reg + 4, ohi);
        size = (~(((u64)mhi << 32) | (mlo & 0xFFFFFFF0u))) + 1ULL;
    } else {
        size = (u64)((~(mlo & 0xFFFFFFF0u)) + 1u);
    }
    pci_write32(bus, dev, fn, reg, olo);
    if (size == 0 || size > (1ULL << 32)) size = 0x1000;   /* мусор в конфиге */
    return size;
}

/* 1 = диапазон [b, b+sz) пересекает хоть один MMIO BAR (кроме самого
 * BAR'а фреймбуфера — тот по определению содержит LFB). Сканируются
 * шины 0..63: покрывает все ВМ и практически всё реальное железо ОС. */
static int mtrr_bar_overlap(u64 b, u64 sz)
{
    u64 e = b + sz;
    for (int bus = 0; bus < 64; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            int multifunc = 0;
            for (int fn = 0; fn < 8; fn++) {
                if (fn > 0 && !multifunc) break;
                u32 vd = pci_read32(bus, dev, fn, 0x00);
                if ((vd & 0xFFFF) == 0xFFFF) {
                    if (fn == 0) break;          /* слот пуст */
                    continue;
                }
                u8 hdr = pci_read8(bus, dev, fn, 0x0E);
                if (fn == 0) multifunc = (hdr & 0x80) != 0;
                int nbars = (hdr & 0x7F) == 0 ? 6        /* обычное устройство */
                          : (hdr & 0x7F) == 1 ? 2        /* PCI-мост */
                          : 1;                           /* CardBus и пр. */
                u32 reg = 0x10;
                for (int bi = 0; bi < nbars; bi++, reg += 4) {
                    u32 lo = pci_read32(bus, dev, fn, reg);
                    if (lo & 1u) continue;               /* port IO — не MMIO */
                    int is64 = ((lo >> 1) & 3) == 2;
                    if (is64) {
                        u32 hi = pci_read32(bus, dev, fn, reg + 4);
                        u64 base = ((u64)hi << 32) | (lo & 0xFFFFFFF0u);
                        u64 bsz = mtrr_bar_size(bus, dev, fn, reg, 1);
                        if (base != 0) {
                            /* BAR фреймбуфера содержит LFB — это он и есть */
                            int is_fb = (base <= b) && (base + bsz > b);
                            if (!is_fb && base < e && base + bsz > b) return 1;
                        }
                        bi++; reg += 4;                  /* старшая половина */
                    } else {
                        u64 base = lo & 0xFFFFFFF0u;
                        if (base == 0) continue;         /* BAR не назначен */
                        u64 bsz = mtrr_bar_size(bus, dev, fn, reg, 0);
                        int is_fb = (base <= b) && (base + bsz > b);
                        if (!is_fb && base < e && base + bsz > b) return 1;
                    }
                }
            }
        }
    }
    return 0;
}

static void mtrr_lfb_wc(const mb_info_t *mb)
{
    if (!(mb->flags & MBIF_FRAMEBUFFER) ||
        mb->framebuffer_type != MB_FT_RGB ||
        mb->framebuffer_bpp < 16)
        return;                          /* headless RAM-буфер — WC не нужен */

    u32 ca, cb, cc, cd;
    if (!__get_cpuid(1, &ca, &cb, &cc, &cd) || !(cd & (1u << 12))) {
        klog_puts("mtrr: CPU без MTRR — WC не включён");
        return;
    }

    u64 base = mb->framebuffer_addr;
    u64 fbsz = (u64)mb->framebuffer_pitch * (u64)mb->framebuffer_height;

    u32 cap = (u32)msr_read(0xFE);       /* MTRRCAP */
    int nvar = (int)(cap & 0xFF);
    if (nvar <= 0) {
        klog_puts("mtrr: нет переменных MTRR — WC не включён");
        return;
    }

    /* размер вверх до степени двойки, база вниз; диапазон обязан
     * целиком накрывать LFB */
    u64 sz = 0x40000;                    /* минимум 256 КиБ */
    while (sz < fbsz) sz <<= 1;
    u64 b = base & ~(sz - 1);
    while (b + sz < base + fbsz && sz < 0x10000000ULL) {
        sz <<= 1;
        b = base & ~(sz - 1);
    }
    if (b + sz < base + fbsz) {
        klog_puts("mtrr: LFB не накрывается выровненным диапазоном — WC не включён");
        return;
    }

    /* только MMIO-дыра, строго ниже IOAPIC (0xFEC00000) */
    if (b < 0xC0000000ULL || b + sz > 0xFEC00000ULL) {
        klog_puts("mtrr: LFB вне безопасного диапазона MMIO — WC не включён");
        return;
    }

    if (mtrr_bar_overlap(b, sz)) {
        klog_puts("mtrr: диапазон пересекает PCI BAR устройства — WC не включён");
        return;
    }

    /* MTRRdefType: включён ли механизм MTRR (бит E). Fixed-range
     * enable (бит 10) НЕ трогаем никогда. */
    u64 def = msr_read(0x2FF);
    if (!(def & 0x800ULL))
        msr_write(0x2FF, def | 0x800ULL);

    int idx = -1;
    for (int i = 0; i < nvar; i++) {
        if (!(msr_read(0x201 + (u32)i * 2) & 0x800ULL)) { idx = i; break; }
    }
    if (idx < 0) {
        klog_puts("mtrr: свободных переменных MTRR нет — WC не включён");
        return;
    }

    {
        int if_had;
        __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
        msr_write(0x200 + (u32)idx * 2, b | 1ULL);                /* тип 1 = WC */
        msr_write(0x201 + (u32)idx * 2, (~(sz - 1)) | 0x800ULL);  /* маска+valid */
        __asm__ __volatile__("cpuid"
                             :: : "eax", "ebx", "ecx", "edx", "memory");
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    }

    /* ВНИМАНИЕ: мини-snprintf ОС не умеет %llx (модификатор l
     * пропускается, аргумент читается как u32) — base всегда < 4 ГиБ
     * (MMIO-дыра), поэтому печатаем через %x от u32. */
    char log[96];
    snprintf(log, sizeof(log),
             "mtrr: LFB WC: base=0x%08x size=%u KiB (MTRR#%d)",
             (u32)b, (unsigned)(sz >> 10), idx);
    klog_puts(log);
}

void kmain(u32 magic, const mb_info_t *mb)
{
    /* Первым делом — serial, чтобы поймать даже падение до gdt. */
    serial_init();
    serial_puts("\n\n=== N2600-OS boot ===\n");

    /* Журнал загрузки: первые вехи — до всего остального (dmesg покажет
     * даже то, что на экран пролетело за миллисекунды). */
    klog_puts("N2600-OS boot");
    {
        char kb[64];
        snprintf(kb, sizeof(kb), "multiboot magic=0x%08x", (unsigned)magic);
        klog_puts(kb);
    }

    /* Инициализируем ранний LFB-вывод из multiboot info.
     * Это позволяет писать текст ПРЯМО в фреймбуфер ДО fb_init,
     * что критично на реальном железе где GRUB уже выставил VESA-режим. */
    early_fb_init(mb);
    early_clear();
    early_puts("N2600-OS boot...\n");

    g_mbi = mb;

    early_puts("magic=");
    early_puthex(magic);
    early_puts("\n");

    if (magic != MB_BOOTLOADER_MAGIC) {
        early_puts("ERROR: bad multiboot magic\n");
        early_puts("expected=0x2BADB002\n");
        vga_fail("bad multiboot magic");
        return;
    }
    early_puts("magic OK\n");

    /* Выводим информацию о framebuffer из multiboot info */
    if (mb->flags & MBIF_FRAMEBUFFER) {
        early_puts("FB: ");
        early_putu(mb->framebuffer_width);
        early_putc('x');
        early_putu(mb->framebuffer_height);
        early_putc('x');
        early_putu(mb->framebuffer_bpp);
        early_puts(" @");
        early_puthex((u32)(u32)mb->framebuffer_addr);
        early_puts("\n");
    } else {
        early_puts("FB: NO framebuffer info!\n");
    }

    early_puts("gdt...");
    serial_puts("[boot] gdt_init...\n");
    gdt_init();
    early_puts("OK\n");

    early_puts("idt...");
    serial_puts("[boot] idt_init...\n");
    idt_init();
    early_puts("OK\n");

    early_puts("mem...");
    serial_puts("[boot] mem_init...\n");
    mem_init(mb);
    early_puts("OK\n");
    {
        char kb[64];
        snprintf(kb, sizeof(kb), "mem: RAM %u МиБ, куча %u МиБ",
                 (unsigned)mem_ram_mib(), (unsigned)(mem_heap_size() >> 20));
        klog_puts(kb);
    }

    /* Фреймбуфер поднимаем как можно раньше — нужен для экранной отладки. */
    early_puts("fb...");
    serial_puts("[boot] fb_init...\n");
    if (!fb_init(mb)) {
        early_puts("FAIL\n");
        vga_fail("no VESA framebuffer (need 16+ bpp mode)");
        return;
    }
    early_puts("OK\n");

    /* ПЕРФ: Write-Combining для LFB через свободный переменный MTRR.
     * Обязательно ДО инициализации драйверов (BAR-скан/сизинг безопасен,
     * пока устройства неактивны). При любой сомнительной конфигурации
     * WC просто не включается (см. klog/dmesg: строка "mtrr:"). */
    mtrr_lfb_wc(mb);

    dbg_color_ok  = fb_rgb(0xFF, 0xFF, 0x00);
    dbg_color_err = fb_rgb(0xFF, 0x60, 0x60);

    {
        char buf[80];
        snprintf(buf, sizeof(buf), "fb: %ux%u, %u bpp, pitch %u",
                 (unsigned)fb_width(), (unsigned)fb_height(),
                 (unsigned)fb_bpp(), (unsigned)fb_pitch());
        dbg(buf);
    }

    dbg("fb_make_bg...");    fb_make_bg();

    /* =======================================================================
     * ЗАЩИТА: Аппаратное маскирование IRQ 14 и 15 (ATA Primary/Secondary)
     * 0xA1 - порт данных Slave PIC. Биты 6 и 7 отвечают за IRQ 14 и 15.
     * Устанавливаем их в 1, чтобы прерывания от диска физически не дошли до CPU.
     * ======================================================================= */
    outb(0xA1, inb(0xA1) | 0xC0);
    dbg("IRQ14/15 masked");

        /* ---------- ATA (CD для загрузки) ----------
     * AHCI/SATA с сессии 11 НЕ блокирует загрузку: инициализация SATA-
     * контроллера, НЖМД и файловых систем (FAT32/NTFS) выполняется
     * ФОНОВОЙ задачей после старта ОС (см. sata_task_fn). ata_init
     * остаётся синхронным: он быстрый (пустые каналы отвечают сразу)
     * и нужен для ATAPI-CD (ISO9660 + сидинг ramfs при загрузке с CD). */
    dbg("ata_init...");
    {
        int r = ata_init();
        if (r) {
            char buf[80];
            if (ata_is_cdrom()) {
                snprintf(buf, sizeof(buf),
                         "ata: CD-ROM on port 0x%x, sel 0x%x (%s)",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model());
            } else {
                snprintf(buf, sizeof(buf),
                         "ata: HDD on port 0x%x, sel 0x%x, %s, sectors=%u",
                         (unsigned)ata_base_port(), (unsigned)ata_drive_sel(),
                         ata_model(), (unsigned)ata_sectors());
            }
            dbg(buf);
        } else {
            dbg_err("ata: NOT present (return 0)");
        }
        /* Диагностика дисков для dmesg/disks: отдельно НЖМД, если найден */
        if (ata_hdd_present()) {
            char buf[96];
            snprintf(buf, sizeof(buf),
                     "ata: HDD %s, %u секторов (%u МиБ)",
                     ata_hdd_model(), (unsigned)ata_hdd_sectors(),
                     (unsigned)(ata_hdd_sectors() / 2048u));
            dbg(buf);
        } else {
            dbg("ata: HDD не найден (только CD или пустые каналы)");
        }
        /* Сессия 13: командная строка ядра (GRUB: multiboot /boot/kernel.bin arg).
         * ataprobe — дамп регистров IDE (Bochs/железо: «почему CD не найден»);
         * bochs — вывод в serial дополнительной диагностики загрузки. */
        if ((mb->flags & MBIF_CMDLINE) && mb->cmdline) {
            const char *cl = (const char *)(u32)mb->cmdline;
            extern void ata_probe_diag(void);
            {
                char cb[96];
                extern int snprintf(char*, u32, const char*, ...);
                snprintf(cb, sizeof(cb), "[kmain] cmdline='%s'", cl);
                serial_puts(cb);
                serial_puts("\n");
            }
            if (strstr(cl, "ataprobe")) {
                dbg("cmdline: ataprobe");
                ata_probe_diag();
            }
            if (strstr(cl, "sandbox=off")) {
                extern void loader_set_sandbox(int on);
                loader_set_sandbox(0);
                dbg("cmdline: sandbox=off (бинарники без региона памяти)");
            }
        }
    }

    dbg("sata: инициализация AHCI/SATA отложена — фоновая задача после старта");

    /* ---------- ISO9660 ---------- */
    dbg("iso9660_init...");
    if (iso9660_init())
        dbg("iso9660: ready");
    else
        dbg_err("iso9660: not found (return 0)");

    /* ---------- RAMFS ---------- */
    dbg("ramfs_init...");
    if (ramfs_init()) {
        char buf[80];
        snprintf(buf, sizeof(buf), "ramfs: ready, %u МиБ",
                 (unsigned)(ramfs_total_space() / (1024 * 1024)));
        dbg(buf);
    } else {
        dbg_err("ramfs: init failed");
    }

    /* Сидинг RAM disk из /boot/ramdisk в ISO (если есть и влезает) */
    dbg("ramfs_seed_from_iso...");
    ramfs_seed_from_iso();
    /* Сессия 55: встроенные ресурсы (LOGO.PNG/IMG.JS) — только если
     * файлов ещё нет: у пересобранного ISO приоритет у /boot/ramdisk */
    imgres_seed();
    /* FIX [R2] (перенесено в sata_task, сессия 11): сидинг из \RAMDISK
     * на FAT32 требует НЖМД, который теперь инициализируется ФОНОВО —
     * вызов переехал в sata_task_fn после монтирования файловых систем. */
    /* ---------- периферия ---------- */
    /* СЕССИЯ 33: PIT 1000 Гц (1 тик = 1 мс) — точные короткие паузы
     * (task_msleep(1) больше не растягивается до 10 мс), плавнее UI,
     * честные тайминги USB/WiFi. Накладные расходы IRQ0 ~1% vCPU. */
    dbg("timer_init...");    timer_init(1000);
    dbg("kbd_init...");      kbd_init();
    dbg("mouse_init...");    mouse_init();
    if (mouse_present())
        dbg("mouse: present");
    else
        dbg_err("mouse: not present");

    /* ---------- USB ---------- */
    /* Инициализируем UHCI-контроллеры и ищем HID-устройства.
     * Реальный опрос HID-отчётов требует полного QH-стека и прерываний —
     * здесь выполняется только детекция (события продолжают приходить
     * через PS/2-эмуляцию BIOS Legacy USB). */
    dbg("usb_init...");     usb_init();
    if (usb_controllers_found())
        dbg("usb: UHCI controller initialized");
    else
        dbg_err("usb: no UHCI controller (используется BIOS Legacy USB)");
    if (usb_devices_found() > 0) {
        char buf[80];
        snprintf(buf, sizeof(buf), "usb: %d device(s) detected", usb_devices_found());
        dbg(buf);
    }

    /* ---------- WiFi (СЕССИЯ 15: ФОНОВАЯ задача) ----------
     * Больше НЕ блокируем загрузку: инициализация Atheros (PCI-скан +
     * cold reset + INI + калибровки AGC/NF — СЕКУНДЫ на нетбуке)
     * идёт в wifi_task_fn ПОСЛЕ старта ОС (как SATA с сессии 11).
     * Если при загрузке ethernet-адаптеров нет, сеть поднимет сама
     * wifi-задача, когда адаптер будет готов (см. wifi_task_fn). */
    dbg("wifi: отложено в фоновую задачу (после старта ОС)");

    /* ---------- Ethernet: инициализируем ВСЕ драйверы ----------
     * Сессия 11: реестр адаптеров (net.c) сам выбирает активный по
     * линку — поэтому каждый драйвер должен отработать свой PCI-скан.
     * Раньше цепочка «e1000 ИЛИ virtio ИЛИ ne2000 ИЛИ atl1c» не давала
     * второму NIC зарегистрироваться (и WiFi не участвовал вообще). */
    dbg("e1000_init...");     e1000_init();
    dbg("virtio_net_init..."); virtio_net_init();
    dbg("ne2000_init...");    ne2000_init();

    /* Atheros L1c/L2c (AR813x/815x) — проводная сетевая карта ASUS X101CH
     * (AR8152 v2, PCI 1969:2062). В QEMU её нет — PCI-скан вернётся
     * мгновенно; на X101CH это единственный проводной NIC. */
    dbg("atl1c_init...");     atl1c_init();

    /* wifi в этом условии НЕ участвует: его инициализация теперь
     * фоновая (сессия 15) — на момент загрузки он не готов. Если
     * ethernet нет, сеть поднимет wifi_task_fn позже. */
    if (e1000_present() || virtio_net_present() || ne2000_present() ||
        atl1c_present()) {
        /* Настройки приоритета адаптера из SETTINGS.CFG (RAM disk),
         * затем инициализация реестра NIC и выбор активного по линку */
        net_settings_load();
        dbg("net_init...");
        net_init();
        /* callback: смена адаптера → сброс адресов + повтор DHCP */
        net_adapter_set_change_cb(netmon_adapter_changed);
        /* IP, шлюз, маска (QEMU user-net) — умолчания до DHCP */
        net_set_ip(0x0A00020F);        /* 10.0.2.15 */
        net_set_gateway(0x0A000202);  /* 10.0.2.2  */
        net_set_netmask(0xFFFFFF00);  /* 255.255.255.0 */
        dbg("net: 10.0.2.15/24 gw 10.0.2.2 (умолчания до DHCP)");
    } else {
        dbg("net: ethernet NIC нет — сеть поднимет wifi-задача (фон)");
    }

    /* Встроенный HTTP-сервер: localhost для теста. Работает даже
     * БЕЗ NIC (loopback 127.0.0.1 замыкается внутри стека):
     * curl http://127.0.0.1/ , http://localhost/ из браузера,
     * а снаружи — через QEMU hostfwd=tcp::8080-:80. */
    dbg("httpd: listen :80...");
    net_httpd_start();

    /* ---------- звук (сессия 57) ---------- */
    /* ES1371 (VMware «Sound Blaster AudioPCI» / es1371-режим) или
     * Intel HDA (VMware hdaudio + настоящая ALC269VB). Проба PCI —
     * до многозадачности, безопасно по I/O. */
    dbg("sound: probe...");
    sound_init();

    /* ---------- многозадачность ---------- */
    /* task_init() создаёт TCB[0] для главной задачи и регистрирует IRQ0
     * на наш планировщик. Должно идти ДО sti(), чтобы первый IRQ0 уже
     * нашёл готовую таблицу задач. */
    dbg("task_init...");     task_init();

    /* ramfs КАК ОТДЕЛЬНЫЙ ПРОЦЕСС: задача-сервер «ramfs» (системная,
     * kill запрещён). После первого IRQ0 она заберёт владение ramdisk —
     * в диспетчере задач появится строка ramfs с честной памятью. */
    if (ramfs_server_start()) {
        char b[64];
        snprintf(b, sizeof(b), "ramfs: сервер запущен (задача %d)",
                 ramfs_server_task());
        dbg(b);
    } else {
        dbg_err("ramfs: не удалось запустить задачу-сервер");
    }

    /* ---------- СЕССИЯ 15: запуск фоновых задач сети ---------- */
    /* netmon: постоянный монитор сети (DHCP/линк/авто-переключение) */
    if (net_adapter_count() > 0) {
        int tid = task_spawn_prio("netmon", netmon_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_netmon_started = 1;
        }
    }

    /* wifi: инициализация Atheros ФОНОМ (сессия 15 — нетбук больше
     * не ждёт адаптер при загрузке; задача живёт до готовности,
     * затем WiFi опрашивается из главного цикла).
     * СЕССИЯ 40: через wifi_task_spawn() — ставит g_wifi_spawn_pending,
     * чтобы главный цикл не заспавнил вторую задачу до старта первой. */
    {
        /* СЕССИЯ 34: PRIO_BG — шторм перечисления/скана не тормозит UI */
        int tid = task_spawn_prio("wifi", wifi_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) {
            task_set_system(tid);
            g_wifi_spawn_pending = 1;   /* задача выставит alive на входе */
        }
    }

    /* ---------- фоновая инициализация SATA (сессия 11) ----------
     * Рабочий стол поднимается НЕЖДАЯ диск: AHCI/НЖМД/FAT32/NTFS
     * инициализируются параллельно в фоновой задаче (на реальном
     * железе COMRESET+раскрутка+IDENTIFY занимают десятки секунд). */
    {
        int tid = task_spawn_prio("sata", sata_task_fn, NULL, TASK_PRIO_BG);
        if (tid > 0) task_set_system(tid);
    }

    /* ---------- оконный менеджер ---------- */
    dbg("wm_init...");       wm_init();
    /* При загрузке открываем ТОЛЬКО терминал.
     * Остальные приложения доступны через меню «Меню». */
    dbg("apps_open(terminal)...");
    apps_open(2);   /* Терминал */

    /* ---------- прерывания ---------- */
    dbg("irq setup...");
    mouse_install_irq();
    pic_unmask((u16)((1 << 0) | (1 << 1) | (1 << 2) | (1 << 12)));
    /* Сессия 12 (FIX «остатки boot-лога сквозь обои»): экранный вывод
     * dbg() выключается ДО sti(). Раньше флаг ставился ПОСЛЕ sti() —
     * между ними успевали стартовать фоновые задачи (sata/netmon) и
     * рисовали свои строки ПОВЕРХ обоев: обои уже были, но строки
     * оставались на экране до первого полного кадра, а при отсутствии
     * событий — висели минутами. Теперь после sti() ни одна фоновая
     * задача не может испортить экран. */
    g_screen_log_off = 1;
    sti();
    serial_puts("[boot] irq on, entering main loop\n");
    klog_puts("irq on, entering main loop");
    klog_puts("Загрузка завершена — система готова");
    /* полная перерисовка: обои + окна + таскбар поверх последнего
     * состояния загрузочного лога */
    fb_touch_all();

    /* главный цикл: события -> композитинг -> hlt до следующего прерывания */
    key_event_t ev;
    u32 last_half = 0;
    for (;;) {
        while (kbd_pop(&ev))
            wm_key(&ev);

        wm_mouse_poll();
        usb_poll();        /* опрос HID (если что-то найдено) */
        wifi_poll();        /* опрос WiFi (сканирование) */
        net_poll();         /* опрос сети: приём и обработка Ethernet/ARP/IP/ICMP */
        net_httpd_poll();   /* сессия 60: FSM отправки файлов + idle-таймаут httpd */

        /* СЕССИЯ 40: авто-восстановление WiFi-адаптера. Адаптер перестал
         * отвечать по USB (ватчдог rtl8192eu) или донгл переподключили
         * после готовности — а wifi-задачи больше нет (она вышла после
         * wifi_net_up). Поднимаем новую: она сбросит порт, переперечислит
         * и выполнит полный bring-up. */
        if (wifi_present() && !wifi_ready() &&
            !g_wifi_spawn_pending && g_wifi_task_alive == 0) {
            wifi_task_spawn();
        }

        u32 t = timer_ticks();
        if (t / 500 != last_half) {  /* 2 раза в секунду (1 тик = 1 мс) */
            last_half = t / 500;
            wm_halfsec();
            /* Ватчдог: kill задач, зависших > 5 секунд (5000 тиков по 1 мс).
             * Главная задача (task[0]) не проверяется. */
            int killed = task_watchdog(5000);
            if (killed > 0) {
                char buf[64];
                snprintf(buf, sizeof(buf), "[watchdog] killed %d hung task(s)", killed);
                serial_puts(buf);
            }
            /* СЕССИЯ 35: hot-plug EHCI не зависит от wifi-задачи: главный
             * цикл видит CSC/необслуженный порт и спавнит BG-скан.
             * СЕССИЯ 37: скан — не I/O-ожидание, а честные контрольные
             * трансферы и сбросы порта (сотни мс CPU): на BG-крошках
             * (1 тик из 250 при всегда-готовом kmain) перечисление
             * растягивалось с секунд до минут. Задача короткоживущая
             * и большую часть пауз спит (waiting) — UI-приоритет ей
             * ничего не стоит, а завершает скан в реальном времени. */
            if (usb_ehci_present() && !g_usb_scan_running &&
                (usb_ehci_csc_pending() || usb_ehci_work_pending())) {
                if (task_spawn_prio("usbhot", usb_hotplug_task_fn,
                                    NULL, TASK_PRIO_UI) > 0)
                    g_usb_scan_running = 1;
            }
        }

        {
            /* Сессия 13 (диагностика порчи кучи): сторож в главном цикле.
             * СРАЗУ при обнаружении — serial + последний блок.
             * ПЕРФ (запрос пользователя): полный обход кучи на КАЖДЫЙ
             * проход главного цикла съедал CPU на Atom и рвал плавность
             * интерфейса — теперь раз в секунду (достаточно для
             * диагностики: порча ловится и на аллокациях). */
            static u32 last_guard = 0;
            if (t - last_guard >= 1000) {   /* 1 тик = 1 мс */
                last_guard = t;
                /* Сессия 59: канарейки стеков РАНЬШЕ проверки кучи —
                 * переполнение стека задачи бьёт канарейку ДО того,
                 * как побьёт заголовок соседнего блока кучи. */
                extern void task_check_stack_canaries(void);
                task_check_stack_canaries();
                extern int mem_check_corrupt(void);
                extern void mem_dump_blocks(void);
                if (mem_check_corrupt()) {
                    extern void serial_puts(const char *s);
                    serial_puts("[guard] ПОРЧА КУЧИ ОБНАРУЖЕНА (главный цикл)\n");
                    mem_dump_blocks();
                    for (;;) hlt();   /* замереть для сохранения контекста */
                }
            }
        }
        wm_frame();
        hlt();
    }
}