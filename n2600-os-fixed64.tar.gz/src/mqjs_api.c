/* mqjs_api.c — мост между MicroQuickJS и API N2600-OS (сессия 64).
 *
 * CMScript (SUNSETDEVER KernelCDM) заменён на MicroQuickJS
 * (bellard/mquickjs, MIT; single-file amalgamation, см. mqjs_engine.c).
 * Скриптовый язык теперь JavaScript (диалект ES5.1 движка: var/function,
 * без let/const/arrow/template literals), со стандартной библиотекой
 * (Object/Array/String/JSON/Math/TypedArray — всё из движка).
 *
 * Из скрипта доступны функции ОС (те же имена, что были в CMScript):
 *   print(...)               — вывод значений через пробел + '\n' в буфер run'а
 *   print_int(n)             — вывод числа (совместимость со старыми скриптами)
 *   screen_width() / screen_height()
 *   fill_rect(x,y,w,h,color) — прямоугольник на экране (как в CMScript)
 *   draw_text(x,y,str,color) — текст на экране
 *   get_color(r,g,b)         — 0xRRGGBB
 *   clear_screen(color)      — очистка экрана
 *   flip()                   — перерисовка экрана сейчас
 *   delay(ms)                — кооперативная задержка (task_yield)
 *   uptime()                 — секунды с загрузки
 *   strlen(s)                — длина строки в БАЙТАХ (utf8), совместимость
 *   ramfs_read(name)         -> строка с содержимым (прежде (name,buf,max))
 *   ramfs_write(name, data)  — записать строку в RAM disk
 *   ramfs_list()             -> массив имён файлов RAM disk
 *   win_open(title,x,y,w,h)  -> дескриптор окна или -1
 *   win_close(id) / win_alive(id) -> 1, пока окно открыто
 *   win_clear(id,color) / win_rect(id,x,y,w,h,color)
 *   win_text(id,x,y,text,color) / win_update(id)
 *   btn_add(id,x,y,w,h,label) -> номер кнопки или -1
 *   btn_clicked(id)           -> номер нажатой кнопки или -1
 *   btn_set_label(id,btn,label)
 *   img_load(path)            -> дескриптор картинки (RAM disk или http(s)://)
 *   img_w(id) / img_h(id) / img_pixel(id,x,y) -> 0xRRGGBB или -1
 *   img_draw(id,x,y) / img_draw_scaled(id,x,y,w,h)
 *   img_free(id)
 *   win_img(id,img,x,y) / win_img_scaled(id,img,x,y,w,h)
 *
 * НЕ переносились (у них нет смысла в JS; старые C-подобные вызовы):
 *   malloc/free/memset/memcmp — память скрипта целиком во владении GC.
 *   sprintf/snprintf — используйте конкатенацию, String(), toFixed().
 *
 * Отличия от CMScript-моста (cmscript_api.c, файл удалён):
 *   - движок: JS_NewContext с фиксированным регионом 512 КиБ (heap+stack
 *     внутри), GC — компактация внутри региона, ядро malloc не участвует;
 *   - ПАРСЕР: глубокие вложения ограничены только стеком задачи (32 КиБ,
 *     task_spawn) — как у CMScript-парсера;
 *   - print и вывод ошибок идут в один буфер run'а (write_func движка);
 *   - обработчик прерываний движка вызывает task_yield() каждые ~10000
 *     операций — чисто-JS бесконечный цикл не вешает систему;
 *   - эта же реализация (print/gc/Date/...) подставлена в таблицу C-функций
 *     стандарта: CLI-часть amalgamation (mqjs.c) не собирается.
 *
 * Также здесь живут c4k_* (GUI-сервисы для c4-песочницы, kapi_t) — они
 * переехали из cmscript_api.c без изменений вместе с движком окон sg_*.
 */
#include "mqjs.h"
#include "mqjs_priv.h"    /* JS_MTAG_*, JS_ROM_VALUE, js_global_isNaN/isFinite */
#include "mqjs_libm.h"    /* js_sin/js_pow/... — Math.* в таблице стандарта */
#include "types.h"
#include "mem.h"
#include "string.h"
#include "sync.h"
#include "kernel.h"
#include "fb.h"
#include "wm.h"
#include "mouse.h"        /* MSB_LEFT */
#include "timer.h"
#include "task.h"
#include "ramfs.h"
#include "imgsvc.h"
#include "kapi.h"         /* декларации c4k_* (и для kapi_fill в loader.c) */
#include "c4.h"           /* c4_gui_api_t (таблица GUI для VM-пути c4.c) */

/* Функции из CLI mqjs.c, на которые ссылается сгенерированная таблица
 * стандарта. Реализации — ниже (print/gc полезны и в ядре; load/setTimeout
 * в N2600-OS не имеют смысла). mqjs_stdlib.h включается ПОСЛЕ прототипов. */
static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
#include "mqjs_stdlib.h"
#include "mqjs.h"         /* публичный API движка (после priv — без разницы) */

/* ================= mqjs_libc.h: реализации шима ================= */

/* printf движка (отладочные дампы JS_DumpValue и пр.) — в serial.
 * Форматы движка шире ядрового vsnprintf — но это путь только для
 * диагностики: в нормальной работе не вызывается. */
int printf(const char *fmt, ...)
{
    static char buf[384];
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    serial_puts(buf);
    return 0;
}

/* Сбой инварианта движка (assert) — в ядре это неисправимо: печать и стоп. */
void mqjs_assert_fail(const char *expr, const char *file, int line)
{
    char msg[160];
    snprintf(msg, sizeof(msg), "[mqjs] ASSERT: %s (%s:%d)\n",
             expr ? expr : "?", file ? file : "?", line);
    serial_puts(msg);
    klog_puts(msg);
    for (;;) { __asm__ __volatile__("cli\n\thlt"); }
}

void abort(void)
{
    serial_puts("[mqjs] abort()\n");
    klog_puts("[mqjs] abort()");
    for (;;) { __asm__ __volatile__("cli\n\thlt"); }
}

void exit(int code)
{
    (void)code;
    /* движок exit() не зовёт (CLI исключён); на всякий случай — стоп */
    abort();
}

/* realloc ядра не имеет; движку не нужен (память — регион), но cutils
 * резервирует символ в недостижимых путях. */
void *realloc(void *p, size_t n)
{
    void *q;
    if (n == 0) { free(p); return NULL; }
    q = malloc((u32)n);
    if (q && p) {
        /* размер старого блока знает только куча: копируем по-простому
         * максимум старого заголовка — движок этот путь не использует */
        u32 *hdr = (u32 *)p - 1;
        u32 old = hdr[0] & ~3u;
        if (old > n) old = (u32)n;
        memcpy(q, p, old);
        free(p);
    }
    return q;
}

int abs(int x) { return x < 0 ? -x : x; }

/* setjmp/longjmp — см. mqjs_libc.h. Точка возобновления — «возврат из
 * setjmp»: обязательно noinline, иначе уплыл бы esp кадра вызова. */
__attribute__((noinline)) int setjmp(jmp_buf buf)
{
    __asm__ __volatile__ (
        "movl %%ebx, 0(%0)\n\t"
        "movl %%esi, 4(%0)\n\t"
        "movl %%edi, 8(%0)\n\t"
        "movl %%ebp, 12(%0)\n\t"
        "leal 4(%%esp), %%eax\n\t"
        "movl %%eax, 16(%0)\n\t"
        "movl (%%esp), %%eax\n\t"
        "movl %%eax, 20(%0)"
        : : "d"(buf) : "eax", "memory", "cc");
    return 0;
}

void longjmp(jmp_buf buf, int val)
{
    __asm__ __volatile__ (
        "movl 0(%0), %%ebx\n\t"
        "movl 4(%0), %%esi\n\t"
        "movl 8(%0), %%edi\n\t"
        "movl 12(%0), %%ebp\n\t"
        "testl %%eax, %%eax\n\t"
        "jnz 1f\n\t"
        "movl $1, %%eax\n"
        "1:\n\t"
        "movl 20(%0), %%edx\n\t"
        "movl 16(%0), %%esp\n\t"
        "jmp *%%edx"
        : : "d"(buf), "a"(val) : "memory", "cc");
    __builtin_unreachable();
}

/* ================= буфер вывода run'а ================= */

static char *g_mq_out = 0;
static u32   g_mq_out_pos = 0;
static u32   g_mq_out_max = 0;

static void mq_putc(char c)
{
    if (g_mq_out_pos + 1 < g_mq_out_max)
        g_mq_out[g_mq_out_pos++] = c;
}

static void mq_putn(const char *s, u32 n)
{
    while (n--) mq_putc(*s++);
}

static void mq_puts(const char *s)
{
    while (*s) mq_putc(*s++);
}

static void mq_putint(int v)
{
    char b[12];
    int i = 0;
    if (v < 0) { mq_putc('-'); v = -v; }
    if (v == 0) { mq_putc('0'); return; }
    while (v) { b[i++] = (char)('0' + v % 10); v /= 10; }
    while (i--) mq_putc(b[i]);
}

/* ================= чтение аргументов JS -> C ================= */

static int arg_int(JSContext *ctx, JSValue v, int def)
{
    int r = def;
    JS_ToInt32Sat(ctx, &r, v);
    return r;
}

static u32 arg_color(JSContext *ctx, JSValue v)
{
    u32 r = 0;
    JS_ToUint32(ctx, &r, v);
    return r;
}

/* Строка аргумента: копия уже на стеке/в буфере вызова, валидна до
 * следующей аллокации движка (GC может сдвинуть) — используем сразу. */
static const char *arg_str(JSContext *ctx, JSValue v, JSCStringBuf *sb)
{
    size_t len = 0;
    return JS_ToCStringLen(ctx, &len, v, sb);
}

/* ================= функции из CLI mqjs.c (таблица стандарта) ================= */

/* print(value, ...) — через пробел, в конце '\n' (семантика mqjs.c) */
static JSValue mq_print_impl(JSContext *ctx, JSValue *argv, int argc)
{
    for (int i = 0; i < argc; i++) {
        if (i) mq_putc(' ');
        JSValue s = JS_ToString(ctx, argv[i]);
        if (JS_IsException(s)) return s;
        JSCStringBuf sb;
        size_t len = 0;
        const char *str = JS_ToCStringLen(ctx, &len, s, &sb);
        if (!str) return JS_EXCEPTION;
        mq_putn(str, (u32)len);
    }
    mq_putc('\n');
    return JS_UNDEFINED;
}

static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val;
    return mq_print_impl(ctx, argv, argc);
}

static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    JS_GC(ctx);
    return JS_UNDEFINED;
}

static JSValue js_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_ThrowTypeError(ctx, "load() is not supported in N2600-OS");
}

/* 1 тик = 1 мс (сессия 33): uptime в мс — просто timer_ticks() */
static double mq_now_ms(void)
{
    return (double)timer_ticks();
}

static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val,
                                   int argc, JSValue *argv)
{
    (void)this_val;
    double val;
    argc &= ~FRAME_CF_CTOR;
    if (argc == 0) {
        val = mq_now_ms();
    } else if (argc == 1 && JS_IsNumber(ctx, argv[0])) {
        if (JS_ToNumber(ctx, &val, argv[0]))
            return JS_EXCEPTION;
    } else {
        return JS_ThrowTypeError(ctx, "unsupported Date() parameter");
    }
    return JS_NewDate(ctx, val);
}

static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt64(ctx, (long long)mq_now_ms());
}

static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt64(ctx, (long long)mq_now_ms());
}

/* Событийного цикла в ядре нет: таймеры не работают (возвращаем id=0) */
static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt32(ctx, 0);
}

static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_UNDEFINED;
}

/* ================= host-функции ОС (задача run'а) ================= */

/* Совместимость со старыми скриптами: печать числа без '\n' */
static JSValue jsf_print_int(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    mq_putint(arg_int(ctx, argv[0], 0));
    return JS_UNDEFINED;
}

static JSValue jsf_screen_width(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt32(ctx, (int)fb_width());
}

static JSValue jsf_screen_height(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt32(ctx, (int)fb_height());
}

static JSValue jsf_fill_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    fb_fill_rect(arg_int(ctx, argv[0], 0), arg_int(ctx, argv[1], 0),
                 arg_int(ctx, argv[2], 0), arg_int(ctx, argv[3], 0),
                 arg_color(ctx, argv[4]));
    return JS_UNDEFINED;
}

static JSValue jsf_draw_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *s = arg_str(ctx, argv[2], &sb);
    fb_text(arg_int(ctx, argv[0], 0), arg_int(ctx, argv[1], 0),
            s ? s : "", arg_color(ctx, argv[3]), -1);
    return JS_UNDEFINED;
}

static JSValue jsf_get_color(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    return JS_NewInt32(ctx, (int)fb_rgb((u8)arg_int(ctx, argv[0], 0),
                                        (u8)arg_int(ctx, argv[1], 0),
                                        (u8)arg_int(ctx, argv[2], 0)));
}

static JSValue jsf_clear_screen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    fb_fill_screen(arg_color(ctx, argv[0]));
    return JS_UNDEFINED;
}

static JSValue jsf_flip(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    fb_touch_all();
    fb_flush();
    return JS_UNDEFINED;
}

static JSValue jsf_delay(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    u32 start = timer_ticks();
    u32 need = (u32)arg_int(ctx, argv[0], 0);
    if (need == 0) need = 1;
    while (timer_ticks() - start < need)
        task_yield();
    return JS_UNDEFINED;
}

static JSValue jsf_uptime(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt32(ctx, (int)uptime_sec());
}

static JSValue jsf_strlen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *s = arg_str(ctx, argv[0], &sb);
    return JS_NewInt32(ctx, s ? (int)strlen(s) : 0);
}

/* ramfs_read(name) -> строка (прежний вариант (name, buf, max) требовал
 * указателей, которых в JS нет). Пустая строка — файла нет. */
static JSValue jsf_ramfs_read(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *name = arg_str(ctx, argv[0], &sb);
    if (!name || !ramfs_ready())
        return JS_NewStringLen(ctx, "", 0);
    ramfs_dirent_t de;
    if (ramfs_stat_ci(name, &de) != 0)
        return JS_NewStringLen(ctx, "", 0);
    u32 cap = de.size + 1;
    char *buf = (char *)malloc(cap);
    if (!buf)
        return JS_ThrowOutOfMemory(ctx);
    u32 got = ramfs_read(name, buf, cap);
    buf[got] = 0;
    JSValue r = JS_NewStringLen(ctx, buf, got);
    free(buf);
    return r;
}

/* ramfs_write(name, data) — data: строка (utf8) */
static JSValue jsf_ramfs_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb, sb2;
    const char *name = arg_str(ctx, argv[0], &sb);
    size_t len = 0;
    const char *data = JS_ToCStringLen(ctx, &len, argv[1], &sb2);
    if (!name || !data || !ramfs_ready())
        return JS_FALSE;
    ramfs_delete(name);
    if (!ramfs_create(name, (u32)len + 1))
        return JS_FALSE;
    if (!ramfs_write(name, data, (u32)len + 1))
        return JS_FALSE;
    return JS_TRUE;
}

/* ramfs_list() -> массив имён (прежде был TODO-стаб, возвращавший 0) */
static JSValue jsf_ramfs_list(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    JSValue arr = JS_NewArray(ctx, 0);
    if (!ramfs_ready())
        return arr;
    ramfs_dirent_t list[64];
    int n = ramfs_list(list, 64);
    for (int i = 0; i < n; i++) {
        if (list[i].is_dir) continue;
        JS_SetPropertyUint32(ctx, arr, (u32)i, JS_NewString(ctx, list[i].name));
    }
    return arr;
}

/* ===== SCRIPT GUI: окна и кнопки из .js-скрипта =====
 *
 * Дескрипторы — индексы в статической таблице (без heap). Окно рисуется
 * колбэком sg_draw (фон + список примитивов + кнопки), клики от мыши
 * ловит sg_mouse, Esc закрывает окно. Скрипт опрашивает btn_clicked()
 * в цикле while (win_alive(id)) { ... delay(30); }.
 *
 * Потоки: sg_draw/sg_mouse/sg_key зовутся из задачи WM, скриптовые
 * sgf_* — из задачи run'а (cs_run_task). Общий доступ к таблице
 * сериализуется s_lock(sg_lock); отрисовка идёт без блокировки —
 * допускаем мгновенный "рваный" кадр, но не дедлок.
 *
 * ВАЖНО: win_close()/win_create() вызываются ВНЕ блокировки — WM может
 * вызвать sg_close синхронно, и вложенный s_lock заклинил бы спинлок. */

#define SG_MAX_WINS   4
#define SG_MAX_BTNS   16
#define SG_MAX_OPS    64
#define SG_TITLE_MAX  48
#define SG_LABEL_MAX  24
#define SG_TEXT_MAX   40

typedef struct {
    int  type;                      /* 0 = rect, 1 = text,
                                     * 2 = img (дескриптор imgsvc),
                                     * 3 = img_scaled (свой буфер ptr) */
    int  x, y, w, h;
    u32  color;
    char text[SG_TEXT_MAX];
    /* сессия 55: картинки */
    int  img_id;                    /* type 2: дескриптор imgsvc */
    void *ptr;                      /* type 3: буфер RGBA (владелец — op) */
} sg_op_t;

typedef struct {
    int  used;
    int  x, y, w, h;
    char label[SG_LABEL_MAX];
    int  hot;                       /* курсор над кнопкой */
    int  pressed;                   /* зажата */
} sg_btn_t;

typedef struct {
    int        used;
    window_t  *win;                 /* NULL после закрытия */
    int        want_close;
    u32        bg;
    char       title[SG_TITLE_MAX];
    sg_btn_t   btns[SG_MAX_BTNS];
    sg_op_t    ops[SG_MAX_OPS];
    int        op_count;
    int        last_click;          /* номер нажатой кнопки или -1 */
} sg_win_t;

static sg_win_t g_sgw[SG_MAX_WINS];
static volatile int sg_lock = 0;

/* Взять окно под блокировкой (если слот жив). Разблокирует вызывающий. */
static sg_win_t *sg_lock_win(int id) {
    if (id < 0 || id >= SG_MAX_WINS) return NULL;
    s_lock(&sg_lock);
    if (!g_sgw[id].used) { s_unlock(&sg_lock); return NULL; }
    return &g_sgw[id];
}
static void sg_unlock_win(void) {
    s_unlock(&sg_lock);
}
static void sg_repaint(sg_win_t *g) {
    if (g && g->win) win_invalidate(g->win);
}
static void sg_copy_str(char *dst, int cap, const char *src) {
    int i = 0;
    if (src) for (; src[i] && i < cap - 1; i++) dst[i] = src[i];
    dst[i] = 0;
}

/* Освободить ресурсы ops (сессия 55): буферы type-3 (масштабированные
 * копии) принадлежат op'ам. type-2 держат ссылку через img_retain —
 * отпускаем здесь же. */
static void sg_free_ops(sg_win_t *g) {
    for (int i = 0; i < g->op_count && i < SG_MAX_OPS; i++) {
        sg_op_t *o = &g->ops[i];
        if (o->type == 3 && o->ptr) { free(o->ptr); o->ptr = NULL; }
        else if (o->type == 2 && o->img_id > 0) {
            img_release(o->img_id);
            o->img_id = 0;
        }
    }
    g->op_count = 0;
}

/* ---------- колбэки окна (задача WM) ---------- */

static void sg_draw(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, g->bg);

    /* СНИМОК списка ops под sg_lock: скриптовая задача (sgf_win_text и
     * др.) перестраивает список ПАР АЛЛЕЛЬНО отрисовке — без снимка
     * sg_draw мог увидеть полусобранный кадр (текст без фона и т.п.).
     * Копия дешёвая: до SG_MAX_OPS * sizeof(sg_op_t) ~ 3.5 КБ на стеке
     * потока окна (стек 16 КБ — помещается). */
    sg_op_t snap[SG_MAX_OPS];
    int snap_n = 0;
    s_lock(&sg_lock);
    snap_n = g->op_count;
    if (snap_n > SG_MAX_OPS) snap_n = SG_MAX_OPS;
    for (int i = 0; i < snap_n; i++) snap[i] = g->ops[i];
    s_unlock(&sg_lock);

    for (int i = 0; i < snap_n; i++) {
        sg_op_t *o = &snap[i];
        if (o->type == 0) {
            int x = o->x, y = o->y, ww = o->w, hh = o->h;
            if (x < 0) { ww += x; x = 0; }
            if (y < 0) { hh += y; y = 0; }
            if (x + ww > cw) ww = cw - x;
            if (y + hh > ch) hh = ch - y;
            if (ww > 0 && hh > 0) fb_fill_rect(x, y, ww, hh, o->color);
        } else if (o->type == 1) {
            if (o->y > -16 && o->y < ch && o->x < cw)
                fb_text(o->x, o->y, o->text, o->color, -1);
        } else if (o->type == 2 && o->img_id > 0) {
            /* сессия 55: картинка по дескриптору (refcount: живёт,
             * пока скрипт не позвал img_free — тогда op рискует быть
             * пустым, но не падает) */
            img_t t;
            if (img_retain(o->img_id) == 0 && img_get(o->img_id, &t) == 0) {
                if (t.rgba && t.w > 0 && t.h > 0)
                    fb_blit_rgba(t.rgba, t.w, t.h, o->x, o->y, t.w, t.h);
                img_release(o->img_id);
            }
        } else if (o->type == 3 && o->ptr) {
            /* масштабированная копия — собственность op'а */
            if (o->w > 0 && o->h > 0)
                fb_blit_rgba((const u8 *)o->ptr, o->w, o->h,
                             o->x, o->y, o->w, o->h);
        }
    }

    /* кнопки — как в редакторе скриптов */
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (!b->used) continue;
        u32 bgc = b->pressed ? fb_rgb(0x4A, 0x7F, 0xB0)
                : b->hot     ? fb_rgb(0x32, 0x60, 0x8E)
                : fb_rgb(0x25, 0x4A, 0x70);
        fb_fill_rect(b->x, b->y, b->w, b->h, bgc);
        fb_rect(b->x, b->y, b->w, b->h, wm_theme_accent());
        int tw = (int)strlen(b->label) * 8;
        int tx = (tw > b->w - 4) ? b->x + 2 : b->x + (b->w - tw) / 2;
        int ty = b->y + (b->h - 16) / 2 + 1;
        fb_text(tx, ty, b->label, wm_theme_text(), -1);
    }
}

static void sg_key(window_t *w, const key_event_t *ev) {
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) {   /* Esc */
        sg_win_t *g = (sg_win_t *)w->data;
        if (g) g->want_close = 1;
        win_close(w);
    }
}

static void sg_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;

    int btn = -1;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (b->used && mx >= b->x && mx < b->x + b->w &&
            my >= b->y && my < b->y + b->h) { btn = i; break; }
    }

    int redraw = 0;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        int h2 = (i == btn) ? 1 : 0;
        int p2 = (i == btn && (buttons & MSB_LEFT)) ? 1 : 0;
        if (b->hot != h2 || b->pressed != p2) {
            b->hot = h2; b->pressed = p2; redraw = 1;
        }
    }

    if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT) && btn >= 0) {
        s_lock(&sg_lock);
        g->last_click = btn;        /* ждёт btn_clicked() скрипта */
        s_unlock(&sg_lock);
    }
    if (redraw) win_invalidate(w);
}

static void sg_close(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    s_lock(&sg_lock);
    g->win = NULL;
    g->want_close = 1;
    s_unlock(&sg_lock);
    /* слот останется used до закрытия окна, чтобы дескриптор скрипта
     * оставался валидным для win_alive/btn_clicked (они вернут 0/-1) */
}

/* ---------- скриптовые функции (задача run'а) — JS-обёртки над c4k_* ----------
 * Движок окон sg_* и C-API c4k_* едины: c4-песочница (loader.c, kapi_t) и
 * JS-скрипты используют одни окна, кнопки и примитивы. */

static JSValue jsf_win_open(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *title = arg_str(ctx, argv[0], &sb);
    int id = c4k_win_open(title ? title : "Script window",
                          arg_int(ctx, argv[1], 100), arg_int(ctx, argv[2], 80),
                          arg_int(ctx, argv[3], 240), arg_int(ctx, argv[4], 200));
    return JS_NewInt32(ctx, id);
}

static JSValue jsf_win_close(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    c4k_win_close(arg_int(ctx, argv[0], -1));
    return JS_UNDEFINED;
}

static JSValue jsf_win_alive(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    return JS_NewBool(c4k_win_alive(arg_int(ctx, argv[0], -1)));
}

static JSValue jsf_win_clear(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    c4k_win_clear(arg_int(ctx, argv[0], -1), arg_color(ctx, argv[1]));
    return JS_UNDEFINED;
}

static JSValue jsf_win_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    c4k_win_rect(arg_int(ctx, argv[0], -1),
                 arg_int(ctx, argv[1], 0), arg_int(ctx, argv[2], 0),
                 arg_int(ctx, argv[3], 0), arg_int(ctx, argv[4], 0),
                 arg_color(ctx, argv[5]));
    return JS_UNDEFINED;
}

static JSValue jsf_win_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *s = arg_str(ctx, argv[3], &sb);
    c4k_win_text(arg_int(ctx, argv[0], -1),
                 arg_int(ctx, argv[1], 0), arg_int(ctx, argv[2], 0),
                 s ? s : "", arg_color(ctx, argv[4]));
    return JS_UNDEFINED;
}

static JSValue jsf_win_update(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    c4k_win_update(arg_int(ctx, argv[0], -1));
    return JS_UNDEFINED;
}

static JSValue jsf_btn_add(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *label = arg_str(ctx, argv[5], &sb);
    int n = c4k_btn_add(arg_int(ctx, argv[0], -1),
                        arg_int(ctx, argv[1], 0), arg_int(ctx, argv[2], 0),
                        arg_int(ctx, argv[3], 20), arg_int(ctx, argv[4], 16),
                        label ? label : "?");
    return JS_NewInt32(ctx, n);
}

static JSValue jsf_btn_clicked(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    return JS_NewInt32(ctx, c4k_btn_clicked(arg_int(ctx, argv[0], -1)));
}

static JSValue jsf_btn_set_label(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *label = arg_str(ctx, argv[2], &sb);
    c4k_btn_set_label(arg_int(ctx, argv[0], -1), arg_int(ctx, argv[1], -1),
                      label ? label : "?");
    return JS_UNDEFINED;
}

/* ---------- КАРТИНКИ (stb_image через imgsvc; прежде сессия 55) ---------- */

/* img_load(path) -> дескриптор или -1. ВНИМАНИЕ: сетевая загрузка
 * блокирующая (до 15 с) — скриптовая задача на это время спит. */
static JSValue jsf_img_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    JSCStringBuf sb;
    const char *path = arg_str(ctx, argv[0], &sb);
    img_t t;
    if (!path || !path[0] || img_decode_url(path, NULL, &t) != 0)
        return JS_NewInt32(ctx, -1);
    int id = img_open(&t);          /* владение rgba переходит дескриптору */
    if (id < 0) img_dispose(&t);
    return JS_NewInt32(ctx, id);
}

static JSValue jsf_img_free(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_release(arg_int(ctx, argv[0], -1));
    return JS_UNDEFINED;
}

static JSValue jsf_img_w(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(arg_int(ctx, argv[0], -1), &t) != 0)
        return JS_NewInt32(ctx, 0);
    return JS_NewInt32(ctx, t.w);
}

static JSValue jsf_img_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(arg_int(ctx, argv[0], -1), &t) != 0)
        return JS_NewInt32(ctx, 0);
    return JS_NewInt32(ctx, t.h);
}

/* img_pixel(id,x,y) -> 0xRRGGBB (альфа отброшена) или -1 */
static JSValue jsf_img_pixel(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    int x = arg_int(ctx, argv[1], 0), y = arg_int(ctx, argv[2], 0);
    if (img_get(arg_int(ctx, argv[0], -1), &t) != 0 || !t.rgba)
        return JS_NewInt32(ctx, -1);
    if (x < 0 || y < 0 || x >= t.w || y >= t.h)
        return JS_NewInt32(ctx, -1);
    const u8 *p = t.rgba + ((u32)y * (u32)t.w + (u32)x) * 4;
    return JS_NewInt32(ctx, ((int)p[0] << 16) | ((int)p[1] << 8) | (int)p[2]);
}

/* img_draw(id,x,y) — оригинальный размер, в текущую цель fb */
static JSValue jsf_img_draw(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(arg_int(ctx, argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     arg_int(ctx, argv[1], 0), arg_int(ctx, argv[2], 0), t.w, t.h);
    }
    return JS_UNDEFINED;
}

/* img_draw_scaled(id,x,y,w,h) — масштаб (nearest, безопасно без лока) */
static JSValue jsf_img_draw_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    int w = arg_int(ctx, argv[3], 0), h = arg_int(ctx, argv[4], 0);
    if (img_get(arg_int(ctx, argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0 && w > 0 && h > 0 && w <= 4096 && h <= 4096) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     arg_int(ctx, argv[1], 0), arg_int(ctx, argv[2], 0), w, h);
    }
    return JS_UNDEFINED;
}

/* win_img(id, img_id, x, y) — op держит ссылку img_retain */
static JSValue jsf_win_img(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    int id = arg_int(ctx, argv[0], -1);
    int iid = arg_int(ctx, argv[1], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && img_retain(iid) == 0) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 2;
            o->x = arg_int(ctx, argv[2], 0);
            o->y = arg_int(ctx, argv[3], 0);
            o->w = o->h = 0;
            o->color = 0;
            o->text[0] = 0;
            o->img_id = iid;
            o->ptr = NULL;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

/* win_img_scaled(id, img_id, x, y, w, h) — op владеет масштабированной
 * копией (билинейной, под локом imgsvc) — оригинал можно img_free */
static JSValue jsf_win_img_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    int id = arg_int(ctx, argv[0], -1);
    int iid = arg_int(ctx, argv[1], -1);
    int w = arg_int(ctx, argv[4], 0), h = arg_int(ctx, argv[5], 0);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && w > 0 && h > 0 &&
            w <= 4096 && h <= 4096) {
            img_t t, s;
            if (img_get(iid, &t) == 0 && t.rgba &&
                img_scale(&t, w, h, &s) == 0) {
                sg_op_t *o = &g->ops[g->op_count++];
                o->type = 3;
                o->x = arg_int(ctx, argv[2], 0);
                o->y = arg_int(ctx, argv[3], 0);
                o->w = s.w;
                o->h = s.h;
                o->color = 0;
                o->text[0] = 0;
                o->img_id = 0;
                o->ptr = s.rgba;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

/* ================= C-API для c4-песочницы (kapi_t / c4_gui_api) =====
 * Переехали из cmscript_api.c без изменений (сессия 64).
 */

int c4k_win_open(const char *title, int x, int y, int w, int h)
{
    if (w < 60) w = 60;
    if (h < 40) h = 40;
    if (w > 800) w = 800;
    if (h > 600) h = 600;

    int id = -1;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++)
        if (!g_sgw[k].used) { id = k; break; }
    if (id >= 0) {
        sg_win_t *g = &g_sgw[id];
        memset(g, 0, sizeof(*g));
        g->used = 1;
        g->last_click = -1;
        g->bg = wm_theme_win_bg();
        sg_copy_str(g->title, SG_TITLE_MAX, title ? title : "c4");
        g->win = win_create(g->title, x, y, w, h,
                            sg_draw, sg_key, sg_mouse, NULL, sg_close, g);
        if (!g->win) { g->used = 0; id = -1; }
    }
    s_unlock(&sg_lock);
    return id;
}

void c4k_win_close(int id)
{
    window_t *w = NULL;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used) {
        g_sgw[id].want_close = 1;
        w = g_sgw[id].win;
    }
    s_unlock(&sg_lock);
    if (w) win_close(w);            /* ВНЕ блокировки — см. шапку секции */
}

int c4k_win_alive(int id)
{
    int alive = 0;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used &&
        g_sgw[id].win && !g_sgw[id].want_close)
        alive = 1;
    s_unlock(&sg_lock);
    return alive;
}

void c4k_win_clear(int id, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        g->bg = color;
        sg_free_ops(g);
        g->last_click = -1;
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_rect(int id, int x, int y, int w, int h, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 0;
            o->x = x; o->y = y; o->w = w; o->h = h;
            o->color = color;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_text(int id, int x, int y, const char *s, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 1;
            o->x = x; o->y = y;
            o->w = o->h = 0;
            o->color = color;
            sg_copy_str(o->text, SG_TEXT_MAX, s ? s : "");
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_update(int id)
{
    sg_win_t *g = sg_lock_win(id);
    window_t *w = NULL;
    if (g) { w = g->win; sg_unlock_win(); }
    if (w) win_invalidate(w);
}

int c4k_btn_add(int id, int x, int y, int w, int h, const char *label)
{
    int ret = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        for (int i = 0; i < SG_MAX_BTNS; i++) {
            if (!g->btns[i].used) {
                sg_btn_t *b = &g->btns[i];
                b->used = 1;
                b->x = x; b->y = y;
                b->w = w > 0 ? w : 20;
                b->h = h > 0 ? h : 16;
                if (b->w < 8) b->w = 8;
                if (b->h < 8) b->h = 8;
                sg_copy_str(b->label, SG_LABEL_MAX, label ? label : "?");
                b->hot = 0;
                b->pressed = 0;
                ret = i;
                break;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return ret;
}

int c4k_btn_clicked(int id)
{
    int r = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        r = g->last_click;
        g->last_click = -1;         /* pop: читается один раз */
        sg_unlock_win();
    }
    return r;
}

void c4k_btn_set_label(int id, int btn, const char *label)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (btn >= 0 && btn < SG_MAX_BTNS && g->btns[btn].used) {
            sg_copy_str(g->btns[btn].label, SG_LABEL_MAX, label ? label : "?");
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

/* ================= расширенная таблица C-функций =================
 * Таблица стандарта (mqjs_stdlib.h) static — копируем её в хвост
 * BSS и добавляем свои функции. Префикс НЕ меняется: ROM-глобалы
 * (print/gc/Date/...) указывают на НЕИЗМЕНЁННЫЕ индексы, а мои
 * реализации js_print/js_gc/... линкуются вместо CLI mqjs.c.
 * name = JS_UNDEFINED — имя функции остаётся undefined (безопасно
 * для GC, проверено хост-харнесом). */

#define MQ_NDEFAULT ((int)(sizeof(js_c_function_table) / sizeof(js_c_function_table[0])))

#define MQ_UF(fn, nargs) { { .generic = (fn) }, JS_UNDEFINED, JS_CFUNC_generic, (nargs), 0 }

static const JSCFunctionDef mq_user_funcs[] = {
    MQ_UF(jsf_print_int,        1),
    MQ_UF(jsf_screen_width,     0),
    MQ_UF(jsf_screen_height,    0),
    MQ_UF(jsf_fill_rect,        5),
    MQ_UF(jsf_draw_text,        4),
    MQ_UF(jsf_get_color,        3),
    MQ_UF(jsf_clear_screen,     1),
    MQ_UF(jsf_flip,             0),
    MQ_UF(jsf_delay,            1),
    MQ_UF(jsf_uptime,           0),
    MQ_UF(jsf_strlen,           1),
    MQ_UF(jsf_ramfs_read,       1),
    MQ_UF(jsf_ramfs_write,      2),
    MQ_UF(jsf_ramfs_list,       0),
    MQ_UF(jsf_win_open,         5),
    MQ_UF(jsf_win_close,        1),
    MQ_UF(jsf_win_alive,        1),
    MQ_UF(jsf_win_clear,        2),
    MQ_UF(jsf_win_rect,         6),
    MQ_UF(jsf_win_text,         5),
    MQ_UF(jsf_win_update,       1),
    MQ_UF(jsf_btn_add,          6),
    MQ_UF(jsf_btn_clicked,      1),
    MQ_UF(jsf_btn_set_label,    3),
    MQ_UF(jsf_img_load,         1),
    MQ_UF(jsf_img_free,         1),
    MQ_UF(jsf_img_w,            1),
    MQ_UF(jsf_img_h,            1),
    MQ_UF(jsf_img_pixel,        3),
    MQ_UF(jsf_img_draw,         3),
    MQ_UF(jsf_img_draw_scaled,  5),
    MQ_UF(jsf_win_img,          4),
    MQ_UF(jsf_win_img_scaled,   6),
};

#define MQ_NUSER ((int)(sizeof(mq_user_funcs) / sizeof(mq_user_funcs[0])))

static const char *const mq_user_names[MQ_NUSER] = {
    "print_int", "screen_width", "screen_height",
    "fill_rect", "draw_text", "get_color", "clear_screen", "flip",
    "delay", "uptime", "strlen",
    "ramfs_read", "ramfs_write", "ramfs_list",
    "win_open", "win_close", "win_alive", "win_clear", "win_rect",
    "win_text", "win_update", "btn_add", "btn_clicked", "btn_set_label",
    "img_load", "img_free", "img_w", "img_h", "img_pixel",
    "img_draw", "img_draw_scaled", "win_img", "win_img_scaled",
};

static JSCFunctionDef  g_mq_table[MQ_NDEFAULT + MQ_NUSER];
static JSSTDLibraryDef g_mq_stdlib;
static int             g_mq_table_ready = 0;

static void mq_build_table(void)
{
    if (g_mq_table_ready) return;
#ifndef __LP64__
    /* i386 (ядро): ROM-значения таблиц нельзя записать константами
     * (cast ptr->u64 при -fno-pic не является константным выражением) —
     * прописываем их рантайм-фикступом ОДИН раз до JS_NewContext.
     * Таблица объявлена не-const (i386-ветка mqjs_stdlib.h, .data). */
    {
        u32 n = (u32)(sizeof(js_rom_fixups_tab) / sizeof(js_rom_fixups_tab[0]));
        for (u32 i = 0; i < n; i++) {
            js_stdlib_table[js_rom_fixups_tab[i][0]] =
                (JSWord)(uintptr_t)&js_stdlib_table[js_rom_fixups_tab[i][1]] + 1;
        }
    }
#endif
    memcpy(g_mq_table, js_c_function_table, sizeof(js_c_function_table));
#ifndef __LP64__
    {
        u32 n = (u32)(sizeof(js_rom_fixups_cft) / sizeof(js_rom_fixups_cft[0]));
        for (u32 i = 0; i < n; i++) {
            g_mq_table[js_rom_fixups_cft[i][0]].name =
                (JSWord)(uintptr_t)&js_stdlib_table[js_rom_fixups_cft[i][1]] + 1;
        }
    }
#endif
    memcpy(g_mq_table + MQ_NDEFAULT, mq_user_funcs, sizeof(mq_user_funcs));
    g_mq_stdlib = js_stdlib;
    g_mq_stdlib.c_function_table = g_mq_table;
    g_mq_table_ready = 1;
}

/* ================= запуск скрипта ================= */

/* Кооперативность: движок зовёт обработчик каждые ~10000 операций
 * (JS_INTERRUPT_COUNTER_INIT) — крутим task_yield, чтобы чисто-JS
 * цикл не вешал систему. Прерывание скрипта пользователем не
 * предусмотрено (как и в CMScript) — всегда возвращаем 0. */
static int mq_interrupt_handler(JSContext *ctx, void *opaque)
{
    (void)ctx; (void)opaque;
    task_yield();
    return 0;
}

/* write_func движка: сюда попадают дампы ошибок (JS_PrintValueF) и
 * диагностика js_printf — в тот же буфер, что и print(). */
static void mq_write_func(void *opaque, const void *buf, size_t len)
{
    (void)opaque;
    mq_putn((const char *)buf, (u32)len);
}

/* Сериализация: движок — один глобальный регион/контекст на запуск.
 * Вызывается задачей запуска (как прежде cs_run_task), таких может
 * быть несколько — обёртка mqjs_run сериализует спинлоком. */
static volatile int mq_run_lock = 0;

static int mqjs_run_impl(const char *src, char *out, u32 out_max)
{
    /* Регион движка: [ctx | heap ... | стек VM]. 512 КиБ хватает с
     * запасом для скриптов ОС; GC внутри региона — ядро не участвует. */
    u32 region_size = 512 * 1024;
    u8 *region = (u8 *)malloc(region_size);
    if (!region) {
        if (out && out_max) {
            const char *err = "QuickJS: не хватает памяти под регион движка\n";
            u32 n = (u32)strlen(err);
            if (n >= out_max) n = out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        return -1;
    }
    memset(region, 0, region_size);

    mq_build_table();

    JSContext *ctx = JS_NewContext(region, region_size, &g_mq_stdlib);
    if (!ctx) {
        free(region);
        if (out && out_max) {
            const char *err = "QuickJS: JS_NewContext не удался\n";
            u32 n = (u32)strlen(err);
            if (n >= out_max) n = out_max - 1;
            memcpy(out, err, n);
            out[n] = 0;
        }
        return -1;
    }

    JS_SetLogFunc(ctx, mq_write_func);
    JS_SetInterruptHandler(ctx, mq_interrupt_handler);
    JS_SetRandomSeed(ctx, timer_ticks() | 1);

    /* установка host-функций ОС в global */
    JSValue global = JS_GetGlobalObject(ctx);
    for (int i = 0; i < MQ_NUSER; i++) {
        JSValue f = JS_NewCFunctionParams(ctx, MQ_NDEFAULT + i, JS_UNDEFINED);
        if (JS_SetPropertyStr(ctx, global, mq_user_names[i], f) < 0) {
            mq_puts("QuickJS: не удалось установить ");
            mq_puts(mq_user_names[i]);
            mq_putc('\n');
            break;
        }
    }

    JSValue val = JS_Eval(ctx, src, strlen(src), "script.js", 0);
    int rc = 0;
    if (JS_IsException(val)) {
        rc = -1;
        JSValue exc = JS_GetException(ctx);
        JSValue msg = JS_GetPropertyStr(ctx, exc, "message");
        mq_puts("Ошибка: ");
        if (JS_IsString(ctx, msg)) {
            JSCStringBuf sb;
            size_t len = 0;
            const char *m = JS_ToCStringLen(ctx, &len, msg, &sb);
            if (m) mq_putn(m, (u32)len);
        } else {
            /* не Error-объект — дамп значения через write_func */
            JS_PrintValueF(ctx, exc, JS_DUMP_LONG);
        }
        mq_putc('\n');
    }

    JS_FreeContext(ctx);
    free(region);

    if (out && out_max) out[out_max - 1] = 0;   /* на случай переполнения */
    return rc;
}

int mqjs_run(const char *src, char *out, u32 out_max)
{
    int rc;
    s_lock(&mq_run_lock);
    g_mq_out = out;
    g_mq_out_pos = 0;
    g_mq_out_max = out_max;
    if (out && out_max) out[0] = 0;
    rc = mqjs_run_impl(src, out, out_max);
    if (out && g_mq_out_pos < out_max) out[g_mq_out_pos] = 0;
    s_unlock(&mq_run_lock);
    return rc;
}

/* ================= таблица для VM-пути c4.c ================= */

/* Таблица для VM-пути c4.c (интерпретатор): c4_gui_api глобально
 * инициализируется в kapi_fill (loader.c). */
static c4_gui_api_t g_c4_gui = {
    c4k_win_open, c4k_win_close, c4k_win_alive, c4k_win_clear,
    c4k_win_rect, c4k_win_text, c4k_win_update,
    c4k_btn_add, c4k_btn_clicked, c4k_btn_set_label
};

void c4_gui_init(void)
{
    c4_gui_api = &g_c4_gui;
}
