#!/bin/bash
# Сборка и запуск хост-репро httpd (сессия 60): net.c + net_httpd.c на
# хосте против loopback-пары стека, RAM disk — заглушка в тесте.
cd "$(dirname "$0")"
SRC=${SRC:-../../src}
# убрать копии/редиректы, оставленные run_tcpnet.sh в ЭТОМ каталоге:
# quoted-include файлов теста резолвится в каталог исходника ПЕРВЫМ,
# и libc-редиректы (string.h/mem.h) конфликтуют с заглушками stubs_net
rm -f mem.h string.h sync.h task.h timer.h limits.h ramfs.h \
      net.c net.h net_http.c net_httpd.c net_tls.h net_httpd.h types.h \
      e1000.h ne2000.h virtio_net.h ath9k_wifi.h atl1c.h
mkdir -p build_host
ln -sf "$(pwd)/$SRC/net.c"        build_host/net.c
ln -sf "$(pwd)/$SRC/net_http.c"   build_host/net_http.c
ln -sf "$(pwd)/$SRC/net_dns.c"    build_host/net_dns.c
ln -sf "$(pwd)/$SRC/net_httpd.c"  build_host/net_httpd.c
cp -f stubs_net/sync_host.h       build_host/sync.h

COMMON="-std=c99 -Wall -Wextra -I stubs_net -I $SRC"
FILES="httpd60_test.c fake_nic.c stubs_net/tls_stubs.c build_host/net.c build_host/net_http.c \
       build_host/net_dns.c build_host/net_httpd.c $SRC/string.c"

FAIL=0
gcc $COMMON -g -O1 $FILES -o httpd60_test 2>build_httpd.log || { grep error build_httpd.log | head; exit 1; }
W=$(grep -c warning build_httpd.log); echo "предупреждений: $W"
./httpd60_test || FAIL=1

if gcc $COMMON -g -O1 -fsanitize=address,undefined $FILES \
      -o httpd60_test_asan 2>>build_httpd.log; then
    ./httpd60_test_asan >/dev/null 2>asan_httpd.log
    RC=$?
    if [ $RC -ne 0 ] && grep -q "AddressSanitizer\|runtime error" asan_httpd.log; then
        echo "=== ASAN/UBSAN НАШЁЛ ПРОБЛЕМЫ ==="; head -25 asan_httpd.log; FAIL=1
    else
        echo "ASan/UBSan: чисто"
    fi
fi
exit $FAIL
