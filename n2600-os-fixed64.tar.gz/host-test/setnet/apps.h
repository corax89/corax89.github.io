/* apps.h — реестр приложений N2600-OS.
 *
 * КАК ДОБАВИТЬ СВОЁ ПРИЛОЖЕНИЕ:
 *   1) создайте src/my_app.c по образцу src/apps_games.c (окно + значок
 *      в лаунчере «Игры») или любого другого src/apps_*.c;
 *   2) добавьте строку в app_table[] ниже (src/apps.c);
 *   3) соберите проект build.bat — всё, приложение появится в меню.
 */
#ifndef APPS_H
#define APPS_H

#include "types.h"   /* u32 для app_outwin_open */
#include "filedlg.h" /* fd_source_t (сессия 14: app_editor_open_at) */

typedef struct {
    const char *name;   /* название в меню «Пуск» */
    void (*open_fn)(void);
} app_def_t;

extern const app_def_t app_table[];
extern const int app_table_count;

void apps_open(int idx);
void apps_launch(void (*fn)(void));  /* сессия 22: запуск с окном ошибки при OOM */

/* встроенные приложения */
void app_about_open(void);
void app_term_open(void);
void app_sysinfo_open(void);
void app_files_open(void);   /* файловый менеджер FAT32 */
void app_games_open(void);     /* «Игры»: лаунчер со значками игр */
void app_mines_open(void);     /* «Сапёр» (уровень 1 по умолчанию) */
void app_mines_open_at(int level);  /* 1..3 — 13x13/16x16/21x21 */
void app_checkers_open(void);  /* «Шашки»: GUI-порт с ИИ (chk_game.h) */
void app_editor_open(void);    /* текстовый редактор + компиляция c4 */
void app_editor_open_with(const char *filename, const char *content, int len);
/* СЕССИЯ 14: универсальный текстовый редактор — открыть файл прямо
 * в его каталоге на его диске (RAM-иерархия / HDD / USB FAT32). */
void app_editor_open_at(fd_source_t src, const char *dir, u32 dir_cluster,
                        const char *name, const char *content, int len);
void app_quickjs_open(void);   /* QuickJS-редактор + запуск .js (сессия 64) */
void app_quickjs_open_with(const char *filename, const char *content, int len);
void app_taskmgr_open(void);    /* диспетчер задач */
void app_wifi_open(void);      /* WiFi сканер */
void app_browser_open(void);   /* веб-браузер (HTML→Markdown→рендер) */
void app_browser_open_with(const char *url, const char *content, int len);
void app_nettrace_open(void);  /* HTTP Trace: трассировка запроса/ответа */
void app_settings_open(void); /* Настройки: сеть/WiFi/система (сессия 11) */

/* Сессия 60: MP3-плеер (dr_mp3 + потоковый вывод) и просмотрщик
 * картинок (imgsvc/stb_image). Оба открываются двойным кликом в
 * «Файлах» (.mp3 и .png/.jpg/.jpeg/.bmp/.gif соответственно) через
 * *_open_with — владение буфером data ПЕРЕХОДИТ приложению (оно
 * вызывает free(data) само; вызывающий буфер не освобождает). */
void app_mp3_open(void);       /* из лаунчера: подсказка */
void app_mp3_open_with(const char *filename, const char *data, u32 len);
void app_imgview_open(void);   /* из лаунчера: подсказка */
void app_imgview_open_with(const char *filename, const char *data, u32 len);

/* Окно текстового вывода (используется редактором F9 и loader'ом
 * для вывода нативных c4-программ, запущенных через `run`). */
void app_outwin_open(const char *title, const char *text, u32 len);

/* Запустить приложение по имени (для вызова из других приложений).
 * Возвращает 1 при успехе, 0 если не найдено. */
int app_spawn_by_name(const char *name);

/* Открыть приложение по индексу в app_table */
void apps_open(int idx);

/* информация о CPU для приложений (заполняется лениво) */
void cpu_get_brand(char out[52]);
void cpu_get_vendor(char out[16]);
int  cpu_get_cores(void);

#endif /* APPS_H */
