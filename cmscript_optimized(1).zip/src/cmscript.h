/* cmscript.h — заголовок для встроенного CMScript интерпретатора.
 *
 * CMScript — скриптовый язык от SUNSETDEVER (Apache-2.0), портирован
 * под freestanding N2600-OS. Регистрирует host-функции для доступа
 * к API ОС: окна, кнопки, файлы, графика.
 *
 * API для .cs-скриптов:
 *   print(str)              — вывод текста в буфер run'а
 *   print_int(n)            — вывод числа
 *   screen_width()          — ширина экрана
 *   screen_height()         — высота экрана
 *   fill_rect(x,y,w,h,c)    — заливка прямоугольника
 *   draw_text(x,y,str,color)— вывод текста
 *   get_color(r,g,b)        — получить цвет
 *   clear_screen(color)     — очистка экрана
 *   flip()                  — перерисовка экрана
 *   delay(ms)               — задержка
 *   uptime()                — время работы в секундах
 *
 * GUI из скрипта (окна и кнопки):
 *   win_open(title, x, y, w, h)      -> дескриптор окна или -1
 *   win_close(id) / win_alive(id)    -> закрыть / 1 пока открыто
 *   win_clear(id, color)             — очистить окно цветом
 *   win_rect(id, x, y, w, h, color)  — прямоугольник в окне
 *   win_text(id, x, y, text, color)  — текст в окне (шрифт 8x16)
 *   win_update(id)                   — перерисовать окно сейчас
 *   btn_add(id, x, y, w, h, label)   -> номер кнопки или -1
 *   btn_clicked(id)                  -> номер нажатой кнопки или -1
 *   btn_set_label(id, btn, label)    — сменить надпись кнопки
 */
#ifndef CMSCRIPT_H
#define CMSCRIPT_H

#include "types.h"

/* Запустить .cs-скрипт. Возвращает 0 при успехе, -1 при ошибке.
 * src     — NUL-terminated исходник.
 * out     — буфер под вывод (print/print_int).
 * out_max — размер буфера out. */
int cmscript_run(const char *src, char *out, u32 out_max);

#endif /* CMSCRIPT_H */
