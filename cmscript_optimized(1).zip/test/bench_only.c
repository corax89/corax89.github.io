#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef unsigned char u8; typedef unsigned int u32; typedef long long i64;
unsigned long timer_ticks(void) { return (unsigned long)clock(); }
char* strcat(char* d, const char* s){char*r=d;while(*d)d++;while((*d++=*s++));return r;}
char* strstr(const char* h, const char* n){if(!*n)return(char*)h;for(;*h;h++){const char*a=h,*b=n;while(*a&&*b&&*a==*b){a++;b++;}if(!*b)return(char*)h;}return 0;}
enum { CDM_TYPE_INT=0, CDM_TYPE_FLOAT, CDM_TYPE_PTR, CDM_TYPE_STRUCT, CDM_TYPE_ARRAY, CDM_TYPE_STRING, CDM_TYPE_REF };
typedef struct { int type; int struct_id; int array_len; int array_dim; int array_sizes[4]; int array_elem_type; int array_elem_struct_id; int owned; int from_new; union { long long i; double f; void* p; } v; } CDM_Value_t;
typedef CDM_Value_t (*CDM_HostFuncEx_t)(int, CDM_Value_t*);
extern void CDM_RegisterHostFuncEx(const char*, CDM_HostFuncEx_t);
extern char* CDM_Preprocess(const char*);
extern void* CDM_Parse(const char*);
extern int CDM_Execute(void*);
extern void CDM_FreeAST(void*);
extern int CDM_GetErrorCount(void);
extern void CDM_ClearErrors(void);
extern void CMScript_Init(void);
static CDM_Value_t h_print_int(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r,0,sizeof(r)); r.type=CDM_TYPE_INT; r.struct_id=-1; r.array_elem_struct_id=-1;
    if (argc>=1){ CDM_Value_t v=argv[0]; if(v.type==CDM_TYPE_REF) v=*(CDM_Value_t*)v.v.p; }
    return r;
}
static CDM_Value_t h_add3(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r,0,sizeof(r)); r.type=CDM_TYPE_INT; r.struct_id=-1; r.array_elem_struct_id=-1;
    long long s=0; for (int i=0;i<argc;i++){ CDM_Value_t v=argv[i]; if(v.type==CDM_TYPE_REF) v=*(CDM_Value_t*)v.v.p; s+=v.v.i; }
    r.v.i=s; return r;
}
static void run(const char* src) {
    CDM_ClearErrors();
    char* pre = CDM_Preprocess(src);
    if (!pre || CDM_GetErrorCount()) { printf(" PP-ERR"); free(pre); return; }
    void* ast = CDM_Parse(pre);
    free(pre);
    if (!ast || CDM_GetErrorCount()) { printf(" PARSE-ERR"); if (ast) CDM_FreeAST(ast); return; }
    CDM_Execute(ast);
    CDM_FreeAST(ast);
}
static double bench(const char* name, const char* src, int runs) {
    double best = 1e9;
    for (int r = 0; r < runs; r++) {
        clock_t t0 = clock();
        run(src);
        clock_t t1 = clock();
        double ms = (double)(t1 - t0) * 1000.0 / CLOCKS_PER_SEC;
        if (ms < best) best = ms;
    }
    printf("%-42s %8.2f ms\n", name, best);
    return best;
}
int main(void) {
    setbuf(stdout, NULL);
    CDM_RegisterHostFuncEx("print_int", h_print_int);
    CDM_RegisterHostFuncEx("add3", h_add3);
    CMScript_Init();
    bench("fib(15) recursive",
        "int fib(int n) { if (n < 2) return n; return fib(n - 1) + fib(n - 2); }"
        "int main() { print_int(fib(15)); return 0; }", 5);
    bench("loop 1M (sum+compare+assign)",
        "int main() { int s = 0; int i = 0; while (i < 1000000) { s = s + i; i = i + 1; }"
        " print_int(s); return 0; }", 5);
    bench("string concat x3000",
        "int main() { char* s = \"\"; for (int i = 0; i < 3000; i = i + 1)"
        " { s = s + \"ab\"; } print_int(strlen(s)); return 0; }", 5);
    bench("sprintf x20000",
        "int main() { char* buf = \"\"; int s = 0; for (int i = 0; i < 20000; i = i + 1)"
        " { sprintf(buf, \"%d\", i); s = s + 1; } print_int(s); return 0; }", 5);
    bench("host call x100000",
        "int main() { int s = 0; for (int i = 0; i < 100000; i = i + 1)"
        " { s = s + add3(i, 1, 2); } print_int(s); return 0; }", 5);
    bench("mixed: loop w/ locals+shadow x200k",
        "int main() { int s = 0; for (int i = 0; i < 200000; i = i + 1)"
        " { int t = i; { int t2 = t + 1; s = s + t2; } } print_int(s); return 0; }", 5);
    return 0;
}
