/* Заглушка string.h N2600-OS — сигнатуры как в ОС (unsigned long вместо size_t) */
#ifndef STUB_STRING_H
#define STUB_STRING_H
unsigned long strlen(const char*);
int   strcmp(const char*, const char*);
int   strncmp(const char*, const char*, unsigned long);
char* strncpy(char*, const char*, unsigned long);
char* strcpy(char*, const char*);
char* strcat(char*, const char*);
char* strchr(const char*, int);
char* strstr(const char*, const char*);
void* memcpy(void*, const void*, unsigned long);
void* memset(void*, int, unsigned long);
int   memcmp(const void*, const void*, unsigned long);
#endif
