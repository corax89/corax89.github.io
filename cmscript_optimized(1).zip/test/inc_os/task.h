#ifndef STUB_TASK_H
#define STUB_TASK_H
void task_yield(void);
#endif
