#ifndef STUB_FB_H
#define STUB_FB_H
typedef unsigned int u32;
unsigned int fb_width(void);
unsigned int fb_height(void);
unsigned int fb_rgb(int r, int g, int b);
void fb_fill_rect(int x, int y, int w, int h, unsigned int c);
void fb_fill_screen(unsigned int c);
void fb_rect(int x, int y, int w, int h, unsigned int c);
void fb_text(int x, int y, const char* s, unsigned int c);
void fb_flush(void);
void fb_touch_all(void);
#endif
