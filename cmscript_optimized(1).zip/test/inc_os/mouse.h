#ifndef STUB_MOUSE_H
#define STUB_MOUSE_H
#define MSB_LEFT 1
#endif
