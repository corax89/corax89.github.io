#ifndef STUB_RAMFS_H
#define STUB_RAMFS_H
int  ramfs_read(const char* name, unsigned char* buf, int max);
int  ramfs_write(const char* name, const unsigned char* buf, int len);
int  ramfs_list(char* out, int max);
int  ramfs_create(const char* name);
int  ramfs_delete(const char* name);
#endif
