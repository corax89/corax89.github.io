#ifndef STUB_TIMER_H
#define STUB_TIMER_H
unsigned long timer_ticks(void);
#endif
