#ifndef STUB_WM_H
#define STUB_WM_H
#include "types.h"
unsigned int wm_theme_accent(void);
unsigned int wm_theme_text(void);
unsigned int wm_theme_win_bg(void);
/* simplified GUI structs — только то, что трогает cmscript_api.c */
#define SG_LABEL_MAX 32
#define SG_MAX_OPS 64
typedef struct { int used; int x, y, w, h; char label[SG_LABEL_MAX]; } sg_btn_t;
typedef struct { int used; int x, y, w, h; int nops; } sg_op_t;
typedef struct { int used; int x, y, w, h; int nbtns; sg_btn_t btns[8]; int nops; sg_op_t ops[SG_MAX_OPS]; int cur; } sg_win_t;
void sg_lock(void);
void sg_unlock(void);
void sg_lock_win(int id);
void sg_unlock_win(int id);
void sg_repaint(void* g);
void sg_draw(int id, int op, int a, int b, int c, unsigned int color, const char* s);
void sg_key(int id, int key);
void sg_mouse(int id, int mx, int my, int buttons);
void sg_copy_str(char* dst, int max, const char* src);
int  sg_close(int id);
#endif
