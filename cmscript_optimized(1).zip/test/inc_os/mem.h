#ifndef STUB_MEM_H
#define STUB_MEM_H
void* malloc(unsigned long);
void  free(void*);
void* calloc(unsigned long, unsigned long);
void* realloc(void*, unsigned long);
#endif
