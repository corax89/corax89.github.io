#ifndef STUB_SYNC_H
#define STUB_SYNC_H
void s_lock(volatile int* l);
void s_unlock(volatile int* l);
#endif
