#ifndef STUB_CMSCRIPT_H
#define STUB_CMSCRIPT_H
#include "types.h"
int cmscript_run(const char *src, char *out, u32 out_max);
#endif
