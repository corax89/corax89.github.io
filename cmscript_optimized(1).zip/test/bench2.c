/* bench2.c — бенчмарки арены и кэша символов: парсинг+освобождение
 * большого скрипта, чтение переменной чужого кадра. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef unsigned char u8; typedef unsigned int u32; typedef long long i64;
unsigned long timer_ticks(void) { return (unsigned long)clock(); }
char* strcat(char* d, const char* s){char*r=d;while(*d)d++;while((*d++=*s++));return r;}
char* strstr(const char* h, const char* n){if(!*n)return(char*)h;for(;*h;h++){const char*a=h,*b=n;while(*a&&*b&&*a==*b){a++;b++;}if(!*b)return(char*)h;}return 0;}
enum { CDM_TYPE_INT=0, CDM_TYPE_FLOAT, CDM_TYPE_PTR, CDM_TYPE_STRUCT, CDM_TYPE_ARRAY, CDM_TYPE_STRING, CDM_TYPE_REF };
typedef struct { int type; int struct_id; int array_len; int array_dim; int array_sizes[4]; int array_elem_type; int array_elem_struct_id; int owned; int from_new; union { long long i; double f; void* p; } v; } CDM_Value_t;
typedef CDM_Value_t (*CDM_HostFuncEx_t)(int, CDM_Value_t*);
extern void CDM_RegisterHostFuncEx(const char*, CDM_HostFuncEx_t);
extern char* CDM_Preprocess(const char*);
extern void* CDM_Parse(const char*);
extern int CDM_Execute(void*);
extern void CDM_FreeAST(void*);
extern int CDM_GetErrorCount(void);
extern void CDM_ClearErrors(void);
extern void CMScript_Init(void);

static CDM_Value_t h_print_int(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r,0,sizeof(r)); r.type=CDM_TYPE_INT; r.struct_id=-1; r.array_elem_struct_id=-1;
    (void)argc; (void)argv; return r;   /* вывод не нужен — чистый тайминг */
}

static char* gen_big(int nfuncs) {
    size_t cap = 1u << 22;
    char* s = (char*)malloc(cap);
    size_t o = 0;
    for (int f = 0; f < nfuncs; f++) {
        o += (size_t)sprintf(s + o,
            "int fn%d(int x, int y) { int a = x + y + %d; int b = a * 2 - y;"
            " int c[6] = { 1, 2, 3, 4, 5, 6 };"
            " if (a > b) { c[0] = a; } else { c[1] = b; }"
            " int i = 0; int s = 0;"
            " while (i < 6) { s = s + c[i] + a * i - b; i = i + 1; }"
            " switch (x & 3) { case 0: s = s + 1; break; case 1: s = s + 2; break;"
            " default: s = s + 3; }"
            " return s; }\n", f, f);
        if (o > cap - 8192) break;
    }
    o += (size_t)sprintf(s + o, "int main() { return fn0(1, 2); }\n");
    return s;
}

/* Парсинг+освобождение без Execute: чистая стоимость front-end */
static double bench_parse(const char* name, char* src, int runs) {
    double best = 1e9;
    for (int r = 0; r < runs; r++) {
        clock_t t0 = clock();
        CDM_ClearErrors();
        char* pre = CDM_Preprocess(src);
        void* ast = CDM_Parse(pre);
        free(pre);
        if (ast) CDM_FreeAST(ast);
        clock_t t1 = clock();
        double ms = (double)(t1 - t0) * 1000.0 / CLOCKS_PER_SEC;
        if (ms < best) best = ms;
    }
    printf("%-46s %8.2f ms\n", name, best);
    return best;
}

static double bench_exec(const char* name, const char* src, int runs) {
    double best = 1e9;
    for (int r = 0; r < runs; r++) {
        clock_t t0 = clock();
        CDM_ClearErrors();
        char* pre = CDM_Preprocess(src);
        void* ast = CDM_Parse(pre);
        free(pre);
        CDM_Execute(ast);
        CDM_FreeAST(ast);
        clock_t t1 = clock();
        double ms = (double)(t1 - t0) * 1000.0 / CLOCKS_PER_SEC;
        if (ms < best) best = ms;
    }
    printf("%-46s %8.2f ms\n", name, best);
    return best;
}

int main(void) {
    setbuf(stdout, NULL);
    CDM_RegisterHostFuncEx("print_int", h_print_int);
    CMScript_Init();

    /* <64 КБ: старый PP режет вывод на 64 КБ — сравниваем на скрипте,
     * который оригинал тоже парсит ЦЕЛИКОМ (~48 КБ, 150 функций) */
    char* fair = gen_big(150);
    printf("fair script: %u bytes\n", (unsigned)strlen(fair));
    bench_parse("parse+free 150-func script x1", fair, 9);

    /* >64 КБ: только новая версия (старый PP молча резал на 64 КБ) */
    char* big = gen_big(1500);
    printf("big script: %u bytes\n", (unsigned)strlen(big));
    bench_parse("parse+free big script x1 (new cap)", big, 7);
    free(big);

    bench_exec("cross-frame read x200k (global from fn)",
        "int get() { return gcounter; }"
        "int main() { gcounter = 0; int i = 0; int s = 0;"
        " while (i < 200000) { s = s + get(); gcounter = gcounter + 1; i = i + 1; }"
        " print_int(s); return 0; }", 5);

    bench_exec("local read x1M (slot path, regression)",
        "int main() { int g = 7; int i = 0; int s = 0;"
        " while (i < 1000000) { s = s + g; i = i + 1; } print_int(s); return 0; }", 5);

    bench_exec("enum read x500k (regression)",
        "enum E { VAL = 42 };"
        "int main() { int i = 0; int s = 0;"
        " while (i < 500000) { s = s + VAL; i = i + 1; } print_int(s); return 0; }", 5);

    return 0;
}
