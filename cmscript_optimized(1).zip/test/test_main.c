/* test_main.c — стенд для проверки CMScript вне ОС.
 * Эмулирует интеграцию cmscript_api.c: регистрирует host-функции,
 * гоняет скрипты через Preprocess->Parse->Execute, сверяет вывод. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ---- типы как в ОС ---- */
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long long u64;
typedef int i32;
typedef long long i64;

unsigned long timer_ticks(void) { return (unsigned long)clock(); }

/* strcat/strstr — по замечанию в шапке cmscript.c живут в string.c хоста */
char* strcat(char* dst, const char* src) {
    char* r = dst;
    while (*dst) dst++;
    while ((*dst++ = *src++));
    return r;
}
char* strstr(const char* h, const char* n) {
    if (!*n) return (char*)h;
    for (; *h; h++) {
        const char* a = h; const char* b = n;
        while (*a && *b && *a == *b) { a++; b++; }
        if (!*b) return (char*)h;
    }
    return 0;
}

/* ---- CDM_Value_t — точная копия из cmscript.c ---- */
enum { CDM_TYPE_INT = 0, CDM_TYPE_FLOAT, CDM_TYPE_PTR, CDM_TYPE_STRUCT,
       CDM_TYPE_ARRAY, CDM_TYPE_STRING, CDM_TYPE_REF };
typedef struct {
    int type;
    int struct_id;
    int array_len;
    int array_dim;
    int array_sizes[4];
    int array_elem_type;
    int array_elem_struct_id;
    int owned;
    int from_new;
    union { long long i; double f; void* p; } v;
} CDM_Value_t;
typedef CDM_Value_t (*CDM_HostFuncEx_t)(int argc, CDM_Value_t* argv);

extern void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);
extern void CDM_RegisterHostFunc(const char* name, int (*fn)(int, const char**));
extern char* CDM_Preprocess(const char* src);
extern void* CDM_Parse(const char* src);
extern int   CDM_Execute(void* root);
extern void  CDM_FreeAST(void* root);
extern int   CDM_GetErrorCount(void);
extern const void* CDM_GetError(int idx);
extern void  CDM_ClearErrors(void);
extern void  CMScript_Init(void);

/* ---- вывод скрипта ---- */
static char out_buf[65536];
static int  out_pos = 0;

static CDM_Value_t h_print_int(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT; r.struct_id = -1; r.array_elem_struct_id = -1;
    if (argc >= 1) {
        long long v = (argv[0].type == CDM_TYPE_REF)
            ? ((CDM_Value_t*)argv[0].v.p)->v.i : argv[0].v.i;
        out_pos += sprintf(out_buf + out_pos, "%lld", v);
    }
    return r;
}
static CDM_Value_t h_print_float(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT; r.struct_id = -1; r.array_elem_struct_id = -1;
    if (argc >= 1) {
        double d = (argv[0].type == CDM_TYPE_REF)
            ? ((CDM_Value_t*)argv[0].v.p)->v.f : argv[0].v.f;
        out_pos += sprintf(out_buf + out_pos, "%g", d);
    }
    return r;
}
static CDM_Value_t h_print(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT; r.struct_id = -1; r.array_elem_struct_id = -1;
    if (argc >= 1) {
        CDM_Value_t v = argv[0];
        if (v.type == CDM_TYPE_REF) v = *(CDM_Value_t*)v.v.p;
        if (v.type == CDM_TYPE_STRING && v.v.p)
            out_pos += sprintf(out_buf + out_pos, "%s", (const char*)v.v.p);
        else if (v.type == CDM_TYPE_FLOAT)
            out_pos += sprintf(out_buf + out_pos, "%g", v.v.f);
        else
            out_pos += sprintf(out_buf + out_pos, "%lld", v.v.i);
    }
    return r;
}
static CDM_Value_t h_add(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT; r.struct_id = -1; r.array_elem_struct_id = -1;
    long long s = 0;
    for (int i = 0; i < argc; i++) {
        CDM_Value_t v = argv[i];
        if (v.type == CDM_TYPE_REF) v = *(CDM_Value_t*)v.v.p;
        s += v.v.i;
    }
    r.v.i = s;
    return r;
}
static CDM_Value_t h_strlen(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT; r.struct_id = -1; r.array_elem_struct_id = -1;
    if (argc >= 1) {
        CDM_Value_t v = argv[0];
        if (v.type == CDM_TYPE_REF) v = *(CDM_Value_t*)v.v.p;
        r.v.i = (v.type == CDM_TYPE_STRING && v.v.p) ? (long long)strlen((const char*)v.v.p) : 0;
    }
    return r;
}

/* ---- инфраструктура тестов ---- */
static int tests_run = 0, tests_failed = 0;

static void run_script(const char* src) {
    out_pos = 0; out_buf[0] = 0;
    CDM_ClearErrors();
    char* pre = CDM_Preprocess(src);
    if (!pre) { printf("  [PREPROC NULL]\n"); return; }
    if (CDM_GetErrorCount() > 0) {
        printf("  [PP ERRORS: %d]\n", CDM_GetErrorCount());
        free(pre);
        return;
    }
    void* ast = CDM_Parse(pre);
    free(pre);
    if (!ast) { printf("  [PARSE NULL]\n"); return; }
    if (CDM_GetErrorCount() > 0) {
        printf("  [PARSE ERRORS: %d]\n", CDM_GetErrorCount());
        CDM_FreeAST(ast);
        return;
    }
    CDM_Execute(ast);
    CDM_FreeAST(ast);
}

static void expect(const char* name, const char* script, const char* want) {
    tests_run++;
    run_script(script);
    if (strcmp(out_buf, want) == 0) {
        printf("PASS  %s\n", name);
    } else {
        tests_failed++;
        printf("FAIL  %s\n  want: [%s]\n  got : [%s]\n", name, want, out_buf);
    }
}

static void expect_err(const char* name, const char* script) {
    tests_run++;
    out_pos = 0; out_buf[0] = 0;
    CDM_ClearErrors();
    char* pre = CDM_Preprocess(script);
    int fail = 0;
    if (!pre) { fail = 1; }
    else {
        if (CDM_GetErrorCount() == 0) {
            void* ast = CDM_Parse(pre);
            if (CDM_GetErrorCount() == 0) fail = 0;   /* ошибки не было — плохо */
            else fail = 1;
            if (ast) CDM_FreeAST(ast);
        } else fail = 1;
        free(pre);
    }
    if (fail) printf("PASS  %s\n", name);
    else { tests_failed++; printf("FAIL  %s (expected an error)\n", name); }
}

static double bench(const char* name, const char* src, int runs) {
    double best = 1e9;
    for (int r = 0; r < runs; r++) {
        clock_t t0 = clock();
        run_script(src);
        clock_t t1 = clock();
        double ms = (double)(t1 - t0) * 1000.0 / CLOCKS_PER_SEC;
        if (ms < best) best = ms;
    }
    printf("BENCH %s : %.2f ms\n", name, best);
    return best;
}

int main(void) {
    setbuf(stdout, NULL);
    CDM_RegisterHostFuncEx("print_int", h_print_int);
    CDM_RegisterHostFuncEx("print_float", h_print_float);
    CDM_RegisterHostFuncEx("print", h_print);
    CDM_RegisterHostFuncEx("add3", h_add);
    CDM_RegisterHostFuncEx("strlen", h_strlen);   /* как в cmscript_api.c */
    CMScript_Init();   /* 69 std-функций (sprintf/strlen/...) */

    /* ============ базовая арифметика (opcode switch) ============ */
    expect("int math",
        "int main() { int a = 17; int b = 5; print_int(a + b); print(\",\");"
        " print_int(a - b); print(\",\"); print_int(a * b); print(\",\");"
        " print_int(a / b); print(\",\"); print_int(a % b); return 0; }",
        "22,12,85,3,2");
    expect("precedence",
        "int main() { print_int(2 + 3 * 4); print(\",\"); print_int((2 + 3) * 4);"
        " print(\",\"); print_int(20 / 3 / 2); return 0; }",
        "14,20,3");
    expect("float math",
        "int main() { float x = 2.5; float y = 4.0; print_float(x * y);"
        " print(\",\"); print_float(x + y); return 0; }",
        "10,6.5");
    expect("bitwise",
        "int main() { print_int(12 & 10); print(\",\"); print_int(12 | 10);"
        " print(\",\"); print_int(12 ^ 10); print(\",\"); print_int(1 << 8);"
        " print(\",\"); print_int(256 >> 4); return 0; }",
        "8,14,6,256,16");
    expect("compare",
        "int main() { print_int(3 < 5); print_int(5 < 3); print_int(3 == 3);"
        " print_int(3 != 3); print_int(4 >= 4); print_int(2 <= 1); return 0; }",
        "101010");
    expect("logical",
        "int main() { print_int(1 && 2); print_int(0 && 2); print_int(0 || 3);"
        " print_int(0 || 0); return 0; }",
        "1010");
    expect("compound assign",
        "int main() { int a = 10; a += 5; print_int(a); a -= 3; print_int(a);"
        " a *= 2; print_int(a); a /= 4; print_int(a); a %= 4; print_int(a);"
        " a = 0xF0; a &= 0x3C; print_int(a); a |= 0x03; print_int(a);"
        " a ^= 0x10; print_int(a); a <<= 2; print_int(a); a >>= 1; print_int(a);"
        " return 0; }",
        "1512246248513514070");

    /* ============ слоты: функции, рекурсия, тени ============ */
    expect("func call",
        "int add(int a, int b) { return a + b; }"
        "int main() { print_int(add(20, 22)); return 0; }",
        "42");
    expect("recursion fib",
        "int fib(int n) { if (n < 2) return n; return fib(n - 1) + fib(n - 2); }"
        "int main() { print_int(fib(18)); return 0; }",
        "2584");
    expect("shadowing",
        "int main() { int x = 1; { int x = 2; { int x = 3; print_int(x); }"
        " print_int(x); } print_int(x); return 0; }",
        "321");
    expect("for-scope i",
        "int main() { int i = 100; for (int i = 0; i < 3; i = i + 1) print_int(i);"
        " print_int(i); return 0; }",
        "012100");
    expect("loop locals re-created",
        "int main() { for (int k = 0; k < 3; k = k + 1) { int t = k * 10;"
        " print_int(t); } return 0; }",
        "01020");
    expect("params independent of recursion",
        "int sum(int n) { if (n == 0) return 0; int me = n; int r = sum(n - 1);"
        " return r + me; } int main() { print_int(sum(80)); return 0; }",
        "3240");
    expect("many locals",
        "int main() { int a1=1; int a2=2; int a3=3; int a4=4; int a5=5; int a6=6;"
        " int a7=7; int a8=8; print_int(a1+a2+a3+a4+a5+a6+a7+a8); return 0; }",
        "36");
    expect("while + nested blocks",
        "int main() { int i = 0; int s = 0; while (i < 10) { int j = i * i;"
        " s = s + j; i = i + 1; } print_int(s); return 0; }",
        "285");

    /* ============ строки ============ */
    expect("string concat",
        "int main() { char* s = \"Hello\"; char* t = \"World\";"
        " char* u = s + \" \" + t; print(u); print(\"!\"); return 0; }",
        "Hello World!");
    expect("string concat loop (temp pool)",
        "int main() { char* s = \"\"; for (int i = 0; i < 200; i = i + 1) { s = s + \"x\"; } print(s); return 0; }",
        "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
    expect("string compare",
        "int main() { char* a = \"abc\"; print_int(a == \"abc\");"
        " print_int(a != \"abd\"); return 0; }",
        "11");
    expect("sprintf",
        "int main() { char* buf = \"\"; sprintf(buf, \"n=%d f=%s\", 42, \"ok\");"
        " print(buf); return 0; }",
        "n=42 f=ok");
    expect("string literals concat lexer",
        "int main() { print(\"Hello \" \"World\"); print(\" a\" \"b\" \"c\");"
        " return 0; }",
        "Hello World abc");
    expect("string literals concat across lines",
        "int main() {\n  print(\"line1 \"\n     \"line2\");\n  return 0;\n}\n",
        "line1 line2");
    expect("strlen host via string",
        "int main() { char* s = \"12345\"; print_int(strlen(s)); return 0; }",
        "5");

    /* ============ escape-последовательности ============ */
    expect("escapes classic",
        "int main() { print(\"a\\tb\"); print(\"\\n\"); print(\"q\\n\"); return 0; }",
        "a\tb\nq\n");
    expect("escapes hex octal",
        "int main() { print(\"\\x41\\x42\"); print(\"\\101\\102\"); print(\"\\r.\\n\");"
        " return 0; }",
        "ABAB\r.\n");
    expect("char literals",
        "int main() { int c = 'A'; print_int(c); print(\",\");"
        " int nl = '\\n'; print_int(nl); print(\",\"); int hx = '\\x41';"
        " print_int(hx); return 0; }",
        "65,10,65");

    /* ============ оператор запятая ============ */
    expect("comma in for",
        "int main() { int j; int i; for (i = 0, j = 10; i < j; i = i + 1, j = j - 1)"
        " { } print_int(i); print(\",\"); print_int(j); return 0; }",
        "5,5");
    expect("comma in parens",
        "int main() { int a; int b; a = 0; b = (a = 5, a + 2); print_int(b);"
        " print(\",\"); print_int(a); return 0; }",
        "7,5");
    expect("comma in cond",
        "int main() { int x = 0; int y = 0; if ((x = 3, y = 4)) print_int(x + y);"
        " return 0; }",
        "7");
    expect("args still split by comma",
        "int add3f(int a, int b, int c) { return a + b + c; }"
        "int main() { print_int(add3f(1, 2, 3)); return 0; }",
        "6");

    /* ============ указатели ============ */
    expect("pointer basics",
        "int main() { int x = 41; int* p = &x; *p = *p + 1; print_int(x);"
        " print_int(p == p); return 0; }",
        "421");
    expect("pointer arithmetic",
        "int main() { int a = 7; int b = 8; int* p = &a; int* q = &b;"
        " print_int(p > q); print_int(p < q); print_int(p == q); print_int(p != q);"
        " return 0; }",
        "0101");
    expect("ptr arithmetic +/- int",
        "int main() { char* base = (char*)1000; char* p = base + 16;"
        " print_int((int)(base - p)); print_int((int)(p - base)); return 0; }",
        "-1616");

    /* ============ препроцессор ============ */
    expect("preproc define",
        "#defineAnswer NE 42\n#define NE 42\nint main() { print_int(NE); return 0; }",
        "42");
    expect("preproc func macro",
        "#define SQR(x) ((x) * (x))\n#define MAX(a,b) ((a) > (b) ? (a) : (b))\n"
        "int main() { print_int(SQR(6)); print(\",\"); print_int(MAX(3, 9)); return 0; }",
        "36,9");
    expect("preproc multiline macro",
        "#define SUM(a, b) \\\n    ((a) + \\\n     (b))\n"
        "int main() { print_int(SUM(20, 22)); return 0; }",
        "42");
    expect("preproc ifdef",
        "#define FEATURE 1\n"
        "int main() {\n"
        "#ifdef FEATURE\n  print(\"on\");\n#else\n  print(\"off\");\n#endif\n"
        "#ifdef MISSING\n  print(\"bad\");\n#endif\n  return 0;\n}\n",
        "on");
    expect("preproc if expr",
        "#define A 2\nint main() {\n#if A * 3 == 6\n  print(\"ok\");\n#endif\n"
        "#if !defined(B) \n  print(\"!\");\n#endif\n return 0;\n}\n",
        "ok!");
    expect("predef NULL",
        "int main() { int* p = NULL; print_int(p == 0); return 0; }",
        "1");
    expect("predef TRUE FALSE EOF",
        "int main() { print_int(TRUE); print_int(FALSE); print_int(EOF); return 0; }",
        "10-1");
    expect("predef override",
        "#define TRUE 5\nint main() { print_int(TRUE); return 0; }",
        "5");
    expect("builtin __LINE__",
        "int main() {\n  print(__LINE__);\n  return 0;\n}\n",
        "2");
    expect("builtin __FILE__",
        "int main() { print(__FILE__); return 0; }",
        "script.cs");
    expect_err("#error aborts",
        "#define VER 1\nint main() {\n#if VER != 2\n#error unsupported version\n#endif\n return 0;\n}\n");

    /* ============ структуры/массивы (регрессия) ============ */
    expect("struct basics",
        "struct Point { int x; int y; };"
        "int main() { struct Point p; p.x = 3; p.y = 4; print_int(p.x + p.y);"
        " return 0; }",
        "7");
    expect("struct ptr arrow",
        "struct Point { int x; int y; };"
        "int main() { struct Point* p = new Point; p->x = 10; p->y = 20;"
        " print_int(p->x + p->y); delete p; return 0; }",
        "30");
    expect("array basics",
        "int main() { int a[5]; for (int i = 0; i < 5; i = i + 1) a[i] = i * i;"
        " print_int(a[4]); return 0; }",
        "16");
    expect("range for",
        "int main() { int a[3]; a[0] = 5; a[1] = 6; a[2] = 7; int s = 0;"
        " for (int v : a) { s = s + v; } print_int(s); return 0; }",
        "18");

    /* ============ прочие конструкции (регрессия) ============ */
    expect("ternary",
        "int main() { int a = 5; int b = a > 3 ? 100 : 200; print_int(b); return 0; }",
        "100");
    expect("switch",
        "int main() { int x = 2; switch (x) { case 1: print(\"one\"); break;"
        " case 2: print(\"two\"); break; default: print(\"other\"); } return 0; }",
        "two");
    expect("goto",
        "int main() { int i = 0; loop: i = i + 1; if (i < 3) goto loop;"
        " print_int(i); return 0; }",
        "3");
    expect("do while",
        "int main() { int i = 0; do { i = i + 1; } while (i < 5); print_int(i);"
        " return 0; }",
        "5");
    expect("typedef",
        "typedef int myint; int main() { myint x = 33; print_int(x); return 0; }",
        "33");
    expect("enum",
        "enum Color { RED, GREEN = 10, BLUE };"
        "int main() { print_int(RED); print_int(GREEN); print_int(BLUE); return 0; }",
        "01011");
    expect("unary ops",
        "int main() { int i = 5; i++; print_int(i); ++i; print_int(i); i--; print_int(i);"
        " --i; print_int(i); print_int(-i); print_int(!0); print_int(~0); return 0; }",
        "6765-51-1");
    expect("host func args",
        "int main() { print_int(add3(1, 2, 3)); print_int(add3(10, 20, 30)); return 0; }",
        "660");

    /* ============ раунд 2: арена + новые фичи ============ */
    expect("unary plus",
        "int main() { int a = 5; print_int(+a); print_int(+(-a));"
        " float f = 2.5; print_float(+f); return 0; }",
        "5-52.5");
    expect("float modulo (C99 fmod)",
        "int main() { print_float(7.5 % 2.0); print_float(-7.0 % 3.0);"
        " print_float(10.0 % 4.0); return 0; }",
        "1.5-12");
    expect("bool/true/false predef macros",
        "int main() { bool flag = TRUE; bool off = FALSE;"
        " if (flag) print(\"T\"); if (!off) print(\"F\"); return 0; }",
        "TF");
    expect("sprintf width flags tolerated",
        "int main() { char* b = \"\"; sprintf(b, \"%5d|%x|%s\", 42, 255, \"hi\");"
        " print(b); return 0; }",
        "42|ff|hi");
    expect("global var cached across calls",
        "int bump() { return counter; }"
        "int main() { counter = 0; int i = 0; while (i < 100) { counter = counter + 2;"
        " i = i + 1; } print_int(bump() + bump()); return 0; }",
        "400");
    expect("enum shadowing C-style",
        "enum C { A = 7, B = 8 };"
        "int main() { int A = 1; print_int(A); print_int(B); return 0; }",
        "18");
    expect("many args + big initializer (arena arrays)",
        "int s9(int a, int b, int c, int d, int e, int f, int g, int h, int i)"
        " { return a + b + c + d + e + f + g + h + i; }"
        "int main() { int arr[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }; int s = 0;"
        " for (int k = 0; k < 10; k = k + 1) s = s + arr[k];"
        " print_int(s9(1, 2, 3, 4, 5, 6, 7, 8, 9) + s); return 0; }",
        "90");
    expect("arena stress: deep calls + many nodes",
        "int q(int n) { if (n <= 0) return 0; int a = n; int b = q(n - 1);"
        " int c = a + b; return c; }"
        "int main() { int i = 0; int s = 0; while (i < 50) { s = s + q(i); i = i + 1; }"
        " print_int(s); return 0; }",
        "20825");

    /* ============ производительность ============ */
    {
        double t_fib = bench("fib(20) recursive",
            "int fib(int n) { if (n < 2) return n; return fib(n - 1) + fib(n - 2); }"
            "int main() { print_int(fib(20)); return 0; }", 3);
        (void)t_fib;
        double t_loop = bench("loop 1M iterations (sum + compare + assign)",
            "int main() { int s = 0; int i = 0; while (i < 1000000) { s = s + i; i = i + 1; }"
            " print_int(s); return 0; }", 3);
        (void)t_loop;
        double t_str = bench("string concat x3000",
            "int main() { char* s = \"\"; for (int i = 0; i < 3000; i = i + 1) {"
            " s = s + \"ab\"; } print_int(strlen(s)); return 0; }", 3);
        (void)t_str;
        double t_spr = bench("sprintf x20000",
            "int main() { char* buf = \"\"; int s = 0; for (int i = 0; i < 20000; i = i + 1)"
            " { sprintf(buf, \"%d\", i); s = s + 1; } print_int(s); return 0; }", 3);
        (void)t_spr;
        double t_call = bench("host call x100000",
            "int main() { int s = 0; for (int i = 0; i < 100000; i = i + 1)"
            " { s = s + add3(i, 1, 2); } print_int(s); return 0; }", 3);
        (void)t_call;
    }

    printf("\n==== %d tests, %d failed ====\n", tests_run, tests_failed);
    return tests_failed ? 1 : 0;
}
