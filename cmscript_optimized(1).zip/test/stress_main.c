/* stress_main.c — стресс арены: большой скрипт (десятки чанков AST),
 * много циклов Parse->Execute->FreeAST, кэши в узлах между запусками. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { CDM_TYPE_INT = 0, CDM_TYPE_FLOAT, CDM_TYPE_PTR, CDM_TYPE_STRUCT,
       CDM_TYPE_ARRAY, CDM_TYPE_STRING, CDM_TYPE_REF };
typedef struct {
    int type; int struct_id; int array_len; int array_dim;
    int array_sizes[4]; int array_elem_type; int array_elem_struct_id;
    int owned; int from_new;
    union { long long i; double f; void* p; } v;
} CDM_Value_t;
typedef CDM_Value_t (*CDM_HostFuncEx_t)(int argc, CDM_Value_t* argv);
extern void CDM_RegisterHostFuncEx(const char* name, CDM_HostFuncEx_t fn);
extern char* CDM_Preprocess(const char* src);
extern void* CDM_Parse(const char* src);
extern int   CDM_Execute(void* root);
extern void  CDM_FreeAST(void* root);
extern int   CDM_GetErrorCount(void);
extern void  CDM_ClearErrors(void);

static CDM_Value_t h_print_int(int argc, CDM_Value_t* argv) {
    CDM_Value_t r; memset(&r, 0, sizeof(r));
    r.type = CDM_TYPE_INT;
    if (argc >= 1) {
        long long v = (argv[0].type == CDM_TYPE_REF)
            ? ((CDM_Value_t*)argv[0].v.p)->v.i : argv[0].v.i;
        printf("%lld\n", v);
    }
    return r;
}

/* генерируем скрипт с ~40 тыс. узлов AST: 200 функций по ~30 узлов + main */
static char* gen_big_script(int nfuncs) {
    size_t cap = 1u << 22;
    char* s = (char*)malloc(cap);
    size_t o = 0;
    o += (size_t)sprintf(s + o, "int add3(int a, int b, int c) { return a + b + c; }\n");
    for (int f = 0; f < nfuncs; f++) {
        o += (size_t)sprintf(s + o,
            "int fn%d(int x) { int a = x + %d; int b = a * 2; int c[4] = { 1, 2, 3, 4 };\n"
            "  if (a > b) { c[0] = a; } else { c[1] = b; }\n"
            "  int i = 0; int s = 0; while (i < 4) { s = s + c[i] + add3(a, b, x); i = i + 1; }\n"
            "  return s + fn%d(x - 1) * (x > 0 ? 1 : 0); }\n", f, f, f);
        if (o > cap - 4096) break;
    }
    o += (size_t)sprintf(s + o,
        "int main() { long long s = 0; int k = 0;\n"
        "  while (k < 200) { s = s + fn0(k); k = k + 1; }\n"
        "  print_int((int)(s & 1023)); return 0; }\n");
    return s;
}

int main(void) {
    CDM_RegisterHostFuncEx("print_int", h_print_int);

    /* 1) много циклов на среднем скрипте — кэши в узлах переиспользуются */
    const char* mid =
        "int fib(int n) { if (n < 2) return n; return fib(n - 1) + fib(n - 2); }"
        "int main() { int i = 0; int s = 0; while (i < 10) { s = s + fib(i + 5); i = i + 1; }"
        " print_int(s); return 0; }";
    for (int it = 0; it < 200; it++) {
        CDM_ClearErrors();
        char* pre = CDM_Preprocess(mid);
        if (!pre || CDM_GetErrorCount()) { printf("PRE FAIL\n"); return 1; }
        void* ast = CDM_Parse(pre);
        free(pre);
        if (!ast || CDM_GetErrorCount()) { printf("PARSE FAIL\n"); return 1; }
        if (CDM_Execute(ast) != 0) { printf("EXEC FAIL\n"); return 1; }
        CDM_FreeAST(ast);          /* каждый 2-й запуск — без FreeAST (сброс в Parse) */
        if (it % 2 == 1) CDM_FreeAST(NULL);
    }

    /* 2) большой скрипт — десятки чанков арены */
    char* big = gen_big_script(200);
    printf("big script: %u bytes\n", (unsigned)strlen(big));
    for (int it = 0; it < 20; it++) {
        CDM_ClearErrors();
        char* pre = CDM_Preprocess(big);
        if (!pre || CDM_GetErrorCount()) { printf("BIG PRE FAIL\n"); return 1; }
        void* ast = CDM_Parse(pre);
        free(pre);
        if (!ast) { printf("BIG PARSE FAIL\n"); return 1; }
        CDM_Execute(ast);
        CDM_FreeAST(ast);
    }

    /* 3) скрипт с ошибкой разбора — FreeAST не зовётся, чанк отдаётся
     *    следующему CDM_Parse */
    const char* broken = "int main() { int x = ; } garbage {{{";
    for (int it = 0; it < 50; it++) {
        CDM_ClearErrors();
        char* pre = CDM_Preprocess(broken);
        void* ast = pre ? CDM_Parse(pre) : NULL;
        free(pre);
        if (ast) CDM_FreeAST(ast);
        CDM_FreeAST(NULL);         /* в т.ч. после ошибки разбора */
    }

    printf("STRESS OK\n");
    free(big);
    return 0;
}
