/*
 * jar_reader.c — single canonical JAR/ZIP resource reader (v19).
 *
 * WHY THIS EXISTS
 * ===============
 * Until v18 there were FOUR independent hand-rolled ZIP scanners in the
 * code base (main.c, jvm.c, libretro/libretro.c, libretro/sdl_backend_stubs.c).
 * All four parsed the End-Of-Central-Directory record and the central
 * directory by hand. Divergence between them caused at least one hard to
 * reproduce bug: on a user's Windows build class loading (jvm.c scanner)
 * worked while resource loading (sdl_backend_stubs.c scanner) returned NULL
 * for every entry — NEscube then rendered its cube without the texture.
 *
 * This file replaces all four with ONE implementation built on miniz
 * (src/utils/miniz.c, already part of every build target). miniz handles
 * the whole zoo of valid-but-exotic ZIP layouts our hand-rolled code does
 * not: data descriptors (streaming zippers), ZIP64, SFX/prepended data,
 * entries with extra fields/comments, etc.
 *
 * API
 * ===
 *   jar_read_file(data, size, "path/inside/jar", &out_size) -> malloc'd buffer
 *
 * The returned buffer always has ONE extra NUL byte (not counted in
 * *out_size) — callers historically relied on text resources being
 * NUL-terminated. Free with free().
 *
 * Name lookup: exact match first; if that fails a case-insensitive pass
 * runs (a jar repacked on Windows may change letter case). Directory
 * entries never match.
 *
 * Diagnostics: failures are logged to stderr with the exact reason and
 * rate-limited, so a broken build reports e.g.
 *   [JAR-READ] FAILED (no-zip): 'res/bin/texture.res'
 * instead of leaving callers to guess which NULL branch fired.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "debug.h"   /* v34.24: routes jar_log through the log gate (quiet by default) */
#include "miniz.h"
#include "jar_reader.h"

/* Rate limiting: stop spamming after this many messages per session. */
#define JAR_READ_MAX_LOGS 24
static int s_jar_read_logs = 0;

/* v34.30: gnu_printf flavor — jar_log formats use %zu (size_t); MinGW's
 * ms_printf checking rejects 'z'. Same fix as J2ME_PRINTF_ATTR in debug.h
 * (which this file includes above). */
__attribute__((format(gnu_printf, 1, 2)))
static void jar_log(const char* fmt, ...) {
    if (s_jar_read_logs >= JAR_READ_MAX_LOGS) return;
    s_jar_read_logs++;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
}

uint8_t* jar_read_file(const void* jar_data, size_t jar_size,
                       const char* name, size_t* out_size) {
    if (out_size) *out_size = 0;
    if (!jar_data || jar_size < 22 || !name || !name[0]) {
        jar_log("[JAR-READ] FAILED (bad-args): '%s' (data=%p size=%zu)\n",
                name ? name : "NULL", jar_data, jar_size);
        return NULL;
    }

    /* Stack-local archive handle: getResourceAsStream may be called from
     * several Java threads concurrently, so no shared static state here. */
    mz_zip_archive zip;
    memset(&zip, 0, sizeof(zip));

    if (!mz_zip_reader_init_mem(&zip, jar_data, jar_size, 0)) {
        jar_log("[JAR-READ] FAILED (no-zip): '%s' (not a readable ZIP/JAR image)\n", name);
        return NULL;
    }

    /* 1) Exact, case-sensitive match (fast path — miniz sorts lowercased
     *    names at init, so even the insensitive pass is a binary search). */
    int idx = mz_zip_reader_locate_file(&zip, name, NULL, MZ_ZIP_FLAG_CASE_SENSITIVE);

    /* 2) Case-insensitive fallback (jar repacked on Windows). */
    if (idx < 0) {
        idx = mz_zip_reader_locate_file(&zip, name, NULL, 0);
    }

    if (idx < 0) {
        /* Class probes (foo/bar/Exception.class, [I.class ...) are EXPECTED
         * misses: the VM probes the JAR before falling back to built-in
         * stubs. Logging them would spam every session with noise, so they
         * stay silent; genuine resource misses still log. */
        if (!strstr(name, ".class")) {
            jar_log("[JAR-READ] FAILED (no-entry): '%s'\n", name);
        }
        mz_zip_reader_end(&zip);
        return NULL;
    }

    size_t len = 0;
    void* data = mz_zip_reader_extract_to_heap(&zip, (mz_uint)idx, &len, 0);
    mz_zip_reader_end(&zip);

    if (!data) {
        jar_log("[JAR-READ] FAILED (extract-fail): '%s' (corrupt or unsupported method)\n", name);
        return NULL;
    }

    /* Preserve the historical contract: one extra NUL terminator. */
    uint8_t* out = (uint8_t*)realloc(data, len + 1);
    if (!out) {
        free(data);
        jar_log("[JAR-READ] FAILED (oom): '%s' (%zu bytes)\n", name, len);
        return NULL;
    }
    out[len] = '\0';

    if (out_size) *out_size = len;
    return out;
}

/* v34.29: manifest line-folding — see include/jar_reader.h for the spec
 * rationale and the JBenchmark 3D failure case. Implementation notes:
 *  - a physical line break is \r, \n or a run of them (CRLF, LFCR, CRCR…)
 *  - a SINGLE space right after the break marks a continuation: the space
 *    is dropped and nothing else happens (the logical line continues)
 *  - a line starting with 2+ spaces is a continuation whose value begins
 *    with the remaining spaces (spec: exactly one space is the marker)
 *  - a real logical-line break emits exactly one '\n', so downstream
 *    strtok/strstr parsing sees clean folded lines */
char* jar_manifest_unfold(const uint8_t* data, size_t size) {
    if (!data && size > 0) return NULL;

    char* out = (char*)malloc(size + 1);
    if (!out) return NULL;

    size_t o = 0;
    size_t i = 0;
    while (i < size) {
        char c = (char)data[i];
        if (c == '\r' || c == '\n') {
            /* Consume the entire run of newline characters. */
            size_t j = i;
            while (j < size && ((char)data[j] == '\r' || (char)data[j] == '\n')) j++;

            int folded = 0;
            if (j < size && (char)data[j] == ' ') {
                j++;          /* exactly one space is the fold marker */
                folded = 1;
            }
            if (!folded && j < size) {
                out[o++] = '\n';   /* real end of logical line */
            }
            i = j;
            continue;
        }
        out[o++] = c;
        i++;
    }
    out[o] = '\0';
    return out;
}
