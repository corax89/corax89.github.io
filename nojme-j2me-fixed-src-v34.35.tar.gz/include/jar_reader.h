/*
 * jar_reader.h — single canonical in-memory JAR/ZIP reader (v19).
 *
 * Replaces the four divergent hand-rolled ZIP scanners that used to live in
 * main.c, jvm.c, libretro/libretro.c and libretro/sdl_backend_stubs.c.
 * Built on miniz; see src/utils/jar_reader.c for the rationale.
 */

#ifndef JAR_READER_H
#define JAR_READER_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Read one file from an in-memory JAR/ZIP image.
 *
 *   jar_data/jar_size  — the JAR image (as loaded into memory)
 *   name               — entry name, e.g. "res/bin/texture.res"
 *   out_size           — receives the exact byte count (may be NULL)
 *
 * Returns a malloc'd buffer of *out_size + 1 bytes (the extra byte is a NUL
 * terminator, not counted in *out_size) or NULL if the archive is not a
 * readable ZIP, the entry is absent, or extraction fails. Free with free().
 *
 * Lookup: exact case-sensitive match first, then a case-insensitive pass
 * (jars repacked on Windows often change letter case).
 */
uint8_t* jar_read_file(const void* jar_data, size_t jar_size,
                       const char* name, size_t* out_size);

/* v34.29 FIX (manifest line folding): JAR manifests (MIDP/CLDC spec, same
 * format as java.util.jar) allow a logical line to span multiple physical
 * lines: a physical line starting with a single space is a CONTINUATION —
 * the space is dropped and the remainder is appended to the previous
 * logical line. JBenchmark 3D's manifest folds its main class:
 *
 *   MIDlet-1: JBenchmark3D,/JBenchmark3D/3dlogo32.png,JBenchmark3D.JBenchm\r\n
 *   ark3D\r\n
 *
 * The old parsers split on strtok("\r\n") and read the class as the
 * truncated "…JBenchm" -> ClassNotFoundException at launch.
 *
 * Returns a malloc'd NUL-terminated string with folds joined (continuation
 * content concatenated directly after the previous line, no space) and all
 * newline runs (CRLF/LF/CRCR...) collapsed to a single '\n'. Free with
 * free(). Returns NULL on allocation failure.
 */
char* jar_manifest_unfold(const uint8_t* data, size_t size);

#ifdef __cplusplus
}
#endif

#endif /* JAR_READER_H */
