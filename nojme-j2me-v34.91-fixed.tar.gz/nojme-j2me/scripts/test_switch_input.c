/*
 * test_switch_input.c — v34.90 white-box FUNCTIONAL test of the
 * SINGLE-PUMP Switch input + RU/EN language toggle.
 *
 * Includes src/sdl/sdl_graphics.c directly (single TU, -D__SWITCH__) so the
 * file-static helpers are reachable, and LINKS the REAL switch_ui.c /
 * switch_font.c / switch_scaling.c (compiled WITHOUT -D__SWITCH__ so the
 * settings ini lands in NOJME_SWITCH_UI_DIR instead of sdmc:/) — the i18n
 * machinery and the menu session are the production code under test.
 *
 * Coverage (the fix for «кнопки сразу работали, но затем перестали»):
 *   1. platform init opens the virtual pad (device index 0 -> slot 0)
 *   2. menu pump: button taps -> SWK_* bits; MINUS -> SWK_MINUS
 *   3. HELD state persists across pump calls (v34.89 kept it only in the
 *      pump that saw the DOWN event — browser auto-repeat could not work)
 *   4. SHORT TAP (press+release inside one pump interval) still registers
 *      via the SDL_JOYBUTTONDOWN latch
 *   5. EVENT-LOSS RESILIENCE: queue drained behind the pump's back — the
 *      press still registers via the SDL_JoystickGetButton state repair
 *      (the "buttons stopped working" insurance)
 *   6. in-game frame pump: buttons -> MIDP keyCodes, stick -> dpad edges
 *      with hysteresis
 *   7. MINUS opens the pause menu on the frame thread; A resumes
 *   8. the GAME-THREAD pump (sdl_process_events_minimal) is a NO-OP: it
 *      steals nothing — a queued press survives it and is delivered by
 *      the frame pump (the single-pump rule)
 *   9. hotplug detach/re-attach
 *  10. i18n: RU by default, switch_lang_toggle -> EN (+ settings.ini
 *      lang=en), localized strings, badge text
 *  11. FULL MENU E2E: NOJME_SWITCH_KEYS drives the real menu session —
 *      MINUS switches the language mid-run, A opens the browser, A picks
 *      the jar
 *
 * Build (see scripts/test_switch_input.sh): host gcc + SDL2 runtime +
 * the 2.30.x header snapshot, dummy video/audio drivers.
 */
#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdbool.h>

/* pull the whole backend in as ONE translation unit: every static
 * __SWITCH__ helper (switch_input_pump, g_sw_in, g_joy[], ...) becomes
 * visible to this test. -D__SWITCH__ + the SDL2 snapshot on the include
 * path give the exact NRO compilation surface. */
#include "sdl/sdl_graphics.c"
#include "switch/switch_ui.h" /* switch_ui_pick_game (real impl linked) */

/* ------------------------- MIDP seam stubs ------------------------- */
static int g_kp[64], g_kp_n;          /* keyPressed codes */
static int g_kr[64], g_kr_n;          /* keyReleased codes */
static int g_krep[64], g_krep_n;      /* keyRepeated codes */
static int g_pause_open_count = 0;    /* "pause menu open" log sightings */

void midp_call_keyPressed(JVM* jvm, int keycode) {
    (void)jvm; g_kp[g_kp_n++] = keycode;
}
void midp_call_keyReleased(JVM* jvm, int keycode) {
    (void)jvm; g_kr[g_kr_n++] = keycode;
}
void midp_call_keyRepeated(JVM* jvm, int keycode) {
    (void)jvm; g_krep[g_krep_n++] = keycode;
}
bool midp_handle_soft_button(JVM* jvm, int button_index) {
    (void)jvm; (void)button_index; return false; /* pass through to game */
}
bool midp_is_command_menu_open(void) { return false; }
bool midp_handle_menu_navigation(int direction) { (void)direction; return false; }
void midp_input_activity_mark(void) {}
void midlet_call_destroy_app(JVM* jvm, bool unconditional) { (void)jvm; (void)unconditional; }
void midp_call_pointerPressed(JVM* jvm, int x, int y) { (void)jvm; (void)x; (void)y; }
void midp_call_pointerReleased(JVM* jvm, int x, int y) { (void)jvm; (void)x; (void)y; }
void midp_call_pointerDragged(JVM* jvm, int x, int y) { (void)jvm; (void)x; (void)y; }

/* core build id — normally provided by main.c */
const char* j2me_core_build_id(void) { return "v34.90-test"; }

/* debug_var.c seam (declarations come from debug_macros.h via the .c).
 * debug_macros.h #defines fprintf/vfprintf (object-like!) to the gate —
 * #undef them HERE so the gate stubs below call the REAL libc
 * functions instead of infinitely recursing on themselves. */
#undef fprintf
#undef vfprintf
int g_j2me_runtime_debug = 0;
int j2me_log_enabled(void) { return 1; }
int j2me_log_ungated(const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    if (strstr(fmt, "pause menu open") != NULL) g_pause_open_count++;
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    return 0;
}
int j2me_fprintf_gate(FILE* stream, const char* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vfprintf(stream, fmt, ap);
    va_end(ap);
    return r;
}
int j2me_vfprintf_gate(FILE* stream, const char* fmt, va_list ap) {
    return vfprintf(stream, fmt, ap);
}
void log_lock(void) {}
void log_unlock(void) {}
void log_mutex_init(void) {}

/* ---- the rest of the linked-but-uncalled MIDP / jvm seam ---- */
bool midlet_is_destroyed(void) { return false; }
void jvm_process_timers(JVM* j) { (void)j; }
void jvm_frontend_frame_tick(void) {}
void jvm_frontend_run_exit(void) {}
bool midp_check_alert_timeout(JVM* j) { (void)j; return false; }
void midp_clear_pending_repaint(void) {}
void midp_frame_tick(void) {}
void midp_pump_deferred_keys(JVM* j) { (void)j; }
void midp_process_call_serially_queue(JVM* j) { (void)j; }
void midp_process_repaints(JVM* j) { (void)j; }
void midp_vsync_tick(void) {}
void midp_graphics_init(MidpGraphics* gfx, uint32_t* pixels, int width, int height) {
    (void)gfx; (void)pixels; (void)width; (void)height;
}
void midp_present_settled_snapshot(void) {}
void midp_set_clipboard_hooks(void (*set_fn)(const char*), char* (*get_fn)(void)) {
    (void)set_fn; (void)get_fn; /* clipboard bridge — not under test */
}
uint32_t midp_present_stable_copy(uint32_t* dst, int dst_px) { (void)dst; (void)dst_px; return 0; }

/* ------------------------- assertions ------------------------- */
static int g_fail = 0;
#define CHECK(cond, msg) do { \
    if (cond) { printf("  ok   %s\n", msg); } \
    else      { printf("  FAIL %s\n", msg); g_fail++; } \
} while (0)

static void reset_keys(void) {
    g_kp_n = g_kr_n = g_krep_n = 0;
}

/* drain everything so each test starts with an empty queue */
static void drain(void) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {}
    reset_keys();
}

/* press+release a raw pad button. IMPORTANT: the SDL2 virtual-joystick
 * driver only EMITS events during SDL_PumpEvents (in button-index order) —
 * a press and release with no pump in between is a net no-change and
 * generates NOTHING. So we pump after each state change, exactly like a
 * real 60 Hz event loop would. */
static void tap_button(int button) {
    SDL_JoystickSetVirtualButton(g_joy[0], button, 1);
    SDL_PumpEvents();   /* flush the press into the queue */
    SDL_JoystickSetVirtualButton(g_joy[0], button, 0);
    SDL_PumpEvents();   /* flush the release */
}

/* Resume key delivered from SDL's timer thread while the pause menu loop
 * is blocked inside sdl_process_events (SDL_PushEvent is thread-safe). */
static Uint32 SDLCALL tsi_resume_cb(Uint32 interval, void* param) {
    (void)interval; (void)param;
    SDL_Event ev;
    SDL_zero(ev);
    ev.type = SDL_KEYDOWN;
    ev.key.keysym.sym = SDLK_RETURN; /* menu: RETURN = A/OK */
    SDL_PushEvent(&ev);
    return 0; /* one-shot */
}

int main(void) {
    SDL_setenv("SDL_VIDEODRIVER", "dummy", 1);
    SDL_setenv("SDL_AUDIODRIVER", "dummy", 1);

    /* i18n sandbox: settings ini + browse root in /tmp */
    const char* langdir = "/tmp/tsi_v3490";
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "rm -rf %s && mkdir -p %s", langdir, langdir);
    if (system(cmd) != 0) { printf("FATAL: cannot prepare %s\n", langdir); return 2; }
    SDL_setenv("NOJME_SWITCH_UI_DIR", langdir, 1);
    SDL_setenv("NOJME_SWITCH_BROWSE_ROOT", langdir, 1);
    SDL_setenv("NOJME_SWITCH_LANG", "ru", 1);
    /* a jar for the E2E picker */
    {
        char jar[600];
        snprintf(jar, sizeof(jar), "%s/testgame.jar", langdir);
        FILE* f = fopen(jar, "wb");
        if (f) { fputs("PK\x03\x04stub", f); fclose(f); }
    }

    /* ---- bootstrap: attach the virtual pad BEFORE platform init ---- */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_JOYSTICK) != 0) {
        printf("FATAL: SDL_Init: %s\n", SDL_GetError());
        return 2;
    }
    SDL_VirtualJoystickDesc desc;
    SDL_zero(desc);
    desc.version = SDL_VIRTUAL_JOYSTICK_DESC_VERSION;
    desc.type = SDL_JOYSTICK_TYPE_GAMECONTROLLER;
    desc.naxes = 4;
    desc.nbuttons = 16;
    desc.name = "Virtual Switch Pad";
    int dev = SDL_JoystickAttachVirtualEx(&desc);
    CHECK(dev == 0, "virtual joystick attached as device index 0");

    printf("== 1. platform init opens the raw pad ==\n");
    CHECK(sdl_switch_platform_init() == 0, "sdl_switch_platform_init OK");
    drain(); /* eat the queued ADDED duplicates etc. (open already won) */
    CHECK(g_joy[0] != NULL, "raw joystick slot 0 opened by platform init");
    CHECK(g_joy_instance[0] == SDL_JoystickInstanceID(g_joy[0]),
          "instance id recorded for slot 0");
    CHECK(switch_joy_slot(SDL_JoystickInstanceID(g_joy[0])) == 0,
          "switch_joy_slot maps instance -> slot 0");

    printf("== 2. menu pump: taps -> SWK_* bits, MINUS -> SWK_MINUS ==\n");
    unsigned k;
    tap_button(SWJB_A);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_A, "menu: button A -> SWK_A");
    tap_button(SWJB_PLUS);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_A, "menu: PLUS -> SWK_A (OK)");
    tap_button(SWJB_B);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_B, "menu: B -> SWK_B");
    tap_button(SWJB_UP);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_UP, "menu: raw button 13 -> SWK_UP");
    tap_button(SWJB_DOWN);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_DOWN, "menu: raw button 15 -> SWK_DOWN");
    tap_button(SWJB_LEFT);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_LEFT, "menu: raw button 12 -> SWK_LEFT");
    tap_button(SWJB_RIGHT);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_RIGHT, "menu: raw button 14 -> SWK_RIGHT");
    tap_button(SWJB_MINUS);
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_MINUS, "menu: MINUS edge -> SWK_MINUS (language key)");
    tap_button(SWJB_ZL);
    k = sdl_switch_ui_pump_keys();
    CHECK(k == 0, "menu: ZL produces no menu bit");

    printf("== 3. HELD state persists across pump calls ==\n");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_UP, 1);
    SDL_PumpEvents();
    k = sdl_switch_ui_pump_keys(); /* first pump sees the press */
    CHECK(sdl_switch_ui_held_keys() & SWK_UP, "held: UP seen held on press pump");
    k = sdl_switch_ui_pump_keys(); /* second pump: NO new events */
    CHECK(k == 0, "held: no spurious EDGE on the follow-up pump");
    CHECK(sdl_switch_ui_held_keys() & SWK_UP,
          "held: UP still held on a LATER pump (v34.89 lost it here)");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_UP, 0);
    SDL_PumpEvents();
    k = sdl_switch_ui_pump_keys();
    CHECK(!(sdl_switch_ui_held_keys() & SWK_UP), "held: UP released");

    printf("== 4. short tap inside one pump interval (event latch) ==\n");
    tap_button(SWJB_A);          /* press AND release already flushed */
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_A, "short tap: A still registers via the DOWN-event latch");

    printf("== 5. event-loss resilience (state repair) ==\n");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_B, 1);
    SDL_PumpEvents();
    {   SDL_Event e; while (SDL_PollEvent(&e)) {} } /* THROW the events away */
    k = sdl_switch_ui_pump_keys();
    CHECK(k & SWK_B, "event lost: B press recovered from SDL_JoystickGetButton state");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_B, 0);
    SDL_PumpEvents();
    {   SDL_Event e; while (SDL_PollEvent(&e)) {} }
    k = sdl_switch_ui_pump_keys();
    CHECK(!(k & SWK_B), "event lost: no ghost edge after release");

    printf("== 6. in-game frame pump: buttons -> MIDP keyCodes ==\n");
    SdlContext ctx;
    memset(&ctx, 0, sizeof(ctx));
    ctx.width = 240; ctx.height = 320; ctx.scale = 1;
    ctx.running = true;
    ctx.jvm = (JVM*)(uintptr_t)0x1234; /* opaque for the stubs */
    g_sdl_ctx_ptr = &ctx;
    g_switch_game_active = 1;

    /* A -> FIRE (-5, Nokia FullCanvas) */
    drain();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_A, 1);
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -5, "game: A press -> keyPressed(-5 FIRE)");
    reset_keys();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_A, 0);
    sdl_process_events(&ctx);
    CHECK(g_kr_n == 1 && g_kr[0] == -5, "game: A release -> keyReleased(-5)");

    /* X/Y -> soft keys */
    drain();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_X, 1);
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -6, "game: X press -> keyPressed(-6 left soft)");
    reset_keys();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_Y, 1);
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -8, "game: Y press -> keyPressed(-8 GAME_C)");
    reset_keys();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_X, 0);
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_Y, 0);
    sdl_process_events(&ctx);

    /* L/R -> asterisk / hash */
    drain();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_L, 1);
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == '*', "game: L press -> keyPressed('*')");
    reset_keys();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_L, 0);
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_R, 1);
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == '#', "game: R press -> keyPressed('#')");
    reset_keys();
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_R, 0);
    sdl_process_events(&ctx);

    printf("== 7. stick -> dpad edges with hysteresis ==\n");
    drain();
    SDL_JoystickSetVirtualAxis(g_joy[0], 1, -32767);  /* stick up */
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -1, "stick up -> keyPressed(-1 UP)");
    reset_keys();
    SDL_JoystickSetVirtualAxis(g_joy[0], 0, -32767);  /* + left */
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -3, "stick up+left -> keyPressed(-3 LEFT)");
    reset_keys();
    /* hysteresis: partial release to -0.42 (inside the 0.35..0.50 hold
     * band, still on the SAME side) — the direction KEEPS, no edges fire */
    SDL_JoystickSetVirtualAxis(g_joy[0], 1, (int)(-0.42f * 32767));
    SDL_JoystickSetVirtualAxis(g_joy[0], 0, (int)(-0.42f * 32767));
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 0 && g_kr_n == 0,
          "hysteresis: 0.42 partial deflection holds the direction (no edges)");
    /* below the exit threshold: both release */
    SDL_JoystickSetVirtualAxis(g_joy[0], 1, 0);
    SDL_JoystickSetVirtualAxis(g_joy[0], 0, 0);
    sdl_process_events(&ctx);
    CHECK(g_kr_n == 2 && ((g_kr[0] == -1 && g_kr[1] == -3) ||
                          (g_kr[0] == -3 && g_kr[1] == -1)),
          "stick center -> keyReleased(UP and LEFT)");

    printf("== 8. MINUS opens the pause menu (frame thread), A resumes ==\n");
    drain();
    /* Realistic timing: MINUS pressed, the menu OPENS (and loops inside
     * sdl_process_events); A is pressed 150 ms LATER from SDL's timer
     * thread via SDL_PushEvent — exactly how a user resumes. */
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_MINUS, 1);
    SDL_PumpEvents();
    SDL_TimerID resume_timer = SDL_AddTimer(150, tsi_resume_cb, NULL);
    CHECK(resume_timer != 0, "pause test: resume timer armed");
    sdl_process_events(&ctx);   /* opens + runs the pause menu until A */
    CHECK(g_pause_open_count >= 1, "pause menu opened on MINUS press");
    CHECK(g_switch_pause_open == 0, "pause menu closed by A (resume)");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_MINUS, 0);
    SDL_PumpEvents();
    drain();
    reset_keys();
    g_switch_pause_req = 0; /* white-box: drop anything stale */

    printf("== 9. game-thread pump is a NO-OP (single-pump rule) ==\n");
    drain();
    g_switch_game_active = 1;
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_A, 1);
    SDL_PumpEvents();                 /* the press is in the queue */
    sdl_process_events_minimal();     /* game thread mid-bytecode — must NOT steal */
    CHECK(g_kp_n == 0, "minimal pump: delivers NOTHING (no re-entrant Java mid-yield)");
    SDL_JoystickSetVirtualButton(g_joy[0], SWJB_A, 0);
    SDL_PumpEvents();
    sdl_process_events_minimal();
    CHECK(g_kr_n == 0, "minimal pump: release also untouched");
    /* the frame pump still delivers the full tap: latch + state repair */
    sdl_process_events(&ctx);
    CHECK(g_kp_n == 1 && g_kp[0] == -5,
          "frame pump: the tap SURVIVED the minimal pump and is delivered");
    CHECK(g_kr_n == 1 && g_kr[0] == -5, "frame pump: release delivered too");

    printf("== 10. hotplug detach / re-attach ==\n");
    {
        SDL_JoystickID iid = SDL_JoystickInstanceID(g_joy[0]);
        CHECK(SDL_JoystickDetachVirtual(dev) == 0, "virtual joystick detached");
        unsigned kk = sdl_switch_ui_pump_keys(); /* drains REMOVED */
        (void)kk;
        CHECK(g_joy[0] == NULL, "slot 0 closed on SDL_JOYDEVICEREMOVED");
        CHECK(switch_joy_slot(iid) == -1, "instance no longer maps");
        drain();
        CHECK(g_joy[0] == NULL, "still closed");
    }
    {
        int dev2 = SDL_JoystickAttachVirtualEx(&desc);
        (void)dev2;
        unsigned kk = sdl_switch_ui_pump_keys(); /* drains ADDED -> open */
        (void)kk;
        CHECK(g_joy[0] != NULL, "pad re-opened after re-attach");
        drain();
        tap_button(SWJB_A);
        kk = sdl_switch_ui_pump_keys();
        CHECK(kk & SWK_A, "menu input works again after hotplug");
    }

    printf("== 11. language: RU default, MINUS-toggle, ini persistence ==\n");
    CHECK(switch_lang() == NOJME_LANG_RU, "lang: Russian by default");
    CHECK(strcmp(switch_text(ST_MENU_OPEN), "\xD0\x9E\xD1\x82\xD0\xBA\xD1\x80\xD1\x8B\xD1\x82\xD1\x8C \xD0\xB8\xD0\xB3\xD1\x80\xD1\x83") == 0,
          "lang: RU menu string");
    CHECK(strstr(switch_lang_badge_text(), "\xD0\xA0\xD1\x83\xD1\x81\xD1\x81\xD0\xBA\xD0\xB8\xD0\xB9") != NULL,
          "lang: badge names the current language (RU)");
    CHECK(strstr(switch_lang_badge_text(), "English") != NULL,
          "lang: badge names the switch target (English)");
    CHECK(switch_lang_toggle() == NOJME_LANG_EN, "lang: toggle -> English");
    CHECK(strcmp(switch_text(ST_MENU_OPEN), "Open game") == 0, "lang: EN menu string");
    CHECK(strcmp(switch_text(ST_PAUSE_TITLE), "PAUSED") == 0, "lang: EN pause title");
    CHECK(strstr(switch_lang_badge_text(), "English") != NULL &&
          strstr(switch_lang_badge_text(), "\xD0\xA0\xD1\x83\xD1\x81\xD1\x81\xD0\xBA\xD0\xB8\xD0\xB9") != NULL,
          "lang: EN badge names the switch target (Russian)");
    {   /* settings.ini persisted with lang=en */
        char inipath[600], line[256];
        snprintf(inipath, sizeof(inipath), "%s/switchui_settings.ini", langdir);
        FILE* f = fopen(inipath, "r");
        int found_en = 0;
        if (f) {
            while (fgets(line, sizeof(line), f))
                if (strncmp(line, "lang=en", 7) == 0) found_en = 1;
            fclose(f);
        }
        CHECK(found_en, "lang: settings.ini persisted lang=en");
    }
    CHECK(switch_lang_toggle() == NOJME_LANG_RU, "lang: toggle back -> Russian");
    CHECK(strcmp(switch_text(ST_PAUSE_TITLE), "\xD0\x9F\xD0\x90\xD0\xA3\xD0\x97\xD0\x90") == 0,
          "lang: RU pause title");

    printf("== 12. FULL MENU E2E: MINUS switches language mid-run ==\n");
    {
        char out[1024] = {0};
        SDL_setenv("NOJME_SWITCH_KEYS", "MINUS:120,A:260,A:420", 1);
        drain();
        reset_keys();
        g_switch_game_active = 0;   /* menu context */
        int r = switch_ui_pick_game(out, sizeof(out));
        SDL_setenv("NOJME_SWITCH_KEYS", "", 1);
        CHECK(r == 1, "e2e: menu session returned a game");
        CHECK(strstr(out, "testgame.jar") != NULL, "e2e: the jar was selected");
        CHECK(switch_lang() == NOJME_LANG_EN, "e2e: language switched to EN mid-run");
    }
    switch_lang_toggle(); /* leave RU for any follow-up runs */

    /* ================= v34.91 freeze triage ================= */
    printf("== 13. trace log: breadcrumbs land in $NOJME_SWITCH_UI_DIR/log.txt ==\n");
    {
        char logpath[600];
        snprintf(logpath, sizeof(logpath), "%s/log.txt", langdir);
        FILE* f = fopen(logpath, "r");
        CHECK(f != NULL, "trace: log.txt exists");
        if (f) {
            char buf[16384];
            size_t n = fread(buf, 1, sizeof(buf) - 1, f);
            fclose(f);
            buf[n] = 0;
            CHECK(strstr(buf, "trace start") != NULL, "trace: banner with build id");
            CHECK(strstr(buf, "menu: session start") != NULL, "trace: menu session start line");
            CHECK(strstr(buf, "scan:") != NULL, "trace: directory scan line");
            CHECK(strstr(buf, "testgame.jar") != NULL, "trace: selected game line");
            CHECK(strstr(buf, "menu: session end (1)") != NULL, "trace: session end line");
        }
        CHECK(sw_trace_line()[0] != 0, "trace: on-screen status line is live");
    }

    printf("== 14. settings screen E2E: A enters settings, navigation, EXIT ==\n");
    {
        /* v34.91: the user freeze report names the SETTINGS entry. Drive it
         * on the host with the same single pump: DOWN -> Настройки, A ->
         * settings screen, DOWN x4 + A (toggle a value), B (back), EXIT. */
        char out[1024] = {0};
        SDL_setenv("NOJME_SWITCH_KEYS",
                   "DOWN:60,A:120,DOWN:180,DOWN:240,A:300,B:360,EXIT:420", 1);
        drain();
        reset_keys();
        g_switch_game_active = 0;
        Uint32 t0 = SDL_GetTicks();
        int r = switch_ui_pick_game(out, sizeof(out));
        Uint32 dt = SDL_GetTicks() - t0;
        SDL_setenv("NOJME_SWITCH_KEYS", "", 1);
        CHECK(r == 0, "settings e2e: session ended via EXIT (not a game)");
        CHECK(dt < 4000, "settings e2e: no hang (completed promptly)");
        CHECK(out[0] == 0, "settings e2e: no game path returned");
    }

    printf("== 15. poisoned games_dir (invalid UTF-8) renders safely ==\n");
    {
        /* v34.91 utf8_trunc fix: a games_dir ending in a lone 0xD0 lead byte
         * must render (settings value column) without walking past the NUL.
         * Enter the settings screen with such an ini and walk the list. */
        char inipath[600];
        snprintf(inipath, sizeof(inipath), "%s/switchui_settings.ini", langdir);
        FILE* f = fopen(inipath, "wb");
        CHECK(f != NULL, "poison: ini writable");
        if (f) {
            fprintf(f, "scale=fit_black\nfilter=nearest\naudio=on\nvm_speed=fast\n");
            fprintf(f, "games_dir=/tmp/\xD0\n"); /* lone lead byte at the end */
            fclose(f);
        }
        /* reset the singleton so the poisoned ini is re-read */
        extern void switch_settings_force_reload_for_test(void);
        switch_settings_force_reload_for_test();

        char out[1024] = {0};
        SDL_setenv("NOJME_SWITCH_KEYS",
                   "DOWN:60,A:120,DOWN:180,DOWN:240,DOWN:300,DOWN:360,EXIT:420", 1);
        drain();
        reset_keys();
        g_switch_game_active = 0;
        int r = switch_ui_pick_game(out, sizeof(out));
        SDL_setenv("NOJME_SWITCH_KEYS", "", 1);
        CHECK(r == 0, "poison: settings session completed (no crash/hang)");
    }

    printf("== 16. browse caps: 25000 junk files + jar still selectable ==\n");
    {
        const char* junkdir = "/tmp/tsi_junk";
        char cmd[600];
        snprintf(cmd, sizeof(cmd), "rm -rf %s && mkdir -p %s", junkdir, junkdir);
        if (system(cmd) == 0) {
            char p[700];
            /* the jar FIRST so readdir keeps it before the scan cap hits */
            snprintf(p, sizeof(p), "%s/thejar.jar", junkdir);
            FILE* jf = fopen(p, "wb");
            if (jf) { fputs("stub", jf); fclose(jf); }
            for (int i = 0; i < 20500; i++) {
                snprintf(p, sizeof(p), "%s/junk_%05d.dat", junkdir, i);
                FILE* f = fopen(p, "wb");
                if (f) fclose(f);
            }
            /* non-UTF-8 (CP1251 "Игры") .jar name: listed AND rendered —
             * exercises the hardened utf8_trunc (v34.91 OOB fix) */
            snprintf(p, sizeof(p), "%s/\xC8\xE3\xF0\xFB.jar", junkdir);
            FILE* f = fopen(p, "wb");
            if (f) { fputs("x", f); fclose(f); }

            char out[1024] = {0};
            SDL_setenv("NOJME_SWITCH_BROWSE_ROOT", junkdir, 1);
            SDL_setenv("NOJME_SWITCH_KEYS", "A:80,A:200", 1);
            drain();
            reset_keys();
            g_switch_game_active = 0;
            Uint32 t0 = SDL_GetTicks();
            int r = switch_ui_pick_game(out, sizeof(out));
            Uint32 dt = SDL_GetTicks() - t0;
            SDL_setenv("NOJME_SWITCH_KEYS", "", 1);
            SDL_setenv("NOJME_SWITCH_BROWSE_ROOT", "", 1);
            CHECK(r == 1, "caps: the jar was still found and selected");
            CHECK(strstr(out, "thejar.jar") != NULL, "caps: correct jar path");
            CHECK(dt < 8000, "caps: scan bounded (no multi-second hang)");
        } else {
            CHECK(0, "caps: junk dir preparation failed");
        }
    }

    sdl_switch_platform_shutdown();
    printf("\n%s (%d failures)\n", g_fail ? "=== FAILURES ===" : "=== ALL SWITCH-INPUT TESTS PASSED ===", g_fail);
    return g_fail ? 1 : 0;
}
