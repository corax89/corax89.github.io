/*
 * J2ME Emulator - SDL2 Backend
 * Cross-platform graphics, input, and audio using SDL2
 * Falls back to stub implementation if SDL2 is not available
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#endif
#include <time.h>

/* Try to include SDL2 - support multiple header locations */
#if defined(HAVE_SDL2) || \
    defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL2/SDL.h>
#  elif __has_include(<SDL.h>)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#else
/* Assume SDL2 might be available, try to include */
#  if defined(_WIN32) || defined(__MINGW32__)
#    define SDL2_AVAILABLE 1
#    include <SDL.h>
#  else
#    define SDL2_AVAILABLE 0
#  endif
#endif

/* v34.86 FIX (pre-existing since the v34.84 key-event refactor): with
 * SDL2_AVAILABLE == 0 the shared helper sdl_handle_key_event() still
 * referenced the SDL_Keycode type in its signature, so `make app` on a
 * host without SDL2 dev headers died with "unknown type name
 * 'SDL_Keycode'" (line ~802). Give the no-SDL no-op backend a dummy
 * typedef so the documented "build WITHOUT SDL" path compiles again. */
#if !SDL2_AVAILABLE
typedef int SDL_Keycode;
#endif

/* v34.88 FIX (devkitA64 "implicit declaration of 'sdl_switch_game_begin'"
* at the sdl_init call site + "'sdl_handle_key_event' defined but not used"):
* both diagnostics together mean this file was compiled WITHOUT any SDL2
* headers on the include path, so the __SWITCH__ glue section (which pulls
* switch/switch_glue.h — the declaration) was compiled out while the
* #ifdef __SWITCH__ call sites stayed. On the Switch, SDL2 is MANDATORY
* (the whole frontend is SDL2): fail loud and early with the actual cause
* instead of a cascade of unrelated errors. See the Makefile v34.88 note
* (PORTLIBS must point at $(DEVKITPRO)/portlibs/switch). */
#if defined(__SWITCH__) && !SDL2_AVAILABLE
#  error "__SWITCH__ build: SDL2 headers not found on the include path. The Switch frontend requires switch-SDL2 (dkp-pacman -S switch-SDL2). Check the PORTLIBS/SDL2 discovery in the Makefile (v34.88)."
#endif

#include "sdl_backend.h"
#include "midp.h"
#include "midi.h"
#include "debug.h"
#include "debug_macros.h"
/* v34.91 freeze triage: stage breadcrumbs — audio-open is a classic
 * emulator hang point, so the shared audio path traces too. Macro no-op
 * when neither __SWITCH__ nor NOJME_SWITCH_TRACE is defined. */
#include "switch/switch_trace.h"

/* Global context */
static SdlContext* g_sdl_ctx_ptr = NULL;

/* Mutex for thread-safe SDL access (only needed when the SDL2 backend is
 * active; without SDL2 the lock macros are never expanded, and defining the
 * mutex unconditionally trips -Wunused-variable) */
#ifdef _WIN32
#include <windows.h>
#endif

#if SDL2_AVAILABLE
#ifdef _WIN32
static CRITICAL_SECTION g_sdl_mutex;
static bool g_sdl_mutex_initialized = false;
#define SDL_LOCK() EnterCriticalSection(&g_sdl_mutex)
#define SDL_UNLOCK() LeaveCriticalSection(&g_sdl_mutex)
#else
#include <pthread.h>
static pthread_mutex_t g_sdl_mutex = PTHREAD_MUTEX_INITIALIZER;
#define SDL_LOCK() pthread_mutex_lock(&g_sdl_mutex)
#define SDL_UNLOCK() pthread_mutex_unlock(&g_sdl_mutex)
#endif
#endif /* SDL2_AVAILABLE */

#if SDL2_AVAILABLE
static SDL_Window* g_window = NULL;
static SDL_Renderer* g_renderer = NULL;
static SDL_Texture* g_texture = NULL;
static SDL_AudioDeviceID g_audio_dev = 0;

/* Key mapping tables
 * 
 * ИСПРАВЛЕНО: Теперь отправляем правильные keyCode по стандарту Nokia FullCanvas:
 * - UP: keyCode = -1 (FULL_UP)
 * - DOWN: keyCode = -2 (FULL_DOWN)
 * - LEFT: keyCode = -3 (FULL_LEFT)
 * - RIGHT: keyCode = -4 (FULL_RIGHT)
 * - FIRE: keyCode = -5 (FULL_FIRE)
 * 
 * game_action используется для getGameAction() конверсии.
 * Многие игры (например Bobby Carrot) проверяют keyCode напрямую,
 * а не через getGameAction(), поэтому keyCode должен быть правильным.
 */
static const struct {
    SDL_Keycode sdl_key;
    int midp_key;       /* keyCode отправляемый в keyPressed() */
    int game_action;    /* game action для getGameAction() */
} key_map[] = {
    /* Цифры - отправляем ASCII коды */
    {SDLK_0, '0', 0}, {SDLK_1, '1', 0}, {SDLK_2, '2', 0},
    {SDLK_3, '3', 0}, {SDLK_4, '4', 0}, {SDLK_5, '5', 0},
    {SDLK_6, '6', 0}, {SDLK_7, '7', 0}, {SDLK_8, '8', 0},
    {SDLK_9, '9', 0}, {SDLK_ASTERISK, '*', 0}, {SDLK_HASH, '#', 0},
    /* Game keys - отправляем keyCode по стандарту Nokia FullCanvas */
    /* Игра Bobby Carrot проверяет: var1 == -5 || var1 == 5 || var1 == 53 для FIRE */
    {SDLK_UP, -1, GAME_UP},      /* keyCode=-1 (Nokia FULL_UP), gameAction=1 */
    {SDLK_DOWN, -2, GAME_DOWN},  /* keyCode=-2 (Nokia FULL_DOWN), gameAction=6 */
    {SDLK_LEFT, -3, GAME_LEFT},  /* keyCode=-3 (Nokia FULL_LEFT), gameAction=2 */
    {SDLK_RIGHT, -4, GAME_RIGHT},/* keyCode=-4 (Nokia FULL_RIGHT), gameAction=5 */
    {SDLK_RETURN, -5, GAME_FIRE},/* keyCode=-5 (Nokia FULL_FIRE), gameAction=8 */
    {SDLK_SPACE, -5, GAME_FIRE}, /* keyCode=-5 (Nokia FULL_FIRE), gameAction=8 */
    /* Soft buttons - F1 = Left Soft, F2 = Right Soft (по стандарту Nokia) */
    /* F1 отправляет keyCode=-6 (стандартный код левой софт-кнопки) */
    /* F2 отправляет keyCode=-7 (стандартный код правой софт-кнопки) */
    {SDLK_F1, -6, 0},            /* Left Soft Key: keyCode=-6 */
    {SDLK_F2, -7, 0},            /* Right Soft Key: keyCode=-7 */
    /* Game A/B/C/D - альтернативные клавиши (используются реже) */
    {SDLK_a, -6, GAME_A},        /* keyCode=-6, gameAction=9 */
    {SDLK_b, -7, GAME_B},        /* keyCode=-7, gameAction=10 */
    {SDLK_c, -8, GAME_C},        /* keyCode=-8, gameAction=11 */
    {SDLK_d, -9, GAME_D},        /* keyCode=-9, gameAction=12 */
    {SDLK_ESCAPE, 0, 0},
};
#define KEY_MAP_SIZE (sizeof(key_map) / sizeof(key_map[0]))

/* Software key repeat for SDL build.
 * SDL2 doesn't generate key repeat events by default.
 * Many J2ME Canvas games rely on repeated keyPressed events for
 * continuous movement. This implements the same repeat behavior as
 * real J2ME phones: initial delay ~400ms, then repeat at ~80ms interval.
 */
#define SDL_KEY_REPEAT_DELAY_MS   400
#define SDL_KEY_REPEAT_INTERVAL_MS 80
#define SDL_KEY_REPEAT_MAX_KEYS   256  /* Based on SDL_Keycode range */

static struct {
    uint64_t press_time[SDL_KEY_REPEAT_MAX_KEYS];      /* When key was first pressed */
    uint64_t last_repeat_time[SDL_KEY_REPEAT_MAX_KEYS]; /* Last repeat event time */
    bool is_held[SDL_KEY_REPEAT_MAX_KEYS];             /* Key is currently held */
} g_sdl_key_repeat = {{0}, {0}, {false}};

/* Convert SDL_Keycode to index for repeat tracking (handles negative values) */
static int sdl_key_to_repeat_idx(SDL_Keycode key) {
    /* SDL_Keycode values can be negative (e.g. SDLK_RETURN = 13)
     * Map them to positive indices by adding an offset */
    int idx = (int)key + 128;  /* Shift to make most keys positive */
    if (idx < 0) idx = 0;
    if (idx >= SDL_KEY_REPEAT_MAX_KEYS) idx = SDL_KEY_REPEAT_MAX_KEYS - 1;
    return idx;
}

/* Get current time in milliseconds */
static uint64_t sdl_get_time_ms(void) {
    return SDL_GetTicks();
}

/* Process software key repeat - call this after event handling */
static void sdl_process_key_repeat(SdlContext* ctx) {
    if (!ctx || !ctx->jvm) return;
    
    uint64_t now = sdl_get_time_ms();
    
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        SDL_Keycode key = key_map[i].sdl_key;
        int midp_key = key_map[i].midp_key;
        int game_action = key_map[i].game_action;
        
        /* Skip soft keys, escape, etc. - they should not repeat */
        if (key == SDLK_F1 || key == SDLK_F2 || key == SDLK_ESCAPE || key == SDLK_F12) {
            continue;
        }
        
        /* Skip if no valid key to send */
        if (!midp_key && !game_action) continue;
        
        int idx = sdl_key_to_repeat_idx(key);
        
        if (g_sdl_key_repeat.is_held[idx]) {
            uint64_t hold_duration = now - g_sdl_key_repeat.press_time[idx];
            uint64_t since_last = now - g_sdl_key_repeat.last_repeat_time[idx];
            
            if (hold_duration >= SDL_KEY_REPEAT_DELAY_MS &&
                since_last >= SDL_KEY_REPEAT_INTERVAL_MS) {
                /* Generate repeat event.
                 * FIX (audit M-3, v18): deliver as keyRepeated() on canvases
                 * that implement it, not as a phantom extra keyPressed(). */
                g_sdl_key_repeat.last_repeat_time[idx] = now;
                int keycode = midp_key ? midp_key : game_action;
                midp_call_keyRepeated(ctx->jvm, keycode);
            }
        }
    }
}

/* Note: Audio uses SDL_QueueAudio() for queue-based playback.
 * No callback needed - samples are generated in media.c audio thread. */

#endif /* SDL2_AVAILABLE */

/*
 * switch_glue_impl.c.txt — the __SWITCH__ section of sdl_graphics.c.
 * Inserted by scripts/switch_patch_sdl.py after the key-repeat block.
 * Everything here is compiled ONLY when __SWITCH__ is defined (real
 * devkitPro build) or in the Linux verification build (same define).
 */
#if defined(__SWITCH__) && SDL2_AVAILABLE

#include "switch/switch_glue.h"
#include "switch/switch_common.h"
#include "switch/switch_scaling.h"
#include "switch/switch_font.h"
#include "switch/switch_trace.h" /* v34.91: freeze triage (real impl: __SWITCH__/verify) */

extern void midlet_call_destroy_app(JVM* jvm, bool unconditional);

/* defined below (extracted v34.84): shared keyboard-event handler the
 * gamepad path re-dispatches through */
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat);

/* ============================ state ============================ */

static SDL_Texture* g_ui_tex = NULL;      /* 1280x720 menu canvas */
static uint32_t* g_ui_canvas = NULL;      /* CPU side of the same */
static SDL_Texture* g_bg_tex = NULL;      /* small blurred background */
static uint32_t* g_bg_buf = NULL;
static int g_bg_w = 0, g_bg_h = 0;
static SDL_Rect g_game_rect = {0, 0, 0, 0};  /* last presented game rect */
static volatile int g_switch_game_active = 0; /* between game_begin/game_end */
static unsigned g_menu_held = 0;          /* held menu-key bitmask */

/* v34.89: RAW-JOYSTICK input replaces the GameController API.
 * switch-SDL2 exposes the pads as plain joysticks and often ships NO
 * GameController mapping: SDL_IsGameController() returns false, no
 * SDL_CONTROLLER* events are ever delivered and the frontend looks
 * completely dead (user report: controls do not work in an emulator).
 * Raw SDL_JOY* events are the devkitPro-example pattern that works on
 * real hardware AND in emulators. Joystick events only flow for OPENED
 * devices, so every pad is opened right after SDL_Init. */
#define SWITCH_JOY_SLOTS 4
static SDL_Joystick* g_joy[SWITCH_JOY_SLOTS];         /* opened pads */
static SDL_JoystickID g_joy_instance[SWITCH_JOY_SLOTS] = {-1,-1,-1,-1};
static volatile int g_switch_pause_req = 0;  /* v34.90: vestigial latch (nothing sets it
                                              * anymore - MINUS is handled inline by
                                              * the frame pump); kept for ABI/log parity */
static volatile int g_switch_pause_open = 0; /* pause menu is on screen */

/* Raw button indices of the switch-SDL2 joystick driver — libnx HID bit
 * order (A..MINUS are bits 0..11, D-pad L,U,R,D are bits 12..15). */
enum {
    SWJB_A = 0,  SWJB_B = 1,  SWJB_X = 2,  SWJB_Y = 3,
    SWJB_LSTICK = 4, SWJB_RSTICK = 5,
    SWJB_L = 6,  SWJB_R = 7,  SWJB_ZL = 8, SWJB_ZR = 9,
    SWJB_PLUS = 10, SWJB_MINUS = 11,
    SWJB_LEFT = 12, SWJB_UP = 13, SWJB_RIGHT = 14, SWJB_DOWN = 15
};

/* ---------------- v34.90 central input state ----------------
 * Single source of truth for ALL Switch input (see the full design comment
 * at switch_input_pump below). Declared before every consumer, filled only
 * by switch_input_pump() on the main/frame context. */
typedef struct {
    uint16_t held[SWITCH_JOY_SLOTS];    /* live button state (bit = SWJB_*) */
    uint16_t prev[SWITCH_JOY_SLOTS];    /* state at the previous pump */
    uint16_t latch[SWITCH_JOY_SLOTS];   /* JOYBUTTONDOWN events seen this pump */
    int      dir[SWITCH_JOY_SLOTS];     /* stick->dpad mask: 1=u 2=d 4=l 8=r */
    int      dir_prev[SWITCH_JOY_SLOTS];
    unsigned kb_edge;                   /* keyboard press edges this pump */
    unsigned kb_held;                   /* keyboard held bits */
    int      touch_x, touch_y;          /* window pixels (SWITCH_UI_*) */
    int      touch_down;
    int      touch_moved;               /* FINGERMOTION seen while down */
    int      quit;                      /* SDL_QUIT seen this pump */
} SwitchInputState;

static SwitchInputState g_sw_in;

static void switch_input_reset(void) {
    memset(&g_sw_in, 0, sizeof(g_sw_in));
}

/* Acknowledge the CURRENT held state without firing edges (pause-menu
 * open/close): a button held THROUGH the menu must not re-press when the
 * game resumes. */
static void switch_input_settle(void) {
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        g_sw_in.prev[i] = g_sw_in.held[i];
        g_sw_in.latch[i] = 0;
        g_sw_in.dir_prev[i] = g_sw_in.dir[i];
    }
    g_sw_in.kb_edge = 0;
    g_sw_in.touch_moved = 0;
}

/* Event instance-id -> slot (events only arrive for OPENED pads). */
static int switch_joy_slot(SDL_JoystickID id) {
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++)
        if (g_joy[i] && g_joy_instance[i] == id) return i;
    return -1;
}

/* Open device `idx' into a free slot (idempotent for already-open pads). */
static void switch_joy_open_index(int idx) {
    if (idx < 0 || idx >= SDL_NumJoysticks()) return;
#if SDL_VERSION_ATLEAST(2, 0, 14)
    {   /* SDL2 queues SDL_JOYDEVICEADDED for pads present at SDL_Init —
         * skip the duplicate open when the direct init-time open won. */
        SDL_JoystickID iid = SDL_JoystickGetDeviceInstanceID(idx);
        if (iid >= 0 && switch_joy_slot(iid) >= 0) return;
    }
#endif
    int slot = -1;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) if (!g_joy[i]) { slot = i; break; }
    if (slot < 0) return;
    g_joy[slot] = SDL_JoystickOpen(idx);
    if (g_joy[slot]) {
        SDL_JoystickID new_iid = SDL_JoystickInstanceID(g_joy[slot]);
        /* v34.90: if ANOTHER slot already holds this instance, the same
         * physical pad is being opened a second time (the init-time open
         * won and the queued SDL_JOYDEVICEADDED was processed on an SDL
         * older than 2.0.14, where the GetDeviceInstanceID guard above is
         * compiled out). A pad opened twice double-fires every event;
         * close the duplicate immediately. */
        for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
            if (i != slot && g_joy[i] && g_joy_instance[i] == new_iid) {
                SDL_JoystickClose(g_joy[slot]);
                g_joy[slot] = NULL;
                LOG_SAFE("[SWITCH] joystick device %d already open in slot %d - duplicate closed\n",
                         idx, i);
                return;
            }
        }
        g_joy_instance[slot] = new_iid;
        const char* nm = SDL_JoystickName(g_joy[slot]);
        LOG_SAFE("[SWITCH] joystick slot %d (device %d) open: %s\n",
                 slot, idx, nm ? nm : "(unnamed)");
    } else {
        LOG_SAFE("[SWITCH] joystick slot %d (device %d) open FAILED\n", slot, idx);
    }
}

/* SDL_JOYDEVICEADDED / SDL_JOYDEVICEREMOVED (rails attach/detach, pads).
 * ADDED carries a device INDEX, REMOVED an instance id (SDL2 semantics). */
static void switch_joy_hotplug(const SDL_Event* e) {
    if (e->type == SDL_JOYDEVICEADDED) {
        switch_joy_open_index(e->jdevice.which);
        return;
    }
    if (e->type == SDL_JOYDEVICEREMOVED) {
        int slot = switch_joy_slot(e->jdevice.which);
        if (slot >= 0) {
            SDL_JoystickClose(g_joy[slot]);
            g_joy[slot] = NULL;
            g_joy_instance[slot] = -1;
            /* v34.90: clear the slot in the central input state as well */
            g_sw_in.held[slot] = g_sw_in.prev[slot] = g_sw_in.latch[slot] = 0;
            g_sw_in.dir[slot] = g_sw_in.dir_prev[slot] = 0;
            LOG_SAFE("[SWITCH] joystick slot %d removed\n", slot);
        }
    }
}

/* ======================= platform bootstrap ======================= */

int sdl_switch_platform_init(void) {
    static int done = 0;
    if (done) return g_window ? 0 : -1;
    done = 1;

    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"); /* linear filtering */
    /* v34.89: SDL_INIT_JOYSTICK, not GAMECONTROLLER — raw SDL_JOY* events
     * are the only input path that works on every switch-SDL2 setup.
     * v34.91: + SDL_INIT_TIMER — the freeze-triage heartbeat (see
     * switch_trace.c) rides an SDL timer thread. */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS |
                 SDL_INIT_JOYSTICK | SDL_INIT_TIMER) != 0) {
        LOG_SAFE("[SWITCH] SDL_Init failed: %s\n", SDL_GetError());
        return -1;
    }
#ifdef __SWITCH__
    g_window = SDL_CreateWindow("J2ME Emulator",
                                SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                                SDL_WINDOW_FULLSCREEN);
#else
    /* verification build: windowed, resizable off, same geometry */
    g_window = SDL_CreateWindow("nojme Switch UI (verify)",
                                SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                                SDL_WINDOW_SHOWN);
#endif
    if (!g_window) {
        LOG_SAFE("[SWITCH] window failed: %s\n", SDL_GetError());
        return -1;
    }
    g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED);
    if (!g_renderer) {
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);
    }
    if (!g_renderer) {
        LOG_SAFE("[SWITCH] renderer failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(g_window);
        g_window = NULL;
        SDL_Quit();
        return -1;
    }
    g_ui_tex = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                 SDL_TEXTUREACCESS_STREAMING,
                                 SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT);
    if (!g_ui_tex) {
        LOG_SAFE("[SWITCH] UI texture failed: %s\n", SDL_GetError());
        return -1;
    }
    SDL_SetTextureBlendMode(g_ui_tex, SDL_BLENDMODE_BLEND);
    g_ui_canvas = (uint32_t*)malloc((size_t)SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT * 4);
    if (!g_ui_canvas) return -1;

    /* v34.89: open up to SWITCH_JOY_SLOTS raw pads — joystick events are
     * delivered only for OPENED devices (1 combined pad in handheld
     * mode, 2 when the joy-cons are paired separately, up to 4 pads). */
    for (int i = 0; i < SDL_NumJoysticks() && i < SWITCH_JOY_SLOTS; i++) {
        switch_joy_open_index(i);
    }
    if (SDL_NumJoysticks() <= 0) {
        LOG_SAFE("[SWITCH] no joystick detected (keyboard fallback active)\n");
    }
    LOG_SAFE("[SWITCH] platform init OK (%s renderer)\n",
             SDL_GetCurrentVideoDriver());
    return 0;
}

void sdl_switch_platform_shutdown(void) {
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        if (g_joy[i]) { SDL_JoystickClose(g_joy[i]); g_joy[i] = NULL; }
    }
    if (g_ui_tex) { SDL_DestroyTexture(g_ui_tex); g_ui_tex = NULL; }
    free(g_ui_canvas); g_ui_canvas = NULL;
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
}

/* ======================= menu canvas / input ======================= */

uint32_t* sdl_switch_ui_canvas(void) { return g_ui_canvas; }

static unsigned kb_key_bit(const SDL_Event* e) {
    switch (e->key.keysym.sym) {
        case SDLK_UP:    return SWK_UP;
        case SDLK_DOWN:  return SWK_DOWN;
        case SDLK_LEFT:  return SWK_LEFT;
        case SDLK_RIGHT: return SWK_RIGHT;
        case SDLK_RETURN:
        case SDLK_KP_ENTER:
        case SDLK_SPACE: return SWK_A;
        case SDLK_ESCAPE:
        case SDLK_BACKSPACE: return SWK_B;
        case SDLK_q:     return SWK_EXIT;
        default: return 0;
    }
}

/* ==================== v34.90 SINGLE-PUMP input ====================
 * FORENSICS (user report: «кнопки сразу работали, но затем перестали, я так
 * и не смог попасть ни в один из пунктов меню — возможно ВМ перехватывает
 * события»): v34.89 still drained the SDL queue from TWO places during a
 * game — the frame pump (sdl_process_events) AND the game-thread pump
 * (sdl_process_events_minimal, called from thread_yield() every ~16k
 * opcodes MID-BYTECODE on a yielding VM fiber, plus from Thread.sleep).
 * The game-thread pump re-dispatched soft keys (X/B ->
 * midp_handle_soft_button), FIRE while a command menu was open and EVERY
 * touch event through paths that execute JAVA directly
 * (call_command_action / pointerPressed -> execute_method) RE-ENTRANTLY
 * from the middle of the yield — corrupting interpreter state and/or
 * leaving the command menu stuck open, after which it swallows every
 * FIRE/UP/DOWN («не смог попасть ни в один из пунктов меню»). That is
 * exactly «ВМ перехватывает события».
 *
 * FIX (the user's own suggestion — «лучше забирать их из одного места»):
 * ONE pump owns the SDL queue on __SWITCH__. switch_input_pump() runs only
 * on the main/frame context: the frontend menu loop, the frame pump, the
 * pause menu and the finished screen. The game thread (Thread.sleep /
 * thread_yield) NEVER touches SDL events — sdl_process_events_minimal()
 * is a no-op on __SWITCH__, so mid-bytecode re-entrant Java execution is
 * impossible by construction. Input reaches a game with at most one frame
 * (~16 ms) of latency.
 *
 * ROBUSTNESS (the «then they stopped» insurance): press edges are
 * EVENT-FIRST (SDL_JOYBUTTONDOWN latches — a tap shorter than one pump
 * interval still registers) plus STATE-REPAIR (SDL_JoystickGetButton
 * ground truth on every pump — lost, duplicated or swallowed events
 * self-heal on the next pump). Stick->dpad uses hysteresis (enter past
 * 0.50, exit below 0.35) so threshold jitter cannot spam direction edges. */
/* THE pump: drain the queue, refresh ground-truth pad state, derive edges.
 * Press edge  per button = (held | latch) & ~prev   — a full tap inside one
 * pump interval still counts (latch), a lost event still counts (state).
 * Release edge per button = ~held & (prev | latch).  All state lives in one
 * struct updated ONLY from the main/frame context — no locking needed. */
static void switch_input_pump(void) {
    g_sw_in.quit = 0;
    g_sw_in.touch_moved = 0;
    g_sw_in.kb_edge = 0;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) g_sw_in.latch[i] = 0;

    SDL_Event e;
    while (SDL_PollEvent(&e)) {
        switch (e.type) {
            case SDL_QUIT:
                g_sw_in.quit = 1;
                break;
            case SDL_JOYDEVICEADDED:
            case SDL_JOYDEVICEREMOVED:
                switch_joy_hotplug(&e);
                break;
            case SDL_JOYBUTTONDOWN:
                if (e.jbutton.button < 16) {
                    for (int i = 0; i < SWITCH_JOY_SLOTS; i++)
                        if (g_joy[i] && g_joy_instance[i] == e.jbutton.which)
                            g_sw_in.latch[i] |= (uint16_t)(1u << e.jbutton.button);
                }
                break;
            case SDL_KEYDOWN:
            case SDL_KEYUP: {
                unsigned bit = kb_key_bit(&e);
                if (bit) {
                    if (e.type == SDL_KEYDOWN) {
                        if (!e.key.repeat) g_sw_in.kb_edge |= bit;
                        g_sw_in.kb_held |= bit;
                    } else {
                        g_sw_in.kb_held &= ~bit;
                    }
                }
                break;
            }
            case SDL_FINGERDOWN:
            case SDL_FINGERUP:
            case SDL_FINGERMOTION:
                g_sw_in.touch_x = (int)(e.tfinger.x * SWITCH_UI_WIDTH);
                g_sw_in.touch_y = (int)(e.tfinger.y * SWITCH_UI_HEIGHT);
                if (e.type == SDL_FINGERDOWN) g_sw_in.touch_down = 1;
                if (e.type == SDL_FINGERUP)   g_sw_in.touch_down = 0;
                if (e.type == SDL_FINGERMOTION && g_sw_in.touch_down)
                    g_sw_in.touch_moved = 1;
                break;
            default:
                break; /* drained and ignored (MOUSE*, AXIS, WINDOWEVENT...) */
        }
    }

    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        if (!g_joy[i]) {
            g_sw_in.prev[i] = g_sw_in.held[i] = 0;
            g_sw_in.dir_prev[i] = g_sw_in.dir[i] = 0;
            continue;
        }
        uint16_t h = 0;
        for (int b = 0; b < 16; b++)
            if (SDL_JoystickGetButton(g_joy[i], b)) h |= (uint16_t)(1u << b);
        g_sw_in.prev[i] = g_sw_in.held[i];
        g_sw_in.held[i] = h;

        /* stick -> dpad with hysteresis: enter past 0.50, exit below 0.35 */
        float ax = (float)SDL_JoystickGetAxis(g_joy[i], 0) / 32767.0f;
        float ay = (float)SDL_JoystickGetAxis(g_joy[i], 1) / 32767.0f;
        int dir = g_sw_in.dir[i];
        if (ax < -0.50f) dir |= 4; else if (ax > -0.35f) dir &= ~4;
        if (ax >  0.50f) dir |= 8; else if (ax <  0.35f) dir &= ~8;
        if (ay < -0.50f) dir |= 1; else if (ay > -0.35f) dir &= ~1;
        if (ay >  0.50f) dir |= 2; else if (ay <  0.35f) dir &= ~2;
        g_sw_in.dir_prev[i] = g_sw_in.dir[i];
        g_sw_in.dir[i] = dir;
    }
}

unsigned sdl_switch_ui_pump_keys(void) {
    switch_input_pump();
    unsigned pressed = 0;
    unsigned held = 0;
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        uint16_t pe = (uint16_t)((g_sw_in.held[i] | g_sw_in.latch[i]) & ~g_sw_in.prev[i]);
        uint16_t h  = g_sw_in.held[i];
        int de = g_sw_in.dir[i] & ~g_sw_in.dir_prev[i]; /* stick edges navigate too */
        if (pe & (1u << SWJB_UP))    pressed |= SWK_UP;
        if (pe & (1u << SWJB_DOWN))  pressed |= SWK_DOWN;
        if (pe & (1u << SWJB_LEFT))  pressed |= SWK_LEFT;
        if (pe & (1u << SWJB_RIGHT)) pressed |= SWK_RIGHT;
        if (pe & ((1u << SWJB_A) | (1u << SWJB_PLUS))) pressed |= SWK_A;
        if (pe & (1u << SWJB_B))     pressed |= SWK_B;
        if (pe & (1u << SWJB_MINUS)) pressed |= SWK_MINUS; /* v34.90: язык */
        if (de & 1) pressed |= SWK_UP;
        if (de & 2) pressed |= SWK_DOWN;
        if (de & 4) pressed |= SWK_LEFT;
        if (de & 8) pressed |= SWK_RIGHT;
        if (h & (1u << SWJB_UP))    held |= SWK_UP;
        if (h & (1u << SWJB_DOWN))  held |= SWK_DOWN;
        if (h & (1u << SWJB_LEFT))  held |= SWK_LEFT;
        if (h & (1u << SWJB_RIGHT)) held |= SWK_RIGHT;
        if (h & ((1u << SWJB_A) | (1u << SWJB_PLUS))) held |= SWK_A;
        if (h & (1u << SWJB_B))     held |= SWK_B;
    }
    pressed |= g_sw_in.kb_edge;
    if (g_sw_in.quit) pressed |= SWK_EXIT;
    /* v34.90: held is the LIVE pad state — valid on EVERY call (v34.89 kept
     * it only in the pump that happened to see the DOWN event, so browser
     * hold-to-repeat could never engage). */
    g_menu_held = held | g_sw_in.kb_held;
    return pressed;
}

unsigned sdl_switch_ui_held_keys(void) { return g_menu_held; }

void sdl_switch_ui_present(void) {
    if (!g_ui_tex || !g_renderer || !g_ui_canvas) return;
    SDL_UpdateTexture(g_ui_tex, NULL, g_ui_canvas,
                      SWITCH_UI_WIDTH * sizeof(uint32_t));
    SDL_RenderClear(g_renderer);
    SDL_RenderCopy(g_renderer, g_ui_tex, NULL, NULL);
    SDL_RenderPresent(g_renderer);
}

static uint64_t switch_ticks_ms(void) {
    static Uint64 freq = 0;
    if (!freq) freq = SDL_GetPerformanceFrequency();
    Uint64 c = SDL_GetPerformanceCounter();
    return freq ? (uint64_t)(c * 1000ULL / freq) : SDL_GetTicks();
}

uint64_t sdl_switch_ui_ticks_ms(void) { return switch_ticks_ms(); }

void sdl_switch_ui_wait(uint32_t ms) { SDL_Delay(ms); }

/* ======================= game session ======================= */

int sdl_switch_game_begin(int fb_w, int fb_h) {
    if (!g_renderer) return -1;
    sw_trace("game: begin %dx%d", fb_w, fb_h); /* v34.91 */
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }

    const SwitchSettings* st = switch_settings_get();
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,
                st->filter == NOJME_FILTER_LINEAR ? "1" : "0");

    g_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                  SDL_TEXTUREACCESS_STREAMING, fb_w, fb_h);
    if (!g_texture) {
        LOG_SAFE("[SWITCH] game texture %dx%d failed: %s\n",
                 fb_w, fb_h, SDL_GetError());
        return -1;
    }
    switch_scaling_bg_size(fb_w, fb_h, &g_bg_w, &g_bg_h);
    if (g_bg_tex) { SDL_DestroyTexture(g_bg_tex); g_bg_tex = NULL; }
    g_bg_tex = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
                                 SDL_TEXTUREACCESS_STREAMING, g_bg_w, g_bg_h);
    free(g_bg_buf);
    g_bg_buf = (uint32_t*)malloc((size_t)g_bg_w * g_bg_h * sizeof(uint32_t));
    g_switch_game_active = 1;
    switch_input_reset(); /* v34.90: no edges leak across the menu->game seam */
    g_game_rect.x = g_game_rect.y = g_game_rect.w = g_game_rect.h = 0;
    LOG_SAFE("[SWITCH] game session %dx%d (scale=%d filter=%d bg=%dx%d)\n",
             fb_w, fb_h, st->scale_mode, st->filter, g_bg_w, g_bg_h);
    return 0;
}

void sdl_switch_game_end(void) {
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_bg_tex) { SDL_DestroyTexture(g_bg_tex); g_bg_tex = NULL; }
    free(g_bg_buf); g_bg_buf = NULL;
    g_switch_game_active = 0;
    switch_input_reset(); /* v34.90: the frontend menu starts from clean edges */
    /* close any game audio so the menu is silent */
    if (g_audio_dev) { SDL_CloseAudioDevice(g_audio_dev); g_audio_dev = 0; }
    LOG_SAFE("[SWITCH] game session end\n");
}

/* ======================= present with scaling ======================= */

static void sdl_switch_present_game(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) return;

    const SwitchSettings* st = switch_settings_get();
    int x, y, w, h;
    switch_scaling_game_rect(st->scale_mode, ctx->width, ctx->height,
                             SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, &x, &y, &w, &h);
    g_game_rect.x = x; g_game_rect.y = y; g_game_rect.w = w; g_game_rect.h = h;

    sdl_update_texture(ctx); /* uploads the SETTLED frame (v34.61 semantics) */

    if (st->scale_mode == NOJME_SCALE_FIT_BLUR && g_bg_tex && g_bg_buf) {
        /* 1/8-size box downsample + blur, GPU stretches it linearly */
        {
            extern uint32_t midp_present_stable_copy(uint32_t* dst, int dst_px);
            static uint32_t* s_scanout = NULL;
            static int s_scanout_px = 0;
            int px = ctx->width * ctx->height;
            const uint32_t* src = ctx->framebuffer;
            if (px > 0 && px <= 8192 * 8192) {
                if (px > s_scanout_px) {
                    uint32_t* nb = (uint32_t*)realloc(s_scanout,
                                                      (size_t)px * sizeof(uint32_t));
                    if (nb) { s_scanout = nb; s_scanout_px = px; }
                }
                if (s_scanout && midp_present_stable_copy(s_scanout, px) == 0)
                    src = s_scanout;
            }
            switch_scaling_blur_bg(src, ctx->width, ctx->height,
                                   g_bg_buf, g_bg_w, g_bg_h, 2);
        }
        SDL_UpdateTexture(g_bg_tex, NULL, g_bg_buf, g_bg_w * sizeof(uint32_t));
        SDL_RenderCopy(g_renderer, g_bg_tex, NULL, NULL); /* stretched full screen */
    } else {
        SDL_SetRenderDrawColor(g_renderer, 0, 0, 0, 255);
        SDL_RenderClear(g_renderer);
    }
    SDL_RenderCopy(g_renderer, g_texture, NULL, &g_game_rect);
    SDL_RenderPresent(g_renderer);
}

/* ======================= gamepad -> MIDP keys ======================= */

/* Raw joystick button index -> synthetic keycode. Re-dispatch through
 * sdl_handle_key_event: feeds the SAME soft-button, menu-navigation
 * and key-repeat bookkeeping as the keyboard path. */
static SDL_Keycode switch_joy_button_to_keycode(int b) {
    switch (b) {
        case SWJB_UP:    return SDLK_UP;
        case SWJB_DOWN:  return SDLK_DOWN;
        case SWJB_LEFT:  return SDLK_LEFT;
        case SWJB_RIGHT: return SDLK_RIGHT;
        case SWJB_A:     return SDLK_RETURN; /* FIRE */
        case SWJB_B:     return SDLK_F2;     /* right soft */
        case SWJB_X:     return SDLK_F1;     /* left soft */
        case SWJB_Y:     return SDLK_c;      /* GAME_C/clear */
        case SWJB_L:     return SDLK_ASTERISK;
        case SWJB_R:     return SDLK_HASH;
        case SWJB_PLUS:  return SDLK_RETURN; /* v34.89: PLUS = 2nd FIRE */
        default: return 0;
    }
}

/* v34.90: stick->dpad direction edges from the CENTRAL pump state
 * (hysteresis-protected — see switch_input_pump). Dispatched only by the
 * frame pump. */
static void sdl_switch_dir_dispatch(SdlContext* ctx, int slot) {
    struct { int bit; SDL_Keycode key; } dirs[4] = {
        {1, SDLK_UP}, {2, SDLK_DOWN}, {4, SDLK_LEFT}, {8, SDLK_RIGHT},
    };
    int d = g_sw_in.dir[slot], dp = g_sw_in.dir_prev[slot];
    for (int i = 0; i < 4; i++) {
        int was = (dp >> i) & 1, now = (d >> i) & 1;
        if (was != now) sdl_handle_key_event(ctx, dirs[i].key, now ? true : false, false);
    }
}

/* ======================= in-game pause menu ======================= */

/* Runs while the main frame loop is blocked: no jvm_frontend_frame_tick
 * happens here, so the v34.81 watchdog parks ALL VM threads after the
 * 300 ms stall threshold and virtual time freezes (exactly the RetroArch
 * menu behavior). A resumes, B exits the game back to the frontend menu. */
static void sdl_switch_pause_menu(SdlContext* ctx) {
    LOG_SAFE("[SWITCH] pause menu open\n");
    sw_trace("pause: open"); /* v34.91 */
    g_switch_pause_open = 1;
    g_switch_pause_req = 0; /* drop duplicate MINUS requests */
    switch_input_settle(); /* v34.90: drop the MINUS latch that opened us */
    uint32_t* cv = sdl_switch_ui_canvas();
    if (!cv) { g_switch_pause_open = 0; return; }

    for (;;) {
        unsigned keys = sdl_switch_ui_pump_keys();
        /* v34.90: MINUS switches the UI language here too; the badge in the
         * top-left corner shows the current language and the hint. */
        if (keys & SWK_MINUS) switch_lang_toggle();
        if (keys & SWK_A) break;                 /* продолжить */
        if (keys & SWK_B || keys & SWK_EXIT) {   /* выход в меню */
            if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
            ctx->running = false;
            if (ctx->jvm) ctx->jvm->running = false;
            LOG_SAFE("[SWITCH] pause menu -> exit game\n");
            break;
        }

        /* отрисовка: последний кадр игры + полупрозрачное затемнение */
        if (g_texture && g_renderer) {
            const SwitchSettings* st = switch_settings_get();
            int x, y, w, h;
            switch_scaling_game_rect(st->scale_mode, ctx->width, ctx->height,
                                     SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, &x, &y, &w, &h);
            SDL_SetRenderDrawColor(g_renderer, 0, 0, 0, 255);
            SDL_RenderClear(g_renderer);
            if (st->scale_mode == NOJME_SCALE_FIT_BLUR && g_bg_tex && g_bg_buf) {
                SDL_RenderCopy(g_renderer, g_bg_tex, NULL, NULL);
            }
            SDL_RenderCopy(g_renderer, g_texture, NULL,
                           &(SDL_Rect){x, y, w, h});
        }
        /* overlay */
        for (int i = 0; i < SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT; i++)
            cv[i] = 0x90000000u;
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 200, switch_text(ST_PAUSE_TITLE), 0xFFFFFFFF, 0, 4);
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 320, switch_text(ST_PAUSE_RESUME), 0xFFE8ECF4, 0, 2);
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              480, 360, switch_text(ST_PAUSE_EXIT), 0xFFE8ECF4, 0, 2);
        /* v34.90: language badge in the top-left corner of the pause overlay */
        switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                              32, 24, switch_lang_badge_text(), 0xFFB9C2D4, 0, 2);
        if (g_ui_tex && g_renderer) {
            SDL_UpdateTexture(g_ui_tex, NULL, cv, SWITCH_UI_WIDTH * sizeof(uint32_t));
            SDL_RenderCopy(g_renderer, g_ui_tex, NULL, NULL);
            SDL_RenderPresent(g_renderer);
        }
        SDL_Delay(16);
    }
    g_switch_pause_open = 0;
    g_switch_pause_req = 0; /* a MINUS stolen during the menu must not reopen it */
    switch_input_settle(); /* v34.90: held-through buttons must not re-press */
    sw_trace("pause: close"); /* v34.91 */
    LOG_SAFE("[SWITCH] pause menu close\n");
}

/* ======================= touch -> pointer ======================= */

/* v34.90: touch dispatch from the CENTRAL pump state (one
 * pressed/released/dragged transition per frame — motion floods collapse
 * by design). Runs only on the frame thread: pointerPressed/
 * pointerReleased execute Java (execute_method), so delivering them from
 * the game-thread pump was the re-entrancy hole. */
static void sdl_switch_pointer_dispatch(SdlContext* ctx) {
    if (!ctx->jvm) return;
    extern void midp_call_pointerPressed(JVM* jvm, int x, int y);
    extern void midp_call_pointerReleased(JVM* jvm, int x, int y);
    extern void midp_call_pointerDragged(JVM* jvm, int x, int y);

    static int prev_down = 0;
    static int prev_x = -1, prev_y = -1;

    /* map window -> game canvas through the CURRENT game rect */
    int gx = 0, gy = 0;
    if (g_game_rect.w > 0 && g_game_rect.h > 0) {
        gx = (g_sw_in.touch_x - g_game_rect.x) * ctx->width / g_game_rect.w;
        gy = (g_sw_in.touch_y - g_game_rect.y) * ctx->height / g_game_rect.h;
        if (gx < 0) gx = 0;
        if (gy < 0) gy = 0;
        if (gx >= ctx->width) gx = ctx->width - 1;
        if (gy >= ctx->height) gy = ctx->height - 1;
    }
    ctx->input.pointer_x = gx;
    ctx->input.pointer_y = gy;

    if (g_sw_in.touch_down && !prev_down) {
        ctx->input.pointer_pressed = true;
        midp_call_pointerPressed(ctx->jvm, gx, gy);
    } else if (!g_sw_in.touch_down && prev_down) {
        ctx->input.pointer_pressed = false;
        midp_call_pointerReleased(ctx->jvm, gx, gy);
    } else if (g_sw_in.touch_down && prev_down && g_sw_in.touch_moved &&
               (gx != prev_x || gy != prev_y)) {
        midp_call_pointerDragged(ctx->jvm, gx, gy);
    }
    prev_down = g_sw_in.touch_down;
    prev_x = gx; prev_y = gy;
}

#endif /* __SWITCH__ && SDL2_AVAILABLE */


/* Initialize SDL */
int sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {
    DEBUG_LOG("[SDL] Initializing %dx%d (scale: %d, headless: %s)", width, height, scale, headless ? "yes" : "no");

#ifdef _WIN32
    /* Initialize mutex for Windows */
    if (!g_sdl_mutex_initialized) {
        InitializeCriticalSection(&g_sdl_mutex);
        g_sdl_mutex_initialized = true;
    }
#endif

    /* Use the global context pointer set by main.c */
    if (!g_sdl_ctx_ptr) {
        DEBUG_LOG("[SDL] ERROR: g_sdl_ctx_ptr is NULL - must be set before sdl_init");
        return -1;
    }
    
    SdlContext* ctx = g_sdl_ctx_ptr;
    memset(ctx, 0, sizeof(SdlContext));
    ctx->width = width;
    ctx->height = height;
    ctx->scale = scale;
    ctx->jvm = jvm;
    ctx->running = true;
    ctx->target_fps = 60;  /* Default FPS */
    ctx->headless = headless;  /* Store headless flag */
    ctx->input.pointer_x = 0;
    ctx->input.pointer_y = 0;
    ctx->input.pointer_pressed = false;
    memset(ctx->input.key_states, 0, sizeof(ctx->input.key_states));

    /* Allocate framebuffer */
    ctx->framebuffer = (uint32_t*)malloc(width * height * sizeof(uint32_t));
    if (!ctx->framebuffer) {
        return -1;
    }
    
    /* ИСПРАВЛЕНО: Инициализируем framebuffer чёрным непрозрачным цветом.
     * calloc инициализирует нулями, что означает alpha=0 (прозрачный).
     * Но для J2ME игр нужен чёрный фон с alpha=255 (непрозрачный).
     * Формат ARGB: 0xFF000000 = чёрный, непрозрачный
     */
    for (int i = 0; i < width * height; i++) {
        ctx->framebuffer[i] = 0xFF000000;  /* Чёрный, непрозрачный */
    }

    /* ИСПРАВЛЕНО: В headless режиме не создаём SDL окно */
    if (headless) {
        DEBUG_LOG("[SDL] Headless mode - skipping SDL window creation");
        return 0;
    }

#ifdef __SWITCH__
    /* v34.84 Switch frontend: the window/renderer/UI texture already
     * exist (sdl_switch_platform_init, called from the menu bootstrap);
     * a game session only adds the canvas texture (+ blur bg). */
    if (sdl_switch_game_begin(width, height) != 0) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }
    return 0;
#endif

#if SDL2_AVAILABLE
    /* ИСПРАВЛЕНИЕ: Включаем VSync для устранения мерцания и tearing */
    /* Используем OpenGL или DirectX вместо software renderer */
    SDL_SetHint(SDL_HINT_RENDER_DRIVER, "opengl");
    SDL_SetHint(SDL_HINT_RENDER_VSYNC, "1");
    
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_EVENTS) != 0) {
        DEBUG_LOG("[SDL] Failed to initialize: %s", SDL_GetError());
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;

    /* v17: bridge the Nokia Clipboard to the OS clipboard */
    {
        extern void sdl_setup_clipboard_hooks(void);
        sdl_setup_clipboard_hooks();
    }
    }

    g_window = SDL_CreateWindow(
        "J2ME Emulator",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        width * scale, height * scale,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );

    if (!g_window) {
        DEBUG_LOG("[SDL] Failed to create window: %s", SDL_GetError());
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    /* ИСПРАВЛЕНО: Пробуем hardware-accelerated renderer с VSync */
    g_renderer = SDL_CreateRenderer(g_window, -1, 
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    if (!g_renderer) {
        /* Fallback: try without VSync */
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED);
    }
    
    if (!g_renderer) {
        /* Last resort: software renderer */
        DEBUG_LOG("[SDL] Hardware acceleration not available, using software renderer");
        g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_SOFTWARE);
    }

    if (!g_renderer) {
        DEBUG_LOG("[SDL] Failed to create renderer: %s", SDL_GetError());
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    SDL_RenderSetLogicalSize(g_renderer, width, height);

    g_texture = SDL_CreateTexture(g_renderer,
        SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING,
        width, height);

    if (!g_texture) {
        DEBUG_LOG("[SDL] Failed to create texture: %s", SDL_GetError());
        SDL_DestroyRenderer(g_renderer);
        SDL_DestroyWindow(g_window);
        SDL_Quit();
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }

    DEBUG_LOG("[SDL] Initialized with real SDL2");
#else
    DEBUG_LOG("[SDL] Running in headless mode (no SDL2)");
    DEBUG_LOG("[SDL] Press Ctrl+C to exit");
#endif

    DEBUG_LOG("[SDL] Context: %p, target_fps: %d", (void*)ctx, ctx->target_fps);
    return 0;
}

/* Destroy SDL */
void sdl_destroy(SdlContext* ctx) {
#if SDL2_AVAILABLE
#ifdef __SWITCH__
    /* v34.84: per-GAME teardown only — the shared window/renderer/UI
     * texture live until sdl_switch_platform_shutdown() at app exit. */
    sdl_switch_game_end();
#else
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
#endif
#endif

    if (ctx && ctx->framebuffer) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
    }
}

/* v34.72: finished-MIDlet probe (native.c) — see the revive guard in
 * sdl_run(). */
extern bool midlet_is_destroyed(void);

/* v34.89: declared for EVERY SDL2 build (was __SWITCH__-only since
 * v34.84): the SDL_QUIT handler calls it unconditionally, so a desktop
 * GCC 14 build with SDL2 died on an implicit declaration. */
extern void midlet_call_destroy_app(JVM* jvm, bool unconditional);

/* v34.86: the shared key-event handler uses the SDL-only key_map /
 * repeat bookkeeping, and both of its callers (the SDL event loop and
 * the __SWITCH__&&SDL2 gamepad path) exist only when SDL2_AVAILABLE —
 * compile the body only for SDL builds, stub otherwise (no-SDL hosts
 * have no keyboard events by construction). */
#if SDL2_AVAILABLE
/*
 * sdl_handle_key_event — the shared SDL_KEYDOWN/UP body (extracted v34.84
 * so the __SWITCH__ gamepad path can re-dispatch synthesized keyboard
 * events through the identical logic: repeat bookkeeping, soft buttons,
 * command-menu navigation, ESC/F12 handling).
 */
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat) {
    
    /* Track key hold state for software key repeat.
     * On real J2ME phones, holding a key generates repeated
     * keyPressed events. We track hold state here and
     * generate repeats in sdl_process_key_repeat(). */
    /* v17: refresh DeviceControl inactivity timer */
    {
        extern void midp_input_activity_mark(void);
        midp_input_activity_mark();
    }

    int repeat_idx = sdl_key_to_repeat_idx(key);
    if (pressed && !is_repeat) {
        /* Initial press - start tracking for repeat */
        uint64_t now_ts = sdl_get_time_ms();
        g_sdl_key_repeat.is_held[repeat_idx] = true;
        g_sdl_key_repeat.press_time[repeat_idx] = now_ts;
        g_sdl_key_repeat.last_repeat_time[repeat_idx] = now_ts;
    } else if (!pressed) {
        /* Key released - clear repeat state */
        g_sdl_key_repeat.is_held[repeat_idx] = false;
    }
    
    /* Ignore SDL native repeat events - we handle repeat ourselves */
    if (pressed && is_repeat) {
        return;
    }
    
    int midp_key = 0;
    int game_action = 0;

    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == key) {
            midp_key = key_map[i].midp_key;
            game_action = key_map[i].game_action;
            
            /* Сохраняем состояние клавиши для game_action (положительное) */
            /* midp_key не используем для key_states, т.к. он может быть отрицательным */
            if (game_action > 0 && game_action < 256) {
                ctx->input.key_states[game_action] = pressed;
                GFX_DEBUG("[SDL] Key %s: SDL=%d -> keyCode=%d, gameAction=%d",
                        pressed ? "DOWN" : "UP", key, midp_key, game_action);
            }
            break;
        }
    }

    /* ИСПРАВЛЕНО: Soft button handling (F1/F2) делаем ПЕРВЫМ!
     * По стандарту MIDP:
     * - Если displayable имеет Commands, вызываем commandAction()
     * - Если нет Commands, передаём keyPressed(-6/-7) в игру
     * F1 = -6 (Left Soft Key), F2 = -7 (Right Soft Key)
     */
    if (pressed && ctx->jvm && (key == SDLK_F1 || key == SDLK_F2)) {
        int soft_button = (key == SDLK_F1) ? 0 : 1;
        int soft_keycode = (key == SDLK_F1) ? -6 : -7;
        
        GFX_DEBUG("[SDL] Soft button: key=%s -> button=%d, keyCode=%d",
                key == SDLK_F1 ? "F1" : "F2", soft_button, soft_keycode);
        
        extern bool midp_handle_soft_button(JVM* jvm, int button_index);
        if (!midp_handle_soft_button(ctx->jvm, soft_button)) {
            /* No commands handled - pass keyPressed to game */
            GFX_DEBUG("[SDL] No commands, passing keyPressed(%d) to game", soft_keycode);
            midp_call_keyPressed(ctx->jvm, soft_keycode);
        }
        return; /* Обработано, не передаём дальше */
    }

    /* Call keyPressed/keyReleased on Canvas */
    if (ctx->jvm && (midp_key || game_action)) {
        /* Check if menu navigation should be handled first */
        if (pressed && game_action) {
            extern bool midp_is_command_menu_open(void);
            extern bool midp_handle_menu_navigation(int direction);
            extern bool midp_handle_soft_button(JVM* jvm, int button_index);
            
            if (midp_is_command_menu_open()) {
                if (game_action == 1) { /* UP */
                    midp_handle_menu_navigation(-1);
                    GFX_DEBUG("[SDL] Menu navigation UP");
                    return; /* Don't pass to game */
                } else if (game_action == 6) { /* DOWN */
                    midp_handle_menu_navigation(1);
                    GFX_DEBUG("[SDL] Menu navigation DOWN");
                    return; /* Don't pass to game */
                } else if (game_action == 8) { /* FIRE - confirm selection */
                    /* Right button (index 1) confirms selection */
                    midp_handle_soft_button(ctx->jvm, 1);
                    GFX_DEBUG("[SDL] Menu FIRE - confirm selection");
                    return; /* Don't pass to game */
                }
            }
        }
        
        /* ИСПРАВЛЕНО: Отправляем keyCode по стандарту Nokia FullCanvas:
         * - UP = -1, DOWN = -2, LEFT = -3, RIGHT = -4, FIRE = -5
         * Игра сама вызовет getGameAction() для конвертации в game action
         */
        int keycode = midp_key ? midp_key : game_action;
        
        if (pressed) {
            DEBUG_LOG("[SDL] Key pressed: SDL=%d -> MIDP keyCode=%d (gameAction=%d)", key, keycode, game_action);
            midp_call_keyPressed(ctx->jvm, keycode);
        } else {
            midp_call_keyReleased(ctx->jvm, keycode);
        }
    }

    if (key == SDLK_ESCAPE && pressed) {
        ctx->running = false;
        if (ctx->jvm) ctx->jvm->running = false;
    }
    
    /* F12: Toggle debug mode at runtime */
    if (key == SDLK_F12 && pressed) {
        bool new_state = j2me_debug_toggle();
        /* Also update the window title to show debug state */
        char title[256];
        snprintf(title, sizeof(title), "J2ME Emulator [Debug: %s]", 
                 new_state ? "ON" : "OFF");
        sdl_set_title(ctx, title);
    }}

/* Process events */
void sdl_process_events(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    /* Forward declarations for MIDP input functions */
    extern void midp_call_keyPressed(JVM* jvm, int keycode);
    extern void midp_call_keyReleased(JVM* jvm, int keycode);
    extern void midp_call_pointerPressed(JVM* jvm, int x, int y);
    extern void midp_call_pointerReleased(JVM* jvm, int x, int y);
    extern void midp_call_pointerDragged(JVM* jvm, int x, int y);
#ifndef __SWITCH__
    SDL_Event event;
    /* Track previous pointer state for drag detection (desktop loop) */
    static int prev_pointer_x = -1;
    static int prev_pointer_y = -1;
    static bool prev_pointer_pressed = false;
#endif

#ifdef __SWITCH__
    /* v34.90 SINGLE-PUMP dispatch: this is the ONLY place SDL events are
     * consumed during a game (see the state-block comment above
     * switch_input_pump). Everything below the desktop loop is bypassed. */
    if (g_switch_pause_req) { /* vestigial latch — kept for log parity */
        g_switch_pause_req = 0;
        sdl_switch_pause_menu(ctx);
    }
    switch_input_pump();
    /* v34.91: the first frame of the first game session proves the VM is
     * actually RENDERING (missing line = stuck before the frame pump). */
    {
        static int s_first_frame = 1;
        if (s_first_frame) {
            s_first_frame = 0;
            sw_trace("frame: first");
        }
    }
    if (g_sw_in.quit) {
        if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
        ctx->running = false;
        if (ctx->jvm) ctx->jvm->running = false;
    }
    for (int i = 0; i < SWITCH_JOY_SLOTS; i++) {
        uint16_t press = (uint16_t)((g_sw_in.held[i] | g_sw_in.latch[i]) & ~g_sw_in.prev[i]);
        uint16_t release = (uint16_t)(~g_sw_in.held[i] & (g_sw_in.prev[i] | g_sw_in.latch[i]));
        if (press & (1u << SWJB_MINUS)) {
            /* MINUS — in-game pause menu (VM parks via the v34.81 watchdog;
             * virtual time freezes). Handled HERE on the frame thread —
             * never mid-bytecode on a VM fiber. */
            sdl_switch_pause_menu(ctx);
        }
        for (int b = 0; b < 16; b++) {
            if (b == SWJB_MINUS) continue;
            uint16_t bit = (uint16_t)(1u << b);
            if (press & bit) {
                SDL_Keycode mapped = switch_joy_button_to_keycode(b);
                /* re-dispatch through the shared keyboard path: soft buttons,
                 * menu navigation and key repeat bookkeeping all come along. */
                if (mapped) sdl_handle_key_event(ctx, mapped, true, false);
            }
            if (release & bit) {
                SDL_Keycode mapped = switch_joy_button_to_keycode(b);
                if (mapped) sdl_handle_key_event(ctx, mapped, false, false);
            }
        }
        sdl_switch_dir_dispatch(ctx, i);
    }
    sdl_switch_pointer_dispatch(ctx);
    sdl_process_key_repeat(ctx);
    return; /* the desktop event loop below does not run on __SWITCH__ */
#endif /* __SWITCH__ */

#ifndef __SWITCH__
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                /* FIX (audit T-1, v18): give the MIDlet a chance to run
                 * destroyApp (save progress) before the interpreter stops. */
                if (ctx->jvm) midlet_call_destroy_app(ctx->jvm, true);
                ctx->running = false;
                if (ctx->jvm) ctx->jvm->running = false;
                break;

            case SDL_KEYDOWN:
            case SDL_KEYUP:
                sdl_handle_key_event(ctx, event.key.keysym.sym,
                                     event.type == SDL_KEYDOWN,
                                     event.key.repeat ? true : false);
                break;

            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
                {
                    bool pressed = (event.type == SDL_MOUSEBUTTONDOWN);
                    int x = event.button.x / ctx->scale;
                    int y = event.button.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    ctx->input.pointer_pressed = pressed;
                    
                    /* Call pointer event handlers */
                    if (ctx->jvm) {
                        if (pressed && !prev_pointer_pressed) {
                            /* pointerPressed: transition from not pressed to pressed */
                            DEBUG_LOG("[SDL] Pointer pressed at (%d, %d)", x, y);
                            midp_call_pointerPressed(ctx->jvm, x, y);
                        } else if (!pressed && prev_pointer_pressed) {
                            /* pointerReleased: transition from pressed to not pressed */
                            DEBUG_LOG("[SDL] Pointer released at (%d, %d)", x, y);
                            midp_call_pointerReleased(ctx->jvm, x, y);
                        }
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                    prev_pointer_pressed = pressed;
                }
                break;

            case SDL_MOUSEMOTION:
                {
                    int x = event.motion.x / ctx->scale;
                    int y = event.motion.y / ctx->scale;
                    
                    ctx->input.pointer_x = x;
                    ctx->input.pointer_y = y;
                    
                    /* Check for drag: pointer is pressed and moving */
                    if (ctx->jvm && prev_pointer_pressed && 
                        (x != prev_pointer_x || y != prev_pointer_y)) {
                        DEBUG_LOG("[SDL] Pointer dragged to (%d, %d)", x, y);
                        midp_call_pointerDragged(ctx->jvm, x, y);
                    }
                    
                    prev_pointer_x = x;
                    prev_pointer_y = y;
                }
                break;

            case SDL_WINDOWEVENT:
                if (event.window.event == SDL_WINDOWEVENT_RESIZED) {
                    int new_w = event.window.data1;
                    int new_h = event.window.data2;
                    ctx->scale = (new_w / ctx->width < new_h / ctx->height)
                        ? new_w / ctx->width : new_h / ctx->height;
                    if (ctx->scale < 1) ctx->scale = 1;
                }
                break;
        }
    }
#endif /* !__SWITCH__ */
    
    /* Process software key repeat after all events are handled.
     * Generates repeated keyPressed events for held game keys. */
    sdl_process_key_repeat(ctx);
#endif
}

#else /* !SDL2_AVAILABLE */
#if defined(__GNUC__) || defined(__clang__)
__attribute__((unused))
#endif
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat) {
    (void)ctx; (void)key; (void)pressed; (void)is_repeat; /* no-SDL no-op */
}
#endif /* SDL2_AVAILABLE */

/* Minimal event processing for cooperative threading - called from Thread.sleep() */
void sdl_process_events_minimal(void) {
#if SDL2_AVAILABLE
    if (!g_sdl_ctx_ptr) return;
    
    /* Only process events if we have a valid SDL window */
    if (!g_window) return;

#ifdef __SWITCH__
    /* v34.90 SINGLE-PUMP RULE: the game thread NEVER drains the SDL queue.
     * This pump used to run from thread_yield()/Thread.sleep — MID-BYTECODE
     * on a yielding VM fiber — and re-dispatched soft keys / FIRE with the
     * command menu open / touches through paths that execute Java
     * re-entrantly (execute_method from the middle of the yield): the
     * «buttons work, then stop; cannot enter any menu item» bug. Input
     * now flows exclusively through the frame pump (<= 1 frame latency). */
    return;
#endif
    
    /* ИСПРАВЛЕНО: Кооперативные потоки выполняются в контексте главного потока
     * через ucontext, поэтому SDL_PollEvent безопасен для вызова.
     * Обрабатываем события клавиш, чтобы игры могли реагировать на ввод
     * даже во время выполнения своих игровых циклов. */
    SDL_Event event;
    
    /* Forward declarations for MIDP input functions */
    extern void midp_call_keyPressed(JVM* jvm, int keycode);
    extern void midp_call_keyReleased(JVM* jvm, int keycode);
    
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                g_sdl_ctx_ptr->running = false;
                if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
                break;

            case SDL_KEYDOWN:
            case SDL_KEYUP:
                {
                    bool pressed = (event.type == SDL_KEYDOWN);
                    SDL_Keycode key = event.key.keysym.sym;
                    
                    /* Track key hold state for software key repeat */
                    int repeat_idx2 = sdl_key_to_repeat_idx(key);
                    if (pressed && !event.key.repeat) {
                        uint64_t now_ts2 = sdl_get_time_ms();
                        g_sdl_key_repeat.is_held[repeat_idx2] = true;
                        g_sdl_key_repeat.press_time[repeat_idx2] = now_ts2;
                        g_sdl_key_repeat.last_repeat_time[repeat_idx2] = now_ts2;
                    } else if (!pressed) {
                        g_sdl_key_repeat.is_held[repeat_idx2] = false;
                    }
                    
                    /* Ignore SDL native repeat events - we handle repeat ourselves */
                    if (pressed && event.key.repeat) {
                        break;
                    }
                    
                    int midp_key = 0;
                    int game_action = 0;

                    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
                        if (key_map[i].sdl_key == key) {
                            midp_key = key_map[i].midp_key;
                            game_action = key_map[i].game_action;
                            break;
                        }
                    }

                    /* ИСПРАВЛЕНО: Soft button handling (F1/F2) делаем ПЕРВЫМ! */
                    if (pressed && g_sdl_ctx_ptr->jvm && (key == SDLK_F1 || key == SDLK_F2)) {
                        int soft_button = (key == SDLK_F1) ? 0 : 1;
                        int soft_keycode = (key == SDLK_F1) ? -6 : -7;
                        
                        extern bool midp_handle_soft_button(JVM* jvm, int button_index);
                        if (!midp_handle_soft_button(g_sdl_ctx_ptr->jvm, soft_button)) {
                            midp_call_keyPressed(g_sdl_ctx_ptr->jvm, soft_keycode);
                        }
                        break; /* Обработано, не передаём дальше */
                    }

                    /* Call keyPressed/keyReleased on Canvas */
                    /* Используем keyCode (midp_key) по стандарту Nokia FullCanvas */
                    if (g_sdl_ctx_ptr->jvm && (midp_key || game_action)) {
                        int keycode = midp_key ? midp_key : game_action;
                        
                        if (pressed) {
                            DEBUG_LOG("[SDL] Minimal: Key pressed SDL=%d -> keyCode=%d", key, keycode);
                            midp_call_keyPressed(g_sdl_ctx_ptr->jvm, keycode);
                        } else {
                            midp_call_keyReleased(g_sdl_ctx_ptr->jvm, keycode);
                        }
                    }

                    if (key == SDLK_ESCAPE && pressed) {
                        g_sdl_ctx_ptr->running = false;
                        if (g_sdl_ctx_ptr->jvm) g_sdl_ctx_ptr->jvm->running = false;
                    }
                }
                break;

        }
    }
    
    /* Process software key repeat for minimal event loop too */
    sdl_process_key_repeat(g_sdl_ctx_ptr);
#endif
}

/* Set global context (called by main.c before sdl_init) */
void sdl_set_global_context(SdlContext* ctx) {
    g_sdl_ctx_ptr = ctx;
    DEBUG_LOG("[SDL] Global context set to %p", (void*)ctx);
}

/* Get global context */
SdlContext* sdl_get_global_context(void) {
    return g_sdl_ctx_ptr;
}

/* ИСПРАВЛЕНО: Thread-safe запрос на перерисовку экрана */
void sdl_request_redraw(void) {
    if (g_sdl_ctx_ptr) {
        atomic_store_explicit(&g_sdl_ctx_ptr->needs_redraw, true, memory_order_release);
        /* DEBUG: Log first 20 calls */
        static int redraw_count = 0;
        redraw_count++;
        if (redraw_count <= 20) {
            LOG_SAFE("[SDL] sdl_request_redraw() #%d: set needs_redraw=true, ptr=%p\n", 
                    redraw_count, (void*)g_sdl_ctx_ptr);
        }
    } else {
        LOG_SAFE("[SDL] WARNING: sdl_request_redraw() called but g_sdl_ctx_ptr is NULL!\n");
    }
}

/* Check if redraw is needed */
bool sdl_needs_redraw(SdlContext* ctx) {
    return ctx ? atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire) : false;
}

/* Clear redraw flag */
void sdl_clear_redraw(SdlContext* ctx) {
    if (ctx) {
        atomic_store_explicit(&ctx->needs_redraw, false, memory_order_release);
    }
}

/* Run main loop */
void sdl_run(SdlContext* ctx) {
    if (!ctx) {
        DEBUG_LOG("[SDL] ERROR: sdl_run called with NULL context");
        return;
    }
    
    /* Check if context was properly initialized */
    if (ctx->target_fps <= 0 || ctx->framebuffer == NULL) {
        DEBUG_LOG("[SDL] ERROR: Context not properly initialized");
        DEBUG_LOG("[SDL] target_fps=%d, framebuffer=%p, width=%d, height=%d",
                ctx->target_fps, (void*)ctx->framebuffer, ctx->width, ctx->height);
        DEBUG_LOG("[SDL] This usually means sdl_init() failed or was not called");
        return;
    }

    DEBUG_LOG("[SDL] Running main loop (FPS: %d, %dx%d)", ctx->target_fps, ctx->width, ctx->height);

    /* External function from display.c for callSerially processing */
    extern void midp_process_call_serially_queue(JVM* jvm);
    extern void jvm_process_timers(JVM* jvm);
    extern bool midp_check_alert_timeout(JVM* jvm);
    
    /* ИСПРАВЛЕНО: Функция для вызова paint() на текущем displayable */
    extern void midp_repaint_current(JVM* jvm);

    /* ИСПРАВЛЕНО: Если running=false, принудительно устанавливаем true */
    if (!ctx->running) {
        LOG_SAFE("[HEADLESS] WARNING: ctx->running was false, forcing to true\n");
        ctx->running = true;
    }
    /* v34.72: revive the VM ONLY when it did not deliberately finish
     * (notifyDestroyed/System.exit inside startApp). Reviving a finished
     * VM left a dead pump on a frozen screen forever — the finished
     * MIDlet now falls through to the explicit black finished screen. */
    if (ctx->jvm && !ctx->jvm->running &&
        !ctx->jvm->exiting && !midlet_is_destroyed()) {
        LOG_SAFE("[HEADLESS] WARNING: ctx->jvm->running was false, forcing to true\n");
        ctx->jvm->running = true;
    }

#if SDL2_AVAILABLE
    /* Headless-style mode: SDL2 available but no window (headless or headless-like) */
    /* ИСПРАВЛЕНО: Проверяем g_window ПЕРЕД основным циклом, а не после */
    if (!g_window) {
        /* Headless mode - simple delay loop (SDL2 available but no window created) */
        
        LOG_SAFE("[HEADLESS] Starting headless main loop (SDL2 available, no window)\n");
        LOG_SAFE("[HEADLESS] ctx=%p, ctx->running=%d, ctx->jvm=%p, ctx->jvm->running=%d\n",
                (void*)ctx, ctx->running, (void*)ctx->jvm, ctx->jvm ? ctx->jvm->running : -1);
        
        /* ИСПРАВЛЕНО: Используем clock_gettime вместо SDL_GetTicks, т.к. SDL не инициализирован */
        uint64_t last_auto_redraw = 0;
        const uint64_t auto_redraw_interval = 16;  /* ~60 FPS */
        int headless_loop_count = 0;
        
        /* Get current time using clock_gettime */
        struct timespec start_ts;
        clock_gettime(CLOCK_MONOTONIC, &start_ts);
        last_auto_redraw = (uint64_t)start_ts.tv_sec * 1000 + start_ts.tv_nsec / 1000000;
        
        while (ctx->running && ctx->jvm && ctx->jvm->running) {
            headless_loop_count++;
            
            /* Check for error display mode */
            if (sdl_has_error()) {
                sdl_draw_error_screen(ctx);
                sdl_present(ctx);
                
                /* Short delay in error mode */
#ifdef _WIN32
                Sleep(16);
#else
                struct timespec ts = { .tv_sec = 0, .tv_nsec = 16000000 };
                nanosleep(&ts, NULL);
#endif
                continue;
            }
            
            /* Process timers */
            jvm_process_timers(ctx->jvm);
            
            /* v35: age key queue + fallback delivery (event-driven menus) */
            {
                extern void midp_frame_tick(void);
                extern void midp_pump_deferred_keys(JVM* jvm);
                midp_frame_tick();
                midp_pump_deferred_keys(ctx->jvm);
            }

            /* Process callSerially queue */
            midp_process_call_serially_queue(ctx->jvm);
            
            /* Check Alert timeout */
            midp_check_alert_timeout(ctx->jvm);
            
            /* ИСПРАВЛЕНО: Автоматическая перерисовка в headless режиме */
            struct timespec current_ts;
            clock_gettime(CLOCK_MONOTONIC, &current_ts);
            uint64_t current_time = (uint64_t)current_ts.tv_sec * 1000 + current_ts.tv_nsec / 1000000;
            uint64_t elapsed = current_time - last_auto_redraw;
            
            if (elapsed >= auto_redraw_interval) {
                ctx->needs_redraw = true;
                last_auto_redraw = current_time;
                if (headless_loop_count <= 10) {
                    LOG_SAFE("[HEADLESS] Auto-redraw at iteration %d (elapsed=%lu ms)\n", 
                            headless_loop_count, (unsigned long)elapsed);
                }
            }
            
            /* Process pending repaints */
            if (ctx->needs_redraw) {
                midp_process_repaints(ctx->jvm);
                ctx->needs_redraw = false;
                
                /* ИСПРАВЛЕНО: Сигнализируем что repaint обработан */
                extern void midp_clear_pending_repaint(void);
                midp_clear_pending_repaint();
                
                /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
                 * Только этот поток завершается, остальные продолжают работать.
                 */
                
                /* ИСПРАВЛЕНО: Сохраняем кадр в файл для отладки */
                if (headless_loop_count <= 5 || headless_loop_count % 30 == 0) {
                    char filename[256];
                    snprintf(filename, sizeof(filename), "/tmp/j2me_frame_%d.ppm", headless_loop_count);
                    sdl_save_framebuffer_to_file(ctx, filename);
                }
            }
            
            /* ИСПРАВЛЕНО: В headless режиме SDL не инициализирован, используем nanosleep */
#ifdef _WIN32
            Sleep(16);
#else
            struct timespec ts = { .tv_sec = 0, .tv_nsec = 16000000 };
            nanosleep(&ts, NULL);
#endif
            
            /* Limit headless execution time */
            if (headless_loop_count > 6000) {
                LOG_SAFE("[HEADLESS] Maximum iterations reached\n");
                break;
            }
        }
        return;  /* Headless mode done */
    }
    
    /* Normal SDL2 mode with window - main loop */
    uint64_t last_time = SDL_GetTicks();
    const uint64_t frame_time = 1000 / ctx->target_fps;
    
    ctx->needs_redraw = true;
    uint64_t last_auto_redraw = SDL_GetTicks();
    const uint64_t auto_redraw_interval = 16;

    int loop_count = 0;
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        loop_count++;
#ifdef __SWITCH__
        /* v34.81 pause watchdog: fresh frame timestamp each iteration;
         * when the pause menu blocks this loop, VM threads park after
         * the stall threshold and virtual time freezes. */
        {
            extern void jvm_frontend_frame_tick(void);
            extern void jvm_frontend_run_exit(void);
            jvm_frontend_frame_tick();
            jvm_frontend_run_exit();
        }
#endif
        
        /* Check for error display mode */
        if (sdl_has_error()) {
            sdl_draw_error_screen(ctx);
            
            SDL_LOCK();
            sdl_update_texture(ctx);
            SDL_RenderClear(g_renderer);
            SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
            SDL_RenderPresent(g_renderer);
            SDL_UNLOCK();
            
            /* Still process events so ESC works */
            sdl_process_events(ctx);
            
            SDL_Delay(16);  /* ~60 FPS in error mode */
            continue;
        }
        
        if (loop_count % 60 == 0) {
            DEBUG_LOG("[MAIN_LOOP] Still running, iteration=%d, needs_redraw=%d", loop_count, ctx->needs_redraw);
        }
        
        sdl_process_events(ctx);
        jvm_process_timers(ctx->jvm);
        {
            /* v35: age key queue + fallback delivery (event-driven menus) */
            extern void midp_frame_tick(void);
            extern void midp_pump_deferred_keys(JVM* jvm);
            midp_frame_tick();
            midp_pump_deferred_keys(ctx->jvm);
        }
        midp_process_call_serially_queue(ctx->jvm);
        midp_check_alert_timeout(ctx->jvm);
        
        uint64_t current_time = SDL_GetTicks();
        bool current_needs_redraw = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
        if (!current_needs_redraw && (current_time - last_auto_redraw) >= auto_redraw_interval) {
            atomic_store_explicit(&ctx->needs_redraw, true, memory_order_release);
            last_auto_redraw = current_time;
        }
        
        /* DEBUG: Log first 30 checks */
        if (loop_count <= 30) {
            bool needs_redraw_val = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
            LOG_SAFE("[MAIN_LOOP] iteration=%d, needs_redraw=%d\n", loop_count, needs_redraw_val);
        }
        
        bool needs_redraw_val = atomic_load_explicit(&ctx->needs_redraw, memory_order_acquire);
        if (needs_redraw_val) {
            /* Clear the flag BEFORE processing to avoid race condition */
            atomic_store_explicit(&ctx->needs_redraw, false, memory_order_release);
            
            midp_process_repaints(ctx->jvm);
            extern void midp_clear_pending_repaint(void);
            midp_clear_pending_repaint();
            
            /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
             * Только этот поток завершается, остальные продолжают работать.
             */
        }
        
        SDL_LOCK();
        sdl_update_texture(ctx);
        SDL_RenderClear(g_renderer);
        SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
        SDL_RenderPresent(g_renderer);
        SDL_UNLOCK();

        /* v50 (Asphalt image freeze): end-of-frame vsync tick — game-thread
         * serviceRepaints() paces itself on this (KVM vblank semantics). */
        {
            extern void midp_vsync_tick(void);
            midp_vsync_tick();
        }

        current_time = SDL_GetTicks();
        uint64_t elapsed = current_time - last_time;
        if (elapsed < frame_time) {
            SDL_Delay(1);
        }
        last_time = SDL_GetTicks();
    }

    /* v34.72: the loop above exited because the MIDlet finished
     * (ctx->jvm->running == false while ctx->running is still true —
     * the window-close path clears BOTH). Show the explicit "finished"
     * screen and keep the window responsive until the user closes it;
     * without this the window vanished without any indication that the
     * MIDlet had ended normally. */
    if (ctx->running && ctx->jvm && !ctx->jvm->running && !sdl_has_error()) {
        LOG_SAFE("[SDL] MIDlet finished — showing finished screen until window close\n");
        sdl_draw_midlet_finished_screen(ctx);
        SDL_LOCK();
        sdl_update_texture(ctx);
        SDL_RenderClear(g_renderer);
        SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
        SDL_RenderPresent(g_renderer);
        SDL_UNLOCK();
#ifdef __SWITCH__
        /* Switch: show the finished screen until A/B or 3 s, then fall
         * through — control returns to the frontend menu (switch main).
         * v34.90: same single pump as everything else (hotplug included). */
        {
            uint64_t t0 = SDL_GetTicks();
            switch_input_reset();
            for (;;) {
                unsigned keys = sdl_switch_ui_pump_keys();
                if (keys & (SWK_A | SWK_B) || keys & SWK_EXIT) break;
                if (SDL_GetTicks() - t0 > 3000) break;
                SDL_Delay(16);
            }
        }
#else
        for (;;) {
            SDL_Event ev;
            bool quit = false;
            while (SDL_PollEvent(&ev)) {
                if (ev.type == SDL_QUIT) quit = true;
                if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) quit = true;
            }
            if (quit) break;
            SDL_Delay(16);
        }
#endif
    }
#else
    /* Headless mode - simple delay loop (No SDL2) */
    uint64_t last_auto_redraw = 0;
    const uint64_t auto_redraw_interval = 16;  /* ~60 FPS */
    int headless_loop_count = 0;
    
    LOG_SAFE("[HEADLESS] Starting headless main loop (No SDL2)\n");
    
    /* ИСПРАВЛЕНО: Устанавливаем начальную перерисовку */
    ctx->needs_redraw = true;
    last_auto_redraw = 0;
    
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        headless_loop_count++;
        
        /* Process timers */
        jvm_process_timers(ctx->jvm);
        
        /* Process callSerially queue */
        midp_process_call_serially_queue(ctx->jvm);
        
        /* Check Alert timeout */
        midp_check_alert_timeout(ctx->jvm);
        
        /* ИСПРАВЛЕНО: Автоматическая перерисовка в headless режиме */
        uint64_t current_time = sdl_get_ticks(ctx);
        uint64_t elapsed = current_time - last_auto_redraw;
        
        if (elapsed >= auto_redraw_interval) {
            ctx->needs_redraw = true;
            last_auto_redraw = current_time;
            if (headless_loop_count <= 10) {
                LOG_SAFE("[HEADLESS] Auto-redraw at iteration %d (elapsed=%lu ms)\n", 
                        headless_loop_count, (unsigned long)elapsed);
            }
        }
        
        /* Process pending repaints */
        if (ctx->needs_redraw) {
            midp_process_repaints(ctx->jvm);
            ctx->needs_redraw = false;
            
            /* ИСПРАВЛЕНО: Сигнализируем что repaint обработан */
            extern void midp_clear_pending_repaint(void);
            midp_clear_pending_repaint();
            
            /* В J2ME, поток с необработанным исключением НЕ останавливает приложение.
             * Только этот поток завершается, остальные продолжают работать.
             */
        }
        
#ifdef _WIN32
        Sleep(16);  /* ~60 FPS on Windows */
#else
        usleep(16000);  /* ~60 FPS on POSIX */
#endif

        /* v50 (Asphalt image freeze): vsync tick for this fallback loop too. */
        {
            extern void midp_vsync_tick(void);
            midp_vsync_tick();
        }

        /* Limit headless execution time */
        if (headless_loop_count > 6000) {
            LOG_SAFE("[HEADLESS] Maximum iterations reached\n");
            break;
        }
    }
#endif
}

/* Stop */
void sdl_stop(SdlContext* ctx) {
    if (ctx) ctx->running = false;
}

/* Get framebuffer */
uint32_t* sdl_get_framebuffer(SdlContext* ctx) {
    return ctx ? ctx->framebuffer : NULL;
}

/* Clear */
void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    for (int i = 0; i < ctx->width * ctx->height; i++) {
        ctx->framebuffer[i] = color;
    }
}

/* Save framebuffer to file (for headless mode debugging) */
void sdl_save_framebuffer_to_file(SdlContext* ctx, const char* filename) {
    if (!ctx || !ctx->framebuffer) return;
    
    FILE* f = fopen(filename, "wb");
    if (!f) {
        LOG_SAFE("[SDL] Failed to open %s for writing\n", filename);
        return;
    }
    
    /* Write PPM header (P6 = RGB binary) */
    fprintf(f, "P6\n%d %d\n255\n", ctx->width, ctx->height);
    
    /* Write pixels (convert ARGB to RGB) */
    for (int i = 0; i < ctx->width * ctx->height; i++) {
        uint32_t pixel = ctx->framebuffer[i];
        uint8_t r = (pixel >> 16) & 0xFF;
        uint8_t g = (pixel >> 8) & 0xFF;
        uint8_t b = pixel & 0xFF;
        fwrite(&r, 1, 1, f);
        fwrite(&g, 1, 1, f);
        fwrite(&b, 1, 1, f);
    }
    
    fclose(f);
    LOG_SAFE("[SDL] Saved framebuffer to %s (%dx%d)\n", filename, ctx->width, ctx->height);
}

/* Present */
void sdl_present(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) {
        GFX_DEBUG("[SDL] present: invalid context or texture");
        return;
    }
#ifdef __SWITCH__
    SDL_LOCK();
    sdl_switch_present_game(ctx);
    SDL_UNLOCK();
    return;
#endif
    
    static int present_count = 0;
    present_count++;
    if (present_count <= 10) {
        /* Check pixels at position where title.png should be (y=53) */
        int y = 53;
        GFX_DEBUG("[SDL] present #%d: pixel at (0,0)=0x%08X, pixel at (120,53)=0x%08X, pixel at (0,53)=0x%08X", 
                present_count, ctx->framebuffer[0], 
                ctx->framebuffer[y * ctx->width + 120],
                ctx->framebuffer[y * ctx->width + 0]);
    }
    
    SDL_LOCK();
    sdl_update_texture(ctx);
    SDL_RenderClear(g_renderer);
    SDL_RenderCopy(g_renderer, g_texture, NULL, NULL);
    SDL_RenderPresent(g_renderer);
    SDL_UNLOCK();
#endif
}

/* Update texture */
void sdl_update_texture(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (ctx && ctx->framebuffer && g_texture) {
        /* Debug: show first few pixels */
        static int update_count = 0;
        update_count++;
        if (update_count <= 5) {
            GFX_DEBUG("[SDL] update_texture #%d: first pixels = 0x%08X 0x%08X 0x%08X", 
                    update_count, ctx->framebuffer[0], ctx->framebuffer[1], ctx->framebuffer[2]);
        }
        
        /* v34.61 (Asphalt 3 3D "rarely delivers 3D frames" - same fix as
         * libretro_end_frame): upload the latest SETTLED frame, not the live
         * framebuffer. The game thread paints asynchronously into
         * ctx->framebuffer; uploading it mid-paint showed torn/partial
         * frames (background only). A settled snapshot exists only after a
         * COMPLETE frame, so tearing is impossible by construction. */
        {
            extern uint32_t midp_present_stable_copy(uint32_t* dst, int dst_px);
            static uint32_t* s_scanout = NULL;
            static int s_scanout_px = 0;
            int px = ctx->width * ctx->height;
            if (px > 0 && px <= 8192 * 8192) {
                if (px > s_scanout_px) {
                    uint32_t* nb = (uint32_t*)realloc(s_scanout,
                                                      (size_t)px * sizeof(uint32_t));
                    if (nb) { s_scanout = nb; s_scanout_px = px; }
                }
                if (s_scanout &&
                    midp_present_stable_copy(s_scanout, s_scanout_px) != 0) {
                    SDL_UpdateTexture(g_texture, NULL, s_scanout,
                                      ctx->width * sizeof(uint32_t));
                    return;
                }
            }
        }
        /* Bootstrap / fallback (nothing settled yet): live framebuffer,
         * pre-v34.61 behavior */
        SDL_UpdateTexture(g_texture, NULL, ctx->framebuffer,
            ctx->width * sizeof(uint32_t));
    }
#endif
}

/* Key mapping */
int sdl_key_to_midp(int sdl_key) {
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].midp_key;
    }
#endif
    return sdl_key;
}

int sdl_key_to_game_action(int sdl_key) {
    (void)sdl_key;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    for (size_t i = 0; i < KEY_MAP_SIZE; i++) {
        if (key_map[i].sdl_key == sdl_key) return key_map[i].game_action;
    }
#endif
    return 0;
}

/* Key state - uses SDL_GetKeyboardState for real-time state */
bool sdl_key_pressed(SdlContext* ctx, int keycode) {
    (void)ctx;  /* Not needed when using SDL_GetKeyboardState */
    
#if SDL2_AVAILABLE
    /* Pump events to ensure keyboard state is current */
    SDL_PumpEvents();
    
    /* Get the current keyboard state directly from SDL */
    const Uint8* keyboard_state = SDL_GetKeyboardState(NULL);
    if (!keyboard_state) {
        return false;
    }
    
    /* Map Nokia FullCanvas keyCode to SDL scancode */
    /* -1=UP, -2=DOWN, -3=LEFT, -4=RIGHT, -5=FIRE */
    SDL_Scancode scancode = 0;
    switch (keycode) {
        case -1:  /* UP (Nokia FULL_UP) */
        case GAME_UP:
            scancode = SDL_SCANCODE_UP; 
            break;
        case -2:  /* DOWN (Nokia FULL_DOWN) */
        case GAME_DOWN:
            scancode = SDL_SCANCODE_DOWN; 
            break;
        case -3:  /* LEFT (Nokia FULL_LEFT) */
        case GAME_LEFT:
            scancode = SDL_SCANCODE_LEFT; 
            break;
        case -4:  /* RIGHT (Nokia FULL_RIGHT) */
        case GAME_RIGHT:
            scancode = SDL_SCANCODE_RIGHT; 
            break;
        case -5:  /* FIRE (Nokia FULL_FIRE) */
        case GAME_FIRE:
            /* FIRE can be Return or Space */
            if (keyboard_state[SDL_SCANCODE_RETURN] || keyboard_state[SDL_SCANCODE_SPACE]) {
                GFX_DEBUG("[sdl_key_pressed] FIRE (keycode=%d) -> pressed", keycode);
                return true;
            }
            return false;
        case -6:  /* GAME_A */
        case GAME_A:
            scancode = SDL_SCANCODE_A; 
            break;
        case -7:  /* GAME_B */
        case GAME_B:
            scancode = SDL_SCANCODE_B; 
            break;
        case -8:  /* GAME_C */
        case GAME_C:
            scancode = SDL_SCANCODE_C; 
            break;
        case -9:  /* GAME_D */
        case GAME_D:
            scancode = SDL_SCANCODE_D; 
            break;
        default:
            /* For other keycodes (regular keys), check keyboard state directly */
            if (keycode >= 0 && keycode < 256) {
                /* Try to map ASCII to scancode */
                if (keycode >= '0' && keycode <= '9') {
                    scancode = SDL_SCANCODE_0 + (keycode - '0');
                } else if (keycode >= 'a' && keycode <= 'z') {
                    scancode = SDL_SCANCODE_A + (keycode - 'a');
                } else {
                    return false;
                }
            } else {
                return false;
            }
            break;
    }
    
    bool state = keyboard_state[scancode];
    if (state) {
        GFX_DEBUG("[sdl_key_pressed] keycode=%d -> pressed (scancode=%d)", keycode, scancode);
    }
    return state;
#else
    (void)keycode;
    return false;
#endif
}

/* Pointer */
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) {
    if (!ctx) { if (x) *x = 0; if (y) *y = 0; return; }
    if (x) *x = ctx->input.pointer_x;
    if (y) *y = ctx->input.pointer_y;
}

bool sdl_pointer_pressed(SdlContext* ctx) {
    return ctx ? ctx->input.pointer_pressed : false;
}

/* Audio */
int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
#if defined(__SWITCH__) && SDL2_AVAILABLE
    if (!switch_settings_get()->audio_enabled) return -1; /* Звук: Выкл */
#endif
    (void)ctx; (void)frequency; (void)channels; (void)samples;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_CloseAudioDevice(g_audio_dev);

    sw_trace("audio: open %d Hz %d ch", frequency, channels); /* v34.91: emulator hang point #1 */

    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = frequency;
    want.format = AUDIO_S16;
    want.channels = channels;
    want.samples = samples;
    want.callback = NULL;  /* Use SDL_QueueAudio instead of callback */
    want.userdata = ctx;

    g_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);

    if (g_audio_dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        return -1;
    }

    SDL_PauseAudioDevice(g_audio_dev, 0);
    DEBUG_LOG("[SDL] Audio: %d Hz, %d channels, buffer=%d samples", have.freq, have.channels, have.samples);
    return 0;
#else
    return 0;
#endif
}

void sdl_audio_close(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) { SDL_CloseAudioDevice(g_audio_dev); g_audio_dev = 0; }
#endif
}

int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) {
    (void)ctx; (void)data; (void)length;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_QueueAudio(g_audio_dev, data, length);
#endif
    return -1;
}

uint32_t sdl_audio_queued_size(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) return SDL_GetQueuedAudioSize(g_audio_dev);
#endif
    return 0;
}

void sdl_audio_clear(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_audio_dev) SDL_ClearQueuedAudio(g_audio_dev);
#endif
}

/* Simple audio init without context */
int sdl_audio_init_simple(uint32_t sample_rate) {
#if SDL2_AVAILABLE
    if (g_audio_dev) return 0;  /* Already initialized */
#ifdef __SWITCH__
    if (!switch_settings_get()->audio_enabled) return -1; /* Звук: Выкл */
#endif
    sw_trace("audio: open %lu Hz stereo", (unsigned long)sample_rate); /* v34.91 */
    
    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof(want));
    want.freq = sample_rate;
    want.format = AUDIO_S16;
    want.channels = 2;  /* Stereo */
    want.samples = 2048;  /* Larger buffer for queue-based audio */
    want.callback = NULL;  /* Use SDL_QueueAudio instead of callback */
    want.userdata = NULL;
    
    g_audio_dev = SDL_OpenAudioDevice(NULL, 0, &want, &have,
        SDL_AUDIO_ALLOW_FREQUENCY_CHANGE | SDL_AUDIO_ALLOW_CHANNELS_CHANGE);
    
    if (g_audio_dev == 0) {
        DEBUG_LOG("[SDL] Failed to open audio: %s", SDL_GetError());
        return -1;
    }
    
    SDL_PauseAudioDevice(g_audio_dev, 0);  /* Start audio */
    DEBUG_LOG("[SDL] Audio initialized: %d Hz, %d channels, buffer=%d samples", 
              have.freq, have.channels, have.samples);
    return 0;
#else
    (void)sample_rate;
    return 0;
#endif
}

void sdl_audio_shutdown(void) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
#endif
}

/* Timing */
uint64_t sdl_get_ticks(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    return SDL_GetTicks();
#else
#ifdef _WIN32
    return GetTickCount();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
#endif
#endif
}

void sdl_sleep(uint32_t ms) {
#if SDL2_AVAILABLE
    SDL_Delay(ms);
#else
#ifdef _WIN32
    Sleep(ms);
#else
    usleep(ms * 1000);
#endif
#endif
}

/* Window */
void sdl_set_title(SdlContext* ctx, const char* title) {
    (void)ctx;
    (void)title;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (g_window && title) SDL_SetWindowTitle(g_window, title);
#endif
}

void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) {
    (void)ctx; (void)fullscreen;
#if SDL2_AVAILABLE
    if (g_window) SDL_SetWindowFullscreen(g_window,
        fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
#endif
}

void sdl_toggle_fullscreen(SdlContext* ctx) {
    (void)ctx;
#if SDL2_AVAILABLE
    if (g_window) {
        Uint32 flags = SDL_GetWindowFlags(g_window);
        SDL_SetWindowFullscreen(g_window,
            (flags & SDL_WINDOW_FULLSCREEN_DESKTOP) ? 0 : SDL_WINDOW_FULLSCREEN_DESKTOP);
    }
#endif
}

int sdl_resize(SdlContext* ctx, int width, int height) {
    if (!ctx || width <= 0 || height <= 0) return -1;

    /* ИСПРАВЛЕНО: Сначала выделяем новую память, потом освобождаем старую */
    uint32_t* new_framebuffer = (uint32_t*)malloc(width * height * sizeof(uint32_t));
    if (!new_framebuffer) {
        ERROR_LOG("[SDL] Failed to allocate new framebuffer in sdl_resize");
        return -1;
    }
    
    /* Инициализируем чёрным непрозрачным цветом */
    for (int i = 0; i < width * height; i++) {
        new_framebuffer[i] = 0xFF000000;
    }

#if SDL2_AVAILABLE
    SDL_Texture* new_texture = SDL_CreateTexture(g_renderer, SDL_PIXELFORMAT_ARGB8888,
        SDL_TEXTUREACCESS_STREAMING, width, height);
    if (!new_texture) {
        ERROR_LOG("[SDL] Failed to create new texture in sdl_resize: %s", SDL_GetError());
        free(new_framebuffer);
        return -1;
    }
#endif

    /* Only free old resources after successful allocation */
    free(ctx->framebuffer);
    ctx->framebuffer = new_framebuffer;
    ctx->width = width;
    ctx->height = height;

#if SDL2_AVAILABLE
    if (g_texture) SDL_DestroyTexture(g_texture);
    g_texture = new_texture;
    SDL_RenderSetLogicalSize(g_renderer, width, height);
#endif
    return 0;
}

int sdl_screenshot(SdlContext* ctx, const char* filename) {
    if (!ctx || !filename) return -1;
#if SDL2_AVAILABLE
    if (g_renderer) {
        SDL_Surface* surface = SDL_CreateRGBSurface(0,
            ctx->width * ctx->scale, ctx->height * ctx->scale, 32,
            0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        if (surface) {
            SDL_RenderReadPixels(g_renderer, NULL, SDL_PIXELFORMAT_ARGB8888,
                surface->pixels, surface->pitch);
            int result = SDL_SaveBMP(surface, filename);
            SDL_FreeSurface(surface);
            return result;
        }
    }
#endif
    return -1;
}

/* Global graphics context for screen - used by display.c */
static MidpGraphics g_sdl_graphics;

MidpGraphics* sdl_get_graphics(SdlContext* ctx) {
    if (!ctx) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics called with NULL context");
        return NULL;
    }
    if (!ctx->framebuffer) {
        DEBUG_LOG("[SDL] WARNING: sdl_get_graphics - framebuffer is NULL");
        return NULL;
    }
    /* Only re-init if dimensions changed */
    if (g_sdl_graphics.width != ctx->width || g_sdl_graphics.height != ctx->height ||
        g_sdl_graphics.pixels != ctx->framebuffer) {
        midp_graphics_init(&g_sdl_graphics, ctx->framebuffer, ctx->width, ctx->height);
    }
    return &g_sdl_graphics;
}

/* Check if the given graphics context is the screen graphics */
bool sdl_is_screen_graphics(MidpGraphics* gfx) {
    return gfx == &g_sdl_graphics;
}

MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) {
    (void)ctx;
    return NULL;
}

void sdl_dump_info(SdlContext* ctx) {
    if (!ctx) return;
    DEBUG_LOG("[SDL] Window: %dx%d (scale: %d)", ctx->width, ctx->height, ctx->scale);
#if SDL2_AVAILABLE
    DEBUG_LOG("[SDL] Renderer: %s", SDL_GetCurrentVideoDriver());
    if (g_window) {
        int w, h;
        SDL_GetWindowSize(g_window, &w, &h);
        DEBUG_LOG("[SDL] Window size: %dx%d", w, h);
    }
#else
    DEBUG_LOG("[SDL] Running in headless mode");
#endif
}

/* Queue audio samples directly */
void sdl_audio_queue_samples(const int16_t* samples, size_t count) {
    (void)samples; (void)count;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (g_audio_dev && samples && count > 0) {
        SDL_QueueAudio(g_audio_dev, samples, count * sizeof(int16_t));
    }
#endif
}

/* Get queued audio size */
size_t sdl_audio_get_queued_size(void) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        return SDL_GetQueuedAudioSize(g_audio_dev) / sizeof(int16_t);
    }
#endif
    return 0;
}

/* ============================================================
 * Error Screen Display - Shows unhandled exception info
 * ============================================================ */

/* Include bitmap font for error display */
#include "midp/bitmap_font.h"

/* Draw a single character at position (uses bitmap font) */
static void draw_error_char(uint32_t* framebuffer, int fb_width, int fb_height,
                            int codepoint, int x, int y, uint32_t color) {
    if (!framebuffer || x < 0 || y < 0) return;
    if (x + FONT_WIDTH > fb_width || y + FONT_HEIGHT > fb_height) return;
    
    const uint8_t* char_data = get_char_data_unicode(codepoint);
    if (!char_data) return;
    
    for (int row = 0; row < FONT_HEIGHT; row++) {
        uint8_t row_data = char_data[row];
        for (int col = 0; col < FONT_WIDTH; col++) {
            if (row_data & (1 << (4 - col))) {  /* MSB is leftmost */
                int px = x + col;
                int py = y + row;
                if (px >= 0 && px < fb_width && py >= 0 && py < fb_height) {
                    framebuffer[py * fb_width + px] = color;
                }
            }
        }
    }
}

/* Draw a UTF-8 string at position */
static void draw_error_string(uint32_t* framebuffer, int fb_width, int fb_height,
                              const char* str, int x, int y, uint32_t color) {
    if (!framebuffer || !str) return;
    
    int cur_x = x;
    int cur_y = y;
    int len = 0;
    while (str[len]) len++;
    
    int i = 0;
    while (i < len) {
        int codepoint = utf8_decode(str, &i, len);
        if (codepoint < 0) break;
        
        /* Handle newline */
        if (codepoint == '\n') {
            cur_x = x;
            cur_y += FONT_HEIGHT + 2;
            continue;
        }
        
        /* Handle tab */
        if (codepoint == '\t') {
            cur_x += (FONT_WIDTH + 1) * 4;
            continue;
        }
        
        /* Skip if outside screen */
        if (cur_x + FONT_WIDTH > fb_width) {
            cur_x = x;
            cur_y += FONT_HEIGHT + 2;
        }
        
        if (cur_y + FONT_HEIGHT > fb_height) break;
        
        draw_error_char(framebuffer, fb_width, fb_height, codepoint, cur_x, cur_y, color);
        cur_x += FONT_WIDTH + 1;  /* +1 for spacing */
    }
}

/* Word-wrap text to fit width */
static int wrap_text_line(const char* text, int max_chars_per_line, char* buffer, int buffer_size) {
    if (!text || !buffer || buffer_size <= 0) return 0;
    
    int text_len = 0;
    while (text[text_len]) text_len++;
    
    int chars_written = 0;
    int line_pos = 0;
    int i = 0;
    
    while (i < text_len && chars_written < buffer_size - 1) {
        int codepoint = utf8_decode(text, &i, text_len);
        if (codepoint < 0) break;
        
        /* Count character width (simplified - all chars are 1 char width) */
        line_pos++;
        
        if (line_pos > max_chars_per_line && codepoint == ' ') {
            buffer[chars_written++] = '\n';
            line_pos = 0;
        } else {
            /* Convert codepoint to UTF-8 for buffer */
            if (codepoint < 0x80) {
                if (chars_written < buffer_size - 1) {
                    buffer[chars_written++] = (char)codepoint;
                }
            } else if (codepoint < 0x800) {
                if (chars_written < buffer_size - 2) {
                    buffer[chars_written++] = (char)(0xC0 | (codepoint >> 6));
                    buffer[chars_written++] = (char)(0x80 | (codepoint & 0x3F));
                }
            } else if (codepoint < 0x10000) {
                if (chars_written < buffer_size - 3) {
                    buffer[chars_written++] = (char)(0xE0 | (codepoint >> 12));
                    buffer[chars_written++] = (char)(0x80 | ((codepoint >> 6) & 0x3F));
                    buffer[chars_written++] = (char)(0x80 | (codepoint & 0x3F));
                }
            }
        }
    }
    
    buffer[chars_written] = '\0';
    return chars_written;
}

/* Global error message storage */
static char g_error_title[512] = {0};
static char g_error_message[2048] = {0};
static char g_error_stack[8192] = {0};
static char g_error_extra[2048] = {0};
static bool g_has_error = false;

/* Set error information for display */
void sdl_set_error_info(const char* title, const char* message, const char* stack_trace) {
    g_has_error = true;
    
    if (title) {
        strncpy(g_error_title, title, sizeof(g_error_title) - 1);
        g_error_title[sizeof(g_error_title) - 1] = '\0';
    } else {
        strcpy(g_error_title, "Error");
    }
    
    if (message) {
        strncpy(g_error_message, message, sizeof(g_error_message) - 1);
        g_error_message[sizeof(g_error_message) - 1] = '\0';
    } else {
        g_error_message[0] = '\0';
    }
    
    if (stack_trace) {
        strncpy(g_error_stack, stack_trace, sizeof(g_error_stack) - 1);
        g_error_stack[sizeof(g_error_stack) - 1] = '\0';
    } else {
        g_error_stack[0] = '\0';
    }
    
    /* Log to stderr */
    LOG_SAFE("\n========================================\n");
    LOG_SAFE("  [J2ME UNCAUGHT EXCEPTION]\n");
    LOG_SAFE("========================================\n");
    LOG_SAFE("  Exception: %s\n", g_error_title);
    if (g_error_message[0]) LOG_SAFE("  Message:   %s\n", g_error_message);
    if (g_error_extra[0]) LOG_SAFE("  Details:   %s\n", g_error_extra);
    if (g_error_stack[0]) LOG_SAFE("  Stack:\n%s", g_error_stack);
    LOG_SAFE("========================================\n\n");
}

/* Set extra detail info */
void sdl_set_error_extra(const char* extra) {
    if (extra) {
        strncpy(g_error_extra, extra, sizeof(g_error_extra) - 1);
        g_error_extra[sizeof(g_error_extra) - 1] = '\0';
    } else {
        g_error_extra[0] = '\0';
    }
}

/* Check if there's an error to display */
bool sdl_has_error(void) {
    return g_has_error;
}

/* Clear error state */
void sdl_clear_error(void) {
    g_has_error = false;
    g_error_title[0] = '\0';
    g_error_message[0] = '\0';
    g_error_stack[0] = '\0';
    g_error_extra[0] = '\0';
}

/* Draw the error screen */
void sdl_draw_error_screen(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer) return;
    
    int width = ctx->width;
    int height = ctx->height;
    uint32_t* fb = ctx->framebuffer;
    
    /* Colors: ARGB format */
    const uint32_t bg_color = 0xFF800000;      /* Dark red background */
    const uint32_t title_color = 0xFFFFFFFF;   /* White title */
    const uint32_t msg_color = 0xFFFFFF00;     /* Yellow message */
    const uint32_t stack_color = 0xFFCCCCCC;   /* Light gray stack trace */
    const uint32_t border_color = 0xFFFF0000;  /* Red border */
    
    /* Fill background */
    for (int i = 0; i < width * height; i++) {
        fb[i] = bg_color;
    }
    
    /* Draw border */
    int border_width = 2;
    for (int y = 0; y < border_width; y++) {
        for (int x = 0; x < width; x++) {
            fb[y * width + x] = border_color;
            fb[(height - 1 - y) * width + x] = border_color;
        }
    }
    for (int x = 0; x < border_width; x++) {
        for (int y = 0; y < height; y++) {
            fb[y * width + x] = border_color;
            fb[y * width + (width - 1 - x)] = border_color;
        }
    }
    
    /* Calculate character width for wrapping */
    int char_width = FONT_WIDTH + 1;
    int max_chars = (width - 20) / char_width;
    if (max_chars < 10) max_chars = 10;
    if (max_chars > 60) max_chars = 60;
    
    /* Draw title with prefix */
    char title_line[300];
    /* %.280s caps the copy: g_error_title is 512 bytes, title_line is 300 */
    snprintf(title_line, sizeof(title_line), "[ERROR] %.280s", g_error_title);
    draw_error_string(fb, width, height, title_line, 10, 10, title_color);
    
    /* Draw separator */
    int sep_y = 10 + FONT_HEIGHT + 4;
    for (int x = 10; x < width - 10; x++) {
        fb[sep_y * width + x] = border_color;
    }
    
    /* Draw message */
    int msg_y = sep_y + 10;
    if (g_error_message[0]) {
        char wrapped_msg[3000];
        wrap_text_line(g_error_message, max_chars, wrapped_msg, sizeof(wrapped_msg));
        draw_error_string(fb, width, height, wrapped_msg, 10, msg_y, msg_color);
        msg_y += FONT_HEIGHT * 3;  /* Move down for stack trace */
    }
    
    /* Draw stack trace header */
    if (g_error_stack[0]) {
        draw_error_string(fb, width, height, "Stack trace:", 10, msg_y, title_color);
        msg_y += FONT_HEIGHT + 4;
        
        /* Draw separator */
        for (int x = 10; x < width - 10; x++) {
            fb[msg_y * width + x] = border_color;
        }
        msg_y += 4;
        
        /* Draw stack trace with wrapping */
        char wrapped_stack[6000];
        wrap_text_line(g_error_stack, max_chars, wrapped_stack, sizeof(wrapped_stack));
        draw_error_string(fb, width, height, wrapped_stack, 10, msg_y, stack_color);
    }
    
    /* Draw instructions */
    int inst_y = height - FONT_HEIGHT - 15;
    draw_error_string(fb, width, height, "Press ESC to exit", 10, inst_y, stack_color);
    
    /* v34.61: the error screen is drawn straight into the framebuffer by
     * the main thread; make it the settled frame so the scanout presenter
     * (which no longer reads the live framebuffer) actually shows it. */
    {
        extern void midp_present_settled_snapshot(void);
        midp_present_settled_snapshot();
    }
    
    /* Force redraw flag */
    ctx->needs_redraw = true;
}

/* ============================================
 * v34.72: "MIDlet finished" screen (SDL window app).
 * Same rationale as the libretro twin in sdl_backend_stubs.c: a finished
 * MIDlet must be visibly finished, not a frozen last frame.
 * ============================================ */
static int finished_text_width_px(const char* s) {
    int n = 0, i = 0, len = 0;
    if (!s) return 0;
    while (s[len]) len++;
    while (i < len) {
        int codepoint = utf8_decode(s, &i, len);
        if (codepoint < 0) break;
        n++;
    }
    return n > 0 ? n * (FONT_WIDTH + 1) - 1 : 0;
}

void sdl_draw_midlet_finished_screen(SdlContext* ctx) {
    if (!ctx || !ctx->framebuffer) return;

    int width = ctx->width;
    int height = ctx->height;
    uint32_t* fb = ctx->framebuffer;

    /* Black background */
    for (int i = 0; i < width * height; i++) {
        fb[i] = 0xFF000000;
    }

    const uint32_t title_color = 0xFFFFFFFF;  /* white */
    const uint32_t sub_color   = 0xFFA8A8A8;  /* light gray */
    const uint32_t dim_color   = 0xFF707070;  /* dim gray */
    const uint32_t frame_color = 0xFF303030;  /* thin frame */

    /* Thin frame */
    for (int x = 0; x < width; x++) {
        fb[x] = frame_color;
        fb[(height - 1) * width + x] = frame_color;
    }
    for (int y = 1; y < height - 1; y++) {
        fb[y * width] = frame_color;
        fb[y * width + width - 1] = frame_color;
    }

    int center_y = (height / 2) - 24;

    const char* title = "MIDlet finished";
    {
        int x = (width - finished_text_width_px(title)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, title, x, center_y, title_color);
    }
    {
        const char* sub = "\xD0\x9C\xD0\xB8\xD0\xB4\xD0\xBB\xD0\xB5\xD1\x82 \xD0\xB7\xD0\xB0\xD0\xB2\xD0\xB5\xD1\x80\xD1\x88\xD1\x91\xD0\xBD";  /* "Мидлет завершён" */
        int x = (width - finished_text_width_px(sub)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, sub, x, center_y + FONT_HEIGHT + 6, sub_color);
    }
    {
        int y = center_y + 2 * (FONT_HEIGHT + 6) + 2;
        for (int x = width / 4; x < width - width / 4; x++) {
            fb[y * width + x] = frame_color;
        }
    }
    {
        const char* hint = "The application has ended";
        int x = (width - finished_text_width_px(hint)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, hint, x, center_y + 3 * (FONT_HEIGHT + 6), dim_color);
    }
    {
        const char* hint = "Close the window or press ESC";
        int x = (width - finished_text_width_px(hint)) / 2;
        if (x < 1) x = 1;
        draw_error_string(fb, width, height, hint, x, height - 15, dim_color);
    }

    /* v34.61 semantics: make it the settled frame for the scanout. */
    {
        extern void midp_present_settled_snapshot(void);
        midp_present_settled_snapshot();
    }

    ctx->needs_redraw = true;
}

/* =========================================================================
 * v17: SDL clipboard bridge for com.nokia.mid.ui.Clipboard
 * v34.21: SDL_SetClipboardText/SDL_GetClipboardText need SDL >= 2.26; older
 * distros and mock-SDL builds don't have them — compile-time guard keeps
 * every configuration (real SDL2 new/old, mock, none) warning-free.
 * ========================================================================= */
#include <stdlib.h>
#if defined(__has_include)
#  if __has_include(<SDL2/SDL_version.h>)
#    include <SDL2/SDL_version.h>
#  elif __has_include(<SDL_version.h>)
#    include <SDL_version.h>
#  endif
#endif
#ifndef SDL_VERSION_ATLEAST
#  define SDL_VERSION_ATLEAST(X, Y, Z) 0
#endif

static void sdl_clipboard_set(const char* text) {
#if SDL_VERSION_ATLEAST(2, 26, 0)
    if (text && text[0]) {
        SDL_SetClipboardText(text);
    }
#else
    (void)text; /* clipboard unsupported on this SDL2 */
#endif
}

static char* sdl_clipboard_get(void) {
#if SDL_VERSION_ATLEAST(2, 26, 0)
    char* sys = SDL_GetClipboardText();
    if (!sys || !sys[0]) {
        if (sys) SDL_free(sys);
        return NULL;
    }
    /* Caller frees with free(); SDL requires SDL_free, so copy out */
    char* out = strdup(sys);
    SDL_free(sys);
    return out;
#else
    return NULL; /* clipboard unsupported on this SDL2 */
#endif
}

void sdl_setup_clipboard_hooks(void) {
    extern void midp_set_clipboard_hooks(void (*set_fn)(const char*), char* (*get_fn)(void));
    midp_set_clipboard_hooks(sdl_clipboard_set, sdl_clipboard_get);
}
