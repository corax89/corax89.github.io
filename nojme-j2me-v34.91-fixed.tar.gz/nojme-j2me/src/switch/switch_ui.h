/*
 * switch_ui.h — Nintendo Switch in-app menu: game browser + settings.
 */
#ifndef SWITCH_UI_H
#define SWITCH_UI_H

#include <stddef.h>

/* Result of the menu session. */
typedef enum {
    SWITCH_UI_EXIT = 0,   /* пользователь выбрал «Выход» */
    SWITCH_UI_GAME = 1    /* выбран jar — путь в out_path */
} SwitchUiResult;

/* Show the main menu (→ browser / settings) until a game is picked or the
 * user exits. Returns 1 and fills out_path on game selection, 0 on exit.
 * Uses the sdl_switch_* glue (switch_glue.h) — no direct SDL calls. */
int switch_ui_pick_game(char* out_path, size_t path_cap);

#endif /* SWITCH_UI_H */
