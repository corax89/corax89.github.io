/*
 * switch_trace.c — v34.91 freeze-triage implementation. See switch_trace.h
 * for the design. Linked into the Switch NRO and the host verification
 * builds only (never into the linux desktop app / libretro core).
 *
 * Log line format: "<ticks-ms> <text>\n" — one open(O_APPEND)+write+close
 * per line (stdio buffers would lose the tail exactly when it matters: a
 * hard hang or a crash). A first failure permanently disables file logging.
 */
#include "switch/switch_trace.h"

#if defined(__SWITCH__) || defined(NOJME_SWITCH_TRACE)

#include "switch/switch_glue.h"
#include "switch/switch_common.h" /* SWITCH_UI_WIDTH/HEIGHT */
#include "switch/switch_font.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

/* SDL headers (same discovery order as sdl_graphics.c): switch portlibs
 * expose both layouts, host pkg-config adds -I.../SDL2, the sandbox test
 * snapshot has SDL.h at its root. */
#if defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    include <SDL2/SDL.h>
#  elif __has_include(<SDL.h>)
#    include <SDL.h>
#  endif
#else
#  include <SDL.h>
#endif

#define TRACE_LINE_CAP 160
#define TRACE_LOG_CAP  (256 * 1024)

static char g_line[TRACE_LINE_CAP];      /* on-screen status line */
static int  g_log_fd = -2;               /* -2 not probed, -1 disabled, >=0 fd */
static uint64_t g_bytes = 0;             /* bytes written (cap guard) */
static int  g_beat_on = 0;
static int  g_banner_done = 0;

/* Log path: sdmc:/switch/j2me/log.txt on the Switch (the settings dir —
 * proven writable: every MINUS toggle saves settings.ini there); the
 * NOJME_SWITCH_UI_DIR verification dir on host builds; stderr only when
 * neither applies. */
static const char* trace_log_path(char* buf, size_t cap) {
#ifdef __SWITCH__
    (void)buf; (void)cap;
    return "sdmc:/switch/j2me/log.txt";
#else
    const char* d = getenv("NOJME_SWITCH_UI_DIR");
    if (d && d[0]) {
        snprintf(buf, cap, "%s/log.txt", d);
        return buf;
    }
    return NULL;
#endif
}

static void trace_log_write(const char* s, size_t n) {
    if (g_log_fd == -1 || g_bytes >= TRACE_LOG_CAP) return;

    if (g_log_fd == -2) {
        g_log_fd = -1; /* pessimistic default until the open succeeds */
        char pbuf[512];
        const char* p = trace_log_path(pbuf, sizeof(pbuf));
        if (p) {
#ifdef __SWITCH__
            mkdir("sdmc:/switch", 0777);
            mkdir("sdmc:/switch/j2me", 0777);
#endif
            /* First open per process TRUNCATES (one run = one log);
             * O_APPEND afterwards makes every write atomic-at-end, so
             * heartbeat lines from the SDL timer thread cannot clobber
             * lines written by the main thread. */
            int fd = open(p, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, 0666);
            if (fd >= 0) g_log_fd = fd;
        }
    }
    if (g_log_fd >= 0) {
        ssize_t w = write(g_log_fd, s, n);
        if (w > 0) {
            g_bytes += (uint64_t)w;
        } else if (w < 0) {
            close(g_log_fd);        /* broken card / removed dir: stop trying */
            g_log_fd = -1;
        }
    }
}

static void trace_emit(const char* text) {
    char out[TRACE_LINE_CAP + 64];
    uint64_t t = sdl_switch_ui_ticks_ms();
    int n = snprintf(out, sizeof(out), "%llu %s\n",
                     (unsigned long long)t, text);
    if (n > 0) {
        if ((size_t)n >= sizeof(out)) n = (int)sizeof(out) - 1;
        trace_log_write(out, (size_t)n);
        fprintf(stderr, "[TRACE] %s\n", text);
        fflush(stderr);
    }
}

void sw_trace(const char* fmt, ...) {
    char text[TRACE_LINE_CAP];

    /* One-time banner on first use (NOT a constructor: this must run after
     * SDL/env setup, and it proves WHICH build is actually running — the
     * whole point of CORE_BUILD_ID). */
    if (!g_banner_done) {
        g_banner_done = 1;
        extern const char* j2me_core_build_id(void);
        char b[128];
        snprintf(b, sizeof(b), "nojme %s trace start", j2me_core_build_id());
        trace_emit(b);
    }

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(text, sizeof(text), fmt, ap);
    va_end(ap);

    /* on-screen line: single writer (main thread); benign torn reads from
     * the heartbeat timer at worst garble one log line. */
    snprintf(g_line, sizeof(g_line), "%s", text);
    trace_emit(text);
}

const char* sw_trace_line(void) { return g_line; }

void sw_trace_flush(void) {
    uint32_t* cv = sdl_switch_ui_canvas();
    if (!cv || !g_line[0]) return;

    /* dark screen + centered stage line, presented immediately: if the code
     * right after this call hangs, the user SEES which stage did it. */
    const uint32_t bg = 0xFF0A0C10u;
    const uint32_t fg = 0xFFE8ECF4u;
    const int n = SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT;
    for (int i = 0; i < n; i++) cv[i] = bg;
    switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                          32, SWITCH_UI_HEIGHT / 2 - 16,
                          g_line, fg, 0, 2);
    sdl_switch_ui_present();
}

static Uint32 trace_beat_cb(Uint32 interval, void* param) {
    (void)param;
    char text[TRACE_LINE_CAP];
    snprintf(text, sizeof(text), "alive: %.100s", g_line);
    trace_emit(text);
    return interval; /* keep firing */
}

void sw_trace_heartbeat(void) {
    if (g_beat_on) return;
    g_beat_on = 1;
    SDL_AddTimer(2000, trace_beat_cb, NULL);
}

#endif /* __SWITCH__ || NOJME_SWITCH_TRACE */
