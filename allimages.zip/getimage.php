<?php
// Подключение к базе данных
$dbPath = '/media/data/images.db';
$pdo = new PDO("sqlite:$dbPath");

// Получение превью по ID
$id = 1; // ID медиафайла
if(isset($_GET["f"])){
	$id = $_GET["f"];

    $stmt = $pdo->prepare("SELECT thumbnail_blob, type FROM media WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $thumbnailBlob = $result['thumbnail_blob'];
        $type = $result['type'];
    
        // Отправка заголовков и вывод превью
        if ($type === 'image') {
            header('Content-Type: image/jpeg');
        } elseif ($type === 'video') {
            header('Content-Type: image/jpeg'); // Превью видео также в формате JPEG
        }
        echo $thumbnailBlob;
    } else {
        echo "Превью не найдено.";
    }
}
if(isset($_GET["i"])){
	$id = $_GET["i"];
    
    $stmt = $pdo->prepare("SELECT file_path, type FROM media WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $path = $result['file_path'];
        $type = $result['type'];
    
        // Отправка заголовков и вывод превью
        if ($type === 'image') {
            $image = file_get_contents($path);
            header('Content-Type: image/jpeg');
            echo $image;
        } elseif ($type === 'video') {
            header('Content-Type: video/mp4'); // Превью видео также в формате JPEG
        }
    } else {
        echo "Превью не найдено.";
    }	
}
if(isset($_GET["e"])){
	$id = $_GET["e"];
    
    $stmt = $pdo->prepare("SELECT file_path, exif_data, date, type FROM media WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $path = $result['file_path'];
        $exif_data = $result['exif_data'];
        $date = $result['date'];
        
        echo $path;
        echo "<br><pre>";
        echo json_encode(json_decode($exif_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        echo "</pre>";
        //echo '<a href="getimage.php?d=' . $_GET["e"] . '" />Удалить</a>';
    } else {
        echo "Превью не найдено.";
    }	
}
if(isset($_GET["d"])){
    $id = $_GET["d"];
    
    $stmt = $pdo->prepare("SELECT file_path FROM media WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $filePath = $result['file_path'];
        if (file_exists($filePath)) {
            if (unlink($filePath)) {
                echo "Файл успешно удален.";
            } else {
                $error = error_get_last();
                echo "Не удалось удалить файл. Ошибка: " . $error['message'];
            }
        } else {
            echo "Файл не существует.";
        }
    }
    
    $stmt = $pdo->prepare("DELETE FROM media WHERE id = :id");
    $stmt->execute([':id' => $id]);
    echo "Запись удалена";
}
