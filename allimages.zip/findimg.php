<?php

// Путь к файлу базы данных SQLite
$dbPath = '/media/data/images.db';
// Путь к папке с изображениями
$mediaDirectory = '/media/photo';

// Подключение к базе данных SQLite
try {
    $pdo = new PDO("sqlite:$dbPath");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Создание таблицы, если она не существует
$pdo->exec("
    CREATE TABLE IF NOT EXISTS media (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_path TEXT NOT NULL UNIQUE,
        date TEXT NOT NULL,
        thumbnail_blob BLOB,
        exif_data TEXT,
        type TEXT NOT NULL,
        last_modified INTEGER NOT NULL
    )
");

// Функция для создания превью изображения
function createImageThumbnail($src, $thumbWidth = 160) {
    list($width, $height, $type) = getimagesize($src);

    switch ($type) {
        case IMAGETYPE_JPEG:
            $image = imagecreatefromjpeg($src);
            break;
        case IMAGETYPE_PNG:
            $image = imagecreatefrompng($src);
            break;
        case IMAGETYPE_GIF:
            $image = imagecreatefromgif($src);
            break;
        default:
            return null;
    }

    $thumbHeight = floor($height * ($thumbWidth / $width));
    $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);

    imagecopyresampled($thumbnail, $image, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);

    // Сохраняем превью в буфер
    ob_start();
    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($thumbnail);
            break;
        case IMAGETYPE_PNG:
            imagepng($thumbnail);
            break;
        case IMAGETYPE_GIF:
            imagegif($thumbnail);
            break;
    }
    $thumbnailBlob = ob_get_clean();

    imagedestroy($image);
    imagedestroy($thumbnail);

    return $thumbnailBlob;
}

// Функция для создания превью видео
function createVideoThumbnail($src, $thumbWidth = 160) {
    //$outputFile = tempnam(sys_get_temp_dir(), 'thumb') . '.jpg';

    // Команда FFmpeg для извлечения кадра на 1-й секунде видео
    //$command = "ffmpeg -i '$src' -ss 00:00:01 -vframes 1 -vf scale=$thumbWidth:-1 '$outputFile' 2>&1";
    //$video = new Imagick($src . "[5]");
    //$video->setImageFormat['jpg'];
    //$video->writeImage($outputFile);
    //$video->clear();

    //if (!file_exists($outputFile)) {
    //    return null;
    //}

    // Чтение превью из файла
    $thumbnailBlob = file_get_contents(__DIR__ . "/video-play.jpg");

    // Удаление временного файла
    //unlink($outputFile);

    return $thumbnailBlob;
}

function getDateFromNameOrExif($name, $exifData){
    if ($exifData && isset($exifData['DateTimeOriginal'])) {
        // Преобразование даты в формат "год-месяц-число"
        $dateTime = DateTime::createFromFormat('Y:m:d H:i:s', $exifData['DateTimeOriginal']);
        $formattedDate = $dateTime->format('Y-m-d');
        return $formattedDate;
    }
    if(preg_match('/(\d{4})-?(\d{2})-?(\d{2})-?/', basename($name), $matches)) {
        $year = $matches[1];
        $month = $matches[2];
        $day = $matches[3];
        if($year > 1980)
            return "$year-$month-$day";
    }
    return "2000-00-00";
}

/**
 * Получает пути всех файлов и папок в указанной папке.
 *
 * @param  string $dir             Путь до папки (на конце со слэшем или без).
 *                                                        
 * @return array Вернет массив путей до файлов/папок.
 */
function get_dir_files( $dir ){
	$filenames = array();
	$dir = rtrim( $dir, '/' ); // удалим слэш на конце

	if( is_dir($dir) ){
		if( $handle = opendir($dir) ){
			chdir( $dir );
			while( false !== ($file = readdir($handle)) ){ 
				if( $file != "." && $file != '..' ){ 
					if( is_dir($file) ){ 
						$arr = get_dir_files( $file );
						foreach( $arr as $value ) $filenames[] = $dir .'/'. $value;
					}
					else {
						$filenames[] = $dir .'/'. $file;
					}
				}
			}
			chdir('../');
		}
		closedir( $handle );
	}

	return $filenames;
}

function processDirectory($path) {
    global $pdo;
    $count = 0;
    $files_list = get_dir_files($path);

    foreach ($files_list as $filePath) {
        $mimeType = mime_content_type($filePath);

        // Проверяем, существует ли файл
        if (!file_exists($filePath)) {
            // Удаляем запись, если файл не существует
            $stmt = $pdo->prepare("DELETE FROM media WHERE file_path = :file_path");
            $stmt->execute([':file_path' => $filePath]);
            echo "Удалено: $filePath\n";
            continue;
        }

        // Получаем время последнего изменения файла
        $lastModified = filemtime($filePath);

        // Проверяем, существует ли запись для этого файла
        $stmt = $pdo->prepare("SELECT id, last_modified FROM media WHERE file_path = :file_path");
        $stmt->execute([':file_path' => $filePath]);
        $existingRecord = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingRecord) {
            // Если файл не изменился, пропускаем его
            if ($existingRecord['last_modified'] == $lastModified) {
                $count++;
                echo "$count Пропущено (без изменений): $filePath\n";
                continue;
            }
        }

        if (strpos($mimeType, 'image/') === 0) {
            // Обработка изображений
            $exif = exif_read_data($filePath);
            $thumbnailBlob = createImageThumbnail($filePath);
            $type = 'image';
        } elseif (strpos($mimeType, 'video/') === 0) {
            // Обработка видео
            $exif = []; // Для видео EXIF-данных нет
            $thumbnailBlob = createVideoThumbnail($filePath);
            $type = 'video';
        } else {
            continue; // Пропускаем файлы, которые не являются изображениями или видео
        }
        
        if ($thumbnailBlob) {
            $count++;
            if ($existingRecord) {
                // Обновляем существующую запись
                $stmt = $pdo->prepare("UPDATE media SET date = :date, thumbnail_blob = :thumbnail_blob, exif_data = :exif_data, last_modified = :last_modified WHERE id = :id");
                $stmt->execute([
                    ':date' => getDateFromNameOrExif($filePath, $exif),
                    ':thumbnail_blob' => $thumbnailBlob,
                    ':exif_data' => json_encode($exif),
                    ':last_modified' => $lastModified,
                    ':id' => $existingRecord['id']
                ]);
                echo "$count Обновлено: $filePath ". getDateFromNameOrExif($filePath, $exif) . "\n";
            } else {
                // Добавляем новую запись
                $stmt = $pdo->prepare("INSERT INTO media (file_path, date, thumbnail_blob, exif_data, type, last_modified) VALUES (:file_path, :date, :thumbnail_blob, :exif_data, :type, :last_modified)");
                $stmt->execute([
                    ':file_path' => $filePath,
                    ':date' => getDateFromNameOrExif($filePath, $exif),
                    ':thumbnail_blob' => $thumbnailBlob,
                    ':exif_data' => json_encode($exif),
                    ':type' => $type,
                    ':last_modified' => $lastModified
                ]);
                echo "$count Добавлено: $filePath ". getDateFromNameOrExif($filePath, $exif) . "\n";
            }
        }
    }
}

// Запуск обработки
processDirectory($mediaDirectory);
$query = "CREATE INDEX IF NOT EXISTS idx_date ON media (date)";
$stmt = $pdo->query($query);

echo "Обработка завершена.\n";