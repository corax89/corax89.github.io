<!DOCTYPE html>
<html>
  <head lang="en">
    <meta charset="UTF-8" />
    <title>
      Фотоархив
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
    html,body{
      width: 100%;
      height: 100%;
      overflow: hidden;
      background-color: #f1f1f1;
    }
    img:not([src]) {
        visibility: hidden;
    }
    /* Fixes Firefox anomaly during image load */
    @-moz-document url-prefix() {
        img:-moz-loading {
            visibility: hidden;
        }
    }
    #background{
        display: block;
        position: fixed;
        margin: -2em;
        filter: blur(15px);
        width: 100%;
    }
    #container{
        display:flex;
        width: 99%;
        height: 99%;
    }
    #full{
        display: none;
        flex-grow: 1;
        width: 99%;
        height: 99%;
    }
    #full:hover #info{
        display:block;
    }
    #prev{
        position: relative;
        z-index: 2;
        max-height: 100%;
        flex-direction: column;
        overflow: auto;
    }
    #fullImage {
        display: flex;
        flex: 1;
        object-fit: contain;
        margin: auto;
        max-width: 100%;
        max-height: 100%;
        filter: drop-shadow(2px 2px 4px #333);
        z-index: 1;
    } 
    #fullVideo{
        display: flex;
        flex: 1;
        object-fit: contain;
        margin: auto;
        max-width: 100%;
        max-height: 100%;
        z-index: 1;
        filter: drop-shadow(2px 2px 4px #333);
        display: none;
    }
    #info{
        display: none;
        position: fixed;
        width: 3em;
        height: 2em;
        background-color: rgba(251,251,251,.5);
        border: 1px solid #000;
        border-radius: 6px;
        text-align: center;
        text-decoration: none;
        line-height: 2em;
        box-shadow: 0 0 8px #333;
        z-index: 999;
    }
    .thumb {
        padding: 4px;
        margin: auto;
        margin-top: 15px;
        margin-left: 12px;
        width: 160px;
        background: #fff;
        box-shadow: 2px 2px 4px #333;
        transition: all 0.5s ease;
        display: inline-block;
    }
    .thumb:hover {
        box-shadow: 0 0 8px #333;
    }
    .selectedprev{
        display:flex;
        width:260px;
    }
    @media (orientation: portrait) {
        #container {
            flex-direction: column;
        }
        #prev{
            flex-direction: row;
            overflow-y: hidden;
            overflow-x: auto;
            height: 500px;
            width: 100%;
        }
    }
    </style>
  </head>
<body>
<img id="background">
<div id="container">
<div id="full">
    <a id="info" target="_blank">i</a>
    <video class="op-player__media" id="fullVideo" controls>
    </video>
    <img id="fullImage"/>
</div>
<div id="prev">
<?php
flush();
ob_flush();
$dbPath = '/media/data/images.db';
// Путь к папке с изображениями
$mediaDirectory = '/media/photo';

// Подключение к базе данных SQLite
try {
    $pdo = new PDO("sqlite:$dbPath");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$table_name = "media";
$query = "SELECT * FROM $table_name ORDER BY date DESC";
$stmt = $pdo->query($query);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<div class=\"thumb\"><img class=\"lazy\" src=\"video-play.jpg\" data-src=\"getimage.php?f=";
    echo $row['id'] . "\" onclick=\"viewImg('" . str_replace('/media','data',$row['file_path']) . "'," . $row['id'] . ")\"";
    echo "\" width=\"160\"/>" . $row['date'] . "</div>";
    flush();
    ob_flush();
}
?>
</div>
</div>
<script>
    var video = document.getElementById('fullVideo');
    var source = document.createElement('source');
    
    source.setAttribute('src', '');
    source.setAttribute('type', 'video/mp4');
    
    video.appendChild(source);
    video.play();
    function viewImg(path, id){
        var s=path.match(/\.([^.]+)$|$/)[1];
        document.getElementById("info").href = "getimage.php?e=" + id;
        document.getElementById("full").style.display = "flex";
        document.getElementById("prev").className = "selectedprev";
        if(s == "MP4" || s == "mp4" || s == "3gp" || s == "3GP"){
            video.pause();
            source.setAttribute('src', path);
            source.setAttribute('type', 'video/webm');
            video.load();
            video.play();
            document.getElementById("fullVideo").style.display = 'block';
            document.getElementById("fullImage").style.display = 'none';
        }
        else{
            video.pause();
            document.getElementById("fullImage").src = path;
            document.getElementById("background").src = path;
            document.getElementById("fullVideo").style.display = 'none';
            document.getElementById("fullImage").style.display = 'block';
        }
    }
</script>
<script>
  // Set the options globally
  // to make LazyLoad self-initialize
  window.lazyLoadOptions = {
    // Your custom settings go here
  };
  // Listen to the initialization event
  // and get the instance of LazyLoad
  window.addEventListener(
    "LazyLoad::Initialized",
    function (event) {
      window.lazyLoadInstance = event.detail.instance;
    },
    false
  );
</script>
<script async src="lazyload.min.js"></script>
</body>
</html>