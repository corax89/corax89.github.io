#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <SPI.h>
#include <Wire.h>
#include <LittleFS.h>
#include <TFT_eSPI.h>

#include "user_interface.h"
#include "settings.h"
#include "cpu6502.h"
#include "help.h"
#include "gui.h"

#ifdef ESPBOY
  #include <Adafruit_MCP4725.h>
  #include <ESP8266httpUpdate.h>
  Adafruit_MCP4725 dac;
#endif

uint8_t RAM[RAM_SIZE];
char source[SOURCE_SIZE] = "";
uint8_t global_animation = 1;

extern uint16_t asm6502(char *s, uint8_t *ram, char *error_s);
extern void getKey();
extern uint8_t thiskey();
extern uint16_t  viewEditor(char *str_list_i);
extern void drawError(char *error_string);
extern void geti2cAdress();
extern void scani2c();
extern void getKey();
extern void viewHelp(const unsigned char * p, uint16_t max_length);
extern void sTextEditor(char s[]);
extern uint8_t thiskey();
extern uint16_t fileList();
extern void drawSettings();
extern uint16_t programm_size;

enum e_global_state {
    START_MENU, FILE_MANAGER, EDITOR, ASM, CPU
}global_state;

void WiFiOff() {
  wifi_station_disconnect();
  wifi_set_opmode(NULL_MODE);
  wifi_set_sleep_type(MODEM_SLEEP_T);
  wifi_fpm_open();
  wifi_fpm_do_sleep(0xFFFFFFF);
  WiFi.forceSleepBegin();
}

void setup() {
  delay(1);
  system_update_cpu_freq(FREQUENCY);
  randomSeed(RANDOM_REG32);
  Serial.begin(115200);
  
  Serial.print(F("\nversion "));
  Serial.print(F(BUILD_VERSION_MAJOR));
  Serial.print('.');
  Serial.print(F(BUILD_VERSION_MINOR));
  Serial.print(F(" build "));
  Serial.print(F(__DATE__));

#ifdef ESPBOY
  Serial.println();
  Serial.println(F("ESPboy"));
  scani2c();
  //DAC init
  dac.begin(MCP4725address);
  delay(100);
  dac.setVoltage(0, true);
  delay(50);

  //initialize LCD
  initGui();
  //LCD backlit on
  for (int count = 0; count < 1000; count += 50){
    dac.setVoltage(count, false);
    delay(50);
  }
  
  delay(100);
#else
  Wire.begin(D2, D1);
  initGui();
#endif

  LittleFSConfig cfg;
  cfg.setAutoFormat(false);
  LittleFS.setConfig(cfg);
  if(LittleFS.begin()){
    Serial.println(F("LittleFS ok"));
  }
  else{
    drawString(F("LittleFS init FAILED"), 2, 8, 1);
    drawString(F("LittleFS FORMATING..."), 2, 14, 1);
    Serial.println(F("LittleFS init FAILED. Formatting..."));
    if(LittleFS.format()){
      Serial.println(F("Formatting DONE"));
      drawString(F("Formatting DONE!"), 2, 20, 1);
      redrawScreen(128);
      LittleFS.begin();
      delay(2000);
    }
    else {
      Serial.println(F("Formatting FAILED"));
      drawString(F("Formatting FAILED"), 2, 20, 1);
      redrawScreen(128);
      delay(2000);
    }
  }
  randomSeed(RANDOM_REG32);
  // turn off ESP8266 RF
  WiFiOff();
  delay(1);
  Serial.print(F("free mem: "));
  Serial.println(system_get_free_heap_size());
  Serial.println(F("Enter '?' to list available options."));
  Serial.print('>');
  global_state = START_MENU;
}

extern char error_string[32];

void loop() {
  uint8_t m;
  switch(global_state){
    case START_MENU: {
        clearScr(0);
        drawBackground();
        m = drawMenu(F("editor|load file|help|settings"));
        if(m == 0)
          global_state = EDITOR;
        else if(m == 1)
          global_state = FILE_MANAGER;
        else if(m == 2)
          viewHelp(help_file, sizeof(help_file));
        else if(m == 3)
          drawSettings();
      }
      break;
    case FILE_MANAGER: {
        m = fileList();
        if(m == 1)
          global_state = CPU;
        else if(m == 2)
          global_state = EDITOR;
        else
          global_state = START_MENU;
      }
      break;
    case EDITOR: {
        m = viewEditor(source);
        if(m == 0)
          global_state = START_MENU;
        else if(m == 1)
          global_state = ASM;
        else if(m == 2)
          global_state = CPU;
      }
      break; 
    case ASM:{
        int32_t asm_timer = millis();
        programm_size = asm6502(source, RAM, error_string);
        asm_timer = millis() - asm_timer;
        if(error_string[0] == 0xff){
          drawInfo(F("assembly complete\ntime %0 ms\nsize %1 byte"), asm_timer, programm_size);
          reset6502();
          clearScr(0);
          redrawScreen(128);
        }
        else{
          drawError(error_string);
        }
        global_state = EDITOR;
      }
      break;
    case CPU:{
        m = 0;
        clearScr(0);
        while(global_state == CPU){
          int32_t asm_timer = millis();
          exec6502(16384);
          asm_timer = millis() - asm_timer;
          Serial.print("loop time");
          Serial.println(asm_timer);
          asm_timer = millis();
          redrawScreen(64);
          asm_timer = millis() - asm_timer;
          Serial.print("draw time");
          Serial.println(asm_timer);
          if(Serial.available()){
            char c = Serial.read();
            if(c == 'r')
              ESP.reset();
            else if(c == 'd')
              m = drawDebug();
          }
          getKey();
          if(thiskey() == 192) //key start + select
            m = drawDebug();
          yield();
          if(m == 2)
            global_state = EDITOR;
        }
      }
      break;
  }
}
