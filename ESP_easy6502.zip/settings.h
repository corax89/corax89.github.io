#define ESPBOY
#define RAM_SIZE    16 * 1024
#define SOURCE_SIZE 16 * 1024
#define LABEL_ARRAY_SIZE 384
#define LABEL_LINKS_SIZE 128
#define LABEL_MACROS_SIZE 32
#define FREQUENCY   160    // valid 80, 160
#define PROGRAMM_OFFSET 0x1200
#define BUILD_VERSION_MAJOR "1"
#define BUILD_VERSION_MINOR "000"

#ifdef ESPBOY
  #define APSSID "ESPboy"
  #define APHOST "espboy"
  #define MCP4725address    0x60
  #define MCP23017address   0
  #define csTFTMCP23017pin  8
  #define LEDquantity       1
  #define LEDPIN            D4
  #define SOUNDPIN          D3
  
#else
  #define APSSID "easy6502"
  #define APHOST "easy6502"
  #define SOUNDPIN       -1
#endif

#define SCREEN_WIDTH        128
#define SCREEN_HEIGHT       128
#ifdef ESPBOY
  #define SCREEN_REAL_WIDTH   128
  #define SCREEN_REAL_HEIGHT  128
#else
  #define SCREEN_REAL_WIDTH   320
  #define SCREEN_REAL_HEIGHT  240
#endif
#define SCREEN_SIZE (SCREEN_HEIGHT * SCREEN_WIDTH_BYTES)
#define SCREEN_ARRAY_DEF SCREEN_SIZE
#define SCREEN_ADDR(x, y) ((int(y) << 6) + int(x))

#define TERMINAL_WIDTH           28
#define TERMINAL_HEIGHT          14
#define USE_SYNTAX_HIGHLIGHTING  1

#define KEY_UP      1
#define KEY_DOWN    2
#define KEY_LEFT    4
#define KEY_RIGHT   8
#define KEY_A       16
#define KEY_B       32
#define KEY_SELECT  64
#define KEY_START   128
