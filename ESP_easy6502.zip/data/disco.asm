; DISCO DISCO

start:
 inx
 txa
 sta $200, y
 sta $300, y
 sta $400, y
 sta $500, y
 sta $600, y
 sta $700, y
 sta $800, y
 sta $900, y
 sta $A00, y
 sta $B00, y
 sta $C00, y
 sta $D00, y
 sta $E00, y
 sta $F00, y
 sta $1000, y
 sta $1100, y
 iny
 tya
 cmp 16
 bne do
 iny
 jmp start
do:
 iny
 iny
 iny
 iny
jmp start