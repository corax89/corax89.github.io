#include <Arduino.h>
#include <stdint.h>
#include <stdlib.h>
#include "settings.h"

#define null  0x00
#define true  1
#define false 0

#define SPACE_SKIP(a, b) while(a[b] == ' '){b++;}
#define NUMBER_SKIP(a, b) while((a[b] >= '0' && a[b] <= '9') || (a[b] >= 'a' && a[b] <= 'f') || (a[b] >= 'A' && a[b] <= 'F')){b++;}

enum a_mode {
    NONE, IMM, ZP, ZPX, ZPY, ABS, ABSX, ABSY, IND, INDX, INDY, SNGL, ACC
};

enum v_bytes {
    BYTE, WORD, LOBYTE, HIBYTE 
};

enum macro_mode {
    VALUE, ADDRESS, LABEL 
};

const char mnemonic[24][4] PROGMEM = {
   "ADC", "AND", "ASL", "BIT", "CMP", "CPX", "CPY", "DEC", "EOR", "INC", "JMP", "JSR", 
   "LDA", "LDX", "LDY", "LSR", "ORA", "ROR", "ROL", "SBC", "STA", "STX", "STY", "WDM"};

const uint8_t opcodes[24][12] PROGMEM = {
    /* Imm,  ZP,   ZPX,  ZPY,  ABS,  ABSX, ABSY,  IND, INDX, INDY, ACC */
      {0x69, 0x65, 0x75, null, 0x6d, 0x7d, 0x79, null, 0x61, 0x71, null},//"ADC"
      {0x29, 0x25, 0x35, null, 0x2d, 0x3d, 0x39, null, 0x21, 0x31, null},//"AND"
      {null, 0x06, 0x16, null, 0x0e, 0x1e, null, null, null, null, 0x0a},//"ASL"
      {null, 0x24, null, null, 0x2c, null, null, null, null, null, null},//"BIT"
      {0xc9, 0xc5, 0xd5, null, 0xcd, 0xdd, 0xd9, null, 0xc1, 0xd1, null},//"CMP"
      {0xe0, 0xe4, null, null, 0xec, null, null, null, null, null, null},//"CPX"
      {0xc0, 0xc4, null, null, 0xcc, null, null, null, null, null, null},//"CPY"
      {null, 0xc6, 0xd6, null, 0xce, 0xde, null, null, null, null, null},//"DEC"
      {0x49, 0x45, 0x55, null, 0x4d, 0x5d, 0x59, null, 0x41, 0x51, null},//"EOR"
      {null, 0xe6, 0xf6, null, 0xee, 0xfe, null, null, null, null, null},//"INC"
      {null, null, null, null, 0x4c, null, null, 0x6c, null, null, null},//"JMP"
      {null, null, null, null, 0x20, null, null, null, null, null, null},//"JSR"
      {0xa9, 0xa5, 0xb5, null, 0xad, 0xbd, 0xb9, null, 0xa1, 0xb1, null},//"LDA"
      {0xa2, 0xa6, null, 0xb6, 0xae, null, 0xbe, null, null, null, null},//"LDX"
      {0xa0, 0xa4, 0xb4, null, 0xac, 0xbc, null, null, null, null, null},//"LDY"
      {null, 0x46, 0x56, null, 0x4e, 0x5e, null, null, null, null, 0x4a},//"LSR"
      {0x09, 0x05, 0x15, null, 0x0d, 0x1d, 0x19, null, 0x01, 0x11, null},//"ORA"
      {null, 0x66, 0x76, null, 0x6e, 0x7e, null, null, null, null, 0x6a},//"ROR"
      {null, 0x26, 0x36, null, 0x2e, 0x3e, null, null, null, null, 0x2a},//"ROL"
      {0xe9, 0xe5, 0xf5, null, 0xed, 0xfd, 0xf9, null, 0xe1, 0xf1, null},//"SBC"
      {null, 0x85, 0x95, null, 0x8d, 0x9d, 0x99, null, 0x81, 0x91, null},//"STA"
      {null, 0x86, null, 0x96, 0x8e, null, null, null, null, null, null},//"STX"
      {null, 0x84, 0x94, null, 0x8c, null, null, null, null, null, null},//"STY"
      {0x42, 0x42, null, null, null, null, null, null, null, null, null} //"WDM"
    };
  

const char mnemonic_sngl[8][4] PROGMEM = 
  {"BPL", "BMI", "BVC", "BVS", "BCC", "BCS", "BNE", "BEQ"};

const uint8_t opcodes_sngl[8] PROGMEM = 
  //BPL,  BMI,  BVC,  BVS,  BCC,  BCS,  BNE,  BEQ 
  {0x10, 0x30, 0x50, 0x70, 0x90, 0xb0, 0xd0, 0xf0};
            
const char mnemonic_indy[25][4] PROGMEM = {
  "CLC", "SEC", "CLI", "SEI", "CLV", "CLD", "SED", "TAX", "TXA", "DEX", "INX", "TAY",
  "TYA", "DEY", "INY", "TXS", "TSX", "PHA", "PLA", "PHP", "PLP", "RTI", "RTS", "NOP", "BRK"};

const uint8_t opcodes_indy[25] PROGMEM  =  
  //CLC,  SEC,  CLI,  SEI,  CLV,  CLD,  SED,  TAX,  TXA,  DEX,  INX,  TAY,  TYA,  DEY,  INY,  TXS,  TSX,  PHA,  PLA,  PHP,  PLP,  RTI,  RTS,  NOP,  BRK
  {0x18, 0x38, 0x58, 0x78, 0xb8, 0xd8, 0xf8, 0xaa, 0x8a, 0xca, 0xe8, 0xa8, 0x98, 0x88, 0xc8, 0x9a, 0xba, 0x48, 0x68, 0x08, 0x28, 0x40, 0x60, 0xea, 0x00};

const char types_definitions[3][5] PROGMEM  = 
  {"TEXT", "BYTE", "WORD"};

const char macros_definitions[] PROGMEM  = 
  {"MACRO"};

const char endmacros_definitions[] PROGMEM  = 
  {"ENDMACRO"};

uint16_t *label_array;                   //указатели
uint16_t *label_links_array;             //ссылки на указатели
uint16_t macro_array[LABEL_MACROS_SIZE]; //указатели на макросы
uint16_t label_index = 0;
uint16_t label_links_index = 0;
uint16_t macro_index = 0;

const char error_0[] PROGMEM = "syntax error";
const char error_1[] PROGMEM = "label array is overflowing";
const char error_2[] PROGMEM = "error bytearray definition";
const char error_3[] PROGMEM = "is not defined";
const char error_4[] PROGMEM = "this type is not supported";
const char error_5[] PROGMEM = "transition longer than 127";
const char error_6[] PROGMEM = "macro is incorrectly defined";

struct Macro_struct {
  uint8_t is_macros; 
  uint16_t str_position;
  uint16_t saved_str_position;
  uint16_t str_a[3];
  uint16_t val_a[3];
  macro_mode type[3];
  uint16_t save_label;
} macro;

void opcodeDisasm(char s[], uint8_t op){
  uint16_t i, j, k;
  for(i = 0; i < 25; i++){
    if(pgm_read_byte(&opcodes_indy[i]) == op){
      for(j = 0; j < 3; j++)
        s[j] = pgm_read_byte(&mnemonic_indy[i][j]);
      s[3] = 0;
      return;
    }
  }
  for(i = 0; i < 8; i++){
    if(pgm_read_byte(&opcodes_sngl[i]) == op){
      for(j = 0; j < 3; j++)
        s[j] = pgm_read_byte(&mnemonic_sngl[i][j]);
      s[3] = 0;
      return;
    }
  }
  for(i = 0; i < 24; i++){
    for(k = 0; k < 12; k++){
      if(pgm_read_byte(&opcodes[i][k]) == op){
        for(j = 0; j < 3; j++)
          s[j] = pgm_read_byte(&mnemonic[i][j]);
        s[3] = 0;
        return;
      }
    }
  }
  while(j < 3)
    s[j++] = '?';
  s[3] = 0;
  return;
}

char toUpper(char c){
  if(c >= 'a')
    return c - 'a' + 'A';
  return c;
}

uint16_t isChar(char c){
  if(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_')
    return true;
  return false;
}

uint16_t isNamber(char c){
  if(c >= '0' && c <= '9')
    return true;
  return false;
}

//получить обратный данному условный переход
uint8_t getReverseTransition(uint8_t op){
  uint16_t i;
  for(i = 0; i < 8; i++){
    if(pgm_read_byte(&opcodes_sngl[i]) == op){
      if(i & 0x01)
        return pgm_read_byte(&opcodes_sngl[i - 1]);
      else
        return pgm_read_byte(&opcodes_sngl[i + 1]);
    }
  }
  return 0;
}

uint8_t isDefinition(char s[], uint16_t i, uint16_t t){
  uint8_t j = 0;
  //пока совпадает увеличивать счетчик
  while(toUpper(s[i + 1 + j]) == (char)pgm_read_byte(&types_definitions[t][j]) && j < 5)
    j++;
  //если счетчик совпал и в конце пробел то это искомое
  if(j >= 4 && s[i + 5] == ' '){
    return true;
  }
  return false;
}

uint16_t stringHexToInt(char s[], uint16_t i){
  uint16_t n = 0;
  while((s[i] >= '0' && s[i] <= '9') || (s[i] >= 'a' && s[i] <= 'f') || (s[i] >= 'A' && s[i] <= 'F')){
    if(s[i] < 'A')
      n = n * 16 + (s[i] - 0x30);
    else if(s[i] < 'a')
      n = n * 16 + (s[i] - 0x41 + 10);
    else
      n = n * 16 + (s[i] - 0x61 + 10);
    i++;
  }
  return n;
}

uint16_t stringIntToInt(char s[], uint16_t i){
  uint16_t n = 0;
  while(s[i] >= '0' && s[i] <= '9'){
    n = n * 10 + (s[i] - 0x30);
    i++;
  }
  return n;
}

uint16_t initLabelsMemory(){
  label_array = (uint16_t*)malloc(LABEL_ARRAY_SIZE * 2 * sizeof(uint16_t));
  label_links_array = (uint16_t*)malloc(LABEL_LINKS_SIZE * 2 * sizeof(uint16_t));
  if(label_links_array == NULL || label_array == NULL){
    Serial.println(F("Out of memory"));
    return 0;
  }
  return 1;
}

void freeLabelsMemory(){
  free(label_array);
  free(label_links_array);
}
//очистить массивы указателей
void clearLabels(){
  uint16_t i;
  for(i = 0; i < LABEL_ARRAY_SIZE * 2; i++)
    label_array[i] = 0;
  for(i = 0; i < LABEL_LINKS_SIZE * 2; i++)
    label_links_array[i] = 0;
  for(i = 0; i < LABEL_MACROS_SIZE; i++)
    macro_array[i] = 0;
  label_index = 0;
  label_links_index = 0;
  macro_index = 0;
}

int16_t addLabels(uint16_t str_adr, uint16_t value){
  if(label_index > LABEL_ARRAY_SIZE - 2)
    return -1;
  label_array[label_index++] = str_adr;
  label_array[label_index++] = value;
  return label_index;
}

//добавить новый указатель
int16_t addLinksLabels(uint16_t str_adr, uint16_t code_adr){
  if(label_links_index > LABEL_LINKS_SIZE - 2)
    return -1;
  label_links_array[label_links_index++] = str_adr;
  label_links_array[label_links_index++] = code_adr;
  return label_links_index;
}

//заменить предыдущие указатели если для них появились значения
uint8_t replaceLinksLabels(uint16_t str_adr, char *s, uint8_t *ram, uint16_t value){
  uint16_t i, j, k, n, v;
  //проверить массив указателей
  for(i = 0; i < label_links_index; i += 2){
    j = str_adr;
    k = label_links_array[i];
    //сравнивать значения в строке пока не будет достигнут символ конца указателя
    while(s[j] != ':' && s[k] == s[j]){
      j++;
      k++;
    }
    if(s[j] == ':' && !(isChar(s[k]) || isNamber(s[k]))){
      n = label_links_array[i + 1];
      SPACE_SKIP(s, k)
      if(s[k] == '-'){
        v = 0;
        k++;
        SPACE_SKIP(s, k)
        while(s[k] >= '0' && s[k] <= '9'){
            v = v * 10 + (s[k] - 0x30);
            k++;
          }
        value -= v;
      }
      else if(s[k] == '+'){
        v = 0;
        k++;
        SPACE_SKIP(s, k)
        while(s[k] >= '0' && s[k] <= '9'){
            v = v * 10 + (s[k] - 0x30);
            k++;
          }
        value += v;
      }
      if(s[label_links_array[i - 1]] == '>')
        value = value >> 8;
      else if(s[label_links_array[i - 1]] == '<')
        value = value & 0xff;
      if(n > 0 && getReverseTransition(ram[n - 1])){
        int32_t b = ((int32_t)value) - (PROGRAMM_OFFSET + n + 1);
        //если расстояние до адреса меньше 127
        if(b >= -127 || b <= 127){
          ram[n] = b & 0xff;
        }
        //иначе ошибка, слишком длинный переход
        else{
          return 1;
        }
      }
      else{
        ram[n] = value & 0xff;
        ram[n + 1] = value >> 8;
      }
      for(j = i; j < label_links_index - 1; j++){
        label_links_array[j] = label_links_array[j + 2];
        label_links_array[j + 1] = label_links_array[j + 3];
      }
      i -= 2;
      label_links_index -= 2;
    }
  }
  return 0;
}

uint16_t addMacros(char s[], uint16_t str_adr){
  uint8_t j;
  if(macro_index > LABEL_MACROS_SIZE - 1)
    return 0;
  SPACE_SKIP(s, str_adr);
  macro_array[macro_index++] = str_adr;
  while(s[str_adr] != 0){
    if(s[str_adr] == '.'){
      str_adr++;
      j = 0;
      //пока совпадает увеличивать счетчик
      while(toUpper(s[str_adr]) == (char)pgm_read_byte(&endmacros_definitions[j]) && j < 9){
        str_adr++;
        j++;
      }
      if(j == 8){
        return str_adr + 1;
      }
    }
    str_adr++;
  }
  return 0;
}

uint16_t getMacros(char s[], uint16_t str_adr){
  uint16_t i, j, k, n;
  //проверить массив макросов
  for(i = 0; i < macro_index; i++){
    j = str_adr;
    k = macro_array[i];
    //сравнивать значения в строке пока они одинаковы
    while(s[k] == s[j] && s[j] != 0 && s[j] != ' '){
      j++;
      k++;
    }
    if(s[k] == ' ' || s[k] == '\n' || s[k] == ';'){
      macro.str_a[0] = 0;
      macro.str_a[1] = 0;
      macro.str_a[2] = 0;
      SPACE_SKIP(s, k)
      if(isChar(s[k])){
        n = k;
        while(isChar(s[k]) || isNamber(s[k]))
          k++;
        macro.str_a[0] = n;
        SPACE_SKIP(s, k)
        if(s[k] == ','){
          k++;
          n = k;
          while(isChar(s[k]) || isNamber(s[k]))
            k++;
          macro.str_a[1] = n;
          SPACE_SKIP(s, k)
          if(s[k] == ','){
            k++;
            n = k;
            while(isChar(s[k]) || isNamber(s[k]))
              k++;
            macro.str_a[2] = n;
            SPACE_SKIP(s, k)
          }
          if(s[k] == ','){
            //error
            
          }
        }
      }
      SPACE_SKIP(s, j)
      if(s[j] == '#'){
        j++;
        macro.type[0] = VALUE;
      }
      else{
        macro.type[0] = ADDRESS;
      }
      if(s[j] == '$'){
        j++;
        macro.val_a[0] = stringHexToInt(s, j);
      }
      else if(isNamber(s[j])){
        macro.val_a[0] = stringIntToInt(s, j);
      }
      else if(isChar(s[j])){
        macro.val_a[0] = j;
        macro.type[0] = LABEL;
        while(isChar(s[j]) && s[j])
          j++;
      }
      NUMBER_SKIP(s, j)
      SPACE_SKIP(s, j)
      if(s[j] == ','){
        j++;
        SPACE_SKIP(s, j)
        if(s[j] == '#'){
          j++;
          macro.type[1] = VALUE;
        }
        else{
          macro.type[1] = ADDRESS;
        }
        if(s[j] == '$'){
          j++;
          macro.val_a[1] = stringHexToInt(s, j);
        }
        else if(isNamber(s[j])){
          macro.val_a[1] = stringIntToInt(s, j);
        }
        else if(isChar(s[j])){
          macro.val_a[1] = j;
          macro.type[1] = LABEL;
          while(isChar(s[j]) && s[j])
            j++;
        }
        NUMBER_SKIP(s, j)
        SPACE_SKIP(s, j)
        if(s[j] == ','){
          j++;
          SPACE_SKIP(s, j)
          if(s[j] == '#'){
            j++;
            macro.type[2] = VALUE;
          }
          else{
            macro.type[2] = ADDRESS;
          }
          if(s[j] == '$'){
            j++;
            macro.val_a[2] = stringHexToInt(s, j);
          }
          else if(isNamber(s[j])){
            macro.val_a[2] = stringIntToInt(s, j);
          }
          else if(isChar(s[j])){
            macro.val_a[2] = j;
            macro.type[2] = LABEL;
            while(isChar(s[j]) && s[j])
              j++;
          }
          NUMBER_SKIP(s, j)
          SPACE_SKIP(s, j)
        }
      }
      macro.is_macros = true; //начнем обработку макроса 
      macro.str_position = k; //место, с которого будет идти компиляция
      macro.saved_str_position = j + 1; //адрес, с которого продолжится компиляция после компиляции макроса
      return j;
    }
  }
  return 0;
}
//получить номер переменной в макросе
uint16_t isMacrosValue(char s[], uint16_t str_adr){
  uint16_t j, k;
  if(!macro.is_macros)
    return 0;
  for(uint16_t i = 0; i < 3; i++){
    j = str_adr;
    k = macro.str_a[i];
    if(macro.str_a[i] != 0){
      while(s[k] == s[j] && (isChar(s[j]) || isNamber(s[j]))){
        j++;
        k++;
      }
      if(!(isChar(s[j]) || isNamber(s[j])))
        return i + 1;
    }
  }
  return 0;                                    
}

//получить значение указателя по имени
int32_t getLabelsValue(uint16_t str_adr, char *s){
  uint16_t i, j, k;
  //проверить массив указателей
  for(i = 0; i < label_index; i += 2){
    j = str_adr;
    k = label_array[i];
    //сравнивать значения в строке пока не будет достигнут символ конца указателя
    while(s[k] != ':' && s[k] != ' ' && s[k] != '=' && s[k] == s[j] && s[k] != ','){
      j++;
      k++;
    }
    if((s[k] == ':' || s[k] == ' ' || s[k] == '=' || s[k] != ',') && !(isChar(s[j]) || isNamber(s[j])))
      return label_array[i + 1];
  }
  return -1;
}

uint16_t asm6502(char *s, uint8_t *ram, char *error_s){
  enum a_mode addressing;
  enum v_bytes operand_type;
  int32_t b;
  uint16_t indexOut = 0, i, a;
  uint8_t opcode, op_n, islabel;
  uint16_t operand;
  int16_t n;
  char firstChar;
  macro.is_macros = false;
  i = 0;
  initLabelsMemory();
  clearLabels();
  error_s[0] = 0xff;
  while(s[i]){
    addressing = NONE;
    operand_type = BYTE;
    islabel = true;
    opcode = 0xff;
    operand = 0;
    while(s[i] == ' ' || s[i] == '\n')//убираем пробелы
      i++;
    if(s[i] == 0){
      freeLabelsMemory();
      return indexOut;
    }
    firstChar = toUpper(s[i]);
    if(!isChar(s[i + 3])){
      for(op_n = 0; op_n < 24; op_n++){
        if(firstChar == (char)pgm_read_byte(&mnemonic[op_n][0])){
          if(toUpper(s[i+1]) == (char)pgm_read_byte(&mnemonic[op_n][1]) && toUpper(s[i+2]) == (char)pgm_read_byte(&mnemonic[op_n][2]) && !(isChar(s[i + 3]) || isNamber(s[i + 3]))){
            islabel = false;
            if(firstChar == 'J')
              addressing = ABS;
            else
              addressing = ACC;
            break;
          }
        }
      }
      if(op_n >= 24){//если ничего не найдено в первом массиве
        for(op_n = 0; op_n < 8; op_n++){
          if(firstChar == (char)pgm_read_byte(&mnemonic_sngl[op_n][0])){
            if(toUpper(s[i+1]) == (char)pgm_read_byte(&mnemonic_sngl[op_n][1]) && toUpper(s[i+2]) == (char)pgm_read_byte(&mnemonic_sngl[op_n][2]) && !(isChar(s[i + 3]) || isNamber(s[i + 3]))){
              opcode = pgm_read_byte(&opcodes_sngl[op_n]);
              islabel = false;
              addressing = SNGL;
              break;
            }
          }
        }
        if(op_n >= 8){//если ничего не найдено во втором массиве
          for(op_n = 0; op_n < 25; op_n++){
            if(firstChar == (char)pgm_read_byte(&mnemonic_indy[op_n][0])){
              if(toUpper(s[i+1]) == (char)pgm_read_byte(&mnemonic_indy[op_n][1]) && toUpper(s[i+2]) == (char)pgm_read_byte(&mnemonic_indy[op_n][2]) && !(isChar(s[i + 3]) || isNamber(s[i + 3]))){
                opcode = pgm_read_byte(&opcodes_indy[op_n]);
                islabel = false;
                addressing = INDY;
                break;
              }
            }
          }
        }
      }
  }
  //проверяем не является ли массивом байт
  if(islabel && (firstChar == 'D' && toUpper(s[i+1]) == 'C' && toUpper(s[i+2]) == 'B')){
    i += 3;
    while(s[i] != '\n' && s[i] != 0 && s[i] != ';'){
      SPACE_SKIP(s, i)
      if(s[i] == '$'){
        i++;
        //преобразуем HEX
        n = stringHexToInt(s, i);
        NUMBER_SKIP(s, i);
      }
      //преобразуем десятичное число
      else if(s[i] >= '0' && s[i] <= '9'){
        n = stringIntToInt(s, i);
        NUMBER_SKIP(s, i);
      }
      //записываем строку
      else if(s[i] == '"'){
        i++;
        while(s[i] != '\n' && s[i] != 0 && s[i] != '"'){
          ram[indexOut++] = (uint8_t) s[i++];
        }
        if(s[i] == '"')
          i++;
      }
      ram[indexOut++] = n & 0xff;
      SPACE_SKIP(s, i)
      if(s[i] == ',')
        i++;
      else if(s[i] != '\n' && s[i] != 0 && s[i] != ';'){
        //ошибка в массиве байт
        error_s[0] = i >> 8;
        error_s[1] = i & 0xff;
        uint8_t j;
        for(j = 0; j < strlen_P(error_2); j++){
          error_s[j + 2] = ((char)pgm_read_byte(&error_2[j]));
        }
        error_s[j + 3] = ' ';
        error_s[j + 4] = s[i];
        error_s[j + 5] = 0;
        freeLabelsMemory();
        return indexOut;
      }
    }
  }
  //проверяем не является ли массивом байт, слов или строкой(аналог DCB но в стиле CA65)
  else if(s[i] == '.'){
    //is .text
    if(isDefinition(s, i, 0)){
      i += 5;
      SPACE_SKIP(s, i)
      if(s[i] == '"'){
        i++;
        while(s[i] != '\n' && s[i] != 0 && s[i] != '"'){
          ram[indexOut++] = (uint8_t) s[i++];
        }
        if(s[i] == '"')
          i++;
      }
      else{
        //ошибка в массиве байт
        error_s[0] = i >> 8;
        error_s[1] = i & 0xff;
        for(uint8_t j = 0; j < strlen_P(error_2); j++){
          error_s[j + 2] = ((char)pgm_read_byte(&error_2[j]));
          error_s[j + 3] = 0;
        }
        freeLabelsMemory();
        return indexOut;
      }
    }
    //is .byte || .word
    else if(isDefinition(s, i, 1) || isDefinition(s, i, 2)){
      uint8_t t = isDefinition(s, i, 2);
      i += 5;
      while(s[i] != '\n' && s[i] != 0 && s[i] != ';'){
        SPACE_SKIP(s, i)
        if(s[i] == '$'){
          i++;
          //преобразуем HEX
          n = stringHexToInt(s, i);
          NUMBER_SKIP(s, i);
        }
        //преобразуем десятичное число
        else if(s[i] >= '0' && s[i] <= '9'){
          n = stringIntToInt(s, i);
          NUMBER_SKIP(s, i);
        }
        if(t){
          ram[indexOut++] = n & 0xff;
          ram[indexOut++] = n >> 8;
        }
        else
          ram[indexOut++] = n & 0xff;
        SPACE_SKIP(s, i)
        if(s[i] == ',')
          i++;
      }
    }
    //is .macro
    else{
      uint8_t j = 0;
      i++;
      //пока совпадает увеличивать счетчик
      while(toUpper(s[i]) == (char)pgm_read_byte(&macros_definitions[j]) && j < 5){
        i++;
        j++;
      }
      //если счетчик совпал и в конце не буква или число то это макрос
      if(j >= 4 && !(isChar(s[i]) || isNamber(s[i]))){
        n = i;
        i = addMacros(s, i);
        if(i == 0){
          //ошибка, неправильное определение макроса
          error_s[0] = n >> 8;
          error_s[1] = n & 0xff;
          for(uint8_t j = 0; j < strlen_P(error_6); j++){
            error_s[j + 2] = ((char)pgm_read_byte(&error_6[j]));
            error_s[j + 3] = 0;
          }
          freeLabelsMemory();
          return indexOut;
        }
      }
      else{
        i -= j;
        j = 0;
        //пока совпадает увеличивать счетчик
        while(toUpper(s[i]) == (char)pgm_read_byte(&endmacros_definitions[j]) && j < 8){
          i++;
          j++;
        }
        //если счетчик совпал и в конце не буква или число то это завершение макроса
        if(j >= 7 && !(isChar(s[i]) || isNamber(s[i])) && macro.is_macros){
          i = macro.saved_str_position;
          macro.is_macros = false;
          label_index = macro.save_label;
        }
        else{
          //ошибка, тип определения не поддерживается
          error_s[0] = i >> 8;
          error_s[1] = i & 0xff;
          for(uint8_t j = 0; j < strlen_P(error_4); j++){
            error_s[j + 2] = ((char)pgm_read_byte(&error_4[j]));
            error_s[j + 3] = 0;
          }
          freeLabelsMemory();
          return indexOut;
        }
      }
    SPACE_SKIP(s, i)
    }
  }
  //если это макрос
  else if(getMacros(s, i)) {
    i = macro.str_position;
    macro.save_label = label_index;
  }
  //если это не мнемоника проверяем не указатель ли это
  else if(islabel && s[i] != ';'){
    a = i;
    //пропускаем все до конца строки или символа указателя
    while(s[i] != ':' && s[i] != '\n' && s[i] != 0 && s[i] != '=')
      i++;
    //если указатель то добавляем в массив указателей, иначе ошибка
    if(s[i] == ':'){
      b = addLabels(a, indexOut + PROGRAMM_OFFSET);
      if(b < 0){
        //переполнение массива ссылок
        error_s[0] = a >> 8;
        error_s[1] = a & 0xff;
        for(uint8_t j = 0; j < strlen_P(error_1); j++){
          error_s[j + 2] = ((char)pgm_read_byte(&error_1[j]));
          error_s[j + 3] = 0;
        }
        freeLabelsMemory();
        return indexOut;
      }
      uint8_t e = replaceLinksLabels(a, s, ram, indexOut + PROGRAMM_OFFSET);
      if(e == 1){
        error_s[0] = a >> 8;
        error_s[1] = a & 0xff;
        for (uint8_t j = 0; j < strlen_P(error_5); j++) {
          error_s[j + 2] = ((char)pgm_read_byte(&error_5[j]));
          error_s[j + 3] = 0;
        }
        freeLabelsMemory();
        return indexOut;
      }
      i++;
    }
    else if(s[i] == '='){
      i++;
      SPACE_SKIP(s, i)//убираем пробелы
      if(s[i] == '$'){
        i++;
        //преобразуем HEX
        operand = stringHexToInt(s, i);
        NUMBER_SKIP(s, i);
      }
      else if(s[i] >= '0' && s[i] <= '9'){
        operand = stringIntToInt(s, i);
        NUMBER_SKIP(s, i);
      }
      SPACE_SKIP(s, i)//убираем пробелы
      b = addLabels(a, operand);
      if(b < 0){
        //переполнение массива ссылок
        error_s[0] = a >> 8;
        error_s[1] = a & 0xff;
        for(uint8_t j = 0; j < strlen_P(error_1); j++){
          error_s[j + 2] = ((char)pgm_read_byte(&error_1[j]));
          error_s[j + 3] = 0;
        }
        return indexOut;
      }
      operand = 0;
    }
    else{
      error_s[0] = a >> 8;
      error_s[1] = a & 0xff;
      for(uint8_t j = 0; j < strlen_P(error_0); j++){
        error_s[j + 2] = ((char)pgm_read_byte(&error_0[j]));
        error_s[j + 3] = 0;
      }
      freeLabelsMemory();
      return indexOut;
    }
    islabel = true;
  }
  //пропускаем три символа мнемоники
  else if(s[i] != ';')
    i += 3;
  //если комментарий пропускаем все до конца строки
  if(s[i] == ';'){
    while(s[i] != '\n' && s[i] != 0){
      i++;
    }
  }
  SPACE_SKIP(s, i)//убираем пробелы
  if(s[i] == '('){
    if( op_n == 10 /*JMP*/)
      addressing = IND;
    else
      addressing = INDX;
    i++;
  }
  SPACE_SKIP(s, i)
  if(s[i] == '#'){
    if(addressing == ACC)
      addressing = IMM;
    i++;
  }
  if(s[i] == '>'){
    operand_type = HIBYTE;
    i++;
  }
  else if(s[i] == '<'){
    operand_type = LOBYTE;
    i++;
  }
  if(s[i] == '$'){
    if(addressing == ACC)
      addressing = ABS;
    i++;
    //преобразуем HEX
    operand = stringHexToInt(s, i);
    NUMBER_SKIP(s, i);
    if(operand_type == HIBYTE)
      operand = operand >> 8;
    else if(operand_type == LOBYTE)
      operand = operand & 0xff;
    if(addressing == ACC)
      addressing = ABS;
    if(addressing == ABS && operand < 255 && firstChar != 'J')
      addressing = ZP;
  }
  else if(s[i] >= '0' && s[i] <= '9'){
    operand = stringIntToInt(s, i);
    NUMBER_SKIP(s, i);
    if(operand_type == HIBYTE)
      operand = operand >> 8;
    else if(operand_type == LOBYTE)
      operand = operand & 0xff;
    if(addressing == ACC)
      addressing = ABS;
    if(addressing == ABS && operand < 255 && firstChar != 'J')
      addressing = ZP;
  }
  else if(isChar(s[i]) && !islabel){
    //если это переменная в макросе
    if(isMacrosValue(s, i)){
      b = isMacrosValue(s, i) - 1;
      operand = macro.val_a[b];
      if(macro.type[b] == LABEL){
        b = getLabelsValue(operand, s);
        if(b >= 0){
          operand = (int16_t)b;
        }
        else{
          b = addLinksLabels(operand, indexOut + 1);
          if(b < 0){
            //переполнение массива ссылок
            error_s[0] = i >> 8;
            error_s[1] = i & 0xff;
            for (uint8_t j = 0; j < strlen_P(error_1); j++) {
              error_s[j + 2] = ((char)pgm_read_byte(&error_1[j]));
              error_s[j + 3] = 0;
            }
            freeLabelsMemory();
            return indexOut;
          }
          operand = 0xffff;
        }
        if(addressing == ACC)
          addressing = ABS;
      }
      else if(macro.type[b] == ADDRESS){
        if(addressing == ACC)
          addressing = ABS;
        if(addressing == ABS && operand < 255 && firstChar != 'J')
          addressing = ZP;
      }
      else{
        if(addressing == ACC)
          addressing = IMM;
      }
    }
    else{
      b = getLabelsValue(i, s);
      if(b >= 0){
        operand = (int16_t)b;
      }
      else{
        b = addLinksLabels(i, indexOut + 1);
        if(b < 0){
          //переполнение массива ссылок
          error_s[0] = i >> 8;
          error_s[1] = i & 0xff;
          for (uint8_t j = 0; j < strlen_P(error_1); j++) {
            error_s[j + 2] = ((char)pgm_read_byte(&error_1[j]));
            error_s[j + 3] = 0;
          }
          freeLabelsMemory();
          return indexOut;
        }
        operand = 0xffff;
      }
    }
    while(isChar(s[i]) || isNamber(s[i]))
      i++;
    SPACE_SKIP(s, i)
    if(s[i] == '-'){
      i++;
      SPACE_SKIP(s, i)
      n = stringIntToInt(s, i);
      NUMBER_SKIP(s, i);
      if(b >= 0){
        operand -= n;
      }
    }
    else if(s[i] == '+'){
      i++;
      SPACE_SKIP(s, i)
      n = stringIntToInt(s, i);
      NUMBER_SKIP(s, i);
      if(b >= 0){
        operand += n;
      }
    }
    if(operand_type == HIBYTE)
      operand = operand >> 8;
    else if(operand_type == LOBYTE)
      operand = operand & 0xff;
    if(addressing == ACC)
      addressing = ABS;
    if(addressing == ABS && operand < 255 && firstChar != 'J')
      addressing = ZP;
    }
    SPACE_SKIP(s, i)//убираем пробелы
    if(s[i] == ')'){
      i++;
      SPACE_SKIP(s, i)//убираем пробелы
      if(s[i] == ',')
        i++;
      SPACE_SKIP(s, i)//убираем пробелы
      if(toUpper(s[i]) == 'Y'){
        if(addressing == INDX)
          addressing = INDY;
        i++;
      }
    }
    else if(s[i] == ','){
      i++;
      SPACE_SKIP(s, i)//убираем пробелы
      if(toUpper(s[i]) == 'X'){
        if(addressing == ABS)
          addressing = ABSX;
        else if(addressing == ZP)
          addressing = ZPX;
        i++;
      }
      else if(toUpper(s[i]) == 'Y'){
        if(addressing == ABS)
          addressing = ABSY;
        else if(addressing == ZP)
          addressing = ZPY;
        i++;
      }
      SPACE_SKIP(s, i)//убираем пробелы
      if(s[i] == ')')
        i++;
    }
    if(opcode != 0xff){
      ram[indexOut++] = opcode;
      if(addressing == SNGL){
        b = ((int32_t)operand) - (PROGRAMM_OFFSET + indexOut + 1);
        //если расстояние до адреса больше 127 добавить JMP
        if((b > 127 || b < -127) && operand != 0xffff){
          ram[indexOut - 1] = getReverseTransition(opcode);
          ram[indexOut++] = 3; //перепрыгнуть JMP
          ram[indexOut++] = 0x4c;
          ram[indexOut++] = operand;
          ram[indexOut++] = operand >> 8;
        }
        else
          ram[indexOut++] = (uint8_t) b;
      }
    }
    else{
      switch(addressing){
        case IMM:
          ram[indexOut++] = pgm_read_byte(&opcodes[op_n][0]);
          ram[indexOut++] = operand;
          break;
        case ZP:
        case ZPX:
        case ZPY:
        case INDX:
        case INDY:
          ram[indexOut++] = pgm_read_byte(&opcodes[op_n][addressing - 1]);
          ram[indexOut++] = operand;
          break;
        case ABS:
        case ABSX:
        case ABSY:
        case IND:
          ram[indexOut++] = pgm_read_byte(&opcodes[op_n][addressing - 1]);
          ram[indexOut++] = operand & 0xff;
          ram[indexOut++] = operand >> 8;
          break;
        case ACC:
          ram[indexOut++] = pgm_read_byte(&opcodes[op_n][10]);
      }
    }
    SPACE_SKIP(s, i)//убираем пробелы
    yield();
  }
  if(label_links_index > 0){
    //остались неопределенные ссылки
    error_s[0] = label_links_array[0] >> 8;
    error_s[1] = label_links_array[0] & 0xff;
    n = label_links_array[0];
    uint8_t j = 0;
    while((isChar(s[n]) || isNamber(s[n])) && j < 20){
      error_s[j + 2] = s[n];
      n++;
      j++;
    }
    error_s[2 + j++] = ' ';
    for(uint8_t z = 0; z < strlen_P(error_3); z++){
      error_s[z + 2 + j] = ((char)pgm_read_byte(&error_3[z]));
      error_s[z + 3 + j] = 0;
      if(z + 3 + j >= 31){
        freeLabelsMemory();
        return indexOut;
      }
    }
  }
  freeLabelsMemory();
  return indexOut;
}
