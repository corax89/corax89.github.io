#include "gui.h"

#ifdef ESPBOY
  keyboardModule keybModule(1,1,7000);
  #include "lib/ESPboy_keyboard.cpp"
  #include "ESPboyOTA.h"
  #include "ESPboyLogo.h"
  ESPboyOTA* OTAobj = NULL;
#endif

TFT_eSPI tft = TFT_eSPI();

uint8_t screen[64 * 128];
uint16_t pix_buffer[SCREEN_REAL_WIDTH];

uint16_t palette[] = {
    0x2966, 0xE718, 0xB9A8, 0x7DB6, 0x61EB, 0x6D2D, 0x21EC, 0xD5CA,
    0xAC4D, 0x42CB, 0xBB09, 0x3186, 0x73AE, 0x8D4B, 0x3DF9, 0xBDD7
};

extern uint8_t RAM[RAM_SIZE];
extern void opcodeDisasm(char s[], uint8_t op);
extern uint16_t getLastModifiedRam();
extern uint16_t SerialUI();
extern void exec6502(int32_t tickcount);
extern void setzeroram(uint16_t i, uint8_t v);
extern uint8_t getzeroram(uint16_t i);
extern uint16_t getpc();
extern uint8_t getop();
extern uint8_t getareg();
extern uint8_t getxreg();
extern uint8_t getyreg();
extern void getKey();
extern uint8_t thiskey();
extern char str_buffer_6502[32];
extern uint8_t str_buffer_6502_point;
extern uint8_t global_animation;
extern void geti2cAdress();

#ifdef ESPBOY
  extern Adafruit_MCP23017 mcp;
#endif

int16_t min(int16_t x, int16_t y){
  return x ^ ((y ^ x) & -(x > y));
}

int16_t max(int16_t x, int16_t y){
  return x ^ ((x ^ y) & -(x < y));
}

uint16_t reverseByte(uint16_t c){
  return (c << 8) + (c >> 8);
}

void initGui(){
 #ifdef ESPBOY
  if (keybModule.begin())
    Serial.println(F("\nESPboy keyboard module found"));
  tft.begin();
  delay(100);           
  tft.setRotation(0);
  tft.fillScreen(palette[0]);
  tft.drawXBitmap(30, 24, ESPboyLogo, 68, 64, 0xFFE0);
  pinMode(SOUNDPIN, OUTPUT);
  tone(SOUNDPIN, 200, 100);
  delay(100);
  tone(SOUNDPIN, 100, 100);
  delay(100);
  noTone(SOUNDPIN);
  getKey();
  //go to OTA
  if(thiskey() & 32 || thiskey() & 16){//key AB
    OTAobj = new ESPboyOTA(&tft, &mcp);
  }
 #else
  geti2cAdress();
  tft.init();            // initialize LCD
  tft.setRotation(1);
 #endif
  for(uint8_t i = 0; i < 16; i++)
    palette[i] = reverseByte(palette[i]);
  tft.fillScreen(palette[0]);
}

void ICACHE_RAM_ATTR pushPixels32(const void* data_in, uint32_t start){
 uint16_t *data = (uint16_t*) data_in;
  uint32_t color[16];
  memcpy(color, data + start, 64);
  while(SPI1CMD & SPIBUSY) {}
  digitalWrite(D8, 1);
  SPI1U1 = (255 << SPILMOSI) | (255 << SPILMISO);
  SPI1W0 = color[0];
  SPI1W1 = color[1];
  SPI1W2 = color[2];
  SPI1W3 = color[3];
  SPI1W4 = color[4];
  SPI1W5 = color[5];
  SPI1W6 = color[6];
  SPI1W7 = color[7];
  SPI1W8 = color[8];
  SPI1W9 = color[9];
  SPI1W10 = color[10];
  SPI1W11 = color[11];
  SPI1W12 = color[12];
  SPI1W13 = color[13];
  SPI1W14 = color[14];
  SPI1W15 = color[15];
  SPI1U1 = (((32 * 16) - 1) << SPILMOSI);
  SPI1CMD |= SPIBUSY;
}

void redrawScreen(int16_t size){
    int32_t x_ratio =  ((( int32_t ) size << 16) / SCREEN_REAL_WIDTH);
    int32_t y_ratio =  ((( int32_t ) size << 16) / SCREEN_REAL_HEIGHT);
    int16_t x2, hx2, y2, j;
    int16_t prevy2 = -1;
    tft.setAddrWindow(0, 0, SCREEN_REAL_WIDTH, SCREEN_REAL_HEIGHT);
    for(uint16_t y = 0; y < SCREEN_REAL_HEIGHT; y++) {
      y2 = ((y * y_ratio) >> 16);
      if(prevy2 != y2)
        for (uint16_t j = 0; j < SCREEN_REAL_WIDTH; j++) {
          x2 = ((j * x_ratio) >> 16);
          hx2 = x2 / 2;
          if(x2 & 1){
            pix_buffer[j] = palette[(screen[SCREEN_ADDR(hx2,y2)] & 0xf)];
          }
          else{
            pix_buffer[j] = palette[(screen[SCREEN_ADDR(hx2,y2)] & 0xf0) >> 4];
          }
      }
      prevy2 = y2;
      //tft.pushColors(pix_buffer, SCREEN_REAL_WIDTH);   
      for (uint16_t j = 0; j < SCREEN_REAL_WIDTH; j += 32){
        pushPixels32(pix_buffer, j); 
        exec6502(16);
      }
    }
}

void clearScr(uint8_t color){
  for(int y = 0; y < 128; y ++){
    for(int x = 0; x < 128; x++)
      setPix(x, y, color);
  }
}

void setPix(uint16_t x, uint16_t y, uint8_t c){
  uint16_t xi, b, n;
  if(x < 128 && y < 128){
    xi = x >> 1;
    b = screen[SCREEN_ADDR(xi, y)];
    if(x & 1)
      n = (b & 0xf0) + c;
    else
      n = (b & 0x0f) + ( c << 4);
    if(b != n){
      screen[SCREEN_ADDR(xi, y)] = n;
    }
  }
}

uint8_t getPix(uint8_t x, uint8_t y){
  uint16_t xi, b;
  if(x < 128 && y < 128){
    xi = x / 2;
    if(x % 2)
      b = (screen[SCREEN_ADDR(xi, y)] & 0x0f);
    else
      b = (screen[SCREEN_ADDR(xi, y)] & 0xf0) >> 4;
    return b;
  }
  return 0;
}

void drawPixelToRam(uint16_t address, uint8_t value){
  //пишется 64 байта через 64 байта
  uint16_t a = (address & 0xfc0) + ((address & 0x3f) >> 1);
  if(address & 0x1)
    screen[a] = (screen[a] & 0xf0) + (value & 0x0f);
  else
    screen[a] = (screen[a] & 0x0f) + ((value & 0x0f) << 4);
}

uint8_t loadPixelFromRam(uint16_t address){
  uint16_t a = (address & 0xfc0) + ((address & 0x3f) >> 1);
  if(address & 0x1)
    return (screen[a] & 0x0f);
  else
    return (screen[a] >> 4);
}

void drawHLine(int8_t x0, int8_t x1, int8_t y, uint8_t c){
  for(int16_t x = x0; x < x1; x++)
    setPix(x, y, c);
}

void drawVLine(int8_t x, int8_t y0, int8_t y1, uint8_t c){
  for(int16_t y = y0; y < y1; y++)
    setPix(x, y, c);
}

void rect(int8_t x, int8_t y, int8_t w, int8_t h, uint8_t c){
  drawHLine(x, x + w, y, c);
  drawHLine(x, x + w, y + h, c);
  drawVLine(x, y, y + h, c);
  drawVLine(x + w, y, y + h, c);
}

void fillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c){
   for(int16_t jx = x; jx < x + w; jx++)
     for(int16_t jy = y; jy < y + h; jy++)
      setPix(jx, jy, c);
}

void borderFillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c1, uint8_t c2){
  fillRect(x, y, w, h, c1);
  rect(x, y, w, h, c2);
}

void animateFillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c1, uint8_t c2){
  if(global_animation){
    borderFillRect(x, y + h - h / 6, w, h / 6, c1, c2);
    redrawScreen(128);
    delay(60);
    borderFillRect(x, y + h - h / 4, w, h / 4, c1, c2);
    redrawScreen(128);
    delay(60);
    borderFillRect(x, y + h - h / 3, w, h / 3, c1, c2);
    redrawScreen(128);
    delay(60);
    borderFillRect(x, y + h / 2, w, h / 2, c1, c2);
    redrawScreen(128);
    delay(60);
  }
}

void drawChar(char c, uint8_t x, uint8_t y, uint8_t color) {
    for(int8_t i = 0; i < 5; i++ ) { // Char bitmap = 5 columns
      uint8_t line = pgm_read_byte(&font_a[c * 5 + i]);
      for(int8_t j = 0; j < 8; j++, line >>= 1) {
        if(line & 1)
         setPix(x + i, y + j, color);
      }
  }
}

void drawTinychar(char c, uint8_t x, uint8_t y, uint8_t color) {
  if((y % 8) == 0)
    color = 12;
  if(((uint8_t) c) < 32 || ((uint8_t) c) > 255) 
    c = (char)127;
  uint8_t cval = ((uint8_t) c) - 32;
  if(cval >= 65 && cval <= 90) y++;
  if(cval == 12 || cval == 27) y++;
  const uint8_t *letter = tiny_font + ((cval/2) * 4);
  for(uint8_t i = 0; i < 4; i++ ) {
    uint8_t line = pgm_read_byte(letter++);
    if (c % 2 == 0) {
      line &= 0x0f;
    }
    else{
      line >>= 4;
    }
    for(int8_t j = 0; j < 4; j++, line >>= 1) {
        if(line & 1){
          setPix(x + i, y + j, color);
        }
      }
  }
}

void drawString(char *s, uint16_t x, uint16_t y, uint16_t color){
  int16_t i = 0;
  uint8_t c;
  c = s[i];
  while(c){
    drawChar(c, x, y, color);
    i++;
    c = s[i];
    x += 7;
  }
}

void drawString(PGM_P p, uint16_t x, uint16_t y, uint16_t color){
  int16_t i = 0;
  uint8_t c;
  c = pgm_read_byte(p + i);
  while(c){
    drawChar(c, x, y, color);
    i++;
    c = pgm_read_byte(p + i);
    x += 7;
  }
}

void drawString(const __FlashStringHelper *s, uint16_t x, uint16_t y, uint16_t color){
  PGM_P p = reinterpret_cast<PGM_P>(s);
  drawString(p, x, y, color);
}

void drawTinyString(const __FlashStringHelper *s, uint16_t x, uint16_t y, uint16_t color){
  PGM_P p = reinterpret_cast<PGM_P>(s);
  int16_t i = 0;
  uint8_t c;
  c = pgm_read_byte(p + i);
  while(c){
    drawTinychar(c, x, y, color);
    i++;
    c = pgm_read_byte(p + i);
    x += 5;
  }
}

uint16_t drawNumber(uint16_t n, uint16_t x, uint16_t y, uint16_t color){
  char s_buffer[10];
  int16_t i = 0;
  uint8_t c;
  itoa(n, s_buffer, 10);
  c = s_buffer[i];
  while(c){
      drawChar(c, x, y, color);
      i++;
      c = s_buffer[i];
      x += 7;
    }
  return i;
}

void drawHex(uint16_t n, uint16_t x, uint16_t y, uint16_t color){
  char s_buffer[10];
  int16_t i = 0;
  uint8_t c;
  itoa(n, s_buffer, 16);
  c = s_buffer[i];
  while(c){
      drawChar(c, x, y, color);
      i++;
      c = s_buffer[i];
      x += 7;
    }
}

int16_t pixelEditor(char e_screen[], uint8_t size){
  uint8_t e_color = 1;
  uint8_t e_width = 8;
  uint8_t e_height = 8;
  uint8_t e_cursor_x = 0;
  uint8_t e_cursor_y = 0;
  uint8_t e_pixel_size = 4;
  animateFillRect(28, 32, 64, 64, 0, 10);
  if(size != 0){
    uint16_t n = 1;
    uint16_t n_h = 1;
    uint16_t n_n = 1;
    //fast square
    while(n < size){
      n_h++;
      n_n += 2;
      n += n_n;
    }
    e_width = n_h;
    e_width += e_width & 1;
    e_height = size / n_h;
  }
  while(1){
    borderFillRect(28, 32, 64, 64, 0, 10);
    e_pixel_size = 64 / max(e_width, e_height);
    for(int16_t y = 0; y < e_height; y++){
      for(int16_t x = 0; x < e_width; x++){
        if(x & 0x1)
          fillRect(x * e_pixel_size + 29, y * e_pixel_size + 32, e_pixel_size, e_pixel_size, e_screen[((x + y * e_width) / 2)] & 0xf);
        else
          fillRect(x * e_pixel_size + 29, y * e_pixel_size + 32, e_pixel_size, e_pixel_size, e_screen[((x + y * e_width) / 2)] >> 4);
      }
    }
    for(int i = 0; i < 16; i++){
      fillRect(93, 32 + i * 4, 7, 4, i);
    }
    rect(92, 32, 8, 64, 10);
    borderFillRect(28, 22, 72, 10, 0, 10);
    drawString(F("w    h"), 32, 24, 1);
    drawNumber(e_width, 44, 24, 2);
    drawNumber(e_height, 74, 24, 2);
    borderFillRect(28, 96, 72, 10, 0, 10);
    drawString(F("ok  cancel"), 32, 98, 1);
    borderFillRect(92, 22, 8, 10, e_color, 10);
    if(e_cursor_y == 0){
      rect(e_cursor_x * 30 + 42, 23, 14, 8, 3);
    }
    else if(e_cursor_y <= e_height || e_cursor_x == e_width){
      if(e_cursor_x == e_width)
        rect(92, 28 + e_cursor_y * 4, 8, 4, 3);
      else
        rect(e_cursor_x * e_pixel_size + 28, (e_cursor_y - 1) * e_pixel_size + 32, e_pixel_size + 1, e_pixel_size + 1, 3);
    }
    else{
      rect(e_cursor_x * 30 + 31, 97, 30 + e_cursor_x * 6, 8, 3);
    }
    redrawScreen(128);
    getKey();
    if(thiskey() & KEY_DOWN){
      if(e_cursor_x == e_width){
        if(e_cursor_y < 16){
          e_cursor_y++;
        }
      }
      else{
        if(e_cursor_y <= e_height){
          e_cursor_y++;
        }
      }
    }
    if(thiskey() & KEY_UP){
      if(e_cursor_y > 0){
        if(!(e_cursor_x == e_width && e_cursor_y == 1))
          e_cursor_y--;
      }
    }
    if(thiskey() & KEY_RIGHT){
      if(e_cursor_x < e_width){
        if(!(e_cursor_y == 0 && e_cursor_x == 1))
          e_cursor_x++;
      }
    }
    if(thiskey() & KEY_LEFT){
      if(e_cursor_x > 0){
        e_cursor_x--;
      }
    }
    if(e_cursor_x > 1 && e_cursor_x != e_width && (e_cursor_y < 1 || e_cursor_y >= e_height + 1))
      e_cursor_x = 1;
    if(thiskey() & KEY_A){
      if(e_cursor_x == e_width){
        e_color = e_cursor_y - 1;
      }
      else if(e_cursor_y > 0 && e_cursor_y <= e_height){
        int16_t pos = e_cursor_x + (e_cursor_y - 1) * e_width;
        int16_t v = e_screen[pos / 2];
        if(pos & 0x1){
          v = v & 0xf0;
          e_screen[pos / 2] = v + e_color;
        }
        else{
          v = v & 0x0f;
          e_screen[pos / 2] = v + (e_color << 4);
        }
      }
      else if(e_cursor_y == 0){
        while(thiskey() & KEY_A){
          delay(100);
          getKey();
        }
        if(e_cursor_x == 0){
          while(!(thiskey() & KEY_A)){
            borderFillRect(37, 22, 26, 10, 0, 3);
            drawChar('<', 39, 24, 1);
            drawNumber(e_width, 46, 24, 2);
            drawChar('>', 57, 24, 1);
            getKey();
            if((thiskey() & KEY_LEFT) && e_width > 3){
              e_width -= 2;
            }
            if((thiskey() & KEY_RIGHT) && e_width < 15){
              e_width += 2;
            }
            redrawScreen(128);
            delay(200);
          }
        }
        else if(e_cursor_x == 1){
          while(!(thiskey() & KEY_A)){
            borderFillRect(67, 22, 26, 10, 0, 3);
            drawChar('<', 69, 24, 1);
            drawNumber(e_height, 76, 24, 2);
            drawChar('>', 87, 24, 1);
            getKey();
            if((thiskey() & KEY_LEFT) && e_height > 1){
              e_height--;
            }
            if((thiskey() & KEY_RIGHT) && e_height < 16){
              e_height++;
            }
            redrawScreen(128);
            delay(200);
          }
        }
      }
      else if(e_cursor_y == e_height + 1){
        while(thiskey() & KEY_A){
          delay(100);
          getKey();
        }
        if(e_cursor_x == 1)
          return 0;
        else if(e_cursor_x == 0)
          return e_height * e_width / 2;
      }
    }
    delay(200);
  }
}

/*
ADC,AND,ASL,
BCC,BCS,BEQ,BIT,BMI,BNE,BPL,BRK,BVC,BVS,
CLC,CLD,CLI,CLV,CMP,CPX,CPY,
DEC,DEX,DEY,
EOR,
INC,INX,INY,
JMP,JSR,
LDA,LDX,LDY,LSR,
NOP,
ORA,
PHA,PHP,PLA,PLP,
ROL,ROR,RTI,RTS,
SBC,SEC,SED,SEI,STA,STX,STY,
TAX,TAY,TSX,TXA,TXS,TYA
*/

const char v_keys[]          PROGMEM = "0123456789#$qwertyuiop( asdfghjkl;) zxcvbnm\"/-  ";
const char v_keysShift[]     PROGMEM = "!@%=&*.,[]{}QWERTYUIOP|?ASDFGHJKL:+ ZXCVBNM<>_  ";
const char v_mnemonic_keys[] PROGMEM = "ABCDIJLPRST\046";
const char mnemonic_A[]  PROGMEM = {"ADCANDASL"};
const char mnemonic_B[]  PROGMEM = {"BCCBCSBEQBITBMIBNEBPLBRKBVCBVS"};
const char mnemonic_C[]  PROGMEM = {"CLCCLDCLICLVCMPCPXCPY"};
const char mnemonic_D[]  PROGMEM = {"DECDEXDEY"};
const char mnemonic_I[]  PROGMEM = {"INCINXINY"};
const char mnemonic_J[]  PROGMEM = {"JMPJSR"};
const char mnemonic_L[]  PROGMEM = {"LDALDXLDYLSR"};
const char mnemonic_P[]  PROGMEM = {"PHAPHPPLAPLP"};
const char mnemonic_R[]  PROGMEM = {"ROLRORRTIRTS"};
const char mnemonic_S[]  PROGMEM = {"SBCSECSEDSEISTASTXSTY"};
const char mnemonic_T[]  PROGMEM = {"TAXTAYTSXTXATXSTYA"};
const char mnemonic_Z[]  PROGMEM = {"EORNOPORADCB"};
const char* mnemonic_table[12] PROGMEM = {
  mnemonic_A, mnemonic_B, mnemonic_C, mnemonic_D, mnemonic_I, mnemonic_J, mnemonic_L, mnemonic_P, mnemonic_R, mnemonic_S, mnemonic_T, mnemonic_Z
};
const uint8_t mnemonic_table_length[] PROGMEM = {3, 10, 7, 3, 3, 2, 4, 4, 4, 7, 6, 4};

uint16_t drawMnemonicKeyboard(int16_t offset_x, int16_t offset_y, char str[], char position){
  int8_t cursor_x = 0;
  int8_t cursor_y = 0;
  int8_t selected_x = 0;
  int8_t selected_length;
  int8_t draw_x;
  int8_t draw_y;
  while(1){
    borderFillRect(offset_x, offset_y, 98, 34, 0, 10);
    fillRect(offset_x + selected_x * 8 + 1,offset_y + 1, 8, 9, 10);
    if(cursor_y > 0)
      fillRect(offset_x + cursor_x * 24 + 1,offset_y + cursor_y * 8 + 1, 22, 9, 10);
    for(uint8_t x = 0; x < 12; x++)
      drawChar(pgm_read_byte(v_mnemonic_keys + x), offset_x + x * 8 + 2, offset_y + 2, 1);
    draw_x = 2;
    draw_y = 10;
    selected_length = pgm_read_byte(&mnemonic_table_length[selected_x]);
    for(uint8_t i = 0; i < selected_length * 3; i++){
      drawChar(pgm_read_byte(&(mnemonic_table[selected_x][i])), offset_x + draw_x, offset_y + draw_y, 1);
      draw_x += 7;
      if( i % 3 == 2)
        draw_x += 3;
      if(draw_x > 90){
        draw_x = 2;
        draw_y += 8;
      }
    }
    redrawScreen(128);
    delay(200);
    getKey();
    if(thiskey() & KEY_DOWN){
      if(cursor_y == 0)
        cursor_x = 0;
      cursor_y++;
      if((cursor_y - 1) * 4 >= selected_length)
        cursor_y--;
      if((cursor_y - 1) * 4 + cursor_x >= selected_length)
          cursor_x = selected_length % 4 - 1;
    }
    else if(thiskey() & KEY_UP){
      if(cursor_y > 0){
        cursor_y--;
        if(cursor_y == 0)
          cursor_x = selected_x;
      }
    }
    else if(thiskey() & KEY_RIGHT){
      if(cursor_y == 0){
        (cursor_x < 11) ? cursor_x++ : cursor_x = 0;
        selected_x = cursor_x;
      }
      else{
        if(cursor_x < 3)
          cursor_x++;
        if((cursor_y - 1) * 4 + cursor_x >= selected_length)
          cursor_x--;
      }
    }
    else if(thiskey() & KEY_LEFT){
      if(cursor_y == 0){
        (cursor_x > 0) ? cursor_x-- : cursor_x = 11;
        selected_x = cursor_x;
      }
      else if(cursor_x > 0)
        cursor_x--;
    }
    else if(thiskey() & KEY_A){
      if(cursor_y != 0){
        int8_t mnm_position = ((cursor_y - 1) * 4 + cursor_x) * 3;
        for(uint16_t i = SOURCE_SIZE - 1; i > position + 3; i--)
          str[i] = str[i - 4];
        str[position] = pgm_read_byte(&(mnemonic_table[selected_x][mnm_position]));
        str[position + 1] = pgm_read_byte(&(mnemonic_table[selected_x][mnm_position + 1]));
        str[position + 2] = pgm_read_byte(&(mnemonic_table[selected_x][mnm_position + 2]));
        str[position + 3] = ' ';
      }
      return position + 4;
    }
    else if(thiskey() & KEY_B){
      return position;
    }
  }
}

uint16_t drawKeyboard(int16_t offset_x, int16_t offset_y, char str[], char position, uint8_t is_editor){
  uint16_t start_position = position;
  int8_t pos_c, isShift = 0;
  int8_t cursor_x = 11;
  int8_t cursor_y = 3;
  uint16_t length;
  if(is_editor)
    length = SOURCE_SIZE;
  else
    length = 12;
  animateFillRect(offset_x, offset_y, 98, 34, 0, 10);
  while(1){
    if(is_editor){
      if(position < start_position){
        start_position = position;
      }
      drawEditor(str, start_position, position);
    }
    else{
      borderFillRect(offset_x, offset_y - 10, 98, 10, 0, 10);
      drawString(str, offset_x + 1, offset_y - 8, 1);
    }
    borderFillRect(offset_x, offset_y, 98, 34, 0, 10);
    fillRect(offset_x + cursor_x * 8 + 1,offset_y + cursor_y * 8 + 1, 8, 9, 10);
    for(uint8_t y = 0; y < 4; y++){
      for(uint8_t x = 0; x < 12; x++){
        pos_c = y * 12 + x;
        if(pos_c == 23)
          drawChar(27, offset_x + x * 8 + 2, offset_y + y * 8 + 2, 1);
        else if(pos_c == 35)
          drawChar(28, offset_x + x * 8 + 2, offset_y + y * 8 + 2, 1);
        else if(pos_c == 47)
          drawChar(186, offset_x + x * 8 + 2, offset_y + y * 8 + 2, 1);
        else{
          if(!isShift)
            drawChar(pgm_read_byte(&v_keys[pos_c]), offset_x + x * 8 + 2, offset_y + y * 8 + 2, 1);
          else
            drawChar(pgm_read_byte(&v_keysShift[pos_c]), offset_x + x * 8 + 2, offset_y + y * 8 + 2, 1);
        }
      }
    }
    pos_c = cursor_y * 12 + cursor_x;
    redrawScreen(128);
    delay(200);
    getKey();
    if(thiskey() & KEY_DOWN){
      (cursor_y < 3) ? cursor_y++ : cursor_y = 0;
    }
    else if(thiskey() & KEY_UP){
      (cursor_y > 0) ? cursor_y-- : cursor_y = 3;
    }
    else if(thiskey() & KEY_RIGHT){
      (cursor_x < 11) ? cursor_x++ : cursor_x = 0;
    }
    else if(thiskey() & KEY_LEFT){
      (cursor_x > 0) ? cursor_x-- : cursor_x = 11;
    }
    else if(thiskey() & KEY_A){
      if(pos_c == 23){//delete
        for(uint16_t i = (position == 0) ? position : position - 1; i < length - 1; i++)
          str[i] = str[i + 1];
        if(position > 0)
          position--;
      }
      else if(pos_c == 47){//exit
        while(thiskey() & 16){
          delay(10);
          getKey();
        }
        delay(10);
        return position;
      }
      else{
        for(uint16_t i = length - 1; i > position; i--)
          str[i] = str[i - 1];
        if(isShift)
          str[position] = pgm_read_byte(&v_keysShift[pos_c]);
        else
          str[position] = pgm_read_byte(&v_keys[pos_c]);
        if(pos_c == 35) //Enter
          str[position] = '\n';
        if(position < length - 1)
          position++;
      }
    }
    else if(thiskey() & 32){//shift
      char onlyShift = 1;
      while(thiskey() & 32){
        delay(10);
        getKey();
        if(thiskey() & KEY_LEFT){
          onlyShift = 0;
          if(position > 0)
            position--;
          if(is_editor)
            drawEditor(str, start_position, position);
          redrawScreen(128);
          delay(100);
        }
        else if(thiskey() & KEY_RIGHT){
          onlyShift = 0;
          if(str[position] != 0)
            position++;
          if(is_editor)
            drawEditor(str, start_position, position);
          redrawScreen(128);
          delay(100);
        }
      }
      if(onlyShift){
        if(isShift && is_editor){
          position = drawMnemonicKeyboard(offset_x, offset_y, str, position);
          isShift = 0;
        }
        else
          isShift = 1 - isShift;
      }
    }
    else if(thiskey() & 64){//select
      if(position > 0)
        position--;
    }
    else if(thiskey() & 128){//start
      if(str[position] != 0)
        position++;
    }
  }
}

void drawEditor(char str_list[], uint16_t pos, int16_t cursor){
  uint16_t x = 0;
  uint16_t y = 0;
  uint8_t color = 1;
  clearScr(0);
  fillRect(0, 0, 98, 8, 8);
  if(pos + 12 < cursor)
    pos = cursor - 12;
  while(y < 30){
    while(str_list[pos] != '\n' && pos < SOURCE_SIZE){
      if(pos == cursor && x < 14){
        drawVLine(x * 7, y * 10 - 1, y * 10 + 8, 14);
        drawVLine(x * 7 - 1, y * 10 - 1, y * 10 + 8, 14);
      }
      if(str_list[pos] == '#')
        color = 2;
      else if(str_list[pos] >= '0' && str_list[pos] <= '9' || str_list[pos] == '$')
        color = 3;
      else if(str_list[pos] == ';')
        color = 5;
      if(x < 14){
        if(y < 12)
          drawChar(str_list[pos], x * 7 + 1, y * 10, color);
        drawTinychar(str_list[pos], x * 5 + 98, y * 4, color);
      }
      x++;
      pos++;
    }
    if(pos == cursor && x < 14){
      drawVLine(x * 7, y * 10 - 1, y * 10 + 8, 14);
      drawVLine(x * 7 - 1, y * 10 - 1, y * 10 + 8, 14);
    }
    pos++;
    color = 1;
    x = 0;
    y++;
    if(str_list[pos] == 0){
      return;
    }
  }
}

int16_t drawMenu(const __FlashStringHelper *s){
  PGM_P list = reinterpret_cast<PGM_P>(s);
  uint16_t list_count = 0;
  uint16_t width = 0;
  uint16_t max_width = 0;
  uint16_t i = 0, x = 0, y = 0;
  uint16_t cursor;
  uint16_t offset_x;
  uint16_t offset_y;
  uint16_t menu_position = 0;
  unsigned char c;
  c = pgm_read_byte(list + i);
  while(c){
    if(c == '|'){
      list_count++;
      width = 0;
    }
    i++;
    c = pgm_read_byte(list + i);
    width++;
    if(width > max_width)
      max_width = width;
  }
  list_count++;
  offset_x = (128 - max_width * 8) / 2 - 2;
  offset_y = 128 - (list_count * 10 + 8);
  animateFillRect(offset_x, offset_y, max_width * 8 + 3, list_count * 10 + 3, 0, 2);
  while(1){
    borderFillRect(offset_x, offset_y, max_width * 8 + 3, list_count * 10 + 3, 0, 2);
    fillRect(offset_x + 2, offset_y + 2 + menu_position * 10, max_width * 8, 10, 2);
    i = 0;
    y = 0;
    x = 0;
    c = pgm_read_byte(list + i);
    while(c){
      if(c == '|'){
        y++;
        x = 0;
      }
      else{
        drawChar(c, offset_x + 3 + x * 8, offset_y + 4 + y * 10, 1);
        x++;
      }
      i++;
      c = pgm_read_byte(list + i);
    }
    redrawScreen(128);
    SerialUI();
    delay(200);
    getKey();
    if((thiskey() & 2) && menu_position < list_count){//down
      menu_position++;
    }
    else if((thiskey() & 1) && menu_position > 0){//up
      menu_position--;
    }
    else if(thiskey() & 16){//ok
      while(thiskey() & 16){
        delay(10);
        getKey();
      }
      delay(10);
      return menu_position;
    }
    else if(thiskey() & 32){//exit
      while(thiskey() & 32){
        delay(10);
        getKey();
      }
      delay(10);
      return -1;
    }
  }
}

void drawMemory(uint16_t m_ram){
  uint8_t c = 1, i, x = 0;
  uint16_t n = m_ram & 0xffc0;
  fillRect(0, 74, 128, 54, 0);
  for(i = 0; i < 40; i++){
    if(x == 0){
       drawHex(n + i, 2, 75 + (i / 8) * 9, 1);
       drawChar(':', 28, 75 + (i / 8) * 9, 1);
    }
    if(n + i == m_ram)
      c = 2;
    if(n + i < 512){
      drawHex(getzeroram(n + i), 32 + x * 12, 75 + (i / 8) * 9, c);
    }
    else if(n + i < PROGRAMM_OFFSET){
      drawHex(loadPixelFromRam(n + i - 512), 32 + x * 12, 75 + (i / 8) * 9, c);
    }
    else if(n + i < PROGRAMM_OFFSET + RAM_SIZE){
      drawHex(RAM[n + i - PROGRAMM_OFFSET], 32 + x * 12, 75 + (i / 8) * 9, c);
    }
    c = 1;
    x++;
    if(x >= 8){
      x = 0;
    }
  }
}

int16_t drawDebug(){
  uint8_t debug = 2;
  char s[4];
  for(uint16_t i = 0; i <= 16; i++){
    redrawScreen(64 + i * 4);
    yield();
  }
  getKey();
  while(debug){
    getKey();
    if(debug == 2)
      exec6502(10000);
    else if (debug == 1){
      while(!thiskey()){
        delay(100);
        getKey();
      }
      delay(200);
      exec6502(1);
    }
    if(thiskey() & 8){//left
      debug = 2;
    }
    else if(thiskey() & 4){//right
      debug = 1;
    }
    else if(thiskey() & 1){//up
      uint8_t m = drawMenu(F("close|keyboard|editor|cancel"));
      if(m == 0){
        debug = 0;
      }
      else if(m == 1){
        drawKeyboard(15, 92, str_buffer_6502, 0, 0);
      }
      else if(m == 2){
        animateFillRect(0, 0, 128, 128, 0, 2);
        return 2;
      }
    }
    fillRect(64, 0, 64, 64, 0);
    drawChar('A', 68, 2, 1);
    drawNumber(getareg(), 78, 2, 1);
    drawChar('X', 68, 12, 1);
    drawNumber(getxreg(), 78, 12, 1);
    drawChar('Y', 68, 22, 1);
    drawNumber(getyreg(), 78, 22, 1);
    drawString(F("PC"), 68, 32, 1);
    drawNumber(getpc(), 88, 32, 1);
    opcodeDisasm(s, getop());
    drawString(s, 68, 42, 1);
    drawMemory(getLastModifiedRam());
    drawString(F("\033step \032run \030menu"), 2, 121, 3);
    redrawScreen(128);
    yield();
    if(Serial.available()){
      if(Serial.read() == 'r')
        ESP.reset();
    }
  }
  for(uint16_t i = 0; i <= 16; i++){
    redrawScreen(128 - i * 4);
    yield();
  }
  return 1;
}

void drawBackground(){
  for(int16_t y = 0; y < 128; y += 5)
    for(int16_t x = 0; x < 128; x += 5){
      if(random(0, 16) > 7)
        drawChar('/', x, y, 5);
      else
        drawChar('\\', x, y, 5);
    }
}

uint16_t drawDialog(const __FlashStringHelper *s, const __FlashStringHelper *one, const __FlashStringHelper *two){
  PGM_P ps = reinterpret_cast<PGM_P>(s);
  uint16_t x = 4;
  uint16_t y = 70;
  uint16_t i = 0;
  uint8_t c = pgm_read_byte(ps + i);
  animateFillRect(2, 64, 124, 47, 0, 15);
  borderFillRect(2, 64, 124, 47, 0, 15);
  while(c){
    if(c == '\n'){
      y += 9;
      x = 4;
    }
    else{
      drawChar(c, x, y, 1);
      x += 7;
    }
    i++;
    c = pgm_read_byte(ps + i);
    if(x > 127){
      y += 9;
      x = 4;
    }
  }
  drawString(one, 6, 100, 1);
  drawString(two, 70, 100, 1);
  redrawScreen(128);
  delay(1000);
  getKey();
  x = 0;
  while(thiskey() != KEY_A){
    if(x == 0){
      rect(4, 98, 56, 11, 3);
      rect(68, 98, 56, 11, 0);
    }
    else{
      rect(4, 98, 56, 11, 0);
      rect(68, 98, 56, 11, 3);
    }
    redrawScreen(128);
    delay(100);
    getKey();
    if(thiskey() & KEY_LEFT)
      x = 0;
    else if(thiskey() & KEY_RIGHT)
      x = 1;
  }
  while(thiskey() & KEY_A){
    delay(50);
    getKey();
  }
  return x;
}

void drawInfo(const __FlashStringHelper *s, int16_t n0, int16_t n1){
  PGM_P p = reinterpret_cast<PGM_P>(s);
  int16_t i = 0;
  uint8_t c;
  uint16_t x = 4;
  uint16_t y = 70;
  c = pgm_read_byte(p + i);
  animateFillRect(2, 64, 124, 60, 0, 15);
  borderFillRect(2, 64, 124, 60, 0, 15);
  while(c){
    if(c == '\n'){
      y += 9;
      x = 4;
    }
    else if(c == '%'){
      i++;
      c = pgm_read_byte(p + i);
      if(c == '0')
        x += 7 * drawNumber(n0, x, y, 1);
      else if(c == '1')
        x += 7 * drawNumber(n1, x, y, 1);
    }
    else{
      drawChar(c, x, y, 1);
      x += 7;
    }
    i++;
    c = pgm_read_byte(p + i);
    if(x > 127){
      y += 9;
      x = 4;
    }
  }
  redrawScreen(128);
  delay(1000);
  getKey();
  while(!thiskey()){
    delay(100);
    getKey();
  }
  while(thiskey() > 8){
    delay(50);
    getKey();
  }
}

void drawSettings(){
  uint8_t animation = global_animation;
  while(!(thiskey() & KEY_B)){
    clearScr(0);
    drawString(F("animation"), 4, 4, 1);
    if(animation)
      drawString(F("on"), 84, 4, 5);
    else
      drawString(F("off"), 84, 4, 2);
    redrawScreen(128);
    delay(200);
    getKey();
    if(thiskey() & KEY_LEFT)
      animation = 0;
    if(thiskey() & KEY_RIGHT)
      animation = 1;
  }
  global_animation = animation;
}
