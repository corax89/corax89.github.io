#include <Arduino.h>
#include <Wire.h>
#include "settings.h"

#ifdef ESPBOY
  #include <Adafruit_MCP23017.h>
  
  Adafruit_MCP23017 mcp;
#endif


uint8_t i2c_adress;
uint8_t thiskey_v;

void geti2cAdress(){
  uint8_t error,address;
  i2c_adress=0;
  for(address = 1; address < 127; address++ ){
    Wire.beginTransmission(address);
    error = Wire.endTransmission();
    if (error == 0){
      i2c_adress=address;
      return;
    }
  }
}

void scani2c(){
  uint8_t error, address;
  int nDevices;
  nDevices = 0;
  for(address = 1; address < 127; address++ ){
    Wire.beginTransmission(address);
    error = Wire.endTransmission();
    if (error == 0){
      Serial.print(F("I2C device found at address 0x"));
      if (address<16)
        Serial.print(F("0"));
      Serial.print(address,HEX);
      Serial.println(F("  !"));
      nDevices++;
    }
    else if (error==4){
      Serial.print(F("Unknown error at address 0x"));
      if (address<16)
        Serial.print(F("0"));
      Serial.println(address,HEX);
    }    
  }
  if (nDevices == 0)
    Serial.println(F("No I2C devices found\n"));
  #ifdef ESPBOY
    mcp.begin(MCP23017address);
    delay (100);
    for(int i = 0; i < 8; i++){
       mcp.pinMode(i, INPUT);
       mcp.pullUp(i, HIGH);
    }
    mcp.pinMode(csTFTMCP23017pin, OUTPUT);
    mcp.digitalWrite(csTFTMCP23017pin, LOW);
  #endif
}

#ifdef ESPBOY
void getKey(){
  uint8_t keyread;
  thiskey_v = 0;
  keyread = mcp.readGPIOAB()&255;
  if(!(keyread&1)) thiskey_v |= 4; 
  if(!(keyread&2)) thiskey_v |= 1;
  if(!(keyread&4)) thiskey_v |= 2;
  if(!(keyread&8)) thiskey_v |= 8;
  if(!(keyread&16)) thiskey_v |= 16;
  if(!(keyread&32)) thiskey_v |= 32;
  if(!(keyread&64)) thiskey_v |= 64;
  if(!(keyread&128)) thiskey_v |= 128;
}
#else
void getKey(){
  uint8_t dio_in;
  Wire.beginTransmission(i2c_adress);
  Wire.write(B11111111); //Конфигурация всех портов PCF8574P на клавиатуре как входа
  Wire.endTransmission();
  Wire.requestFrom(i2c_adress,1);
  dio_in = Wire.read();  //читаем состояние портов PCF8574P(кнопок)
  thiskey_v = 0;
  if((dio_in & 128) == 0)
    thiskey_v |= 4;
  if((dio_in & 64) == 0)
    thiskey_v |= 8;
  if((dio_in & 32) == 0)
    thiskey_v |= 2;
  if((dio_in & 16) == 0)
    thiskey_v |= 1; //up
  if((dio_in & 8) == 0)
    thiskey_v |= 128;
  if((dio_in & 4) == 0)
    thiskey_v |= 32;
  if((dio_in & 2) == 0)
    thiskey_v |= 16; 
  if((dio_in & 1) == 0)
    thiskey_v |= 64; 
}
#endif

uint8_t thiskey(){
  return thiskey_v;
}
