#include <Arduino.h>
#include "settings.h"

const char help_words[] PROGMEM =
  "ADCANDASLBCCBCSBEQBITBMIBNEBPLBRKBVCBVSCLCCLDCLICLVCMPCPXCPYDECDEXDEYEORINCINXINYJMPJSRLDALDXLDYLSRNOPORAPHAPHPPLAPLPROLRORRTIRTSSBCSECSEDSEISTASTXSTYTAXTAYTSXTXATXSTYA";  

char *h_screen;

extern void getKey();
extern uint8_t thiskey();
extern void redrawScreen(int16_t size);
extern void fillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c);
void borderFillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c1, uint8_t c2);
extern void drawChar(char c, uint8_t x, uint8_t y, uint8_t color);
extern void drawString(const __FlashStringHelper *s, uint16_t x, uint16_t y, uint16_t color);
extern void drawNumber(uint16_t n, uint16_t x, uint16_t y, uint16_t color);
extern uint8_t global_animation;

uint16_t unpackingLZ(const unsigned char * p, uint16_t to_adr, uint16_t a, uint16_t num_bytes) {
  uint16_t  i = a;
  uint16_t  j;
  uint16_t  length;
  uint16_t  position;
  uint16_t  point;
  uint8_t   pgm;
  while (a - i < num_bytes) {
    pgm = pgm_read_byte(p + a);
    if ((pgm & 128) == 0) {
      pgm = pgm_read_byte(p + a);
      length = (pgm & 127) << 8;
      a++;
      pgm = pgm_read_byte(p + a);
      length += pgm;
      a++;
      for (j = 0; j < length; j++) {
        pgm = pgm_read_byte(p + a);
        h_screen[to_adr] = pgm;
        to_adr++;
        a++;
        if(a - i >= num_bytes)
          return to_adr;
      }
    }
    else {
      length = (pgm & 127) >> 1;
      position = (pgm & 1) << 8;
      a++;
      pgm = pgm_read_byte(p + a);
      position += pgm;
      a++;
      point = to_adr - position;
      for (j = 0; j < length; j++) {
        h_screen[to_adr++] = h_screen[point + j];
      }
    }
  }
  return to_adr;
}

uint16_t replaceWords(uint16_t size){
  uint16_t position = 511;
  uint8_t c;
  for(int16_t i = size - 1; i >= 0; i--){
    c = h_screen[i];
    if(c < 128 || c >= 192){
      h_screen[position] = c;
      position--;
    }
    else{
      int16_t n = (c - 128) * 3 + 2;
      h_screen[position--] = (uint8_t)pgm_read_byte(help_words + n);
      n--;
      h_screen[position--] = (uint8_t)pgm_read_byte(help_words + n);
      n--;
      h_screen[position--] = (uint8_t)pgm_read_byte(help_words + n);
      n--;
    }
  }
  return position + 1;
}

void drawHelpScreen(uint16_t position, uint16_t sx){
  uint16_t y;
  uint16_t x = sx;
  uint8_t color = 1;
  for(y = 0; y < 118; y += 7)
    drawChar('#', sx - 7, y - 1, 12);
  y = 6;
  borderFillRect(sx - 3, 0, 130, 118, 0, 1);
  while(position < 512){
      if(h_screen[position] >= ' '){
        drawChar(h_screen[position], x, y, color);
        x += 7;
      }
      else if(h_screen[position] == 1){
        position++;
        color = h_screen[position] & 0xf;
      }
      if((x > sx + 127 && h_screen[position + 1] != '\n') || h_screen[position] == '\n'){
        x = sx;
        y += 8;
        if(y > 118)
          return;
      } 
      position++;
    }
}

void viewHelp(const unsigned char * p, uint16_t max_length){
  int16_t page = 1;
  uint16_t page_count = 0;
  uint16_t screen_count = 0;
  uint16_t h_screen_adr = 0;
  uint16_t length = 0;
  h_screen = (char*)malloc(512 * sizeof(char));
  while(thiskey() != KEY_B){
    while(page_count != page){
      h_screen_adr += length;
      length = (pgm_read_byte(p + h_screen_adr) << 8);
      h_screen_adr++;
      length += pgm_read_byte(p + h_screen_adr);
      if(length + h_screen_adr < max_length){
        page_count++;
        length++;
      }else{
        page_count = 0;
        page = 1;
        h_screen_adr = 0;
      }
    }
    length--;
    h_screen_adr++;
    uint16_t  s = unpackingLZ(p, 0, h_screen_adr, length);
    uint16_t st = replaceWords(s);
    if(global_animation){
      for(int8_t i = 10; i >= 0; i--){
        drawHelpScreen(st, 2 + i * 10);
        redrawScreen(128);
        delay(10);
      }
    }
    else{
      drawHelpScreen(st, 2);
      redrawScreen(128);
      delay(200);
    }
    fillRect(0, 118, 128, 10, 1);
    drawString(F("< > page"), 2, 119, 0);
    drawNumber(page, 58, 119, 0);
    redrawScreen(128);
    getKey();
    while(!thiskey()){
      delay(200);
      getKey();
    }
    if((thiskey() & KEY_LEFT) && page > 0)
      page--;
    if(thiskey() & KEY_RIGHT)
      page++;
  }
  free(h_screen);
}
