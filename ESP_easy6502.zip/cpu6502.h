#include <stdint.h>
#include <stdlib.h>
#include "settings.h"

void reset6502();
void exec6502(int32_t tickcount);
uint16_t getpc();
uint8_t getop();
uint8_t getareg();
uint8_t getxreg();
uint8_t getyreg();
uint8_t getzeroram(uint16_t i);
uint16_t getLastModifiedRam();
void setzeroram(uint16_t i, uint8_t v);
