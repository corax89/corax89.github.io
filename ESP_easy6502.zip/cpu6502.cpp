#include "cpu6502.h"

//6502 defines
#define UNDOCUMENTED //when this is defined, undocumented opcodes are handled.
                     //otherwise, they're simply treated as NOPs.

#define FLAG_CARRY     0x0001
#define FLAG_ZERO      0x0002
#define FLAG_INTERRUPT 0x0004
#define FLAG_DECIMAL   0x0008
#define FLAG_BREAK     0x0010
#define FLAG_CONSTANT  0x0020
#define FLAG_OVERFLOW  0x0040
#define FLAG_SIGN      0x0080

#define BASE_STACK     0x100

#define saveaccum(n) a = (uint8_t)((n) & 0x00FF)

//flag modifier macros
#define setcarry() cpustatus |= FLAG_CARRY
#define clearcarry() cpustatus &= (~FLAG_CARRY)
#define setzero() cpustatus |= FLAG_ZERO
#define clearzero() cpustatus &= (~FLAG_ZERO)
#define setinterrupt() cpustatus |= FLAG_INTERRUPT
#define clearinterrupt() cpustatus &= (~FLAG_INTERRUPT)
#define setdecimal() cpustatus |= FLAG_DECIMAL
#define cleardecimal() cpustatus &= (~FLAG_DECIMAL)
#define setoverflow() cpustatus |= FLAG_OVERFLOW
#define clearoverflow() cpustatus &= (~FLAG_OVERFLOW)
#define setsign() cpustatus |= FLAG_SIGN
#define clearsign() cpustatus &= (~FLAG_SIGN)

#define clc() clearcarry()
#define cld() cleardecimal()
#define cli() clearinterrupt()
#define clv() clearoverflow()

#define imp() //implied
#define acc() useaccum = 1;
#define imm() ea = pc++;
#define zp()  ea = (uint16_t)read6502(pc++);
#define zpx() ea = ((uint16_t)read6502(pc++) + x) & 0xFF;
#define zpy() ea = ((uint16_t)read6502(pc++) + y) & 0xFF;

//flag calculation macros
#define zerocalc(n)  { if ((n) & 0x00FF) clearzero(); else setzero(); }
#define signcalc(n)  { if ((n) & 0x0080) setsign();   else clearsign(); }
#define carrycalc(n) { if ((n) & 0xFF00) setcarry();  else clearcarry(); }
#define overflowcalc(n, m, o) { if (((n) ^ (uint16_t)(m)) & ((n) ^ (o)) & 0x0080) setoverflow(); else clearoverflow(); }

#define getvalue() ((useaccum)?((uint16_t)a):read6502(ea))
#define getvalue16() ((uint16_t)read6502(ea) | ((uint16_t)read6502(ea + 1) << 8))

#pragma GCC optimize ("-O2")
#pragma GCC push_options

//6502 CPU registers
uint16_t pc;
uint8_t a, x, y;
uint8_t sp;
uint16_t cpustatus;
uint16_t last_modified_ram;
extern uint8_t RAM[RAM_SIZE];

//6502 zero ram + stack
uint8_t zero_ram[512];

//helper variables
uint32_t instructions = 0; //keep track of total instructions executed
uint16_t oldpc, ea, reladdr, value, result;
uint8_t opcode, oldcpustatus, useaccum;
char str_buffer_6502[12];

extern void drawPixelToRam(uint16_t address, uint8_t value);
extern uint8_t loadPixelFromRam(uint16_t address);

uint8_t read6502(uint16_t address) {
  if(address < 0x200){
    if (address >= 0xf0){
      if (address == 0xff) { //simulated ASCII input 
        
      }
      else if (address == 0xfe) { //random 
        return (rand() & 0xff);
      }
    }
    return zero_ram[address];
  }
  if(address < 0x1200){
    return loadPixelFromRam(address - 0x200);
  }
  if(address < 0x1200 + RAM_SIZE){
    return RAM[address - 0x1200];
  }
  return(0);
}

void write6502(uint16_t address, uint8_t value) {
  last_modified_ram = address;
  if(address < 0x200){
    zero_ram[address] = value;
    return;
  }
  if(address < 0x1200){
    drawPixelToRam(address - 0x200, value);
    return;
  }
  if(address < 0x1200 + RAM_SIZE){
    RAM[address - 0x1200] = value;
    return;
  }
}

//a few general functions used by various other functions
inline void push16(uint16_t pushval) {
    write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
    write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
    sp -= 2;
}

inline void push8(uint8_t pushval) {
    write6502(BASE_STACK + sp--, pushval);
}

inline uint16_t pull16() {
    uint16_t temp16;
    temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
    sp += 2;
    return(temp16);
}

inline uint8_t pull8() {
    return (read6502(BASE_STACK + ++sp));
}

void reset6502() {
  last_modified_ram = PROGRAMM_OFFSET;
  pc = PROGRAMM_OFFSET;
  a = 0;
  x = 0;
  y = 0;
  sp = 0xFD;
  cpustatus |= FLAG_CONSTANT;
  for(uint8_t i = 0; i < 12; i++)
    str_buffer_6502[i] = 0;
}

//addressing mode functions, calculates effective addresses
inline void rel() { //relative for branch ops (8-bit immediate value, sign-extended)
    reladdr = (uint16_t)read6502(pc++);
    if (reladdr & 0x80) 
      reladdr |= 0xFF00;
}

inline void abso() { //absolute
    ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc + 1) << 8);
    pc += 2;
}

inline void absx() { //absolute,X
    ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc + 1) << 8));
    ea += x;
    pc += 2;
}

inline void absy() { //absolute,Y
    uint16_t startpage;
    ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc + 1) << 8));
    ea += y;
    pc += 2;
}

inline void ind() { //indirect
    uint16_t eahelp, eahelp2;
    /*
    eahelp = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc + 1) << 8);
    eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
    */
    eahelp = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc + 1) << 8);
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp + 1) << 8);
    pc += 2;
}

inline void indx() { // (indirect,X)
    uint16_t eahelp;
    eahelp = (uint16_t)(((uint16_t)read6502(pc++) + x) & 0xFF); //zero-page wraparound for table pointer
    ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502(eahelp + 1) << 8);
}

inline void indy() { // (indirect),Y
    uint16_t eahelp, eahelp2, startpage;
    /*
    eahelp = (uint16_t)read6502(pc++);
    eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //zero-page wraparound
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
    */
    eahelp = (uint16_t)read6502(pc++);
    ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp + 1) << 8);
    ea += y;
}

inline void putvalue(uint16_t saveval) {
    if (useaccum) 
      a = (uint8_t)(saveval & 0x00FF);
    else 
      write6502(ea, (saveval & 0x00FF));
}

//instruction handler functions
inline void adc() {
    value = getvalue();
    result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
    carrycalc(result);
    zerocalc(result);
    overflowcalc(result, a, value);
    signcalc(result);
    saveaccum(result);
}

inline void op_and() {
    value = getvalue();
    result = (uint16_t)a & value;
    zerocalc(result);
    signcalc(result);
    saveaccum(result);
}

inline void asl() {
    value = getvalue();
    result = value << 1;
    carrycalc(result);
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void bcc() {
    if ((cpustatus & FLAG_CARRY) == 0) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void bcs() {
    if ((cpustatus & FLAG_CARRY) == FLAG_CARRY) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void beq() {
    if ((cpustatus & FLAG_ZERO) == FLAG_ZERO) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void op_bit() {
    value = getvalue();
    result = (uint16_t)a & value;
    zerocalc(result);
    cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
}

inline void bmi() {
    if ((cpustatus & FLAG_SIGN) == FLAG_SIGN) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void bne() {
    if ((cpustatus & FLAG_ZERO) == 0) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void bpl() {
    if ((cpustatus & FLAG_SIGN) == 0) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void brk() {
    pc++;
    push16(pc); //push next instruction address onto stack
    push8(cpustatus | FLAG_BREAK); //push CPU cpustatus to stack
    setinterrupt(); //set interrupt flag
    pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
}

inline void bvc() {
    if ((cpustatus & FLAG_OVERFLOW) == 0) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void bvs() {
    if ((cpustatus & FLAG_OVERFLOW) == FLAG_OVERFLOW) {
        oldpc = pc;
        pc += reladdr;
    }
}

inline void cmp() {
    value = getvalue();
    result = (uint16_t)a - value;
    if (a >= (value & 0x00FF)) 
      setcarry();
    else 
      clearcarry();
    if (a == (value & 0x00FF)) 
      setzero();
    else 
      clearzero();
    signcalc(result);
}

inline void cpx() {
    value = getvalue();
    result = (uint16_t)x - value;
    if (x >= (value & 0x00FF)) setcarry();
        else clearcarry();
    if (x == (value & 0x00FF)) setzero();
        else clearzero();
    signcalc(result);
}

inline void cpy() {
    value = getvalue();
    result = (uint16_t)y - value;
    if (y >= (value & 0x00FF)) 
      setcarry();
    else
      clearcarry();
    if (y == (value & 0x00FF))
      setzero();
    else 
      clearzero();
    signcalc(result);
}

inline void dec() {
    value = getvalue();
    result = value - 1;
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void dex() {
    x--;
    zerocalc(x);
    signcalc(x);
}

inline void dey() {
    y--;
    zerocalc(y);
    signcalc(y);
}

inline void eor() {
    value = getvalue();
    result = (uint16_t)a ^ value;
    zerocalc(result);
    signcalc(result);
    saveaccum(result);
}

inline void inc() {
    value = getvalue();
    result = value + 1;
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void inx() {
    x++;
    zerocalc(x);
    signcalc(x);
}

inline void iny() {
    y++;
    zerocalc(y);
    signcalc(y);
}

inline void jmp() {
    pc = ea;
}

inline void jsr() {
    push16(pc - 1);
    pc = ea;
}

inline void lda() {
    value = getvalue();
    a = (uint8_t)(value & 0x00FF);
    zerocalc(a);
    signcalc(a);
}

inline void ldx() {
    value = getvalue();
    x = value & 0x00FF;
    zerocalc(x);
    signcalc(x);
}

inline void ldy() {
    value = getvalue();
    y = value & 0x00FF;
    zerocalc(y);
    signcalc(y);
}

inline void lsr() {
    value = getvalue();
    result = value >> 1;
    if (value & 1) 
      setcarry();
    else 
      clearcarry();
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void nop() {
}

inline void ora() {
    value = getvalue();
    result = (uint16_t)a | value;
    zerocalc(result);
    signcalc(result);
    saveaccum(result);
}

inline void pha() {
    push8(a);
}

inline void php() {
    push8(cpustatus | FLAG_BREAK);
}

inline void pla() {
    a = pull8();
    zerocalc(a);
    signcalc(a);
}

inline void plp() {
    cpustatus = pull8() | FLAG_CONSTANT;
}

inline void rol() {
    value = getvalue();
    result = (value << 1) | (cpustatus & FLAG_CARRY);
    carrycalc(result);
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void ror() {
    value = getvalue();
    result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
    if (value & 1) 
      setcarry();
    else 
      clearcarry();
    zerocalc(result);
    signcalc(result);
    putvalue(result);
}

inline void rti() {
    cpustatus = pull8();
    value = pull16();
    pc = value;
}

inline void rts() {
    value = pull16();
    pc = value + 1;
}

inline void sbc() {
    value = getvalue() ^ 0x00FF;
    result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
    carrycalc(result);
    zerocalc(result);
    overflowcalc(result, a, value);
    signcalc(result);
    saveaccum(result);
}

inline void tax() {
    x = a;
    zerocalc(x);
    signcalc(x);
}

inline void tay() {
    y = a;
    zerocalc(y);
    signcalc(y);
}

inline void tsx() {
    x = sp;
    zerocalc(x);
    signcalc(x);
}

inline void txa() {
    a = x;
    zerocalc(a);
    signcalc(a);
}

inline void txs() {
    sp = x;
}

inline void tya() {
    a = y;
    zerocalc(a);
    signcalc(a);
}

inline void lax() {
    lda();
    ldx();
}

inline void sax() {
    putvalue(a);//sta
    putvalue(x);//stx
    putvalue(a & x);
}

inline void dcp() {
    dec();
    cmp();
}

inline void isb() {
    inc();
    sbc();
}

inline void slo() {
    asl();
    ora();
}

inline void rla() {
    rol();
    op_and();
}

inline void sre() {
    lsr();
    eor();
}

inline void rra() {
    ror();
    adc();
}

inline void nmi6502() {
    push16(pc);
    push8(cpustatus);
    cpustatus |= FLAG_INTERRUPT;
    pc = (uint16_t)read6502(0xFFFA) | ((uint16_t)read6502(0xFFFB) << 8);
}

inline void irq6502() {
    push16(pc);
    push8(cpustatus);
    cpustatus |= FLAG_INTERRUPT;
    pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
}

void exec6502(int32_t tickcount) {
  while (tickcount--) {
    opcode = read6502(pc++);
    cpustatus |= FLAG_CONSTANT;
    useaccum = 0;
    switch (opcode) {
    case 0x0:
      imp();
      brk();
      break;
    case 0x1:
      indx();
      ora();
      break;
    case 0x2:
    case 0x3:
    case 0x4:
      break;
    case 0x5:
      zp();
      ora();
      break;
    case 0x6:
      zp();
      asl();
      break;
    case 0x7:
      break;
    case 0x8:
      imp();
      php();
      break;
    case 0x9:
      imm();
      ora();
      break;
    case 0xA:
      acc();
      asl();
      break;
    case 0xD:
      abso();
      ora();
      break;
    case 0xE:
      abso();
      asl();
      break;
    case 0xF:
      break;
    case 0x10:
      rel();
      bpl();
      break;
    case 0x11:
      indy();
      ora();
      break;
    case 0x12:
    case 0x13:
    case 0x14:
      break;
    case 0x15:
      zpx();
      ora();
      break;
    case 0x16:
      zpx();
      asl();
      break;
    case 0x17:
      break;
    case 0x18:
      imp();
      clc();
      break;
    case 0x19:
      absy();
      ora();
      break;
    case 0x1A:
    case 0x1B:
    case 0x1C:
      break;
    case 0x1D:
      absx();
      ora();
      break;
    case 0x1E:
      absx();
      asl();
      break;
    case 0x1F:
      break;
    case 0x20:
      abso();
      jsr();
      break;
    case 0x21:
      indx();
      op_and();
      break;
    case 0x22:
    case 0x23:
      break;
    case 0x24:
      zp();
      op_bit();
      break;
    case 0x25:
      zp();
      op_and();
      break;
    case 0x26:
      zp();
      rol();
      break;
    case 0x27:
      break;
    case 0x28:
      imp();
      plp();
      break;
    case 0x29:
      imm();
      op_and();
      break;
    case 0x2A:
      acc();
      rol();
      break;
    case 0x2B:
      break;
    case 0x2C:
      abso();
      op_bit();
      break;
    case 0x2D:
      abso();
      op_and();
      break;
    case 0x2E:
      abso();
      rol();
      break;
    case 0x2F:
      break;
    case 0x30:
      rel();
      bmi();
      break;
    case 0x31:
      indy();
      op_and();
      break;
    case 0x32:
    case 0x33:
    case 0x34:
      break;
    case 0x35:
      zpx();
      op_and();
      break;
    case 0x36:
      zpx();
      rol();
      break;
    case 0x37:
      break;
    case 0x38:
      imp();
      setcarry();
      break;
    case 0x39:
      absy();
      op_and();
      break;
    case 0x3A:
    case 0x3B:
    case 0x3C:
      break;
    case 0x3D:
      absx();
      op_and();
      break;
    case 0x3E:
      absx();
      rol();
      break;
    case 0x3F:
      break;
    case 0x40:
      imp();
      rti();
      break;
    case 0x41:
      indx();
      eor();
      break;
    case 0x42:
    case 0x43:
    case 0x44:
      break;
    case 0x45:
      zp();
      eor();
      break;
    case 0x46:
      zp();
      lsr();
      break;
    case 0x47:
      break;
    case 0x48:
      imp();
      pha();
      break;
    case 0x49:
      imm();
      eor();
      break;
    case 0x4A:
      acc();
      lsr();
      break;
    case 0x4B:
      break;
    case 0x4C:
      abso();
      jmp();
      break;
    case 0x4D:
      abso();
      eor();
      break;
    case 0x4E:
      abso();
      lsr();
      break;
    case 0x4F:
      break;
    case 0x50:
      rel();
      bvc();
      break;
    case 0x51:
      indy();
      eor();
      break;
    case 0x52:
    case 0x53:
    case 0x54:
      break;
    case 0x55:
      zpx();
      eor();
      break;
    case 0x56:
      zpx();
      lsr();
      break;
    case 0x57:
      break;
    case 0x58:
      imp();
      cli();
      break;
    case 0x59:
      absy();
      eor();
      break;
    case 0x5A:
    case 0x5B:
    case 0x5C:
      break;
    case 0x5D:
      absx();
      eor();
      break;
    case 0x5E:
      absx();
      lsr();
      break;
    case 0x5F:
      break;
    case 0x60:
      imp();
      rts();
      break;
    case 0x61:
      indx();
      adc();
      break;
    case 0x62:
    case 0x63:
    case 0x64:
      break;
    case 0x65:
      zp();
      adc();
      break;
    case 0x66:
      zp();
      ror();
      break;
    case 0x67:
      break;
    case 0x68:
      imp();
      pla();
      break;
    case 0x69:
      imm();
      adc();
      break;
    case 0x6A:
      acc();
      ror();
      break;
    case 0x6B:
      break;
    case 0x6C:
      ind();
      jmp();
      break;
    case 0x6D:
      abso();
      adc();
      break;
    case 0x6E:
      abso();
      ror();
      break;
    case 0x6F:
      break;
    case 0x70:
      rel();
      bvs();
      break;
    case 0x71:
      indy();
      adc();
      break;
    case 0x72:
    case 0x73:
    case 0x74:
      break;
    case 0x75:
      zpx();
      adc();
      break;
    case 0x76:
      zpx();
      ror();
      break;
    case 0x77:
      break;
    case 0x78:
      imp();
      setinterrupt();
      break;
    case 0x79:
      absy();
      adc();
      break;
    case 0x7A:
    case 0x7B:
    case 0x7C:
      break;
    case 0x7D:
      absx();
      adc();
      break;
    case 0x7E:
      absx();
      ror();
      break;
    case 0x7F:
    case 0x80:
      break;
    case 0x81:
      indx();
      putvalue(a);//sta
      break;
    case 0x82:
    case 0x83:
      break;
    case 0x84:
      zp();
      putvalue(y);//sty
      break;
    case 0x85:
      zp();
      putvalue(a);//sta
      break;
    case 0x86:
      zp();
      putvalue(x);//stx
      break;
    case 0x87:
      break;
    case 0x88:
      imp();
      dey();
      break;
    case 0x8A:
      imp();
      txa();
      break;
    case 0x8B:
      break;
    case 0x8C:
      abso();
      putvalue(y);//sty
      break;
    case 0x8D:
      abso();
      putvalue(a);//sta
      break;
    case 0x8E:
      abso();
      putvalue(x);//stx
      break;
    case 0x8F:
      break;
    case 0x90:
      rel();
      bcc();
      break;
    case 0x91:
      indy();
      putvalue(a);//sta
      break;
    case 0x92:
    case 0x93:
      break;
    case 0x94:
      zpx();
      putvalue(y);//sty
      break;
    case 0x95:
      zpx();
      putvalue(a);//sta
      break;
    case 0x96:
      zpy();
      putvalue(x);//stx
      break;
    case 0x97:
      break;
    case 0x98:
      imp();
      tya();
      break;
    case 0x99:
      absy();
      putvalue(a);//sta
      break;
    case 0x9A:
      imp();
      txs();
      break;
    case 0x9B:
    case 0x9C:
      break;
    case 0x9D:
      absx();
      putvalue(a);//sta
      break;
    case 0x9E:
    case 0x9F:
      break;
    case 0xA0:
      imm();
      ldy();
      break;
    case 0xA1:
      indx();
      lda();
      break;
    case 0xA2:
      imm();
      ldx();
      break;
    case 0xA3:
      break;
    case 0xA4:
      zp();
      ldy();
      break;
    case 0xA5:
      zp();
      lda();
      break;
    case 0xA6:
      zp();
      ldx();
      break;
    case 0xA7:
      break;
    case 0xA8:
      imp();
      tay();
      break;
    case 0xA9:
      imm();
      lda();
      break;
    case 0xAA:
      imp();
      tax();
      break;
    case 0xAB:
      break;
    case 0xAC:
      abso();
      ldy();
      break;
    case 0xAD:
      abso();
      lda();
      break;
    case 0xAE:
      abso();
      ldx();
      break;
    case 0xAF:
      break;
    case 0xB0:
      rel();
      bcs();
      break;
    case 0xB1:
      indy();
      lda();
      break;
    case 0xB2:
    case 0xB3:
      break;
    case 0xB4:
      zpx();
      ldy();
      break;
    case 0xB5:
      zpx();
      lda();
      break;
    case 0xB6:
      zpy();
      ldx();
      break;
    case 0xB7:
      break;
    case 0xB8:
      imp();
      clv();
      break;
    case 0xB9:
      absy();
      lda();
      break;
    case 0xBA:
      imp();
      tsx();
      break;
    case 0xBC:
      absx();
      ldy();
      break;
    case 0xBD:
      absx();
      lda();
      break;
    case 0xBE:
      absy();
      ldx();
      break;
    case 0xBF:
      break;
    case 0xC0:
      imm();
      cpy();
      break;
    case 0xC1:
      indx();
      cmp();
      break;
    case 0xC2:
    case 0xC3:
      break;
    case 0xC4:
      zp();
      cpy();
      break;
    case 0xC5:
      zp();
      cmp();
      break;
    case 0xC6:
      zp();
      dec();
      break;
    case 0xC7:
      break;
    case 0xC8:
      imp();
      iny();
      break;
    case 0xC9:
      imm();
      cmp();
      break;
    case 0xCA:
      imp();
      dex();
      break;
    case 0xCB:
      break;
    case 0xCC:
      abso();
      cpy();
      break;
    case 0xCD:
      abso();
      cmp();
      break;
    case 0xCE:
      abso();
      dec();
      break;
    case 0xCF:
      break;
    case 0xD0:
      rel();
      bne();
      break;
    case 0xD1:
      indy();
      cmp();
      break;
    case 0xD2:
    case 0xD3:
    case 0xD4:
      break;
    case 0xD5:
      zpx();
      cmp();
      break;
    case 0xD6:
      zpx();
      dec();
      break;
    case 0xD7:
      break;
    case 0xD8:
      imp();
      cld();
      break;
    case 0xD9:
      absy();
      cmp();
      break;
    case 0xDA:
    case 0xDB:
    case 0xDC:
      break;
    case 0xDD:
      absx();
      cmp();
      break;
    case 0xDE:
      absx();
      dec();
      break;
    case 0xDF:
      break;
    case 0xE0:
      imm();
      cpx();
      break;
    case 0xE1:
      indx();
      sbc();
      break;
    case 0xE2:
    case 0xE3:
      break;
    case 0xE4:
      zp();
      cpx();
      break;
    case 0xE5:
      zp();
      sbc();
      break;
    case 0xE6:
      zp();
      inc();
      break;
    case 0xE7:
      break;
    case 0xE8:
      imp();
      inx();
      break;
    case 0xE9:
      imm();
      sbc();
      break;
    case 0xEA:
      break;
    case 0xEB:
      imm();
      sbc();
      break;
    case 0xEC:
      abso();
      cpx();
      break;
    case 0xED:
      abso();
      sbc();
      break;
    case 0xEE:
      abso();
      inc();
      break;
    case 0xEF:
      break;
    case 0xF0:
      rel();
      beq();
      break;
    case 0xF1:
      indy();
      sbc();
      break;
    case 0xF2:
    case 0xF3:
    case 0xF4:
      break;
    case 0xF5:
      zpx();
      sbc();
      break;
    case 0xF6:
      zpx();
      inc();
      break;
    case 0xF7:
      break;
    case 0xF8:
      imp();
      setdecimal();
      break;
    case 0xF9:
      absy();
      sbc();
      break;
    case 0xFA:
    case 0xFB:
    case 0xFC:
      break;
    case 0xFD:
      absx();
      sbc();
      break;
    case 0xFE:
      absx();
      inc();
      break;
    case 0xFF:
      break;
    }
    instructions++;
  }
}

uint16_t getpc() {
  return(pc);
}

uint8_t getop() {
  return(opcode);
}

uint8_t getareg(){
  return(a);
}

uint8_t getxreg(){
  return(x);
}

uint8_t getyreg(){
  return(y);
}

uint8_t getzeroram(uint16_t i){
  return zero_ram[i];
}

void setzeroram(uint16_t i, uint8_t v){
  zero_ram[i] = v;
}

uint16_t getLastModifiedRam(){
  return last_modified_ram;
}
  
