#include <stdint.h>
#include <stdlib.h>
#include <Arduino.h>
#include <EEPROM.h>
#include "settings.h"

int16_t t_editor_position = 0;        //cursor position in the text
int16_t t_editor_y_position = 0;      //the number of the line the cursor is pointing to
int16_t t_editor_string_position = 0;//the number of the character from which the string containing the cursor starts
int16_t t_editor_string_count = 0;   //row count
int16_t t_editor_letter_count = 0;   //number of letters
int32_t asm_time;

extern uint8_t RAM[RAM_SIZE];
char error_string[32] = "  undefine error";

extern void opcodeDisasm(char s[], uint8_t op);
extern uint16_t asm6502(char *s, uint8_t *ram, char *error_s);
extern uint16_t getLastModifiedRam();
extern void reset6502();
extern void exec6502(int32_t tickcount);
extern void setzeroram(uint16_t i, uint8_t v);
extern uint8_t getzeroram(uint16_t i);
extern uint16_t getpc();
extern uint8_t getop();
extern uint8_t getareg();
extern uint8_t getxreg();
extern uint8_t getyreg();
extern void redrawScreen(int16_t size);
extern void clearScr(uint8_t color);

uint16_t isSChar(char c){
  if(c >= ' ' && c <= '~')
    return true;
  return false;
}

uint16_t isNumber(char c){
  if(c >= '0' && c <= '9')
    return 1;
  return 0;
}

void inputWaiting(){
  uint16_t dtime = 0;
  while(!Serial.available() && dtime < 10){
    delay(1);
    dtime++;
  }
}

void s_printInfo(char *string, uint8_t type, uint16_t n){
  int16_t position = ((error_string[0] << 8) + error_string[1]);
  int16_t j = 0;
  if(type == 0)
    Serial.print(F("\033[41m\033[30m"));
  else
    Serial.print(F("\033[47m\033[30m"));
  Serial.print(F("\033[5;1H\033[0K"));
  Serial.print(F("\033[6;1H"));
  if(type == 0){
    Serial.print(F("character "));
    Serial.print(position);
    Serial.print(F(" : "));
    j += 2;
    while(string[j]){
      Serial.print(string[j]);
      j++;
    }
  }
  else{
    Serial.print(F(" assembly complete\033[0K\n\r"));
    Serial.print(F(" length "));
    Serial.print(n);
    Serial.print(F(" byte\033[0K\n\r"));
    Serial.print(F(" time "));
    Serial.print(asm_time);
    Serial.print(F(" ms"));
  }
  Serial.print(F("\033[0K\n\r\033[0K"));
  Serial.print(F("\033[49m\033[39m"));
  delay(1000);
  while(!Serial.available()){
    delay(100);
  }
  while(Serial.available()){
    Serial.read();
    delay(10);
  }
}

void printHex(uint8_t mem[], uint16_t count){
  uint16_t x = 0, i = 0;
  Serial.print(F("\033[1;1H"));
  Serial.print(F("\033[49m\033[39m"));
  Serial.print(F("\033[J"));
  while(i < count){
    if(x == 0){
       Serial.print(i + PROGRAMM_OFFSET, HEX);
       Serial.print(F(":"));
    }
    if(!(x & 1))
      Serial.print(' ');
    Serial.print(mem[i] >> 4, HEX);
    Serial.print(mem[i++] & 0xf, HEX);
    x++;
    if(x >= 8){
      x = 0;
      Serial.print(F("\n\r"));
    }
  }
  delay(1000);
  while(!Serial.available()){
    delay(100);
  }
  while(Serial.available()){
    Serial.read();
    delay(10);
  }
}

void viewTextDebugger(uint8_t mem[]){
  uint8_t operating_mode = 0;
  uint16_t x,i,n;
  char s[4];
  char out_str[28];
  char c;
  uint16_t modified_ram;
  uint16_t previouse_modified_ram = 0;
  for(x = 0; x < 28; x++){
    out_str[x] = 0;
  }
  reset6502();
  clearScr(0);
  Serial.print(F("\033[47m\033[30m"));
  Serial.print(F("\033[3;1H"));
  Serial.print(F("\033[31mCursor right Run\033[0K"));
  Serial.print(F("\033[4;1H"));
  Serial.print(F("\033[31mCursor left  Step\033[0K"));
  Serial.print(F("\033[5;1H"));
  Serial.print(F("\033[31mCursor up    Exit\033[0K"));
  Serial.print(F("\033[47m\033[30m"));
  while(1){
    modified_ram = getLastModifiedRam();
    Serial.print(F("\033[1;1H\033[0K\033[1;1H"));
    Serial.print(F("A: "));
    Serial.print(getareg());
    Serial.print(F("\033[1;7H"));
    Serial.print(F(" X: "));
    Serial.print(getxreg());
    Serial.print(F("\033[1;13H"));
    Serial.print(F(" Y: "));
    Serial.print(getyreg());
    Serial.print(F("\033[0K\n\rPC: "));
    Serial.print(getpc(), HEX);
    Serial.print(F(" opcode:"));
    opcodeDisasm(s, getop());
    Serial.print(s);
    Serial.print('(');
    Serial.print(getop(), HEX);
    Serial.print(F(")\033[0K"));
    Serial.print(F("\033[6;1H\033[0K"));
    if(previouse_modified_ram != modified_ram){
      previouse_modified_ram = modified_ram;
      x = 0;
      n = modified_ram & 0xffc0;
      Serial.print(F("\033[7;1H"));
      Serial.print(F("\033[49m\033[39m"));
      for(i = 0; i < 64; i++){
        if(x == 0){
           Serial.print(n + i, HEX);
           Serial.print(F(":"));
        }
        if(!(x & 1))
          Serial.print(' ');
        if(n + i == modified_ram)
          Serial.print(F("\033[31m"));
        if(n + i < PROGRAMM_OFFSET + RAM_SIZE && n + i > PROGRAMM_OFFSET){
          Serial.print(mem[n + i - PROGRAMM_OFFSET] >> 4, HEX);
          Serial.print(mem[(n + i) - PROGRAMM_OFFSET] & 0xf, HEX);
        }
        else if(n + i < 512){
          Serial.print(getzeroram(n + i) >> 4, HEX);
          Serial.print(getzeroram(n + i) & 0xf, HEX);
        }
        if(n + i == modified_ram)
          Serial.print(F("\033[39m"));
        x++;
        if(x >= 8){
          x = 0;
          Serial.print(F("\033[0K\n\r"));
        }
      }
    }
    if(Serial.available()){
      c = Serial.read();
      if(c == '\033'){
        inputWaiting();
        if(Serial.available()){
          if(Serial.read() == '['){
            inputWaiting();
          }
          c = Serial.read();
          if(c == 'D'){//left key
            operating_mode = 1;
          }
          else if(c == 'C'){//right key
            operating_mode = 2;
          }
          else if(c == 'A'){//up key
            return;
          }
        }
        c = 0;
      }
    }
    if(operating_mode == 1){
      exec6502(1);
      operating_mode = 0;
      redrawScreen(64);
      delay(50);
    }
    else if(operating_mode == 2){
      exec6502(100);
      redrawScreen(64);
      delay(50);
    }
    else
      delay(200);
    if(getzeroram(0xff)){
      out_str[27] = getzeroram(0xff);
      setzeroram(0xff, 0);
      Serial.print(F("\033[6;1H"));
      Serial.print(F("\033[49m\033[39m"));
      for(x = 0; x < 27; x++){
        out_str[x] = out_str[x + 1];
        if(out_str[x] >= 0x20)
          Serial.print((char)out_str[x]);
      }
      Serial.print(F("\033[0K\033[47m\033[30m"));
    }
  }
}

int16_t sTextMenu(){
  int16_t i;
  int16_t pos = 4;
  char c;
  while(1){
    Serial.print(F("\033[47m\033[30m"));
    Serial.print(F("\033[5;11H"));
    Serial.print(F("========"));
    for(i = 0; i < 5; i++){
      Serial.print(F("\033["));
      Serial.print(i + 6, DEC);
      Serial.print(F(";11H "));
      if(i == pos)
        Serial.print(F("\033[105m"));
      switch(i){
        case 0:
          Serial.print(F("ASM   "));
          break;
        case 1:
          Serial.print(F("HEX   "));
          break;
        case 2:
          Serial.print(F("RUN   "));
          break;
        case 3:
          Serial.print(F("EXIT  "));
          break;
        case 4:
          Serial.print(F("CANCEL"));
          break;
      }
      if(i == pos)
        Serial.print(F("\033[47m"));
      Serial.print(' ');
    }
    Serial.print(F("\033[11;11H"));
    Serial.print(F("========"));
    while(!Serial.available()){
      delay(5);
    }
    c = Serial.read();
    if(c == '\033'){
      inputWaiting();
      if(Serial.read() == '['){
        inputWaiting();
      }
      c = Serial.read();
      if(c == 'A'){//up key
        if(pos > 0){
          pos--;
        }
      }
      else if(c == 'B'){//down key
        if(pos < 4){
          pos++;
        }
      }
    }
    else if(c == '\n' || c == '\r'){
      delay(5);
      if(Serial.available()){
        c = Serial.read();
      }
      Serial.print(F("\033[49m\033[39m"));
      return pos;
    }
  }
}

void t_letterAndStringCounter(char s[]){
  t_editor_string_position = 0;
  t_editor_string_count = 1;
  t_editor_letter_count = 0;
  if(t_editor_position == 0)
     t_editor_string_position = 0;
  for(uint16_t i = 0; i < SOURCE_SIZE; i++){
    if(s[i] == '\n'){
      if(t_editor_position > i + 1){
        t_editor_y_position = t_editor_string_count;
        t_editor_string_position = i + 1;
      }
      t_editor_string_count++;
    }
    if(s[i] == 0){
      if(t_editor_string_position == 0)
         t_editor_y_position = 0;
      return;
    }
    t_editor_letter_count++;
  }
  if(t_editor_string_position == 0)
    t_editor_y_position = 0;
}

int16_t sRedrawString(char s[], int16_t y, int16_t pos){
  int16_t x = 0;
  uint8_t color = 1;
  Serial.print(F("\033["));
  Serial.print(y + 1, DEC);
  Serial.print(F(";1H"));//set position
  if(y == 0){
    if(pos < t_editor_position - TERMINAL_WIDTH + 3)
      pos = t_editor_position - TERMINAL_WIDTH + 3;
  }
  while(s[pos] != '\n' && pos < SOURCE_SIZE){
    if(pos == t_editor_position)
      Serial.print(F("\033[45m"));//cursor background
    else if(pos == t_editor_position + 1)
      Serial.print(F("\033[49m"));//clear cursor
#ifdef USE_SYNTAX_HIGHLIGHTING
    if(s[pos] == '#'){
      if(color != 2){
        color = 2;
        Serial.print(F("\033[31m"));//red
      }
    }
    else if(s[pos] >= '0' && s[pos] <= '9' || s[pos] == '$'){
      if(color != 3){
        color = 3;
        Serial.print(F("\033[94m"));//blue
      }
    }
    else if(s[pos] == ';'){
      if(color != 4){
        color = 4;
        Serial.print(F("\033[32m"));//green
      }
    }
#endif
    if(x < TERMINAL_WIDTH - 1)
      Serial.print(s[pos]);
    x++;
    pos++;
  }
  if(pos == t_editor_position)
    Serial.print(F("\033[45m \033[49m"));//set and clear cursor
  else if(pos == t_editor_position + 1)
    Serial.print(F("\033[49m"));//clear cursor
  Serial.println(F("\033[0K"));//clear end string
  if(color != 1){
    color = 1;
    Serial.print(F("\033[39m"));//white
  }
  return pos;
}

void sRedrawTextEditor(char s[]){
  int16_t y = 0;
  int16_t pos = t_editor_string_position;
  Serial.print(F("\033[1;1H"));
  while(y < TERMINAL_HEIGHT){
    pos = sRedrawString(s, y, pos);
    pos++;
    y++;
    if(s[pos] == 0){
      while(y < TERMINAL_HEIGHT){
         Serial.println(F("\033[0K"));//clear end string
         y++;
         if(Serial.available())
            return;
      }
    }
  }
  Serial.print(F("\033[47m"));//black
  Serial.print(F("\033[30m"));//white
  Serial.print(F("\033["));
  Serial.print(TERMINAL_HEIGHT + 1, DEC);
  Serial.print(F(";1H"));//set position
  for(int16_t i = 0; i < TERMINAL_WIDTH; i++)//draw border
    Serial.print(" ");
  Serial.print(F("\033["));
  Serial.print(TERMINAL_HEIGHT + 1, DEC);
  Serial.print(F(";1H"));//set position
  Serial.print(F("str"));
  Serial.print(t_editor_y_position, DEC);
  Serial.print('/');
  Serial.print(t_editor_string_count, DEC);
  Serial.print(F(" chr"));
  Serial.print(t_editor_position, DEC);
  Serial.print('/');
  Serial.print(t_editor_letter_count, DEC);
  Serial.print(F("\033[1;1H"));
  Serial.print(F("\033[39m"));//white
  Serial.print(F("\033[49m"));//black
}

void sTextEditor(char s[]){
  char c;
  uint8_t n_is_new_line = 0;
  uint16_t y = 0;
  uint16_t programm_size = 0;
  uint8_t color;
  char is_redraw = 1;
  t_editor_position = 0;
  int16_t menu_position = -1;
  //Serial.print("\033[5n");  // test terminal
  Serial.print(F("\033[8;")); // set terminal size
  Serial.print(TERMINAL_HEIGHT + 1, DEC);
  Serial.print(';');
  Serial.print(TERMINAL_WIDTH, DEC);
  Serial.print('t');
  while(1){
    if(is_redraw){
      inputWaiting();
      if(!Serial.available()){
        Serial.print(F("\033[3J"));//clear screen
        Serial.print(F("\033[?25l"));// hide cursor
        t_letterAndStringCounter(s);
        sRedrawTextEditor(s);
        is_redraw = 0;
      }
    }
    if(menu_position >= 0){
      Serial.print(F("\033[47m\033[30m\033[7;8H"));
      if(menu_position == 0){
        asm_time = millis();
        programm_size = asm6502(s, RAM, error_string);
        asm_time = millis() - asm_time;
        if(error_string[0] == 0xff){
          s_printInfo("", 1, programm_size);
        }
        else{
          t_editor_position = ((error_string[0] << 8) + error_string[1]);
          s_printInfo(error_string, 0, programm_size);
        }
      }
      else if(menu_position == 1){
        printHex(RAM, programm_size);
      }
      else if(menu_position == 2){
        viewTextDebugger(RAM);
      }
      else if(menu_position == 3){
        return;
      }
      Serial.print(F("\033[49m\033[39m"));
      menu_position = -1;
      is_redraw = 1;
      delay(300);
    }
    if(Serial.available()){
      c = Serial.read();
      while(isSChar(c)){
        if(t_editor_letter_count < SOURCE_SIZE - 1){
          for(uint16_t i = t_editor_letter_count; i > t_editor_position; i--)
            s[i] = s[i - 1];
          s[t_editor_position++] = c;
          t_editor_letter_count++;
          is_redraw = 1;
          c = 0;
        }
        if(Serial.available())
          c = Serial.read();
        else{
          delay(1);
          if(Serial.available())
            c = Serial.read();
        }  
      }
      if(c == '\033'){
        inputWaiting();
        if(Serial.available()){
          if(Serial.read() == '['){
            inputWaiting();
          }
          c = Serial.read();
          if(c == 'D'){//left key
            if(t_editor_position > 0){
              t_editor_position--;
              is_redraw = 1;
            }
          }
          else if(c == 'C'){//right key
            if(t_editor_position < t_editor_letter_count){
              t_editor_position++;
              is_redraw = 1;
            }
          }
          if(c == 'A'){//up key
            if(t_editor_position > 0){
              t_editor_position = t_editor_string_position - 1;//jump to end previouse string
              t_letterAndStringCounter(s);
              t_editor_position = t_editor_string_position;//jump to start string
              is_redraw = 1;
            }
          }
          else if(c == 'B'){//down key
            if(t_editor_position < t_editor_letter_count){
              while(s[t_editor_position] != '\n' && t_editor_position < t_editor_letter_count)
                t_editor_position++;
              if(t_editor_position < t_editor_letter_count)
                t_editor_position++;
              is_redraw = 1;
            }
          }
          else if(isNumber(c)){//info
            if(c == '3'){
              inputWaiting();
              if(Serial.read() == '~'){//delite
                if(s[(t_editor_position > 0) ? (t_editor_position - 1) : 0] == '\n')
                  is_redraw = 1;
                for(uint16_t i = (t_editor_position > 0) ? (t_editor_position - 1) : 0; i < t_editor_letter_count; i++)
                 s[i] = s[i + 1];
                if(t_editor_position > 0)
                 t_editor_position--;
                if(t_editor_position < t_editor_string_position && is_redraw == 0)
                 is_redraw = 1;
                else
                 sRedrawString(s, 0, t_editor_string_position);
              }
            }
            else if(c == '0'){
              //bad
            }
            if(Serial.read() == 'n'){
              //end command
            }
          }
        }
        else{//menu
          menu_position = sTextMenu();
          is_redraw = 1;
        }
      }
      else if(c == '\n'){
        if(t_editor_letter_count < SOURCE_SIZE - 1){
          for(uint16_t i = t_editor_letter_count; i > t_editor_position; i--)
            s[i] = s[i - 1];
          s[t_editor_position++] = c;
          t_editor_letter_count++;
          is_redraw = 1;
          n_is_new_line = 1;
        }
      }
      else if(c == '\r'){
        if(t_editor_letter_count < SOURCE_SIZE - 1){
          if(!n_is_new_line){
            for(uint16_t i = t_editor_letter_count; i > t_editor_position; i--)
              s[i] = s[i - 1];
            s[t_editor_position++] = '\n';
            t_editor_letter_count++;
            is_redraw = 1;
          }
        }
      }
      else if(c == '\b'){
         for(uint16_t i = (t_editor_position > 0) ? (t_editor_position - 1) : 0; i < t_editor_letter_count; i++)
           s[i] = s[i + 1];
         if(t_editor_position > 0)
            t_editor_position--;
         if(t_editor_letter_count > 0)
            t_editor_letter_count--;
         is_redraw = 1;
      }
      else if(c == '\t'){//tab
        menu_position = sTextMenu();
        is_redraw = 1;
      }
    }
    c = 0;
    delay(1);
  }
}
