#include <Arduino.h>
#include <stdint.h>
#include <stdlib.h>
#include <TFT_eSPI.h>
#include <SPI.h>
#include "settings.h"
#include "font_a.h"

#ifdef ESPBOY
  #include "lib/ESPboy_keyboard.h"
#endif

void initGui();
void redrawScreen(int16_t size);
void clearScr(uint8_t color);
void setPix(uint16_t x, uint16_t y, uint8_t c);
uint8_t getPix(uint8_t x, uint8_t y);
void drawPixelToRam(uint16_t address, uint8_t value);
uint8_t loadPixelFromRam(uint16_t address);
void drawHLine(int8_t x0, int8_t x1, int8_t y, uint8_t c);
void rect(int8_t x, int8_t y, int8_t w, int8_t h, uint8_t c);
void fillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c);
void borderFillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c1, uint8_t c2);
void animateFillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c1, uint8_t c2);
void drawChar(char c, uint8_t x, uint8_t y, uint8_t color);
void drawTinychar(char c, uint8_t x, uint8_t y, uint8_t color);
void drawString(char *s, uint16_t x, uint16_t y, uint16_t color);
void drawString(const __FlashStringHelper *s, uint16_t x, uint16_t y, uint16_t color);
uint16_t drawNumber(uint16_t n, uint16_t x, uint16_t y, uint16_t color);
int16_t pixelEditor(char e_screen[], uint8_t size);
uint16_t drawKeyboard(int16_t offset_x, int16_t offset_y, char str[], char position, uint8_t is_editor);
void drawEditor(char str_list[], uint16_t pos, int16_t cursor);
int16_t drawMenu(const __FlashStringHelper *s);
int16_t drawDebug();
void drawBackground();
uint16_t drawDialog(const __FlashStringHelper *s, const __FlashStringHelper *one, const __FlashStringHelper *two);
void drawInfo(const __FlashStringHelper *s, int16_t n0, int16_t n1);
