	.file	"cpu6502.cpp"
# GNU C++17 (GCC) version 10.3.0 (xtensa-lx106-elf)
#	compiled by GNU C version 7.3-win32 20180312, GMP version 6.1.0, MPFR version 3.1.4, MPC version 1.0.3, isl version isl-0.18-GMP

# GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
# options passed: 
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2/tools/sdk/include
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2/tools/sdk/lwip2/include
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2/tools/sdk/libc/xtensa-lx106-elf/include
# -I C:\Users\corax\AppData\Local\Temp\arduino_build_85801/core
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\cores\esp8266
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\variants\d1_mini
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\ESP8266WiFi\src
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\SPI
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\Wire
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\LittleFS\src
# -I C:\Users\corax\Documents\Arduino\libraries\TFT_eSPI
# -I C:\Users\corax\Documents\Arduino\libraries\Adafruit_MCP23017_Arduino_Library
# -I C:\Users\corax\Documents\Arduino\libraries\Adafruit_MCP4725
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\ESP8266httpUpdate\src
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\ESP8266HTTPClient\src
# -I C:\Users\corax\Documents\Arduino\libraries\HTTPSRedirect
# -I C:\Users\corax\AppData\Local\Arduino15\packages\esp8266\hardware\esp8266\3.0.2\libraries\EEPROM
# -iprefix c:\users\corax\appdata\local\arduino15\packages\esp8266\tools\xtensa-lx106-elf-gcc\3.0.4-gcc10.3-1757bed\bin\../lib/gcc/xtensa-lx106-elf/10.3.0/
# -MMD C:\Users\corax\AppData\Local\Temp\arduino_build_85801\sketch\cpu6502.cpp.d
# -MQ C:\Users\corax\AppData\Local\Temp\arduino_build_85801\sketch\cpu6502.cpp.o
# -D __ets__ -D ICACHE_FLASH -U __STRICT_ANSI__ -D _GNU_SOURCE
# -D MMU_IRAM_SIZE=0x8000 -D MMU_ICACHE_SIZE=0x8000 -D NONOSDK22x_190703=1
# -D F_CPU=160000000L -D LWIP_OPEN_SRC -D TCP_MSS=536 -D LWIP_FEATURES=1
# -D LWIP_IPV6=0 -D ARDUINO=10819 -D ARDUINO_ESP8266_WEMOS_D1MINI
# -D ARDUINO_ARCH_ESP8266 -D ARDUINO_BOARD="ESP8266_WEMOS_D1MINI"
# -D FLASHMODE_DIO -D ESP8266
# C:\Users\corax\AppData\Local\Temp\arduino_build_85801\sketch\cpu6502.cpp
# -mlongcalls -mtext-section-literals
# -auxbase-strip C:\Users\corax\AppData\Local\Temp\arduino_build_85801\sketch\cpu6502.cpp.o
# -g -Os -Werror=return-type -std=gnu++17 -free -fipa-pta -fno-rtti
# -falign-functions=4 -ffunction-sections -fdata-sections -fno-exceptions
# -fverbose-asm
# options enabled:  -faggressive-loop-optimizations -fallocation-dce
# -fauto-inc-dec -fbranch-count-reg -fcaller-saves -fcode-hoisting
# -fcombine-stack-adjustments -fcompare-elim -fcprop-registers
# -fcrossjumping -fcse-follow-jumps -fdata-sections -fdefer-pop
# -fdelete-null-pointer-checks -fdevirtualize -fdevirtualize-speculatively
# -fearly-inlining -feliminate-unused-debug-symbols
# -feliminate-unused-debug-types -fexpensive-optimizations -ffinite-loops
# -fforward-propagate -ffp-int-builtin-inexact -ffunction-cse
# -ffunction-sections -fgcse -fgcse-lm -fgnu-unique
# -fguess-branch-probability -fhoist-adjacent-loads -fident -fif-conversion
# -fif-conversion2 -findirect-inlining -finline -finline-atomics
# -finline-functions -finline-functions-called-once
# -finline-small-functions -fipa-bit-cp -fipa-cp -fipa-icf
# -fipa-icf-functions -fipa-icf-variables -fipa-profile -fipa-pta
# -fipa-pure-const -fipa-ra -fipa-reference -fipa-reference-addressable
# -fipa-sra -fipa-stack-alignment -fipa-vrp -fira-hoist-pressure
# -fira-share-save-slots -fira-share-spill-slots
# -fisolate-erroneous-paths-dereference -fivopts -fkeep-static-consts
# -fleading-underscore -flifetime-dse -flra-remat -fmath-errno
# -fmerge-constants -fmerge-debug-strings -fmove-loop-invariants
# -fomit-frame-pointer -foptimize-sibling-calls -fpartial-inlining
# -fpeephole -fpeephole2 -fplt -fprefetch-loop-arrays -free
# -freg-struct-return -freorder-functions -frerun-cse-after-loop
# -fsched-critical-path-heuristic -fsched-dep-count-heuristic
# -fsched-group-heuristic -fsched-interblock -fsched-last-insn-heuristic
# -fsched-rank-heuristic -fsched-spec -fsched-spec-insn-heuristic
# -fsched-stalled-insns-dep -fschedule-fusion -fschedule-insns2
# -fsemantic-interposition -fshow-column -fshrink-wrap
# -fshrink-wrap-separate -fsigned-zeros -fsplit-ivs-in-unroller
# -fsplit-wide-types -fssa-backprop -fssa-phiopt -fstdarg-opt
# -fstore-merging -fstrict-aliasing -fstrict-volatile-bitfields
# -fsync-libcalls -fthread-jumps -ftoplevel-reorder -ftrapping-math
# -ftree-bit-ccp -ftree-builtin-call-dce -ftree-ccp -ftree-ch
# -ftree-coalesce-vars -ftree-copy-prop -ftree-cselim -ftree-dce
# -ftree-dominator-opts -ftree-dse -ftree-forwprop -ftree-fre
# -ftree-loop-distribute-patterns -ftree-loop-if-convert -ftree-loop-im
# -ftree-loop-ivcanon -ftree-loop-optimize -ftree-parallelize-loops=
# -ftree-phiprop -ftree-pre -ftree-pta -ftree-reassoc -ftree-scev-cprop
# -ftree-sink -ftree-slsr -ftree-sra -ftree-switch-conversion
# -ftree-tail-merge -ftree-ter -ftree-vrp -funit-at-a-time -fvar-tracking
# -fvar-tracking-assignments -fverbose-asm -fzero-initialized-in-bss
# -mserialize-volatile

	.text
.Ltext0:
	.section	.text._Z8read6502t,"ax",@progbits
	.literal_position
	.literal .LC0, zero_ram
	.literal .LC1, 4607
	.literal .LC3, 20991
	.literal .LC5, RAM
	.align	4
	.global	_Z8read6502t
	.type	_Z8read6502t, @function
_Z8read6502t:
.LVL0:
.LFB12:
	.file 1 "C:\\Users\\corax\\Documents\\Arduino\\ESP_easy6502\\cpu6502.cpp"
	.loc 1 69 36 view -0
	.loc 1 70 3 view .LVU1
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:69: uint8_t read6502(uint16_t address) {
	.loc 1 69 36 is_stmt 0 view .LVU2
	addi	sp, sp, -16	#,,
.LCFI0:
	extui	a3, a2, 0, 16	# address, address
	s32i.n	a0, sp, 12	#,
.LCFI1:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU3
	movi	a2, 0x1ff	# tmp52,
.LVL1:
	.loc 1 70 3 view .LVU4
	bltu	a2, a3, .L2	# tmp52, address,
	.loc 1 71 5 is_stmt 1 view .LVU5
	.loc 1 72 7 view .LVU6
	.loc 1 75 12 view .LVU7
	movi	a2, 0xfe	# tmp54,
	bne	a3, a2, .L3	# address, tmp54,
	.loc 1 76 9 view .LVU8
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU9
	call0	rand		#
.LVL2:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU10
	extui	a2, a2, 0, 8	# <retval>,
	j	.L4		#
.L3:
	.loc 1 79 5 is_stmt 1 view .LVU11
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU12
	l32r	a2, .LC0	#, tmp55
	add.n	a2, a2, a3	# tmp56, tmp55, address
	j	.L7		#
.L2:
	.loc 1 81 3 is_stmt 1 view .LVU13
	l32r	a2, .LC1	#, tmp57
	extui	a2, a2, 0, 16	# tmp58, tmp57
	bltu	a2, a3, .L5	# tmp58, address,
.LVL3:
.LBB796:
.LBI796:
	.loc 1 69 9 view .LVU14
.LBB797:
	.loc 1 82 5 view .LVU15
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU16
	addmi	a2, a3, -0x200	# tmp59, address,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU17
	extui	a2, a2, 0, 16	#, tmp59
	call0	_Z16loadPixelFromRamt		#
.LVL4:
	.loc 1 82 28 view .LVU18
	j	.L4		#
.L5:
.LBE797:
.LBE796:
	.loc 1 84 3 is_stmt 1 view .LVU19
	l32r	a4, .LC3	#, tmp62
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:87:   return(0);
	.loc 1 87 11 is_stmt 0 view .LVU20
	movi.n	a2, 0	# <retval>,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:84:   if(address < 0x1200 + RAM_SIZE){
	.loc 1 84 3 view .LVU21
	extui	a4, a4, 0, 16	# tmp63, tmp62
	bltu	a4, a3, .L4	# tmp63, address,
	.loc 1 85 5 is_stmt 1 view .LVU22
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU23
	l32r	a2, .LC5	#, tmp64
	add.n	a2, a2, a3	# tmp65, tmp64, address
	addmi	a2, a2, -0x1200	# tmp66, tmp65,
.L7:
	l8ui	a2, a2, 0	# <retval>,
.L4:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:88: }
	.loc 1 88 1 view .LVU24
	l32i.n	a0, sp, 12	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE12:
	.size	_Z8read6502t, .-_Z8read6502t
	.section	.text._Z9write6502th,"ax",@progbits
	.literal_position
	.literal .LC6, last_modified_ram
	.literal .LC7, zero_ram
	.literal .LC8, 4607
	.literal .LC10, 20991
	.literal .LC12, RAM
	.align	4
	.global	_Z9write6502th
	.type	_Z9write6502th, @function
_Z9write6502th:
.LVL5:
.LFB13:
	.loc 1 90 49 is_stmt 1 view -0
	.loc 1 91 3 view .LVU26
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 is_stmt 0 view .LVU27
	l32r	a4, .LC6	#, tmp51
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:90: void write6502(uint16_t address, uint8_t value) {
	.loc 1 90 49 view .LVU28
	addi	sp, sp, -16	#,,
.LCFI2:
	s32i.n	a0, sp, 12	#,
.LCFI3:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:90: void write6502(uint16_t address, uint8_t value) {
	.loc 1 90 49 view .LVU29
	extui	a2, a2, 0, 16	# address, address
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU30
	s16i	a2, a4, 0	# last_modified_ram, address
	.loc 1 92 3 is_stmt 1 view .LVU31
	movi	a4, 0x1ff	# tmp53,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:90: void write6502(uint16_t address, uint8_t value) {
	.loc 1 90 49 is_stmt 0 view .LVU32
	extui	a3, a3, 0, 8	# value, value
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU33
	bltu	a4, a2, .L10	# tmp53, address,
	.loc 1 93 5 is_stmt 1 view .LVU34
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU35
	l32r	a4, .LC7	#, tmp54
	add.n	a2, a4, a2	# tmp55, tmp54, address
.LVL6:
	.loc 1 93 23 view .LVU36
	j	.L13		#
.L10:
.LVL7:
.LBB798:
.LBI798:
	.loc 1 90 6 is_stmt 1 view .LVU37
.LBB799:
	.loc 1 96 3 view .LVU38
	l32r	a4, .LC8	#, tmp56
	extui	a4, a4, 0, 16	# tmp57, tmp56
	bltu	a4, a2, .L12	# tmp57, address,
	.loc 1 97 5 view .LVU39
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU40
	addmi	a2, a2, -0x200	# tmp58, address,
.LVL8:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU41
	extui	a2, a2, 0, 16	#, tmp58
.LVL9:
	.loc 1 97 19 view .LVU42
	call0	_Z14drawPixelToRamth		#
.LVL10:
	.loc 1 98 5 is_stmt 1 view .LVU43
	j	.L9		#
.LVL11:
.L12:
	.loc 1 100 3 view .LVU44
	l32r	a4, .LC10	#, tmp60
	extui	a4, a4, 0, 16	# tmp61, tmp60
	bltu	a4, a2, .L9	# tmp61, address,
	.loc 1 101 5 view .LVU45
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU46
	l32r	a4, .LC12	#, tmp62
	add.n	a2, a4, a2	# tmp63, tmp62, address
.LVL12:
	.loc 1 101 27 view .LVU47
	addmi	a2, a2, -0x1200	# tmp64, tmp63,
.LVL13:
.L13:
	.loc 1 101 27 view .LVU48
	s8i	a3, a2, 0	#, value
	.loc 1 102 5 is_stmt 1 view .LVU49
.L9:
.LBE799:
.LBE798:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:104: }
	.loc 1 104 1 is_stmt 0 view .LVU50
	l32i.n	a0, sp, 12	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE13:
	.size	_Z9write6502th, .-_Z9write6502th
	.section	.text._Z9reset6502v,"ax",@progbits
	.literal_position
	.literal .LC13, last_modified_ram
	.literal .LC14, 4608
	.literal .LC15, pc
	.literal .LC16, a
	.literal .LC17, x
	.literal .LC18, y
	.literal .LC19, sp
	.literal .LC20, cpustatus
	.literal .LC21, str_buffer_6502
	.align	4
	.global	_Z9reset6502v
	.type	_Z9reset6502v, @function
_Z9reset6502v:
.LFB18:
	.loc 1 128 18 is_stmt 1 view -0
	.loc 1 129 3 view .LVU52
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:135:   cpustatus |= FLAG_CONSTANT;
	.loc 1 135 13 is_stmt 0 view .LVU53
	l32r	a5, .LC20	#, tmp56
	movi.n	a7, 0x20	# tmp58,
	l16ui	a4, a5, 0	# cpustatus,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:129:   last_modified_ram = PROGRAMM_OFFSET;
	.loc 1 129 21 view .LVU54
	l32r	a6, .LC14	#, tmp45
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:135:   cpustatus |= FLAG_CONSTANT;
	.loc 1 135 13 view .LVU55
	or	a4, a4, a7	# tmp60, cpustatus, tmp58
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:129:   last_modified_ram = PROGRAMM_OFFSET;
	.loc 1 129 21 view .LVU56
	l32r	a7, .LC13	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:131:   a = 0;
	.loc 1 131 5 view .LVU57
	movi.n	a2, 0	# tmp49,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:129:   last_modified_ram = PROGRAMM_OFFSET;
	.loc 1 129 21 view .LVU58
	s16i	a6, a7, 0	# last_modified_ram, tmp45
	.loc 1 130 3 is_stmt 1 view .LVU59
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:130:   pc = PROGRAMM_OFFSET;
	.loc 1 130 6 is_stmt 0 view .LVU60
	l32r	a7, .LC15	#, tmp46
.LBB800:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:137:     str_buffer_6502[i] = 0;
	.loc 1 137 24 view .LVU61
	l32r	a3, .LC21	#, tmp61
.LBE800:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:130:   pc = PROGRAMM_OFFSET;
	.loc 1 130 6 view .LVU62
	s16i	a6, a7, 0	# pc, tmp45
	.loc 1 131 3 is_stmt 1 view .LVU63
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:131:   a = 0;
	.loc 1 131 5 is_stmt 0 view .LVU64
	l32r	a6, .LC16	#, tmp48
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:134:   sp = 0xFD;
	.loc 1 134 6 view .LVU65
	movi.n	a7, -3	# tmp55,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:131:   a = 0;
	.loc 1 131 5 view .LVU66
	s8i	a2, a6, 0	# a, tmp49
	.loc 1 132 3 is_stmt 1 view .LVU67
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:132:   x = 0;
	.loc 1 132 5 is_stmt 0 view .LVU68
	l32r	a6, .LC17	#, tmp50
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:135:   cpustatus |= FLAG_CONSTANT;
	.loc 1 135 13 view .LVU69
	s16i	a4, a5, 0	# cpustatus, tmp60
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:132:   x = 0;
	.loc 1 132 5 view .LVU70
	s8i	a2, a6, 0	# x, tmp49
	.loc 1 133 3 is_stmt 1 view .LVU71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:133:   y = 0;
	.loc 1 133 5 is_stmt 0 view .LVU72
	l32r	a6, .LC18	#, tmp52
.LBB801:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:137:     str_buffer_6502[i] = 0;
	.loc 1 137 24 view .LVU73
	s8i	a2, a3, 0	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
.LBE801:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:133:   y = 0;
	.loc 1 133 5 view .LVU74
	s8i	a2, a6, 0	# y, tmp49
	.loc 1 134 3 is_stmt 1 view .LVU75
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:134:   sp = 0xFD;
	.loc 1 134 6 is_stmt 0 view .LVU76
	l32r	a6, .LC19	#, tmp54
.LBB802:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:137:     str_buffer_6502[i] = 0;
	.loc 1 137 24 view .LVU77
	s8i	a2, a3, 1	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
.LBE802:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:134:   sp = 0xFD;
	.loc 1 134 6 view .LVU78
	s8i	a7, a6, 0	# sp, tmp55
	.loc 1 135 3 is_stmt 1 view .LVU79
	.loc 1 136 3 view .LVU80
.LVL14:
.LBB803:
	.loc 1 136 24 view .LVU81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:137:     str_buffer_6502[i] = 0;
	.loc 1 137 24 is_stmt 0 view .LVU82
	s8i	a2, a3, 2	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 3	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 4	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 5	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 6	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 7	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 8	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
	s8i	a2, a3, 9	# MEM <char[1:10]> [(void *)&str_buffer_6502], tmp49
.LVL15:
	.loc 1 137 24 view .LVU83
.LBE803:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:138: }
	.loc 1 138 1 view .LVU84
	ret.n	
.LFE18:
	.size	_Z9reset6502v, .-_Z9reset6502v
	.section	.text._Z2zpv,"axG",@progbits,_Z2zpv,comdat
	.literal_position
	.literal .LC22, pc
	.literal .LC23, zero_ram
	.literal .LC24, 4607
	.literal .LC26, 20991
	.literal .LC28, RAM
	.literal .LC29, ea
	.align	4
	.weak	_Z2zpv
	.type	_Z2zpv, @function
_Z2zpv:
.LFB22:
	.loc 1 152 18 is_stmt 1 view -0
	.loc 1 153 5 view .LVU86
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 41 is_stmt 0 view .LVU87
	l32r	a2, .LC22	#, tmp54
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:152: inline void zp() { //zero-page
	.loc 1 152 18 view .LVU88
	addi	sp, sp, -16	#,,
.LCFI4:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 41 view .LVU89
	l16ui	a3, a2, 0	# pc, pc$345_1
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:152: inline void zp() { //zero-page
	.loc 1 152 18 view .LVU90
	s32i.n	a0, sp, 12	#,
.LCFI5:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 41 view .LVU91
	addi.n	a5, a3, 1	# tmp56, pc$345_1,
.LBB804:
.LBB805:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU92
	movi	a4, 0x1ff	# tmp58,
.LBE805:
.LBE804:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 41 view .LVU93
	s16i	a5, a2, 0	# pc, tmp56
.LVL16:
.LBB811:
.LBI804:
	.loc 1 69 9 is_stmt 1 view .LVU94
.LBB808:
	.loc 1 70 3 view .LVU95
	bltu	a4, a3, .L16	# tmp58, pc$345_1,
	.loc 1 71 5 view .LVU96
	.loc 1 72 7 view .LVU97
	.loc 1 75 12 view .LVU98
	movi	a2, 0xfe	# tmp60,
	bne	a3, a2, .L17	# pc$345_1, tmp60,
	.loc 1 76 9 view .LVU99
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU100
	call0	rand		#
.LVL17:
	.loc 1 76 21 view .LVU101
.LBE808:
.LBE811:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 10 view .LVU102
	extui	a2, a2, 0, 8	# prephitmp_4,
.LBB812:
.LBB809:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU103
	j	.L18		#
.LVL18:
.L17:
	.loc 1 79 5 is_stmt 1 view .LVU104
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU105
	l32r	a2, .LC23	#, tmp63
	add.n	a3, a2, a3	# tmp64, tmp63, pc$345_1
.LVL19:
	.loc 1 79 28 view .LVU106
	j	.L21		#
.LVL20:
.L16:
	.loc 1 81 3 is_stmt 1 view .LVU107
	l32r	a2, .LC24	#, tmp67
	extui	a2, a2, 0, 16	# tmp68, tmp67
	bltu	a2, a3, .L19	# tmp68, pc$345_1,
.LVL21:
.LBB806:
.LBI806:
	.loc 1 69 9 view .LVU108
.LBB807:
	.loc 1 82 5 view .LVU109
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU110
	addmi	a2, a3, -0x200	# tmp69, pc$345_1,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU111
	extui	a2, a2, 0, 16	#, tmp69
	call0	_Z16loadPixelFromRamt		#
.LVL22:
	.loc 1 82 28 view .LVU112
.LBE807:
.LBE806:
.LBE809:
.LBE812:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 10 view .LVU113
	extui	a2, a2, 0, 16	# prephitmp_4,
	j	.L18		#
.LVL23:
.L19:
.LBB813:
.LBB810:
	.loc 1 84 3 is_stmt 1 view .LVU114
	l32r	a4, .LC26	#, tmp72
	movi.n	a2, 0	# prephitmp_4,
	extui	a4, a4, 0, 16	# tmp73, tmp72
	bltu	a4, a3, .L18	# tmp73, pc$345_1,
	.loc 1 85 5 view .LVU115
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU116
	l32r	a2, .LC28	#, tmp74
	add.n	a3, a2, a3	# tmp75, tmp74, pc$345_1
.LVL24:
	.loc 1 85 32 view .LVU117
	addmi	a3, a3, -0x1200	# tmp76, tmp75,
.L21:
	.loc 1 85 32 view .LVU118
.LBE810:
.LBE813:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 10 view .LVU119
	l8ui	a2, a3, 0	# prephitmp_4,
.LVL25:
.L18:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 8 view .LVU120
	l32r	a3, .LC29	#, tmp79
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:154: }
	.loc 1 154 1 view .LVU121
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:153:     ea = (uint16_t)read6502((uint16_t)pc++);
	.loc 1 153 8 view .LVU122
	s16i	a2, a3, 0	# ea, prephitmp_4
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:154: }
	.loc 1 154 1 view .LVU123
	addi	sp, sp, 16	#,,
	ret.n	
.LFE22:
	.size	_Z2zpv, .-_Z2zpv
	.section	.text._Z3zpxv,"axG",@progbits,_Z3zpxv,comdat
	.literal_position
	.literal .LC30, pc
	.literal .LC31, zero_ram
	.literal .LC32, 4607
	.literal .LC34, 20991
	.literal .LC36, RAM
	.literal .LC37, ea
	.literal .LC38, x
	.align	4
	.weak	_Z3zpxv
	.type	_Z3zpxv, @function
_Z3zpxv:
.LFB23:
	.loc 1 156 19 is_stmt 1 view -0
	.loc 1 157 5 view .LVU125
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 42 is_stmt 0 view .LVU126
	l32r	a2, .LC30	#, tmp53
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:156: inline void zpx() { //zero-page,X
	.loc 1 156 19 view .LVU127
	addi	sp, sp, -16	#,,
.LCFI6:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 42 view .LVU128
	l16ui	a3, a2, 0	# pc, pc$392_1
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:156: inline void zpx() { //zero-page,X
	.loc 1 156 19 view .LVU129
	s32i.n	a0, sp, 12	#,
.LCFI7:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 42 view .LVU130
	addi.n	a5, a3, 1	# tmp55, pc$392_1,
.LBB814:
.LBB815:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU131
	movi	a4, 0x1ff	# tmp57,
.LBE815:
.LBE814:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 42 view .LVU132
	s16i	a5, a2, 0	# pc, tmp55
.LVL26:
.LBB819:
.LBI814:
	.loc 1 69 9 is_stmt 1 view .LVU133
.LBB818:
	.loc 1 70 3 view .LVU134
	bltu	a4, a3, .L23	# tmp57, pc$392_1,
	.loc 1 71 5 view .LVU135
	.loc 1 72 7 view .LVU136
	.loc 1 75 12 view .LVU137
	movi	a2, 0xfe	# tmp59,
	bne	a3, a2, .L24	# pc$392_1, tmp59,
	.loc 1 76 9 view .LVU138
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU139
	call0	rand		#
.LVL27:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU140
	extui	a2, a2, 0, 8	# _16,
	j	.L25		#
.LVL28:
.L24:
	.loc 1 79 5 is_stmt 1 view .LVU141
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU142
	l32r	a2, .LC31	#, tmp60
	add.n	a3, a2, a3	# tmp61, tmp60, pc$392_1
.LVL29:
	.loc 1 79 28 view .LVU143
	j	.L28		#
.LVL30:
.L23:
	.loc 1 81 3 is_stmt 1 view .LVU144
	l32r	a2, .LC32	#, tmp62
	extui	a2, a2, 0, 16	# tmp63, tmp62
	bltu	a2, a3, .L26	# tmp63, pc$392_1,
.LVL31:
.LBB816:
.LBI816:
	.loc 1 69 9 view .LVU145
.LBB817:
	.loc 1 82 5 view .LVU146
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU147
	addmi	a2, a3, -0x200	# tmp64, pc$392_1,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU148
	extui	a2, a2, 0, 16	#, tmp64
	call0	_Z16loadPixelFromRamt		#
.LVL32:
	.loc 1 82 28 view .LVU149
	j	.L25		#
.LVL33:
.L26:
	.loc 1 82 28 view .LVU150
.LBE817:
.LBE816:
	.loc 1 84 3 is_stmt 1 view .LVU151
	l32r	a4, .LC34	#, tmp67
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:87:   return(0);
	.loc 1 87 11 is_stmt 0 view .LVU152
	movi.n	a2, 0	# _16,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:84:   if(address < 0x1200 + RAM_SIZE){
	.loc 1 84 3 view .LVU153
	extui	a4, a4, 0, 16	# tmp68, tmp67
	bltu	a4, a3, .L25	# tmp68, pc$392_1,
	.loc 1 85 5 is_stmt 1 view .LVU154
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU155
	l32r	a2, .LC36	#, tmp69
	add.n	a3, a2, a3	# tmp70, tmp69, pc$392_1
.LVL34:
	.loc 1 85 32 view .LVU156
	addmi	a3, a3, -0x1200	# tmp71, tmp70,
.L28:
	.loc 1 85 32 view .LVU157
	l8ui	a2, a3, 0	# _16,
.LVL35:
.L25:
	.loc 1 85 32 view .LVU158
.LBE818:
.LBE819:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 61 view .LVU159
	l32r	a3, .LC38	#, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:158: }
	.loc 1 158 1 view .LVU160
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 61 view .LVU161
	l8ui	a3, a3, 0	#, x
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:158: }
	.loc 1 158 1 view .LVU162
	addi	sp, sp, 16	#,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:157:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)x) & 0xFF; //zero-page wraparound
	.loc 1 157 61 view .LVU163
	add.n	a2, a2, a3	# tmp75, _16, x
	l32r	a3, .LC37	#, tmp72
	extui	a2, a2, 0, 8	# tmp76, tmp75
	s16i	a2, a3, 0	# ea, tmp76
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:158: }
	.loc 1 158 1 view .LVU164
	ret.n	
.LFE23:
	.size	_Z3zpxv, .-_Z3zpxv
	.section	.text._Z4absov,"axG",@progbits,_Z4absov,comdat
	.literal_position
	.literal .LC39, pc
	.literal .LC40, ea
	.align	4
	.weak	_Z4absov
	.type	_Z4absov, @function
_Z4absov:
.LFB26:
	.loc 1 169 20 is_stmt 1 view -0
	.loc 1 170 5 view .LVU166
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:169: inline void abso() { //absolute
	.loc 1 169 20 is_stmt 0 view .LVU167
	addi	sp, sp, -16	#,,
.LCFI8:
	s32i.n	a12, sp, 8	#,
.LCFI9:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 28 view .LVU168
	l32r	a12, .LC39	#, tmp57
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:169: inline void abso() { //absolute
	.loc 1 169 20 view .LVU169
	s32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 28 view .LVU170
	l16ui	a2, a12, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:169: inline void abso() { //absolute
	.loc 1 169 20 view .LVU171
	s32i.n	a13, sp, 4	#,
.LCFI10:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 28 view .LVU172
	call0	_Z8read6502t		#
.LVL36:
	mov.n	a13, a2	# tmp59,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 57 view .LVU173
	l16ui	a2, a12, 0	# pc,
	addi.n	a2, a2, 1	# tmp62, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 54 view .LVU174
	extui	a2, a2, 0, 16	#, tmp62
	call0	_Z8read6502t		#
.LVL37:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:171:     pc += 2;
	.loc 1 171 8 view .LVU175
	l16ui	a3, a12, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 8 view .LVU176
	l32r	a4, .LC40	#, tmp65
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:172: }
	.loc 1 172 1 view .LVU177
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 61 view .LVU178
	slli	a2, a2, 8	# tmp66,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 33 view .LVU179
	or	a2, a2, a13	# tmp69, tmp66, tmp59
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:171:     pc += 2;
	.loc 1 171 8 view .LVU180
	addi.n	a3, a3, 2	# tmp73, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:172: }
	.loc 1 172 1 view .LVU181
	l32i.n	a13, sp, 4	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:171:     pc += 2;
	.loc 1 171 8 view .LVU182
	s16i	a3, a12, 0	# pc, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:170:     ea = (uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8);
	.loc 1 170 8 view .LVU183
	s16i	a2, a4, 0	# ea, tmp69
	.loc 1 171 5 is_stmt 1 view .LVU184
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:172: }
	.loc 1 172 1 is_stmt 0 view .LVU185
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE26:
	.size	_Z4absov, .-_Z4absov
	.section	.text._Z4absxv,"axG",@progbits,_Z4absxv,comdat
	.literal_position
	.literal .LC41, pc
	.literal .LC42, ea
	.literal .LC43, x
	.align	4
	.weak	_Z4absxv
	.type	_Z4absxv, @function
_Z4absxv:
.LFB27:
	.loc 1 174 20 is_stmt 1 view -0
	.loc 1 175 5 view .LVU187
	.loc 1 176 5 view .LVU188
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:174: inline void absx() { //absolute,X
	.loc 1 174 20 is_stmt 0 view .LVU189
	addi	sp, sp, -16	#,,
.LCFI11:
	s32i.n	a12, sp, 8	#,
.LCFI12:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 29 view .LVU190
	l32r	a12, .LC41	#, tmp60
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:174: inline void absx() { //absolute,X
	.loc 1 174 20 view .LVU191
	s32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 29 view .LVU192
	l16ui	a2, a12, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:174: inline void absx() { //absolute,X
	.loc 1 174 20 view .LVU193
	s32i.n	a13, sp, 4	#,
.LCFI13:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 29 view .LVU194
	call0	_Z8read6502t		#
.LVL38:
	mov.n	a13, a2	# tmp62,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 58 view .LVU195
	l16ui	a2, a12, 0	# pc,
	addi.n	a2, a2, 1	# tmp65, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 55 view .LVU196
	extui	a2, a2, 0, 16	#, tmp65
	call0	_Z8read6502t		#
.LVL39:
	.loc 1 177 5 is_stmt 1 view .LVU197
	.loc 1 178 5 view .LVU198
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:178:     ea += (uint16_t)x;
	.loc 1 178 8 is_stmt 0 view .LVU199
	l32r	a4, .LC43	#, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 62 view .LVU200
	slli	a2, a2, 8	# tmp69,,
.LVL40:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:178:     ea += (uint16_t)x;
	.loc 1 178 8 view .LVU201
	l8ui	a4, a4, 0	# x, x
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:180:     pc += 2;
	.loc 1 180 8 view .LVU202
	l16ui	a3, a12, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:176:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 176 34 view .LVU203
	or	a2, a2, a13	# tmp72, tmp69, tmp62
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:178:     ea += (uint16_t)x;
	.loc 1 178 8 view .LVU204
	add.n	a4, a4, a2	# tmp77, x, tmp72
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:181: }
	.loc 1 181 1 view .LVU205
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:178:     ea += (uint16_t)x;
	.loc 1 178 8 view .LVU206
	l32r	a2, .LC42	#, tmp68
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:180:     pc += 2;
	.loc 1 180 8 view .LVU207
	addi.n	a3, a3, 2	# tmp81, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:181: }
	.loc 1 181 1 view .LVU208
	l32i.n	a13, sp, 4	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:180:     pc += 2;
	.loc 1 180 8 view .LVU209
	s16i	a3, a12, 0	# pc, tmp81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:178:     ea += (uint16_t)x;
	.loc 1 178 8 view .LVU210
	s16i	a4, a2, 0	# ea, tmp77
	.loc 1 180 5 is_stmt 1 view .LVU211
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:181: }
	.loc 1 181 1 is_stmt 0 view .LVU212
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE27:
	.size	_Z4absxv, .-_Z4absxv
	.section	.text._Z4indxv,"axG",@progbits,_Z4indxv,comdat
	.literal_position
	.literal .LC44, pc
	.literal .LC45, x
	.literal .LC46, ea
	.align	4
	.weak	_Z4indxv
	.type	_Z4indxv, @function
_Z4indxv:
.LFB30:
	.loc 1 200 20 is_stmt 1 view -0
	.loc 1 201 5 view .LVU214
	.loc 1 202 5 view .LVU215
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 47 is_stmt 0 view .LVU216
	l32r	a3, .LC44	#, tmp61
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:200: inline void indx() { // (indirect,X)
	.loc 1 200 20 view .LVU217
	addi	sp, sp, -16	#,,
.LCFI14:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 47 view .LVU218
	l16ui	a2, a3, 0	# pc, pc$342_1
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:200: inline void indx() { // (indirect,X)
	.loc 1 200 20 view .LVU219
	s32i.n	a0, sp, 12	#,
	s32i.n	a12, sp, 8	#,
	s32i.n	a13, sp, 4	#,
.LCFI15:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 47 view .LVU220
	addi.n	a4, a2, 1	# tmp63, pc$342_1,
	s16i	a4, a3, 0	# pc, tmp63
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 44 view .LVU221
	call0	_Z8read6502t		#
.LVL41:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 66 view .LVU222
	l32r	a3, .LC45	#, tmp65
	l8ui	a12, a3, 0	#, x
	add.n	a12, a2, a12	# tmp67,, x
	extui	a12, a12, 0, 8	# _7, tmp67
.LVL42:
	.loc 1 203 5 is_stmt 1 view .LVU223
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 28 is_stmt 0 view .LVU224
	mov.n	a2, a12	#, _7
	call0	_Z8read6502t		#
.LVL43:
	mov.n	a13, a2	# tmp68,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 75 view .LVU225
	addi.n	a2, a12, 1	# tmp70, _7,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 67 view .LVU226
	extui	a2, a2, 0, 8	#, tmp70
	call0	_Z8read6502t		#
.LVL44:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 8 view .LVU227
	l32r	a3, .LC46	#, tmp75
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:204: }
	.loc 1 204 1 view .LVU228
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 89 view .LVU229
	slli	a2, a2, 8	# tmp76,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 46 view .LVU230
	or	a2, a2, a13	# tmp79, tmp76, tmp68
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:204: }
	.loc 1 204 1 view .LVU231
	l32i.n	a12, sp, 8	#,
.LVL45:
	.loc 1 204 1 view .LVU232
	l32i.n	a13, sp, 4	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 8 view .LVU233
	s16i	a2, a3, 0	# ea, tmp79
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:204: }
	.loc 1 204 1 view .LVU234
	addi	sp, sp, 16	#,,
	ret.n	
.LFE30:
	.size	_Z4indxv, .-_Z4indxv
	.section	.text._Z4indyv,"axG",@progbits,_Z4indyv,comdat
	.literal_position
	.literal .LC47, pc
	.literal .LC48, ea
	.literal .LC49, y
	.align	4
	.weak	_Z4indyv
	.type	_Z4indyv, @function
_Z4indyv:
.LFB31:
	.loc 1 206 20 is_stmt 1 view -0
	.loc 1 207 5 view .LVU236
	.loc 1 208 5 view .LVU237
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 35 is_stmt 0 view .LVU238
	l32r	a3, .LC47	#, tmp63
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:206: inline void indy() { // (indirect),Y
	.loc 1 206 20 view .LVU239
	addi	sp, sp, -16	#,,
.LCFI16:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 35 view .LVU240
	l16ui	a2, a3, 0	# pc, pc$386_1
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:206: inline void indy() { // (indirect),Y
	.loc 1 206 20 view .LVU241
	s32i.n	a0, sp, 12	#,
	s32i.n	a12, sp, 8	#,
	s32i.n	a13, sp, 4	#,
.LCFI17:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 35 view .LVU242
	addi.n	a4, a2, 1	# tmp65, pc$386_1,
	s16i	a4, a3, 0	# pc, tmp65
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 32 view .LVU243
	call0	_Z8read6502t		#
.LVL46:
	mov.n	a12, a2	# tmp66,
.LVL47:
	.loc 1 209 5 is_stmt 1 view .LVU244
	.loc 1 210 5 view .LVU245
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 28 is_stmt 0 view .LVU246
	call0	_Z8read6502t		#
.LVL48:
	.loc 1 210 28 view .LVU247
	mov.n	a13, a2	# tmp67,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:209:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //zero-page wraparound
	.loc 1 209 44 view .LVU248
	addi.n	a2, a12, 1	# tmp69, tmp66,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 58 view .LVU249
	extui	a2, a2, 0, 8	#, tmp69
	call0	_Z8read6502t		#
.LVL49:
	.loc 1 211 5 is_stmt 1 view .LVU250
	.loc 1 212 5 view .LVU251
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 is_stmt 0 view .LVU252
	l32r	a3, .LC49	#, tmp80
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 68 view .LVU253
	slli	a2, a2, 8	# tmp76,,
.LVL50:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU254
	l8ui	a3, a3, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 37 view .LVU255
	or	a2, a2, a13	# tmp79, tmp76, tmp67
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU256
	add.n	a3, a3, a2	# tmp84, y, tmp79
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:214: }
	.loc 1 214 1 view .LVU257
	l32i.n	a0, sp, 12	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU258
	l32r	a2, .LC48	#, tmp75
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:214: }
	.loc 1 214 1 view .LVU259
	l32i.n	a12, sp, 8	#,
.LVL51:
	.loc 1 214 1 view .LVU260
	l32i.n	a13, sp, 4	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU261
	s16i	a3, a2, 0	# ea, tmp84
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:214: }
	.loc 1 214 1 view .LVU262
	addi	sp, sp, 16	#,,
	ret.n	
.LFE31:
	.size	_Z4indyv, .-_Z4indyv
	.section	.text._Z3adcv,"axG",@progbits,_Z3adcv,comdat
	.literal_position
	.literal .LC50, useaccum
	.literal .LC51, a
	.literal .LC52, ea
	.literal .LC53, value
	.literal .LC54, cpustatus
	.literal .LC55, result
	.align	4
	.weak	_Z3adcv
	.type	_Z3adcv, @function
_Z3adcv:
.LFB35:
	.loc 1 231 19 is_stmt 1 view -0
	.loc 1 232 5 view .LVU264
.LBB820:
.LBI820:
	.loc 1 216 17 view .LVU265
.LBB821:
	.loc 1 217 5 view .LVU266
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU267
	l32r	a2, .LC50	#, tmp68
.LBE821:
.LBE820:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:231: inline void adc() {
	.loc 1 231 19 view .LVU268
	addi	sp, sp, -16	#,,
.LCFI18:
	s32i.n	a0, sp, 12	#,
.LCFI19:
.LBB828:
.LBB826:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU269
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L34	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU270
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU271
	l32r	a6, .LC51	#, tmp118
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU272
	l8ui	a2, a6, 0	# _52, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 view .LVU273
	mov.n	a5, a2	# a$39_51, _52
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU274
	mov.n	a3, a2	# _69, _52
	j	.L35		#
.L34:
.LBB822:
.LBI822:
	.loc 1 216 17 is_stmt 1 view .LVU275
.LBB823:
	.loc 1 218 14 view .LVU276
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU277
	l32r	a2, .LC52	#, tmp71
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL52:
.LBE823:
.LBE822:
.LBE826:
.LBE828:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 26 view .LVU278
	l32r	a6, .LC51	#, tmp118
.LBB829:
.LBB827:
.LBB825:
.LBB824:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU279
	extui	a2, a2, 0, 16	# _52,
.LBE824:
.LBE825:
.LBE827:
.LBE829:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 26 view .LVU280
	l8ui	a5, a6, 0	# a$39_51, a
	mov.n	a3, a5	# _69, a$39_51
.L35:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 36 view .LVU281
	l32r	a7, .LC54	#, tmp119
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 34 view .LVU282
	add.n	a8, a2, a3	# tmp78, _52, _69
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 36 view .LVU283
	l16ui	a4, a7, 0	# cpustatus, cpustatus$155_5
	extui	a3, a4, 0, 1	# tmp77, cpustatus$155_5,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 34 view .LVU284
	add.n	a3, a3, a8	# tmp81, tmp77, tmp78
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:232:     value = getvalue();
	.loc 1 232 11 view .LVU285
	l32r	a8, .LC53	#, tmp75
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 34 view .LVU286
	extui	a3, a3, 0, 16	# _7, tmp81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:232:     value = getvalue();
	.loc 1 232 11 view .LVU287
	s16i	a2, a8, 0	# value, _52
	.loc 1 233 5 is_stmt 1 view .LVU288
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:233:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 233 12 is_stmt 0 view .LVU289
	l32r	a8, .LC55	#, tmp82
	s16i	a3, a8, 0	# result, _7
	.loc 1 235 5 is_stmt 1 view .LVU290
	.loc 1 235 5 view .LVU291
	movi	a8, -0x100	# tmp83,
	bnone	a3, a8, .L36	# _7, tmp83,
	.loc 1 235 5 discriminator 1 view .LVU292
	movi.n	a8, 1	# tmp88,
	or	a4, a4, a8	# _9, cpustatus$155_5, tmp88
	j	.L37		#
.L36:
	.loc 1 235 5 discriminator 2 view .LVU293
	movi.n	a8, -2	# tmp89,
	and	a4, a4, a8	# _9, cpustatus$155_5, tmp89
.L37:
	.loc 1 235 22 discriminator 4 view .LVU294
	.loc 1 236 5 discriminator 4 view .LVU295
	.loc 1 236 5 discriminator 4 view .LVU296
	extui	a8, a3, 0, 8	# tmp93, _7
	beqz.n	a8, .L38	# tmp93,
	.loc 1 236 5 discriminator 1 view .LVU297
	movi.n	a8, -3	# tmp94,
	and	a4, a4, a8	# _12, _9, tmp94
	j	.L39		#
.L38:
	.loc 1 236 5 discriminator 2 view .LVU298
	movi.n	a8, 2	# tmp97,
	or	a4, a4, a8	# _12, _9, tmp97
.L39:
	.loc 1 236 21 discriminator 4 view .LVU299
	.loc 1 237 5 discriminator 4 view .LVU300
	.loc 1 237 5 discriminator 4 view .LVU301
	xor	a5, a5, a3	# tmp98, a$39_51, _7
	xor	a2, a3, a2	# tmp100, _7, _52
	and	a2, a5, a2	# tmp101, tmp98, tmp100
	bbci	a2, 7, .L40	# tmp101,,
	.loc 1 237 5 discriminator 1 view .LVU302
	movi.n	a2, 0x40	# tmp105,
	or	a4, a4, a2	# _22, _12, tmp105
	j	.L41		#
.L40:
	.loc 1 237 5 discriminator 2 view .LVU303
	movi	a2, -0x41	# tmp106,
	and	a4, a4, a2	# _22, _12, tmp106
.L41:
	.loc 1 237 35 discriminator 4 view .LVU304
	.loc 1 238 5 discriminator 4 view .LVU305
	.loc 1 238 5 discriminator 4 view .LVU306
	movi	a2, 0x80	# tmp108,
	bnone	a3, a2, .L42	# _7, tmp108,
	.loc 1 238 5 discriminator 1 view .LVU307
	or	a4, a4, a2	# tmp113, _22, tmp108
	extui	a4, a4, 0, 16	# _26, tmp113
	j	.L43		#
.L42:
	.loc 1 238 5 discriminator 2 view .LVU308
	movi	a2, -0x81	# tmp114,
	and	a4, a4, a2	# _26, _22, tmp114
.L43:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:239:     saveaccum(result);
	.loc 1 239 5 is_stmt 0 discriminator 4 view .LVU309
	s8i	a3, a6, 0	# a, _7
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:240: }
	.loc 1 240 1 discriminator 4 view .LVU310
	l32i.n	a0, sp, 12	#,
	s16i	a4, a7, 0	# cpustatus, _26
	.loc 1 238 21 is_stmt 1 discriminator 4 view .LVU311
	.loc 1 239 5 discriminator 4 view .LVU312
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:240: }
	.loc 1 240 1 is_stmt 0 discriminator 4 view .LVU313
	addi	sp, sp, 16	#,,
	ret.n	
.LFE35:
	.size	_Z3adcv, .-_Z3adcv
	.section	.text._Z6op_andv,"axG",@progbits,_Z6op_andv,comdat
	.literal_position
	.literal .LC56, useaccum
	.literal .LC57, a
	.literal .LC58, ea
	.literal .LC59, value
	.literal .LC60, result
	.literal .LC61, cpustatus
	.align	4
	.weak	_Z6op_andv
	.type	_Z6op_andv, @function
_Z6op_andv:
.LFB36:
	.loc 1 242 22 is_stmt 1 view -0
	.loc 1 243 5 view .LVU315
.LBB830:
.LBI830:
	.loc 1 216 17 view .LVU316
.LBB831:
	.loc 1 217 5 view .LVU317
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU318
	l32r	a2, .LC56	#, tmp54
.LBE831:
.LBE830:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:242: inline void op_and() {
	.loc 1 242 22 view .LVU319
	addi	sp, sp, -16	#,,
.LCFI20:
	s32i.n	a0, sp, 12	#,
.LCFI21:
.LBB838:
.LBB836:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU320
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L45	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU321
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU322
	l32r	a5, .LC57	#, tmp82
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU323
	l8ui	a3, a5, 0	# _28, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 view .LVU324
	mov.n	a7, a3	# a$39_27, _28
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU325
	mov.n	a2, a3	# _29, _28
	j	.L46		#
.L45:
.LBB832:
.LBI832:
	.loc 1 216 17 is_stmt 1 view .LVU326
.LBB833:
	.loc 1 218 14 view .LVU327
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU328
	l32r	a2, .LC58	#, tmp57
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL53:
.LBE833:
.LBE832:
.LBE836:
.LBE838:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:244:     result = (uint16_t)a & value;
	.loc 1 244 26 view .LVU329
	l32r	a5, .LC57	#, tmp82
.LBB839:
.LBB837:
.LBB835:
.LBB834:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU330
	extui	a3, a2, 0, 16	# _28, tmp59
	l8ui	a4, a5, 0	# tmp62, a
	and	a7, a2, a4	# a$39_27, tmp59, tmp62
.LBE834:
.LBE835:
.LBE837:
.LBE839:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:244:     result = (uint16_t)a & value;
	.loc 1 244 26 view .LVU331
	mov.n	a2, a7	# _29, a$39_27
.L46:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:243:     value = getvalue();
	.loc 1 243 11 view .LVU332
	l32r	a4, .LC59	#, tmp63
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:246:     zerocalc(result);
	.loc 1 246 5 view .LVU333
	l32r	a6, .LC61	#, tmp81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:243:     value = getvalue();
	.loc 1 243 11 view .LVU334
	s16i	a3, a4, 0	# value, _28
	.loc 1 244 5 is_stmt 1 view .LVU335
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:244:     result = (uint16_t)a & value;
	.loc 1 244 12 is_stmt 0 view .LVU336
	l32r	a3, .LC60	#, tmp64
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:246:     zerocalc(result);
	.loc 1 246 5 view .LVU337
	l16ui	a4, a6, 0	# cpustatus, pretmp_45
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:244:     result = (uint16_t)a & value;
	.loc 1 244 12 view .LVU338
	s16i	a2, a3, 0	# result, _29
	.loc 1 246 5 is_stmt 1 view .LVU339
	.loc 1 246 5 view .LVU340
	beqz.n	a2, .L47	# _29,
	.loc 1 246 5 discriminator 1 view .LVU341
	movi.n	a3, -3	# tmp66,
	and	a4, a4, a3	# _8, pretmp_45, tmp66
	.loc 1 246 21 discriminator 1 view .LVU342
	.loc 1 247 5 discriminator 1 view .LVU343
	.loc 1 247 5 discriminator 1 view .LVU344
	movi	a8, 0x80	# tmp69,
	or	a3, a4, a8	# tmp76, _8, tmp69
	extui	a3, a3, 0, 16	# _10, tmp76
	bany	a2, a8, .L50	# _29, tmp69,
	j	.L49		#
.L47:
	.loc 1 246 5 discriminator 2 view .LVU345
	movi.n	a2, 2	# tmp74,
	or	a4, a4, a2	# _8, pretmp_45, tmp74
	.loc 1 246 21 discriminator 2 view .LVU346
	.loc 1 247 5 discriminator 2 view .LVU347
	.loc 1 247 5 discriminator 2 view .LVU348
.L49:
	.loc 1 247 5 discriminator 2 view .LVU349
	movi	a3, -0x81	# tmp77,
	and	a3, a4, a3	# _10, _8, tmp77
.L50:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:249:     saveaccum(result);
	.loc 1 249 5 is_stmt 0 discriminator 4 view .LVU350
	s8i	a7, a5, 0	# a, a$39_27
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:250: }
	.loc 1 250 1 discriminator 4 view .LVU351
	l32i.n	a0, sp, 12	#,
	s16i	a3, a6, 0	# cpustatus, _10
	.loc 1 247 21 is_stmt 1 discriminator 4 view .LVU352
	.loc 1 249 5 discriminator 4 view .LVU353
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:250: }
	.loc 1 250 1 is_stmt 0 discriminator 4 view .LVU354
	addi	sp, sp, 16	#,,
	ret.n	
.LFE36:
	.size	_Z6op_andv, .-_Z6op_andv
	.section	.text._Z3aslv,"axG",@progbits,_Z3aslv,comdat
	.literal_position
	.literal .LC62, useaccum
	.literal .LC63, a
	.literal .LC64, ea
	.literal .LC65, value
	.literal .LC66, result
	.literal .LC67, cpustatus
	.literal .LC68, last_modified_ram
	.literal .LC69, zero_ram
	.literal .LC70, 4607
	.literal .LC72, 20991
	.literal .LC74, RAM
	.align	4
	.weak	_Z3aslv
	.type	_Z3aslv, @function
_Z3aslv:
.LFB37:
	.loc 1 252 19 is_stmt 1 view -0
	.loc 1 253 5 view .LVU356
.LBB840:
.LBI840:
	.loc 1 216 17 view .LVU357
.LBB841:
	.loc 1 217 5 view .LVU358
.LBE841:
.LBE840:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:252: inline void asl() {
	.loc 1 252 19 is_stmt 0 view .LVU359
	addi	sp, sp, -16	#,,
.LCFI22:
	s32i.n	a12, sp, 8	#,
.LCFI23:
.LBB849:
.LBB846:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU360
	l32r	a12, .LC62	#, tmp63
.LBE846:
.LBE849:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:252: inline void asl() {
	.loc 1 252 19 view .LVU361
	s32i.n	a0, sp, 12	#,
.LCFI24:
.LBB850:
.LBB847:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU362
	l8ui	a4, a12, 0	# prephitmp_8, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU363
	beqz.n	a4, .L52	# prephitmp_8,
	.loc 1 217 19 is_stmt 1 view .LVU364
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU365
	l32r	a2, .LC63	#, tmp64
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU366
	l8ui	a2, a2, 0	# _35, a
	j	.L53		#
.L52:
.LBB842:
.LBI842:
	.loc 1 216 17 is_stmt 1 view .LVU367
.LBB843:
	.loc 1 218 14 view .LVU368
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU369
	l32r	a2, .LC64	#, tmp67
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL54:
.LBE843:
.LBE842:
.LBE847:
.LBE850:
.LBB851:
.LBB852:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU370
	l8ui	a4, a12, 0	# prephitmp_8, useaccum
.LBE852:
.LBE851:
.LBB862:
.LBB848:
.LBB845:
.LBB844:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU371
	extui	a2, a2, 0, 16	# _35,
.L53:
.LBE844:
.LBE845:
.LBE848:
.LBE862:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:253:     value = getvalue();
	.loc 1 253 11 view .LVU372
	l32r	a6, .LC65	#, tmp71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:254:     result = value << 1;
	.loc 1 254 20 view .LVU373
	add.n	a3, a2, a2	# tmp72, _35
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:253:     value = getvalue();
	.loc 1 253 11 view .LVU374
	s16i	a2, a6, 0	# value, _35
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:254:     result = value << 1;
	.loc 1 254 12 view .LVU375
	l32r	a2, .LC66	#, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:256:     carrycalc(result);
	.loc 1 256 5 view .LVU376
	l32r	a5, .LC67	#, tmp115
	.loc 1 254 5 is_stmt 1 view .LVU377
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:254:     result = value << 1;
	.loc 1 254 20 is_stmt 0 view .LVU378
	extui	a3, a3, 0, 16	# _2, tmp72
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:254:     result = value << 1;
	.loc 1 254 12 view .LVU379
	s16i	a3, a2, 0	# result, _2
	.loc 1 256 5 is_stmt 1 view .LVU380
	.loc 1 256 5 view .LVU381
	movi	a6, -0x100	# tmp75,
	l16ui	a2, a5, 0	# cpustatus, pretmp_12
	bnone	a3, a6, .L54	# _2, tmp75,
	.loc 1 256 5 discriminator 1 view .LVU382
	movi.n	a6, 1	# tmp80,
	or	a2, a2, a6	# cstore_1, pretmp_12, tmp80
	j	.L55		#
.L54:
	.loc 1 256 5 discriminator 2 view .LVU383
	movi.n	a6, -2	# tmp81,
	and	a2, a2, a6	# cstore_1, pretmp_12, tmp81
.L55:
	.loc 1 256 22 discriminator 4 view .LVU384
	.loc 1 257 5 discriminator 4 view .LVU385
	.loc 1 257 5 discriminator 4 view .LVU386
	extui	a6, a3, 0, 8	# tmp83, _2,
	beqz.n	a6, .L56	# tmp83,
	.loc 1 257 5 discriminator 1 view .LVU387
	movi.n	a6, -3	# tmp86,
	and	a2, a2, a6	# _9, cstore_1, tmp86
	j	.L57		#
.L56:
	.loc 1 257 5 discriminator 2 view .LVU388
	movi.n	a6, 2	# tmp89,
	or	a2, a2, a6	# _9, cstore_1, tmp89
.L57:
	.loc 1 257 21 discriminator 4 view .LVU389
	.loc 1 258 5 discriminator 4 view .LVU390
	.loc 1 258 5 discriminator 4 view .LVU391
	movi	a6, 0x80	# tmp90,
	bnone	a3, a6, .L58	# _2, tmp90,
	.loc 1 258 5 discriminator 1 view .LVU392
	or	a2, a2, a6	# tmp95, _9, tmp90
	extui	a2, a2, 0, 16	# cstore_3, tmp95
	j	.L59		#
.L58:
	.loc 1 258 5 discriminator 2 view .LVU393
	movi	a6, -0x81	# tmp96,
	and	a2, a2, a6	# cstore_3, _9, tmp96
.L59:
	s16i	a2, a5, 0	# cpustatus, cstore_3
	.loc 1 258 21 discriminator 4 view .LVU394
	.loc 1 260 5 discriminator 4 view .LVU395
.LVL55:
.LBB863:
.LBI851:
	.loc 1 225 13 discriminator 4 view .LVU396
.LBB861:
	.loc 1 226 5 discriminator 4 view .LVU397
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU398
	extui	a3, a3, 0, 8	# _14, _2
	l32r	a2, .LC63	#, tmp99
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU399
	bnez.n	a4, .L64	# prephitmp_8,
.L60:
.LVL56:
.LBB853:
.LBI853:
	.loc 1 225 13 is_stmt 1 view .LVU400
.LBB854:
	.loc 1 227 14 view .LVU401
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU402
	l32r	a2, .LC64	#, tmp100
.LBB855:
.LBB856:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU403
	l32r	a5, .LC68	#, tmp101
.LBE856:
.LBE855:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU404
	l16ui	a2, a2, 0	# ea, ea$53_48
.LVL57:
.LBB860:
.LBI855:
	.loc 1 90 6 is_stmt 1 view .LVU405
.LBB859:
	.loc 1 91 3 view .LVU406
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU407
	movi	a4, 0x1ff	# tmp103,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU408
	s16i	a2, a5, 0	# last_modified_ram, ea$53_48
	.loc 1 92 3 is_stmt 1 view .LVU409
	bltu	a4, a2, .L62	# tmp103, ea$53_48,
	.loc 1 93 5 view .LVU410
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU411
	l32r	a4, .LC69	#, tmp104
	add.n	a2, a4, a2	# tmp105, tmp104, ea$53_48
	j	.L64		#
.L62:
.LVL58:
.LBB857:
.LBI857:
	.loc 1 90 6 is_stmt 1 view .LVU412
.LBB858:
	.loc 1 96 3 view .LVU413
	l32r	a4, .LC70	#, tmp106
	extui	a4, a4, 0, 16	# tmp107, tmp106
	bltu	a4, a2, .L63	# tmp107, ea$53_48,
	.loc 1 97 5 view .LVU414
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU415
	addmi	a2, a2, -0x200	# tmp108, ea$53_48,
.LVL59:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU416
	extui	a2, a2, 0, 16	#, tmp108
	call0	_Z14drawPixelToRamth		#
.LVL60:
	.loc 1 98 5 is_stmt 1 view .LVU417
	j	.L51		#
.LVL61:
.L63:
	.loc 1 100 3 view .LVU418
	l32r	a4, .LC72	#, tmp110
	extui	a4, a4, 0, 16	# tmp111, tmp110
	bltu	a4, a2, .L51	# tmp111, ea$53_48,
	.loc 1 101 5 view .LVU419
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU420
	l32r	a4, .LC74	#, tmp112
	add.n	a2, a4, a2	# tmp113, tmp112, ea$53_48
.LVL62:
	.loc 1 101 27 view .LVU421
	addmi	a2, a2, -0x1200	# tmp114, tmp113,
.LVL63:
.L64:
	.loc 1 101 27 view .LVU422
	s8i	a3, a2, 0	#, _14
	.loc 1 102 5 is_stmt 1 view .LVU423
.L51:
	.loc 1 102 5 is_stmt 0 view .LVU424
.LBE858:
.LBE857:
.LBE859:
.LBE860:
.LBE854:
.LBE853:
.LBE861:
.LBE863:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:261: }
	.loc 1 261 1 view .LVU425
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE37:
	.size	_Z3aslv, .-_Z3aslv
	.section	.text._Z3cmpv,"axG",@progbits,_Z3cmpv,comdat
	.literal_position
	.literal .LC75, useaccum
	.literal .LC76, value
	.literal .LC77, a
	.literal .LC78, result
	.literal .LC79, cpustatus
	.literal .LC80, ea
	.align	4
	.weak	_Z3cmpv
	.type	_Z3cmpv, @function
_Z3cmpv:
.LFB52:
	.loc 1 367 19 is_stmt 1 view -0
	.loc 1 368 5 view .LVU427
.LBB864:
.LBI864:
	.loc 1 216 17 view .LVU428
.LBB865:
	.loc 1 217 5 view .LVU429
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU430
	l32r	a2, .LC75	#, tmp57
.LBE865:
.LBE864:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:367: inline void cmp() {
	.loc 1 367 19 view .LVU431
	addi	sp, sp, -16	#,,
.LCFI25:
	s32i.n	a0, sp, 12	#,
.LCFI26:
.LBB875:
.LBB870:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU432
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L66	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU433
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU434
	l32r	a2, .LC77	#, tmp60
.LBE870:
.LBE875:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 41 view .LVU435
	l32r	a5, .LC79	#, tmp90
.LBB876:
.LBB871:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU436
	l8ui	a3, a2, 0	# a, a
	l32r	a2, .LC76	#, tmp59
.LBE871:
.LBE876:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 41 view .LVU437
	l16ui	a6, a5, 0	# cpustatus, pretmp_8
.LBB877:
.LBB872:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU438
	s16i	a3, a2, 0	# value, a
.LBE872:
.LBE877:
	.loc 1 369 5 is_stmt 1 view .LVU439
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 12 is_stmt 0 view .LVU440
	l32r	a2, .LC78	#, tmp62
	movi.n	a3, 0	# tmp63,
	s16i	a3, a2, 0	# result, tmp63
	.loc 1 371 5 is_stmt 1 view .LVU441
	.loc 1 371 41 view .LVU442
	.loc 1 373 5 view .LVU443
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 41 is_stmt 0 view .LVU444
	movi.n	a4, 0	# _44,
	j	.L67		#
.L66:
.LBB878:
.LBB873:
.LBB866:
.LBI866:
	.loc 1 216 17 is_stmt 1 view .LVU445
.LBB867:
	.loc 1 218 14 view .LVU446
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU447
	l32r	a2, .LC80	#, tmp65
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL64:
.LBE867:
.LBE866:
.LBE873:
.LBE878:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 26 view .LVU448
	l32r	a4, .LC77	#, tmp68
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:368:     value = getvalue();
	.loc 1 368 11 view .LVU449
	l32r	a8, .LC76	#, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 26 view .LVU450
	l8ui	a7, a4, 0	# pretmp_14, a
.LBB879:
.LBB874:
.LBB869:
.LBB868:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU451
	extui	a3, a2, 0, 16	# _40, tmp67
.LBE868:
.LBE869:
.LBE874:
.LBE879:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 26 view .LVU452
	sub	a4, a7, a3	# tmp70, pretmp_14, _40
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 41 view .LVU453
	l32r	a5, .LC79	#, tmp90
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:368:     value = getvalue();
	.loc 1 368 11 view .LVU454
	s16i	a3, a8, 0	# value, _40
	.loc 1 369 5 is_stmt 1 view .LVU455
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 12 is_stmt 0 view .LVU456
	l32r	a3, .LC78	#, tmp74
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 26 view .LVU457
	extui	a4, a4, 0, 16	# _29, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:369:     result = (uint16_t)a - value;
	.loc 1 369 12 view .LVU458
	s16i	a4, a3, 0	# result, _29
	.loc 1 371 5 is_stmt 1 view .LVU459
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 41 is_stmt 0 view .LVU460
	l16ui	a6, a5, 0	# cpustatus, pretmp_8
	movi	a3, 0x80	# tmp71,
	and	a4, a4, a3	# _44, _29, tmp71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:372:         else clearcarry();
	.loc 1 372 14 view .LVU461
	movi.n	a3, -2	# tmp79,
	and	a3, a6, a3	# _9, pretmp_8, tmp79
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:371:     if (a >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 371 5 view .LVU462
	bltu	a7, a2, .L69	# pretmp_14, tmp67,
	.loc 1 371 41 is_stmt 1 discriminator 1 view .LVU463
	movi.n	a3, 1	# tmp77,
	or	a3, a6, a3	# _9, pretmp_8, tmp77
	s16i	a3, a5, 0	# cpustatus, _9
	.loc 1 373 5 discriminator 1 view .LVU464
	bne	a7, a2, .L69	# pretmp_14, tmp67,
.L67:
	.loc 1 373 41 discriminator 1 view .LVU465
	movi.n	a2, 3	# tmp82,
	or	a2, a6, a2	# _13, pretmp_8, tmp82
	j	.L70		#
.L69:
	.loc 1 374 14 view .LVU466
	movi.n	a2, -3	# tmp83,
	and	a2, a3, a2	# _13, _9, tmp83
.L70:
	.loc 1 375 5 view .LVU467
	.loc 1 375 5 view .LVU468
	beqz.n	a4, .L71	# _44,
	.loc 1 375 5 discriminator 1 view .LVU469
	movi	a3, 0x80	# tmp86,
	or	a2, a2, a3	# _15, _13, tmp86
	j	.L72		#
.L71:
	.loc 1 375 5 discriminator 2 view .LVU470
	movi	a3, -0x81	# tmp87,
	and	a2, a2, a3	# _15, _13, tmp87
.L72:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:376: }
	.loc 1 376 1 is_stmt 0 discriminator 4 view .LVU471
	l32i.n	a0, sp, 12	#,
	s16i	a2, a5, 0	# cpustatus, _15
	.loc 1 375 21 is_stmt 1 discriminator 4 view .LVU472
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:376: }
	.loc 1 376 1 is_stmt 0 discriminator 4 view .LVU473
	addi	sp, sp, 16	#,,
	ret.n	
.LFE52:
	.size	_Z3cmpv, .-_Z3cmpv
	.section	.text._Z3decv,"axG",@progbits,_Z3decv,comdat
	.literal_position
	.literal .LC81, useaccum
	.literal .LC82, a
	.literal .LC83, ea
	.literal .LC84, value
	.literal .LC85, result
	.literal .LC86, cpustatus
	.literal .LC87, last_modified_ram
	.literal .LC88, zero_ram
	.literal .LC89, 4607
	.literal .LC91, 20991
	.literal .LC93, RAM
	.align	4
	.weak	_Z3decv
	.type	_Z3decv, @function
_Z3decv:
.LFB55:
	.loc 1 400 19 is_stmt 1 view -0
	.loc 1 401 5 view .LVU475
.LBB880:
.LBI880:
	.loc 1 216 17 view .LVU476
.LBB881:
	.loc 1 217 5 view .LVU477
.LBE881:
.LBE880:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:400: inline void dec() {
	.loc 1 400 19 is_stmt 0 view .LVU478
	addi	sp, sp, -16	#,,
.LCFI27:
	s32i.n	a12, sp, 8	#,
.LCFI28:
.LBB889:
.LBB886:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU479
	l32r	a12, .LC81	#, tmp61
.LBE886:
.LBE889:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:400: inline void dec() {
	.loc 1 400 19 view .LVU480
	s32i.n	a0, sp, 12	#,
.LCFI29:
.LBB890:
.LBB887:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU481
	l8ui	a5, a12, 0	# prephitmp_13, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU482
	beqz.n	a5, .L74	# prephitmp_13,
	.loc 1 217 19 is_stmt 1 view .LVU483
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU484
	l32r	a2, .LC82	#, tmp62
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU485
	l8ui	a2, a2, 0	# _27, a
	j	.L75		#
.L74:
.LBB882:
.LBI882:
	.loc 1 216 17 is_stmt 1 view .LVU486
.LBB883:
	.loc 1 218 14 view .LVU487
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU488
	l32r	a2, .LC83	#, tmp65
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL65:
.LBE883:
.LBE882:
.LBE887:
.LBE890:
.LBB891:
.LBB892:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU489
	l8ui	a5, a12, 0	# prephitmp_13, useaccum
.LBE892:
.LBE891:
.LBB902:
.LBB888:
.LBB885:
.LBB884:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU490
	extui	a2, a2, 0, 16	# _27,
.L75:
.LBE884:
.LBE885:
.LBE888:
.LBE902:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU491
	l32r	a4, .LC84	#, tmp69
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU492
	addi.n	a3, a2, -1	# tmp70, _27,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU493
	s16i	a2, a4, 0	# value, _27
	.loc 1 402 5 is_stmt 1 view .LVU494
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 is_stmt 0 view .LVU495
	l32r	a2, .LC85	#, tmp71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU496
	extui	a3, a3, 0, 16	# _2, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:404:     zerocalc(result);
	.loc 1 404 5 view .LVU497
	l32r	a6, .LC86	#, tmp105
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 view .LVU498
	s16i	a3, a2, 0	# result, _2
	.loc 1 404 5 is_stmt 1 view .LVU499
	.loc 1 404 5 view .LVU500
	extui	a4, a3, 0, 8	# tmp75, _2
	l16ui	a2, a6, 0	# cpustatus, pretmp_18
	beqz.n	a4, .L76	# tmp75,
	.loc 1 404 5 discriminator 1 view .LVU501
	movi.n	a4, -3	# tmp76,
	and	a2, a2, a4	# _5, pretmp_18, tmp76
	j	.L77		#
.L76:
	.loc 1 404 5 discriminator 2 view .LVU502
	movi.n	a4, 2	# tmp79,
	or	a2, a2, a4	# _5, pretmp_18, tmp79
.L77:
	.loc 1 404 21 discriminator 4 view .LVU503
	.loc 1 405 5 discriminator 4 view .LVU504
	.loc 1 405 5 discriminator 4 view .LVU505
	movi	a4, 0x80	# tmp80,
	bnone	a3, a4, .L78	# _2, tmp80,
	.loc 1 405 5 discriminator 1 view .LVU506
	or	a2, a2, a4	# tmp85, _5, tmp80
	extui	a2, a2, 0, 16	# cstore_3, tmp85
	j	.L79		#
.L78:
	.loc 1 405 5 discriminator 2 view .LVU507
	movi	a4, -0x81	# tmp86,
	and	a2, a2, a4	# cstore_3, _5, tmp86
.L79:
	s16i	a2, a6, 0	# cpustatus, cstore_3
	.loc 1 405 21 discriminator 4 view .LVU508
	.loc 1 407 5 discriminator 4 view .LVU509
.LVL66:
.LBB903:
.LBI891:
	.loc 1 225 13 discriminator 4 view .LVU510
.LBB901:
	.loc 1 226 5 discriminator 4 view .LVU511
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU512
	extui	a3, a3, 0, 8	# _12, _2
	l32r	a2, .LC82	#, tmp89
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU513
	bnez.n	a5, .L84	# prephitmp_13,
.L80:
.LVL67:
.LBB893:
.LBI893:
	.loc 1 225 13 is_stmt 1 view .LVU514
.LBB894:
	.loc 1 227 14 view .LVU515
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU516
	l32r	a2, .LC83	#, tmp90
.LBB895:
.LBB896:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU517
	l32r	a5, .LC87	#, tmp91
.LBE896:
.LBE895:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU518
	l16ui	a2, a2, 0	# ea, ea$53_40
.LVL68:
.LBB900:
.LBI895:
	.loc 1 90 6 is_stmt 1 view .LVU519
.LBB899:
	.loc 1 91 3 view .LVU520
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU521
	movi	a4, 0x1ff	# tmp93,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU522
	s16i	a2, a5, 0	# last_modified_ram, ea$53_40
	.loc 1 92 3 is_stmt 1 view .LVU523
	bltu	a4, a2, .L82	# tmp93, ea$53_40,
	.loc 1 93 5 view .LVU524
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU525
	l32r	a4, .LC88	#, tmp94
	add.n	a2, a4, a2	# tmp95, tmp94, ea$53_40
	j	.L84		#
.L82:
.LVL69:
.LBB897:
.LBI897:
	.loc 1 90 6 is_stmt 1 view .LVU526
.LBB898:
	.loc 1 96 3 view .LVU527
	l32r	a4, .LC89	#, tmp96
	extui	a4, a4, 0, 16	# tmp97, tmp96
	bltu	a4, a2, .L83	# tmp97, ea$53_40,
	.loc 1 97 5 view .LVU528
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU529
	addmi	a2, a2, -0x200	# tmp98, ea$53_40,
.LVL70:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU530
	extui	a2, a2, 0, 16	#, tmp98
	call0	_Z14drawPixelToRamth		#
.LVL71:
	.loc 1 98 5 is_stmt 1 view .LVU531
	j	.L73		#
.LVL72:
.L83:
	.loc 1 100 3 view .LVU532
	l32r	a4, .LC91	#, tmp100
	extui	a4, a4, 0, 16	# tmp101, tmp100
	bltu	a4, a2, .L73	# tmp101, ea$53_40,
	.loc 1 101 5 view .LVU533
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU534
	l32r	a4, .LC93	#, tmp102
	add.n	a2, a4, a2	# tmp103, tmp102, ea$53_40
.LVL73:
	.loc 1 101 27 view .LVU535
	addmi	a2, a2, -0x1200	# tmp104, tmp103,
.LVL74:
.L84:
	.loc 1 101 27 view .LVU536
	s8i	a3, a2, 0	#, _12
	.loc 1 102 5 is_stmt 1 view .LVU537
.L73:
	.loc 1 102 5 is_stmt 0 view .LVU538
.LBE898:
.LBE897:
.LBE899:
.LBE900:
.LBE894:
.LBE893:
.LBE901:
.LBE903:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:408: }
	.loc 1 408 1 view .LVU539
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE55:
	.size	_Z3decv, .-_Z3decv
	.section	.text._Z3eorv,"axG",@progbits,_Z3eorv,comdat
	.literal_position
	.literal .LC94, useaccum
	.literal .LC95, value
	.literal .LC96, a
	.literal .LC97, result
	.literal .LC98, cpustatus
	.literal .LC99, ea
	.align	4
	.weak	_Z3eorv
	.type	_Z3eorv, @function
_Z3eorv:
.LFB58:
	.loc 1 424 19 is_stmt 1 view -0
	.loc 1 425 5 view .LVU541
.LBB904:
.LBI904:
	.loc 1 216 17 view .LVU542
.LBB905:
	.loc 1 217 5 view .LVU543
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU544
	l32r	a2, .LC94	#, tmp57
.LBE905:
.LBE904:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:424: inline void eor() {
	.loc 1 424 19 view .LVU545
	addi	sp, sp, -16	#,,
.LCFI30:
	s32i.n	a0, sp, 12	#,
.LCFI31:
.LBB920:
.LBB912:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU546
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L86	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU547
.LBE912:
.LBE920:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 is_stmt 0 view .LVU548
	l32r	a6, .LC98	#, tmp88
.LBB921:
.LBB913:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 view .LVU549
	l32r	a5, .LC96	#, tmp89
.LBE913:
.LBE921:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 view .LVU550
	l16ui	a2, a6, 0	# cpustatus,
	movi.n	a3, 2	# tmp65,
.LBB922:
.LBB914:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU551
	l8ui	a4, a5, 0	# a, a
.LBE914:
.LBE922:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 view .LVU552
	or	a2, a2, a3	# tmp67, cpustatus, tmp65
.LBB923:
.LBB915:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU553
	l32r	a3, .LC95	#, tmp59
.LBE915:
.LBE923:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 view .LVU554
	extui	a2, a2, 0, 16	# _6, tmp67
.LBB924:
.LBB916:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU555
	s16i	a4, a3, 0	# value, a
.LBE916:
.LBE924:
	.loc 1 426 5 is_stmt 1 view .LVU556
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:426:     result = (uint16_t)a ^ value;
	.loc 1 426 12 is_stmt 0 view .LVU557
	l32r	a3, .LC97	#, tmp62
	movi.n	a4, 0	# tmp63,
	s16i	a4, a3, 0	# result, tmp63
	.loc 1 428 5 is_stmt 1 view .LVU558
	.loc 1 428 5 view .LVU559
	.loc 1 428 5 view .LVU560
	.loc 1 428 21 view .LVU561
	.loc 1 429 5 view .LVU562
	.loc 1 429 5 view .LVU563
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 is_stmt 0 view .LVU564
	movi.n	a4, 0	# _13,
	j	.L87		#
.L86:
.LBB925:
.LBB917:
.LBB906:
.LBI906:
	.loc 1 216 17 is_stmt 1 view .LVU565
.LBB907:
	.loc 1 218 14 view .LVU566
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU567
	l32r	a2, .LC99	#, tmp68
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL75:
.LBE907:
.LBE906:
.LBE917:
.LBE925:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:426:     result = (uint16_t)a ^ value;
	.loc 1 426 26 view .LVU568
	l32r	a5, .LC96	#, tmp89
.LBB926:
.LBB918:
.LBB910:
.LBB908:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU569
	l32r	a3, .LC95	#, tmp73
.LBE908:
.LBE910:
.LBE918:
.LBE926:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:426:     result = (uint16_t)a ^ value;
	.loc 1 426 26 view .LVU570
	l8ui	a7, a5, 0	# pretmp_15, a
.LBB927:
.LBB919:
.LBB911:
.LBB909:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU571
	s16i	a2, a3, 0	# value, tmp70
.LBE909:
.LBE911:
.LBE919:
.LBE927:
	.loc 1 426 5 is_stmt 1 view .LVU572
	xor	a4, a7, a2	# tmp72, pretmp_15, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:426:     result = (uint16_t)a ^ value;
	.loc 1 426 26 is_stmt 0 view .LVU573
	l32r	a3, .LC97	#, tmp74
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:428:     zerocalc(result);
	.loc 1 428 5 view .LVU574
	l32r	a6, .LC98	#, tmp88
	extui	a4, a4, 0, 8	# _13, tmp72
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:426:     result = (uint16_t)a ^ value;
	.loc 1 426 26 view .LVU575
	s16i	a4, a3, 0	# result, _13
	.loc 1 428 5 is_stmt 1 view .LVU576
	.loc 1 428 5 view .LVU577
	l16ui	a3, a6, 0	# cpustatus, pretmp_42
	beq	a7, a2, .L88	# pretmp_15, tmp70,
	.loc 1 428 5 discriminator 1 view .LVU578
	movi.n	a2, -3	# tmp76,
	and	a2, a3, a2	# _6, pretmp_42, tmp76
	j	.L89		#
.L88:
	.loc 1 428 5 discriminator 2 view .LVU579
	movi.n	a2, 2	# tmp79,
	or	a2, a3, a2	# _6, pretmp_42, tmp79
.L89:
	.loc 1 428 21 discriminator 4 view .LVU580
	.loc 1 429 5 discriminator 4 view .LVU581
	.loc 1 429 5 discriminator 4 view .LVU582
	slli	a3, a4, 24	# tmp81, _13,
	bgez	a3, .L87	# tmp81,
	.loc 1 429 5 discriminator 1 view .LVU583
	movi	a3, 0x80	# tmp83,
	or	a2, a2, a3	# _10, _6, tmp83
	j	.L90		#
.L87:
	.loc 1 429 5 discriminator 2 view .LVU584
	movi	a3, -0x81	# tmp84,
	and	a2, a2, a3	# _10, _6, tmp84
.L90:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:431:     saveaccum(result);
	.loc 1 431 5 is_stmt 0 discriminator 4 view .LVU585
	s8i	a4, a5, 0	# a, _13
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:432: }
	.loc 1 432 1 discriminator 4 view .LVU586
	l32i.n	a0, sp, 12	#,
	s16i	a2, a6, 0	# cpustatus, _10
	.loc 1 429 21 is_stmt 1 discriminator 4 view .LVU587
	.loc 1 431 5 discriminator 4 view .LVU588
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:432: }
	.loc 1 432 1 is_stmt 0 discriminator 4 view .LVU589
	addi	sp, sp, 16	#,,
	ret.n	
.LFE58:
	.size	_Z3eorv, .-_Z3eorv
	.section	.text._Z3incv,"axG",@progbits,_Z3incv,comdat
	.literal_position
	.literal .LC100, useaccum
	.literal .LC101, a
	.literal .LC102, ea
	.literal .LC103, value
	.literal .LC104, result
	.literal .LC105, cpustatus
	.literal .LC106, last_modified_ram
	.literal .LC107, zero_ram
	.literal .LC108, 4607
	.literal .LC110, 20991
	.literal .LC112, RAM
	.align	4
	.weak	_Z3incv
	.type	_Z3incv, @function
_Z3incv:
.LFB59:
	.loc 1 434 19 is_stmt 1 view -0
	.loc 1 435 5 view .LVU591
.LBB928:
.LBI928:
	.loc 1 216 17 view .LVU592
.LBB929:
	.loc 1 217 5 view .LVU593
.LBE929:
.LBE928:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:434: inline void inc() {
	.loc 1 434 19 is_stmt 0 view .LVU594
	addi	sp, sp, -16	#,,
.LCFI32:
	s32i.n	a12, sp, 8	#,
.LCFI33:
.LBB937:
.LBB934:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU595
	l32r	a12, .LC100	#, tmp61
.LBE934:
.LBE937:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:434: inline void inc() {
	.loc 1 434 19 view .LVU596
	s32i.n	a0, sp, 12	#,
.LCFI34:
.LBB938:
.LBB935:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU597
	l8ui	a5, a12, 0	# prephitmp_13, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU598
	beqz.n	a5, .L92	# prephitmp_13,
	.loc 1 217 19 is_stmt 1 view .LVU599
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU600
	l32r	a2, .LC101	#, tmp62
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU601
	l8ui	a2, a2, 0	# _27, a
	j	.L93		#
.L92:
.LBB930:
.LBI930:
	.loc 1 216 17 is_stmt 1 view .LVU602
.LBB931:
	.loc 1 218 14 view .LVU603
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU604
	l32r	a2, .LC102	#, tmp65
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL76:
.LBE931:
.LBE930:
.LBE935:
.LBE938:
.LBB939:
.LBB940:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU605
	l8ui	a5, a12, 0	# prephitmp_13, useaccum
.LBE940:
.LBE939:
.LBB950:
.LBB936:
.LBB933:
.LBB932:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU606
	extui	a2, a2, 0, 16	# _27,
.L93:
.LBE932:
.LBE933:
.LBE936:
.LBE950:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU607
	l32r	a4, .LC103	#, tmp69
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU608
	addi.n	a3, a2, 1	# tmp70, _27,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU609
	s16i	a2, a4, 0	# value, _27
	.loc 1 436 5 is_stmt 1 view .LVU610
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 is_stmt 0 view .LVU611
	l32r	a2, .LC104	#, tmp71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU612
	extui	a3, a3, 0, 16	# _2, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:438:     zerocalc(result);
	.loc 1 438 5 view .LVU613
	l32r	a6, .LC105	#, tmp105
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 view .LVU614
	s16i	a3, a2, 0	# result, _2
	.loc 1 438 5 is_stmt 1 view .LVU615
	.loc 1 438 5 view .LVU616
	extui	a4, a3, 0, 8	# tmp75, _2
	l16ui	a2, a6, 0	# cpustatus, pretmp_18
	beqz.n	a4, .L94	# tmp75,
	.loc 1 438 5 discriminator 1 view .LVU617
	movi.n	a4, -3	# tmp76,
	and	a2, a2, a4	# _5, pretmp_18, tmp76
	j	.L95		#
.L94:
	.loc 1 438 5 discriminator 2 view .LVU618
	movi.n	a4, 2	# tmp79,
	or	a2, a2, a4	# _5, pretmp_18, tmp79
.L95:
	.loc 1 438 21 discriminator 4 view .LVU619
	.loc 1 439 5 discriminator 4 view .LVU620
	.loc 1 439 5 discriminator 4 view .LVU621
	movi	a4, 0x80	# tmp80,
	bnone	a3, a4, .L96	# _2, tmp80,
	.loc 1 439 5 discriminator 1 view .LVU622
	or	a2, a2, a4	# tmp85, _5, tmp80
	extui	a2, a2, 0, 16	# cstore_3, tmp85
	j	.L97		#
.L96:
	.loc 1 439 5 discriminator 2 view .LVU623
	movi	a4, -0x81	# tmp86,
	and	a2, a2, a4	# cstore_3, _5, tmp86
.L97:
	s16i	a2, a6, 0	# cpustatus, cstore_3
	.loc 1 439 21 discriminator 4 view .LVU624
	.loc 1 441 5 discriminator 4 view .LVU625
.LVL77:
.LBB951:
.LBI939:
	.loc 1 225 13 discriminator 4 view .LVU626
.LBB949:
	.loc 1 226 5 discriminator 4 view .LVU627
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU628
	extui	a3, a3, 0, 8	# _12, _2
	l32r	a2, .LC101	#, tmp89
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU629
	bnez.n	a5, .L102	# prephitmp_13,
.L98:
.LVL78:
.LBB941:
.LBI941:
	.loc 1 225 13 is_stmt 1 view .LVU630
.LBB942:
	.loc 1 227 14 view .LVU631
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU632
	l32r	a2, .LC102	#, tmp90
.LBB943:
.LBB944:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU633
	l32r	a5, .LC106	#, tmp91
.LBE944:
.LBE943:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU634
	l16ui	a2, a2, 0	# ea, ea$53_40
.LVL79:
.LBB948:
.LBI943:
	.loc 1 90 6 is_stmt 1 view .LVU635
.LBB947:
	.loc 1 91 3 view .LVU636
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU637
	movi	a4, 0x1ff	# tmp93,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU638
	s16i	a2, a5, 0	# last_modified_ram, ea$53_40
	.loc 1 92 3 is_stmt 1 view .LVU639
	bltu	a4, a2, .L100	# tmp93, ea$53_40,
	.loc 1 93 5 view .LVU640
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU641
	l32r	a4, .LC107	#, tmp94
	add.n	a2, a4, a2	# tmp95, tmp94, ea$53_40
	j	.L102		#
.L100:
.LVL80:
.LBB945:
.LBI945:
	.loc 1 90 6 is_stmt 1 view .LVU642
.LBB946:
	.loc 1 96 3 view .LVU643
	l32r	a4, .LC108	#, tmp96
	extui	a4, a4, 0, 16	# tmp97, tmp96
	bltu	a4, a2, .L101	# tmp97, ea$53_40,
	.loc 1 97 5 view .LVU644
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU645
	addmi	a2, a2, -0x200	# tmp98, ea$53_40,
.LVL81:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU646
	extui	a2, a2, 0, 16	#, tmp98
	call0	_Z14drawPixelToRamth		#
.LVL82:
	.loc 1 98 5 is_stmt 1 view .LVU647
	j	.L91		#
.LVL83:
.L101:
	.loc 1 100 3 view .LVU648
	l32r	a4, .LC110	#, tmp100
	extui	a4, a4, 0, 16	# tmp101, tmp100
	bltu	a4, a2, .L91	# tmp101, ea$53_40,
	.loc 1 101 5 view .LVU649
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU650
	l32r	a4, .LC112	#, tmp102
	add.n	a2, a4, a2	# tmp103, tmp102, ea$53_40
.LVL84:
	.loc 1 101 27 view .LVU651
	addmi	a2, a2, -0x1200	# tmp104, tmp103,
.LVL85:
.L102:
	.loc 1 101 27 view .LVU652
	s8i	a3, a2, 0	#, _12
	.loc 1 102 5 is_stmt 1 view .LVU653
.L91:
	.loc 1 102 5 is_stmt 0 view .LVU654
.LBE946:
.LBE945:
.LBE947:
.LBE948:
.LBE942:
.LBE941:
.LBE949:
.LBE951:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:442: }
	.loc 1 442 1 view .LVU655
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE59:
	.size	_Z3incv, .-_Z3incv
	.section	.text._Z3ldav,"axG",@progbits,_Z3ldav,comdat
	.literal_position
	.literal .LC113, useaccum
	.literal .LC114, a
	.literal .LC115, ea
	.literal .LC116, value
	.literal .LC117, cpustatus
	.align	4
	.weak	_Z3ldav
	.type	_Z3ldav, @function
_Z3ldav:
.LFB64:
	.loc 1 467 19 is_stmt 1 view -0
	.loc 1 468 5 view .LVU657
.LBB952:
.LBI952:
	.loc 1 216 17 view .LVU658
.LBB953:
	.loc 1 217 5 view .LVU659
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU660
	l32r	a2, .LC113	#, tmp51
.LBE953:
.LBE952:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:467: inline void lda() {
	.loc 1 467 19 view .LVU661
	addi	sp, sp, -16	#,,
.LCFI35:
	s32i.n	a0, sp, 12	#,
.LCFI36:
.LBB957:
.LBB956:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU662
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L104	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU663
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU664
	l32r	a3, .LC114	#, tmp72
	l8ui	a2, a3, 0	# prephitmp_20, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU665
	mov.n	a4, a2	# _24, prephitmp_20
	j	.L105		#
.L104:
.LBB954:
.LBI954:
	.loc 1 216 17 is_stmt 1 view .LVU666
.LBB955:
	.loc 1 218 14 view .LVU667
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU668
	l32r	a2, .LC115	#, tmp54
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL86:
	l32r	a3, .LC114	#, tmp72
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU669
	extui	a4, a2, 0, 16	# _24, prephitmp_20
.L105:
.LBE955:
.LBE954:
.LBE956:
.LBE957:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:468:     value = getvalue();
	.loc 1 468 11 view .LVU670
	l32r	a6, .LC116	#, tmp57
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:471:     zerocalc(a);
	.loc 1 471 5 view .LVU671
	l32r	a5, .LC117	#, tmp73
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:469:     a = (uint8_t)(value & 0x00FF);
	.loc 1 469 7 view .LVU672
	s8i	a2, a3, 0	# a, prephitmp_20
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:468:     value = getvalue();
	.loc 1 468 11 view .LVU673
	s16i	a4, a6, 0	# value, _24
	.loc 1 469 5 is_stmt 1 view .LVU674
	.loc 1 471 5 view .LVU675
	.loc 1 471 5 view .LVU676
	l16ui	a3, a5, 0	# cpustatus, pretmp_19
	beqz.n	a4, .L106	# _24,
	.loc 1 471 5 discriminator 1 view .LVU677
	movi.n	a2, -3	# tmp60,
	and	a3, a3, a2	# _6, pretmp_19, tmp60
	.loc 1 471 16 discriminator 1 view .LVU678
	.loc 1 472 5 discriminator 1 view .LVU679
	.loc 1 472 5 discriminator 1 view .LVU680
	movi	a2, 0x80	# tmp68,
	or	a2, a3, a2	# cstore_1, _6, tmp68
	bbsi	a4, 7, .L109	# _24,,
	j	.L108		#
.L106:
	.loc 1 471 5 discriminator 2 view .LVU681
	movi.n	a2, 2	# tmp66,
	or	a3, a3, a2	# _6, pretmp_19, tmp66
	.loc 1 471 16 discriminator 2 view .LVU682
	.loc 1 472 5 discriminator 2 view .LVU683
	.loc 1 472 5 discriminator 2 view .LVU684
.L108:
	.loc 1 472 5 discriminator 2 view .LVU685
	movi	a2, -0x81	# tmp69,
	and	a2, a3, a2	# cstore_1, _6, tmp69
.L109:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:473: }
	.loc 1 473 1 is_stmt 0 discriminator 4 view .LVU686
	l32i.n	a0, sp, 12	#,
	s16i	a2, a5, 0	# cpustatus, cstore_1
	.loc 1 472 16 is_stmt 1 discriminator 4 view .LVU687
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:473: }
	.loc 1 473 1 is_stmt 0 discriminator 4 view .LVU688
	addi	sp, sp, 16	#,,
	ret.n	
.LFE64:
	.size	_Z3ldav, .-_Z3ldav
	.section	.text._Z3lsrv,"axG",@progbits,_Z3lsrv,comdat
	.literal_position
	.literal .LC118, useaccum
	.literal .LC119, a
	.literal .LC120, ea
	.literal .LC121, value
	.literal .LC122, result
	.literal .LC123, cpustatus
	.literal .LC124, last_modified_ram
	.literal .LC125, zero_ram
	.literal .LC126, 4607
	.literal .LC128, 20991
	.literal .LC130, RAM
	.align	4
	.weak	_Z3lsrv
	.type	_Z3lsrv, @function
_Z3lsrv:
.LFB67:
	.loc 1 491 19 is_stmt 1 view -0
	.loc 1 492 5 view .LVU690
.LBB958:
.LBI958:
	.loc 1 216 17 view .LVU691
.LBB959:
	.loc 1 217 5 view .LVU692
.LBE959:
.LBE958:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:491: inline void lsr() {
	.loc 1 491 19 is_stmt 0 view .LVU693
	addi	sp, sp, -16	#,,
.LCFI37:
	s32i.n	a12, sp, 8	#,
.LCFI38:
.LBB967:
.LBB964:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU694
	l32r	a12, .LC118	#, tmp61
.LBE964:
.LBE967:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:491: inline void lsr() {
	.loc 1 491 19 view .LVU695
	s32i.n	a0, sp, 12	#,
.LCFI39:
.LBB968:
.LBB965:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU696
	l8ui	a5, a12, 0	# prephitmp_8, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU697
	beqz.n	a5, .L111	# prephitmp_8,
	.loc 1 217 19 is_stmt 1 view .LVU698
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU699
	l32r	a2, .LC119	#, tmp62
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU700
	l8ui	a2, a2, 0	# _35, a
	j	.L112		#
.L111:
.LBB960:
.LBI960:
	.loc 1 216 17 is_stmt 1 view .LVU701
.LBB961:
	.loc 1 218 14 view .LVU702
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU703
	l32r	a2, .LC120	#, tmp65
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL87:
.LBE961:
.LBE960:
.LBE965:
.LBE968:
.LBB969:
.LBB970:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU704
	l8ui	a5, a12, 0	# prephitmp_8, useaccum
.LBE970:
.LBE969:
.LBB980:
.LBB966:
.LBB963:
.LBB962:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU705
	extui	a2, a2, 0, 16	# _35,
.L112:
.LBE962:
.LBE963:
.LBE966:
.LBE980:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:492:     value = getvalue();
	.loc 1 492 11 view .LVU706
	l32r	a4, .LC121	#, tmp69
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:495:     if (value & 1) setcarry();
	.loc 1 495 20 view .LVU707
	l32r	a6, .LC123	#, tmp103
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:492:     value = getvalue();
	.loc 1 492 11 view .LVU708
	s16i	a2, a4, 0	# value, _35
	.loc 1 493 5 is_stmt 1 view .LVU709
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:493:     result = value >> 1;
	.loc 1 493 12 is_stmt 0 view .LVU710
	l32r	a4, .LC122	#, tmp71
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:493:     result = value >> 1;
	.loc 1 493 20 view .LVU711
	srli	a3, a2, 1	# _2, _35,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:493:     result = value >> 1;
	.loc 1 493 12 view .LVU712
	s16i	a3, a4, 0	# result, _2
	.loc 1 495 5 is_stmt 1 view .LVU713
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:495:     if (value & 1) setcarry();
	.loc 1 495 20 is_stmt 0 view .LVU714
	l16ui	a4, a6, 0	# cpustatus, pretmp_17
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:495:     if (value & 1) setcarry();
	.loc 1 495 5 view .LVU715
	bbci	a2, 0, .L113	# _35,,
	.loc 1 495 20 is_stmt 1 discriminator 1 view .LVU716
	movi.n	a2, 1	# tmp77,
	or	a4, a4, a2	# _4, pretmp_17, tmp77
	j	.L114		#
.L113:
	.loc 1 496 14 view .LVU717
	movi.n	a2, -2	# tmp78,
	and	a4, a4, a2	# _4, pretmp_17, tmp78
.L114:
	.loc 1 497 5 view .LVU718
	.loc 1 497 5 view .LVU719
	beqz.n	a3, .L115	# _2,
	.loc 1 497 5 discriminator 1 view .LVU720
	movi.n	a2, -3	# tmp80,
	and	a4, a4, a2	# cstore_7, _4, tmp80
	j	.L116		#
.L115:
	.loc 1 497 5 discriminator 2 view .LVU721
	movi.n	a2, 2	# tmp83,
	or	a4, a4, a2	# cstore_7, _4, tmp83
.L116:
	.loc 1 497 21 discriminator 4 view .LVU722
	.loc 1 498 5 discriminator 4 view .LVU723
	.loc 1 498 5 discriminator 4 view .LVU724
	.loc 1 498 5 discriminator 4 view .LVU725
	movi	a2, -0x81	# tmp85,
	and	a4, a4, a2	# tmp86, cstore_7, tmp85
	s16i	a4, a6, 0	# cpustatus, tmp86
	.loc 1 498 21 discriminator 4 view .LVU726
	.loc 1 500 5 discriminator 4 view .LVU727
.LVL88:
.LBB981:
.LBI969:
	.loc 1 225 13 discriminator 4 view .LVU728
.LBB979:
	.loc 1 226 5 discriminator 4 view .LVU729
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU730
	extui	a2, a3, 0, 8	# _14, _2
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU731
	beqz.n	a5, .L117	# prephitmp_8,
	.loc 1 226 19 is_stmt 1 view .LVU732
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU733
	l32r	a3, .LC119	#, tmp87
.LVL89:
	.loc 1 226 21 view .LVU734
	s8i	a2, a3, 0	# a, _14
	j	.L110		#
.LVL90:
.L117:
.LBB971:
.LBI971:
	.loc 1 225 13 is_stmt 1 view .LVU735
.LBB972:
	.loc 1 227 14 view .LVU736
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU737
	l32r	a4, .LC120	#, tmp88
.LBB973:
.LBB974:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU738
	l32r	a6, .LC124	#, tmp89
.LBE974:
.LBE973:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU739
	l16ui	a4, a4, 0	# ea, ea$53_48
.LVL91:
.LBB978:
.LBI973:
	.loc 1 90 6 is_stmt 1 view .LVU740
.LBB977:
	.loc 1 91 3 view .LVU741
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU742
	movi	a5, 0x1ff	# tmp91,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU743
	s16i	a4, a6, 0	# last_modified_ram, ea$53_48
	.loc 1 92 3 is_stmt 1 view .LVU744
	bltu	a5, a4, .L119	# tmp91, ea$53_48,
	.loc 1 93 5 view .LVU745
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU746
	l32r	a3, .LC125	#, tmp92
.LVL92:
	.loc 1 93 23 view .LVU747
	add.n	a4, a3, a4	# tmp93, tmp92, ea$53_48
	j	.L121		#
.LVL93:
.L119:
.LBB975:
.LBI975:
	.loc 1 90 6 is_stmt 1 view .LVU748
.LBB976:
	.loc 1 96 3 view .LVU749
	l32r	a5, .LC126	#, tmp94
	extui	a5, a5, 0, 16	# tmp95, tmp94
	bltu	a5, a4, .L120	# tmp95, ea$53_48,
	.loc 1 97 5 view .LVU750
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU751
	addmi	a2, a4, -0x200	# tmp96, ea$53_48,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU752
	extui	a2, a2, 0, 16	#, tmp96
	call0	_Z14drawPixelToRamth		#
.LVL94:
	.loc 1 98 5 is_stmt 1 view .LVU753
	j	.L110		#
.LVL95:
.L120:
	.loc 1 100 3 view .LVU754
	l32r	a3, .LC128	#, tmp98
.LVL96:
	.loc 1 100 3 is_stmt 0 view .LVU755
	extui	a3, a3, 0, 16	# tmp99, tmp98
	bltu	a3, a4, .L110	# tmp99, ea$53_48,
	.loc 1 101 5 is_stmt 1 view .LVU756
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU757
	l32r	a3, .LC130	#, tmp100
	add.n	a4, a3, a4	# tmp101, tmp100, ea$53_48
.LVL97:
	.loc 1 101 27 view .LVU758
	addmi	a4, a4, -0x1200	# tmp102, tmp101,
.LVL98:
.L121:
	.loc 1 101 27 view .LVU759
	s8i	a2, a4, 0	#, _14
.LVL99:
	.loc 1 102 5 is_stmt 1 view .LVU760
.L110:
	.loc 1 102 5 is_stmt 0 view .LVU761
.LBE976:
.LBE975:
.LBE977:
.LBE978:
.LBE972:
.LBE971:
.LBE979:
.LBE981:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:501: }
	.loc 1 501 1 view .LVU762
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE67:
	.size	_Z3lsrv, .-_Z3lsrv
	.section	.text._Z3orav,"axG",@progbits,_Z3orav,comdat
	.literal_position
	.literal .LC131, useaccum
	.literal .LC132, a
	.literal .LC133, ea
	.literal .LC134, value
	.literal .LC135, result
	.literal .LC136, cpustatus
	.align	4
	.weak	_Z3orav
	.type	_Z3orav, @function
_Z3orav:
.LFB69:
	.loc 1 506 19 is_stmt 1 view -0
	.loc 1 507 5 view .LVU764
.LBB982:
.LBI982:
	.loc 1 216 17 view .LVU765
.LBB983:
	.loc 1 217 5 view .LVU766
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU767
	l32r	a2, .LC131	#, tmp54
.LBE983:
.LBE982:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:506: inline void ora() {
	.loc 1 506 19 view .LVU768
	addi	sp, sp, -16	#,,
.LCFI40:
	s32i.n	a0, sp, 12	#,
.LCFI41:
.LBB990:
.LBB988:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU769
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L123	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU770
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU771
	l32r	a5, .LC132	#, tmp82
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU772
	l8ui	a3, a5, 0	# _29, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 view .LVU773
	mov.n	a7, a3	# a$39_28, _29
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU774
	mov.n	a2, a3	# _30, _29
	j	.L124		#
.L123:
.LBB984:
.LBI984:
	.loc 1 216 17 is_stmt 1 view .LVU775
.LBB985:
	.loc 1 218 14 view .LVU776
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU777
	l32r	a2, .LC133	#, tmp57
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL100:
.LBE985:
.LBE984:
.LBE988:
.LBE990:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:508:     result = (uint16_t)a | value;
	.loc 1 508 26 view .LVU778
	l32r	a5, .LC132	#, tmp82
.LBB991:
.LBB989:
.LBB987:
.LBB986:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU779
	extui	a3, a2, 0, 16	# _29, tmp59
	l8ui	a4, a5, 0	#, a
	or	a2, a2, a4	# tmp62, tmp59, a
	extui	a7, a2, 0, 8	# a$39_28, tmp62
.LBE986:
.LBE987:
.LBE989:
.LBE991:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:508:     result = (uint16_t)a | value;
	.loc 1 508 26 view .LVU780
	mov.n	a2, a7	# _30, a$39_28
.L124:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:507:     value = getvalue();
	.loc 1 507 11 view .LVU781
	l32r	a4, .LC134	#, tmp63
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:510:     zerocalc(result);
	.loc 1 510 5 view .LVU782
	l32r	a6, .LC136	#, tmp81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:507:     value = getvalue();
	.loc 1 507 11 view .LVU783
	s16i	a3, a4, 0	# value, _29
	.loc 1 508 5 is_stmt 1 view .LVU784
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:508:     result = (uint16_t)a | value;
	.loc 1 508 12 is_stmt 0 view .LVU785
	l32r	a3, .LC135	#, tmp64
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:510:     zerocalc(result);
	.loc 1 510 5 view .LVU786
	l16ui	a4, a6, 0	# cpustatus, pretmp_45
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:508:     result = (uint16_t)a | value;
	.loc 1 508 12 view .LVU787
	s16i	a2, a3, 0	# result, _30
	.loc 1 510 5 is_stmt 1 view .LVU788
	.loc 1 510 5 view .LVU789
	beqz.n	a2, .L125	# _30,
	.loc 1 510 5 discriminator 1 view .LVU790
	movi.n	a3, -3	# tmp66,
	and	a4, a4, a3	# _8, pretmp_45, tmp66
	.loc 1 510 21 discriminator 1 view .LVU791
	.loc 1 511 5 discriminator 1 view .LVU792
	.loc 1 511 5 discriminator 1 view .LVU793
	movi	a8, 0x80	# tmp69,
	or	a3, a4, a8	# tmp76, _8, tmp69
	extui	a3, a3, 0, 16	# _10, tmp76
	bany	a2, a8, .L128	# _30, tmp69,
	j	.L127		#
.L125:
	.loc 1 510 5 discriminator 2 view .LVU794
	movi.n	a2, 2	# tmp74,
	or	a4, a4, a2	# _8, pretmp_45, tmp74
	.loc 1 510 21 discriminator 2 view .LVU795
	.loc 1 511 5 discriminator 2 view .LVU796
	.loc 1 511 5 discriminator 2 view .LVU797
.L127:
	.loc 1 511 5 discriminator 2 view .LVU798
	movi	a3, -0x81	# tmp77,
	and	a3, a4, a3	# _10, _8, tmp77
.L128:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:513:     saveaccum(result);
	.loc 1 513 5 is_stmt 0 discriminator 4 view .LVU799
	s8i	a7, a5, 0	# a, a$39_28
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:514: }
	.loc 1 514 1 discriminator 4 view .LVU800
	l32i.n	a0, sp, 12	#,
	s16i	a3, a6, 0	# cpustatus, _10
	.loc 1 511 21 is_stmt 1 discriminator 4 view .LVU801
	.loc 1 513 5 discriminator 4 view .LVU802
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:514: }
	.loc 1 514 1 is_stmt 0 discriminator 4 view .LVU803
	addi	sp, sp, 16	#,,
	ret.n	
.LFE69:
	.size	_Z3orav, .-_Z3orav
	.section	.text._Z3rolv,"axG",@progbits,_Z3rolv,comdat
	.literal_position
	.literal .LC137, useaccum
	.literal .LC138, a
	.literal .LC139, ea
	.literal .LC140, value
	.literal .LC141, cpustatus
	.literal .LC142, result
	.literal .LC143, last_modified_ram
	.literal .LC144, zero_ram
	.literal .LC145, 4607
	.literal .LC147, 20991
	.literal .LC149, RAM
	.align	4
	.weak	_Z3rolv
	.type	_Z3rolv, @function
_Z3rolv:
.LFB74:
	.loc 1 535 19 is_stmt 1 view -0
	.loc 1 536 5 view .LVU805
.LBB992:
.LBI992:
	.loc 1 216 17 view .LVU806
.LBB993:
	.loc 1 217 5 view .LVU807
.LBE993:
.LBE992:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:535: inline void rol() {
	.loc 1 535 19 is_stmt 0 view .LVU808
	addi	sp, sp, -16	#,,
.LCFI42:
	s32i.n	a12, sp, 8	#,
.LCFI43:
.LBB1001:
.LBB998:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU809
	l32r	a12, .LC137	#, tmp69
.LBE998:
.LBE1001:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:535: inline void rol() {
	.loc 1 535 19 view .LVU810
	s32i.n	a0, sp, 12	#,
.LCFI44:
.LBB1002:
.LBB999:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU811
	l8ui	a5, a12, 0	# useaccum$38_38, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU812
	beqz.n	a5, .L130	# useaccum$38_38,
	.loc 1 217 19 is_stmt 1 view .LVU813
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU814
	l32r	a2, .LC138	#, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU815
	l8ui	a2, a2, 0	# _40, a
	j	.L131		#
.L130:
.LBB994:
.LBI994:
	.loc 1 216 17 is_stmt 1 view .LVU816
.LBB995:
	.loc 1 218 14 view .LVU817
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU818
	l32r	a2, .LC139	#, tmp73
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL101:
.LBE995:
.LBE994:
.LBE999:
.LBE1002:
.LBB1003:
.LBB1004:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU819
	l8ui	a5, a12, 0	# useaccum$38_38, useaccum
.LBE1004:
.LBE1003:
.LBB1014:
.LBB1000:
.LBB997:
.LBB996:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU820
	extui	a2, a2, 0, 16	# _40,
.L131:
.LBE996:
.LBE997:
.LBE1000:
.LBE1014:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 40 view .LVU821
	l32r	a6, .LC141	#, tmp127
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 21 view .LVU822
	add.n	a3, a2, a2	# tmp79, _40
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 40 view .LVU823
	l16ui	a4, a6, 0	# cpustatus, cpustatus$85_5
	extui	a7, a4, 0, 1	# tmp81, cpustatus$85_5,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 27 view .LVU824
	or	a3, a3, a7	# tmp84, tmp79, tmp81
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:536:     value = getvalue();
	.loc 1 536 11 view .LVU825
	l32r	a7, .LC140	#, tmp77
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 27 view .LVU826
	slli	a3, a3, 16	# tmp85, tmp84,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:536:     value = getvalue();
	.loc 1 536 11 view .LVU827
	s16i	a2, a7, 0	# value, _40
	.loc 1 537 5 is_stmt 1 view .LVU828
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 12 is_stmt 0 view .LVU829
	l32r	a2, .LC142	#, tmp86
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 27 view .LVU830
	extui	a8, a3, 16, 16	# _9, tmp85,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 12 view .LVU831
	s16i	a8, a2, 0	# result, _9
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:539:     carrycalc(result);
	.loc 1 539 5 view .LVU832
	movi	a2, -0x100	# tmp87,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:537:     result = (value << 1) | (cpustatus & FLAG_CARRY);
	.loc 1 537 27 view .LVU833
	srai	a3, a3, 16	# _8, tmp85,
	.loc 1 539 5 is_stmt 1 view .LVU834
	.loc 1 539 5 view .LVU835
	bnone	a8, a2, .L132	# _9, tmp87,
	.loc 1 539 5 discriminator 1 view .LVU836
	movi.n	a2, 1	# tmp92,
	or	a4, a4, a2	# _11, cpustatus$85_5, tmp92
	j	.L133		#
.L132:
	.loc 1 539 5 discriminator 2 view .LVU837
	movi.n	a2, -2	# tmp93,
	and	a4, a4, a2	# _11, cpustatus$85_5, tmp93
.L133:
	.loc 1 539 22 discriminator 4 view .LVU838
	.loc 1 540 5 discriminator 4 view .LVU839
	.loc 1 540 5 discriminator 4 view .LVU840
	extui	a2, a8, 0, 8	# tmp97, _9
	beqz.n	a2, .L134	# tmp97,
	.loc 1 540 5 discriminator 1 view .LVU841
	movi.n	a2, -3	# tmp98,
	and	a4, a4, a2	# _14, _11, tmp98
	j	.L135		#
.L134:
	.loc 1 540 5 discriminator 2 view .LVU842
	movi.n	a2, 2	# tmp101,
	or	a4, a4, a2	# _14, _11, tmp101
.L135:
	.loc 1 540 21 discriminator 4 view .LVU843
	.loc 1 541 5 discriminator 4 view .LVU844
	.loc 1 541 5 discriminator 4 view .LVU845
	movi	a2, 0x80	# tmp102,
	bnone	a8, a2, .L136	# _9, tmp102,
	.loc 1 541 5 discriminator 1 view .LVU846
	or	a4, a4, a2	# tmp107, _14, tmp102
	extui	a4, a4, 0, 16	# cstore_10, tmp107
	j	.L137		#
.L136:
	.loc 1 541 5 discriminator 2 view .LVU847
	movi	a2, -0x81	# tmp108,
	and	a4, a4, a2	# cstore_10, _14, tmp108
.L137:
	s16i	a4, a6, 0	# cpustatus, cstore_10
	.loc 1 541 21 discriminator 4 view .LVU848
	.loc 1 543 5 discriminator 4 view .LVU849
.LVL102:
.LBB1015:
.LBI1003:
	.loc 1 225 13 discriminator 4 view .LVU850
.LBB1013:
	.loc 1 226 5 discriminator 4 view .LVU851
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU852
	l32r	a2, .LC138	#, tmp111
	extui	a3, a3, 0, 8	# _58, _8
.LVL103:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU853
	bnez.n	a5, .L142	# useaccum$38_38,
.L138:
.LVL104:
.LBB1005:
.LBI1005:
	.loc 1 225 13 is_stmt 1 view .LVU854
.LBB1006:
	.loc 1 227 14 view .LVU855
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU856
	l32r	a2, .LC139	#, tmp112
.LBB1007:
.LBB1008:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU857
	l32r	a5, .LC143	#, tmp113
.LBE1008:
.LBE1007:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU858
	l16ui	a2, a2, 0	# ea, ea$53_53
.LVL105:
.LBB1012:
.LBI1007:
	.loc 1 90 6 is_stmt 1 view .LVU859
.LBB1011:
	.loc 1 91 3 view .LVU860
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU861
	movi	a4, 0x1ff	# tmp115,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU862
	s16i	a2, a5, 0	# last_modified_ram, ea$53_53
	.loc 1 92 3 is_stmt 1 view .LVU863
	bltu	a4, a2, .L140	# tmp115, ea$53_53,
	.loc 1 93 5 view .LVU864
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU865
	l32r	a4, .LC144	#, tmp116
	add.n	a2, a4, a2	# tmp117, tmp116, ea$53_53
	j	.L142		#
.L140:
.LVL106:
.LBB1009:
.LBI1009:
	.loc 1 90 6 is_stmt 1 view .LVU866
.LBB1010:
	.loc 1 96 3 view .LVU867
	l32r	a4, .LC145	#, tmp118
	extui	a4, a4, 0, 16	# tmp119, tmp118
	bltu	a4, a2, .L141	# tmp119, ea$53_53,
	.loc 1 97 5 view .LVU868
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU869
	addmi	a2, a2, -0x200	# tmp120, ea$53_53,
.LVL107:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU870
	extui	a2, a2, 0, 16	#, tmp120
	call0	_Z14drawPixelToRamth		#
.LVL108:
	.loc 1 98 5 is_stmt 1 view .LVU871
	j	.L129		#
.LVL109:
.L141:
	.loc 1 100 3 view .LVU872
	l32r	a4, .LC147	#, tmp122
	extui	a4, a4, 0, 16	# tmp123, tmp122
	bltu	a4, a2, .L129	# tmp123, ea$53_53,
	.loc 1 101 5 view .LVU873
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU874
	l32r	a4, .LC149	#, tmp124
	add.n	a2, a4, a2	# tmp125, tmp124, ea$53_53
.LVL110:
	.loc 1 101 27 view .LVU875
	addmi	a2, a2, -0x1200	# tmp126, tmp125,
.LVL111:
.L142:
	.loc 1 101 27 view .LVU876
	s8i	a3, a2, 0	#, _58
	.loc 1 102 5 is_stmt 1 view .LVU877
.L129:
	.loc 1 102 5 is_stmt 0 view .LVU878
.LBE1010:
.LBE1009:
.LBE1011:
.LBE1012:
.LBE1006:
.LBE1005:
.LBE1013:
.LBE1015:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:544: }
	.loc 1 544 1 view .LVU879
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE74:
	.size	_Z3rolv, .-_Z3rolv
	.section	.text._Z3rorv,"axG",@progbits,_Z3rorv,comdat
	.literal_position
	.literal .LC150, useaccum
	.literal .LC151, a
	.literal .LC152, ea
	.literal .LC153, value
	.literal .LC154, cpustatus
	.literal .LC155, result
	.literal .LC156, last_modified_ram
	.literal .LC157, zero_ram
	.literal .LC158, 4607
	.literal .LC160, 20991
	.literal .LC162, RAM
	.align	4
	.weak	_Z3rorv
	.type	_Z3rorv, @function
_Z3rorv:
.LFB75:
	.loc 1 546 19 is_stmt 1 view -0
	.loc 1 547 5 view .LVU881
.LBB1016:
.LBI1016:
	.loc 1 216 17 view .LVU882
.LBB1017:
	.loc 1 217 5 view .LVU883
.LBE1017:
.LBE1016:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:546: inline void ror() {
	.loc 1 546 19 is_stmt 0 view .LVU884
	addi	sp, sp, -16	#,,
.LCFI45:
	s32i.n	a12, sp, 8	#,
.LCFI46:
.LBB1025:
.LBB1022:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU885
	l32r	a12, .LC150	#, tmp69
.LBE1022:
.LBE1025:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:546: inline void ror() {
	.loc 1 546 19 view .LVU886
	s32i.n	a0, sp, 12	#,
.LCFI47:
.LBB1026:
.LBB1023:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 view .LVU887
	l8ui	a5, a12, 0	# useaccum$38_39, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU888
	beqz.n	a5, .L144	# useaccum$38_39,
	.loc 1 217 19 is_stmt 1 view .LVU889
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU890
	l32r	a2, .LC151	#, tmp70
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU891
	l8ui	a2, a2, 0	# _41, a
	j	.L145		#
.L144:
.LBB1018:
.LBI1018:
	.loc 1 216 17 is_stmt 1 view .LVU892
.LBB1019:
	.loc 1 218 14 view .LVU893
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU894
	l32r	a2, .LC152	#, tmp73
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL112:
.LBE1019:
.LBE1018:
.LBE1023:
.LBE1026:
.LBB1027:
.LBB1028:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU895
	l8ui	a5, a12, 0	# useaccum$38_39, useaccum
.LBE1028:
.LBE1027:
.LBB1038:
.LBB1024:
.LBB1021:
.LBB1020:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU896
	extui	a2, a2, 0, 16	# _41,
.L145:
.LBE1020:
.LBE1021:
.LBE1024:
.LBE1038:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 41 view .LVU897
	l32r	a6, .LC154	#, tmp125
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:547:     value = getvalue();
	.loc 1 547 11 view .LVU898
	l32r	a9, .LC153	#, tmp77
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 41 view .LVU899
	l16ui	a4, a6, 0	# cpustatus, cpustatus$173_4
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:547:     value = getvalue();
	.loc 1 547 11 view .LVU900
	s16i	a2, a9, 0	# value, _41
	.loc 1 548 5 is_stmt 1 view .LVU901
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 55 is_stmt 0 view .LVU902
	slli	a3, a4, 7	# tmp79, cpustatus$173_4,
	extui	a3, a3, 0, 8	# tmp81, tmp79,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 12 view .LVU903
	l32r	a9, .LC155	#, tmp87
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 21 view .LVU904
	srli	a7, a2, 1	# tmp82, _41,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 27 view .LVU905
	or	a8, a3, a7	# _10, tmp81, tmp82
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 12 view .LVU906
	s16i	a8, a9, 0	# result, _10
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:548:     result = (value >> 1) | ((cpustatus & FLAG_CARRY) << 7);
	.loc 1 548 27 view .LVU907
	mov.n	a3, a8	# _9, _10
	.loc 1 550 5 is_stmt 1 view .LVU908
	bbci	a2, 0, .L146	# _41,,
	.loc 1 550 20 discriminator 1 view .LVU909
	movi.n	a2, 1	# tmp92,
	or	a4, a4, a2	# _11, cpustatus$173_4, tmp92
	j	.L147		#
.L146:
	.loc 1 551 14 view .LVU910
	movi.n	a2, -2	# tmp93,
	and	a4, a4, a2	# _11, cpustatus$173_4, tmp93
.L147:
	.loc 1 552 5 view .LVU911
	.loc 1 552 5 view .LVU912
	beqz.n	a3, .L148	# _9,
	.loc 1 552 5 discriminator 1 view .LVU913
	movi.n	a2, -3	# tmp95,
	and	a4, a4, a2	# _17, _11, tmp95
	.loc 1 552 21 discriminator 1 view .LVU914
	.loc 1 553 5 discriminator 1 view .LVU915
	.loc 1 553 5 discriminator 1 view .LVU916
	movi	a7, 0x80	# tmp98,
	or	a2, a4, a7	# tmp105, _17, tmp98
	extui	a2, a2, 0, 16	# cstore_13, tmp105
	bany	a8, a7, .L151	# _10, tmp98,
	j	.L150		#
.L148:
	.loc 1 552 5 discriminator 2 view .LVU917
	movi.n	a2, 2	# tmp103,
	or	a4, a4, a2	# _17, _11, tmp103
	.loc 1 552 21 discriminator 2 view .LVU918
	.loc 1 553 5 discriminator 2 view .LVU919
	.loc 1 553 5 discriminator 2 view .LVU920
.L150:
	.loc 1 553 5 discriminator 2 view .LVU921
	movi	a2, -0x81	# tmp106,
	and	a2, a4, a2	# cstore_13, _17, tmp106
.L151:
	s16i	a2, a6, 0	# cpustatus, cstore_13
	.loc 1 553 21 discriminator 4 view .LVU922
	.loc 1 555 5 discriminator 4 view .LVU923
.LVL113:
.LBB1039:
.LBI1027:
	.loc 1 225 13 discriminator 4 view .LVU924
.LBB1037:
	.loc 1 226 5 discriminator 4 view .LVU925
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 discriminator 4 view .LVU926
	extui	a2, a3, 0, 8	# _67, _9
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 discriminator 4 view .LVU927
	beqz.n	a5, .L152	# useaccum$38_39,
	.loc 1 226 19 is_stmt 1 view .LVU928
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU929
	l32r	a3, .LC151	#, tmp109
.LVL114:
	.loc 1 226 21 view .LVU930
	s8i	a2, a3, 0	# a, _67
	j	.L143		#
.LVL115:
.L152:
.LBB1029:
.LBI1029:
	.loc 1 225 13 is_stmt 1 view .LVU931
.LBB1030:
	.loc 1 227 14 view .LVU932
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU933
	l32r	a4, .LC152	#, tmp110
.LBB1031:
.LBB1032:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU934
	l32r	a6, .LC156	#, tmp111
.LBE1032:
.LBE1031:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU935
	l16ui	a4, a4, 0	# ea, ea$53_54
.LVL116:
.LBB1036:
.LBI1031:
	.loc 1 90 6 is_stmt 1 view .LVU936
.LBB1035:
	.loc 1 91 3 view .LVU937
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU938
	movi	a5, 0x1ff	# tmp113,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU939
	s16i	a4, a6, 0	# last_modified_ram, ea$53_54
	.loc 1 92 3 is_stmt 1 view .LVU940
	bltu	a5, a4, .L154	# tmp113, ea$53_54,
	.loc 1 93 5 view .LVU941
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU942
	l32r	a3, .LC157	#, tmp114
.LVL117:
	.loc 1 93 23 view .LVU943
	add.n	a4, a3, a4	# tmp115, tmp114, ea$53_54
	j	.L156		#
.LVL118:
.L154:
.LBB1033:
.LBI1033:
	.loc 1 90 6 is_stmt 1 view .LVU944
.LBB1034:
	.loc 1 96 3 view .LVU945
	l32r	a5, .LC158	#, tmp116
	extui	a5, a5, 0, 16	# tmp117, tmp116
	bltu	a5, a4, .L155	# tmp117, ea$53_54,
	.loc 1 97 5 view .LVU946
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU947
	addmi	a2, a4, -0x200	# tmp118, ea$53_54,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU948
	extui	a2, a2, 0, 16	#, tmp118
	call0	_Z14drawPixelToRamth		#
.LVL119:
	.loc 1 98 5 is_stmt 1 view .LVU949
	j	.L143		#
.LVL120:
.L155:
	.loc 1 100 3 view .LVU950
	l32r	a3, .LC160	#, tmp120
.LVL121:
	.loc 1 100 3 is_stmt 0 view .LVU951
	extui	a3, a3, 0, 16	# tmp121, tmp120
	bltu	a3, a4, .L143	# tmp121, ea$53_54,
	.loc 1 101 5 is_stmt 1 view .LVU952
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU953
	l32r	a3, .LC162	#, tmp122
	add.n	a4, a3, a4	# tmp123, tmp122, ea$53_54
.LVL122:
	.loc 1 101 27 view .LVU954
	addmi	a4, a4, -0x1200	# tmp124, tmp123,
.LVL123:
.L156:
	.loc 1 101 27 view .LVU955
	s8i	a2, a4, 0	#, _67
.LVL124:
	.loc 1 102 5 is_stmt 1 view .LVU956
.L143:
	.loc 1 102 5 is_stmt 0 view .LVU957
.LBE1034:
.LBE1033:
.LBE1035:
.LBE1036:
.LBE1030:
.LBE1029:
.LBE1037:
.LBE1039:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:556: }
	.loc 1 556 1 view .LVU958
	l32i.n	a0, sp, 12	#,
	l32i.n	a12, sp, 8	#,
	addi	sp, sp, 16	#,,
	ret.n	
.LFE75:
	.size	_Z3rorv, .-_Z3rorv
	.section	.text._Z3sbcv,"axG",@progbits,_Z3sbcv,comdat
	.literal_position
	.literal .LC163, useaccum
	.literal .LC164, a
	.literal .LC165, ea
	.literal .LC166, value
	.literal .LC167, cpustatus
	.literal .LC168, result
	.align	4
	.weak	_Z3sbcv
	.type	_Z3sbcv, @function
_Z3sbcv:
.LFB78:
	.loc 1 569 19 is_stmt 1 view -0
	.loc 1 570 5 view .LVU960
.LBB1040:
.LBI1040:
	.loc 1 216 17 view .LVU961
.LBB1041:
	.loc 1 217 5 view .LVU962
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU963
	l32r	a2, .LC163	#, tmp69
.LBE1041:
.LBE1040:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:569: inline void sbc() {
	.loc 1 569 19 view .LVU964
	addi	sp, sp, -16	#,,
.LCFI48:
	s32i.n	a0, sp, 12	#,
.LCFI49:
.LBB1048:
.LBB1046:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU965
	l8ui	a2, a2, 0	# useaccum, useaccum
	beqz.n	a2, .L158	# useaccum,
	.loc 1 217 19 is_stmt 1 view .LVU966
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU967
	l32r	a6, .LC164	#, tmp121
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU968
	l8ui	a8, a6, 0	# _53, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 view .LVU969
	mov.n	a5, a8	# a$39_52, _53
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU970
	mov.n	a3, a8	# _72, _53
	j	.L159		#
.L158:
.LBB1042:
.LBI1042:
	.loc 1 216 17 is_stmt 1 view .LVU971
.LBB1043:
	.loc 1 218 14 view .LVU972
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU973
	l32r	a2, .LC165	#, tmp72
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL125:
.LBE1043:
.LBE1042:
.LBE1046:
.LBE1048:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 26 view .LVU974
	l32r	a6, .LC164	#, tmp121
.LBB1049:
.LBB1047:
.LBB1045:
.LBB1044:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU975
	extui	a8, a2, 0, 16	# _53,
.LBE1044:
.LBE1045:
.LBE1047:
.LBE1049:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 26 view .LVU976
	l8ui	a5, a6, 0	# a$39_52, a
	mov.n	a3, a5	# _72, a$39_52
.L159:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 36 view .LVU977
	l32r	a7, .LC167	#, tmp122
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:570:     value = getvalue() ^ 0x00FF;
	.loc 1 570 24 view .LVU978
	movi	a2, 0xff	# tmp77,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 36 view .LVU979
	l16ui	a4, a7, 0	# cpustatus, cpustatus$404_6
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:570:     value = getvalue() ^ 0x00FF;
	.loc 1 570 24 view .LVU980
	xor	a2, a8, a2	# _2, _53, tmp77
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 36 view .LVU981
	extui	a8, a4, 0, 1	# tmp80, cpustatus$404_6,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 34 view .LVU982
	add.n	a3, a3, a8	# tmp82, _72, tmp80
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:570:     value = getvalue() ^ 0x00FF;
	.loc 1 570 11 view .LVU983
	l32r	a8, .LC166	#, tmp78
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 34 view .LVU984
	add.n	a3, a2, a3	# tmp84, _2, tmp82
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:570:     value = getvalue() ^ 0x00FF;
	.loc 1 570 11 view .LVU985
	s16i	a2, a8, 0	# value, _2
	.loc 1 571 5 is_stmt 1 view .LVU986
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 12 is_stmt 0 view .LVU987
	l32r	a8, .LC168	#, tmp85
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 34 view .LVU988
	extui	a3, a3, 0, 16	# _8, tmp84
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:571:     result = (uint16_t)a + value + (uint16_t)(cpustatus & FLAG_CARRY);
	.loc 1 571 12 view .LVU989
	s16i	a3, a8, 0	# result, _8
	.loc 1 573 5 is_stmt 1 view .LVU990
	.loc 1 573 5 view .LVU991
	movi	a8, -0x100	# tmp86,
	bnone	a3, a8, .L160	# _8, tmp86,
	.loc 1 573 5 discriminator 1 view .LVU992
	movi.n	a8, 1	# tmp91,
	or	a4, a4, a8	# _10, cpustatus$404_6, tmp91
	j	.L161		#
.L160:
	.loc 1 573 5 discriminator 2 view .LVU993
	movi.n	a8, -2	# tmp92,
	and	a4, a4, a8	# _10, cpustatus$404_6, tmp92
.L161:
	.loc 1 573 22 discriminator 4 view .LVU994
	.loc 1 574 5 discriminator 4 view .LVU995
	.loc 1 574 5 discriminator 4 view .LVU996
	extui	a8, a3, 0, 8	# tmp96, _8
	beqz.n	a8, .L162	# tmp96,
	.loc 1 574 5 discriminator 1 view .LVU997
	movi.n	a8, -3	# tmp97,
	and	a4, a4, a8	# _13, _10, tmp97
	j	.L163		#
.L162:
	.loc 1 574 5 discriminator 2 view .LVU998
	movi.n	a8, 2	# tmp100,
	or	a4, a4, a8	# _13, _10, tmp100
.L163:
	.loc 1 574 21 discriminator 4 view .LVU999
	.loc 1 575 5 discriminator 4 view .LVU1000
	.loc 1 575 5 discriminator 4 view .LVU1001
	xor	a5, a5, a3	# tmp101, a$39_52, _8
	xor	a2, a2, a3	# tmp103, _2, _8
	and	a2, a5, a2	# tmp104, tmp101, tmp103
	bbci	a2, 7, .L164	# tmp104,,
	.loc 1 575 5 discriminator 1 view .LVU1002
	movi.n	a2, 0x40	# tmp108,
	or	a4, a4, a2	# _23, _13, tmp108
	j	.L165		#
.L164:
	.loc 1 575 5 discriminator 2 view .LVU1003
	movi	a2, -0x41	# tmp109,
	and	a4, a4, a2	# _23, _13, tmp109
.L165:
	.loc 1 575 35 discriminator 4 view .LVU1004
	.loc 1 576 5 discriminator 4 view .LVU1005
	.loc 1 576 5 discriminator 4 view .LVU1006
	movi	a2, 0x80	# tmp111,
	bnone	a3, a2, .L166	# _8, tmp111,
	.loc 1 576 5 discriminator 1 view .LVU1007
	or	a4, a4, a2	# tmp116, _23, tmp111
	extui	a4, a4, 0, 16	# _27, tmp116
	j	.L167		#
.L166:
	.loc 1 576 5 discriminator 2 view .LVU1008
	movi	a2, -0x81	# tmp117,
	and	a4, a4, a2	# _27, _23, tmp117
.L167:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:578:     saveaccum(result);
	.loc 1 578 5 is_stmt 0 discriminator 4 view .LVU1009
	s8i	a3, a6, 0	# a, _8
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:579: }
	.loc 1 579 1 discriminator 4 view .LVU1010
	l32i.n	a0, sp, 12	#,
	s16i	a4, a7, 0	# cpustatus, _27
	.loc 1 576 21 is_stmt 1 discriminator 4 view .LVU1011
	.loc 1 578 5 discriminator 4 view .LVU1012
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:579: }
	.loc 1 579 1 is_stmt 0 discriminator 4 view .LVU1013
	addi	sp, sp, 16	#,,
	ret.n	
.LFE78:
	.size	_Z3sbcv, .-_Z3sbcv
	.section	.text._Z8exec6502i,"ax",@progbits
	.literal_position
	.literal .LC169, pc
	.literal .LC170, opcode
	.literal .LC171, cpustatus
	.literal .LC172, useaccum
	.literal .LC173, .L172
	.literal .LC174, sp
	.literal .LC175, zero_ram
	.literal .LC176, last_modified_ram
	.literal .LC177, 65534
	.literal .LC178, 65535
	.literal .LC179, ea
	.literal .LC180, 4607
	.literal .LC182, 20991
	.literal .LC184, RAM
	.literal .LC185, reladdr
	.literal .LC186, oldpc
	.literal .LC187, clockticks6502
	.literal .LC188, y
	.literal .LC189, x
	.literal .LC190, a
	.literal .LC191, value
	.literal .LC192, result
	.literal .LC193, instructions
	.align	4
	.global	_Z8exec6502i
	.type	_Z8exec6502i, @function
_Z8exec6502i:
.LVL126:
.LFB101:
	.loc 1 712 34 is_stmt 1 view -0
	.loc 1 713 3 view .LVU1015
	.loc 1 713 19 view .LVU1016
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:712: void exec6502(int32_t tickcount) {
	.loc 1 712 34 is_stmt 0 view .LVU1017
	addi	sp, sp, -48	#,,
.LCFI50:
	s32i.n	a0, sp, 44	#,
	s32i.n	a12, sp, 40	#,
	s32i.n	a13, sp, 36	#,
	s32i.n	a14, sp, 32	#,
	s32i.n	a15, sp, 28	#,
.LCFI51:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:713:   while (tickcount--) {
	.loc 1 713 19 view .LVU1018
	beqz.n	a2, .L168	# tickcount,
	l32r	a13, .LC169	#, tmp3111
	l32r	a14, .LC171	#, tmp3109
	l32r	a15, .LC193	#, tmp3110
	mov.n	a12, a2	# ivtmp$594, tickcount
.LVL127:
.L594:
	.loc 1 714 5 is_stmt 1 view .LVU1019
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:714:     opcode = read6502(pc++);
	.loc 1 714 25 is_stmt 0 view .LVU1020
	l16ui	a2, a13, 0	# pc, pc$4_1
	addi.n	a3, a2, 1	# tmp1085, pc$4_1,
	s16i	a3, a13, 0	# pc, tmp1085
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:714:     opcode = read6502(pc++);
	.loc 1 714 22 view .LVU1021
	call0	_Z8read6502t		#
.LVL128:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:715:     cpustatus |= FLAG_CONSTANT;
	.loc 1 715 15 view .LVU1022
	l16ui	a5, a14, 0	# cpustatus, cpustatus$6_5
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:714:     opcode = read6502(pc++);
	.loc 1 714 12 view .LVU1023
	l32r	a3, .LC170	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:715:     cpustatus |= FLAG_CONSTANT;
	.loc 1 715 15 view .LVU1024
	movi.n	a4, 0x20	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:717:     useaccum = 0;
	.loc 1 717 14 view .LVU1025
	l32r	a6, .LC172	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:714:     opcode = read6502(pc++);
	.loc 1 714 12 view .LVU1026
	s8i	a2, a3, 0	# opcode, tmp1086
	.loc 1 715 5 is_stmt 1 view .LVU1027
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:715:     cpustatus |= FLAG_CONSTANT;
	.loc 1 715 15 is_stmt 0 view .LVU1028
	or	a3, a5, a4	# tmp1090, cpustatus$6_5,
	extui	a3, a3, 0, 16	# prephitmp_1199, tmp1090
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:717:     useaccum = 0;
	.loc 1 717 14 view .LVU1029
	movi.n	a4, 0	#,
	s8i	a4, a6, 0	# useaccum,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:715:     cpustatus |= FLAG_CONSTANT;
	.loc 1 715 15 view .LVU1030
	s16i	a3, a14, 0	# cpustatus, prephitmp_1199
	.loc 1 717 5 is_stmt 1 view .LVU1031
	.loc 1 719 5 view .LVU1032
	movi	a4, 0xfe	# tmp1095,
	bltu	a4, a2, .L170	# tmp1095, tmp1086,
	l32r	a4, .LC173	#, tmp1096
	addx4	a2, a2, a4	#, tmp1098, tmp1086, tmp1096
	l32i.n	a2, a2, 0	#, tmp1099
	jx	a2		# tmp1099
	.align	4
	.align	4
.L172:
	.word	.L321
	.word	.L320
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L319
	.word	.L318
	.word	.L170
	.word	.L317
	.word	.L316
	.word	.L315
	.word	.L170
	.word	.L170
	.word	.L314
	.word	.L313
	.word	.L170
	.word	.L312
	.word	.L311
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L310
	.word	.L309
	.word	.L170
	.word	.L308
	.word	.L307
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L306
	.word	.L305
	.word	.L170
	.word	.L304
	.word	.L303
	.word	.L170
	.word	.L170
	.word	.L302
	.word	.L301
	.word	.L300
	.word	.L170
	.word	.L299
	.word	.L298
	.word	.L297
	.word	.L170
	.word	.L296
	.word	.L295
	.word	.L294
	.word	.L170
	.word	.L293
	.word	.L292
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L291
	.word	.L290
	.word	.L170
	.word	.L289
	.word	.L288
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L287
	.word	.L286
	.word	.L170
	.word	.L285
	.word	.L284
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L283
	.word	.L282
	.word	.L170
	.word	.L281
	.word	.L280
	.word	.L279
	.word	.L170
	.word	.L278
	.word	.L277
	.word	.L276
	.word	.L170
	.word	.L275
	.word	.L274
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L273
	.word	.L272
	.word	.L170
	.word	.L271
	.word	.L270
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L269
	.word	.L268
	.word	.L170
	.word	.L267
	.word	.L266
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L265
	.word	.L264
	.word	.L170
	.word	.L263
	.word	.L262
	.word	.L261
	.word	.L170
	.word	.L260
	.word	.L259
	.word	.L258
	.word	.L170
	.word	.L257
	.word	.L256
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L255
	.word	.L254
	.word	.L170
	.word	.L253
	.word	.L252
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L251
	.word	.L250
	.word	.L170
	.word	.L170
	.word	.L249
	.word	.L170
	.word	.L170
	.word	.L248
	.word	.L247
	.word	.L246
	.word	.L170
	.word	.L245
	.word	.L170
	.word	.L244
	.word	.L170
	.word	.L243
	.word	.L242
	.word	.L241
	.word	.L170
	.word	.L240
	.word	.L239
	.word	.L170
	.word	.L170
	.word	.L238
	.word	.L237
	.word	.L236
	.word	.L170
	.word	.L235
	.word	.L234
	.word	.L233
	.word	.L170
	.word	.L170
	.word	.L232
	.word	.L170
	.word	.L170
	.word	.L231
	.word	.L230
	.word	.L229
	.word	.L170
	.word	.L228
	.word	.L227
	.word	.L226
	.word	.L170
	.word	.L225
	.word	.L224
	.word	.L223
	.word	.L170
	.word	.L222
	.word	.L221
	.word	.L220
	.word	.L170
	.word	.L219
	.word	.L218
	.word	.L170
	.word	.L170
	.word	.L217
	.word	.L216
	.word	.L215
	.word	.L170
	.word	.L214
	.word	.L213
	.word	.L212
	.word	.L170
	.word	.L211
	.word	.L210
	.word	.L209
	.word	.L170
	.word	.L208
	.word	.L207
	.word	.L170
	.word	.L170
	.word	.L206
	.word	.L205
	.word	.L204
	.word	.L170
	.word	.L203
	.word	.L202
	.word	.L201
	.word	.L170
	.word	.L200
	.word	.L199
	.word	.L198
	.word	.L170
	.word	.L197
	.word	.L196
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L195
	.word	.L194
	.word	.L170
	.word	.L193
	.word	.L192
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L191
	.word	.L190
	.word	.L170
	.word	.L189
	.word	.L188
	.word	.L170
	.word	.L170
	.word	.L187
	.word	.L186
	.word	.L185
	.word	.L170
	.word	.L184
	.word	.L183
	.word	.L170
	.word	.L183
	.word	.L182
	.word	.L181
	.word	.L180
	.word	.L170
	.word	.L179
	.word	.L178
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L177
	.word	.L176
	.word	.L170
	.word	.L175
	.word	.L174
	.word	.L170
	.word	.L170
	.word	.L170
	.word	.L173
	.word	.L171
.L321:
	.loc 1 720 5 view .LVU1033
	.loc 1 721 7 view .LVU1034
	.loc 1 722 7 view .LVU1035
.LBB1050:
.LBI1050:
	.loc 1 325 13 view .LVU1036
.LBB1051:
	.loc 1 326 5 view .LVU1037
.LBB1052:
.LBB1053:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 is_stmt 0 view .LVU1038
	l32r	a8, .LC174	#, tmp1104
.LBE1053:
.LBE1052:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:326:     pc++;
	.loc 1 326 7 view .LVU1039
	l16ui	a4, a13, 0	# pc,
.LBB1072:
.LBB1066:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 view .LVU1040
	l8ui	a6, a8, 0	# _406, sp
.LBB1054:
.LBB1055:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1041
	l32r	a10, .LC175	#, tmp1105
.LBE1055:
.LBE1054:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 view .LVU1042
	mov.n	a9, a6	# sp$14_405, _406
.LBE1066:
.LBE1072:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:326:     pc++;
	.loc 1 326 7 view .LVU1043
	addi.n	a4, a4, 1	# tmp1102, pc,
	extui	a4, a4, 0, 16	# _381, tmp1102
.LBB1073:
.LBB1067:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 33 view .LVU1044
	addi.n	a2, a6, -1	# tmp1111, _406,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:110:     sp -= 2;
	.loc 1 110 8 view .LVU1045
	addi	a7, a9, -2	# tmp1120, sp$14_405,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 14 view .LVU1046
	addmi	a6, a6, 0x100	# tmp1107, _406,
.LBB1059:
.LBB1056:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1047
	add.n	a6, a10, a6	# tmp1108, tmp1105, tmp1107
.LBE1056:
.LBE1059:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 41 view .LVU1048
	srli	a11, a4, 8	# tmp1109, _381,
.LBE1067:
.LBE1073:
.LBB1074:
.LBB1075:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1049
	extui	a7, a7, 0, 8	# tmp1122, tmp1120
.LBE1075:
.LBE1074:
.LBB1091:
.LBB1068:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 38 view .LVU1050
	extui	a2, a2, 0, 8	# tmp1113, tmp1111,
.LBB1060:
.LBB1057:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1051
	s8i	a11, a6, 0	# zero_ram[_408], tmp1109
.LBE1057:
.LBE1060:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 14 view .LVU1052
	addmi	a2, a2, 0x100	# tmp1116, tmp1113,
.LBE1068:
.LBE1091:
.LBB1092:
.LBB1084:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 26 view .LVU1053
	addmi	a6, a7, 0x100	# _987, tmp1122,
.LBE1084:
.LBE1092:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:328:     push8(cpustatus | FLAG_BREAK); //push CPU cpustatus to stack
	.loc 1 328 21 view .LVU1054
	movi.n	a7, 0x10	# tmp1127,
	or	a7, a3, a7	# tmp1129, prephitmp_1199, tmp1127
.LBB1093:
.LBB1069:
.LBB1061:
.LBB1062:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1055
	add.n	a2, a10, a2	# tmp1117, tmp1105, tmp1116
.LBE1062:
.LBE1061:
.LBE1069:
.LBE1093:
.LBB1094:
.LBB1085:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1056
	addi	a3, a9, -3	# tmp1119, sp$14_405,
.LBE1085:
.LBE1094:
.LBB1095:
.LBB1070:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 14 view .LVU1057
	s8i	a4, a2, 0	# zero_ram[_965], _381
.LBE1070:
.LBE1095:
.LBB1096:
.LBB1086:
.LBB1076:
.LBB1077:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1058
	add.n	a10, a10, a6	# tmp1126, tmp1105, _987
.LBE1077:
.LBE1076:
.LBE1086:
.LBE1096:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:329:     setinterrupt(); //set interrupt flag
	.loc 1 329 5 view .LVU1059
	movi.n	a9, 0x24	# tmp1131,
.LBB1097:
.LBB1087:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1060
	s8i	a3, a8, 0	# sp, tmp1119
.LBE1087:
.LBE1097:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 28 view .LVU1061
	l32r	a2, .LC177	#,
.LBB1098:
.LBB1088:
.LBB1081:
.LBB1078:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1062
	l32r	a3, .LC176	#, tmp1124
.LBE1078:
.LBE1081:
.LBE1088:
.LBE1098:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:329:     setinterrupt(); //set interrupt flag
	.loc 1 329 5 view .LVU1063
	or	a5, a5, a9	# tmp1132, cpustatus$6_5, tmp1131
.LBB1099:
.LBB1089:
.LBB1082:
.LBB1079:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1064
	s8i	a7, a10, 0	# zero_ram[_986], tmp1129
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1065
	s16i	a6, a3, 0	# last_modified_ram, _987
.LBE1079:
.LBE1082:
.LBE1089:
.LBE1099:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:326:     pc++;
	.loc 1 326 7 view .LVU1066
	s16i	a4, a13, 0	# pc, _381
	.loc 1 327 5 is_stmt 1 view .LVU1067
.LVL129:
.LBB1100:
.LBI1052:
	.loc 1 107 13 view .LVU1068
.LBB1071:
	.loc 1 108 5 view .LVU1069
.LBB1064:
.LBI1054:
	.loc 1 90 6 view .LVU1070
.LBB1058:
	.loc 1 91 3 view .LVU1071
	.loc 1 92 3 view .LVU1072
	.loc 1 93 5 view .LVU1073
	.loc 1 94 5 view .LVU1074
	.loc 1 94 5 is_stmt 0 view .LVU1075
.LBE1058:
.LBE1064:
	.loc 1 109 5 is_stmt 1 view .LVU1076
.LBB1065:
.LBI1061:
	.loc 1 90 6 view .LVU1077
.LBB1063:
	.loc 1 91 3 view .LVU1078
	.loc 1 92 3 view .LVU1079
	.loc 1 93 5 view .LVU1080
	.loc 1 94 5 view .LVU1081
	.loc 1 94 5 is_stmt 0 view .LVU1082
.LBE1063:
.LBE1065:
	.loc 1 110 5 is_stmt 1 view .LVU1083
	.loc 1 110 5 is_stmt 0 view .LVU1084
.LBE1071:
.LBE1100:
	.loc 1 328 5 is_stmt 1 view .LVU1085
.LBB1101:
.LBI1074:
	.loc 1 113 13 view .LVU1086
.LBB1090:
	.loc 1 114 5 view .LVU1087
.LBB1083:
.LBI1076:
	.loc 1 90 6 view .LVU1088
.LBB1080:
	.loc 1 91 3 view .LVU1089
	.loc 1 92 3 view .LVU1090
	.loc 1 93 5 view .LVU1091
	.loc 1 94 5 view .LVU1092
	.loc 1 94 5 is_stmt 0 view .LVU1093
.LBE1080:
.LBE1083:
.LBE1090:
.LBE1101:
	.loc 1 329 5 is_stmt 1 view .LVU1094
	s16i	a5, a14, 0	# cpustatus, tmp1132
	.loc 1 330 5 view .LVU1095
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 28 is_stmt 0 view .LVU1096
	call0	_Z8read6502t		#
.LVL130:
	mov.n	a3, a2	# tmp1134,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 58 view .LVU1097
	l32r	a2, .LC178	#,
	s32i.n	a3, sp, 0	#,
	call0	_Z8read6502t		#
.LVL131:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 37 view .LVU1098
	l32i.n	a3, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 67 view .LVU1099
	slli	a2, a2, 8	# tmp1138,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 37 view .LVU1100
	or	a2, a2, a3	# tmp1141, tmp1138, tmp1134
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:330:     pc = (uint16_t)read6502(0xFFFE) | ((uint16_t)read6502(0xFFFF) << 8);
	.loc 1 330 8 view .LVU1101
	s16i	a2, a13, 0	# pc, tmp1141
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:331: }
	.loc 1 331 1 view .LVU1102
	j	.L170		#
.L320:
.LBE1051:
.LBE1050:
	.loc 1 724 5 is_stmt 1 view .LVU1103
	.loc 1 725 7 view .LVU1104
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:725:       indx();
	.loc 1 725 11 is_stmt 0 view .LVU1105
	call0	_Z4indxv		#
.LVL132:
	.loc 1 726 7 is_stmt 1 view .LVU1106
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:726:       ora();
	.loc 1 726 10 is_stmt 0 view .LVU1107
	call0	_Z3orav		#
.LVL133:
	.loc 1 727 7 is_stmt 1 view .LVU1108
	j	.L170		#
.L319:
	.loc 1 732 5 view .LVU1109
	.loc 1 733 7 view .LVU1110
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:733:       zp();
	.loc 1 733 9 is_stmt 0 view .LVU1111
	call0	_Z2zpv		#
.LVL134:
	.loc 1 734 7 is_stmt 1 view .LVU1112
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:734:       ora();
	.loc 1 734 10 is_stmt 0 view .LVU1113
	call0	_Z3orav		#
.LVL135:
	.loc 1 735 7 is_stmt 1 view .LVU1114
	j	.L170		#
.L318:
	.loc 1 736 5 view .LVU1115
	.loc 1 737 7 view .LVU1116
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:737:       zp();
	.loc 1 737 9 is_stmt 0 view .LVU1117
	call0	_Z2zpv		#
.LVL136:
	.loc 1 738 7 is_stmt 1 view .LVU1118
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:738:       asl();
	.loc 1 738 10 is_stmt 0 view .LVU1119
	call0	_Z3aslv		#
.LVL137:
	.loc 1 739 7 is_stmt 1 view .LVU1120
	j	.L170		#
.L317:
	.loc 1 742 5 view .LVU1121
	.loc 1 743 7 view .LVU1122
	.loc 1 744 7 view .LVU1123
.LBB1102:
.LBI1102:
	.loc 1 520 13 view .LVU1124
.LBB1103:
	.loc 1 521 5 view .LVU1125
.LVL138:
.LBB1104:
.LBI1104:
	.loc 1 113 13 view .LVU1126
.LBB1105:
	.loc 1 114 5 view .LVU1127
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 is_stmt 0 view .LVU1128
	l32r	a7, .LC174	#, tmp1142
.LBB1106:
.LBB1107:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1129
	l32r	a4, .LC175	#, tmp1148
.LBE1107:
.LBE1106:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1130
	l8ui	a2, a7, 0	# sp$17_458, sp
.LBE1105:
.LBE1104:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:521:     push8(cpustatus | FLAG_BREAK);
	.loc 1 521 21 view .LVU1131
	movi.n	a5, 0x10	# tmp1150,
.LBB1116:
.LBB1114:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 26 view .LVU1132
	addmi	a6, a2, 0x100	# _461, sp$17_458,
.LVL139:
.LBB1111:
.LBI1106:
	.loc 1 90 6 is_stmt 1 view .LVU1133
.LBB1108:
	.loc 1 91 3 view .LVU1134
.LBE1108:
.LBE1111:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 is_stmt 0 view .LVU1135
	addi.n	a2, a2, -1	# tmp1144, sp$17_458,
	s8i	a2, a7, 0	# sp, tmp1144
.LBB1112:
.LBB1109:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1136
	l32r	a2, .LC176	#, tmp1147
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1137
	add.n	a4, a4, a6	# tmp1149, tmp1148, _461
.LBE1109:
.LBE1112:
.LBE1114:
.LBE1116:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:521:     push8(cpustatus | FLAG_BREAK);
	.loc 1 521 21 view .LVU1138
	or	a3, a3, a5	# tmp1152, prephitmp_1199, tmp1150
.LVL140:
.LBB1117:
.LBB1115:
.LBB1113:
.LBB1110:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1139
	s16i	a6, a2, 0	# last_modified_ram, _461
	.loc 1 92 3 is_stmt 1 view .LVU1140
	.loc 1 93 5 view .LVU1141
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU1142
	s8i	a3, a4, 0	# zero_ram[_462], tmp1152
	.loc 1 94 5 is_stmt 1 view .LVU1143
	j	.L170		#
.LVL141:
.L316:
	.loc 1 94 5 is_stmt 0 view .LVU1144
.LBE1110:
.LBE1113:
.LBE1115:
.LBE1117:
.LBE1103:
.LBE1102:
	.loc 1 746 5 is_stmt 1 view .LVU1145
	.loc 1 747 7 view .LVU1146
.LBB1118:
.LBI1118:
	.loc 1 148 13 view .LVU1147
.LBB1119:
	.loc 1 149 5 view .LVU1148
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU1149
	l16ui	a2, a13, 0	# pc, pc$356_85
	addi.n	a3, a2, 1	# tmp1155, pc$356_85,
	s16i	a3, a13, 0	# pc, tmp1155
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU1150
	l32r	a3, .LC179	#, tmp1156
	s16i	a2, a3, 0	# ea, pc$356_85
.LBE1119:
.LBE1118:
	.loc 1 748 7 is_stmt 1 view .LVU1151
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:748:       ora();
	.loc 1 748 10 is_stmt 0 view .LVU1152
	call0	_Z3orav		#
.LVL142:
	.loc 1 749 7 is_stmt 1 view .LVU1153
	j	.L170		#
.L315:
	.loc 1 750 5 view .LVU1154
	.loc 1 751 7 view .LVU1155
.LBB1120:
.LBI1120:
	.loc 1 144 13 view .LVU1156
.LBB1121:
	.loc 1 145 3 view .LVU1157
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:145:   useaccum = 1;
	.loc 1 145 12 is_stmt 0 view .LVU1158
	l32r	a5, .LC172	#,
	movi.n	a2, 1	# tmp1158,
	s8i	a2, a5, 0	# useaccum, tmp1158
.LBE1121:
.LBE1120:
	.loc 1 752 7 is_stmt 1 view .LVU1159
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:752:       asl();
	.loc 1 752 10 is_stmt 0 view .LVU1160
	call0	_Z3aslv		#
.LVL143:
	.loc 1 753 7 is_stmt 1 view .LVU1161
	j	.L170		#
.L314:
	.loc 1 754 5 view .LVU1162
	.loc 1 755 7 view .LVU1163
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:755:       abso();
	.loc 1 755 11 is_stmt 0 view .LVU1164
	call0	_Z4absov		#
.LVL144:
	.loc 1 756 7 is_stmt 1 view .LVU1165
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:756:       ora();
	.loc 1 756 10 is_stmt 0 view .LVU1166
	call0	_Z3orav		#
.LVL145:
	.loc 1 757 7 is_stmt 1 view .LVU1167
	j	.L170		#
.L313:
	.loc 1 758 5 view .LVU1168
	.loc 1 759 7 view .LVU1169
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:759:       abso();
	.loc 1 759 11 is_stmt 0 view .LVU1170
	call0	_Z4absov		#
.LVL146:
	.loc 1 760 7 is_stmt 1 view .LVU1171
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:760:       asl();
	.loc 1 760 10 is_stmt 0 view .LVU1172
	call0	_Z3aslv		#
.LVL147:
	.loc 1 761 7 is_stmt 1 view .LVU1173
	j	.L170		#
.L312:
	.loc 1 764 5 view .LVU1174
	.loc 1 765 7 view .LVU1175
.LBB1122:
.LBI1122:
	.loc 1 164 13 view .LVU1176
.LBB1123:
	.loc 1 165 5 view .LVU1177
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU1178
	l16ui	a2, a13, 0	# pc, pc$374_478
.LBB1124:
.LBB1125:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU1179
	movi	a4, 0x1ff	# tmp1163,
.LBE1125:
.LBE1124:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU1180
	addi.n	a5, a2, 1	# tmp1161, pc$374_478,
	s16i	a5, a13, 0	# pc, tmp1161
.LVL148:
.LBB1130:
.LBI1124:
	.loc 1 69 9 is_stmt 1 view .LVU1181
.LBB1128:
	.loc 1 70 3 view .LVU1182
	bltu	a4, a2, .L322	# tmp1163, pc$374_478,
	.loc 1 71 5 view .LVU1183
	.loc 1 72 7 view .LVU1184
	.loc 1 75 12 view .LVU1185
	movi	a4, 0xfe	# tmp1165,
	bne	a2, a4, .L323	# pc$374_478, tmp1165,
	.loc 1 76 9 view .LVU1186
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU1187
	call0	rand		#
.LVL149:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU1188
	extui	a2, a2, 0, 8	# _489,
	j	.L618		#
.LVL150:
.L323:
	.loc 1 79 5 is_stmt 1 view .LVU1189
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU1190
	l32r	a4, .LC175	#, tmp1167
	add.n	a2, a4, a2	# tmp1168, tmp1167, pc$374_478
.LVL151:
	.loc 1 79 28 view .LVU1191
	j	.L619		#
.LVL152:
.L322:
	.loc 1 81 3 is_stmt 1 view .LVU1192
	l32r	a4, .LC180	#, tmp1169
	extui	a4, a4, 0, 16	# tmp1170, tmp1169
	bltu	a4, a2, .L325	# tmp1170, pc$374_478,
.LVL153:
.LBB1126:
.LBI1126:
	.loc 1 69 9 view .LVU1193
.LBB1127:
	.loc 1 82 5 view .LVU1194
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU1195
	addmi	a2, a2, -0x200	# tmp1171, pc$374_478,
.LVL154:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU1196
	extui	a2, a2, 0, 16	#, tmp1171
.LVL155:
	.loc 1 82 28 view .LVU1197
	call0	_Z16loadPixelFromRamt		#
.LVL156:
.L618:
	.loc 1 82 28 view .LVU1198
.LBE1127:
.LBE1126:
.LBE1128:
.LBE1130:
.LBE1123:
.LBE1122:
.LBB1135:
.LBB1136:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:317:     if ((cpustatus & FLAG_SIGN) == 0) {
	.loc 1 317 20 view .LVU1199
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L324		#
.LVL157:
.L325:
	.loc 1 317 20 view .LVU1200
.LBE1136:
.LBE1135:
.LBB1141:
.LBB1132:
.LBB1131:
.LBB1129:
	.loc 1 84 3 is_stmt 1 view .LVU1201
	l32r	a4, .LC182	#, tmp1175
	extui	a4, a4, 0, 16	# tmp1176, tmp1175
	bltu	a4, a2, .L326	# tmp1176, pc$374_478,
	.loc 1 85 5 view .LVU1202
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU1203
	l32r	a4, .LC184	#, tmp1177
	add.n	a2, a4, a2	# tmp1178, tmp1177, pc$374_478
.LVL158:
	.loc 1 85 32 view .LVU1204
	addmi	a2, a2, -0x1200	# tmp1179, tmp1178,
.L619:
	.loc 1 85 32 view .LVU1205
	l8ui	a2, a2, 0	# _489,
.LVL159:
.L324:
	.loc 1 85 32 view .LVU1206
.LBE1129:
.LBE1131:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU1207
	extui	a4, a2, 0, 16	# _482, _489
	.loc 1 166 5 is_stmt 1 view .LVU1208
	bbsi	a2, 7, .L327	# _489,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU1209
	l32r	a2, .LC185	#, tmp3112
	j	.L620		#
.L327:
	.loc 1 166 25 is_stmt 1 view .LVU1210
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1211
	movi	a5, -0x100	# tmp1184,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp1185, _482, tmp1184
.L620:
.LBE1132:
.LBE1141:
	.loc 1 766 7 is_stmt 1 view .LVU1212
.LBB1142:
.LBI1135:
	.loc 1 316 13 view .LVU1213
.LBB1139:
	.loc 1 317 5 view .LVU1214
.LBE1139:
.LBE1142:
.LBB1143:
.LBB1133:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1215
	s16i	a4, a2, 0	# reladdr, tmp1185
.LBE1133:
.LBE1143:
.LBB1144:
.LBB1140:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:317:     if ((cpustatus & FLAG_SIGN) == 0) {
	.loc 1 317 5 view .LVU1216
	bbsi	a3, 7, .L170	# prephitmp_1199,,
.LBB1137:
.LBI1137:
	.loc 1 263 13 is_stmt 1 view .LVU1217
.LBB1138:
	.loc 1 265 9 view .LVU1218
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU1219
	l16ui	a5, a13, 0	# pc, pc$202_501
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1220
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1221
	l32r	a6, .LC187	#, tmp1196
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1222
	add.n	a3, a5, a3	# tmp1194, pc$202_501, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1223
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1224
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1224
	extui	a3, a3, 0, 16	# _503, tmp1194
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1225
	movi	a7, -0x100	# tmp1198,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU1226
	xor	a4, a5, a3	# tmp1197, pc$202_501, _503
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1227
	and	a4, a4, a7	# tmp1202, tmp1197, tmp1198
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1228
	addi.n	a7, a2, 1	# tmp1206, pretmp_1224,
	addi.n	a2, a2, 2	# tmp1204, pretmp_1224,
	moveqz	a2, a7, a4	# tmp3115, tmp1206, tmp1202
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1229
	l32r	a4, .LC186	#, tmp1191
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1230
	s16i	a3, a13, 0	# pc, _503
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1231
	s16i	a5, a4, 0	# oldpc, pc$202_501
	.loc 1 266 9 is_stmt 1 view .LVU1232
	.loc 1 267 9 view .LVU1233
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU1234
	s32i.n	a2, a6, 0	# clockticks6502, tmp3115
	j	.L170		#
.L311:
.LBE1138:
.LBE1137:
.LBE1140:
.LBE1144:
	.loc 1 768 5 is_stmt 1 view .LVU1235
	.loc 1 769 7 view .LVU1236
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:769:       indy();
	.loc 1 769 11 is_stmt 0 view .LVU1237
	call0	_Z4indyv		#
.LVL160:
	.loc 1 770 7 is_stmt 1 view .LVU1238
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:770:       ora();
	.loc 1 770 10 is_stmt 0 view .LVU1239
	call0	_Z3orav		#
.LVL161:
	.loc 1 771 7 is_stmt 1 view .LVU1240
	j	.L170		#
.L310:
	.loc 1 776 5 view .LVU1241
	.loc 1 777 7 view .LVU1242
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:777:       zpx();
	.loc 1 777 10 is_stmt 0 view .LVU1243
	call0	_Z3zpxv		#
.LVL162:
	.loc 1 778 7 is_stmt 1 view .LVU1244
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:778:       ora();
	.loc 1 778 10 is_stmt 0 view .LVU1245
	call0	_Z3orav		#
.LVL163:
	.loc 1 779 7 is_stmt 1 view .LVU1246
	j	.L170		#
.L309:
	.loc 1 780 5 view .LVU1247
	.loc 1 781 7 view .LVU1248
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:781:       zpx();
	.loc 1 781 10 is_stmt 0 view .LVU1249
	call0	_Z3zpxv		#
.LVL164:
	.loc 1 782 7 is_stmt 1 view .LVU1250
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:782:       asl();
	.loc 1 782 10 is_stmt 0 view .LVU1251
	call0	_Z3aslv		#
.LVL165:
	.loc 1 783 7 is_stmt 1 view .LVU1252
	j	.L170		#
.L308:
	.loc 1 786 5 view .LVU1253
	.loc 1 787 7 view .LVU1254
	.loc 1 788 7 view .LVU1255
.LBB1145:
.LBI1145:
	.loc 1 351 13 view .LVU1256
.LBB1146:
	.loc 1 352 5 view .LVU1257
	movi.n	a2, -2	# tmp1208,
	and	a2, a5, a2	# tmp1209, cpustatus$6_5, tmp1208
	movi.n	a6, 0x20	#,
	or	a2, a2, a6	# tmp1212, tmp1209,
	s16i	a2, a14, 0	# cpustatus, tmp1212
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:353: }
	.loc 1 353 1 is_stmt 0 view .LVU1258
	j	.L170		#
.L307:
.LBE1146:
.LBE1145:
	.loc 1 790 5 is_stmt 1 view .LVU1259
	.loc 1 791 7 view .LVU1260
.LBB1147:
.LBI1147:
	.loc 1 183 13 view .LVU1261
.LBB1148:
	.loc 1 184 5 view .LVU1262
	.loc 1 185 5 view .LVU1263
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU1264
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL166:
	mov.n	a5, a2	# tmp1215,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1265
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1266
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1267
	addi.n	a2, a2, 1	# tmp1218, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1268
	extui	a2, a2, 0, 16	#, tmp1218
	call0	_Z8read6502t		#
.LVL167:
	.loc 1 186 5 is_stmt 1 view .LVU1269
	.loc 1 187 5 view .LVU1270
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU1271
	l32r	a4, .LC188	#, tmp1226
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1272
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1273
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU1274
	slli	a2, a2, 8	# tmp1222,,
.LVL168:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1275
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1276
	or	a2, a2, a5	# tmp1225, tmp1222, tmp1215
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1277
	add.n	a4, a4, a2	# tmp1230, y, tmp1225
	l32r	a2, .LC179	#, tmp1221
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1278
	addi.n	a3, a3, 2	# tmp1234, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1279
	s16i	a4, a2, 0	# ea, tmp1230
	.loc 1 189 5 is_stmt 1 view .LVU1280
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU1281
	s16i	a3, a13, 0	# pc, tmp1234
.LBE1148:
.LBE1147:
	.loc 1 792 7 is_stmt 1 view .LVU1282
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:792:       ora();
	.loc 1 792 10 is_stmt 0 view .LVU1283
	call0	_Z3orav		#
.LVL169:
	.loc 1 793 7 is_stmt 1 view .LVU1284
	j	.L170		#
.L306:
	.loc 1 798 5 view .LVU1285
	.loc 1 799 7 view .LVU1286
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:799:       absx();
	.loc 1 799 11 is_stmt 0 view .LVU1287
	call0	_Z4absxv		#
.LVL170:
	.loc 1 800 7 is_stmt 1 view .LVU1288
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:800:       ora();
	.loc 1 800 10 is_stmt 0 view .LVU1289
	call0	_Z3orav		#
.LVL171:
	.loc 1 801 7 is_stmt 1 view .LVU1290
	j	.L170		#
.L305:
	.loc 1 802 5 view .LVU1291
	.loc 1 803 7 view .LVU1292
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:803:       absx();
	.loc 1 803 11 is_stmt 0 view .LVU1293
	call0	_Z4absxv		#
.LVL172:
	.loc 1 804 7 is_stmt 1 view .LVU1294
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:804:       asl();
	.loc 1 804 10 is_stmt 0 view .LVU1295
	call0	_Z3aslv		#
.LVL173:
	.loc 1 805 7 is_stmt 1 view .LVU1296
	j	.L170		#
.L304:
	.loc 1 808 5 view .LVU1297
	.loc 1 809 7 view .LVU1298
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:809:       abso();
	.loc 1 809 11 is_stmt 0 view .LVU1299
	call0	_Z4absov		#
.LVL174:
	.loc 1 810 7 is_stmt 1 view .LVU1300
.LBB1149:
.LBI1149:
	.loc 1 462 13 view .LVU1301
.LBB1150:
	.loc 1 463 5 view .LVU1302
.LBB1151:
.LBB1152:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 is_stmt 0 view .LVU1303
	l32r	a6, .LC174	#, tmp1238
.LBE1152:
.LBE1151:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:463:     push16(pc - 1);
	.loc 1 463 15 view .LVU1304
	l16ui	a5, a13, 0	# pc,
.LBB1173:
.LBB1169:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 view .LVU1305
	l8ui	a2, a6, 0	# _534, sp
.LBB1153:
.LBB1154:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1306
	l32r	a7, .LC175	#, tmp1239
.LBE1154:
.LBE1153:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 33 view .LVU1307
	addi.n	a3, a2, -1	# tmp1244, _534,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 26 view .LVU1308
	mov.n	a4, a2	# sp$14_533, _534
.LBE1169:
.LBE1173:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:463:     push16(pc - 1);
	.loc 1 463 15 view .LVU1309
	addi.n	a5, a5, -1	# tmp1237, pc,
.LVL175:
.LBB1174:
.LBI1151:
	.loc 1 107 13 is_stmt 1 view .LVU1310
.LBB1170:
	.loc 1 108 5 view .LVU1311
.LBB1158:
.LBI1153:
	.loc 1 90 6 view .LVU1312
.LBB1155:
	.loc 1 91 3 view .LVU1313
	.loc 1 92 3 view .LVU1314
	.loc 1 93 5 view .LVU1315
.LBE1155:
.LBE1158:
.LBE1170:
.LBE1174:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:464:     pc = ea;
	.loc 1 464 8 is_stmt 0 view .LVU1316
	l32r	a8, .LC179	#, tmp1255
.LBB1175:
.LBB1171:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 14 view .LVU1317
	addmi	a2, a2, 0x100	# tmp1241, _534,
.LVL176:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 38 view .LVU1318
	extui	a3, a3, 0, 8	# tmp1246, tmp1244,
.LBB1159:
.LBB1156:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1319
	add.n	a2, a7, a2	# tmp1242, tmp1239, tmp1241
.LBE1156:
.LBE1159:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 26 view .LVU1320
	addmi	a3, a3, 0x100	# _277, tmp1246,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:108:     write6502(BASE_STACK + sp, (pushval >> 8) & 0xFF);
	.loc 1 108 41 view .LVU1321
	extui	a9, a5, 8, 8	# tmp1243, tmp1237,,
.LBB1160:
.LBB1157:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1322
	s8i	a9, a2, 0	# zero_ram[_536], tmp1243
	.loc 1 94 5 is_stmt 1 view .LVU1323
.LVL177:
	.loc 1 94 5 is_stmt 0 view .LVU1324
.LBE1157:
.LBE1160:
	.loc 1 109 5 is_stmt 1 view .LVU1325
.LBB1161:
.LBI1161:
	.loc 1 90 6 view .LVU1326
.LBB1162:
	.loc 1 91 3 view .LVU1327
.LBE1162:
.LBE1161:
.LBE1171:
.LBE1175:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:464:     pc = ea;
	.loc 1 464 8 is_stmt 0 view .LVU1328
	l16ui	a8, a8, 0	# ea,
.LBB1176:
.LBB1172:
.LBB1166:
.LBB1163:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1329
	add.n	a2, a7, a3	# tmp1251, tmp1239, _277
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1330
	l32r	a7, .LC176	#, tmp1249
.LBE1163:
.LBE1166:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:110:     sp -= 2;
	.loc 1 110 8 view .LVU1331
	addi	a4, a4, -2	# tmp1253, sp$14_533,
.LBB1167:
.LBB1164:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1332
	s16i	a3, a7, 0	# last_modified_ram, _277
	.loc 1 92 3 is_stmt 1 view .LVU1333
	.loc 1 93 5 view .LVU1334
.LBE1164:
.LBE1167:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:109:     write6502(BASE_STACK + ((sp - 1) & 0xFF), pushval & 0xFF);
	.loc 1 109 14 is_stmt 0 view .LVU1335
	s8i	a5, a2, 0	# zero_ram[_1622], tmp1237
.LBB1168:
.LBB1165:
	.loc 1 94 5 is_stmt 1 view .LVU1336
.LVL178:
	.loc 1 94 5 is_stmt 0 view .LVU1337
.LBE1165:
.LBE1168:
	.loc 1 110 5 is_stmt 1 view .LVU1338
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:110:     sp -= 2;
	.loc 1 110 8 is_stmt 0 view .LVU1339
	s8i	a4, a6, 0	# sp, tmp1253
.LVL179:
	.loc 1 110 8 view .LVU1340
.LBE1172:
.LBE1176:
	.loc 1 464 5 is_stmt 1 view .LVU1341
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:464:     pc = ea;
	.loc 1 464 8 is_stmt 0 view .LVU1342
	s16i	a8, a13, 0	# pc, ea
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:465: }
	.loc 1 465 1 view .LVU1343
	j	.L170		#
.L303:
.LBE1150:
.LBE1149:
	.loc 1 812 5 is_stmt 1 view .LVU1344
	.loc 1 813 7 view .LVU1345
.LBB1177:
.LBI1177:
	.loc 1 200 13 view .LVU1346
.LBB1178:
	.loc 1 201 5 view .LVU1347
	.loc 1 202 5 view .LVU1348
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 47 is_stmt 0 view .LVU1349
	l16ui	a2, a13, 0	# pc, pc$342_573
	addi.n	a3, a2, 1	# tmp1259, pc$342_573,
	s16i	a3, a13, 0	# pc, tmp1259
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 44 view .LVU1350
	call0	_Z8read6502t		#
.LVL180:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:202:     eahelp = (uint16_t)(((uint16_t)read6502(pc++) + (uint16_t)x) & 0xFF); //zero-page wraparound for table pointer
	.loc 1 202 66 view .LVU1351
	l32r	a3, .LC189	#, tmp1261
	l8ui	a3, a3, 0	#, x
	add.n	a3, a2, a3	# tmp1263,, x
	extui	a3, a3, 0, 8	# _578, tmp1263
.LVL181:
	.loc 1 203 5 is_stmt 1 view .LVU1352
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 28 is_stmt 0 view .LVU1353
	mov.n	a2, a3	#, _578
	s32i.n	a3, sp, 0	#,
	call0	_Z8read6502t		#
.LVL182:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 75 view .LVU1354
	l32i.n	a3, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 28 view .LVU1355
	mov.n	a4, a2	# tmp1264,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 75 view .LVU1356
	addi.n	a2, a3, 1	# tmp1266, _578,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 67 view .LVU1357
	extui	a2, a2, 0, 8	#, tmp1266
	s32i.n	a4, sp, 0	#,
	call0	_Z8read6502t		#
.LVL183:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 46 view .LVU1358
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 8 view .LVU1359
	l32r	a3, .LC179	#, tmp1271
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 89 view .LVU1360
	slli	a2, a2, 8	# tmp1272,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 46 view .LVU1361
	or	a2, a2, a4	# tmp1275, tmp1272, tmp1264
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:203:     ea = (uint16_t)read6502(eahelp & 0x00FF) | ((uint16_t)read6502((eahelp+1) & 0x00FF) << 8);
	.loc 1 203 8 view .LVU1362
	s16i	a2, a3, 0	# ea, tmp1275
	.loc 1 203 8 view .LVU1363
.LBE1178:
.LBE1177:
	.loc 1 814 7 is_stmt 1 view .LVU1364
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:814:       op_and();
	.loc 1 814 13 is_stmt 0 view .LVU1365
	call0	_Z6op_andv		#
.LVL184:
	.loc 1 815 7 is_stmt 1 view .LVU1366
	j	.L170		#
.L302:
	.loc 1 819 5 view .LVU1367
	.loc 1 820 7 view .LVU1368
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:820:       zp();
	.loc 1 820 9 is_stmt 0 view .LVU1369
	call0	_Z2zpv		#
.LVL185:
	.loc 1 821 7 is_stmt 1 view .LVU1370
.LBB1179:
.LBI1179:
	.loc 1 290 13 view .LVU1371
.LBB1180:
	.loc 1 291 5 view .LVU1372
.LBB1181:
.LBI1181:
	.loc 1 216 17 view .LVU1373
.LBB1182:
	.loc 1 217 5 view .LVU1374
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	beqz.n	a2, .L331	# useaccum,
	.loc 1 217 19 view .LVU1375
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU1376
	l32r	a2, .LC190	#, tmp1278
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU1377
	l8ui	a3, a2, 0	# _610, a
	mov.n	a4, a3	# prephitmp_1202, _610
	j	.L332		#
.L331:
.LBB1183:
.LBI1183:
	.loc 1 216 17 is_stmt 1 view .LVU1378
.LBB1184:
	.loc 1 218 14 view .LVU1379
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU1380
	l32r	a2, .LC179	#, tmp1281
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL186:
.LBE1184:
.LBE1183:
.LBE1182:
.LBE1181:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 26 view .LVU1381
	l32r	a4, .LC190	#, tmp1284
.LBB1188:
.LBB1187:
.LBB1186:
.LBB1185:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU1382
	extui	a3, a2, 0, 16	# _610, tmp1283
.LBE1185:
.LBE1186:
.LBE1187:
.LBE1188:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 26 view .LVU1383
	l8ui	a4, a4, 0	# tmp1286, a
	and	a4, a2, a4	# prephitmp_1202, tmp1283, tmp1286
.L332:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:291:     value = getvalue();
	.loc 1 291 11 view .LVU1384
	l32r	a2, .LC191	#, tmp1289
	s16i	a3, a2, 0	# value, _610
	.loc 1 292 5 is_stmt 1 view .LVU1385
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 12 is_stmt 0 view .LVU1386
	l32r	a2, .LC192	#, tmp1290
	s16i	a4, a2, 0	# result, prephitmp_1202
	.loc 1 294 5 is_stmt 1 view .LVU1387
	.loc 1 294 5 view .LVU1388
	l16ui	a2, a14, 0	# cpustatus, pretmp_1223
	beqz.n	a4, .L333	# prephitmp_1202,
	.loc 1 294 5 view .LVU1389
	movi.n	a4, -3	# tmp1292,
	and	a2, a2, a4	# _597, pretmp_1223, tmp1292
	j	.L334		#
.L333:
	.loc 1 294 5 view .LVU1390
	movi.n	a4, 2	# tmp1295,
	or	a2, a2, a4	# _597, pretmp_1223, tmp1295
.L334:
	.loc 1 294 21 view .LVU1391
	.loc 1 295 5 view .LVU1392
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 38 is_stmt 0 view .LVU1393
	movi	a4, 0xc0	# tmp1299,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 28 view .LVU1394
	extui	a2, a2, 0, 6	# tmp1298, _597,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 38 view .LVU1395
	and	a3, a3, a4	# tmp1301, _610, tmp1299
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 36 view .LVU1396
	or	a2, a2, a3	# tmp1304, tmp1298, tmp1301
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 15 view .LVU1397
	s16i	a2, a14, 0	# cpustatus, tmp1304
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:296: }
	.loc 1 296 1 view .LVU1398
	j	.L170		#
.L301:
.LBE1180:
.LBE1179:
	.loc 1 823 5 is_stmt 1 view .LVU1399
	.loc 1 824 7 view .LVU1400
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:824:       zp();
	.loc 1 824 9 is_stmt 0 view .LVU1401
	call0	_Z2zpv		#
.LVL187:
	.loc 1 825 7 is_stmt 1 view .LVU1402
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:825:       op_and();
	.loc 1 825 13 is_stmt 0 view .LVU1403
	call0	_Z6op_andv		#
.LVL188:
	.loc 1 826 7 is_stmt 1 view .LVU1404
	j	.L170		#
.L300:
	.loc 1 827 5 view .LVU1405
	.loc 1 828 7 view .LVU1406
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:828:       zp();
	.loc 1 828 9 is_stmt 0 view .LVU1407
	call0	_Z2zpv		#
.LVL189:
	.loc 1 829 7 is_stmt 1 view .LVU1408
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:829:       rol();
	.loc 1 829 10 is_stmt 0 view .LVU1409
	call0	_Z3rolv		#
.LVL190:
	.loc 1 830 7 is_stmt 1 view .LVU1410
	j	.L170		#
.L299:
	.loc 1 833 5 view .LVU1411
	.loc 1 834 7 view .LVU1412
	.loc 1 835 7 view .LVU1413
.LBB1189:
.LBI1189:
	.loc 1 531 13 view .LVU1414
.LBB1190:
	.loc 1 532 5 view .LVU1415
.LBB1191:
.LBI1191:
	.loc 1 124 16 view .LVU1416
.LBB1192:
	.loc 1 125 5 view .LVU1417
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 35 is_stmt 0 view .LVU1418
	l32r	a4, .LC174	#, tmp1305
	l8ui	a3, a4, 0	#, sp
	addi.n	a3, a3, 1	# tmp1307, sp,
	extui	a3, a3, 0, 8	# _619, tmp1307
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1419
	addmi	a2, a3, 0x100	#, _619,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 40 view .LVU1420
	s8i	a3, a4, 0	# sp, _619
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1421
	call0	_Z8read6502t		#
.LVL191:
.LBE1192:
.LBE1191:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:532:     cpustatus = pull8() | FLAG_CONSTANT;
	.loc 1 532 25 view .LVU1422
	movi.n	a3, 0x20	# tmp1314,
	or	a2, a2, a3	# tmp1315,, tmp1314
	extui	a2, a2, 0, 8	# tmp1316, tmp1315
	s16i	a2, a14, 0	# cpustatus, tmp1316
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:533: }
	.loc 1 533 1 view .LVU1423
	j	.L170		#
.L298:
.LBE1190:
.LBE1189:
	.loc 1 837 5 is_stmt 1 view .LVU1424
	.loc 1 838 7 view .LVU1425
.LBB1193:
.LBI1193:
	.loc 1 148 13 view .LVU1426
.LBB1194:
	.loc 1 149 5 view .LVU1427
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU1428
	l16ui	a2, a13, 0	# pc, pc$356_87
	addi.n	a3, a2, 1	# tmp1319, pc$356_87,
	s16i	a3, a13, 0	# pc, tmp1319
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU1429
	l32r	a3, .LC179	#, tmp1320
	s16i	a2, a3, 0	# ea, pc$356_87
.LBE1194:
.LBE1193:
	.loc 1 839 7 is_stmt 1 view .LVU1430
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:839:       op_and();
	.loc 1 839 13 is_stmt 0 view .LVU1431
	call0	_Z6op_andv		#
.LVL192:
	.loc 1 840 7 is_stmt 1 view .LVU1432
	j	.L170		#
.L297:
	.loc 1 841 5 view .LVU1433
	.loc 1 842 7 view .LVU1434
.LBB1195:
.LBI1195:
	.loc 1 144 13 view .LVU1435
.LBB1196:
	.loc 1 145 3 view .LVU1436
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:145:   useaccum = 1;
	.loc 1 145 12 is_stmt 0 view .LVU1437
	l32r	a4, .LC172	#,
	movi.n	a2, 1	# tmp1322,
	s8i	a2, a4, 0	# useaccum, tmp1322
.LBE1196:
.LBE1195:
	.loc 1 843 7 is_stmt 1 view .LVU1438
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:843:       rol();
	.loc 1 843 10 is_stmt 0 view .LVU1439
	call0	_Z3rolv		#
.LVL193:
	.loc 1 844 7 is_stmt 1 view .LVU1440
	j	.L170		#
.L296:
	.loc 1 847 5 view .LVU1441
	.loc 1 848 7 view .LVU1442
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:848:       abso();
	.loc 1 848 11 is_stmt 0 view .LVU1443
	call0	_Z4absov		#
.LVL194:
	.loc 1 849 7 is_stmt 1 view .LVU1444
.LBB1197:
.LBI1197:
	.loc 1 290 13 view .LVU1445
.LBB1198:
	.loc 1 291 5 view .LVU1446
.LBB1199:
.LBI1199:
	.loc 1 216 17 view .LVU1447
.LBB1200:
	.loc 1 217 5 view .LVU1448
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	beqz.n	a2, .L335	# useaccum,
	.loc 1 217 19 view .LVU1449
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU1450
	l32r	a2, .LC190	#, tmp1325
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU1451
	l8ui	a3, a2, 0	# _642, a
	mov.n	a4, a3	# _1152, _642
	j	.L336		#
.L335:
.LBB1201:
.LBI1201:
	.loc 1 216 17 is_stmt 1 view .LVU1452
.LBB1202:
	.loc 1 218 14 view .LVU1453
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU1454
	l32r	a2, .LC179	#, tmp1328
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL195:
.LBE1202:
.LBE1201:
.LBE1200:
.LBE1199:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 26 view .LVU1455
	l32r	a4, .LC190	#, tmp1331
.LBB1206:
.LBB1205:
.LBB1204:
.LBB1203:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU1456
	extui	a3, a2, 0, 16	# _642, tmp1330
.LBE1203:
.LBE1204:
.LBE1205:
.LBE1206:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 26 view .LVU1457
	l8ui	a4, a4, 0	# tmp1333, a
	and	a4, a2, a4	# _1152, tmp1330, tmp1333
.L336:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:291:     value = getvalue();
	.loc 1 291 11 view .LVU1458
	l32r	a2, .LC191	#, tmp1336
	s16i	a3, a2, 0	# value, _642
	.loc 1 292 5 is_stmt 1 view .LVU1459
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:292:     result = (uint16_t)a & value;
	.loc 1 292 12 is_stmt 0 view .LVU1460
	l32r	a2, .LC192	#, tmp1337
	s16i	a4, a2, 0	# result, _1152
	.loc 1 294 5 is_stmt 1 view .LVU1461
	.loc 1 294 5 view .LVU1462
	l16ui	a2, a14, 0	# cpustatus, pretmp_1215
	beqz.n	a4, .L337	# _1152,
	.loc 1 294 5 view .LVU1463
	movi.n	a4, -3	# tmp1339,
	and	a2, a2, a4	# _629, pretmp_1215, tmp1339
	j	.L338		#
.L337:
	.loc 1 294 5 view .LVU1464
	movi.n	a4, 2	# tmp1342,
	or	a2, a2, a4	# _629, pretmp_1215, tmp1342
.L338:
	.loc 1 294 21 view .LVU1465
	.loc 1 295 5 view .LVU1466
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 38 is_stmt 0 view .LVU1467
	movi	a4, 0xc0	# tmp1346,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 28 view .LVU1468
	extui	a2, a2, 0, 6	# tmp1345, _629,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 38 view .LVU1469
	and	a3, a3, a4	# tmp1348, _642, tmp1346
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 36 view .LVU1470
	or	a2, a2, a3	# tmp1351, tmp1345, tmp1348
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:295:     cpustatus = (cpustatus & 0x3F) | (uint8_t)(value & 0xC0);
	.loc 1 295 15 view .LVU1471
	s16i	a2, a14, 0	# cpustatus, tmp1351
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:296: }
	.loc 1 296 1 view .LVU1472
	j	.L170		#
.L295:
.LBE1198:
.LBE1197:
	.loc 1 851 5 is_stmt 1 view .LVU1473
	.loc 1 852 7 view .LVU1474
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:852:       abso();
	.loc 1 852 11 is_stmt 0 view .LVU1475
	call0	_Z4absov		#
.LVL196:
	.loc 1 853 7 is_stmt 1 view .LVU1476
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:853:       op_and();
	.loc 1 853 13 is_stmt 0 view .LVU1477
	call0	_Z6op_andv		#
.LVL197:
	.loc 1 854 7 is_stmt 1 view .LVU1478
	j	.L170		#
.L294:
	.loc 1 855 5 view .LVU1479
	.loc 1 856 7 view .LVU1480
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:856:       abso();
	.loc 1 856 11 is_stmt 0 view .LVU1481
	call0	_Z4absov		#
.LVL198:
	.loc 1 857 7 is_stmt 1 view .LVU1482
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:857:       rol();
	.loc 1 857 10 is_stmt 0 view .LVU1483
	call0	_Z3rolv		#
.LVL199:
	.loc 1 858 7 is_stmt 1 view .LVU1484
	j	.L170		#
.L293:
	.loc 1 861 5 view .LVU1485
	.loc 1 862 7 view .LVU1486
.LBB1207:
.LBI1207:
	.loc 1 164 13 view .LVU1487
.LBB1208:
	.loc 1 165 5 view .LVU1488
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU1489
	l16ui	a2, a13, 0	# pc, pc$374_652
.LBB1209:
.LBB1210:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU1490
	movi	a4, 0x1ff	# tmp1356,
.LBE1210:
.LBE1209:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU1491
	addi.n	a5, a2, 1	# tmp1354, pc$374_652,
	s16i	a5, a13, 0	# pc, tmp1354
.LVL200:
.LBB1215:
.LBI1209:
	.loc 1 69 9 is_stmt 1 view .LVU1492
.LBB1213:
	.loc 1 70 3 view .LVU1493
	bltu	a4, a2, .L339	# tmp1356, pc$374_652,
	.loc 1 71 5 view .LVU1494
	.loc 1 72 7 view .LVU1495
	.loc 1 75 12 view .LVU1496
	movi	a4, 0xfe	# tmp1358,
	bne	a2, a4, .L340	# pc$374_652, tmp1358,
	.loc 1 76 9 view .LVU1497
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU1498
	call0	rand		#
.LVL201:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU1499
	extui	a2, a2, 0, 8	# _663,
	j	.L621		#
.LVL202:
.L340:
	.loc 1 79 5 is_stmt 1 view .LVU1500
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU1501
	l32r	a4, .LC175	#, tmp1360
	add.n	a2, a4, a2	# tmp1361, tmp1360, pc$374_652
.LVL203:
	.loc 1 79 28 view .LVU1502
	j	.L622		#
.LVL204:
.L339:
	.loc 1 81 3 is_stmt 1 view .LVU1503
	l32r	a4, .LC180	#, tmp1362
	extui	a4, a4, 0, 16	# tmp1363, tmp1362
	bltu	a4, a2, .L342	# tmp1363, pc$374_652,
.LVL205:
.LBB1211:
.LBI1211:
	.loc 1 69 9 view .LVU1504
.LBB1212:
	.loc 1 82 5 view .LVU1505
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU1506
	addmi	a2, a2, -0x200	# tmp1364, pc$374_652,
.LVL206:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU1507
	extui	a2, a2, 0, 16	#, tmp1364
.LVL207:
	.loc 1 82 28 view .LVU1508
	call0	_Z16loadPixelFromRamt		#
.LVL208:
.L621:
	.loc 1 82 28 view .LVU1509
.LBE1212:
.LBE1211:
.LBE1213:
.LBE1215:
.LBE1208:
.LBE1207:
.LBB1220:
.LBB1221:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:299:     if ((cpustatus & FLAG_SIGN) == FLAG_SIGN) {
	.loc 1 299 20 view .LVU1510
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L341		#
.LVL209:
.L342:
	.loc 1 299 20 view .LVU1511
.LBE1221:
.LBE1220:
.LBB1226:
.LBB1217:
.LBB1216:
.LBB1214:
	.loc 1 84 3 is_stmt 1 view .LVU1512
	l32r	a4, .LC182	#, tmp1368
	extui	a4, a4, 0, 16	# tmp1369, tmp1368
	bltu	a4, a2, .L343	# tmp1369, pc$374_652,
	.loc 1 85 5 view .LVU1513
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU1514
	l32r	a4, .LC184	#, tmp1370
	add.n	a2, a4, a2	# tmp1371, tmp1370, pc$374_652
.LVL210:
	.loc 1 85 32 view .LVU1515
	addmi	a2, a2, -0x1200	# tmp1372, tmp1371,
.L622:
	.loc 1 85 32 view .LVU1516
	l8ui	a2, a2, 0	# _663,
.LVL211:
.L341:
	.loc 1 85 32 view .LVU1517
.LBE1214:
.LBE1216:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU1518
	extui	a4, a2, 0, 16	# _656, _663
	.loc 1 166 5 is_stmt 1 view .LVU1519
	bbsi	a2, 7, .L344	# _663,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU1520
	l32r	a2, .LC185	#, tmp3112
	j	.L623		#
.L344:
	.loc 1 166 25 is_stmt 1 view .LVU1521
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1522
	movi	a5, -0x100	# tmp1377,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp1378, _656, tmp1377
.L623:
.LBE1217:
.LBE1226:
	.loc 1 863 7 is_stmt 1 view .LVU1523
.LBB1227:
.LBI1220:
	.loc 1 298 13 view .LVU1524
.LBB1224:
	.loc 1 299 5 view .LVU1525
.LBE1224:
.LBE1227:
.LBB1228:
.LBB1218:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1526
	s16i	a4, a2, 0	# reladdr, tmp1378
.LBE1218:
.LBE1228:
.LBB1229:
.LBB1225:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:299:     if ((cpustatus & FLAG_SIGN) == FLAG_SIGN) {
	.loc 1 299 5 view .LVU1527
	bbci	a3, 7, .L170	# prephitmp_1199,,
.LBB1222:
.LBI1222:
	.loc 1 263 13 is_stmt 1 view .LVU1528
.LBB1223:
	.loc 1 265 9 view .LVU1529
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU1530
	l16ui	a5, a13, 0	# pc, pc$202_675
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1531
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1532
	l32r	a6, .LC187	#, tmp1389
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1533
	add.n	a3, a5, a3	# tmp1387, pc$202_675, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1534
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1241
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1535
	extui	a3, a3, 0, 16	# _677, tmp1387
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1536
	movi	a7, -0x100	# tmp1391,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU1537
	xor	a4, a5, a3	# tmp1390, pc$202_675, _677
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1538
	and	a4, a4, a7	# tmp1395, tmp1390, tmp1391
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1539
	addi.n	a7, a2, 1	# tmp1399, pretmp_1241,
	addi.n	a2, a2, 2	# tmp1397, pretmp_1241,
	moveqz	a2, a7, a4	# tmp3120, tmp1399, tmp1395
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1540
	l32r	a4, .LC186	#, tmp1384
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1541
	s16i	a3, a13, 0	# pc, _677
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1542
	s16i	a5, a4, 0	# oldpc, pc$202_675
	.loc 1 266 9 is_stmt 1 view .LVU1543
	.loc 1 267 9 view .LVU1544
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU1545
	s32i.n	a2, a6, 0	# clockticks6502, tmp3120
	j	.L170		#
.L292:
.LBE1223:
.LBE1222:
.LBE1225:
.LBE1229:
	.loc 1 865 5 is_stmt 1 view .LVU1546
	.loc 1 866 7 view .LVU1547
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:866:       indy();
	.loc 1 866 11 is_stmt 0 view .LVU1548
	call0	_Z4indyv		#
.LVL212:
	.loc 1 867 7 is_stmt 1 view .LVU1549
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:867:       op_and();
	.loc 1 867 13 is_stmt 0 view .LVU1550
	call0	_Z6op_andv		#
.LVL213:
	.loc 1 868 7 is_stmt 1 view .LVU1551
	j	.L170		#
.L291:
	.loc 1 873 5 view .LVU1552
	.loc 1 874 7 view .LVU1553
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:874:       zpx();
	.loc 1 874 10 is_stmt 0 view .LVU1554
	call0	_Z3zpxv		#
.LVL214:
	.loc 1 875 7 is_stmt 1 view .LVU1555
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:875:       op_and();
	.loc 1 875 13 is_stmt 0 view .LVU1556
	call0	_Z6op_andv		#
.LVL215:
	.loc 1 876 7 is_stmt 1 view .LVU1557
	j	.L170		#
.L290:
	.loc 1 877 5 view .LVU1558
	.loc 1 878 7 view .LVU1559
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:878:       zpx();
	.loc 1 878 10 is_stmt 0 view .LVU1560
	call0	_Z3zpxv		#
.LVL216:
	.loc 1 879 7 is_stmt 1 view .LVU1561
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:879:       rol();
	.loc 1 879 10 is_stmt 0 view .LVU1562
	call0	_Z3rolv		#
.LVL217:
	.loc 1 880 7 is_stmt 1 view .LVU1563
	j	.L170		#
.L289:
	.loc 1 883 5 view .LVU1564
	.loc 1 884 7 view .LVU1565
	.loc 1 885 7 view .LVU1566
.LBB1230:
.LBI1230:
	.loc 1 581 13 view .LVU1567
.LBB1231:
	.loc 1 582 5 view .LVU1568
	movi.n	a2, 0x21	# tmp1401,
	or	a2, a5, a2	# tmp1402, cpustatus$6_5, tmp1401
	s16i	a2, a14, 0	# cpustatus, tmp1402
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:583: }
	.loc 1 583 1 is_stmt 0 view .LVU1569
	j	.L170		#
.L288:
.LBE1231:
.LBE1230:
	.loc 1 887 5 is_stmt 1 view .LVU1570
	.loc 1 888 7 view .LVU1571
.LBB1232:
.LBI1232:
	.loc 1 183 13 view .LVU1572
.LBB1233:
	.loc 1 184 5 view .LVU1573
	.loc 1 185 5 view .LVU1574
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU1575
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL218:
	mov.n	a5, a2	# tmp1405,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1576
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1577
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1578
	addi.n	a2, a2, 1	# tmp1408, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1579
	extui	a2, a2, 0, 16	#, tmp1408
	call0	_Z8read6502t		#
.LVL219:
	.loc 1 186 5 is_stmt 1 view .LVU1580
	.loc 1 187 5 view .LVU1581
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU1582
	l32r	a4, .LC188	#, tmp1416
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1583
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1584
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU1585
	slli	a2, a2, 8	# tmp1412,,
.LVL220:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1586
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1587
	or	a2, a2, a5	# tmp1415, tmp1412, tmp1405
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1588
	add.n	a4, a4, a2	# tmp1420, y, tmp1415
	l32r	a2, .LC179	#, tmp1411
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1589
	addi.n	a3, a3, 2	# tmp1424, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1590
	s16i	a4, a2, 0	# ea, tmp1420
	.loc 1 189 5 is_stmt 1 view .LVU1591
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU1592
	s16i	a3, a13, 0	# pc, tmp1424
.LBE1233:
.LBE1232:
	.loc 1 889 7 is_stmt 1 view .LVU1593
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:889:       op_and();
	.loc 1 889 13 is_stmt 0 view .LVU1594
	call0	_Z6op_andv		#
.LVL221:
	.loc 1 890 7 is_stmt 1 view .LVU1595
	j	.L170		#
.L287:
	.loc 1 895 5 view .LVU1596
	.loc 1 896 7 view .LVU1597
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:896:       absx();
	.loc 1 896 11 is_stmt 0 view .LVU1598
	call0	_Z4absxv		#
.LVL222:
	.loc 1 897 7 is_stmt 1 view .LVU1599
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:897:       op_and();
	.loc 1 897 13 is_stmt 0 view .LVU1600
	call0	_Z6op_andv		#
.LVL223:
	.loc 1 898 7 is_stmt 1 view .LVU1601
	j	.L170		#
.L286:
	.loc 1 899 5 view .LVU1602
	.loc 1 900 7 view .LVU1603
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:900:       absx();
	.loc 1 900 11 is_stmt 0 view .LVU1604
	call0	_Z4absxv		#
.LVL224:
	.loc 1 901 7 is_stmt 1 view .LVU1605
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:901:       rol();
	.loc 1 901 10 is_stmt 0 view .LVU1606
	call0	_Z3rolv		#
.LVL225:
	.loc 1 902 7 is_stmt 1 view .LVU1607
	j	.L170		#
.L285:
	.loc 1 905 5 view .LVU1608
	.loc 1 906 7 view .LVU1609
	.loc 1 907 7 view .LVU1610
.LBB1234:
.LBI1234:
	.loc 1 558 13 view .LVU1611
.LBB1235:
	.loc 1 559 5 view .LVU1612
.LBB1236:
.LBI1236:
	.loc 1 124 16 view .LVU1613
.LBB1237:
	.loc 1 125 5 view .LVU1614
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 35 is_stmt 0 view .LVU1615
	l32r	a6, .LC174	#,
	l8ui	a3, a6, 0	#, sp
	addi.n	a3, a3, 1	# tmp1427, sp,
	extui	a3, a3, 0, 8	# _728, tmp1427
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1616
	addmi	a2, a3, 0x100	#, _728,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 40 view .LVU1617
	s8i	a3, a6, 0	# sp, _728
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1618
	call0	_Z8read6502t		#
.LVL226:
.LBE1237:
.LBE1236:
.LBB1238:
.LBB1239:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 46 view .LVU1619
	l32r	a4, .LC174	#,
.LBE1239:
.LBE1238:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:559:     cpustatus = pull8();
	.loc 1 559 22 view .LVU1620
	s16i	a2, a14, 0	# cpustatus,
	.loc 1 560 5 is_stmt 1 view .LVU1621
.LBB1242:
.LBI1238:
	.loc 1 117 17 view .LVU1622
.LBB1240:
	.loc 1 118 5 view .LVU1623
	.loc 1 119 5 view .LVU1624
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 46 is_stmt 0 view .LVU1625
	l8ui	a3, a4, 0	# sp, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 41 view .LVU1626
	addi.n	a2, a3, 1	# tmp1437, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 46 view .LVU1627
	extui	a2, a2, 0, 8	# tmp1439, tmp1437,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 22 view .LVU1628
	addmi	a2, a2, 0x100	#, tmp1439,
	call0	_Z8read6502t		#
.LVL227:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1629
	l32r	a5, .LC174	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 22 view .LVU1630
	mov.n	a4, a2	# tmp1443,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1631
	l8ui	a2, a5, 0	# sp, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 76 view .LVU1632
	s32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 95 view .LVU1633
	addi.n	a2, a2, 2	# tmp1447, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1634
	extui	a2, a2, 0, 8	# tmp1449, tmp1447,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 76 view .LVU1635
	addmi	a2, a2, 0x100	#, tmp1449,
	call0	_Z8read6502t		#
.LVL228:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1636
	l32r	a6, .LC174	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 55 view .LVU1637
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1638
	l8ui	a3, a6, 0	#, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 109 view .LVU1639
	slli	a2, a2, 8	# tmp1454,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1640
	addi.n	a3, a3, 2	# tmp1461, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 55 view .LVU1641
	or	a2, a2, a4	# tmp1457, tmp1454, tmp1443
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1642
	s8i	a3, a6, 0	# sp, tmp1461
.LBE1240:
.LBE1242:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:560:     value = pull16();
	.loc 1 560 11 view .LVU1643
	l32r	a3, .LC191	#, tmp1462
.LBB1243:
.LBB1241:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 12 view .LVU1644
	extui	a2, a2, 0, 16	# temp16, tmp1457
.LVL229:
	.loc 1 120 5 is_stmt 1 view .LVU1645
	.loc 1 121 5 view .LVU1646
	.loc 1 121 5 is_stmt 0 view .LVU1647
.LBE1241:
.LBE1243:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:560:     value = pull16();
	.loc 1 560 11 view .LVU1648
	s16i	a2, a3, 0	# value, temp16
	.loc 1 561 5 is_stmt 1 view .LVU1649
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:561:     pc = value;
	.loc 1 561 8 is_stmt 0 view .LVU1650
	s16i	a2, a13, 0	# pc, temp16
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:562: }
	.loc 1 562 1 view .LVU1651
	j	.L170		#
.L284:
.LBE1235:
.LBE1234:
	.loc 1 909 5 is_stmt 1 view .LVU1652
	.loc 1 910 7 view .LVU1653
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:910:       indx();
	.loc 1 910 11 is_stmt 0 view .LVU1654
	call0	_Z4indxv		#
.LVL230:
	.loc 1 911 7 is_stmt 1 view .LVU1655
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:911:       eor();
	.loc 1 911 10 is_stmt 0 view .LVU1656
	call0	_Z3eorv		#
.LVL231:
	.loc 1 912 7 is_stmt 1 view .LVU1657
	j	.L170		#
.L283:
	.loc 1 917 5 view .LVU1658
	.loc 1 918 7 view .LVU1659
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:918:       zp();
	.loc 1 918 9 is_stmt 0 view .LVU1660
	call0	_Z2zpv		#
.LVL232:
	.loc 1 919 7 is_stmt 1 view .LVU1661
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:919:       eor();
	.loc 1 919 10 is_stmt 0 view .LVU1662
	call0	_Z3eorv		#
.LVL233:
	.loc 1 920 7 is_stmt 1 view .LVU1663
	j	.L170		#
.L282:
	.loc 1 921 5 view .LVU1664
	.loc 1 922 7 view .LVU1665
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:922:       zp();
	.loc 1 922 9 is_stmt 0 view .LVU1666
	call0	_Z2zpv		#
.LVL234:
	.loc 1 923 7 is_stmt 1 view .LVU1667
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:923:       lsr();
	.loc 1 923 10 is_stmt 0 view .LVU1668
	call0	_Z3lsrv		#
.LVL235:
	.loc 1 924 7 is_stmt 1 view .LVU1669
	j	.L170		#
.L281:
	.loc 1 927 5 view .LVU1670
	.loc 1 928 7 view .LVU1671
	.loc 1 929 7 view .LVU1672
.LBB1244:
.LBI1244:
	.loc 1 516 13 view .LVU1673
.LBB1245:
	.loc 1 517 5 view .LVU1674
.LBB1246:
.LBB1247:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 is_stmt 0 view .LVU1675
	l32r	a5, .LC174	#, tmp1465
.LBE1247:
.LBE1246:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:517:     push8(a);
	.loc 1 517 10 view .LVU1676
	l32r	a3, .LC190	#, tmp1464
.LBB1254:
.LBB1252:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1677
	l8ui	a2, a5, 0	# sp$17_734, sp
.LBE1252:
.LBE1254:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:517:     push8(a);
	.loc 1 517 10 view .LVU1678
	l8ui	a6, a3, 0	# a$101_140, a
.LVL236:
.LBB1255:
.LBI1246:
	.loc 1 113 13 is_stmt 1 view .LVU1679
.LBB1253:
	.loc 1 114 5 view .LVU1680
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 26 is_stmt 0 view .LVU1681
	addmi	a4, a2, 0x100	# _737, sp$17_734,
.LVL237:
.LBB1248:
.LBI1248:
	.loc 1 90 6 is_stmt 1 view .LVU1682
.LBB1249:
	.loc 1 91 3 view .LVU1683
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU1684
	l32r	a3, .LC175	#, tmp1471
	.loc 1 93 23 view .LVU1685
.LBE1249:
.LBE1248:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:114:     write6502(BASE_STACK + sp--, pushval);
	.loc 1 114 30 view .LVU1686
	addi.n	a2, a2, -1	# tmp1467, sp$17_734,
	s8i	a2, a5, 0	# sp, tmp1467
.LBB1251:
.LBB1250:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1687
	l32r	a2, .LC176	#, tmp1470
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU1688
	add.n	a3, a3, a4	# tmp1472, tmp1471, _737
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU1689
	s16i	a4, a2, 0	# last_modified_ram, _737
	.loc 1 92 3 is_stmt 1 view .LVU1690
	.loc 1 93 5 view .LVU1691
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU1692
	s8i	a6, a3, 0	# zero_ram[_738], a$101_140
	.loc 1 94 5 is_stmt 1 view .LVU1693
	j	.L170		#
.LVL238:
.L280:
	.loc 1 94 5 is_stmt 0 view .LVU1694
.LBE1250:
.LBE1251:
.LBE1253:
.LBE1255:
.LBE1245:
.LBE1244:
	.loc 1 931 5 is_stmt 1 view .LVU1695
	.loc 1 932 7 view .LVU1696
.LBB1256:
.LBI1256:
	.loc 1 148 13 view .LVU1697
.LBB1257:
	.loc 1 149 5 view .LVU1698
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU1699
	l16ui	a2, a13, 0	# pc, pc$356_175
	addi.n	a3, a2, 1	# tmp1475, pc$356_175,
	s16i	a3, a13, 0	# pc, tmp1475
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU1700
	l32r	a3, .LC179	#, tmp1476
	s16i	a2, a3, 0	# ea, pc$356_175
.LBE1257:
.LBE1256:
	.loc 1 933 7 is_stmt 1 view .LVU1701
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:933:       eor();
	.loc 1 933 10 is_stmt 0 view .LVU1702
	call0	_Z3eorv		#
.LVL239:
	.loc 1 934 7 is_stmt 1 view .LVU1703
	j	.L170		#
.L279:
	.loc 1 935 5 view .LVU1704
	.loc 1 936 7 view .LVU1705
.LBB1258:
.LBI1258:
	.loc 1 144 13 view .LVU1706
.LBB1259:
	.loc 1 145 3 view .LVU1707
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:145:   useaccum = 1;
	.loc 1 145 12 is_stmt 0 view .LVU1708
	l32r	a3, .LC172	#,
	movi.n	a2, 1	# tmp1478,
	s8i	a2, a3, 0	# useaccum, tmp1478
.LBE1259:
.LBE1258:
	.loc 1 937 7 is_stmt 1 view .LVU1709
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:937:       lsr();
	.loc 1 937 10 is_stmt 0 view .LVU1710
	call0	_Z3lsrv		#
.LVL240:
	.loc 1 938 7 is_stmt 1 view .LVU1711
	j	.L170		#
.L278:
	.loc 1 941 5 view .LVU1712
	.loc 1 942 7 view .LVU1713
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:942:       abso();
	.loc 1 942 11 is_stmt 0 view .LVU1714
	call0	_Z4absov		#
.LVL241:
	.loc 1 943 7 is_stmt 1 view .LVU1715
.LBB1260:
.LBI1260:
	.loc 1 458 13 view .LVU1716
.LBB1261:
	.loc 1 459 5 view .LVU1717
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:459:     pc = ea;
	.loc 1 459 8 is_stmt 0 view .LVU1718
	l32r	a2, .LC179	#, tmp1480
	l16ui	a2, a2, 0	# ea,
	s16i	a2, a13, 0	# pc, ea
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:460: }
	.loc 1 460 1 view .LVU1719
	j	.L170		#
.L277:
.LBE1261:
.LBE1260:
	.loc 1 945 5 is_stmt 1 view .LVU1720
	.loc 1 946 7 view .LVU1721
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:946:       abso();
	.loc 1 946 11 is_stmt 0 view .LVU1722
	call0	_Z4absov		#
.LVL242:
	.loc 1 947 7 is_stmt 1 view .LVU1723
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:947:       eor();
	.loc 1 947 10 is_stmt 0 view .LVU1724
	call0	_Z3eorv		#
.LVL243:
	.loc 1 948 7 is_stmt 1 view .LVU1725
	j	.L170		#
.L276:
	.loc 1 949 5 view .LVU1726
	.loc 1 950 7 view .LVU1727
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:950:       abso();
	.loc 1 950 11 is_stmt 0 view .LVU1728
	call0	_Z4absov		#
.LVL244:
	.loc 1 951 7 is_stmt 1 view .LVU1729
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:951:       lsr();
	.loc 1 951 10 is_stmt 0 view .LVU1730
	call0	_Z3lsrv		#
.LVL245:
	.loc 1 952 7 is_stmt 1 view .LVU1731
	j	.L170		#
.L275:
	.loc 1 955 5 view .LVU1732
	.loc 1 956 7 view .LVU1733
.LBB1262:
.LBI1262:
	.loc 1 164 13 view .LVU1734
.LBB1263:
	.loc 1 165 5 view .LVU1735
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU1736
	l16ui	a2, a13, 0	# pc, pc$374_754
.LBB1264:
.LBB1265:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU1737
	movi	a4, 0x1ff	# tmp1486,
.LBE1265:
.LBE1264:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU1738
	addi.n	a5, a2, 1	# tmp1484, pc$374_754,
	s16i	a5, a13, 0	# pc, tmp1484
.LVL246:
.LBB1270:
.LBI1264:
	.loc 1 69 9 is_stmt 1 view .LVU1739
.LBB1268:
	.loc 1 70 3 view .LVU1740
	bltu	a4, a2, .L348	# tmp1486, pc$374_754,
	.loc 1 71 5 view .LVU1741
	.loc 1 72 7 view .LVU1742
	.loc 1 75 12 view .LVU1743
	movi	a4, 0xfe	# tmp1488,
	bne	a2, a4, .L349	# pc$374_754, tmp1488,
	.loc 1 76 9 view .LVU1744
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU1745
	call0	rand		#
.LVL247:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU1746
	extui	a2, a2, 0, 8	# _765,
	j	.L624		#
.LVL248:
.L349:
	.loc 1 79 5 is_stmt 1 view .LVU1747
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU1748
	l32r	a4, .LC175	#, tmp1490
	add.n	a2, a4, a2	# tmp1491, tmp1490, pc$374_754
.LVL249:
	.loc 1 79 28 view .LVU1749
	j	.L625		#
.LVL250:
.L348:
	.loc 1 81 3 is_stmt 1 view .LVU1750
	l32r	a4, .LC180	#, tmp1492
	extui	a4, a4, 0, 16	# tmp1493, tmp1492
	bltu	a4, a2, .L351	# tmp1493, pc$374_754,
.LVL251:
.LBB1266:
.LBI1266:
	.loc 1 69 9 view .LVU1751
.LBB1267:
	.loc 1 82 5 view .LVU1752
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU1753
	addmi	a2, a2, -0x200	# tmp1494, pc$374_754,
.LVL252:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU1754
	extui	a2, a2, 0, 16	#, tmp1494
.LVL253:
	.loc 1 82 28 view .LVU1755
	call0	_Z16loadPixelFromRamt		#
.LVL254:
.L624:
	.loc 1 82 28 view .LVU1756
.LBE1267:
.LBE1266:
.LBE1268:
.LBE1270:
.LBE1263:
.LBE1262:
.LBB1275:
.LBB1276:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:334:     if ((cpustatus & FLAG_OVERFLOW) == 0) {
	.loc 1 334 20 view .LVU1757
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L350		#
.LVL255:
.L351:
	.loc 1 334 20 view .LVU1758
.LBE1276:
.LBE1275:
.LBB1281:
.LBB1272:
.LBB1271:
.LBB1269:
	.loc 1 84 3 is_stmt 1 view .LVU1759
	l32r	a4, .LC182	#, tmp1498
	extui	a4, a4, 0, 16	# tmp1499, tmp1498
	bltu	a4, a2, .L352	# tmp1499, pc$374_754,
	.loc 1 85 5 view .LVU1760
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU1761
	l32r	a4, .LC184	#, tmp1500
	add.n	a2, a4, a2	# tmp1501, tmp1500, pc$374_754
.LVL256:
	.loc 1 85 32 view .LVU1762
	addmi	a2, a2, -0x1200	# tmp1502, tmp1501,
.L625:
	.loc 1 85 32 view .LVU1763
	l8ui	a2, a2, 0	# _765,
.LVL257:
.L350:
	.loc 1 85 32 view .LVU1764
.LBE1269:
.LBE1271:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU1765
	extui	a4, a2, 0, 16	# _758, _765
	.loc 1 166 5 is_stmt 1 view .LVU1766
	bbsi	a2, 7, .L353	# _765,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU1767
	l32r	a2, .LC185	#, tmp3112
	j	.L626		#
.L353:
	.loc 1 166 25 is_stmt 1 view .LVU1768
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1769
	movi	a5, -0x100	# tmp1507,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp1508, _758, tmp1507
.L626:
.LBE1272:
.LBE1281:
	.loc 1 957 7 is_stmt 1 view .LVU1770
.LBB1282:
.LBI1275:
	.loc 1 333 13 view .LVU1771
.LBB1279:
	.loc 1 334 5 view .LVU1772
.LBE1279:
.LBE1282:
.LBB1283:
.LBB1273:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU1773
	s16i	a4, a2, 0	# reladdr, tmp1508
.LBE1273:
.LBE1283:
.LBB1284:
.LBB1280:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:334:     if ((cpustatus & FLAG_OVERFLOW) == 0) {
	.loc 1 334 5 view .LVU1774
	bbsi	a3, 6, .L170	# prephitmp_1199,,
.LBB1277:
.LBI1277:
	.loc 1 263 13 is_stmt 1 view .LVU1775
.LBB1278:
	.loc 1 265 9 view .LVU1776
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU1777
	l16ui	a5, a13, 0	# pc, pc$202_777
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1778
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1779
	l32r	a6, .LC187	#, tmp1519
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1780
	add.n	a3, a5, a3	# tmp1517, pc$202_777, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1781
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1281
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1782
	extui	a3, a3, 0, 16	# _779, tmp1517
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1783
	movi	a7, -0x100	# tmp1521,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU1784
	xor	a4, a5, a3	# tmp1520, pc$202_777, _779
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU1785
	and	a4, a4, a7	# tmp1525, tmp1520, tmp1521
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU1786
	addi.n	a7, a2, 1	# tmp1529, pretmp_1281,
	addi.n	a2, a2, 2	# tmp1527, pretmp_1281,
	moveqz	a2, a7, a4	# tmp3121, tmp1529, tmp1525
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1787
	l32r	a4, .LC186	#, tmp1514
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU1788
	s16i	a3, a13, 0	# pc, _779
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU1789
	s16i	a5, a4, 0	# oldpc, pc$202_777
	.loc 1 266 9 is_stmt 1 view .LVU1790
	.loc 1 267 9 view .LVU1791
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU1792
	s32i.n	a2, a6, 0	# clockticks6502, tmp3121
	j	.L170		#
.L274:
.LBE1278:
.LBE1277:
.LBE1280:
.LBE1284:
	.loc 1 959 5 is_stmt 1 view .LVU1793
	.loc 1 960 7 view .LVU1794
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:960:       indy();
	.loc 1 960 11 is_stmt 0 view .LVU1795
	call0	_Z4indyv		#
.LVL258:
	.loc 1 961 7 is_stmt 1 view .LVU1796
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:961:       eor();
	.loc 1 961 10 is_stmt 0 view .LVU1797
	call0	_Z3eorv		#
.LVL259:
	.loc 1 962 7 is_stmt 1 view .LVU1798
	j	.L170		#
.L273:
	.loc 1 967 5 view .LVU1799
	.loc 1 968 7 view .LVU1800
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:968:       zpx();
	.loc 1 968 10 is_stmt 0 view .LVU1801
	call0	_Z3zpxv		#
.LVL260:
	.loc 1 969 7 is_stmt 1 view .LVU1802
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:969:       eor();
	.loc 1 969 10 is_stmt 0 view .LVU1803
	call0	_Z3eorv		#
.LVL261:
	.loc 1 970 7 is_stmt 1 view .LVU1804
	j	.L170		#
.L272:
	.loc 1 971 5 view .LVU1805
	.loc 1 972 7 view .LVU1806
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:972:       zpx();
	.loc 1 972 10 is_stmt 0 view .LVU1807
	call0	_Z3zpxv		#
.LVL262:
	.loc 1 973 7 is_stmt 1 view .LVU1808
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:973:       lsr();
	.loc 1 973 10 is_stmt 0 view .LVU1809
	call0	_Z3lsrv		#
.LVL263:
	.loc 1 974 7 is_stmt 1 view .LVU1810
	j	.L170		#
.L271:
	.loc 1 977 5 view .LVU1811
	.loc 1 978 7 view .LVU1812
	.loc 1 979 7 view .LVU1813
.LBB1285:
.LBI1285:
	.loc 1 359 13 view .LVU1814
.LBB1286:
	.loc 1 360 5 view .LVU1815
	movi.n	a2, -5	# tmp1531,
	and	a2, a5, a2	# tmp1532, cpustatus$6_5, tmp1531
	movi.n	a4, 0x20	#,
	or	a2, a2, a4	# tmp1535, tmp1532,
	s16i	a2, a14, 0	# cpustatus, tmp1535
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:361: }
	.loc 1 361 1 is_stmt 0 view .LVU1816
	j	.L170		#
.L270:
.LBE1286:
.LBE1285:
	.loc 1 981 5 is_stmt 1 view .LVU1817
	.loc 1 982 7 view .LVU1818
.LBB1287:
.LBI1287:
	.loc 1 183 13 view .LVU1819
.LBB1288:
	.loc 1 184 5 view .LVU1820
	.loc 1 185 5 view .LVU1821
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU1822
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL264:
	mov.n	a5, a2	# tmp1538,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1823
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1824
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU1825
	addi.n	a2, a2, 1	# tmp1541, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU1826
	extui	a2, a2, 0, 16	#, tmp1541
	call0	_Z8read6502t		#
.LVL265:
	.loc 1 186 5 is_stmt 1 view .LVU1827
	.loc 1 187 5 view .LVU1828
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU1829
	l32r	a4, .LC188	#, tmp1549
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1830
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1831
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU1832
	slli	a2, a2, 8	# tmp1545,,
.LVL266:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1833
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU1834
	or	a2, a2, a5	# tmp1548, tmp1545, tmp1538
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1835
	add.n	a4, a4, a2	# tmp1553, y, tmp1548
	l32r	a2, .LC179	#, tmp1544
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU1836
	addi.n	a3, a3, 2	# tmp1557, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU1837
	s16i	a4, a2, 0	# ea, tmp1553
	.loc 1 189 5 is_stmt 1 view .LVU1838
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU1839
	s16i	a3, a13, 0	# pc, tmp1557
.LBE1288:
.LBE1287:
	.loc 1 983 7 is_stmt 1 view .LVU1840
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:983:       eor();
	.loc 1 983 10 is_stmt 0 view .LVU1841
	call0	_Z3eorv		#
.LVL267:
	.loc 1 984 7 is_stmt 1 view .LVU1842
	j	.L170		#
.L269:
	.loc 1 989 5 view .LVU1843
	.loc 1 990 7 view .LVU1844
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:990:       absx();
	.loc 1 990 11 is_stmt 0 view .LVU1845
	call0	_Z4absxv		#
.LVL268:
	.loc 1 991 7 is_stmt 1 view .LVU1846
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:991:       eor();
	.loc 1 991 10 is_stmt 0 view .LVU1847
	call0	_Z3eorv		#
.LVL269:
	.loc 1 992 7 is_stmt 1 view .LVU1848
	j	.L170		#
.L268:
	.loc 1 993 5 view .LVU1849
	.loc 1 994 7 view .LVU1850
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:994:       absx();
	.loc 1 994 11 is_stmt 0 view .LVU1851
	call0	_Z4absxv		#
.LVL270:
	.loc 1 995 7 is_stmt 1 view .LVU1852
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:995:       lsr();
	.loc 1 995 10 is_stmt 0 view .LVU1853
	call0	_Z3lsrv		#
.LVL271:
	.loc 1 996 7 is_stmt 1 view .LVU1854
	j	.L170		#
.L267:
	.loc 1 999 5 view .LVU1855
	.loc 1 1000 7 view .LVU1856
	.loc 1 1001 7 view .LVU1857
.LBB1289:
.LBI1289:
	.loc 1 564 13 view .LVU1858
.LBB1290:
	.loc 1 565 5 view .LVU1859
.LBB1291:
.LBI1291:
	.loc 1 117 17 view .LVU1860
.LBB1292:
	.loc 1 118 5 view .LVU1861
	.loc 1 119 5 view .LVU1862
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 46 is_stmt 0 view .LVU1863
	l32r	a5, .LC174	#,
	l8ui	a2, a5, 0	# sp, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 41 view .LVU1864
	addi.n	a2, a2, 1	# tmp1561, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 46 view .LVU1865
	extui	a2, a2, 0, 8	# tmp1563, tmp1561,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 22 view .LVU1866
	addmi	a2, a2, 0x100	#, tmp1563,
	call0	_Z8read6502t		#
.LVL272:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1867
	l32r	a6, .LC174	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 22 view .LVU1868
	mov.n	a4, a2	# tmp1567,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1869
	l8ui	a2, a6, 0	# sp, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 76 view .LVU1870
	s32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 95 view .LVU1871
	addi.n	a2, a2, 2	# tmp1571, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 100 view .LVU1872
	extui	a2, a2, 0, 8	# tmp1573, tmp1571,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 76 view .LVU1873
	addmi	a2, a2, 0x100	#, tmp1573,
	call0	_Z8read6502t		#
.LVL273:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1874
	l32r	a5, .LC174	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 55 view .LVU1875
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1876
	l8ui	a3, a5, 0	#, sp
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 109 view .LVU1877
	slli	a2, a2, 8	# tmp1578,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 55 view .LVU1878
	or	a2, a2, a4	# tmp1581, tmp1578, tmp1567
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 view .LVU1879
	addi.n	a3, a3, 2	# tmp1585, sp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:119:     temp16 = read6502(BASE_STACK + ((sp + 1) & 0xFF)) | ((uint16_t)read6502(BASE_STACK + ((sp + 2) & 0xFF)) << 8);
	.loc 1 119 12 view .LVU1880
	extui	a2, a2, 0, 16	# temp16, tmp1581
.LVL274:
	.loc 1 120 5 is_stmt 1 view .LVU1881
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:120:     sp += 2;
	.loc 1 120 8 is_stmt 0 view .LVU1882
	s8i	a3, a5, 0	# sp, tmp1585
	.loc 1 121 5 is_stmt 1 view .LVU1883
.LVL275:
	.loc 1 121 5 is_stmt 0 view .LVU1884
.LBE1292:
.LBE1291:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:565:     value = pull16();
	.loc 1 565 11 view .LVU1885
	l32r	a3, .LC191	#, tmp1586
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:566:     pc = value + 1;
	.loc 1 566 16 view .LVU1886
	addi.n	a4, a2, 1	# tmp1588, temp16,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:565:     value = pull16();
	.loc 1 565 11 view .LVU1887
	s16i	a2, a3, 0	# value, temp16
	.loc 1 566 5 is_stmt 1 view .LVU1888
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:566:     pc = value + 1;
	.loc 1 566 8 is_stmt 0 view .LVU1889
	s16i	a4, a13, 0	# pc, tmp1588
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:567: }
	.loc 1 567 1 view .LVU1890
	j	.L170		#
.L266:
.LBE1290:
.LBE1289:
	.loc 1 1003 5 is_stmt 1 view .LVU1891
	.loc 1 1004 7 view .LVU1892
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1004:       indx();
	.loc 1 1004 11 is_stmt 0 view .LVU1893
	call0	_Z4indxv		#
.LVL276:
	.loc 1 1005 7 is_stmt 1 view .LVU1894
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1005:       adc();
	.loc 1 1005 10 is_stmt 0 view .LVU1895
	call0	_Z3adcv		#
.LVL277:
	.loc 1 1006 7 is_stmt 1 view .LVU1896
	j	.L170		#
.L265:
	.loc 1 1011 5 view .LVU1897
	.loc 1 1012 7 view .LVU1898
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1012:       zp();
	.loc 1 1012 9 is_stmt 0 view .LVU1899
	call0	_Z2zpv		#
.LVL278:
	.loc 1 1013 7 is_stmt 1 view .LVU1900
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1013:       adc();
	.loc 1 1013 10 is_stmt 0 view .LVU1901
	call0	_Z3adcv		#
.LVL279:
	.loc 1 1014 7 is_stmt 1 view .LVU1902
	j	.L170		#
.L264:
	.loc 1 1015 5 view .LVU1903
	.loc 1 1016 7 view .LVU1904
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1016:       zp();
	.loc 1 1016 9 is_stmt 0 view .LVU1905
	call0	_Z2zpv		#
.LVL280:
	.loc 1 1017 7 is_stmt 1 view .LVU1906
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1017:       ror();
	.loc 1 1017 10 is_stmt 0 view .LVU1907
	call0	_Z3rorv		#
.LVL281:
	.loc 1 1018 7 is_stmt 1 view .LVU1908
	j	.L170		#
.L263:
	.loc 1 1021 5 view .LVU1909
	.loc 1 1022 7 view .LVU1910
	.loc 1 1023 7 view .LVU1911
.LBB1293:
.LBI1293:
	.loc 1 524 13 view .LVU1912
.LBB1294:
	.loc 1 525 5 view .LVU1913
.LBB1295:
.LBI1295:
	.loc 1 124 16 view .LVU1914
.LBB1296:
	.loc 1 125 5 view .LVU1915
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 35 is_stmt 0 view .LVU1916
	l32r	a4, .LC174	#, tmp1589
	l8ui	a3, a4, 0	#, sp
	addi.n	a3, a3, 1	# tmp1591, sp,
	extui	a3, a3, 0, 8	# _839, tmp1591
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1917
	addmi	a2, a3, 0x100	#, _839,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 40 view .LVU1918
	s8i	a3, a4, 0	# sp, _839
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:125:     return (read6502(BASE_STACK + ++sp));
	.loc 1 125 21 view .LVU1919
	call0	_Z8read6502t		#
.LVL282:
.LBE1296:
.LBE1295:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:525:     a = pull8();
	.loc 1 525 7 view .LVU1920
	l32r	a3, .LC190	#, tmp1597
	s8i	a2, a3, 0	# a, tmp1596
	.loc 1 527 5 is_stmt 1 view .LVU1921
	.loc 1 527 5 view .LVU1922
	beqz.n	a2, .L356	# tmp1596,
	.loc 1 527 5 view .LVU1923
	l16ui	a3, a14, 0	# cpustatus, tmp1601
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:528:     signcalc(a);
	.loc 1 528 5 is_stmt 0 view .LVU1924
	slli	a4, a2, 24	# tmp1603, tmp1596,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:527:     zerocalc(a);
	.loc 1 527 5 view .LVU1925
	movi.n	a2, -3	# tmp1599,
	and	a2, a3, a2	# _832, tmp1601, tmp1599
	.loc 1 527 16 is_stmt 1 view .LVU1926
	.loc 1 528 5 view .LVU1927
	.loc 1 528 5 view .LVU1928
	bltz	a4, .L357	# tmp1603,
	j	.L358		#
.L356:
	.loc 1 527 5 view .LVU1929
	l16ui	a2, a14, 0	# cpustatus,
	movi.n	a3, 2	# tmp1605,
	or	a2, a2, a3	# tmp1607, cpustatus, tmp1605
	extui	a2, a2, 0, 16	# _832, tmp1607
	.loc 1 527 16 view .LVU1930
	.loc 1 528 5 view .LVU1931
	.loc 1 528 5 view .LVU1932
	j	.L358		#
.L357:
	.loc 1 528 5 view .LVU1933
	movi	a3, 0x80	# tmp1609,
	or	a2, a2, a3	# tmp1610, _832, tmp1609
	s16i	a2, a14, 0	# cpustatus, tmp1610
	j	.L170		#
.L358:
	.loc 1 528 5 view .LVU1934
	movi	a3, -0x81	# tmp1612,
	and	a2, a2, a3	# tmp1613, _832, tmp1612
	s16i	a2, a14, 0	# cpustatus, tmp1613
	j	.L170		#
.L262:
.LBE1294:
.LBE1293:
	.loc 1 1025 5 view .LVU1935
	.loc 1 1026 7 view .LVU1936
.LBB1297:
.LBI1297:
	.loc 1 148 13 view .LVU1937
.LBB1298:
	.loc 1 149 5 view .LVU1938
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU1939
	l16ui	a2, a13, 0	# pc, pc$356_263
	addi.n	a3, a2, 1	# tmp1616, pc$356_263,
	s16i	a3, a13, 0	# pc, tmp1616
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU1940
	l32r	a3, .LC179	#, tmp1617
	s16i	a2, a3, 0	# ea, pc$356_263
.LBE1298:
.LBE1297:
	.loc 1 1027 7 is_stmt 1 view .LVU1941
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1027:       adc();
	.loc 1 1027 10 is_stmt 0 view .LVU1942
	call0	_Z3adcv		#
.LVL283:
	.loc 1 1028 7 is_stmt 1 view .LVU1943
	j	.L170		#
.L261:
	.loc 1 1029 5 view .LVU1944
	.loc 1 1030 7 view .LVU1945
.LBB1299:
.LBI1299:
	.loc 1 144 13 view .LVU1946
.LBB1300:
	.loc 1 145 3 view .LVU1947
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:145:   useaccum = 1;
	.loc 1 145 12 is_stmt 0 view .LVU1948
	l32r	a6, .LC172	#,
	movi.n	a2, 1	# tmp1619,
	s8i	a2, a6, 0	# useaccum, tmp1619
.LBE1300:
.LBE1299:
	.loc 1 1031 7 is_stmt 1 view .LVU1949
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1031:       ror();
	.loc 1 1031 10 is_stmt 0 view .LVU1950
	call0	_Z3rorv		#
.LVL284:
	.loc 1 1032 7 is_stmt 1 view .LVU1951
	j	.L170		#
.L260:
	.loc 1 1035 5 view .LVU1952
	.loc 1 1036 7 view .LVU1953
.LBB1301:
.LBI1301:
	.loc 1 192 13 view .LVU1954
.LBB1302:
	.loc 1 193 5 view .LVU1955
	.loc 1 194 5 view .LVU1956
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 32 is_stmt 0 view .LVU1957
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL285:
	mov.n	a4, a2	# tmp1622,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 71 view .LVU1958
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 68 view .LVU1959
	s32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 71 view .LVU1960
	addi.n	a2, a2, 1	# tmp1625, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 68 view .LVU1961
	extui	a2, a2, 0, 16	#, tmp1625
	call0	_Z8read6502t		#
.LVL286:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 12 view .LVU1962
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 75 view .LVU1963
	slli	a3, a2, 8	# tmp1629,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:194:     eahelp = (uint16_t)read6502(pc) | (uint16_t)((uint16_t)read6502(pc+1) << 8);
	.loc 1 194 12 view .LVU1964
	or	a3, a3, a4	# tmp1632, tmp1629, tmp1622
	extui	a3, a3, 0, 16	# eahelp, tmp1632
.LVL287:
	.loc 1 195 5 is_stmt 1 view .LVU1965
	.loc 1 196 5 view .LVU1966
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 28 is_stmt 0 view .LVU1967
	mov.n	a2, a3	#, eahelp
	s32i.n	a3, sp, 0	#,
	call0	_Z8read6502t		#
.LVL288:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:195:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
	.loc 1 195 44 view .LVU1968
	l32i.n	a3, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 28 view .LVU1969
	mov.n	a4, a2	# tmp1633,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:195:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
	.loc 1 195 23 view .LVU1970
	movi	a5, -0x100	# tmp1637,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:195:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
	.loc 1 195 44 view .LVU1971
	addi.n	a2, a3, 1	# tmp1634, eahelp,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:195:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
	.loc 1 195 49 view .LVU1972
	extui	a2, a2, 0, 8	# tmp1636, tmp1634,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:195:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //replicate 6502 page-boundary wraparound bug
	.loc 1 195 23 view .LVU1973
	and	a3, a3, a5	# tmp1639, eahelp, tmp1637
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 58 view .LVU1974
	or	a2, a2, a3	#, tmp1636, tmp1639
	s32i.n	a4, sp, 0	#,
	call0	_Z8read6502t		#
.LVL289:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 37 view .LVU1975
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 68 view .LVU1976
	slli	a2, a2, 8	# tmp1645,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 8 view .LVU1977
	l32r	a3, .LC179	#, tmp1649
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 37 view .LVU1978
	or	a2, a2, a4	# tmp1648, tmp1645, tmp1633
	extui	a2, a2, 0, 16	# _871, tmp1648
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:196:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 196 8 view .LVU1979
	s16i	a2, a3, 0	# ea, _871
	.loc 1 197 5 is_stmt 1 view .LVU1980
	.loc 1 197 5 is_stmt 0 view .LVU1981
.LBE1302:
.LBE1301:
	.loc 1 1037 7 is_stmt 1 view .LVU1982
.LBB1303:
.LBI1303:
	.loc 1 458 13 view .LVU1983
.LBB1304:
	.loc 1 459 5 view .LVU1984
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:459:     pc = ea;
	.loc 1 459 8 is_stmt 0 view .LVU1985
	s16i	a2, a13, 0	# pc, _871
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:460: }
	.loc 1 460 1 view .LVU1986
	j	.L170		#
.L259:
.LBE1304:
.LBE1303:
	.loc 1 1039 5 is_stmt 1 view .LVU1987
	.loc 1 1040 7 view .LVU1988
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1040:       abso();
	.loc 1 1040 11 is_stmt 0 view .LVU1989
	call0	_Z4absov		#
.LVL290:
	.loc 1 1041 7 is_stmt 1 view .LVU1990
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1041:       adc();
	.loc 1 1041 10 is_stmt 0 view .LVU1991
	call0	_Z3adcv		#
.LVL291:
	.loc 1 1042 7 is_stmt 1 view .LVU1992
	j	.L170		#
.L258:
	.loc 1 1043 5 view .LVU1993
	.loc 1 1044 7 view .LVU1994
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1044:       abso();
	.loc 1 1044 11 is_stmt 0 view .LVU1995
	call0	_Z4absov		#
.LVL292:
	.loc 1 1045 7 is_stmt 1 view .LVU1996
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1045:       ror();
	.loc 1 1045 10 is_stmt 0 view .LVU1997
	call0	_Z3rorv		#
.LVL293:
	.loc 1 1046 7 is_stmt 1 view .LVU1998
	j	.L170		#
.L257:
	.loc 1 1049 5 view .LVU1999
	.loc 1 1050 7 view .LVU2000
.LBB1305:
.LBI1305:
	.loc 1 164 13 view .LVU2001
.LBB1306:
	.loc 1 165 5 view .LVU2002
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU2003
	l16ui	a2, a13, 0	# pc, pc$374_876
.LBB1307:
.LBB1308:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU2004
	movi	a4, 0x1ff	# tmp1655,
.LBE1308:
.LBE1307:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU2005
	addi.n	a5, a2, 1	# tmp1653, pc$374_876,
	s16i	a5, a13, 0	# pc, tmp1653
.LVL294:
.LBB1313:
.LBI1307:
	.loc 1 69 9 is_stmt 1 view .LVU2006
.LBB1311:
	.loc 1 70 3 view .LVU2007
	bltu	a4, a2, .L359	# tmp1655, pc$374_876,
	.loc 1 71 5 view .LVU2008
	.loc 1 72 7 view .LVU2009
	.loc 1 75 12 view .LVU2010
	movi	a4, 0xfe	# tmp1657,
	bne	a2, a4, .L360	# pc$374_876, tmp1657,
	.loc 1 76 9 view .LVU2011
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU2012
	call0	rand		#
.LVL295:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU2013
	extui	a2, a2, 0, 8	# _887,
	j	.L627		#
.LVL296:
.L360:
	.loc 1 79 5 is_stmt 1 view .LVU2014
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU2015
	l32r	a4, .LC175	#, tmp1659
	add.n	a2, a4, a2	# tmp1660, tmp1659, pc$374_876
.LVL297:
	.loc 1 79 28 view .LVU2016
	j	.L628		#
.LVL298:
.L359:
	.loc 1 81 3 is_stmt 1 view .LVU2017
	l32r	a4, .LC180	#, tmp1661
	extui	a4, a4, 0, 16	# tmp1662, tmp1661
	bltu	a4, a2, .L362	# tmp1662, pc$374_876,
.LVL299:
.LBB1309:
.LBI1309:
	.loc 1 69 9 view .LVU2018
.LBB1310:
	.loc 1 82 5 view .LVU2019
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU2020
	addmi	a2, a2, -0x200	# tmp1663, pc$374_876,
.LVL300:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU2021
	extui	a2, a2, 0, 16	#, tmp1663
.LVL301:
	.loc 1 82 28 view .LVU2022
	call0	_Z16loadPixelFromRamt		#
.LVL302:
.L627:
	.loc 1 82 28 view .LVU2023
.LBE1310:
.LBE1309:
.LBE1311:
.LBE1313:
.LBE1306:
.LBE1305:
.LBB1318:
.LBB1319:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:343:     if ((cpustatus & FLAG_OVERFLOW) == FLAG_OVERFLOW) {
	.loc 1 343 20 view .LVU2024
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L361		#
.LVL303:
.L362:
	.loc 1 343 20 view .LVU2025
.LBE1319:
.LBE1318:
.LBB1324:
.LBB1315:
.LBB1314:
.LBB1312:
	.loc 1 84 3 is_stmt 1 view .LVU2026
	l32r	a4, .LC182	#, tmp1667
	extui	a4, a4, 0, 16	# tmp1668, tmp1667
	bltu	a4, a2, .L363	# tmp1668, pc$374_876,
	.loc 1 85 5 view .LVU2027
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU2028
	l32r	a4, .LC184	#, tmp1669
	add.n	a2, a4, a2	# tmp1670, tmp1669, pc$374_876
.LVL304:
	.loc 1 85 32 view .LVU2029
	addmi	a2, a2, -0x1200	# tmp1671, tmp1670,
.L628:
	.loc 1 85 32 view .LVU2030
	l8ui	a2, a2, 0	# _887,
.LVL305:
.L361:
	.loc 1 85 32 view .LVU2031
.LBE1312:
.LBE1314:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU2032
	extui	a4, a2, 0, 16	# _880, _887
	.loc 1 166 5 is_stmt 1 view .LVU2033
	bbsi	a2, 7, .L364	# _887,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU2034
	l32r	a2, .LC185	#, tmp3112
	j	.L629		#
.L364:
	.loc 1 166 25 is_stmt 1 view .LVU2035
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU2036
	movi	a5, -0x100	# tmp1676,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp1677, _880, tmp1676
.L629:
.LBE1315:
.LBE1324:
	.loc 1 1051 7 is_stmt 1 view .LVU2037
.LBB1325:
.LBI1318:
	.loc 1 342 13 view .LVU2038
.LBB1322:
	.loc 1 343 5 view .LVU2039
.LBE1322:
.LBE1325:
.LBB1326:
.LBB1316:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU2040
	s16i	a4, a2, 0	# reladdr, tmp1677
.LBE1316:
.LBE1326:
.LBB1327:
.LBB1323:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:343:     if ((cpustatus & FLAG_OVERFLOW) == FLAG_OVERFLOW) {
	.loc 1 343 5 view .LVU2041
	bbci	a3, 6, .L170	# prephitmp_1199,,
.LBB1320:
.LBI1320:
	.loc 1 263 13 is_stmt 1 view .LVU2042
.LBB1321:
	.loc 1 265 9 view .LVU2043
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU2044
	l16ui	a5, a13, 0	# pc, pc$202_899
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2045
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2046
	l32r	a6, .LC187	#, tmp1688
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2047
	add.n	a3, a5, a3	# tmp1686, pc$202_899, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2048
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1276
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2049
	extui	a3, a3, 0, 16	# _901, tmp1686
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU2050
	movi	a7, -0x100	# tmp1690,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU2051
	xor	a4, a5, a3	# tmp1689, pc$202_899, _901
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU2052
	and	a4, a4, a7	# tmp1694, tmp1689, tmp1690
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2053
	addi.n	a7, a2, 1	# tmp1698, pretmp_1276,
	addi.n	a2, a2, 2	# tmp1696, pretmp_1276,
	moveqz	a2, a7, a4	# tmp3122, tmp1698, tmp1694
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU2054
	l32r	a4, .LC186	#, tmp1683
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2055
	s16i	a3, a13, 0	# pc, _901
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU2056
	s16i	a5, a4, 0	# oldpc, pc$202_899
	.loc 1 266 9 is_stmt 1 view .LVU2057
	.loc 1 267 9 view .LVU2058
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU2059
	s32i.n	a2, a6, 0	# clockticks6502, tmp3122
	j	.L170		#
.L256:
.LBE1321:
.LBE1320:
.LBE1323:
.LBE1327:
	.loc 1 1053 5 is_stmt 1 view .LVU2060
	.loc 1 1054 7 view .LVU2061
.LBB1328:
.LBI1328:
	.loc 1 206 13 view .LVU2062
.LBB1329:
	.loc 1 207 5 view .LVU2063
	.loc 1 208 5 view .LVU2064
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 35 is_stmt 0 view .LVU2065
	l16ui	a2, a13, 0	# pc, pc$386_908
	addi.n	a3, a2, 1	# tmp1701, pc$386_908,
	s16i	a3, a13, 0	# pc, tmp1701
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:208:     eahelp = (uint16_t)read6502(pc++);
	.loc 1 208 32 view .LVU2066
	call0	_Z8read6502t		#
.LVL306:
	.loc 1 209 5 is_stmt 1 view .LVU2067
	.loc 1 210 5 view .LVU2068
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 28 is_stmt 0 view .LVU2069
	s32i.n	a2, sp, 0	#, tmp3
	call0	_Z8read6502t		#
.LVL307:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:209:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //zero-page wraparound
	.loc 1 209 44 view .LVU2070
	l32i.n	a3, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 28 view .LVU2071
	mov.n	a4, a2	# tmp1703,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:209:     eahelp2 = (eahelp & 0xFF00) | ((eahelp + 1) & 0x00FF); //zero-page wraparound
	.loc 1 209 44 view .LVU2072
	addi.n	a2, a3, 1	# tmp1705, tmp1702,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 58 view .LVU2073
	extui	a2, a2, 0, 8	#, tmp1705
	s32i.n	a4, sp, 0	#,
	call0	_Z8read6502t		#
.LVL308:
	.loc 1 211 5 is_stmt 1 view .LVU2074
	.loc 1 212 5 view .LVU2075
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 is_stmt 0 view .LVU2076
	l32r	a3, .LC188	#, tmp1716
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 37 view .LVU2077
	l32i.n	a4, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU2078
	l8ui	a3, a3, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 68 view .LVU2079
	slli	a2, a2, 8	# tmp1712,,
.LVL309:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:210:     ea = (uint16_t)read6502(eahelp) | ((uint16_t)read6502(eahelp2) << 8);
	.loc 1 210 37 view .LVU2080
	or	a2, a2, a4	# tmp1715, tmp1712, tmp1703
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:212:     ea += (uint16_t)y;
	.loc 1 212 8 view .LVU2081
	add.n	a3, a3, a2	# tmp1720, y, tmp1715
	l32r	a2, .LC179	#, tmp1711
	s16i	a3, a2, 0	# ea, tmp1720
	.loc 1 212 8 view .LVU2082
.LBE1329:
.LBE1328:
	.loc 1 1055 7 is_stmt 1 view .LVU2083
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1055:       adc();
	.loc 1 1055 10 is_stmt 0 view .LVU2084
	call0	_Z3adcv		#
.LVL310:
	.loc 1 1056 7 is_stmt 1 view .LVU2085
	j	.L170		#
.L255:
	.loc 1 1061 5 view .LVU2086
	.loc 1 1062 7 view .LVU2087
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1062:       zpx();
	.loc 1 1062 10 is_stmt 0 view .LVU2088
	call0	_Z3zpxv		#
.LVL311:
	.loc 1 1063 7 is_stmt 1 view .LVU2089
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1063:       adc();
	.loc 1 1063 10 is_stmt 0 view .LVU2090
	call0	_Z3adcv		#
.LVL312:
	.loc 1 1064 7 is_stmt 1 view .LVU2091
	j	.L170		#
.L254:
	.loc 1 1065 5 view .LVU2092
	.loc 1 1066 7 view .LVU2093
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1066:       zpx();
	.loc 1 1066 10 is_stmt 0 view .LVU2094
	call0	_Z3zpxv		#
.LVL313:
	.loc 1 1067 7 is_stmt 1 view .LVU2095
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1067:       ror();
	.loc 1 1067 10 is_stmt 0 view .LVU2096
	call0	_Z3rorv		#
.LVL314:
	.loc 1 1068 7 is_stmt 1 view .LVU2097
	j	.L170		#
.L253:
	.loc 1 1071 5 view .LVU2098
	.loc 1 1072 7 view .LVU2099
	.loc 1 1073 7 view .LVU2100
.LBB1330:
.LBI1330:
	.loc 1 589 13 view .LVU2101
.LBB1331:
	.loc 1 590 5 view .LVU2102
	movi.n	a2, 0x24	# tmp1722,
	or	a2, a5, a2	# tmp1723, cpustatus$6_5, tmp1722
	s16i	a2, a14, 0	# cpustatus, tmp1723
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:591: }
	.loc 1 591 1 is_stmt 0 view .LVU2103
	j	.L170		#
.L252:
.LBE1331:
.LBE1330:
	.loc 1 1075 5 is_stmt 1 view .LVU2104
	.loc 1 1076 7 view .LVU2105
.LBB1332:
.LBI1332:
	.loc 1 183 13 view .LVU2106
.LBB1333:
	.loc 1 184 5 view .LVU2107
	.loc 1 185 5 view .LVU2108
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU2109
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL315:
	mov.n	a5, a2	# tmp1726,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU2110
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU2111
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU2112
	addi.n	a2, a2, 1	# tmp1729, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU2113
	extui	a2, a2, 0, 16	#, tmp1729
	call0	_Z8read6502t		#
.LVL316:
	.loc 1 186 5 is_stmt 1 view .LVU2114
	.loc 1 187 5 view .LVU2115
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU2116
	l32r	a4, .LC188	#, tmp1737
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU2117
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2118
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU2119
	slli	a2, a2, 8	# tmp1733,,
.LVL317:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU2120
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU2121
	or	a2, a2, a5	# tmp1736, tmp1733, tmp1726
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2122
	add.n	a4, a4, a2	# tmp1741, y, tmp1736
	l32r	a2, .LC179	#, tmp1732
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU2123
	addi.n	a3, a3, 2	# tmp1745, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2124
	s16i	a4, a2, 0	# ea, tmp1741
	.loc 1 189 5 is_stmt 1 view .LVU2125
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU2126
	s16i	a3, a13, 0	# pc, tmp1745
.LBE1333:
.LBE1332:
	.loc 1 1077 7 is_stmt 1 view .LVU2127
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1077:       adc();
	.loc 1 1077 10 is_stmt 0 view .LVU2128
	call0	_Z3adcv		#
.LVL318:
	.loc 1 1078 7 is_stmt 1 view .LVU2129
	j	.L170		#
.L251:
	.loc 1 1083 5 view .LVU2130
	.loc 1 1084 7 view .LVU2131
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1084:       absx();
	.loc 1 1084 11 is_stmt 0 view .LVU2132
	call0	_Z4absxv		#
.LVL319:
	.loc 1 1085 7 is_stmt 1 view .LVU2133
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1085:       adc();
	.loc 1 1085 10 is_stmt 0 view .LVU2134
	call0	_Z3adcv		#
.LVL320:
	.loc 1 1086 7 is_stmt 1 view .LVU2135
	j	.L170		#
.L250:
	.loc 1 1087 5 view .LVU2136
	.loc 1 1088 7 view .LVU2137
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1088:       absx();
	.loc 1 1088 11 is_stmt 0 view .LVU2138
	call0	_Z4absxv		#
.LVL321:
	.loc 1 1089 7 is_stmt 1 view .LVU2139
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1089:       ror();
	.loc 1 1089 10 is_stmt 0 view .LVU2140
	call0	_Z3rorv		#
.LVL322:
	.loc 1 1090 7 is_stmt 1 view .LVU2141
	j	.L170		#
.L249:
	.loc 1 1094 5 view .LVU2142
	.loc 1 1095 7 view .LVU2143
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1095:       indx();
	.loc 1 1095 11 is_stmt 0 view .LVU2144
	call0	_Z4indxv		#
.LVL323:
	.loc 1 1096 7 is_stmt 1 view .LVU2145
.LBB1334:
.LBI1334:
	.loc 1 593 13 view .LVU2146
.LBB1335:
	.loc 1 594 5 view .LVU2147
.LBB1336:
.LBI1336:
	.loc 1 225 13 view .LVU2148
.LBB1337:
	.loc 1 226 5 view .LVU2149
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1338:
.LBB1339:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2150
	l32r	a2, .LC179	#, tmp1749
.LBB1340:
.LBB1341:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2151
	l32r	a3, .LC176	#, tmp1750
.LBE1341:
.LBE1340:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2152
	l16ui	a2, a2, 0	# ea, ea$53_952
.LBB1346:
.LBB1344:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2153
	movi	a4, 0x1ff	# tmp1752,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2154
	s16i	a2, a3, 0	# last_modified_ram, ea$53_952
.LBE1344:
.LBE1346:
.LBE1339:
.LBE1338:
.LBE1337:
.LBE1336:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2155
	l32r	a3, .LC190	#, tmp1748
.LVL324:
	.loc 1 594 13 view .LVU2156
	l8ui	a3, a3, 0	# a$220_279, a
.LVL325:
.LBB1351:
.LBB1350:
.LBB1349:
.LBI1338:
	.loc 1 225 13 is_stmt 1 view .LVU2157
.LBB1348:
	.loc 1 227 14 view .LVU2158
.LBB1347:
.LBI1340:
	.loc 1 90 6 view .LVU2159
.LBB1345:
	.loc 1 91 3 view .LVU2160
	.loc 1 92 3 view .LVU2161
	bltu	a4, a2, .L367	# tmp1752, ea$53_952,
	.loc 1 93 5 view .LVU2162
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2163
	l32r	a4, .LC175	#, tmp1753
	add.n	a2, a4, a2	# tmp1754, tmp1753, ea$53_952
	s8i	a3, a2, 0	# zero_ram[_953], a$220_279
	.loc 1 94 5 is_stmt 1 view .LVU2164
	j	.L170		#
.L367:
.LVL326:
.LBB1342:
.LBI1342:
	.loc 1 90 6 view .LVU2165
.LBB1343:
	.loc 1 96 3 view .LVU2166
	l32r	a4, .LC180	#, tmp1755
	extui	a4, a4, 0, 16	# tmp1756, tmp1755
	bltu	a4, a2, .L368	# tmp1756, ea$53_952,
	.loc 1 97 5 view .LVU2167
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2168
	addmi	a2, a2, -0x200	# tmp1757, ea$53_952,
.LVL327:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2169
	extui	a2, a2, 0, 16	#, tmp1757
	call0	_Z14drawPixelToRamth		#
.LVL328:
	.loc 1 98 5 is_stmt 1 view .LVU2170
	j	.L170		#
.LVL329:
.L368:
	.loc 1 100 3 view .LVU2171
	l32r	a4, .LC182	#, tmp1759
	extui	a4, a4, 0, 16	# tmp1760, tmp1759
	bltu	a4, a2, .L170	# tmp1760, ea$53_952,
	.loc 1 101 5 view .LVU2172
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2173
	l32r	a4, .LC184	#, tmp1761
	add.n	a2, a4, a2	# tmp1762, tmp1761, ea$53_952
.LVL330:
	.loc 1 101 27 view .LVU2174
	addmi	a2, a2, -0x1200	# tmp1763, tmp1762,
	s8i	a3, a2, 0	# RAM[_967], a$220_279
	.loc 1 102 5 is_stmt 1 view .LVU2175
	j	.L170		#
.LVL331:
.L248:
	.loc 1 102 5 is_stmt 0 view .LVU2176
.LBE1343:
.LBE1342:
.LBE1345:
.LBE1347:
.LBE1348:
.LBE1349:
.LBE1350:
.LBE1351:
.LBE1335:
.LBE1334:
	.loc 1 1101 5 is_stmt 1 view .LVU2177
	.loc 1 1102 7 view .LVU2178
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1102:       zp();
	.loc 1 1102 9 is_stmt 0 view .LVU2179
	call0	_Z2zpv		#
.LVL332:
	.loc 1 1103 7 is_stmt 1 view .LVU2180
.LBB1352:
.LBI1352:
	.loc 1 601 13 view .LVU2181
.LBB1353:
	.loc 1 602 5 view .LVU2182
.LBB1354:
.LBB1355:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2183
	l32r	a4, .LC172	#,
.LBE1355:
.LBE1354:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2184
	l32r	a3, .LC188	#, tmp1764
.LBB1366:
.LBB1364:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2185
	l8ui	a2, a4, 0	# useaccum, useaccum
.LBE1364:
.LBE1366:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2186
	l8ui	a3, a3, 0	# y$209_281, y
.LVL333:
.LBB1367:
.LBI1354:
	.loc 1 225 13 is_stmt 1 view .LVU2187
.LBB1365:
	.loc 1 226 5 view .LVU2188
	beqz.n	a2, .L369	# useaccum,
	.loc 1 226 19 view .LVU2189
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2190
	l32r	a2, .LC190	#, tmp1767
	s8i	a3, a2, 0	# a, y$209_281
	j	.L170		#
.L369:
.LVL334:
.LBB1356:
.LBI1356:
	.loc 1 225 13 is_stmt 1 view .LVU2191
.LBB1357:
	.loc 1 227 14 view .LVU2192
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2193
	l32r	a2, .LC179	#, tmp1768
.LBB1358:
.LBB1359:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2194
	l32r	a5, .LC176	#, tmp1769
.LBE1359:
.LBE1358:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2195
	l16ui	a2, a2, 0	# ea, ea$53_973
.LVL335:
.LBB1363:
.LBI1358:
	.loc 1 90 6 is_stmt 1 view .LVU2196
.LBB1362:
	.loc 1 91 3 view .LVU2197
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU2198
	movi	a4, 0x1ff	# tmp1771,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2199
	s16i	a2, a5, 0	# last_modified_ram, ea$53_973
	.loc 1 92 3 is_stmt 1 view .LVU2200
	bltu	a4, a2, .L370	# tmp1771, ea$53_973,
	.loc 1 93 5 view .LVU2201
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2202
	l32r	a4, .LC175	#, tmp1772
	add.n	a2, a4, a2	# tmp1773, tmp1772, ea$53_973
	s8i	a3, a2, 0	# zero_ram[_974], y$209_281
	.loc 1 94 5 is_stmt 1 view .LVU2203
	j	.L170		#
.L370:
.LVL336:
.LBB1360:
.LBI1360:
	.loc 1 90 6 view .LVU2204
.LBB1361:
	.loc 1 96 3 view .LVU2205
	l32r	a4, .LC180	#, tmp1774
	extui	a4, a4, 0, 16	# tmp1775, tmp1774
	bltu	a4, a2, .L371	# tmp1775, ea$53_973,
	.loc 1 97 5 view .LVU2206
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2207
	addmi	a2, a2, -0x200	# tmp1776, ea$53_973,
.LVL337:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2208
	extui	a2, a2, 0, 16	#, tmp1776
	call0	_Z14drawPixelToRamth		#
.LVL338:
	.loc 1 98 5 is_stmt 1 view .LVU2209
	j	.L170		#
.LVL339:
.L371:
	.loc 1 100 3 view .LVU2210
	l32r	a4, .LC182	#, tmp1778
	extui	a4, a4, 0, 16	# tmp1779, tmp1778
	bltu	a4, a2, .L170	# tmp1779, ea$53_973,
	.loc 1 101 5 view .LVU2211
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2212
	l32r	a4, .LC184	#, tmp1780
	add.n	a2, a4, a2	# tmp1781, tmp1780, ea$53_973
.LVL340:
	.loc 1 101 27 view .LVU2213
	addmi	a2, a2, -0x1200	# tmp1782, tmp1781,
	s8i	a3, a2, 0	# RAM[_988], y$209_281
	.loc 1 102 5 is_stmt 1 view .LVU2214
	j	.L170		#
.LVL341:
.L247:
	.loc 1 102 5 is_stmt 0 view .LVU2215
.LBE1361:
.LBE1360:
.LBE1362:
.LBE1363:
.LBE1357:
.LBE1356:
.LBE1365:
.LBE1367:
.LBE1353:
.LBE1352:
	.loc 1 1105 5 is_stmt 1 view .LVU2216
	.loc 1 1106 7 view .LVU2217
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1106:       zp();
	.loc 1 1106 9 is_stmt 0 view .LVU2218
	call0	_Z2zpv		#
.LVL342:
	.loc 1 1107 7 is_stmt 1 view .LVU2219
.LBB1368:
.LBI1368:
	.loc 1 593 13 view .LVU2220
.LBB1369:
	.loc 1 594 5 view .LVU2221
.LBB1370:
.LBI1370:
	.loc 1 225 13 view .LVU2222
.LBB1371:
	.loc 1 226 5 view .LVU2223
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1372:
.LBB1373:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2224
	l32r	a2, .LC179	#, tmp1786
.LBB1374:
.LBB1375:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2225
	l32r	a3, .LC176	#, tmp1787
.LBE1375:
.LBE1374:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2226
	l16ui	a2, a2, 0	# ea, ea$53_994
.LBB1380:
.LBB1378:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2227
	movi	a4, 0x1ff	# tmp1789,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2228
	s16i	a2, a3, 0	# last_modified_ram, ea$53_994
.LBE1378:
.LBE1380:
.LBE1373:
.LBE1372:
.LBE1371:
.LBE1370:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2229
	l32r	a3, .LC190	#, tmp1785
.LVL343:
	.loc 1 594 13 view .LVU2230
	l8ui	a3, a3, 0	# a$220_283, a
.LVL344:
.LBB1385:
.LBB1384:
.LBB1383:
.LBI1372:
	.loc 1 225 13 is_stmt 1 view .LVU2231
.LBB1382:
	.loc 1 227 14 view .LVU2232
.LBB1381:
.LBI1374:
	.loc 1 90 6 view .LVU2233
.LBB1379:
	.loc 1 91 3 view .LVU2234
	.loc 1 92 3 view .LVU2235
	bltu	a4, a2, .L372	# tmp1789, ea$53_994,
	.loc 1 93 5 view .LVU2236
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2237
	l32r	a4, .LC175	#, tmp1790
	add.n	a2, a4, a2	# tmp1791, tmp1790, ea$53_994
	s8i	a3, a2, 0	# zero_ram[_995], a$220_283
	.loc 1 94 5 is_stmt 1 view .LVU2238
	j	.L170		#
.L372:
.LVL345:
.LBB1376:
.LBI1376:
	.loc 1 90 6 view .LVU2239
.LBB1377:
	.loc 1 96 3 view .LVU2240
	l32r	a4, .LC180	#, tmp1792
	extui	a4, a4, 0, 16	# tmp1793, tmp1792
	bltu	a4, a2, .L373	# tmp1793, ea$53_994,
	.loc 1 97 5 view .LVU2241
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2242
	addmi	a2, a2, -0x200	# tmp1794, ea$53_994,
.LVL346:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2243
	extui	a2, a2, 0, 16	#, tmp1794
	call0	_Z14drawPixelToRamth		#
.LVL347:
	.loc 1 98 5 is_stmt 1 view .LVU2244
	j	.L170		#
.LVL348:
.L373:
	.loc 1 100 3 view .LVU2245
	l32r	a4, .LC182	#, tmp1796
	extui	a4, a4, 0, 16	# tmp1797, tmp1796
	bltu	a4, a2, .L170	# tmp1797, ea$53_994,
	.loc 1 101 5 view .LVU2246
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2247
	l32r	a4, .LC184	#, tmp1798
	add.n	a2, a4, a2	# tmp1799, tmp1798, ea$53_994
.LVL349:
	.loc 1 101 27 view .LVU2248
	addmi	a2, a2, -0x1200	# tmp1800, tmp1799,
	s8i	a3, a2, 0	# RAM[_1009], a$220_283
	.loc 1 102 5 is_stmt 1 view .LVU2249
	j	.L170		#
.LVL350:
.L246:
	.loc 1 102 5 is_stmt 0 view .LVU2250
.LBE1377:
.LBE1376:
.LBE1379:
.LBE1381:
.LBE1382:
.LBE1383:
.LBE1384:
.LBE1385:
.LBE1369:
.LBE1368:
	.loc 1 1109 5 is_stmt 1 view .LVU2251
	.loc 1 1110 7 view .LVU2252
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1110:       zp();
	.loc 1 1110 9 is_stmt 0 view .LVU2253
	call0	_Z2zpv		#
.LVL351:
	.loc 1 1111 7 is_stmt 1 view .LVU2254
.LBB1386:
.LBI1386:
	.loc 1 597 13 view .LVU2255
.LBB1387:
	.loc 1 598 5 view .LVU2256
.LBB1388:
.LBB1389:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2257
	l32r	a6, .LC172	#,
.LBE1389:
.LBE1388:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:598:     putvalue(x);
	.loc 1 598 13 view .LVU2258
	l32r	a3, .LC189	#, tmp1801
.LBB1400:
.LBB1398:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2259
	l8ui	a2, a6, 0	# useaccum, useaccum
.LBE1398:
.LBE1400:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:598:     putvalue(x);
	.loc 1 598 13 view .LVU2260
	l8ui	a3, a3, 0	# x$210_285, x
.LVL352:
.LBB1401:
.LBI1388:
	.loc 1 225 13 is_stmt 1 view .LVU2261
.LBB1399:
	.loc 1 226 5 view .LVU2262
	beqz.n	a2, .L374	# useaccum,
	.loc 1 226 19 view .LVU2263
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2264
	l32r	a2, .LC190	#, tmp1804
	s8i	a3, a2, 0	# a, x$210_285
	j	.L170		#
.L374:
.LVL353:
.LBB1390:
.LBI1390:
	.loc 1 225 13 is_stmt 1 view .LVU2265
.LBB1391:
	.loc 1 227 14 view .LVU2266
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2267
	l32r	a2, .LC179	#, tmp1805
.LBB1392:
.LBB1393:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2268
	l32r	a5, .LC176	#, tmp1806
.LBE1393:
.LBE1392:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2269
	l16ui	a2, a2, 0	# ea, ea$53_1015
.LVL354:
.LBB1397:
.LBI1392:
	.loc 1 90 6 is_stmt 1 view .LVU2270
.LBB1396:
	.loc 1 91 3 view .LVU2271
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU2272
	movi	a4, 0x1ff	# tmp1808,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2273
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1015
	.loc 1 92 3 is_stmt 1 view .LVU2274
	bltu	a4, a2, .L375	# tmp1808, ea$53_1015,
	.loc 1 93 5 view .LVU2275
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2276
	l32r	a4, .LC175	#, tmp1809
	add.n	a2, a4, a2	# tmp1810, tmp1809, ea$53_1015
	s8i	a3, a2, 0	# zero_ram[_1016], x$210_285
	.loc 1 94 5 is_stmt 1 view .LVU2277
	j	.L170		#
.L375:
.LVL355:
.LBB1394:
.LBI1394:
	.loc 1 90 6 view .LVU2278
.LBB1395:
	.loc 1 96 3 view .LVU2279
	l32r	a4, .LC180	#, tmp1811
	extui	a4, a4, 0, 16	# tmp1812, tmp1811
	bltu	a4, a2, .L376	# tmp1812, ea$53_1015,
	.loc 1 97 5 view .LVU2280
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2281
	addmi	a2, a2, -0x200	# tmp1813, ea$53_1015,
.LVL356:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2282
	extui	a2, a2, 0, 16	#, tmp1813
	call0	_Z14drawPixelToRamth		#
.LVL357:
	.loc 1 98 5 is_stmt 1 view .LVU2283
	j	.L170		#
.LVL358:
.L376:
	.loc 1 100 3 view .LVU2284
	l32r	a4, .LC182	#, tmp1815
	extui	a4, a4, 0, 16	# tmp1816, tmp1815
	bltu	a4, a2, .L170	# tmp1816, ea$53_1015,
	.loc 1 101 5 view .LVU2285
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2286
	l32r	a4, .LC184	#, tmp1817
	add.n	a2, a4, a2	# tmp1818, tmp1817, ea$53_1015
.LVL359:
	.loc 1 101 27 view .LVU2287
	addmi	a2, a2, -0x1200	# tmp1819, tmp1818,
	s8i	a3, a2, 0	# RAM[_1030], x$210_285
	.loc 1 102 5 is_stmt 1 view .LVU2288
	j	.L170		#
.LVL360:
.L245:
	.loc 1 102 5 is_stmt 0 view .LVU2289
.LBE1395:
.LBE1394:
.LBE1396:
.LBE1397:
.LBE1391:
.LBE1390:
.LBE1399:
.LBE1401:
.LBE1387:
.LBE1386:
	.loc 1 1115 5 is_stmt 1 view .LVU2290
	.loc 1 1116 7 view .LVU2291
	.loc 1 1117 7 view .LVU2292
.LBB1402:
.LBI1402:
	.loc 1 417 13 view .LVU2293
.LBB1403:
	.loc 1 418 5 view .LVU2294
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:418:     y--;
	.loc 1 418 6 is_stmt 0 view .LVU2295
	l32r	a3, .LC188	#, tmp1820
	l8ui	a2, a3, 0	#, y
	addi.n	a2, a2, -1	# tmp1822, y,
	extui	a2, a2, 0, 8	# _1032, tmp1822
	s8i	a2, a3, 0	# y, _1032
	.loc 1 420 5 is_stmt 1 view .LVU2296
	.loc 1 420 5 view .LVU2297
	beqz.n	a2, .L377	# _1032,
	.loc 1 420 5 view .LVU2298
	movi.n	a3, -3	# tmp1824,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:421:     signcalc(y);
	.loc 1 421 5 is_stmt 0 view .LVU2299
	slli	a2, a2, 24	# tmp1827, _1032,
	and	a5, a5, a3	# _2165, cpustatus$6_5, tmp1824
	.loc 1 420 16 is_stmt 1 view .LVU2300
	.loc 1 421 5 view .LVU2301
	.loc 1 421 5 view .LVU2302
	bltz	a2, .L378	# tmp1827,
	j	.L609		#
.L377:
	.loc 1 420 5 view .LVU2303
	movi.n	a2, 0x22	# tmp1829,
	or	a2, a5, a2	# cstore_416, cpustatus$6_5, tmp1829
	.loc 1 420 16 view .LVU2304
	.loc 1 421 5 view .LVU2305
	.loc 1 421 5 view .LVU2306
	j	.L380		#
.L378:
	.loc 1 421 5 view .LVU2307
	movi	a2, 0xa0	# tmp1831,
	or	a5, a5, a2	# tmp1832, _2165, tmp1831
	s16i	a5, a14, 0	# cpustatus, tmp1832
	j	.L170		#
.L609:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:420:     zerocalc(y);
	.loc 1 420 5 is_stmt 0 view .LVU2308
	movi.n	a2, 0x20	#,
	or	a5, a5, a2	# tmp1834, _2165,
	extui	a2, a5, 0, 16	# cstore_416, tmp1834
.L380:
	.loc 1 421 5 is_stmt 1 view .LVU2309
	movi	a3, -0x81	# tmp1836,
	and	a2, a2, a3	# tmp1837, cstore_416, tmp1836
	s16i	a2, a14, 0	# cpustatus, tmp1837
	j	.L170		#
.L244:
.LBE1403:
.LBE1402:
	.loc 1 1119 5 view .LVU2310
	.loc 1 1120 7 view .LVU2311
	.loc 1 1121 7 view .LVU2312
.LBB1404:
.LBI1404:
	.loc 1 626 13 view .LVU2313
.LBB1405:
	.loc 1 627 5 view .LVU2314
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:627:     a = x;
	.loc 1 627 7 is_stmt 0 view .LVU2315
	l32r	a2, .LC189	#, tmp1838
	l32r	a3, .LC190	#, tmp1839
	l8ui	a2, a2, 0	# x$193_1042, x
	s8i	a2, a3, 0	# a, x$193_1042
	.loc 1 629 5 is_stmt 1 view .LVU2316
	.loc 1 629 5 view .LVU2317
	beqz.n	a2, .L381	# x$193_1042,
	.loc 1 629 5 view .LVU2318
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:630:     signcalc(a);
	.loc 1 630 5 is_stmt 0 view .LVU2319
	slli	a3, a2, 24	# tmp1843, x$193_1042,
	movi.n	a2, -3	# tmp1840,
	and	a2, a5, a2	# _2454, cpustatus$6_5, tmp1840
	.loc 1 629 16 is_stmt 1 view .LVU2320
	.loc 1 630 5 view .LVU2321
	.loc 1 630 5 view .LVU2322
	bltz	a3, .L382	# tmp1843,
	j	.L610		#
.L381:
	.loc 1 629 5 view .LVU2323
	movi.n	a2, 0x22	# tmp1845,
	or	a2, a5, a2	# _1046, cpustatus$6_5, tmp1845
	.loc 1 629 16 view .LVU2324
	.loc 1 630 5 view .LVU2325
	.loc 1 630 5 view .LVU2326
	j	.L384		#
.L382:
	.loc 1 630 5 view .LVU2327
	movi	a3, 0xa0	# tmp1847,
	or	a2, a2, a3	# tmp1848, _2454, tmp1847
	s16i	a2, a14, 0	# cpustatus, tmp1848
	j	.L170		#
.L610:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:629:     zerocalc(a);
	.loc 1 629 5 is_stmt 0 view .LVU2328
	movi.n	a3, 0x20	#,
	or	a2, a2, a3	# tmp1850, _2454,
	extui	a2, a2, 0, 16	# _1046, tmp1850
.L384:
	.loc 1 630 5 is_stmt 1 view .LVU2329
	movi	a3, -0x81	# tmp1852,
	and	a2, a2, a3	# tmp1853, _1046, tmp1852
	s16i	a2, a14, 0	# cpustatus, tmp1853
	j	.L170		#
.L243:
.LBE1405:
.LBE1404:
	.loc 1 1125 5 view .LVU2330
	.loc 1 1126 7 view .LVU2331
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1126:       abso();
	.loc 1 1126 11 is_stmt 0 view .LVU2332
	call0	_Z4absov		#
.LVL361:
	.loc 1 1127 7 is_stmt 1 view .LVU2333
.LBB1406:
.LBI1406:
	.loc 1 601 13 view .LVU2334
.LBB1407:
	.loc 1 602 5 view .LVU2335
.LBB1408:
.LBB1409:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2336
	l32r	a4, .LC172	#,
.LBE1409:
.LBE1408:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2337
	l32r	a3, .LC188	#, tmp1854
.LBB1420:
.LBB1418:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2338
	l8ui	a2, a4, 0	# useaccum, useaccum
.LBE1418:
.LBE1420:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2339
	l8ui	a3, a3, 0	# y$209_287, y
.LVL362:
.LBB1421:
.LBI1408:
	.loc 1 225 13 is_stmt 1 view .LVU2340
.LBB1419:
	.loc 1 226 5 view .LVU2341
	beqz.n	a2, .L385	# useaccum,
	.loc 1 226 19 view .LVU2342
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2343
	l32r	a2, .LC190	#, tmp1857
	s8i	a3, a2, 0	# a, y$209_287
	j	.L170		#
.L385:
.LVL363:
.LBB1410:
.LBI1410:
	.loc 1 225 13 is_stmt 1 view .LVU2344
.LBB1411:
	.loc 1 227 14 view .LVU2345
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2346
	l32r	a2, .LC179	#, tmp1858
.LBB1412:
.LBB1413:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2347
	l32r	a5, .LC176	#, tmp1859
.LBE1413:
.LBE1412:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2348
	l16ui	a2, a2, 0	# ea, ea$53_1057
.LVL364:
.LBB1417:
.LBI1412:
	.loc 1 90 6 is_stmt 1 view .LVU2349
.LBB1416:
	.loc 1 91 3 view .LVU2350
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU2351
	movi	a4, 0x1ff	# tmp1861,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2352
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1057
	.loc 1 92 3 is_stmt 1 view .LVU2353
	bltu	a4, a2, .L386	# tmp1861, ea$53_1057,
	.loc 1 93 5 view .LVU2354
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2355
	l32r	a4, .LC175	#, tmp1862
	add.n	a2, a4, a2	# tmp1863, tmp1862, ea$53_1057
	s8i	a3, a2, 0	# zero_ram[_1058], y$209_287
	.loc 1 94 5 is_stmt 1 view .LVU2356
	j	.L170		#
.L386:
.LVL365:
.LBB1414:
.LBI1414:
	.loc 1 90 6 view .LVU2357
.LBB1415:
	.loc 1 96 3 view .LVU2358
	l32r	a4, .LC180	#, tmp1864
	extui	a4, a4, 0, 16	# tmp1865, tmp1864
	bltu	a4, a2, .L387	# tmp1865, ea$53_1057,
	.loc 1 97 5 view .LVU2359
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2360
	addmi	a2, a2, -0x200	# tmp1866, ea$53_1057,
.LVL366:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2361
	extui	a2, a2, 0, 16	#, tmp1866
	call0	_Z14drawPixelToRamth		#
.LVL367:
	.loc 1 98 5 is_stmt 1 view .LVU2362
	j	.L170		#
.LVL368:
.L387:
	.loc 1 100 3 view .LVU2363
	l32r	a4, .LC182	#, tmp1868
	extui	a4, a4, 0, 16	# tmp1869, tmp1868
	bltu	a4, a2, .L170	# tmp1869, ea$53_1057,
	.loc 1 101 5 view .LVU2364
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2365
	l32r	a4, .LC184	#, tmp1870
	add.n	a2, a4, a2	# tmp1871, tmp1870, ea$53_1057
.LVL369:
	.loc 1 101 27 view .LVU2366
	addmi	a2, a2, -0x1200	# tmp1872, tmp1871,
	s8i	a3, a2, 0	# RAM[_1072], y$209_287
	.loc 1 102 5 is_stmt 1 view .LVU2367
	j	.L170		#
.LVL370:
.L242:
	.loc 1 102 5 is_stmt 0 view .LVU2368
.LBE1415:
.LBE1414:
.LBE1416:
.LBE1417:
.LBE1411:
.LBE1410:
.LBE1419:
.LBE1421:
.LBE1407:
.LBE1406:
	.loc 1 1129 5 is_stmt 1 view .LVU2369
	.loc 1 1130 7 view .LVU2370
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1130:       abso();
	.loc 1 1130 11 is_stmt 0 view .LVU2371
	call0	_Z4absov		#
.LVL371:
	.loc 1 1131 7 is_stmt 1 view .LVU2372
.LBB1422:
.LBI1422:
	.loc 1 593 13 view .LVU2373
.LBB1423:
	.loc 1 594 5 view .LVU2374
.LBB1424:
.LBI1424:
	.loc 1 225 13 view .LVU2375
.LBB1425:
	.loc 1 226 5 view .LVU2376
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1426:
.LBB1427:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2377
	l32r	a2, .LC179	#, tmp1876
.LBB1428:
.LBB1429:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2378
	l32r	a3, .LC176	#, tmp1877
.LBE1429:
.LBE1428:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2379
	l16ui	a2, a2, 0	# ea, ea$53_1078
.LBB1434:
.LBB1432:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2380
	movi	a4, 0x1ff	# tmp1879,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2381
	s16i	a2, a3, 0	# last_modified_ram, ea$53_1078
.LBE1432:
.LBE1434:
.LBE1427:
.LBE1426:
.LBE1425:
.LBE1424:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2382
	l32r	a3, .LC190	#, tmp1875
.LVL372:
	.loc 1 594 13 view .LVU2383
	l8ui	a3, a3, 0	# a$220_289, a
.LVL373:
.LBB1439:
.LBB1438:
.LBB1437:
.LBI1426:
	.loc 1 225 13 is_stmt 1 view .LVU2384
.LBB1436:
	.loc 1 227 14 view .LVU2385
.LBB1435:
.LBI1428:
	.loc 1 90 6 view .LVU2386
.LBB1433:
	.loc 1 91 3 view .LVU2387
	.loc 1 92 3 view .LVU2388
	bltu	a4, a2, .L388	# tmp1879, ea$53_1078,
	.loc 1 93 5 view .LVU2389
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2390
	l32r	a4, .LC175	#, tmp1880
	add.n	a2, a4, a2	# tmp1881, tmp1880, ea$53_1078
	s8i	a3, a2, 0	# zero_ram[_1079], a$220_289
	.loc 1 94 5 is_stmt 1 view .LVU2391
	j	.L170		#
.L388:
.LVL374:
.LBB1430:
.LBI1430:
	.loc 1 90 6 view .LVU2392
.LBB1431:
	.loc 1 96 3 view .LVU2393
	l32r	a4, .LC180	#, tmp1882
	extui	a4, a4, 0, 16	# tmp1883, tmp1882
	bltu	a4, a2, .L389	# tmp1883, ea$53_1078,
	.loc 1 97 5 view .LVU2394
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2395
	addmi	a2, a2, -0x200	# tmp1884, ea$53_1078,
.LVL375:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2396
	extui	a2, a2, 0, 16	#, tmp1884
	call0	_Z14drawPixelToRamth		#
.LVL376:
	.loc 1 98 5 is_stmt 1 view .LVU2397
	j	.L170		#
.LVL377:
.L389:
	.loc 1 100 3 view .LVU2398
	l32r	a4, .LC182	#, tmp1886
	extui	a4, a4, 0, 16	# tmp1887, tmp1886
	bltu	a4, a2, .L170	# tmp1887, ea$53_1078,
	.loc 1 101 5 view .LVU2399
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2400
	l32r	a4, .LC184	#, tmp1888
	add.n	a2, a4, a2	# tmp1889, tmp1888, ea$53_1078
.LVL378:
	.loc 1 101 27 view .LVU2401
	addmi	a2, a2, -0x1200	# tmp1890, tmp1889,
	s8i	a3, a2, 0	# RAM[_1093], a$220_289
	.loc 1 102 5 is_stmt 1 view .LVU2402
	j	.L170		#
.LVL379:
.L241:
	.loc 1 102 5 is_stmt 0 view .LVU2403
.LBE1431:
.LBE1430:
.LBE1433:
.LBE1435:
.LBE1436:
.LBE1437:
.LBE1438:
.LBE1439:
.LBE1423:
.LBE1422:
	.loc 1 1133 5 is_stmt 1 view .LVU2404
	.loc 1 1134 7 view .LVU2405
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1134:       abso();
	.loc 1 1134 11 is_stmt 0 view .LVU2406
	call0	_Z4absov		#
.LVL380:
	.loc 1 1135 7 is_stmt 1 view .LVU2407
.LBB1440:
.LBI1440:
	.loc 1 597 13 view .LVU2408
.LBB1441:
	.loc 1 598 5 view .LVU2409
.LBB1442:
.LBB1443:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2410
	l32r	a6, .LC172	#,
.LBE1443:
.LBE1442:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:598:     putvalue(x);
	.loc 1 598 13 view .LVU2411
	l32r	a3, .LC189	#, tmp1891
.LBB1454:
.LBB1452:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2412
	l8ui	a2, a6, 0	# useaccum, useaccum
.LBE1452:
.LBE1454:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:598:     putvalue(x);
	.loc 1 598 13 view .LVU2413
	l8ui	a3, a3, 0	# x$210_291, x
.LVL381:
.LBB1455:
.LBI1442:
	.loc 1 225 13 is_stmt 1 view .LVU2414
.LBB1453:
	.loc 1 226 5 view .LVU2415
	beqz.n	a2, .L390	# useaccum,
	.loc 1 226 19 view .LVU2416
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2417
	l32r	a2, .LC190	#, tmp1894
	s8i	a3, a2, 0	# a, x$210_291
	j	.L170		#
.L390:
.LVL382:
.LBB1444:
.LBI1444:
	.loc 1 225 13 is_stmt 1 view .LVU2418
.LBB1445:
	.loc 1 227 14 view .LVU2419
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2420
	l32r	a2, .LC179	#, tmp1895
.LBB1446:
.LBB1447:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2421
	l32r	a5, .LC176	#, tmp1896
.LBE1447:
.LBE1446:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2422
	l16ui	a2, a2, 0	# ea, ea$53_1099
.LVL383:
.LBB1451:
.LBI1446:
	.loc 1 90 6 is_stmt 1 view .LVU2423
.LBB1450:
	.loc 1 91 3 view .LVU2424
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU2425
	movi	a4, 0x1ff	# tmp1898,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2426
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1099
	.loc 1 92 3 is_stmt 1 view .LVU2427
	bltu	a4, a2, .L391	# tmp1898, ea$53_1099,
	.loc 1 93 5 view .LVU2428
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2429
	l32r	a4, .LC175	#, tmp1899
	add.n	a2, a4, a2	# tmp1900, tmp1899, ea$53_1099
	s8i	a3, a2, 0	# zero_ram[_1100], x$210_291
	.loc 1 94 5 is_stmt 1 view .LVU2430
	j	.L170		#
.L391:
.LVL384:
.LBB1448:
.LBI1448:
	.loc 1 90 6 view .LVU2431
.LBB1449:
	.loc 1 96 3 view .LVU2432
	l32r	a4, .LC180	#, tmp1901
	extui	a4, a4, 0, 16	# tmp1902, tmp1901
	bltu	a4, a2, .L392	# tmp1902, ea$53_1099,
	.loc 1 97 5 view .LVU2433
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2434
	addmi	a2, a2, -0x200	# tmp1903, ea$53_1099,
.LVL385:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2435
	extui	a2, a2, 0, 16	#, tmp1903
	call0	_Z14drawPixelToRamth		#
.LVL386:
	.loc 1 98 5 is_stmt 1 view .LVU2436
	j	.L170		#
.LVL387:
.L392:
	.loc 1 100 3 view .LVU2437
	l32r	a4, .LC182	#, tmp1905
	extui	a4, a4, 0, 16	# tmp1906, tmp1905
	bltu	a4, a2, .L170	# tmp1906, ea$53_1099,
	.loc 1 101 5 view .LVU2438
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2439
	l32r	a4, .LC184	#, tmp1907
	add.n	a2, a4, a2	# tmp1908, tmp1907, ea$53_1099
.LVL388:
	.loc 1 101 27 view .LVU2440
	addmi	a2, a2, -0x1200	# tmp1909, tmp1908,
	s8i	a3, a2, 0	# RAM[_1114], x$210_291
	.loc 1 102 5 is_stmt 1 view .LVU2441
	j	.L170		#
.LVL389:
.L240:
	.loc 1 102 5 is_stmt 0 view .LVU2442
.LBE1449:
.LBE1448:
.LBE1450:
.LBE1451:
.LBE1445:
.LBE1444:
.LBE1453:
.LBE1455:
.LBE1441:
.LBE1440:
	.loc 1 1139 5 is_stmt 1 view .LVU2443
	.loc 1 1140 7 view .LVU2444
.LBB1456:
.LBI1456:
	.loc 1 164 13 view .LVU2445
.LBB1457:
	.loc 1 165 5 view .LVU2446
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU2447
	l16ui	a2, a13, 0	# pc, pc$374_1117
.LBB1458:
.LBB1459:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU2448
	movi	a4, 0x1ff	# tmp1914,
.LBE1459:
.LBE1458:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU2449
	addi.n	a5, a2, 1	# tmp1912, pc$374_1117,
	s16i	a5, a13, 0	# pc, tmp1912
.LVL390:
.LBB1464:
.LBI1458:
	.loc 1 69 9 is_stmt 1 view .LVU2450
.LBB1462:
	.loc 1 70 3 view .LVU2451
	bltu	a4, a2, .L393	# tmp1914, pc$374_1117,
	.loc 1 71 5 view .LVU2452
	.loc 1 72 7 view .LVU2453
	.loc 1 75 12 view .LVU2454
	movi	a4, 0xfe	# tmp1916,
	bne	a2, a4, .L394	# pc$374_1117, tmp1916,
	.loc 1 76 9 view .LVU2455
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU2456
	call0	rand		#
.LVL391:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU2457
	extui	a2, a2, 0, 8	# _1128,
	j	.L630		#
.LVL392:
.L394:
	.loc 1 79 5 is_stmt 1 view .LVU2458
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU2459
	l32r	a4, .LC175	#, tmp1918
	add.n	a2, a4, a2	# tmp1919, tmp1918, pc$374_1117
.LVL393:
	.loc 1 79 28 view .LVU2460
	j	.L631		#
.LVL394:
.L393:
	.loc 1 81 3 is_stmt 1 view .LVU2461
	l32r	a4, .LC180	#, tmp1920
	extui	a4, a4, 0, 16	# tmp1921, tmp1920
	bltu	a4, a2, .L396	# tmp1921, pc$374_1117,
.LVL395:
.LBB1460:
.LBI1460:
	.loc 1 69 9 view .LVU2462
.LBB1461:
	.loc 1 82 5 view .LVU2463
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU2464
	addmi	a2, a2, -0x200	# tmp1922, pc$374_1117,
.LVL396:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU2465
	extui	a2, a2, 0, 16	#, tmp1922
.LVL397:
	.loc 1 82 28 view .LVU2466
	call0	_Z16loadPixelFromRamt		#
.LVL398:
.L630:
	.loc 1 82 28 view .LVU2467
.LBE1461:
.LBE1460:
.LBE1462:
.LBE1464:
.LBE1457:
.LBE1456:
.LBB1469:
.LBB1470:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:264:     if ((cpustatus & FLAG_CARRY) == 0) {
	.loc 1 264 20 view .LVU2468
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L395		#
.LVL399:
.L396:
	.loc 1 264 20 view .LVU2469
.LBE1470:
.LBE1469:
.LBB1475:
.LBB1466:
.LBB1465:
.LBB1463:
	.loc 1 84 3 is_stmt 1 view .LVU2470
	l32r	a4, .LC182	#, tmp1926
	extui	a4, a4, 0, 16	# tmp1927, tmp1926
	bltu	a4, a2, .L397	# tmp1927, pc$374_1117,
	.loc 1 85 5 view .LVU2471
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU2472
	l32r	a4, .LC184	#, tmp1928
	add.n	a2, a4, a2	# tmp1929, tmp1928, pc$374_1117
.LVL400:
	.loc 1 85 32 view .LVU2473
	addmi	a2, a2, -0x1200	# tmp1930, tmp1929,
.L631:
	.loc 1 85 32 view .LVU2474
	l8ui	a2, a2, 0	# _1128,
.LVL401:
.L395:
	.loc 1 85 32 view .LVU2475
.LBE1463:
.LBE1465:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU2476
	extui	a4, a2, 0, 16	# _1121, _1128
	.loc 1 166 5 is_stmt 1 view .LVU2477
	bbsi	a2, 7, .L398	# _1128,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU2478
	l32r	a2, .LC185	#, tmp3112
	j	.L632		#
.L398:
	.loc 1 166 25 is_stmt 1 view .LVU2479
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU2480
	movi	a5, -0x100	# tmp1935,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp1936, _1121, tmp1935
.L632:
.LBE1466:
.LBE1475:
	.loc 1 1141 7 is_stmt 1 view .LVU2481
.LBB1476:
.LBI1469:
	.loc 1 263 13 view .LVU2482
.LBB1473:
	.loc 1 264 5 view .LVU2483
.LBE1473:
.LBE1476:
.LBB1477:
.LBB1467:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU2484
	s16i	a4, a2, 0	# reladdr, tmp1936
.LBE1467:
.LBE1477:
.LBB1478:
.LBB1474:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:264:     if ((cpustatus & FLAG_CARRY) == 0) {
	.loc 1 264 5 view .LVU2485
	bbsi	a3, 0, .L170	# prephitmp_1199,,
.LBB1471:
.LBI1471:
	.loc 1 263 13 is_stmt 1 view .LVU2486
.LBB1472:
	.loc 1 265 9 view .LVU2487
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU2488
	l16ui	a5, a13, 0	# pc, pc$202_1140
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2489
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2490
	l32r	a6, .LC187	#, tmp1946
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2491
	add.n	a3, a5, a3	# tmp1944, pc$202_1140, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2492
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1307
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2493
	extui	a3, a3, 0, 16	# _1142, tmp1944
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU2494
	movi	a7, -0x100	# tmp1948,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU2495
	xor	a4, a5, a3	# tmp1947, pc$202_1140, _1142
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU2496
	and	a4, a4, a7	# tmp1952, tmp1947, tmp1948
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU2497
	addi.n	a7, a2, 1	# tmp1956, pretmp_1307,
	addi.n	a2, a2, 2	# tmp1954, pretmp_1307,
	moveqz	a2, a7, a4	# tmp3123, tmp1956, tmp1952
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU2498
	l32r	a4, .LC186	#, tmp1941
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU2499
	s16i	a3, a13, 0	# pc, _1142
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU2500
	s16i	a5, a4, 0	# oldpc, pc$202_1140
	.loc 1 266 9 is_stmt 1 view .LVU2501
	.loc 1 267 9 view .LVU2502
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU2503
	s32i.n	a2, a6, 0	# clockticks6502, tmp3123
	j	.L170		#
.L239:
.LBE1472:
.LBE1471:
.LBE1474:
.LBE1478:
	.loc 1 1143 5 is_stmt 1 view .LVU2504
	.loc 1 1144 7 view .LVU2505
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1144:       indy();
	.loc 1 1144 11 is_stmt 0 view .LVU2506
	call0	_Z4indyv		#
.LVL402:
	.loc 1 1145 7 is_stmt 1 view .LVU2507
.LBB1479:
.LBI1479:
	.loc 1 593 13 view .LVU2508
.LBB1480:
	.loc 1 594 5 view .LVU2509
.LBB1481:
.LBI1481:
	.loc 1 225 13 view .LVU2510
.LBB1482:
	.loc 1 226 5 view .LVU2511
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1483:
.LBB1484:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2512
	l32r	a2, .LC179	#, tmp1960
.LBB1485:
.LBB1486:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2513
	l32r	a3, .LC176	#, tmp1961
.LBE1486:
.LBE1485:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2514
	l16ui	a2, a2, 0	# ea, ea$53_1154
.LBB1491:
.LBB1489:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2515
	movi	a4, 0x1ff	# tmp1963,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2516
	s16i	a2, a3, 0	# last_modified_ram, ea$53_1154
.LBE1489:
.LBE1491:
.LBE1484:
.LBE1483:
.LBE1482:
.LBE1481:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2517
	l32r	a3, .LC190	#, tmp1959
.LVL403:
	.loc 1 594 13 view .LVU2518
	l8ui	a3, a3, 0	# a$220_293, a
.LVL404:
.LBB1496:
.LBB1495:
.LBB1494:
.LBI1483:
	.loc 1 225 13 is_stmt 1 view .LVU2519
.LBB1493:
	.loc 1 227 14 view .LVU2520
.LBB1492:
.LBI1485:
	.loc 1 90 6 view .LVU2521
.LBB1490:
	.loc 1 91 3 view .LVU2522
	.loc 1 92 3 view .LVU2523
	bltu	a4, a2, .L401	# tmp1963, ea$53_1154,
	.loc 1 93 5 view .LVU2524
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2525
	l32r	a4, .LC175	#, tmp1964
	add.n	a2, a4, a2	# tmp1965, tmp1964, ea$53_1154
	s8i	a3, a2, 0	# zero_ram[_1155], a$220_293
	.loc 1 94 5 is_stmt 1 view .LVU2526
	j	.L170		#
.L401:
.LVL405:
.LBB1487:
.LBI1487:
	.loc 1 90 6 view .LVU2527
.LBB1488:
	.loc 1 96 3 view .LVU2528
	l32r	a4, .LC180	#, tmp1966
	extui	a4, a4, 0, 16	# tmp1967, tmp1966
	bltu	a4, a2, .L402	# tmp1967, ea$53_1154,
	.loc 1 97 5 view .LVU2529
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2530
	addmi	a2, a2, -0x200	# tmp1968, ea$53_1154,
.LVL406:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2531
	extui	a2, a2, 0, 16	#, tmp1968
	call0	_Z14drawPixelToRamth		#
.LVL407:
	.loc 1 98 5 is_stmt 1 view .LVU2532
	j	.L170		#
.LVL408:
.L402:
	.loc 1 100 3 view .LVU2533
	l32r	a4, .LC182	#, tmp1970
	extui	a4, a4, 0, 16	# tmp1971, tmp1970
	bltu	a4, a2, .L170	# tmp1971, ea$53_1154,
	.loc 1 101 5 view .LVU2534
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2535
	l32r	a4, .LC184	#, tmp1972
	add.n	a2, a4, a2	# tmp1973, tmp1972, ea$53_1154
.LVL409:
	.loc 1 101 27 view .LVU2536
	addmi	a2, a2, -0x1200	# tmp1974, tmp1973,
	s8i	a3, a2, 0	# RAM[_1169], a$220_293
	.loc 1 102 5 is_stmt 1 view .LVU2537
	j	.L170		#
.LVL410:
.L238:
	.loc 1 102 5 is_stmt 0 view .LVU2538
.LBE1488:
.LBE1487:
.LBE1490:
.LBE1492:
.LBE1493:
.LBE1494:
.LBE1495:
.LBE1496:
.LBE1480:
.LBE1479:
	.loc 1 1150 5 is_stmt 1 view .LVU2539
	.loc 1 1151 7 view .LVU2540
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1151:       zpx();
	.loc 1 1151 10 is_stmt 0 view .LVU2541
	call0	_Z3zpxv		#
.LVL411:
	.loc 1 1152 7 is_stmt 1 view .LVU2542
.LBB1497:
.LBI1497:
	.loc 1 601 13 view .LVU2543
.LBB1498:
	.loc 1 602 5 view .LVU2544
.LBB1499:
.LBB1500:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2545
	l32r	a4, .LC172	#,
.LBE1500:
.LBE1499:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2546
	l32r	a3, .LC188	#, tmp1975
.LBB1511:
.LBB1509:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2547
	l8ui	a2, a4, 0	# useaccum, useaccum
.LBE1509:
.LBE1511:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:602:     putvalue(y);
	.loc 1 602 13 view .LVU2548
	l8ui	a3, a3, 0	# y$209_295, y
.LVL412:
.LBB1512:
.LBI1499:
	.loc 1 225 13 is_stmt 1 view .LVU2549
.LBB1510:
	.loc 1 226 5 view .LVU2550
	beqz.n	a2, .L403	# useaccum,
	.loc 1 226 19 view .LVU2551
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2552
	l32r	a2, .LC190	#, tmp1978
	s8i	a3, a2, 0	# a, y$209_295
	j	.L170		#
.L403:
.LVL413:
.LBB1501:
.LBI1501:
	.loc 1 225 13 is_stmt 1 view .LVU2553
.LBB1502:
	.loc 1 227 14 view .LVU2554
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2555
	l32r	a2, .LC179	#, tmp1979
.LBB1503:
.LBB1504:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2556
	l32r	a5, .LC176	#, tmp1980
.LBE1504:
.LBE1503:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2557
	l16ui	a2, a2, 0	# ea, ea$53_1175
.LVL414:
.LBB1508:
.LBI1503:
	.loc 1 90 6 is_stmt 1 view .LVU2558
.LBB1507:
	.loc 1 91 3 view .LVU2559
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU2560
	movi	a4, 0x1ff	# tmp1982,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2561
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1175
	.loc 1 92 3 is_stmt 1 view .LVU2562
	bltu	a4, a2, .L404	# tmp1982, ea$53_1175,
	.loc 1 93 5 view .LVU2563
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2564
	l32r	a4, .LC175	#, tmp1983
	add.n	a2, a4, a2	# tmp1984, tmp1983, ea$53_1175
	s8i	a3, a2, 0	# zero_ram[_1176], y$209_295
	.loc 1 94 5 is_stmt 1 view .LVU2565
	j	.L170		#
.L404:
.LVL415:
.LBB1505:
.LBI1505:
	.loc 1 90 6 view .LVU2566
.LBB1506:
	.loc 1 96 3 view .LVU2567
	l32r	a4, .LC180	#, tmp1985
	extui	a4, a4, 0, 16	# tmp1986, tmp1985
	bltu	a4, a2, .L405	# tmp1986, ea$53_1175,
	.loc 1 97 5 view .LVU2568
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2569
	addmi	a2, a2, -0x200	# tmp1987, ea$53_1175,
.LVL416:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2570
	extui	a2, a2, 0, 16	#, tmp1987
	call0	_Z14drawPixelToRamth		#
.LVL417:
	.loc 1 98 5 is_stmt 1 view .LVU2571
	j	.L170		#
.LVL418:
.L405:
	.loc 1 100 3 view .LVU2572
	l32r	a4, .LC182	#, tmp1989
	extui	a4, a4, 0, 16	# tmp1990, tmp1989
	bltu	a4, a2, .L170	# tmp1990, ea$53_1175,
	.loc 1 101 5 view .LVU2573
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2574
	l32r	a4, .LC184	#, tmp1991
	add.n	a2, a4, a2	# tmp1992, tmp1991, ea$53_1175
.LVL419:
	.loc 1 101 27 view .LVU2575
	addmi	a2, a2, -0x1200	# tmp1993, tmp1992,
	s8i	a3, a2, 0	# RAM[_1190], y$209_295
	.loc 1 102 5 is_stmt 1 view .LVU2576
	j	.L170		#
.LVL420:
.L237:
	.loc 1 102 5 is_stmt 0 view .LVU2577
.LBE1506:
.LBE1505:
.LBE1507:
.LBE1508:
.LBE1502:
.LBE1501:
.LBE1510:
.LBE1512:
.LBE1498:
.LBE1497:
	.loc 1 1154 5 is_stmt 1 view .LVU2578
	.loc 1 1155 7 view .LVU2579
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1155:       zpx();
	.loc 1 1155 10 is_stmt 0 view .LVU2580
	call0	_Z3zpxv		#
.LVL421:
	.loc 1 1156 7 is_stmt 1 view .LVU2581
.LBB1513:
.LBI1513:
	.loc 1 593 13 view .LVU2582
.LBB1514:
	.loc 1 594 5 view .LVU2583
.LBB1515:
.LBI1515:
	.loc 1 225 13 view .LVU2584
.LBB1516:
	.loc 1 226 5 view .LVU2585
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1517:
.LBB1518:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2586
	l32r	a2, .LC179	#, tmp1997
.LBB1519:
.LBB1520:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2587
	l32r	a3, .LC176	#, tmp1998
.LBE1520:
.LBE1519:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2588
	l16ui	a2, a2, 0	# ea, ea$53_1196
.LBB1525:
.LBB1523:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2589
	movi	a4, 0x1ff	# tmp2000,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2590
	s16i	a2, a3, 0	# last_modified_ram, ea$53_1196
.LBE1523:
.LBE1525:
.LBE1518:
.LBE1517:
.LBE1516:
.LBE1515:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2591
	l32r	a3, .LC190	#, tmp1996
.LVL422:
	.loc 1 594 13 view .LVU2592
	l8ui	a3, a3, 0	# a$220_297, a
.LVL423:
.LBB1530:
.LBB1529:
.LBB1528:
.LBI1517:
	.loc 1 225 13 is_stmt 1 view .LVU2593
.LBB1527:
	.loc 1 227 14 view .LVU2594
.LBB1526:
.LBI1519:
	.loc 1 90 6 view .LVU2595
.LBB1524:
	.loc 1 91 3 view .LVU2596
	.loc 1 92 3 view .LVU2597
	bltu	a4, a2, .L406	# tmp2000, ea$53_1196,
	.loc 1 93 5 view .LVU2598
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2599
	l32r	a4, .LC175	#, tmp2001
	add.n	a2, a4, a2	# tmp2002, tmp2001, ea$53_1196
	s8i	a3, a2, 0	# zero_ram[_1197], a$220_297
	.loc 1 94 5 is_stmt 1 view .LVU2600
	j	.L170		#
.L406:
.LVL424:
.LBB1521:
.LBI1521:
	.loc 1 90 6 view .LVU2601
.LBB1522:
	.loc 1 96 3 view .LVU2602
	l32r	a4, .LC180	#, tmp2003
	extui	a4, a4, 0, 16	# tmp2004, tmp2003
	bltu	a4, a2, .L407	# tmp2004, ea$53_1196,
	.loc 1 97 5 view .LVU2603
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2604
	addmi	a2, a2, -0x200	# tmp2005, ea$53_1196,
.LVL425:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2605
	extui	a2, a2, 0, 16	#, tmp2005
	call0	_Z14drawPixelToRamth		#
.LVL426:
	.loc 1 98 5 is_stmt 1 view .LVU2606
	j	.L170		#
.LVL427:
.L407:
	.loc 1 100 3 view .LVU2607
	l32r	a4, .LC182	#, tmp2007
	extui	a4, a4, 0, 16	# tmp2008, tmp2007
	bltu	a4, a2, .L170	# tmp2008, ea$53_1196,
	.loc 1 101 5 view .LVU2608
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2609
	l32r	a4, .LC184	#, tmp2009
	add.n	a2, a4, a2	# tmp2010, tmp2009, ea$53_1196
.LVL428:
	.loc 1 101 27 view .LVU2610
	addmi	a2, a2, -0x1200	# tmp2011, tmp2010,
	s8i	a3, a2, 0	# RAM[_1211], a$220_297
	.loc 1 102 5 is_stmt 1 view .LVU2611
	j	.L170		#
.LVL429:
.L236:
	.loc 1 102 5 is_stmt 0 view .LVU2612
.LBE1522:
.LBE1521:
.LBE1524:
.LBE1526:
.LBE1527:
.LBE1528:
.LBE1529:
.LBE1530:
.LBE1514:
.LBE1513:
	.loc 1 1158 5 is_stmt 1 view .LVU2613
	.loc 1 1159 7 view .LVU2614
.LBB1531:
.LBI1531:
	.loc 1 160 13 view .LVU2615
.LBB1532:
	.loc 1 161 5 view .LVU2616
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 42 is_stmt 0 view .LVU2617
	l16ui	a2, a13, 0	# pc, pc$245_1216
	addi.n	a3, a2, 1	# tmp2014, pc$245_1216,
	s16i	a3, a13, 0	# pc, tmp2014
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 29 view .LVU2618
	call0	_Z8read6502t		#
.LVL430:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU2619
	l32r	a3, .LC188	#, tmp2016
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 8 view .LVU2620
	l32r	a5, .LC179	#, tmp2019
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU2621
	l8ui	a3, a3, 0	#, y
.LBE1532:
.LBE1531:
.LBB1534:
.LBB1535:
.LBB1536:
.LBB1537:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2622
	l32r	a6, .LC172	#,
.LBE1537:
.LBE1536:
.LBE1535:
.LBE1534:
.LBB1547:
.LBB1533:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU2623
	add.n	a2, a2, a3	# tmp2018,, y
	extui	a3, a2, 0, 8	# _1222, tmp2018
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 8 view .LVU2624
	s16i	a3, a5, 0	# ea, _1222
.LBE1533:
.LBE1547:
	.loc 1 1160 7 is_stmt 1 view .LVU2625
.LBB1548:
.LBI1534:
	.loc 1 597 13 view .LVU2626
.LBB1546:
	.loc 1 598 5 view .LVU2627
.LBB1544:
.LBB1542:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 is_stmt 0 view .LVU2628
	l8ui	a4, a6, 0	# useaccum, useaccum
.LBE1542:
.LBE1544:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:598:     putvalue(x);
	.loc 1 598 13 view .LVU2629
	l32r	a5, .LC189	#, tmp2020
	l8ui	a5, a5, 0	# x$210_299, x
.LVL431:
.LBB1545:
.LBI1536:
	.loc 1 225 13 is_stmt 1 view .LVU2630
.LBB1543:
	.loc 1 226 5 view .LVU2631
	beqz.n	a4, .L408	# useaccum,
	.loc 1 226 19 view .LVU2632
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU2633
	l32r	a2, .LC190	#, tmp2023
	s8i	a5, a2, 0	# a, x$210_299
	j	.L170		#
.L408:
.LVL432:
.LBB1538:
.LBI1538:
	.loc 1 225 13 is_stmt 1 view .LVU2634
.LBB1539:
	.loc 1 227 14 view .LVU2635
.LBB1540:
.LBI1540:
	.loc 1 90 6 view .LVU2636
.LBB1541:
	.loc 1 91 3 view .LVU2637
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2638
	l32r	a4, .LC175	#, tmp2025
	add.n	a2, a4, a3	# tmp2026, tmp2025, _1221
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2639
	l32r	a4, .LC176	#, tmp2024
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 view .LVU2640
	s8i	a5, a2, 0	# zero_ram[_1225], x$210_299
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2641
	s16i	a3, a4, 0	# last_modified_ram, _1222
	.loc 1 92 3 is_stmt 1 view .LVU2642
	.loc 1 93 5 view .LVU2643
	.loc 1 94 5 view .LVU2644
	j	.L170		#
.LVL433:
.L235:
	.loc 1 94 5 is_stmt 0 view .LVU2645
.LBE1541:
.LBE1540:
.LBE1539:
.LBE1538:
.LBE1543:
.LBE1545:
.LBE1546:
.LBE1548:
	.loc 1 1164 5 is_stmt 1 view .LVU2646
	.loc 1 1165 7 view .LVU2647
	.loc 1 1166 7 view .LVU2648
.LBB1549:
.LBI1549:
	.loc 1 637 13 view .LVU2649
.LBB1550:
	.loc 1 638 5 view .LVU2650
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:638:     a = y;
	.loc 1 638 7 is_stmt 0 view .LVU2651
	l32r	a2, .LC188	#, tmp2027
	l32r	a3, .LC190	#, tmp2028
	l8ui	a2, a2, 0	# y$211_1240, y
	s8i	a2, a3, 0	# a, y$211_1240
	.loc 1 640 5 is_stmt 1 view .LVU2652
	.loc 1 640 5 view .LVU2653
	beqz.n	a2, .L409	# y$211_1240,
	.loc 1 640 5 view .LVU2654
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:641:     signcalc(a);
	.loc 1 641 5 is_stmt 0 view .LVU2655
	slli	a3, a2, 24	# tmp2032, y$211_1240,
	movi.n	a2, -3	# tmp2029,
	and	a2, a5, a2	# _2463, cpustatus$6_5, tmp2029
	.loc 1 640 16 is_stmt 1 view .LVU2656
	.loc 1 641 5 view .LVU2657
	.loc 1 641 5 view .LVU2658
	bltz	a3, .L410	# tmp2032,
	j	.L611		#
.L409:
	.loc 1 640 5 view .LVU2659
	movi.n	a2, 0x22	# tmp2034,
	or	a2, a5, a2	# cstore_414, cpustatus$6_5, tmp2034
	.loc 1 640 16 view .LVU2660
	.loc 1 641 5 view .LVU2661
	.loc 1 641 5 view .LVU2662
	j	.L412		#
.L410:
	.loc 1 641 5 view .LVU2663
	movi	a3, 0xa0	# tmp2036,
	or	a2, a2, a3	# tmp2037, _2463, tmp2036
	s16i	a2, a14, 0	# cpustatus, tmp2037
	j	.L170		#
.L611:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:640:     zerocalc(a);
	.loc 1 640 5 is_stmt 0 view .LVU2664
	movi.n	a3, 0x20	#,
	or	a2, a2, a3	# tmp2039, _2463,
	extui	a2, a2, 0, 16	# cstore_414, tmp2039
.L412:
	.loc 1 641 5 is_stmt 1 view .LVU2665
	movi	a3, -0x81	# tmp2041,
	and	a2, a2, a3	# tmp2042, cstore_414, tmp2041
	s16i	a2, a14, 0	# cpustatus, tmp2042
	j	.L170		#
.L234:
.LBE1550:
.LBE1549:
	.loc 1 1168 5 view .LVU2666
	.loc 1 1169 7 view .LVU2667
.LBB1551:
.LBI1551:
	.loc 1 183 13 view .LVU2668
.LBB1552:
	.loc 1 184 5 view .LVU2669
	.loc 1 185 5 view .LVU2670
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU2671
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL434:
	mov.n	a5, a2	# tmp2045,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU2672
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU2673
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU2674
	addi.n	a2, a2, 1	# tmp2048, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU2675
	extui	a2, a2, 0, 16	#, tmp2048
	call0	_Z8read6502t		#
.LVL435:
	.loc 1 186 5 is_stmt 1 view .LVU2676
	.loc 1 187 5 view .LVU2677
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 is_stmt 0 view .LVU2678
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2679
	l32r	a3, .LC188	#, tmp2055
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU2680
	slli	a2, a2, 8	# tmp2051,,
.LVL436:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2681
	l8ui	a4, a3, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU2682
	or	a2, a2, a5	# tmp2054, tmp2051, tmp2045
.LBE1552:
.LBE1551:
.LBB1555:
.LBB1556:
.LBB1557:
.LBB1558:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2683
	l32r	a5, .LC172	#,
.LBE1558:
.LBE1557:
.LBE1556:
.LBE1555:
.LBB1577:
.LBB1553:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU2684
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2685
	add.n	a2, a4, a2	# tmp2059, y, tmp2054
.LBE1553:
.LBE1577:
.LBB1578:
.LBB1575:
.LBB1572:
.LBB1569:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU2686
	l8ui	a4, a5, 0	# useaccum, useaccum
.LBE1569:
.LBE1572:
.LBE1575:
.LBE1578:
.LBB1579:
.LBB1554:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2687
	l32r	a5, .LC179	#, tmp2060
	extui	a2, a2, 0, 16	# _1269, tmp2059
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU2688
	addi.n	a3, a3, 2	# tmp2064, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU2689
	s16i	a2, a5, 0	# ea, _1269
	.loc 1 189 5 is_stmt 1 view .LVU2690
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU2691
	s16i	a3, a13, 0	# pc, tmp2064
.LBE1554:
.LBE1579:
	.loc 1 1170 7 is_stmt 1 view .LVU2692
.LBB1580:
.LBI1555:
	.loc 1 593 13 view .LVU2693
.LBB1576:
	.loc 1 594 5 view .LVU2694
.LVL437:
.LBB1573:
.LBI1557:
	.loc 1 225 13 view .LVU2695
.LBB1570:
	.loc 1 226 5 view .LVU2696
	bnez.n	a4, .L170	# useaccum,
.LBB1559:
.LBB1560:
.LBB1561:
.LBB1562:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 is_stmt 0 view .LVU2697
	l32r	a3, .LC176	#, tmp2068
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2698
	movi	a4, 0x1ff	# tmp2070,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2699
	s16i	a2, a3, 0	# last_modified_ram, _1269
.LBE1562:
.LBE1561:
.LBE1560:
.LBE1559:
.LBE1570:
.LBE1573:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2700
	l32r	a3, .LC190	#, tmp2067
.LVL438:
	.loc 1 594 13 view .LVU2701
	l8ui	a3, a3, 0	# a$220_301, a
.LVL439:
.LBB1574:
.LBB1571:
.LBB1568:
.LBI1559:
	.loc 1 225 13 is_stmt 1 view .LVU2702
.LBB1567:
	.loc 1 227 14 view .LVU2703
.LBB1566:
.LBI1561:
	.loc 1 90 6 view .LVU2704
.LBB1565:
	.loc 1 91 3 view .LVU2705
	.loc 1 92 3 view .LVU2706
	bltu	a4, a2, .L413	# tmp2070, _1269,
	.loc 1 93 5 view .LVU2707
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2708
	l32r	a4, .LC175	#, tmp2071
	add.n	a2, a4, a2	# tmp2072, tmp2071, _1269
.LVL440:
	.loc 1 93 23 view .LVU2709
	s8i	a3, a2, 0	# zero_ram[_1274], a$220_301
	.loc 1 94 5 is_stmt 1 view .LVU2710
	j	.L170		#
.LVL441:
.L413:
.LBB1563:
.LBI1563:
	.loc 1 90 6 view .LVU2711
.LBB1564:
	.loc 1 96 3 view .LVU2712
	l32r	a4, .LC180	#, tmp2073
	extui	a4, a4, 0, 16	# tmp2074, tmp2073
	bltu	a4, a2, .L414	# tmp2074, _1269,
	.loc 1 97 5 view .LVU2713
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2714
	addmi	a2, a2, -0x200	# tmp2075, _1269,
.LVL442:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2715
	extui	a2, a2, 0, 16	#, tmp2075
.LVL443:
	.loc 1 97 19 view .LVU2716
	call0	_Z14drawPixelToRamth		#
.LVL444:
	.loc 1 98 5 is_stmt 1 view .LVU2717
	j	.L170		#
.LVL445:
.L414:
	.loc 1 100 3 view .LVU2718
	l32r	a4, .LC182	#, tmp2077
	extui	a4, a4, 0, 16	# tmp2078, tmp2077
	bltu	a4, a2, .L170	# tmp2078, _1269,
	.loc 1 101 5 view .LVU2719
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2720
	l32r	a4, .LC184	#, tmp2079
	add.n	a2, a4, a2	# tmp2080, tmp2079, _1269
.LVL446:
	.loc 1 101 27 view .LVU2721
	addmi	a2, a2, -0x1200	# tmp2081, tmp2080,
	s8i	a3, a2, 0	# RAM[_1288], a$220_301
	.loc 1 102 5 is_stmt 1 view .LVU2722
	j	.L170		#
.LVL447:
.L233:
	.loc 1 102 5 is_stmt 0 view .LVU2723
.LBE1564:
.LBE1563:
.LBE1565:
.LBE1566:
.LBE1567:
.LBE1568:
.LBE1571:
.LBE1574:
.LBE1576:
.LBE1580:
	.loc 1 1172 5 is_stmt 1 view .LVU2724
	.loc 1 1173 7 view .LVU2725
	.loc 1 1174 7 view .LVU2726
.LBB1581:
.LBI1581:
	.loc 1 633 13 view .LVU2727
.LBB1582:
	.loc 1 634 5 view .LVU2728
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:634:     sp = x;
	.loc 1 634 8 is_stmt 0 view .LVU2729
	l32r	a2, .LC189	#, tmp2083
	l8ui	a3, a2, 0	#, x
	l32r	a2, .LC174	#, tmp2082
	s8i	a3, a2, 0	# sp, x
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:635: }
	.loc 1 635 1 view .LVU2730
	j	.L170		#
.L232:
.LBE1582:
.LBE1581:
	.loc 1 1179 5 is_stmt 1 view .LVU2731
	.loc 1 1180 7 view .LVU2732
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1180:       absx();
	.loc 1 1180 11 is_stmt 0 view .LVU2733
	call0	_Z4absxv		#
.LVL448:
	.loc 1 1181 7 is_stmt 1 view .LVU2734
.LBB1583:
.LBI1583:
	.loc 1 593 13 view .LVU2735
.LBB1584:
	.loc 1 594 5 view .LVU2736
.LBB1585:
.LBI1585:
	.loc 1 225 13 view .LVU2737
.LBB1586:
	.loc 1 226 5 view .LVU2738
	l32r	a6, .LC172	#,
	l8ui	a2, a6, 0	# useaccum, useaccum
	bnez.n	a2, .L170	# useaccum,
.LBB1587:
.LBB1588:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU2739
	l32r	a2, .LC179	#, tmp2088
.LBB1589:
.LBB1590:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2740
	l32r	a3, .LC176	#, tmp2089
.LBE1590:
.LBE1589:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU2741
	l16ui	a2, a2, 0	# ea, ea$53_1294
.LBB1595:
.LBB1593:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 view .LVU2742
	movi	a4, 0x1ff	# tmp2091,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU2743
	s16i	a2, a3, 0	# last_modified_ram, ea$53_1294
.LBE1593:
.LBE1595:
.LBE1588:
.LBE1587:
.LBE1586:
.LBE1585:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:594:     putvalue(a);
	.loc 1 594 13 view .LVU2744
	l32r	a3, .LC190	#, tmp2087
.LVL449:
	.loc 1 594 13 view .LVU2745
	l8ui	a3, a3, 0	# a$220_304, a
.LVL450:
.LBB1600:
.LBB1599:
.LBB1598:
.LBI1587:
	.loc 1 225 13 is_stmt 1 view .LVU2746
.LBB1597:
	.loc 1 227 14 view .LVU2747
.LBB1596:
.LBI1589:
	.loc 1 90 6 view .LVU2748
.LBB1594:
	.loc 1 91 3 view .LVU2749
	.loc 1 92 3 view .LVU2750
	bltu	a4, a2, .L415	# tmp2091, ea$53_1294,
	.loc 1 93 5 view .LVU2751
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU2752
	l32r	a4, .LC175	#, tmp2092
	add.n	a2, a4, a2	# tmp2093, tmp2092, ea$53_1294
	s8i	a3, a2, 0	# zero_ram[_1295], a$220_304
	.loc 1 94 5 is_stmt 1 view .LVU2753
	j	.L170		#
.L415:
.LVL451:
.LBB1591:
.LBI1591:
	.loc 1 90 6 view .LVU2754
.LBB1592:
	.loc 1 96 3 view .LVU2755
	l32r	a4, .LC180	#, tmp2094
	extui	a4, a4, 0, 16	# tmp2095, tmp2094
	bltu	a4, a2, .L416	# tmp2095, ea$53_1294,
	.loc 1 97 5 view .LVU2756
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU2757
	addmi	a2, a2, -0x200	# tmp2096, ea$53_1294,
.LVL452:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU2758
	extui	a2, a2, 0, 16	#, tmp2096
	call0	_Z14drawPixelToRamth		#
.LVL453:
	.loc 1 98 5 is_stmt 1 view .LVU2759
	j	.L170		#
.LVL454:
.L416:
	.loc 1 100 3 view .LVU2760
	l32r	a4, .LC182	#, tmp2098
	extui	a4, a4, 0, 16	# tmp2099, tmp2098
	bltu	a4, a2, .L170	# tmp2099, ea$53_1294,
	.loc 1 101 5 view .LVU2761
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU2762
	l32r	a4, .LC184	#, tmp2100
	add.n	a2, a4, a2	# tmp2101, tmp2100, ea$53_1294
.LVL455:
	.loc 1 101 27 view .LVU2763
	addmi	a2, a2, -0x1200	# tmp2102, tmp2101,
	s8i	a3, a2, 0	# RAM[_1309], a$220_304
	.loc 1 102 5 is_stmt 1 view .LVU2764
	j	.L170		#
.LVL456:
.L231:
	.loc 1 102 5 is_stmt 0 view .LVU2765
.LBE1592:
.LBE1591:
.LBE1594:
.LBE1596:
.LBE1597:
.LBE1598:
.LBE1599:
.LBE1600:
.LBE1584:
.LBE1583:
	.loc 1 1186 5 is_stmt 1 view .LVU2766
	.loc 1 1187 7 view .LVU2767
.LBB1601:
.LBI1601:
	.loc 1 148 13 view .LVU2768
.LBB1602:
	.loc 1 149 5 view .LVU2769
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU2770
	l16ui	a3, a13, 0	# pc, pc$356_306
	addi.n	a4, a3, 1	# tmp2105, pc$356_306,
	s16i	a4, a13, 0	# pc, tmp2105
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU2771
	l32r	a4, .LC179	#, tmp2106
.LBE1602:
.LBE1601:
.LBB1604:
.LBB1605:
.LBB1606:
.LBB1607:
.LBB1608:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 view .LVU2772
	mov.n	a2, a3	#, pc$356_306
.LBE1608:
.LBE1607:
.LBE1606:
.LBE1605:
.LBE1604:
.LBB1618:
.LBB1603:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU2773
	s16i	a3, a4, 0	# ea, pc$356_306
.LBE1603:
.LBE1618:
	.loc 1 1188 7 is_stmt 1 view .LVU2774
.LBB1619:
.LBI1604:
	.loc 1 483 13 view .LVU2775
.LBB1616:
	.loc 1 484 5 view .LVU2776
.LBB1613:
.LBI1606:
	.loc 1 216 17 view .LVU2777
.LBE1613:
.LBE1616:
.LBE1619:
	.loc 1 217 5 view .LVU2778
.LBB1620:
.LBB1617:
.LBB1614:
.LBB1611:
.LBI1607:
	.loc 1 216 17 view .LVU2779
.LBB1609:
	.loc 1 218 14 view .LVU2780
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU2781
	call0	_Z8read6502t		#
.LVL457:
.LBE1609:
.LBE1611:
.LBE1614:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU2782
	l32r	a4, .LC191	#, tmp2108
.LBB1615:
.LBB1612:
.LBB1610:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU2783
	extui	a3, a2, 0, 16	# _1329, tmp2107
.LBE1610:
.LBE1612:
.LBE1615:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU2784
	s16i	a3, a4, 0	# value, _1329
	.loc 1 485 5 is_stmt 1 view .LVU2785
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:485:     y = (uint8_t)(value & 0x00FF);
	.loc 1 485 7 is_stmt 0 view .LVU2786
	l32r	a4, .LC188	#, tmp2109
	s8i	a2, a4, 0	# y, tmp2107
	.loc 1 487 5 is_stmt 1 view .LVU2787
	.loc 1 487 5 view .LVU2788
	beqz.n	a3, .L417	# _1329,
	.loc 1 487 5 view .LVU2789
	l16ui	a3, a14, 0	# cpustatus, tmp2113
	movi.n	a4, -3	# tmp2111,
	and	a3, a3, a4	# _1315, tmp2113, tmp2111
	.loc 1 487 16 view .LVU2790
	.loc 1 488 5 view .LVU2791
	.loc 1 488 5 view .LVU2792
	bbsi	a2, 7, .L418	# tmp2107,,
	j	.L419		#
.L417:
	.loc 1 487 5 view .LVU2793
	l16ui	a3, a14, 0	# cpustatus,
	movi.n	a2, 2	# tmp2117,
	or	a3, a3, a2	# tmp2119, cpustatus, tmp2117
	extui	a3, a3, 0, 16	# _1315, tmp2119
	.loc 1 487 16 view .LVU2794
	.loc 1 488 5 view .LVU2795
	.loc 1 488 5 view .LVU2796
	j	.L419		#
.L418:
	.loc 1 488 5 view .LVU2797
	movi	a2, 0x80	# tmp2121,
	or	a3, a3, a2	# tmp2122, _1315, tmp2121
	s16i	a3, a14, 0	# cpustatus, tmp2122
	j	.L170		#
.L419:
	.loc 1 488 5 view .LVU2798
	movi	a2, -0x81	# tmp2124,
	and	a3, a3, a2	# tmp2125, _1315, tmp2124
	s16i	a3, a14, 0	# cpustatus, tmp2125
	j	.L170		#
.L230:
.LBE1617:
.LBE1620:
	.loc 1 1190 5 view .LVU2799
	.loc 1 1191 7 view .LVU2800
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1191:       indx();
	.loc 1 1191 11 is_stmt 0 view .LVU2801
	call0	_Z4indxv		#
.LVL458:
	.loc 1 1192 7 is_stmt 1 view .LVU2802
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1192:       lda();
	.loc 1 1192 10 is_stmt 0 view .LVU2803
	call0	_Z3ldav		#
.LVL459:
	.loc 1 1193 7 is_stmt 1 view .LVU2804
	j	.L170		#
.L229:
	.loc 1 1194 5 view .LVU2805
	.loc 1 1195 7 view .LVU2806
.LBB1621:
.LBI1621:
	.loc 1 148 13 view .LVU2807
.LBB1622:
	.loc 1 149 5 view .LVU2808
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU2809
	l16ui	a3, a13, 0	# pc, pc$356_308
	addi.n	a4, a3, 1	# tmp2128, pc$356_308,
	s16i	a4, a13, 0	# pc, tmp2128
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU2810
	l32r	a4, .LC179	#, tmp2129
.LBE1622:
.LBE1621:
.LBB1624:
.LBB1625:
.LBB1626:
.LBB1627:
.LBB1628:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 view .LVU2811
	mov.n	a2, a3	#, pc$356_308
.LBE1628:
.LBE1627:
.LBE1626:
.LBE1625:
.LBE1624:
.LBB1638:
.LBB1623:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU2812
	s16i	a3, a4, 0	# ea, pc$356_308
.LBE1623:
.LBE1638:
	.loc 1 1196 7 is_stmt 1 view .LVU2813
.LBB1639:
.LBI1624:
	.loc 1 475 13 view .LVU2814
.LBB1636:
	.loc 1 476 5 view .LVU2815
.LBB1633:
.LBI1626:
	.loc 1 216 17 view .LVU2816
.LBE1633:
.LBE1636:
.LBE1639:
	.loc 1 217 5 view .LVU2817
.LBB1640:
.LBB1637:
.LBB1634:
.LBB1631:
.LBI1627:
	.loc 1 216 17 view .LVU2818
.LBB1629:
	.loc 1 218 14 view .LVU2819
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU2820
	call0	_Z8read6502t		#
.LVL460:
.LBE1629:
.LBE1631:
.LBE1634:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU2821
	l32r	a4, .LC191	#, tmp2131
.LBB1635:
.LBB1632:
.LBB1630:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU2822
	extui	a3, a2, 0, 16	# _1350, tmp2130
.LBE1630:
.LBE1632:
.LBE1635:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU2823
	s16i	a3, a4, 0	# value, _1350
	.loc 1 477 5 is_stmt 1 view .LVU2824
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:477:     x = (uint8_t)(value & 0x00FF);
	.loc 1 477 7 is_stmt 0 view .LVU2825
	l32r	a4, .LC189	#, tmp2132
	s8i	a2, a4, 0	# x, tmp2130
	.loc 1 479 5 is_stmt 1 view .LVU2826
	.loc 1 479 5 view .LVU2827
	beqz.n	a3, .L420	# _1350,
	.loc 1 479 5 view .LVU2828
	l16ui	a3, a14, 0	# cpustatus, tmp2136
	movi.n	a4, -3	# tmp2134,
	and	a3, a3, a4	# cstore_546, tmp2136, tmp2134
	.loc 1 479 16 view .LVU2829
	.loc 1 480 5 view .LVU2830
	.loc 1 480 5 view .LVU2831
	bbsi	a2, 7, .L421	# tmp2130,,
	j	.L422		#
.L420:
	.loc 1 479 5 view .LVU2832
	l16ui	a3, a14, 0	# cpustatus,
	movi.n	a2, 2	# tmp2140,
	or	a3, a3, a2	# tmp2142, cpustatus, tmp2140
	extui	a3, a3, 0, 16	# cstore_546, tmp2142
	.loc 1 479 16 view .LVU2833
	.loc 1 480 5 view .LVU2834
	.loc 1 480 5 view .LVU2835
	j	.L422		#
.L421:
	.loc 1 480 5 view .LVU2836
	movi	a2, 0x80	# tmp2144,
	or	a3, a3, a2	# tmp2145, cstore_546, tmp2144
	s16i	a3, a14, 0	# cpustatus, tmp2145
	j	.L170		#
.L422:
	.loc 1 480 5 view .LVU2837
	movi	a2, -0x81	# tmp2147,
	and	a3, a3, a2	# tmp2148, cstore_546, tmp2147
	s16i	a3, a14, 0	# cpustatus, tmp2148
	j	.L170		#
.L228:
.LBE1637:
.LBE1640:
	.loc 1 1200 5 view .LVU2838
	.loc 1 1201 7 view .LVU2839
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1201:       zp();
	.loc 1 1201 9 is_stmt 0 view .LVU2840
	call0	_Z2zpv		#
.LVL461:
	.loc 1 1202 7 is_stmt 1 view .LVU2841
.LBB1641:
.LBI1641:
	.loc 1 483 13 view .LVU2842
.LBB1642:
	.loc 1 484 5 view .LVU2843
.LBB1643:
.LBI1643:
	.loc 1 216 17 view .LVU2844
.LBB1644:
	.loc 1 217 5 view .LVU2845
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	beqz.n	a2, .L423	# useaccum,
	.loc 1 217 19 view .LVU2846
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU2847
	l32r	a3, .LC190	#, tmp2151
	l8ui	a2, a3, 0	# prephitmp_1070, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU2848
	mov.n	a3, a2	# _1365, prephitmp_1070
	j	.L424		#
.L423:
.LBB1645:
.LBI1645:
	.loc 1 216 17 is_stmt 1 view .LVU2849
.LBB1646:
	.loc 1 218 14 view .LVU2850
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU2851
	l32r	a2, .LC179	#, tmp2152
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL462:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU2852
	extui	a3, a2, 0, 16	# _1365, prephitmp_1070
.L424:
.LBE1646:
.LBE1645:
.LBE1644:
.LBE1643:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU2853
	l32r	a4, .LC191	#, tmp2155
	s16i	a3, a4, 0	# value, _1365
	.loc 1 485 5 is_stmt 1 view .LVU2854
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:485:     y = (uint8_t)(value & 0x00FF);
	.loc 1 485 7 is_stmt 0 view .LVU2855
	l32r	a4, .LC188	#, tmp2156
	s8i	a2, a4, 0	# y, prephitmp_1070
	.loc 1 487 5 is_stmt 1 view .LVU2856
	.loc 1 487 5 view .LVU2857
	l16ui	a2, a14, 0	# cpustatus, pretmp_1301
	beqz.n	a3, .L425	# _1365,
	.loc 1 487 5 view .LVU2858
	movi.n	a4, -3	# tmp2158,
	and	a2, a2, a4	# cstore_415, pretmp_1301, tmp2158
	.loc 1 487 16 view .LVU2859
	.loc 1 488 5 view .LVU2860
	.loc 1 488 5 view .LVU2861
	bbsi	a3, 7, .L426	# _1365,,
	j	.L427		#
.L425:
	.loc 1 487 5 view .LVU2862
	movi.n	a3, 2	# tmp2163,
	or	a2, a2, a3	# cstore_415, pretmp_1301, tmp2163
	.loc 1 487 16 view .LVU2863
	.loc 1 488 5 view .LVU2864
	.loc 1 488 5 view .LVU2865
	j	.L427		#
.L426:
	.loc 1 488 5 view .LVU2866
	movi	a3, 0x80	# tmp2165,
	or	a2, a2, a3	# tmp2166, cstore_415, tmp2165
	s16i	a2, a14, 0	# cpustatus, tmp2166
	j	.L170		#
.L427:
	.loc 1 488 5 view .LVU2867
	movi	a3, -0x81	# tmp2168,
	and	a2, a2, a3	# tmp2169, cstore_415, tmp2168
	s16i	a2, a14, 0	# cpustatus, tmp2169
	j	.L170		#
.L227:
.LBE1642:
.LBE1641:
	.loc 1 1204 5 view .LVU2868
	.loc 1 1205 7 view .LVU2869
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1205:       zp();
	.loc 1 1205 9 is_stmt 0 view .LVU2870
	call0	_Z2zpv		#
.LVL463:
	.loc 1 1206 7 is_stmt 1 view .LVU2871
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1206:       lda();
	.loc 1 1206 10 is_stmt 0 view .LVU2872
	call0	_Z3ldav		#
.LVL464:
	.loc 1 1207 7 is_stmt 1 view .LVU2873
	j	.L170		#
.L226:
	.loc 1 1208 5 view .LVU2874
	.loc 1 1209 7 view .LVU2875
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1209:       zp();
	.loc 1 1209 9 is_stmt 0 view .LVU2876
	call0	_Z2zpv		#
.LVL465:
	.loc 1 1210 7 is_stmt 1 view .LVU2877
.LBB1647:
.LBI1647:
	.loc 1 475 13 view .LVU2878
.LBB1648:
	.loc 1 476 5 view .LVU2879
.LBB1649:
.LBI1649:
	.loc 1 216 17 view .LVU2880
.LBB1650:
	.loc 1 217 5 view .LVU2881
	l32r	a4, .LC172	#,
	l8ui	a2, a4, 0	# useaccum, useaccum
	beqz.n	a2, .L428	# useaccum,
	.loc 1 217 19 view .LVU2882
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU2883
	l32r	a3, .LC190	#, tmp2172
	l8ui	a2, a3, 0	# prephitmp_1063, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU2884
	mov.n	a3, a2	# _1386, prephitmp_1063
	j	.L429		#
.L428:
.LBB1651:
.LBI1651:
	.loc 1 216 17 is_stmt 1 view .LVU2885
.LBB1652:
	.loc 1 218 14 view .LVU2886
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU2887
	l32r	a2, .LC179	#, tmp2173
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL466:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU2888
	extui	a3, a2, 0, 16	# _1386, prephitmp_1063
.L429:
.LBE1652:
.LBE1651:
.LBE1650:
.LBE1649:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU2889
	l32r	a4, .LC191	#, tmp2176
	s16i	a3, a4, 0	# value, _1386
	.loc 1 477 5 is_stmt 1 view .LVU2890
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:477:     x = (uint8_t)(value & 0x00FF);
	.loc 1 477 7 is_stmt 0 view .LVU2891
	l32r	a4, .LC189	#, tmp2177
	s8i	a2, a4, 0	# x, prephitmp_1063
	.loc 1 479 5 is_stmt 1 view .LVU2892
	.loc 1 479 5 view .LVU2893
	l16ui	a2, a14, 0	# cpustatus, pretmp_1297
	beqz.n	a3, .L430	# _1386,
	.loc 1 479 5 view .LVU2894
	movi.n	a4, -3	# tmp2179,
	and	a2, a2, a4	# cstore_545, pretmp_1297, tmp2179
	.loc 1 479 16 view .LVU2895
	.loc 1 480 5 view .LVU2896
	.loc 1 480 5 view .LVU2897
	bbsi	a3, 7, .L431	# _1386,,
	j	.L432		#
.L430:
	.loc 1 479 5 view .LVU2898
	movi.n	a3, 2	# tmp2184,
	or	a2, a2, a3	# cstore_545, pretmp_1297, tmp2184
	.loc 1 479 16 view .LVU2899
	.loc 1 480 5 view .LVU2900
	.loc 1 480 5 view .LVU2901
	j	.L432		#
.L431:
	.loc 1 480 5 view .LVU2902
	movi	a3, 0x80	# tmp2186,
	or	a2, a2, a3	# tmp2187, cstore_545, tmp2186
	s16i	a2, a14, 0	# cpustatus, tmp2187
	j	.L170		#
.L432:
	.loc 1 480 5 view .LVU2903
	movi	a3, -0x81	# tmp2189,
	and	a2, a2, a3	# tmp2190, cstore_545, tmp2189
	s16i	a2, a14, 0	# cpustatus, tmp2190
	j	.L170		#
.L225:
.LBE1648:
.LBE1647:
	.loc 1 1214 5 view .LVU2904
	.loc 1 1215 7 view .LVU2905
	.loc 1 1216 7 view .LVU2906
.LBB1653:
.LBI1653:
	.loc 1 612 13 view .LVU2907
.LBB1654:
	.loc 1 613 5 view .LVU2908
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:613:     y = a;
	.loc 1 613 7 is_stmt 0 view .LVU2909
	l32r	a2, .LC190	#, tmp2191
	l32r	a3, .LC188	#, tmp2192
	l8ui	a2, a2, 0	# a$221_1394, a
	s8i	a2, a3, 0	# y, a$221_1394
	.loc 1 615 5 is_stmt 1 view .LVU2910
	.loc 1 615 5 view .LVU2911
	beqz.n	a2, .L433	# a$221_1394,
	.loc 1 615 5 view .LVU2912
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:616:     signcalc(y);
	.loc 1 616 5 is_stmt 0 view .LVU2913
	slli	a3, a2, 24	# tmp2196, a$221_1394,
	movi.n	a2, -3	# tmp2193,
	and	a2, a5, a2	# _873, cpustatus$6_5, tmp2193
	.loc 1 615 16 is_stmt 1 view .LVU2914
	.loc 1 616 5 view .LVU2915
	.loc 1 616 5 view .LVU2916
	bltz	a3, .L434	# tmp2196,
	j	.L612		#
.L433:
	.loc 1 615 5 view .LVU2917
	movi.n	a2, 0x22	# tmp2198,
	or	a2, a5, a2	# cstore_544, cpustatus$6_5, tmp2198
	.loc 1 615 16 view .LVU2918
	.loc 1 616 5 view .LVU2919
	.loc 1 616 5 view .LVU2920
	j	.L436		#
.L434:
	.loc 1 616 5 view .LVU2921
	movi	a3, 0xa0	# tmp2200,
	or	a2, a2, a3	# tmp2201, _873, tmp2200
	s16i	a2, a14, 0	# cpustatus, tmp2201
	j	.L170		#
.L612:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:615:     zerocalc(y);
	.loc 1 615 5 is_stmt 0 view .LVU2922
	movi.n	a5, 0x20	#,
	or	a2, a2, a5	# tmp2203, _873,
	extui	a2, a2, 0, 16	# cstore_544, tmp2203
.L436:
	.loc 1 616 5 is_stmt 1 view .LVU2923
	movi	a3, -0x81	# tmp2205,
	and	a2, a2, a3	# tmp2206, cstore_544, tmp2205
	s16i	a2, a14, 0	# cpustatus, tmp2206
	j	.L170		#
.L224:
.LBE1654:
.LBE1653:
	.loc 1 1218 5 view .LVU2924
	.loc 1 1219 7 view .LVU2925
.LBB1655:
.LBI1655:
	.loc 1 148 13 view .LVU2926
.LBB1656:
	.loc 1 149 5 view .LVU2927
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU2928
	l16ui	a2, a13, 0	# pc, pc$356_310
	addi.n	a3, a2, 1	# tmp2209, pc$356_310,
	s16i	a3, a13, 0	# pc, tmp2209
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU2929
	l32r	a3, .LC179	#, tmp2210
	s16i	a2, a3, 0	# ea, pc$356_310
.LBE1656:
.LBE1655:
	.loc 1 1220 7 is_stmt 1 view .LVU2930
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1220:       lda();
	.loc 1 1220 10 is_stmt 0 view .LVU2931
	call0	_Z3ldav		#
.LVL467:
	.loc 1 1221 7 is_stmt 1 view .LVU2932
	j	.L170		#
.L223:
	.loc 1 1222 5 view .LVU2933
	.loc 1 1223 7 view .LVU2934
	.loc 1 1224 7 view .LVU2935
.LBB1657:
.LBI1657:
	.loc 1 605 13 view .LVU2936
.LBB1658:
	.loc 1 606 5 view .LVU2937
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:606:     x = a;
	.loc 1 606 7 is_stmt 0 view .LVU2938
	l32r	a2, .LC190	#, tmp2211
	l32r	a3, .LC189	#, tmp2212
	l8ui	a2, a2, 0	# a$229_1404, a
	s8i	a2, a3, 0	# x, a$229_1404
	.loc 1 608 5 is_stmt 1 view .LVU2939
	.loc 1 608 5 view .LVU2940
	beqz.n	a2, .L437	# a$229_1404,
	.loc 1 608 5 view .LVU2941
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:609:     signcalc(x);
	.loc 1 609 5 is_stmt 0 view .LVU2942
	slli	a3, a2, 24	# tmp2216, a$229_1404,
	movi.n	a2, -3	# tmp2213,
	and	a2, a5, a2	# _872, cpustatus$6_5, tmp2213
	.loc 1 608 16 is_stmt 1 view .LVU2943
	.loc 1 609 5 view .LVU2944
	.loc 1 609 5 view .LVU2945
	bltz	a3, .L438	# tmp2216,
	j	.L613		#
.L437:
	.loc 1 608 5 view .LVU2946
	movi.n	a2, 0x22	# tmp2218,
	or	a2, a5, a2	# cstore_543, cpustatus$6_5, tmp2218
	.loc 1 608 16 view .LVU2947
	.loc 1 609 5 view .LVU2948
	.loc 1 609 5 view .LVU2949
	j	.L440		#
.L438:
	.loc 1 609 5 view .LVU2950
	movi	a3, 0xa0	# tmp2220,
	or	a2, a2, a3	# tmp2221, _872, tmp2220
	s16i	a2, a14, 0	# cpustatus, tmp2221
	j	.L170		#
.L613:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:608:     zerocalc(x);
	.loc 1 608 5 is_stmt 0 view .LVU2951
	movi.n	a6, 0x20	#,
	or	a2, a2, a6	# tmp2223, _872,
	extui	a2, a2, 0, 16	# cstore_543, tmp2223
.L440:
	.loc 1 609 5 is_stmt 1 view .LVU2952
	movi	a3, -0x81	# tmp2225,
	and	a2, a2, a3	# tmp2226, cstore_543, tmp2225
	s16i	a2, a14, 0	# cpustatus, tmp2226
	j	.L170		#
.L222:
.LBE1658:
.LBE1657:
	.loc 1 1228 5 view .LVU2953
	.loc 1 1229 7 view .LVU2954
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1229:       abso();
	.loc 1 1229 11 is_stmt 0 view .LVU2955
	call0	_Z4absov		#
.LVL468:
	.loc 1 1230 7 is_stmt 1 view .LVU2956
.LBB1659:
.LBI1659:
	.loc 1 483 13 view .LVU2957
.LBB1660:
	.loc 1 484 5 view .LVU2958
.LBB1661:
.LBI1661:
	.loc 1 216 17 view .LVU2959
.LBB1662:
	.loc 1 217 5 view .LVU2960
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	beqz.n	a2, .L441	# useaccum,
	.loc 1 217 19 view .LVU2961
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU2962
	l32r	a3, .LC190	#, tmp2229
	l8ui	a2, a3, 0	# a$39_1426, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU2963
	mov.n	a3, a2	# _1427, a$39_1426
	j	.L442		#
.L441:
.LBB1663:
.LBI1663:
	.loc 1 216 17 is_stmt 1 view .LVU2964
.LBB1664:
	.loc 1 218 14 view .LVU2965
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU2966
	l32r	a2, .LC179	#, tmp2230
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL469:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU2967
	extui	a3, a2, 0, 16	# _1427, a$39_1426
.L442:
.LBE1664:
.LBE1663:
.LBE1662:
.LBE1661:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU2968
	l32r	a4, .LC191	#, tmp2233
	s16i	a3, a4, 0	# value, _1427
	.loc 1 485 5 is_stmt 1 view .LVU2969
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:485:     y = (uint8_t)(value & 0x00FF);
	.loc 1 485 7 is_stmt 0 view .LVU2970
	l32r	a4, .LC188	#, tmp2234
	s8i	a2, a4, 0	# y, a$39_1426
	.loc 1 487 5 is_stmt 1 view .LVU2971
	.loc 1 487 5 view .LVU2972
	l16ui	a2, a14, 0	# cpustatus, pretmp_1293
	beqz.n	a3, .L443	# _1427,
	.loc 1 487 5 view .LVU2973
	movi.n	a4, -3	# tmp2236,
	and	a2, a2, a4	# cstore_539, pretmp_1293, tmp2236
	.loc 1 487 16 view .LVU2974
	.loc 1 488 5 view .LVU2975
	.loc 1 488 5 view .LVU2976
	bbsi	a3, 7, .L444	# _1427,,
	j	.L445		#
.L443:
	.loc 1 487 5 view .LVU2977
	movi.n	a3, 2	# tmp2241,
	or	a2, a2, a3	# cstore_539, pretmp_1293, tmp2241
	.loc 1 487 16 view .LVU2978
	.loc 1 488 5 view .LVU2979
	.loc 1 488 5 view .LVU2980
	j	.L445		#
.L444:
	.loc 1 488 5 view .LVU2981
	movi	a3, 0x80	# tmp2243,
	or	a2, a2, a3	# tmp2244, cstore_539, tmp2243
	s16i	a2, a14, 0	# cpustatus, tmp2244
	j	.L170		#
.L445:
	.loc 1 488 5 view .LVU2982
	movi	a3, -0x81	# tmp2246,
	and	a2, a2, a3	# tmp2247, cstore_539, tmp2246
	s16i	a2, a14, 0	# cpustatus, tmp2247
	j	.L170		#
.L221:
.LBE1660:
.LBE1659:
	.loc 1 1232 5 view .LVU2983
	.loc 1 1233 7 view .LVU2984
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1233:       abso();
	.loc 1 1233 11 is_stmt 0 view .LVU2985
	call0	_Z4absov		#
.LVL470:
	.loc 1 1234 7 is_stmt 1 view .LVU2986
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1234:       lda();
	.loc 1 1234 10 is_stmt 0 view .LVU2987
	call0	_Z3ldav		#
.LVL471:
	.loc 1 1235 7 is_stmt 1 view .LVU2988
	j	.L170		#
.L220:
	.loc 1 1236 5 view .LVU2989
	.loc 1 1237 7 view .LVU2990
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1237:       abso();
	.loc 1 1237 11 is_stmt 0 view .LVU2991
	call0	_Z4absov		#
.LVL472:
	.loc 1 1238 7 is_stmt 1 view .LVU2992
.LBB1665:
.LBI1665:
	.loc 1 475 13 view .LVU2993
.LBB1666:
	.loc 1 476 5 view .LVU2994
.LBB1667:
.LBI1667:
	.loc 1 216 17 view .LVU2995
.LBB1668:
	.loc 1 217 5 view .LVU2996
	l32r	a4, .LC172	#,
	l8ui	a2, a4, 0	# useaccum, useaccum
	beqz.n	a2, .L446	# useaccum,
	.loc 1 217 19 view .LVU2997
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU2998
	l32r	a3, .LC190	#, tmp2250
	l8ui	a2, a3, 0	# a$39_1447, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU2999
	mov.n	a3, a2	# _1448, a$39_1447
	j	.L447		#
.L446:
.LBB1669:
.LBI1669:
	.loc 1 216 17 is_stmt 1 view .LVU3000
.LBB1670:
	.loc 1 218 14 view .LVU3001
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3002
	l32r	a2, .LC179	#, tmp2251
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL473:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3003
	extui	a3, a2, 0, 16	# _1448, a$39_1447
.L447:
.LBE1670:
.LBE1669:
.LBE1668:
.LBE1667:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU3004
	l32r	a4, .LC191	#, tmp2254
	s16i	a3, a4, 0	# value, _1448
	.loc 1 477 5 is_stmt 1 view .LVU3005
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:477:     x = (uint8_t)(value & 0x00FF);
	.loc 1 477 7 is_stmt 0 view .LVU3006
	l32r	a4, .LC189	#, tmp2255
	s8i	a2, a4, 0	# x, a$39_1447
	.loc 1 479 5 is_stmt 1 view .LVU3007
	.loc 1 479 5 view .LVU3008
	l16ui	a2, a14, 0	# cpustatus, pretmp_1292
	beqz.n	a3, .L448	# _1448,
	.loc 1 479 5 view .LVU3009
	movi.n	a4, -3	# tmp2257,
	and	a2, a2, a4	# cstore_412, pretmp_1292, tmp2257
	.loc 1 479 16 view .LVU3010
	.loc 1 480 5 view .LVU3011
	.loc 1 480 5 view .LVU3012
	bbsi	a3, 7, .L449	# _1448,,
	j	.L450		#
.L448:
	.loc 1 479 5 view .LVU3013
	movi.n	a3, 2	# tmp2262,
	or	a2, a2, a3	# cstore_412, pretmp_1292, tmp2262
	.loc 1 479 16 view .LVU3014
	.loc 1 480 5 view .LVU3015
	.loc 1 480 5 view .LVU3016
	j	.L450		#
.L449:
	.loc 1 480 5 view .LVU3017
	movi	a3, 0x80	# tmp2264,
	or	a2, a2, a3	# tmp2265, cstore_412, tmp2264
	s16i	a2, a14, 0	# cpustatus, tmp2265
	j	.L170		#
.L450:
	.loc 1 480 5 view .LVU3018
	movi	a3, -0x81	# tmp2267,
	and	a2, a2, a3	# tmp2268, cstore_412, tmp2267
	s16i	a2, a14, 0	# cpustatus, tmp2268
	j	.L170		#
.L219:
.LBE1666:
.LBE1665:
	.loc 1 1242 5 view .LVU3019
	.loc 1 1243 7 view .LVU3020
.LBB1671:
.LBI1671:
	.loc 1 164 13 view .LVU3021
.LBB1672:
	.loc 1 165 5 view .LVU3022
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU3023
	l16ui	a2, a13, 0	# pc, pc$374_1458
.LBB1673:
.LBB1674:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU3024
	movi	a4, 0x1ff	# tmp2273,
.LBE1674:
.LBE1673:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU3025
	addi.n	a5, a2, 1	# tmp2271, pc$374_1458,
	s16i	a5, a13, 0	# pc, tmp2271
.LVL474:
.LBB1679:
.LBI1673:
	.loc 1 69 9 is_stmt 1 view .LVU3026
.LBB1677:
	.loc 1 70 3 view .LVU3027
	bltu	a4, a2, .L451	# tmp2273, pc$374_1458,
	.loc 1 71 5 view .LVU3028
	.loc 1 72 7 view .LVU3029
	.loc 1 75 12 view .LVU3030
	movi	a4, 0xfe	# tmp2275,
	bne	a2, a4, .L452	# pc$374_1458, tmp2275,
	.loc 1 76 9 view .LVU3031
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU3032
	call0	rand		#
.LVL475:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU3033
	extui	a2, a2, 0, 8	# _1469,
	j	.L633		#
.LVL476:
.L452:
	.loc 1 79 5 is_stmt 1 view .LVU3034
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU3035
	l32r	a4, .LC175	#, tmp2277
	add.n	a2, a4, a2	# tmp2278, tmp2277, pc$374_1458
.LVL477:
	.loc 1 79 28 view .LVU3036
	j	.L634		#
.LVL478:
.L451:
	.loc 1 81 3 is_stmt 1 view .LVU3037
	l32r	a4, .LC180	#, tmp2279
	extui	a4, a4, 0, 16	# tmp2280, tmp2279
	bltu	a4, a2, .L454	# tmp2280, pc$374_1458,
.LVL479:
.LBB1675:
.LBI1675:
	.loc 1 69 9 view .LVU3038
.LBB1676:
	.loc 1 82 5 view .LVU3039
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU3040
	addmi	a2, a2, -0x200	# tmp2281, pc$374_1458,
.LVL480:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU3041
	extui	a2, a2, 0, 16	#, tmp2281
.LVL481:
	.loc 1 82 28 view .LVU3042
	call0	_Z16loadPixelFromRamt		#
.LVL482:
.L633:
	.loc 1 82 28 view .LVU3043
.LBE1676:
.LBE1675:
.LBE1677:
.LBE1679:
.LBE1672:
.LBE1671:
.LBB1684:
.LBB1685:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:273:     if ((cpustatus & FLAG_CARRY) == FLAG_CARRY) {
	.loc 1 273 20 view .LVU3044
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L453		#
.LVL483:
.L454:
	.loc 1 273 20 view .LVU3045
.LBE1685:
.LBE1684:
.LBB1690:
.LBB1681:
.LBB1680:
.LBB1678:
	.loc 1 84 3 is_stmt 1 view .LVU3046
	l32r	a4, .LC182	#, tmp2285
	extui	a4, a4, 0, 16	# tmp2286, tmp2285
	bltu	a4, a2, .L455	# tmp2286, pc$374_1458,
	.loc 1 85 5 view .LVU3047
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU3048
	l32r	a4, .LC184	#, tmp2287
	add.n	a2, a4, a2	# tmp2288, tmp2287, pc$374_1458
.LVL484:
	.loc 1 85 32 view .LVU3049
	addmi	a2, a2, -0x1200	# tmp2289, tmp2288,
.L634:
	.loc 1 85 32 view .LVU3050
	l8ui	a2, a2, 0	# _1469,
.LVL485:
.L453:
	.loc 1 85 32 view .LVU3051
.LBE1678:
.LBE1680:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU3052
	extui	a4, a2, 0, 16	# _1462, _1469
	.loc 1 166 5 is_stmt 1 view .LVU3053
	bbsi	a2, 7, .L456	# _1469,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU3054
	l32r	a2, .LC185	#, tmp3112
	j	.L635		#
.L456:
	.loc 1 166 25 is_stmt 1 view .LVU3055
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU3056
	movi	a5, -0x100	# tmp2294,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp2295, _1462, tmp2294
.L635:
.LBE1681:
.LBE1690:
	.loc 1 1244 7 is_stmt 1 view .LVU3057
.LBB1691:
.LBI1684:
	.loc 1 272 13 view .LVU3058
.LBB1688:
	.loc 1 273 5 view .LVU3059
.LBE1688:
.LBE1691:
.LBB1692:
.LBB1682:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU3060
	s16i	a4, a2, 0	# reladdr, tmp2295
.LBE1682:
.LBE1692:
.LBB1693:
.LBB1689:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:273:     if ((cpustatus & FLAG_CARRY) == FLAG_CARRY) {
	.loc 1 273 5 view .LVU3061
	bbci	a3, 0, .L170	# prephitmp_1199,,
.LBB1686:
.LBI1686:
	.loc 1 263 13 is_stmt 1 view .LVU3062
.LBB1687:
	.loc 1 265 9 view .LVU3063
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU3064
	l16ui	a5, a13, 0	# pc, pc$202_1481
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3065
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3066
	l32r	a6, .LC187	#, tmp2305
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3067
	add.n	a3, a5, a3	# tmp2303, pc$202_1481, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3068
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1791
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3069
	extui	a3, a3, 0, 16	# _1483, tmp2303
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU3070
	movi	a7, -0x100	# tmp2307,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU3071
	xor	a4, a5, a3	# tmp2306, pc$202_1481, _1483
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU3072
	and	a4, a4, a7	# tmp2311, tmp2306, tmp2307
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3073
	addi.n	a7, a2, 1	# tmp2315, pretmp_1791,
	addi.n	a2, a2, 2	# tmp2313, pretmp_1791,
	moveqz	a2, a7, a4	# tmp3124, tmp2315, tmp2311
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU3074
	l32r	a4, .LC186	#, tmp2300
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3075
	s16i	a3, a13, 0	# pc, _1483
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU3076
	s16i	a5, a4, 0	# oldpc, pc$202_1481
	.loc 1 266 9 is_stmt 1 view .LVU3077
	.loc 1 267 9 view .LVU3078
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU3079
	s32i.n	a2, a6, 0	# clockticks6502, tmp3124
	j	.L170		#
.L218:
.LBE1687:
.LBE1686:
.LBE1689:
.LBE1693:
	.loc 1 1246 5 is_stmt 1 view .LVU3080
	.loc 1 1247 7 view .LVU3081
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1247:       indy();
	.loc 1 1247 11 is_stmt 0 view .LVU3082
	call0	_Z4indyv		#
.LVL486:
	.loc 1 1248 7 is_stmt 1 view .LVU3083
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1248:       lda();
	.loc 1 1248 10 is_stmt 0 view .LVU3084
	call0	_Z3ldav		#
.LVL487:
	.loc 1 1249 7 is_stmt 1 view .LVU3085
	j	.L170		#
.L217:
	.loc 1 1253 5 view .LVU3086
	.loc 1 1254 7 view .LVU3087
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1254:       zpx();
	.loc 1 1254 10 is_stmt 0 view .LVU3088
	call0	_Z3zpxv		#
.LVL488:
	.loc 1 1255 7 is_stmt 1 view .LVU3089
.LBB1694:
.LBI1694:
	.loc 1 483 13 view .LVU3090
.LBB1695:
	.loc 1 484 5 view .LVU3091
.LBB1696:
.LBI1696:
	.loc 1 216 17 view .LVU3092
.LBB1697:
	.loc 1 217 5 view .LVU3093
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	beqz.n	a2, .L459	# useaccum,
	.loc 1 217 19 view .LVU3094
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3095
	l32r	a3, .LC190	#, tmp2318
	l8ui	a2, a3, 0	# prephitmp_1023, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3096
	mov.n	a3, a2	# _1503, prephitmp_1023
	j	.L460		#
.L459:
.LBB1698:
.LBI1698:
	.loc 1 216 17 is_stmt 1 view .LVU3097
.LBB1699:
	.loc 1 218 14 view .LVU3098
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3099
	l32r	a2, .LC179	#, tmp2319
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL489:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3100
	extui	a3, a2, 0, 16	# _1503, prephitmp_1023
.L460:
.LBE1699:
.LBE1698:
.LBE1697:
.LBE1696:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU3101
	l32r	a4, .LC191	#, tmp2322
	s16i	a3, a4, 0	# value, _1503
	.loc 1 485 5 is_stmt 1 view .LVU3102
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:485:     y = (uint8_t)(value & 0x00FF);
	.loc 1 485 7 is_stmt 0 view .LVU3103
	l32r	a4, .LC188	#, tmp2323
	s8i	a2, a4, 0	# y, prephitmp_1023
	.loc 1 487 5 is_stmt 1 view .LVU3104
	.loc 1 487 5 view .LVU3105
	l16ui	a2, a14, 0	# cpustatus, pretmp_1321
	beqz.n	a3, .L461	# _1503,
	.loc 1 487 5 view .LVU3106
	movi.n	a4, -3	# tmp2325,
	and	a2, a2, a4	# cstore_419, pretmp_1321, tmp2325
	.loc 1 487 16 view .LVU3107
	.loc 1 488 5 view .LVU3108
	.loc 1 488 5 view .LVU3109
	bbsi	a3, 7, .L462	# _1503,,
	j	.L463		#
.L461:
	.loc 1 487 5 view .LVU3110
	movi.n	a3, 2	# tmp2330,
	or	a2, a2, a3	# cstore_419, pretmp_1321, tmp2330
	.loc 1 487 16 view .LVU3111
	.loc 1 488 5 view .LVU3112
	.loc 1 488 5 view .LVU3113
	j	.L463		#
.L462:
	.loc 1 488 5 view .LVU3114
	movi	a3, 0x80	# tmp2332,
	or	a2, a2, a3	# tmp2333, cstore_419, tmp2332
	s16i	a2, a14, 0	# cpustatus, tmp2333
	j	.L170		#
.L463:
	.loc 1 488 5 view .LVU3115
	movi	a3, -0x81	# tmp2335,
	and	a2, a2, a3	# tmp2336, cstore_419, tmp2335
	s16i	a2, a14, 0	# cpustatus, tmp2336
	j	.L170		#
.L216:
.LBE1695:
.LBE1694:
	.loc 1 1257 5 view .LVU3116
	.loc 1 1258 7 view .LVU3117
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1258:       zpx();
	.loc 1 1258 10 is_stmt 0 view .LVU3118
	call0	_Z3zpxv		#
.LVL490:
	.loc 1 1259 7 is_stmt 1 view .LVU3119
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1259:       lda();
	.loc 1 1259 10 is_stmt 0 view .LVU3120
	call0	_Z3ldav		#
.LVL491:
	.loc 1 1260 7 is_stmt 1 view .LVU3121
	j	.L170		#
.L215:
	.loc 1 1261 5 view .LVU3122
	.loc 1 1262 7 view .LVU3123
.LBB1700:
.LBI1700:
	.loc 1 160 13 view .LVU3124
.LBB1701:
	.loc 1 161 5 view .LVU3125
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 42 is_stmt 0 view .LVU3126
	l16ui	a2, a13, 0	# pc, pc$245_1522
	addi.n	a3, a2, 1	# tmp2339, pc$245_1522,
	s16i	a3, a13, 0	# pc, tmp2339
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 29 view .LVU3127
	call0	_Z8read6502t		#
.LVL492:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU3128
	l32r	a3, .LC188	#, tmp2341
.LBE1701:
.LBE1700:
.LBB1704:
.LBB1705:
.LBB1706:
.LBB1707:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3129
	l32r	a6, .LC172	#,
.LBE1707:
.LBE1706:
.LBE1705:
.LBE1704:
.LBB1716:
.LBB1702:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU3130
	l8ui	a3, a3, 0	#, y
.LBE1702:
.LBE1716:
.LBB1717:
.LBB1714:
.LBB1712:
.LBB1710:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3131
	l8ui	a4, a6, 0	# useaccum, useaccum
.LBE1710:
.LBE1712:
.LBE1714:
.LBE1717:
.LBB1718:
.LBB1703:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:161:     ea = ((uint16_t)read6502((uint16_t)pc++) + (uint16_t)y) & 0xFF; //zero-page wraparound
	.loc 1 161 61 view .LVU3132
	add.n	a2, a2, a3	# tmp2343,, y
	l32r	a3, .LC179	#, tmp2344
	extui	a2, a2, 0, 8	# _1527, tmp2343
	s16i	a2, a3, 0	# ea, _1527
.LBE1703:
.LBE1718:
	.loc 1 1263 7 is_stmt 1 view .LVU3133
.LBB1719:
.LBI1704:
	.loc 1 475 13 view .LVU3134
.LBB1715:
	.loc 1 476 5 view .LVU3135
.LBB1713:
.LBI1706:
	.loc 1 216 17 view .LVU3136
.LBB1711:
	.loc 1 217 5 view .LVU3137
	beqz.n	a4, .L464	# useaccum,
	.loc 1 217 19 view .LVU3138
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3139
	l32r	a3, .LC190	#, tmp2347
	l8ui	a2, a3, 0	# prephitmp_1029, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3140
	mov.n	a3, a2	# _1531, prephitmp_1029
	j	.L465		#
.L464:
.LBB1708:
.LBI1708:
	.loc 1 216 17 is_stmt 1 view .LVU3141
.LBB1709:
	.loc 1 218 14 view .LVU3142
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3143
	call0	_Z8read6502t		#
.LVL493:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3144
	extui	a3, a2, 0, 16	# _1531, prephitmp_1029
.L465:
.LBE1709:
.LBE1708:
.LBE1711:
.LBE1713:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU3145
	l32r	a4, .LC191	#, tmp2349
	s16i	a3, a4, 0	# value, _1531
	.loc 1 477 5 is_stmt 1 view .LVU3146
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:477:     x = (uint8_t)(value & 0x00FF);
	.loc 1 477 7 is_stmt 0 view .LVU3147
	l32r	a4, .LC189	#, tmp2350
	s8i	a2, a4, 0	# x, prephitmp_1029
	.loc 1 479 5 is_stmt 1 view .LVU3148
	.loc 1 479 5 view .LVU3149
	l16ui	a2, a14, 0	# cpustatus, pretmp_1347
	beqz.n	a3, .L466	# _1531,
	.loc 1 479 5 view .LVU3150
	movi.n	a4, -3	# tmp2352,
	and	a2, a2, a4	# _1516, pretmp_1347, tmp2352
	.loc 1 479 16 view .LVU3151
	.loc 1 480 5 view .LVU3152
	.loc 1 480 5 view .LVU3153
	bbsi	a3, 7, .L467	# _1531,,
	j	.L468		#
.L466:
	.loc 1 479 5 view .LVU3154
	movi.n	a3, 2	# tmp2357,
	or	a2, a2, a3	# _1516, pretmp_1347, tmp2357
	.loc 1 479 16 view .LVU3155
	.loc 1 480 5 view .LVU3156
	.loc 1 480 5 view .LVU3157
	j	.L468		#
.L467:
	.loc 1 480 5 view .LVU3158
	movi	a3, 0x80	# tmp2359,
	or	a2, a2, a3	# tmp2360, _1516, tmp2359
	s16i	a2, a14, 0	# cpustatus, tmp2360
	j	.L170		#
.L468:
	.loc 1 480 5 view .LVU3159
	movi	a3, -0x81	# tmp2362,
	and	a2, a2, a3	# tmp2363, _1516, tmp2362
	s16i	a2, a14, 0	# cpustatus, tmp2363
	j	.L170		#
.L214:
.LBE1715:
.LBE1719:
	.loc 1 1267 5 view .LVU3160
	.loc 1 1268 7 view .LVU3161
	.loc 1 1269 7 view .LVU3162
.LBB1720:
.LBI1720:
	.loc 1 363 13 view .LVU3163
.LBB1721:
	.loc 1 364 5 view .LVU3164
	movi	a2, -0x41	# tmp2365,
	and	a2, a5, a2	# tmp2366, cpustatus$6_5, tmp2365
	movi.n	a3, 0x20	#,
	or	a2, a2, a3	# tmp2369, tmp2366,
	s16i	a2, a14, 0	# cpustatus, tmp2369
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:365: }
	.loc 1 365 1 is_stmt 0 view .LVU3165
	j	.L170		#
.L213:
.LBE1721:
.LBE1720:
	.loc 1 1271 5 is_stmt 1 view .LVU3166
	.loc 1 1272 7 view .LVU3167
.LBB1722:
.LBI1722:
	.loc 1 183 13 view .LVU3168
.LBB1723:
	.loc 1 184 5 view .LVU3169
	.loc 1 185 5 view .LVU3170
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU3171
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL494:
	mov.n	a5, a2	# tmp2372,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3172
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3173
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3174
	addi.n	a2, a2, 1	# tmp2375, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3175
	extui	a2, a2, 0, 16	#, tmp2375
	call0	_Z8read6502t		#
.LVL495:
	.loc 1 186 5 is_stmt 1 view .LVU3176
	.loc 1 187 5 view .LVU3177
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU3178
	l32r	a4, .LC188	#, tmp2383
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3179
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3180
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU3181
	slli	a2, a2, 8	# tmp2379,,
.LVL496:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3182
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3183
	or	a2, a2, a5	# tmp2382, tmp2379, tmp2372
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3184
	add.n	a4, a4, a2	# tmp2387, y, tmp2382
	l32r	a2, .LC179	#, tmp2378
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3185
	addi.n	a3, a3, 2	# tmp2391, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3186
	s16i	a4, a2, 0	# ea, tmp2387
	.loc 1 189 5 is_stmt 1 view .LVU3187
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU3188
	s16i	a3, a13, 0	# pc, tmp2391
.LBE1723:
.LBE1722:
	.loc 1 1273 7 is_stmt 1 view .LVU3189
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1273:       lda();
	.loc 1 1273 10 is_stmt 0 view .LVU3190
	call0	_Z3ldav		#
.LVL497:
	.loc 1 1274 7 is_stmt 1 view .LVU3191
	j	.L170		#
.L212:
	.loc 1 1275 5 view .LVU3192
	.loc 1 1276 7 view .LVU3193
	.loc 1 1277 7 view .LVU3194
.LBB1724:
.LBI1724:
	.loc 1 619 13 view .LVU3195
.LBB1725:
	.loc 1 620 5 view .LVU3196
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:620:     x = sp;
	.loc 1 620 7 is_stmt 0 view .LVU3197
	l32r	a2, .LC174	#, tmp2392
	l32r	a3, .LC189	#, tmp2393
	l8ui	a2, a2, 0	# sp$249_1557, sp
	s8i	a2, a3, 0	# x, sp$249_1557
	.loc 1 622 5 is_stmt 1 view .LVU3198
	.loc 1 622 5 view .LVU3199
	beqz.n	a2, .L469	# sp$249_1557,
	.loc 1 622 5 view .LVU3200
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:623:     signcalc(x);
	.loc 1 623 5 is_stmt 0 view .LVU3201
	slli	a3, a2, 24	# tmp2397, sp$249_1557,
	movi.n	a2, -3	# tmp2394,
	and	a2, a5, a2	# _2492, cpustatus$6_5, tmp2394
	.loc 1 622 16 is_stmt 1 view .LVU3202
	.loc 1 623 5 view .LVU3203
	.loc 1 623 5 view .LVU3204
	bltz	a3, .L470	# tmp2397,
	j	.L614		#
.L469:
	.loc 1 622 5 view .LVU3205
	movi.n	a2, 0x22	# tmp2399,
	or	a2, a5, a2	# cstore_413, cpustatus$6_5, tmp2399
	.loc 1 622 16 view .LVU3206
	.loc 1 623 5 view .LVU3207
	.loc 1 623 5 view .LVU3208
	j	.L472		#
.L470:
	.loc 1 623 5 view .LVU3209
	movi	a3, 0xa0	# tmp2401,
	or	a2, a2, a3	# tmp2402, _2492, tmp2401
	s16i	a2, a14, 0	# cpustatus, tmp2402
	j	.L170		#
.L614:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:622:     zerocalc(x);
	.loc 1 622 5 is_stmt 0 view .LVU3210
	movi.n	a4, 0x20	#,
	or	a2, a2, a4	# tmp2404, _2492,
	extui	a2, a2, 0, 16	# cstore_413, tmp2404
.L472:
	.loc 1 623 5 is_stmt 1 view .LVU3211
	movi	a3, -0x81	# tmp2406,
	and	a2, a2, a3	# tmp2407, cstore_413, tmp2406
	s16i	a2, a14, 0	# cpustatus, tmp2407
	j	.L170		#
.L211:
.LBE1725:
.LBE1724:
	.loc 1 1279 5 view .LVU3212
	.loc 1 1280 7 view .LVU3213
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1280:       absx();
	.loc 1 1280 11 is_stmt 0 view .LVU3214
	call0	_Z4absxv		#
.LVL498:
	.loc 1 1281 7 is_stmt 1 view .LVU3215
.LBB1726:
.LBI1726:
	.loc 1 483 13 view .LVU3216
.LBB1727:
	.loc 1 484 5 view .LVU3217
.LBB1728:
.LBI1728:
	.loc 1 216 17 view .LVU3218
.LBB1729:
	.loc 1 217 5 view .LVU3219
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	beqz.n	a2, .L473	# useaccum,
	.loc 1 217 19 view .LVU3220
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3221
	l32r	a3, .LC190	#, tmp2410
	l8ui	a2, a3, 0	# prephitmp_1131, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3222
	mov.n	a3, a2	# _1580, prephitmp_1131
	j	.L474		#
.L473:
.LBB1730:
.LBI1730:
	.loc 1 216 17 is_stmt 1 view .LVU3223
.LBB1731:
	.loc 1 218 14 view .LVU3224
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3225
	l32r	a2, .LC179	#, tmp2411
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL499:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3226
	extui	a3, a2, 0, 16	# _1580, prephitmp_1131
.L474:
.LBE1731:
.LBE1730:
.LBE1729:
.LBE1728:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:484:     value = getvalue();
	.loc 1 484 11 view .LVU3227
	l32r	a4, .LC191	#, tmp2414
	s16i	a3, a4, 0	# value, _1580
	.loc 1 485 5 is_stmt 1 view .LVU3228
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:485:     y = (uint8_t)(value & 0x00FF);
	.loc 1 485 7 is_stmt 0 view .LVU3229
	l32r	a4, .LC188	#, tmp2415
	s8i	a2, a4, 0	# y, prephitmp_1131
	.loc 1 487 5 is_stmt 1 view .LVU3230
	.loc 1 487 5 view .LVU3231
	l16ui	a2, a14, 0	# cpustatus, pretmp_2490
	beqz.n	a3, .L475	# _1580,
	.loc 1 487 5 view .LVU3232
	movi.n	a4, -3	# tmp2417,
	and	a2, a2, a4	# cstore_950, pretmp_2490, tmp2417
	.loc 1 487 16 view .LVU3233
	.loc 1 488 5 view .LVU3234
	.loc 1 488 5 view .LVU3235
	bbsi	a3, 7, .L476	# _1580,,
	j	.L477		#
.L475:
	.loc 1 487 5 view .LVU3236
	movi.n	a3, 2	# tmp2422,
	or	a2, a2, a3	# cstore_950, pretmp_2490, tmp2422
	.loc 1 487 16 view .LVU3237
	.loc 1 488 5 view .LVU3238
	.loc 1 488 5 view .LVU3239
	j	.L477		#
.L476:
	.loc 1 488 5 view .LVU3240
	movi	a3, 0x80	# tmp2424,
	or	a2, a2, a3	# tmp2425, cstore_950, tmp2424
	s16i	a2, a14, 0	# cpustatus, tmp2425
	j	.L170		#
.L477:
	.loc 1 488 5 view .LVU3241
	movi	a3, -0x81	# tmp2427,
	and	a2, a2, a3	# tmp2428, cstore_950, tmp2427
	s16i	a2, a14, 0	# cpustatus, tmp2428
	j	.L170		#
.L210:
.LBE1727:
.LBE1726:
	.loc 1 1283 5 view .LVU3242
	.loc 1 1284 7 view .LVU3243
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1284:       absx();
	.loc 1 1284 11 is_stmt 0 view .LVU3244
	call0	_Z4absxv		#
.LVL500:
	.loc 1 1285 7 is_stmt 1 view .LVU3245
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1285:       lda();
	.loc 1 1285 10 is_stmt 0 view .LVU3246
	call0	_Z3ldav		#
.LVL501:
	.loc 1 1286 7 is_stmt 1 view .LVU3247
	j	.L170		#
.L209:
	.loc 1 1287 5 view .LVU3248
	.loc 1 1288 7 view .LVU3249
.LBB1732:
.LBI1732:
	.loc 1 183 13 view .LVU3250
.LBB1733:
	.loc 1 184 5 view .LVU3251
	.loc 1 185 5 view .LVU3252
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU3253
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL502:
	mov.n	a5, a2	# tmp2431,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3254
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3255
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3256
	addi.n	a2, a2, 1	# tmp2434, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3257
	extui	a2, a2, 0, 16	#, tmp2434
	call0	_Z8read6502t		#
.LVL503:
	.loc 1 186 5 is_stmt 1 view .LVU3258
	.loc 1 187 5 view .LVU3259
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU3260
	l32r	a3, .LC188	#, tmp2441
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3261
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3262
	l8ui	a3, a3, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU3263
	slli	a2, a2, 8	# tmp2437,,
.LVL504:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3264
	l16ui	a4, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3265
	or	a2, a2, a5	# tmp2440, tmp2437, tmp2431
.LBE1733:
.LBE1732:
.LBB1736:
.LBB1737:
.LBB1738:
.LBB1739:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3266
	l32r	a6, .LC172	#,
.LBE1739:
.LBE1738:
.LBE1737:
.LBE1736:
.LBB1748:
.LBB1734:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3267
	add.n	a2, a3, a2	# tmp2445, y, tmp2440
	l32r	a5, .LC179	#, tmp2446
	extui	a2, a2, 0, 16	# _1614, tmp2445
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3268
	addi.n	a4, a4, 2	# tmp2450, pc,
.LBE1734:
.LBE1748:
.LBB1749:
.LBB1746:
.LBB1744:
.LBB1742:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3269
	l8ui	a3, a6, 0	# useaccum, useaccum
.LBE1742:
.LBE1744:
.LBE1746:
.LBE1749:
.LBB1750:
.LBB1735:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3270
	s16i	a2, a5, 0	# ea, _1614
	.loc 1 189 5 is_stmt 1 view .LVU3271
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU3272
	s16i	a4, a13, 0	# pc, tmp2450
.LBE1735:
.LBE1750:
	.loc 1 1289 7 is_stmt 1 view .LVU3273
.LBB1751:
.LBI1736:
	.loc 1 475 13 view .LVU3274
.LBB1747:
	.loc 1 476 5 view .LVU3275
.LBB1745:
.LBI1738:
	.loc 1 216 17 view .LVU3276
.LBB1743:
	.loc 1 217 5 view .LVU3277
	beqz.n	a3, .L478	# useaccum,
	.loc 1 217 19 view .LVU3278
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3279
	l32r	a3, .LC190	#, tmp2453
	l8ui	a2, a3, 0	# prephitmp_1097, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3280
	mov.n	a3, a2	# _1619, prephitmp_1097
	j	.L479		#
.L478:
.LBB1740:
.LBI1740:
	.loc 1 216 17 is_stmt 1 view .LVU3281
.LBB1741:
	.loc 1 218 14 view .LVU3282
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3283
	call0	_Z8read6502t		#
.LVL505:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3284
	extui	a3, a2, 0, 16	# _1619, prephitmp_1097
.L479:
.LBE1741:
.LBE1740:
.LBE1743:
.LBE1745:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:476:     value = getvalue();
	.loc 1 476 11 view .LVU3285
	l32r	a4, .LC191	#, tmp2455
	s16i	a3, a4, 0	# value, _1619
	.loc 1 477 5 is_stmt 1 view .LVU3286
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:477:     x = (uint8_t)(value & 0x00FF);
	.loc 1 477 7 is_stmt 0 view .LVU3287
	l32r	a4, .LC189	#, tmp2456
	s8i	a2, a4, 0	# x, prephitmp_1097
	.loc 1 479 5 is_stmt 1 view .LVU3288
	.loc 1 479 5 view .LVU3289
	l16ui	a2, a14, 0	# cpustatus, pretmp_1280
	beqz.n	a3, .L480	# _1619,
	.loc 1 479 5 view .LVU3290
	movi.n	a4, -3	# tmp2458,
	and	a2, a2, a4	# cstore_1001, pretmp_1280, tmp2458
	.loc 1 479 16 view .LVU3291
	.loc 1 480 5 view .LVU3292
	.loc 1 480 5 view .LVU3293
	bbsi	a3, 7, .L481	# _1619,,
	j	.L482		#
.L480:
	.loc 1 479 5 view .LVU3294
	movi.n	a3, 2	# tmp2463,
	or	a2, a2, a3	# cstore_1001, pretmp_1280, tmp2463
	.loc 1 479 16 view .LVU3295
	.loc 1 480 5 view .LVU3296
	.loc 1 480 5 view .LVU3297
	j	.L482		#
.L481:
	.loc 1 480 5 view .LVU3298
	movi	a3, 0x80	# tmp2465,
	or	a2, a2, a3	# tmp2466, cstore_1001, tmp2465
	s16i	a2, a14, 0	# cpustatus, tmp2466
	j	.L170		#
.L482:
	.loc 1 480 5 view .LVU3299
	movi	a3, -0x81	# tmp2468,
	and	a2, a2, a3	# tmp2469, cstore_1001, tmp2468
	s16i	a2, a14, 0	# cpustatus, tmp2469
	j	.L170		#
.L208:
	.loc 1 480 5 is_stmt 0 view .LVU3300
.LBE1747:
.LBE1751:
	.loc 1 1293 5 is_stmt 1 view .LVU3301
	.loc 1 1294 7 view .LVU3302
.LBB1752:
.LBI1752:
	.loc 1 148 13 view .LVU3303
.LBB1753:
	.loc 1 149 5 view .LVU3304
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU3305
	l16ui	a3, a13, 0	# pc, pc$356_313
	addi.n	a4, a3, 1	# tmp2472, pc$356_313,
	s16i	a4, a13, 0	# pc, tmp2472
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3306
	l32r	a4, .LC179	#, tmp2473
.LBE1753:
.LBE1752:
.LBB1755:
.LBB1756:
.LBB1757:
.LBB1758:
.LBB1759:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 view .LVU3307
	mov.n	a2, a3	#, pc$356_313
.LBE1759:
.LBE1758:
.LBE1757:
.LBE1756:
.LBE1755:
.LBB1769:
.LBB1754:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3308
	s16i	a3, a4, 0	# ea, pc$356_313
.LBE1754:
.LBE1769:
	.loc 1 1295 7 is_stmt 1 view .LVU3309
.LBB1770:
.LBI1755:
	.loc 1 389 13 view .LVU3310
.LBB1767:
	.loc 1 390 5 view .LVU3311
.LBB1764:
.LBI1757:
	.loc 1 216 17 view .LVU3312
.LBE1764:
.LBE1767:
.LBE1770:
	.loc 1 217 5 view .LVU3313
.LBB1771:
.LBB1768:
.LBB1765:
.LBB1762:
.LBI1758:
	.loc 1 216 17 view .LVU3314
.LBB1760:
	.loc 1 218 14 view .LVU3315
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3316
	call0	_Z8read6502t		#
.LVL506:
.LBE1760:
.LBE1762:
.LBE1765:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3317
	l32r	a4, .LC188	#, tmp2476
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3318
	l32r	a6, .LC191	#, tmp2475
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3319
	l8ui	a5, a4, 0	# y$299_1628, y
.LBB1766:
.LBB1763:
.LBB1761:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3320
	extui	a3, a2, 0, 16	# _1653, tmp2474
.LBE1761:
.LBE1763:
.LBE1766:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3321
	sub	a4, a5, a3	# tmp2478, y$299_1628, _1653
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3322
	s16i	a3, a6, 0	# value, _1653
	.loc 1 391 5 is_stmt 1 view .LVU3323
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 is_stmt 0 view .LVU3324
	l32r	a3, .LC192	#, tmp2479
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3325
	extui	a4, a4, 0, 16	# _1630, tmp2478
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 view .LVU3326
	s16i	a4, a3, 0	# result, _1630
	.loc 1 393 5 is_stmt 1 view .LVU3327
	bltu	a5, a2, .L483	# y$299_1628, tmp2474,
	.loc 1 393 41 view .LVU3328
	l16ui	a3, a14, 0	# cpustatus, cpustatus$303_1632
	movi.n	a6, 1	# tmp2482,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3329
	movi.n	a7, 3	# tmp2489,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 41 view .LVU3330
	or	a6, a3, a6	# prephitmp_1076, cpustatus$303_1632, tmp2482
	.loc 1 395 5 is_stmt 1 view .LVU3331
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3332
	or	a3, a3, a7	# cstore_270, cpustatus$303_1632, tmp2489
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 5 view .LVU3333
	beq	a5, a2, .L486	# y$299_1628, tmp2474,
	j	.L485		#
.L483:
	.loc 1 394 14 is_stmt 1 view .LVU3334
	l16ui	a6, a14, 0	# cpustatus, tmp2487
	movi.n	a2, -2	# tmp2485,
	and	a6, a6, a2	# prephitmp_1076, tmp2487, tmp2485
	.loc 1 395 5 view .LVU3335
.L485:
	.loc 1 396 14 view .LVU3336
	movi.n	a3, -3	# tmp2490,
	and	a3, a6, a3	# cstore_270, prephitmp_1076, tmp2490
.L486:
	.loc 1 397 5 view .LVU3337
	.loc 1 397 5 view .LVU3338
	movi	a2, 0x80	# tmp2492,
	bnone	a4, a2, .L487	# _1630, tmp2492,
	.loc 1 397 5 view .LVU3339
	or	a3, a3, a2	# tmp2498, cstore_270, tmp2492
	s16i	a3, a14, 0	# cpustatus, tmp2498
	j	.L170		#
.L487:
	.loc 1 397 5 view .LVU3340
	movi	a2, -0x81	# tmp2500,
	and	a3, a3, a2	# tmp2501, cstore_270, tmp2500
	s16i	a3, a14, 0	# cpustatus, tmp2501
	j	.L170		#
.L207:
.LBE1768:
.LBE1771:
	.loc 1 1297 5 view .LVU3341
	.loc 1 1298 7 view .LVU3342
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1298:       indx();
	.loc 1 1298 11 is_stmt 0 view .LVU3343
	call0	_Z4indxv		#
.LVL507:
	.loc 1 1299 7 is_stmt 1 view .LVU3344
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1299:       cmp();
	.loc 1 1299 10 is_stmt 0 view .LVU3345
	call0	_Z3cmpv		#
.LVL508:
	.loc 1 1300 7 is_stmt 1 view .LVU3346
	j	.L170		#
.L206:
	.loc 1 1304 5 view .LVU3347
	.loc 1 1305 7 view .LVU3348
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1305:       zp();
	.loc 1 1305 9 is_stmt 0 view .LVU3349
	call0	_Z2zpv		#
.LVL509:
	.loc 1 1306 7 is_stmt 1 view .LVU3350
.LBB1772:
.LBI1772:
	.loc 1 389 13 view .LVU3351
.LBB1773:
	.loc 1 390 5 view .LVU3352
.LBB1774:
.LBI1774:
	.loc 1 216 17 view .LVU3353
.LBB1775:
	.loc 1 217 5 view .LVU3354
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	beqz.n	a2, .L488	# useaccum,
	.loc 1 217 19 view .LVU3355
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3356
	l32r	a3, .LC190	#, tmp2504
	l8ui	a2, a3, 0	# prephitmp_1056, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3357
	mov.n	a3, a2	# _1675, prephitmp_1056
	j	.L489		#
.L488:
.LBB1776:
.LBI1776:
	.loc 1 216 17 is_stmt 1 view .LVU3358
.LBB1777:
	.loc 1 218 14 view .LVU3359
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3360
	l32r	a2, .LC179	#, tmp2505
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL510:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3361
	extui	a3, a2, 0, 16	# _1675, prephitmp_1056
.L489:
.LBE1777:
.LBE1776:
.LBE1775:
.LBE1774:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3362
	l32r	a4, .LC188	#, tmp2509
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3363
	l32r	a6, .LC191	#, tmp2508
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3364
	l8ui	a5, a4, 0	# y$299_1656, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3365
	s16i	a3, a6, 0	# value, _1675
	.loc 1 391 5 is_stmt 1 view .LVU3366
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 is_stmt 0 view .LVU3367
	sub	a4, a5, a3	# tmp2511, y$299_1656, _1675
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 view .LVU3368
	l32r	a3, .LC192	#, tmp2512
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3369
	extui	a4, a4, 0, 16	# _1658, tmp2511
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 view .LVU3370
	s16i	a4, a3, 0	# result, _1658
	.loc 1 393 5 is_stmt 1 view .LVU3371
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 41 is_stmt 0 view .LVU3372
	l16ui	a3, a14, 0	# cpustatus, pretmp_1308
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 5 view .LVU3373
	bltu	a5, a2, .L490	# y$299_1656, prephitmp_1056,
	.loc 1 393 41 is_stmt 1 view .LVU3374
	movi.n	a6, 1	# tmp2515,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3375
	movi.n	a7, 3	# tmp2520,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 41 view .LVU3376
	or	a6, a3, a6	# prephitmp_1055, pretmp_1308, tmp2515
	.loc 1 395 5 is_stmt 1 view .LVU3377
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3378
	or	a3, a3, a7	# _1667, pretmp_1308, tmp2520
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 5 view .LVU3379
	beq	a2, a5, .L493	# prephitmp_1056, y$299_1656,
	j	.L492		#
.L490:
	.loc 1 394 14 is_stmt 1 view .LVU3380
	movi.n	a6, -2	# tmp2517,
	and	a6, a3, a6	# prephitmp_1055, pretmp_1308, tmp2517
	.loc 1 395 5 view .LVU3381
.L492:
	.loc 1 396 14 view .LVU3382
	movi.n	a3, -3	# tmp2521,
	and	a3, a6, a3	# _1667, prephitmp_1055, tmp2521
.L493:
	.loc 1 397 5 view .LVU3383
	.loc 1 397 5 view .LVU3384
	movi	a2, 0x80	# tmp2523,
	bnone	a4, a2, .L494	# _1658, tmp2523,
	.loc 1 397 5 view .LVU3385
	or	a3, a3, a2	# tmp2529, _1667, tmp2523
	s16i	a3, a14, 0	# cpustatus, tmp2529
	j	.L170		#
.L494:
	.loc 1 397 5 view .LVU3386
	movi	a2, -0x81	# tmp2531,
	and	a3, a3, a2	# tmp2532, _1667, tmp2531
	s16i	a3, a14, 0	# cpustatus, tmp2532
	j	.L170		#
.L205:
.LBE1773:
.LBE1772:
	.loc 1 1308 5 view .LVU3387
	.loc 1 1309 7 view .LVU3388
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1309:       zp();
	.loc 1 1309 9 is_stmt 0 view .LVU3389
	call0	_Z2zpv		#
.LVL511:
	.loc 1 1310 7 is_stmt 1 view .LVU3390
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1310:       cmp();
	.loc 1 1310 10 is_stmt 0 view .LVU3391
	call0	_Z3cmpv		#
.LVL512:
	.loc 1 1311 7 is_stmt 1 view .LVU3392
	j	.L170		#
.L204:
	.loc 1 1312 5 view .LVU3393
	.loc 1 1313 7 view .LVU3394
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1313:       zp();
	.loc 1 1313 9 is_stmt 0 view .LVU3395
	call0	_Z2zpv		#
.LVL513:
	.loc 1 1314 7 is_stmt 1 view .LVU3396
.LBB1778:
.LBI1778:
	.loc 1 400 13 view .LVU3397
.LBB1779:
	.loc 1 401 5 view .LVU3398
.LBB1780:
.LBI1780:
	.loc 1 216 17 view .LVU3399
.LBB1781:
	.loc 1 217 5 view .LVU3400
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU3401
	l32r	a5, .LC172	#,
	l8ui	a4, a5, 0	# prephitmp_1018, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3402
	beqz.n	a4, .L495	# prephitmp_1018,
	.loc 1 217 19 is_stmt 1 view .LVU3403
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3404
	l32r	a2, .LC190	#, tmp2534
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3405
	l8ui	a2, a2, 0	# _1698, a
	j	.L496		#
.L495:
.LBB1782:
.LBI1782:
	.loc 1 216 17 is_stmt 1 view .LVU3406
.LBB1783:
	.loc 1 218 14 view .LVU3407
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3408
	l32r	a2, .LC179	#, tmp2537
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL514:
.LBE1783:
.LBE1782:
.LBE1781:
.LBE1780:
.LBB1787:
.LBB1788:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3409
	l32r	a6, .LC172	#,
.LBE1788:
.LBE1787:
.LBB1799:
.LBB1786:
.LBB1785:
.LBB1784:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3410
	extui	a2, a2, 0, 16	# _1698,
.LBE1784:
.LBE1785:
.LBE1786:
.LBE1799:
.LBB1800:
.LBB1797:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3411
	l8ui	a4, a6, 0	# prephitmp_1018, useaccum
.L496:
.LBE1797:
.LBE1800:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3412
	l32r	a5, .LC191	#, tmp2541
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3413
	addi.n	a3, a2, -1	# tmp2542, _1698,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3414
	s16i	a2, a5, 0	# value, _1698
	.loc 1 402 5 is_stmt 1 view .LVU3415
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 is_stmt 0 view .LVU3416
	l32r	a2, .LC192	#, tmp2543
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3417
	extui	a3, a3, 0, 16	# _1684, tmp2542
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 view .LVU3418
	s16i	a3, a2, 0	# result, _1684
	.loc 1 404 5 is_stmt 1 view .LVU3419
	.loc 1 404 5 view .LVU3420
	extui	a5, a3, 0, 8	# tmp2547, _1684
	l16ui	a2, a14, 0	# cpustatus, pretmp_1326
	beqz.n	a5, .L497	# tmp2547,
	.loc 1 404 5 view .LVU3421
	movi.n	a5, -3	# tmp2548,
	and	a2, a2, a5	# cstore_538, pretmp_1326, tmp2548
	j	.L498		#
.L497:
	.loc 1 404 5 view .LVU3422
	movi.n	a5, 2	# tmp2551,
	or	a2, a2, a5	# cstore_538, pretmp_1326, tmp2551
.L498:
	.loc 1 404 21 view .LVU3423
	.loc 1 405 5 view .LVU3424
	.loc 1 405 5 view .LVU3425
	movi	a5, 0x80	# tmp2552,
	bnone	a3, a5, .L499	# _1684, tmp2552,
	.loc 1 405 5 view .LVU3426
	or	a2, a2, a5	# tmp2557, cstore_538, tmp2552
	extui	a2, a2, 0, 16	# cstore_530, tmp2557
	j	.L500		#
.L499:
	.loc 1 405 5 view .LVU3427
	movi	a5, -0x81	# tmp2558,
	and	a2, a2, a5	# cstore_530, cstore_538, tmp2558
.L500:
	s16i	a2, a14, 0	# cpustatus, cstore_530
	.loc 1 405 21 view .LVU3428
	.loc 1 407 5 view .LVU3429
.LVL515:
.LBB1801:
.LBI1787:
	.loc 1 225 13 view .LVU3430
.LBB1798:
	.loc 1 226 5 view .LVU3431
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3432
	extui	a3, a3, 0, 8	# _1793, _1684
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU3433
	beqz.n	a4, .L501	# prephitmp_1018,
	.loc 1 226 19 is_stmt 1 view .LVU3434
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3435
	l32r	a2, .LC190	#, tmp2561
	s8i	a3, a2, 0	# a, _1793
	j	.L170		#
.L501:
.LVL516:
.LBB1789:
.LBI1789:
	.loc 1 225 13 is_stmt 1 view .LVU3436
.LBB1790:
	.loc 1 227 14 view .LVU3437
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU3438
	l32r	a2, .LC179	#, tmp2562
.LBB1791:
.LBB1792:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3439
	l32r	a5, .LC176	#, tmp2563
.LBE1792:
.LBE1791:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU3440
	l16ui	a2, a2, 0	# ea, ea$53_1711
.LVL517:
.LBB1796:
.LBI1791:
	.loc 1 90 6 is_stmt 1 view .LVU3441
.LBB1795:
	.loc 1 91 3 view .LVU3442
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU3443
	movi	a4, 0x1ff	# tmp2565,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3444
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1711
	.loc 1 92 3 is_stmt 1 view .LVU3445
	bltu	a4, a2, .L502	# tmp2565, ea$53_1711,
	.loc 1 93 5 view .LVU3446
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU3447
	l32r	a4, .LC175	#, tmp2566
	add.n	a2, a4, a2	# tmp2567, tmp2566, ea$53_1711
	s8i	a3, a2, 0	# zero_ram[_1712], _1793
	.loc 1 94 5 is_stmt 1 view .LVU3448
	j	.L170		#
.L502:
.LVL518:
.LBB1793:
.LBI1793:
	.loc 1 90 6 view .LVU3449
.LBB1794:
	.loc 1 96 3 view .LVU3450
	l32r	a4, .LC180	#, tmp2568
	extui	a4, a4, 0, 16	# tmp2569, tmp2568
	bltu	a4, a2, .L503	# tmp2569, ea$53_1711,
	.loc 1 97 5 view .LVU3451
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU3452
	addmi	a2, a2, -0x200	# tmp2570, ea$53_1711,
.LVL519:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU3453
	extui	a2, a2, 0, 16	#, tmp2570
	call0	_Z14drawPixelToRamth		#
.LVL520:
	.loc 1 98 5 is_stmt 1 view .LVU3454
	j	.L170		#
.LVL521:
.L503:
	.loc 1 100 3 view .LVU3455
	l32r	a4, .LC182	#, tmp2572
	extui	a4, a4, 0, 16	# tmp2573, tmp2572
	bltu	a4, a2, .L170	# tmp2573, ea$53_1711,
	.loc 1 101 5 view .LVU3456
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU3457
	l32r	a4, .LC184	#, tmp2574
	add.n	a2, a4, a2	# tmp2575, tmp2574, ea$53_1711
.LVL522:
	.loc 1 101 27 view .LVU3458
	addmi	a2, a2, -0x1200	# tmp2576, tmp2575,
	s8i	a3, a2, 0	# RAM[_1726], _1793
	.loc 1 102 5 is_stmt 1 view .LVU3459
	j	.L170		#
.LVL523:
.L203:
	.loc 1 102 5 is_stmt 0 view .LVU3460
.LBE1794:
.LBE1793:
.LBE1795:
.LBE1796:
.LBE1790:
.LBE1789:
.LBE1798:
.LBE1801:
.LBE1779:
.LBE1778:
	.loc 1 1318 5 is_stmt 1 view .LVU3461
	.loc 1 1319 7 view .LVU3462
	.loc 1 1320 7 view .LVU3463
.LBB1802:
.LBI1802:
	.loc 1 451 13 view .LVU3464
.LBB1803:
	.loc 1 452 5 view .LVU3465
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:452:     y++;
	.loc 1 452 6 is_stmt 0 view .LVU3466
	l32r	a3, .LC188	#, tmp2577
	l8ui	a2, a3, 0	#, y
	addi.n	a2, a2, 1	# tmp2579, y,
	extui	a2, a2, 0, 8	# _1728, tmp2579
	s8i	a2, a3, 0	# y, _1728
	.loc 1 454 5 is_stmt 1 view .LVU3467
	.loc 1 454 5 view .LVU3468
	beqz.n	a2, .L504	# _1728,
	.loc 1 454 5 view .LVU3469
	movi.n	a3, -3	# tmp2581,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:455:     signcalc(y);
	.loc 1 455 5 is_stmt 0 view .LVU3470
	slli	a2, a2, 24	# tmp2584, _1728,
	and	a5, a5, a3	# _2453, cpustatus$6_5, tmp2581
	.loc 1 454 16 is_stmt 1 view .LVU3471
	.loc 1 455 5 view .LVU3472
	.loc 1 455 5 view .LVU3473
	bltz	a2, .L505	# tmp2584,
	j	.L615		#
.L504:
	.loc 1 454 5 view .LVU3474
	movi.n	a2, 0x22	# tmp2586,
	or	a2, a5, a2	# _1732, cpustatus$6_5, tmp2586
	.loc 1 454 16 view .LVU3475
	.loc 1 455 5 view .LVU3476
	.loc 1 455 5 view .LVU3477
	j	.L507		#
.L505:
	.loc 1 455 5 view .LVU3478
	movi	a2, 0xa0	# tmp2588,
	or	a5, a5, a2	# tmp2589, _2453, tmp2588
	s16i	a5, a14, 0	# cpustatus, tmp2589
	j	.L170		#
.L615:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:454:     zerocalc(y);
	.loc 1 454 5 is_stmt 0 view .LVU3479
	movi.n	a2, 0x20	#,
	or	a5, a5, a2	# tmp2591, _2453,
	extui	a2, a5, 0, 16	# _1732, tmp2591
.L507:
	.loc 1 455 5 is_stmt 1 view .LVU3480
	movi	a3, -0x81	# tmp2593,
	and	a2, a2, a3	# tmp2594, _1732, tmp2593
	s16i	a2, a14, 0	# cpustatus, tmp2594
	j	.L170		#
.L202:
.LBE1803:
.LBE1802:
	.loc 1 1322 5 view .LVU3481
	.loc 1 1323 7 view .LVU3482
.LBB1804:
.LBI1804:
	.loc 1 148 13 view .LVU3483
.LBB1805:
	.loc 1 149 5 view .LVU3484
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU3485
	l16ui	a2, a13, 0	# pc, pc$356_315
	addi.n	a3, a2, 1	# tmp2597, pc$356_315,
	s16i	a3, a13, 0	# pc, tmp2597
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3486
	l32r	a3, .LC179	#, tmp2598
	s16i	a2, a3, 0	# ea, pc$356_315
.LBE1805:
.LBE1804:
	.loc 1 1324 7 is_stmt 1 view .LVU3487
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1324:       cmp();
	.loc 1 1324 10 is_stmt 0 view .LVU3488
	call0	_Z3cmpv		#
.LVL524:
	.loc 1 1325 7 is_stmt 1 view .LVU3489
	j	.L170		#
.L201:
	.loc 1 1326 5 view .LVU3490
	.loc 1 1327 7 view .LVU3491
	.loc 1 1328 7 view .LVU3492
.LBB1806:
.LBI1806:
	.loc 1 410 13 view .LVU3493
.LBB1807:
	.loc 1 411 5 view .LVU3494
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:411:     x--;
	.loc 1 411 6 is_stmt 0 view .LVU3495
	l32r	a3, .LC189	#, tmp2599
	l8ui	a2, a3, 0	#, x
	addi.n	a2, a2, -1	# tmp2601, x,
	extui	a2, a2, 0, 8	# _1739, tmp2601
	s8i	a2, a3, 0	# x, _1739
	.loc 1 413 5 is_stmt 1 view .LVU3496
	.loc 1 413 5 view .LVU3497
	beqz.n	a2, .L508	# _1739,
	.loc 1 413 5 view .LVU3498
	movi.n	a3, -3	# tmp2603,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:414:     signcalc(x);
	.loc 1 414 5 is_stmt 0 view .LVU3499
	slli	a2, a2, 24	# tmp2606, _1739,
	and	a5, a5, a3	# _2493, cpustatus$6_5, tmp2603
	.loc 1 413 16 is_stmt 1 view .LVU3500
	.loc 1 414 5 view .LVU3501
	.loc 1 414 5 view .LVU3502
	bltz	a2, .L509	# tmp2606,
	j	.L616		#
.L508:
	.loc 1 413 5 view .LVU3503
	movi.n	a2, 0x22	# tmp2608,
	or	a2, a5, a2	# _1743, cpustatus$6_5, tmp2608
	.loc 1 413 16 view .LVU3504
	.loc 1 414 5 view .LVU3505
	.loc 1 414 5 view .LVU3506
	j	.L511		#
.L509:
	.loc 1 414 5 view .LVU3507
	movi	a2, 0xa0	# tmp2610,
	or	a5, a5, a2	# tmp2611, _2493, tmp2610
	s16i	a5, a14, 0	# cpustatus, tmp2611
	j	.L170		#
.L616:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:413:     zerocalc(x);
	.loc 1 413 5 is_stmt 0 view .LVU3508
	movi.n	a3, 0x20	#,
	or	a5, a5, a3	# tmp2613, _2493,
	extui	a2, a5, 0, 16	# _1743, tmp2613
.L511:
	.loc 1 414 5 is_stmt 1 view .LVU3509
	movi	a3, -0x81	# tmp2615,
	and	a2, a2, a3	# tmp2616, _1743, tmp2615
	s16i	a2, a14, 0	# cpustatus, tmp2616
	j	.L170		#
.L200:
.LBE1807:
.LBE1806:
	.loc 1 1332 5 view .LVU3510
	.loc 1 1333 7 view .LVU3511
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1333:       abso();
	.loc 1 1333 11 is_stmt 0 view .LVU3512
	call0	_Z4absov		#
.LVL525:
	.loc 1 1334 7 is_stmt 1 view .LVU3513
.LBB1808:
.LBI1808:
	.loc 1 389 13 view .LVU3514
.LBB1809:
	.loc 1 390 5 view .LVU3515
.LBB1810:
.LBI1810:
	.loc 1 216 17 view .LVU3516
.LBB1811:
	.loc 1 217 5 view .LVU3517
	l32r	a4, .LC172	#,
	l8ui	a2, a4, 0	# useaccum, useaccum
	beqz.n	a2, .L512	# useaccum,
	.loc 1 217 19 view .LVU3518
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3519
	l32r	a3, .LC190	#, tmp2619
	l8ui	a2, a3, 0	# prephitmp_1014, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3520
	mov.n	a3, a2	# _1769, prephitmp_1014
	j	.L513		#
.L512:
.LBB1812:
.LBI1812:
	.loc 1 216 17 is_stmt 1 view .LVU3521
.LBB1813:
	.loc 1 218 14 view .LVU3522
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3523
	l32r	a2, .LC179	#, tmp2620
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL526:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3524
	extui	a3, a2, 0, 16	# _1769, prephitmp_1014
.L513:
.LBE1813:
.LBE1812:
.LBE1811:
.LBE1810:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3525
	l32r	a4, .LC188	#, tmp2624
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3526
	l32r	a6, .LC191	#, tmp2623
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3527
	l8ui	a5, a4, 0	# y$299_1750, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:390:     value = getvalue();
	.loc 1 390 11 view .LVU3528
	s16i	a3, a6, 0	# value, _1769
	.loc 1 391 5 is_stmt 1 view .LVU3529
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 is_stmt 0 view .LVU3530
	sub	a4, a5, a3	# tmp2626, y$299_1750, _1769
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 view .LVU3531
	l32r	a3, .LC192	#, tmp2627
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 26 view .LVU3532
	extui	a4, a4, 0, 16	# _1752, tmp2626
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:391:     result = (uint16_t)y - value;
	.loc 1 391 12 view .LVU3533
	s16i	a4, a3, 0	# result, _1752
	.loc 1 393 5 is_stmt 1 view .LVU3534
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 41 is_stmt 0 view .LVU3535
	l16ui	a3, a14, 0	# cpustatus, pretmp_1789
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 5 view .LVU3536
	bltu	a5, a2, .L514	# y$299_1750, prephitmp_1014,
	.loc 1 393 41 is_stmt 1 view .LVU3537
	movi.n	a6, 1	# tmp2630,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3538
	movi.n	a7, 3	# tmp2635,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:393:     if (y >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 393 41 view .LVU3539
	or	a6, a3, a6	# prephitmp_1033, pretmp_1789, tmp2630
	.loc 1 395 5 is_stmt 1 view .LVU3540
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 41 is_stmt 0 view .LVU3541
	or	a3, a3, a7	# cstore_968, pretmp_1789, tmp2635
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:395:     if (y == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 395 5 view .LVU3542
	beq	a2, a5, .L517	# prephitmp_1014, y$299_1750,
	j	.L516		#
.L514:
	.loc 1 394 14 is_stmt 1 view .LVU3543
	movi.n	a6, -2	# tmp2632,
	and	a6, a3, a6	# prephitmp_1033, pretmp_1789, tmp2632
	.loc 1 395 5 view .LVU3544
.L516:
	.loc 1 396 14 view .LVU3545
	movi.n	a3, -3	# tmp2636,
	and	a3, a6, a3	# cstore_968, prephitmp_1033, tmp2636
.L517:
	.loc 1 397 5 view .LVU3546
	.loc 1 397 5 view .LVU3547
	movi	a2, 0x80	# tmp2638,
	bnone	a4, a2, .L518	# _1752, tmp2638,
	.loc 1 397 5 view .LVU3548
	or	a3, a3, a2	# tmp2644, cstore_968, tmp2638
	s16i	a3, a14, 0	# cpustatus, tmp2644
	j	.L170		#
.L518:
	.loc 1 397 5 view .LVU3549
	movi	a2, -0x81	# tmp2646,
	and	a3, a3, a2	# tmp2647, cstore_968, tmp2646
	s16i	a3, a14, 0	# cpustatus, tmp2647
	j	.L170		#
.L199:
.LBE1809:
.LBE1808:
	.loc 1 1336 5 view .LVU3550
	.loc 1 1337 7 view .LVU3551
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1337:       abso();
	.loc 1 1337 11 is_stmt 0 view .LVU3552
	call0	_Z4absov		#
.LVL527:
	.loc 1 1338 7 is_stmt 1 view .LVU3553
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1338:       cmp();
	.loc 1 1338 10 is_stmt 0 view .LVU3554
	call0	_Z3cmpv		#
.LVL528:
	.loc 1 1339 7 is_stmt 1 view .LVU3555
	j	.L170		#
.L198:
	.loc 1 1340 5 view .LVU3556
	.loc 1 1341 7 view .LVU3557
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1341:       abso();
	.loc 1 1341 11 is_stmt 0 view .LVU3558
	call0	_Z4absov		#
.LVL529:
	.loc 1 1342 7 is_stmt 1 view .LVU3559
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1342:       dec();
	.loc 1 1342 10 is_stmt 0 view .LVU3560
	call0	_Z3decv		#
.LVL530:
	.loc 1 1343 7 is_stmt 1 view .LVU3561
	j	.L170		#
.L197:
	.loc 1 1346 5 view .LVU3562
	.loc 1 1347 7 view .LVU3563
.LBB1814:
.LBI1814:
	.loc 1 164 13 view .LVU3564
.LBB1815:
	.loc 1 165 5 view .LVU3565
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU3566
	l16ui	a2, a13, 0	# pc, pc$374_1779
.LBB1816:
.LBB1817:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU3567
	movi	a4, 0x1ff	# tmp2652,
.LBE1817:
.LBE1816:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU3568
	addi.n	a5, a2, 1	# tmp2650, pc$374_1779,
	s16i	a5, a13, 0	# pc, tmp2650
.LVL531:
.LBB1822:
.LBI1816:
	.loc 1 69 9 is_stmt 1 view .LVU3569
.LBB1820:
	.loc 1 70 3 view .LVU3570
	bltu	a4, a2, .L519	# tmp2652, pc$374_1779,
	.loc 1 71 5 view .LVU3571
	.loc 1 72 7 view .LVU3572
	.loc 1 75 12 view .LVU3573
	movi	a4, 0xfe	# tmp2654,
	bne	a2, a4, .L520	# pc$374_1779, tmp2654,
	.loc 1 76 9 view .LVU3574
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU3575
	call0	rand		#
.LVL532:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU3576
	extui	a2, a2, 0, 8	# _1790,
	j	.L636		#
.LVL533:
.L520:
	.loc 1 79 5 is_stmt 1 view .LVU3577
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU3578
	l32r	a4, .LC175	#, tmp2656
	add.n	a2, a4, a2	# tmp2657, tmp2656, pc$374_1779
.LVL534:
	.loc 1 79 28 view .LVU3579
	j	.L637		#
.LVL535:
.L519:
	.loc 1 81 3 is_stmt 1 view .LVU3580
	l32r	a4, .LC180	#, tmp2658
	extui	a4, a4, 0, 16	# tmp2659, tmp2658
	bltu	a4, a2, .L522	# tmp2659, pc$374_1779,
.LVL536:
.LBB1818:
.LBI1818:
	.loc 1 69 9 view .LVU3581
.LBB1819:
	.loc 1 82 5 view .LVU3582
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU3583
	addmi	a2, a2, -0x200	# tmp2660, pc$374_1779,
.LVL537:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU3584
	extui	a2, a2, 0, 16	#, tmp2660
.LVL538:
	.loc 1 82 28 view .LVU3585
	call0	_Z16loadPixelFromRamt		#
.LVL539:
.L636:
	.loc 1 82 28 view .LVU3586
.LBE1819:
.LBE1818:
.LBE1820:
.LBE1822:
.LBE1815:
.LBE1814:
.LBB1827:
.LBB1828:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:308:     if ((cpustatus & FLAG_ZERO) == 0) {
	.loc 1 308 20 view .LVU3587
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L521		#
.LVL540:
.L522:
	.loc 1 308 20 view .LVU3588
.LBE1828:
.LBE1827:
.LBB1833:
.LBB1824:
.LBB1823:
.LBB1821:
	.loc 1 84 3 is_stmt 1 view .LVU3589
	l32r	a4, .LC182	#, tmp2664
	extui	a4, a4, 0, 16	# tmp2665, tmp2664
	bltu	a4, a2, .L523	# tmp2665, pc$374_1779,
	.loc 1 85 5 view .LVU3590
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU3591
	l32r	a4, .LC184	#, tmp2666
	add.n	a2, a4, a2	# tmp2667, tmp2666, pc$374_1779
.LVL541:
	.loc 1 85 32 view .LVU3592
	addmi	a2, a2, -0x1200	# tmp2668, tmp2667,
.L637:
	.loc 1 85 32 view .LVU3593
	l8ui	a2, a2, 0	# _1790,
.LVL542:
.L521:
	.loc 1 85 32 view .LVU3594
.LBE1821:
.LBE1823:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU3595
	extui	a4, a2, 0, 16	# _1783, _1790
	.loc 1 166 5 is_stmt 1 view .LVU3596
	bbsi	a2, 7, .L524	# _1790,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU3597
	l32r	a2, .LC185	#, tmp3112
	j	.L638		#
.L524:
	.loc 1 166 25 is_stmt 1 view .LVU3598
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU3599
	movi	a5, -0x100	# tmp2673,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp2674, _1783, tmp2673
.L638:
.LBE1824:
.LBE1833:
	.loc 1 1348 7 is_stmt 1 view .LVU3600
.LBB1834:
.LBI1827:
	.loc 1 307 13 view .LVU3601
.LBB1831:
	.loc 1 308 5 view .LVU3602
.LBE1831:
.LBE1834:
.LBB1835:
.LBB1825:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU3603
	s16i	a4, a2, 0	# reladdr, tmp2674
.LBE1825:
.LBE1835:
.LBB1836:
.LBB1832:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:308:     if ((cpustatus & FLAG_ZERO) == 0) {
	.loc 1 308 5 view .LVU3604
	bbsi	a3, 1, .L170	# prephitmp_1199,,
.LBB1829:
.LBI1829:
	.loc 1 263 13 is_stmt 1 view .LVU3605
.LBB1830:
	.loc 1 265 9 view .LVU3606
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU3607
	l16ui	a5, a13, 0	# pc, pc$202_1802
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3608
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3609
	l32r	a6, .LC187	#, tmp2685
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3610
	add.n	a3, a5, a3	# tmp2683, pc$202_1802, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3611
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1302
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3612
	extui	a3, a3, 0, 16	# _1804, tmp2683
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU3613
	movi	a7, -0x100	# tmp2687,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU3614
	xor	a4, a5, a3	# tmp2686, pc$202_1802, _1804
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU3615
	and	a4, a4, a7	# tmp2691, tmp2686, tmp2687
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU3616
	addi.n	a7, a2, 1	# tmp2695, pretmp_1302,
	addi.n	a2, a2, 2	# tmp2693, pretmp_1302,
	moveqz	a2, a7, a4	# tmp3132, tmp2695, tmp2691
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU3617
	l32r	a4, .LC186	#, tmp2680
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU3618
	s16i	a3, a13, 0	# pc, _1804
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU3619
	s16i	a5, a4, 0	# oldpc, pc$202_1802
	.loc 1 266 9 is_stmt 1 view .LVU3620
	.loc 1 267 9 view .LVU3621
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU3622
	s32i.n	a2, a6, 0	# clockticks6502, tmp3132
	j	.L170		#
.L196:
.LBE1830:
.LBE1829:
.LBE1832:
.LBE1836:
	.loc 1 1350 5 is_stmt 1 view .LVU3623
	.loc 1 1351 7 view .LVU3624
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1351:       indy();
	.loc 1 1351 11 is_stmt 0 view .LVU3625
	call0	_Z4indyv		#
.LVL543:
	.loc 1 1352 7 is_stmt 1 view .LVU3626
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1352:       cmp();
	.loc 1 1352 10 is_stmt 0 view .LVU3627
	call0	_Z3cmpv		#
.LVL544:
	.loc 1 1353 7 is_stmt 1 view .LVU3628
	j	.L170		#
.L195:
	.loc 1 1358 5 view .LVU3629
	.loc 1 1359 7 view .LVU3630
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1359:       zpx();
	.loc 1 1359 10 is_stmt 0 view .LVU3631
	call0	_Z3zpxv		#
.LVL545:
	.loc 1 1360 7 is_stmt 1 view .LVU3632
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1360:       cmp();
	.loc 1 1360 10 is_stmt 0 view .LVU3633
	call0	_Z3cmpv		#
.LVL546:
	.loc 1 1361 7 is_stmt 1 view .LVU3634
	j	.L170		#
.L194:
	.loc 1 1362 5 view .LVU3635
	.loc 1 1363 7 view .LVU3636
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1363:       zpx();
	.loc 1 1363 10 is_stmt 0 view .LVU3637
	call0	_Z3zpxv		#
.LVL547:
	.loc 1 1364 7 is_stmt 1 view .LVU3638
.LBB1837:
.LBI1837:
	.loc 1 400 13 view .LVU3639
.LBB1838:
	.loc 1 401 5 view .LVU3640
.LBB1839:
.LBI1839:
	.loc 1 216 17 view .LVU3641
.LBB1840:
	.loc 1 217 5 view .LVU3642
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU3643
	l32r	a5, .LC172	#,
	l8ui	a4, a5, 0	# prephitmp_1085, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3644
	beqz.n	a4, .L527	# prephitmp_1085,
	.loc 1 217 19 is_stmt 1 view .LVU3645
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3646
	l32r	a2, .LC190	#, tmp2697
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3647
	l8ui	a2, a2, 0	# _1826, a
	j	.L528		#
.L527:
.LBB1841:
.LBI1841:
	.loc 1 216 17 is_stmt 1 view .LVU3648
.LBB1842:
	.loc 1 218 14 view .LVU3649
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3650
	l32r	a2, .LC179	#, tmp2700
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL548:
.LBE1842:
.LBE1841:
.LBE1840:
.LBE1839:
.LBB1846:
.LBB1847:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3651
	l32r	a6, .LC172	#,
.LBE1847:
.LBE1846:
.LBB1858:
.LBB1845:
.LBB1844:
.LBB1843:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3652
	extui	a2, a2, 0, 16	# _1826,
.LBE1843:
.LBE1844:
.LBE1845:
.LBE1858:
.LBB1859:
.LBB1856:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3653
	l8ui	a4, a6, 0	# prephitmp_1085, useaccum
.L528:
.LBE1856:
.LBE1859:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3654
	l32r	a5, .LC191	#, tmp2704
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3655
	addi.n	a3, a2, -1	# tmp2705, _1826,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3656
	s16i	a2, a5, 0	# value, _1826
	.loc 1 402 5 is_stmt 1 view .LVU3657
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 is_stmt 0 view .LVU3658
	l32r	a2, .LC192	#, tmp2706
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3659
	extui	a3, a3, 0, 16	# _1812, tmp2705
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 view .LVU3660
	s16i	a3, a2, 0	# result, _1812
	.loc 1 404 5 is_stmt 1 view .LVU3661
	.loc 1 404 5 view .LVU3662
	extui	a5, a3, 0, 8	# tmp2710, _1812
	l16ui	a2, a14, 0	# cpustatus, pretmp_1300
	beqz.n	a5, .L529	# tmp2710,
	.loc 1 404 5 view .LVU3663
	movi.n	a5, -3	# tmp2711,
	and	a2, a2, a5	# cstore_989, pretmp_1300, tmp2711
	j	.L530		#
.L529:
	.loc 1 404 5 view .LVU3664
	movi.n	a5, 2	# tmp2714,
	or	a2, a2, a5	# cstore_989, pretmp_1300, tmp2714
.L530:
	.loc 1 404 21 view .LVU3665
	.loc 1 405 5 view .LVU3666
	.loc 1 405 5 view .LVU3667
	movi	a5, 0x80	# tmp2715,
	bnone	a3, a5, .L531	# _1812, tmp2715,
	.loc 1 405 5 view .LVU3668
	or	a2, a2, a5	# tmp2720, cstore_989, tmp2715
	extui	a2, a2, 0, 16	# cstore_1010, tmp2720
	j	.L532		#
.L531:
	.loc 1 405 5 view .LVU3669
	movi	a5, -0x81	# tmp2721,
	and	a2, a2, a5	# cstore_1010, cstore_989, tmp2721
.L532:
	s16i	a2, a14, 0	# cpustatus, cstore_1010
	.loc 1 405 21 view .LVU3670
	.loc 1 407 5 view .LVU3671
.LVL549:
.LBB1860:
.LBI1846:
	.loc 1 225 13 view .LVU3672
.LBB1857:
	.loc 1 226 5 view .LVU3673
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3674
	extui	a3, a3, 0, 8	# _2481, _1812
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU3675
	beqz.n	a4, .L533	# prephitmp_1085,
	.loc 1 226 19 is_stmt 1 view .LVU3676
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3677
	l32r	a2, .LC190	#, tmp2724
	s8i	a3, a2, 0	# a, _2481
	j	.L170		#
.L533:
.LVL550:
.LBB1848:
.LBI1848:
	.loc 1 225 13 is_stmt 1 view .LVU3678
.LBB1849:
	.loc 1 227 14 view .LVU3679
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU3680
	l32r	a2, .LC179	#, tmp2725
.LBB1850:
.LBB1851:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3681
	l32r	a5, .LC176	#, tmp2726
.LBE1851:
.LBE1850:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU3682
	l16ui	a2, a2, 0	# ea, ea$53_1839
.LVL551:
.LBB1855:
.LBI1850:
	.loc 1 90 6 is_stmt 1 view .LVU3683
.LBB1854:
	.loc 1 91 3 view .LVU3684
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU3685
	movi	a4, 0x1ff	# tmp2728,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3686
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1839
	.loc 1 92 3 is_stmt 1 view .LVU3687
	bltu	a4, a2, .L534	# tmp2728, ea$53_1839,
	.loc 1 93 5 view .LVU3688
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU3689
	l32r	a4, .LC175	#, tmp2729
	add.n	a2, a4, a2	# tmp2730, tmp2729, ea$53_1839
	s8i	a3, a2, 0	# zero_ram[_1840], _2481
	.loc 1 94 5 is_stmt 1 view .LVU3690
	j	.L170		#
.L534:
.LVL552:
.LBB1852:
.LBI1852:
	.loc 1 90 6 view .LVU3691
.LBB1853:
	.loc 1 96 3 view .LVU3692
	l32r	a4, .LC180	#, tmp2731
	extui	a4, a4, 0, 16	# tmp2732, tmp2731
	bltu	a4, a2, .L535	# tmp2732, ea$53_1839,
	.loc 1 97 5 view .LVU3693
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU3694
	addmi	a2, a2, -0x200	# tmp2733, ea$53_1839,
.LVL553:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU3695
	extui	a2, a2, 0, 16	#, tmp2733
	call0	_Z14drawPixelToRamth		#
.LVL554:
	.loc 1 98 5 is_stmt 1 view .LVU3696
	j	.L170		#
.LVL555:
.L535:
	.loc 1 100 3 view .LVU3697
	l32r	a4, .LC182	#, tmp2735
	extui	a4, a4, 0, 16	# tmp2736, tmp2735
	bltu	a4, a2, .L170	# tmp2736, ea$53_1839,
	.loc 1 101 5 view .LVU3698
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU3699
	l32r	a4, .LC184	#, tmp2737
	add.n	a2, a4, a2	# tmp2738, tmp2737, ea$53_1839
.LVL556:
	.loc 1 101 27 view .LVU3700
	addmi	a2, a2, -0x1200	# tmp2739, tmp2738,
	s8i	a3, a2, 0	# RAM[_1854], _2481
	.loc 1 102 5 is_stmt 1 view .LVU3701
	j	.L170		#
.LVL557:
.L193:
	.loc 1 102 5 is_stmt 0 view .LVU3702
.LBE1853:
.LBE1852:
.LBE1854:
.LBE1855:
.LBE1849:
.LBE1848:
.LBE1857:
.LBE1860:
.LBE1838:
.LBE1837:
	.loc 1 1368 5 is_stmt 1 view .LVU3703
	.loc 1 1369 7 view .LVU3704
	.loc 1 1370 7 view .LVU3705
.LBB1861:
.LBI1861:
	.loc 1 355 13 view .LVU3706
.LBB1862:
	.loc 1 356 5 view .LVU3707
	movi.n	a2, -9	# tmp2741,
	and	a2, a5, a2	# tmp2742, cpustatus$6_5, tmp2741
	movi.n	a3, 0x20	#,
	or	a2, a2, a3	# tmp2745, tmp2742,
	s16i	a2, a14, 0	# cpustatus, tmp2745
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:357: }
	.loc 1 357 1 is_stmt 0 view .LVU3708
	j	.L170		#
.L192:
.LBE1862:
.LBE1861:
	.loc 1 1372 5 is_stmt 1 view .LVU3709
	.loc 1 1373 7 view .LVU3710
.LBB1863:
.LBI1863:
	.loc 1 183 13 view .LVU3711
.LBB1864:
	.loc 1 184 5 view .LVU3712
	.loc 1 185 5 view .LVU3713
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU3714
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL558:
	mov.n	a5, a2	# tmp2748,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3715
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3716
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU3717
	addi.n	a2, a2, 1	# tmp2751, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU3718
	extui	a2, a2, 0, 16	#, tmp2751
	call0	_Z8read6502t		#
.LVL559:
	.loc 1 186 5 is_stmt 1 view .LVU3719
	.loc 1 187 5 view .LVU3720
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU3721
	l32r	a4, .LC188	#, tmp2759
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3722
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3723
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU3724
	slli	a2, a2, 8	# tmp2755,,
.LVL560:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3725
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU3726
	or	a2, a2, a5	# tmp2758, tmp2755, tmp2748
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3727
	add.n	a4, a4, a2	# tmp2763, y, tmp2758
	l32r	a2, .LC179	#, tmp2754
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU3728
	addi.n	a3, a3, 2	# tmp2767, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU3729
	s16i	a4, a2, 0	# ea, tmp2763
	.loc 1 189 5 is_stmt 1 view .LVU3730
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU3731
	s16i	a3, a13, 0	# pc, tmp2767
.LBE1864:
.LBE1863:
	.loc 1 1374 7 is_stmt 1 view .LVU3732
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1374:       cmp();
	.loc 1 1374 10 is_stmt 0 view .LVU3733
	call0	_Z3cmpv		#
.LVL561:
	.loc 1 1375 7 is_stmt 1 view .LVU3734
	j	.L170		#
.L191:
	.loc 1 1380 5 view .LVU3735
	.loc 1 1381 7 view .LVU3736
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1381:       absx();
	.loc 1 1381 11 is_stmt 0 view .LVU3737
	call0	_Z4absxv		#
.LVL562:
	.loc 1 1382 7 is_stmt 1 view .LVU3738
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1382:       cmp();
	.loc 1 1382 10 is_stmt 0 view .LVU3739
	call0	_Z3cmpv		#
.LVL563:
	.loc 1 1383 7 is_stmt 1 view .LVU3740
	j	.L170		#
.L190:
	.loc 1 1384 5 view .LVU3741
	.loc 1 1385 7 view .LVU3742
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1385:       absx();
	.loc 1 1385 11 is_stmt 0 view .LVU3743
	call0	_Z4absxv		#
.LVL564:
	.loc 1 1386 7 is_stmt 1 view .LVU3744
.LBB1865:
.LBI1865:
	.loc 1 400 13 view .LVU3745
.LBB1866:
	.loc 1 401 5 view .LVU3746
.LBB1867:
.LBI1867:
	.loc 1 216 17 view .LVU3747
.LBB1868:
	.loc 1 217 5 view .LVU3748
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU3749
	l32r	a5, .LC172	#,
	l8ui	a4, a5, 0	# prephitmp_1077, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3750
	beqz.n	a4, .L536	# prephitmp_1077,
	.loc 1 217 19 is_stmt 1 view .LVU3751
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3752
	l32r	a2, .LC190	#, tmp2769
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3753
	l8ui	a2, a2, 0	# _1888, a
	j	.L537		#
.L536:
.LBB1869:
.LBI1869:
	.loc 1 216 17 is_stmt 1 view .LVU3754
.LBB1870:
	.loc 1 218 14 view .LVU3755
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3756
	l32r	a2, .LC179	#, tmp2772
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL565:
.LBE1870:
.LBE1869:
.LBE1868:
.LBE1867:
.LBB1874:
.LBB1875:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3757
	l32r	a6, .LC172	#,
.LBE1875:
.LBE1874:
.LBB1886:
.LBB1873:
.LBB1872:
.LBB1871:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3758
	extui	a2, a2, 0, 16	# _1888,
.LBE1871:
.LBE1872:
.LBE1873:
.LBE1886:
.LBB1887:
.LBB1884:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3759
	l8ui	a4, a6, 0	# prephitmp_1077, useaccum
.L537:
.LBE1884:
.LBE1887:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3760
	l32r	a5, .LC191	#, tmp2776
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3761
	addi.n	a3, a2, -1	# tmp2777, _1888,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:401:     value = getvalue();
	.loc 1 401 11 view .LVU3762
	s16i	a2, a5, 0	# value, _1888
	.loc 1 402 5 is_stmt 1 view .LVU3763
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 is_stmt 0 view .LVU3764
	l32r	a2, .LC192	#, tmp2778
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 20 view .LVU3765
	extui	a3, a3, 0, 16	# _1874, tmp2777
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:402:     result = value - 1;
	.loc 1 402 12 view .LVU3766
	s16i	a3, a2, 0	# result, _1874
	.loc 1 404 5 is_stmt 1 view .LVU3767
	.loc 1 404 5 view .LVU3768
	extui	a5, a3, 0, 8	# tmp2782, _1874
	l16ui	a2, a14, 0	# cpustatus, pretmp_1253
	beqz.n	a5, .L538	# tmp2782,
	.loc 1 404 5 view .LVU3769
	movi.n	a5, -3	# tmp2783,
	and	a2, a2, a5	# cstore_1052, pretmp_1253, tmp2783
	j	.L539		#
.L538:
	.loc 1 404 5 view .LVU3770
	movi.n	a5, 2	# tmp2786,
	or	a2, a2, a5	# cstore_1052, pretmp_1253, tmp2786
.L539:
	.loc 1 404 21 view .LVU3771
	.loc 1 405 5 view .LVU3772
	.loc 1 405 5 view .LVU3773
	movi	a5, 0x80	# tmp2787,
	bnone	a3, a5, .L540	# _1874, tmp2787,
	.loc 1 405 5 view .LVU3774
	or	a2, a2, a5	# tmp2792, cstore_1052, tmp2787
	extui	a2, a2, 0, 16	# cstore_1073, tmp2792
	j	.L541		#
.L540:
	.loc 1 405 5 view .LVU3775
	movi	a5, -0x81	# tmp2793,
	and	a2, a2, a5	# cstore_1073, cstore_1052, tmp2793
.L541:
	s16i	a2, a14, 0	# cpustatus, cstore_1073
	.loc 1 405 21 view .LVU3776
	.loc 1 407 5 view .LVU3777
.LVL566:
.LBB1888:
.LBI1874:
	.loc 1 225 13 view .LVU3778
.LBB1885:
	.loc 1 226 5 view .LVU3779
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3780
	extui	a3, a3, 0, 8	# _1272, _1874
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU3781
	beqz.n	a4, .L542	# prephitmp_1077,
	.loc 1 226 19 is_stmt 1 view .LVU3782
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU3783
	l32r	a2, .LC190	#, tmp2796
	s8i	a3, a2, 0	# a, _1272
	j	.L170		#
.L542:
.LVL567:
.LBB1876:
.LBI1876:
	.loc 1 225 13 is_stmt 1 view .LVU3784
.LBB1877:
	.loc 1 227 14 view .LVU3785
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU3786
	l32r	a2, .LC179	#, tmp2797
.LBB1878:
.LBB1879:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3787
	l32r	a5, .LC176	#, tmp2798
.LBE1879:
.LBE1878:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU3788
	l16ui	a2, a2, 0	# ea, ea$53_1901
.LVL568:
.LBB1883:
.LBI1878:
	.loc 1 90 6 is_stmt 1 view .LVU3789
.LBB1882:
	.loc 1 91 3 view .LVU3790
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU3791
	movi	a4, 0x1ff	# tmp2800,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU3792
	s16i	a2, a5, 0	# last_modified_ram, ea$53_1901
	.loc 1 92 3 is_stmt 1 view .LVU3793
	bltu	a4, a2, .L543	# tmp2800, ea$53_1901,
	.loc 1 93 5 view .LVU3794
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU3795
	l32r	a4, .LC175	#, tmp2801
	add.n	a2, a4, a2	# tmp2802, tmp2801, ea$53_1901
	s8i	a3, a2, 0	# zero_ram[_1902], _1272
	.loc 1 94 5 is_stmt 1 view .LVU3796
	j	.L170		#
.L543:
.LVL569:
.LBB1880:
.LBI1880:
	.loc 1 90 6 view .LVU3797
.LBB1881:
	.loc 1 96 3 view .LVU3798
	l32r	a4, .LC180	#, tmp2803
	extui	a4, a4, 0, 16	# tmp2804, tmp2803
	bltu	a4, a2, .L544	# tmp2804, ea$53_1901,
	.loc 1 97 5 view .LVU3799
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU3800
	addmi	a2, a2, -0x200	# tmp2805, ea$53_1901,
.LVL570:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU3801
	extui	a2, a2, 0, 16	#, tmp2805
	call0	_Z14drawPixelToRamth		#
.LVL571:
	.loc 1 98 5 is_stmt 1 view .LVU3802
	j	.L170		#
.LVL572:
.L544:
	.loc 1 100 3 view .LVU3803
	l32r	a4, .LC182	#, tmp2807
	extui	a4, a4, 0, 16	# tmp2808, tmp2807
	bltu	a4, a2, .L170	# tmp2808, ea$53_1901,
	.loc 1 101 5 view .LVU3804
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU3805
	l32r	a4, .LC184	#, tmp2809
	add.n	a2, a4, a2	# tmp2810, tmp2809, ea$53_1901
.LVL573:
	.loc 1 101 27 view .LVU3806
	addmi	a2, a2, -0x1200	# tmp2811, tmp2810,
	s8i	a3, a2, 0	# RAM[_1916], _1272
	.loc 1 102 5 is_stmt 1 view .LVU3807
	j	.L170		#
.LVL574:
.L189:
	.loc 1 102 5 is_stmt 0 view .LVU3808
.LBE1881:
.LBE1880:
.LBE1882:
.LBE1883:
.LBE1877:
.LBE1876:
.LBE1885:
.LBE1888:
.LBE1866:
.LBE1865:
	.loc 1 1390 5 is_stmt 1 view .LVU3809
	.loc 1 1391 7 view .LVU3810
.LBB1889:
.LBI1889:
	.loc 1 148 13 view .LVU3811
.LBB1890:
	.loc 1 149 5 view .LVU3812
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU3813
	l16ui	a3, a13, 0	# pc, pc$356_318
	addi.n	a4, a3, 1	# tmp2814, pc$356_318,
	s16i	a4, a13, 0	# pc, tmp2814
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3814
	l32r	a4, .LC179	#, tmp2815
.LBE1890:
.LBE1889:
.LBB1892:
.LBB1893:
.LBB1894:
.LBB1895:
.LBB1896:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 view .LVU3815
	mov.n	a2, a3	#, pc$356_318
.LBE1896:
.LBE1895:
.LBE1894:
.LBE1893:
.LBE1892:
.LBB1906:
.LBB1891:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3816
	s16i	a3, a4, 0	# ea, pc$356_318
.LBE1891:
.LBE1906:
	.loc 1 1392 7 is_stmt 1 view .LVU3817
.LBB1907:
.LBI1892:
	.loc 1 378 13 view .LVU3818
.LBB1904:
	.loc 1 379 5 view .LVU3819
.LBB1901:
.LBI1894:
	.loc 1 216 17 view .LVU3820
.LBE1901:
.LBE1904:
.LBE1907:
	.loc 1 217 5 view .LVU3821
.LBB1908:
.LBB1905:
.LBB1902:
.LBB1899:
.LBI1895:
	.loc 1 216 17 view .LVU3822
.LBB1897:
	.loc 1 218 14 view .LVU3823
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3824
	call0	_Z8read6502t		#
.LVL575:
.LBE1897:
.LBE1899:
.LBE1902:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3825
	l32r	a4, .LC189	#, tmp2818
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3826
	l32r	a6, .LC191	#, tmp2817
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3827
	l8ui	a5, a4, 0	# x$358_1918, x
.LBB1903:
.LBB1900:
.LBB1898:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3828
	extui	a3, a2, 0, 16	# _1943, tmp2816
.LBE1898:
.LBE1900:
.LBE1903:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3829
	sub	a4, a5, a3	# tmp2820, x$358_1918, _1943
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3830
	s16i	a3, a6, 0	# value, _1943
	.loc 1 380 5 is_stmt 1 view .LVU3831
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 is_stmt 0 view .LVU3832
	l32r	a3, .LC192	#, tmp2821
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3833
	extui	a4, a4, 0, 16	# _1920, tmp2820
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 view .LVU3834
	s16i	a4, a3, 0	# result, _1920
	.loc 1 382 5 is_stmt 1 view .LVU3835
	bltu	a5, a2, .L545	# x$358_1918, tmp2816,
	.loc 1 382 41 view .LVU3836
	l16ui	a3, a14, 0	# cpustatus, cpustatus$362_1922
	movi.n	a6, 1	# tmp2824,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3837
	movi.n	a7, 3	# tmp2831,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 41 view .LVU3838
	or	a6, a3, a6	# prephitmp_1102, cpustatus$362_1922, tmp2824
	.loc 1 384 5 is_stmt 1 view .LVU3839
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3840
	or	a3, a3, a7	# cstore_1094, cpustatus$362_1922, tmp2831
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 5 view .LVU3841
	beq	a5, a2, .L548	# x$358_1918, tmp2816,
	j	.L547		#
.L545:
	.loc 1 383 14 is_stmt 1 view .LVU3842
	l16ui	a6, a14, 0	# cpustatus, tmp2829
	movi.n	a2, -2	# tmp2827,
	and	a6, a6, a2	# prephitmp_1102, tmp2829, tmp2827
	.loc 1 384 5 view .LVU3843
.L547:
	.loc 1 385 14 view .LVU3844
	movi.n	a3, -3	# tmp2832,
	and	a3, a6, a3	# cstore_1094, prephitmp_1102, tmp2832
.L548:
	.loc 1 386 5 view .LVU3845
	.loc 1 386 5 view .LVU3846
	movi	a2, 0x80	# tmp2834,
	bnone	a4, a2, .L549	# _1920, tmp2834,
	.loc 1 386 5 view .LVU3847
	or	a3, a3, a2	# tmp2840, cstore_1094, tmp2834
	s16i	a3, a14, 0	# cpustatus, tmp2840
	j	.L170		#
.L549:
	.loc 1 386 5 view .LVU3848
	movi	a2, -0x81	# tmp2842,
	and	a3, a3, a2	# tmp2843, cstore_1094, tmp2842
	s16i	a3, a14, 0	# cpustatus, tmp2843
	j	.L170		#
.L188:
.LBE1905:
.LBE1908:
	.loc 1 1394 5 view .LVU3849
	.loc 1 1395 7 view .LVU3850
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1395:       indx();
	.loc 1 1395 11 is_stmt 0 view .LVU3851
	call0	_Z4indxv		#
.LVL576:
	.loc 1 1396 7 is_stmt 1 view .LVU3852
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1396:       sbc();
	.loc 1 1396 10 is_stmt 0 view .LVU3853
	call0	_Z3sbcv		#
.LVL577:
	.loc 1 1397 7 is_stmt 1 view .LVU3854
	j	.L170		#
.L187:
	.loc 1 1401 5 view .LVU3855
	.loc 1 1402 7 view .LVU3856
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1402:       zp();
	.loc 1 1402 9 is_stmt 0 view .LVU3857
	call0	_Z2zpv		#
.LVL578:
	.loc 1 1403 7 is_stmt 1 view .LVU3858
.LBB1909:
.LBI1909:
	.loc 1 378 13 view .LVU3859
.LBB1910:
	.loc 1 379 5 view .LVU3860
.LBB1911:
.LBI1911:
	.loc 1 216 17 view .LVU3861
.LBB1912:
	.loc 1 217 5 view .LVU3862
	l32r	a3, .LC172	#,
	l8ui	a2, a3, 0	# useaccum, useaccum
	beqz.n	a2, .L550	# useaccum,
	.loc 1 217 19 view .LVU3863
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3864
	l32r	a3, .LC190	#, tmp2846
	l8ui	a2, a3, 0	# prephitmp_1106, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3865
	mov.n	a3, a2	# _1965, prephitmp_1106
	j	.L551		#
.L550:
.LBB1913:
.LBI1913:
	.loc 1 216 17 is_stmt 1 view .LVU3866
.LBB1914:
	.loc 1 218 14 view .LVU3867
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3868
	l32r	a2, .LC179	#, tmp2847
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL579:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3869
	extui	a3, a2, 0, 16	# _1965, prephitmp_1106
.L551:
.LBE1914:
.LBE1913:
.LBE1912:
.LBE1911:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3870
	l32r	a4, .LC189	#, tmp2851
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3871
	l32r	a6, .LC191	#, tmp2850
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3872
	l8ui	a5, a4, 0	# x$358_1946, x
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3873
	s16i	a3, a6, 0	# value, _1965
	.loc 1 380 5 is_stmt 1 view .LVU3874
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 is_stmt 0 view .LVU3875
	sub	a4, a5, a3	# tmp2853, x$358_1946, _1965
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 view .LVU3876
	l32r	a3, .LC192	#, tmp2854
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3877
	extui	a4, a4, 0, 16	# _1948, tmp2853
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 view .LVU3878
	s16i	a4, a3, 0	# result, _1948
	.loc 1 382 5 is_stmt 1 view .LVU3879
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 41 is_stmt 0 view .LVU3880
	l16ui	a3, a14, 0	# cpustatus, pretmp_1273
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 5 view .LVU3881
	bltu	a5, a2, .L552	# x$358_1946, prephitmp_1106,
	.loc 1 382 41 is_stmt 1 view .LVU3882
	movi.n	a6, 1	# tmp2857,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3883
	movi.n	a7, 3	# tmp2862,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 41 view .LVU3884
	or	a6, a3, a6	# prephitmp_1098, pretmp_1273, tmp2857
	.loc 1 384 5 is_stmt 1 view .LVU3885
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3886
	or	a3, a3, a7	# cstore_1149, pretmp_1273, tmp2862
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 5 view .LVU3887
	beq	a2, a5, .L555	# prephitmp_1106, x$358_1946,
	j	.L554		#
.L552:
	.loc 1 383 14 is_stmt 1 view .LVU3888
	movi.n	a6, -2	# tmp2859,
	and	a6, a3, a6	# prephitmp_1098, pretmp_1273, tmp2859
	.loc 1 384 5 view .LVU3889
.L554:
	.loc 1 385 14 view .LVU3890
	movi.n	a3, -3	# tmp2863,
	and	a3, a6, a3	# cstore_1149, prephitmp_1098, tmp2863
.L555:
	.loc 1 386 5 view .LVU3891
	.loc 1 386 5 view .LVU3892
	movi	a2, 0x80	# tmp2865,
	bnone	a4, a2, .L556	# _1948, tmp2865,
	.loc 1 386 5 view .LVU3893
	or	a3, a3, a2	# tmp2871, cstore_1149, tmp2865
	s16i	a3, a14, 0	# cpustatus, tmp2871
	j	.L170		#
.L556:
	.loc 1 386 5 view .LVU3894
	movi	a2, -0x81	# tmp2873,
	and	a3, a3, a2	# tmp2874, cstore_1149, tmp2873
	s16i	a3, a14, 0	# cpustatus, tmp2874
	j	.L170		#
.L186:
.LBE1910:
.LBE1909:
	.loc 1 1405 5 view .LVU3895
	.loc 1 1406 7 view .LVU3896
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1406:       zp();
	.loc 1 1406 9 is_stmt 0 view .LVU3897
	call0	_Z2zpv		#
.LVL580:
	.loc 1 1407 7 is_stmt 1 view .LVU3898
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1407:       sbc();
	.loc 1 1407 10 is_stmt 0 view .LVU3899
	call0	_Z3sbcv		#
.LVL581:
	.loc 1 1408 7 is_stmt 1 view .LVU3900
	j	.L170		#
.L185:
	.loc 1 1409 5 view .LVU3901
	.loc 1 1410 7 view .LVU3902
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1410:       zp();
	.loc 1 1410 9 is_stmt 0 view .LVU3903
	call0	_Z2zpv		#
.LVL582:
	.loc 1 1411 7 is_stmt 1 view .LVU3904
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1411:       inc();
	.loc 1 1411 10 is_stmt 0 view .LVU3905
	call0	_Z3incv		#
.LVL583:
	.loc 1 1412 7 is_stmt 1 view .LVU3906
	j	.L170		#
.L184:
	.loc 1 1415 5 view .LVU3907
	.loc 1 1416 7 view .LVU3908
	.loc 1 1417 7 view .LVU3909
.LBB1915:
.LBI1915:
	.loc 1 444 13 view .LVU3910
.LBB1916:
	.loc 1 445 5 view .LVU3911
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:445:     x++;
	.loc 1 445 6 is_stmt 0 view .LVU3912
	l32r	a3, .LC189	#, tmp2875
	l8ui	a2, a3, 0	#, x
	addi.n	a2, a2, 1	# tmp2877, x,
	extui	a2, a2, 0, 8	# _1974, tmp2877
	s8i	a2, a3, 0	# x, _1974
	.loc 1 447 5 is_stmt 1 view .LVU3913
	.loc 1 447 5 view .LVU3914
	beqz.n	a2, .L557	# _1974,
	.loc 1 447 5 view .LVU3915
	movi.n	a3, -3	# tmp2879,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:448:     signcalc(x);
	.loc 1 448 5 is_stmt 0 view .LVU3916
	slli	a2, a2, 24	# tmp2882, _1974,
	and	a5, a5, a3	# _2363, cpustatus$6_5, tmp2879
	.loc 1 447 16 is_stmt 1 view .LVU3917
	.loc 1 448 5 view .LVU3918
	.loc 1 448 5 view .LVU3919
	bltz	a2, .L558	# tmp2882,
	j	.L617		#
.L557:
	.loc 1 447 5 view .LVU3920
	movi.n	a2, 0x22	# tmp2884,
	or	a2, a5, a2	# _1978, cpustatus$6_5, tmp2884
	.loc 1 447 16 view .LVU3921
	.loc 1 448 5 view .LVU3922
	.loc 1 448 5 view .LVU3923
	j	.L560		#
.L558:
	.loc 1 448 5 view .LVU3924
	movi	a2, 0xa0	# tmp2886,
	or	a5, a5, a2	# tmp2887, _2363, tmp2886
	s16i	a5, a14, 0	# cpustatus, tmp2887
	j	.L170		#
.L617:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:447:     zerocalc(x);
	.loc 1 447 5 is_stmt 0 view .LVU3925
	movi.n	a4, 0x20	#,
	or	a5, a5, a4	# tmp2889, _2363,
	extui	a2, a5, 0, 16	# _1978, tmp2889
.L560:
	.loc 1 448 5 is_stmt 1 view .LVU3926
	movi	a3, -0x81	# tmp2891,
	and	a2, a2, a3	# tmp2892, _1978, tmp2891
	s16i	a2, a14, 0	# cpustatus, tmp2892
	j	.L170		#
.L183:
.LBE1916:
.LBE1915:
	.loc 1 1419 5 view .LVU3927
	.loc 1 1420 7 view .LVU3928
.LBB1917:
.LBI1917:
	.loc 1 148 13 view .LVU3929
.LBB1918:
	.loc 1 149 5 view .LVU3930
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 12 is_stmt 0 view .LVU3931
	l16ui	a2, a13, 0	# pc, pc$356_320
	addi.n	a3, a2, 1	# tmp2895, pc$356_320,
	s16i	a3, a13, 0	# pc, tmp2895
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:149:     ea = pc++;
	.loc 1 149 8 view .LVU3932
	l32r	a3, .LC179	#, tmp2896
	s16i	a2, a3, 0	# ea, pc$356_320
.LBE1918:
.LBE1917:
	.loc 1 1421 7 is_stmt 1 view .LVU3933
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1421:       sbc();
	.loc 1 1421 10 is_stmt 0 view .LVU3934
	call0	_Z3sbcv		#
.LVL584:
	.loc 1 1422 7 is_stmt 1 view .LVU3935
	j	.L170		#
.L182:
	.loc 1 1429 5 view .LVU3936
	.loc 1 1430 7 view .LVU3937
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1430:       abso();
	.loc 1 1430 11 is_stmt 0 view .LVU3938
	call0	_Z4absov		#
.LVL585:
	.loc 1 1431 7 is_stmt 1 view .LVU3939
.LBB1919:
.LBI1919:
	.loc 1 378 13 view .LVU3940
.LBB1920:
	.loc 1 379 5 view .LVU3941
.LBB1921:
.LBI1921:
	.loc 1 216 17 view .LVU3942
.LBB1922:
	.loc 1 217 5 view .LVU3943
	l32r	a5, .LC172	#,
	l8ui	a2, a5, 0	# useaccum, useaccum
	beqz.n	a2, .L561	# useaccum,
	.loc 1 217 19 view .LVU3944
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3945
	l32r	a3, .LC190	#, tmp2899
	l8ui	a2, a3, 0	# prephitmp_1846, a
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3946
	mov.n	a3, a2	# _2004, prephitmp_1846
	j	.L562		#
.L561:
.LBB1923:
.LBI1923:
	.loc 1 216 17 is_stmt 1 view .LVU3947
.LBB1924:
	.loc 1 218 14 view .LVU3948
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3949
	l32r	a2, .LC179	#, tmp2900
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL586:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3950
	extui	a3, a2, 0, 16	# _2004, prephitmp_1846
.L562:
.LBE1924:
.LBE1923:
.LBE1922:
.LBE1921:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3951
	l32r	a4, .LC189	#, tmp2904
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3952
	l32r	a6, .LC191	#, tmp2903
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3953
	l8ui	a5, a4, 0	# x$358_1985, x
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:379:     value = getvalue();
	.loc 1 379 11 view .LVU3954
	s16i	a3, a6, 0	# value, _2004
	.loc 1 380 5 is_stmt 1 view .LVU3955
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 is_stmt 0 view .LVU3956
	sub	a4, a5, a3	# tmp2906, x$358_1985, _2004
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 view .LVU3957
	l32r	a3, .LC192	#, tmp2907
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 26 view .LVU3958
	extui	a4, a4, 0, 16	# _1987, tmp2906
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:380:     result = (uint16_t)x - value;
	.loc 1 380 12 view .LVU3959
	s16i	a4, a3, 0	# result, _1987
	.loc 1 382 5 is_stmt 1 view .LVU3960
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 41 is_stmt 0 view .LVU3961
	l16ui	a3, a14, 0	# cpustatus, pretmp_1286
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 5 view .LVU3962
	bltu	a5, a2, .L563	# x$358_1985, prephitmp_1846,
	.loc 1 382 41 is_stmt 1 view .LVU3963
	movi.n	a6, 1	# tmp2910,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3964
	movi.n	a7, 3	# tmp2915,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:382:     if (x >= (uint8_t)(value & 0x00FF)) setcarry();
	.loc 1 382 41 view .LVU3965
	or	a6, a3, a6	# prephitmp_1837, pretmp_1286, tmp2910
	.loc 1 384 5 is_stmt 1 view .LVU3966
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 41 is_stmt 0 view .LVU3967
	or	a3, a3, a7	# cstore_1191, pretmp_1286, tmp2915
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:384:     if (x == (uint8_t)(value & 0x00FF)) setzero();
	.loc 1 384 5 view .LVU3968
	beq	a2, a5, .L566	# prephitmp_1846, x$358_1985,
	j	.L565		#
.L563:
	.loc 1 383 14 is_stmt 1 view .LVU3969
	movi.n	a6, -2	# tmp2912,
	and	a6, a3, a6	# prephitmp_1837, pretmp_1286, tmp2912
	.loc 1 384 5 view .LVU3970
.L565:
	.loc 1 385 14 view .LVU3971
	movi.n	a3, -3	# tmp2916,
	and	a3, a6, a3	# cstore_1191, prephitmp_1837, tmp2916
.L566:
	.loc 1 386 5 view .LVU3972
	.loc 1 386 5 view .LVU3973
	movi	a2, 0x80	# tmp2918,
	bnone	a4, a2, .L567	# _1987, tmp2918,
	.loc 1 386 5 view .LVU3974
	or	a3, a3, a2	# tmp2924, cstore_1191, tmp2918
	s16i	a3, a14, 0	# cpustatus, tmp2924
	j	.L170		#
.L567:
	.loc 1 386 5 view .LVU3975
	movi	a2, -0x81	# tmp2926,
	and	a3, a3, a2	# tmp2927, cstore_1191, tmp2926
	s16i	a3, a14, 0	# cpustatus, tmp2927
	j	.L170		#
.L181:
.LBE1920:
.LBE1919:
	.loc 1 1433 5 view .LVU3976
	.loc 1 1434 7 view .LVU3977
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1434:       abso();
	.loc 1 1434 11 is_stmt 0 view .LVU3978
	call0	_Z4absov		#
.LVL587:
	.loc 1 1435 7 is_stmt 1 view .LVU3979
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1435:       sbc();
	.loc 1 1435 10 is_stmt 0 view .LVU3980
	call0	_Z3sbcv		#
.LVL588:
	.loc 1 1436 7 is_stmt 1 view .LVU3981
	j	.L170		#
.L180:
	.loc 1 1437 5 view .LVU3982
	.loc 1 1438 7 view .LVU3983
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1438:       abso();
	.loc 1 1438 11 is_stmt 0 view .LVU3984
	call0	_Z4absov		#
.LVL589:
	.loc 1 1439 7 is_stmt 1 view .LVU3985
.LBB1925:
.LBI1925:
	.loc 1 434 13 view .LVU3986
.LBB1926:
	.loc 1 435 5 view .LVU3987
.LBB1927:
.LBI1927:
	.loc 1 216 17 view .LVU3988
.LBB1928:
	.loc 1 217 5 view .LVU3989
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU3990
	l32r	a6, .LC172	#,
	l8ui	a4, a6, 0	# prephitmp_1129, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU3991
	beqz.n	a4, .L568	# prephitmp_1129,
	.loc 1 217 19 is_stmt 1 view .LVU3992
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU3993
	l32r	a2, .LC190	#, tmp2929
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU3994
	l8ui	a2, a2, 0	# _2027, a
	j	.L569		#
.L568:
.LBB1929:
.LBI1929:
	.loc 1 216 17 is_stmt 1 view .LVU3995
.LBB1930:
	.loc 1 218 14 view .LVU3996
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU3997
	l32r	a2, .LC179	#, tmp2932
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL590:
.LBE1930:
.LBE1929:
.LBE1928:
.LBE1927:
.LBB1934:
.LBB1935:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU3998
	l32r	a3, .LC172	#,
.LBE1935:
.LBE1934:
.LBB1946:
.LBB1933:
.LBB1932:
.LBB1931:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU3999
	extui	a2, a2, 0, 16	# _2027,
.LBE1931:
.LBE1932:
.LBE1933:
.LBE1946:
.LBB1947:
.LBB1944:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU4000
	l8ui	a4, a3, 0	# prephitmp_1129, useaccum
.L569:
.LBE1944:
.LBE1947:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU4001
	l32r	a5, .LC191	#, tmp2936
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU4002
	addi.n	a3, a2, 1	# tmp2937, _2027,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU4003
	s16i	a2, a5, 0	# value, _2027
	.loc 1 436 5 is_stmt 1 view .LVU4004
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 is_stmt 0 view .LVU4005
	l32r	a2, .LC192	#, tmp2938
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU4006
	extui	a3, a3, 0, 16	# _2013, tmp2937
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 view .LVU4007
	s16i	a3, a2, 0	# result, _2013
	.loc 1 438 5 is_stmt 1 view .LVU4008
	.loc 1 438 5 view .LVU4009
	extui	a5, a3, 0, 8	# tmp2942, _2013
	l16ui	a2, a14, 0	# cpustatus, pretmp_1287
	beqz.n	a5, .L570	# tmp2942,
	.loc 1 438 5 view .LVU4010
	movi.n	a5, -3	# tmp2943,
	and	a2, a2, a5	# cstore_1212, pretmp_1287, tmp2943
	j	.L571		#
.L570:
	.loc 1 438 5 view .LVU4011
	movi.n	a5, 2	# tmp2946,
	or	a2, a2, a5	# cstore_1212, pretmp_1287, tmp2946
.L571:
	.loc 1 438 21 view .LVU4012
	.loc 1 439 5 view .LVU4013
	.loc 1 439 5 view .LVU4014
	movi	a5, 0x80	# tmp2947,
	bnone	a3, a5, .L572	# _2013, tmp2947,
	.loc 1 439 5 view .LVU4015
	or	a2, a2, a5	# tmp2952, cstore_1212, tmp2947
	extui	a2, a2, 0, 16	# cstore_300, tmp2952
	j	.L573		#
.L572:
	.loc 1 439 5 view .LVU4016
	movi	a5, -0x81	# tmp2953,
	and	a2, a2, a5	# cstore_300, cstore_1212, tmp2953
.L573:
	s16i	a2, a14, 0	# cpustatus, cstore_300
	.loc 1 439 21 view .LVU4017
	.loc 1 441 5 view .LVU4018
.LVL591:
.LBB1948:
.LBI1934:
	.loc 1 225 13 view .LVU4019
.LBB1945:
	.loc 1 226 5 view .LVU4020
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU4021
	extui	a3, a3, 0, 8	# _1279, _2013
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU4022
	beqz.n	a4, .L574	# prephitmp_1129,
	.loc 1 226 19 is_stmt 1 view .LVU4023
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU4024
	l32r	a2, .LC190	#, tmp2956
	s8i	a3, a2, 0	# a, _1279
	j	.L170		#
.L574:
.LVL592:
.LBB1936:
.LBI1936:
	.loc 1 225 13 is_stmt 1 view .LVU4025
.LBB1937:
	.loc 1 227 14 view .LVU4026
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU4027
	l32r	a2, .LC179	#, tmp2957
.LBB1938:
.LBB1939:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU4028
	l32r	a5, .LC176	#, tmp2958
.LBE1939:
.LBE1938:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU4029
	l16ui	a2, a2, 0	# ea, ea$53_2040
.LVL593:
.LBB1943:
.LBI1938:
	.loc 1 90 6 is_stmt 1 view .LVU4030
.LBB1942:
	.loc 1 91 3 view .LVU4031
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU4032
	movi	a4, 0x1ff	# tmp2960,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU4033
	s16i	a2, a5, 0	# last_modified_ram, ea$53_2040
	.loc 1 92 3 is_stmt 1 view .LVU4034
	bltu	a4, a2, .L575	# tmp2960, ea$53_2040,
	.loc 1 93 5 view .LVU4035
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU4036
	l32r	a4, .LC175	#, tmp2961
	add.n	a2, a4, a2	# tmp2962, tmp2961, ea$53_2040
	s8i	a3, a2, 0	# zero_ram[_2041], _1279
	.loc 1 94 5 is_stmt 1 view .LVU4037
	j	.L170		#
.L575:
.LVL594:
.LBB1940:
.LBI1940:
	.loc 1 90 6 view .LVU4038
.LBB1941:
	.loc 1 96 3 view .LVU4039
	l32r	a4, .LC180	#, tmp2963
	extui	a4, a4, 0, 16	# tmp2964, tmp2963
	bltu	a4, a2, .L576	# tmp2964, ea$53_2040,
	.loc 1 97 5 view .LVU4040
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU4041
	addmi	a2, a2, -0x200	# tmp2965, ea$53_2040,
.LVL595:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU4042
	extui	a2, a2, 0, 16	#, tmp2965
	call0	_Z14drawPixelToRamth		#
.LVL596:
	.loc 1 98 5 is_stmt 1 view .LVU4043
	j	.L170		#
.LVL597:
.L576:
	.loc 1 100 3 view .LVU4044
	l32r	a4, .LC182	#, tmp2967
	extui	a4, a4, 0, 16	# tmp2968, tmp2967
	bltu	a4, a2, .L170	# tmp2968, ea$53_2040,
	.loc 1 101 5 view .LVU4045
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU4046
	l32r	a4, .LC184	#, tmp2969
	add.n	a2, a4, a2	# tmp2970, tmp2969, ea$53_2040
.LVL598:
	.loc 1 101 27 view .LVU4047
	addmi	a2, a2, -0x1200	# tmp2971, tmp2970,
	s8i	a3, a2, 0	# RAM[_2055], _1279
	.loc 1 102 5 is_stmt 1 view .LVU4048
	j	.L170		#
.LVL599:
.L179:
	.loc 1 102 5 is_stmt 0 view .LVU4049
.LBE1941:
.LBE1940:
.LBE1942:
.LBE1943:
.LBE1937:
.LBE1936:
.LBE1945:
.LBE1948:
.LBE1926:
.LBE1925:
	.loc 1 1443 5 is_stmt 1 view .LVU4050
	.loc 1 1444 7 view .LVU4051
.LBB1949:
.LBI1949:
	.loc 1 164 13 view .LVU4052
.LBB1950:
	.loc 1 165 5 view .LVU4053
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 is_stmt 0 view .LVU4054
	l16ui	a2, a13, 0	# pc, pc$374_2058
.LBB1951:
.LBB1952:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:70:   if(address < 0x200){
	.loc 1 70 3 view .LVU4055
	movi	a4, 0x1ff	# tmp2976,
.LBE1952:
.LBE1951:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 36 view .LVU4056
	addi.n	a5, a2, 1	# tmp2974, pc$374_2058,
	s16i	a5, a13, 0	# pc, tmp2974
.LVL600:
.LBB1957:
.LBI1951:
	.loc 1 69 9 is_stmt 1 view .LVU4057
.LBB1955:
	.loc 1 70 3 view .LVU4058
	bltu	a4, a2, .L577	# tmp2976, pc$374_2058,
	.loc 1 71 5 view .LVU4059
	.loc 1 72 7 view .LVU4060
	.loc 1 75 12 view .LVU4061
	movi	a4, 0xfe	# tmp2978,
	bne	a2, a4, .L578	# pc$374_2058, tmp2978,
	.loc 1 76 9 view .LVU4062
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 21 is_stmt 0 view .LVU4063
	call0	rand		#
.LVL601:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:76:         return (rand() & 0xff);
	.loc 1 76 30 view .LVU4064
	extui	a2, a2, 0, 8	# _2069,
	j	.L639		#
.LVL602:
.L578:
	.loc 1 79 5 is_stmt 1 view .LVU4065
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:79:     return zero_ram[address];
	.loc 1 79 28 is_stmt 0 view .LVU4066
	l32r	a4, .LC175	#, tmp2980
	add.n	a2, a4, a2	# tmp2981, tmp2980, pc$374_2058
.LVL603:
	.loc 1 79 28 view .LVU4067
	j	.L640		#
.LVL604:
.L577:
	.loc 1 81 3 is_stmt 1 view .LVU4068
	l32r	a4, .LC180	#, tmp2982
	extui	a4, a4, 0, 16	# tmp2983, tmp2982
	bltu	a4, a2, .L580	# tmp2983, pc$374_2058,
.LVL605:
.LBB1953:
.LBI1953:
	.loc 1 69 9 view .LVU4069
.LBB1954:
	.loc 1 82 5 view .LVU4070
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 37 is_stmt 0 view .LVU4071
	addmi	a2, a2, -0x200	# tmp2984, pc$374_2058,
.LVL606:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:82:     return loadPixelFromRam(address - 0x200);
	.loc 1 82 28 view .LVU4072
	extui	a2, a2, 0, 16	#, tmp2984
.LVL607:
	.loc 1 82 28 view .LVU4073
	call0	_Z16loadPixelFromRamt		#
.LVL608:
.L639:
	.loc 1 82 28 view .LVU4074
.LBE1954:
.LBE1953:
.LBE1955:
.LBE1957:
.LBE1950:
.LBE1949:
.LBB1962:
.LBB1963:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:282:     if ((cpustatus & FLAG_ZERO) == FLAG_ZERO) {
	.loc 1 282 20 view .LVU4075
	l16ui	a3, a14, 0	# cpustatus, prephitmp_1199
	j	.L579		#
.LVL609:
.L580:
	.loc 1 282 20 view .LVU4076
.LBE1963:
.LBE1962:
.LBB1968:
.LBB1959:
.LBB1958:
.LBB1956:
	.loc 1 84 3 is_stmt 1 view .LVU4077
	l32r	a4, .LC182	#, tmp2988
	extui	a4, a4, 0, 16	# tmp2989, tmp2988
	bltu	a4, a2, .L581	# tmp2989, pc$374_2058,
	.loc 1 85 5 view .LVU4078
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:85:     return RAM[address - 0x1200];
	.loc 1 85 32 is_stmt 0 view .LVU4079
	l32r	a4, .LC184	#, tmp2990
	add.n	a2, a4, a2	# tmp2991, tmp2990, pc$374_2058
.LVL610:
	.loc 1 85 32 view .LVU4080
	addmi	a2, a2, -0x1200	# tmp2992, tmp2991,
.L640:
	.loc 1 85 32 view .LVU4081
	l8ui	a2, a2, 0	# _2069,
.LVL611:
.L579:
	.loc 1 85 32 view .LVU4082
.LBE1956:
.LBE1958:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 15 view .LVU4083
	extui	a4, a2, 0, 16	# _2062, _2069
	.loc 1 166 5 is_stmt 1 view .LVU4084
	bbsi	a2, 7, .L582	# _2069,,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 is_stmt 0 view .LVU4085
	l32r	a2, .LC185	#, tmp3112
	j	.L641		#
.L582:
	.loc 1 166 25 is_stmt 1 view .LVU4086
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU4087
	movi	a5, -0x100	# tmp2997,
	l32r	a2, .LC185	#, tmp3112
	or	a4, a4, a5	# tmp2998, _2062, tmp2997
.L641:
.LBE1959:
.LBE1968:
	.loc 1 1445 7 is_stmt 1 view .LVU4088
.LBB1969:
.LBI1962:
	.loc 1 281 13 view .LVU4089
.LBB1966:
	.loc 1 282 5 view .LVU4090
.LBE1966:
.LBE1969:
.LBB1970:
.LBB1960:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:166:     if (reladdr & 0x80) reladdr |= 0xFF00;
	.loc 1 166 33 is_stmt 0 view .LVU4091
	s16i	a4, a2, 0	# reladdr, tmp2998
.LBE1960:
.LBE1970:
.LBB1971:
.LBB1967:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:282:     if ((cpustatus & FLAG_ZERO) == FLAG_ZERO) {
	.loc 1 282 5 view .LVU4092
	bbci	a3, 1, .L170	# prephitmp_1199,,
.LBB1964:
.LBI1964:
	.loc 1 263 13 is_stmt 1 view .LVU4093
.LBB1965:
	.loc 1 265 9 view .LVU4094
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 is_stmt 0 view .LVU4095
	l16ui	a5, a13, 0	# pc, pc$202_2081
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU4096
	l16ui	a3, a2, 0	# reladdr,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU4097
	l32r	a6, .LC187	#, tmp3009
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU4098
	add.n	a3, a5, a3	# tmp3007, pc$202_2081, reladdr
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU4099
	l32i.n	a2, a6, 0	# clockticks6502, pretmp_1243
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU4100
	extui	a3, a3, 0, 16	# _2083, tmp3007
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU4101
	movi	a7, -0x100	# tmp3011,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 30 view .LVU4102
	xor	a4, a5, a3	# tmp3010, pc$202_2081, _2083
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 9 view .LVU4103
	and	a4, a4, a7	# tmp3015, tmp3010, tmp3011
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 view .LVU4104
	addi.n	a7, a2, 1	# tmp3019, pretmp_1243,
	addi.n	a2, a2, 2	# tmp3017, pretmp_1243,
	moveqz	a2, a7, a4	# tmp3148, tmp3019, tmp3015
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU4105
	l32r	a4, .LC186	#, tmp3004
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:266:         pc += reladdr;
	.loc 1 266 12 view .LVU4106
	s16i	a3, a13, 0	# pc, _2083
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:265:         oldpc = pc;
	.loc 1 265 15 view .LVU4107
	s16i	a5, a4, 0	# oldpc, pc$202_2081
	.loc 1 266 9 is_stmt 1 view .LVU4108
	.loc 1 267 9 view .LVU4109
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:267:         if ((oldpc & 0xFF00) != (pc & 0xFF00)) clockticks6502 += 2; //check if jump crossed a page boundary
	.loc 1 267 63 is_stmt 0 view .LVU4110
	s32i.n	a2, a6, 0	# clockticks6502, tmp3148
	j	.L170		#
.L178:
.LBE1965:
.LBE1964:
.LBE1967:
.LBE1971:
	.loc 1 1447 5 is_stmt 1 view .LVU4111
	.loc 1 1448 7 view .LVU4112
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1448:       indy();
	.loc 1 1448 11 is_stmt 0 view .LVU4113
	call0	_Z4indyv		#
.LVL612:
	.loc 1 1449 7 is_stmt 1 view .LVU4114
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1449:       sbc();
	.loc 1 1449 10 is_stmt 0 view .LVU4115
	call0	_Z3sbcv		#
.LVL613:
	.loc 1 1450 7 is_stmt 1 view .LVU4116
	j	.L170		#
.L177:
	.loc 1 1455 5 view .LVU4117
	.loc 1 1456 7 view .LVU4118
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1456:       zpx();
	.loc 1 1456 10 is_stmt 0 view .LVU4119
	call0	_Z3zpxv		#
.LVL614:
	.loc 1 1457 7 is_stmt 1 view .LVU4120
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1457:       sbc();
	.loc 1 1457 10 is_stmt 0 view .LVU4121
	call0	_Z3sbcv		#
.LVL615:
	.loc 1 1458 7 is_stmt 1 view .LVU4122
	j	.L170		#
.L176:
	.loc 1 1459 5 view .LVU4123
	.loc 1 1460 7 view .LVU4124
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1460:       zpx();
	.loc 1 1460 10 is_stmt 0 view .LVU4125
	call0	_Z3zpxv		#
.LVL616:
	.loc 1 1461 7 is_stmt 1 view .LVU4126
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1461:       inc();
	.loc 1 1461 10 is_stmt 0 view .LVU4127
	call0	_Z3incv		#
.LVL617:
	.loc 1 1462 7 is_stmt 1 view .LVU4128
	j	.L170		#
.L175:
	.loc 1 1465 5 view .LVU4129
	.loc 1 1466 7 view .LVU4130
	.loc 1 1467 7 view .LVU4131
.LBB1972:
.LBI1972:
	.loc 1 585 13 view .LVU4132
.LBB1973:
	.loc 1 586 5 view .LVU4133
	movi.n	a2, 0x28	# tmp3021,
	or	a2, a5, a2	# tmp3022, cpustatus$6_5, tmp3021
	s16i	a2, a14, 0	# cpustatus, tmp3022
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:587: }
	.loc 1 587 1 is_stmt 0 view .LVU4134
	j	.L170		#
.L174:
.LBE1973:
.LBE1972:
	.loc 1 1469 5 is_stmt 1 view .LVU4135
	.loc 1 1470 7 view .LVU4136
.LBB1974:
.LBI1974:
	.loc 1 183 13 view .LVU4137
.LBB1975:
	.loc 1 184 5 view .LVU4138
	.loc 1 185 5 view .LVU4139
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 29 is_stmt 0 view .LVU4140
	l16ui	a2, a13, 0	# pc,
	call0	_Z8read6502t		#
.LVL618:
	mov.n	a5, a2	# tmp3025,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU4141
	l16ui	a2, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU4142
	s32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 58 view .LVU4143
	addi.n	a2, a2, 1	# tmp3028, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 55 view .LVU4144
	extui	a2, a2, 0, 16	#, tmp3028
	call0	_Z8read6502t		#
.LVL619:
	.loc 1 186 5 is_stmt 1 view .LVU4145
	.loc 1 187 5 view .LVU4146
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 is_stmt 0 view .LVU4147
	l32r	a4, .LC188	#, tmp3036
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU4148
	l32i.n	a5, sp, 0	#,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU4149
	l8ui	a4, a4, 0	# y, y
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 62 view .LVU4150
	slli	a2, a2, 8	# tmp3032,,
.LVL620:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU4151
	l16ui	a3, a13, 0	# pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:185:     ea = ((uint16_t)read6502(pc) | ((uint16_t)read6502(pc+1) << 8));
	.loc 1 185 34 view .LVU4152
	or	a2, a2, a5	# tmp3035, tmp3032, tmp3025
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU4153
	add.n	a4, a4, a2	# tmp3040, y, tmp3035
	l32r	a2, .LC179	#, tmp3031
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 view .LVU4154
	addi.n	a3, a3, 2	# tmp3044, pc,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:187:     ea += (uint16_t)y;
	.loc 1 187 8 view .LVU4155
	s16i	a4, a2, 0	# ea, tmp3040
	.loc 1 189 5 is_stmt 1 view .LVU4156
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:189:     pc += 2;
	.loc 1 189 8 is_stmt 0 view .LVU4157
	s16i	a3, a13, 0	# pc, tmp3044
.LBE1975:
.LBE1974:
	.loc 1 1471 7 is_stmt 1 view .LVU4158
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1471:       sbc();
	.loc 1 1471 10 is_stmt 0 view .LVU4159
	call0	_Z3sbcv		#
.LVL621:
	.loc 1 1472 7 is_stmt 1 view .LVU4160
	j	.L170		#
.L173:
	.loc 1 1477 5 view .LVU4161
	.loc 1 1478 7 view .LVU4162
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1478:       absx();
	.loc 1 1478 11 is_stmt 0 view .LVU4163
	call0	_Z4absxv		#
.LVL622:
	.loc 1 1479 7 is_stmt 1 view .LVU4164
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1479:       sbc();
	.loc 1 1479 10 is_stmt 0 view .LVU4165
	call0	_Z3sbcv		#
.LVL623:
	.loc 1 1480 7 is_stmt 1 view .LVU4166
	j	.L170		#
.L171:
	.loc 1 1481 5 view .LVU4167
	.loc 1 1482 7 view .LVU4168
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1482:       absx();
	.loc 1 1482 11 is_stmt 0 view .LVU4169
	call0	_Z4absxv		#
.LVL624:
	.loc 1 1483 7 is_stmt 1 view .LVU4170
.LBB1976:
.LBI1976:
	.loc 1 434 13 view .LVU4171
.LBB1977:
	.loc 1 435 5 view .LVU4172
.LBB1978:
.LBI1978:
	.loc 1 216 17 view .LVU4173
.LBB1979:
	.loc 1 217 5 view .LVU4174
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 9 is_stmt 0 view .LVU4175
	l32r	a5, .LC172	#,
	l8ui	a4, a5, 0	# prephitmp_1194, useaccum
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 5 view .LVU4176
	beqz.n	a4, .L585	# prephitmp_1194,
	.loc 1 217 19 is_stmt 1 view .LVU4177
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 26 is_stmt 0 view .LVU4178
	l32r	a2, .LC190	#, tmp3046
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:217:     if (useaccum) return((uint16_t)a);
	.loc 1 217 37 view .LVU4179
	l8ui	a2, a2, 0	# _2123, a
	j	.L586		#
.L585:
.LBB1980:
.LBI1980:
	.loc 1 216 17 is_stmt 1 view .LVU4180
.LBB1981:
	.loc 1 218 14 view .LVU4181
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 39 is_stmt 0 view .LVU4182
	l32r	a2, .LC179	#, tmp3049
	l16ui	a2, a2, 0	# ea,
	call0	_Z8read6502t		#
.LVL625:
.LBE1981:
.LBE1980:
.LBE1979:
.LBE1978:
.LBB1985:
.LBB1986:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU4183
	l32r	a6, .LC172	#,
.LBE1986:
.LBE1985:
.LBB1997:
.LBB1984:
.LBB1983:
.LBB1982:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:218:         else return((uint16_t)read6502(ea));
	.loc 1 218 43 view .LVU4184
	extui	a2, a2, 0, 16	# _2123,
.LBE1982:
.LBE1983:
.LBE1984:
.LBE1997:
.LBB1998:
.LBB1995:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 9 view .LVU4185
	l8ui	a4, a6, 0	# prephitmp_1194, useaccum
.L586:
.LBE1995:
.LBE1998:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU4186
	l32r	a5, .LC191	#, tmp3053
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU4187
	addi.n	a3, a2, 1	# tmp3054, _2123,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:435:     value = getvalue();
	.loc 1 435 11 view .LVU4188
	s16i	a2, a5, 0	# value, _2123
	.loc 1 436 5 is_stmt 1 view .LVU4189
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 is_stmt 0 view .LVU4190
	l32r	a2, .LC192	#, tmp3055
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 20 view .LVU4191
	extui	a3, a3, 0, 16	# _2109, tmp3054
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:436:     result = value + 1;
	.loc 1 436 12 view .LVU4192
	s16i	a3, a2, 0	# result, _2109
	.loc 1 438 5 is_stmt 1 view .LVU4193
	.loc 1 438 5 view .LVU4194
	extui	a5, a3, 0, 8	# tmp3059, _2109
	l16ui	a2, a14, 0	# cpustatus, pretmp_1227
	beqz.n	a5, .L587	# tmp3059,
	.loc 1 438 5 view .LVU4195
	movi.n	a5, -3	# tmp3060,
	and	a2, a2, a5	# cstore_1250, pretmp_1227, tmp3060
	j	.L588		#
.L587:
	.loc 1 438 5 view .LVU4196
	movi.n	a5, 2	# tmp3063,
	or	a2, a2, a5	# cstore_1250, pretmp_1227, tmp3063
.L588:
	.loc 1 438 21 view .LVU4197
	.loc 1 439 5 view .LVU4198
	.loc 1 439 5 view .LVU4199
	movi	a5, 0x80	# tmp3064,
	bnone	a3, a5, .L589	# _2109, tmp3064,
	.loc 1 439 5 view .LVU4200
	or	a2, a2, a5	# tmp3069, cstore_1250, tmp3064
	extui	a2, a2, 0, 16	# cstore_1289, tmp3069
	j	.L590		#
.L589:
	.loc 1 439 5 view .LVU4201
	movi	a5, -0x81	# tmp3070,
	and	a2, a2, a5	# cstore_1289, cstore_1250, tmp3070
.L590:
	s16i	a2, a14, 0	# cpustatus, cstore_1289
	.loc 1 439 21 view .LVU4202
	.loc 1 441 5 view .LVU4203
.LVL626:
.LBB1999:
.LBI1985:
	.loc 1 225 13 view .LVU4204
.LBB1996:
	.loc 1 226 5 view .LVU4205
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU4206
	extui	a3, a3, 0, 8	# _1230, _2109
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 5 view .LVU4207
	beqz.n	a4, .L591	# prephitmp_1194,
	.loc 1 226 19 is_stmt 1 view .LVU4208
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:226:     if (useaccum) a = (uint8_t)(saveval & 0x00FF);
	.loc 1 226 21 is_stmt 0 view .LVU4209
	l32r	a2, .LC190	#, tmp3073
	s8i	a3, a2, 0	# a, _1230
	j	.L170		#
.L591:
.LVL627:
.LBB1987:
.LBI1987:
	.loc 1 225 13 is_stmt 1 view .LVU4210
.LBB1988:
	.loc 1 227 14 view .LVU4211
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 is_stmt 0 view .LVU4212
	l32r	a2, .LC179	#, tmp3074
.LBB1989:
.LBB1990:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU4213
	l32r	a5, .LC176	#, tmp3075
.LBE1990:
.LBE1989:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:227:         else write6502(ea, (saveval & 0x00FF));
	.loc 1 227 23 view .LVU4214
	l16ui	a2, a2, 0	# ea, ea$53_2136
.LVL628:
.LBB1994:
.LBI1989:
	.loc 1 90 6 is_stmt 1 view .LVU4215
.LBB1993:
	.loc 1 91 3 view .LVU4216
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:92:   if(address < 0x200){
	.loc 1 92 3 is_stmt 0 view .LVU4217
	movi	a4, 0x1ff	# tmp3077,
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:91:   last_modified_ram = address;
	.loc 1 91 21 view .LVU4218
	s16i	a2, a5, 0	# last_modified_ram, ea$53_2136
	.loc 1 92 3 is_stmt 1 view .LVU4219
	bltu	a4, a2, .L592	# tmp3077, ea$53_2136,
	.loc 1 93 5 view .LVU4220
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:93:     zero_ram[address] = value;
	.loc 1 93 23 is_stmt 0 view .LVU4221
	l32r	a4, .LC175	#, tmp3078
	add.n	a2, a4, a2	# tmp3079, tmp3078, ea$53_2136
	s8i	a3, a2, 0	# zero_ram[_2137], _1230
	.loc 1 94 5 is_stmt 1 view .LVU4222
	j	.L170		#
.L592:
.LVL629:
.LBB1991:
.LBI1991:
	.loc 1 90 6 view .LVU4223
.LBB1992:
	.loc 1 96 3 view .LVU4224
	l32r	a4, .LC180	#, tmp3080
	extui	a4, a4, 0, 16	# tmp3081, tmp3080
	bltu	a4, a2, .L593	# tmp3081, ea$53_2136,
	.loc 1 97 5 view .LVU4225
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 28 is_stmt 0 view .LVU4226
	addmi	a2, a2, -0x200	# tmp3082, ea$53_2136,
.LVL630:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:97:     drawPixelToRam(address - 0x200, value);
	.loc 1 97 19 view .LVU4227
	extui	a2, a2, 0, 16	#, tmp3082
	call0	_Z14drawPixelToRamth		#
.LVL631:
	.loc 1 98 5 is_stmt 1 view .LVU4228
	j	.L170		#
.LVL632:
.L593:
	.loc 1 100 3 view .LVU4229
	l32r	a4, .LC182	#, tmp3084
	extui	a4, a4, 0, 16	# tmp3085, tmp3084
	bltu	a4, a2, .L170	# tmp3085, ea$53_2136,
	.loc 1 101 5 view .LVU4230
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:101:     RAM[address - 0x1200] = value;
	.loc 1 101 27 is_stmt 0 view .LVU4231
	l32r	a4, .LC184	#, tmp3086
	add.n	a2, a4, a2	# tmp3087, tmp3086, ea$53_2136
.LVL633:
	.loc 1 101 27 view .LVU4232
	addmi	a2, a2, -0x1200	# tmp3088, tmp3087,
	s8i	a3, a2, 0	# RAM[_2151], _1230
	.loc 1 102 5 is_stmt 1 view .LVU4233
.LVL634:
.L170:
	.loc 1 102 5 is_stmt 0 view .LVU4234
.LBE1992:
.LBE1991:
.LBE1993:
.LBE1994:
.LBE1988:
.LBE1987:
.LBE1996:
.LBE1999:
.LBE1977:
.LBE1976:
	.loc 1 1488 5 is_stmt 1 view .LVU4235
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1488:     instructions++;
	.loc 1 1488 17 is_stmt 0 view .LVU4236
	l32i.n	a2, a15, 0	# instructions, instructions
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:713:   while (tickcount--) {
	.loc 1 713 19 view .LVU4237
	addi.n	a12, a12, -1	# ivtmp$594, ivtmp$594,
.LVL635:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1488:     instructions++;
	.loc 1 1488 17 view .LVU4238
	addi.n	a2, a2, 1	# tmp3091, instructions,
	s32i.n	a2, a15, 0	# instructions, tmp3091
	.loc 1 713 3 is_stmt 1 view .LVU4239
	.loc 1 713 19 view .LVU4240
.LVL636:
	.loc 1 713 19 is_stmt 0 view .LVU4241
	bnez.n	a12, .L594	# ivtmp$594,
	j	.L168		#
.LVL637:
.L326:
.LBB2000:
.LBB1134:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:165:     reladdr = (uint16_t)read6502(pc++);
	.loc 1 165 13 view .LVU4242
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3094,
	j	.L620		#
.LVL638:
.L343:
	.loc 1 165 13 view .LVU4243
.LBE1134:
.LBE2000:
.LBB2001:
.LBB1219:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3096,
	j	.L623		#
.LVL639:
.L581:
	.loc 1 165 13 view .LVU4244
.LBE1219:
.LBE2001:
.LBB2002:
.LBB1961:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3098,
	j	.L641		#
.LVL640:
.L352:
	.loc 1 165 13 view .LVU4245
.LBE1961:
.LBE2002:
.LBB2003:
.LBB1274:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3100,
	j	.L626		#
.LVL641:
.L363:
	.loc 1 165 13 view .LVU4246
.LBE1274:
.LBE2003:
.LBB2004:
.LBB1317:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3102,
	j	.L629		#
.LVL642:
.L397:
	.loc 1 165 13 view .LVU4247
.LBE1317:
.LBE2004:
.LBB2005:
.LBB1468:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3104,
	j	.L632		#
.LVL643:
.L523:
	.loc 1 165 13 view .LVU4248
.LBE1468:
.LBE2005:
.LBB2006:
.LBB1826:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3106,
	j	.L638		#
.LVL644:
.L455:
	.loc 1 165 13 view .LVU4249
.LBE1826:
.LBE2006:
.LBB2007:
.LBB1683:
	l32r	a2, .LC185	#, tmp3112
	movi.n	a4, 0	# tmp3108,
	j	.L635		#
.LVL645:
.L168:
	.loc 1 165 13 view .LVU4250
.LBE1683:
.LBE2007:
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1490: }
	.loc 1 1490 1 view .LVU4251
	l32i.n	a0, sp, 44	#,
	l32i.n	a12, sp, 40	#,
	l32i.n	a13, sp, 36	#,
	l32i.n	a14, sp, 32	#,
	l32i.n	a15, sp, 28	#,
	addi	sp, sp, 48	#,,
	ret.n	
.LFE101:
	.size	_Z8exec6502i, .-_Z8exec6502i
	.section	.text._Z5getpcv,"ax",@progbits
	.literal_position
	.literal .LC194, pc
	.align	4
	.global	_Z5getpcv
	.type	_Z5getpcv, @function
_Z5getpcv:
.LFB102:
	.loc 1 1492 18 is_stmt 1 view -0
	.loc 1 1493 3 view .LVU4253
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1493:   return(pc);
	.loc 1 1493 12 is_stmt 0 view .LVU4254
	l32r	a2, .LC194	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1494: }
	.loc 1 1494 1 view .LVU4255
	l16ui	a2, a2, 0	# pc,
	ret.n	
.LFE102:
	.size	_Z5getpcv, .-_Z5getpcv
	.section	.text._Z5getopv,"ax",@progbits
	.literal_position
	.literal .LC195, opcode
	.align	4
	.global	_Z5getopv
	.type	_Z5getopv, @function
_Z5getopv:
.LFB103:
	.loc 1 1496 17 is_stmt 1 view -0
	.loc 1 1497 3 view .LVU4257
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1497:   return(opcode);
	.loc 1 1497 16 is_stmt 0 view .LVU4258
	l32r	a2, .LC195	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1498: }
	.loc 1 1498 1 view .LVU4259
	l8ui	a2, a2, 0	#, opcode
	ret.n	
.LFE103:
	.size	_Z5getopv, .-_Z5getopv
	.section	.text._Z7getaregv,"ax",@progbits
	.literal_position
	.literal .LC196, a
	.align	4
	.global	_Z7getaregv
	.type	_Z7getaregv, @function
_Z7getaregv:
.LFB104:
	.loc 1 1500 18 is_stmt 1 view -0
	.loc 1 1501 3 view .LVU4261
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1501:   return(a);
	.loc 1 1501 11 is_stmt 0 view .LVU4262
	l32r	a2, .LC196	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1502: }
	.loc 1 1502 1 view .LVU4263
	l8ui	a2, a2, 0	#, a
	ret.n	
.LFE104:
	.size	_Z7getaregv, .-_Z7getaregv
	.section	.text._Z7getxregv,"ax",@progbits
	.literal_position
	.literal .LC197, x
	.align	4
	.global	_Z7getxregv
	.type	_Z7getxregv, @function
_Z7getxregv:
.LFB105:
	.loc 1 1504 18 is_stmt 1 view -0
	.loc 1 1505 3 view .LVU4265
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1505:   return(x);
	.loc 1 1505 11 is_stmt 0 view .LVU4266
	l32r	a2, .LC197	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1506: }
	.loc 1 1506 1 view .LVU4267
	l8ui	a2, a2, 0	#, x
	ret.n	
.LFE105:
	.size	_Z7getxregv, .-_Z7getxregv
	.section	.text._Z7getyregv,"ax",@progbits
	.literal_position
	.literal .LC198, y
	.align	4
	.global	_Z7getyregv
	.type	_Z7getyregv, @function
_Z7getyregv:
.LFB106:
	.loc 1 1508 18 is_stmt 1 view -0
	.loc 1 1509 3 view .LVU4269
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1509:   return(y);
	.loc 1 1509 11 is_stmt 0 view .LVU4270
	l32r	a2, .LC198	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1510: }
	.loc 1 1510 1 view .LVU4271
	l8ui	a2, a2, 0	#, y
	ret.n	
.LFE106:
	.size	_Z7getyregv, .-_Z7getyregv
	.section	.text._Z10getzeroramt,"ax",@progbits
	.literal_position
	.literal .LC199, zero_ram
	.align	4
	.global	_Z10getzeroramt
	.type	_Z10getzeroramt, @function
_Z10getzeroramt:
.LVL646:
.LFB107:
	.loc 1 1512 31 is_stmt 1 view -0
	.loc 1 1513 3 view .LVU4273
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1513:   return zero_ram[i];
	.loc 1 1513 20 is_stmt 0 view .LVU4274
	l32r	a3, .LC199	#, tmp47
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1512: uint8_t getzeroram(uint16_t i){
	.loc 1 1512 31 view .LVU4275
	extui	a2, a2, 0, 16	# i, i
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1513:   return zero_ram[i];
	.loc 1 1513 20 view .LVU4276
	add.n	a3, a3, a2	# tmp48, tmp47, i
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1514: }
	.loc 1 1514 1 view .LVU4277
	l8ui	a2, a3, 0	#, zero_ram[_1]
.LVL647:
	.loc 1 1514 1 view .LVU4278
	ret.n	
.LFE107:
	.size	_Z10getzeroramt, .-_Z10getzeroramt
	.section	.text._Z10setzeroramth,"ax",@progbits
	.literal_position
	.literal .LC200, zero_ram
	.align	4
	.global	_Z10setzeroramth
	.type	_Z10setzeroramth, @function
_Z10setzeroramth:
.LVL648:
.LFB108:
	.loc 1 1516 39 is_stmt 1 view -0
	.loc 1 1517 3 view .LVU4280
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1517:   zero_ram[i] = v;
	.loc 1 1517 15 is_stmt 0 view .LVU4281
	l32r	a4, .LC200	#, tmp47
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1516: void setzeroram(uint16_t i, uint8_t v){
	.loc 1 1516 39 view .LVU4282
	extui	a2, a2, 0, 16	# i, i
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1517:   zero_ram[i] = v;
	.loc 1 1517 15 view .LVU4283
	add.n	a4, a4, a2	# tmp48, tmp47, i
	s8i	a3, a4, 0	# zero_ram[_1], v
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1518: }
	.loc 1 1518 1 view .LVU4284
	ret.n	
.LFE108:
	.size	_Z10setzeroramth, .-_Z10setzeroramth
	.section	.text._Z18getLastModifiedRamv,"ax",@progbits
	.literal_position
	.literal .LC201, last_modified_ram
	.align	4
	.global	_Z18getLastModifiedRamv
	.type	_Z18getLastModifiedRamv, @function
_Z18getLastModifiedRamv:
.LFB109:
	.loc 1 1520 30 is_stmt 1 view -0
	.loc 1 1521 3 view .LVU4286
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1521:   return last_modified_ram;
	.loc 1 1521 10 is_stmt 0 view .LVU4287
	l32r	a2, .LC201	#, tmp44
# C:\Users\corax\Documents\Arduino\ESP_easy6502\cpu6502.cpp:1522: }
	.loc 1 1522 1 view .LVU4288
	l16ui	a2, a2, 0	# last_modified_ram,
	ret.n	
.LFE109:
	.size	_Z18getLastModifiedRamv, .-_Z18getLastModifiedRamv
	.global	str_buffer_6502
	.section	.bss.str_buffer_6502,"aw",@nobits
	.type	str_buffer_6502, @object
	.size	str_buffer_6502, 12
str_buffer_6502:
	.zero	12
	.global	useaccum
	.section	.bss.useaccum,"aw",@nobits
	.type	useaccum, @object
	.size	useaccum, 1
useaccum:
	.zero	1
	.global	oldcpustatus
	.section	.bss.oldcpustatus,"aw",@nobits
	.type	oldcpustatus, @object
	.size	oldcpustatus, 1
oldcpustatus:
	.zero	1
	.global	opcode
	.section	.bss.opcode,"aw",@nobits
	.type	opcode, @object
	.size	opcode, 1
opcode:
	.zero	1
	.global	result
	.section	.bss.result,"aw",@nobits
	.align	2
	.type	result, @object
	.size	result, 2
result:
	.zero	2
	.global	value
	.section	.bss.value,"aw",@nobits
	.align	2
	.type	value, @object
	.size	value, 2
value:
	.zero	2
	.global	reladdr
	.section	.bss.reladdr,"aw",@nobits
	.align	2
	.type	reladdr, @object
	.size	reladdr, 2
reladdr:
	.zero	2
	.global	ea
	.section	.bss.ea,"aw",@nobits
	.align	2
	.type	ea, @object
	.size	ea, 2
ea:
	.zero	2
	.global	oldpc
	.section	.bss.oldpc,"aw",@nobits
	.align	2
	.type	oldpc, @object
	.size	oldpc, 2
oldpc:
	.zero	2
	.global	clockgoal6502
	.section	.bss.clockgoal6502,"aw",@nobits
	.align	4
	.type	clockgoal6502, @object
	.size	clockgoal6502, 4
clockgoal6502:
	.zero	4
	.global	clockticks6502
	.section	.bss.clockticks6502,"aw",@nobits
	.align	4
	.type	clockticks6502, @object
	.size	clockticks6502, 4
clockticks6502:
	.zero	4
	.global	instructions
	.section	.bss.instructions,"aw",@nobits
	.align	4
	.type	instructions, @object
	.size	instructions, 4
instructions:
	.zero	4
	.global	zero_ram
	.section	.bss.zero_ram,"aw",@nobits
	.type	zero_ram, @object
	.size	zero_ram, 512
zero_ram:
	.zero	512
	.global	last_modified_ram
	.section	.bss.last_modified_ram,"aw",@nobits
	.align	2
	.type	last_modified_ram, @object
	.size	last_modified_ram, 2
last_modified_ram:
	.zero	2
	.global	cpustatus
	.section	.bss.cpustatus,"aw",@nobits
	.align	2
	.type	cpustatus, @object
	.size	cpustatus, 2
cpustatus:
	.zero	2
	.global	sp
	.section	.bss.sp,"aw",@nobits
	.type	sp, @object
	.size	sp, 1
sp:
	.zero	1
	.global	y
	.section	.bss.y,"aw",@nobits
	.type	y, @object
	.size	y, 1
y:
	.zero	1
	.global	x
	.section	.bss.x,"aw",@nobits
	.type	x, @object
	.size	x, 1
x:
	.zero	1
	.global	a
	.section	.bss.a,"aw",@nobits
	.type	a, @object
	.size	a, 1
a:
	.zero	1
	.global	pc
	.section	.bss.pc,"aw",@nobits
	.align	2
	.type	pc, @object
	.size	pc, 2
pc:
	.zero	2
	.section	.debug_frame,"",@progbits
.Lframe0:
	.4byte	.LECIE0-.LSCIE0
.LSCIE0:
	.4byte	0xffffffff
	.byte	0x3
	.string	""
	.uleb128 0x1
	.sleb128 -4
	.uleb128 0
	.byte	0xc
	.uleb128 0x1
	.uleb128 0
	.align	4
.LECIE0:
.LSFDE0:
	.4byte	.LEFDE0-.LASFDE0
.LASFDE0:
	.4byte	.Lframe0
	.4byte	.LFB12
	.4byte	.LFE12-.LFB12
	.byte	0x4
	.4byte	.LCFI0-.LFB12
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI1-.LCFI0
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE0:
.LSFDE2:
	.4byte	.LEFDE2-.LASFDE2
.LASFDE2:
	.4byte	.Lframe0
	.4byte	.LFB13
	.4byte	.LFE13-.LFB13
	.byte	0x4
	.4byte	.LCFI2-.LFB13
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI3-.LCFI2
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE2:
.LSFDE4:
	.4byte	.LEFDE4-.LASFDE4
.LASFDE4:
	.4byte	.Lframe0
	.4byte	.LFB18
	.4byte	.LFE18-.LFB18
	.align	4
.LEFDE4:
.LSFDE6:
	.4byte	.LEFDE6-.LASFDE6
.LASFDE6:
	.4byte	.Lframe0
	.4byte	.LFB22
	.4byte	.LFE22-.LFB22
	.byte	0x4
	.4byte	.LCFI4-.LFB22
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI5-.LCFI4
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE6:
.LSFDE8:
	.4byte	.LEFDE8-.LASFDE8
.LASFDE8:
	.4byte	.Lframe0
	.4byte	.LFB23
	.4byte	.LFE23-.LFB23
	.byte	0x4
	.4byte	.LCFI6-.LFB23
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI7-.LCFI6
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE8:
.LSFDE10:
	.4byte	.LEFDE10-.LASFDE10
.LASFDE10:
	.4byte	.Lframe0
	.4byte	.LFB26
	.4byte	.LFE26-.LFB26
	.byte	0x4
	.4byte	.LCFI8-.LFB26
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI9-.LCFI8
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI10-.LCFI9
	.byte	0x80
	.uleb128 0x1
	.byte	0x8d
	.uleb128 0x3
	.align	4
.LEFDE10:
.LSFDE12:
	.4byte	.LEFDE12-.LASFDE12
.LASFDE12:
	.4byte	.Lframe0
	.4byte	.LFB27
	.4byte	.LFE27-.LFB27
	.byte	0x4
	.4byte	.LCFI11-.LFB27
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI12-.LCFI11
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI13-.LCFI12
	.byte	0x80
	.uleb128 0x1
	.byte	0x8d
	.uleb128 0x3
	.align	4
.LEFDE12:
.LSFDE14:
	.4byte	.LEFDE14-.LASFDE14
.LASFDE14:
	.4byte	.Lframe0
	.4byte	.LFB30
	.4byte	.LFE30-.LFB30
	.byte	0x4
	.4byte	.LCFI14-.LFB30
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI15-.LCFI14
	.byte	0x80
	.uleb128 0x1
	.byte	0x8c
	.uleb128 0x2
	.byte	0x8d
	.uleb128 0x3
	.align	4
.LEFDE14:
.LSFDE16:
	.4byte	.LEFDE16-.LASFDE16
.LASFDE16:
	.4byte	.Lframe0
	.4byte	.LFB31
	.4byte	.LFE31-.LFB31
	.byte	0x4
	.4byte	.LCFI16-.LFB31
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI17-.LCFI16
	.byte	0x80
	.uleb128 0x1
	.byte	0x8c
	.uleb128 0x2
	.byte	0x8d
	.uleb128 0x3
	.align	4
.LEFDE16:
.LSFDE18:
	.4byte	.LEFDE18-.LASFDE18
.LASFDE18:
	.4byte	.Lframe0
	.4byte	.LFB35
	.4byte	.LFE35-.LFB35
	.byte	0x4
	.4byte	.LCFI18-.LFB35
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI19-.LCFI18
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE18:
.LSFDE20:
	.4byte	.LEFDE20-.LASFDE20
.LASFDE20:
	.4byte	.Lframe0
	.4byte	.LFB36
	.4byte	.LFE36-.LFB36
	.byte	0x4
	.4byte	.LCFI20-.LFB36
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI21-.LCFI20
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE20:
.LSFDE22:
	.4byte	.LEFDE22-.LASFDE22
.LASFDE22:
	.4byte	.Lframe0
	.4byte	.LFB37
	.4byte	.LFE37-.LFB37
	.byte	0x4
	.4byte	.LCFI22-.LFB37
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI23-.LCFI22
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI24-.LCFI23
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE22:
.LSFDE24:
	.4byte	.LEFDE24-.LASFDE24
.LASFDE24:
	.4byte	.Lframe0
	.4byte	.LFB52
	.4byte	.LFE52-.LFB52
	.byte	0x4
	.4byte	.LCFI25-.LFB52
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI26-.LCFI25
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE24:
.LSFDE26:
	.4byte	.LEFDE26-.LASFDE26
.LASFDE26:
	.4byte	.Lframe0
	.4byte	.LFB55
	.4byte	.LFE55-.LFB55
	.byte	0x4
	.4byte	.LCFI27-.LFB55
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI28-.LCFI27
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI29-.LCFI28
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE26:
.LSFDE28:
	.4byte	.LEFDE28-.LASFDE28
.LASFDE28:
	.4byte	.Lframe0
	.4byte	.LFB58
	.4byte	.LFE58-.LFB58
	.byte	0x4
	.4byte	.LCFI30-.LFB58
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI31-.LCFI30
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE28:
.LSFDE30:
	.4byte	.LEFDE30-.LASFDE30
.LASFDE30:
	.4byte	.Lframe0
	.4byte	.LFB59
	.4byte	.LFE59-.LFB59
	.byte	0x4
	.4byte	.LCFI32-.LFB59
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI33-.LCFI32
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI34-.LCFI33
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE30:
.LSFDE32:
	.4byte	.LEFDE32-.LASFDE32
.LASFDE32:
	.4byte	.Lframe0
	.4byte	.LFB64
	.4byte	.LFE64-.LFB64
	.byte	0x4
	.4byte	.LCFI35-.LFB64
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI36-.LCFI35
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE32:
.LSFDE34:
	.4byte	.LEFDE34-.LASFDE34
.LASFDE34:
	.4byte	.Lframe0
	.4byte	.LFB67
	.4byte	.LFE67-.LFB67
	.byte	0x4
	.4byte	.LCFI37-.LFB67
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI38-.LCFI37
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI39-.LCFI38
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE34:
.LSFDE36:
	.4byte	.LEFDE36-.LASFDE36
.LASFDE36:
	.4byte	.Lframe0
	.4byte	.LFB69
	.4byte	.LFE69-.LFB69
	.byte	0x4
	.4byte	.LCFI40-.LFB69
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI41-.LCFI40
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE36:
.LSFDE38:
	.4byte	.LEFDE38-.LASFDE38
.LASFDE38:
	.4byte	.Lframe0
	.4byte	.LFB74
	.4byte	.LFE74-.LFB74
	.byte	0x4
	.4byte	.LCFI42-.LFB74
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI43-.LCFI42
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI44-.LCFI43
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE38:
.LSFDE40:
	.4byte	.LEFDE40-.LASFDE40
.LASFDE40:
	.4byte	.Lframe0
	.4byte	.LFB75
	.4byte	.LFE75-.LFB75
	.byte	0x4
	.4byte	.LCFI45-.LFB75
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI46-.LCFI45
	.byte	0x8c
	.uleb128 0x2
	.byte	0x4
	.4byte	.LCFI47-.LCFI46
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE40:
.LSFDE42:
	.4byte	.LEFDE42-.LASFDE42
.LASFDE42:
	.4byte	.Lframe0
	.4byte	.LFB78
	.4byte	.LFE78-.LFB78
	.byte	0x4
	.4byte	.LCFI48-.LFB78
	.byte	0xe
	.uleb128 0x10
	.byte	0x4
	.4byte	.LCFI49-.LCFI48
	.byte	0x80
	.uleb128 0x1
	.align	4
.LEFDE42:
.LSFDE44:
	.4byte	.LEFDE44-.LASFDE44
.LASFDE44:
	.4byte	.Lframe0
	.4byte	.LFB101
	.4byte	.LFE101-.LFB101
	.byte	0x4
	.4byte	.LCFI50-.LFB101
	.byte	0xe
	.uleb128 0x30
	.byte	0x4
	.4byte	.LCFI51-.LCFI50
	.byte	0x80
	.uleb128 0x1
	.byte	0x8c
	.uleb128 0x2
	.byte	0x8d
	.uleb128 0x3
	.byte	0x8e
	.uleb128 0x4
	.byte	0x8f
	.uleb128 0x5
	.align	4
.LEFDE44:
.LSFDE46:
	.4byte	.LEFDE46-.LASFDE46
.LASFDE46:
	.4byte	.Lframe0
	.4byte	.LFB102
	.4byte	.LFE102-.LFB102
	.align	4
.LEFDE46:
.LSFDE48:
	.4byte	.LEFDE48-.LASFDE48
.LASFDE48:
	.4byte	.Lframe0
	.4byte	.LFB103
	.4byte	.LFE103-.LFB103
	.align	4
.LEFDE48:
.LSFDE50:
	.4byte	.LEFDE50-.LASFDE50
.LASFDE50:
	.4byte	.Lframe0
	.4byte	.LFB104
	.4byte	.LFE104-.LFB104
	.align	4
.LEFDE50:
.LSFDE52:
	.4byte	.LEFDE52-.LASFDE52
.LASFDE52:
	.4byte	.Lframe0
	.4byte	.LFB105
	.4byte	.LFE105-.LFB105
	.align	4
.LEFDE52:
.LSFDE54:
	.4byte	.LEFDE54-.LASFDE54
.LASFDE54:
	.4byte	.Lframe0
	.4byte	.LFB106
	.4byte	.LFE106-.LFB106
	.align	4
.LEFDE54:
.LSFDE56:
	.4byte	.LEFDE56-.LASFDE56
.LASFDE56:
	.4byte	.Lframe0
	.4byte	.LFB107
	.4byte	.LFE107-.LFB107
	.align	4
.LEFDE56:
.LSFDE58:
	.4byte	.LEFDE58-.LASFDE58
.LASFDE58:
	.4byte	.Lframe0
	.4byte	.LFB108
	.4byte	.LFE108-.LFB108
	.align	4
.LEFDE58:
.LSFDE60:
	.4byte	.LEFDE60-.LASFDE60
.LASFDE60:
	.4byte	.Lframe0
	.4byte	.LFB109
	.4byte	.LFE109-.LFB109
	.align	4
.LEFDE60:
	.text
.Letext0:
	.file 2 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\machine\\_default_types.h"
	.file 3 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\sys\\_stdint.h"
	.file 4 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\c++\\10.3.0\\cstdlib"
	.file 5 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\c++\\10.3.0\\bits\\std_abs.h"
	.file 6 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\c++\\10.3.0\\xtensa-lx106-elf\\bits\\c++config.h"
	.file 7 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\lib\\gcc\\xtensa-lx106-elf\\10.3.0\\include\\stddef.h"
	.file 8 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\stdlib.h"
	.file 9 "c:\\users\\corax\\appdata\\local\\arduino15\\packages\\esp8266\\tools\\xtensa-lx106-elf-gcc\\3.0.4-gcc10.3-1757bed\\xtensa-lx106-elf\\include\\c++\\10.3.0\\stdlib.h"
	.file 10 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.4byte	0x424c
	.2byte	0x4
	.4byte	.Ldebug_abbrev0
	.byte	0x4
	.uleb128 0x1
	.4byte	.LASF198
	.byte	0x4
	.4byte	.LASF199
	.4byte	.LASF200
	.4byte	.Ldebug_ranges0+0x1318
	.4byte	0
	.4byte	.Ldebug_line0
	.uleb128 0x2
	.byte	0x1
	.byte	0x6
	.4byte	.LASF0
	.uleb128 0x3
	.4byte	.LASF3
	.byte	0x2
	.byte	0x17
	.byte	0x17
	.4byte	0x38
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.4byte	.LASF1
	.uleb128 0x2
	.byte	0x2
	.byte	0x5
	.4byte	.LASF2
	.uleb128 0x3
	.4byte	.LASF4
	.byte	0x2
	.byte	0x1b
	.byte	0x18
	.4byte	0x52
	.uleb128 0x2
	.byte	0x2
	.byte	0x7
	.4byte	.LASF5
	.uleb128 0x3
	.4byte	.LASF6
	.byte	0x2
	.byte	0x1e
	.byte	0x14
	.4byte	0x65
	.uleb128 0x4
	.byte	0x4
	.byte	0x5
	.string	"int"
	.uleb128 0x3
	.4byte	.LASF7
	.byte	0x2
	.byte	0x1f
	.byte	0x16
	.4byte	0x78
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.4byte	.LASF8
	.uleb128 0x2
	.byte	0x8
	.byte	0x5
	.4byte	.LASF9
	.uleb128 0x2
	.byte	0x8
	.byte	0x7
	.4byte	.LASF10
	.uleb128 0x3
	.4byte	.LASF11
	.byte	0x3
	.byte	0x18
	.byte	0x13
	.4byte	0x2c
	.uleb128 0x3
	.4byte	.LASF12
	.byte	0x3
	.byte	0x24
	.byte	0x14
	.4byte	0x46
	.uleb128 0x3
	.4byte	.LASF13
	.byte	0x3
	.byte	0x2c
	.byte	0x13
	.4byte	0x59
	.uleb128 0x3
	.4byte	.LASF14
	.byte	0x3
	.byte	0x30
	.byte	0x14
	.4byte	0x6c
	.uleb128 0x5
	.string	"std"
	.byte	0xa
	.byte	0
	.4byte	0x268
	.uleb128 0x6
	.4byte	.LASF20
	.byte	0x6
	.2byte	0x11e
	.byte	0x41
	.uleb128 0x7
	.byte	0x6
	.2byte	0x11e
	.byte	0x41
	.4byte	0xc8
	.uleb128 0x8
	.byte	0x4
	.byte	0x7f
	.byte	0xb
	.4byte	0x34a
	.uleb128 0x8
	.byte	0x4
	.byte	0x80
	.byte	0xb
	.4byte	0x37e
	.uleb128 0x8
	.byte	0x4
	.byte	0x86
	.byte	0xb
	.4byte	0x3eb
	.uleb128 0x8
	.byte	0x4
	.byte	0x8c
	.byte	0xb
	.4byte	0x401
	.uleb128 0x8
	.byte	0x4
	.byte	0x8d
	.byte	0xb
	.4byte	0x41e
	.uleb128 0x8
	.byte	0x4
	.byte	0x8e
	.byte	0xb
	.4byte	0x434
	.uleb128 0x8
	.byte	0x4
	.byte	0x8f
	.byte	0xb
	.4byte	0x44a
	.uleb128 0x8
	.byte	0x4
	.byte	0x91
	.byte	0xb
	.4byte	0x474
	.uleb128 0x8
	.byte	0x4
	.byte	0x94
	.byte	0xb
	.4byte	0x48f
	.uleb128 0x8
	.byte	0x4
	.byte	0x96
	.byte	0xb
	.4byte	0x4a5
	.uleb128 0x8
	.byte	0x4
	.byte	0x99
	.byte	0xb
	.4byte	0x4c0
	.uleb128 0x8
	.byte	0x4
	.byte	0x9a
	.byte	0xb
	.4byte	0x4db
	.uleb128 0x8
	.byte	0x4
	.byte	0x9b
	.byte	0xb
	.4byte	0x50d
	.uleb128 0x8
	.byte	0x4
	.byte	0x9d
	.byte	0xb
	.4byte	0x52d
	.uleb128 0x8
	.byte	0x4
	.byte	0xa3
	.byte	0xb
	.4byte	0x54e
	.uleb128 0x8
	.byte	0x4
	.byte	0xa5
	.byte	0xb
	.4byte	0x55a
	.uleb128 0x8
	.byte	0x4
	.byte	0xa6
	.byte	0xb
	.4byte	0x56c
	.uleb128 0x8
	.byte	0x4
	.byte	0xa7
	.byte	0xb
	.4byte	0x58d
	.uleb128 0x8
	.byte	0x4
	.byte	0xa8
	.byte	0xb
	.4byte	0x5ad
	.uleb128 0x8
	.byte	0x4
	.byte	0xa9
	.byte	0xb
	.4byte	0x5cd
	.uleb128 0x8
	.byte	0x4
	.byte	0xab
	.byte	0xb
	.4byte	0x5e3
	.uleb128 0x8
	.byte	0x4
	.byte	0xac
	.byte	0xb
	.4byte	0x609
	.uleb128 0x8
	.byte	0x4
	.byte	0xf0
	.byte	0x16
	.4byte	0x3b2
	.uleb128 0x8
	.byte	0x4
	.byte	0xf5
	.byte	0x16
	.4byte	0x2bf
	.uleb128 0x8
	.byte	0x4
	.byte	0xf6
	.byte	0x16
	.4byte	0x624
	.uleb128 0x8
	.byte	0x4
	.byte	0xf8
	.byte	0x16
	.4byte	0x640
	.uleb128 0x8
	.byte	0x4
	.byte	0xf9
	.byte	0x16
	.4byte	0x699
	.uleb128 0x8
	.byte	0x4
	.byte	0xfa
	.byte	0x16
	.4byte	0x657
	.uleb128 0x8
	.byte	0x4
	.byte	0xfb
	.byte	0x16
	.4byte	0x678
	.uleb128 0x8
	.byte	0x4
	.byte	0xfc
	.byte	0x16
	.4byte	0x6bb
	.uleb128 0x9
	.string	"abs"
	.byte	0x5
	.byte	0x4f
	.byte	0x3
	.4byte	.LASF15
	.4byte	0x2e7
	.4byte	0x1e4
	.uleb128 0xa
	.4byte	0x2e7
	.byte	0
	.uleb128 0x9
	.string	"abs"
	.byte	0x5
	.byte	0x4b
	.byte	0x3
	.4byte	.LASF16
	.4byte	0x6b4
	.4byte	0x1fe
	.uleb128 0xa
	.4byte	0x6b4
	.byte	0
	.uleb128 0x9
	.string	"abs"
	.byte	0x5
	.byte	0x47
	.byte	0x3
	.4byte	.LASF17
	.4byte	0x417
	.4byte	0x218
	.uleb128 0xa
	.4byte	0x417
	.byte	0
	.uleb128 0x9
	.string	"abs"
	.byte	0x5
	.byte	0x3d
	.byte	0x3
	.4byte	.LASF18
	.4byte	0x7f
	.4byte	0x232
	.uleb128 0xa
	.4byte	0x7f
	.byte	0
	.uleb128 0x9
	.string	"abs"
	.byte	0x5
	.byte	0x38
	.byte	0x3
	.4byte	.LASF19
	.4byte	0x2f3
	.4byte	0x24c
	.uleb128 0xa
	.4byte	0x2f3
	.byte	0
	.uleb128 0xb
	.string	"div"
	.byte	0x4
	.byte	0xb1
	.byte	0x3
	.4byte	.LASF21
	.4byte	0x37e
	.uleb128 0xa
	.4byte	0x2f3
	.uleb128 0xa
	.4byte	0x2f3
	.byte	0
	.byte	0
	.uleb128 0xc
	.4byte	.LASF201
	.byte	0x6
	.2byte	0x120
	.byte	0xb
	.4byte	0x2db
	.uleb128 0x6
	.4byte	.LASF20
	.byte	0x6
	.2byte	0x122
	.byte	0x41
	.uleb128 0x7
	.byte	0x6
	.2byte	0x122
	.byte	0x41
	.4byte	0x275
	.uleb128 0x8
	.byte	0x4
	.byte	0xc8
	.byte	0xb
	.4byte	0x3b2
	.uleb128 0x8
	.byte	0x4
	.byte	0xd8
	.byte	0xb
	.4byte	0x624
	.uleb128 0x8
	.byte	0x4
	.byte	0xe3
	.byte	0xb
	.4byte	0x640
	.uleb128 0x8
	.byte	0x4
	.byte	0xe4
	.byte	0xb
	.4byte	0x657
	.uleb128 0x8
	.byte	0x4
	.byte	0xe5
	.byte	0xb
	.4byte	0x678
	.uleb128 0x8
	.byte	0x4
	.byte	0xe7
	.byte	0xb
	.4byte	0x699
	.uleb128 0x8
	.byte	0x4
	.byte	0xe8
	.byte	0xb
	.4byte	0x6bb
	.uleb128 0xb
	.string	"div"
	.byte	0x4
	.byte	0xd5
	.byte	0x3
	.4byte	.LASF22
	.4byte	0x3b2
	.uleb128 0xa
	.4byte	0x7f
	.uleb128 0xa
	.4byte	0x7f
	.byte	0
	.byte	0
	.uleb128 0x3
	.4byte	.LASF23
	.byte	0x7
	.byte	0xd1
	.byte	0x17
	.4byte	0x78
	.uleb128 0x2
	.byte	0x8
	.byte	0x4
	.4byte	.LASF24
	.uleb128 0xd
	.4byte	.LASF202
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.4byte	.LASF25
	.uleb128 0xe
	.byte	0x4
	.uleb128 0x2
	.byte	0x4
	.byte	0x7
	.4byte	.LASF26
	.uleb128 0xf
	.byte	0x4
	.4byte	0x309
	.uleb128 0x10
	.uleb128 0xf
	.byte	0x4
	.4byte	0x310
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.4byte	.LASF27
	.uleb128 0x11
	.4byte	0x310
	.uleb128 0xf
	.byte	0x4
	.4byte	0x317
	.uleb128 0x12
	.byte	0x8
	.byte	0x8
	.byte	0x24
	.byte	0x1
	.4byte	.LASF30
	.4byte	0x34a
	.uleb128 0x13
	.4byte	.LASF28
	.byte	0x8
	.byte	0x25
	.byte	0x7
	.4byte	0x65
	.byte	0
	.uleb128 0x14
	.string	"rem"
	.byte	0x8
	.byte	0x26
	.byte	0x7
	.4byte	0x65
	.byte	0x4
	.byte	0
	.uleb128 0x3
	.4byte	.LASF29
	.byte	0x8
	.byte	0x27
	.byte	0x3
	.4byte	0x322
	.uleb128 0x12
	.byte	0x8
	.byte	0x8
	.byte	0x2a
	.byte	0x1
	.4byte	.LASF31
	.4byte	0x37e
	.uleb128 0x13
	.4byte	.LASF28
	.byte	0x8
	.byte	0x2b
	.byte	0x8
	.4byte	0x2f3
	.byte	0
	.uleb128 0x14
	.string	"rem"
	.byte	0x8
	.byte	0x2c
	.byte	0x8
	.4byte	0x2f3
	.byte	0x4
	.byte	0
	.uleb128 0x3
	.4byte	.LASF32
	.byte	0x8
	.byte	0x2d
	.byte	0x3
	.4byte	0x356
	.uleb128 0x12
	.byte	0x10
	.byte	0x8
	.byte	0x31
	.byte	0x1
	.4byte	.LASF33
	.4byte	0x3b2
	.uleb128 0x13
	.4byte	.LASF28
	.byte	0x8
	.byte	0x32
	.byte	0x11
	.4byte	0x7f
	.byte	0
	.uleb128 0x14
	.string	"rem"
	.byte	0x8
	.byte	0x33
	.byte	0x11
	.4byte	0x7f
	.byte	0x8
	.byte	0
	.uleb128 0x3
	.4byte	.LASF34
	.byte	0x8
	.byte	0x34
	.byte	0x3
	.4byte	0x38a
	.uleb128 0x3
	.4byte	.LASF35
	.byte	0x8
	.byte	0x39
	.byte	0xf
	.4byte	0x3ca
	.uleb128 0xf
	.byte	0x4
	.4byte	0x3d0
	.uleb128 0x15
	.4byte	0x65
	.4byte	0x3e4
	.uleb128 0xa
	.4byte	0x3e4
	.uleb128 0xa
	.4byte	0x3e4
	.byte	0
	.uleb128 0xf
	.byte	0x4
	.4byte	0x3ea
	.uleb128 0x16
	.uleb128 0x17
	.4byte	.LASF36
	.byte	0x8
	.byte	0x50
	.byte	0x5
	.4byte	0x65
	.4byte	0x401
	.uleb128 0xa
	.4byte	0x303
	.byte	0
	.uleb128 0x17
	.4byte	.LASF37
	.byte	0x8
	.byte	0x51
	.byte	0x8
	.4byte	0x417
	.4byte	0x417
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x2
	.byte	0x8
	.byte	0x4
	.4byte	.LASF38
	.uleb128 0x17
	.4byte	.LASF39
	.byte	0x8
	.byte	0x55
	.byte	0x5
	.4byte	0x65
	.4byte	0x434
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x17
	.4byte	.LASF40
	.byte	0x8
	.byte	0x57
	.byte	0x6
	.4byte	0x2f3
	.4byte	0x44a
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x17
	.4byte	.LASF41
	.byte	0x8
	.byte	0x59
	.byte	0x8
	.4byte	0x2fa
	.4byte	0x474
	.uleb128 0xa
	.4byte	0x3e4
	.uleb128 0xa
	.4byte	0x3e4
	.uleb128 0xa
	.4byte	0x2db
	.uleb128 0xa
	.4byte	0x2db
	.uleb128 0xa
	.4byte	0x3be
	.byte	0
	.uleb128 0x18
	.string	"div"
	.byte	0x8
	.byte	0x60
	.byte	0x7
	.4byte	0x34a
	.4byte	0x48f
	.uleb128 0xa
	.4byte	0x65
	.uleb128 0xa
	.4byte	0x65
	.byte	0
	.uleb128 0x17
	.4byte	.LASF42
	.byte	0x8
	.byte	0x63
	.byte	0x9
	.4byte	0x30a
	.4byte	0x4a5
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x17
	.4byte	.LASF43
	.byte	0x8
	.byte	0x6f
	.byte	0x8
	.4byte	0x37e
	.4byte	0x4c0
	.uleb128 0xa
	.4byte	0x2f3
	.uleb128 0xa
	.4byte	0x2f3
	.byte	0
	.uleb128 0x17
	.4byte	.LASF44
	.byte	0x8
	.byte	0x71
	.byte	0x5
	.4byte	0x65
	.4byte	0x4db
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x2db
	.byte	0
	.uleb128 0x17
	.4byte	.LASF45
	.byte	0x8
	.byte	0x77
	.byte	0x8
	.4byte	0x2db
	.4byte	0x4fb
	.uleb128 0xa
	.4byte	0x4fb
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x2db
	.byte	0
	.uleb128 0xf
	.byte	0x4
	.4byte	0x501
	.uleb128 0x2
	.byte	0x2
	.byte	0x7
	.4byte	.LASF46
	.uleb128 0x11
	.4byte	0x501
	.uleb128 0x17
	.4byte	.LASF47
	.byte	0x8
	.byte	0x73
	.byte	0x5
	.4byte	0x65
	.4byte	0x52d
	.uleb128 0xa
	.4byte	0x4fb
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x2db
	.byte	0
	.uleb128 0x19
	.4byte	.LASF48
	.byte	0x8
	.byte	0x93
	.byte	0x6
	.4byte	0x54e
	.uleb128 0xa
	.4byte	0x2fa
	.uleb128 0xa
	.4byte	0x2db
	.uleb128 0xa
	.4byte	0x2db
	.uleb128 0xa
	.4byte	0x3be
	.byte	0
	.uleb128 0x1a
	.4byte	.LASF94
	.byte	0x8
	.byte	0x94
	.byte	0x5
	.4byte	0x65
	.uleb128 0x19
	.4byte	.LASF49
	.byte	0x8
	.byte	0xa3
	.byte	0x6
	.4byte	0x56c
	.uleb128 0xa
	.4byte	0x78
	.byte	0
	.uleb128 0x17
	.4byte	.LASF50
	.byte	0x8
	.byte	0xa4
	.byte	0x8
	.4byte	0x417
	.4byte	0x587
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.byte	0
	.uleb128 0xf
	.byte	0x4
	.4byte	0x30a
	.uleb128 0x17
	.4byte	.LASF51
	.byte	0x8
	.byte	0xaf
	.byte	0x6
	.4byte	0x2f3
	.4byte	0x5ad
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.uleb128 0xa
	.4byte	0x65
	.byte	0
	.uleb128 0x17
	.4byte	.LASF52
	.byte	0x8
	.byte	0xb1
	.byte	0xf
	.4byte	0x2fc
	.4byte	0x5cd
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.uleb128 0xa
	.4byte	0x65
	.byte	0
	.uleb128 0x17
	.4byte	.LASF53
	.byte	0x8
	.byte	0xc3
	.byte	0x5
	.4byte	0x65
	.4byte	0x5e3
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x17
	.4byte	.LASF54
	.byte	0x8
	.byte	0x79
	.byte	0x8
	.4byte	0x2db
	.4byte	0x603
	.uleb128 0xa
	.4byte	0x30a
	.uleb128 0xa
	.4byte	0x603
	.uleb128 0xa
	.4byte	0x2db
	.byte	0
	.uleb128 0xf
	.byte	0x4
	.4byte	0x508
	.uleb128 0x17
	.4byte	.LASF55
	.byte	0x8
	.byte	0x75
	.byte	0x5
	.4byte	0x65
	.4byte	0x624
	.uleb128 0xa
	.4byte	0x30a
	.uleb128 0xa
	.4byte	0x501
	.byte	0
	.uleb128 0x1b
	.4byte	.LASF56
	.byte	0x8
	.2byte	0x110
	.byte	0x9
	.4byte	0x3b2
	.4byte	0x640
	.uleb128 0xa
	.4byte	0x7f
	.uleb128 0xa
	.4byte	0x7f
	.byte	0
	.uleb128 0x1b
	.4byte	.LASF57
	.byte	0x8
	.2byte	0x10b
	.byte	0xb
	.4byte	0x7f
	.4byte	0x657
	.uleb128 0xa
	.4byte	0x31c
	.byte	0
	.uleb128 0x1b
	.4byte	.LASF58
	.byte	0x8
	.2byte	0x111
	.byte	0xb
	.4byte	0x7f
	.4byte	0x678
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.uleb128 0xa
	.4byte	0x65
	.byte	0
	.uleb128 0x1b
	.4byte	.LASF59
	.byte	0x8
	.2byte	0x115
	.byte	0x14
	.4byte	0x86
	.4byte	0x699
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.uleb128 0xa
	.4byte	0x65
	.byte	0
	.uleb128 0x17
	.4byte	.LASF60
	.byte	0x8
	.byte	0xa7
	.byte	0x7
	.4byte	0x6b4
	.4byte	0x6b4
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.byte	0
	.uleb128 0x2
	.byte	0x4
	.byte	0x4
	.4byte	.LASF61
	.uleb128 0x1b
	.4byte	.LASF62
	.byte	0x8
	.2byte	0x148
	.byte	0x14
	.4byte	0x2e7
	.4byte	0x6d7
	.uleb128 0xa
	.4byte	0x31c
	.uleb128 0xa
	.4byte	0x587
	.byte	0
	.uleb128 0x8
	.byte	0x9
	.byte	0x27
	.byte	0xc
	.4byte	0x3eb
	.uleb128 0x8
	.byte	0x9
	.byte	0x33
	.byte	0xc
	.4byte	0x34a
	.uleb128 0x8
	.byte	0x9
	.byte	0x34
	.byte	0xc
	.4byte	0x37e
	.uleb128 0x8
	.byte	0x9
	.byte	0x36
	.byte	0xc
	.4byte	0x1ca
	.uleb128 0x8
	.byte	0x9
	.byte	0x36
	.byte	0xc
	.4byte	0x1e4
	.uleb128 0x8
	.byte	0x9
	.byte	0x36
	.byte	0xc
	.4byte	0x1fe
	.uleb128 0x8
	.byte	0x9
	.byte	0x36
	.byte	0xc
	.4byte	0x218
	.uleb128 0x8
	.byte	0x9
	.byte	0x36
	.byte	0xc
	.4byte	0x232
	.uleb128 0x8
	.byte	0x9
	.byte	0x37
	.byte	0xc
	.4byte	0x401
	.uleb128 0x8
	.byte	0x9
	.byte	0x38
	.byte	0xc
	.4byte	0x41e
	.uleb128 0x8
	.byte	0x9
	.byte	0x39
	.byte	0xc
	.4byte	0x434
	.uleb128 0x8
	.byte	0x9
	.byte	0x3a
	.byte	0xc
	.4byte	0x44a
	.uleb128 0x8
	.byte	0x9
	.byte	0x3c
	.byte	0xc
	.4byte	0x2bf
	.uleb128 0x8
	.byte	0x9
	.byte	0x3c
	.byte	0xc
	.4byte	0x24c
	.uleb128 0x8
	.byte	0x9
	.byte	0x3c
	.byte	0xc
	.4byte	0x474
	.uleb128 0x8
	.byte	0x9
	.byte	0x3e
	.byte	0xc
	.4byte	0x48f
	.uleb128 0x8
	.byte	0x9
	.byte	0x40
	.byte	0xc
	.4byte	0x4a5
	.uleb128 0x8
	.byte	0x9
	.byte	0x43
	.byte	0xc
	.4byte	0x4c0
	.uleb128 0x8
	.byte	0x9
	.byte	0x44
	.byte	0xc
	.4byte	0x4db
	.uleb128 0x8
	.byte	0x9
	.byte	0x45
	.byte	0xc
	.4byte	0x50d
	.uleb128 0x8
	.byte	0x9
	.byte	0x47
	.byte	0xc
	.4byte	0x52d
	.uleb128 0x8
	.byte	0x9
	.byte	0x48
	.byte	0xc
	.4byte	0x54e
	.uleb128 0x8
	.byte	0x9
	.byte	0x4a
	.byte	0xc
	.4byte	0x55a
	.uleb128 0x8
	.byte	0x9
	.byte	0x4b
	.byte	0xc
	.4byte	0x56c
	.uleb128 0x8
	.byte	0x9
	.byte	0x4c
	.byte	0xc
	.4byte	0x58d
	.uleb128 0x8
	.byte	0x9
	.byte	0x4d
	.byte	0xc
	.4byte	0x5ad
	.uleb128 0x8
	.byte	0x9
	.byte	0x4e
	.byte	0xc
	.4byte	0x5cd
	.uleb128 0x8
	.byte	0x9
	.byte	0x50
	.byte	0xc
	.4byte	0x5e3
	.uleb128 0x8
	.byte	0x9
	.byte	0x51
	.byte	0xc
	.4byte	0x609
	.uleb128 0x1c
	.string	"pc"
	.byte	0x1
	.byte	0x31
	.byte	0xa
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	pc
	.uleb128 0x1c
	.string	"a"
	.byte	0x1
	.byte	0x32
	.byte	0x9
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	a
	.uleb128 0x1c
	.string	"x"
	.byte	0x1
	.byte	0x32
	.byte	0xc
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	x
	.uleb128 0x1c
	.string	"y"
	.byte	0x1
	.byte	0x32
	.byte	0xf
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	y
	.uleb128 0x1c
	.string	"sp"
	.byte	0x1
	.byte	0x33
	.byte	0x9
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	sp
	.uleb128 0x1d
	.4byte	.LASF63
	.byte	0x1
	.byte	0x34
	.byte	0xa
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	cpustatus
	.uleb128 0x1d
	.4byte	.LASF64
	.byte	0x1
	.byte	0x35
	.byte	0xa
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	last_modified_ram
	.uleb128 0x1e
	.4byte	0x8d
	.4byte	0x846
	.uleb128 0x1f
	.4byte	0x78
	.2byte	0x3fff
	.byte	0
	.uleb128 0x20
	.string	"RAM"
	.byte	0x1
	.byte	0x36
	.byte	0x10
	.4byte	0x835
	.uleb128 0x1e
	.4byte	0x8d
	.4byte	0x863
	.uleb128 0x1f
	.4byte	0x78
	.2byte	0x1ff
	.byte	0
	.uleb128 0x1d
	.4byte	.LASF65
	.byte	0x1
	.byte	0x39
	.byte	0x9
	.4byte	0x852
	.uleb128 0x5
	.byte	0x3
	.4byte	zero_ram
	.uleb128 0x1d
	.4byte	.LASF66
	.byte	0x1
	.byte	0x3c
	.byte	0xa
	.4byte	0xb1
	.uleb128 0x5
	.byte	0x3
	.4byte	instructions
	.uleb128 0x1d
	.4byte	.LASF67
	.byte	0x1
	.byte	0x3d
	.byte	0x9
	.4byte	0xa5
	.uleb128 0x5
	.byte	0x3
	.4byte	clockticks6502
	.uleb128 0x1d
	.4byte	.LASF68
	.byte	0x1
	.byte	0x3d
	.byte	0x1d
	.4byte	0xa5
	.uleb128 0x5
	.byte	0x3
	.4byte	clockgoal6502
	.uleb128 0x1d
	.4byte	.LASF69
	.byte	0x1
	.byte	0x3e
	.byte	0xa
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	oldpc
	.uleb128 0x1c
	.string	"ea"
	.byte	0x1
	.byte	0x3e
	.byte	0x11
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	ea
	.uleb128 0x1d
	.4byte	.LASF70
	.byte	0x1
	.byte	0x3e
	.byte	0x15
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	reladdr
	.uleb128 0x1d
	.4byte	.LASF71
	.byte	0x1
	.byte	0x3e
	.byte	0x1e
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	value
	.uleb128 0x1d
	.4byte	.LASF72
	.byte	0x1
	.byte	0x3e
	.byte	0x25
	.4byte	0x99
	.uleb128 0x5
	.byte	0x3
	.4byte	result
	.uleb128 0x1d
	.4byte	.LASF73
	.byte	0x1
	.byte	0x3f
	.byte	0x9
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	opcode
	.uleb128 0x1d
	.4byte	.LASF74
	.byte	0x1
	.byte	0x3f
	.byte	0x11
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	oldcpustatus
	.uleb128 0x1d
	.4byte	.LASF75
	.byte	0x1
	.byte	0x3f
	.byte	0x1f
	.4byte	0x8d
	.uleb128 0x5
	.byte	0x3
	.4byte	useaccum
	.uleb128 0x1e
	.4byte	0x310
	.4byte	0x94a
	.uleb128 0x21
	.4byte	0x78
	.byte	0xb
	.byte	0
	.uleb128 0x1d
	.4byte	.LASF76
	.byte	0x1
	.byte	0x40
	.byte	0x6
	.4byte	0x93a
	.uleb128 0x5
	.byte	0x3
	.4byte	str_buffer_6502
	.uleb128 0x22
	.4byte	.LASF77
	.byte	0x1
	.2byte	0x5f0
	.byte	0xa
	.4byte	.LASF79
	.4byte	0x99
	.4byte	.LFB109
	.4byte	.LFE109-.LFB109
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x23
	.4byte	.LASF89
	.byte	0x1
	.2byte	0x5ec
	.byte	0x6
	.4byte	.LASF91
	.4byte	.LFB108
	.4byte	.LFE108-.LFB108
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x9ad
	.uleb128 0x24
	.string	"i"
	.byte	0x1
	.2byte	0x5ec
	.byte	0x1a
	.4byte	0x99
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x24
	.string	"v"
	.byte	0x1
	.2byte	0x5ec
	.byte	0x25
	.4byte	0x8d
	.uleb128 0x1
	.byte	0x53
	.byte	0
	.uleb128 0x25
	.4byte	.LASF203
	.byte	0x1
	.2byte	0x5e8
	.byte	0x9
	.4byte	.LASF204
	.4byte	0x8d
	.4byte	.LFB107
	.4byte	.LFE107-.LFB107
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x9e0
	.uleb128 0x26
	.string	"i"
	.byte	0x1
	.2byte	0x5e8
	.byte	0x1d
	.4byte	0x99
	.4byte	.LLST172
	.4byte	.LVUS172
	.byte	0
	.uleb128 0x22
	.4byte	.LASF78
	.byte	0x1
	.2byte	0x5e4
	.byte	0x9
	.4byte	.LASF80
	.4byte	0x8d
	.4byte	.LFB106
	.4byte	.LFE106-.LFB106
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x22
	.4byte	.LASF81
	.byte	0x1
	.2byte	0x5e0
	.byte	0x9
	.4byte	.LASF82
	.4byte	0x8d
	.4byte	.LFB105
	.4byte	.LFE105-.LFB105
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x22
	.4byte	.LASF83
	.byte	0x1
	.2byte	0x5dc
	.byte	0x9
	.4byte	.LASF84
	.4byte	0x8d
	.4byte	.LFB104
	.4byte	.LFE104-.LFB104
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x22
	.4byte	.LASF85
	.byte	0x1
	.2byte	0x5d8
	.byte	0x9
	.4byte	.LASF86
	.4byte	0x8d
	.4byte	.LFB103
	.4byte	.LFE103-.LFB103
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x22
	.4byte	.LASF87
	.byte	0x1
	.2byte	0x5d4
	.byte	0xa
	.4byte	.LASF88
	.4byte	0x99
	.4byte	.LFB102
	.4byte	.LFE102-.LFB102
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x23
	.4byte	.LASF90
	.byte	0x1
	.2byte	0x2c8
	.byte	0x6
	.4byte	.LASF92
	.4byte	.LFB101
	.4byte	.LFE101-.LFB101
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3343
	.uleb128 0x27
	.4byte	.LASF93
	.byte	0x1
	.2byte	0x2c8
	.byte	0x17
	.4byte	0xa5
	.4byte	.LLST37
	.4byte	.LVUS37
	.uleb128 0x28
	.4byte	0x3997
	.4byte	.LBI1050
	.2byte	.LVU1036
	.4byte	.LBB1050
	.4byte	.LBE1050-.LBB1050
	.byte	0x1
	.2byte	0x2d2
	.byte	0xa
	.4byte	0xb8e
	.uleb128 0x29
	.4byte	0x3e5c
	.4byte	.LBI1052
	.2byte	.LVU1068
	.4byte	.Ldebug_ranges0+0x4c0
	.byte	0x1
	.2byte	0x147
	.byte	0xb
	.4byte	0xb25
	.uleb128 0x2a
	.4byte	0x3e6d
	.4byte	.LLST38
	.4byte	.LVUS38
	.uleb128 0x2b
	.4byte	0x3e7a
	.4byte	.LBI1054
	.2byte	.LVU1070
	.4byte	.Ldebug_ranges0+0x500
	.byte	0x1
	.byte	0x6c
	.byte	0xe
	.4byte	0xaff
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST39
	.4byte	.LVUS39
	.uleb128 0x2c
	.4byte	0x3e8b
	.byte	0
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1061
	.2byte	.LVU1077
	.4byte	.Ldebug_ranges0+0x528
	.byte	0x1
	.byte	0x6d
	.byte	0xe
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST40
	.4byte	.LVUS40
	.uleb128 0x2c
	.4byte	0x3e8b
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3e3e
	.4byte	.LBI1074
	.2byte	.LVU1086
	.4byte	.Ldebug_ranges0+0x540
	.byte	0x1
	.2byte	0x148
	.byte	0xa
	.4byte	0xb67
	.uleb128 0x2c
	.4byte	0x3e4f
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1076
	.2byte	.LVU1088
	.4byte	.Ldebug_ranges0+0x588
	.byte	0x1
	.byte	0x72
	.byte	0xe
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST41
	.4byte	.LVUS41
	.byte	0
	.byte	0
	.uleb128 0x2e
	.4byte	.LVL130
	.4byte	0x3ea4
	.4byte	0xb7c
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x3
	.byte	0xa
	.2byte	0xfffe
	.byte	0
	.uleb128 0x30
	.4byte	.LVL131
	.4byte	0x3ea4
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x3
	.byte	0xa
	.2byte	0xffff
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x364f
	.4byte	.LBI1102
	.2byte	.LVU1124
	.4byte	.LBB1102
	.4byte	.LBE1102-.LBB1102
	.byte	0x1
	.2byte	0x2e8
	.byte	0xa
	.4byte	0xbf8
	.uleb128 0x31
	.4byte	0x3e3e
	.4byte	.LBI1104
	.2byte	.LVU1126
	.4byte	.Ldebug_ranges0+0x5b0
	.byte	0x1
	.2byte	0x209
	.byte	0xa
	.uleb128 0x2a
	.4byte	0x3e4f
	.4byte	.LLST42
	.4byte	.LVUS42
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1106
	.2byte	.LVU1133
	.4byte	.Ldebug_ranges0+0x5d0
	.byte	0x1
	.byte	0x72
	.byte	0xe
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST43
	.4byte	.LVUS43
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST44
	.4byte	.LVUS44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1118
	.2byte	.LVU1147
	.4byte	.LBB1118
	.4byte	.LBE1118-.LBB1118
	.byte	0x1
	.2byte	0x2eb
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3dbe
	.4byte	.LBI1120
	.2byte	.LVU1156
	.4byte	.LBB1120
	.4byte	.LBE1120-.LBB1120
	.byte	0x1
	.2byte	0x2ef
	.byte	0xa
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1122
	.2byte	.LVU1176
	.4byte	.Ldebug_ranges0+0x5f8
	.byte	0x1
	.2byte	0x2fd
	.byte	0xa
	.4byte	0xc98
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1124
	.2byte	.LVU1181
	.4byte	.Ldebug_ranges0+0x620
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST45
	.4byte	.LVUS45
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1126
	.2byte	.LVU1193
	.4byte	.LBB1126
	.4byte	.LBE1126-.LBB1126
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0xc8d
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST46
	.4byte	.LVUS46
	.uleb128 0x34
	.4byte	.LVL156
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL149
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39a5
	.4byte	.LBI1135
	.2byte	.LVU1213
	.4byte	.Ldebug_ranges0+0x640
	.byte	0x1
	.2byte	0x2fe
	.byte	0xa
	.4byte	0xcc7
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1137
	.2byte	.LVU1217
	.4byte	.LBB1137
	.4byte	.LBE1137-.LBB1137
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x32
	.4byte	0x396d
	.4byte	.LBI1145
	.2byte	.LVU1256
	.4byte	.LBB1145
	.4byte	.LBE1145-.LBB1145
	.byte	0x1
	.2byte	0x314
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1147
	.2byte	.LVU1261
	.4byte	.LBB1147
	.4byte	.LBE1147-.LBB1147
	.byte	0x1
	.2byte	0x317
	.byte	0xb
	.4byte	0xd19
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST47
	.4byte	.LVUS47
	.uleb128 0x34
	.4byte	.LVL166
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL167
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x381f
	.4byte	.LBI1149
	.2byte	.LVU1301
	.4byte	.LBB1149
	.4byte	.LBE1149-.LBB1149
	.byte	0x1
	.2byte	0x32a
	.byte	0xa
	.4byte	0xdb4
	.uleb128 0x31
	.4byte	0x3e5c
	.4byte	.LBI1151
	.2byte	.LVU1310
	.4byte	.Ldebug_ranges0+0x660
	.byte	0x1
	.2byte	0x1cf
	.byte	0xb
	.uleb128 0x2a
	.4byte	0x3e6d
	.4byte	.LLST48
	.4byte	.LVUS48
	.uleb128 0x2b
	.4byte	0x3e7a
	.4byte	.LBI1153
	.2byte	.LVU1312
	.4byte	.Ldebug_ranges0+0x690
	.byte	0x1
	.byte	0x6c
	.byte	0xe
	.4byte	0xd85
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST49
	.4byte	.LVUS49
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST50
	.4byte	.LVUS50
	.byte	0
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1161
	.2byte	.LVU1326
	.4byte	.Ldebug_ranges0+0x6b8
	.byte	0x1
	.byte	0x6d
	.byte	0xe
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST51
	.4byte	.LVUS51
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST52
	.4byte	.LVUS52
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3bda
	.4byte	.LBI1177
	.2byte	.LVU1346
	.4byte	.LBB1177
	.4byte	.LBE1177-.LBB1177
	.byte	0x1
	.2byte	0x32d
	.byte	0xb
	.4byte	0xdf8
	.uleb128 0x35
	.4byte	0x3beb
	.4byte	.LLST53
	.4byte	.LVUS53
	.uleb128 0x34
	.4byte	.LVL180
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL182
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL183
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x39cf
	.4byte	.LBI1179
	.2byte	.LVU1371
	.4byte	.LBB1179
	.4byte	.LBE1179-.LBB1179
	.byte	0x1
	.2byte	0x335
	.byte	0xd
	.4byte	0xe44
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1181
	.2byte	.LVU1373
	.4byte	.Ldebug_ranges0+0x6e0
	.byte	0x1
	.2byte	0x123
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1183
	.2byte	.LVU1378
	.4byte	.Ldebug_ranges0+0x6f8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL186
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3633
	.4byte	.LBI1189
	.2byte	.LVU1414
	.4byte	.LBB1189
	.4byte	.LBE1189-.LBB1189
	.byte	0x1
	.2byte	0x343
	.byte	0xa
	.4byte	0xe81
	.uleb128 0x36
	.4byte	0x3e0b
	.4byte	.LBI1191
	.2byte	.LVU1416
	.4byte	.LBB1191
	.4byte	.LBE1191-.LBB1191
	.byte	0x1
	.2byte	0x214
	.byte	0x16
	.uleb128 0x34
	.4byte	.LVL191
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1193
	.2byte	.LVU1426
	.4byte	.LBB1193
	.4byte	.LBE1193-.LBB1193
	.byte	0x1
	.2byte	0x346
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3dbe
	.4byte	.LBI1195
	.2byte	.LVU1435
	.4byte	.LBB1195
	.4byte	.LBE1195-.LBB1195
	.byte	0x1
	.2byte	0x34a
	.byte	0xa
	.uleb128 0x28
	.4byte	0x39cf
	.4byte	.LBI1197
	.2byte	.LVU1445
	.4byte	.LBB1197
	.4byte	.LBE1197-.LBB1197
	.byte	0x1
	.2byte	0x351
	.byte	0xd
	.4byte	0xefb
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1199
	.2byte	.LVU1447
	.4byte	.Ldebug_ranges0+0x710
	.byte	0x1
	.2byte	0x123
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1201
	.2byte	.LVU1452
	.4byte	.Ldebug_ranges0+0x728
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL195
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1207
	.2byte	.LVU1487
	.4byte	.Ldebug_ranges0+0x740
	.byte	0x1
	.2byte	0x35e
	.byte	0xa
	.4byte	0xf6d
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1209
	.2byte	.LVU1492
	.4byte	.Ldebug_ranges0+0x768
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST54
	.4byte	.LVUS54
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1211
	.2byte	.LVU1504
	.4byte	.LBB1211
	.4byte	.LBE1211-.LBB1211
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0xf62
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST55
	.4byte	.LVUS55
	.uleb128 0x34
	.4byte	.LVL208
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL201
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39c1
	.4byte	.LBI1220
	.2byte	.LVU1524
	.4byte	.Ldebug_ranges0+0x788
	.byte	0x1
	.2byte	0x35f
	.byte	0xa
	.4byte	0xf9c
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1222
	.2byte	.LVU1528
	.4byte	.LBB1222
	.4byte	.LBE1222-.LBB1222
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x32
	.4byte	0x33dd
	.4byte	.LBI1230
	.2byte	.LVU1567
	.4byte	.LBB1230
	.4byte	.LBE1230-.LBB1230
	.byte	0x1
	.2byte	0x375
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1232
	.2byte	.LVU1572
	.4byte	.LBB1232
	.4byte	.LBE1232-.LBB1232
	.byte	0x1
	.2byte	0x378
	.byte	0xb
	.4byte	0xfee
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST56
	.4byte	.LVUS56
	.uleb128 0x34
	.4byte	.LVL218
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL219
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x3445
	.4byte	.LBI1234
	.2byte	.LVU1611
	.4byte	.LBB1234
	.4byte	.LBE1234-.LBB1234
	.byte	0x1
	.2byte	0x38b
	.byte	0xa
	.4byte	0x1068
	.uleb128 0x28
	.4byte	0x3e0b
	.4byte	.LBI1236
	.2byte	.LVU1613
	.4byte	.LBB1236
	.4byte	.LBE1236-.LBB1236
	.byte	0x1
	.2byte	0x22f
	.byte	0x16
	.4byte	0x102e
	.uleb128 0x34
	.4byte	.LVL226
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x31
	.4byte	0x3e1c
	.4byte	.LBI1238
	.2byte	.LVU1622
	.4byte	.Ldebug_ranges0+0x7a8
	.byte	0x1
	.2byte	0x230
	.byte	0x13
	.uleb128 0x37
	.4byte	.Ldebug_ranges0+0x7a8
	.uleb128 0x35
	.4byte	0x3e31
	.4byte	.LLST57
	.4byte	.LVUS57
	.uleb128 0x34
	.4byte	.LVL227
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL228
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x365d
	.4byte	.LBI1244
	.2byte	.LVU1673
	.4byte	.LBB1244
	.4byte	.LBE1244-.LBB1244
	.byte	0x1
	.2byte	0x3a1
	.byte	0xa
	.4byte	0x10d2
	.uleb128 0x31
	.4byte	0x3e3e
	.4byte	.LBI1246
	.2byte	.LVU1679
	.4byte	.Ldebug_ranges0+0x7c8
	.byte	0x1
	.2byte	0x205
	.byte	0xa
	.uleb128 0x2a
	.4byte	0x3e4f
	.4byte	.LLST58
	.4byte	.LVUS58
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1248
	.2byte	.LVU1682
	.4byte	.Ldebug_ranges0+0x7e8
	.byte	0x1
	.byte	0x72
	.byte	0xe
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST59
	.4byte	.LVUS59
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST60
	.4byte	.LVUS60
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1256
	.2byte	.LVU1697
	.4byte	.LBB1256
	.4byte	.LBE1256-.LBB1256
	.byte	0x1
	.2byte	0x3a4
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3dbe
	.4byte	.LBI1258
	.2byte	.LVU1706
	.4byte	.LBB1258
	.4byte	.LBE1258-.LBB1258
	.byte	0x1
	.2byte	0x3a8
	.byte	0xa
	.uleb128 0x32
	.4byte	0x382d
	.4byte	.LBI1260
	.2byte	.LVU1716
	.4byte	.LBB1260
	.4byte	.LBE1260-.LBB1260
	.byte	0x1
	.2byte	0x3af
	.byte	0xa
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1262
	.2byte	.LVU1734
	.4byte	.Ldebug_ranges0+0x800
	.byte	0x1
	.2byte	0x3bc
	.byte	0xa
	.4byte	0x1189
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1264
	.2byte	.LVU1739
	.4byte	.Ldebug_ranges0+0x828
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST61
	.4byte	.LVUS61
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1266
	.2byte	.LVU1751
	.4byte	.LBB1266
	.4byte	.LBE1266-.LBB1266
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x117e
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST62
	.4byte	.LVUS62
	.uleb128 0x34
	.4byte	.LVL254
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL247
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3989
	.4byte	.LBI1275
	.2byte	.LVU1771
	.4byte	.Ldebug_ranges0+0x848
	.byte	0x1
	.2byte	0x3bd
	.byte	0xa
	.4byte	0x11b8
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1277
	.2byte	.LVU1775
	.4byte	.LBB1277
	.4byte	.LBE1277-.LBB1277
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x32
	.4byte	0x3951
	.4byte	.LBI1285
	.2byte	.LVU1814
	.4byte	.LBB1285
	.4byte	.LBE1285-.LBB1285
	.byte	0x1
	.2byte	0x3d3
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1287
	.2byte	.LVU1819
	.4byte	.LBB1287
	.4byte	.LBE1287-.LBB1287
	.byte	0x1
	.2byte	0x3d6
	.byte	0xb
	.4byte	0x120a
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST63
	.4byte	.LVUS63
	.uleb128 0x34
	.4byte	.LVL264
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL265
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x3437
	.4byte	.LBI1289
	.2byte	.LVU1858
	.4byte	.LBB1289
	.4byte	.LBE1289-.LBB1289
	.byte	0x1
	.2byte	0x3e9
	.byte	0xa
	.4byte	0x125d
	.uleb128 0x36
	.4byte	0x3e1c
	.4byte	.LBI1291
	.2byte	.LVU1860
	.4byte	.LBB1291
	.4byte	.LBE1291-.LBB1291
	.byte	0x1
	.2byte	0x235
	.byte	0x13
	.uleb128 0x35
	.4byte	0x3e31
	.4byte	.LLST64
	.4byte	.LVUS64
	.uleb128 0x34
	.4byte	.LVL272
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL273
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3641
	.4byte	.LBI1293
	.2byte	.LVU1912
	.4byte	.LBB1293
	.4byte	.LBE1293-.LBB1293
	.byte	0x1
	.2byte	0x3ff
	.byte	0xa
	.4byte	0x129a
	.uleb128 0x36
	.4byte	0x3e0b
	.4byte	.LBI1295
	.2byte	.LVU1914
	.4byte	.LBB1295
	.4byte	.LBE1295-.LBB1295
	.byte	0x1
	.2byte	0x20d
	.byte	0xe
	.uleb128 0x34
	.4byte	.LVL282
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1297
	.2byte	.LVU1937
	.4byte	.LBB1297
	.4byte	.LBE1297-.LBB1297
	.byte	0x1
	.2byte	0x402
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3dbe
	.4byte	.LBI1299
	.2byte	.LVU1946
	.4byte	.LBB1299
	.4byte	.LBE1299-.LBB1299
	.byte	0x1
	.2byte	0x406
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3bf8
	.4byte	.LBI1301
	.2byte	.LVU1954
	.4byte	.LBB1301
	.4byte	.LBE1301-.LBB1301
	.byte	0x1
	.2byte	0x40c
	.byte	0xa
	.4byte	0x1322
	.uleb128 0x35
	.4byte	0x3c09
	.4byte	.LLST65
	.4byte	.LVUS65
	.uleb128 0x35
	.4byte	0x3c15
	.4byte	.LLST66
	.4byte	.LVUS66
	.uleb128 0x34
	.4byte	.LVL285
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL286
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL288
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL289
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x32
	.4byte	0x382d
	.4byte	.LBI1303
	.2byte	.LVU1983
	.4byte	.LBB1303
	.4byte	.LBE1303-.LBB1303
	.byte	0x1
	.2byte	0x40d
	.byte	0xa
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1305
	.2byte	.LVU2001
	.4byte	.Ldebug_ranges0+0x868
	.byte	0x1
	.2byte	0x41a
	.byte	0xa
	.4byte	0x13ab
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1307
	.2byte	.LVU2006
	.4byte	.Ldebug_ranges0+0x890
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST67
	.4byte	.LVUS67
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1309
	.2byte	.LVU2018
	.4byte	.LBB1309
	.4byte	.LBE1309-.LBB1309
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x13a0
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST68
	.4byte	.LVUS68
	.uleb128 0x34
	.4byte	.LVL302
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL295
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x397b
	.4byte	.LBI1318
	.2byte	.LVU2038
	.4byte	.Ldebug_ranges0+0x8b0
	.byte	0x1
	.2byte	0x41b
	.byte	0xa
	.4byte	0x13da
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1320
	.2byte	.LVU2042
	.4byte	.LBB1320
	.4byte	.LBE1320-.LBB1320
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x28
	.4byte	0x3ba4
	.4byte	.LBI1328
	.2byte	.LVU2062
	.4byte	.LBB1328
	.4byte	.LBE1328-.LBB1328
	.byte	0x1
	.2byte	0x41e
	.byte	0xb
	.4byte	0x1438
	.uleb128 0x35
	.4byte	0x3bb5
	.4byte	.LLST69
	.4byte	.LVUS69
	.uleb128 0x35
	.4byte	0x3bc1
	.4byte	.LLST70
	.4byte	.LVUS70
	.uleb128 0x35
	.4byte	0x3bcd
	.4byte	.LLST71
	.4byte	.LVUS71
	.uleb128 0x34
	.4byte	.LVL306
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL307
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL308
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x32
	.4byte	0x33c1
	.4byte	.LBI1330
	.2byte	.LVU2101
	.4byte	.LBB1330
	.4byte	.LBE1330-.LBB1330
	.byte	0x1
	.2byte	0x431
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1332
	.2byte	.LVU2106
	.4byte	.LBB1332
	.4byte	.LBE1332-.LBB1332
	.byte	0x1
	.2byte	0x434
	.byte	0xb
	.4byte	0x148a
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST72
	.4byte	.LVUS72
	.uleb128 0x34
	.4byte	.LVL315
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL316
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1334
	.2byte	.LVU2146
	.4byte	.LBB1334
	.4byte	.LBE1334-.LBB1334
	.byte	0x1
	.2byte	0x448
	.byte	0xa
	.4byte	0x154e
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1336
	.2byte	.LVU2148
	.4byte	.Ldebug_ranges0+0x8d0
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST73
	.4byte	.LVUS73
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1338
	.2byte	.LVU2157
	.4byte	.Ldebug_ranges0+0x8e8
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST74
	.4byte	.LVUS74
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1340
	.2byte	.LVU2159
	.4byte	.Ldebug_ranges0+0x900
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST75
	.4byte	.LVUS75
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST76
	.4byte	.LVUS76
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1342
	.2byte	.LVU2165
	.4byte	.LBB1342
	.4byte	.LBE1342-.LBB1342
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST77
	.4byte	.LVUS77
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST78
	.4byte	.LVUS78
	.uleb128 0x34
	.4byte	.LVL328
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3397
	.4byte	.LBI1352
	.2byte	.LVU2181
	.4byte	.LBB1352
	.4byte	.LBE1352-.LBB1352
	.byte	0x1
	.2byte	0x44f
	.byte	0xa
	.4byte	0x1616
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1354
	.2byte	.LVU2187
	.4byte	.Ldebug_ranges0+0x920
	.byte	0x1
	.2byte	0x25a
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST79
	.4byte	.LVUS79
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1356
	.2byte	.LVU2191
	.4byte	.LBB1356
	.4byte	.LBE1356-.LBB1356
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST80
	.4byte	.LVUS80
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1358
	.2byte	.LVU2196
	.4byte	.Ldebug_ranges0+0x940
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST81
	.4byte	.LVUS81
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST82
	.4byte	.LVUS82
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1360
	.2byte	.LVU2204
	.4byte	.LBB1360
	.4byte	.LBE1360-.LBB1360
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST83
	.4byte	.LVUS83
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST84
	.4byte	.LVUS84
	.uleb128 0x34
	.4byte	.LVL338
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1368
	.2byte	.LVU2220
	.4byte	.LBB1368
	.4byte	.LBE1368-.LBB1368
	.byte	0x1
	.2byte	0x453
	.byte	0xa
	.4byte	0x16da
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1370
	.2byte	.LVU2222
	.4byte	.Ldebug_ranges0+0x958
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST85
	.4byte	.LVUS85
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1372
	.2byte	.LVU2231
	.4byte	.Ldebug_ranges0+0x970
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST86
	.4byte	.LVUS86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1374
	.2byte	.LVU2233
	.4byte	.Ldebug_ranges0+0x988
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST87
	.4byte	.LVUS87
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST88
	.4byte	.LVUS88
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1376
	.2byte	.LVU2239
	.4byte	.LBB1376
	.4byte	.LBE1376-.LBB1376
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST89
	.4byte	.LVUS89
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST90
	.4byte	.LVUS90
	.uleb128 0x34
	.4byte	.LVL347
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x33a5
	.4byte	.LBI1386
	.2byte	.LVU2255
	.4byte	.LBB1386
	.4byte	.LBE1386-.LBB1386
	.byte	0x1
	.2byte	0x457
	.byte	0xa
	.4byte	0x17a2
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1388
	.2byte	.LVU2261
	.4byte	.Ldebug_ranges0+0x9a8
	.byte	0x1
	.2byte	0x256
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST91
	.4byte	.LVUS91
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1390
	.2byte	.LVU2265
	.4byte	.LBB1390
	.4byte	.LBE1390-.LBB1390
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST92
	.4byte	.LVUS92
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1392
	.2byte	.LVU2270
	.4byte	.Ldebug_ranges0+0x9c8
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST93
	.4byte	.LVUS93
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST94
	.4byte	.LVUS94
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1394
	.2byte	.LVU2278
	.4byte	.LBB1394
	.4byte	.LBE1394-.LBB1394
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST95
	.4byte	.LVUS95
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST96
	.4byte	.LVUS96
	.uleb128 0x34
	.4byte	.LVL357
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x38b1
	.4byte	.LBI1402
	.2byte	.LVU2293
	.4byte	.LBB1402
	.4byte	.LBE1402-.LBB1402
	.byte	0x1
	.2byte	0x45d
	.byte	0xa
	.uleb128 0x32
	.4byte	0x335f
	.4byte	.LBI1404
	.2byte	.LVU2313
	.4byte	.LBB1404
	.4byte	.LBE1404-.LBB1404
	.byte	0x1
	.2byte	0x461
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3397
	.4byte	.LBI1406
	.2byte	.LVU2334
	.4byte	.LBB1406
	.4byte	.LBE1406-.LBB1406
	.byte	0x1
	.2byte	0x467
	.byte	0xa
	.4byte	0x1898
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1408
	.2byte	.LVU2340
	.4byte	.Ldebug_ranges0+0x9e0
	.byte	0x1
	.2byte	0x25a
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST97
	.4byte	.LVUS97
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1410
	.2byte	.LVU2344
	.4byte	.LBB1410
	.4byte	.LBE1410-.LBB1410
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST98
	.4byte	.LVUS98
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1412
	.2byte	.LVU2349
	.4byte	.Ldebug_ranges0+0xa00
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST99
	.4byte	.LVUS99
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST100
	.4byte	.LVUS100
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1414
	.2byte	.LVU2357
	.4byte	.LBB1414
	.4byte	.LBE1414-.LBB1414
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST101
	.4byte	.LVUS101
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST102
	.4byte	.LVUS102
	.uleb128 0x34
	.4byte	.LVL367
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1422
	.2byte	.LVU2373
	.4byte	.LBB1422
	.4byte	.LBE1422-.LBB1422
	.byte	0x1
	.2byte	0x46b
	.byte	0xa
	.4byte	0x195c
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1424
	.2byte	.LVU2375
	.4byte	.Ldebug_ranges0+0xa18
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST103
	.4byte	.LVUS103
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1426
	.2byte	.LVU2384
	.4byte	.Ldebug_ranges0+0xa30
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST104
	.4byte	.LVUS104
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1428
	.2byte	.LVU2386
	.4byte	.Ldebug_ranges0+0xa48
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST105
	.4byte	.LVUS105
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST106
	.4byte	.LVUS106
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1430
	.2byte	.LVU2392
	.4byte	.LBB1430
	.4byte	.LBE1430-.LBB1430
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST107
	.4byte	.LVUS107
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST108
	.4byte	.LVUS108
	.uleb128 0x34
	.4byte	.LVL376
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x33a5
	.4byte	.LBI1440
	.2byte	.LVU2408
	.4byte	.LBB1440
	.4byte	.LBE1440-.LBB1440
	.byte	0x1
	.2byte	0x46f
	.byte	0xa
	.4byte	0x1a24
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1442
	.2byte	.LVU2414
	.4byte	.Ldebug_ranges0+0xa68
	.byte	0x1
	.2byte	0x256
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST109
	.4byte	.LVUS109
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1444
	.2byte	.LVU2418
	.4byte	.LBB1444
	.4byte	.LBE1444-.LBB1444
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST110
	.4byte	.LVUS110
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1446
	.2byte	.LVU2423
	.4byte	.Ldebug_ranges0+0xa88
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST111
	.4byte	.LVUS111
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST112
	.4byte	.LVUS112
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1448
	.2byte	.LVU2431
	.4byte	.LBB1448
	.4byte	.LBE1448-.LBB1448
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST113
	.4byte	.LVUS113
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST114
	.4byte	.LVUS114
	.uleb128 0x34
	.4byte	.LVL386
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1456
	.2byte	.LVU2445
	.4byte	.Ldebug_ranges0+0xaa0
	.byte	0x1
	.2byte	0x474
	.byte	0xa
	.4byte	0x1a96
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1458
	.2byte	.LVU2450
	.4byte	.Ldebug_ranges0+0xac8
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST115
	.4byte	.LVUS115
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1460
	.2byte	.LVU2462
	.4byte	.LBB1460
	.4byte	.LBE1460-.LBB1460
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x1a8b
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST116
	.4byte	.LVUS116
	.uleb128 0x34
	.4byte	.LVL398
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL391
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39f9
	.4byte	.LBI1469
	.2byte	.LVU2482
	.4byte	.Ldebug_ranges0+0xae8
	.byte	0x1
	.2byte	0x475
	.byte	0xa
	.4byte	0x1ac5
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1471
	.2byte	.LVU2486
	.4byte	.LBB1471
	.4byte	.LBE1471-.LBB1471
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1479
	.2byte	.LVU2508
	.4byte	.LBB1479
	.4byte	.LBE1479-.LBB1479
	.byte	0x1
	.2byte	0x479
	.byte	0xa
	.4byte	0x1b89
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1481
	.2byte	.LVU2510
	.4byte	.Ldebug_ranges0+0xb08
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST117
	.4byte	.LVUS117
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1483
	.2byte	.LVU2519
	.4byte	.Ldebug_ranges0+0xb20
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST118
	.4byte	.LVUS118
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1485
	.2byte	.LVU2521
	.4byte	.Ldebug_ranges0+0xb38
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST119
	.4byte	.LVUS119
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST120
	.4byte	.LVUS120
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1487
	.2byte	.LVU2527
	.4byte	.LBB1487
	.4byte	.LBE1487-.LBB1487
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST121
	.4byte	.LVUS121
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST122
	.4byte	.LVUS122
	.uleb128 0x34
	.4byte	.LVL407
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3397
	.4byte	.LBI1497
	.2byte	.LVU2543
	.4byte	.LBB1497
	.4byte	.LBE1497-.LBB1497
	.byte	0x1
	.2byte	0x480
	.byte	0xa
	.4byte	0x1c51
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1499
	.2byte	.LVU2549
	.4byte	.Ldebug_ranges0+0xb58
	.byte	0x1
	.2byte	0x25a
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST123
	.4byte	.LVUS123
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1501
	.2byte	.LVU2553
	.4byte	.LBB1501
	.4byte	.LBE1501-.LBB1501
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST124
	.4byte	.LVUS124
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1503
	.2byte	.LVU2558
	.4byte	.Ldebug_ranges0+0xb78
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST125
	.4byte	.LVUS125
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST126
	.4byte	.LVUS126
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1505
	.2byte	.LVU2566
	.4byte	.LBB1505
	.4byte	.LBE1505-.LBB1505
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST127
	.4byte	.LVUS127
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST128
	.4byte	.LVUS128
	.uleb128 0x34
	.4byte	.LVL417
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1513
	.2byte	.LVU2582
	.4byte	.LBB1513
	.4byte	.LBE1513-.LBB1513
	.byte	0x1
	.2byte	0x484
	.byte	0xa
	.4byte	0x1d15
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1515
	.2byte	.LVU2584
	.4byte	.Ldebug_ranges0+0xb90
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST129
	.4byte	.LVUS129
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1517
	.2byte	.LVU2593
	.4byte	.Ldebug_ranges0+0xba8
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST130
	.4byte	.LVUS130
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1519
	.2byte	.LVU2595
	.4byte	.Ldebug_ranges0+0xbc0
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST131
	.4byte	.LVUS131
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST132
	.4byte	.LVUS132
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1521
	.2byte	.LVU2601
	.4byte	.LBB1521
	.4byte	.LBE1521-.LBB1521
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST133
	.4byte	.LVUS133
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST134
	.4byte	.LVUS134
	.uleb128 0x34
	.4byte	.LVL426
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cbb
	.4byte	.LBI1531
	.2byte	.LVU2615
	.4byte	.Ldebug_ranges0+0xbe0
	.byte	0x1
	.2byte	0x487
	.byte	0xa
	.4byte	0x1d36
	.uleb128 0x34
	.4byte	.LVL430
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x29
	.4byte	0x33a5
	.4byte	.LBI1534
	.2byte	.LVU2626
	.4byte	.Ldebug_ranges0+0xbf8
	.byte	0x1
	.2byte	0x488
	.byte	0xa
	.4byte	0x1dc4
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1536
	.2byte	.LVU2630
	.4byte	.Ldebug_ranges0+0xc10
	.byte	0x1
	.2byte	0x256
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST135
	.4byte	.LVUS135
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1538
	.2byte	.LVU2634
	.4byte	.LBB1538
	.4byte	.LBE1538-.LBB1538
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST136
	.4byte	.LVUS136
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1540
	.2byte	.LVU2636
	.4byte	.LBB1540
	.4byte	.LBE1540-.LBB1540
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST137
	.4byte	.LVUS137
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST138
	.4byte	.LVUS138
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3343
	.4byte	.LBI1549
	.2byte	.LVU2649
	.4byte	.LBB1549
	.4byte	.LBE1549-.LBB1549
	.byte	0x1
	.2byte	0x48e
	.byte	0xa
	.uleb128 0x29
	.4byte	0x3c22
	.4byte	.LBI1551
	.2byte	.LVU2668
	.4byte	.Ldebug_ranges0+0xc30
	.byte	0x1
	.2byte	0x491
	.byte	0xb
	.4byte	0x1e18
	.uleb128 0x37
	.4byte	.Ldebug_ranges0+0xc30
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST139
	.4byte	.LVUS139
	.uleb128 0x34
	.4byte	.LVL434
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL435
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x33b3
	.4byte	.LBI1555
	.2byte	.LVU2693
	.4byte	.Ldebug_ranges0+0xc50
	.byte	0x1
	.2byte	0x492
	.byte	0xa
	.4byte	0x1ed8
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1557
	.2byte	.LVU2695
	.4byte	.Ldebug_ranges0+0xc70
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST140
	.4byte	.LVUS140
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1559
	.2byte	.LVU2702
	.4byte	.Ldebug_ranges0+0xc98
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST141
	.4byte	.LVUS141
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1561
	.2byte	.LVU2704
	.4byte	.Ldebug_ranges0+0xcb0
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST142
	.4byte	.LVUS142
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST143
	.4byte	.LVUS143
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1563
	.2byte	.LVU2711
	.4byte	.LBB1563
	.4byte	.LBE1563-.LBB1563
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST144
	.4byte	.LVUS144
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST145
	.4byte	.LVUS145
	.uleb128 0x34
	.4byte	.LVL444
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3351
	.4byte	.LBI1581
	.2byte	.LVU2727
	.4byte	.LBB1581
	.4byte	.LBE1581-.LBB1581
	.byte	0x1
	.2byte	0x496
	.byte	0xa
	.uleb128 0x28
	.4byte	0x33b3
	.4byte	.LBI1583
	.2byte	.LVU2735
	.4byte	.LBB1583
	.4byte	.LBE1583-.LBB1583
	.byte	0x1
	.2byte	0x49d
	.byte	0xa
	.4byte	0x1fb3
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1585
	.2byte	.LVU2737
	.4byte	.Ldebug_ranges0+0xcc8
	.byte	0x1
	.2byte	0x252
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST146
	.4byte	.LVUS146
	.uleb128 0x2d
	.4byte	0x3b75
	.4byte	.LBI1587
	.2byte	.LVU2746
	.4byte	.Ldebug_ranges0+0xce0
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST147
	.4byte	.LVUS147
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1589
	.2byte	.LVU2748
	.4byte	.Ldebug_ranges0+0xcf8
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST148
	.4byte	.LVUS148
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST149
	.4byte	.LVUS149
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1591
	.2byte	.LVU2754
	.4byte	.LBB1591
	.4byte	.LBE1591-.LBB1591
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST150
	.4byte	.LVUS150
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST151
	.4byte	.LVUS151
	.uleb128 0x34
	.4byte	.LVL453
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x39
	.4byte	0x3db1
	.4byte	.LBI1601
	.2byte	.LVU2768
	.4byte	.Ldebug_ranges0+0xd18
	.byte	0x1
	.2byte	0x4a3
	.byte	0xa
	.uleb128 0x29
	.4byte	0x37b3
	.4byte	.LBI1604
	.2byte	.LVU2775
	.4byte	.Ldebug_ranges0+0xd30
	.byte	0x1
	.2byte	0x4a4
	.byte	0xa
	.4byte	0x200e
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1606
	.2byte	.LVU2777
	.4byte	.Ldebug_ranges0+0xd50
	.byte	0x1
	.2byte	0x1e4
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1607
	.2byte	.LVU2779
	.4byte	.Ldebug_ranges0+0xd78
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL457
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x39
	.4byte	0x3db1
	.4byte	.LBI1621
	.2byte	.LVU2807
	.4byte	.Ldebug_ranges0+0xd98
	.byte	0x1
	.2byte	0x4ab
	.byte	0xa
	.uleb128 0x29
	.4byte	0x37c1
	.4byte	.LBI1624
	.2byte	.LVU2814
	.4byte	.Ldebug_ranges0+0xdb0
	.byte	0x1
	.2byte	0x4ac
	.byte	0xa
	.4byte	0x2069
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1626
	.2byte	.LVU2816
	.4byte	.Ldebug_ranges0+0xdd0
	.byte	0x1
	.2byte	0x1dc
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1627
	.2byte	.LVU2818
	.4byte	.Ldebug_ranges0+0xdf8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL460
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x37b3
	.4byte	.LBI1641
	.2byte	.LVU2842
	.4byte	.LBB1641
	.4byte	.LBE1641-.LBB1641
	.byte	0x1
	.2byte	0x4b2
	.byte	0xa
	.4byte	0x20bd
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1643
	.2byte	.LVU2844
	.4byte	.LBB1643
	.4byte	.LBE1643-.LBB1643
	.byte	0x1
	.2byte	0x1e4
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1645
	.2byte	.LVU2849
	.4byte	.LBB1645
	.4byte	.LBE1645-.LBB1645
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL462
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x37c1
	.4byte	.LBI1647
	.2byte	.LVU2878
	.4byte	.LBB1647
	.4byte	.LBE1647-.LBB1647
	.byte	0x1
	.2byte	0x4ba
	.byte	0xa
	.4byte	0x2111
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1649
	.2byte	.LVU2880
	.4byte	.LBB1649
	.4byte	.LBE1649-.LBB1649
	.byte	0x1
	.2byte	0x1dc
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1651
	.2byte	.LVU2885
	.4byte	.LBB1651
	.4byte	.LBE1651-.LBB1651
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL466
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x337b
	.4byte	.LBI1653
	.2byte	.LVU2907
	.4byte	.LBB1653
	.4byte	.LBE1653-.LBB1653
	.byte	0x1
	.2byte	0x4c0
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1655
	.2byte	.LVU2926
	.4byte	.LBB1655
	.4byte	.LBE1655-.LBB1655
	.byte	0x1
	.2byte	0x4c3
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3389
	.4byte	.LBI1657
	.2byte	.LVU2936
	.4byte	.LBB1657
	.4byte	.LBE1657-.LBB1657
	.byte	0x1
	.2byte	0x4c8
	.byte	0xa
	.uleb128 0x28
	.4byte	0x37b3
	.4byte	.LBI1659
	.2byte	.LVU2957
	.4byte	.LBB1659
	.4byte	.LBE1659-.LBB1659
	.byte	0x1
	.2byte	0x4ce
	.byte	0xa
	.4byte	0x21aa
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1661
	.2byte	.LVU2959
	.4byte	.LBB1661
	.4byte	.LBE1661-.LBB1661
	.byte	0x1
	.2byte	0x1e4
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1663
	.2byte	.LVU2964
	.4byte	.LBB1663
	.4byte	.LBE1663-.LBB1663
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL469
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x37c1
	.4byte	.LBI1665
	.2byte	.LVU2993
	.4byte	.LBB1665
	.4byte	.LBE1665-.LBB1665
	.byte	0x1
	.2byte	0x4d6
	.byte	0xa
	.4byte	0x21fe
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1667
	.2byte	.LVU2995
	.4byte	.LBB1667
	.4byte	.LBE1667-.LBB1667
	.byte	0x1
	.2byte	0x1dc
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1669
	.2byte	.LVU3000
	.4byte	.LBB1669
	.4byte	.LBE1669-.LBB1669
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL473
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1671
	.2byte	.LVU3021
	.4byte	.Ldebug_ranges0+0xe18
	.byte	0x1
	.2byte	0x4db
	.byte	0xa
	.4byte	0x2270
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1673
	.2byte	.LVU3026
	.4byte	.Ldebug_ranges0+0xe40
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST152
	.4byte	.LVUS152
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1675
	.2byte	.LVU3038
	.4byte	.LBB1675
	.4byte	.LBE1675-.LBB1675
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x2265
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST153
	.4byte	.LVUS153
	.uleb128 0x34
	.4byte	.LVL482
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL475
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39eb
	.4byte	.LBI1684
	.2byte	.LVU3058
	.4byte	.Ldebug_ranges0+0xe60
	.byte	0x1
	.2byte	0x4dc
	.byte	0xa
	.4byte	0x229f
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1686
	.2byte	.LVU3062
	.4byte	.LBB1686
	.4byte	.LBE1686-.LBB1686
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x28
	.4byte	0x37b3
	.4byte	.LBI1694
	.2byte	.LVU3090
	.4byte	.LBB1694
	.4byte	.LBE1694-.LBB1694
	.byte	0x1
	.2byte	0x4e7
	.byte	0xa
	.4byte	0x22f3
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1696
	.2byte	.LVU3092
	.4byte	.LBB1696
	.4byte	.LBE1696-.LBB1696
	.byte	0x1
	.2byte	0x1e4
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1698
	.2byte	.LVU3097
	.4byte	.LBB1698
	.4byte	.LBE1698-.LBB1698
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL489
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cbb
	.4byte	.LBI1700
	.2byte	.LVU3124
	.4byte	.Ldebug_ranges0+0xe80
	.byte	0x1
	.2byte	0x4ee
	.byte	0xa
	.4byte	0x2314
	.uleb128 0x34
	.4byte	.LVL492
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x29
	.4byte	0x37c1
	.4byte	.LBI1704
	.2byte	.LVU3134
	.4byte	.Ldebug_ranges0+0xea0
	.byte	0x1
	.2byte	0x4ef
	.byte	0xa
	.4byte	0x2360
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1706
	.2byte	.LVU3136
	.4byte	.Ldebug_ranges0+0xec0
	.byte	0x1
	.2byte	0x1dc
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1708
	.2byte	.LVU3141
	.4byte	.LBB1708
	.4byte	.LBE1708-.LBB1708
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL493
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3943
	.4byte	.LBI1720
	.2byte	.LVU3163
	.4byte	.LBB1720
	.4byte	.LBE1720-.LBB1720
	.byte	0x1
	.2byte	0x4f5
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1722
	.2byte	.LVU3168
	.4byte	.LBB1722
	.4byte	.LBE1722-.LBB1722
	.byte	0x1
	.2byte	0x4f8
	.byte	0xb
	.4byte	0x23b2
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST154
	.4byte	.LVUS154
	.uleb128 0x34
	.4byte	.LVL494
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL495
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x32
	.4byte	0x336d
	.4byte	.LBI1724
	.2byte	.LVU3195
	.4byte	.LBB1724
	.4byte	.LBE1724-.LBB1724
	.byte	0x1
	.2byte	0x4fd
	.byte	0xa
	.uleb128 0x28
	.4byte	0x37b3
	.4byte	.LBI1726
	.2byte	.LVU3216
	.4byte	.LBB1726
	.4byte	.LBE1726-.LBB1726
	.byte	0x1
	.2byte	0x501
	.byte	0xa
	.4byte	0x241d
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1728
	.2byte	.LVU3218
	.4byte	.LBB1728
	.4byte	.LBE1728-.LBB1728
	.byte	0x1
	.2byte	0x1e4
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1730
	.2byte	.LVU3223
	.4byte	.LBB1730
	.4byte	.LBE1730-.LBB1730
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL499
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3c22
	.4byte	.LBI1732
	.2byte	.LVU3250
	.4byte	.Ldebug_ranges0+0xee0
	.byte	0x1
	.2byte	0x508
	.byte	0xb
	.4byte	0x245a
	.uleb128 0x37
	.4byte	.Ldebug_ranges0+0xee0
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST155
	.4byte	.LVUS155
	.uleb128 0x34
	.4byte	.LVL502
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL503
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x37c1
	.4byte	.LBI1736
	.2byte	.LVU3274
	.4byte	.Ldebug_ranges0+0xf00
	.byte	0x1
	.2byte	0x509
	.byte	0xa
	.4byte	0x24a6
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1738
	.2byte	.LVU3276
	.4byte	.Ldebug_ranges0+0xf20
	.byte	0x1
	.2byte	0x1dc
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1740
	.2byte	.LVU3281
	.4byte	.LBB1740
	.4byte	.LBE1740-.LBB1740
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL505
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x39
	.4byte	0x3db1
	.4byte	.LBI1752
	.2byte	.LVU3303
	.4byte	.Ldebug_ranges0+0xf40
	.byte	0x1
	.2byte	0x50e
	.byte	0xa
	.uleb128 0x29
	.4byte	0x38db
	.4byte	.LBI1755
	.2byte	.LVU3310
	.4byte	.Ldebug_ranges0+0xf58
	.byte	0x1
	.2byte	0x50f
	.byte	0xa
	.4byte	0x2501
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1757
	.2byte	.LVU3312
	.4byte	.Ldebug_ranges0+0xf78
	.byte	0x1
	.2byte	0x186
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1758
	.2byte	.LVU3314
	.4byte	.Ldebug_ranges0+0xfa0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL506
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x38db
	.4byte	.LBI1772
	.2byte	.LVU3351
	.4byte	.LBB1772
	.4byte	.LBE1772-.LBB1772
	.byte	0x1
	.2byte	0x51a
	.byte	0xa
	.4byte	0x2555
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1774
	.2byte	.LVU3353
	.4byte	.LBB1774
	.4byte	.LBE1774-.LBB1774
	.byte	0x1
	.2byte	0x186
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1776
	.2byte	.LVU3358
	.4byte	.LBB1776
	.4byte	.LBE1776-.LBB1776
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL510
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x38cd
	.4byte	.LBI1778
	.2byte	.LVU3397
	.4byte	.LBB1778
	.4byte	.LBE1778-.LBB1778
	.byte	0x1
	.2byte	0x522
	.byte	0xa
	.4byte	0x2631
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1780
	.2byte	.LVU3399
	.4byte	.Ldebug_ranges0+0xfc0
	.byte	0x1
	.2byte	0x191
	.byte	0x15
	.4byte	0x25a4
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1782
	.2byte	.LVU3406
	.4byte	.Ldebug_ranges0+0xfd8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL514
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1787
	.2byte	.LVU3430
	.4byte	.Ldebug_ranges0+0xff0
	.byte	0x1
	.2byte	0x197
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1789
	.2byte	.LVU3436
	.4byte	.LBB1789
	.4byte	.LBE1789-.LBB1789
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1791
	.2byte	.LVU3441
	.4byte	.Ldebug_ranges0+0x1010
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST156
	.4byte	.LVUS156
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1793
	.2byte	.LVU3449
	.4byte	.LBB1793
	.4byte	.LBE1793-.LBB1793
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST157
	.4byte	.LVUS157
	.uleb128 0x34
	.4byte	.LVL520
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x383b
	.4byte	.LBI1802
	.2byte	.LVU3464
	.4byte	.LBB1802
	.4byte	.LBE1802-.LBB1802
	.byte	0x1
	.2byte	0x528
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1804
	.2byte	.LVU3483
	.4byte	.LBB1804
	.4byte	.LBE1804-.LBB1804
	.byte	0x1
	.2byte	0x52b
	.byte	0xa
	.uleb128 0x32
	.4byte	0x38bf
	.4byte	.LBI1806
	.2byte	.LVU3493
	.4byte	.LBB1806
	.4byte	.LBE1806-.LBB1806
	.byte	0x1
	.2byte	0x530
	.byte	0xa
	.uleb128 0x28
	.4byte	0x38db
	.4byte	.LBI1808
	.2byte	.LVU3514
	.4byte	.LBB1808
	.4byte	.LBE1808-.LBB1808
	.byte	0x1
	.2byte	0x536
	.byte	0xa
	.4byte	0x26ca
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1810
	.2byte	.LVU3516
	.4byte	.LBB1810
	.4byte	.LBE1810-.LBB1810
	.byte	0x1
	.2byte	0x186
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1812
	.2byte	.LVU3521
	.4byte	.LBB1812
	.4byte	.LBE1812-.LBB1812
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL526
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1814
	.2byte	.LVU3564
	.4byte	.Ldebug_ranges0+0x1028
	.byte	0x1
	.2byte	0x543
	.byte	0xa
	.4byte	0x273c
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1816
	.2byte	.LVU3569
	.4byte	.Ldebug_ranges0+0x1050
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST158
	.4byte	.LVUS158
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1818
	.2byte	.LVU3581
	.4byte	.LBB1818
	.4byte	.LBE1818-.LBB1818
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x2731
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST159
	.4byte	.LVUS159
	.uleb128 0x34
	.4byte	.LVL539
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL532
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39b3
	.4byte	.LBI1827
	.2byte	.LVU3601
	.4byte	.Ldebug_ranges0+0x1070
	.byte	0x1
	.2byte	0x544
	.byte	0xa
	.4byte	0x276b
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1829
	.2byte	.LVU3605
	.4byte	.LBB1829
	.4byte	.LBE1829-.LBB1829
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x28
	.4byte	0x38cd
	.4byte	.LBI1837
	.2byte	.LVU3639
	.4byte	.LBB1837
	.4byte	.LBE1837-.LBB1837
	.byte	0x1
	.2byte	0x554
	.byte	0xa
	.4byte	0x2847
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1839
	.2byte	.LVU3641
	.4byte	.Ldebug_ranges0+0x1090
	.byte	0x1
	.2byte	0x191
	.byte	0x15
	.4byte	0x27ba
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1841
	.2byte	.LVU3648
	.4byte	.Ldebug_ranges0+0x10a8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL548
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1846
	.2byte	.LVU3672
	.4byte	.Ldebug_ranges0+0x10c0
	.byte	0x1
	.2byte	0x197
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1848
	.2byte	.LVU3678
	.4byte	.LBB1848
	.4byte	.LBE1848-.LBB1848
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1850
	.2byte	.LVU3683
	.4byte	.Ldebug_ranges0+0x10e0
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST160
	.4byte	.LVUS160
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1852
	.2byte	.LVU3691
	.4byte	.LBB1852
	.4byte	.LBE1852-.LBB1852
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST161
	.4byte	.LVUS161
	.uleb128 0x34
	.4byte	.LVL554
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x395f
	.4byte	.LBI1861
	.2byte	.LVU3706
	.4byte	.LBB1861
	.4byte	.LBE1861-.LBB1861
	.byte	0x1
	.2byte	0x55a
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1863
	.2byte	.LVU3711
	.4byte	.LBB1863
	.4byte	.LBE1863-.LBB1863
	.byte	0x1
	.2byte	0x55d
	.byte	0xb
	.4byte	0x2899
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST162
	.4byte	.LVUS162
	.uleb128 0x34
	.4byte	.LVL558
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL559
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x38cd
	.4byte	.LBI1865
	.2byte	.LVU3745
	.4byte	.LBB1865
	.4byte	.LBE1865-.LBB1865
	.byte	0x1
	.2byte	0x56a
	.byte	0xa
	.4byte	0x2975
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1867
	.2byte	.LVU3747
	.4byte	.Ldebug_ranges0+0x10f8
	.byte	0x1
	.2byte	0x191
	.byte	0x15
	.4byte	0x28e8
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1869
	.2byte	.LVU3754
	.4byte	.Ldebug_ranges0+0x1110
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL565
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1874
	.2byte	.LVU3778
	.4byte	.Ldebug_ranges0+0x1128
	.byte	0x1
	.2byte	0x197
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1876
	.2byte	.LVU3784
	.4byte	.LBB1876
	.4byte	.LBE1876-.LBB1876
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1878
	.2byte	.LVU3789
	.4byte	.Ldebug_ranges0+0x1148
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST163
	.4byte	.LVUS163
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1880
	.2byte	.LVU3797
	.4byte	.LBB1880
	.4byte	.LBE1880-.LBB1880
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST164
	.4byte	.LVUS164
	.uleb128 0x34
	.4byte	.LVL571
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x39
	.4byte	0x3db1
	.4byte	.LBI1889
	.2byte	.LVU3811
	.4byte	.Ldebug_ranges0+0x1160
	.byte	0x1
	.2byte	0x56f
	.byte	0xa
	.uleb128 0x29
	.4byte	0x38e9
	.4byte	.LBI1892
	.2byte	.LVU3818
	.4byte	.Ldebug_ranges0+0x1178
	.byte	0x1
	.2byte	0x570
	.byte	0xa
	.4byte	0x29d0
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1894
	.2byte	.LVU3820
	.4byte	.Ldebug_ranges0+0x1198
	.byte	0x1
	.2byte	0x17b
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1895
	.2byte	.LVU3822
	.4byte	.Ldebug_ranges0+0x11c0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL575
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x38e9
	.4byte	.LBI1909
	.2byte	.LVU3859
	.4byte	.LBB1909
	.4byte	.LBE1909-.LBB1909
	.byte	0x1
	.2byte	0x57b
	.byte	0xa
	.4byte	0x2a24
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1911
	.2byte	.LVU3861
	.4byte	.LBB1911
	.4byte	.LBE1911-.LBB1911
	.byte	0x1
	.2byte	0x17b
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1913
	.2byte	.LVU3866
	.4byte	.LBB1913
	.4byte	.LBE1913-.LBB1913
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL579
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x32
	.4byte	0x3849
	.4byte	.LBI1915
	.2byte	.LVU3910
	.4byte	.LBB1915
	.4byte	.LBE1915-.LBB1915
	.byte	0x1
	.2byte	0x589
	.byte	0xa
	.uleb128 0x32
	.4byte	0x3db1
	.4byte	.LBI1917
	.2byte	.LVU3929
	.4byte	.LBB1917
	.4byte	.LBE1917-.LBB1917
	.byte	0x1
	.2byte	0x58c
	.byte	0xa
	.uleb128 0x28
	.4byte	0x38e9
	.4byte	.LBI1919
	.2byte	.LVU3940
	.4byte	.LBB1919
	.4byte	.LBE1919-.LBB1919
	.byte	0x1
	.2byte	0x597
	.byte	0xa
	.4byte	0x2aa6
	.uleb128 0x36
	.4byte	0x3b93
	.4byte	.LBI1921
	.2byte	.LVU3942
	.4byte	.LBB1921
	.4byte	.LBE1921-.LBB1921
	.byte	0x1
	.2byte	0x17b
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI1923
	.2byte	.LVU3947
	.4byte	.LBB1923
	.4byte	.LBE1923-.LBB1923
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL586
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x28
	.4byte	0x3857
	.4byte	.LBI1925
	.2byte	.LVU3986
	.4byte	.LBB1925
	.4byte	.LBE1925-.LBB1925
	.byte	0x1
	.2byte	0x59f
	.byte	0xa
	.4byte	0x2b82
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1927
	.2byte	.LVU3988
	.4byte	.Ldebug_ranges0+0x11e0
	.byte	0x1
	.2byte	0x1b3
	.byte	0x15
	.4byte	0x2af5
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1929
	.2byte	.LVU3995
	.4byte	.Ldebug_ranges0+0x11f8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL590
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1934
	.2byte	.LVU4019
	.4byte	.Ldebug_ranges0+0x1210
	.byte	0x1
	.2byte	0x1b9
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1936
	.2byte	.LVU4025
	.4byte	.LBB1936
	.4byte	.LBE1936-.LBB1936
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1938
	.2byte	.LVU4030
	.4byte	.Ldebug_ranges0+0x1230
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST165
	.4byte	.LVUS165
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1940
	.2byte	.LVU4038
	.4byte	.LBB1940
	.4byte	.LBE1940-.LBB1940
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST166
	.4byte	.LVUS166
	.uleb128 0x34
	.4byte	.LVL596
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x3cae
	.4byte	.LBI1949
	.2byte	.LVU4052
	.4byte	.Ldebug_ranges0+0x1248
	.byte	0x1
	.2byte	0x5a4
	.byte	0xa
	.4byte	0x2bf4
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI1951
	.2byte	.LVU4057
	.4byte	.Ldebug_ranges0+0x1270
	.byte	0x1
	.byte	0xa5
	.byte	0x21
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST167
	.4byte	.LVUS167
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI1953
	.2byte	.LVU4069
	.4byte	.LBB1953
	.4byte	.LBE1953-.LBB1953
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x2be9
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST168
	.4byte	.LVUS168
	.uleb128 0x34
	.4byte	.LVL608
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL601
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x29
	.4byte	0x39dd
	.4byte	.LBI1962
	.2byte	.LVU4089
	.4byte	.Ldebug_ranges0+0x1290
	.byte	0x1
	.2byte	0x5a5
	.byte	0xa
	.4byte	0x2c23
	.uleb128 0x32
	.4byte	0x39f9
	.4byte	.LBI1964
	.2byte	.LVU4093
	.4byte	.LBB1964
	.4byte	.LBE1964-.LBB1964
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.byte	0
	.uleb128 0x32
	.4byte	0x33cf
	.4byte	.LBI1972
	.2byte	.LVU4132
	.4byte	.LBB1972
	.4byte	.LBE1972-.LBB1972
	.byte	0x1
	.2byte	0x5bb
	.byte	0xa
	.uleb128 0x28
	.4byte	0x3c22
	.4byte	.LBI1974
	.2byte	.LVU4137
	.4byte	.LBB1974
	.4byte	.LBE1974-.LBB1974
	.byte	0x1
	.2byte	0x5be
	.byte	0xb
	.4byte	0x2c75
	.uleb128 0x35
	.4byte	0x3c33
	.4byte	.LLST169
	.4byte	.LVUS169
	.uleb128 0x34
	.4byte	.LVL618
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL619
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x28
	.4byte	0x3857
	.4byte	.LBI1976
	.2byte	.LVU4171
	.4byte	.LBB1976
	.4byte	.LBE1976-.LBB1976
	.byte	0x1
	.2byte	0x5cb
	.byte	0xa
	.4byte	0x2d51
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1978
	.2byte	.LVU4173
	.4byte	.Ldebug_ranges0+0x12b0
	.byte	0x1
	.2byte	0x1b3
	.byte	0x15
	.4byte	0x2cc4
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1980
	.2byte	.LVU4180
	.4byte	.Ldebug_ranges0+0x12c8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL625
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1985
	.2byte	.LVU4204
	.4byte	.Ldebug_ranges0+0x12e0
	.byte	0x1
	.2byte	0x1b9
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1987
	.2byte	.LVU4210
	.4byte	.LBB1987
	.4byte	.LBE1987-.LBB1987
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1989
	.2byte	.LVU4215
	.4byte	.Ldebug_ranges0+0x1300
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST170
	.4byte	.LVUS170
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1991
	.2byte	.LVU4223
	.4byte	.LBB1991
	.4byte	.LBE1991-.LBB1991
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST171
	.4byte	.LVUS171
	.uleb128 0x34
	.4byte	.LVL631
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x34
	.4byte	.LVL128
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL132
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL133
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL134
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL135
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL136
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL137
	.4byte	0x3a07
	.uleb128 0x34
	.4byte	.LVL142
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL143
	.4byte	0x3a07
	.uleb128 0x34
	.4byte	.LVL144
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL145
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL146
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL147
	.4byte	0x3a07
	.uleb128 0x34
	.4byte	.LVL160
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL161
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL162
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL163
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL164
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL165
	.4byte	0x3a07
	.uleb128 0x34
	.4byte	.LVL169
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL170
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL171
	.4byte	0x366b
	.uleb128 0x34
	.4byte	.LVL172
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL173
	.4byte	0x3a07
	.uleb128 0x34
	.4byte	.LVL174
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL184
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL185
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL187
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL188
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL189
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL190
	.4byte	0x354f
	.uleb128 0x34
	.4byte	.LVL192
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL193
	.4byte	0x354f
	.uleb128 0x34
	.4byte	.LVL194
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL196
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL197
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL198
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL199
	.4byte	0x354f
	.uleb128 0x34
	.4byte	.LVL212
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL213
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL214
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL215
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL216
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL217
	.4byte	0x354f
	.uleb128 0x34
	.4byte	.LVL221
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL222
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL223
	.4byte	0x3ae1
	.uleb128 0x34
	.4byte	.LVL224
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL225
	.4byte	0x354f
	.uleb128 0x34
	.4byte	.LVL230
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL231
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL232
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL233
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL234
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL235
	.4byte	0x36b7
	.uleb128 0x34
	.4byte	.LVL239
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL240
	.4byte	0x36b7
	.uleb128 0x34
	.4byte	.LVL241
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL242
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL243
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL244
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL245
	.4byte	0x36b7
	.uleb128 0x34
	.4byte	.LVL258
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL259
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL260
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL261
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL262
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL263
	.4byte	0x36b7
	.uleb128 0x34
	.4byte	.LVL267
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL268
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL269
	.4byte	0x3865
	.uleb128 0x34
	.4byte	.LVL270
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL271
	.4byte	0x36b7
	.uleb128 0x34
	.4byte	.LVL276
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL277
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL278
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL279
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL280
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL281
	.4byte	0x3453
	.uleb128 0x34
	.4byte	.LVL283
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL284
	.4byte	0x3453
	.uleb128 0x34
	.4byte	.LVL290
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL291
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL292
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL293
	.4byte	0x3453
	.uleb128 0x34
	.4byte	.LVL310
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL311
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL312
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL313
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL314
	.4byte	0x3453
	.uleb128 0x34
	.4byte	.LVL318
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL319
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL320
	.4byte	0x3b2b
	.uleb128 0x34
	.4byte	.LVL321
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL322
	.4byte	0x3453
	.uleb128 0x34
	.4byte	.LVL323
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL332
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL342
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL351
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL361
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL371
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL380
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL402
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL411
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL421
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL448
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL458
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL459
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL461
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL463
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL464
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL465
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL467
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL468
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL470
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL471
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL472
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL486
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL487
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL488
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL490
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL491
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL497
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL498
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL500
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL501
	.4byte	0x37cf
	.uleb128 0x34
	.4byte	.LVL507
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL508
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL509
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL511
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL512
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL513
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL524
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL525
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL527
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL528
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL529
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL530
	.4byte	0x38cd
	.uleb128 0x34
	.4byte	.LVL543
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL544
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL545
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL546
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL547
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL561
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL562
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL563
	.4byte	0x38f7
	.uleb128 0x34
	.4byte	.LVL564
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL576
	.4byte	0x3bda
	.uleb128 0x34
	.4byte	.LVL577
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL578
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL580
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL581
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL582
	.4byte	0x3d3d
	.uleb128 0x34
	.4byte	.LVL583
	.4byte	0x3857
	.uleb128 0x34
	.4byte	.LVL584
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL585
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL587
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL588
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL589
	.4byte	0x3c81
	.uleb128 0x34
	.4byte	.LVL612
	.4byte	0x3ba4
	.uleb128 0x34
	.4byte	.LVL613
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL614
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL615
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL616
	.4byte	0x3cc8
	.uleb128 0x34
	.4byte	.LVL617
	.4byte	0x3857
	.uleb128 0x34
	.4byte	.LVL621
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL622
	.4byte	0x3c40
	.uleb128 0x34
	.4byte	.LVL623
	.4byte	0x33eb
	.uleb128 0x34
	.4byte	.LVL624
	.4byte	0x3c40
	.byte	0
	.uleb128 0x3a
	.string	"tya"
	.byte	0x1
	.2byte	0x27d
	.byte	0xd
	.4byte	.LASF95
	.byte	0x3
	.uleb128 0x3a
	.string	"txs"
	.byte	0x1
	.2byte	0x279
	.byte	0xd
	.4byte	.LASF96
	.byte	0x3
	.uleb128 0x3a
	.string	"txa"
	.byte	0x1
	.2byte	0x272
	.byte	0xd
	.4byte	.LASF97
	.byte	0x3
	.uleb128 0x3a
	.string	"tsx"
	.byte	0x1
	.2byte	0x26b
	.byte	0xd
	.4byte	.LASF98
	.byte	0x3
	.uleb128 0x3a
	.string	"tay"
	.byte	0x1
	.2byte	0x264
	.byte	0xd
	.4byte	.LASF99
	.byte	0x3
	.uleb128 0x3a
	.string	"tax"
	.byte	0x1
	.2byte	0x25d
	.byte	0xd
	.4byte	.LASF100
	.byte	0x3
	.uleb128 0x3a
	.string	"sty"
	.byte	0x1
	.2byte	0x259
	.byte	0xd
	.4byte	.LASF101
	.byte	0x3
	.uleb128 0x3a
	.string	"stx"
	.byte	0x1
	.2byte	0x255
	.byte	0xd
	.4byte	.LASF102
	.byte	0x3
	.uleb128 0x3a
	.string	"sta"
	.byte	0x1
	.2byte	0x251
	.byte	0xd
	.4byte	.LASF103
	.byte	0x3
	.uleb128 0x3a
	.string	"sei"
	.byte	0x1
	.2byte	0x24d
	.byte	0xd
	.4byte	.LASF104
	.byte	0x3
	.uleb128 0x3a
	.string	"sed"
	.byte	0x1
	.2byte	0x249
	.byte	0xd
	.4byte	.LASF105
	.byte	0x3
	.uleb128 0x3a
	.string	"sec"
	.byte	0x1
	.2byte	0x245
	.byte	0xd
	.4byte	.LASF106
	.byte	0x3
	.uleb128 0x3b
	.string	"sbc"
	.byte	0x1
	.2byte	0x239
	.byte	0xd
	.4byte	.LASF109
	.4byte	.LFB78
	.4byte	.LFE78-.LFB78
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3437
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI1040
	.2byte	.LVU961
	.4byte	.Ldebug_ranges0+0x488
	.byte	0x1
	.2byte	0x23a
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1042
	.2byte	.LVU971
	.4byte	.Ldebug_ranges0+0x4a8
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL125
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"rts"
	.byte	0x1
	.2byte	0x234
	.byte	0xd
	.4byte	.LASF107
	.byte	0x3
	.uleb128 0x3a
	.string	"rti"
	.byte	0x1
	.2byte	0x22e
	.byte	0xd
	.4byte	.LASF108
	.byte	0x3
	.uleb128 0x3b
	.string	"ror"
	.byte	0x1
	.2byte	0x222
	.byte	0xd
	.4byte	.LASF110
	.4byte	.LFB75
	.4byte	.LFE75-.LFB75
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x354f
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI1016
	.2byte	.LVU882
	.4byte	.Ldebug_ranges0+0x418
	.byte	0x1
	.2byte	0x223
	.byte	0x15
	.4byte	0x34a2
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI1018
	.2byte	.LVU892
	.4byte	.Ldebug_ranges0+0x440
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL112
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1027
	.2byte	.LVU924
	.4byte	.Ldebug_ranges0+0x458
	.byte	0x1
	.2byte	0x22b
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST31
	.4byte	.LVUS31
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1029
	.2byte	.LVU931
	.4byte	.LBB1029
	.4byte	.LBE1029-.LBB1029
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST32
	.4byte	.LVUS32
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1031
	.2byte	.LVU936
	.4byte	.Ldebug_ranges0+0x470
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST33
	.4byte	.LVUS33
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST34
	.4byte	.LVUS34
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1033
	.2byte	.LVU944
	.4byte	.LBB1033
	.4byte	.LBE1033-.LBB1033
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST35
	.4byte	.LVUS35
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST36
	.4byte	.LVUS36
	.uleb128 0x34
	.4byte	.LVL119
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3b
	.string	"rol"
	.byte	0x1
	.2byte	0x217
	.byte	0xd
	.4byte	.LASF111
	.4byte	.LFB74
	.4byte	.LFE74-.LFB74
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3633
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI992
	.2byte	.LVU806
	.4byte	.Ldebug_ranges0+0x3a8
	.byte	0x1
	.2byte	0x218
	.byte	0x15
	.4byte	0x359e
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI994
	.2byte	.LVU816
	.4byte	.Ldebug_ranges0+0x3d0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL101
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI1003
	.2byte	.LVU850
	.4byte	.Ldebug_ranges0+0x3e8
	.byte	0x1
	.2byte	0x21f
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST28
	.4byte	.LVUS28
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI1005
	.2byte	.LVU854
	.4byte	.LBB1005
	.4byte	.LBE1005-.LBB1005
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI1007
	.2byte	.LVU859
	.4byte	.Ldebug_ranges0+0x400
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST29
	.4byte	.LVUS29
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI1009
	.2byte	.LVU866
	.4byte	.LBB1009
	.4byte	.LBE1009-.LBB1009
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST30
	.4byte	.LVUS30
	.uleb128 0x34
	.4byte	.LVL108
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"plp"
	.byte	0x1
	.2byte	0x213
	.byte	0xd
	.4byte	.LASF112
	.byte	0x3
	.uleb128 0x3a
	.string	"pla"
	.byte	0x1
	.2byte	0x20c
	.byte	0xd
	.4byte	.LASF113
	.byte	0x3
	.uleb128 0x3a
	.string	"php"
	.byte	0x1
	.2byte	0x208
	.byte	0xd
	.4byte	.LASF114
	.byte	0x3
	.uleb128 0x3a
	.string	"pha"
	.byte	0x1
	.2byte	0x204
	.byte	0xd
	.4byte	.LASF115
	.byte	0x3
	.uleb128 0x3b
	.string	"ora"
	.byte	0x1
	.2byte	0x1fa
	.byte	0xd
	.4byte	.LASF116
	.4byte	.LFB69
	.4byte	.LFE69-.LFB69
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x36b7
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI982
	.2byte	.LVU765
	.4byte	.Ldebug_ranges0+0x370
	.byte	0x1
	.2byte	0x1fb
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI984
	.2byte	.LVU775
	.4byte	.Ldebug_ranges0+0x390
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL100
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3b
	.string	"lsr"
	.byte	0x1
	.2byte	0x1eb
	.byte	0xd
	.4byte	.LASF117
	.4byte	.LFB67
	.4byte	.LFE67-.LFB67
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x37b3
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI958
	.2byte	.LVU691
	.4byte	.Ldebug_ranges0+0x300
	.byte	0x1
	.2byte	0x1ec
	.byte	0x15
	.4byte	0x3706
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI960
	.2byte	.LVU701
	.4byte	.Ldebug_ranges0+0x328
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL87
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI969
	.2byte	.LVU728
	.4byte	.Ldebug_ranges0+0x340
	.byte	0x1
	.2byte	0x1f4
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST22
	.4byte	.LVUS22
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI971
	.2byte	.LVU735
	.4byte	.LBB971
	.4byte	.LBE971-.LBB971
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2a
	.4byte	0x3b86
	.4byte	.LLST23
	.4byte	.LVUS23
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI973
	.2byte	.LVU740
	.4byte	.Ldebug_ranges0+0x358
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST24
	.4byte	.LVUS24
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST25
	.4byte	.LVUS25
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI975
	.2byte	.LVU748
	.4byte	.LBB975
	.4byte	.LBE975-.LBB975
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST26
	.4byte	.LVUS26
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST27
	.4byte	.LVUS27
	.uleb128 0x34
	.4byte	.LVL94
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"ldy"
	.byte	0x1
	.2byte	0x1e3
	.byte	0xd
	.4byte	.LASF118
	.byte	0x3
	.uleb128 0x3a
	.string	"ldx"
	.byte	0x1
	.2byte	0x1db
	.byte	0xd
	.4byte	.LASF119
	.byte	0x3
	.uleb128 0x3b
	.string	"lda"
	.byte	0x1
	.2byte	0x1d3
	.byte	0xd
	.4byte	.LASF120
	.4byte	.LFB64
	.4byte	.LFE64-.LFB64
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x381f
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI952
	.2byte	.LVU658
	.4byte	.Ldebug_ranges0+0x2e8
	.byte	0x1
	.2byte	0x1d4
	.byte	0x15
	.uleb128 0x38
	.4byte	0x3b93
	.4byte	.LBI954
	.2byte	.LVU666
	.4byte	.LBB954
	.4byte	.LBE954-.LBB954
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL86
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"jsr"
	.byte	0x1
	.2byte	0x1ce
	.byte	0xd
	.4byte	.LASF121
	.byte	0x3
	.uleb128 0x3a
	.string	"jmp"
	.byte	0x1
	.2byte	0x1ca
	.byte	0xd
	.4byte	.LASF122
	.byte	0x3
	.uleb128 0x3a
	.string	"iny"
	.byte	0x1
	.2byte	0x1c3
	.byte	0xd
	.4byte	.LASF123
	.byte	0x3
	.uleb128 0x3a
	.string	"inx"
	.byte	0x1
	.2byte	0x1bc
	.byte	0xd
	.4byte	.LASF124
	.byte	0x3
	.uleb128 0x3a
	.string	"inc"
	.byte	0x1
	.2byte	0x1b2
	.byte	0xd
	.4byte	.LASF125
	.byte	0x3
	.uleb128 0x3b
	.string	"eor"
	.byte	0x1
	.2byte	0x1a8
	.byte	0xd
	.4byte	.LASF126
	.4byte	.LFB58
	.4byte	.LFE58-.LFB58
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x38b1
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI904
	.2byte	.LVU542
	.4byte	.Ldebug_ranges0+0x208
	.byte	0x1
	.2byte	0x1a9
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI906
	.2byte	.LVU565
	.4byte	.Ldebug_ranges0+0x258
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL75
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"dey"
	.byte	0x1
	.2byte	0x1a1
	.byte	0xd
	.4byte	.LASF127
	.byte	0x3
	.uleb128 0x3a
	.string	"dex"
	.byte	0x1
	.2byte	0x19a
	.byte	0xd
	.4byte	.LASF128
	.byte	0x3
	.uleb128 0x3a
	.string	"dec"
	.byte	0x1
	.2byte	0x190
	.byte	0xd
	.4byte	.LASF129
	.byte	0x3
	.uleb128 0x3a
	.string	"cpy"
	.byte	0x1
	.2byte	0x185
	.byte	0xd
	.4byte	.LASF130
	.byte	0x3
	.uleb128 0x3a
	.string	"cpx"
	.byte	0x1
	.2byte	0x17a
	.byte	0xd
	.4byte	.LASF131
	.byte	0x3
	.uleb128 0x3b
	.string	"cmp"
	.byte	0x1
	.2byte	0x16f
	.byte	0xd
	.4byte	.LASF132
	.4byte	.LFB52
	.4byte	.LFE52-.LFB52
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3943
	.uleb128 0x31
	.4byte	0x3b93
	.4byte	.LBI864
	.2byte	.LVU428
	.4byte	.Ldebug_ranges0+0x148
	.byte	0x1
	.2byte	0x170
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI866
	.2byte	.LVU445
	.4byte	.Ldebug_ranges0+0x180
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL64
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3a
	.string	"clv"
	.byte	0x1
	.2byte	0x16b
	.byte	0xd
	.4byte	.LASF133
	.byte	0x3
	.uleb128 0x3a
	.string	"cli"
	.byte	0x1
	.2byte	0x167
	.byte	0xd
	.4byte	.LASF134
	.byte	0x3
	.uleb128 0x3a
	.string	"cld"
	.byte	0x1
	.2byte	0x163
	.byte	0xd
	.4byte	.LASF135
	.byte	0x3
	.uleb128 0x3a
	.string	"clc"
	.byte	0x1
	.2byte	0x15f
	.byte	0xd
	.4byte	.LASF136
	.byte	0x3
	.uleb128 0x3a
	.string	"bvs"
	.byte	0x1
	.2byte	0x156
	.byte	0xd
	.4byte	.LASF137
	.byte	0x3
	.uleb128 0x3a
	.string	"bvc"
	.byte	0x1
	.2byte	0x14d
	.byte	0xd
	.4byte	.LASF138
	.byte	0x3
	.uleb128 0x3a
	.string	"brk"
	.byte	0x1
	.2byte	0x145
	.byte	0xd
	.4byte	.LASF139
	.byte	0x3
	.uleb128 0x3a
	.string	"bpl"
	.byte	0x1
	.2byte	0x13c
	.byte	0xd
	.4byte	.LASF140
	.byte	0x3
	.uleb128 0x3a
	.string	"bne"
	.byte	0x1
	.2byte	0x133
	.byte	0xd
	.4byte	.LASF141
	.byte	0x3
	.uleb128 0x3a
	.string	"bmi"
	.byte	0x1
	.2byte	0x12a
	.byte	0xd
	.4byte	.LASF142
	.byte	0x3
	.uleb128 0x3c
	.4byte	.LASF143
	.byte	0x1
	.2byte	0x122
	.byte	0xd
	.4byte	.LASF205
	.byte	0x3
	.uleb128 0x3a
	.string	"beq"
	.byte	0x1
	.2byte	0x119
	.byte	0xd
	.4byte	.LASF144
	.byte	0x3
	.uleb128 0x3a
	.string	"bcs"
	.byte	0x1
	.2byte	0x110
	.byte	0xd
	.4byte	.LASF145
	.byte	0x3
	.uleb128 0x3a
	.string	"bcc"
	.byte	0x1
	.2byte	0x107
	.byte	0xd
	.4byte	.LASF146
	.byte	0x3
	.uleb128 0x3d
	.string	"asl"
	.byte	0x1
	.byte	0xfc
	.byte	0xd
	.4byte	.LASF148
	.4byte	.LFB37
	.4byte	.LFE37-.LFB37
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3ae1
	.uleb128 0x2b
	.4byte	0x3b93
	.4byte	.LBI840
	.2byte	.LVU357
	.4byte	.Ldebug_ranges0+0xd8
	.byte	0x1
	.byte	0xfd
	.byte	0x15
	.4byte	0x3a54
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI842
	.2byte	.LVU367
	.4byte	.Ldebug_ranges0+0x100
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL54
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI851
	.2byte	.LVU396
	.4byte	.Ldebug_ranges0+0x118
	.byte	0x1
	.2byte	0x104
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI853
	.2byte	.LVU400
	.4byte	.LBB853
	.4byte	.LBE853-.LBB853
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI855
	.2byte	.LVU405
	.4byte	.Ldebug_ranges0+0x130
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST16
	.4byte	.LVUS16
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI857
	.2byte	.LVU412
	.4byte	.LBB857
	.4byte	.LBE857-.LBB857
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST17
	.4byte	.LVUS17
	.uleb128 0x34
	.4byte	.LVL60
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3e
	.4byte	.LASF147
	.byte	0x1
	.byte	0xf2
	.byte	0xd
	.4byte	.LASF163
	.4byte	.LFB36
	.4byte	.LFE36-.LFB36
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3b2b
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI830
	.2byte	.LVU316
	.4byte	.Ldebug_ranges0+0xa0
	.byte	0x1
	.byte	0xf3
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI832
	.2byte	.LVU326
	.4byte	.Ldebug_ranges0+0xc0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL53
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3d
	.string	"adc"
	.byte	0x1
	.byte	0xe7
	.byte	0xd
	.4byte	.LASF149
	.4byte	.LFB35
	.4byte	.LFE35-.LFB35
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3b75
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI820
	.2byte	.LVU265
	.4byte	.Ldebug_ranges0+0x68
	.byte	0x1
	.byte	0xe8
	.byte	0x15
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI822
	.2byte	.LVU275
	.4byte	.Ldebug_ranges0+0x88
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL52
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF150
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.4byte	.LASF152
	.byte	0x3
	.4byte	0x3b93
	.uleb128 0x40
	.4byte	.LASF184
	.byte	0x1
	.byte	0xe1
	.byte	0x1f
	.4byte	0x99
	.byte	0
	.uleb128 0x41
	.4byte	.LASF176
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.4byte	.LASF178
	.4byte	0x99
	.byte	0x3
	.uleb128 0x3f
	.4byte	.LASF151
	.byte	0x1
	.byte	0xce
	.byte	0xd
	.4byte	.LASF153
	.byte	0x3
	.4byte	0x3bda
	.uleb128 0x42
	.4byte	.LASF154
	.byte	0x1
	.byte	0xcf
	.byte	0xe
	.4byte	0x99
	.uleb128 0x42
	.4byte	.LASF155
	.byte	0x1
	.byte	0xcf
	.byte	0x16
	.4byte	0x99
	.uleb128 0x42
	.4byte	.LASF156
	.byte	0x1
	.byte	0xcf
	.byte	0x1f
	.4byte	0x99
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF157
	.byte	0x1
	.byte	0xc8
	.byte	0xd
	.4byte	.LASF158
	.byte	0x3
	.4byte	0x3bf8
	.uleb128 0x42
	.4byte	.LASF154
	.byte	0x1
	.byte	0xc9
	.byte	0xe
	.4byte	0x99
	.byte	0
	.uleb128 0x43
	.string	"ind"
	.byte	0x1
	.byte	0xc0
	.byte	0xd
	.4byte	.LASF159
	.byte	0x3
	.4byte	0x3c22
	.uleb128 0x42
	.4byte	.LASF154
	.byte	0x1
	.byte	0xc1
	.byte	0xe
	.4byte	0x99
	.uleb128 0x42
	.4byte	.LASF155
	.byte	0x1
	.byte	0xc1
	.byte	0x16
	.4byte	0x99
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF160
	.byte	0x1
	.byte	0xb7
	.byte	0xd
	.4byte	.LASF161
	.byte	0x3
	.4byte	0x3c40
	.uleb128 0x42
	.4byte	.LASF156
	.byte	0x1
	.byte	0xb8
	.byte	0xe
	.4byte	0x99
	.byte	0
	.uleb128 0x3e
	.4byte	.LASF162
	.byte	0x1
	.byte	0xae
	.byte	0xd
	.4byte	.LASF164
	.4byte	.LFB27
	.4byte	.LFE27-.LFB27
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3c81
	.uleb128 0x44
	.4byte	.LASF156
	.byte	0x1
	.byte	0xaf
	.byte	0xe
	.4byte	0x99
	.4byte	.LLST11
	.4byte	.LVUS11
	.uleb128 0x34
	.4byte	.LVL38
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL39
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x3e
	.4byte	.LASF165
	.byte	0x1
	.byte	0xa9
	.byte	0xd
	.4byte	.LASF166
	.4byte	.LFB26
	.4byte	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3cae
	.uleb128 0x34
	.4byte	.LVL36
	.4byte	0x3ea4
	.uleb128 0x34
	.4byte	.LVL37
	.4byte	0x3ea4
	.byte	0
	.uleb128 0x45
	.string	"rel"
	.byte	0x1
	.byte	0xa4
	.byte	0xd
	.4byte	.LASF167
	.byte	0x3
	.uleb128 0x45
	.string	"zpy"
	.byte	0x1
	.byte	0xa0
	.byte	0xd
	.4byte	.LASF168
	.byte	0x3
	.uleb128 0x3d
	.string	"zpx"
	.byte	0x1
	.byte	0x9c
	.byte	0xd
	.4byte	.LASF169
	.4byte	.LFB23
	.4byte	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3d3d
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI814
	.2byte	.LVU133
	.4byte	.Ldebug_ranges0+0x50
	.byte	0x1
	.byte	0x9d
	.byte	0x1d
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST9
	.4byte	.LVUS9
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI816
	.2byte	.LVU145
	.4byte	.LBB816
	.4byte	.LBE816-.LBB816
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x3d32
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST10
	.4byte	.LVUS10
	.uleb128 0x34
	.4byte	.LVL32
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL27
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x3d
	.string	"zp"
	.byte	0x1
	.byte	0x98
	.byte	0xd
	.4byte	.LASF170
	.4byte	.LFB22
	.4byte	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3db1
	.uleb128 0x2d
	.4byte	0x3ea4
	.4byte	.LBI804
	.2byte	.LVU94
	.4byte	.Ldebug_ranges0+0x28
	.byte	0x1
	.byte	0x99
	.byte	0x1c
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST7
	.4byte	.LVUS7
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI806
	.2byte	.LVU108
	.4byte	.LBB806
	.4byte	.LBE806-.LBB806
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x3da6
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST8
	.4byte	.LVUS8
	.uleb128 0x34
	.4byte	.LVL22
	.4byte	0x4237
	.byte	0
	.uleb128 0x34
	.4byte	.LVL17
	.4byte	0x54e
	.byte	0
	.byte	0
	.uleb128 0x45
	.string	"imm"
	.byte	0x1
	.byte	0x94
	.byte	0xd
	.4byte	.LASF171
	.byte	0x3
	.uleb128 0x45
	.string	"acc"
	.byte	0x1
	.byte	0x90
	.byte	0xd
	.4byte	.LASF172
	.byte	0x3
	.uleb128 0x45
	.string	"imp"
	.byte	0x1
	.byte	0x8d
	.byte	0xd
	.4byte	.LASF173
	.byte	0x3
	.uleb128 0x3e
	.4byte	.LASF174
	.byte	0x1
	.byte	0x80
	.byte	0x6
	.4byte	.LASF175
	.4byte	.LFB18
	.4byte	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3e0b
	.uleb128 0x37
	.4byte	.Ldebug_ranges0+0
	.uleb128 0x46
	.string	"i"
	.byte	0x1
	.byte	0x88
	.byte	0xf
	.4byte	0x8d
	.4byte	.LLST6
	.4byte	.LVUS6
	.byte	0
	.byte	0
	.uleb128 0x41
	.4byte	.LASF177
	.byte	0x1
	.byte	0x7c
	.byte	0x10
	.4byte	.LASF179
	.4byte	0x8d
	.byte	0x3
	.uleb128 0x47
	.4byte	.LASF180
	.byte	0x1
	.byte	0x75
	.byte	0x11
	.4byte	.LASF192
	.4byte	0x99
	.byte	0x3
	.4byte	0x3e3e
	.uleb128 0x42
	.4byte	.LASF181
	.byte	0x1
	.byte	0x76
	.byte	0xe
	.4byte	0x99
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF182
	.byte	0x1
	.byte	0x71
	.byte	0xd
	.4byte	.LASF183
	.byte	0x3
	.4byte	0x3e5c
	.uleb128 0x40
	.4byte	.LASF185
	.byte	0x1
	.byte	0x71
	.byte	0x1b
	.4byte	0x8d
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF186
	.byte	0x1
	.byte	0x6b
	.byte	0xd
	.4byte	.LASF187
	.byte	0x3
	.4byte	0x3e7a
	.uleb128 0x40
	.4byte	.LASF185
	.byte	0x1
	.byte	0x6b
	.byte	0x1d
	.4byte	0x99
	.byte	0
	.uleb128 0x3f
	.4byte	.LASF188
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.4byte	.LASF189
	.byte	0x1
	.4byte	0x3ea4
	.uleb128 0x40
	.4byte	.LASF190
	.byte	0x1
	.byte	0x5a
	.byte	0x19
	.4byte	0x99
	.uleb128 0x40
	.4byte	.LASF71
	.byte	0x1
	.byte	0x5a
	.byte	0x2a
	.4byte	0x8d
	.byte	0
	.uleb128 0x47
	.4byte	.LASF191
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	.LASF193
	.4byte	0x8d
	.byte	0x1
	.4byte	0x3ec6
	.uleb128 0x40
	.4byte	.LASF190
	.byte	0x1
	.byte	0x45
	.byte	0x1b
	.4byte	0x99
	.byte	0
	.uleb128 0x48
	.4byte	0x3ea4
	.4byte	.LASF193
	.4byte	.LFB12
	.4byte	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3f39
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST0
	.4byte	.LVUS0
	.uleb128 0x33
	.4byte	0x3ea4
	.4byte	.LBI796
	.2byte	.LVU14
	.4byte	.LBB796
	.4byte	.LBE796-.LBB796
	.byte	0x1
	.byte	0x45
	.byte	0x9
	.4byte	0x3f2f
	.uleb128 0x2a
	.4byte	0x3eb9
	.4byte	.LLST1
	.4byte	.LVUS1
	.uleb128 0x30
	.4byte	.LVL4
	.4byte	0x4237
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0xf
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0xa
	.2byte	0xffff
	.byte	0x1a
	.byte	0xa
	.2byte	0x200
	.byte	0x1c
	.byte	0xa
	.2byte	0xffff
	.byte	0x1a
	.byte	0
	.byte	0
	.uleb128 0x34
	.4byte	.LVL2
	.4byte	0x54e
	.byte	0
	.uleb128 0x48
	.4byte	0x3e7a
	.4byte	.LASF189
	.4byte	.LFB13
	.4byte	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x3fc3
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST2
	.4byte	.LVUS2
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST3
	.4byte	.LVUS3
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI798
	.2byte	.LVU37
	.4byte	.LBB798
	.4byte	.LBE798-.LBB798
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2a
	.4byte	0x3e97
	.4byte	.LLST4
	.4byte	.LVUS4
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST5
	.4byte	.LVUS5
	.uleb128 0x30
	.4byte	.LVL10
	.4byte	0x4243
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0xf
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0xa
	.2byte	0xffff
	.byte	0x1a
	.byte	0xa
	.2byte	0x200
	.byte	0x1c
	.byte	0xa
	.2byte	0xffff
	.byte	0x1a
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x53
	.uleb128 0x6
	.byte	0xf3
	.uleb128 0x1
	.byte	0x53
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x48
	.4byte	0x3bda
	.4byte	.LASF158
	.4byte	.LFB30
	.4byte	.LFE30-.LFB30
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x4018
	.uleb128 0x35
	.4byte	0x3beb
	.4byte	.LLST12
	.4byte	.LVUS12
	.uleb128 0x34
	.4byte	.LVL41
	.4byte	0x3ea4
	.uleb128 0x2e
	.4byte	.LVL43
	.4byte	0x3ea4
	.4byte	0x4004
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x2
	.byte	0x7c
	.sleb128 0
	.byte	0
	.uleb128 0x30
	.4byte	.LVL44
	.4byte	0x3ea4
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x5
	.byte	0x7c
	.sleb128 1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0
	.byte	0
	.uleb128 0x48
	.4byte	0x3ba4
	.4byte	.LASF153
	.4byte	.LFB31
	.4byte	.LFE31-.LFB31
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x4087
	.uleb128 0x35
	.4byte	0x3bb5
	.4byte	.LLST13
	.4byte	.LVUS13
	.uleb128 0x35
	.4byte	0x3bc1
	.4byte	.LLST14
	.4byte	.LVUS14
	.uleb128 0x35
	.4byte	0x3bcd
	.4byte	.LLST15
	.4byte	.LVUS15
	.uleb128 0x34
	.4byte	.LVL46
	.4byte	0x3ea4
	.uleb128 0x2e
	.4byte	.LVL48
	.4byte	0x3ea4
	.4byte	0x4073
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x2
	.byte	0x7c
	.sleb128 0
	.byte	0
	.uleb128 0x30
	.4byte	.LVL49
	.4byte	0x3ea4
	.uleb128 0x2f
	.uleb128 0x1
	.byte	0x52
	.uleb128 0x5
	.byte	0x7c
	.sleb128 1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0
	.byte	0
	.uleb128 0x48
	.4byte	0x38cd
	.4byte	.LASF129
	.4byte	.LFB55
	.4byte	.LFE55-.LFB55
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x415f
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI880
	.2byte	.LVU476
	.4byte	.Ldebug_ranges0+0x198
	.byte	0x1
	.2byte	0x191
	.byte	0x15
	.4byte	0x40d2
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI882
	.2byte	.LVU486
	.4byte	.Ldebug_ranges0+0x1c0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL65
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI891
	.2byte	.LVU510
	.4byte	.Ldebug_ranges0+0x1d8
	.byte	0x1
	.2byte	0x197
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI893
	.2byte	.LVU514
	.4byte	.LBB893
	.4byte	.LBE893-.LBB893
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI895
	.2byte	.LVU519
	.4byte	.Ldebug_ranges0+0x1f0
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST18
	.4byte	.LVUS18
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI897
	.2byte	.LVU526
	.4byte	.LBB897
	.4byte	.LBE897-.LBB897
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST19
	.4byte	.LVUS19
	.uleb128 0x34
	.4byte	.LVL71
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x48
	.4byte	0x3857
	.4byte	.LASF125
	.4byte	.LFB59
	.4byte	.LFE59-.LFB59
	.uleb128 0x1
	.byte	0x9c
	.4byte	0x4237
	.uleb128 0x29
	.4byte	0x3b93
	.4byte	.LBI928
	.2byte	.LVU592
	.4byte	.Ldebug_ranges0+0x278
	.byte	0x1
	.2byte	0x1b3
	.byte	0x15
	.4byte	0x41aa
	.uleb128 0x2d
	.4byte	0x3b93
	.4byte	.LBI930
	.2byte	.LVU602
	.4byte	.Ldebug_ranges0+0x2a0
	.byte	0x1
	.byte	0xd8
	.byte	0x11
	.uleb128 0x34
	.4byte	.LVL76
	.4byte	0x3ea4
	.byte	0
	.byte	0
	.uleb128 0x31
	.4byte	0x3b75
	.4byte	.LBI939
	.2byte	.LVU626
	.4byte	.Ldebug_ranges0+0x2b8
	.byte	0x1
	.2byte	0x1b9
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x38
	.4byte	0x3b75
	.4byte	.LBI941
	.2byte	.LVU630
	.4byte	.LBB941
	.4byte	.LBE941-.LBB941
	.byte	0x1
	.byte	0xe1
	.byte	0xd
	.uleb128 0x2c
	.4byte	0x3b86
	.uleb128 0x2d
	.4byte	0x3e7a
	.4byte	.LBI943
	.2byte	.LVU635
	.4byte	.Ldebug_ranges0+0x2d0
	.byte	0x1
	.byte	0xe3
	.byte	0x17
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST20
	.4byte	.LVUS20
	.uleb128 0x38
	.4byte	0x3e7a
	.4byte	.LBI945
	.2byte	.LVU642
	.4byte	.LBB945
	.4byte	.LBE945-.LBB945
	.byte	0x1
	.byte	0x5a
	.byte	0x6
	.uleb128 0x2c
	.4byte	0x3e97
	.uleb128 0x2a
	.4byte	0x3e8b
	.4byte	.LLST21
	.4byte	.LVUS21
	.uleb128 0x34
	.4byte	.LVL82
	.4byte	0x4243
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x49
	.4byte	.LASF194
	.4byte	.LASF196
	.byte	0x1
	.byte	0x43
	.byte	0x10
	.uleb128 0x49
	.4byte	.LASF195
	.4byte	.LASF197
	.byte	0x1
	.byte	0x42
	.byte	0xd
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1b
	.uleb128 0xe
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x8
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x39
	.byte	0x1
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x39
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x89
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x8
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x5
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x39
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x3b
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x15
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x15
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x26
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x29
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2a
	.uleb128 0x5
	.byte	0
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x2b
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0xb
	.uleb128 0x57
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2c
	.uleb128 0x5
	.byte	0
	.uleb128 0x31
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2d
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0xb
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2e
	.uleb128 0x4109
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2f
	.uleb128 0x410a
	.byte	0
	.uleb128 0x2
	.uleb128 0x18
	.uleb128 0x2111
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x30
	.uleb128 0x4109
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x31
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x31
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x32
	.uleb128 0x1d
	.byte	0
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x33
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0xb
	.uleb128 0x57
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x34
	.uleb128 0x4109
	.byte	0
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x31
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x35
	.uleb128 0x34
	.byte	0
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x36
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x37
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x38
	.uleb128 0x1d
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0xb
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x39
	.uleb128 0x1d
	.byte	0
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x52
	.uleb128 0x1
	.uleb128 0x2138
	.uleb128 0x5
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x58
	.uleb128 0xb
	.uleb128 0x59
	.uleb128 0x5
	.uleb128 0x57
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x3a
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x20
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x3b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3c
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x20
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x3d
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3e
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3f
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x20
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x40
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x41
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x20
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x42
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x43
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x20
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x44
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x45
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x20
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x46
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x17
	.uleb128 0x2137
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x47
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x20
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x48
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x31
	.uleb128 0x13
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x6
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x2117
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x49
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_loc,"",@progbits
.Ldebug_loc0:
.LVUS172:
	.uleb128 0
	.uleb128 .LVU4278
	.uleb128 .LVU4278
	.uleb128 0
.LLST172:
	.4byte	.LVL646
	.4byte	.LVL647
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL647
	.4byte	.LFE107
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS37:
	.uleb128 0
	.uleb128 .LVU1017
	.uleb128 .LVU1017
	.uleb128 .LVU1019
	.uleb128 .LVU1019
	.uleb128 .LVU4238
	.uleb128 .LVU4238
	.uleb128 .LVU4241
	.uleb128 .LVU4242
	.uleb128 .LVU4250
.LLST37:
	.4byte	.LVL126
	.4byte	.LVL126
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL126
	.4byte	.LVL127
	.2byte	0x3
	.byte	0x72
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL127
	.4byte	.LVL635
	.2byte	0x3
	.byte	0x7c
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL635
	.4byte	.LVL636
	.2byte	0x1
	.byte	0x5c
	.4byte	.LVL637
	.4byte	.LVL645
	.2byte	0x3
	.byte	0x7c
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS38:
	.uleb128 .LVU1068
	.uleb128 .LVU1084
.LLST38:
	.4byte	.LVL129
	.4byte	.LVL129
	.2byte	0x1
	.byte	0x54
	.4byte	0
	.4byte	0
.LVUS39:
	.uleb128 .LVU1070
	.uleb128 .LVU1075
.LLST39:
	.4byte	.LVL129
	.4byte	.LVL129
	.2byte	0x5
	.byte	0x74
	.sleb128 0
	.byte	0x38
	.byte	0x25
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS40:
	.uleb128 .LVU1077
	.uleb128 .LVU1082
.LLST40:
	.4byte	.LVL129
	.4byte	.LVL129
	.2byte	0x1
	.byte	0x54
	.4byte	0
	.4byte	0
.LVUS41:
	.uleb128 .LVU1088
	.uleb128 .LVU1093
.LLST41:
	.4byte	.LVL129
	.4byte	.LVL129
	.2byte	0x1
	.byte	0x56
	.4byte	0
	.4byte	0
.LVUS42:
	.uleb128 .LVU1126
	.uleb128 .LVU1139
.LLST42:
	.4byte	.LVL138
	.4byte	.LVL140
	.2byte	0x5
	.byte	0x73
	.sleb128 0
	.byte	0x40
	.byte	0x21
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS43:
	.uleb128 .LVU1133
	.uleb128 .LVU1139
.LLST43:
	.4byte	.LVL139
	.4byte	.LVL140
	.2byte	0x5
	.byte	0x73
	.sleb128 0
	.byte	0x40
	.byte	0x21
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS44:
	.uleb128 .LVU1133
	.uleb128 .LVU1144
.LLST44:
	.4byte	.LVL139
	.4byte	.LVL141
	.2byte	0x1
	.byte	0x56
	.4byte	0
	.4byte	0
.LVUS45:
	.uleb128 .LVU1181
	.uleb128 .LVU1188
	.uleb128 .LVU1189
	.uleb128 .LVU1191
	.uleb128 .LVU1191
	.uleb128 .LVU1192
	.uleb128 .LVU1192
	.uleb128 .LVU1196
	.uleb128 .LVU1196
	.uleb128 .LVU1197
	.uleb128 .LVU1197
	.uleb128 .LVU1198
	.uleb128 .LVU1200
	.uleb128 .LVU1204
	.uleb128 .LVU1204
	.uleb128 .LVU1206
.LLST45:
	.4byte	.LVL148
	.4byte	.LVL149-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL150
	.4byte	.LVL151
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL151
	.4byte	.LVL152
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL152
	.4byte	.LVL154
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL154
	.4byte	.LVL155
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL155
	.4byte	.LVL156-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL157
	.4byte	.LVL158
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL158
	.4byte	.LVL159
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS46:
	.uleb128 .LVU1193
	.uleb128 .LVU1196
	.uleb128 .LVU1196
	.uleb128 .LVU1197
	.uleb128 .LVU1197
	.uleb128 .LVU1198
.LLST46:
	.4byte	.LVL153
	.4byte	.LVL154
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL154
	.4byte	.LVL155
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL155
	.4byte	.LVL156-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS47:
	.uleb128 .LVU1270
	.uleb128 .LVU1275
.LLST47:
	.4byte	.LVL167
	.4byte	.LVL168
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS48:
	.uleb128 .LVU1310
	.uleb128 .LVU1340
.LLST48:
	.4byte	.LVL175
	.4byte	.LVL179
	.2byte	0x1
	.byte	0x55
	.4byte	0
	.4byte	0
.LVUS49:
	.uleb128 .LVU1312
	.uleb128 .LVU1324
.LLST49:
	.4byte	.LVL175
	.4byte	.LVL177
	.2byte	0x5
	.byte	0x75
	.sleb128 0
	.byte	0x38
	.byte	0x25
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS50:
	.uleb128 .LVU1312
	.uleb128 .LVU1318
	.uleb128 .LVU1318
	.uleb128 .LVU1324
.LLST50:
	.4byte	.LVL175
	.4byte	.LVL176
	.2byte	0x4
	.byte	0x72
	.sleb128 256
	.byte	0x9f
	.4byte	.LVL176
	.4byte	.LVL177
	.2byte	0x4
	.byte	0x74
	.sleb128 256
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS51:
	.uleb128 .LVU1326
	.uleb128 .LVU1337
.LLST51:
	.4byte	.LVL177
	.4byte	.LVL178
	.2byte	0x1
	.byte	0x55
	.4byte	0
	.4byte	0
.LVUS52:
	.uleb128 .LVU1326
	.uleb128 .LVU1337
.LLST52:
	.4byte	.LVL177
	.4byte	.LVL178
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS53:
	.uleb128 .LVU1352
	.uleb128 .LVU1354
.LLST53:
	.4byte	.LVL181
	.4byte	.LVL182-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS54:
	.uleb128 .LVU1492
	.uleb128 .LVU1499
	.uleb128 .LVU1500
	.uleb128 .LVU1502
	.uleb128 .LVU1502
	.uleb128 .LVU1503
	.uleb128 .LVU1503
	.uleb128 .LVU1507
	.uleb128 .LVU1507
	.uleb128 .LVU1508
	.uleb128 .LVU1508
	.uleb128 .LVU1509
	.uleb128 .LVU1511
	.uleb128 .LVU1515
	.uleb128 .LVU1515
	.uleb128 .LVU1517
.LLST54:
	.4byte	.LVL200
	.4byte	.LVL201-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL202
	.4byte	.LVL203
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL203
	.4byte	.LVL204
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL204
	.4byte	.LVL206
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL206
	.4byte	.LVL207
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL207
	.4byte	.LVL208-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL209
	.4byte	.LVL210
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL210
	.4byte	.LVL211
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS55:
	.uleb128 .LVU1504
	.uleb128 .LVU1507
	.uleb128 .LVU1507
	.uleb128 .LVU1508
	.uleb128 .LVU1508
	.uleb128 .LVU1509
.LLST55:
	.4byte	.LVL205
	.4byte	.LVL206
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL206
	.4byte	.LVL207
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL207
	.4byte	.LVL208-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS56:
	.uleb128 .LVU1581
	.uleb128 .LVU1586
.LLST56:
	.4byte	.LVL219
	.4byte	.LVL220
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS57:
	.uleb128 .LVU1645
	.uleb128 .LVU1647
.LLST57:
	.4byte	.LVL229
	.4byte	.LVL229
	.2byte	0x1
	.byte	0x52
	.4byte	0
	.4byte	0
.LVUS58:
	.uleb128 .LVU1679
	.uleb128 .LVU1694
.LLST58:
	.4byte	.LVL236
	.4byte	.LVL238
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS59:
	.uleb128 .LVU1682
	.uleb128 .LVU1694
.LLST59:
	.4byte	.LVL237
	.4byte	.LVL238
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS60:
	.uleb128 .LVU1682
	.uleb128 .LVU1694
.LLST60:
	.4byte	.LVL237
	.4byte	.LVL238
	.2byte	0x1
	.byte	0x54
	.4byte	0
	.4byte	0
.LVUS61:
	.uleb128 .LVU1739
	.uleb128 .LVU1746
	.uleb128 .LVU1747
	.uleb128 .LVU1749
	.uleb128 .LVU1749
	.uleb128 .LVU1750
	.uleb128 .LVU1750
	.uleb128 .LVU1754
	.uleb128 .LVU1754
	.uleb128 .LVU1755
	.uleb128 .LVU1755
	.uleb128 .LVU1756
	.uleb128 .LVU1758
	.uleb128 .LVU1762
	.uleb128 .LVU1762
	.uleb128 .LVU1764
.LLST61:
	.4byte	.LVL246
	.4byte	.LVL247-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL248
	.4byte	.LVL249
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL249
	.4byte	.LVL250
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL250
	.4byte	.LVL252
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL252
	.4byte	.LVL253
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL253
	.4byte	.LVL254-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL255
	.4byte	.LVL256
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL256
	.4byte	.LVL257
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS62:
	.uleb128 .LVU1751
	.uleb128 .LVU1754
	.uleb128 .LVU1754
	.uleb128 .LVU1755
	.uleb128 .LVU1755
	.uleb128 .LVU1756
.LLST62:
	.4byte	.LVL251
	.4byte	.LVL252
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL252
	.4byte	.LVL253
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL253
	.4byte	.LVL254-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS63:
	.uleb128 .LVU1828
	.uleb128 .LVU1833
.LLST63:
	.4byte	.LVL265
	.4byte	.LVL266
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS64:
	.uleb128 .LVU1881
	.uleb128 .LVU1884
.LLST64:
	.4byte	.LVL274
	.4byte	.LVL275
	.2byte	0x1
	.byte	0x52
	.4byte	0
	.4byte	0
.LVUS65:
	.uleb128 .LVU1965
	.uleb128 .LVU1968
.LLST65:
	.4byte	.LVL287
	.4byte	.LVL288-1
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS66:
	.uleb128 .LVU1966
	.uleb128 .LVU1968
.LLST66:
	.4byte	.LVL287
	.4byte	.LVL288-1
	.2byte	0xd
	.byte	0x73
	.sleb128 1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x73
	.sleb128 0
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x21
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS67:
	.uleb128 .LVU2006
	.uleb128 .LVU2013
	.uleb128 .LVU2014
	.uleb128 .LVU2016
	.uleb128 .LVU2016
	.uleb128 .LVU2017
	.uleb128 .LVU2017
	.uleb128 .LVU2021
	.uleb128 .LVU2021
	.uleb128 .LVU2022
	.uleb128 .LVU2022
	.uleb128 .LVU2023
	.uleb128 .LVU2025
	.uleb128 .LVU2029
	.uleb128 .LVU2029
	.uleb128 .LVU2031
.LLST67:
	.4byte	.LVL294
	.4byte	.LVL295-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL296
	.4byte	.LVL297
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL297
	.4byte	.LVL298
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL298
	.4byte	.LVL300
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL300
	.4byte	.LVL301
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL301
	.4byte	.LVL302-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL303
	.4byte	.LVL304
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL304
	.4byte	.LVL305
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS68:
	.uleb128 .LVU2018
	.uleb128 .LVU2021
	.uleb128 .LVU2021
	.uleb128 .LVU2022
	.uleb128 .LVU2022
	.uleb128 .LVU2023
.LLST68:
	.4byte	.LVL299
	.4byte	.LVL300
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL300
	.4byte	.LVL301
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL301
	.4byte	.LVL302-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS69:
	.uleb128 .LVU2067
	.uleb128 .LVU2070
.LLST69:
	.4byte	.LVL306
	.4byte	.LVL307-1
	.2byte	0x6
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS70:
	.uleb128 .LVU2068
	.uleb128 .LVU2070
.LLST70:
	.4byte	.LVL306
	.4byte	.LVL307-1
	.2byte	0xb
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x23
	.uleb128 0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS71:
	.uleb128 .LVU2075
	.uleb128 .LVU2080
.LLST71:
	.4byte	.LVL308
	.4byte	.LVL309
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS72:
	.uleb128 .LVU2115
	.uleb128 .LVU2120
.LLST72:
	.4byte	.LVL316
	.4byte	.LVL317
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS73:
	.uleb128 .LVU2148
	.uleb128 .LVU2156
	.uleb128 .LVU2156
	.uleb128 .LVU2157
	.uleb128 .LVU2157
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2176
.LLST73:
	.4byte	.LVL323
	.4byte	.LVL324
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL324
	.4byte	.LVL325
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL325
	.4byte	.LVL328-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL329
	.4byte	.LVL331
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS74:
	.uleb128 .LVU2157
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2176
.LLST74:
	.4byte	.LVL325
	.4byte	.LVL328-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL329
	.4byte	.LVL331
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS75:
	.uleb128 .LVU2159
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2176
.LLST75:
	.4byte	.LVL325
	.4byte	.LVL328-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL329
	.4byte	.LVL331
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS76:
	.uleb128 .LVU2159
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2176
.LLST76:
	.4byte	.LVL325
	.4byte	.LVL328-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL329
	.4byte	.LVL331
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS77:
	.uleb128 .LVU2165
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2176
.LLST77:
	.4byte	.LVL326
	.4byte	.LVL328-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL329
	.4byte	.LVL331
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS78:
	.uleb128 .LVU2165
	.uleb128 .LVU2169
	.uleb128 .LVU2169
	.uleb128 .LVU2170
	.uleb128 .LVU2171
	.uleb128 .LVU2174
	.uleb128 .LVU2174
	.uleb128 .LVU2176
.LLST78:
	.4byte	.LVL326
	.4byte	.LVL327
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL327
	.4byte	.LVL328-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL329
	.4byte	.LVL330
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL330
	.4byte	.LVL331
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS79:
	.uleb128 .LVU2187
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2215
.LLST79:
	.4byte	.LVL333
	.4byte	.LVL338-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL339
	.4byte	.LVL341
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS80:
	.uleb128 .LVU2191
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2215
.LLST80:
	.4byte	.LVL334
	.4byte	.LVL338-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL339
	.4byte	.LVL341
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS81:
	.uleb128 .LVU2196
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2215
.LLST81:
	.4byte	.LVL335
	.4byte	.LVL338-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL339
	.4byte	.LVL341
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS82:
	.uleb128 .LVU2196
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2215
.LLST82:
	.4byte	.LVL335
	.4byte	.LVL338-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL339
	.4byte	.LVL341
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS83:
	.uleb128 .LVU2204
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2215
.LLST83:
	.4byte	.LVL336
	.4byte	.LVL338-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL339
	.4byte	.LVL341
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS84:
	.uleb128 .LVU2204
	.uleb128 .LVU2208
	.uleb128 .LVU2208
	.uleb128 .LVU2209
	.uleb128 .LVU2210
	.uleb128 .LVU2213
	.uleb128 .LVU2213
	.uleb128 .LVU2215
.LLST84:
	.4byte	.LVL336
	.4byte	.LVL337
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL337
	.4byte	.LVL338-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL339
	.4byte	.LVL340
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL340
	.4byte	.LVL341
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS85:
	.uleb128 .LVU2222
	.uleb128 .LVU2230
	.uleb128 .LVU2230
	.uleb128 .LVU2231
	.uleb128 .LVU2231
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2250
.LLST85:
	.4byte	.LVL342
	.4byte	.LVL343
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL343
	.4byte	.LVL344
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL344
	.4byte	.LVL347-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL348
	.4byte	.LVL350
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS86:
	.uleb128 .LVU2231
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2250
.LLST86:
	.4byte	.LVL344
	.4byte	.LVL347-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL348
	.4byte	.LVL350
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS87:
	.uleb128 .LVU2233
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2250
.LLST87:
	.4byte	.LVL344
	.4byte	.LVL347-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL348
	.4byte	.LVL350
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS88:
	.uleb128 .LVU2233
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2250
.LLST88:
	.4byte	.LVL344
	.4byte	.LVL347-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL348
	.4byte	.LVL350
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS89:
	.uleb128 .LVU2239
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2250
.LLST89:
	.4byte	.LVL345
	.4byte	.LVL347-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL348
	.4byte	.LVL350
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS90:
	.uleb128 .LVU2239
	.uleb128 .LVU2243
	.uleb128 .LVU2243
	.uleb128 .LVU2244
	.uleb128 .LVU2245
	.uleb128 .LVU2248
	.uleb128 .LVU2248
	.uleb128 .LVU2250
.LLST90:
	.4byte	.LVL345
	.4byte	.LVL346
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL346
	.4byte	.LVL347-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL348
	.4byte	.LVL349
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL349
	.4byte	.LVL350
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS91:
	.uleb128 .LVU2261
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2289
.LLST91:
	.4byte	.LVL352
	.4byte	.LVL357-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL358
	.4byte	.LVL360
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS92:
	.uleb128 .LVU2265
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2289
.LLST92:
	.4byte	.LVL353
	.4byte	.LVL357-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL358
	.4byte	.LVL360
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS93:
	.uleb128 .LVU2270
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2289
.LLST93:
	.4byte	.LVL354
	.4byte	.LVL357-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL358
	.4byte	.LVL360
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS94:
	.uleb128 .LVU2270
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2289
.LLST94:
	.4byte	.LVL354
	.4byte	.LVL357-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL358
	.4byte	.LVL360
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS95:
	.uleb128 .LVU2278
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2289
.LLST95:
	.4byte	.LVL355
	.4byte	.LVL357-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL358
	.4byte	.LVL360
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS96:
	.uleb128 .LVU2278
	.uleb128 .LVU2282
	.uleb128 .LVU2282
	.uleb128 .LVU2283
	.uleb128 .LVU2284
	.uleb128 .LVU2287
	.uleb128 .LVU2287
	.uleb128 .LVU2289
.LLST96:
	.4byte	.LVL355
	.4byte	.LVL356
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL356
	.4byte	.LVL357-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL358
	.4byte	.LVL359
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL359
	.4byte	.LVL360
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS97:
	.uleb128 .LVU2340
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2368
.LLST97:
	.4byte	.LVL362
	.4byte	.LVL367-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL368
	.4byte	.LVL370
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS98:
	.uleb128 .LVU2344
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2368
.LLST98:
	.4byte	.LVL363
	.4byte	.LVL367-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL368
	.4byte	.LVL370
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS99:
	.uleb128 .LVU2349
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2368
.LLST99:
	.4byte	.LVL364
	.4byte	.LVL367-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL368
	.4byte	.LVL370
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS100:
	.uleb128 .LVU2349
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2368
.LLST100:
	.4byte	.LVL364
	.4byte	.LVL367-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL368
	.4byte	.LVL370
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS101:
	.uleb128 .LVU2357
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2368
.LLST101:
	.4byte	.LVL365
	.4byte	.LVL367-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL368
	.4byte	.LVL370
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS102:
	.uleb128 .LVU2357
	.uleb128 .LVU2361
	.uleb128 .LVU2361
	.uleb128 .LVU2362
	.uleb128 .LVU2363
	.uleb128 .LVU2366
	.uleb128 .LVU2366
	.uleb128 .LVU2368
.LLST102:
	.4byte	.LVL365
	.4byte	.LVL366
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL366
	.4byte	.LVL367-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL368
	.4byte	.LVL369
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL369
	.4byte	.LVL370
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS103:
	.uleb128 .LVU2375
	.uleb128 .LVU2383
	.uleb128 .LVU2383
	.uleb128 .LVU2384
	.uleb128 .LVU2384
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2403
.LLST103:
	.4byte	.LVL371
	.4byte	.LVL372
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL372
	.4byte	.LVL373
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL373
	.4byte	.LVL376-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL377
	.4byte	.LVL379
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS104:
	.uleb128 .LVU2384
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2403
.LLST104:
	.4byte	.LVL373
	.4byte	.LVL376-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL377
	.4byte	.LVL379
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS105:
	.uleb128 .LVU2386
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2403
.LLST105:
	.4byte	.LVL373
	.4byte	.LVL376-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL377
	.4byte	.LVL379
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS106:
	.uleb128 .LVU2386
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2403
.LLST106:
	.4byte	.LVL373
	.4byte	.LVL376-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL377
	.4byte	.LVL379
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS107:
	.uleb128 .LVU2392
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2403
.LLST107:
	.4byte	.LVL374
	.4byte	.LVL376-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL377
	.4byte	.LVL379
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS108:
	.uleb128 .LVU2392
	.uleb128 .LVU2396
	.uleb128 .LVU2396
	.uleb128 .LVU2397
	.uleb128 .LVU2398
	.uleb128 .LVU2401
	.uleb128 .LVU2401
	.uleb128 .LVU2403
.LLST108:
	.4byte	.LVL374
	.4byte	.LVL375
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL375
	.4byte	.LVL376-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL377
	.4byte	.LVL378
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL378
	.4byte	.LVL379
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS109:
	.uleb128 .LVU2414
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2442
.LLST109:
	.4byte	.LVL381
	.4byte	.LVL386-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL387
	.4byte	.LVL389
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS110:
	.uleb128 .LVU2418
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2442
.LLST110:
	.4byte	.LVL382
	.4byte	.LVL386-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL387
	.4byte	.LVL389
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS111:
	.uleb128 .LVU2423
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2442
.LLST111:
	.4byte	.LVL383
	.4byte	.LVL386-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL387
	.4byte	.LVL389
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS112:
	.uleb128 .LVU2423
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2442
.LLST112:
	.4byte	.LVL383
	.4byte	.LVL386-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL387
	.4byte	.LVL389
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS113:
	.uleb128 .LVU2431
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2442
.LLST113:
	.4byte	.LVL384
	.4byte	.LVL386-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL387
	.4byte	.LVL389
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS114:
	.uleb128 .LVU2431
	.uleb128 .LVU2435
	.uleb128 .LVU2435
	.uleb128 .LVU2436
	.uleb128 .LVU2437
	.uleb128 .LVU2440
	.uleb128 .LVU2440
	.uleb128 .LVU2442
.LLST114:
	.4byte	.LVL384
	.4byte	.LVL385
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL385
	.4byte	.LVL386-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL387
	.4byte	.LVL388
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL388
	.4byte	.LVL389
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS115:
	.uleb128 .LVU2450
	.uleb128 .LVU2457
	.uleb128 .LVU2458
	.uleb128 .LVU2460
	.uleb128 .LVU2460
	.uleb128 .LVU2461
	.uleb128 .LVU2461
	.uleb128 .LVU2465
	.uleb128 .LVU2465
	.uleb128 .LVU2466
	.uleb128 .LVU2466
	.uleb128 .LVU2467
	.uleb128 .LVU2469
	.uleb128 .LVU2473
	.uleb128 .LVU2473
	.uleb128 .LVU2475
.LLST115:
	.4byte	.LVL390
	.4byte	.LVL391-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL392
	.4byte	.LVL393
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL393
	.4byte	.LVL394
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL394
	.4byte	.LVL396
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL396
	.4byte	.LVL397
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL397
	.4byte	.LVL398-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL399
	.4byte	.LVL400
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL400
	.4byte	.LVL401
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS116:
	.uleb128 .LVU2462
	.uleb128 .LVU2465
	.uleb128 .LVU2465
	.uleb128 .LVU2466
	.uleb128 .LVU2466
	.uleb128 .LVU2467
.LLST116:
	.4byte	.LVL395
	.4byte	.LVL396
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL396
	.4byte	.LVL397
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL397
	.4byte	.LVL398-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS117:
	.uleb128 .LVU2510
	.uleb128 .LVU2518
	.uleb128 .LVU2518
	.uleb128 .LVU2519
	.uleb128 .LVU2519
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2538
.LLST117:
	.4byte	.LVL402
	.4byte	.LVL403
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL403
	.4byte	.LVL404
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL404
	.4byte	.LVL407-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL408
	.4byte	.LVL410
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS118:
	.uleb128 .LVU2519
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2538
.LLST118:
	.4byte	.LVL404
	.4byte	.LVL407-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL408
	.4byte	.LVL410
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS119:
	.uleb128 .LVU2521
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2538
.LLST119:
	.4byte	.LVL404
	.4byte	.LVL407-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL408
	.4byte	.LVL410
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS120:
	.uleb128 .LVU2521
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2538
.LLST120:
	.4byte	.LVL404
	.4byte	.LVL407-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL408
	.4byte	.LVL410
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS121:
	.uleb128 .LVU2527
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2538
.LLST121:
	.4byte	.LVL405
	.4byte	.LVL407-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL408
	.4byte	.LVL410
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS122:
	.uleb128 .LVU2527
	.uleb128 .LVU2531
	.uleb128 .LVU2531
	.uleb128 .LVU2532
	.uleb128 .LVU2533
	.uleb128 .LVU2536
	.uleb128 .LVU2536
	.uleb128 .LVU2538
.LLST122:
	.4byte	.LVL405
	.4byte	.LVL406
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL406
	.4byte	.LVL407-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL408
	.4byte	.LVL409
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL409
	.4byte	.LVL410
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS123:
	.uleb128 .LVU2549
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2577
.LLST123:
	.4byte	.LVL412
	.4byte	.LVL417-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL418
	.4byte	.LVL420
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS124:
	.uleb128 .LVU2553
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2577
.LLST124:
	.4byte	.LVL413
	.4byte	.LVL417-1
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL418
	.4byte	.LVL420
	.2byte	0x6
	.byte	0x73
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS125:
	.uleb128 .LVU2558
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2577
.LLST125:
	.4byte	.LVL414
	.4byte	.LVL417-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL418
	.4byte	.LVL420
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS126:
	.uleb128 .LVU2558
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2577
.LLST126:
	.4byte	.LVL414
	.4byte	.LVL417-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL418
	.4byte	.LVL420
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS127:
	.uleb128 .LVU2566
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2577
.LLST127:
	.4byte	.LVL415
	.4byte	.LVL417-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL418
	.4byte	.LVL420
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS128:
	.uleb128 .LVU2566
	.uleb128 .LVU2570
	.uleb128 .LVU2570
	.uleb128 .LVU2571
	.uleb128 .LVU2572
	.uleb128 .LVU2575
	.uleb128 .LVU2575
	.uleb128 .LVU2577
.LLST128:
	.4byte	.LVL415
	.4byte	.LVL416
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL416
	.4byte	.LVL417-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL418
	.4byte	.LVL419
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL419
	.4byte	.LVL420
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS129:
	.uleb128 .LVU2584
	.uleb128 .LVU2592
	.uleb128 .LVU2592
	.uleb128 .LVU2593
	.uleb128 .LVU2593
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2612
.LLST129:
	.4byte	.LVL421
	.4byte	.LVL422
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL422
	.4byte	.LVL423
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL423
	.4byte	.LVL426-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL427
	.4byte	.LVL429
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS130:
	.uleb128 .LVU2593
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2612
.LLST130:
	.4byte	.LVL423
	.4byte	.LVL426-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL427
	.4byte	.LVL429
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS131:
	.uleb128 .LVU2595
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2612
.LLST131:
	.4byte	.LVL423
	.4byte	.LVL426-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL427
	.4byte	.LVL429
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS132:
	.uleb128 .LVU2595
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2612
.LLST132:
	.4byte	.LVL423
	.4byte	.LVL426-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL427
	.4byte	.LVL429
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS133:
	.uleb128 .LVU2601
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2612
.LLST133:
	.4byte	.LVL424
	.4byte	.LVL426-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL427
	.4byte	.LVL429
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS134:
	.uleb128 .LVU2601
	.uleb128 .LVU2605
	.uleb128 .LVU2605
	.uleb128 .LVU2606
	.uleb128 .LVU2607
	.uleb128 .LVU2610
	.uleb128 .LVU2610
	.uleb128 .LVU2612
.LLST134:
	.4byte	.LVL424
	.4byte	.LVL425
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL425
	.4byte	.LVL426-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL427
	.4byte	.LVL428
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL428
	.4byte	.LVL429
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS135:
	.uleb128 .LVU2630
	.uleb128 .LVU2645
.LLST135:
	.4byte	.LVL431
	.4byte	.LVL433
	.2byte	0x6
	.byte	0x75
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS136:
	.uleb128 .LVU2634
	.uleb128 .LVU2645
.LLST136:
	.4byte	.LVL432
	.4byte	.LVL433
	.2byte	0x6
	.byte	0x75
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS137:
	.uleb128 .LVU2636
	.uleb128 .LVU2645
.LLST137:
	.4byte	.LVL432
	.4byte	.LVL433
	.2byte	0x1
	.byte	0x55
	.4byte	0
	.4byte	0
.LVUS138:
	.uleb128 .LVU2636
	.uleb128 .LVU2645
.LLST138:
	.4byte	.LVL432
	.4byte	.LVL433
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS139:
	.uleb128 .LVU2677
	.uleb128 .LVU2681
.LLST139:
	.4byte	.LVL435
	.4byte	.LVL436
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS140:
	.uleb128 .LVU2695
	.uleb128 .LVU2701
	.uleb128 .LVU2701
	.uleb128 .LVU2702
	.uleb128 .LVU2702
	.uleb128 .LVU2717
	.uleb128 .LVU2718
	.uleb128 .LVU2723
.LLST140:
	.4byte	.LVL437
	.4byte	.LVL438
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL438
	.4byte	.LVL439
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL439
	.4byte	.LVL444-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL445
	.4byte	.LVL447
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS141:
	.uleb128 .LVU2702
	.uleb128 .LVU2717
	.uleb128 .LVU2718
	.uleb128 .LVU2723
.LLST141:
	.4byte	.LVL439
	.4byte	.LVL444-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL445
	.4byte	.LVL447
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS142:
	.uleb128 .LVU2704
	.uleb128 .LVU2717
	.uleb128 .LVU2718
	.uleb128 .LVU2723
.LLST142:
	.4byte	.LVL439
	.4byte	.LVL444-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL445
	.4byte	.LVL447
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS143:
	.uleb128 .LVU2704
	.uleb128 .LVU2709
	.uleb128 .LVU2711
	.uleb128 .LVU2715
	.uleb128 .LVU2715
	.uleb128 .LVU2716
	.uleb128 .LVU2718
	.uleb128 .LVU2721
.LLST143:
	.4byte	.LVL439
	.4byte	.LVL440
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL441
	.4byte	.LVL442
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL442
	.4byte	.LVL443
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL445
	.4byte	.LVL446
	.2byte	0x1
	.byte	0x52
	.4byte	0
	.4byte	0
.LVUS144:
	.uleb128 .LVU2711
	.uleb128 .LVU2717
	.uleb128 .LVU2718
	.uleb128 .LVU2723
.LLST144:
	.4byte	.LVL441
	.4byte	.LVL444-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL445
	.4byte	.LVL447
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS145:
	.uleb128 .LVU2711
	.uleb128 .LVU2715
	.uleb128 .LVU2715
	.uleb128 .LVU2716
	.uleb128 .LVU2718
	.uleb128 .LVU2721
.LLST145:
	.4byte	.LVL441
	.4byte	.LVL442
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL442
	.4byte	.LVL443
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL445
	.4byte	.LVL446
	.2byte	0x1
	.byte	0x52
	.4byte	0
	.4byte	0
.LVUS146:
	.uleb128 .LVU2737
	.uleb128 .LVU2745
	.uleb128 .LVU2745
	.uleb128 .LVU2746
	.uleb128 .LVU2746
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2765
.LLST146:
	.4byte	.LVL448
	.4byte	.LVL449
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL449
	.4byte	.LVL450
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL450
	.4byte	.LVL453-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL454
	.4byte	.LVL456
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS147:
	.uleb128 .LVU2746
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2765
.LLST147:
	.4byte	.LVL450
	.4byte	.LVL453-1
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL454
	.4byte	.LVL456
	.2byte	0xb
	.byte	0x3
	.4byte	a
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS148:
	.uleb128 .LVU2748
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2765
.LLST148:
	.4byte	.LVL450
	.4byte	.LVL453-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL454
	.4byte	.LVL456
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS149:
	.uleb128 .LVU2748
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2765
.LLST149:
	.4byte	.LVL450
	.4byte	.LVL453-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL454
	.4byte	.LVL456
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS150:
	.uleb128 .LVU2754
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2765
.LLST150:
	.4byte	.LVL451
	.4byte	.LVL453-1
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	.LVL454
	.4byte	.LVL456
	.2byte	0x5
	.byte	0x3
	.4byte	a
	.4byte	0
	.4byte	0
.LVUS151:
	.uleb128 .LVU2754
	.uleb128 .LVU2758
	.uleb128 .LVU2758
	.uleb128 .LVU2759
	.uleb128 .LVU2760
	.uleb128 .LVU2763
	.uleb128 .LVU2763
	.uleb128 .LVU2765
.LLST151:
	.4byte	.LVL451
	.4byte	.LVL452
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL452
	.4byte	.LVL453-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL454
	.4byte	.LVL455
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL455
	.4byte	.LVL456
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS152:
	.uleb128 .LVU3026
	.uleb128 .LVU3033
	.uleb128 .LVU3034
	.uleb128 .LVU3036
	.uleb128 .LVU3036
	.uleb128 .LVU3037
	.uleb128 .LVU3037
	.uleb128 .LVU3041
	.uleb128 .LVU3041
	.uleb128 .LVU3042
	.uleb128 .LVU3042
	.uleb128 .LVU3043
	.uleb128 .LVU3045
	.uleb128 .LVU3049
	.uleb128 .LVU3049
	.uleb128 .LVU3051
.LLST152:
	.4byte	.LVL474
	.4byte	.LVL475-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL476
	.4byte	.LVL477
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL477
	.4byte	.LVL478
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL478
	.4byte	.LVL480
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL480
	.4byte	.LVL481
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL481
	.4byte	.LVL482-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL483
	.4byte	.LVL484
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL484
	.4byte	.LVL485
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS153:
	.uleb128 .LVU3038
	.uleb128 .LVU3041
	.uleb128 .LVU3041
	.uleb128 .LVU3042
	.uleb128 .LVU3042
	.uleb128 .LVU3043
.LLST153:
	.4byte	.LVL479
	.4byte	.LVL480
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL480
	.4byte	.LVL481
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL481
	.4byte	.LVL482-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS154:
	.uleb128 .LVU3177
	.uleb128 .LVU3182
.LLST154:
	.4byte	.LVL495
	.4byte	.LVL496
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS155:
	.uleb128 .LVU3259
	.uleb128 .LVU3264
.LLST155:
	.4byte	.LVL503
	.4byte	.LVL504
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS156:
	.uleb128 .LVU3441
	.uleb128 .LVU3454
	.uleb128 .LVU3455
	.uleb128 .LVU3460
.LLST156:
	.4byte	.LVL517
	.4byte	.LVL520-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL521
	.4byte	.LVL523
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS157:
	.uleb128 .LVU3449
	.uleb128 .LVU3453
	.uleb128 .LVU3453
	.uleb128 .LVU3454
	.uleb128 .LVU3455
	.uleb128 .LVU3458
	.uleb128 .LVU3458
	.uleb128 .LVU3460
.LLST157:
	.4byte	.LVL518
	.4byte	.LVL519
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL519
	.4byte	.LVL520-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL521
	.4byte	.LVL522
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL522
	.4byte	.LVL523
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS158:
	.uleb128 .LVU3569
	.uleb128 .LVU3576
	.uleb128 .LVU3577
	.uleb128 .LVU3579
	.uleb128 .LVU3579
	.uleb128 .LVU3580
	.uleb128 .LVU3580
	.uleb128 .LVU3584
	.uleb128 .LVU3584
	.uleb128 .LVU3585
	.uleb128 .LVU3585
	.uleb128 .LVU3586
	.uleb128 .LVU3588
	.uleb128 .LVU3592
	.uleb128 .LVU3592
	.uleb128 .LVU3594
.LLST158:
	.4byte	.LVL531
	.4byte	.LVL532-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL533
	.4byte	.LVL534
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL534
	.4byte	.LVL535
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL535
	.4byte	.LVL537
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL537
	.4byte	.LVL538
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL538
	.4byte	.LVL539-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL540
	.4byte	.LVL541
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL541
	.4byte	.LVL542
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS159:
	.uleb128 .LVU3581
	.uleb128 .LVU3584
	.uleb128 .LVU3584
	.uleb128 .LVU3585
	.uleb128 .LVU3585
	.uleb128 .LVU3586
.LLST159:
	.4byte	.LVL536
	.4byte	.LVL537
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL537
	.4byte	.LVL538
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL538
	.4byte	.LVL539-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS160:
	.uleb128 .LVU3683
	.uleb128 .LVU3696
	.uleb128 .LVU3697
	.uleb128 .LVU3702
.LLST160:
	.4byte	.LVL551
	.4byte	.LVL554-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL555
	.4byte	.LVL557
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS161:
	.uleb128 .LVU3691
	.uleb128 .LVU3695
	.uleb128 .LVU3695
	.uleb128 .LVU3696
	.uleb128 .LVU3697
	.uleb128 .LVU3700
	.uleb128 .LVU3700
	.uleb128 .LVU3702
.LLST161:
	.4byte	.LVL552
	.4byte	.LVL553
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL553
	.4byte	.LVL554-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL555
	.4byte	.LVL556
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL556
	.4byte	.LVL557
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS162:
	.uleb128 .LVU3720
	.uleb128 .LVU3725
.LLST162:
	.4byte	.LVL559
	.4byte	.LVL560
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS163:
	.uleb128 .LVU3789
	.uleb128 .LVU3802
	.uleb128 .LVU3803
	.uleb128 .LVU3808
.LLST163:
	.4byte	.LVL568
	.4byte	.LVL571-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL572
	.4byte	.LVL574
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS164:
	.uleb128 .LVU3797
	.uleb128 .LVU3801
	.uleb128 .LVU3801
	.uleb128 .LVU3802
	.uleb128 .LVU3803
	.uleb128 .LVU3806
	.uleb128 .LVU3806
	.uleb128 .LVU3808
.LLST164:
	.4byte	.LVL569
	.4byte	.LVL570
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL570
	.4byte	.LVL571-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL572
	.4byte	.LVL573
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL573
	.4byte	.LVL574
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS165:
	.uleb128 .LVU4030
	.uleb128 .LVU4043
	.uleb128 .LVU4044
	.uleb128 .LVU4049
.LLST165:
	.4byte	.LVL593
	.4byte	.LVL596-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL597
	.4byte	.LVL599
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS166:
	.uleb128 .LVU4038
	.uleb128 .LVU4042
	.uleb128 .LVU4042
	.uleb128 .LVU4043
	.uleb128 .LVU4044
	.uleb128 .LVU4047
	.uleb128 .LVU4047
	.uleb128 .LVU4049
.LLST166:
	.4byte	.LVL594
	.4byte	.LVL595
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL595
	.4byte	.LVL596-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL597
	.4byte	.LVL598
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL598
	.4byte	.LVL599
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS167:
	.uleb128 .LVU4057
	.uleb128 .LVU4064
	.uleb128 .LVU4065
	.uleb128 .LVU4067
	.uleb128 .LVU4067
	.uleb128 .LVU4068
	.uleb128 .LVU4068
	.uleb128 .LVU4072
	.uleb128 .LVU4072
	.uleb128 .LVU4073
	.uleb128 .LVU4073
	.uleb128 .LVU4074
	.uleb128 .LVU4076
	.uleb128 .LVU4080
	.uleb128 .LVU4080
	.uleb128 .LVU4082
.LLST167:
	.4byte	.LVL600
	.4byte	.LVL601-1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL602
	.4byte	.LVL603
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL603
	.4byte	.LVL604
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL604
	.4byte	.LVL606
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL606
	.4byte	.LVL607
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL607
	.4byte	.LVL608-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL609
	.4byte	.LVL610
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL610
	.4byte	.LVL611
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS168:
	.uleb128 .LVU4069
	.uleb128 .LVU4072
	.uleb128 .LVU4072
	.uleb128 .LVU4073
	.uleb128 .LVU4073
	.uleb128 .LVU4074
.LLST168:
	.4byte	.LVL605
	.4byte	.LVL606
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL606
	.4byte	.LVL607
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL607
	.4byte	.LVL608-1
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS169:
	.uleb128 .LVU4146
	.uleb128 .LVU4151
.LLST169:
	.4byte	.LVL619
	.4byte	.LVL620
	.2byte	0x14
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x71
	.sleb128 0
	.byte	0x94
	.byte	0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS170:
	.uleb128 .LVU4215
	.uleb128 .LVU4228
	.uleb128 .LVU4229
	.uleb128 .LVU4234
.LLST170:
	.4byte	.LVL628
	.4byte	.LVL631-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL632
	.4byte	.LVL634
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS171:
	.uleb128 .LVU4223
	.uleb128 .LVU4227
	.uleb128 .LVU4227
	.uleb128 .LVU4228
	.uleb128 .LVU4229
	.uleb128 .LVU4232
	.uleb128 .LVU4232
	.uleb128 .LVU4234
.LLST171:
	.4byte	.LVL629
	.4byte	.LVL630
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL630
	.4byte	.LVL631-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL632
	.4byte	.LVL633
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL633
	.4byte	.LVL634
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS31:
	.uleb128 .LVU924
	.uleb128 .LVU930
	.uleb128 .LVU930
	.uleb128 .LVU931
	.uleb128 .LVU931
	.uleb128 .LVU943
	.uleb128 .LVU943
	.uleb128 .LVU944
	.uleb128 .LVU944
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU951
	.uleb128 .LVU951
	.uleb128 .LVU957
.LLST31:
	.4byte	.LVL113
	.4byte	.LVL114
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL114
	.4byte	.LVL115
	.2byte	0x1
	.byte	0x58
	.4byte	.LVL115
	.4byte	.LVL117
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL117
	.4byte	.LVL118
	.2byte	0x1
	.byte	0x58
	.4byte	.LVL118
	.4byte	.LVL119-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL120
	.4byte	.LVL121
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL121
	.4byte	.LVL124
	.2byte	0x1
	.byte	0x58
	.4byte	0
	.4byte	0
.LVUS32:
	.uleb128 .LVU931
	.uleb128 .LVU943
	.uleb128 .LVU943
	.uleb128 .LVU944
	.uleb128 .LVU944
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU951
	.uleb128 .LVU951
	.uleb128 .LVU957
.LLST32:
	.4byte	.LVL115
	.4byte	.LVL117
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL117
	.4byte	.LVL118
	.2byte	0x1
	.byte	0x58
	.4byte	.LVL118
	.4byte	.LVL119-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL120
	.4byte	.LVL121
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL121
	.4byte	.LVL124
	.2byte	0x1
	.byte	0x58
	.4byte	0
	.4byte	0
.LVUS33:
	.uleb128 .LVU936
	.uleb128 .LVU943
	.uleb128 .LVU943
	.uleb128 .LVU944
	.uleb128 .LVU944
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU951
	.uleb128 .LVU951
	.uleb128 .LVU957
.LLST33:
	.4byte	.LVL116
	.4byte	.LVL117
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL117
	.4byte	.LVL118
	.2byte	0x1
	.byte	0x58
	.4byte	.LVL118
	.4byte	.LVL119-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL120
	.4byte	.LVL121
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL121
	.4byte	.LVL124
	.2byte	0x1
	.byte	0x58
	.4byte	0
	.4byte	0
.LVUS34:
	.uleb128 .LVU936
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU956
.LLST34:
	.4byte	.LVL116
	.4byte	.LVL119-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL120
	.4byte	.LVL124
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS35:
	.uleb128 .LVU944
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU951
	.uleb128 .LVU951
	.uleb128 .LVU955
.LLST35:
	.4byte	.LVL118
	.4byte	.LVL119-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL120
	.4byte	.LVL121
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL121
	.4byte	.LVL123
	.2byte	0x1
	.byte	0x58
	.4byte	0
	.4byte	0
.LVUS36:
	.uleb128 .LVU944
	.uleb128 .LVU949
	.uleb128 .LVU950
	.uleb128 .LVU954
	.uleb128 .LVU954
	.uleb128 .LVU955
.LLST36:
	.4byte	.LVL118
	.4byte	.LVL119-1
	.2byte	0x1
	.byte	0x54
	.4byte	.LVL120
	.4byte	.LVL122
	.2byte	0x1
	.byte	0x54
	.4byte	.LVL122
	.4byte	.LVL123
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS28:
	.uleb128 .LVU850
	.uleb128 .LVU853
.LLST28:
	.4byte	.LVL102
	.4byte	.LVL103
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS29:
	.uleb128 .LVU859
	.uleb128 .LVU871
	.uleb128 .LVU872
	.uleb128 .LVU876
.LLST29:
	.4byte	.LVL105
	.4byte	.LVL108-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL109
	.4byte	.LVL111
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS30:
	.uleb128 .LVU866
	.uleb128 .LVU870
	.uleb128 .LVU870
	.uleb128 .LVU871
	.uleb128 .LVU872
	.uleb128 .LVU875
	.uleb128 .LVU875
	.uleb128 .LVU876
.LLST30:
	.4byte	.LVL106
	.4byte	.LVL107
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL107
	.4byte	.LVL108-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL109
	.4byte	.LVL110
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL110
	.4byte	.LVL111
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS22:
	.uleb128 .LVU728
	.uleb128 .LVU734
	.uleb128 .LVU735
	.uleb128 .LVU747
	.uleb128 .LVU748
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU755
.LLST22:
	.4byte	.LVL88
	.4byte	.LVL89
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL90
	.4byte	.LVL92
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL93
	.4byte	.LVL94-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL95
	.4byte	.LVL96
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS23:
	.uleb128 .LVU735
	.uleb128 .LVU747
	.uleb128 .LVU748
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU755
.LLST23:
	.4byte	.LVL90
	.4byte	.LVL92
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL93
	.4byte	.LVL94-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL95
	.4byte	.LVL96
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS24:
	.uleb128 .LVU740
	.uleb128 .LVU747
	.uleb128 .LVU748
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU755
.LLST24:
	.4byte	.LVL91
	.4byte	.LVL92
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL93
	.4byte	.LVL94-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL95
	.4byte	.LVL96
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS25:
	.uleb128 .LVU740
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU760
.LLST25:
	.4byte	.LVL91
	.4byte	.LVL94-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL95
	.4byte	.LVL99
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS26:
	.uleb128 .LVU748
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU755
.LLST26:
	.4byte	.LVL93
	.4byte	.LVL94-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL95
	.4byte	.LVL96
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS27:
	.uleb128 .LVU748
	.uleb128 .LVU753
	.uleb128 .LVU754
	.uleb128 .LVU758
	.uleb128 .LVU758
	.uleb128 .LVU759
.LLST27:
	.4byte	.LVL93
	.4byte	.LVL94-1
	.2byte	0x1
	.byte	0x54
	.4byte	.LVL95
	.4byte	.LVL97
	.2byte	0x1
	.byte	0x54
	.4byte	.LVL97
	.4byte	.LVL98
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS16:
	.uleb128 .LVU405
	.uleb128 .LVU417
	.uleb128 .LVU418
	.uleb128 .LVU422
.LLST16:
	.4byte	.LVL57
	.4byte	.LVL60-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL61
	.4byte	.LVL63
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS17:
	.uleb128 .LVU412
	.uleb128 .LVU416
	.uleb128 .LVU416
	.uleb128 .LVU417
	.uleb128 .LVU418
	.uleb128 .LVU421
	.uleb128 .LVU421
	.uleb128 .LVU422
.LLST17:
	.4byte	.LVL58
	.4byte	.LVL59
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL59
	.4byte	.LVL60-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL61
	.4byte	.LVL62
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL62
	.4byte	.LVL63
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS11:
	.uleb128 .LVU198
	.uleb128 .LVU201
.LLST11:
	.4byte	.LVL39
	.4byte	.LVL40
	.2byte	0x12
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x7d
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS9:
	.uleb128 .LVU133
	.uleb128 .LVU140
	.uleb128 .LVU141
	.uleb128 .LVU143
	.uleb128 .LVU143
	.uleb128 .LVU144
	.uleb128 .LVU144
	.uleb128 .LVU149
	.uleb128 .LVU150
	.uleb128 .LVU156
	.uleb128 .LVU156
	.uleb128 .LVU158
.LLST9:
	.4byte	.LVL26
	.4byte	.LVL27-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL28
	.4byte	.LVL29
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL29
	.4byte	.LVL30
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL30
	.4byte	.LVL32-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL33
	.4byte	.LVL34
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL34
	.4byte	.LVL35
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS10:
	.uleb128 .LVU145
	.uleb128 .LVU149
.LLST10:
	.4byte	.LVL31
	.4byte	.LVL32-1
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS7:
	.uleb128 .LVU94
	.uleb128 .LVU101
	.uleb128 .LVU104
	.uleb128 .LVU106
	.uleb128 .LVU106
	.uleb128 .LVU107
	.uleb128 .LVU107
	.uleb128 .LVU112
	.uleb128 .LVU114
	.uleb128 .LVU117
	.uleb128 .LVU117
	.uleb128 .LVU120
.LLST7:
	.4byte	.LVL16
	.4byte	.LVL17-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL18
	.4byte	.LVL19
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL19
	.4byte	.LVL20
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	.LVL20
	.4byte	.LVL22-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL23
	.4byte	.LVL24
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL24
	.4byte	.LVL25
	.2byte	0x3
	.byte	0x75
	.sleb128 -1
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS8:
	.uleb128 .LVU108
	.uleb128 .LVU112
.LLST8:
	.4byte	.LVL21
	.4byte	.LVL22-1
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS6:
	.uleb128 .LVU81
	.uleb128 .LVU83
.LLST6:
	.4byte	.LVL14
	.4byte	.LVL15
	.2byte	0x2
	.byte	0x30
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS0:
	.uleb128 0
	.uleb128 .LVU4
	.uleb128 .LVU4
	.uleb128 .LVU10
	.uleb128 .LVU10
	.uleb128 0
.LLST0:
	.4byte	.LVL0
	.4byte	.LVL1
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL1
	.4byte	.LVL2-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL2-1
	.4byte	.LFE12
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS1:
	.uleb128 .LVU14
	.uleb128 .LVU18
	.uleb128 .LVU18
	.uleb128 .LVU18
.LLST1:
	.4byte	.LVL3
	.4byte	.LVL4-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL4-1
	.4byte	.LVL4
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS2:
	.uleb128 0
	.uleb128 .LVU36
	.uleb128 .LVU36
	.uleb128 0
.LLST2:
	.4byte	.LVL5
	.4byte	.LVL6
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL6
	.4byte	.LFE13
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS3:
	.uleb128 0
	.uleb128 .LVU43
	.uleb128 .LVU43
	.uleb128 0
.LLST3:
	.4byte	.LVL5
	.4byte	.LVL10-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL10-1
	.4byte	.LFE13
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x53
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS4:
	.uleb128 .LVU37
	.uleb128 .LVU43
	.uleb128 .LVU43
	.uleb128 .LVU44
	.uleb128 .LVU44
	.uleb128 .LVU48
.LLST4:
	.4byte	.LVL7
	.4byte	.LVL10-1
	.2byte	0x1
	.byte	0x53
	.4byte	.LVL10-1
	.4byte	.LVL11
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x53
	.byte	0x9f
	.4byte	.LVL11
	.4byte	.LVL13
	.2byte	0x1
	.byte	0x53
	.4byte	0
	.4byte	0
.LVUS5:
	.uleb128 .LVU37
	.uleb128 .LVU41
	.uleb128 .LVU41
	.uleb128 .LVU42
	.uleb128 .LVU42
	.uleb128 .LVU44
	.uleb128 .LVU44
	.uleb128 .LVU47
	.uleb128 .LVU47
	.uleb128 .LVU48
.LLST5:
	.4byte	.LVL7
	.4byte	.LVL8
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL8
	.4byte	.LVL9
	.2byte	0x4
	.byte	0x72
	.sleb128 512
	.byte	0x9f
	.4byte	.LVL9
	.4byte	.LVL11
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	.LVL11
	.4byte	.LVL12
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL12
	.4byte	.LVL13
	.2byte	0x4
	.byte	0xf3
	.uleb128 0x1
	.byte	0x52
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS12:
	.uleb128 .LVU223
	.uleb128 .LVU232
.LLST12:
	.4byte	.LVL42
	.4byte	.LVL45
	.2byte	0x6
	.byte	0x7c
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS13:
	.uleb128 .LVU244
	.uleb128 .LVU247
	.uleb128 .LVU247
	.uleb128 .LVU260
.LLST13:
	.4byte	.LVL47
	.4byte	.LVL48-1
	.2byte	0x6
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL48-1
	.4byte	.LVL51
	.2byte	0x6
	.byte	0x7c
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS14:
	.uleb128 .LVU245
	.uleb128 .LVU247
	.uleb128 .LVU247
	.uleb128 .LVU260
.LLST14:
	.4byte	.LVL47
	.4byte	.LVL48-1
	.2byte	0xb
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x23
	.uleb128 0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	.LVL48-1
	.4byte	.LVL51
	.2byte	0xb
	.byte	0x7c
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x23
	.uleb128 0x1
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS15:
	.uleb128 .LVU251
	.uleb128 .LVU254
.LLST15:
	.4byte	.LVL49
	.4byte	.LVL50
	.2byte	0x12
	.byte	0x72
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x38
	.byte	0x24
	.byte	0x7d
	.sleb128 0
	.byte	0x8
	.byte	0xff
	.byte	0x1a
	.byte	0x21
	.byte	0xb
	.2byte	0xff00
	.byte	0x1a
	.byte	0x9f
	.4byte	0
	.4byte	0
.LVUS18:
	.uleb128 .LVU519
	.uleb128 .LVU531
	.uleb128 .LVU532
	.uleb128 .LVU536
.LLST18:
	.4byte	.LVL68
	.4byte	.LVL71-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL72
	.4byte	.LVL74
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS19:
	.uleb128 .LVU526
	.uleb128 .LVU530
	.uleb128 .LVU530
	.uleb128 .LVU531
	.uleb128 .LVU532
	.uleb128 .LVU535
	.uleb128 .LVU535
	.uleb128 .LVU536
.LLST19:
	.4byte	.LVL69
	.4byte	.LVL70
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL70
	.4byte	.LVL71-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL72
	.4byte	.LVL73
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL73
	.4byte	.LVL74
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS20:
	.uleb128 .LVU635
	.uleb128 .LVU647
	.uleb128 .LVU648
	.uleb128 .LVU652
.LLST20:
	.4byte	.LVL79
	.4byte	.LVL82-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL83
	.4byte	.LVL85
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
.LVUS21:
	.uleb128 .LVU642
	.uleb128 .LVU646
	.uleb128 .LVU646
	.uleb128 .LVU647
	.uleb128 .LVU648
	.uleb128 .LVU651
	.uleb128 .LVU651
	.uleb128 .LVU652
.LLST21:
	.4byte	.LVL80
	.4byte	.LVL81
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL81
	.4byte	.LVL82-1
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	.LVL83
	.4byte	.LVL84
	.2byte	0x1
	.byte	0x52
	.4byte	.LVL84
	.4byte	.LVL85
	.2byte	0x5
	.byte	0x3
	.4byte	ea
	.4byte	0
	.4byte	0
	.section	.debug_aranges,"",@progbits
	.4byte	0x10c
	.2byte	0x2
	.4byte	.Ldebug_info0
	.byte	0x4
	.byte	0
	.2byte	0
	.2byte	0
	.4byte	.LFB12
	.4byte	.LFE12-.LFB12
	.4byte	.LFB13
	.4byte	.LFE13-.LFB13
	.4byte	.LFB18
	.4byte	.LFE18-.LFB18
	.4byte	.LFB22
	.4byte	.LFE22-.LFB22
	.4byte	.LFB23
	.4byte	.LFE23-.LFB23
	.4byte	.LFB26
	.4byte	.LFE26-.LFB26
	.4byte	.LFB27
	.4byte	.LFE27-.LFB27
	.4byte	.LFB30
	.4byte	.LFE30-.LFB30
	.4byte	.LFB31
	.4byte	.LFE31-.LFB31
	.4byte	.LFB35
	.4byte	.LFE35-.LFB35
	.4byte	.LFB36
	.4byte	.LFE36-.LFB36
	.4byte	.LFB37
	.4byte	.LFE37-.LFB37
	.4byte	.LFB52
	.4byte	.LFE52-.LFB52
	.4byte	.LFB55
	.4byte	.LFE55-.LFB55
	.4byte	.LFB58
	.4byte	.LFE58-.LFB58
	.4byte	.LFB59
	.4byte	.LFE59-.LFB59
	.4byte	.LFB64
	.4byte	.LFE64-.LFB64
	.4byte	.LFB67
	.4byte	.LFE67-.LFB67
	.4byte	.LFB69
	.4byte	.LFE69-.LFB69
	.4byte	.LFB74
	.4byte	.LFE74-.LFB74
	.4byte	.LFB75
	.4byte	.LFE75-.LFB75
	.4byte	.LFB78
	.4byte	.LFE78-.LFB78
	.4byte	.LFB101
	.4byte	.LFE101-.LFB101
	.4byte	.LFB102
	.4byte	.LFE102-.LFB102
	.4byte	.LFB103
	.4byte	.LFE103-.LFB103
	.4byte	.LFB104
	.4byte	.LFE104-.LFB104
	.4byte	.LFB105
	.4byte	.LFE105-.LFB105
	.4byte	.LFB106
	.4byte	.LFE106-.LFB106
	.4byte	.LFB107
	.4byte	.LFE107-.LFB107
	.4byte	.LFB108
	.4byte	.LFE108-.LFB108
	.4byte	.LFB109
	.4byte	.LFE109-.LFB109
	.4byte	0
	.4byte	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.4byte	.LBB800
	.4byte	.LBE800
	.4byte	.LBB801
	.4byte	.LBE801
	.4byte	.LBB802
	.4byte	.LBE802
	.4byte	.LBB803
	.4byte	.LBE803
	.4byte	0
	.4byte	0
	.4byte	.LBB804
	.4byte	.LBE804
	.4byte	.LBB811
	.4byte	.LBE811
	.4byte	.LBB812
	.4byte	.LBE812
	.4byte	.LBB813
	.4byte	.LBE813
	.4byte	0
	.4byte	0
	.4byte	.LBB814
	.4byte	.LBE814
	.4byte	.LBB819
	.4byte	.LBE819
	.4byte	0
	.4byte	0
	.4byte	.LBB820
	.4byte	.LBE820
	.4byte	.LBB828
	.4byte	.LBE828
	.4byte	.LBB829
	.4byte	.LBE829
	.4byte	0
	.4byte	0
	.4byte	.LBB822
	.4byte	.LBE822
	.4byte	.LBB825
	.4byte	.LBE825
	.4byte	0
	.4byte	0
	.4byte	.LBB830
	.4byte	.LBE830
	.4byte	.LBB838
	.4byte	.LBE838
	.4byte	.LBB839
	.4byte	.LBE839
	.4byte	0
	.4byte	0
	.4byte	.LBB832
	.4byte	.LBE832
	.4byte	.LBB835
	.4byte	.LBE835
	.4byte	0
	.4byte	0
	.4byte	.LBB840
	.4byte	.LBE840
	.4byte	.LBB849
	.4byte	.LBE849
	.4byte	.LBB850
	.4byte	.LBE850
	.4byte	.LBB862
	.4byte	.LBE862
	.4byte	0
	.4byte	0
	.4byte	.LBB842
	.4byte	.LBE842
	.4byte	.LBB845
	.4byte	.LBE845
	.4byte	0
	.4byte	0
	.4byte	.LBB851
	.4byte	.LBE851
	.4byte	.LBB863
	.4byte	.LBE863
	.4byte	0
	.4byte	0
	.4byte	.LBB855
	.4byte	.LBE855
	.4byte	.LBB860
	.4byte	.LBE860
	.4byte	0
	.4byte	0
	.4byte	.LBB864
	.4byte	.LBE864
	.4byte	.LBB875
	.4byte	.LBE875
	.4byte	.LBB876
	.4byte	.LBE876
	.4byte	.LBB877
	.4byte	.LBE877
	.4byte	.LBB878
	.4byte	.LBE878
	.4byte	.LBB879
	.4byte	.LBE879
	.4byte	0
	.4byte	0
	.4byte	.LBB866
	.4byte	.LBE866
	.4byte	.LBB869
	.4byte	.LBE869
	.4byte	0
	.4byte	0
	.4byte	.LBB880
	.4byte	.LBE880
	.4byte	.LBB889
	.4byte	.LBE889
	.4byte	.LBB890
	.4byte	.LBE890
	.4byte	.LBB902
	.4byte	.LBE902
	.4byte	0
	.4byte	0
	.4byte	.LBB882
	.4byte	.LBE882
	.4byte	.LBB885
	.4byte	.LBE885
	.4byte	0
	.4byte	0
	.4byte	.LBB891
	.4byte	.LBE891
	.4byte	.LBB903
	.4byte	.LBE903
	.4byte	0
	.4byte	0
	.4byte	.LBB895
	.4byte	.LBE895
	.4byte	.LBB900
	.4byte	.LBE900
	.4byte	0
	.4byte	0
	.4byte	.LBB904
	.4byte	.LBE904
	.4byte	.LBB920
	.4byte	.LBE920
	.4byte	.LBB921
	.4byte	.LBE921
	.4byte	.LBB922
	.4byte	.LBE922
	.4byte	.LBB923
	.4byte	.LBE923
	.4byte	.LBB924
	.4byte	.LBE924
	.4byte	.LBB925
	.4byte	.LBE925
	.4byte	.LBB926
	.4byte	.LBE926
	.4byte	.LBB927
	.4byte	.LBE927
	.4byte	0
	.4byte	0
	.4byte	.LBB906
	.4byte	.LBE906
	.4byte	.LBB910
	.4byte	.LBE910
	.4byte	.LBB911
	.4byte	.LBE911
	.4byte	0
	.4byte	0
	.4byte	.LBB928
	.4byte	.LBE928
	.4byte	.LBB937
	.4byte	.LBE937
	.4byte	.LBB938
	.4byte	.LBE938
	.4byte	.LBB950
	.4byte	.LBE950
	.4byte	0
	.4byte	0
	.4byte	.LBB930
	.4byte	.LBE930
	.4byte	.LBB933
	.4byte	.LBE933
	.4byte	0
	.4byte	0
	.4byte	.LBB939
	.4byte	.LBE939
	.4byte	.LBB951
	.4byte	.LBE951
	.4byte	0
	.4byte	0
	.4byte	.LBB943
	.4byte	.LBE943
	.4byte	.LBB948
	.4byte	.LBE948
	.4byte	0
	.4byte	0
	.4byte	.LBB952
	.4byte	.LBE952
	.4byte	.LBB957
	.4byte	.LBE957
	.4byte	0
	.4byte	0
	.4byte	.LBB958
	.4byte	.LBE958
	.4byte	.LBB967
	.4byte	.LBE967
	.4byte	.LBB968
	.4byte	.LBE968
	.4byte	.LBB980
	.4byte	.LBE980
	.4byte	0
	.4byte	0
	.4byte	.LBB960
	.4byte	.LBE960
	.4byte	.LBB963
	.4byte	.LBE963
	.4byte	0
	.4byte	0
	.4byte	.LBB969
	.4byte	.LBE969
	.4byte	.LBB981
	.4byte	.LBE981
	.4byte	0
	.4byte	0
	.4byte	.LBB973
	.4byte	.LBE973
	.4byte	.LBB978
	.4byte	.LBE978
	.4byte	0
	.4byte	0
	.4byte	.LBB982
	.4byte	.LBE982
	.4byte	.LBB990
	.4byte	.LBE990
	.4byte	.LBB991
	.4byte	.LBE991
	.4byte	0
	.4byte	0
	.4byte	.LBB984
	.4byte	.LBE984
	.4byte	.LBB987
	.4byte	.LBE987
	.4byte	0
	.4byte	0
	.4byte	.LBB992
	.4byte	.LBE992
	.4byte	.LBB1001
	.4byte	.LBE1001
	.4byte	.LBB1002
	.4byte	.LBE1002
	.4byte	.LBB1014
	.4byte	.LBE1014
	.4byte	0
	.4byte	0
	.4byte	.LBB994
	.4byte	.LBE994
	.4byte	.LBB997
	.4byte	.LBE997
	.4byte	0
	.4byte	0
	.4byte	.LBB1003
	.4byte	.LBE1003
	.4byte	.LBB1015
	.4byte	.LBE1015
	.4byte	0
	.4byte	0
	.4byte	.LBB1007
	.4byte	.LBE1007
	.4byte	.LBB1012
	.4byte	.LBE1012
	.4byte	0
	.4byte	0
	.4byte	.LBB1016
	.4byte	.LBE1016
	.4byte	.LBB1025
	.4byte	.LBE1025
	.4byte	.LBB1026
	.4byte	.LBE1026
	.4byte	.LBB1038
	.4byte	.LBE1038
	.4byte	0
	.4byte	0
	.4byte	.LBB1018
	.4byte	.LBE1018
	.4byte	.LBB1021
	.4byte	.LBE1021
	.4byte	0
	.4byte	0
	.4byte	.LBB1027
	.4byte	.LBE1027
	.4byte	.LBB1039
	.4byte	.LBE1039
	.4byte	0
	.4byte	0
	.4byte	.LBB1031
	.4byte	.LBE1031
	.4byte	.LBB1036
	.4byte	.LBE1036
	.4byte	0
	.4byte	0
	.4byte	.LBB1040
	.4byte	.LBE1040
	.4byte	.LBB1048
	.4byte	.LBE1048
	.4byte	.LBB1049
	.4byte	.LBE1049
	.4byte	0
	.4byte	0
	.4byte	.LBB1042
	.4byte	.LBE1042
	.4byte	.LBB1045
	.4byte	.LBE1045
	.4byte	0
	.4byte	0
	.4byte	.LBB1052
	.4byte	.LBE1052
	.4byte	.LBB1072
	.4byte	.LBE1072
	.4byte	.LBB1073
	.4byte	.LBE1073
	.4byte	.LBB1091
	.4byte	.LBE1091
	.4byte	.LBB1093
	.4byte	.LBE1093
	.4byte	.LBB1095
	.4byte	.LBE1095
	.4byte	.LBB1100
	.4byte	.LBE1100
	.4byte	0
	.4byte	0
	.4byte	.LBB1054
	.4byte	.LBE1054
	.4byte	.LBB1059
	.4byte	.LBE1059
	.4byte	.LBB1060
	.4byte	.LBE1060
	.4byte	.LBB1064
	.4byte	.LBE1064
	.4byte	0
	.4byte	0
	.4byte	.LBB1061
	.4byte	.LBE1061
	.4byte	.LBB1065
	.4byte	.LBE1065
	.4byte	0
	.4byte	0
	.4byte	.LBB1074
	.4byte	.LBE1074
	.4byte	.LBB1092
	.4byte	.LBE1092
	.4byte	.LBB1094
	.4byte	.LBE1094
	.4byte	.LBB1096
	.4byte	.LBE1096
	.4byte	.LBB1097
	.4byte	.LBE1097
	.4byte	.LBB1098
	.4byte	.LBE1098
	.4byte	.LBB1099
	.4byte	.LBE1099
	.4byte	.LBB1101
	.4byte	.LBE1101
	.4byte	0
	.4byte	0
	.4byte	.LBB1076
	.4byte	.LBE1076
	.4byte	.LBB1081
	.4byte	.LBE1081
	.4byte	.LBB1082
	.4byte	.LBE1082
	.4byte	.LBB1083
	.4byte	.LBE1083
	.4byte	0
	.4byte	0
	.4byte	.LBB1104
	.4byte	.LBE1104
	.4byte	.LBB1116
	.4byte	.LBE1116
	.4byte	.LBB1117
	.4byte	.LBE1117
	.4byte	0
	.4byte	0
	.4byte	.LBB1106
	.4byte	.LBE1106
	.4byte	.LBB1111
	.4byte	.LBE1111
	.4byte	.LBB1112
	.4byte	.LBE1112
	.4byte	.LBB1113
	.4byte	.LBE1113
	.4byte	0
	.4byte	0
	.4byte	.LBB1122
	.4byte	.LBE1122
	.4byte	.LBB1141
	.4byte	.LBE1141
	.4byte	.LBB1143
	.4byte	.LBE1143
	.4byte	.LBB2000
	.4byte	.LBE2000
	.4byte	0
	.4byte	0
	.4byte	.LBB1124
	.4byte	.LBE1124
	.4byte	.LBB1130
	.4byte	.LBE1130
	.4byte	.LBB1131
	.4byte	.LBE1131
	.4byte	0
	.4byte	0
	.4byte	.LBB1135
	.4byte	.LBE1135
	.4byte	.LBB1142
	.4byte	.LBE1142
	.4byte	.LBB1144
	.4byte	.LBE1144
	.4byte	0
	.4byte	0
	.4byte	.LBB1151
	.4byte	.LBE1151
	.4byte	.LBB1173
	.4byte	.LBE1173
	.4byte	.LBB1174
	.4byte	.LBE1174
	.4byte	.LBB1175
	.4byte	.LBE1175
	.4byte	.LBB1176
	.4byte	.LBE1176
	.4byte	0
	.4byte	0
	.4byte	.LBB1153
	.4byte	.LBE1153
	.4byte	.LBB1158
	.4byte	.LBE1158
	.4byte	.LBB1159
	.4byte	.LBE1159
	.4byte	.LBB1160
	.4byte	.LBE1160
	.4byte	0
	.4byte	0
	.4byte	.LBB1161
	.4byte	.LBE1161
	.4byte	.LBB1166
	.4byte	.LBE1166
	.4byte	.LBB1167
	.4byte	.LBE1167
	.4byte	.LBB1168
	.4byte	.LBE1168
	.4byte	0
	.4byte	0
	.4byte	.LBB1181
	.4byte	.LBE1181
	.4byte	.LBB1188
	.4byte	.LBE1188
	.4byte	0
	.4byte	0
	.4byte	.LBB1183
	.4byte	.LBE1183
	.4byte	.LBB1186
	.4byte	.LBE1186
	.4byte	0
	.4byte	0
	.4byte	.LBB1199
	.4byte	.LBE1199
	.4byte	.LBB1206
	.4byte	.LBE1206
	.4byte	0
	.4byte	0
	.4byte	.LBB1201
	.4byte	.LBE1201
	.4byte	.LBB1204
	.4byte	.LBE1204
	.4byte	0
	.4byte	0
	.4byte	.LBB1207
	.4byte	.LBE1207
	.4byte	.LBB1226
	.4byte	.LBE1226
	.4byte	.LBB1228
	.4byte	.LBE1228
	.4byte	.LBB2001
	.4byte	.LBE2001
	.4byte	0
	.4byte	0
	.4byte	.LBB1209
	.4byte	.LBE1209
	.4byte	.LBB1215
	.4byte	.LBE1215
	.4byte	.LBB1216
	.4byte	.LBE1216
	.4byte	0
	.4byte	0
	.4byte	.LBB1220
	.4byte	.LBE1220
	.4byte	.LBB1227
	.4byte	.LBE1227
	.4byte	.LBB1229
	.4byte	.LBE1229
	.4byte	0
	.4byte	0
	.4byte	.LBB1238
	.4byte	.LBE1238
	.4byte	.LBB1242
	.4byte	.LBE1242
	.4byte	.LBB1243
	.4byte	.LBE1243
	.4byte	0
	.4byte	0
	.4byte	.LBB1246
	.4byte	.LBE1246
	.4byte	.LBB1254
	.4byte	.LBE1254
	.4byte	.LBB1255
	.4byte	.LBE1255
	.4byte	0
	.4byte	0
	.4byte	.LBB1248
	.4byte	.LBE1248
	.4byte	.LBB1251
	.4byte	.LBE1251
	.4byte	0
	.4byte	0
	.4byte	.LBB1262
	.4byte	.LBE1262
	.4byte	.LBB1281
	.4byte	.LBE1281
	.4byte	.LBB1283
	.4byte	.LBE1283
	.4byte	.LBB2003
	.4byte	.LBE2003
	.4byte	0
	.4byte	0
	.4byte	.LBB1264
	.4byte	.LBE1264
	.4byte	.LBB1270
	.4byte	.LBE1270
	.4byte	.LBB1271
	.4byte	.LBE1271
	.4byte	0
	.4byte	0
	.4byte	.LBB1275
	.4byte	.LBE1275
	.4byte	.LBB1282
	.4byte	.LBE1282
	.4byte	.LBB1284
	.4byte	.LBE1284
	.4byte	0
	.4byte	0
	.4byte	.LBB1305
	.4byte	.LBE1305
	.4byte	.LBB1324
	.4byte	.LBE1324
	.4byte	.LBB1326
	.4byte	.LBE1326
	.4byte	.LBB2004
	.4byte	.LBE2004
	.4byte	0
	.4byte	0
	.4byte	.LBB1307
	.4byte	.LBE1307
	.4byte	.LBB1313
	.4byte	.LBE1313
	.4byte	.LBB1314
	.4byte	.LBE1314
	.4byte	0
	.4byte	0
	.4byte	.LBB1318
	.4byte	.LBE1318
	.4byte	.LBB1325
	.4byte	.LBE1325
	.4byte	.LBB1327
	.4byte	.LBE1327
	.4byte	0
	.4byte	0
	.4byte	.LBB1336
	.4byte	.LBE1336
	.4byte	.LBB1351
	.4byte	.LBE1351
	.4byte	0
	.4byte	0
	.4byte	.LBB1338
	.4byte	.LBE1338
	.4byte	.LBB1349
	.4byte	.LBE1349
	.4byte	0
	.4byte	0
	.4byte	.LBB1340
	.4byte	.LBE1340
	.4byte	.LBB1346
	.4byte	.LBE1346
	.4byte	.LBB1347
	.4byte	.LBE1347
	.4byte	0
	.4byte	0
	.4byte	.LBB1354
	.4byte	.LBE1354
	.4byte	.LBB1366
	.4byte	.LBE1366
	.4byte	.LBB1367
	.4byte	.LBE1367
	.4byte	0
	.4byte	0
	.4byte	.LBB1358
	.4byte	.LBE1358
	.4byte	.LBB1363
	.4byte	.LBE1363
	.4byte	0
	.4byte	0
	.4byte	.LBB1370
	.4byte	.LBE1370
	.4byte	.LBB1385
	.4byte	.LBE1385
	.4byte	0
	.4byte	0
	.4byte	.LBB1372
	.4byte	.LBE1372
	.4byte	.LBB1383
	.4byte	.LBE1383
	.4byte	0
	.4byte	0
	.4byte	.LBB1374
	.4byte	.LBE1374
	.4byte	.LBB1380
	.4byte	.LBE1380
	.4byte	.LBB1381
	.4byte	.LBE1381
	.4byte	0
	.4byte	0
	.4byte	.LBB1388
	.4byte	.LBE1388
	.4byte	.LBB1400
	.4byte	.LBE1400
	.4byte	.LBB1401
	.4byte	.LBE1401
	.4byte	0
	.4byte	0
	.4byte	.LBB1392
	.4byte	.LBE1392
	.4byte	.LBB1397
	.4byte	.LBE1397
	.4byte	0
	.4byte	0
	.4byte	.LBB1408
	.4byte	.LBE1408
	.4byte	.LBB1420
	.4byte	.LBE1420
	.4byte	.LBB1421
	.4byte	.LBE1421
	.4byte	0
	.4byte	0
	.4byte	.LBB1412
	.4byte	.LBE1412
	.4byte	.LBB1417
	.4byte	.LBE1417
	.4byte	0
	.4byte	0
	.4byte	.LBB1424
	.4byte	.LBE1424
	.4byte	.LBB1439
	.4byte	.LBE1439
	.4byte	0
	.4byte	0
	.4byte	.LBB1426
	.4byte	.LBE1426
	.4byte	.LBB1437
	.4byte	.LBE1437
	.4byte	0
	.4byte	0
	.4byte	.LBB1428
	.4byte	.LBE1428
	.4byte	.LBB1434
	.4byte	.LBE1434
	.4byte	.LBB1435
	.4byte	.LBE1435
	.4byte	0
	.4byte	0
	.4byte	.LBB1442
	.4byte	.LBE1442
	.4byte	.LBB1454
	.4byte	.LBE1454
	.4byte	.LBB1455
	.4byte	.LBE1455
	.4byte	0
	.4byte	0
	.4byte	.LBB1446
	.4byte	.LBE1446
	.4byte	.LBB1451
	.4byte	.LBE1451
	.4byte	0
	.4byte	0
	.4byte	.LBB1456
	.4byte	.LBE1456
	.4byte	.LBB1475
	.4byte	.LBE1475
	.4byte	.LBB1477
	.4byte	.LBE1477
	.4byte	.LBB2005
	.4byte	.LBE2005
	.4byte	0
	.4byte	0
	.4byte	.LBB1458
	.4byte	.LBE1458
	.4byte	.LBB1464
	.4byte	.LBE1464
	.4byte	.LBB1465
	.4byte	.LBE1465
	.4byte	0
	.4byte	0
	.4byte	.LBB1469
	.4byte	.LBE1469
	.4byte	.LBB1476
	.4byte	.LBE1476
	.4byte	.LBB1478
	.4byte	.LBE1478
	.4byte	0
	.4byte	0
	.4byte	.LBB1481
	.4byte	.LBE1481
	.4byte	.LBB1496
	.4byte	.LBE1496
	.4byte	0
	.4byte	0
	.4byte	.LBB1483
	.4byte	.LBE1483
	.4byte	.LBB1494
	.4byte	.LBE1494
	.4byte	0
	.4byte	0
	.4byte	.LBB1485
	.4byte	.LBE1485
	.4byte	.LBB1491
	.4byte	.LBE1491
	.4byte	.LBB1492
	.4byte	.LBE1492
	.4byte	0
	.4byte	0
	.4byte	.LBB1499
	.4byte	.LBE1499
	.4byte	.LBB1511
	.4byte	.LBE1511
	.4byte	.LBB1512
	.4byte	.LBE1512
	.4byte	0
	.4byte	0
	.4byte	.LBB1503
	.4byte	.LBE1503
	.4byte	.LBB1508
	.4byte	.LBE1508
	.4byte	0
	.4byte	0
	.4byte	.LBB1515
	.4byte	.LBE1515
	.4byte	.LBB1530
	.4byte	.LBE1530
	.4byte	0
	.4byte	0
	.4byte	.LBB1517
	.4byte	.LBE1517
	.4byte	.LBB1528
	.4byte	.LBE1528
	.4byte	0
	.4byte	0
	.4byte	.LBB1519
	.4byte	.LBE1519
	.4byte	.LBB1525
	.4byte	.LBE1525
	.4byte	.LBB1526
	.4byte	.LBE1526
	.4byte	0
	.4byte	0
	.4byte	.LBB1531
	.4byte	.LBE1531
	.4byte	.LBB1547
	.4byte	.LBE1547
	.4byte	0
	.4byte	0
	.4byte	.LBB1534
	.4byte	.LBE1534
	.4byte	.LBB1548
	.4byte	.LBE1548
	.4byte	0
	.4byte	0
	.4byte	.LBB1536
	.4byte	.LBE1536
	.4byte	.LBB1544
	.4byte	.LBE1544
	.4byte	.LBB1545
	.4byte	.LBE1545
	.4byte	0
	.4byte	0
	.4byte	.LBB1551
	.4byte	.LBE1551
	.4byte	.LBB1577
	.4byte	.LBE1577
	.4byte	.LBB1579
	.4byte	.LBE1579
	.4byte	0
	.4byte	0
	.4byte	.LBB1555
	.4byte	.LBE1555
	.4byte	.LBB1578
	.4byte	.LBE1578
	.4byte	.LBB1580
	.4byte	.LBE1580
	.4byte	0
	.4byte	0
	.4byte	.LBB1557
	.4byte	.LBE1557
	.4byte	.LBB1572
	.4byte	.LBE1572
	.4byte	.LBB1573
	.4byte	.LBE1573
	.4byte	.LBB1574
	.4byte	.LBE1574
	.4byte	0
	.4byte	0
	.4byte	.LBB1559
	.4byte	.LBE1559
	.4byte	.LBB1568
	.4byte	.LBE1568
	.4byte	0
	.4byte	0
	.4byte	.LBB1561
	.4byte	.LBE1561
	.4byte	.LBB1566
	.4byte	.LBE1566
	.4byte	0
	.4byte	0
	.4byte	.LBB1585
	.4byte	.LBE1585
	.4byte	.LBB1600
	.4byte	.LBE1600
	.4byte	0
	.4byte	0
	.4byte	.LBB1587
	.4byte	.LBE1587
	.4byte	.LBB1598
	.4byte	.LBE1598
	.4byte	0
	.4byte	0
	.4byte	.LBB1589
	.4byte	.LBE1589
	.4byte	.LBB1595
	.4byte	.LBE1595
	.4byte	.LBB1596
	.4byte	.LBE1596
	.4byte	0
	.4byte	0
	.4byte	.LBB1601
	.4byte	.LBE1601
	.4byte	.LBB1618
	.4byte	.LBE1618
	.4byte	0
	.4byte	0
	.4byte	.LBB1604
	.4byte	.LBE1604
	.4byte	.LBB1619
	.4byte	.LBE1619
	.4byte	.LBB1620
	.4byte	.LBE1620
	.4byte	0
	.4byte	0
	.4byte	.LBB1606
	.4byte	.LBE1606
	.4byte	.LBB1613
	.4byte	.LBE1613
	.4byte	.LBB1614
	.4byte	.LBE1614
	.4byte	.LBB1615
	.4byte	.LBE1615
	.4byte	0
	.4byte	0
	.4byte	.LBB1607
	.4byte	.LBE1607
	.4byte	.LBB1611
	.4byte	.LBE1611
	.4byte	.LBB1612
	.4byte	.LBE1612
	.4byte	0
	.4byte	0
	.4byte	.LBB1621
	.4byte	.LBE1621
	.4byte	.LBB1638
	.4byte	.LBE1638
	.4byte	0
	.4byte	0
	.4byte	.LBB1624
	.4byte	.LBE1624
	.4byte	.LBB1639
	.4byte	.LBE1639
	.4byte	.LBB1640
	.4byte	.LBE1640
	.4byte	0
	.4byte	0
	.4byte	.LBB1626
	.4byte	.LBE1626
	.4byte	.LBB1633
	.4byte	.LBE1633
	.4byte	.LBB1634
	.4byte	.LBE1634
	.4byte	.LBB1635
	.4byte	.LBE1635
	.4byte	0
	.4byte	0
	.4byte	.LBB1627
	.4byte	.LBE1627
	.4byte	.LBB1631
	.4byte	.LBE1631
	.4byte	.LBB1632
	.4byte	.LBE1632
	.4byte	0
	.4byte	0
	.4byte	.LBB1671
	.4byte	.LBE1671
	.4byte	.LBB1690
	.4byte	.LBE1690
	.4byte	.LBB1692
	.4byte	.LBE1692
	.4byte	.LBB2007
	.4byte	.LBE2007
	.4byte	0
	.4byte	0
	.4byte	.LBB1673
	.4byte	.LBE1673
	.4byte	.LBB1679
	.4byte	.LBE1679
	.4byte	.LBB1680
	.4byte	.LBE1680
	.4byte	0
	.4byte	0
	.4byte	.LBB1684
	.4byte	.LBE1684
	.4byte	.LBB1691
	.4byte	.LBE1691
	.4byte	.LBB1693
	.4byte	.LBE1693
	.4byte	0
	.4byte	0
	.4byte	.LBB1700
	.4byte	.LBE1700
	.4byte	.LBB1716
	.4byte	.LBE1716
	.4byte	.LBB1718
	.4byte	.LBE1718
	.4byte	0
	.4byte	0
	.4byte	.LBB1704
	.4byte	.LBE1704
	.4byte	.LBB1717
	.4byte	.LBE1717
	.4byte	.LBB1719
	.4byte	.LBE1719
	.4byte	0
	.4byte	0
	.4byte	.LBB1706
	.4byte	.LBE1706
	.4byte	.LBB1712
	.4byte	.LBE1712
	.4byte	.LBB1713
	.4byte	.LBE1713
	.4byte	0
	.4byte	0
	.4byte	.LBB1732
	.4byte	.LBE1732
	.4byte	.LBB1748
	.4byte	.LBE1748
	.4byte	.LBB1750
	.4byte	.LBE1750
	.4byte	0
	.4byte	0
	.4byte	.LBB1736
	.4byte	.LBE1736
	.4byte	.LBB1749
	.4byte	.LBE1749
	.4byte	.LBB1751
	.4byte	.LBE1751
	.4byte	0
	.4byte	0
	.4byte	.LBB1738
	.4byte	.LBE1738
	.4byte	.LBB1744
	.4byte	.LBE1744
	.4byte	.LBB1745
	.4byte	.LBE1745
	.4byte	0
	.4byte	0
	.4byte	.LBB1752
	.4byte	.LBE1752
	.4byte	.LBB1769
	.4byte	.LBE1769
	.4byte	0
	.4byte	0
	.4byte	.LBB1755
	.4byte	.LBE1755
	.4byte	.LBB1770
	.4byte	.LBE1770
	.4byte	.LBB1771
	.4byte	.LBE1771
	.4byte	0
	.4byte	0
	.4byte	.LBB1757
	.4byte	.LBE1757
	.4byte	.LBB1764
	.4byte	.LBE1764
	.4byte	.LBB1765
	.4byte	.LBE1765
	.4byte	.LBB1766
	.4byte	.LBE1766
	.4byte	0
	.4byte	0
	.4byte	.LBB1758
	.4byte	.LBE1758
	.4byte	.LBB1762
	.4byte	.LBE1762
	.4byte	.LBB1763
	.4byte	.LBE1763
	.4byte	0
	.4byte	0
	.4byte	.LBB1780
	.4byte	.LBE1780
	.4byte	.LBB1799
	.4byte	.LBE1799
	.4byte	0
	.4byte	0
	.4byte	.LBB1782
	.4byte	.LBE1782
	.4byte	.LBB1785
	.4byte	.LBE1785
	.4byte	0
	.4byte	0
	.4byte	.LBB1787
	.4byte	.LBE1787
	.4byte	.LBB1800
	.4byte	.LBE1800
	.4byte	.LBB1801
	.4byte	.LBE1801
	.4byte	0
	.4byte	0
	.4byte	.LBB1791
	.4byte	.LBE1791
	.4byte	.LBB1796
	.4byte	.LBE1796
	.4byte	0
	.4byte	0
	.4byte	.LBB1814
	.4byte	.LBE1814
	.4byte	.LBB1833
	.4byte	.LBE1833
	.4byte	.LBB1835
	.4byte	.LBE1835
	.4byte	.LBB2006
	.4byte	.LBE2006
	.4byte	0
	.4byte	0
	.4byte	.LBB1816
	.4byte	.LBE1816
	.4byte	.LBB1822
	.4byte	.LBE1822
	.4byte	.LBB1823
	.4byte	.LBE1823
	.4byte	0
	.4byte	0
	.4byte	.LBB1827
	.4byte	.LBE1827
	.4byte	.LBB1834
	.4byte	.LBE1834
	.4byte	.LBB1836
	.4byte	.LBE1836
	.4byte	0
	.4byte	0
	.4byte	.LBB1839
	.4byte	.LBE1839
	.4byte	.LBB1858
	.4byte	.LBE1858
	.4byte	0
	.4byte	0
	.4byte	.LBB1841
	.4byte	.LBE1841
	.4byte	.LBB1844
	.4byte	.LBE1844
	.4byte	0
	.4byte	0
	.4byte	.LBB1846
	.4byte	.LBE1846
	.4byte	.LBB1859
	.4byte	.LBE1859
	.4byte	.LBB1860
	.4byte	.LBE1860
	.4byte	0
	.4byte	0
	.4byte	.LBB1850
	.4byte	.LBE1850
	.4byte	.LBB1855
	.4byte	.LBE1855
	.4byte	0
	.4byte	0
	.4byte	.LBB1867
	.4byte	.LBE1867
	.4byte	.LBB1886
	.4byte	.LBE1886
	.4byte	0
	.4byte	0
	.4byte	.LBB1869
	.4byte	.LBE1869
	.4byte	.LBB1872
	.4byte	.LBE1872
	.4byte	0
	.4byte	0
	.4byte	.LBB1874
	.4byte	.LBE1874
	.4byte	.LBB1887
	.4byte	.LBE1887
	.4byte	.LBB1888
	.4byte	.LBE1888
	.4byte	0
	.4byte	0
	.4byte	.LBB1878
	.4byte	.LBE1878
	.4byte	.LBB1883
	.4byte	.LBE1883
	.4byte	0
	.4byte	0
	.4byte	.LBB1889
	.4byte	.LBE1889
	.4byte	.LBB1906
	.4byte	.LBE1906
	.4byte	0
	.4byte	0
	.4byte	.LBB1892
	.4byte	.LBE1892
	.4byte	.LBB1907
	.4byte	.LBE1907
	.4byte	.LBB1908
	.4byte	.LBE1908
	.4byte	0
	.4byte	0
	.4byte	.LBB1894
	.4byte	.LBE1894
	.4byte	.LBB1901
	.4byte	.LBE1901
	.4byte	.LBB1902
	.4byte	.LBE1902
	.4byte	.LBB1903
	.4byte	.LBE1903
	.4byte	0
	.4byte	0
	.4byte	.LBB1895
	.4byte	.LBE1895
	.4byte	.LBB1899
	.4byte	.LBE1899
	.4byte	.LBB1900
	.4byte	.LBE1900
	.4byte	0
	.4byte	0
	.4byte	.LBB1927
	.4byte	.LBE1927
	.4byte	.LBB1946
	.4byte	.LBE1946
	.4byte	0
	.4byte	0
	.4byte	.LBB1929
	.4byte	.LBE1929
	.4byte	.LBB1932
	.4byte	.LBE1932
	.4byte	0
	.4byte	0
	.4byte	.LBB1934
	.4byte	.LBE1934
	.4byte	.LBB1947
	.4byte	.LBE1947
	.4byte	.LBB1948
	.4byte	.LBE1948
	.4byte	0
	.4byte	0
	.4byte	.LBB1938
	.4byte	.LBE1938
	.4byte	.LBB1943
	.4byte	.LBE1943
	.4byte	0
	.4byte	0
	.4byte	.LBB1949
	.4byte	.LBE1949
	.4byte	.LBB1968
	.4byte	.LBE1968
	.4byte	.LBB1970
	.4byte	.LBE1970
	.4byte	.LBB2002
	.4byte	.LBE2002
	.4byte	0
	.4byte	0
	.4byte	.LBB1951
	.4byte	.LBE1951
	.4byte	.LBB1957
	.4byte	.LBE1957
	.4byte	.LBB1958
	.4byte	.LBE1958
	.4byte	0
	.4byte	0
	.4byte	.LBB1962
	.4byte	.LBE1962
	.4byte	.LBB1969
	.4byte	.LBE1969
	.4byte	.LBB1971
	.4byte	.LBE1971
	.4byte	0
	.4byte	0
	.4byte	.LBB1978
	.4byte	.LBE1978
	.4byte	.LBB1997
	.4byte	.LBE1997
	.4byte	0
	.4byte	0
	.4byte	.LBB1980
	.4byte	.LBE1980
	.4byte	.LBB1983
	.4byte	.LBE1983
	.4byte	0
	.4byte	0
	.4byte	.LBB1985
	.4byte	.LBE1985
	.4byte	.LBB1998
	.4byte	.LBE1998
	.4byte	.LBB1999
	.4byte	.LBE1999
	.4byte	0
	.4byte	0
	.4byte	.LBB1989
	.4byte	.LBE1989
	.4byte	.LBB1994
	.4byte	.LBE1994
	.4byte	0
	.4byte	0
	.4byte	.LFB12
	.4byte	.LFE12
	.4byte	.LFB13
	.4byte	.LFE13
	.4byte	.LFB18
	.4byte	.LFE18
	.4byte	.LFB22
	.4byte	.LFE22
	.4byte	.LFB23
	.4byte	.LFE23
	.4byte	.LFB26
	.4byte	.LFE26
	.4byte	.LFB27
	.4byte	.LFE27
	.4byte	.LFB30
	.4byte	.LFE30
	.4byte	.LFB31
	.4byte	.LFE31
	.4byte	.LFB35
	.4byte	.LFE35
	.4byte	.LFB36
	.4byte	.LFE36
	.4byte	.LFB37
	.4byte	.LFE37
	.4byte	.LFB52
	.4byte	.LFE52
	.4byte	.LFB55
	.4byte	.LFE55
	.4byte	.LFB58
	.4byte	.LFE58
	.4byte	.LFB59
	.4byte	.LFE59
	.4byte	.LFB64
	.4byte	.LFE64
	.4byte	.LFB67
	.4byte	.LFE67
	.4byte	.LFB69
	.4byte	.LFE69
	.4byte	.LFB74
	.4byte	.LFE74
	.4byte	.LFB75
	.4byte	.LFE75
	.4byte	.LFB78
	.4byte	.LFE78
	.4byte	.LFB101
	.4byte	.LFE101
	.4byte	.LFB102
	.4byte	.LFE102
	.4byte	.LFB103
	.4byte	.LFE103
	.4byte	.LFB104
	.4byte	.LFE104
	.4byte	.LFB105
	.4byte	.LFE105
	.4byte	.LFB106
	.4byte	.LFE106
	.4byte	.LFB107
	.4byte	.LFE107
	.4byte	.LFB108
	.4byte	.LFE108
	.4byte	.LFB109
	.4byte	.LFE109
	.4byte	0
	.4byte	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF42:
	.string	"getenv"
.LASF132:
	.string	"_Z3cmpv"
.LASF125:
	.string	"_Z3incv"
.LASF109:
	.string	"_Z3sbcv"
.LASF94:
	.string	"rand"
.LASF172:
	.string	"_Z3accv"
.LASF90:
	.string	"exec6502"
.LASF53:
	.string	"system"
.LASF122:
	.string	"_Z3jmpv"
.LASF21:
	.string	"_ZSt3divll"
.LASF168:
	.string	"_Z3zpyv"
.LASF165:
	.string	"abso"
.LASF154:
	.string	"eahelp"
.LASF162:
	.string	"absx"
.LASF160:
	.string	"absy"
.LASF67:
	.string	"clockticks6502"
.LASF44:
	.string	"mblen"
.LASF159:
	.string	"_Z3indv"
.LASF8:
	.string	"unsigned int"
.LASF201:
	.string	"__gnu_cxx"
.LASF6:
	.string	"__int32_t"
.LASF46:
	.string	"wchar_t"
.LASF144:
	.string	"_Z3beqv"
.LASF141:
	.string	"_Z3bnev"
.LASF133:
	.string	"_Z3clvv"
.LASF112:
	.string	"_Z3plpv"
.LASF179:
	.string	"_Z5pull8v"
.LASF91:
	.string	"_Z10setzeroramth"
.LASF22:
	.string	"_ZN9__gnu_cxx3divExx"
.LASF59:
	.string	"strtoull"
.LASF181:
	.string	"temp16"
.LASF138:
	.string	"_Z3bvcv"
.LASF119:
	.string	"_Z3ldxv"
.LASF199:
	.string	"C:\\Users\\corax\\AppData\\Local\\Temp\\arduino_build_85801\\sketch\\cpu6502.cpp"
.LASF163:
	.string	"_Z6op_andv"
.LASF17:
	.string	"_ZSt3absd"
.LASF15:
	.string	"_ZSt3abse"
.LASF16:
	.string	"_ZSt3absf"
.LASF153:
	.string	"_Z4indyv"
.LASF19:
	.string	"_ZSt3absl"
.LASF62:
	.string	"strtold"
.LASF111:
	.string	"_Z3rolv"
.LASF97:
	.string	"_Z3txav"
.LASF58:
	.string	"strtoll"
.LASF14:
	.string	"uint32_t"
.LASF18:
	.string	"_ZSt3absx"
.LASF164:
	.string	"_Z4absxv"
.LASF47:
	.string	"mbtowc"
.LASF106:
	.string	"_Z3secv"
.LASF64:
	.string	"last_modified_ram"
.LASF61:
	.string	"float"
.LASF167:
	.string	"_Z3relv"
.LASF147:
	.string	"op_and"
.LASF72:
	.string	"result"
.LASF10:
	.string	"long long unsigned int"
.LASF195:
	.string	"_Z14drawPixelToRamth"
.LASF4:
	.string	"__uint16_t"
.LASF171:
	.string	"_Z3immv"
.LASF105:
	.string	"_Z3sedv"
.LASF178:
	.string	"_Z8getvaluev"
.LASF56:
	.string	"lldiv"
.LASF57:
	.string	"atoll"
.LASF71:
	.string	"value"
.LASF92:
	.string	"_Z8exec6502i"
.LASF192:
	.string	"_Z6pull16v"
.LASF82:
	.string	"_Z7getxregv"
.LASF63:
	.string	"cpustatus"
.LASF23:
	.string	"size_t"
.LASF50:
	.string	"strtod"
.LASF49:
	.string	"srand"
.LASF170:
	.string	"_Z2zpv"
.LASF161:
	.string	"_Z4absyv"
.LASF84:
	.string	"_Z7getaregv"
.LASF41:
	.string	"bsearch"
.LASF140:
	.string	"_Z3bplv"
.LASF96:
	.string	"_Z3txsv"
.LASF124:
	.string	"_Z3inxv"
.LASF191:
	.string	"read6502"
.LASF78:
	.string	"getyreg"
.LASF139:
	.string	"_Z3brkv"
.LASF134:
	.string	"_Z3cliv"
.LASF186:
	.string	"push16"
.LASF27:
	.string	"char"
.LASF74:
	.string	"oldcpustatus"
.LASF30:
	.string	"5div_t"
.LASF198:
	.string	"GNU C++17 10.3.0 -mlongcalls -mtext-section-literals -g -Os -std=gnu++17 -free -fipa-pta -fno-rtti -falign-functions=4 -ffunction-sections -fdata-sections -fno-exceptions"
.LASF197:
	.string	"drawPixelToRam"
.LASF149:
	.string	"_Z3adcv"
.LASF158:
	.string	"_Z4indxv"
.LASF73:
	.string	"opcode"
.LASF126:
	.string	"_Z3eorv"
.LASF123:
	.string	"_Z3inyv"
.LASF11:
	.string	"uint8_t"
.LASF157:
	.string	"indx"
.LASF151:
	.string	"indy"
.LASF28:
	.string	"quot"
.LASF173:
	.string	"_Z3impv"
.LASF142:
	.string	"_Z3bmiv"
.LASF103:
	.string	"_Z3stav"
.LASF45:
	.string	"mbstowcs"
.LASF104:
	.string	"_Z3seiv"
.LASF9:
	.string	"long long int"
.LASF193:
	.string	"_Z8read6502t"
.LASF76:
	.string	"str_buffer_6502"
.LASF120:
	.string	"_Z3ldav"
.LASF114:
	.string	"_Z3phpv"
.LASF20:
	.string	"__cxx11"
.LASF175:
	.string	"_Z9reset6502v"
.LASF102:
	.string	"_Z3stxv"
.LASF43:
	.string	"ldiv"
.LASF83:
	.string	"getareg"
.LASF187:
	.string	"_Z6push16t"
.LASF121:
	.string	"_Z3jsrv"
.LASF129:
	.string	"_Z3decv"
.LASF35:
	.string	"__compar_fn_t"
.LASF66:
	.string	"instructions"
.LASF194:
	.string	"_Z16loadPixelFromRamt"
.LASF100:
	.string	"_Z3taxv"
.LASF110:
	.string	"_Z3rorv"
.LASF95:
	.string	"_Z3tyav"
.LASF75:
	.string	"useaccum"
.LASF101:
	.string	"_Z3styv"
.LASF189:
	.string	"_Z9write6502th"
.LASF188:
	.string	"write6502"
.LASF146:
	.string	"_Z3bccv"
.LASF127:
	.string	"_Z3deyv"
.LASF24:
	.string	"long double"
.LASF12:
	.string	"uint16_t"
.LASF107:
	.string	"_Z3rtsv"
.LASF88:
	.string	"_Z5getpcv"
.LASF77:
	.string	"getLastModifiedRam"
.LASF99:
	.string	"_Z3tayv"
.LASF152:
	.string	"_Z8putvaluet"
.LASF115:
	.string	"_Z3phav"
.LASF145:
	.string	"_Z3bcsv"
.LASF196:
	.string	"loadPixelFromRam"
.LASF118:
	.string	"_Z3ldyv"
.LASF2:
	.string	"short int"
.LASF93:
	.string	"tickcount"
.LASF174:
	.string	"reset6502"
.LASF69:
	.string	"oldpc"
.LASF25:
	.string	"long int"
.LASF166:
	.string	"_Z4absov"
.LASF184:
	.string	"saveval"
.LASF36:
	.string	"atexit"
.LASF130:
	.string	"_Z3cpyv"
.LASF177:
	.string	"pull8"
.LASF117:
	.string	"_Z3lsrv"
.LASF98:
	.string	"_Z3tsxv"
.LASF131:
	.string	"_Z3cpxv"
.LASF204:
	.string	"_Z10getzeroramt"
.LASF85:
	.string	"getop"
.LASF32:
	.string	"ldiv_t"
.LASF3:
	.string	"__uint8_t"
.LASF200:
	.string	"C:\\Program Files (x86)\\Arduino"
.LASF155:
	.string	"eahelp2"
.LASF136:
	.string	"_Z3clcv"
.LASF156:
	.string	"startpage"
.LASF87:
	.string	"getpc"
.LASF52:
	.string	"strtoul"
.LASF26:
	.string	"long unsigned int"
.LASF79:
	.string	"_Z18getLastModifiedRamv"
.LASF190:
	.string	"address"
.LASF108:
	.string	"_Z3rtiv"
.LASF176:
	.string	"getvalue"
.LASF137:
	.string	"_Z3bvsv"
.LASF13:
	.string	"int32_t"
.LASF205:
	.string	"_Z6op_bitv"
.LASF86:
	.string	"_Z5getopv"
.LASF185:
	.string	"pushval"
.LASF89:
	.string	"setzeroram"
.LASF81:
	.string	"getxreg"
.LASF135:
	.string	"_Z3cldv"
.LASF29:
	.string	"div_t"
.LASF1:
	.string	"unsigned char"
.LASF7:
	.string	"__uint32_t"
.LASF202:
	.string	"decltype(nullptr)"
.LASF60:
	.string	"strtof"
.LASF113:
	.string	"_Z3plav"
.LASF54:
	.string	"wcstombs"
.LASF51:
	.string	"strtol"
.LASF203:
	.string	"getzeroram"
.LASF31:
	.string	"6ldiv_t"
.LASF180:
	.string	"pull16"
.LASF183:
	.string	"_Z5push8h"
.LASF65:
	.string	"zero_ram"
.LASF33:
	.string	"7lldiv_t"
.LASF182:
	.string	"push8"
.LASF0:
	.string	"signed char"
.LASF5:
	.string	"short unsigned int"
.LASF34:
	.string	"lldiv_t"
.LASF37:
	.string	"atof"
.LASF116:
	.string	"_Z3orav"
.LASF39:
	.string	"atoi"
.LASF40:
	.string	"atol"
.LASF128:
	.string	"_Z3dexv"
.LASF68:
	.string	"clockgoal6502"
.LASF55:
	.string	"wctomb"
.LASF148:
	.string	"_Z3aslv"
.LASF38:
	.string	"double"
.LASF143:
	.string	"op_bit"
.LASF80:
	.string	"_Z7getyregv"
.LASF150:
	.string	"putvalue"
.LASF169:
	.string	"_Z3zpxv"
.LASF70:
	.string	"reladdr"
.LASF48:
	.string	"qsort"
	.ident	"GCC: (GNU) 10.3.0"
