#include <stdint.h>
#include <stdlib.h>
#include <Arduino.h>
#include "settings.h"
#include "user_interface.h"
#include "gui.h"

char *str_list;
int16_t editor_position = 0;
uint16_t editor_string_position = 0;
uint16_t editor_string_position_end = 0;
uint16_t editor_string_count = 0;
uint16_t editor_letter_count = 0;
char pixel_array[128];

extern void sTextEditor(char s[]);
extern int16_t pixelEditor(char e_screen[]);
extern void getKey();
extern uint8_t thiskey();
extern void saveFile(char str_list[], uint16_t editor_letter_count, char file_name[], uint8_t type);
extern char thisFile[32];

void letterAndStringCounter(){
  editor_string_position = 0;
  editor_string_position_end = 0;
  editor_string_count = 0;
  editor_letter_count = 0;
  if(editor_position == 0)
     editor_string_position = 0;
  for(uint16_t i = 0; i < SOURCE_SIZE; i++){
    if(str_list[i] == '\n'){
      editor_string_count++;
      if(editor_string_position_end == 0)
        editor_string_position_end = i - 1;
      if(editor_position == editor_string_count)
        editor_string_position = i + 1;
      if((editor_position + 1) == editor_string_count)
        editor_string_position_end = i;
    }
    if(str_list[i] == 0){
      if(editor_position > editor_string_count){
        editor_string_position = i - 1;
        editor_string_position_end = i;
        editor_position = editor_string_count;
      }
      return;
    }
    editor_letter_count++;
  }
}

uint16_t SerialUI(){
  char c;
  if(Serial.available()){
    c = Serial.read();
    if(c == '?'){
      Serial.println('?');
      Serial.println(F("Enter the first letter of the command:"));
      Serial.println(F(" editor"));
      Serial.println(F(" info"));
      Serial.println(F(" reset"));
      Serial.println(F(" load"));
      Serial.println(F(" asm"));
      Serial.print('>');
    }
    else if(c == 'e'){
      sTextEditor(str_list);
    }
    else if(c == 'i'){
      letterAndStringCounter();
      Serial.println('i');
      Serial.print(F("free_heap_size "));
      Serial.println(system_get_free_heap_size());
      Serial.print('>');
    }
    else if(c == 'l'){
      Serial.println('l');
      Serial.println(F("enter the code. To complete the entry, type ==="));
      Serial.print('>');
      editor_position = 0;
      while(1){
        if(Serial.available()){
          c = Serial.read();
          Serial.print(c);
          if(c != 0 && c != '\r' && editor_position < SOURCE_SIZE - 1){
           str_list[editor_position++] = c;
          }
          if(editor_position > 2 && str_list[editor_position - 3] == '=' && str_list[editor_position - 2] == '=' && str_list[editor_position - 1] == '='){
            editor_position -= 3;
            for(uint16_t i = editor_position; i < SOURCE_SIZE; i++)
              str_list[i] = 0;
            editor_position = 0;
            letterAndStringCounter();
            Serial.println();
            Serial.println(F("input completed"));
            Serial.print('>');
            return 0;
          }
          if(editor_position >= SOURCE_SIZE - 1){
            Serial.println(F("program memory ran out"));
            Serial.print('>');
            return 0;
          }
        }
        yield();
      }
    }
    else if(c == 'a'){
      Serial.println(c);
      Serial.println(F("program assembly"));
      return 1;
    }
    else if(c == 'r'){
      Serial.println(c);
      Serial.print('>');
    }
    else{
      Serial.println(c);
      Serial.print('>');
    }
  }
  return 0;
}

void insertHexArray(char pixel_array[], uint8_t sz){
  uint16_t i, c;
  uint8_t n;
  uint16_t size = sz * 4 + 4;
  if(sz * 4 + 4 + editor_letter_count >= SOURCE_SIZE)
    return;
  for(i = editor_letter_count - 1 + size; i >= editor_string_position + size; i--)
    str_list[i] = str_list[i - size];
  c = 0;
  str_list[editor_string_position] = 'D';
  str_list[editor_string_position + 1] = 'C';
  str_list[editor_string_position + 2] = 'B';
  str_list[editor_string_position + 3] = ' ';
  for(i = editor_string_position + 4; i < size + editor_string_position; i += 4){
    str_list[i] = '$';
    n = pixel_array[c] >> 4;
    if(n < 10)
      str_list[i + 1] = '0' + n;
    else
      str_list[i + 1] = 'A' + n;
    n = pixel_array[c] & 0xf;
    if(n < 10)
      str_list[i + 2] = '0' + n;
    else
      str_list[i + 2] = 'A' + n;
    str_list[i + 3] = ',';
    c++;
  }
  if(str_list[size + editor_string_position] != '\n')
    str_list[size + editor_string_position - 1] = '\n';
  else
    str_list[size + editor_string_position - 1] = ' ';
}

uint16_t viewEditor(char *str_list_i){
  str_list = str_list_i;
  clearScr(0);
  while(1){
    drawEditor(str_list, editor_string_position, -1);
    fillRect(0, 120, 128, 8, 2);
    drawString(F("line"), 1, 121, 0);
    drawNumber(editor_position, 35, 121, 0);
    drawChar('/', 63, 121, 0);
    drawNumber(editor_string_count, 70, 121, 0);
    redrawScreen(128);
    if(SerialUI())
      return 0;
    getKey();
    if(thiskey() & 2){//down
      editor_position++;
      delay(250);
    }
    else if(thiskey() & 1){//up
      if(editor_position > 0)
        editor_position--;
      delay(250);
    }
    else if(thiskey() & 8){//left
      for(uint16_t i = 0; i < 14; i++){
        editor_position++;
        letterAndStringCounter();
        drawEditor(str_list, editor_string_position, -1);
        fillRect(0, 120, 128, 8, 2);
        redrawScreen(128);
      }
      delay(10);
    }
    else if(thiskey() & 4){//right
      for(uint16_t i = 0; i < 14; i++){
        drawEditor(str_list, editor_string_position, -1);
        fillRect(0, 120, 128, 8, 2);
        redrawScreen(128);
        editor_position--;
        if(editor_position < 0)
          editor_position = 0;
        letterAndStringCounter();
      }
      delay(10);
    }
    else if(thiskey() & 16){//ok
      letterAndStringCounter();
      while(thiskey() & 16){
        delay(10);
        getKey();
      }
      delay(10);
      drawKeyboard(15, 92, str_list, editor_string_position, 1);
    }
    else if(thiskey() & 32){//menu
      letterAndStringCounter();
      while(thiskey() & 32){
        delay(10);
        getKey();
      }
      delay(10);
      uint8_t m = drawMenu(F("asembler|run|pixel editor|save  asm|save  bin|clear all|close|cancel"));
      if(m == 0){
        return 1;
      }
      else if(m == 1){
        return 2;
      }
      else if(m == 2){
        uint16_t next_c = 0;
        uint16_t p = 0;
        if(str_list[editor_string_position] == 'D' || str_list[editor_string_position] == 'd'){
          if((str_list[editor_string_position + 1] == 'C' || str_list[editor_string_position + 1] == 'c') 
            && (str_list[editor_string_position + 2] == 'B' || str_list[editor_string_position + 2] == 'b') && p < 128){
            next_c = editor_string_position + 3;
            uint8_t n;
            for(p; p < 128; p++)
              pixel_array[p] = 0;
            p = 0;
            while(str_list[next_c] != '\n' && str_list[next_c] != 0 && str_list[next_c] != ';'){
              n = 0;
              while(str_list[next_c] == ' ')
                next_c++;
              if(str_list[next_c] == '$'){
                next_c++;
                while((str_list[next_c] >= '0' && str_list[next_c] <= '9') || (str_list[next_c] >= 'a' && str_list[next_c] <= 'f') || (str_list[next_c] >= 'A' && str_list[next_c] <= 'F')){
                  if(str_list[next_c] < 'A')
                    n = n * 16 + (str_list[next_c] - 0x30);
                  else if(str_list[next_c] < 'a')
                    n = n * 16 + (str_list[next_c] - 0x41 + 10);
                  else
                    n = n * 16 + (str_list[next_c] - 0x61 + 10);
                  next_c++;
                }
              }
              //преобразуем десятичное число
              else if(str_list[next_c] >= '0' && str_list[next_c] <= '9'){
                while(str_list[next_c] >= '0' && str_list[next_c] <= '9'){
                  n = n * 10 + (str_list[next_c] - 0x30);
                  next_c++;
                }
              }
              pixel_array[p++] = n;
              while(str_list[next_c] == ' ')
                next_c++;
              if(str_list[next_c] == ',')
                next_c++;
            }
          }
        }
        uint8_t sz = pixelEditor(pixel_array, p * 2);
        if(next_c > 0){
          for(uint16_t i = editor_string_position; i < editor_letter_count - next_c; i++)
            str_list[i] = str_list[i + next_c];
          editor_letter_count -= next_c;
          str_list[editor_letter_count] = 0;
        }
        if(sz){
          insertHexArray(pixel_array, sz);
        }
      }
      else if(m == 3 || m == 4){
        char *file_name_buffer = (char*)malloc(12);
        if(thisFile[0] != 0){
          for(uint8_t i = 0; i < 11; i++)
            file_name_buffer[i] = thisFile[i];
          file_name_buffer[11] = 0;
        }
        else{
          file_name_buffer[0] = '.';
          if(m == 3){
            file_name_buffer[1] = 'a';
            file_name_buffer[2] = 's';
            file_name_buffer[3] = 'm';
          }
          else{
            file_name_buffer[1] = 'b';
            file_name_buffer[2] = 'i';
            file_name_buffer[3] = 'n';
          }
          file_name_buffer[4] = 0;
        }
        letterAndStringCounter();
        drawKeyboard(15, 92, file_name_buffer, 0, 0);
        if(m == 3)
          saveFile(str_list, editor_letter_count, file_name_buffer, 0);
        else
          saveFile((char*)"", 0, file_name_buffer, 1);
        free(file_name_buffer);
      }
      else if(m == 5){
        if(!drawDialog(F(" source code will  be deleted"), F("yes"), F("no"))){
          for(uint16_t i = 0; i < SOURCE_SIZE; i++)
            str_list[i] = 0;
          editor_position = 0;
        }
      }
      else if(m == 6){
        return 0;
      }
    }
    letterAndStringCounter();
    yield();
  }
}

void drawError(char *error_string){
  int position = ((error_string[0] << 8) + error_string[1]);
  int j = 0;
  drawEditor(str_list, editor_string_position, -1);
  animateFillRect(2, 64, 124, 60, 0, 2);
  rect(0, 0, 98, 8, 2);
  fillRect(2, 64, 124, 60, 0);
  rect(2, 64, 124, 60, 2);
  drawString(F("character"), 8, 70, 1);
  drawNumber(position, 78, 70, 1);
  Serial.println();
  while(error_string[j + 2]){
    Serial.print(error_string[j + 2]);
    drawChar(error_string[(j++) + 2], 8 + (j % 15) * 7, 84 + (j / 15) * 10, 1);
  }
  Serial.println();
  Serial.println(F("press y for exit"));
  Serial.print('>');
  redrawScreen(128);
  delay(1000);
  while(thiskey() < 16){
    delay(10);
    getKey();
    if(Serial.available()){
      if(Serial.read() == 'y')
        return;
    }
  }
  delay(200);
}
