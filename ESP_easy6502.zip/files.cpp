#include <Arduino.h>
#include <LittleFS.h>
#include "settings.h"

extern uint8_t RAM[RAM_SIZE];
extern char source[SOURCE_SIZE];

extern void redrawScreen(int16_t size);
extern void clearScr(uint8_t color);
extern void drawString(char *s, uint16_t x, uint16_t y, uint16_t color);
extern void drawString(const __FlashStringHelper *s, uint16_t x, uint16_t y, uint16_t color);
extern void drawNumber(uint16_t n, uint16_t x, uint16_t y, uint16_t color);
extern void drawChar(char c, uint8_t x, uint8_t y, uint8_t color);
extern void fillRect(int8_t x, int8_t y, uint8_t w, uint8_t h, uint8_t c);
extern uint16_t drawDialog(const __FlashStringHelper *s, const __FlashStringHelper *one, const __FlashStringHelper *two);
extern void getKey();
extern uint8_t thiskey();
extern void drawInfo(const __FlashStringHelper *s, int16_t n0, int16_t n1);
char thisFile[32] = "";
uint16_t programm_size = 0;

void loadBinFromFS(char fileName[]){
  int i;
  for(i = 0; i < RAM_SIZE; i++)
    RAM[i] = 0;
  fs::File f = LittleFS.open(fileName, "r");
  if(f.size() < RAM_SIZE)
    for(i = 0; i < f.size(); i++){
      RAM[i] = (uint8_t)f.read();
    }
  Serial.print(F("loaded "));
  Serial.print(i);
  Serial.println(F(" byte"));
  f.close();  //Close file
}

void loadAsmFromFS(char fileName[]){
  int i;
  for(i = 0; i < SOURCE_SIZE; i++)
    source[i] = 0;
  fs::File f = LittleFS.open(fileName, "r");
  if(f.size() < SOURCE_SIZE){
    i = 0;
    while(i < f.size()){
      char c = (char)f.read();
      if(c != '\r')
        source[i++] = c;
    }
  }
  Serial.println(fileName);
  Serial.print(F("loaded "));
  Serial.print(i);
  Serial.println(F(" byte"));
  f.close();  //Close file
}

uint16_t fileList() {
  fs::Dir dir = LittleFS.openDir("/");
  char s[32];
  int16_t lst = 0;
  int16_t pos;
  int16_t startpos = 0;
  int16_t fileCount = 0;
  int16_t skip = 0;
  uint8_t i,b;
  pos = 0;
  startpos = 0;
  clearScr(0);
  while (dir.next()) {
    fs::File entry = dir.openFile("r");
    entry.close();
    fileCount++;
  }
  while(1){
    clearScr(0);
    skip = startpos;
    if(skip < 0)
      skip = 0;
    lst = 1;
    dir = LittleFS.openDir("/");
    fillRect(2, (pos - startpos) * 17 + 14, 125, 14, 2);
    while(dir.next() && lst < 8) {
      fs::File entry = dir.openFile("r");
      if(skip > 0){
        skip--;
      }
      else{
        strcpy(s, entry.name());
        if(lst + startpos == pos + 1)
          strcpy(thisFile, entry.name());
        drawString(s, 2, lst * 17, 1);
        i = 0;
        while(i < 28 && s[i] != '.')
          i++;
        i++;
        lst++;
      }
      entry.close();   
    }
    if(lst + startpos - 1 < pos){
      if(fileCount > pos)
        startpos++;
      else
        pos--;
    }
    else if(startpos > pos){
      startpos = pos;
    }
    fillRect(0, 0, 128, 10, 1);
    drawString(F("file"), 1, 1, 0);
    drawNumber(pos + 1, 35, 1, 0);
    drawChar('/', 63, 1, 0);
    drawNumber(fileCount, 70, 1, 0);
    redrawScreen(128);
    delay(200);
    getKey();
    while(thiskey() == 0){   
      getKey();
      delay(100);
    }
    if(thiskey() & 16){//ok
      i = 0;
      while(i < 28 && thisFile[i] != '.')
        i++;
      i++;
      if(thisFile[i] == 'b' && thisFile[i + 1] == 'i' && thisFile[i + 2] == 'n'){
        loadBinFromFS(thisFile);
        return 1;
      }
      else if(thisFile[i] == 'a' && thisFile[i + 1] == 's' && thisFile[i + 2] == 'm'){
        loadAsmFromFS(thisFile);
        return 2;
      }
      else{
        if(drawDialog(F("open as"), F("asm"), F("bin"))){
          loadBinFromFS(thisFile);
          return 1;
        }
        else{
          loadAsmFromFS(thisFile);
          return 2;
        }
      }
    }
    else if(thiskey() & 2){//down
      if(pos < fileCount - 1){
        pos++;
      }
      else{
        pos = 0;
        startpos = 0;
      }
      if(pos - startpos > 5){
        startpos++;
      }
    }
    else if(thiskey() & 1){//up
      if(pos > 0){
        pos--;
      }
      else{
        pos = fileCount - 1;
        startpos = (fileCount - 6 >= 0) ? fileCount - 6 : 0;
      }
      if(pos - startpos < 0){
        startpos--;
      }
    }
    if(thiskey() & 32){//B
      return 0;
    }
  }
}

void saveFile(char str_list[], uint16_t editor_letter_count, char file_name[], uint8_t type){
  uint16_t n;
  if(LittleFS.exists((String)"/" + (String)file_name)){
    if(drawDialog(F("overwrite the file?"), F("yes"), F("no"))){
      return;
    }
  }
  File sFile = LittleFS.open((String)"/" + (String)file_name, "w");
  if(type)
    n = sFile.write(RAM, programm_size);
  else
    n = sFile.print(str_list);
  delay(10);
  drawInfo(F("%0 bytes written"), n, 0);
  sFile.close();
}
