#!/bin/bash

# J2ME Build Script for Demo3D
# Auto-generated build script with recursive compilation

LIB_DIR="lib"
SRC_DIR="src"
CLS_DIR="classes"
BIN_DIR="bin"
APP_NAME="Demo3D"

echo ""
echo "========================================"
echo "Building Demo3D for J2ME"
echo "========================================"
echo ""

# Create directories
mkdir -p $CLS_DIR
mkdir -p $BIN_DIR

# Clean old classes
rm -rf $CLS_DIR/*

# Set up classpath
CLDC="$LIB_DIR/cldc_1.1.jar"
MIDP="$LIB_DIR/midp_2.0.jar"

# JSR-184 (M3G) library
JSR184=""
if [ -f "lib/jsr_184.jar" ]; then JSR184="lib/jsr_184.jar"; fi
if [ -f "jsr_184_stub.jar" ]; then JSR184="jsr_184_stub.jar"; fi


# Check if libraries exist
if [ ! -f "$CLDC" ]; then
    echo "ERROR: CLDC library not found: $CLDC"
    echo "Please ensure cldc_1.1.jar is in the lib folder"
    exit 1
fi

if [ ! -f "$MIDP" ]; then
    echo "ERROR: MIDP library not found: $MIDP"
    echo "Please ensure midp_2.0.jar is in the lib folder"
    exit 1
fi

echo "[1/3] Compiling..."

# Find all Java files recursively
JAVA_FILES=$(find $SRC_DIR -name "*.java" 2>/dev/null)

if [ -z "$JAVA_FILES" ]; then
    echo "ERROR: No Java files found in $SRC_DIR"
    exit 1
fi

# Count files
FILE_COUNT=$(echo "$JAVA_FILES" | wc -l)
echo "Found $FILE_COUNT Java file(s)"

# Compile all Java files
javac -bootclasspath "$CLDC:$MIDP:$JSR184" -source 1.3 -target 1.3 -d $CLS_DIR $JAVA_FILES 2>&1
if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi

# Copy resources preserving directory structure
if [ -d "res" ]; then cp -r res classes/ 2>/dev/null; fi
if [ -d "resources" ]; then cp -r resources classes/ 2>/dev/null; fi
if [ -d "images" ]; then cp -r images classes/ 2>/dev/null; fi

echo "[2/3] Creating JAR..."

# Create JAR with all class files preserving package structure
cd $CLS_DIR
jar cfm ../$BIN_DIR/Demo3D.jar ../manifest.mf * 2>&1
cd ..

if [ ! -f "$BIN_DIR/Demo3D.jar" ]; then
    echo "ERROR: Failed to create JAR"
    exit 1
fi

# Get JAR size
JAR_SIZE=$(stat -c%s "$BIN_DIR/Demo3D.jar" 2>/dev/null || stat -f%z "$BIN_DIR/Demo3D.jar")

echo "[3/3] Creating JAD..."
cat > $BIN_DIR/Demo3D.jad << EOF
MIDlet-Name: Demo3D
MIDlet-Vendor: Superscape Ltd.
MIDlet-Version: 1.0
MIDlet-1: Life3D, com.superscape.m3g.wtksamples.life3d.Life3D
MIDlet-2: PogoRoo, com.superscape.m3g.wtksamples.pogoroo.PogoRooMIDlet
MIDlet-3: RetainedMode, com.superscape.m3g.wtksamples.retainedmode.RetainedModeMidlet
MicroEdition-Configuration: CLDC-1.1
MicroEdition-Profile: MIDP-2.1
MIDlet-Jar-URL: Demo3D.jar
MIDlet-Jar-Size: $JAR_SIZE
EOF

echo ""
echo "========================================"
echo "Build complete!"
echo "========================================"
echo "JAR: $BIN_DIR/Demo3D.jar"
echo "JAD: $BIN_DIR/Demo3D.jad"
echo "Size: $JAR_SIZE bytes"
echo ""
