@echo off
REM J2ME Build Script for Demo3D
REM Auto-generated build script with recursive compilation

setlocal enabledelayedexpansion

set LIB_DIR=lib
set SRC_DIR=src
set CLS_DIR=classes
set BIN_DIR=bin
set APP_NAME=Demo3D

echo.
echo ========================================
echo Building Demo3D for J2ME
echo ========================================
echo.

REM Create directories
if not exist %CLS_DIR% mkdir %CLS_DIR%
if not exist %BIN_DIR% mkdir %BIN_DIR%

REM Clean old classes
if exist %CLS_DIR%\* del /Q /S %CLS_DIR%\* >nul 2>&1

REM Set up classpath
set CLDC=%LIB_DIR%\cldc_1.1.jar
set MIDP=%LIB_DIR%\midp_2.0.jar

REM JSR-184 (M3G) library
set JSR184=
if exist "lib\jsr_184.jar" set JSR184=lib\jsr_184.jar
if exist "jsr_184_stub.jar" set JSR184=jsr_184_stub.jar

REM Check if libraries exist
if not exist %CLDC% (
    echo ERROR: CLDC library not found: %CLDC%
    echo Please ensure cldc_1.1.jar is in the lib folder
    exit /b 1
)

if not exist %MIDP% (
    echo ERROR: MIDP library not found: %MIDP%
    echo Please ensure midp_2.0.jar is in the lib folder
    exit /b 1
)

echo [1/3] Compiling...

REM Find all Java files recursively
set JAVA_FILES=
for /r "%SRC_DIR%" %%f in (*.java) do (
    set JAVA_FILES=!JAVA_FILES! "%%f"
)

if "%JAVA_FILES%"=="" (
    echo ERROR: No Java files found in %SRC_DIR%
    exit /b 1
)

REM Compile all Java files
javac -bootclasspath %CLDC%;%MIDP%;%JSR184% -source 1.3 -target 1.3 -d %CLS_DIR% %JAVA_FILES% 2>&1
if errorlevel 1 (
    echo Compilation failed!
    exit /b 1
)

REM Copy resources preserving directory structure
if exist res xcopy /E /I /Y res classes\res >nul 2>&1
if exist resources xcopy /E /I /Y resources classes\resources >nul 2>&1
if exist images xcopy /E /I /Y images classes\images >nul 2>&1

echo [2/3] Creating JAR...

REM Create JAR with all class files preserving package structure
cd %CLS_DIR%
jar cfm ..\%BIN_DIR%\Demo3D.jar ..\manifest.mf * 2>&1
cd ..

if not exist %BIN_DIR%\Demo3D.jar (
    echo ERROR: Failed to create JAR
    exit /b 1
)

REM Get JAR size
for %%A in (%BIN_DIR%\Demo3D.jar) do set JAR_SIZE=%%~zA

echo [3/3] Creating JAD...
echo MIDlet-Name: Demo3D> %BIN_DIR%\Demo3D.jad
echo MIDlet-Vendor: Superscape Ltd.>> %BIN_DIR%\Demo3D.jad
echo MIDlet-Version: 1.0>> %BIN_DIR%\Demo3D.jad
echo MIDlet-1: Life3D, com.superscape.m3g.wtksamples.life3d.Life3D>> %BIN_DIR%\Demo3D.jad
echo MIDlet-2: PogoRoo, com.superscape.m3g.wtksamples.pogoroo.PogoRooMIDlet>> %BIN_DIR%\Demo3D.jad
echo MIDlet-3: RetainedMode, com.superscape.m3g.wtksamples.retainedmode.RetainedModeMidlet>> %BIN_DIR%\Demo3D.jad
echo MicroEdition-Configuration: CLDC-1.1>> %BIN_DIR%\Demo3D.jad
echo MicroEdition-Profile: MIDP-2.1>> %BIN_DIR%\Demo3D.jad
echo MIDlet-Jar-URL: Demo3D.jar>> %BIN_DIR%\Demo3D.jad
echo MIDlet-Jar-Size: %JAR_SIZE%>> %BIN_DIR%\Demo3D.jad

echo.
echo ========================================
echo Build complete!
echo ========================================
echo JAR: %BIN_DIR%\Demo3D.jar
echo JAD: %BIN_DIR%\Demo3D.jad
echo Size: %JAR_SIZE% bytes
echo.
