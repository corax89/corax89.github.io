/*
 * switch_ui.c — Nintendo Switch frontend menus: game browser, settings,
 * main menu. Pure logic + software rendering into the UI canvas (no SDL
 * calls — see switch_glue.h). Russian UI, UTF-8, rendered with the
 * embedded bitmap font (switch_font.c).
 *
 * Settings persist to <base>/settings.ini where <base> is
 * sdmc:/switch/j2me on real hardware, ./switchui under verification
 * builds (non-Switch hosts).
 */
#include "switch/switch_ui.h"
#include "switch/switch_common.h"
#include "switch/switch_glue.h"
#include "switch/switch_font.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>

#define LOG_TAG "[SWITCH-UI] "
#define ui_log(...) do { fprintf(stderr, LOG_TAG __VA_ARGS__); fflush(stderr); } while (0)

/* ================= Settings persistence ================= */

static SwitchSettings g_settings;
static int g_settings_loaded = 0;

static const char* switch_settings_path(char* buf, size_t cap) {
#ifdef __SWITCH__
    (void)buf; (void)cap;
    return "sdmc:/switch/j2me/settings.ini";
#else
    snprintf(buf, cap, "%s/switchui_settings.ini",
             getenv("NOJME_SWITCH_UI_DIR") ? getenv("NOJME_SWITCH_UI_DIR") : ".");
    return buf;
#endif
}

void switch_settings_defaults(SwitchSettings* s) {
    if (!s) return;
    memset(s, 0, sizeof(*s));
    s->scale_mode = NOJME_SCALE_FIT_BLACK;
    s->filter = NOJME_FILTER_NEAREST;
    s->audio_enabled = 1;
    s->vm_speed = NOJME_VM_SPEED_FAST;
#ifdef __SWITCH__
    snprintf(s->games_dir, sizeof(s->games_dir), "sdmc:/");
#else
    snprintf(s->games_dir, sizeof(s->games_dir), ".");
#endif
}

const char* switch_scale_mode_name(int mode) {
    switch (mode) {
        case NOJME_SCALE_STRETCH:   return "Растянуть на весь экран";
        case NOJME_SCALE_FIT_BLACK: return "Пропорции (чёрный бордюр)";
        case NOJME_SCALE_FIT_BLUR:  return "Пропорции (размытый фон)";
        default: return "?";
    }
}

const char* switch_filter_name(int filter) {
    return filter == NOJME_FILTER_LINEAR ? "Сглаженный" : "Пиксельный";
}

const char* switch_vm_speed_name(int speed) {
    switch (speed) {
        case NOJME_VM_SPEED_ORIGINAL: return "Обычная (как телефон)";
        case NOJME_VM_SPEED_TURBO:    return "Турбо (без лимита)";
        default:                      return "Быстрая";
    }
}

static void trim(char* s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r' ||
                 s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = '\0';
    size_t off = 0;
    while (s[off] == ' ' || s[off] == '\t') off++;
    if (off) memmove(s, s + off, n - off + 1);
}

static void parse_ini_line(char* line, SwitchSettings* s) {
    trim(line);
    if (!line[0] || line[0] == '#' || line[0] == ';') return;
    char* eq = strchr(line, '=');
    if (!eq) return;
    *eq = '\0';
    char* key = line;
    char* val = eq + 1;
    trim(key);
    trim(val);

    if (strcmp(key, "scale") == 0) {
        if (strcmp(val, "stretch") == 0) s->scale_mode = NOJME_SCALE_STRETCH;
        else if (strcmp(val, "fit_blur") == 0) s->scale_mode = NOJME_SCALE_FIT_BLUR;
        else s->scale_mode = NOJME_SCALE_FIT_BLACK;
    } else if (strcmp(key, "filter") == 0) {
        s->filter = strcmp(val, "linear") == 0 ? NOJME_FILTER_LINEAR : NOJME_FILTER_NEAREST;
    } else if (strcmp(key, "audio") == 0) {
        s->audio_enabled = strcmp(val, "off") == 0 ? 0 : 1;
    } else if (strcmp(key, "vm_speed") == 0) {
        if (strcmp(val, "original") == 0) s->vm_speed = NOJME_VM_SPEED_ORIGINAL;
        else if (strcmp(val, "turbo") == 0) s->vm_speed = NOJME_VM_SPEED_TURBO;
        else s->vm_speed = NOJME_VM_SPEED_FAST;
    } else if (strcmp(key, "games_dir") == 0) {
        snprintf(s->games_dir, sizeof(s->games_dir), "%s", val);
    }
}

const SwitchSettings* switch_settings_get(void) {
    if (!g_settings_loaded) {
        g_settings_loaded = 1;
        switch_settings_defaults(&g_settings);
        char pbuf[600];
        const char* path = switch_settings_path(pbuf, sizeof(pbuf));
        FILE* f = fopen(path, "r");
        if (f) {
            char line[1024];
            while (fgets(line, sizeof(line), f)) parse_ini_line(line, &g_settings);
            fclose(f);
            ui_log("settings loaded from %s (scale=%d filter=%d audio=%d vm=%d dir=%s)\n",
                   path, g_settings.scale_mode, g_settings.filter,
                   g_settings.audio_enabled, g_settings.vm_speed, g_settings.games_dir);
        } else {
            ui_log("settings: no %s, using defaults\n", path);
        }
    }
    return &g_settings;
}

void switch_settings_set(const SwitchSettings* s) {
    if (s) {
        g_settings = *s;
        g_settings_loaded = 1;
    }
}

int switch_settings_save(const SwitchSettings* s) {
    if (!s) return -1;
    switch_settings_set(s);

    char pbuf[600];
    const char* path = switch_settings_path(pbuf, sizeof(pbuf));
    /* parent dir may not exist yet on a fresh SD — best effort mkdir */
#ifdef __SWITCH__
    mkdir("sdmc:/switch", 0777);
    mkdir("sdmc:/switch/j2me", 0777);
#endif
    FILE* f = fopen(path, "w");
    if (!f) {
        ui_log("settings: cannot write %s\n", path);
        return -1;
    }
    static const char* scale_names[] = { "stretch", "fit_black", "fit_blur" };
    static const char* speed_names[] = { "original", "fast", "turbo" };
    fprintf(f, "# nojme Switch frontend settings\n");
    fprintf(f, "scale=%s\n", scale_names[s->scale_mode % NOJME_SCALE_MODE_COUNT]);
    fprintf(f, "filter=%s\n", s->filter == NOJME_FILTER_LINEAR ? "linear" : "nearest");
    fprintf(f, "audio=%s\n", s->audio_enabled ? "on" : "off");
    fprintf(f, "vm_speed=%s\n", speed_names[s->vm_speed % NOJME_VM_SPEED_COUNT]);
    fprintf(f, "games_dir=%s\n", s->games_dir);
    fclose(f);
    ui_log("settings saved to %s\n", path);
    return 0;
}

/* ================= UI drawing helpers ================= */

#define COL_BG      0xFF10131A  /* тёмный сине-серый фон */
#define COL_BG_ALT  0xFF181C26
#define COL_ACCENT  0xFF2E7CF6  /* синий акцент */
#define COL_ACCENT2 0xFF1B4FA8
#define COL_TEXT    0xFFE8ECF4
#define COL_DIM     0xFF8A93A6
#define COL_SEL_BG  0xFF2E7CF6
#define COL_SEL_FG  0xFFFFFFFF
#define COL_HEADER  0xFF161B2E
#define COL_LINE    0xFF2A3040

static void fill_rect(uint32_t* cv, int cw, int ch, int x, int y, int w, int h, uint32_t col) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > cw) w = cw - x;
    if (y + h > ch) h = ch - y;
    if (w <= 0 || h <= 0) return;
    for (int yy = 0; yy < h; yy++) {
        uint32_t* row = cv + (size_t)(y + yy) * cw + x;
        for (int xx = 0; xx < w; xx++) row[xx] = col;
    }
}

static void hline(uint32_t* cv, int cw, int ch, int x0, int x1, int y, uint32_t col) {
    if (y < 0 || y >= ch) return;
    if (x0 < 0) x0 = 0;
    if (x1 > cw) x1 = cw;
    for (int x = x0; x < x1; x++) cv[(size_t)y * cw + x] = col;
}

static void draw_text(uint32_t* cv, int cw, int ch, int x, int y, const char* s, uint32_t col, int scale) {
    switch_font_draw_text(cv, cw, ch, x, y, s, col, 0, scale);
}

/* Truncate an UTF-8 string to max_cells glyphs (appending an ellipsis
 * when it does not fit). Works on codepoints, not bytes. */
static void utf8_trunc(const char* src, char* dst, size_t dst_cap, int max_cells) {
    int cells = 0;
    const char* p = src;
    const char* last_start = src;
    while (*p) {
        unsigned char c = (unsigned char)*p;
        int len = (c < 0x80) ? 1 : ((c & 0xE0) == 0xC0) ? 2 : ((c & 0xF0) == 0xE0) ? 3 : 4;
        last_start = p;
        if (cells == max_cells) {
            /* doesn't fit — cut here and add ellipsis */
            size_t used = (size_t)(last_start - src);
            if (used + 4 > dst_cap) used = dst_cap > 4 ? dst_cap - 4 : 0;
            memcpy(dst, src, used);
            dst[used] = 0;
            strcat(dst, "…");
            return;
        }
        p += len;
        cells++;
    }
    snprintf(dst, dst_cap, "%s", src);
}

/* ================= File browser model ================= */

typedef struct {
    char name[256];
    int is_dir;
    int is_jar;
} BrowseEntry;

typedef struct {
    BrowseEntry* items;
    int count;
    int cap;
    int truncated; /* >0 when the directory had more entries than kept */
} BrowseList;

static void browse_free(BrowseList* l) {
    free(l->items);
    memset(l, 0, sizeof(*l));
}

static int entry_cmp(const void* a, const void* b) {
    const BrowseEntry* ea = (const BrowseEntry*)a;
    const BrowseEntry* eb = (const BrowseEntry*)b;
    if (ea->is_dir != eb->is_dir) return ea->is_dir ? -1 : 1; /* dirs first */
    return strcmp(ea->name, eb->name);
}

#define BROWSE_MAX_ENTRIES 2000

static void browse_load(BrowseList* l, const char* dir) {
    browse_free(l);
    DIR* d = opendir(dir);
    if (!d) return;
    l->cap = 64;
    l->items = (BrowseEntry*)malloc((size_t)l->cap * sizeof(BrowseEntry));
    if (!l->items) { closedir(d); return; }

    struct dirent* de;
    while ((de = readdir(d)) != NULL) {
        const char* n = de->d_name;
        /* «.» и «..» не показываем: подъём на уровень — кнопка B
         * (path_parent), дублирование в списке только путает навигацию. */
        if (strcmp(n, ".") == 0 || strcmp(n, "..") == 0) continue;
        size_t nl = strlen(n);
        int is_dir = (de->d_type == DT_DIR);
        if (!is_dir && de->d_type == DT_UNKNOWN) {
            char full[1024];
            snprintf(full, sizeof(full), "%s/%s", dir, n);
            struct stat st;
            is_dir = (stat(full, &st) == 0 && S_ISDIR(st.st_mode)) ? 1 : 0;
        }
        int is_jar = 0;
        if (!is_dir && nl > 4) {
            is_jar = (strcasecmp(n + nl - 4, ".jar") == 0);
        }
        if (!is_dir && !is_jar) continue; /* показываем только каталоги и .jar */

        if (l->count >= BROWSE_MAX_ENTRIES) { l->truncated = 1; break; }
        if (l->count == l->cap) {
            int nc = l->cap * 2;
            BrowseEntry* ni = (BrowseEntry*)realloc(l->items, (size_t)nc * sizeof(BrowseEntry));
            if (!ni) break;
            l->items = ni;
            l->cap = nc;
        }
        BrowseEntry* e = &l->items[l->count++];
        snprintf(e->name, sizeof(e->name), "%s", n);
        e->is_dir = is_dir;
        e->is_jar = is_jar;
    }
    closedir(d);
    if (l->count > 1) qsort(l->items, (size_t)l->count, sizeof(BrowseEntry), entry_cmp);
}

static void path_join(char* dst, size_t cap, const char* dir, const char* name) {
    /* dst may ALIAS dir (cwd updates in place) — build in a temp first:
     * snprintf with overlapping src/dst is undefined behavior. */
    char tmp[1024];
    size_t dl = strlen(dir);
    if (dl && dir[dl - 1] == '/') snprintf(tmp, sizeof(tmp), "%s%s", dir, name);
    else snprintf(tmp, sizeof(tmp), "%s/%s", dir, name);
    snprintf(dst, cap, "%s", tmp);
}

static void path_parent(char* path) {
    size_t n = strlen(path);
    while (n > 1 && path[n - 1] == '/') n--;
    while (n > 0 && path[n - 1] != '/') n--;
    if (n == 0) { strcpy(path, "/"); return; }
    if (path[n - 1] == '/') n--; /* strip trailing slash of the parent */
    path[n] = '\0';
    if (!path[0]) strcpy(path, "/");
}

static int dir_exists(const char* p) {
    DIR* d = opendir(p);
    if (!d) return 0;
    closedir(d);
    return 1;
}

/* Root for browsing: settings games_dir, else fallbacks. */
static void browse_root(char* out, size_t cap) {
    const SwitchSettings* st = switch_settings_get();
    const char* env_root = getenv("NOJME_SWITCH_BROWSE_ROOT");
    if (env_root && env_root[0] && dir_exists(env_root)) {
        snprintf(out, cap, "%s", env_root);
        return;
    }
    if (st->games_dir[0] && dir_exists(st->games_dir)) {
        snprintf(out, cap, "%s", st->games_dir);
        return;
    }
#ifdef __SWITCH__
    if (dir_exists("sdmc:/")) { snprintf(out, cap, "sdmc:/"); return; }
    snprintf(out, cap, "/");
#else
    snprintf(out, cap, ".");
#endif
}

/* ================= AUTOTEST driver (verification builds) =================
 * NOJME_SWITCH_KEYS="A:300,B:150,UP:100" — press key, hold it for one pump
 * cycle, then advance after the delay (ms). Lets the sandbox drive the
 * whole menu with SDL dummy video. Also NOJME_SWITCH_AUTOTEST_EXIT=<code>
 * makes the app _exit() with that code right after the menu session ends
 * (clean exit code assertion). */
static int g_at_enabled = -1;
static const char* g_at_script = NULL;
static int g_at_pos = 0;
static uint64_t g_at_next_ms = 0;

static unsigned at_keys(void) {
    if (g_at_enabled < 0) {
        g_at_script = getenv("NOJME_SWITCH_KEYS");
        g_at_enabled = (g_at_script && g_at_script[0]) ? 1 : 0;
        if (g_at_enabled) ui_log("autotest script: %s\n", g_at_script);
    }
    if (!g_at_enabled) return 0;
    if (!g_at_script[g_at_pos]) return 0; /* script exhausted */
    if (sdl_switch_ui_ticks_ms() < g_at_next_ms) return 0;

    /* parse one token: KEY:delay */
    char key[16] = {0};
    int delay = 0;
    int consumed = 0;
    if (sscanf(g_at_script + g_at_pos, "%15[^:]:%d%n", key, &delay, &consumed) >= 2 && consumed > 0) {
        g_at_pos += consumed;
        while (g_at_script[g_at_pos] == ',' || g_at_script[g_at_pos] == ' ') g_at_pos++;
        g_at_next_ms = sdl_switch_ui_ticks_ms() + (uint64_t)(delay < 0 ? 0 : delay);
        ui_log("autotest key=%s delay=%dms\n", key, delay);
        if (strcmp(key, "UP") == 0) return SWK_UP;
        if (strcmp(key, "DOWN") == 0) return SWK_DOWN;
        if (strcmp(key, "LEFT") == 0) return SWK_LEFT;
        if (strcmp(key, "RIGHT") == 0) return SWK_RIGHT;
        if (strcmp(key, "A") == 0) return SWK_A;
        if (strcmp(key, "B") == 0) return SWK_B;
        if (strcmp(key, "EXIT") == 0) return SWK_EXIT;
    } else {
        g_at_pos = (int)strlen(g_at_script); /* malformed — stop */
    }
    return 0;
}

/* ================= Menu screens ================= */

typedef enum {
    MMAIN_MAIN = 0,
    MMAIN_BROWSER,
    MMAIN_SETTINGS,
    MMAIN_DIRPICKER
} MenuScreen;

#define VISIBLE_ROWS 12
#define ROW_H 48
#define LIST_Y 110

static void draw_header(uint32_t* cv, int cw, const char* title, const char* right) {
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, 0, 0, cw, 72, COL_HEADER);
    hline(cv, cw, SWITCH_UI_HEIGHT, 0, cw, 72, COL_LINE);
    draw_text(cv, cw, SWITCH_UI_HEIGHT, 32, 16, title, COL_TEXT, 3);
    if (right) draw_text(cv, cw, SWITCH_UI_HEIGHT, cw - 32 - switch_font_text_width(right, 2), 24, right, COL_DIM, 2);
}

static void draw_footer(uint32_t* cv, int cw, const char* hint) {
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, 0, SWITCH_UI_HEIGHT - 48, cw, 48, COL_HEADER);
    hline(cv, cw, SWITCH_UI_HEIGHT, 0, cw, SWITCH_UI_HEIGHT - 48, COL_LINE);
    draw_text(cv, cw, SWITCH_UI_HEIGHT, 32, SWITCH_UI_HEIGHT - 38, hint, COL_DIM, 2);
}

/* Generic list row drawing; returns y of the next row. */
static int draw_row(uint32_t* cv, int cw, int y, const char* label, const char* value,
                    int selected, int i, int total) {
    if (selected) fill_rect(cv, cw, SWITCH_UI_HEIGHT, 16, y - 4, cw - 32, ROW_H, COL_SEL_BG);
    draw_text(cv, cw, SWITCH_UI_HEIGHT, 40, y + 4, label,
              selected ? COL_SEL_FG : COL_TEXT, 2);
    if (value) {
        int vw = switch_font_text_width(value, 2);
        draw_text(cv, cw, SWITCH_UI_HEIGHT, cw - 48 - vw, y + 4, value,
                  selected ? COL_SEL_FG : COL_ACCENT, 2);
    }
    (void)i; (void)total;
    return y + ROW_H;
}

static void draw_scrollbar(uint32_t* cv, int cw, int count, int sel) {
    if (count <= VISIBLE_ROWS) return;
    int track_y = LIST_Y - 4;
    int track_h = VISIBLE_ROWS * ROW_H;
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, cw - 14, track_y, 6, track_h, COL_LINE);
    int thumb_h = track_h * VISIBLE_ROWS / count;
    if (thumb_h < 30) thumb_h = 30;
    int thumb_y = track_y + (track_h - thumb_h) * sel / (count - 1);
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, cw - 14, thumb_y, 6, thumb_h, COL_ACCENT);
}

/* ================= Browser screen ================= */

typedef struct {
    char cwd[1024];
    BrowseList list;
    int sel;
    int scroll;
    /* возвращение из dirpicker */
    int return_to_settings;
} BrowserState;

static void browser_draw(uint32_t* cv, const BrowserState* b) {
    int cw = SWITCH_UI_WIDTH;
    char title[512];
    utf8_trunc(b->cwd, title, sizeof(title), 70);
    draw_header(cv, cw, "Открыть игру", title);

    int count = b->list.count;
    if (count == 0) {
        draw_text(cv, cw, SWITCH_UI_HEIGHT, 40, LIST_Y + 8, "(пусто или нет доступа)", COL_DIM, 2);
        if (b->list.truncated)
            draw_text(cv, cw, SWITCH_UI_HEIGHT, 40, LIST_Y + 48, "(показаны первые 2000 записей)", COL_DIM, 2);
    }
    int y = LIST_Y;
    int from = b->scroll;
    int to = from + VISIBLE_ROWS;
    if (to > count) to = count;
    for (int i = from; i < to; i++) {
        const BrowseEntry* e = &b->list.items[i];
        char label[320];
        if (e->is_dir) snprintf(label, sizeof(label), "[%s]", e->name);
        else snprintf(label, sizeof(label), "%s", e->name);
        char shown[320];
        utf8_trunc(label, shown, sizeof(shown), 60);
        draw_row(cv, cw, y, shown, e->is_dir ? "каталог" : "JAR", i == b->sel, i, count);
        y += ROW_H;
    }
    draw_scrollbar(cv, cw, count, b->sel);

    char footer[256];
    snprintf(footer, sizeof(footer), "A — открыть   B — выше   %d/%d", count ? b->sel + 1 : 0, count);
    draw_footer(cv, cw, footer);
}

/* Returns: 0 — stay, 1 — jar selected (out_path), 2 — back to main. */
static int browser_handle(BrowserState* b, unsigned keys, char* out_path, size_t cap) {
    int count = b->list.count;
    if (count > 0) {
        if (keys & SWK_UP) { b->sel--; if (b->sel < 0) b->sel = count - 1; }
        if (keys & SWK_DOWN) { b->sel++; if (b->sel >= count) b->sel = 0; }
    }
    /* window scroll */
    if (b->sel < b->scroll) b->scroll = b->sel;
    if (b->sel >= b->scroll + VISIBLE_ROWS) b->scroll = b->sel - VISIBLE_ROWS + 1;
    if (b->scroll < 0) b->scroll = 0;

    if (keys & SWK_B) {
        if (strcmp(b->cwd, "/") == 0 || b->cwd[0] == '\0') return 2; /* уже корень — в главное меню */
        path_parent(b->cwd);
        browse_load(&b->list, b->cwd);
        b->sel = 0;
        b->scroll = 0;
        return 0;
    }
    if (keys & SWK_A && count > 0) {
        const BrowseEntry* e = &b->list.items[b->sel];
        ui_log("browser A: sel=%d/%d '%s' dir=%d\n", b->sel, count, e->name, e->is_dir);
        if (e->is_dir) {
            path_join(b->cwd, sizeof(b->cwd), b->cwd, e->name);
            browse_load(&b->list, b->cwd);
            b->sel = 0;
            b->scroll = 0;
        } else {
            path_join(out_path, cap, b->cwd, e->name);
            ui_log("game selected: %s\n", out_path);
            return 1;
        }
    }
    return 0;
}

/* ================= Settings screen ================= */

typedef enum {
    SET_SCALE = 0,
    SET_FILTER,
    SET_AUDIO,
    SET_VM_SPEED,
    SET_GAMES_DIR,
    SET_SAVE,
    SET_COUNT
} SettingsItem;

static const char* settings_value(const SwitchSettings* s, int item) {
    static char buf[512];
    switch (item) {
        case SET_SCALE:     return switch_scale_mode_name(s->scale_mode);
        case SET_FILTER:    return switch_filter_name(s->filter);
        case SET_AUDIO:     return s->audio_enabled ? "Вкл" : "Выкл";
        case SET_VM_SPEED:  return switch_vm_speed_name(s->vm_speed);
        case SET_GAMES_DIR:
            utf8_trunc(s->games_dir, buf, sizeof(buf), 30);
            return buf;
        default: return NULL;
    }
}

static void settings_draw(uint32_t* cv, const SwitchSettings* s, int sel) {
    int cw = SWITCH_UI_WIDTH;
    draw_header(cv, cw, "Настройки", NULL);
    static const char* names[SET_COUNT] = {
        "Масштаб изображения", "Фильтр изображения", "Звук",
        "Скорость VM", "Папка игр", "Сохранить и выйти"
    };
    int y = LIST_Y;
    for (int i = 0; i < SET_COUNT; i++) {
        y = draw_row(cv, cw, y, names[i], settings_value(s, i), i == sel, i, SET_COUNT);
    }
    /* живой предпросмотр рамки масштабирования */
    int pv_w = 420, pv_h = 236;
    int pv_x = cw - pv_w - 60, pv_y = SWITCH_UI_HEIGHT - 300;
    draw_text(cv, cw, SWITCH_UI_HEIGHT, pv_x, pv_y - 36, "Предпросмотр:", COL_DIM, 2);
    int rx, ry, rw, rh;
    extern void switch_scaling_game_rect(int, int, int, int, int, int*, int*, int*, int*);
    switch_scaling_game_rect(s->scale_mode, 240, 320, pv_w, pv_h, &rx, &ry, &rw, &rh);
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, pv_x, pv_y, pv_w, pv_h, COL_BG_ALT);
    hline(cv, cw, SWITCH_UI_HEIGHT, pv_x, pv_x + pv_w, pv_y, COL_LINE);
    if (s->scale_mode == NOJME_SCALE_FIT_BLUR) {
        /* имитация блюр-фона: тёмно-синяя «размытая» подложка */
        fill_rect(cv, cw, SWITCH_UI_HEIGHT, pv_x, pv_y, pv_w, pv_h, 0xFF1E2A44);
        fill_rect(cv, cw, SWITCH_UI_HEIGHT, pv_x + rx, pv_y + ry, rw, rh, 0xFF3B4C6E);
    } else {
        fill_rect(cv, cw, SWITCH_UI_HEIGHT, pv_x, pv_y, pv_w, pv_h, 0xFF000000);
        fill_rect(cv, cw, SWITCH_UI_HEIGHT, pv_x + rx, pv_y + ry, rw, rh, 0xFF3B4C6E);
    }
    draw_text(cv, cw, SWITCH_UI_HEIGHT, pv_x + rx + 8, pv_y + ry + rh / 2 - 16, "240x320", COL_DIM, 2);
    draw_footer(cv, cw, "A — изменить   B — назад");
}

/* Returns 0 stay, 1 back to main. */
static int settings_handle(SwitchSettings* s, int* sel, unsigned keys) {
    if (keys & SWK_UP) { (*sel)--; if (*sel < 0) *sel = SET_COUNT - 1; }
    if (keys & SWK_DOWN) { (*sel)++; if (*sel >= SET_COUNT) *sel = 0; }

    if (keys & SWK_B) return 1;

    if (keys & (SWK_A | SWK_LEFT | SWK_RIGHT)) {
        int dir = (keys & SWK_LEFT) ? -1 : 1;
        switch (*sel) {
            case SET_SCALE:
                if (keys & SWK_A) s->scale_mode = (s->scale_mode + 1) % NOJME_SCALE_MODE_COUNT;
                else s->scale_mode = (s->scale_mode + dir + NOJME_SCALE_MODE_COUNT) % NOJME_SCALE_MODE_COUNT;
                break;
            case SET_FILTER:
                s->filter = (s->filter + (keys & SWK_A ? 1 : dir) + NOJME_FILTER_COUNT) % NOJME_FILTER_COUNT;
                break;
            case SET_AUDIO:
                s->audio_enabled = !s->audio_enabled;
                break;
            case SET_VM_SPEED:
                if (keys & SWK_A) s->vm_speed = (s->vm_speed + 1) % NOJME_VM_SPEED_COUNT;
                else s->vm_speed = (s->vm_speed + dir + NOJME_VM_SPEED_COUNT) % NOJME_VM_SPEED_COUNT;
                break;
            case SET_GAMES_DIR:
            case SET_SAVE:
                if (keys & SWK_A) {
                    switch_settings_save(s);
                    return 1;
                }
                break;
        }
    }
    return 0;
}

/* ================= Main menu ================= */

typedef enum {
    MM_OPEN = 0,
    MM_SETTINGS,
    MM_EXIT,
    MM_COUNT
} MainItem;

static void main_draw(uint32_t* cv, int sel) {
    int cw = SWITCH_UI_WIDTH;
    fill_rect(cv, cw, SWITCH_UI_HEIGHT, 0, 0, cw, 72, COL_HEADER);
    hline(cv, cw, SWITCH_UI_HEIGHT, 0, cw, 72, COL_LINE);
    draw_text(cv, cw, SWITCH_UI_HEIGHT, 32, 14, "J2ME Эмулятор", COL_TEXT, 3);
    {
        extern const char* nojme_switch_version_string(void);
        const char* v = nojme_switch_version_string();
        draw_text(cv, cw, SWITCH_UI_HEIGHT, cw - 32 - switch_font_text_width(v, 2), 24, v, COL_DIM, 2);
    }
    int y = LIST_Y + 40;
    static const char* names[MM_COUNT] = { "Открыть игру", "Настройки", "Выход" };
    for (int i = 0; i < MM_COUNT; i++) {
        y = draw_row(cv, cw, y, names[i], NULL, i == sel, i, MM_COUNT);
    }
    draw_text(cv, cw, SWITCH_UI_HEIGHT, 40, y + 40, "MIDP2 мобильные игры на Nintendo Switch", COL_DIM, 2);
    draw_footer(cv, cw, "A — выбрать   B — выход");
}

/* ================= Top-level menu session ================= */

int switch_ui_pick_game(char* out_path, size_t path_cap) {
    static const char* menu_names[MM_COUNT] = { "Открыть игру", "Настройки", "Выход" };
    (void)menu_names;

    SwitchSettings st = *switch_settings_get();
    MenuScreen screen = MMAIN_MAIN;
    int sel = 0;
    int set_sel = 0;
    BrowserState br;
    memset(&br, 0, sizeof(br));
    browse_root(br.cwd, sizeof(br.cwd));

    int result = 0; /* 0 = выход, 1 = игра выбрана */
    uint64_t last_draw = 0;
    unsigned held_last = 0;
    uint64_t repeat_t0 = 0;

    ui_log("menu session start\n");

    for (;;) {
        unsigned keys = sdl_switch_ui_pump_keys();
        unsigned held = sdl_switch_ui_held_keys();
        keys |= at_keys();

        /* hold-to-repeat в браузере (долгие списки) */
        if (screen == MMAIN_BROWSER) {
            unsigned newly_held = held & ~held_last;
            if (newly_held & (SWK_UP | SWK_DOWN)) repeat_t0 = sdl_switch_ui_ticks_ms();
            if (held & (SWK_UP | SWK_DOWN) && sdl_switch_ui_ticks_ms() - repeat_t0 > 450) {
                static uint64_t last_rep = 0;
                if (sdl_switch_ui_ticks_ms() - last_rep > 110) {
                    keys |= (held & SWK_UP) ? SWK_UP : 0;
                    keys |= (held & SWK_DOWN) ? SWK_DOWN : 0;
                    last_rep = sdl_switch_ui_ticks_ms();
                }
            }
        }
        held_last = held;

        if (keys & SWK_EXIT) break;

        switch (screen) {
            case MMAIN_MAIN:
                if (keys & SWK_UP) { sel--; if (sel < 0) sel = MM_COUNT - 1; }
                if (keys & SWK_DOWN) { sel++; if (sel >= MM_COUNT) sel = 0; }
                if (keys & (SWK_A | SWK_RIGHT)) {
                    if (sel == MM_OPEN) {
                        browse_root(br.cwd, sizeof(br.cwd));
                        browse_load(&br.list, br.cwd);
                        br.sel = 0; br.scroll = 0; br.return_to_settings = 0;
                        ui_log("browser open: %s (%d entries)\n", br.cwd, br.list.count);
                        screen = MMAIN_BROWSER;
                    } else if (sel == MM_SETTINGS) {
                        set_sel = 0;
                        screen = MMAIN_SETTINGS;
                    } else {
                        ui_log("menu exit (item Выход)\n");
                        goto done;
                    }
                }
                if (keys & SWK_B) {
                    ui_log("menu exit (B at main)\n");
                    goto done;
                }
                break;

            case MMAIN_BROWSER: {
                int r = browser_handle(&br, keys, out_path, path_cap);
                if (r == 1) { result = 1; goto done; }
                if (r == 2) screen = MMAIN_MAIN;
                break;
            }

            case MMAIN_SETTINGS: {
                if (keys & SWK_A && set_sel == SET_GAMES_DIR) {
                    /* выбор папки игр через браузер */
                    browse_root(br.cwd, sizeof(br.cwd));
                    browse_load(&br.list, br.cwd);
                    br.sel = 0; br.scroll = 0; br.return_to_settings = 1;
                    screen = MMAIN_DIRPICKER;
                    break;
                }
                if (settings_handle(&st, &set_sel, keys) == 1) {
                    /* выход из настроек: применяем (без записи — запись
                     * только через «Сохранить», но сессионные значения
                     * применяются немедленно) */
                    switch_settings_set(&st);
                    screen = MMAIN_MAIN;
                }
                break;
            }

            case MMAIN_DIRPICKER: {
                /* Выбор «Папки игр»: список = [Эта папка] + подкаталоги.
                 * A на псевдо-строке подтверждает текущую папку, A на
                 * каталоге входит в него, B — на уровень выше (из корня —
                 * назад в настройки без изменения). */
                int count = br.list.count + 1; /* + «[Эта папка]» */
                if (keys & SWK_UP) { br.sel--; if (br.sel < 0) br.sel = count - 1; }
                if (keys & SWK_DOWN) { br.sel++; if (br.sel >= count) br.sel = 0; }
                if (br.sel < br.scroll) br.scroll = br.sel;
                if (br.sel >= br.scroll + VISIBLE_ROWS) br.scroll = br.sel - VISIBLE_ROWS + 1;

                if (keys & SWK_B) {
                    if (strcmp(br.cwd, "/") == 0 || strcmp(br.cwd, ".") == 0) {
                        screen = MMAIN_SETTINGS;
                    } else {
                        path_parent(br.cwd);
                        browse_load(&br.list, br.cwd);
                        br.sel = 0; br.scroll = 0;
                    }
                    break;
                }
                if (keys & SWK_A) {
                    if (br.sel == 0) {
                        snprintf(st.games_dir, sizeof(st.games_dir), "%s", br.cwd);
                        switch_settings_set(&st);
                        switch_settings_save(&st);
                        ui_log("games_dir set to %s\n", br.cwd);
                        screen = MMAIN_SETTINGS;
                    } else if (br.list.count > 0) {
                        const BrowseEntry* e = &br.list.items[br.sel - 1];
                        if (e->is_dir) {
                            path_join(br.cwd, sizeof(br.cwd), br.cwd, e->name);
                            browse_load(&br.list, br.cwd);
                            br.sel = 0; br.scroll = 0;
                        }
                    }
                }
                break;
            }
        }

        /* ---- render (trottle to ~60 fps) ---- */
        uint64_t now = sdl_switch_ui_ticks_ms();
        if (now - last_draw >= 16) {
            last_draw = now;
            uint32_t* cv = sdl_switch_ui_canvas();
            if (cv) {
                fill_rect(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, 0, 0,
                          SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT, COL_BG);
                switch (screen) {
                    case MMAIN_MAIN:     main_draw(cv, sel); break;
                    case MMAIN_BROWSER:  browser_draw(cv, &br); break;
                    case MMAIN_SETTINGS: settings_draw(cv, &st, set_sel); break;
                    case MMAIN_DIRPICKER: {
                        /* своя отрисовка: [Эта папка] + подкаталоги */
                        draw_header(cv, SWITCH_UI_WIDTH, "Папка игр", br.cwd);
                        int y = LIST_Y;
                        y = draw_row(cv, SWITCH_UI_WIDTH, y, "[Эта папка]",
                                     "сделать стартовой", br.sel == 0, 0, br.list.count + 1);
                        int from = br.scroll; /* окно по ВИДИМЫМ строкам */
                        for (int i = from; i < br.list.count && y < LIST_Y + VISIBLE_ROWS * ROW_H; i++) {
                            const BrowseEntry* e = &br.list.items[i];
                            char label[320];
                            snprintf(label, sizeof(label), "[%s]", e->name);
                            char shown[320];
                            utf8_trunc(label, shown, sizeof(shown), 52);
                            y = draw_row(cv, SWITCH_UI_WIDTH, y, shown, "каталог",
                                         br.sel == i + 1, i + 1, br.list.count + 1);
                        }
                        draw_footer(cv, SWITCH_UI_WIDTH, "A — применить/войти   B — выше");
                        break;
                    }
                }
                sdl_switch_ui_present();
            }
        } else {
            sdl_switch_ui_wait(4);
        }
    }

done:
    browse_free(&br.list);
    ui_log("menu session end (result=%d)\n", result);
    return result;
}

/* Version string for the main menu header. */
const char* nojme_switch_version_string(void) {
    extern const char* j2me_core_build_id(void);
    static char buf[64];
    if (!buf[0]) snprintf(buf, sizeof(buf), "core %s", j2me_core_build_id());
    return buf;
}
