/*
 * switch_common.h — shared settings model for the Nintendo Switch frontend.
 *
 * The Switch port (Makefile: platform=switch) is an SDL2 app: the same
 * core drives a 1280x720 window with an in-app menu system (game browser +
 * settings) implemented in src/switch/switch_ui.c. Settings persist to
 * <sdmc:/switch/j2me/settings.ini> on real hardware (plain file next to
 * the binary in non-Switch verification builds).
 */
#ifndef SWITCH_COMMON_H
#define SWITCH_COMMON_H

#include <stddef.h>

/* ---- Display scaling modes (settings item "Масштаб") ---- */
#define NOJME_SCALE_STRETCH   0  /* растянуть на весь экран (игнор пропорций) */
#define NOJME_SCALE_FIT_BLACK 1  /* пропорции сохранены, чёрный бордюр */
#define NOJME_SCALE_FIT_BLUR  2  /* пропорции сохранены, размытый фон вместо бордюра */
#define NOJME_SCALE_MODE_COUNT 3

/* ---- Game canvas filtering (settings item "Фильтр") ---- */
#define NOJME_FILTER_NEAREST 0  /* пиксельный (retro) */
#define NOJME_FILTER_LINEAR  1  /* сглаженный */
#define NOJME_FILTER_COUNT   2

/* ---- VM speed presets (settings item "Скорость VM") ----
 * Mirrors the libretro j2me_vm_speed option semantics: the value maps to
 * g_jvm_thread_budget (game-thread instruction budget per 16.6 ms slice):
 * original = 15000 (~0.9M instr/s, «телефонный» темп), fast = 90000
 * (default, ~5.4M instr/s), turbo = 0 (бюджет снят, потоки свободны). */
#define NOJME_VM_SPEED_ORIGINAL 0
#define NOJME_VM_SPEED_FAST     1
#define NOJME_VM_SPEED_TURBO    2
#define NOJME_VM_SPEED_COUNT    3

typedef struct {
    int scale_mode;          /* NOJME_SCALE_* */
    int filter;              /* NOJME_FILTER_* */
    int audio_enabled;       /* 1 = звук включён */
    int vm_speed;            /* NOJME_VM_SPEED_* */
    char games_dir[512];     /* стартовая папка браузера ("") = корень SD */
} SwitchSettings;

/* Defaults: fit-with-black-borders, pixel filtering, audio on, fast VM. */
void switch_settings_defaults(SwitchSettings* s);

/* Singleton: loads settings.ini on first call. NULL-safe (returns defaults
 * if the file is missing/corrupt). */
const SwitchSettings* switch_settings_get(void);

/* Update the singleton (call switch_settings_save right after to persist). */
void switch_settings_set(const SwitchSettings* s);

/* Persist to settings.ini. Returns 0 on success. */
int switch_settings_save(const SwitchSettings* s);

/* Human-readable value names for the settings UI. */
const char* switch_scale_mode_name(int mode);
const char* switch_filter_name(int filter);
const char* switch_vm_speed_name(int speed);

/* ---- Switch frontend screen geometry ---- */
#define SWITCH_UI_WIDTH  1280
#define SWITCH_UI_HEIGHT 720

#endif /* SWITCH_COMMON_H */
