mobile3d.o: src/midp/mobile3d.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h \
 src/include/win_thread_shim.h include/jvm.h include/native.h \
 include/jvm.h include/heap.h include/opcodes.h include/midp.h \
 include/sdl_backend.h include/midp.h src/render/render.h include/miniz.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/win_thread_shim.h:
include/jvm.h:
include/native.h:
include/jvm.h:
include/heap.h:
include/opcodes.h:
include/midp.h:
include/sdl_backend.h:
include/midp.h:
src/render/render.h:
include/miniz.h:
