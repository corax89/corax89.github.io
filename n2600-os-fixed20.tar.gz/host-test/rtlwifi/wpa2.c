/* wpa2.c — криптография и EAPOL для WPA2-PSK (CCMP) — сессия 12.
 *
 * Минимальный supplicant-набор для подключения к WPA2-Personal:
 *   - SHA-1 / HMAC-SHA1 (FIPS 180-1, RFC 2104);
 *   - PBKDF2-HMAC-SHA1 (RFC 2898): парольная фраза + SSID → PMK
 *     (4096 итераций, 32 байта — как требует 802.11i);
 *   - PRF по 802.11i §8.5.1.1 (счётчик, как sha1_prf() из hostap):
 *     PTK = PRF(PMK, "Pairwise key expansion",
 *               min/max(AA,SPA) || min/max(ANonce,SNonce)) — 48 байт
 *       (KCK 16 + KEK 16 + TK 16 для CCMP);
 *   - AES-128 (FIPS-197, encrypt+decrypt — decrypt нужен для
 *     RFC 3394 AES Key Unwrap: Key Data в сообщении 3 рукопожатия
 *     зашифрован KEK'ом);
 *   - сборка/разбор кадров EAPOL-Key (802.1X-2004, дескриптор 2).
 *
 * Само шифрование DATA-кадров делает ЖЕЛЕЗО AR9285 (keycache + бит
 * EncrType в TX-дескрипторе) — здесь только рукопожатие и ключи.
 *
 * Проверено тест-векторами (scripts/test_wpa2_host.c — сборка на хосте):
 *   SHA-1("abc"), HMAC-SHA1 (RFC 2202 #1), PBKDF2 (RFC 6070 #1..#3),
 *   AES-128 (FIPS-197 C.1), AES-Wrap/Unwrap (RFC 3394 4.1),
 *   PTK-вектор из hostap test (sha1_prf) — см. тест.
 */
#include "wpa2.h"

#ifdef __HOST_TEST__
/* сборка на хосте (тест-векторы): libc вместо freestanding-строк */
#include <string.h>
#else
#include "string.h"
#include "types.h"
#endif

/* ================= SHA-1 ================= */

typedef struct {
    u32 h[5];
    u64 len;              /* всего байт до паддинга */
    u8  buf[64];
    u32 buf_len;
} sha1_ctx_t;

static u32 rol32(u32 v, int n) { return (v << n) | (v >> (32 - n)); }

static void sha1_compress(u32 h[5], const u8 *p)
{
    u32 w[80];
    for (int i = 0; i < 16; i++)
        w[i] = ((u32)p[i*4] << 24) | ((u32)p[i*4+1] << 16) |
               ((u32)p[i*4+2] << 8) | (u32)p[i*4+3];
    for (int i = 16; i < 80; i++)
        w[i] = rol32(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);

    u32 a = h[0], b = h[1], c = h[2], d = h[3], e = h[4];
    for (int i = 0; i < 80; i++) {
        u32 f, k;
        if (i < 20)      { f = (b & c) | ((~b) & d);          k = 0x5A827999; }
        else if (i < 40) { f = b ^ c ^ d;                     k = 0x6ED9EBA1; }
        else if (i < 60) { f = (b & c) | (b & d) | (c & d);   k = 0x8F1BBCDC; }
        else             { f = b ^ c ^ d;                     k = 0xCA62C1D6; }
        u32 t = rol32(a, 5) + f + e + k + w[i];
        e = d; d = c; c = rol32(b, 30); b = a; a = t;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e;
}

static void sha1_init(sha1_ctx_t *c)
{
    c->h[0] = 0x67452301; c->h[1] = 0xEFCDAB89; c->h[2] = 0x98BADCFE;
    c->h[3] = 0x10325476; c->h[4] = 0xC3D2E1F0;
    c->len = 0;
    c->buf_len = 0;
}

static void sha1_update(sha1_ctx_t *c, const u8 *data, u32 n)
{
    c->len += n;
    while (n > 0) {
        u32 take = 64 - c->buf_len;
        if (take > n) take = n;
        memcpy(c->buf + c->buf_len, data, take);
        c->buf_len += take;
        data += take;
        n -= take;
        if (c->buf_len == 64) {
            sha1_compress(c->h, c->buf);
            c->buf_len = 0;
        }
    }
}

static void sha1_final(sha1_ctx_t *c, u8 out[20])
{
    u64 bits = c->len * 8;
    u8 pad = 0x80;
    sha1_update(c, &pad, 1);
    pad = 0;
    while (c->buf_len != 56)
        sha1_update(c, &pad, 1);
    /* длина — БЕЗ учёта добивки (сохранили раньше) */
    for (int i = 0; i < 8; i++)
        c->buf[56 + i] = (u8)(bits >> (56 - i * 8));
    sha1_compress(c->h, c->buf);
    for (int i = 0; i < 5; i++) {
        out[i*4]   = (u8)(c->h[i] >> 24);
        out[i*4+1] = (u8)(c->h[i] >> 16);
        out[i*4+2] = (u8)(c->h[i] >> 8);
        out[i*4+3] = (u8)(c->h[i]);
    }
}

void wpa2_sha1(const void *data, u32 len, u8 out[20])
{
    sha1_ctx_t c;
    sha1_init(&c);
    sha1_update(&c, (const u8 *)data, len);
    sha1_final(&c, out);
}

/* ================= HMAC-SHA1 ================= */

static void hmac_sha1_keyblocks(const u8 *key, u32 key_len, u8 kipad[64], u8 kopad[64])
{
    u8 k0[64];
    memset(k0, 0, sizeof(k0));
    if (key_len > 64) {
        sha1_ctx_t c;
        sha1_init(&c);
        sha1_update(&c, key, key_len);
        sha1_final(&c, k0);          /* ключ > 64 байт: сначала хэш */
    } else {
        memcpy(k0, key, key_len);
    }
    for (int i = 0; i < 64; i++) {
        kipad[i] = (u8)(k0[i] ^ 0x36);
        kopad[i] = (u8)(k0[i] ^ 0x5C);
    }
}

void wpa2_hmac_sha1(const u8 *key, u32 key_len,
                    const u8 *data, u32 data_len, u8 out[20])
{
    u8 kipad[64], kopad[64], inner[20];
    sha1_ctx_t c;
    hmac_sha1_keyblocks(key, key_len, kipad, kopad);
    sha1_init(&c);
    sha1_update(&c, kipad, 64);
    sha1_update(&c, data, data_len);
    sha1_final(&c, inner);
    sha1_init(&c);
    sha1_update(&c, kopad, 64);
    sha1_update(&c, inner, 20);
    sha1_final(&c, out);
}

/* HMAC по нескольким буферам (для PRF без склейки копий) */
static void hmac_sha1_vec(const u8 *key, u32 key_len,
                          const u8 *const parts[4], const u32 plen[4],
                          u8 out[20])
{
    u8 kipad[64], kopad[64], inner[20];
    sha1_ctx_t c;
    hmac_sha1_keyblocks(key, key_len, kipad, kopad);
    sha1_init(&c);
    sha1_update(&c, kipad, 64);
    for (int i = 0; i < 4; i++)
        if (plen[i]) sha1_update(&c, parts[i], plen[i]);
    sha1_final(&c, inner);
    sha1_init(&c);
    sha1_update(&c, kopad, 64);
    sha1_update(&c, inner, 20);
    sha1_final(&c, out);
}

/* ================= PBKDF2-HMAC-SHA1 (RFC 2898) ================= */

static void be32(u8 *p, u32 v)
{
    p[0] = (u8)(v >> 24); p[1] = (u8)(v >> 16);
    p[2] = (u8)(v >> 8);  p[3] = (u8)v;
}

void wpa2_pbkdf2_sha1(const u8 *pass, u32 pass_len,
                      const u8 *salt, u32 salt_len,
                      u32 iters, u8 *out, u32 out_len)
{
    /* salt у нас — SSID (≤ 32 байт), склейка на стеке */
    if (salt_len > 96) return;
    u32 blocks = (out_len + 19) / 20;
    for (u32 b = 1; b <= blocks; b++) {
        u8 u[20], t[20], tmp[128];
        memcpy(tmp, salt, salt_len);
        be32(tmp + salt_len, b);
        /* U1 = HMAC(P, S || INT(b)) */
        wpa2_hmac_sha1(pass, pass_len, tmp, salt_len + 4, u);
        memcpy(t, u, 20);
        for (u32 i = 2; i <= iters; i++) {
            wpa2_hmac_sha1(pass, pass_len, u, 20, u);
            for (int k = 0; k < 20; k++) t[k] ^= u[k];
        }
        u32 take = out_len - (b - 1) * 20;
        if (take > 20) take = 20;
        memcpy(out + (b - 1) * 20, t, take);
    }
}

/* ================= PRF-802.11i (как sha1_prf() из hostap) =================
 * HMAC-SHA1(key, label||NUL || data || counter), counter = 0,1,2… */
void wpa2_prf(const u8 *key, u32 key_len, const char *label,
              const u8 *data, u32 data_len, u8 *buf, u32 buf_len)
{
    u32 label_len = (u32)strlen(label) + 1;   /* ВКЛЮЧАЯ NUL — как в hostap */
    u32 pos = 0;
    u8 counter = 0;
    while (pos < buf_len) {
        const u8 *parts[4];
        u32 plen[4];
        parts[0] = (const u8 *)label; plen[0] = label_len;
        parts[1] = data;            plen[1] = data_len;
        parts[2] = &counter;        plen[2] = 1;
        parts[3] = 0;               plen[3] = 0;
        u8 hash[20];
        hmac_sha1_vec(key, key_len, parts, plen, hash);
        u32 take = buf_len - pos;
        if (take > 20) take = 20;
        memcpy(buf + pos, hash, take);
        pos += take;
        counter++;
    }
}

/* PTK = PRF-48(PMK, "Pairwise key expansion",
 *              min(AA,SPA)||max(AA,SPA)||min(ANonce,SNonce)||max(ANonce,SNonce))
 * AA — адрес точки, SPA — наш адрес. 48 байт = KCK16+KEK16+TK16. */
void wpa2_derive_ptk(const u8 pmk[32],
                     const u8 aa[6], const u8 spa[6],
                     const u8 anonce[32], const u8 snonce[32],
                     u8 ptk[48])
{
    u8 data[76];
    const u8 *mac1, *mac2, *nc1, *nc2;
    if (memcmp(aa, spa, 6) < 0) { mac1 = aa;  mac2 = spa; }
    else                        { mac1 = spa; mac2 = aa; }
    if (memcmp(anonce, snonce, 32) < 0) { nc1 = anonce; nc2 = snonce; }
    else                                { nc1 = snonce; nc2 = anonce; }
    memcpy(data, mac1, 6);
    memcpy(data + 6, mac2, 6);
    memcpy(data + 12, nc1, 32);
    memcpy(data + 44, nc2, 32);
    wpa2_prf(pmk, 32, "Pairwise key expansion", data, 76, ptk, 48);
}

/* ================= AES-128 (FIPS-197) ================= */

static const u8 aes_sbox[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

static const u8 aes_inv_sbox[256] = {
    0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
    0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
    0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
    0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
    0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
    0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
    0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
    0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
    0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
    0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
    0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
    0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
    0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
    0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
    0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
    0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d
};

static u8 gf_xtime(u8 a)
{
    u8 r = (u8)(a << 1);
    if (a & 0x80) r ^= 0x1B;
    return r;
}

static u8 gf_mul(u8 a, u8 b)
{
    u8 r = 0;
    while (b) {
        if (b & 1) r ^= a;
        a = gf_xtime(a);
        b >>= 1;
    }
    return r;
}

/* Расширение ключа AES-128: 44 слова (11 подключей). */
static void aes128_expand(const u8 key[16], u32 rk[44])
{
    u32 rcon = 1;
    for (int i = 0; i < 4; i++)
        rk[i] = ((u32)key[i*4] << 24) | ((u32)key[i*4+1] << 16) |
                ((u32)key[i*4+2] << 8) | (u32)key[i*4+3];
    for (int i = 4; i < 44; i++) {
        u32 t = rk[i-1];
        if (i % 4 == 0) {
            t = rol32(t, 8);                          /* RotWord */
            t = ((u32)aes_sbox[(t >> 24) & 0xFF] << 24) |
                ((u32)aes_sbox[(t >> 16) & 0xFF] << 16) |
                ((u32)aes_sbox[(t >> 8) & 0xFF] << 8) |
                (u32)aes_sbox[t & 0xFF];
            t ^= rcon << 24;
            rcon = gf_xtime((u8)rcon);
        }
        rk[i] = rk[i-4] ^ t;
    }
}

/* Шифрование одного блока. Состояние st[16]: байт i = input[i],
 * порядок FIPS-197 (state[r][c] = in[r + 4c]) — работаем прямо в нём. */
void wpa2_aes128_encrypt(const u8 key[16], const u8 in[16], u8 out[16])
{
    u32 rk[44];
    u8 st[16], tmp[16];
    aes128_expand(key, rk);
    memcpy(st, in, 16);
    /* AddRoundKey(0) */
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++)
            st[r + 4*c] ^= (u8)(rk[c] >> (24 - 8 * r));
    for (int round = 1; round <= 10; round++) {
        /* SubBytes */
        for (int i = 0; i < 16; i++) st[i] = aes_sbox[st[i]];
        /* ShiftRows: строка r — цикл. сдвиг влево на r
         * (строка 0 не двигается — копируем её в tmp целиком!) */
        memcpy(tmp, st, 16);
        for (int r = 1; r < 4; r++)
            for (int c = 0; c < 4; c++)
                tmp[r + 4*c] = st[r + 4*((c + r) % 4)];
        for (int i = 0; i < 16; i++) st[i] = tmp[i];
        if (round != 10) {
            /* MixColumns по столбцам */
            for (int c = 0; c < 4; c++) {
                u8 a0 = st[0 + 4*c], a1 = st[1 + 4*c];
                u8 a2 = st[2 + 4*c], a3 = st[3 + 4*c];
                st[0 + 4*c] = (u8)(gf_mul(a0, 2) ^ gf_mul(a1, 3) ^ a2 ^ a3);
                st[1 + 4*c] = (u8)(a0 ^ gf_mul(a1, 2) ^ gf_mul(a2, 3) ^ a3);
                st[2 + 4*c] = (u8)(a0 ^ a1 ^ gf_mul(a2, 2) ^ gf_mul(a3, 3));
                st[3 + 4*c] = (u8)(gf_mul(a0, 3) ^ a1 ^ a2 ^ gf_mul(a3, 2));
            }
        }
        /* AddRoundKey(round) */
        for (int c = 0; c < 4; c++)
            for (int r = 0; r < 4; r++)
                st[r + 4*c] ^= (u8)(rk[round * 4 + c] >> (24 - 8 * r));
    }
    memcpy(out, st, 16);
}

/* Расшифровка блока (обратный порядок раундов). */
void wpa2_aes128_decrypt(const u8 key[16], const u8 in[16], u8 out[16])
{
    u32 rk[44];
    u8 st[16], tmp[16];
    aes128_expand(key, rk);
    memcpy(st, in, 16);
    /* AddRoundKey(10) */
    for (int c = 0; c < 4; c++)
        for (int r = 0; r < 4; r++)
            st[r + 4*c] ^= (u8)(rk[10 * 4 + c] >> (24 - 8 * r));
    for (int round = 9; round >= 0; round--) {
        /* InvShiftRows: строка r — цикл. сдвиг ВПРАВО на r
         * (строка 0 не двигается — копируем её в tmp целиком!) */
        memcpy(tmp, st, 16);
        for (int r = 1; r < 4; r++)
            for (int c = 0; c < 4; c++)
                tmp[r + 4*c] = st[r + 4*((c + 4 - r) % 4)];
        for (int i = 0; i < 16; i++) st[i] = tmp[i];
        /* InvSubBytes */
        for (int i = 0; i < 16; i++) st[i] = aes_inv_sbox[st[i]];
        /* AddRoundKey(round) */
        for (int c = 0; c < 4; c++)
            for (int r = 0; r < 4; r++)
                st[r + 4*c] ^= (u8)(rk[round * 4 + c] >> (24 - 8 * r));
        if (round != 0) {
            /* InvMixColumns */
            for (int c = 0; c < 4; c++) {
                u8 a0 = st[0 + 4*c], a1 = st[1 + 4*c];
                u8 a2 = st[2 + 4*c], a3 = st[3 + 4*c];
                st[0 + 4*c] = (u8)(gf_mul(a0,14) ^ gf_mul(a1,11) ^ gf_mul(a2,13) ^ gf_mul(a3, 9));
                st[1 + 4*c] = (u8)(gf_mul(a0, 9) ^ gf_mul(a1,14) ^ gf_mul(a2,11) ^ gf_mul(a3,13));
                st[2 + 4*c] = (u8)(gf_mul(a0,13) ^ gf_mul(a1, 9) ^ gf_mul(a2,14) ^ gf_mul(a3,11));
                st[3 + 4*c] = (u8)(gf_mul(a0,11) ^ gf_mul(a1,13) ^ gf_mul(a2, 9) ^ gf_mul(a3,14));
            }
        }
    }
    memcpy(out, st, 16);
}

/* ================= RFC 3394: AES Key Wrap / Unwrap ================= */

/* XOR старших 8 байт с t (big-endian, RFC 3394). */
static void xor_be64(u8 *dst, const u8 *src, u64 t)
{
    for (int k = 0; k < 8; k++)
        dst[k] = (u8)(src[k] ^ (t >> (56 - 8 * k)));
}

/* Unwrap: in_len кратен 8 и >= 16; выход = in_len - 8 байт.
 * Возвращает 1 при успехе (IV = A6…A6), 0 при неверном значении. */
int wpa2_aes_unwrap(const u8 kek[16], const u8 *in, u32 in_len, u8 *out)
{
    if (in_len < 16 || (in_len & 7)) return 0;
    u32 n = in_len / 8 - 1;              /* число блоков данных */
    u8 A[8], B[16];
    u8 *R = out;                          /* out вмещает 8*n байт */
    memcpy(A, in, 8);
    memmove(R, in + 8, 8 * n);
    for (int j = 5; j >= 0; j--) {
        for (int i = (int)n - 1; i >= 0; i--) {
            u64 t = (u64)j * n + (u64)(i + 1);
            xor_be64(B, A, t);            /* B[0..7] = A ^ t */
            memcpy(B + 8, R + 8 * i, 8);
            wpa2_aes128_decrypt(kek, B, B);
            memcpy(A, B, 8);
            memcpy(R + 8 * i, B + 8, 8);
        }
    }
    static const u8 iv[8] = {0xA6,0xA6,0xA6,0xA6,0xA6,0xA6,0xA6,0xA6};
    return memcmp(A, iv, 8) == 0;
}

/* Wrap (для тестов): out = in_len + 8 байт. */
void wpa2_aes_wrap(const u8 kek[16], const u8 *in, u32 in_len, u8 *out)
{
    if (in_len == 0 || (in_len & 7)) return;
    u32 n = in_len / 8;
    u8 A[8] = {0xA6,0xA6,0xA6,0xA6,0xA6,0xA6,0xA6,0xA6};
    u8 B[16];
    u8 *R = out + 8;
    memmove(R, in, in_len);
    for (int j = 0; j <= 5; j++) {
        for (u32 i = 0; i < n; i++) {
            memcpy(B, A, 8);
            memcpy(B + 8, R + 8 * i, 8);
            wpa2_aes128_encrypt(kek, B, B);
            xor_be64(A, B, (u64)j * n + (i + 1));   /* A = MSB(B) ^ t */
            memcpy(R + 8 * i, B + 8, 8);
        }
    }
    memcpy(out, A, 8);
}

/* ================= EAPOL-Key (802.1X-2004, дескриптор 2) =================
 * Ethernet-кадр:
 *   0..5  dst (AP), 6..11 src (мы), 12..13 = 0x888E
 *   14    version (2), 15 type (3 = Key), 16..17 body length (BE)
 *   18    descriptor type (2 = RSN)
 *   19..20 key info (BE), 21..22 key length (BE)
 *   23..30 replay counter
 *   31..62 nonce, 63..78 IV, 79..86 RSC, 87..94 reserved
 *   95..110 MIC (16), 111..112 key data length (BE), 113.. key data */

#define EK_MIC_OFF      95     /* смещение MIC в Ethernet-кадре */
#define EK_KDLEN_OFF    111
#define EK_KD_OFF       113
#define EAPOL_HDR_SZ    4      /* version+type+len16 */

int wpa2_parse_eapol_key(const u8 *eth, u32 len, eapol_key_t *k)
{
    if (len < 14 + EAPOL_HDR_SZ + 95) return 0;
    if ((eth[12] != 0x88) || (eth[13] != 0x8E)) return 0;
    const u8 *e = eth + 14;
    u32 blen = ((u32)e[2] << 8) | e[3];          /* длина тела EAPOL */
    if (14 + 4 + blen > len) return 0;           /* усечённый кадр */
    if (e[1] != 3) return 0;                     /* не Key */
    k->ver = e[0];
    k->desc_type = e[4];
    if (k->desc_type != 2) return 0;             /* только RSN-дескриптор */
    k->key_info = (u16)(((u32)e[5] << 8) | e[6]);
    k->key_len  = (u16)(((u32)e[7] << 8) | e[8]);
    k->replay   = e + 9;                         /* 8 */
    k->nonce    = e + 17;                        /* 32 */
    k->iv       = e + 49;                        /* 16 */
    k->rsc      = e + 65;                        /* 8 */
    k->reserved = e + 73;                        /* 8 */
    k->mic      = e + 81;                        /* 16 */
    k->key_data_len = (u16)(((u32)e[81 + 16] << 8) | e[81 + 16 + 1]);
    /* ВАЖНО: 95 байт дескриптора УЖЕ включают поле key_data_len (2 б) —
     * прежний frame_len с «+2» захватывал 2 мусорных байта за кадром:
     * MIC проверялся/ставился по окну, сдвинутому на 2 байта (на реальных
     * точках это иногда проходило из-за нулей за кадром, иногда ломало
     * рукопожатие). Корректная длина EAPOL-Key кадра:
     *   14 (eth) + 4 (EAPOL hdr) + 95 (дескриптор) + key_data_len */
    if (14 + 4 + 95 + (u32)k->key_data_len > len) return 0;
    k->key_data = e + 99;
    k->frame = eth;                              /* целиком, для MIC */
    k->frame_len = 14 + 4 + 95 + k->key_data_len;
    return 1;
}

/* MIC EAPOL-кадра: HMAC-SHA1(KCK, кадр от поля version до конца),
 * поле MIC должно быть заполнено нулями; результат — 16 байт. */
void wpa2_eapol_mic(const u8 kck[16], const u8 *frame, u32 frame_len, u8 mic[16])
{
    u8 h[20];
    wpa2_hmac_sha1(kck, 16, frame + 14, frame_len - 14, h);
    memcpy(mic, h, 16);
}

/* Записать MIC в собранный кадр (поле было нулевым). */
void wpa2_eapol_set_mic(u8 *frame, const u8 mic[16])
{
    memcpy(frame + EK_MIC_OFF, mic, 16);
}

/* Собрать Ethernet-кадр EAPOL-Key (без MIC — поле нулей).
 * dst/src — MAC-адреса (AP / мы). Возвращает длину кадра. */
u32 wpa2_build_eapol_key(u8 *frame, const u8 dst[6], const u8 src[6],
                         u16 key_info, const u8 *nonce /* 32 или NULL */,
                         const u8 *replay /* 8 */,
                         const u8 *key_data, u16 key_data_len)
{
    u32 total = 14 + 4 + 95 + 2 + key_data_len;
    memset(frame, 0, total);
    memcpy(frame, dst, 6);
    memcpy(frame + 6, src, 6);
    frame[12] = 0x88; frame[13] = 0x8E;
    frame[14] = 2;    /* version: 802.1X-2004 */
    frame[15] = 3;    /* type: Key */
    frame[16] = (u8)((95 + 2 + key_data_len) >> 8);
    frame[17] = (u8)(95 + 2 + key_data_len);
    frame[18] = 2;    /* descriptor type: RSN */
    frame[19] = (u8)(key_info >> 8);
    frame[20] = (u8)key_info;
    frame[21] = 0; frame[22] = 16;   /* key length = 16 (CCMP) */
    if (replay) memcpy(frame + 23, replay, 8);
    if (nonce)  memcpy(frame + 31, nonce, 32);
    /* IV/RSC/reserved/MIC — нули */
    frame[EK_KDLEN_OFF]     = (u8)(key_data_len >> 8);
    frame[EK_KDLEN_OFF + 1] = (u8)key_data_len;
    if (key_data && key_data_len)
        memcpy(frame + EK_KD_OFF, key_data, key_data_len);
    return total;
}

/* Биты Key Info (host order, после BE16) */
u16 wpa2_key_info(const eapol_key_t *k) { return k->key_info; }

/* RSN IE для Association Request и EAPOL-Key M2:
 * version 1, group CCMP, pairwise {CCMP}, AKM {PSK}, capabilities 0. */
u32 wpa2_build_rsn_ie(u8 *out, int group_tkip)
{
    /* Сессия 25: групповой шифр берём от ТОЧКИ (из RSN IE маяка).
     * В смешанном режиме «WPA/WPA2 (TKIP+AES)» группа = TKIP — если
     * в assoc предложить CCMP, строгие точки отклоняют ассоциацию. */
    static const u8 body_ccmp[20] = {
        0x01, 0x00,                                 /* version 1 */
        0x00, 0x0F, 0xAC, 0x04,                     /* group: CCMP */
        0x01, 0x00,                                 /* 1 pairwise */
        0x00, 0x0F, 0xAC, 0x04,                     /* pairwise: CCMP */
        0x01, 0x00,                                 /* 1 AKM */
        0x00, 0x0F, 0xAC, 0x02,                     /* AKM: PSK */
        0x00, 0x00                                  /* RSN capabilities */
    };
    u8 body[20];
    memcpy(body, body_ccmp, sizeof(body));
    if (group_tkip) {
        body[2] = 0x00; body[3] = 0x0F; body[4] = 0xAC; body[5] = 0x02;
    }
    out[0] = 48;            /* element id: RSN */
    out[1] = sizeof(body);
    memcpy(out + 2, body, sizeof(body));
    return (u32)sizeof(body) + 2;
}
