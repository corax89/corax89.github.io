/* task.h — вытесняющая многозадачность N2600-OS.
 *
 * Реализация: round-robin планировщик на IRQ0 (PIT 100 Гц).
 * Контекст задач сохраняется в обработчике irq_stub_0 (см. task.c):
 *   pusha -> call task_schedule(saved_esp) -> movl ret, %esp -> popa -> iret
 *
 * Каждая задача имеет собственный стек (TASK_STACK_SIZE) из кучи ядра.
 * Главная задача (kmain) — это task[0], её стек не выделяется отдельно
 * (используется системный стек _stack_top из linker-скрипта).
 *
 * Лимит задач: 256 (был 8 — увеличен по запросу для диспетчера задач).
 *
 * API:
 *   task_init()                 — инициализация до sti(); создаёт task[0]
 *   task_spawn(name, fn, arg)   — породить новую задачу, fn(arg) запустится
 *                                  при первом переключении; возвращает индекс >=1
 *                                  или -1 при ошибке
 *   task_yield()                — уступить процессор (hlt до следующего IRQ0)
 *   task_exit()                 — завершить текущую задачу (не возвращает)
 *   task_count()                — число активных (не завершённых) задач
 *   task_current()              — индекс текущей задачи
 *   task_name(i)                — имя задачи (или "")
 *   task_used(i)                — занят ли слот
 *   task_finished(i)            — завершена ли задача
 *   task_uptime(i)              — сколько тиков задача суммарно исполнялась
 */
#ifndef TASK_H
#define TASK_H

#include "types.h"

#define MAX_TASKS 256

/* ---------------- приоритеты задач (сессия 34) ----------------
 * Проблема: чистый round-robin давал фоновым задачам (wifi/usb/sata)
 * равные слоты с потоками окон — во время USB-шторма перечисления
 * интерфейс заметно подтормаживал на Atom N2600.
 * Уровни (0 — самый высокий):
 *   UI     — kmain и потоки окон WM: отзывчивость мыши/отрисовки;
 *   NORMAL — приложения, ramfs-сервер;
 *   BG     — wifi/usb-hotplug/sata/netmon/httpd: фоновые подсистемы.
 * Планировщик: строгий приоритет среди готовых, round-robin внутри
 * уровня. Анти-голодание: задача, не получавшая CPU дольше
 * TASK_STARVE_TICKS, временно планируется как UI (потом возвращается
 * на свой уровень) — ватчдог (5 с) больше никого не убивает зря. */
#define TASK_PRIO_UI     0
#define TASK_PRIO_NORMAL 1
#define TASK_PRIO_BG     2
#define TASK_PRIO_LEVELS 3
#define TASK_STARVE_TICKS 250      /* 250 мс без CPU -> временное повышение */

void task_init(void);
int  task_spawn(const char *name, void (*fn)(void *), void *arg);
int  task_spawn_prio(const char *name, void (*fn)(void *), void *arg, int prio);
void task_set_priority(int idx, int prio);
int  task_priority(int idx);
/* Вариант с ВНЕШНИМ стеком (песочница нативных c4-бинарников:
 * loader передаёт стек внутри региона задачи — см. gdt.c/loader.c).
 * Память stack_mem будет освобождена при переиспользовании слота. */
int  task_spawn_ext(const char *name, void (*fn)(void *), void *arg,
                     u8 *stack_mem, u32 stack_size);
void task_yield(void);
void task_msleep(u32 ms);          /* сон на ms мс с уступкой CPU (kapi->msleep) */
void task_exit(void);
int  task_kill(int idx);          /* завершить задачу по индексу; 1=успех */

int  task_count(void);
int  task_current(void);
const char *task_name(int idx);
int  task_used(int idx);
int  task_finished(int idx);
u32  task_uptime(int idx);

/* Системные задачи (ramfs-сервер и т.п.): task_kill отказывается их
 * убивать, ватчдог их пропускает. Пометить можно сразу после task_spawn. */
void task_set_system(int idx);
int  task_is_system(int idx);

/* Ватчдог: проверяет все задачи на зависание.
 * Задача считается зависшей, если uptime не меняется > timeout_ticks.
 * kill зависших задач. Возвращает число убитых. */
int  task_watchdog(u32 timeout_ticks);

/* FIX [T3]: версия для вызова из IRQ0-контекста (прерывания уже
 * запрещены). Вызывается планировщиком каждые ~320 мс — ватчдог
 * работает ДАЖЕ если главный цикл kmain завис. */
int  task_watchdog_irq(u32 timeout_ticks);

/* Установить/получить таймаут ватчдога для конкретной задачи. */
void task_set_watchdog(int idx, u32 timeout_ticks);
u32  task_get_watchdog(int idx);

/* ---------------- сон и пробуждение (многопоточный WM) ----------------
 * Поток окна, у которого нет событий, помечает себя спящим
 * (task_set_waiting_me под cli) и делает hlt. Планировщик ПРОПУСКАЕТ
 * спящие задачи; posted события -> task_wake(idx) снимает waiting,
 * и задача снова участвует в round-robin. Ватчдог игнорирует спящие
 * задачи (это не зависание). */
void task_set_waiting_me(void);
void task_wake(int idx);
int  task_is_waiting(int idx);

/* Признак «текущая задача ждёт блокировку» (для ватчдога): задачи
 * в ожидании блокировки НЕ считаются зависшими — их защищает таймаут
 * отбора блокировки в sync.h (SLOCK_STALE_TICKS), а не ватчдог. */
void task_set_lockwait_me(int on);
int  task_is_lockwait(int idx);

/* Внутренняя функция — вызывается из irq_stub_0 (не использовать напрямую). */
u32 *task_schedule(u32 *saved_esp);

/* ---------------- защита памяти (песочница задач) ----------------
 * Линейная база региона задачи: пока задача исполняет нативный код
 * c4 (loader.c: sandbox_run), её SS/DS/ES имеют базу = регион, а ESP —
 * смещение; irq_stub_0 пересчитывает ESP по task_region_base[] при
 * каждом переключении. 0 = обычная задача (сегменты ядра flat).
 * ГЛОБАЛЬНЫЕ данные (не через функции) — см. task.c. */
void task_set_region_base(int tid, u32 base);
u32  task_get_region_base(int tid);

/* Хук очистки слота: вызывается при переиспользовании слота задачи,
 * у которой остался регион песочницы (kill/ватчдог внутри sandbox_run
 * — loader_task_fn не дошёл до своего free). Устанавливает loader. */
void task_set_slot_cleanup_hook(void (*cb)(int tid));

#endif /* TASK_H */
