#!/bin/sh
# run_tmfmt.sh — сборка и прогон хост-теста диспетчера задач
# (настоящий src/apps_taskmgr.c против заглушек).
# Использование: ./run_tmfmt.sh          (обычный)
#                ./run_tmfmt.sh asan     (AddressSanitizer + UBSan)
set -e
cd "$(dirname "$0")"

# 1) свежие копии src-файлов (quoted-include резолвится локально)
for f in apps_taskmgr.c utf8.h; do
    cp ../../n2600/src/$f .
done

# 2) компиляция (заглушки — локальные tm_stubs.h + тонкие обёртки;
# БЕЗ -I.: quoted-include резолвится в каталог исходника, а <...> — в
# настоящие заголовки libc, иначе заглушка string.h перекрывает libc)
FLAGS="-std=c99 -g -Wall -Wextra -Wno-unused-parameter"
if [ "$1" = "asan" ]; then
    FLAGS="$FLAGS -fsanitize=address,undefined -fno-omit-frame-pointer"
    BIN=tmfmt_test_asan
else
    BIN=tmfmt_test
fi
gcc $FLAGS tmfmt_test.c -o $BIN

echo "== Запуск $BIN =="
ASAN_OPTIONS=detect_leaks=1 ./$BIN
