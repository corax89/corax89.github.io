#!/usr/bin/env python3
"""qmon.py — управление QEMU через monitor-сокет + OCR скриншотов.

Использование как библиотека; из CLI:
  qmon.py send <iso> <secs> "команды;через;точку;с;запятой"  — запустить, послать, снять скрин
"""
import socket, subprocess, sys, time, os, re

QEMU = "/home/z/qemu-root/usr/bin/qemu-system-i386"
LD = "/home/z/qemu-root/usr/lib/x86_64-linux-gnu"
BIOS = ["-L", "/home/z/qemu-root/usr/share/seabios", "-L", "/home/z/qemu-root/usr/share/qemu", "-L", "/home/z/qemu-root/usr/share/ipxe"]
MON = "/tmp/qmon.sock"


class QMon:
    def __init__(self, iso, extra_args=None, ram=512):
        self.iso = iso
        self.proc = None
        self.extra = extra_args or []
        self.ram = ram
        self.pos = (400, 300)   # текущее положение мыши (ОС стартует в центре)
        self._mouse_calibrated = False

    def __enter__(self):
        if os.path.exists(MON):
            os.unlink(MON)
        cmd = [QEMU] + BIOS + [
            "-m", str(self.ram),
            "-drive", f"file={self.iso},format=raw,media=cdrom,if=ide,index=2",
            "-boot", "d",
            "-display", "none",
            "-serial", "file:/tmp/os-serial.log",
            "-monitor", f"unix:{MON},server,nowait",
            "-no-reboot",
        ]
        # сеть: если extra_args уже содержат netdev — не добавляем свою
        # romfile="" — без PXE ROM (ipxe-roms нет в portable-сборке, для
        # загрузки с CD он и не нужен)
        if not any("netdev" in a for a in self.extra):
            cmd += ["-netdev", "user,id=net0", "-device",
                    "e1000,netdev=net0,romfile="]
        cmd += self.extra
        env = dict(os.environ, LD_LIBRARY_PATH=LD)
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, env=env)
        # ждать monitor-сокет
        for _ in range(100):
            if os.path.exists(MON):
                try:
                    self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                    self.sock.connect(MON)
                    break
                except OSError:
                    pass
            time.sleep(0.1)
        else:
            raise RuntimeError("monitor socket not ready")
        time.sleep(0.5)
        self._drain()
        return self

    def _drain(self):
        self.sock.setblocking(False)
        try:
            while True:
                d = self.sock.recv(65536)
                if not d:
                    break
        except BlockingIOError:
            pass
        self.sock.setblocking(True)

    def cmd(self, c, wait=0.05):
        self.sock.sendall((c + "\n").encode())
        time.sleep(wait)
        self._drain()

    def screendump(self, path):
        self.cmd(f"screendump {path}", 0.4)
        for _ in range(20):
            if os.path.exists(path) and os.path.getsize(path) > 1000:
                return
            time.sleep(0.1)

    def sendkeys(self, text, delay=0.04):
        """Набрать текст посимвольно (us-раскладка)."""
        for ch in text:
            k = self._key(ch)
            if k:
                self.cmd(f"sendkey {k}", delay)

    @staticmethod
    def _key(ch):
        specials = {
            ' ': 'spc', '\n': 'ret', '.': 'dot', ',': 'comma',
            '/': 'slash', ';': 'semicolon', "'": 'apostrophe',
            '[': 'bracket_left', ']': 'bracket_right',
            '-': 'minus', '=': 'equal', '`': 'grave_accent',
            '\\': 'backslash', '\t': 'tab',
        }
        if ch in specials:
            return specials[ch]
        if ch == ':':
            return 'shift-semicolon'
        if ch == '_':
            return 'shift-minus'
        if ch == '?':
            return 'shift-slash'
        if ch == '!':
            return 'shift-1'
        if ch == '@':
            return 'shift-2'
        if ch == '#':
            return 'shift-3'
        if ch.isupper():
            return 'shift-' + ch.lower()
        if ch.isalnum():
            return ch
        return None

    def mouse_to(self, x, y, cur=None):
        """Относительное перемещение мыши к абсолютной точке (PS/2 relative).
        cur — можно передать стартовую позицию; по умолчанию self.pos.
        ВНИМАНИЕ: ПЕРВОЕ движение после загрузки даёт мусорный пакет
        (рассинхрон PS/2) — используйте click_at() с обратной связью."""
        cx, cy = cur if cur else self.pos
        dx, dy = x - cx, y - cy
        while dx != 0 or dy != 0:
            sx = max(-100, min(100, dx))
            sy = max(-100, min(100, dy))
            self.cmd(f"mouse_move {sx} {sy}", 0.01)
            dx -= sx
            dy -= sy
        self.pos = (x, y)
        return (x, y)

    def find_cursor(self, path=None):
        """Найти стрелку мыши на скрине.

        Строгий паттерн (курсор рисуется ЯВНО чёрным с белым контуром —
        виден на любом фоне и не совпадает с текстом):
          row 0:  'X           '  → (x,y) чёрный
          row 1:  'XX          '  → (x,y+1),(x+1,y+1) чёрные
          row 10: 'X*****XXXXX '  → (x) чёрный, (x+1..x+5) белые,
                                   (x+6..x+7) чёрные
        Возвращает (x, y) или None."""
        if path is None:
            path = "/tmp/shots/_cursor.ppm"
            self.screendump(path)
        w, h, img = read_ppm(path)

        def px(x, y):
            off = (y * w + x) * 3
            return img[off], img[off + 1], img[off + 2]

        def black(x, y):
            r, g, b = px(x, y)
            return r < 60 and g < 60 and b < 60

        def white(x, y):
            r, g, b = px(x, y)
            return r > 200 and g > 200 and b > 200

        # паттерн использует строки y..y+10 и колонки x..x+11:
        # сканируем всю площадь до этих пределов (низ экрана — таскбар —
        # тоже должен находиться!)
        for y in range(h - 11):
            for x in range(w - 12):
                if not black(x, y):
                    continue
                if not (black(x, y + 1) and black(x + 1, y + 1)):
                    continue
                # диагональная лестница стрелки (45°, белый заполняет
                # клин) — у шрифтовых глифов такого НЕТ:
                # row2: X*X   row3: X**X   row4: X***X
                if not (black(x, y + 2) and white(x + 1, y + 2) and
                        black(x + 2, y + 2)):
                    continue
                if not (black(x, y + 3) and white(x + 1, y + 3) and
                        white(x + 2, y + 3) and black(x + 3, y + 3)):
                    continue
                if not (black(x, y + 4) and white(x + 1, y + 4) and
                        white(x + 2, y + 4) and white(x + 3, y + 4) and
                        black(x + 4, y + 4)):
                    continue
                if not black(x, y + 10):
                    continue
                ok = all(white(x + k, y + 10) for k in range(1, 6))
                if not ok:
                    continue
                if not (black(x + 6, y + 10) and black(x + 7, y + 10)):
                    continue
                return (x, y)
        return None

    def move_at(self, x, y, tries=6):
        """Переместить мышь к (x,y) БЕЗ клика (для правой кнопки и hover)."""
        if not self._mouse_calibrated:
            self.cmd("mouse_move 1 1", 0.3)
            self.cmd("mouse_move 2 0", 0.3)
            self.cmd("mouse_move 0 2", 0.3)
            self._mouse_calibrated = True
        for _ in range(tries):
            cur = self.find_cursor()
            if cur is None:
                self.cmd("mouse_move 1 0", 0.2)
                self.cmd("mouse_move 0 1", 0.2)
                cur = self.find_cursor()
                if cur is None:
                    cur = self.pos
            cx, cy = cur
            dx, dy = x - cx, y - cy
            if abs(dx) <= 4 and abs(dy) <= 4:
                break
            while dx != 0 or dy != 0:
                sx = max(-100, min(100, dx))
                sy = max(-100, min(100, dy))
                self.cmd(f"mouse_move {sx} {sy}", 0.12)
                dx -= sx
                dy -= sy
            time.sleep(0.3)
        self.pos = (x, y)
        return self.pos

    def click_at(self, x, y, tries=6):
        """Переместить мышь к (x,y) С ОБРАТНОЙ СВЯЗЬЮ (по скрину) и кликнуть.
        Первые 1-2 движения после загрузки дают мусорные пакеты (рассинхрон
        PS/2) — калибруем холостыми движениями, дальше ведём по скрину."""
        if not self._mouse_calibrated:
            # калибровка: 3 холостых движения съедают рассинхрон
            self.cmd("mouse_move 1 1", 0.3)
            self.cmd("mouse_move 2 0", 0.3)
            self.cmd("mouse_move 0 2", 0.3)
            self._mouse_calibrated = True
        for _ in range(tries):
            cur = self.find_cursor()
            if cur is None:
                # курсор потерян (светлый фон?): шевелить и искать снова
                self.cmd("mouse_move 1 0", 0.2)
                self.cmd("mouse_move 0 1", 0.2)
                cur = self.find_cursor()
                if cur is None:
                    cur = self.pos
            cx, cy = cur
            dx, dy = x - cx, y - cy
            if abs(dx) <= 4 and abs(dy) <= 4:
                break
            # не более 100 за пакет (безопасно для PS/2)
            while dx != 0 or dy != 0:
                sx = max(-100, min(100, dx))
                sy = max(-100, min(100, dy))
                self.cmd(f"mouse_move {sx} {sy}", 0.02)
                dx -= sx
                dy -= sy
            time.sleep(0.3)
        self.pos = (x, y)
        self.click()

    def click(self, btn=1):
        self.cmd(f"mouse_button {btn}", 0.15)
        self.cmd("mouse_button 0", 0.15)

    def serial(self):
        try:
            with open("/tmp/os-serial.log", "rb") as f:
                return f.read().decode("utf-8", "replace")
        except FileNotFoundError:
            return ""

    def __exit__(self, *a):
        try:
            self.proc.terminate()
            self.proc.wait(timeout=5)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass


# ------------------------------------------------------------------ OCR
# Парсит font.c, строит таблицу глифов и распознаёт текст на PPM-скриншоте.
# Как и fb.c: cp 0x20..0x7E -> [0..94], 0x410..0x44F -> [95..158], спец.

def load_glyphs():
    src = open("/home/z/my-project/work/n2600/n2600-os/src/font.c").read()
    m = re.search(r"font8x16\[FONT_GLYPH_COUNT\]\[16\]\s*=\s*\{(.*?)\n\};",
                  src, re.S)
    body = m.group(1)
    glyphs = []
    for gm in re.finditer(r"\{((?:\s*0x[0-9A-Fa-f]+\s*,)+\s*0x[0-9A-Fa-f]+\s*)\}", body):
        vals = [int(v, 16) for v in re.findall(r"0x[0-9A-Fa-f]+", gm.group(1))]
        if len(vals) == 16:
            glyphs.append(vals)
    return glyphs


GLYPHS = None


def glyph_index(cp):
    if 0x20 <= cp <= 0x7E:
        return cp - 0x20
    if 0x410 <= cp <= 0x44F:
        return 95 + cp - 0x410
    if cp == 0x401:
        return 159
    if cp == 0x451:
        return 160
    if cp == 0xAB:
        return 161
    if cp == 0xBB:
        return 162
    if cp == 0xB0:
        return 163
    return -1


def cp_of_glyph(idx):
    for cp in list(range(0x20, 0x7F)) + list(range(0x410, 0x450)) + \
            [0x401, 0x451, 0xAB, 0xBB, 0xB0]:
        if glyph_index(cp) == idx:
            return cp
    return None


def read_ppm(path):
    data = open(path, "rb").read()
    # P6 заголовок: P6\nW H\nMAX\n<binary>
    parts = data.split(b"\n", 3)
    w, h = map(int, parts[1].split())
    return w, h, parts[3]


def ocr_region(img, w, x0, y0, cols, rows, glyphs, bright=300):
    """Распознать текстовую сетку 8x16, начиная с (x0,y0): cols×rows символов."""
    out = []
    for r in range(rows):
        line = ""
        for c in range(cols):
            x = x0 + c * 8
            y = y0 + r * 16
            pat = []
            ok = True
            for ry in range(16):
                b = 0
                for rx in range(8):
                    off = ((y + ry) * w + (x + rx)) * 3
                    p = img[off:off + 3]
                    br = p[0] + p[1] + p[2]
                    if br > bright * 3:
                        b |= 0x80 >> rx
                pat.append(b)
            # сравнить с глифами
            ch = None
            for gi, g in enumerate(glyphs):
                if g == pat:
                    cp = cp_of_glyph(gi)
                    ch = chr(cp) if cp else "?"
                    break
            line += ch if ch else "?"
        out.append(line)
    return out


def ocr_at(path, x, y, n_chars, glyphs=None, bright=400):
    """Прочитать n_chars символов с ЛЮБОЙ пиксельной позиции (x,y)."""
    global GLYPHS
    if glyphs is None:
        if GLYPHS is None:
            GLYPHS = load_glyphs()
        glyphs = GLYPHS
    w, h, img = read_ppm(path)
    out = ""
    for c in range(n_chars):
        cx = x + c * 8
        if cx + 8 > w or y + 16 > h:
            out += " "
            continue
        pat = []
        for ry in range(16):
            b = 0
            for rx in range(8):
                off = ((y + ry) * w + (cx + rx)) * 3
                p = img[off:off + 3]
                if p[0] + p[1] + p[2] > bright:
                    b |= 0x80 >> rx
            pat.append(b)
        ch = None
        for gi, g in enumerate(glyphs):
            if g == pat:
                cp = cp_of_glyph(gi)
                ch = chr(cp) if cp else "?"
                break
        out += ch if ch is not None else "?"
    return out


def ocr_strip(path, x0, y0, cols, rows, glyphs=None, bright=400):
    """Сетка символов с шагом 8x16 от (x0,y0) — для многострочных зон."""
    return [ocr_at(path, x0, y0 + r * 16, cols, glyphs, bright)
            for r in range(rows)]


def find_text_line(path, x, y_guess, y_range=24, glyphs=None, bright=400):
    """Найти строку текста около y_guess: перебрать смещения 0..y_range.
    Возвращает (y, text) лучшей строки (по числу распознанных глифов)."""
    global GLYPHS
    if glyphs is None:
        if GLYPHS is None:
            GLYPHS = load_glyphs()
        glyphs = GLYPHS
    best = (y_guess, "", -1)
    for dy in range(y_range):
        y = y_guess + dy
        t = ocr_at(path, x, y, 60, glyphs, bright)
        score = sum(1 for ch in t if ch not in ("?", " "))
        if score > best[2]:
            best = (y, t, score)
    return best[0], best[1]


# Кириллические буквы, чьи растры неотличимы от латинских (DejaVu Mono):
# OCR возвращает ПЕРВОЕ совпадение — латиницу. Нормализуем обе стороны.
# ВАЖНО: совпадения РЕГИСТРОЗАВИСИМЫ: «М»=M, но «м»≠m; «Т»=T, «т»≠t.
HOMO = {
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O',
    'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X',
}


def norm(s):
    """Нормализация для сравнения: омоглифы → латиница (регистр важен)."""
    return "".join(HOMO.get(ch, ch) for ch in s)


def looks_like(ocr_text, expected):
    """Сравнение с учётом омоглифов (кириллица читается латиницей)."""
    return norm(expected) in norm(ocr_text)


if __name__ == "__main__":
    if sys.argv[1] == "ocr":
        # ocr <ppm> <x> <y> <n>
        print(repr(ocr_at(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]),
                          int(sys.argv[5]))))
    elif sys.argv[1] == "strip":
        # strip <ppm> <x> <y> <cols> <rows>
        for l in ocr_strip(sys.argv[2], int(sys.argv[3]), int(sys.argv[4]),
                           int(sys.argv[5]), int(sys.argv[6])):
            print(f"{l}")
