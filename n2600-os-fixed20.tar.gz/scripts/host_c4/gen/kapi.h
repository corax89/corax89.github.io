/* kapi.h — таблица API ядра для приложений, загружаемых с диска.
 *
 * Загружаемый .bin-файл должен экспортировать точку входа:
 *   void entry(kapi_t *k, void *win);
 *
 * Все обращения к ядру идут через указатели в этой таблице — это позволяет
 * не делать полноценный динамический линковщик в простом ядре.
 *
 * Формат таблицы стабилен: новые функции добавляются только в конец,
 * существующие — без изменения сигнатуры.
 */
#ifndef KAPI_H
#define KAPI_H

#include "types.h"

struct window;

typedef struct {
    /* ---- Графика ---- */
    void (*fb_fill_rect)(int x, int y, int w, int h, u32 c);
    void (*fb_rect)(int x, int y, int w, int h, u32 c);
    void (*fb_hline)(int x0, int x1, int y, u32 c);
    void (*fb_text)(int x, int y, const char *s, u32 fg, int bg);
    void (*fb_char)(int x, int y, unsigned cp, u32 fg, int bg);
    u32  (*fb_rgb)(u8 r, u8 g, u8 b);
    u32  (*fb_width)(void);
    u32  (*fb_height)(void);
    void (*fb_fill_screen)(u32 c);
    int  (*win_content_w)(struct window *w);
    int  (*win_content_h)(struct window *w);
    void (*win_invalidate)(struct window *w);

    /* ---- Память ---- */
    void *(*malloc)(u32 n);
    void  (*free)(void *p);

    /* ---- Система ---- */
    u32  (*uptime_sec)(void);
    u32  (*timer_ticks)(void);
    void (*task_yield)(void);
    int  (*task_spawn)(const char *name, void (*fn)(void *), void *arg);

    /* ---- Строки ---- */
    int  (*snprintf)(char *out, u32 n, const char *fmt, ...);
    u32  (*strlen)(const char *s);
    int  (*strcmp)(const char *a, const char *b);
    char *(*strcpy)(char *dst, const char *src);
    int  (*memcmp)(const void *a, const void *b, u32 n);
    void *(*memset)(void *dst, int c, u32 n);
    void *(*memcpy)(void *dst, const void *src, u32 n);

    /* ---- c4 runtime (для запуска c4-программ, сгенерированных в x86) ---- */
    void (*c4_print_str)(const char *s, u32 len);  /* вывод строки в c4_out */
    int  (*c4_event_poll)(void *out_buf);            /* 0=нет, 1=клавиша, 2=мышь */
    int  (*c4_printf_va)(const char *fmt, int nargs, int *args_reversed);  /* formatted print, возвращает число символов */

    /* ---- Сон (для kdelay в native c4-программах) ----
     * ДОБАВЛЯТЬ ТОЛЬКО В КОНЕЦ: смещения полей зашиты в генерируемый
     * код (c4_x86 KAPI_*), STATIC_ASSERT-ы в c4_x86.c проверяют. */
    void (*msleep)(u32 ms);                          /* уступить CPU на ms мс */
} kapi_t;

/* Заполнить таблицу API указателями на функции ядра. */
void kapi_fill(kapi_t *k);

#endif /* KAPI_H */
