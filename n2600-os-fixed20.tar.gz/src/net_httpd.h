/* net_httpd.h — встроенный HTTP-сервер N2600-OS (loopback-тест).
 *
 * Слушает порт 80. Работает БЕЗ сети: соединение с 127.0.0.1 (или со
 * своим IP) замыкается внутри TCP-стека (см. net.c loopback-пара).
 * Проверка из терминала:   curl http://127.0.0.1/
 *                          curl http://localhost/hello
 * Из браузера:             http://localhost/
 * Снаружи (QEMU slirp):    -netdev user,hostfwd=tcp::8080-:80 →
 *                          на хосте: curl http://127.0.0.1:8080/
 */
#ifndef NET_HTTPD_H
#define NET_HTTPD_H

/* Запустить сервер (listen :80). Повторный вызов — no-op. */
void net_httpd_start(void);

#endif /* NET_HTTPD_H */
