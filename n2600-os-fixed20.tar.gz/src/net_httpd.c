/* net_httpd.c — встроенный HTTP-сервер N2600-OS (сессия 7).
 *
 * Цель: «локалхост для теста» — проверка HTTP-клиентов (curl, браузер,
 * HTTP Trace) и самой сетевой подсистемы ВООБЩЕ без внешней сети и
 * сервера: соединение с 127.0.0.1 замыкается внутри стека (loopback-пара
 * в net.c, пер-сокетный recv_cb у слушателя).
 *
 * Также доступен снаружи через QEMU hostfwd: -netdev user,hostfwd=tcp::8080-:80
 *
 * Страницы:
 *   /  (и /index.html) — статус системы: NIC, IP/mask/gw/DNS, DHCP,
 *                        счётчики TX/RX, ARP-кэш, uptime
 *   /hello             — text/plain «Hello from N2600-OS local httpd!»
 *   прочее             — 404
 *
 * Модель: полностью событийная (callback-и из net_poll) — отдельной
 * задачи не нужно. Ответ всегда укладывается в один сегмент (<MSS),
 * после ответа соединение закрывается (HTTP/1.0, Connection: close).
 */
#include "net_httpd.h"
#include "net.h"
#include "string.h"
#include "timer.h"

extern void serial_puts(const char *s);

#define HTTPD_CONNS    3
#define HTTPD_REQ_MAX  1024

typedef struct {
    int  sock;                    /* индекс TCP-сокета или -1 (свободно) */
    char req[HTTPD_REQ_MAX];
    u32  req_len;
} httpd_conn_t;

static httpd_conn_t g_conns[HTTPD_CONNS];
static int g_httpd_started = 0;

/* ---------- генерация ответа ---------- */

/* Статусная страница: короткая сводка о системе (UTF-8, htmlconv
 * браузера понимает h1/p/ul/li). Держим < 1200 байт — один сегмент. */
static u32 httpd_build_status(char *out, u32 out_max)
{
    char page[1024];
    int p = 0;

    char ipbuf[16];
    u32 ip = net_get_ip(), gw = net_get_gateway(), dns = net_dns_server();
    u32 mask = net_get_netmask();

    p += snprintf(page + p, sizeof(page) - p,
                  "<html><head><title>N2600-OS httpd</title></head><body>");
    p += snprintf(page + p, sizeof(page) - p, "<h1>N2600-OS local httpd</h1>");
    p += snprintf(page + p, sizeof(page) - p,
                  "<p>Loopback works. Try also /hello</p><ul>");
    p += snprintf(page + p, sizeof(page) - p, "<li>NIC: %s</li>",
                  net_nic_present() ? net_nic_name() : "none (loopback only)");
    net_ntoa(ip, ipbuf, sizeof(ipbuf));
    p += snprintf(page + p, sizeof(page) - p, "<li>IP: %s", ipbuf);
    net_ntoa(mask, ipbuf, sizeof(ipbuf));
    p += snprintf(page + p, sizeof(page) - p, " mask %s", ipbuf);
    net_ntoa(gw, ipbuf, sizeof(ipbuf));
    p += snprintf(page + p, sizeof(page) - p, " gw %s</li>", ipbuf);
    if (dns) {
        net_ntoa(dns, ipbuf, sizeof(ipbuf));
        p += snprintf(page + p, sizeof(page) - p, "<li>DNS: %s</li>", ipbuf);
    }
    p += snprintf(page + p, sizeof(page) - p, "<li>DHCP: %s</li>",
                  net_dhcp_state() == DHCP_BOUND ? "bound" : "not bound");
    p += snprintf(page + p, sizeof(page) - p,
                  "<li>Packets: tx=%u rx=%u</li>",
                  (unsigned)net_tx_packets(), (unsigned)net_rx_packets());
    {
        net_arp_entry_t dump[NET_ARP_CACHE_SIZE];
        int n = net_arp_dump(dump, NET_ARP_CACHE_SIZE);
        p += snprintf(page + p, sizeof(page) - p, "<li>ARP cache: %d</li>", n);
    }
    p += snprintf(page + p, sizeof(page) - p, "<li>Uptime: %u s</li>",
                  (unsigned)(timer_ticks() / 1000u));   /* 1 тик = 1 мс */
    p += snprintf(page + p, sizeof(page) - p, "</ul></body></html>");
    if (p < 0) p = 0;

    return (u32)snprintf(out, out_max,
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%s", p, page);
}

static u32 httpd_build_hello(char *out, u32 out_max)
{
    static const char body[] = "Hello from N2600-OS local httpd!\n";
    return (u32)snprintf(out, out_max,
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%s", (int)sizeof(body) - 1, body);
}

static u32 httpd_build_404(char *out, u32 out_max)
{
    static const char body[] = "404 Not Found (N2600-OS httpd)\n";
    return (u32)snprintf(out, out_max,
        "HTTP/1.0 404 Not Found\r\n"
        "Content-Type: text/plain\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%s", (int)sizeof(body) - 1, body);
}

/* ---------- обработка запроса ---------- */

static void httpd_respond(httpd_conn_t *c)
{
    static char resp[1400];      /* один сегмент (MSS 1460) */
    /* первая строка: "GET <путь> HTTP/x" */
    const char *p = c->req;
    while (*p == ' ' || *p == '\t') p++;
    int is_get = (p[0] == 'G' && p[1] == 'E' && p[2] == 'T');
    const char *path = p;
    while (*path && *path != ' ') path++;       /* после метода */
    while (*path == ' ') path++;
    u32 path_len = 0;
    while (path[path_len] && path[path_len] != ' ' && path[path_len] != '\r')
        path_len++;

    u32 rlen;
    if (!is_get) {
        rlen = (u32)snprintf(resp, sizeof(resp),
            "HTTP/1.0 501 Not Implemented\r\nContent-Length: 0\r\n"
            "Connection: close\r\n\r\n");
    } else if ((path_len == 1 && path[0] == '/') ||
               (path_len >= 2 && path[0] == '/' && path[1] == 'i')) {
        /* "/", "/index.html" */
        rlen = httpd_build_status(resp, sizeof(resp));
    } else if (path_len >= 2 && path[0] == '/' && path[1] == 'h') {
        /* "/hello", "/hello.txt" */
        rlen = httpd_build_hello(resp, sizeof(resp));
    } else {
        rlen = httpd_build_404(resp, sizeof(resp));
    }

    int sent = net_tcp_send(c->sock, resp, rlen);
    {
        char dbg[64];
        snprintf(dbg, sizeof(dbg), "[httpd] send sock=%d len=%u rc=%d\n",
                 c->sock, (unsigned)rlen, sent);
        serial_puts(dbg);
    }
    /* HTTP/1.0: закрыть сразу после ответа (loopback-клиент мгновенно
     * увидит CLOSED, реальный клиент получит FIN после данных) */
    net_tcp_close(c->sock);
    c->sock = -1;
}

/* per-socket приём: данные запроса */
static void httpd_recv(int sock, u32 src_ip, u16 src_port,
                       const void *data, u32 len)
{
    (void)src_ip; (void)src_port;
    httpd_conn_t *c = NULL;
    for (int i = 0; i < HTTPD_CONNS; i++) {
        if (g_conns[i].sock == sock) { c = &g_conns[i]; break; }
    }
    if (!c) return;   /* соединение уже закрыто нами — игнорируем */

    /* копим запрос */
    u32 room = HTTPD_REQ_MAX - 1 - c->req_len;
    u32 copy = len < room ? len : room;
    {
        char dbg[64];
        snprintf(dbg, sizeof(dbg), "[httpd] recv sock=%d len=%u (total %u)\n",
                 sock, (unsigned)len, (unsigned)(c->req_len + copy));
        serial_puts(dbg);
    }
    memcpy(c->req + c->req_len, data, copy);
    c->req_len += copy;
    c->req[c->req_len] = 0;

    /* конец заголовков или переполнение → ответ */
    if (strstr(c->req, "\r\n\r\n") || strstr(c->req, "\n\n") ||
        c->req_len >= HTTPD_REQ_MAX - 1) {
        httpd_respond(c);
    }
}

/* входящее соединение */
static void httpd_accept(int new_sock, u32 remote_ip, u16 remote_port)
{
    (void)remote_ip; (void)remote_port;
    for (int i = 0; i < HTTPD_CONNS; i++) {
        if (g_conns[i].sock < 0) {
            g_conns[i].sock = new_sock;
            g_conns[i].req_len = 0;
            g_conns[i].req[0] = 0;
            return;
        }
    }
    /* слотов нет — отказ */
    net_tcp_close(new_sock);
}

void net_httpd_start(void)
{
    if (g_httpd_started) return;
    for (int i = 0; i < HTTPD_CONNS; i++) g_conns[i].sock = -1;
    if (net_tcp_listen(80, httpd_accept, httpd_recv) < 0) {
        serial_puts("[httpd] cannot listen :80\n");
        return;
    }
    g_httpd_started = 1;
    serial_puts("[httpd] listening on :80 (127.0.0.1 / localhost)\n");
}
