/* idt.c — IDT, исключения CPU, контроллер прерываний 8259A.
 * Упрощенная версия без массивов указателей для исключения багов MinGW. */
#include "idt.h"
#include "io.h"
#include "types.h"
#include "fb.h"
#include "task.h"   /* task_current в диагностике исключений */

#define IDT_ENTRIES 256

typedef struct {
    u16 lo;
    u16 sel;
    u8  zero;
    u8  flags;
    u16 hi;
} __attribute__((packed)) idt_entry_t;

static idt_entry_t idt[IDT_ENTRIES];
static irq_handler_t irq_handlers[16];

/* Объявляем функции serial для трассировки */
extern void serial_puts(const char *s);
extern void serial_putdec(i32 v);

/* IRQ0 stub теперь определён в task.c (контекстное переключение). */
extern void irq_stub_0(void);

/* Самодостаточный вывод в COM1 для паники.
 * COM1 уже настроен в kernel.c, здесь только шлём байты. */
static void panic_putc(char c)
{
    while (!(inb(0x3FD) & 0x20)) { }   /* ждём THR empty */
    outb(0x3F8, (u8)c);
}

static void panic_puts(const char *s)
{
    for (; *s; s++) {
        if (*s == '\n') panic_putc('\r');
        panic_putc(*s);
    }
}

static void panic_dec(u32 v)
{
    char buf[12];
    int i = 0;
    if (v == 0) { panic_putc('0'); return; }
    while (v) { buf[i++] = (char)('0' + (v % 10)); v /= 10; }
    while (i--) panic_putc(buf[i]);
}

/* ------------------------------- обработка ------------------------------- */
void irq_dispatch(u32 n) {
    if (n < 16 && irq_handlers[n]) irq_handlers[n]();
    if (n >= 8) outb(0xA0, 0x20);
    outb(0x20, 0x20);
}

static const char *exc_name(u32 n) {
    static const char *names[] = {
        "деление на ноль", "отладка", "NMI", "точка останова",
        "переполнение", "границы BOUND", "неверный код", "сопроцессор недоступен",
        "двойная ошибка", "сегмент TSS", "нет сегмента", "ошибка стека",
        "защита", "страничная ошибка", "-", "x87 FPU",
        "проверка выравнивания", "машинная проверка", "SIMD FP", "виртуализация",
        "-", "-", "-", "-", "-", "-", "-", "-", "-", "безопасность", "-", "-"
    };
    return (n < 32) ? names[n] : "неизвестно";
}

void exc_panic(u32 n, u32 *frame)
{
    cli();

    /* --- Проверка: исключение в приложении? ---
     * Если активное приложение (loader_set_app_active), делаем longjmp
     * в loader вместо паники ядра. Приложение "падает", ядро продолжает. */
    extern void **loader_get_app_jmp(void);
    extern void  loader_set_app_active(int active, u32 exc_num);
    void **app_jmp = loader_get_app_jmp();
    if (app_jmp) {
        /* Исключение в приложении — перехватываем. Диагностика:
         * EIP/CS/сегменты на момент сбоя (кадр: [err?]EIP CS EFLAGS;
         * для векторов с error code EIP = frame[1], без — frame[0]). */
        u16 ss, ds, es, cs;
        __asm__ __volatile__("movw %%ss, %0\n\tmovw %%ds, %1\n\t"
                             "movw %%es, %2\n\tmovw %%cs, %3"
                             : "=r"(ss), "=r"(ds), "=r"(es), "=r"(cs));
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        char buf[128];
        u32 eip = frame ? frame[1] : 0;   /* #GP и др. с error code */
        u32 eip0 = frame ? frame[0] : 0;  /* err code / EIP без err */
        /* Сегменты ПРЕРВАННОЙ задачи: стаб сохранил [es][ds] под кадром
         * (frame[-10], frame[-9]; SS стаб не сохраняет — он его переключает). */
        u32 f_es = frame ? frame[-10] : 0;
        u32 f_ds = frame ? frame[-9] : 0;
        const u8 *code8 = (const u8 *)(unsigned long)eip;
        snprintf(buf, sizeof(buf),
                 "[exc] #%u eip=%x|%x | fault-ctx: ds=%x es=%x ss=%x cs=%x code=%02x%02x task=%d\n",
                 (unsigned)n, (unsigned)eip, (unsigned)eip0,
                 f_ds, f_es, ss, cs, code8[0], code8[1], task_current());
        {
            extern void loader_set_app_eip(u32 eip);
            loader_set_app_eip(eip ? eip : eip0);
        }
        panic_puts(buf);
        panic_puts("[exc] exception #");
        panic_dec(n);
        panic_puts(" in app — caught, killing task\n");
        loader_set_app_active(0, n);
        /* longjmp обратно в loader_task_fn */
        __builtin_longjmp(app_jmp, 1);
        /* не возвращаемся */
    }

    /* --- НОВОЕ: сообщаем номер исключения в serial --- */
    panic_puts("\n=== CPU EXCEPTION ===\n");
    panic_puts("vector #");
    panic_dec(n);
    panic_puts(" : ");
    panic_puts(exc_name(n));
    panic_puts("\n");
    /* ----------------------------------------------- */
    if (fb_ready()) {
        fb_mark_disable();
        fb_fill_screen(fb_rgb(0x60, 0x10, 0x10));
        fb_text_screen_centered(0, (int)fb_height() / 2 - 32, "ПАНИКА ЯДРА: ИСКЛЮЧЕНИЕ", fb_rgb(255, 255, 255));
        char buf[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(buf, sizeof(buf), "#%u %s", (unsigned)n, exc_name(n));
        fb_text_screen_centered(0, (int)fb_height() / 2, buf, fb_rgb(255, 220, 120));
        fb_text_screen_centered(0, (int)fb_height() / 2 + 32, "Система остановлена.", fb_rgb(255, 255, 255));
        fb_mark_enable(); fb_touch_all(); fb_flush();
    } else {
        volatile u16 *vt = (volatile u16 *)0xB8000;
        const char *m = "KERNEL PANIC";
        for (int i = 0; m[i]; i++) vt[i] = 0x4F00 | (u8)m[i];
    }
    for (;;) hlt();
}

/* --------------------------- генерация заглушек --------------------------- */
/* ВАЖНО: Двойные подчеркивания __ обязательны!
 *
 * ЗАЩИТА ПАМЯТИ (песочница): если прерывание/исключение пришло задаче
 * с SS=сегмент региона (база != 0), её ESP — СМЕЩЕНИЕ. Обработчики C
 * пишут с сегментами ядра (base 0, абсолютные адреса) — комбинация
 * «SS=база региона + DS=ядро» ломает любой указатель на локальные
 * переменные (читаются как смещение через DS ядра → мусор из низкой
 * памяти). Поэтому стаб ПЕРЕСЧИТЫВАЕТ ESP в абсолютный (прибавляет
 * task_region_base[cur_task]) и ставит SS=ядро ДО вызова C-кода, а
 * после — возвращает сегменты и смещение прерванной задаче.
 * Для задач ядра base=0 — все пересчёты вырождаются в no-op. */
#define IRQ_STUB(n) \
    __attribute__((naked, used)) void irq_stub_##n(void) \
    { \
        __asm__ __volatile__( \
            "pusha\n\t" \
            "pushl %ds\n\t" \
            "pushl %es\n\t" \
            "movl $0x10, %ecx\n\t" \
            "movw %cx, %ds\n\t" \
            "movw %cx, %es\n\t" \
            "movl cur_task, %eax\n\t" \
            "movl task_region_base(,%eax,4), %eax\n\t" \
            "addl %eax, %esp\n\t" \
            "movw %cx, %ss\n\t" \
            "cld\n\t" \
            "pushl $" #n "\n\t" \
            "call _irq_dispatch\n\t" \
            "addl $4, %esp\n\t" \
            "movl cur_task, %eax\n\t" \
            "movl task_region_base(,%eax,4), %ecx\n\t" \
            "movl 4(%esp), %eax\n\t" \
            "movw %ax, %ss\n\t" \
            "subl %ecx, %esp\n\t" \
            "popl %es\n\t" \
            "popl %ds\n\t" \
            "popa\n\t" \
            "iret\n\t" \
        ); \
    }

/* EXC_STUB: после exc_panic управление не возвращается (longjmp в
 * loader либо hlt-паника), поэтому восстановление сегментов не нужно —
 * но пересчёт ESP обязателен: diagnostics (snprintf с локальным буфером)
 * и fb-вывод идут с указателями на СВОЙ стек. */
#define EXC_STUB(n) \
    __attribute__((naked, used)) void exc_stub_##n(void) \
    { \
        __asm__ __volatile__( \
            "pusha\n\t" \
            "pushl %ds\n\t" \
            "pushl %es\n\t" \
            "movl $0x10, %ecx\n\t" \
            "movw %cx, %ds\n\t" \
            "movw %cx, %es\n\t" \
            "movl cur_task, %eax\n\t" \
            "movl task_region_base(,%eax,4), %eax\n\t" \
            "addl %eax, %esp\n\t" \
            "movw %cx, %ss\n\t" \
            "cld\n\t" \
            "leal 40(%esp), %eax\n\t"  /* кадр: [err]EIP CS EFLAGS */ \
            "pushl %eax\n\t"             /* arg2: frame */ \
            "pushl $" #n "\n\t"          /* arg1: n */ \
            "call _exc_panic\n\t" \
            "addl $8, %esp\n\t" \
            "popl %es\n\t" \
            "popl %ds\n\t" \
        "1:\n\t" \
            "hlt\n\t" \
            "jmp 1b\n\t" \
        ); \
    }

IRQ_STUB(1)  IRQ_STUB(2)  IRQ_STUB(3)  IRQ_STUB(4)
IRQ_STUB(5)  IRQ_STUB(6)  IRQ_STUB(7)  IRQ_STUB(8)
IRQ_STUB(9)  IRQ_STUB(10) IRQ_STUB(11) IRQ_STUB(12)
IRQ_STUB(13) IRQ_STUB(14) IRQ_STUB(15)

EXC_STUB(0)  EXC_STUB(1)  EXC_STUB(2)  EXC_STUB(3)
EXC_STUB(4)  EXC_STUB(5)  EXC_STUB(6)  EXC_STUB(7)
EXC_STUB(8)  EXC_STUB(9)  EXC_STUB(10) EXC_STUB(11)
EXC_STUB(12) EXC_STUB(13) EXC_STUB(14) EXC_STUB(15)
EXC_STUB(16) EXC_STUB(17) EXC_STUB(18) EXC_STUB(19)
EXC_STUB(20) EXC_STUB(21) EXC_STUB(22) EXC_STUB(23)
EXC_STUB(24) EXC_STUB(25) EXC_STUB(26) EXC_STUB(27)
EXC_STUB(28) EXC_STUB(29) EXC_STUB(30) EXC_STUB(31)

/* ИСПРАВЛЕНО: Явно указан указатель на функцию void (*fn)(void) */
static void set_gate(int n, void (*fn)(void)) {
    u32 addr = (u32)(unsigned long)fn;
    idt[n].lo    = (u16)(addr & 0xFFFF);
    idt[n].sel   = 0x08;
    idt[n].zero  = 0;
    idt[n].flags = 0x8E; /* present, ring0, 32-bit interrupt gate */
    idt[n].hi    = (u16)(addr >> 16);
}

void irq_install(int n, irq_handler_t fn) {
    if (n >= 0 && n < 16) irq_handlers[n] = fn;
}

void pic_mask_update(u16 irq_mask) {
    outb(0x21, (u8)(irq_mask & 0xFF));
    outb(0xA1, (u8)(irq_mask >> 8));
}

void pic_unmask(u16 irq_mask) {
    pic_mask_update((u16)~irq_mask);
}

void idt_init(void) {
    serial_puts("[idt] clearing IDT...\n");
    for (int i = 0; i < IDT_ENTRIES; i++) {
        idt[i].lo = idt[i].sel = idt[i].hi = 0;
        idt[i].zero = 0; idt[i].flags = 0;
    }

    serial_puts("[idt] setting IRQ gates (direct calls)...\n");
    /* УБИРАЕМ МАССИВ УКАЗАТЕЛЕЙ — вызываем напрямую для исключения багов MinGW */
    set_gate(32, irq_stub_0);  set_gate(33, irq_stub_1);
    set_gate(34, irq_stub_2);  set_gate(35, irq_stub_3);
    set_gate(36, irq_stub_4);  set_gate(37, irq_stub_5);
    set_gate(38, irq_stub_6);  set_gate(39, irq_stub_7);
    set_gate(40, irq_stub_8);  set_gate(41, irq_stub_9);
    set_gate(42, irq_stub_10); set_gate(43, irq_stub_11);
    set_gate(44, irq_stub_12); set_gate(45, irq_stub_13);
    set_gate(46, irq_stub_14); set_gate(47, irq_stub_15);

    serial_puts("[idt] setting exception gates...\n");
    set_gate(0, exc_stub_0);   set_gate(1, exc_stub_1);
    set_gate(2, exc_stub_2);   set_gate(3, exc_stub_3);
    set_gate(4, exc_stub_4);   set_gate(5, exc_stub_5);
    set_gate(6, exc_stub_6);   set_gate(7, exc_stub_7);
    set_gate(8, exc_stub_8);   set_gate(9, exc_stub_9);
    set_gate(10, exc_stub_10); set_gate(11, exc_stub_11);
    set_gate(12, exc_stub_12); set_gate(13, exc_stub_13);
    set_gate(14, exc_stub_14); set_gate(15, exc_stub_15);
    set_gate(16, exc_stub_16); set_gate(17, exc_stub_17);
    set_gate(18, exc_stub_18); set_gate(19, exc_stub_19);
    set_gate(20, exc_stub_20); set_gate(21, exc_stub_21);
    set_gate(22, exc_stub_22); set_gate(23, exc_stub_23);
    set_gate(24, exc_stub_24); set_gate(25, exc_stub_25);
    set_gate(26, exc_stub_26); set_gate(27, exc_stub_27);
    set_gate(28, exc_stub_28); set_gate(29, exc_stub_29);
    set_gate(30, exc_stub_30); set_gate(31, exc_stub_31);

    serial_puts("[idt] loading IDT...\n");
    struct dt_ptr p;
    p.limit = (u16)(sizeof(idt) - 1);
    p.base  = (u32)(unsigned long)idt;
    lidt_load(&p);

    serial_puts("[idt] remapping PIC...\n");
    outb(0x20, 0x11); io_wait();
    outb(0xA0, 0x11); io_wait();
    outb(0x21, 0x20); io_wait();
    outb(0xA1, 0x28); io_wait();
    outb(0x21, 0x04); io_wait();
    outb(0xA1, 0x02); io_wait();
    outb(0x21, 0x01); io_wait();
    outb(0xA1, 0x01); io_wait();
    
    serial_puts("[idt] masking all IRQs...\n");
    pic_mask_update(0xFFFF);
    outb(0x20, 0x20);
    outb(0xA0, 0x20);
    
    serial_puts("[idt] init complete!\n");
}