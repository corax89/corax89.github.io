/* string.c — реализация минимальной библиотеки строк */
#include "string.h"

void *memset(void *dst, int c, u32 n)
{
    u8 *d = (u8 *)dst;
    while (n--) *d++ = (u8)c;
    return dst;
}

void *memcpy(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    while (n--) *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, u32 n)
{
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    if (d < s) {
        while (n--) *d++ = *s++;
    } else if (d > s) {
        d += n; s += n;
        while (n--) *--d = *--s;
    }
    return dst;
}

int memcmp(const void *a, const void *b, u32 n)
{
    const u8 *pa = (const u8 *)a, *pb = (const u8 *)b;
    while (n--) {
        if (*pa != *pb) return (int)*pa - (int)*pb;
        pa++; pb++;
    }
    return 0;
}

/* memchr: первый байт c в первых n байтах s (NULL = не найден).
 * Нужен klog (поиск '\n' в кольцевом буфере журнала загрузки). */
void *memchr(const void *s, int c, u32 n)
{
    const u8 *p = (const u8 *)s;
    while (n--) {
        if (*p == (u8)c) return (void *)p;
        p++;
    }
    return NULL;
}

u32 strlen(const char *s)
{
    u32 n = 0;
    while (*s++) n++;
    return n;
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (int)(u8)*a - (int)(u8)*b;
}

int strncmp(const char *a, const char *b, u32 n)
{
    while (n && *a && *a == *b) { a++; b++; n--; }
    return n ? (int)(u8)*a - (int)(u8)*b : 0;
}

char *strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++) != 0) {}
    return dst;
}

char *strncpy(char *dst, const char *src, u32 n)
{
    char *d = dst;
    while (n && *src) { *d++ = *src++; n--; }
    while (n--) *d++ = 0;
    return dst;
}

char *strchr(const char *s, int c) {
   while (*s) {
           if (*s == (char)c) return (char *)s;
           s++;
   }
   return (c == '\0') ? (char *)s : NULL;
}

/* Сессия 13: последнее вхождение символа (ramfs mkdir: родитель пути). */
char *strrchr(const char *s, int c)
{
    const char *last = NULL;
    if (!s) return NULL;
    while (*s) {
        if (*s == (char)c) last = s;
        s++;
    }
    /* NUL-терминатор тоже считается для c==0 (семантика strrchr) */
    if (c == 0) return (char *)s;
    return (char *)last;
}

/* strstr: первое вхождение needle в hay (NULL = не найден).
 * Нужно HTTP Trace (поиск конца заголовков "\r\n\r\n" в ответе).
 * Пустая needle возвращает hay (как в стандартном libc). */
char *strstr(const char *hay, const char *needle)
{
    if (!needle || !needle[0]) return (char *)hay;
    u32 nl = strlen(needle);
    for (const char *p = hay; *p; p++) {
        if (*p == needle[0] && strncmp(p, needle, nl) == 0)
            return (char *)p;
    }
    return NULL;
}

/* ---- мини-vsnprintf: %s %c %d %u %x %X %p %%, флаги '-' и '0',
 * ширина до 2 цифр, точность %.N для %s, модификаторы l/ll игнорируются.
 *
 * FIX [P1] (мусор в диспетчере задач): раньше флаг '-' НЕ поддерживался —
 * формат "%-12s" выводился как литеральный текст "%-12s", БЕЗ потребления
 * аргумента. Все последующие спецификаторы сдвигались на один аргумент:
 * "%8u" печатал указатель имени как число, а "%s" в графе «Статус»
 * разыменовывал ЗНАЧЕНИЕ UPTIME как указатель → случайные символы,
 * меняющиеся каждые полсекунды. Теперь: левое выравнивание + ширина для
 * %s (и всех типов), 'll' пропускается целиком (низ 32 бит — на x86-32
 * vararg 64-бит лежит двумя слотами, младший первым), %.N обрезает строку. */

static int put_char(char *out, u32 n, u32 *pos, char c)
{
    if (*pos + 1 < n) out[*pos] = c;
    (*pos)++;
    return 1;
}

static int put_str(char *out, u32 n, u32 *pos, const char *s, int max_chars)
{
    int cnt = 0;
    while (*s && (max_chars < 0 || cnt < max_chars)) {
        put_char(out, n, pos, *s++);
        cnt++;
    }
    return cnt;
}

static int put_pad(char *out, u32 n, u32 *pos, char pad, int count)
{
    int cnt = 0;
    while (count-- > 0) { put_char(out, n, pos, pad); cnt++; }
    return cnt;
}

static int put_num(char *out, u32 n, u32 *pos, u32 val, int base, int upper,
                   int neg, char pad, int width)
{
    char buf[12];
    const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int i = 0, cnt = 0;
    if (val == 0) buf[i++] = '0';
    while (val) { buf[i++] = digits[val % (u32)base]; val /= (u32)base; }
    if (neg) { put_char(out, n, pos, '-'); cnt++; width--; }
    while (width > i) { put_char(out, n, pos, pad); cnt++; width--; }
    while (i--) { put_char(out, n, pos, buf[i]); cnt++; }
    return cnt;
}

int vsnprintf(char *out, u32 n, const char *fmt, __builtin_va_list ap)
{
    u32 pos = 0;
    if (n) out[0] = 0;

    while (*fmt) {
        if (*fmt != '%') { put_char(out, n, &pos, *fmt++); continue; }
        fmt++;
        if (*fmt == 0) break;

        /* флаги */
        int left_align = 0;
        char pad = ' ';
        for (;;) {
            if (*fmt == '-') { left_align = 1; fmt++; }
            else if (*fmt == '0') { pad = '0'; fmt++; }
            else break;
        }
        /* ширина */
        int width = 0;
        while (*fmt >= '0' && *fmt <= '9' && width < 99) {
            width = width * 10 + (*fmt - '0');
            fmt++;
        }
        /* точность (только для %s: обрезка строки); '*' не поддерживаем */
        int prec = -1;
        if (*fmt == '.') {
            fmt++;
            prec = 0;
            while (*fmt >= '0' && *fmt <= '9' && prec < 999) {
                prec = prec * 10 + (*fmt - '0');
                fmt++;
            }
        }
        /* модификаторы длины: l, ll — пропускаем (32-битные значения,
         * у 64-битного vararg на x86-32 младший слот идёт первым) */
        while (*fmt == 'l') fmt++;

        switch (*fmt) {
        case 's': {
            const char *s = __builtin_va_arg(ap, const char *);
            if (!s) s = "(null)";
            /* длина с учётом точности */
            int slen = 0;
            while (s[slen] && (prec < 0 || slen < prec)) slen++;
            if (left_align) {
                put_str(out, n, &pos, s, prec);
                put_pad(out, n, &pos, ' ', width - slen);
            } else {
                put_pad(out, n, &pos, ' ', width - slen);
                put_str(out, n, &pos, s, prec);
            }
            break;
        }
        case 'c': {
            char c = (char)__builtin_va_arg(ap, int);
            if (left_align) {
                put_char(out, n, &pos, c);
                put_pad(out, n, &pos, ' ', width - 1);
            } else {
                put_pad(out, n, &pos, ' ', width - 1);
                put_char(out, n, &pos, c);
            }
            break;
        }
        case 'd': {
            i32 v = __builtin_va_arg(ap, i32);
            u32 uv = (v < 0) ? (u32)(-v) : (u32)v;
            if (left_align) {
                int w = put_num(out, n, &pos, uv, 10, 0, v < 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w - (v < 0 ? 1 : 0));
            } else {
                put_num(out, n, &pos, uv, 10, 0, v < 0, pad, width);
            }
            break;
        }
        case 'u': {
            u32 v = __builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 10, 0, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 10, 0, 0, pad, width);
            }
            break;
        }
        case 'x': {
            u32 v = __builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 16, 0, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 16, 0, 0, pad, width);
            }
            break;
        }
        case 'X': {
            u32 v = __builtin_va_arg(ap, u32);
            if (left_align) {
                int w = put_num(out, n, &pos, v, 16, 1, 0, ' ', 0);
                put_pad(out, n, &pos, ' ', width - w);
            } else {
                put_num(out, n, &pos, v, 16, 1, 0, pad, width);
            }
            break;
        }
        case 'p': {
            put_str(out, n, &pos, "0x", -1);
            put_num(out, n, &pos, (u32)(unsigned long)__builtin_va_arg(ap, void *),
                    16, 0, 0, '0', 8);
            break;
        }
        case '%':
            put_char(out, n, &pos, '%');
            break;
        default:
            put_char(out, n, &pos, '%');
            put_char(out, n, &pos, *fmt);
            break;
        }
        fmt++;
    }
    if (n) out[(pos < n) ? pos : n - 1] = 0;
    return (int)pos;
}

int snprintf(char *out, u32 n, const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    int r = vsnprintf(out, n, fmt, ap);
    __builtin_va_end(ap);
    return r;
}

unsigned utf8_next(const char **ps)
{
    const unsigned char *s = (const unsigned char *)*ps;
    unsigned c;
    if (s[0] < 0x80) {
        c = s[0];
        *ps += 1;
    } else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) {
        c = ((unsigned)(s[0] & 0x1F) << 6) | (s[1] & 0x3F);
        *ps += 2;
    } else {
        c = '?';
        do { *ps += 1; } while (((**ps) & 0xC0) == 0x80);
    }
    return c;
}
