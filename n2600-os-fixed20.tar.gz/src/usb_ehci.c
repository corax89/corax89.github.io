/* usb_ehci.c — EHCI (USB 2.0) драйвер + USB Mass Storage (SCSI/CBC).
 *
 * Реализовано:
 *   1. PCI-сканирование EHCI (class 0x0C, subclass 0x03, prog-if 0x20).
 *   2. Захват контроллера у BIOS (USBLEGSUP register, OS Owned bit).
 *   3. Сброс HC (USBCMD.HCRESET).
 *   4. Инициализация periodic и async списков (4K-aligned, 1024 entries).
 *   5. QH (Queue Head, 32-байта, 32-byte aligned) и qTD (32-байта, 32-byte aligned)
 *      с overlay-структурой.
 *   6. Control transfers (SETUP + DATA + STATUS) через async schedule.
 *   7. Bulk transfers (для mass storage).
 *   8. USB Mass Storage class driver (BBB protocol):
 *      CBW (31 байт) → DATA → CSW (13 байт).
 *      Поддержаны SCSI-команды: INQUIRY, READ CAPACITY, READ 10, TEST UNIT READY.
 *
 * Что НЕ реализовано:
 *   - Interrupt transfers (periodic schedule для HID). UHCI покрывает HID.
 *   - Split transactions (Transaction Translator) для low/full-speed
 *     устройств на hi-speed порт EHCI. EHCI здесь работает только с hi-speed.
 *   - Multiline support (TT — Transaction Translator через hub).
 *
 * Источники: EHCI spec 1.0, Linux ehci-hcd.c, USB Mass Storage Class spec.
 */
#include "usb_ehci.h"
#include "pci.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "timer.h"
#include "task.h"
#include "ata.h"  /* для ata.h совместимости, не используется */

extern void serial_puts(const char *s);
extern void serial_putc(char c);
extern void *memset(void *dst, int c, u32 n);

/* ---------- СЕССИЯ 32: ожидания без выжигания CPU ----------
 * Старые циклы крутились в busy-wait до ПОЛНОГО таймаута (bulk — 2 c!):
 * wifi_poll() вызывается из главного цикла kmain, и на тихом канале
 * (устройство NAK-ит bulk IN) kmain проводил в этих циклах ~100% времени
 * — мышь/клавиатура/WM опрашивались раз в секунды («все ресурсы уходят
 * на одну программу»). Теперь в каждой итерации ожидания при включённых
 * прерываниях исполняется hlt: vCPU паркуется до следующего IRQ (PIT
 * 100 Гц), завершение qTD замечаем с задержкой до одного тика — для USB
 * RX это не страшно (кадры буферизуются устройством). При выключенных
 * прерываниях (ранний boot, usb_init) поведение прежнее — busy-цикл. */
static inline int ehci_irq_enabled(void)
{
    u32 f;
    __asm__ __volatile__("pushfl\n\tpopl %0" : "=r"(f) :: "memory");
    return (int)((f >> 9) & 1u);
}

static void ehci_wait_pause(void)
{
    if (ehci_irq_enabled())
        __asm__ __volatile__("hlt");
}

/* Гибридная пауза: пока с момента dl не прошло grace_us — плотный опрос
 * (быстрые завершения — регистры RTL, фаза ASS — ловятся без такта
 * планировщика: иначе каждая контрольная операцияbring-up'а прошивки
 * дорожала бы на 10 мс); после grace_us — hlt до следующего IRQ. */
static void ehci_wait_grace(u32 dl, u32 grace_us)
{
    if (!timer_poll_expired(dl, grace_us)) return;
    ehci_wait_pause();
}

/* ---------- EHCI регистры (capability + operational) ---------- */

#define EHCI_CAP_CAPLENGTH   0x00     /* 8-bit R */
#define EHCI_CAP_HCIVERSION  0x02     /* 16-bit R */
#define EHCI_CAP_HCSPARAMS   0x04     /* 32-bit R */
#define EHCI_CAP_HCCPARAMS   0x08     /* 32-bit R */

/* HCCPARAMS bits */
#define EHCI_HCC_EXT_CAP_OFF  0xFF     /* bits 7..0: extended capabilities offset (pointer in PCI config) */
#define EHCI_HCC_64BIT        (1 << 0)

/* Operational registers (offset from base + CAPLENGTH) */
#define EHCI_OP_USBCMD        0x00
#define EHCI_OP_USBSTS        0x04
#define EHCI_OP_USBINTR       0x08
#define EHCI_OP_FRINDEX       0x0C
#define EHCI_OP_CTRLDSSEGMENT 0x10
#define EHCI_OP_PERIODICLISTBASE 0x14
#define EHCI_OP_ASYNCLISTADDR 0x18
/* СЕССИЯ 31, КРИТИЧНО: по EHCI spec (Table 2-7) 0x1C..0x3F — reserved,
 * CONFIGFLAG — 0x40, PORTSC[0] — 0x44 (+4 на порт). Раньше CONFIGFLAG
 * писали в 0x1C (зарезервировано — игнорировалось), а PORTSC читали с
 * 0x40: “порт 0” был регистром CONFIGFLAG, реальный порт 0 выглядели как
 * “порт 1” — вся логика портов/сбросов/перечисления работала не на тех
 * регистрах. Именно поэтому в логе пользователя CSC виднелся на “порте 1”
 * с ps=0x1003 (CCS|CSC|PP — настоящий порт 0). */
#define EHCI_OP_CONFIGFLAG    0x40
#define EHCI_OP_PORTSC        0x44     /* + 4*port — каждый порт 4 байта */

/* USBCMD bits — layout из EHCI spec 2.2.
 *   bit 0:     RS (Run/Stop)
 *   bit 1:     HCRESET (Host Controller Reset)
 *   bits 4..3: FLS (Frame List Size)
 *   bit 4:     PSE (Periodic Schedule Enable)
 *   bit 5:     ASE (Async Schedule Enable)  ← было (1<<4), правильно (1<<5)
 *   bit 6:     DbC (Debug)
 *   bit 7:     ASP (Async Schedule Park Mode)
 *   bit 24:    IAAD (Interrupt on Async Advance Doorbell)
 *   bits 23..16: IAA Threshold */
#define EHCI_USBCMD_RS        (1u << 0)       /* Run/Stop */
#define EHCI_USBCMD_HCRESET   (1u << 1)       /* Host Controller Reset */
#define EHCI_USBCMD_PSE       (1u << 4)       /* Periodic Schedule Enable */
#define EHCI_USBCMD_ASE       (1u << 5)       /* Async Schedule Enable */
#define EHCI_USBCMD_IAAD      (1u << 6)       /* Interrupt on Async Advance Doorbell */

/* USBSTS bits */
#define EHCI_USBSTS_UI        (1 << 0)       /* USB Interrupt */
#define EHCI_USBSTS_PCI       (1 << 2)       /* Port Change Detect */
#define EHCI_USBSTS_FRI       (1 << 3)       /* Frame List Rollover */
#define EHCI_USBSTS_HSE       (1 << 4)       /* Host System Error */
#define EHCI_USBSTS_IAA       (1 << 5)       /* Interrupt on Async Advance */
#define EHCI_USBSTS_HCH       (1 << 12)      /* HC Halted */
#define EHCI_USBSTS_PSS       (1 << 14)      /* Periodic Schedule Status */
#define EHCI_USBSTS_ASS       (1 << 15)      /* Async Schedule Status */

/* PORTSC bits */
#define EHCI_PORTSC_CCS       (1 << 0)       /* Current Connect Status */
#define EHCI_PORTSC_CSC       (1 << 1)       /* Connect Status Change */
#define EHCI_PORTSC_PE        (1 << 2)       /* Port Enable */
#define EHCI_PORTSC_PEC       (1 << 3)       /* Port Enable/Disable Change */
#define EHCI_PORTSC_OCA       (1 << 4)       /* Over-current Active */
#define EHCI_PORTSC_OCC       (1 << 5)       /* Over-current Change */
#define EHCI_PORTSC_FPR       (1 << 6)       /* Force Port Resume */
#define EHCI_PORTSC_SUSPEND   (1 << 7)       /* Suspend */
#define EHCI_PORTSC_PR        (1 << 8)       /* Port Reset */
#define EHCI_PORTSC_PLS_MASK  0x0F00         /* Port Link State */
#define EHCI_PORTSC_PLS_SHFT  8
#define EHCI_PORTSC_PP        (1 << 12)      /* Port Power */
#define EHCI_PORTSC_LS_SHFT   10            /* Line Status */
#define EHCI_PORTSC_LS_MASK   (3 << 10)
#define EHCI_PORTSC_LS_SE0    (0 << 10)
#define EHCI_PORTSC_LS_J      (2 << 10)      /* hi-speed: D+ high */
#define EHCI_PORTSC_LS_K      (1 << 10)
#define EHCI_PORTSC_LS_SE1    (3 << 10)      /* both lines high */
#define EHCI_PORTSC_OWNER     (1 << 13)      /* Port Owner (1 = companion) */
#define EHCI_PORTSC_FPO       (1 << 13)      /* ... alternate */
#define EHCI_PORTSC_WKOC_E    (1 << 24)      /* Wake on Over-current */
#define EHCI_PORTSC_WKD_CONN  (1 << 25)     /* Wake on Disconnect */
#define EHCI_PORTSC_WKCONN_E  (1 << 26)      /* Wake on Connect */
#define EHCI_PORTSC_PTC_SHFT  16            /* Port Test Control */
#define EHCI_PORTSC_PTC_MASK  (0xF << 16)

/* ---------- qTD (queue element TD) ---------- */

/* EHCI qTD (32 bytes, 32-byte aligned). */
typedef struct __attribute__((packed, aligned(32))) ehci_qtd {
    u32 next_qtd;       /* link to next qTD (bit 0 = T terminate, bits 4..1 = type, bit 1 reserved) */
    u32 alt_next_qtd;   /* alternate next (for short packet) */
    u32 token;          /* status, PID, length, etc. */
    u32 buffer[5];      /* 5 buffer pointers, each pointing to a 4K page */
    /* software fields (not hardware, padding to 32 bytes) */
    u32 soft_active;
    u32 soft_result;
} ehci_qtd_t;

/* Token bits — layout из EHCI spec 3.5.3 + Linux ehci.h.
 * После отладки с QEMU ("cpage out of range (6)") правильный layout:
 *   bits 0..7:    status (bit 7 = Active, 6 = Halt, 5 = DBE, 4 = Babble, 3 = XactErr, 2 = MissedMicro, 1 = SplitXState, 0 = PING)
 *   bits 10..8:   PID code (3 bits, 0=OUT, 1=IN, 2=SETUP)
 *   bits 11..10:  CERR (2 bits, 11 = 3 retries)
 *   bits 14..12:  Current Page (3 bits, range 0..7) ← QEMU использует 3 бита!
 *   bit 15:       IOC (Interrupt On Complete)
 *   bits 30..16:  Total Bytes to Transfer (15 bits, value = bytes left)
 *   bit 31:       Data Toggle (DT) */
#define EHCI_TD_ACTIVE       (1u << 7)
#define EHCI_TD_HALT         (1u << 6)
#define EHCI_TD_DBE          (1u << 5)
#define EHCI_TD_BABBLE       (1u << 4)
#define EHCI_TD_XACT_ERR     (1u << 3)
#define EHCI_TD_PID_OUT     (0u << 8)
#define EHCI_TD_PID_IN       (1u << 8)
#define EHCI_TD_PID_SETUP    (2u << 8)
#define EHCI_TD_CERR_SHFT    10
#define EHCI_TD_CERR_DEF     (3u << 10)        /* CERR=3 retries, bits 11..10 */
#define EHCI_TD_IOC          (1u << 15)        /* Interrupt On Complete, bit 15 */
#define EHCI_TD_BYTES_SHFT   16
#define EHCI_TD_BYTES_MASK   0x7FFF           /* 15 bits */
#define EHCI_TD_DT           (1u << 31)        /* Data Toggle: 0=DATA0, 1=DATA1 */

#define EHCI_QTD_TERMINATE   0x00000001u
/* qTD next_qtd field format:
 *   bit 0: T (Terminate), bits 4..1: Reserved (must be 0),
 *   bits 31..5: 32-byte aligned qTD pointer.
 * Для QH horiz_link тип указывается в битах 4..2, но для qTD next_qtd
 * биты 4..1 должны быть 0. */
#define EHCI_QTD_NEXT(n)     ((u32)(unsigned long)(n) & ~0x1Fu)

/* ---------- QH (Queue Head) ---------- */

/* EHCI QH (48 bytes hardware + padding to 64 for cache line, 32-byte aligned). */
typedef struct __attribute__((packed, aligned(32))) ehci_qh {
    u32 horiz_link;        /* next QH/QH pointer (bit 0 = T terminate, bits 2..1 = type) */
    u32 characteristics;   /* EP, dev addr, max packet, etc. */
    u32 split_completion;  /* split transaction (for low/full via TT) */
    u32 cur_qtd;          /* current qTD pointer (filled by HC) */
    /* Overlay (qTD copy): HC writes here when it advances. */
    u32 next_qtd;          /* overlay: next qTD */
    u32 alt_next_qtd;       /* overlay: alt next */
    u32 token;             /* overlay: token */
    u32 buffer[5];          /* overlay: 5 buffer pointers */
} ehci_qh_t;

/* Horiz link types */
#define EHCI_QH_TYPE_ITD     0x00
#define EHCI_QH_TYPE_QH      0x02      /* bits 2..1 = 01 means QH */
#define EHCI_QH_TYPE_SITD    0x04
#define EHCI_QH_TYPE_FSTN    0x06
#define EHCI_QH_TERMINATE    0x00000001u

/* Characteristics bits — раскладка по EHCI spec (Table 3-16, DWord 1
 * “Endpoint Characteristics”) + сверено с Linux ehci.h (hw_info2):
 *   bits 6..0:    Device Address
 *   bits 11..8:   Endpoint Number
 *   bit 12:       I (Inactive on Next Transaction)
 *   bits 13..12:  Endpoint Speed (00=Full, 01=Low, 10=High) — СДВИГ 12!
 *                 (раньше 13: EPS=10b попадала в биты 14:13 → все QH
 *                 объявлялись FULL-SPEED со случайно взведённым DTC —
 *                 HC требовал split-транзакции и не работал на VM)
 *   bit 14:       DTC (Data Toggle Control: 1=toggle из qTD)
 *                 (раньше (1<<23) — а это старший бит MaxPacketLength:
 *                 MPL = 64|128 = 192 вместо 64!)
 *   bit 15:       H (Head of Reclamation List Flag)
 *   bits 26..16:  Maximum Packet Length (11 bits)
 *   bit 27:       C (Control Endpoint Flag)
 *   bits 31..28:  RL (Nak Count Reload) */
#define EHCI_QH_DEVADDR_SHFT  0
#define EHCI_QH_EP_SHFT       8
#define EHCI_QH_EPSPEED_SHFT  12      /* 0=full, 1=low, 2=hi — биты 13:12 */
#define EHCI_QH_MAXPKT_SHFT   16
#define EHCI_QH_DTC            (1 << 14)  /* Data Toggle Control (бит 14!) */
#define EHCI_QH_C_MASK         (1 << 27)  /* Control endpoint flag (бит 27) */
#define EHCI_QH_NAK_CNT_RL_SHFT 28

/* ---------- пулы статических QH и qTD ---------- */

#define EHCI_QH_POOL 16
#define EHCI_QTD_POOL 64

static ehci_qh_t  ehci_qh_pool  [EHCI_QH_POOL];
static ehci_qtd_t ehci_qtd_pool [EHCI_QTD_POOL];
static u8 ehci_qh_used [EHCI_QH_POOL];
static u8 ehci_qtd_used[EHCI_QTD_POOL];

static ehci_qh_t *ehci_qh_alloc(void)
{
    for (int i = 0; i < EHCI_QH_POOL; i++) {
        if (!ehci_qh_used[i]) {
            ehci_qh_used[i] = 1;
            memset(&ehci_qh_pool[i], 0, sizeof(ehci_qh_t));
            return &ehci_qh_pool[i];
        }
    }
    return NULL;
}

static void ehci_qh_free(ehci_qh_t *qh)
{
    if (!qh) return;
    for (int i = 0; i < EHCI_QH_POOL; i++) {
        if (&ehci_qh_pool[i] == qh) { ehci_qh_used[i] = 0; return; }
    }
}

static ehci_qtd_t *ehci_qtd_alloc(void)
{
    for (int i = 0; i < EHCI_QTD_POOL; i++) {
        if (!ehci_qtd_used[i]) {
            ehci_qtd_used[i] = 1;
            memset(&ehci_qtd_pool[i], 0, sizeof(ehci_qtd_t));
            return &ehci_qtd_pool[i];
        }
    }
    return NULL;
}

static void ehci_qtd_free(ehci_qtd_t *qtd)
{
    if (!qtd) return;
    for (int i = 0; i < EHCI_QTD_POOL; i++) {
        if (&ehci_qtd_pool[i] == qtd) { ehci_qtd_used[i] = 0; return; }
    }
}

/* ---------- контроллер ---------- */

typedef struct {
    int  valid;
    u8   cap_length;       /* offset to operational registers */
    u16  hciversion;
    u8   n_ports;          /* number of ports (from HCSPARAMS) */
    u32  mmio_base;        /* base of MMIO region (BAR0) */
    int  bus, dev, func;   /* PCI coordinates */
    u32 *periodic_list;    /* 4K-aligned, 1024 entries */
    ehci_qh_t *async_qh;   /* head of async list (self-link for empty) */
    /* Mass storage device info */
    int  storage_dev_addr;
    int  storage_ep_in;
    int  storage_ep_out;
    u32  storage_max_lba;
    u32  storage_block_size;
} ehci_ctrl_t;

static ehci_ctrl_t ehci_ctrl;
/* per-port «перечислен/обработан» — hot-plug без повторов и спама */
static u8 ehci_port_done[16];
/* СЕССИЯ 33: счётчик неудачных проходов перечисления на порт.
 * СЕССИЯ 34: порог снижен 30 -> 12 (проходы теперь редкие и вежливые:
 * 1 с тишины после CSC, сброс не чаще раза в 3 прохода), лог с ps. */
static u8 ehci_port_tries[16];
/* СЕССИЯ 34: стадии порта. SETTLE — после CSC молчим (VMware
 * passthrough + прошивка донгла инициализируются; сброс-шторм в этот
 * период мешал BOTH: не давал устройству загрузиться и грузил CPU);
 * POLL — штатные мягкие попытки перечисления. */
#define EHCI_STAGE_SETTLE 0
#define EHCI_STAGE_POLL   1
static u8  ehci_port_stage[16];
static u32 ehci_port_ok_at[16];   /* тик (мс), раньше которого порт не трогаем */
/* СЕССИЯ 40: addr устройства, перечисленного на порту — для адресного
 * сброса порта при восстановлении «клина» адаптера
 * (usb_ehci_reset_wifi_device). */
static int ehci_port_addr[16];

/* MMIO helpers */
static inline u8  mmio_r8 (u32 base, u32 off) { return *(volatile u8 *)(unsigned long)(base + off); }
static inline u16 mmio_r16(u32 base, u32 off) { return *(volatile u16 *)(unsigned long)(base + off); }
static inline u32 mmio_r32(u32 base, u32 off) { return *(volatile u32 *)(unsigned long)(base + off); }
static inline void mmio_w8 (u32 base, u32 off, u8 v)  { *(volatile u8 *)(unsigned long)(base + off) = v; }
static inline void mmio_w16(u32 base, u32 off, u16 v) { *(volatile u16 *)(unsigned long)(base + off) = v; }
static inline void mmio_w32(u32 base, u32 off, u32 v) { *(volatile u32 *)(unsigned long)(base + off) = v; }

/* ---------- взятие у BIOS ---------- */

static void ehci_take_ownership(int bus, int dev, int func)
{
    /* USBLEGSUP register offset is in HCCPARAMS bits 7..0 (extended capability pointer) */
    u32 hccparams = pci_read32(bus, dev, func, 0x08 + EHCI_CAP_HCCPARAMS);
    /* Actually HCCPARAMS is at offset 0x08 from BAR0 (MMIO) — but in PCI config, it's at offset 0x08 + 4 = 0x0C? No, HCCPARAMS is in the CAPABILITY registers (MMIO), not in PCI config. */

    /* Read HCCPARAMS from MMIO if we have a base; else skip. */
    if (!ehci_ctrl.mmio_base) return;
    u32 hccp = mmio_r32(ehci_ctrl.mmio_base, EHCI_CAP_HCCPARAMS);
    u8 ecp = (u8)(hccp & 0xFF);
    if (ecp == 0) {
        serial_puts("[ehci] no USBLEGSUP cap\n");
        return;
    }

    /* USBLEGSUP register: at offset ecp in PCI config space of this device. */
    u32 legsup = pci_read32(bus, dev, func, ecp);
    if (legsup & (1 << 16)) {
        /* BIOS owns HC — request ownership by setting OS Owned bit (bit 24) */
        serial_puts("[ehci] requesting ownership from BIOS...\n");
        pci_write32(bus, dev, func, ecp, legsup | (1 << 24));
        /* Wait for BIOS to release (up to 1 sec) */
        for (int i = 0; i < 100; i++) {
            u32 v = pci_read32(bus, dev, func, ecp);
            if ((v & (1 << 16)) == 0) {
                serial_puts("[ehci] ownership acquired\n");
                return;
            }
            for (volatile int j = 0; j < 100000; j++) { }   /* ~10ms */
        }
        serial_puts("[ehci] WARN: BIOS didn't release ownership\n");
    } else {
        serial_puts("[ehci] ownership: OS already owns (or no BIOS owner)\n");
    }
}

/* ---------- инициализация HC ---------- */

static int ehci_init_one(int bus, int dev, int func)
{
    u32 bar0 = pci_read32(bus, dev, func, 0x10);
    if (bar0 == 0xFFFFFFFF) return 0;
    /* BAR0 — это MMIO адрес (бит 0..3 типа = 0 для MMIO) */
    u32 mmio = bar0 & 0xFFFFFFF0u;
    if (mmio == 0) return 0;

    /* Включаем Bus Master + MMIO */
    u16 cmd = pci_read16(bus, dev, func, 0x04);
    cmd |= 0x06;     /* MSE | BME */
    pci_write16(bus, dev, func, 0x04, cmd);

    ehci_ctrl.mmio_base = mmio;
    ehci_ctrl.bus = bus; ehci_ctrl.dev = dev; ehci_ctrl.func = func;

    /* Читаем capability registers */
    ehci_ctrl.cap_length  = mmio_r8(mmio, EHCI_CAP_CAPLENGTH);
    ehci_ctrl.hciversion  = mmio_r16(mmio, EHCI_CAP_HCIVERSION);
    u32 hcsparams = mmio_r32(mmio, EHCI_CAP_HCSPARAMS);
    ehci_ctrl.n_ports = (u8)(hcsparams & 0xF);

    {
        char buf[120];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(buf, sizeof(buf),
                 "[ehci] mmio=0x%x caplen=%u hciver=0x%x nports=%u\n",
                 (unsigned)mmio, (unsigned)ehci_ctrl.cap_length,
                 (unsigned)ehci_ctrl.hciversion, (unsigned)ehci_ctrl.n_ports);
        serial_puts(buf);
    }

    /* Взять владение у BIOS */
    ehci_take_ownership(bus, dev, func);

    /* Шаг 1: Остановить HC */
    u32 op = mmio + ehci_ctrl.cap_length;
    mmio_w32(op, EHCI_OP_USBCMD, 0);
    /* Ждём HCHalted */
    for (int i = 0; i < 1000; i++) {
        if (mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_HCH) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }

    /* Шаг 2: Сброс HC */
    mmio_w32(op, EHCI_OP_USBCMD, EHCI_USBCMD_HCRESET);
    for (int i = 0; i < 1000; i++) {
        if (!(mmio_r32(op, EHCI_OP_USBCMD) & EHCI_USBCMD_HCRESET)) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }
    /* Очищаем статусы */
    mmio_w32(op, EHCI_OP_USBSTS, 0xFFFFFFFF);

    /* Шаг 3: Выделяем periodic list (4K-aligned, 1024 entries = 4K) */
    u8 *storage = (u8 *)malloc(8192 + 32);
    if (!storage) {
        serial_puts("[ehci] no memory for periodic list\n");
        return 0;
    }
    u32 aligned = ((u32)(unsigned long)storage + 0xFFF) & ~0xFFFu;
    u32 *plist = (u32 *)(unsigned long)aligned;
    ehci_ctrl.periodic_list = plist;
    /* Все 1024 элементов терминированы (T=1, type QH=01 → 0x3 = T|QH-type) */
    for (int i = 0; i < 1024; i++) plist[i] = EHCI_QH_TERMINATE | EHCI_QH_TYPE_QH;

    /* Шаг 4: Создаём async QH (пустой, self-link с Head флагом) */
    ehci_qh_t *aqh = ehci_qh_alloc();
    if (!aqh) {
        serial_puts("[ehci] no memory for async QH\n");
        return 0;
    }
    /* Head of reclamation list flag (bit 15), EPSPEED=hi (2<<12 — биты 13:12!),
     * maxpkt=64. Это особый "head" QH, который HC обходит циклически. */
    aqh->characteristics = (1 << 15) | (2 << EHCI_QH_EPSPEED_SHFT) | (64 << EHCI_QH_MAXPKT_SHFT);
    aqh->split_completion = (1u << 30);   /* Mult=1 (биты 31:30; по spec 0 недопустим).
                                           * Head-QH трансферов не исполняет, но пусть будет канонично. */
    aqh->horiz_link = (u32)(unsigned long)aqh | EHCI_QH_TYPE_QH | EHCI_QH_TERMINATE;
    aqh->cur_qtd = EHCI_QTD_TERMINATE;
    aqh->next_qtd = EHCI_QTD_TERMINATE;
    aqh->alt_next_qtd = EHCI_QTD_TERMINATE;
    aqh->token = 0;
    ehci_ctrl.async_qh = aqh;

    /* Шаг 5: Программируем регистры */
    mmio_w32(op, EHCI_OP_CTRLDSSEGMENT, 0);     /* 32-bit, без сегментации */
    mmio_w32(op, EHCI_OP_PERIODICLISTBASE, (u32)(unsigned long)plist);
    mmio_w32(op, EHCI_OP_FRINDEX, 0);
    mmio_w32(op, EHCI_OP_ASYNCLISTADDR, (u32)(unsigned long)aqh);
    mmio_w32(op, EHCI_OP_USBINTR, 0);
    /* Установить Configflag = 1 (claim all ports from companion) */
    mmio_w32(op, EHCI_OP_CONFIGFLAG, 1);

    /* Шаг 6: Включить HC: Run + Async Schedule Enable (периодикой не пользуемся) */
    mmio_w32(op, EHCI_OP_USBCMD, EHCI_USBCMD_RS | EHCI_USBCMD_ASE);
    /* Подождать запуска */
    for (int i = 0; i < 1000; i++) {
        if (!(mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_HCH)) break;
        for (volatile int j = 0; j < 1000; j++) { }
    }

    /* Шаг 7: Power on all ports.
     * СЕССИЯ 35: пауза после включения питания 50 -> 250 мс — VMware
     * passthrough успевает прокинуть линию; иначе boot-перечисление
     * читает CCS=0 (устройство «ещё не подключено») и ждёт CSC. */
    for (int p = 0; p < ehci_ctrl.n_ports; p++) {
        u32 psc = mmio_r32(op, EHCI_OP_PORTSC + p * 4);
        mmio_w32(op, EHCI_OP_PORTSC + p * 4, psc | EHCI_PORTSC_PP);
    }
    for (volatile int i = 0; i < 250000; i++) { }

    ehci_ctrl.valid = 1;
    serial_puts("[ehci] initialized\n");
    return 1;
}

/* ---------- сброс порта ----------
 * СЕССИЯ 34: ждём PE до 200 мс после снятия PR (опрос каждые ~1 мс),
 * а не 20 мс однократно — VMware завершает chirp-рукопожатие с
 * задержкой, а RTL8192EU после сброса инициализирует PHY.
 * Возврат: 1 — порт включён (PE=1), 0 — устройства нет, -1 — не включился. */
static int ehci_reset_port(int port)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    u32 psc_addr = op + EHCI_OP_PORTSC + port * 4;
    u32 ps = mmio_r32(psc_addr, 0);
    if (!(ps & EHCI_PORTSC_CCS)) return 0;

    /* Сброс порта: PR на 50 мс (spec: не менее 10) */
    ps |= EHCI_PORTSC_PR;
    mmio_w32(psc_addr, 0, ps);
    {
        u32 dl = timer_poll_deadline();
        while (!timer_poll_expired(dl, 50000)) ehci_wait_pause();  /* 50 мс */
    }
    ps = mmio_r32(psc_addr, 0);
    ps &= ~EHCI_PORTSC_PR;
    mmio_w32(psc_addr, 0, ps);

    /* Ждём PE до 200 мс */
    {
        u32 dl = timer_poll_deadline();
        for (;;) {
            ps = mmio_r32(psc_addr, 0);
            if (ps & EHCI_PORTSC_PE) break;
            if (!(ps & EHCI_PORTSC_CCS)) {
                mmio_w32(psc_addr, 0, ps | EHCI_PORTSC_CSC | EHCI_PORTSC_PEC);
                return 0;                 /* выдернули во время сброса */
            }
            if (timer_poll_expired(dl, 200000)) return -1;
            ehci_wait_pause();            /* hlt ~1 мс (в boot — busy) */
        }
    }
    /* Очистим change-биты */
    mmio_w32(psc_addr, 0, ps | EHCI_PORTSC_CSC | EHCI_PORTSC_PEC);
    return 1;
}

/* ---------- СЕССИЯ 40: постоянная RX-очередь (bulk IN) ----------
 * Проблема: RX-поллинг WiFi каждые 20 мс ставил bulk IN с таймаутом
 * 25 мс; по таймауту QH вырывался из живого async-кольца, а qTD
 * освобождался ещё ACTIVE. Во время скана кадры идут непрерывно —
 * рано или поздно abort попадал на середину DMA, и прошивка
 * RTL8192EU вставала клином: EP0 (регистры) и EP4 (RX) молчали
 * навсегда (в логе «xfer timeout» с ovl = SETUP 8 б / IN 4096 б,
 * после первого полного скана 0 кадров на всех каналах).
 * Решение — как в Linux: RX-трансфер ставится в кольцо ОДИН РАЗ и
 * живёт там, пока не придут данные. НИКАКИХ таймаутов и абортов:
 * пустой endpoint NAK-ится — HC просто переспрашивает каждый кадр.
 * Ошибки транзакций разбирает usb_ehci_rx_poll() (-2 — очередь
 * снята, вызывающий переоружит). */

static ehci_qh_t  *rx_qh   = NULL;   /* QH RX-очереди (постоянно в кольце) */
static ehci_qtd_t *rx_qtd  = NULL;   /* его единственный qTD */
static int         rx_armed = 0;     /* QH в кольце */
static int         rx_len   = 0;     /* запрошенная длина */
static u32         rx_armed_at = 0;  /* тик постановки в очередь/последнего rearm */

static void qtd_fill_pages(ehci_qtd_t *q, const void *buf);   /* ниже по файлу */

/* СЕССИЯ 40: страховка «неподнятой» очереди. Если qTD не завершился за
 * 3 с (тихий канал ИЛИ HC пропустил AdvanceQueue после rearm) — цикл
 * disarm+arm на свежем QH/qTD (проверенный путь). На живом канале
 * маяки приходят каждые ~100 мс — страховка не срабатывает вовсе. */
#define RX_RECYCLE_MS 3000u

/* Вставить транзитный QH между головой и хвостом кольца (rx_qh живёт
 * в кольце постоянно — вставляемся ПЕРЕД ним). */
static void ehci_ring_link_transfer(ehci_qh_t *qh)
{
    ehci_qh_t *tail = (rx_armed && rx_qh) ? rx_qh : ehci_ctrl.async_qh;
    ehci_ctrl.async_qh->horiz_link = (u32)(unsigned long)qh | EHCI_QH_TYPE_QH;
    qh->horiz_link = (u32)(unsigned long)tail | EHCI_QH_TYPE_QH;
}

/* Убрать транзитный QH из кольца (после завершения/doorbell). */
static void ehci_ring_unlink_transfer(void)
{
    if (rx_armed && rx_qh)
        ehci_ctrl.async_qh->horiz_link =
            (u32)(unsigned long)rx_qh | EHCI_QH_TYPE_QH;
    else
        ehci_ctrl.async_qh->horiz_link =
            (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH |
            EHCI_QH_TERMINATE;
}

/* СЕССИЯ 40: Async-Advance-Doorbell (spec 4.8.2). Ставит IAAD и ждёт
 * IAA: после него HC гарантированно отпустил async-состояние — можно
 * снимать QH с кольца и освобождать qTD (он мог остаться ACTIVE:
 * устройство молчит, а freed qTD мгновенно переиспользуется пулом). */
static void ehci_async_advance_doorbell(void)
{
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    mmio_w32(op, EHCI_OP_USBCMD,
             mmio_r32(op, EHCI_OP_USBCMD) | EHCI_USBCMD_IAAD);
    u32 dl = timer_poll_deadline();
    while (!(mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_IAA)) {
        if (timer_poll_expired(dl, 20000)) break;    /* 20 мс, best effort */
        ehci_wait_grace(dl, 500);
    }
    mmio_w32(op, EHCI_OP_USBSTS, EHCI_USBSTS_IAA);   /* W1C */
}

int usb_ehci_rx_arm(int addr, int ep, int ep_size, void *buf, int len)
{
    if (!ehci_ctrl.valid) return -1;
    if (rx_armed) return 1;               /* уже стоит — idempotent */
    if (!buf || len <= 0 || len > 0x7FFF) return -1;

    ehci_qh_t *qh = ehci_qh_alloc();
    ehci_qtd_t *q = ehci_qtd_alloc();
    if (!qh || !q) {
        ehci_qh_free(qh);
        ehci_qtd_free(q);
        return -1;
    }

    qh->characteristics = (addr << EHCI_QH_DEVADDR_SHFT) |
                          ((ep & 0xF) << EHCI_QH_EP_SHFT) |
                          (2 << EHCI_QH_EPSPEED_SHFT) |   /* hi-speed */
                          (((u32)ep_size) << EHCI_QH_MAXPKT_SHFT) |
                          EHCI_QH_DTC;
    qh->split_completion = (1u << 30);    /* Mult=1 */
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    qh->next_qtd = EHCI_QTD_TERMINATE;
    qh->alt_next_qtd = EHCI_QTD_TERMINATE;
    /* СЕССИЯ 36: оверлей-токен не активируем — HC сам возьмёт next_qtd */
    qh->token = 0;

    q->next_qtd = EHCI_QTD_TERMINATE;
    q->alt_next_qtd = EHCI_QTD_TERMINATE;
    q->token = ((u32)len << EHCI_TD_BYTES_SHFT) |
               EHCI_TD_PID_IN | (3 << EHCI_TD_CERR_SHFT) |
               EHCI_TD_ACTIVE | EHCI_TD_IOC;
    qtd_fill_pages(q, buf);

    qh->next_qtd = EHCI_QTD_NEXT(q);

    rx_qh = qh;
    rx_qtd = q;
    rx_len = len;
    rx_armed_at = timer_ticks();

    /* Связать кольцо: голова -> rx_qh -> голова. ASE включён с init;
     * HC дойдёт до нового QH на ближайшем проходе кольца. */
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    u32 cmd = mmio_r32(op, EHCI_OP_USBCMD);
    if (!(cmd & EHCI_USBCMD_ASE))
        mmio_w32(op, EHCI_OP_USBCMD, cmd | EHCI_USBCMD_ASE);
    ehci_ctrl.async_qh->horiz_link = (u32)(unsigned long)qh | EHCI_QH_TYPE_QH;
    qh->horiz_link = (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH;
    rx_armed = 1;
    return 1;
}

/* Неблокирующий опрос RX-очереди.
 * Возвращает: -1 — данных ещё нет; 0..len — принято n байт (очередь
 * пуста, нужен rearm); -2 — ошибка транзакции (очередь снята). */
int usb_ehci_rx_poll(void)
{
    if (!ehci_ctrl.valid || !rx_armed || !rx_qh || !rx_qtd) return -1;
    u32 tok = rx_qtd->token;
    if (tok & EHCI_TD_ACTIVE) {
        /* HC мог остановить очередь в ОВЕРЛЕЕ QH (XactErr -> halt):
         * сам qTD ещё active, но исполняться больше не будет */
        if (rx_qh->token & (EHCI_TD_HALT | EHCI_TD_XACT_ERR |
                            EHCI_TD_BABBLE | EHCI_TD_DBE))
            goto fail;
        if ((u32)(timer_ticks() - rx_armed_at) > RX_RECYCLE_MS) {
            /* 3 с без единого пакета: перестраховка — пересобрать
             * очередь на свежем QH/qTD (тихий канал это тоже переживёт:
             * один doorbell+free за 3 с — цена нулевая) */
            goto fail;
        }
        return -1;
    }
    if (tok & (EHCI_TD_HALT | EHCI_TD_DBE | EHCI_TD_BABBLE | EHCI_TD_XACT_ERR))
        goto fail;
    /* Готово: сколько байт реально принял HC (в token — ОСТАТОК) */
    {
        u32 rem = (tok >> EHCI_TD_BYTES_SHFT) & EHCI_TD_BYTES_MASK;
        int got = (int)((u32)rx_len - rem);
        if (got < 0) got = 0;
        if (got > rx_len) got = rx_len;
        return got;
    }
fail:
    ehci_async_advance_doorbell();
    ehci_ring_unlink_transfer();
    ehci_qtd_free(rx_qtd);
    ehci_qh_free(rx_qh);
    rx_qh = NULL;
    rx_qtd = NULL;
    rx_armed = 0;
    return -2;
}

/* Поставить qTD обратно в очередь (после успешного poll). Оверлей QH
 * неактивен (qTD завершён) — HC сам сделает AdvanceQueue и возьмёт
 * next_qtd на ближайшем проходе кольца. */
int usb_ehci_rx_rearm(void)
{
    if (!ehci_ctrl.valid || !rx_armed || !rx_qh || !rx_qtd) return -1;
    rx_qtd->next_qtd = EHCI_QTD_TERMINATE;
    rx_qtd->alt_next_qtd = EHCI_QTD_TERMINATE;
    rx_qtd->token = ((u32)rx_len << EHCI_TD_BYTES_SHFT) |
                    EHCI_TD_PID_IN | (3 << EHCI_TD_CERR_SHFT) |
                    EHCI_TD_ACTIVE | EHCI_TD_IOC;
    rx_qh->next_qtd = EHCI_QTD_NEXT(rx_qtd);
    rx_qh->cur_qtd = EHCI_QTD_TERMINATE;
    rx_armed_at = timer_ticks();
    return 1;
}

/* Снять RX-очередь с кольца (detach/recovery). qTD мог быть ACTIVE —
 * сначала doorbell. */
int usb_ehci_rx_disarm(void)
{
    if (!rx_armed || !rx_qh) return 0;
    ehci_async_advance_doorbell();
    ehci_ctrl.async_qh->horiz_link =
        (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH |
        EHCI_QH_TERMINATE;
    ehci_qtd_free(rx_qtd);
    ehci_qh_free(rx_qh);
    rx_qh = NULL;
    rx_qtd = NULL;
    rx_armed = 0;
    return 1;
}

/* ---------- ожидание завершения qTD ---------- */

/* Заполнить 5 buffer-указателей qTD (EHCI spec 3.5.4):
 *   buffer[0] — ПОЛНЫЙ адрес первого байта: биты 31:12 — база страницы,
 *               биты 11:0 — офсет, с которого HC НАЧИНАЕТ трансфер;
 *   buffer[1..4] — базы следующих 4K-страниц (офсет там должен быть 0).
 * СЕССИЯ 36, КРИТИЧНО: раньше buffer[0] писался как (addr & ~0xFFF) — офсет
 * затирался, и ВЕСЬ DATA-стейдж читал/писал НАЧАЛО 4K-страницы вместо
 * буфера. Для стекового devbuf это значило: устройство честно отдавало
 * дескриптор, но данные падали в чужое место, буфер оставался нулевым —
 * отсюда «hi-speed устройство 0000:0000» (сессия 33) и «get_descriptor(8)
 * не читается» после добавления валидации содержимого (сессия 34).
 * Эталон: Linux ehci-q.c qtd_fill() — hw_buf[0] = (u32)addr (офсет на месте);
 * QEMU (hcd-ehci.c) считает старт = bufptr[page] | (bufptr[0] & 0xfff). */
static void qtd_fill_pages(ehci_qtd_t *q, const void *buf) {
    u32 addr = (u32)(unsigned long)buf;
    u32 page = addr & ~0xFFFu;
    q->buffer[0] = addr;                 /* офсет в битах 11:0 ОБЯЗАТЕЛЕН */
    for (int i = 1; i < 5; i++)
        q->buffer[i] = page + (u32)i * 0x1000u;
}

static int ehci_wait_qtd(ehci_qtd_t *qtd, u32 timeout_us)
{
    u32 dl = timer_poll_deadline();
    for (;;) {
        u32 t = qtd->token;
        if (!(t & EHCI_TD_ACTIVE)) {
            /* Готово. Проверим ошибки. */
            if (t & (EHCI_TD_HALT | EHCI_TD_DBE | EHCI_TD_BABBLE | EHCI_TD_XACT_ERR)) {
                return -1;
            }
            return 1;
        }
        if (timer_poll_expired(dl, timeout_us)) return -1;
        ehci_wait_grace(dl, 1500);   /* 1.5 мс плотно, потом hlt */
    }
}

/* ---------- управление async schedule ---------- */

static int ehci_run_async_qh(ehci_qh_t *qh, u32 timeout_us)
{
    /* Поместить qh в async schedule (circular list), дождаться, снять. */
    if (!ehci_ctrl.valid) return -1;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;

    /* Вставить QH в кольцо. СЕССИЯ 40: ASYNCLISTADDR при живой RX-очереди
     * не перепрограммируем и ASE не выключаем — кольцо уже крутится
     * (ASE включён с init), HC сам дойдёт до нового QH за микрокадр.
     * Перепрограммирование ASYNCLISTADDR на работающем schedule
     * вне спецификации. */
    ehci_ring_link_transfer(qh);

    /* Включим async schedule; ждём ASS (реальное время — не итерации:
     * в VMware каждый inb — VM-exit, старый цикл 500000 итераций
     * выжигал секунды на каждом таймауте). */
    u32 cmd = mmio_r32(op, EHCI_OP_USBCMD);
    if (!(cmd & EHCI_USBCMD_ASE)) {
        mmio_w32(op, EHCI_OP_USBCMD, cmd | EHCI_USBCMD_ASE);
        if (!rx_armed) {
            u32 dl = timer_poll_deadline();
            while (!(mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_ASS)) {
                if (timer_poll_expired(dl, 20000)) break;    /* 20 мс */
                ehci_wait_grace(dl, 1500);
            }
        }
    }

    /* Ждём завершения всей цепочки qTD. После всех qTD'ишек HC
     * обновляет overlay: qh->next_qtd=TERMINATE и Active бит очищается.
     * Сессия 32: hlt-пауза в каждой итерации; печать таймаутов не чаще
     * раза в секунду (при коротком RX-таймауте пустого endpoint'а
     * таймауты — ШТАТНАЯ ситуация, раньше лог тонул в спаме). */
    int result = -1;
    {
        static u32 tmo_hidden = 0, tmo_last_print = 0;
        u32 dl = timer_poll_deadline();
        for (;;) {
            u32 ovl = qh->token;
            /* СЕССИЯ 34: HC остановил цепочку (ошибка транзакции,
             * Cerr исчерпан) — это НЕ успех и НЕ повод ждать полный
             * таймаут. Раньше цикл продолжал крутиться до timeout_us
             * (овердлей уже не менялся) и затем, увидев next==T &&
             * !Active, трактовал состояние как готовое — получали
             * «нулевые» дескрипторы и бесконечные пустые ретраи. */
            if (ovl & EHCI_TD_HALT) {
                result = -2;
                /* СЕССИЯ 36: диагностика остановки очереди (XactErr/
                 * STALL — устройство молчит или бракует запрос).
                 * Троттлинг 1/с, чтобы не спамить от bulk-RX. */
                {
                    static u32 halt_last_print = 0;
                    u32 now = timer_ticks();
                    if (halt_last_print == 0 ||
                        (u32)(now - halt_last_print) >= 1000) {
                        char b[150];
                        extern int snprintf(char *out, u32 n, const char *fmt, ...);
                        snprintf(b, sizeof(b),
                                 "[ehci] qh halt: ovl=0x%08x next=0x%08x cmd=0x%08x sts=0x%08x\n",
                                 (unsigned)ovl, (unsigned)qh->next_qtd,
                                 (unsigned)mmio_r32(op, EHCI_OP_USBCMD),
                                 (unsigned)mmio_r32(op, EHCI_OP_USBSTS));
                        serial_puts(b);
                        halt_last_print = now;
                    }
                }
                break;
            }
            if (qh->next_qtd == EHCI_QTD_TERMINATE && !(ovl & EHCI_TD_ACTIVE)) {
                result = 1;
                break;
            }
            if (timer_poll_expired(dl, timeout_us)) {
                u32 now = timer_ticks();
                tmo_hidden++;
                if (tmo_last_print == 0 ||
                    (u32)(now - tmo_last_print) >= 1000) {   /* 1 с (1 тик = 1 мс) */
                    /* Диагностика (одна строка): что показывает HC */
                    u32 sts = mmio_r32(op, EHCI_OP_USBSTS);
                    char b[140];
                    extern int snprintf(char *out, u32 n, const char *fmt, ...);
                    snprintf(b, sizeof(b),
                             "[ehci] xfer timeout%s: cmd=0x%08x sts=0x%08x next=0x%08x ovl=0x%08x\n",
                             (tmo_hidden > 1) ? " (плюс скрытые)" : "",
                             (unsigned)mmio_r32(op, EHCI_OP_USBCMD), (unsigned)sts,
                             (unsigned)qh->next_qtd, (unsigned)qh->token);
                    serial_puts(b);
                    tmo_last_print = now;
                    tmo_hidden = 0;
                }
                break;
            }
            ehci_wait_grace(dl, 1500);   /* 1.5 мс плотно, потом hlt */
        }
    }

    /* Снять QH из кольца.
     * СЕССИЯ 40: при таймауте/halt qTD мог остаться ACTIVE (устройство
     * молчит). Раньше QH вырывали из кольца и освобождали qTD сразу —
     * HC мог ещё исполнять цепочку, а память мгновенно переиспользовалась
     * следующим трансфером. Теперь перед снятием — Async-Advance-Doorbell. */
    if (result != 1)
        ehci_async_advance_doorbell();
    ehci_ring_unlink_transfer();

    /* ASE выключаем только когда RX-очереди в кольце нет (boot-фаза):
     * с постоянной RX-очередью schedule работает вечно. */
    if (!rx_armed) {
        cmd = mmio_r32(op, EHCI_OP_USBCMD);
        mmio_w32(op, EHCI_OP_USBCMD, cmd & ~EHCI_USBCMD_ASE);
        /* Подождать выключения async. */
        {
            u32 dl = timer_poll_deadline();
            while (mmio_r32(op, EHCI_OP_USBSTS) & EHCI_USBSTS_ASS) {
                if (timer_poll_expired(dl, 20000)) break;
                ehci_wait_grace(dl, 1500);
            }
        }
        ehci_ctrl.async_qh->horiz_link = (u32)(unsigned long)ehci_ctrl.async_qh | EHCI_QH_TYPE_QH | EHCI_QH_TERMINATE;
    }

    return (result > 0) ? 0 : -1;
}

/* ---------- control transfer ---------- */

static int ehci_control_transfer(int addr, u8 *setup_buf,
                                  void *data_buf, int data_len, int data_in)
{
    if (!ehci_ctrl.valid) return -1;

    ehci_qh_t *qh = ehci_qh_alloc();
    ehci_qtd_t *q_setup = ehci_qtd_alloc();
    ehci_qtd_t *q_status = ehci_qtd_alloc();
    ehci_qtd_t *q_data = NULL;
    if (!qh || !q_setup || !q_status) {
        ehci_qh_free(qh); ehci_qtd_free(q_setup); ehci_qtd_free(q_status);
        return -1;
    }

    /* Setup QH */
    qh->characteristics = (addr << EHCI_QH_DEVADDR_SHFT) |
                          (0 << EHCI_QH_EP_SHFT) |
                          (2 << EHCI_QH_EPSPEED_SHFT) |   /* hi-speed */
                          (64 << EHCI_QH_MAXPKT_SHFT) |
                          EHCI_QH_DTC;                    /* data toggle from qTD */
    qh->split_completion = (1u << 30);   /* Mult=1 (биты 31:30; по spec 0 недопустим) */
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    qh->next_qtd = EHCI_QTD_TERMINATE;
    qh->alt_next_qtd = EHCI_QTD_TERMINATE;
    /* СЕССИЯ 36: overlay-token НЕ активируем (0 = очередь простаивает).
     * HC сам берёт первый qTD из overlay next_qtd (spec 4.10.2) и сам
     * ведёт overlay (Linux: "only hc or qh_refresh() ever modify the
     * overlay"). Проверено по QEMU hcd-ehci.c: неактивная очередь идёт в
     * EST_ADVANCEQUEUE и читает qh.next_qtd — Active в overlay не нужен. */
    qh->token = 0;

    /* Setup qTD (8 bytes SETUP, DATA0) */
    q_setup->next_qtd = EHCI_QTD_TERMINATE;
    q_setup->alt_next_qtd = EHCI_QTD_TERMINATE;
    q_setup->token = (8 << EHCI_TD_BYTES_SHFT) |
                     EHCI_TD_PID_SETUP |
                     EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC;
    qtd_fill_pages(q_setup, setup_buf);

    /* Data qTD (если есть) */
    if (data_len > 0) {
        q_data = ehci_qtd_alloc();
        if (!q_data) {
            ehci_qh_free(qh); ehci_qtd_free(q_setup); ehci_qtd_free(q_status);
            return -1;
        }
        q_data->next_qtd = EHCI_QTD_TERMINATE;
        q_data->alt_next_qtd = EHCI_QTD_TERMINATE;
        q_data->token = ((u32)data_len << EHCI_TD_BYTES_SHFT) |
                        (data_in ? EHCI_TD_PID_IN : EHCI_TD_PID_OUT) |
                        EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                        EHCI_TD_DT;       /* DATA1 */
        qtd_fill_pages(q_data, data_buf);
        q_setup->next_qtd = EHCI_QTD_NEXT(q_data);
        q_status->token = (0 << EHCI_TD_BYTES_SHFT) |
                          (data_in ? EHCI_TD_PID_OUT : EHCI_TD_PID_IN) |
                          EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                          EHCI_TD_DT;       /* DATA1 */
    } else {
        q_status->token = (0 << EHCI_TD_BYTES_SHFT) |
                          EHCI_TD_PID_IN |
                          EHCI_TD_CERR_DEF | EHCI_TD_ACTIVE | EHCI_TD_IOC |
                          EHCI_TD_DT;       /* DATA1 */
    }

    /* Status qTD (zero-length, opposite direction, DATA1) */
    q_status->next_qtd = EHCI_QTD_TERMINATE;
    q_status->alt_next_qtd = EHCI_QTD_TERMINATE;
    q_status->buffer[0] = 0;

    /* Chain: setup -> data? -> status */
    if (q_data) {
        q_setup->next_qtd = EHCI_QTD_NEXT(q_data);
        q_data->next_qtd = EHCI_QTD_NEXT(q_status);
    } else {
        q_setup->next_qtd = EHCI_QTD_NEXT(q_status);
    }

    /* Point QH to first qTD.
     * cur_qtd MUST be EHCI_QTD_TERMINATE (not 0!) — иначе HC интерпретирует
     * это как указатель на qTD по адресу 0 (недопустимо).
     * HC использует next_qtd overlay, когда cur_qtd = TERMINATE. */
    qh->next_qtd = EHCI_QTD_NEXT(q_setup);
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    /* token установлен в EHCI_TD_ACTIVE при инициализации QH. Не обнуляем! */

    /* Run async (control — до 200 мс на всю цепочку SETUP+DATA+STATUS) */
    int r = ehci_run_async_qh(qh, 200000);
    int result = (r == 0) ? data_len : -1;

    /* Cleanup */
    ehci_qtd_free(q_setup);
    ehci_qtd_free(q_status);
    if (q_data) ehci_qtd_free(q_data);
    ehci_qh_free(qh);
    return result;
}

/* ---------- bulk transfer ---------- */

/* timeout_us — предельное ожидание завершения qTD. Сессия 32: параметр
 * вынесен наружу, чтобы RX-поллинг WiFi не ждал 2 с на пустом канале. */
static int ehci_bulk_transfer(int addr, int ep, int ep_size, int data_in,
                               void *buf, int len, u32 timeout_us)
{
    if (!ehci_ctrl.valid) return -1;

    ehci_qh_t *qh = ehci_qh_alloc();
    ehci_qtd_t *q = ehci_qtd_alloc();
    if (!qh || !q) {
        ehci_qh_free(qh); ehci_qtd_free(q);
        return -1;
    }

    /* Bulk QH */
    qh->characteristics = (addr << EHCI_QH_DEVADDR_SHFT) |
                          ((ep & 0xF) << EHCI_QH_EP_SHFT) |
                          (2 << EHCI_QH_EPSPEED_SHFT) |   /* hi-speed */
                          (((u32)ep_size) << EHCI_QH_MAXPKT_SHFT) |
                          EHCI_QH_DTC;
    qh->split_completion = (1u << 30);   /* Mult=1 (биты 31:30; по spec 0 недопустим) */
    qh->cur_qtd = EHCI_QTD_TERMINATE;
    qh->next_qtd = EHCI_QTD_TERMINATE;
    qh->alt_next_qtd = EHCI_QTD_TERMINATE;
    /* СЕССИЯ 36: overlay-token не трогаем (см. ehci_control_transfer) */
    qh->token = 0;

    /* qTD */
    q->next_qtd = EHCI_QTD_TERMINATE;
    q->alt_next_qtd = EHCI_QTD_TERMINATE;
    q->token = ((u32)len << EHCI_TD_BYTES_SHFT) |
               (data_in ? EHCI_TD_PID_IN : EHCI_TD_PID_OUT) |
               (3 << EHCI_TD_CERR_SHFT) | EHCI_TD_ACTIVE | EHCI_TD_IOC;
    qtd_fill_pages(q, buf);   /* buffer[0] несёт офсет, [1..4] — страницы */
    /* Если длина больше 4K, нужно несколько buffer[]; упрощение — до 4K */

    qh->next_qtd = EHCI_QTD_NEXT(q);
    qh->cur_qtd = EHCI_QTD_TERMINATE;   /* как в control: T, не 0 */

    /* Bulk может быть длинным (кадры 802.11, сектора) — таймаут задаёт
     * вызывающий (сектора/ТХ — 2 с, RX-поллинг — десятки мс). */
    int r = ehci_run_async_qh(qh, timeout_us);
    int result = (r == 0) ? len : -1;

    ehci_qtd_free(q);
    ehci_qh_free(qh);
    return result;
}

/* ---------- standard USB requests ---------- */

typedef struct __attribute__((packed)) {
    u8 bmRequestType;
    u8 bRequest;
    u16 wValue;
    u16 wIndex;
    u16 wLength;
} usb_request_t;

static int ehci_get_descriptor(int addr, u8 type, u8 idx, void *buf, int len)
{
    usb_request_t req;
    req.bmRequestType = 0x80;     /* IN, Standard, Device */
    req.bRequest = 6;
    req.wValue = (u16)((type << 8) | idx);
    req.wIndex = 0;
    req.wLength = (u16)len;
    return ehci_control_transfer(addr, (u8 *)&req, buf, len, 1);
}

static int ehci_set_address(int addr)
{
    usb_request_t req;
    req.bmRequestType = 0x00;
    req.bRequest = 5;
    req.wValue = (u16)addr;
    req.wIndex = 0;
    req.wLength = 0;
    return ehci_control_transfer(0, (u8 *)&req, 0, 0, 0);
}

static int ehci_set_configuration(int addr, u8 cfg)
{
    usb_request_t req;
    req.bmRequestType = 0x00;
    req.bRequest = 9;
    req.wValue = cfg;
    req.wIndex = 0;
    req.wLength = 0;
    return ehci_control_transfer(addr, (u8 *)&req, 0, 0, 0);
}

/* ---------- USB Mass Storage (BBB protocol + SCSI) ---------- */

typedef struct __attribute__((packed)) {
    u32 dCBWSignature;       /* 0x43425355 = 'USBC' */
    u32 dCBWTag;
    u32 dCBWDataTransferLength;
    u8  bmCBWFlags;            /* bit 7 = direction (1 = IN, 0 = OUT) */
    u8  bCBWLUN;
    u8  bCBWCBLength;
    u8  CBWCB[16];
} msd_cbw_t;     /* total 31 bytes */

typedef struct __attribute__((packed)) {
    u32 dCSWSignature;        /* 0x53425355 = 'USBS' */
    u32 dCSWTag;
    u32 dCSWDataResidue;
    u8  bCSWStatus;           /* 0 = OK, 1 = failed, 2 = phase error */
} msd_csw_t;     /* total 13 bytes */

static u8 msd_inquiry_cmd[6] = { 0x12, 0x00, 0x00, 0x00, 0x24, 0x00 };   /* INQUIRY, 36 bytes */
static u8 msd_test_unit_ready[6] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static u8 msd_read_capacity[10] = { 0x25, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static u8 msd_request_sense[6] = { 0x03, 0x00, 0x00, 0x00, 0x12, 0x00 };

static int ehci_msd_send_cbw(msd_cbw_t *cbw, int ep_out, int addr, int ep_size)
{
    return ehci_bulk_transfer(addr, ep_out, ep_size, 0, cbw, 31, 2000000);
}

static int ehci_msd_recv_csw(msd_csw_t *csw, int ep_in, int addr, int ep_size)
{
    return ehci_bulk_transfer(addr, ep_in, ep_size, 1, csw, 13, 2000000);
}

static int ehci_msd_init_device(int addr, int ep_in, int ep_out, int ep_size)
{
    /* Шлём TEST UNIT READY, пока не ответит OK (или limit) */
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    for (int attempt = 0; attempt < 5; attempt++) {
        cbw.dCBWSignature = 0x43425355u;
        cbw.dCBWTag = 0x100 + attempt;
        cbw.dCBWDataTransferLength = 0;
        cbw.bmCBWFlags = 0;            /* OUT */
        cbw.bCBWLUN = 0;
        cbw.bCBWCBLength = 6;
        memcpy(cbw.CBWCB, msd_test_unit_ready, 6);

        ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
        ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);
        if (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) {
            return 1;
        }
        /* Если статус 1, шлём REQUEST SENSE */
        memset(&csw, 0, sizeof(csw));
        cbw.dCBWTag = 0x200 + attempt;
        cbw.dCBWDataTransferLength = 0x12;
        cbw.bmCBWFlags = 0x80;     /* IN */
        cbw.bCBWCBLength = 6;
        memcpy(cbw.CBWCB, msd_request_sense, 6);
        u8 sense[18];
        ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
        ehci_bulk_transfer(addr, ep_in, ep_size, 1, sense, 0x12, 2000000);
        ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);
    }
    return 0;
}

static int ehci_msd_read_capacity(int addr, int ep_in, int ep_out, int ep_size,
                                   u32 *out_max_lba, u32 *out_block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    u8 resp[8];
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));
    memset(resp, 0, sizeof(resp));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x300;
    cbw.dCBWDataTransferLength = 8;
    cbw.bmCBWFlags = 0x80;     /* IN */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    memcpy(cbw.CBWCB, msd_read_capacity, 10);

    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    ehci_bulk_transfer(addr, ep_in, ep_size, 1, resp, 8, 2000000);
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    if (csw.dCSWSignature != 0x53425355u || csw.bCSWStatus != 0) return 0;

    /* resp: last LBA (big-endian 4 bytes) + block size (big-endian 4 bytes) */
    *out_max_lba = ((u32)resp[0] << 24) | ((u32)resp[1] << 16) |
                   ((u32)resp[2] << 8) | (u32)resp[3];
    *out_block_size = ((u32)resp[4] << 24) | ((u32)resp[5] << 16) |
                     ((u32)resp[6] << 8) | (u32)resp[7];
    return 1;
}

static int ehci_msd_read10(int addr, int ep_in, int ep_out, int ep_size,
                            u32 lba, void *buf, u32 n_blocks, u32 block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x400 + lba;
    cbw.dCBWDataTransferLength = n_blocks * block_size;
    cbw.bmCBWFlags = 0x80;     /* IN (read from device) */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    /* READ 10 command */
    cbw.CBWCB[0] = 0x28;     /* READ 10 */
    cbw.CBWCB[2] = (u8)((lba >> 24) & 0xFF);
    cbw.CBWCB[3] = (u8)((lba >> 16) & 0xFF);
    cbw.CBWCB[4] = (u8)((lba >> 8) & 0xFF);
    cbw.CBWCB[5] = (u8)(lba & 0xFF);
    cbw.CBWCB[7] = (u8)((n_blocks >> 8) & 0xFF);
    cbw.CBWCB[8] = (u8)(n_blocks & 0xFF);

    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    /* Receive data */
    ehci_bulk_transfer(addr, ep_in, ep_size, 1, buf, n_blocks * block_size, 2000000);
    /* Receive CSW */
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    return (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) ? 1 : 0;
}

/* WRITE 10: запись блоков на USB-флешку через BBB-протокол.
 * CBW (OUT) → DATA (OUT) → CSW (IN). */
static int ehci_msd_write10(int addr, int ep_in, int ep_out, int ep_size,
                             u32 lba, const void *buf, u32 n_blocks, u32 block_size)
{
    msd_cbw_t cbw;
    msd_csw_t csw;
    memset(&cbw, 0, sizeof(cbw));
    memset(&csw, 0, sizeof(csw));

    cbw.dCBWSignature = 0x43425355u;
    cbw.dCBWTag = 0x600 + lba;
    cbw.dCBWDataTransferLength = n_blocks * block_size;
    cbw.bmCBWFlags = 0x00;     /* OUT (write to device) */
    cbw.bCBWLUN = 0;
    cbw.bCBWCBLength = 10;
    /* WRITE 10 command (opcode 0x2A) */
    cbw.CBWCB[0] = 0x2A;     /* WRITE 10 */
    cbw.CBWCB[2] = (u8)((lba >> 24) & 0xFF);
    cbw.CBWCB[3] = (u8)((lba >> 16) & 0xFF);
    cbw.CBWCB[4] = (u8)((lba >> 8) & 0xFF);
    cbw.CBWCB[5] = (u8)(lba & 0xFF);
    cbw.CBWCB[7] = (u8)((n_blocks >> 8) & 0xFF);
    cbw.CBWCB[8] = (u8)(n_blocks & 0xFF);

    /* Send CBW (OUT direction) */
    ehci_msd_send_cbw(&cbw, ep_out, addr, ep_size);
    /* Send data (OUT direction — host to device) */
    ehci_bulk_transfer(addr, ep_out, ep_size, 0, (void *)buf, n_blocks * block_size, 2000000);
    /* Receive CSW (IN direction — device to host) */
    ehci_msd_recv_csw(&csw, ep_in, addr, ep_size);

    return (csw.dCSWSignature == 0x53425355u && csw.bCSWStatus == 0) ? 1 : 0;
}

/* ---------- публичные обёртки для class-драйверов (WiFi) ----------
 * RTL8192EU общается с регистрами через vendor control-трансферы и
 * передаёт 802.11-кадры bulk-ом. Обе операции ниже — тонкие обёртки
 * над внутренними функциями этого файла. */

/* Control-трансфер с произвольной запрос-пара (vendor-регистры Realtek).
 * data_in = 1 — IN (чтение), 0 — OUT (запись). Возвращает data_len или -1. */
int usb_ehci_ctrl_xfer(int addr, u8 bmReqType, u8 bReq,
                       u16 wValue, u16 wIndex, void *data, int len, int data_in)
{
    usb_request_t req;
    req.bmRequestType = bmReqType;
    req.bRequest      = bReq;
    req.wValue        = wValue;
    req.wIndex        = wIndex;
    req.wLength       = (u16)len;
    return ehci_control_transfer(addr, (u8 *)&req, data, len, data_in);
}

/* Bulk-трансфер. Возвращает len или -1. */
int usb_ehci_bulk_xfer(int addr, int ep, int ep_size, int data_in,
                       void *buf, int len)
{
    return ehci_bulk_transfer(addr, ep, ep_size, data_in, buf, len, 2000000);
}

/* СЕССИЯ 32: bulk с ЯВНЫМ таймаутом. Для RX-поллинга WiFi: пустой
 * endpoint NAK-ится, и раньше это стоило 2 с busy-wait на КАЖДЫЙ опрос
 * из главного цикла. Теперь драйвер передаёт десятки мс. */
int usb_ehci_bulk_xfer_to(int addr, int ep, int ep_size, int data_in,
                          void *buf, int len, u32 timeout_us)
{
    return ehci_bulk_transfer(addr, ep, ep_size, data_in, buf, len, timeout_us);
}

/* Хук class-драйвера WiFi (реализован в rtl8192eu.c). Вызывается
 * из перечисления для КАЖДОГО hi-speed устройства ПОСЛЕ
 * SetConfiguration; 1 = устройство забрано. Драйвер сам парсит
 * конфигурацию (нужны ВСЕ bulk-эндпоинты — по очередям TX). */
extern int usb_wifi_try_attach(int addr, u16 vid, u16 pid,
                               const u8 *cfgbuf, int cfg_total);

/* ---------- enumeration + storage discovery ---------- */

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 bcdUSB;
    u8 bDeviceClass, bDeviceSubClass, bDeviceProtocol;
    u8 bMaxPacketSize0;
    u16 idVendor, idProduct, bcdDevice;
    u8 iManufacturer, iProduct, iSerial;
    u8 bNumConfigurations;
} ehci_dev_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u16 wTotalLength;
    u8 bNumInterfaces, bConfigValue, iConfig, bmAttributes, bMaxPower;
} ehci_cfg_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bInterfaceNumber, bAlternateSetting;
    u8 bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol;
    u8 iInterface;
} ehci_iface_desc_t;

typedef struct __attribute__((packed)) {
    u8 bLength, bDescriptorType;
    u8 bEndpointAddress, bmAttributes;
    u16 wMaxPacketSize;
    u8 bInterval;
} ehci_ep_desc_t;

/* Найти в конфигурации mass-storage interface (class 8). */
static void ehci_parse_config_for_msd(u8 *buf, int len, int *ep_in, int *ep_out, int *ep_size)
{
    int i = 0;
    int cur_iface = -1;
    u8 iface_class = 0, iface_sub = 0, iface_proto = 0;
    while (i + 2 <= len) {
        u8 dlen = buf[i];
        u8 dtyp = buf[i + 1];
        if (dlen == 0) break;
        if (dtyp == 4 && i + 9 <= len) {
            cur_iface = buf[i + 2];
            iface_class = buf[i + 5];
            iface_sub = buf[i + 6];
            iface_proto = buf[i + 7];
        }
        else if (dtyp == 5 && i + 7 <= len) {
            u8 ep_addr = buf[i + 2];
            u8 ep_attr = buf[i + 3];
            u16 ep_sz = (u16)(buf[i + 4] | (buf[i + 5] << 8));
            /* Mass storage: bulk endpoints (attr=2). */
            if ((ep_attr & 0x03) == 0x02 && iface_class == 8) {
                if (ep_addr & 0x80) {
                    *ep_in = ep_addr & 0x0F;
                    *ep_size = ep_sz;
                } else {
                    *ep_out = ep_addr & 0x0F;
                    *ep_size = ep_sz;
                }
            }
        }
        i += dlen;
    }
    (void)iface_sub; (void)iface_proto; (void)cur_iface;
}

/* Перечисление портов EHCI (и при загрузке, и по hot-plug).
 * Возвращает число НОВО перечисленных hi-speed устройств.
 * Сессия 30:
 *  - per-port флаг done: каждое подключение перечисляем ОДИН раз;
 *  - FS/LS устройства отдаём companion-контроллеру (PORTSC.Owner=1),
 *    их обслуживает UHCI.
 * Сессия 34 (вежливое перечисление):
 *  - после CSC — 1 с тишины (стадия SETTLE), потом мягкие проходы;
 *  - сброс только когда порт не включён, не чаще раза в 3 прохода;
 *  - line-status анализируется только ПОСЛЕ сброса (до сброса HS-
 *    устройство держит D+ и выглядит как full-speed!);
 *  - попытки GET_DESCRIPTOR — без сбросов между ними;
 *  - Halt в overlay = ошибка трансфера (раньше считался успехом). */
/* СЕССИЯ 34: единая точка учёта неудач перечисления порта.
 * Возвращает 1, если порт ещё «жив» (повторим на следующем обслуживании),
 * 0 — попытки исчерпаны, порт отложен до нового CSC-события.
 * Печать троттлится: первые 2 попытки, далее каждая 3-я; в сообщении —
 * текущий ps (PE/CCS/line-status) для диагностики по serial-логу. */
static int ehci_port_fail(int port, const char *what)
{
    int tr = ++ehci_port_tries[port];
    if (tr <= 2 || (tr % 3) == 0) {
        u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
        u32 ps = mmio_r32(op, EHCI_OP_PORTSC + port * 4);
        char b2[130];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(b2, sizeof(b2),
                 "[ehci] port %d: %s (попытка %d, ps=0x%08x)\n",
                 port, what, tr, (unsigned)ps);
        serial_puts(b2);
    }
    if (tr >= 12) {
        /* 12 вежливых проходов (~8-10 с с паузами) — откладываем порт
         * до переподключения (CSC) */
        ehci_port_done[port] = 1;
        serial_puts("[ehci] порт отложен до переподключения (CSC)\n");
        return 0;
    }
    return 1;
}

static int ehci_enumerate(void)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    int found = 0;

    int next_addr = 10;     /* EHCI-адреса начинаем с 10, чтобы не конфликтовать с UHCI */
    for (int port = 0; port < ehci_ctrl.n_ports && port < 16; port++) {
        u32 psc_addr = op + EHCI_OP_PORTSC + port * 4;
        if (ehci_port_done[port]) continue;

        u32 ps = mmio_r32(psc_addr, 0);
        if (!(ps & EHCI_PORTSC_CCS)) {
            /* устройства нет — сброс стадии/счётчика */
            ehci_port_tries[port] = 0;
            ehci_port_stage[port] = EHCI_STAGE_SETTLE;
            ehci_port_ok_at[port] = timer_ticks();
            continue;
        }
        if (ps & EHCI_PORTSC_OWNER) continue;   /* порт у companion (UHCI) */

        /* ---- СЕССИЯ 34: стадия SETTLE — пауза после CSC ----
         * VMware passthrough и прошивка донгла инициализируются после
         * подключения; раньше перечисление начиналось немедленно и
         * сброс-шторм (до 120 control-трансферов с ресетами) не давал
         * устройству загрузиться — все дескрипторы читались нулями
         * или не читались вовсе, а CPU выжигался (тормозили окна). */
        if (ehci_port_stage[port] == EHCI_STAGE_SETTLE) {
            u32 now = timer_ticks();
            if ((int)(now - ehci_port_ok_at[port]) < 0) continue;
            ehci_port_stage[port] = EHCI_STAGE_POLL;
            ps = mmio_r32(psc_addr, 0);   /* состояние могло измениться за паузу */
            if (!(ps & EHCI_PORTSC_CCS)) continue;
            if (ps & EHCI_PORTSC_OWNER) continue;
        }

        /* ---- СЕССИЯ 34: сброс ТОЛЬКО когда порт не включён ----
         * КЛЮЧЕВОЙ ФИКС «отдано companion»: раньше порт отдавали UHCI
         * по line-status ДО сброса, но hi-speed устройство ДО сброса
         * держит D+ (idle = J-state) и выглядело как full-speed — порт
         * навсегда уходил к UHCI, который HS не умеет. Теперь line-status
         * смотрим только ПОСЛЕ неудачного сброса: по EHCI spec 4.2 после
         * сброса порт НЕ включается только у настоящих FS/LS устройств. */
        int did_reset = 0;
        if (!(ps & EHCI_PORTSC_PE)) {
            /* освежающий сброс не чаще раза в 3 неудачных прохода */
            if (ehci_port_tries[port] > 0 &&
                (ehci_port_tries[port] % 3) != 0) {
                (void)ehci_port_fail(port, "порт не включён, ждём");
                continue;
            }
            int rc = ehci_reset_port(port);
            if (rc == 0) continue;               /* устройства уже нет */
            did_reset = (rc > 0);
            ps = mmio_r32(psc_addr, 0);
            if (!(ps & EHCI_PORTSC_PE)) {
                u32 ls2 = (ps & EHCI_PORTSC_LS_MASK) >> EHCI_PORTSC_LS_SHFT;
                if (ls2 != 0 && !(ps & EHCI_PORTSC_OWNER)) {
                    /* J/K-state ПОСЛЕ сброса — настоящее FS/LS устройство */
                    mmio_w32(psc_addr, 0, ps | EHCI_PORTSC_OWNER);
                    char buf[80];
                    extern int snprintf(char *out, u32 n, const char *fmt, ...);
                    snprintf(buf, sizeof(buf),
                             "[ehci] port %d: FS/LS устройство — отдано companion UHCI\n",
                             port);
                    serial_puts(buf);
                    ehci_port_done[port] = 1;
                    continue;
                }
                /* SE0: переходное состояние (VMware/донгл ещё приходят в
                 * себя) — порт НЕ отдаём и НЕ фиксируем, ретраим позже */
                (void)ehci_port_fail(port, "порт не включился после сброса");
                continue;
            }
        }

        /* PE=1: после свежего сброса — 100 мс стабилизации
         * (RTL8192EU грузит прошивку, VMware настраивает passthrough) */
        if (did_reset) {
            u32 dl = timer_poll_deadline();
            while (!timer_poll_expired(dl, 100000)) ehci_wait_pause();  /* 100 мс */
        }

        /* ---- валидация содержимого дескрипторов + МЯГКИЕ ретраи ----
         * Сессия 33: содержимое валидируется (bLength/bDescriptorType),
         * при неудаче порт остаётся открытым для повторного перечисления.
         * Сессия 34: попытки БЕЗ сброса между ними — GET_DESCRIPTOR на
         * адрес 0 законен повторно, устройство остаётся в Default state.
         * Старый сброс между попытками обнулял прогресс инициализации
         * устройства, и шторм не мог закончиться. */
        u8 devbuf[64];
        int got8 = 0;
        for (int attempt = 0; attempt < 3; attempt++) {
            if (attempt > 0) {
                u32 dl = timer_poll_deadline();
                while (!timer_poll_expired(dl, 100000)) ehci_wait_pause();  /* 100 мс */
            }
            memset(devbuf, 0, sizeof(devbuf));
            int rc8 = ehci_get_descriptor(0, 1, 0, devbuf, 8);
            if (rc8 >= 8 && devbuf[0] >= 8 && devbuf[1] == 0x01) {
                got8 = 1;
                break;
            }
            if (rc8 >= 8 && attempt == 0) {
                /* СЕССИЯ 36: трансфер «успешен», но содержимое мусорное —
                 * печатаем первые байты (раз за проход): раньше здесь был
                 * невидимый офсет-баг qtd_fill_pages (данные уходили в
                 * начало 4K-страницы, буфер оставался нулевым). */
                char b[120];
                extern int snprintf(char *out, u32 n, const char *fmt, ...);
                snprintf(b, sizeof(b),
                         "[ehci] port %d: desc8 мусор: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                         port, devbuf[0], devbuf[1], devbuf[2], devbuf[3],
                         devbuf[4], devbuf[5], devbuf[6], devbuf[7]);
                serial_puts(b);
            }
            if (!(mmio_r32(psc_addr, 0) & EHCI_PORTSC_CCS)) break;  /* выдернули */
        }
        if (!got8) {
            if (mmio_r32(psc_addr, 0) & EHCI_PORTSC_CCS)
                (void)ehci_port_fail(port, "get_descriptor(8) не читается");
            continue;   /* повтор на следующем обслуживании */
        }

        /* Адрес назначаем только при УСПЕХЕ всей цепочки (в цикле ниже
         * не инкрементируем): неудачный SET_ADDRESS с ретраем не должен
         * оставлять «дыры» и дубли адресов. */
        int addr = next_addr;
        if (ehci_set_address(addr) < 0) {
            (void)ehci_port_fail(port, "set_address failed");
            continue;   /* устройство осталось в Default — повторим проход */
        }
        {   /* spec: ≥2 мс на восстановление после SET_ADDRESS;
             * 20 мс — с запасом для медленных устройств */
            u32 dl = timer_poll_deadline();
            while (!timer_poll_expired(dl, 20000)) ehci_wait_pause();
        }

        /* Полный дескриптор (18 байт): читаем с ретраями и валидацией.
         * Нули => устройство «отвалилось» после SET_ADDRESS — сбрасываем
         * порт и пробуем весь проход заново при следующем обслуживании. */
        int got18 = 0;
        for (int attempt = 0; attempt < 3; attempt++) {
            if (attempt > 0) {
                u32 dl = timer_poll_deadline();
                while (!timer_poll_expired(dl, 30000)) ehci_wait_pause();
            }
            memset(devbuf, 0, sizeof(devbuf));
            if (ehci_get_descriptor(addr, 1, 0, devbuf, 18) >= 18 &&
                devbuf[0] == 18 && devbuf[1] == 0x01 &&
                (devbuf[8] | devbuf[9] | devbuf[10] | devbuf[11]) != 0) {
                got18 = 1;
                break;
            }
        }
        if (!got18) {
            ehci_port_fail(port, "дескриптор после SET_ADDRESS мусорный (0000:0000) — сброс и повтор");
            ehci_reset_port(port);   /* устройство -> Default, адрес свободен */
            continue;                /* порт НЕ помечаем done */
        }
        next_addr++;
        u16 vid = (u16)(devbuf[8] | (devbuf[9] << 8));
        u16 pid = (u16)(devbuf[10] | (devbuf[11] << 8));

        /* Дескриптор конфигурации: та же гонка, что и с device-дескриптором —
         * валидируем (wTotalLength 9..200, bDescriptorType=0x02) и ретраим. */
        u8 cfgbuf[256];
        int cfg_total = 0;
        {
            int gotcfg = 0;
            for (int attempt = 0; attempt < 3; attempt++) {
                if (attempt > 0) {
                    u32 dl = timer_poll_deadline();
                    while (!timer_poll_expired(dl, 20000)) ehci_wait_pause();
                }
                memset(cfgbuf, 0, sizeof(cfgbuf));
                if (ehci_get_descriptor(addr, 2, 0, cfgbuf, 9) < 9) continue;
                int total = cfgbuf[2] | (cfgbuf[3] << 8);
                if (cfgbuf[1] != 0x02 || total < 9) continue;
                if (total > 200) total = 200;
                if (ehci_get_descriptor(addr, 2, 0, cfgbuf, total) < total)
                    continue;
                cfg_total = total;
                gotcfg = 1;
                break;
            }
            if (!gotcfg) {
                ehci_port_fail(port, "config descriptor не читается — сброс и повтор");
                ehci_reset_port(port);
                continue;
            }
        }
        ehci_set_configuration(addr, 1);

        /* Порт перечислен (дальше — только выбор класс-драйвера) */
        ehci_port_done[port] = 1;
        ehci_port_tries[port] = 0;
        ehci_port_addr[port] = addr;      /* сессия 40: адресный сброс */
        found++;
        {
            char buf[96];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[ehci] port %d: hi-speed устройство %04x:%04x (addr %d)\n",
                     port, vid, pid, addr);
            serial_puts(buf);
        }

        /* WiFi (RTL8192EU 0bda:818b и совместимые) — class-драйвер
         * сам решает, его ли это устройство по VID/PID, и сам
         * разбирает конфигурацию (все bulk-эндпоинты) */
        if (usb_wifi_try_attach(addr, vid, pid, cfgbuf, cfg_total)) {
            char buf[96];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[ehci] WiFi устройство %04x:%04x забрано (addr %d)\n",
                     vid, pid, addr);
            serial_puts(buf);
            continue;
        }

        int ep_in = 0, ep_out = 0, ep_size = 0;
        ehci_parse_config_for_msd(cfgbuf, cfg_total, &ep_in, &ep_out, &ep_size);

        if (ep_in && ep_out && ep_size) {
            char buf[80];
            extern int snprintf(char *out, u32 n, const char *fmt, ...);
            snprintf(buf, sizeof(buf),
                     "[ehci] mass storage @ addr %d, EPin=%d EPout=%d size=%d\n",
                     addr, ep_in, ep_out, ep_size);
            serial_puts(buf);

            if (ehci_msd_init_device(addr, ep_in, ep_out, ep_size)) {
                u32 max_lba = 0, bsz = 0;
                if (ehci_msd_read_capacity(addr, ep_in, ep_out, ep_size, &max_lba, &bsz)) {
                    snprintf(buf, sizeof(buf),
                             "[ehci] storage: %u blocks x %u bytes = %u MiB\n",
                             (unsigned)max_lba, (unsigned)bsz,
                             (unsigned)((u64)max_lba * bsz / (1024 * 1024)));
                    serial_puts(buf);
                    ehci_ctrl.storage_dev_addr = addr;
                    ehci_ctrl.storage_ep_in = ep_in;
                    ehci_ctrl.storage_ep_out = ep_out;
                    ehci_ctrl.storage_max_lba = max_lba;
                    ehci_ctrl.storage_block_size = bsz;
                }
            }
        }
    }
    return found;
}

/* Горячее подключение EHCI (сессия 30): гасим CSC, перечисляем новенькое.
 * Вызывается из wifi-задачи раз в 500 мс (та же задача — без гонок с
 * rtl8192eu_probe). Возвращает 1, если был event подключения или
 * перечислено новое устройство (сигнал для wifi-задачи попробовать probe). */
int usb_ehci_hotplug_service(void)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    int event = 0;

    for (int port = 0; port < ehci_ctrl.n_ports && port < 16; port++) {
        u32 ps = mmio_r32(op, EHCI_OP_PORTSC + port * 4);
        if (ps & EHCI_PORTSC_CSC) {
            mmio_w32(op, EHCI_OP_PORTSC + port * 4, ps | EHCI_PORTSC_CSC);  /* W1C */
            ehci_port_done[port] = 0;    /* пересмотреть порт */
            ehci_port_tries[port] = 0;   /* и счётчик неудач тоже */
            /* СЕССИЯ 34: после CSC — 1 с тишины (стадия SETTLE):
             * устройство/VMware passthrough приходят в готовность,
             * немедленный сброс-шторм только ломал инициализацию */
            ehci_port_stage[port] = EHCI_STAGE_SETTLE;
            ehci_port_ok_at[port] = timer_ticks() + 1000;
            event = 1;
            {
                char buf[80];
                extern int snprintf(char *out, u32 n, const char *fmt, ...);
                snprintf(buf, sizeof(buf),
                         "[ehci] port %d: connect status change (ps=0x%x), пауза 1 с\n",
                         port, (unsigned)ps);
                serial_puts(buf);
            }
        }
    }

    int found = ehci_enumerate();
    return (event || found) ? 1 : 0;
}

/* СЕССИЯ 40: адресный сброс порта с устройством addr (восстановление
 * «клина» USB WiFi: прошивка не отвечает на EP0/EP4, лечится только
 * сбросом порта + переперечислением). Порт помечается необслуженным —
 * обычный hot-plug проход перечислит устройство заново. */
int usb_ehci_reset_wifi_device(int addr)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    for (int p = 0; p < ehci_ctrl.n_ports && p < 16; p++) {
        if (ehci_port_addr[p] != addr) continue;
        char b[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        u32 ps = mmio_r32(op, EHCI_OP_PORTSC + p * 4);
        snprintf(b, sizeof(b),
                 "[ehci] сброс порта %d (addr %d не отвечает, ps=0x%08x)\n",
                 p, addr, (unsigned)ps);
        serial_puts(b);
        int rc = ehci_reset_port(p);
        ehci_port_done[p] = 0;      /* перечислить заново */
        ehci_port_tries[p] = 0;
        ehci_port_stage[p] = EHCI_STAGE_SETTLE;
        ehci_port_ok_at[p] = timer_ticks() + 150;
        ehci_port_addr[p] = 0;
        return (rc > 0) ? 1 : 0;
    }
    return 0;
}

/* СЕССИЯ 35: предикаты для главного цикла (см. usb_ehci.h).
 * Только чтение PORTSC — ничего не гасим, не сбрасываем, не перечисляем. */
int usb_ehci_csc_pending(void)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    for (int p = 0; p < ehci_ctrl.n_ports && p < 16; p++)
        if (mmio_r32(op, EHCI_OP_PORTSC + p * 4) & EHCI_PORTSC_CSC) return 1;
    return 0;
}

int usb_ehci_work_pending(void)
{
    if (!ehci_ctrl.valid) return 0;
    u32 op = ehci_ctrl.mmio_base + ehci_ctrl.cap_length;
    for (int p = 0; p < ehci_ctrl.n_ports && p < 16; p++) {
        u32 ps = mmio_r32(op, EHCI_OP_PORTSC + p * 4);
        if (ps & EHCI_PORTSC_CSC) return 1;
        if ((ps & EHCI_PORTSC_CCS) && !(ps & EHCI_PORTSC_OWNER) &&
            !ehci_port_done[p]) return 1;
    }
    return 0;
}

/* ---------- public API ---------- */

int usb_ehci_present(void) { return ehci_ctrl.valid ? 1 : 0; }

int usb_ehci_storage_ready(void) { return ehci_ctrl.storage_dev_addr ? 1 : 0; }

int usb_ehci_read_sector(u32 lba, void *buf)
{
    if (!ehci_ctrl.storage_dev_addr) return 0;
    return ehci_msd_read10(ehci_ctrl.storage_dev_addr,
                            ehci_ctrl.storage_ep_in,
                            ehci_ctrl.storage_ep_out,
                            ehci_ctrl.storage_block_size,
                            lba, buf, 1, 512);
}

int usb_ehci_write_sector(u32 lba, const void *buf)
{
    if (!ehci_ctrl.storage_dev_addr) return 0;
    return ehci_msd_write10(ehci_ctrl.storage_dev_addr,
                             ehci_ctrl.storage_ep_in,
                             ehci_ctrl.storage_ep_out,
                             ehci_ctrl.storage_block_size,
                             lba, buf, 1, 512);
}

void usb_ehci_init(void)
{
    ehci_ctrl.valid = 0;
    ehci_ctrl.storage_dev_addr = 0;
    memset(ehci_qh_used, 0, sizeof(ehci_qh_used));
    memset(ehci_qtd_used, 0, sizeof(ehci_qtd_used));
    memset(ehci_port_done, 0, sizeof(ehci_port_done));
    memset(ehci_port_tries, 0, sizeof(ehci_port_tries));
    memset(ehci_port_addr, 0, sizeof(ehci_port_addr));
    rx_qh = NULL; rx_qtd = NULL; rx_armed = 0; rx_len = 0;   /* сессия 40 */
    /* СЕССИЯ 34: при загрузке порты сразу в POLL (устройство,
     * подключенное ДО старта ВМ, уже готово — пауза не нужна);
     * SETTLE выставляется только обработчиком CSC (hot-plug). */
    for (int p = 0; p < 16; p++) {
        ehci_port_stage[p] = EHCI_STAGE_POLL;
        ehci_port_ok_at[p] = 0;
    }

    serial_puts("[ehci] init...\n");
    for (int bus = 0; bus < 256; bus++) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                u32 id = pci_read32(bus, dev, func, 0);
                if ((id & 0xFFFF) == 0 || (id & 0xFFFF) == 0xFFFF) {
                    if (func == 0) break;
                    continue;
                }
                u32 class_code = pci_read32(bus, dev, func, 0x08);
                u8 base_class = (u8)((class_code >> 24) & 0xFF);
                u8 sub_class  = (u8)((class_code >> 16) & 0xFF);
                u8 prog_if    = (u8)((class_code >> 8)  & 0xFF);
                if (base_class == 0x0C && sub_class == 0x03 && prog_if == 0x20) {
                    if (ehci_init_one(bus, dev, func)) {
                        (void)ehci_enumerate();
                        return;
                    }
                }
                if (func == 0) {
                    u8 hdr = pci_read8(bus, dev, 0, 0x0E);
                    if (!(hdr & 0x80)) break;
                }
            }
        }
    }
    serial_puts("[ehci] no EHCI controller found\n");
}
