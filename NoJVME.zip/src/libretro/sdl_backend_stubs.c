/*
 * SDL Backend Stubs for Libretro Build
 * With proper double buffering for multi-threaded mode
 */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdatomic.h>
#include <sys/time.h>

#include "libretro.h"
#include "sdl_backend.h"
#include "midp.h"
#include "miniz.h"

/* ============================================
 * External variables from libretro.c
 * ============================================ */

extern retro_video_refresh_t video_cb;
extern retro_input_poll_t input_poll_cb;
extern retro_input_state_t input_state_cb;
extern retro_environment_t environ_cb;

extern uint32_t* libretro_get_framebuffer(void);
extern int libretro_get_screen_width(void);
extern int libretro_get_screen_height(void);

/* ============================================
 * Audio Buffer for Libretro
 * ============================================ */

/* Small buffer - just enough for 2-3 frames to prevent overflow */
#define AUDIO_BUFFER_SIZE 4096
#define AUDIO_SOURCE_RATE 44100

static int16_t g_audio_buffer[AUDIO_BUFFER_SIZE * 2];
static size_t g_audio_write_pos = 0;
static size_t g_audio_read_pos = 0;
static size_t g_audio_count = 0;
static bool g_audio_initialized = false;

static uint32_t g_frontend_sample_rate = 22050;
static double g_audio_resample_ratio = 1.0;
static double g_audio_resample_pos = 0.0;

/* Time-based audio control */
static uint64_t g_last_frame_time = 0;
static double g_audio_time_accumulator = 0.0;  /* Accumulated audio time in samples */

static uint64_t audio_get_time_us(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec;
}

static void audio_buffer_init(void) {
    if (!g_audio_initialized) {
        memset(g_audio_buffer, 0, sizeof(g_audio_buffer));
        g_audio_write_pos = 0;
        g_audio_read_pos = 0;
        g_audio_count = 0;
        g_audio_resample_pos = 0.0;
        g_audio_time_accumulator = 0.0;
        g_last_frame_time = audio_get_time_us();
        g_audio_initialized = true;
        fprintf(stderr, "[J2ME Libretro] Audio initialized (rate: %d)\n",
                g_frontend_sample_rate);
    }
}

void libretro_set_sample_rate(uint32_t rate) {
    g_frontend_sample_rate = rate;
    g_audio_resample_ratio = (double)AUDIO_SOURCE_RATE / (double)rate;
    g_audio_time_accumulator = 0.0;
    g_last_frame_time = audio_get_time_us();
    fprintf(stderr, "[J2ME Audio] Sample rate set: %u, resample ratio: %.3f\n",
            rate, g_audio_resample_ratio);
}

/* Set FPS for audio calculation - called from libretro.c */
void libretro_set_fps(int fps) {
    (void)fps;  /* Not used in time-based mode */
    fprintf(stderr, "[J2ME Audio] Using time-based synchronization\n");
}

static void resample_audio(const int16_t* input, size_t input_samples,
                           int16_t* output, size_t* output_samples,
                           double ratio, double* pos) {
    if (ratio <= 0) ratio = 1.0;
    size_t out_idx = 0;
    double src_pos = *pos;
    
    while (src_pos < (double)(input_samples - 1) && out_idx < *output_samples) {
        int idx0 = (int)src_pos;
        int idx1 = idx0 + 1;
        if (idx1 >= (int)input_samples) idx1 = idx0;
        double frac = src_pos - (double)idx0;
        output[out_idx * 2] = (int16_t)(input[idx0 * 2] * (1.0 - frac) + input[idx1 * 2] * frac);
        output[out_idx * 2 + 1] = (int16_t)(input[idx0 * 2 + 1] * (1.0 - frac) + input[idx1 * 2 + 1] * frac);
        src_pos += ratio;
        out_idx++;
    }
    *pos = src_pos - (double)input_samples;
    *output_samples = out_idx;
}

void sdl_audio_queue_samples(const int16_t* samples, size_t count) {
    if (!samples || count == 0) return;
    audio_buffer_init();
    
    if (g_audio_resample_ratio != 1.0 && g_audio_resample_ratio > 0) {
        size_t max_output = (size_t)(count / g_audio_resample_ratio) + 16;
        int16_t* resampled = (int16_t*)malloc(max_output * 2 * sizeof(int16_t));
        if (resampled) {
            size_t output_count = max_output;
            resample_audio(samples, count / 2, resampled, &output_count, 
                          g_audio_resample_ratio, &g_audio_resample_pos);
            for (size_t i = 0; i < output_count; i++) {
                if (g_audio_count >= AUDIO_BUFFER_SIZE) {
                    g_audio_read_pos = (g_audio_read_pos + 1) % AUDIO_BUFFER_SIZE;
                    g_audio_count--;
                }
                g_audio_buffer[g_audio_write_pos * 2] = resampled[i * 2];
                g_audio_buffer[g_audio_write_pos * 2 + 1] = resampled[i * 2 + 1];
                g_audio_write_pos = (g_audio_write_pos + 1) % AUDIO_BUFFER_SIZE;
                g_audio_count++;
            }
            free(resampled);
            return;
        }
    }
    
    size_t samples_to_write = count / 2;
    for (size_t i = 0; i < samples_to_write; i++) {
        if (g_audio_count >= AUDIO_BUFFER_SIZE) {
            g_audio_read_pos = (g_audio_read_pos + 1) % AUDIO_BUFFER_SIZE;
            g_audio_count--;
        }
        g_audio_buffer[g_audio_write_pos * 2] = samples[i * 2];
        g_audio_buffer[g_audio_write_pos * 2 + 1] = samples[i * 2 + 1];
        g_audio_write_pos = (g_audio_write_pos + 1) % AUDIO_BUFFER_SIZE;
        g_audio_count++;
    }
}

size_t sdl_audio_get_queued_size(void) { return g_audio_count; }

extern void media_generate_audio_samples(int samples);

void libretro_process_audio(void) {
    extern retro_audio_sample_batch_t audio_batch_cb;
    if (!audio_batch_cb) return;

    /* TIME-BASED SYNCHRONIZATION - the key to correct audio speed! */
    uint64_t current_time = audio_get_time_us();
    uint64_t elapsed_us = current_time - g_last_frame_time;
    g_last_frame_time = current_time;

    /* Clamp elapsed time to reasonable range (1ms - 100ms) */
    if (elapsed_us < 1000) elapsed_us = 1000;
    if (elapsed_us > 100000) elapsed_us = 100000;

    /* Calculate how many samples are needed for the elapsed time */
    /* samples = sample_rate * time_seconds = sample_rate * time_us / 1000000 */
    double samples_needed = (double)g_frontend_sample_rate * (double)elapsed_us / 1000000.0;
    g_audio_time_accumulator += samples_needed;

    /* Also account for any previously unsent samples */
    int samples_to_send = (int)g_audio_time_accumulator;
    if (samples_to_send < 1) return;  /* Not enough time passed */
    g_audio_time_accumulator -= (double)samples_to_send;

    /* Clamp to reasonable range */
    if (samples_to_send > 2048) samples_to_send = 2048;

    /* Generate samples at source rate (44100 Hz) */
    int samples_to_generate = samples_to_send;
    if (g_audio_resample_ratio > 0 && g_audio_resample_ratio != 1.0) {
        samples_to_generate = (int)(samples_to_send * g_audio_resample_ratio);
    }

    /* Add small buffer to prevent underrun */
    samples_to_generate += 32;
    if (samples_to_generate < 64) samples_to_generate = 64;

    media_generate_audio_samples(samples_to_generate);

    if (g_audio_count == 0) return;

    /* Limit to what we have and what we calculated */
    if ((size_t)samples_to_send > g_audio_count) {
        samples_to_send = (int)g_audio_count;
    }

    /* Send samples in chunks */
    int samples_sent = 0;
    while (samples_sent < samples_to_send) {
        int remaining = samples_to_send - samples_sent;
        int chunk = remaining > 256 ? 256 : remaining;

        size_t contiguous = AUDIO_BUFFER_SIZE - g_audio_read_pos;
        if (contiguous > (size_t)chunk) contiguous = (size_t)chunk;
        if (contiguous > g_audio_count) contiguous = g_audio_count;

        if (contiguous == 0) break;

        audio_batch_cb(&g_audio_buffer[g_audio_read_pos * 2], contiguous);
        g_audio_read_pos = (g_audio_read_pos + contiguous) % AUDIO_BUFFER_SIZE;
        g_audio_count -= contiguous;
        samples_sent += contiguous;
    }

    /* Debug output periodically */
    static int debug_counter = 0;
    if (++debug_counter >= 60) {
        debug_counter = 0;
        fprintf(stderr, "[J2ME Audio] elapsed=%llu us, sent=%d, buffer=%zu\n",
                (unsigned long long)elapsed_us, samples_sent, g_audio_count);
    }
}

/* ============================================
 * Double Buffering - J2ME renders to ONE buffer
 * ============================================ */

static SdlContext g_libretro_context = {0};

/* Double buffer: J2ME always renders to buffer[0], we copy to buffer[1] for display */
#define BUFFER_COUNT 2
static uint32_t* g_buffers[BUFFER_COUNT] = {NULL, NULL};
static atomic_bool g_frame_ready = false;
static atomic_bool g_copying = false;

static int g_buffer_width = 0;
static int g_buffer_height = 0;
static size_t g_buffer_size = 0;

static bool init_buffers(int width, int height) {
    if (width <= 0 || height <= 0) {
        fprintf(stderr, "[J2ME] Invalid buffer size: %dx%d\n", width, height);
        return false;
    }

    g_buffer_width = width;
    g_buffer_height = height;
    g_buffer_size = (size_t)width * (size_t)height * sizeof(uint32_t);

    for (int i = 0; i < BUFFER_COUNT; i++) {
        g_buffers[i] = (uint32_t*)malloc(g_buffer_size);
        if (!g_buffers[i]) {
            for (int j = 0; j < i; j++) {
                free(g_buffers[j]);
                g_buffers[j] = NULL;
            }
            fprintf(stderr, "[J2ME] Failed to allocate buffer %d\n", i);
            return false;
        }
        memset(g_buffers[i], 0, g_buffer_size);
    }

    atomic_store(&g_frame_ready, false);
    atomic_store(&g_copying, false);

    /* J2ME always renders to buffer[0] */
    g_libretro_context.framebuffer = g_buffers[0];

    fprintf(stderr, "[J2ME] Double buffer initialized: %dx%d\n", width, height);
    return true;
}

/* Resize buffers - called when resolution changes at runtime */
bool libretro_resize_buffers(int width, int height) {
    if (width <= 0 || height <= 0) {
        fprintf(stderr, "[J2ME] Invalid resize dimensions: %dx%d\n", width, height);
        return false;
    }

    /* Check if size actually changed */
    if (width == g_buffer_width && height == g_buffer_height) {
        return true;  /* No change needed */
    }

    fprintf(stderr, "[J2ME] Resizing buffers from %dx%d to %dx%d\n",
            g_buffer_width, g_buffer_height, width, height);

    /* Free old buffers */
    for (int i = 0; i < BUFFER_COUNT; i++) {
        if (g_buffers[i]) {
            free(g_buffers[i]);
            g_buffers[i] = NULL;
        }
    }

    /* Allocate new buffers */
    return init_buffers(width, height);
}

/* Called at START of frame - nothing to do */
void libretro_begin_frame(void) {
    /* J2ME renders incrementally, don't clear */
}

/* Called at END of frame - copy render buffer to display buffer */
void libretro_end_frame(void) {
    if (!g_buffers[0] || !g_buffers[1]) return;
    
    /* Wait if previous copy is still being read */
    while (atomic_load(&g_copying)) {
        /* Busy wait - should be very short */
    }
    
    /* Copy buffer[0] (render) to buffer[1] (display) */
    atomic_store(&g_copying, true);
    atomic_thread_fence(memory_order_release);
    
    memcpy(g_buffers[1], g_buffers[0], g_buffer_size);
    
    atomic_thread_fence(memory_order_release);
    atomic_store(&g_frame_ready, true);
    atomic_store(&g_copying, false);
}

/* Get buffer for display - always return buffer[1] */
bool libretro_get_display_buffer(uint32_t** buffer, int* width, int* height) {
    if (!g_buffers[1]) {
        *buffer = libretro_get_framebuffer();
        *width = g_libretro_context.width > 0 ? g_libretro_context.width : 240;
        *height = g_libretro_context.height > 0 ? g_libretro_context.height : 320;
        return true;
    }
    
    /* Wait for copy to complete if in progress */
    while (atomic_load(&g_copying)) {
        /* Busy wait */
    }
    
    atomic_thread_fence(memory_order_acquire);
    
    /* Always return display buffer[1] */
    *buffer = g_buffers[1];
    *width = g_buffer_width > 0 ? g_buffer_width : 240;
    *height = g_buffer_height > 0 ? g_buffer_height : 320;
    
    return true;
}

SdlContext* sdl_get_global_context(void) { return &g_libretro_context; }

void sdl_set_global_context(SdlContext* ctx) {
    if (ctx) {
        g_libretro_context = *ctx;
    } else {
        memset(&g_libretro_context, 0, sizeof(SdlContext));
    }
}

int sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {
    (void)headless; (void)scale;
    
    if (width <= 0 || height <= 0) {
        fprintf(stderr, "[J2ME] Invalid dimensions %dx%d, using defaults\n", width, height);
        width = 240;
        height = 320;
    }
    
    g_libretro_context.jvm = jvm;
    g_libretro_context.width = width;
    g_libretro_context.height = height;
    g_libretro_context.scale = 1;
    g_libretro_context.target_fps = 30;
    g_libretro_context.running = true;
    
    if (!init_buffers(width, height)) {
        uint32_t* fb = (uint32_t*)libretro_get_framebuffer();
        if (fb) {
            g_libretro_context.framebuffer = fb;
            fprintf(stderr, "[J2ME] Using single buffer fallback\n");
        } else {
            fprintf(stderr, "[J2ME] ERROR: No framebuffer available!\n");
        }
    }
    /* framebuffer already set to g_buffers[0] in init_buffers */
    
    return 0;
}

void sdl_destroy(SdlContext* ctx) {
    (void)ctx;
    for (int i = 0; i < BUFFER_COUNT; i++) {
        if (g_buffers[i]) free(g_buffers[i]);
        g_buffers[i] = NULL;
    }
    g_buffer_size = 0;
    fprintf(stderr, "[J2ME] Destroyed\n");
}

void sdl_run(SdlContext* ctx) { (void)ctx; }
void sdl_set_fullscreen(SdlContext* ctx, bool fullscreen) { (void)ctx; (void)fullscreen; }
uint64_t sdl_get_ticks(SdlContext* ctx) { (void)ctx; return 0; }
void sdl_delay(uint32_t ms) { (void)ms; }

/* Update screen - called multiple times during frame, DON'T swap here! */
void sdl_update_screen(SdlContext* ctx) {
    /* Do nothing here - we swap only in libretro_end_frame */
    (void)ctx;
}

void sdl_handle_events(SdlContext* ctx) { (void)ctx; }

bool sdl_key_pressed(SdlContext* ctx, int key) {
    (void)ctx;
    extern int libretro_get_key_states(void);
    int keys = libretro_get_key_states();
    
    switch (key) {
        case 1:  return (keys & (1 << 1)) != 0;
        case 6:  return (keys & (1 << 6)) != 0;
        case 2:  return (keys & (1 << 2)) != 0;
        case 5:  return (keys & (1 << 5)) != 0;
        case 8:  return (keys & (1 << 8)) != 0;
        case 9:  return (keys & (1 << 9)) != 0;
        case 10: return (keys & (1 << 10)) != 0;
        case 11: return (keys & (1 << 11)) != 0;
        case 12: return (keys & (1 << 12)) != 0;
        default: return false;
    }
}

MidpGraphics* sdl_get_graphics(SdlContext* ctx) { (void)ctx; return NULL; }
int sdl_audio_init_simple(uint32_t sample_rate) { (void)sample_rate; audio_buffer_init(); return 0; }

void sdl_audio_shutdown(void) {
    g_audio_initialized = false;
    g_audio_write_pos = 0;
    g_audio_read_pos = 0;
    g_audio_count = 0;
}

/* JAR resource loading */
uint8_t* load_jar_resource(const char* path, size_t* size) {
    if (size) *size = 0;
    if (!path) return NULL;
    extern JVM* g_jvm;
    if (!g_jvm || !g_jvm->class_loader.jar_data) return NULL;
    
    const uint8_t* jar_data = g_jvm->class_loader.jar_data;
    size_t jar_size = g_jvm->class_loader.jar_size;
    
    size_t eocd = 0;
    for (size_t i = jar_size - 22; i > 0; i--) {
        if (jar_data[i] == 0x50 && jar_data[i+1] == 0x4B &&
            jar_data[i+2] == 0x05 && jar_data[i+3] == 0x06) {
            eocd = i; break;
        }
    }
    if (eocd == 0) return NULL;
    
    uint32_t cd_start = jar_data[eocd + 16] | (jar_data[eocd + 17] << 8) |
                        (jar_data[eocd + 18] << 16) | (jar_data[eocd + 19] << 24);
    uint16_t cd_entries = jar_data[eocd + 10] | (jar_data[eocd + 11] << 8);
    
    size_t cde = cd_start;
    for (int i = 0; i < cd_entries && cde < eocd; i++) {
        uint32_t sig = jar_data[cde] | (jar_data[cde+1] << 8) |
                       (jar_data[cde+2] << 16) | (jar_data[cde+3] << 24);
        if (sig != 0x02014B50) break;
        
        uint16_t compression = jar_data[cde + 10] | (jar_data[cde + 11] << 8);
        uint32_t comp_size = jar_data[cde + 20] | (jar_data[cde + 21] << 8) |
                             (jar_data[cde + 22] << 16) | (jar_data[cde + 23] << 24);
        uint32_t uncomp_size = jar_data[cde + 24] | (jar_data[cde + 25] << 8) |
                               (jar_data[cde + 26] << 16) | (jar_data[cde + 27] << 24);
        uint16_t name_len = jar_data[cde + 28] | (jar_data[cde + 29] << 8);
        uint16_t extra_len = jar_data[cde + 30] | (jar_data[cde + 31] << 8);
        uint16_t comment_len = jar_data[cde + 32] | (jar_data[cde + 33] << 8);
        uint32_t local_off = jar_data[cde + 42] | (jar_data[cde + 43] << 8) |
                             (jar_data[cde + 44] << 16) | (jar_data[cde + 45] << 24);
        
        const char* name = (const char*)(jar_data + cde + 46);
        if (name_len == strlen(path) && memcmp(name, path, name_len) == 0) {
            uint16_t local_name_len = jar_data[local_off + 26] | (jar_data[local_off + 27] << 8);
            uint16_t local_extra_len = jar_data[local_off + 28] | (jar_data[local_off + 29] << 8);
            size_t data_off = local_off + 30 + local_name_len + local_extra_len;
            
            if (compression == 0) {
                *size = uncomp_size;
                uint8_t* data = (uint8_t*)malloc(*size);
                if (data) memcpy(data, jar_data + data_off, *size);
                return data;
            } else if (compression == 8) {
                uint8_t* data = (uint8_t*)malloc(uncomp_size);
                if (!data) return NULL;
                z_stream stream;
                memset(&stream, 0, sizeof(stream));
                if (inflateInit2(&stream, -MAX_WBITS) != Z_OK) { free(data); return NULL; }
                stream.next_in = (Bytef*)(jar_data + data_off);
                stream.avail_in = comp_size;
                stream.next_out = data;
                stream.avail_out = uncomp_size;
                if (inflate(&stream, Z_FINISH) != Z_STREAM_END) {
                    inflateEnd(&stream); free(data); return NULL;
                }
                inflateEnd(&stream);
                *size = uncomp_size;
                return data;
            }
        }
        cde += 46 + name_len + extra_len + comment_len;
    }
    return NULL;
}

void sdl_present(SdlContext* ctx) { (void)ctx; }

/* Stubs */
void sdl_request_redraw(void) { g_libretro_context.needs_redraw = true; }
bool sdl_needs_redraw(SdlContext* ctx) { return ctx ? ctx->needs_redraw : false; }
void sdl_clear_redraw(SdlContext* ctx) { if (ctx) ctx->needs_redraw = false; }
void sdl_process_events_minimal(void) {}
void sdl_update_texture(SdlContext* ctx) { (void)ctx; }

void sdl_clear(SdlContext* ctx, uint32_t color) {
    if (!ctx || !ctx->framebuffer) return;
    int size = ctx->width * ctx->height;
    for (int i = 0; i < size; i++) ctx->framebuffer[i] = color;
}

int sdl_resize(SdlContext* ctx, int width, int height) { (void)ctx; (void)width; (void)height; return 0; }
int sdl_screenshot(SdlContext* ctx, const char* filename) { (void)ctx; (void)filename; return -1; }
void sdl_frame_end(SdlContext* ctx) { (void)ctx; }
void sdl_sleep(uint32_t ms) { (void)ms; }
void sdl_set_title(SdlContext* ctx, const char* title) { (void)ctx; (void)title; }
void sdl_toggle_fullscreen(SdlContext* ctx) { (void)ctx; }
void sdl_get_window_size(SdlContext* ctx, int* width, int* height) {
    if (width && ctx) *width = ctx->width;
    if (height && ctx) *height = ctx->height;
}
void sdl_stop(SdlContext* ctx) { if (ctx) ctx->running = false; }
MidpPlatformCallbacks* sdl_get_platform_callbacks(SdlContext* ctx) { (void)ctx; return NULL; }
bool sdl_is_screen_graphics(MidpGraphics* gfx) { (void)gfx; return true; }
int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
    (void)ctx; (void)frequency; (void)channels; (void)samples; audio_buffer_init(); return 0;
}
int sdl_audio_queue(SdlContext* ctx, const void* data, size_t length) { (void)ctx; (void)data; (void)length; return 0; }
uint32_t sdl_audio_queued_size(SdlContext* ctx) { (void)ctx; return (uint32_t)g_audio_count; }
void sdl_audio_clear(SdlContext* ctx) { (void)ctx; g_audio_read_pos = 0; g_audio_write_pos = 0; g_audio_count = 0; }
void sdl_process_events(SdlContext* ctx) { (void)ctx; }
int sdl_key_to_midp(int sdl_key) { (void)sdl_key; return 0; }
int sdl_key_to_game_action(int sdl_key) { (void)sdl_key; return 0; }
void sdl_get_pointer(SdlContext* ctx, int* x, int* y) { if (x) *x = 0; if (y) *y = 0; (void)ctx; }
bool sdl_pointer_pressed(SdlContext* ctx) { (void)ctx; return false; }
void sdl_dump_info(SdlContext* ctx) { (void)ctx; }

int g_j2me_runtime_debug = 0;
void sdl_save_framebuffer_to_file(SdlContext* ctx, const char* filename) { (void)ctx; (void)filename; }
