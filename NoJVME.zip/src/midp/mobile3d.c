/*
 * J2ME Emulator - JSR 184 Mobile 3D Graphics API (Software Implementation)
 * 
 * This implements the M3G (Mobile 3D Graphics) API in pure software mode.
 * JSR 184 provides a retained-mode 3D graphics API for mobile devices.
 * 
 * Implemented features:
 * - Graphics3D rendering context
 * - Transform (4x4 matrix operations)
 * - VertexArray (vertex data storage)
 * - IndexBuffer (triangle indices)
 * - Mesh (renderable 3D objects)
 * - Camera (view/projection)
 * - Light (directional, point, spot)
 * - Material and Texture2D
 * - Background
 * - World (scene graph)
 * - Software rasterization with Z-buffer
 */

#ifndef _WIN32
#define _POSIX_C_SOURCE 200809L  /* For strdup */
#endif

#include <stdio.h>
#include "debug.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#include "jvm.h"
#include "native.h"
#include "heap.h"
#include "opcodes.h"  /* For T_* array type constants */
#include "midp.h"     /* For load_jar_resource */

/* Light types from JSR-184 */
#define M3G_LIGHT_AMBIENT       1
#define M3G_LIGHT_DIRECTIONAL   2  
#define M3G_LIGHT_OMNI          4
#define M3G_LIGHT_SPOT          8

/* ============================================================================
 * HELPER FUNCTIONS FOR FIELD ACCESS
 * ============================================================================ */

/* Find the slot index for a named field in an object.
 * This correctly traverses the class hierarchy from Object down to the actual class,
 * calculating the cumulative slot index for instance fields.
 * Returns -1 if field not found. */
static int m3g_find_field_slot(JavaObject* obj, const char* field_name) {
    if (!obj || !field_name) return -1;
    
    JavaClass* clazz = obj->header.clazz;
    if (!clazz) return -1;
    
    /* Build class hierarchy from Object to actual class */
    JavaClass* hierarchy[64];
    int depth = 0;
    JavaClass* c = clazz;
    while (c && depth < 64) {
        hierarchy[depth++] = c;
        c = c->super_class;
    }
    
    /* Search for field and calculate slot from Object down to actual class */
    int slot = 0;
    for (int h = depth - 1; h >= 0; h--) {
        JavaClass* current = hierarchy[h];
        if (!current->fields) continue;
        
        for (int i = 0; i < current->fields_count; i++) {
            JavaField* field = &current->fields[i];
            
            /* Skip static fields */
            if (field->access_flags & ACC_STATIC) continue;
            
            if (field->name && strcmp(field->name, field_name) == 0) {
                return slot;
            }
            
            slot++;
            /* Long and double take 2 slots */
            if (field->descriptor && 
                (field->descriptor[0] == 'J' || field->descriptor[0] == 'D')) {
                slot++;
            }
        }
    }
    
    return -1;  /* Field not found */
}

/* Helper to get an int field value by name */
static jint m3g_get_int_field(JavaObject* obj, const char* field_name, jint default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].i;
    }
    return default_val;
}

/* Helper to set an int field value by name */
static void m3g_set_int_field(JavaObject* obj, const char* field_name, jint value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].i = value;
    }
}

/* Helper to get a float field value by name */
static jfloat m3g_get_float_field(JavaObject* obj, const char* field_name, jfloat default_val) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return obj->fields[slot].f;
    }
    return default_val;
}

/* Helper to set a float field value by name */
static void m3g_set_float_field(JavaObject* obj, const char* field_name, jfloat value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].f = value;
    }
}

/* Helper to get a reference field value by name */
static JavaObject* m3g_get_ref_field(JavaObject* obj, const char* field_name) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        return (JavaObject*)obj->fields[slot].ref;
    }
    return NULL;
}

/* Helper to set a reference field value by name */
static void m3g_set_ref_field(JavaObject* obj, const char* field_name, JavaObject* value) {
    int slot = m3g_find_field_slot(obj, field_name);
    if (slot >= 0) {
        obj->fields[slot].ref = value;
    }
}

/* ============================================================================
 * M3G Constants (from JSR 184 specification)
 * ============================================================================ */

/* Light types */
#define M3G_LIGHT_AMBIENT       1
#define M3G_LIGHT_DIRECTIONAL   2
#define M3G_LIGHT_OMNI          4
#define M3G_LIGHT_SPOT          8

/* Material components */
#define M3G_MATERIAL_AMBIENT    1
#define M3G_MATERIAL_DIFFUSE    2
#define M3G_MATERIAL_EMISSIVE   4
#define M3G_MATERIAL_SPECULAR   8

/* Rendering hints */
#define M3G_ANTIALIAS           1
#define M3G_DITHER              2
#define M3G_TRUE_COLOR          4

/* Compositing modes */
#define M3G_ALPHA_BLEND         64
#define M3G_ALPHA_ADDITIVE      65
#define M3G_ALPHA_MULTIPLY      66
#define M3G_ALPHA_REPLACE       67

/* Polygon modes */
#define M3G_POLYGON_MODE_SOLID          64
#define M3G_POLYGON_MODE_WIREFRAME      65
#define M3G_POLYGON_MODE_POINT          66
#define M3G_POLYGON_MODE_POINT_SPRITE   67

/* Crop modes */
#define M3G_CROP_CENTER        96
#define M3G_CROP_STRETCH       97
#define M3G_CROP_FILL          98

/* Maximum dimensions for Image2D and render targets to prevent OOM.
 * J2ME M3G typically supports 256x256 or 512x512 textures.
 * Allow up to 1024x1024 for compatibility with newer devices. */
#define M3G_MAX_IMAGE_DIMENSION 1024
#define M3G_MAX_IMAGE_PIXELS (M3G_MAX_IMAGE_DIMENSION * M3G_MAX_IMAGE_DIMENSION)

/* Maximum vertex count for VertexArray to prevent OOM */
#define M3G_MAX_VERTEX_COUNT 65536
#define M3G_MAX_INDEX_COUNT  65536

/* ============================================================================
 * M3G Internal Data Structures
 * ============================================================================ */

/* 4x4 Transformation Matrix (column-major, OpenGL style) */
typedef struct {
    float m[16];  /* Column-major: m[col*4+row] */
} M3GTransform;

/* Vertex data */
typedef struct {
    float* positions;     /* XYZ positions */
    float* normals;       /* XYZ normals (optional) */
    float* texcoords;     /* UV coordinates (optional) */
    uint8_t* colors;      /* RGBA colors (optional) */
    int vertex_count;
    int vertex_stride;    /* Components per vertex */
} M3GVertexArray;

/* Triangle indices */
typedef struct {
    uint16_t* indices;
    int index_count;
    int primitive_type;   /* TRIANGLES=4, LINES=3, POINTS=2 */
} M3GIndexBuffer;

/* Material properties */
typedef struct {
    float ambient[4];     /* RGBA */
    float diffuse[4];
    float specular[4];
    float emissive[4];
    float shininess;
} M3GMaterial;

/* Texture data */
typedef struct {
    uint32_t* pixels;     /* ARGB pixels */
    int width;
    int height;
    int blend_s, blend_t; /* Wrapping mode */
    int filter_level;
} M3GTexture2D;

/* Light source */
typedef struct {
    int type;             /* AMBIENT, DIRECTIONAL, OMNI, SPOT */
    float color[4];       /* RGBA intensity */
    float direction[4];   /* For directional/spot */
    float position[4];    /* For omni/spot */
    float attenuation[3]; /* Constant, linear, quadratic */
    float spot_angle;     /* Spot cone angle */
    float spot_exponent;
} M3GLight;

/* Appearance state */
typedef struct {
    M3GMaterial* material;
    M3GTexture2D* texture;
    int compositing_mode;
    int polygon_mode;
    int layer;
} M3GAppearance;

/* Mesh object */
typedef struct {
    M3GVertexArray* vertices;
    M3GIndexBuffer* indices;
    M3GAppearance* appearance;
    int submesh_count;
} M3GMesh;

/* Camera */
typedef struct {
    float position[3];
    float look_at[3];
    float up[3];
    float fov;            /* Field of view in degrees */
    float aspect;         /* Width / Height */
    float near_plane;
    float far_plane;
    int projection_type;  /* 0=perspective, 1=parallel */
} M3GCamera;

/* Render buffer pool for object reuse - avoids per-frame allocations */
#define M3G_VERTEX_POOL_SIZE (64 * 1024)  /* 64K floats = ~21K vertices */
#define M3G_INDEX_POOL_SIZE (32 * 1024)   /* 32K indices */

typedef struct {
    float* vertex_pool;
    size_t vertex_pool_capacity;  /* in floats */
    size_t vertex_pool_used;
    
    uint16_t* index_pool;
    size_t index_pool_capacity;  /* in indices */
    size_t index_pool_used;
    
    int initialized;
} M3GRenderPool;

/* Rendering context */
typedef struct {
    /* Viewport */
    int viewport_x, viewport_y;
    int viewport_width, viewport_height;
    
    /* Target buffer */
    uint32_t* color_buffer;
    float* depth_buffer;
    int buffer_width, buffer_height;
    int buffers_allocated;  /* Track if buffers are allocated */
    
    /* Target Image2D object for releaseTarget */
    JavaObject* target_image;
    
    /* Current transformation */
    M3GTransform modelview;
    M3GTransform projection;
    M3GTransform mvp;     /* ModelView * Projection */
    
    /* Lights (max 8) */
    M3GLight lights[8];
    int light_count;
    
    /* Global ambient */
    float ambient_light[4];
    
    /* Render states */
    int depth_test_enabled;
    int depth_write_enabled;
    int blending_enabled;
    int culling_enabled;    /* Back-face culling */
    
    /* Render buffer pool */
    M3GRenderPool render_pool;
    
    /* Statistics */
    int triangles_rendered;
    int vertices_processed;
} M3GContext;

/* Global M3G context */
static M3GContext g_m3g;

/* ============================================================================
 * M3G Math Functions
 * ============================================================================ */

/* Create identity matrix */
static void m3g_transform_identity(M3GTransform* t) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 1.0f;   t->m[5] = 1.0f;   t->m[10] = 1.0f;  t->m[15] = 1.0f;
}

/* Multiply two matrices: result = a * b */
static void m3g_transform_multiply(M3GTransform* result, 
                                    const M3GTransform* a, 
                                    const M3GTransform* b) {
    float r[16];
    for (int col = 0; col < 4; col++) {
        for (int row = 0; row < 4; row++) {
            float sum = 0.0f;
            for (int k = 0; k < 4; k++) {
                sum += a->m[k * 4 + row] * b->m[col * 4 + k];
            }
            r[col * 4 + row] = sum;
        }
    }
    memcpy(result->m, r, sizeof(r));
}

/* Translate */
static void m3g_transform_translate(M3GTransform* t, float x, float y, float z) {
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = x;  trans.m[13] = y;  trans.m[14] = z;
    m3g_transform_multiply(t, t, &trans);
}

/* Scale */
static void m3g_transform_scale(M3GTransform* t, float x, float y, float z) {
    M3GTransform scale;
    m3g_transform_identity(&scale);
    scale.m[0] = x;  scale.m[5] = y;  scale.m[10] = z;
    m3g_transform_multiply(t, t, &scale);
}

/* Rotate around axis (angle in radians) */
static void m3g_transform_rotate(M3GTransform* t, float angle, 
                                  float ax, float ay, float az) {
    /* Normalize axis */
    float len = sqrtf(ax*ax + ay*ay + az*az);
    if (len < 0.0001f) return;
    ax /= len;  ay /= len;  az /= len;
    
    float c = cosf(angle);
    float s = sinf(angle);
    float omc = 1.0f - c;
    
    M3GTransform rot;
    m3g_transform_identity(&rot);
    
    rot.m[0] = ax*ax*omc + c;
    rot.m[1] = ax*ay*omc + az*s;
    rot.m[2] = ax*az*omc - ay*s;
    
    rot.m[4] = ax*ay*omc - az*s;
    rot.m[5] = ay*ay*omc + c;
    rot.m[6] = ay*az*omc + ax*s;
    
    rot.m[8] = ax*az*omc + ay*s;
    rot.m[9] = ay*az*omc - ax*s;
    rot.m[10] = az*az*omc + c;
    
    m3g_transform_multiply(t, t, &rot);
}

/* Set perspective projection */
static void m3g_transform_perspective(M3GTransform* t, float fov, 
                                       float aspect, float near, float far) {
    float f = 1.0f / tanf(fov * 3.14159f / 360.0f);
    float range = 1.0f / (near - far);
    
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = f / aspect;
    t->m[5] = f;
    t->m[10] = (near + far) * range;
    t->m[11] = -1.0f;
    t->m[14] = 2.0f * near * far * range;
}

/* Set orthographic projection */
static void m3g_transform_ortho(M3GTransform* t, float left, float right,
                                 float bottom, float top, float near, float far) {
    memset(t->m, 0, sizeof(t->m));
    t->m[0] = 2.0f / (right - left);
    t->m[5] = 2.0f / (top - bottom);
    t->m[10] = 2.0f / (near - far);
    t->m[12] = -(right + left) / (right - left);
    t->m[13] = -(top + bottom) / (top - bottom);
    t->m[14] = (near + far) / (near - far);
    t->m[15] = 1.0f;
}

/* Set look-at matrix */
static void m3g_transform_look_at(M3GTransform* t,
                                   float eye_x, float eye_y, float eye_z,
                                   float at_x, float at_y, float at_z,
                                   float up_x, float up_y, float up_z) {
    /* Forward vector (Z) */
    float fx = at_x - eye_x;
    float fy = at_y - eye_y;
    float fz = at_z - eye_z;
    float flen = sqrtf(fx*fx + fy*fy + fz*fz);
    fx /= flen; fy /= flen; fz /= flen;
    
    /* Side vector (X) = forward x up */
    float sx = fy * up_z - fz * up_y;
    float sy = fz * up_x - fx * up_z;
    float sz = fx * up_y - fy * up_x;
    float slen = sqrtf(sx*sx + sy*sy + sz*sz);
    sx /= slen; sy /= slen; sz /= slen;
    
    /* Recalculate up (Y) = side x forward */
    float ux = sy * fz - sz * fy;
    float uy = sz * fx - sx * fz;
    float uz = sx * fy - sy * fx;
    
    /* Build rotation matrix */
    t->m[0] = sx;   t->m[4] = ux;   t->m[8]  = -fx;  t->m[12] = 0;
    t->m[1] = sy;   t->m[5] = uy;   t->m[9]  = -fy;  t->m[13] = 0;
    t->m[2] = sz;   t->m[6] = uz;   t->m[10] = -fz;  t->m[14] = 0;
    t->m[3] = 0;    t->m[7] = 0;    t->m[11] = 0;    t->m[15] = 1;
    
    /* Apply translation */
    M3GTransform trans;
    m3g_transform_identity(&trans);
    trans.m[12] = -eye_x;
    trans.m[13] = -eye_y;
    trans.m[14] = -eye_z;
    m3g_transform_multiply(t, t, &trans);
}

/* Transform a point by matrix */
static void m3g_transform_point(float* result, const M3GTransform* t, 
                                 const float* point) {
    float x = point[0], y = point[1], z = point[2], w = point[3];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
    result[3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
}

/* Transform a vector (no translation) */
static void m3g_transform_vector(float* result, const M3GTransform* t,
                                  const float* vec) {
    float x = vec[0], y = vec[1], z = vec[2];
    result[0] = t->m[0]*x + t->m[4]*y + t->m[8]*z;
    result[1] = t->m[1]*x + t->m[5]*y + t->m[9]*z;
    result[2] = t->m[2]*x + t->m[6]*y + t->m[10]*z;
}

/* Vector operations */
static void m3g_vec3_normalize(float* v) {
    float len = sqrtf(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    if (len > 0.0001f) {
        v[0] /= len; v[1] /= len; v[2] /= len;
    }
}

static void m3g_vec3_cross(float* result, const float* a, const float* b) {
    result[0] = a[1]*b[2] - a[2]*b[1];
    result[1] = a[2]*b[0] - a[0]*b[2];
    result[2] = a[0]*b[1] - a[1]*b[0];
}

static float m3g_vec3_dot(const float* a, const float* b) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

/* ============================================================================
 * M3G Software Rasterizer
 * ============================================================================ */

/* Free existing context buffers - call before reinitializing */
static void m3g_context_free_buffers(void) {
    if (g_m3g.color_buffer) {
        free(g_m3g.color_buffer);
        g_m3g.color_buffer = NULL;
    }
    if (g_m3g.depth_buffer) {
        free(g_m3g.depth_buffer);
        g_m3g.depth_buffer = NULL;
    }
    g_m3g.buffers_allocated = 0;
}

/* Initialize render pool for object reuse */
static void m3g_render_pool_init(void) {
    if (g_m3g.render_pool.initialized) {
        return;  /* Already initialized */
    }
    
    g_m3g.render_pool.vertex_pool = (float*)malloc(M3G_VERTEX_POOL_SIZE * sizeof(float));
    g_m3g.render_pool.vertex_pool_capacity = g_m3g.render_pool.vertex_pool ? M3G_VERTEX_POOL_SIZE : 0;
    g_m3g.render_pool.vertex_pool_used = 0;
    
    g_m3g.render_pool.index_pool = (uint16_t*)malloc(M3G_INDEX_POOL_SIZE * sizeof(uint16_t));
    g_m3g.render_pool.index_pool_capacity = g_m3g.render_pool.index_pool ? M3G_INDEX_POOL_SIZE : 0;
    g_m3g.render_pool.index_pool_used = 0;
    
    g_m3g.render_pool.initialized = 1;
    GFX_DEBUG("Render pool initialized: vertices=%zu, indices=%zu", 
             g_m3g.render_pool.vertex_pool_capacity, g_m3g.render_pool.index_pool_capacity);
}

/* Reset render pool for new frame */
static void m3g_render_pool_reset(void) {
    g_m3g.render_pool.vertex_pool_used = 0;
    g_m3g.render_pool.index_pool_used = 0;
}

/* Allocate from vertex pool (returns NULL if pool exhausted) */
static float* m3g_render_pool_alloc_vertices(size_t count) {
    if (g_m3g.render_pool.vertex_pool_used + count > g_m3g.render_pool.vertex_pool_capacity) {
        GFX_DEBUG("Vertex pool exhausted: need %zu, have %zu", 
                 count, g_m3g.render_pool.vertex_pool_capacity - g_m3g.render_pool.vertex_pool_used);
        return NULL;
    }
    float* ptr = g_m3g.render_pool.vertex_pool + g_m3g.render_pool.vertex_pool_used;
    g_m3g.render_pool.vertex_pool_used += count;
    return ptr;
}

/* Allocate from index pool (returns NULL if pool exhausted) */
static uint16_t* m3g_render_pool_alloc_indices(size_t count) {
    if (g_m3g.render_pool.index_pool_used + count > g_m3g.render_pool.index_pool_capacity) {
        GFX_DEBUG("Index pool exhausted: need %zu, have %zu", 
                 count, g_m3g.render_pool.index_pool_capacity - g_m3g.render_pool.index_pool_used);
        return NULL;
    }
    uint16_t* ptr = g_m3g.render_pool.index_pool + g_m3g.render_pool.index_pool_used;
    g_m3g.render_pool.index_pool_used += count;
    return ptr;
}

/* Initialize M3G context */
static void m3g_context_init(int width, int height) {
    /* FIX: Free existing buffers before allocating new ones to prevent memory leak */
    m3g_context_free_buffers();
    
    /* Preserve render pool and other state across reinit */
    M3GRenderPool saved_pool = g_m3g.render_pool;
    
    memset(&g_m3g, 0, sizeof(g_m3g));
    
    /* Restore render pool */
    g_m3g.render_pool = saved_pool;
    
    g_m3g.buffer_width = width;
    g_m3g.buffer_height = height;
    g_m3g.viewport_width = width;
    g_m3g.viewport_height = height;
    
    g_m3g.color_buffer = (uint32_t*)calloc(width * height, sizeof(uint32_t));
    g_m3g.depth_buffer = (float*)calloc(width * height, sizeof(float));
    
    if (g_m3g.color_buffer && g_m3g.depth_buffer) {
        g_m3g.buffers_allocated = 1;
    }
    
    /* Initialize transforms */
    m3g_transform_identity(&g_m3g.modelview);
    m3g_transform_identity(&g_m3g.projection);
    m3g_transform_identity(&g_m3g.mvp);
    
    /* Default render state */
    g_m3g.depth_test_enabled = 1;
    g_m3g.depth_write_enabled = 1;
    g_m3g.culling_enabled = 1;
    
    /* Default ambient */
    g_m3g.ambient_light[0] = 0.2f;
    g_m3g.ambient_light[1] = 0.2f;
    g_m3g.ambient_light[2] = 0.2f;
    g_m3g.ambient_light[3] = 1.0f;
    
    /* Initialize render pool if not already done */
    m3g_render_pool_init();
    
    GFX_DEBUG("Context initialized: %dx%d, buffers=%d", width, height, g_m3g.buffers_allocated);
}

/* Clear buffers */
static void m3g_clear(float r, float g, float b, float a, float depth) {
    uint32_t color = ((uint32_t)(a * 255) << 24) |
                     ((uint32_t)(r * 255) << 16) |
                     ((uint32_t)(g * 255) << 8) |
                     ((uint32_t)(b * 255));
    
    for (int i = 0; i < g_m3g.buffer_width * g_m3g.buffer_height; i++) {
        g_m3g.color_buffer[i] = color;
        g_m3g.depth_buffer[i] = depth;
    }
}

/* Convert clip coordinates to screen coordinates */
static void m3g_clip_to_screen(float* screen, const float* clip) {
    /* Perspective divide */
    float w = clip[3];
    if (fabsf(w) < 0.0001f) w = 0.0001f;
    
    float ndc_x = clip[0] / w;
    float ndc_y = clip[1] / w;
    float ndc_z = clip[2] / w;
    
    /* NDC to screen */
    screen[0] = (ndc_x + 1.0f) * 0.5f * g_m3g.viewport_width + g_m3g.viewport_x;
    screen[1] = (1.0f - ndc_y) * 0.5f * g_m3g.viewport_height + g_m3g.viewport_y;  /* Y-flip */
    screen[2] = (ndc_z + 1.0f) * 0.5f;  /* Depth to [0,1] */
    screen[3] = 1.0f / w;  /* 1/w for perspective correction */
}

/* Edge function for triangle rasterization */
static inline float m3g_edge_function(const float* a, const float* b, const float* c) {
    return (c[0] - a[0]) * (b[1] - a[1]) - (c[1] - a[1]) * (b[0] - a[0]);
}

/* Compute barycentric coordinates */
static void m3g_barycentric(float* bary, const float* v0, const float* v1, 
                            const float* v2, float x, float y) {
    float area = m3g_edge_function(v0, v1, v2);
    if (fabsf(area) < 0.0001f) {
        bary[0] = bary[1] = bary[2] = 0;
        return;
    }
    
    float p[2] = {x, y};
    bary[0] = m3g_edge_function(v1, v2, p) / area;
    bary[1] = m3g_edge_function(v2, v0, p) / area;
    bary[2] = m3g_edge_function(v0, v1, p) / area;
}

/* Simple color interpolation */
static void m3g_interpolate_color(uint8_t* result, 
                                   const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                   float w0, float w1, float w2) {
    for (int i = 0; i < 4; i++) {
        result[i] = (uint8_t)(c0[i] * w0 + c1[i] * w1 + c2[i] * w2);
    }
}

/* Interpolate texture coordinates */
static void m3g_interpolate_texcoord(float* result,
                                      const float* t0, const float* t1, const float* t2,
                                      float w0, float w1, float w2, float one_over_w) {
    /* Perspective-correct interpolation */
    float u = (t0[0] * w0 + t1[0] * w1 + t2[0] * w2) * one_over_w;
    float v = (t0[1] * w0 + t1[1] * w1 + t2[1] * w2) * one_over_w;
    result[0] = u;
    result[1] = v;
}

/* Sample texture (bilinear filtering) */
static uint32_t m3g_sample_texture(M3GTexture2D* tex, float u, float v) {
    if (!tex || !tex->pixels) return 0xFFFFFFFF;
    
    /* Wrap coordinates */
    u = u - floorf(u);
    v = v - floorf(v);
    if (u < 0) u += 1.0f;
    if (v < 0) v += 1.0f;
    
    /* Nearest neighbor (simple version) */
    int x = (int)(u * tex->width) % tex->width;
    int y = (int)(v * tex->height) % tex->height;
    if (x < 0) x += tex->width;
    if (y < 0) y += tex->height;
    
    return tex->pixels[y * tex->width + x];
}

/* Apply lighting to a vertex */
static void m3g_light_vertex(float* result, const float* position, 
                              const float* normal, M3GMaterial* mat) {
    /* Start with ambient */
    result[0] = g_m3g.ambient_light[0] * mat->ambient[0] + mat->emissive[0];
    result[1] = g_m3g.ambient_light[1] * mat->ambient[1] + mat->emissive[1];
    result[2] = g_m3g.ambient_light[2] * mat->ambient[2] + mat->emissive[2];
    
    float N[3] = {normal[0], normal[1], normal[2]};
    m3g_vec3_normalize(N);
    
    /* Process each light */
    for (int i = 0; i < g_m3g.light_count; i++) {
        M3GLight* light = &g_m3g.lights[i];
        
        float L[3];  /* Light direction */
        float attenuation = 1.0f;
        
        if (light->type == M3G_LIGHT_DIRECTIONAL) {
            L[0] = -light->direction[0];
            L[1] = -light->direction[1];
            L[2] = -light->direction[2];
        } else if (light->type == M3G_LIGHT_OMNI) {
            L[0] = light->position[0] - position[0];
            L[1] = light->position[1] - position[1];
            L[2] = light->position[2] - position[2];
            float dist = sqrtf(L[0]*L[0] + L[1]*L[1] + L[2]*L[2]);
            if (dist > 0.0001f) {
                L[0] /= dist; L[1] /= dist; L[2] /= dist;
            }
            attenuation = 1.0f / (light->attenuation[0] + 
                                  light->attenuation[1] * dist +
                                  light->attenuation[2] * dist * dist);
        } else {
            continue;  /* Skip unsupported light types */
        }
        
        /* Diffuse */
        float NdotL = m3g_vec3_dot(N, L);
        if (NdotL > 0) {
            result[0] += light->color[0] * mat->diffuse[0] * NdotL * attenuation;
            result[1] += light->color[1] * mat->diffuse[1] * NdotL * attenuation;
            result[2] += light->color[2] * mat->diffuse[2] * NdotL * attenuation;
        }
        
        /* Specular (simplified) */
        float V[3] = {0, 0, 1};  /* View direction (assumed) */
        float H[3];  /* Half vector */
        H[0] = L[0] + V[0];
        H[1] = L[1] + V[1];
        H[2] = L[2] + V[2];
        m3g_vec3_normalize(H);
        
        float NdotH = m3g_vec3_dot(N, H);
        if (NdotH > 0) {
            float spec = powf(NdotH, mat->shininess);
            result[0] += light->color[0] * mat->specular[0] * spec * attenuation;
            result[1] += light->color[1] * mat->specular[1] * spec * attenuation;
            result[2] += light->color[2] * mat->specular[2] * spec * attenuation;
        }
    }
    
    /* Clamp */
    result[0] = result[0] > 1.0f ? 1.0f : result[0];
    result[1] = result[1] > 1.0f ? 1.0f : result[1];
    result[2] = result[2] > 1.0f ? 1.0f : result[2];
}

/* Rasterize a single triangle */
static void m3g_rasterize_triangle(const float* v0, const float* v1, const float* v2,
                                    const float* t0, const float* t1, const float* t2,
                                    const uint8_t* c0, const uint8_t* c1, const uint8_t* c2,
                                    M3GAppearance* appearance) {
    /* Screen coordinates */
    float s0[4], s1[4], s2[4];
    m3g_clip_to_screen(s0, v0);
    m3g_clip_to_screen(s1, v1);
    m3g_clip_to_screen(s2, v2);
    
    /* Skip triangles outside viewport */
    if (s0[2] < 0 && s1[2] < 0 && s2[2] < 0) return;
    if (s0[2] > 1 && s1[2] > 1 && s2[2] > 1) return;
    
    /* Back-face culling */
    if (g_m3g.culling_enabled) {
        float e = m3g_edge_function(s0, s1, s2);
        if (e < 0) return;  /* Back-facing */
    }
    
    /* Bounding box */
    int min_x = (int)(s0[0] < s1[0] ? (s0[0] < s2[0] ? s0[0] : s2[0]) : (s1[0] < s2[0] ? s1[0] : s2[0]));
    int max_x = (int)(s0[0] > s1[0] ? (s0[0] > s2[0] ? s0[0] : s2[0]) : (s1[0] > s2[0] ? s1[0] : s2[0]));
    int min_y = (int)(s0[1] < s1[1] ? (s0[1] < s2[1] ? s0[1] : s2[1]) : (s1[1] < s2[1] ? s1[1] : s2[1]));
    int max_y = (int)(s0[1] > s1[1] ? (s0[1] > s2[1] ? s0[1] : s2[1]) : (s1[1] > s2[1] ? s1[1] : s2[1]));
    
    /* Clip to viewport */
    min_x = min_x < 0 ? 0 : min_x;
    max_x = max_x >= g_m3g.buffer_width ? g_m3g.buffer_width - 1 : max_x;
    min_y = min_y < 0 ? 0 : min_y;
    max_y = max_y >= g_m3g.buffer_height ? g_m3g.buffer_height - 1 : max_y;
    
    /* Area for barycentric */
    float area = m3g_edge_function(s0, s1, s2);
    if (fabsf(area) < 0.001f) return;
    
    /* Rasterize */
    for (int y = min_y; y <= max_y; y++) {
        for (int x = min_x; x <= max_x; x++) {
            float px = x + 0.5f;
            float py = y + 0.5f;
            
            /* Barycentric coordinates */
            float w0 = m3g_edge_function(s1, s2, (float[]){px, py}) / area;
            float w1 = m3g_edge_function(s2, s0, (float[]){px, py}) / area;
            float w2 = m3g_edge_function(s0, s1, (float[]){px, py}) / area;
            
            /* Inside triangle? */
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            
            /* Depth test */
            float z = s0[2] * w0 + s1[2] * w1 + s2[2] * w2;
            int idx = y * g_m3g.buffer_width + x;
            
            if (g_m3g.depth_test_enabled && z > g_m3g.depth_buffer[idx]) {
                continue;  /* Failed depth test */
            }
            
            /* Perspective correction */
            float one_over_w = s0[3] * w0 + s1[3] * w1 + s2[3] * w2;
            
            /* Interpolate color */
            uint8_t color[4] = {255, 255, 255, 255};
            if (c0 && c1 && c2) {
                m3g_interpolate_color(color, c0, c1, c2, w0, w1, w2);
            }
            
            /* Texture sampling */
            if (appearance && appearance->texture && t0 && t1 && t2) {
                float uv[2];
                m3g_interpolate_texcoord(uv, t0, t1, t2, w0, w1, w2, one_over_w);
                uint32_t tex_color = m3g_sample_texture(appearance->texture, uv[0], uv[1]);
                
                /* Modulate with vertex color */
                uint8_t tr = (tex_color >> 16) & 0xFF;
                uint8_t tg = (tex_color >> 8) & 0xFF;
                uint8_t tb = tex_color & 0xFF;
                uint8_t ta = (tex_color >> 24) & 0xFF;
                
                color[0] = (uint8_t)(color[0] * tr / 255);
                color[1] = (uint8_t)(color[1] * tg / 255);
                color[2] = (uint8_t)(color[2] * tb / 255);
                color[3] = (uint8_t)(color[3] * ta / 255);
            }
            
            /* Write to buffers */
            g_m3g.color_buffer[idx] = (color[3] << 24) | (color[0] << 16) | 
                                       (color[1] << 8) | color[2];
            if (g_m3g.depth_write_enabled) {
                g_m3g.depth_buffer[idx] = z;
            }
        }
    }
    
    g_m3g.triangles_rendered++;
}

/* ============================================================================
 * Java Object <-> Native Object Mapping
 * ============================================================================ */

/* Get native transform from Java Transform object */
static M3GTransform* get_native_transform(JavaObject* obj) {
    if (!obj) return NULL;
    
    /* Ensure object has fields */
    if (!OBJECT_HAS_FIELDS(obj, 1)) return NULL;
    
    /* Transform stores 16 floats in a float[] field */
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    if (!arr) return NULL;
    if (arr->element_type != T_FLOAT || arr->length < 16) return NULL;
    
    /* We'll create a temp transform - for real use, cache it */
    static M3GTransform temp;
    float* data = (float*)array_data(arr);
    memcpy(temp.m, data, 16 * sizeof(float));
    return &temp;
}

/* Set native transform to Java Transform object */
static void set_native_transform(JavaObject* obj, M3GTransform* t) {
    if (!obj || !t) return;
    
    /* Ensure object has fields */
    if (!OBJECT_HAS_FIELDS(obj, 1)) return;
    
    JavaArray* arr = (JavaArray*)obj->fields[0].ref;
    
    /* If no array exists, we cannot set - caller should ensure array exists */
    if (!arr) return;
    
    if (arr->element_type != T_FLOAT || arr->length < 16) return;
    
    float* data = (float*)array_data(arr);
    memcpy(data, t->m, 16 * sizeof(float));
}

/* Get VertexArray data */
static M3GVertexArray* get_vertex_array(JavaObject* obj, M3GVertexArray* temp) {
    if (!obj || !temp) return NULL;
    
    memset(temp, 0, sizeof(M3GVertexArray));
    
    /* VertexArray fields: data (byte[]/short[]), componentCount, componentSize, count */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_count = m3g_get_int_field(obj, "componentCount", 3);
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    int vertex_count = m3g_get_int_field(obj, "vertexCount", 0);
    
    if (!data || vertex_count <= 0) return NULL;
    
    /* Sanity checks to prevent OOM */
    if (vertex_count > M3G_MAX_VERTEX_COUNT) {
        GFX_DEBUG("get_vertex_array: vertex_count %d exceeds max %d", vertex_count, M3G_MAX_VERTEX_COUNT);
        return NULL;
    }
    if (component_count > 4 || component_count < 2) {
        GFX_DEBUG("get_vertex_array: invalid component_count %d", component_count);
        return NULL;
    }
    
    /* Convert to float positions */
    temp->positions = (float*)malloc(vertex_count * 3 * sizeof(float));
    if (!temp->positions) return NULL;
    
    temp->vertex_count = vertex_count;
    temp->vertex_stride = component_count;
    
    if (component_size == 1) {
        int8_t* src = (int8_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    } else {
        int16_t* src = (int16_t*)array_data(data);
        for (int i = 0; i < vertex_count * component_count; i++) {
            temp->positions[i] = (float)src[i];
        }
    }
    
    return temp;
}

/* ============================================================================
 * Native Method Implementations
 * ============================================================================ */

/* Graphics3D.getInstance() */
static JavaValue native_graphics3d_getInstance(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)args; (void)arg_count;
    
    /* Find Graphics3D class */
    JavaClass* g3d_class = jvm_load_class(jvm, "javax/microedition/m3g/Graphics3D");
    if (!g3d_class) {
        GFX_DEBUG("Graphics3D class not found");
        return NATIVE_RETURN_NULL();
    }
    
    /* Check for static instance field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            if (g3d_class->static_fields[i].value.ref) {
                return NATIVE_RETURN_OBJECT(g3d_class->static_fields[i].value.ref);
            }
            break;
        }
    }
    
    /* Create new instance */
    JavaObject* instance = jvm_new_object(jvm, g3d_class);
    if (!instance) {
        GFX_DEBUG("Failed to create Graphics3D instance");
        return NATIVE_RETURN_NULL();
    }
    
    /* Store as static field */
    for (int i = 0; i < g3d_class->static_fields_count; i++) {
        if (strcmp(g3d_class->static_fields[i].name, "instance") == 0) {
            g3d_class->static_fields[i].value.ref = instance;
            break;
        }
    }
    
    GFX_DEBUG("Graphics3D.getInstance() -> %p", (void*)instance);
    return NATIVE_RETURN_OBJECT(instance);
}

/* Graphics3D.bindTarget(Image2D) */
static JavaValue native_graphics3d_bindTarget(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* target = (JavaObject*)args[1].ref;
    
    (void)g3d;  /* Instance not used in this simple impl */
    
    if (!target) {
        GFX_DEBUG("bindTarget: null target");
        g_m3g.target_image = NULL;
        return NATIVE_RETURN_VOID();
    }
    
    /* Get image dimensions from target */
    int width = m3g_get_int_field(target, "width", 240);
    int height = m3g_get_int_field(target, "height", 320);
    
    /* Sanity check: prevent OOM from unreasonable dimensions */
    if (width <= 0 || height <= 0) {
        GFX_DEBUG("bindTarget: Invalid dimensions %dx%d, using defaults", width, height);
        width = 240;
        height = 320;
    }
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("bindTarget: Dimensions too large %dx%d, clamping to %d", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        if (width > M3G_MAX_IMAGE_DIMENSION) width = M3G_MAX_IMAGE_DIMENSION;
        if (height > M3G_MAX_IMAGE_DIMENSION) height = M3G_MAX_IMAGE_DIMENSION;
    }
    
    /* Check for integer overflow */
    int pixel_count = width * height;
    if (pixel_count <= 0 || pixel_count > M3G_MAX_IMAGE_PIXELS) {
        GFX_DEBUG("bindTarget: Pixel count overflow or invalid: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize or reinitialize context */
    if (g_m3g.color_buffer) {
        free(g_m3g.color_buffer);
        free(g_m3g.depth_buffer);
    }
    m3g_context_init(width, height);
    
    /* Save target image for releaseTarget */
    g_m3g.target_image = target;
    
    GFX_DEBUG("bindTarget: %dx%d, image=%p", width, height, (void*)target);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.releaseTarget() */
static JavaValue native_graphics3d_releaseTarget(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)args; (void)arg_count;
    
    GFX_DEBUG("releaseTarget: triangles=%d", g_m3g.triangles_rendered);
    
    /* Copy rendered buffer back to Image2D */
    if (g_m3g.target_image && g_m3g.color_buffer) {
        JavaObject* image2d = g_m3g.target_image;
        JavaArray* pixels = (JavaArray*)m3g_get_ref_field(image2d, "pixels");
        
        if (pixels && pixels->element_type == T_INT) {
            int width = m3g_get_int_field(image2d, "width", g_m3g.buffer_width);
            int height = m3g_get_int_field(image2d, "height", g_m3g.buffer_height);
            int pixel_count = width * height;
            
            jint* dst = (jint*)array_data(pixels);
            if (dst && pixel_count > 0) {
                int copy_count = pixel_count < (g_m3g.buffer_width * g_m3g.buffer_height) 
                               ? pixel_count 
                               : g_m3g.buffer_width * g_m3g.buffer_height;
                
                for (int i = 0; i < copy_count; i++) {
                    /* Convert ABGR to ARGB */
                    uint32_t c = g_m3g.color_buffer[i];
                    dst[i] = ((c & 0xFF) << 16) | (c & 0xFF00FF00) | ((c >> 16) & 0xFF);
                }
                GFX_DEBUG("releaseTarget: copied %d pixels to Image2D", copy_count);
            }
        }
        g_m3g.target_image = NULL;
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.clear(Background) */
static JavaValue native_graphics3d_clear(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* background = (JavaObject*)args[1].ref;
    
    float r = 0.0f, g = 0.0f, b = 0.0f, a = 1.0f;
    float depth = 1.0f;
    
    if (background) {
        /* Background has clearColor field (int ARGB) */
        int argb = m3g_get_int_field(background, "clearColor", 0);
        a = ((argb >> 24) & 0xFF) / 255.0f;
        r = ((argb >> 16) & 0xFF) / 255.0f;
        g = ((argb >> 8) & 0xFF) / 255.0f;
        b = (argb & 0xFF) / 255.0f;
    }
    
    m3g_clear(r, g, b, a, depth);
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setViewport(int x, int y, int width, int height) */
static JavaValue native_graphics3d_setViewport(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    (void)g3d;
    
    g_m3g.viewport_x = args[1].i;
    g_m3g.viewport_y = args[2].i;
    g_m3g.viewport_width = args[3].i;
    g_m3g.viewport_height = args[4].i;
    
    GFX_DEBUG("setViewport: %d,%d %dx%d", 
            g_m3g.viewport_x, g_m3g.viewport_y, 
            g_m3g.viewport_width, g_m3g.viewport_height);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.setIdentity() */
/* Transform.<init>() - default constructor, creates identity matrix */
static JavaValue native_transform_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    GFX_DEBUG("Transform.<init>() called, obj=%p", (void*)obj);
    
    if (!obj) {
        GFX_DEBUG("Transform.<init>: NULL object!");
        return NATIVE_RETURN_VOID();
    }
    
    /* Create float[16] array for the matrix */
    JavaArray* arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
    if (!arr) {
        GFX_DEBUG("Transform.<init>: failed to create float array");
        return NATIVE_RETURN_VOID();
    }
    
    /* Initialize to identity matrix */
    float* data = (float*)array_data(arr);
    memset(data, 0, 16 * sizeof(float));
    data[0] = 1.0f;   /* m[0][0] */
    data[5] = 1.0f;   /* m[1][1] */
    data[10] = 1.0f;  /* m[2][2] */
    data[15] = 1.0f;  /* m[3][3] */
    
    /* Store in Transform's first field */
    obj->fields[0].ref = arr;
    
    GFX_DEBUG("Transform.<init>(): created identity transform, arr=%p", (void*)arr);
    return NATIVE_RETURN_VOID();
}

/* Transform.<init>(Transform) - copy constructor */
static JavaValue native_transform_init_copy(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* other = (JavaObject*)args[1].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Create float[16] array for the matrix */
    JavaArray* arr = jvm_new_array(jvm, T_FLOAT, 16, NULL);
    if (!arr) {
        GFX_DEBUG("Transform.<init>(Transform): failed to create float array");
        return NATIVE_RETURN_VOID();
    }
    
    float* data = (float*)array_data(arr);
    
    if (other && OBJECT_HAS_FIELDS(other, 1)) {
        /* Copy from other transform */
        JavaArray* other_arr = (JavaArray*)other->fields[0].ref;
        if (other_arr && other_arr->element_type == T_FLOAT && other_arr->length >= 16) {
            float* other_data = (float*)array_data(other_arr);
            memcpy(data, other_data, 16 * sizeof(float));
            GFX_DEBUG("Transform.<init>(Transform): copied transform");
        } else {
            /* Other transform has invalid data, use identity */
            memset(data, 0, 16 * sizeof(float));
            data[0] = 1.0f;
            data[5] = 1.0f;
            data[10] = 1.0f;
            data[15] = 1.0f;
            GFX_DEBUG("Transform.<init>(Transform): other has invalid data, using identity");
        }
    } else {
        /* Other is null, use identity */
        memset(data, 0, 16 * sizeof(float));
        data[0] = 1.0f;
        data[5] = 1.0f;
        data[10] = 1.0f;
        data[15] = 1.0f;
        GFX_DEBUG("Transform.<init>(Transform): other is null, using identity");
    }
    
    /* Store in Transform's first field */
    obj->fields[0].ref = arr;
    
    return NATIVE_RETURN_VOID();
}

static JavaValue native_transform_setIdentity(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    M3GTransform t;
    m3g_transform_identity(&t);
    set_native_transform(obj, &t);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postMultiply(Transform) */
static JavaValue native_transform_postMultiply(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* this_obj = (JavaObject*)args[0].ref;
    JavaObject* other_obj = (JavaObject*)args[1].ref;
    
    M3GTransform this_t, other_t;
    if (!get_native_transform(this_obj) || !get_native_transform(other_obj)) {
        return NATIVE_RETURN_VOID();
    }
    
    memcpy(this_t.m, get_native_transform(this_obj)->m, sizeof(this_t.m));
    memcpy(other_t.m, get_native_transform(other_obj)->m, sizeof(other_t.m));
    
    M3GTransform result;
    m3g_transform_multiply(&result, &this_t, &other_t);
    set_native_transform(this_obj, &result);
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postTranslate(float x, float y, float z) */
static JavaValue native_transform_postTranslate(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_translate(&temp, x, y, z);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postRotate(float angle, float ax, float ay, float az) */
static JavaValue native_transform_postRotate(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f * 3.14159f / 180.0f;  /* Degrees to radians */
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_rotate(&temp, angle, ax, ay, az);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Transform.postScale(float sx, float sy, float sz) */
static JavaValue native_transform_postScale(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    
    M3GTransform* t = get_native_transform(obj);
    if (t) {
        M3GTransform temp;
        memcpy(temp.m, t->m, sizeof(temp.m));
        m3g_transform_scale(&temp, sx, sy, sz);
        set_native_transform(obj, &temp);
    }
    
    return NATIVE_RETURN_VOID();
}

/* VertexArray.<init>(int numVertices, int numComponents, int componentSize) */
static JavaValue native_vertexarray_init(JVM* jvm, JavaThread* thread,
                                          JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint num_vertices = args[1].i;
    jint num_components = args[2].i;
    jint component_size = args[3].i;
    
    if (!obj || num_vertices <= 0 || num_components < 2 || num_components > 4) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Sanity check: limit vertex count to prevent OOM */
    if (num_vertices > M3G_MAX_VERTEX_COUNT) {
        GFX_DEBUG("VertexArray: num_vertices %d exceeds max %d", num_vertices, M3G_MAX_VERTEX_COUNT);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in data_size calculation */
    int data_size = num_vertices * num_components * component_size;
    if (data_size <= 0 || data_size > M3G_MAX_VERTEX_COUNT * 4 * 2) {
        GFX_DEBUG("VertexArray: data_size overflow or invalid: %d", data_size);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create data array */
    JavaArray* data = jvm_new_array(jvm, component_size == 1 ? T_BYTE : T_SHORT, data_size, NULL);
    if (!data) {
        GFX_DEBUG("VertexArray: failed to allocate data array");
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "data", (JavaObject*)data);
    m3g_set_int_field(obj, "componentCount", num_components);
    m3g_set_int_field(obj, "componentSize", component_size);
    m3g_set_int_field(obj, "vertexCount", num_vertices);
    
    GFX_DEBUG("VertexArray.init: %d vertices, %d components, %d bytes",
            num_vertices, num_components, component_size);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setPerspective(float fov, float aspectRatio, float near, float far) */
static JavaValue native_camera_setPerspective(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float fov = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Update projection matrix */
    m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    
    GFX_DEBUG("Camera.setPerspective: fov=%.1f, aspect=%.2f, near=%.2f, far=%.2f",
            fov, aspect, near, far);
    
    return NATIVE_RETURN_VOID();
}

/* Camera.setParallel(float height, float aspectRatio, float near, float far) */
static JavaValue native_camera_setParallel(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float height = args[1].f;
    float aspect = args[2].f;
    float near = args[3].f;
    float far = args[4].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    float half_h = height / 2.0f;
    float half_w = half_h * aspect;
    
    m3g_transform_ortho(&g_m3g.projection, -half_w, half_w, -half_h, half_h, near, far);
    
    GFX_DEBUG("Camera.setParallel: height=%.1f, aspect=%.2f", height, aspect);
    
    return NATIVE_RETURN_VOID();
}

/* Light.setType(int type) */
static JavaValue native_light_setType(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint type = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Add to lights array if new */
    int light_idx = -1;
    for (int i = 0; i < g_m3g.light_count; i++) {
        /* Check if this object is already registered */
        /* Simple approach: just use next slot */
    }
    
    if (g_m3g.light_count < 8) {
        light_idx = g_m3g.light_count++;
        g_m3g.lights[light_idx].type = type;
    }
    
    GFX_DEBUG("Light.setType: %d (idx=%d)", type, light_idx);
    
    return NATIVE_RETURN_VOID();
}

/* World.addCamera(Camera) */
static JavaValue native_world_addCamera(JVM* jvm, JavaThread* thread,
                                         JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* camera = (JavaObject*)args[1].ref;
    (void)world; (void)camera;
    
    GFX_DEBUG("World.addCamera");
    return NATIVE_RETURN_VOID();
}

/* World.setBackground(Background) */
static JavaValue native_world_setBackground(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* background = (JavaObject*)args[1].ref;
    (void)world; (void)background;
    
    GFX_DEBUG("World.setBackground");
    return NATIVE_RETURN_VOID();
}

/* World.render(World) - Render a 3D scene */
static JavaValue native_graphics3d_renderWorld(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* world = (JavaObject*)args[1].ref;
    (void)g3d;
    
    GFX_DEBUG("renderWorld: world=%p", (void*)world);
    
    /* Reset stats */
    g_m3g.triangles_rendered = 0;
    
    if (!world) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Get background from world */
    JavaObject* background = (JavaObject*)m3g_get_ref_field(world, "background");
    
    /* Clear with background color */
    float r = 0.0f, g = 0.0f, b = 0.0f, a = 1.0f;
    if (background) {
        int argb = m3g_get_int_field(background, "clearColor", 0xFF000000);
        a = ((argb >> 24) & 0xFF) / 255.0f;
        r = ((argb >> 16) & 0xFF) / 255.0f;
        g = ((argb >> 8) & 0xFF) / 255.0f;
        b = (argb & 0xFF) / 255.0f;
    }
    
    m3g_clear(r, g, b, a, 1.0f);
    
    /* Get active camera from world */
    JavaObject* camera = (JavaObject*)m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        /* Get camera projection */
        float fov = m3g_get_float_field(camera, "fov", 60.0f);
        float aspect = m3g_get_float_field(camera, "aspect", 1.0f);
        float near = m3g_get_float_field(camera, "near", 1.0f);
        float far = m3g_get_float_field(camera, "far", 1000.0f);
        
        m3g_transform_perspective(&g_m3g.projection, fov, aspect, near, far);
    }
    
    /* Reset modelview matrix */
    m3g_transform_identity(&g_m3g.modelview);
    
    /* Build MVP matrix */
    m3g_transform_multiply(&g_m3g.mvp, &g_m3g.modelview, &g_m3g.projection);
    
    /* Render child nodes */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children && children->length > 0 && children->element_type == DESC_OBJECT) {
        GFX_DEBUG("renderWorld: %d children to process", children->length);
        JavaObject** child_arr = (JavaObject**)array_data(children);
        
        for (jsize c = 0; c < children->length; c++) {
            JavaObject* child = child_arr[c];
            if (!child) continue;
            
            JavaClass* child_class = child->header.clazz;
            if (!child_class || !child_class->class_name) continue;
            
            /* Check if this is a Mesh */
            if (strstr(child_class->class_name, "Mesh") != NULL) {
                GFX_DEBUG("renderWorld: found Mesh at index %d", c);
                
                /* Get vertex buffer and index buffer from mesh */
                JavaObject* vertexBuffer = m3g_get_ref_field(child, "vertexBuffer");
                JavaObject* indexBuffer = m3g_get_ref_field(child, "indexBuffer");
                
                if (!vertexBuffer || !indexBuffer) continue;
                
                /* Get position array from vertex buffer */
                JavaObject* positions = m3g_get_ref_field(vertexBuffer, "positions");
                if (!positions) continue;
                
                int vertex_count = m3g_get_int_field(positions, "vertexCount", 0);
                int pos_components = m3g_get_int_field(positions, "componentCount", 3);
                int pos_size = m3g_get_int_field(positions, "componentSize", 1);
                float pos_scale = m3g_get_float_field(vertexBuffer, "positionScale", 1.0f);
                
                if (vertex_count == 0) continue;
                
                /* Sanity check: limit vertex count to prevent OOM */
                if (vertex_count > M3G_MAX_VERTEX_COUNT) {
                    GFX_DEBUG("renderWorld: vertex_count %d exceeds max %d, skipping", vertex_count, M3G_MAX_VERTEX_COUNT);
                    continue;
                }
                
                JavaArray* pos_data = (JavaArray*)m3g_get_ref_field(positions, "data");
                if (!pos_data) continue;
                
                /* Get index count */
                int index_count = m3g_get_int_field(indexBuffer, "indexCount", 0);
                JavaArray* idx_data = (JavaArray*)m3g_get_ref_field(indexBuffer, "indices");
                
                if (!idx_data || index_count == 0) continue;
                
                /* Sanity check: limit index count */
                if (index_count > M3G_MAX_INDEX_COUNT) {
                    GFX_DEBUG("renderWorld: index_count %d exceeds max %d, skipping", index_count, M3G_MAX_INDEX_COUNT);
                    continue;
                }
                
                GFX_DEBUG("renderWorld: mesh has %d vertices, %d indices", vertex_count, index_count);
                
                /* Convert positions to float array */
                float* vertices = (float*)malloc(vertex_count * 3 * sizeof(float));
                if (!vertices) continue;
                
                if (pos_size == 1) {
                    int8_t* src = (int8_t*)array_data(pos_data);
                    for (int i = 0; i < vertex_count * pos_components && i < (int)pos_data->length; i++) {
                        vertices[i] = (float)src[i] * pos_scale;
                    }
                } else {
                    int16_t* src = (int16_t*)array_data(pos_data);
                    for (int i = 0; i < vertex_count * pos_components && i < (int)pos_data->length; i++) {
                        vertices[i] = (float)src[i] * pos_scale;
                    }
                }
                
                /* Get indices */
                uint16_t* indices = NULL;
                int need_free = 0;
                
                if (idx_data->element_type == T_INT) {
                    jint* src = (jint*)array_data(idx_data);
                    indices = (uint16_t*)malloc(index_count * sizeof(uint16_t));
                    need_free = 1;
                    for (int i = 0; i < index_count; i++) {
                        indices[i] = (uint16_t)src[i];
                    }
                } else if (idx_data->element_type == T_SHORT) {
                    indices = (uint16_t*)array_data(idx_data);
                }
                
                if (indices) {
                    /* Render triangles */
                    for (int t = 0; t + 2 < index_count; t += 3) {
                        float v0[4], v1[4], v2[4];
                        float clip0[4], clip1[4], clip2[4];
                        
                        int i0 = indices[t] * pos_components;
                        int i1 = indices[t+1] * pos_components;
                        int i2 = indices[t+2] * pos_components;
                        
                        if (pos_components >= 3 && 
                            i0 + 2 < vertex_count * pos_components &&
                            i1 + 2 < vertex_count * pos_components &&
                            i2 + 2 < vertex_count * pos_components) {
                            
                            /* Apply MVP transformation */
                            v0[0] = vertices[i0]; v0[1] = vertices[i0+1]; v0[2] = vertices[i0+2]; v0[3] = 1.0f;
                            v1[0] = vertices[i1]; v1[1] = vertices[i1+1]; v1[2] = vertices[i1+2]; v1[3] = 1.0f;
                            v2[0] = vertices[i2]; v2[1] = vertices[i2+1]; v2[2] = vertices[i2+2]; v2[3] = 1.0f;
                            
                            m3g_transform_point(clip0, &g_m3g.mvp, v0);
                            m3g_transform_point(clip1, &g_m3g.mvp, v1);
                            m3g_transform_point(clip2, &g_m3g.mvp, v2);
                            
                            /* Render with default gray color */
                            uint8_t color[4] = {180, 180, 180, 255};
                            
                            m3g_rasterize_triangle(clip0, clip1, clip2,
                                                   NULL, NULL, NULL,
                                                   color, color, color, NULL);
                        }
                    }
                    
                    if (need_free) free(indices);
                }
                
                free(vertices);
            }
            /* Check for Group to recurse */
            else if (strstr(child_class->class_name, "Group") != NULL) {
                /* TODO: Handle nested groups */
            }
        }
    }
    
    GFX_DEBUG("renderWorld: rendered %d triangles", g_m3g.triangles_rendered);
    
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended M3G Native Methods - Additional JSR 184 Support
 * ============================================================================ */

/* VertexArray.set(int firstVertex, int numVertices, byte[] src) */
static JavaValue native_vertexarray_set_byte(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper functions */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    int component_size = m3g_get_int_field(obj, "componentSize", 1);
    
    if (!data) return NATIVE_RETURN_VOID();
    
    /* Copy data */
    int8_t* dst_data = (int8_t*)array_data(data);
    int8_t* src_data = (int8_t*)array_data(src);
    
    int copy_count = count;
    if (first + copy_count > (int)data->length) {
        copy_count = (int)data->length - first;
    }
    
    if (copy_count > 0) {
        memcpy(dst_data + first, src_data, copy_count * component_size);
    }
    
    GFX_DEBUG("VertexArray.set: first=%d, count=%d", first, count);
    return NATIVE_RETURN_VOID();
}

/* VertexArray.set(int firstVertex, int numVertices, short[] src) */
static JavaValue native_vertexarray_set_short(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    jint count = args[2].i;
    JavaArray* src = (JavaArray*)args[3].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get internal data array using helper function */
    JavaArray* data = (JavaArray*)m3g_get_ref_field(obj, "data");
    
    if (!data || data->element_type != T_SHORT) return NATIVE_RETURN_VOID();
    
    /* Copy data */
    int16_t* dst_data = (int16_t*)array_data(data);
    int16_t* src_data = (int16_t*)array_data(src);
    
    int copy_count = count;
    if (first + copy_count > (int)data->length) {
        copy_count = (int)data->length - first;
    }
    
    if (copy_count > 0) {
        memcpy(dst_data + first, src_data, copy_count * sizeof(int16_t));
    }
    
    GFX_DEBUG("VertexArray.set(short[]): first=%d, count=%d", first, count);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * VertexBuffer Native Methods
 * ============================================================================ */

/* VertexBuffer.<init>() */
static JavaValue native_vertexbuffer_init(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_int_field(obj, "vertexCount", 0);
    m3g_set_ref_field(obj, "positions", NULL);
    m3g_set_ref_field(obj, "normals", NULL);
    m3g_set_ref_field(obj, "texCoords", NULL);
    m3g_set_ref_field(obj, "colors", NULL);
    m3g_set_float_field(obj, "positionScale", 1.0f);
    
    GFX_DEBUG("VertexBuffer.<init>");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setPositions(VertexArray positions, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setPositions(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* positions = (JavaObject*)args[1].ref;
    float scale = args[2].f;
    JavaArray* bias = (JavaArray*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "positions", positions);
    m3g_set_float_field(obj, "positionScale", scale);
    
    if (positions) {
        int count = m3g_get_int_field(positions, "vertexCount", 0);
        m3g_set_int_field(obj, "vertexCount", count);
    }
    
    if (bias && bias->element_type == T_FLOAT && bias->length >= 3) {
        float* bias_data = (float*)array_data(bias);
        m3g_set_float_field(obj, "biasX", bias_data[0]);
        m3g_set_float_field(obj, "biasY", bias_data[1]);
        m3g_set_float_field(obj, "biasZ", bias_data[2]);
    }
    
    GFX_DEBUG("VertexBuffer.setPositions: scale=%.2f", scale);
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setNormals(VertexArray normals) */
static JavaValue native_vertexbuffer_setNormals(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* normals = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "normals", normals);
    
    GFX_DEBUG("VertexBuffer.setNormals");
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setTexCoords(int index, VertexArray texCoords, float scale, float[] bias) */
static JavaValue native_vertexbuffer_setTexCoords(JVM* jvm, JavaThread* thread,
                                                   JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texCoords = (JavaObject*)args[2].ref;
    float scale = args[3].f;
    JavaArray* bias = (JavaArray*)args[4].ref;
    (void)bias;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    if (index == 0) {
        m3g_set_ref_field(obj, "texCoords", texCoords);
        m3g_set_float_field(obj, "texCoordScale", scale);
    }
    
    GFX_DEBUG("VertexBuffer.setTexCoords: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* VertexBuffer.setColors(VertexArray colors) */
static JavaValue native_vertexbuffer_setColors(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* colors = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_ref_field(obj, "colors", colors);
    
    GFX_DEBUG("VertexBuffer.setColors");
    return NATIVE_RETURN_VOID();
}

/* Transform.invert() */
static JavaValue native_transform_invert(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    /* 4x4 matrix inversion using Gauss-Jordan elimination */
    float m[16], inv[16];
    memcpy(m, t->m, sizeof(m));
    memset(inv, 0, sizeof(inv));
    inv[0] = inv[5] = inv[10] = inv[15] = 1.0f;
    
    for (int col = 0; col < 4; col++) {
        /* Find pivot */
        int pivot = col;
        for (int row = col + 1; row < 4; row++) {
            if (fabsf(m[row * 4 + col]) > fabsf(m[pivot * 4 + col])) {
                pivot = row;
            }
        }
        
        /* Swap rows */
        if (pivot != col) {
            for (int i = 0; i < 4; i++) {
                float tmp = m[col * 4 + i];
                m[col * 4 + i] = m[pivot * 4 + i];
                m[pivot * 4 + i] = tmp;
                
                tmp = inv[col * 4 + i];
                inv[col * 4 + i] = inv[pivot * 4 + i];
                inv[pivot * 4 + i] = tmp;
            }
        }
        
        /* Check for singular matrix */
        if (fabsf(m[col * 4 + col]) < 0.00001f) {
            GFX_DEBUG("Transform.invert: singular matrix");
            return NATIVE_RETURN_VOID();
        }
        
        /* Scale pivot row */
        float scale = m[col * 4 + col];
        for (int i = 0; i < 4; i++) {
            m[col * 4 + i] /= scale;
            inv[col * 4 + i] /= scale;
        }
        
        /* Eliminate column */
        for (int row = 0; row < 4; row++) {
            if (row != col) {
                float factor = m[row * 4 + col];
                for (int i = 0; i < 4; i++) {
                    m[row * 4 + i] -= factor * m[col * 4 + i];
                    inv[row * 4 + i] -= factor * inv[col * 4 + i];
                }
            }
        }
    }
    
    set_native_transform(obj, &(M3GTransform){.m = {inv[0], inv[1], inv[2], inv[3],
                                                    inv[4], inv[5], inv[6], inv[7],
                                                    inv[8], inv[9], inv[10], inv[11],
                                                    inv[12], inv[13], inv[14], inv[15]}});
    
    GFX_DEBUG("Transform.invert");
    return NATIVE_RETURN_VOID();
}

/* Transform.transform(float[] vectors) */
static JavaValue native_transform_transform(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaArray* vectors = (JavaArray*)args[1].ref;
    
    if (!obj || !vectors || vectors->element_type != T_FLOAT) {
        return NATIVE_RETURN_VOID();
    }
    
    M3GTransform* t = get_native_transform(obj);
    if (!t) return NATIVE_RETURN_VOID();
    
    float* data = (float*)array_data(vectors);
    int count = vectors->length / 4;
    
    for (int i = 0; i < count; i++) {
        float x = data[i * 4 + 0];
        float y = data[i * 4 + 1];
        float z = data[i * 4 + 2];
        float w = data[i * 4 + 3];
        
        data[i * 4 + 0] = t->m[0]*x + t->m[4]*y + t->m[8]*z + t->m[12]*w;
        data[i * 4 + 1] = t->m[1]*x + t->m[5]*y + t->m[9]*z + t->m[13]*w;
        data[i * 4 + 2] = t->m[2]*x + t->m[6]*y + t->m[10]*z + t->m[14]*w;
        data[i * 4 + 3] = t->m[3]*x + t->m[7]*y + t->m[11]*z + t->m[15]*w;
    }
    
    GFX_DEBUG("Transform.transform: %d vectors", count);
    return NATIVE_RETURN_VOID();
}

/* Light.setColor(int ARGB) */
static JavaValue native_light_setColor(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Find light index from object (simplified: use next light) */
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->color[0] = ((argb >> 16) & 0xFF) / 255.0f;
        light->color[1] = ((argb >> 8) & 0xFF) / 255.0f;
        light->color[2] = (argb & 0xFF) / 255.0f;
        light->color[3] = ((argb >> 24) & 0xFF) / 255.0f;
    }
    
    GFX_DEBUG("Light.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Light.setIntensity(float intensity) */
static JavaValue native_light_setIntensity(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float intensity = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store in color's alpha or a separate field */
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->color[3] = intensity;
    }
    
    GFX_DEBUG("Light.setIntensity: %.2f", intensity);
    return NATIVE_RETURN_VOID();
}

/* Light.setDirection(float x, float y, float z) */
static JavaValue native_light_setDirection(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    if (g_m3g.light_count > 0) {
        M3GLight* light = &g_m3g.lights[g_m3g.light_count - 1];
        light->direction[0] = x;
        light->direction[1] = y;
        light->direction[2] = z;
        light->direction[3] = 0.0f;  /* Direction, not position */
    }
    
    GFX_DEBUG("Light.setDirection: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Material.setColor(int target, int ARGB) */
static JavaValue native_material_setColor(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint target = args[1].i;
    jint argb = args[2].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store in fields using helper functions */
    if (target & M3G_MATERIAL_AMBIENT) {
        m3g_set_int_field(obj, "ambient", argb);
    }
    if (target & M3G_MATERIAL_DIFFUSE) {
        m3g_set_int_field(obj, "diffuse", argb);
    }
    if (target & M3G_MATERIAL_SPECULAR) {
        m3g_set_int_field(obj, "specular", argb);
    }
    if (target & M3G_MATERIAL_EMISSIVE) {
        m3g_set_int_field(obj, "emissive", argb);
    }
    
    GFX_DEBUG("Material.setColor: target=%d, ARGB=0x%08X", target, argb);
    return NATIVE_RETURN_VOID();
}

/* Material.setShininess(float shininess) */
static JavaValue native_material_setShininess(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float shininess = args[1].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store shininess using helper function */
    m3g_set_float_field(obj, "shininess", shininess);
    
    GFX_DEBUG("Material.setShininess: %.2f", shininess);
    return NATIVE_RETURN_VOID();
}

/* Appearance.setMaterial(Material) */
static JavaValue native_appearance_setMaterial(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* material = (JavaObject*)args[1].ref;
    (void)obj; (void)material;
    
    GFX_DEBUG("Appearance.setMaterial");
    return NATIVE_RETURN_VOID();
}

/* Appearance.setTexture(int index, Texture2D) */
static JavaValue native_appearance_setTexture(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* texture = (JavaObject*)args[2].ref;
    (void)obj; (void)index; (void)texture;
    
    GFX_DEBUG("Appearance.setTexture: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.<init>(Image2D) */
static JavaValue native_texture2d_init(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Get image data using helper functions */
    if (image) {
        m3g_set_ref_field(obj, "pixels", m3g_get_ref_field(image, "pixels"));
        m3g_set_int_field(obj, "width", m3g_get_int_field(image, "width", 64));
        m3g_set_int_field(obj, "height", m3g_get_int_field(image, "height", 64));
    }
    
    GFX_DEBUG("Texture2D.<init>: image=%p", (void*)image);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setFiltering(int level) */
static JavaValue native_texture2d_setFiltering(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint level = args[1].i;
    (void)obj; (void)level;
    
    GFX_DEBUG("Texture2D.setFiltering: level=%d", level);
    return NATIVE_RETURN_VOID();
}

/* Texture2D.setWrapping(int wrapS, int wrapT) */
static JavaValue native_texture2d_setWrapping(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint wrap_s = args[1].i;
    jint wrap_t = args[2].i;
    (void)obj; (void)wrap_s; (void)wrap_t;
    
    GFX_DEBUG("Texture2D.setWrapping: s=%d, t=%d", wrap_s, wrap_t);
    return NATIVE_RETURN_VOID();
}

/* Mesh.<init>(VertexArray, IndexBuffer, Appearance) */
static JavaValue native_mesh_init(JVM* jvm, JavaThread* thread,
                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* vertices = (JavaObject*)args[1].ref;
    JavaObject* indices = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store references using helper functions */
    m3g_set_ref_field(obj, "vertices", vertices);
    m3g_set_ref_field(obj, "indices", indices);
    m3g_set_ref_field(obj, "appearance", appearance);
    
    GFX_DEBUG("Mesh.<init>: vertices=%p, indices=%p, appearance=%p",
            (void*)vertices, (void*)indices, (void*)appearance);
    return NATIVE_RETURN_VOID();
}

/* TriangleStripArray.<init>(int firstIndex, int[] stripLengths) */
static JavaValue native_trianglestrip_init(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint first = args[1].i;
    JavaArray* lengths = (JavaArray*)args[2].ref;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Calculate total indices needed */
    int total_indices = 0;
    int strip_count = lengths ? lengths->length : 0;
    jint* len_data = lengths ? (jint*)array_data(lengths) : NULL;
    
    /* Sanity check: limit strip count */
    if (strip_count > 1024) {
        GFX_DEBUG("TriangleStripArray: strip_count %d exceeds max 1024", strip_count);
        strip_count = 1024;
    }
    
    for (int i = 0; i < strip_count; i++) {
        int strip_len = len_data[i];
        /* Skip invalid strips (need at least 3 vertices for a triangle) */
        if (strip_len < 3) continue;
        /* Each strip of n vertices produces (n-2) triangles */
        int strip_indices = (strip_len - 2) * 3;
        /* Check for overflow */
        if (total_indices + strip_indices > M3G_MAX_INDEX_COUNT) {
            GFX_DEBUG("TriangleStripArray: total_indices overflow, clamping");
            break;
        }
        total_indices += strip_indices;
    }
    
    /* Validate total_indices before allocation */
    if (total_indices <= 0 || total_indices > M3G_MAX_INDEX_COUNT) {
        GFX_DEBUG("TriangleStripArray: invalid total_indices %d", total_indices);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create index buffer */
    JavaArray* indices = jvm_new_array(jvm, T_SHORT, total_indices, NULL);
    if (indices) {
        int idx = 0;
        int vertex = first;
        
        for (int strip = 0; strip < strip_count && idx < total_indices; strip++) {
            int strip_len = len_data[strip];
            if (strip_len < 3) continue;
            
            /* Generate triangle strip indices */
            for (int t = 0; t < strip_len - 2 && idx + 2 < total_indices; t++) {
                int16_t* data = (int16_t*)array_data(indices);
                if (t % 2 == 0) {
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 1;
                    data[idx++] = vertex + t + 2;
                } else {
                    /* Swap last two for correct winding */
                    data[idx++] = vertex + t;
                    data[idx++] = vertex + t + 2;
                    data[idx++] = vertex + t + 1;
                }
            }
            vertex += strip_len;
        }
        
        /* Store index buffer using helper function */
        m3g_set_ref_field(obj, "indices", (JavaObject*)indices);
    }
    
    GFX_DEBUG("TriangleStripArray.<init>: first=%d, strips=%d, indices=%d",
            first, strip_count, total_indices);
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.render(Node, Transform) - Immediate mode rendering */
static JavaValue native_graphics3d_render_node(JVM* jvm, JavaThread* thread,
                                                 JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* node = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d; (void)node; (void)transform;
    
    GFX_DEBUG("Graphics3D.render(Node, Transform): immediate mode");
    
    /* TODO: Implement actual mesh rendering using software rasterizer */
    
    return NATIVE_RETURN_VOID();
}

/* Node.setScale(float sx, float sy, float sz) */
static JavaValue native_node_setScale(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float sx = args[1].f;
    float sy = args[2].f;
    float sz = args[3].f;
    (void)obj; (void)sx; (void)sy; (void)sz;
    
    GFX_DEBUG("Node.setScale: (%.2f, %.2f, %.2f)", sx, sy, sz);
    return NATIVE_RETURN_VOID();
}

/* Node.setTranslation(float x, float y, float z) */
static JavaValue native_node_setTranslation(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float x = args[1].f;
    float y = args[2].f;
    float z = args[3].f;
    (void)obj; (void)x; (void)y; (void)z;
    
    GFX_DEBUG("Node.setTranslation: (%.2f, %.2f, %.2f)", x, y, z);
    return NATIVE_RETURN_VOID();
}

/* Node.setRotation(float angle, float ax, float ay, float az) */
static JavaValue native_node_setRotation(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float angle = args[1].f;
    float ax = args[2].f;
    float ay = args[3].f;
    float az = args[4].f;
    (void)obj; (void)angle; (void)ax; (void)ay; (void)az;
    
    GFX_DEBUG("Node.setRotation: angle=%.1f, axis=(%.2f, %.2f, %.2f)", angle, ax, ay, az);
    return NATIVE_RETURN_VOID();
}

/* Camera.setGeneric(Transform) */
static JavaValue native_camera_setGeneric(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    (void)obj; (void)transform;
    
    GFX_DEBUG("Camera.setGeneric");
    return NATIVE_RETURN_VOID();
}

/* Background.setColor(int ARGB) */
static JavaValue native_background_setColor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint argb = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Store color using helper function */
    m3g_set_int_field(obj, "clearColor", argb);
    
    GFX_DEBUG("Background.setColor: 0x%08X", argb);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, int width, int height) */
static JavaValue native_image2d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    jint width = args[2].i;
    jint height = args[3].i;
    
    if (!obj || width <= 0 || height <= 0) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for oversized images to prevent OOM errors from malformed M3G files */
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("Image2D.<init>: REJECTED - dimensions too large: %dx%d (max %d)", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in width * height calculation */
    jint pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS || pixel_count <= 0) {
        GFX_DEBUG("Image2D.<init>: REJECTED - pixel count overflow: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, pixel_count, NULL);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    GFX_DEBUG("Image2D.<init>: format=%d, %dx%d", format, width, height);
    return NATIVE_RETURN_VOID();
}

/* Image2D.<init>(int format, Object image) - creates Image2D from LCDUI Image */
static JavaValue native_image2d_init_from_image(JVM* jvm, JavaThread* thread,
                                                  JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint format = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    
    if (!obj) {
        return NATIVE_RETURN_VOID();
    }
    
    GFX_DEBUG("Image2D.<init>(int, Object): format=%d, image=%p", format, (void*)image);
    
    int width = 0, height = 0;
    JavaArray* src_pixels = NULL;
    
    /* Try to get image data from LCDUI Image object using helper functions */
    if (image) {
        width = m3g_get_int_field(image, "width", 0);
        height = m3g_get_int_field(image, "height", 0);
        src_pixels = (JavaArray*)m3g_get_ref_field(image, "pixels");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "data");
        if (!src_pixels) src_pixels = (JavaArray*)m3g_get_ref_field(image, "imageData");
    }
    
    /* If no valid dimensions, use defaults */
    if (width <= 0) width = 64;
    if (height <= 0) height = 64;
    
    /* Check for oversized images to prevent OOM errors */
    if (width > M3G_MAX_IMAGE_DIMENSION || height > M3G_MAX_IMAGE_DIMENSION) {
        GFX_DEBUG("Image2D.<init>(Object): REJECTED - dimensions too large: %dx%d (max %d)", 
                width, height, M3G_MAX_IMAGE_DIMENSION);
        return NATIVE_RETURN_VOID();
    }
    
    /* Check for integer overflow in width * height calculation */
    int pixel_count = width * height;
    if (pixel_count > M3G_MAX_IMAGE_PIXELS || pixel_count <= 0) {
        GFX_DEBUG("Image2D.<init>(Object): REJECTED - pixel count overflow: %d", pixel_count);
        return NATIVE_RETURN_VOID();
    }
    
    /* Create pixel array (ARGB format) */
    JavaArray* pixels = jvm_new_array(jvm, T_INT, pixel_count, NULL);
    if (!pixels) {
        return NATIVE_RETURN_VOID();
    }
    
    /* Copy source pixels if available */
    if (src_pixels && src_pixels->length > 0) {
        int copy_count = src_pixels->length < pixel_count ? src_pixels->length : pixel_count;
        jint* dst_data = (jint*)((uint8_t*)pixels + sizeof(JavaArray));
        jint* src_data = (jint*)((uint8_t*)src_pixels + sizeof(JavaArray));
        for (int i = 0; i < copy_count; i++) {
            dst_data[i] = src_data[i];
        }
    }
    
    /* Store fields using helper functions */
    m3g_set_ref_field(obj, "pixels", (JavaObject*)pixels);
    m3g_set_int_field(obj, "width", width);
    m3g_set_int_field(obj, "height", height);
    m3g_set_int_field(obj, "format", format);
    
    return NATIVE_RETURN_VOID();
}

/* Image2D.set(int x, int y, int width, int height, byte[] pixels) */
static JavaValue native_image2d_set(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint x = args[1].i;
    jint y = args[2].i;
    jint w = args[3].i;
    jint h = args[4].i;
    JavaArray* src = (JavaArray*)args[5].ref;
    
    if (!obj || !src) return NATIVE_RETURN_VOID();
    
    /* Get destination pixel array using helper functions */
    JavaArray* dst = (JavaArray*)m3g_get_ref_field(obj, "pixels");
    int img_width = m3g_get_int_field(obj, "width", 0);
    
    if (!dst) return NATIVE_RETURN_VOID();
    
    uint8_t* src_data = (uint8_t*)array_data(src);
    uint32_t* dst_data = (uint32_t*)array_data(dst);
    
    /* Copy and convert to ARGB */
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            int src_idx = (row * w + col) * 4;  /* Assume RGBA */
            int dst_idx = (y + row) * img_width + (x + col);
            
            if (dst_idx < (int)dst->length) {
                dst_data[dst_idx] = (0xFF << 24) |  /* Alpha */
                                    (src_data[src_idx] << 16) |  /* R */
                                    (src_data[src_idx + 1] << 8) |  /* G */
                                    src_data[src_idx + 2];  /* B */
            }
        }
    }
    
    GFX_DEBUG("Image2D.set: (%d,%d) %dx%d", x, y, w, h);
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Extended JSR 184 Implementation - Additional Features
 * ============================================================================ */

/* World.addChild(Node) */
static JavaValue native_world_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!world || !child) return NATIVE_RETURN_VOID();
    
    /* Get children array using helper function */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children) {
        /* Add child to array - simplified: just store first child */
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j] == NULL) {
                arr[j] = child;
                break;
            }
        }
    }
    
    GFX_DEBUG("World.addChild: %p", (void*)child);
    return NATIVE_RETURN_VOID();
}

/* World.getActiveCamera() */
static JavaValue native_world_getActiveCamera(JVM* jvm, JavaThread* thread,
                                               JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* world = (JavaObject*)args[0].ref;
    
    if (!world) return NATIVE_RETURN_NULL();
    
    /* Get active camera from World using helper function */
    JavaObject* camera = m3g_get_ref_field(world, "activeCamera");
    if (camera) {
        return NATIVE_RETURN_OBJECT(camera);
    }
    
    /* Try to find camera in children */
    JavaArray* children = (JavaArray*)m3g_get_ref_field(world, "children");
    if (children && children->element_type == DESC_OBJECT) {
        JavaObject** arr = (JavaObject**)array_data(children);
        for (jsize j = 0; j < children->length; j++) {
            if (arr[j]) {
                JavaClass* child_class = arr[j]->header.clazz;
                if (child_class && child_class->class_name && 
                    strstr(child_class->class_name, "Camera")) {
                    return NATIVE_RETURN_OBJECT(arr[j]);
                }
            }
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Helper: Recursively search for object with userID in scene graph */
static JavaObject* m3g_find_recursive(JavaObject* obj, jint user_id) {
    if (!obj) return NULL;

    /* Check if this object matches */
    jint obj_user_id = m3g_get_int_field(obj, "userID", -1);
    if (obj_user_id == user_id) {
        return obj;
    }

    /* Check if this is a Group (has children) - World extends Group */
    JavaClass* clazz = obj->header.clazz;
    if (!clazz || !clazz->class_name) return NULL;

    /* Group, World, and Mesh can have children */
    if (strstr(clazz->class_name, "Group") || strstr(clazz->class_name, "World")) {
        JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
        if (children && children->element_type == DESC_OBJECT) {
            JavaObject** arr = (JavaObject**)array_data(children);
            for (jsize i = 0; i < children->length; i++) {
                if (arr[i]) {
                    JavaObject* found = m3g_find_recursive(arr[i], user_id);
                    if (found) return found;
                }
            }
        }
    }

    return NULL;
}

/* Object3D.find(int userID) */
static JavaValue native_object3d_find(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;

    if (!obj) return NATIVE_RETURN_NULL();

    GFX_DEBUG("Object3D.find: searching for userID=%d", user_id);

    /* Recursively search this object and its children */
    JavaObject* found = m3g_find_recursive(obj, user_id);
    if (found) {
        GFX_DEBUG("Object3D.find: found userID=%d at %p", user_id, (void*)found);
        return NATIVE_RETURN_OBJECT(found);
    }

    GFX_DEBUG("Object3D.find: userID=%d not found", user_id);
    return NATIVE_RETURN_NULL();
}

/* Object3D.getUserID() */
static JavaValue native_object3d_getUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_INT(0);
    
    return NATIVE_RETURN_INT(m3g_get_int_field(obj, "userID", 0));
}

/* Object3D.setUserID(int id) */
static JavaValue native_object3d_setUserID(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint user_id = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    m3g_set_int_field(obj, "userID", user_id);
    
    GFX_DEBUG("Object3D.setUserID: %d", user_id);
    return NATIVE_RETURN_VOID();
}

/* Object3D.duplicate() - creates a copy of the object */
static JavaValue native_object3d_duplicate(JVM* jvm, JavaThread* thread,
                                            JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) {
        GFX_DEBUG("Object3D.duplicate: null object");
        return NATIVE_RETURN_NULL();
    }
    
    GFX_DEBUG("Object3D.duplicate: duplicating %p", (void*)obj);
    
    /* For simplicity, return the same object (shallow copy) */
    /* A full implementation would create a deep copy */
    return NATIVE_RETURN_OBJECT(obj);
}

/* Node.getTransform(Transform) */
static JavaValue native_node_getTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy node's transform to the provided Transform object using helper functions */
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        
        JavaArray* trans_arr = (JavaArray*)m3g_get_ref_field(transform, "matrix");
        if (trans_arr && trans_arr->element_type == T_FLOAT) {
            float* trans_matrix = (float*)array_data(trans_arr);
            memcpy(trans_matrix, node_matrix, 16 * sizeof(float));
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Node.setTransform(Transform) */
static JavaValue native_node_setTransform(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    JavaObject* transform = (JavaObject*)args[1].ref;
    
    if (!node || !transform) return NATIVE_RETURN_VOID();
    
    /* Copy transform to node's transform field */
    M3GTransform* t = get_native_transform(transform);
    if (!t) return NATIVE_RETURN_VOID();
    
    JavaArray* node_arr = (JavaArray*)m3g_get_ref_field(node, "transform");
    if (node_arr && node_arr->element_type == T_FLOAT) {
        float* node_matrix = (float*)array_data(node_arr);
        memcpy(node_matrix, t->m, 16 * sizeof(float));
    }
    
    GFX_DEBUG("Node.setTransform");
    return NATIVE_RETURN_VOID();
}

/* Node.setAlphaFactor(float factor) */
static JavaValue native_node_setAlphaFactor(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* node = (JavaObject*)args[0].ref;
    float factor = args[1].f;
    
    if (!node) return NATIVE_RETURN_VOID();
    
    m3g_set_float_field(node, "alphaFactor", factor);
    
    GFX_DEBUG("Node.setAlphaFactor: %.2f", factor);
    return NATIVE_RETURN_VOID();
}

/* Group.addChild(Node) */
static JavaValue native_group_addChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    /* Get children list */
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT) {
                JavaObject** arr = (JavaObject**)array_data(children);
                /* Find empty slot */
                for (jsize j = 0; j < children->length; j++) {
                    if (arr[j] == NULL) {
                        arr[j] = child;
                        GFX_DEBUG("Group.addChild: added child at index %d", j);
                        break;
                    }
                }
            }
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.removeChild(Node) */
static JavaValue native_group_removeChild(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    JavaObject* child = (JavaObject*)args[1].ref;
    
    if (!group || !child) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT) {
                JavaObject** arr = (JavaObject**)array_data(children);
                for (jsize j = 0; j < children->length; j++) {
                    if (arr[j] == child) {
                        arr[j] = NULL;
                        GFX_DEBUG("Group.removeChild: removed child at index %d", j);
                        break;
                    }
                }
            }
            break;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* Group.getChild(int index) */
static JavaValue native_group_getChild(JVM* jvm, JavaThread* thread,
                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* group = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    
    if (!group) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = group->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "children") == 0) {
            JavaArray* children = (JavaArray*)group->fields[i].ref;
            if (children && children->element_type == DESC_OBJECT && index >= 0 && index < (jint)children->length) {
                JavaObject** arr = (JavaObject**)array_data(children);
                return NATIVE_RETURN_OBJECT(arr[index]);
            }
            break;
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* CompositingMode.setBlending(int mode) */
static JavaValue native_compositingmode_setBlending(JVM* jvm, JavaThread* thread,
                                                     JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "blending") == 0) {
            obj->fields[i].i = mode;
            break;
        }
    }
    
    GFX_DEBUG("CompositingMode.setBlending: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* PolygonMode.setCulling(int mode) */
static JavaValue native_polygonmode_setCulling(JVM* jvm, JavaThread* thread,
                                                JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jint mode = args[1].i;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    g_m3g.culling_enabled = (mode != 0);
    
    GFX_DEBUG("PolygonMode.setCulling: %d", mode);
    return NATIVE_RETURN_VOID();
}

/* Mesh.setVertexBuffer(int index, VertexArray) */
static JavaValue native_mesh_setVertexBuffer(JVM* jvm, JavaThread* thread,
                                              JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* mesh = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* va = (JavaObject*)args[2].ref;
    
    if (!mesh) return NATIVE_RETURN_VOID();
    
    JavaClass* clazz = mesh->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "vertexBuffers") == 0) {
            JavaArray* buffers = (JavaArray*)mesh->fields[i].ref;
            if (buffers && buffers->element_type == DESC_OBJECT && index >= 0 && index < (jint)buffers->length) {
                JavaObject** arr = (JavaObject**)array_data(buffers);
                arr[index] = va;
            }
            break;
        }
    }
    
    GFX_DEBUG("Mesh.setVertexBuffer: index=%d", index);
    return NATIVE_RETURN_VOID();
}

/* Camera.lookAt(float x, float y, float z, float atX, float atY, float atZ, float upX, float upY, float upZ) */
static JavaValue native_camera_lookAt(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    float eye_x = args[1].f;
    float eye_y = args[2].f;
    float eye_z = args[3].f;
    float at_x = args[4].f;
    float at_y = args[5].f;
    float at_z = args[6].f;
    float up_x = args[7].f;
    float up_y = args[8].f;
    float up_z = args[9].f;
    
    if (!obj) return NATIVE_RETURN_VOID();
    
    /* Update modelview matrix */
    m3g_transform_look_at(&g_m3g.modelview, eye_x, eye_y, eye_z, at_x, at_y, at_z, up_x, up_y, up_z);
    
    GFX_DEBUG("Camera.lookAt: eye=(%.2f,%.2f,%.2f), at=(%.2f,%.2f,%.2f)", 
            eye_x, eye_y, eye_z, at_x, at_y, at_z);
    return NATIVE_RETURN_VOID();
}

/* M3G file format constants */
#define M3G_MAGIC1 0xAB
#define M3G_MAGIC2 0xBB
#define M3G_VERSION_MIN 2
#define M3G_VERSION_MAX 3

/* M3G object type codes (from JSR-184 specification) */
#define M3G_OBJ_HEADER              0
#define M3G_OBJ_ANIMATIONCONTROLLER 1
#define M3G_OBJ_ANIMATIONTRACK      2
#define M3G_OBJ_APPEARANCE          3
#define M3G_OBJ_BACKGROUND          4
#define M3G_OBJ_CAMERA              5
#define M3G_OBJ_COMPOSITINGMODE     6
#define M3G_OBJ_FOG                 7
#define M3G_OBJ_POLYGONMODE         8
#define M3G_OBJ_GROUP               9
#define M3G_OBJ_IMAGE2D             10
#define M3G_OBJ_TRIANGLESTRIPARRAY  11   /* IndexBuffer */
#define M3G_OBJ_LIGHT               12
#define M3G_OBJ_MATERIAL            13
#define M3G_OBJ_MESH                14
#define M3G_OBJ_MORPHINGMESH        15
#define M3G_OBJ_SKINNEDMESH         16
#define M3G_OBJ_TEXTURE2D           17
#define M3G_OBJ_SPRITE3D            18
#define M3G_OBJ_KEYFRAMESEQUENCE    19
#define M3G_OBJ_VERTEXARRAY         20
#define M3G_OBJ_VERTEXBUFFER        21
#define M3G_OBJ_WORLD               22
#define M3G_OBJ_EXTERNALREF         255

#include "miniz.h"  /* Use miniz for zlib decompression - single file implementation */

/* Helper: Parse M3G file and extract objects */
/* M3G reference system: ref 0 = null, ref N = objects[N] (direct index)
 * Objects are stored at their file position (0=header, 1=first object, etc.)
 * This preserves reference indices for correct linking.
 */
typedef struct {
    JavaObject** objects;      /* Objects stored at file position index */
    int object_count;          /* Number of objects stored */
    int object_capacity;       /* Capacity of objects array */
    JavaObject* world;
    JavaObject* camera;
    JavaObject* background;
    JavaObject* light;
    int external_links;        /* Header flag */
    int current_section;       /* Current section number */
    /* Temporary storage for parsing - used during linking */
    JavaObject* mesh;
    JavaObject* vertex_buffer;
    JavaObject* index_buffer;
    JavaObject* appearance;
} M3GParseContext;

/* Decompress zlib data - FIX: Use two-pass approach to determine exact size */
static uint8_t* m3g_decompress(const uint8_t* data, size_t data_size, size_t* out_size) {
    if (!data || data_size < 2) return NULL;

    /* Check for zlib header (0x78 0x9C or similar) */
    if (data[0] != 0x78 || (data[1] != 0x9C && data[1] != 0xDA && data[1] != 0x01)) {
        /* Not compressed, return copy */
        GFX_DEBUG("M3G: Data not zlib compressed, returning copy");
        uint8_t* result = malloc(data_size);
        if (result) {
            memcpy(result, data, data_size);
            *out_size = data_size;
        }
        return result;
    }

    GFX_DEBUG("M3G: Decompressing zlib data, input size=%zu", data_size);

    z_stream strm;
    memset(&strm, 0, sizeof(strm));

    if (inflateInit(&strm) != Z_OK) {
        GFX_DEBUG("M3G: inflateInit failed");
        return NULL;
    }

    strm.next_in = (Bytef*)data;
    strm.avail_in = data_size;

    /* FIX: Two-pass decompression - first determine exact size needed */
    /* Use a small stack buffer for the first pass to estimate size */
    #define PROBE_BUF_SIZE 4096
    uint8_t probe_buf[PROBE_BUF_SIZE];
    size_t total_out_estimate = 0;
    
    /* First pass: decompress in chunks to count total output size */
    int ret = Z_OK;
    while (ret == Z_OK) {
        strm.next_out = probe_buf;
        strm.avail_out = PROBE_BUF_SIZE;
        ret = inflate(&strm, Z_NO_FLUSH);
        if (ret == Z_OK || ret == Z_STREAM_END) {
            total_out_estimate += (PROBE_BUF_SIZE - strm.avail_out);
        }
    }
    
    if (ret != Z_STREAM_END) {
        GFX_DEBUG("M3G: First pass inflate failed with code %d", ret);
        inflateEnd(&strm);
        return NULL;
    }
    
    *out_size = strm.total_out;
    inflateEnd(&strm);
    
    GFX_DEBUG("M3G: First pass complete, exact output size=%zu bytes", *out_size);

    /* Second pass: allocate exact size and decompress */
    uint8_t* result = malloc(*out_size);
    if (!result) {
        GFX_DEBUG("M3G: Failed to allocate exact buffer of %zu bytes", *out_size);
        return NULL;
    }

    /* Reinitialize for second pass */
    memset(&strm, 0, sizeof(strm));
    if (inflateInit(&strm) != Z_OK) {
        GFX_DEBUG("M3G: inflateInit failed on second pass");
        free(result);
        return NULL;
    }

    strm.next_in = (Bytef*)data;
    strm.avail_in = data_size;
    strm.next_out = result;
    strm.avail_out = *out_size;

    ret = inflate(&strm, Z_FINISH);
    if (ret != Z_STREAM_END && ret != Z_OK) {
        GFX_DEBUG("M3G: Second pass inflate failed with code %d", ret);
        inflateEnd(&strm);
        free(result);
        return NULL;
    }

    inflateEnd(&strm);
    GFX_DEBUG("M3G: Successfully decompressed %zu bytes to %zu bytes", data_size, *out_size);
    
    return result;
}

/* Read a 32-bit little-endian value */
static uint32_t m3g_read_u32(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos + 4 > max) return 0;
    uint32_t val = data[*pos] | (data[*pos+1] << 8) | (data[*pos+2] << 16) | (data[*pos+3] << 24);
    *pos += 4;
    return val;
}

/* Read a 16-bit little-endian value */
static uint16_t m3g_read_u16(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos + 2 > max) return 0;
    uint16_t val = data[*pos] | (data[*pos+1] << 8);
    *pos += 2;
    return val;
}

/* Read a byte */
static uint8_t m3g_read_u8(const uint8_t* data, size_t* pos, size_t max) {
    if (*pos >= max) return 0;
    return data[(*pos)++];
}

/* Read a float (32-bit IEEE 754) */
static float m3g_read_float(const uint8_t* data, size_t* pos, size_t max) {
    union { uint32_t i; float f; } u;
    u.i = m3g_read_u32(data, pos, max);
    return u.f;
}

/* ============================================================================
 * M3G Object Data Reading Helpers (per JSR-184 spec)
 * ============================================================================ */

/* Skip Object3D base data: userID already read, then animationTrackCount + refs, userObjectCount + data */
static void m3g_skip_object3d_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* Animation tracks count and references */
    uint32_t track_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < track_count; i++) {
        m3g_read_u32(data, pos, data_size);  /* Skip track reference */
    }

    /* User object count and data */
    uint32_t user_object_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < user_object_count; i++) {
        uint32_t key = m3g_read_u32(data, pos, data_size);
        (void)key;
        uint32_t value_len = m3g_read_u32(data, pos, data_size);
        *pos += value_len;  /* Skip value bytes */
    }
}

/* Skip Transformable data after Object3D data */
static void m3g_skip_transformable_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* hasComponentTransform (boolean) */
    uint8_t has_component = m3g_read_u8(data, pos, data_size);
    if (has_component) {
        /* translation: 3 floats */
        *pos += 12;
        /* scale: 3 floats */
        *pos += 12;
        /* orientation: angle + 3 axis floats */
        *pos += 16;
    }

    /* hasGeneralTransform (boolean) */
    uint8_t has_general = m3g_read_u8(data, pos, data_size);
    if (has_general) {
        /* 4x4 matrix = 16 floats = 64 bytes */
        *pos += 64;
    }
}

/* Skip Node data after Transformable data */
static void m3g_skip_node_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* renderingEnable (boolean) */
    m3g_read_u8(data, pos, data_size);
    /* pickingEnable (boolean) */
    m3g_read_u8(data, pos, data_size);
    /* alphaFactor (byte) */
    m3g_read_u8(data, pos, data_size);
    /* scope (uint32) */
    m3g_read_u32(data, pos, data_size);

    /* hasAlignment (boolean) */
    uint8_t has_alignment = m3g_read_u8(data, pos, data_size);
    if (has_alignment) {
        /* alignmentTarget for Z, Y */
        m3g_read_u8(data, pos, data_size);
        m3g_read_u8(data, pos, data_size);
        /* reference indices */
        m3g_read_u32(data, pos, data_size);
        m3g_read_u32(data, pos, data_size);
    }
}

/* Skip Group data after Node data */
static void m3g_skip_group_data(const uint8_t* data, size_t data_size, size_t* pos) {
    /* child count */
    uint32_t child_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < child_count; i++) {
        m3g_read_u32(data, pos, data_size);  /* Skip child reference */
    }
}

/* Read and store Object3D data, return userID */
static uint32_t m3g_read_object3d_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, M3GParseContext* ctx) {
    /* userID already read by caller */
    uint32_t user_id = 0;  /* Caller should pass this */

    /* Animation tracks count and references - store count for later */
    uint32_t track_count = m3g_read_u32(data, pos, data_size);
    (void)track_count;
    for (uint32_t i = 0; i < track_count; i++) {
        m3g_read_u32(data, pos, data_size);  /* Skip track reference for now */
    }

    /* User object count and data */
    uint32_t user_object_count = m3g_read_u32(data, pos, data_size);
    for (uint32_t i = 0; i < user_object_count; i++) {
        uint32_t key = m3g_read_u32(data, pos, data_size);
        (void)key;
        uint32_t value_len = m3g_read_u32(data, pos, data_size);
        *pos += value_len;
    }

    return user_id;
}

/* Read Transformable data after Object3D data */
static void m3g_read_transformable_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, JVM* jvm) {
    /* hasComponentTransform (boolean) */
    uint8_t has_component = m3g_read_u8(data, pos, data_size);
    if (has_component) {
        /* translation: 3 floats */
        float tx = m3g_read_float(data, pos, data_size);
        float ty = m3g_read_float(data, pos, data_size);
        float tz = m3g_read_float(data, pos, data_size);
        /* scale: 3 floats */
        float sx = m3g_read_float(data, pos, data_size);
        float sy = m3g_read_float(data, pos, data_size);
        float sz = m3g_read_float(data, pos, data_size);
        /* orientation: angle + 3 axis floats */
        float angle = m3g_read_float(data, pos, data_size);
        float ax = m3g_read_float(data, pos, data_size);
        float ay = m3g_read_float(data, pos, data_size);
        float az = m3g_read_float(data, pos, data_size);

        /* Store transform data */
        m3g_set_float_field(obj, "translationX", tx);
        m3g_set_float_field(obj, "translationY", ty);
        m3g_set_float_field(obj, "translationZ", tz);
        m3g_set_float_field(obj, "scaleX", sx);
        m3g_set_float_field(obj, "scaleY", sy);
        m3g_set_float_field(obj, "scaleZ", sz);
        m3g_set_float_field(obj, "orientationAngle", angle);
        m3g_set_float_field(obj, "orientationX", ax);
        m3g_set_float_field(obj, "orientationY", ay);
        m3g_set_float_field(obj, "orientationZ", az);

        GFX_DEBUG("M3G: Transform tx=%.2f ty=%.2f tz=%.2f sx=%.2f sy=%.2f sz=%.2f",
                 tx, ty, tz, sx, sy, sz);
    }

    /* hasGeneralTransform (boolean) */
    uint8_t has_general = m3g_read_u8(data, pos, data_size);
    if (has_general) {
        /* 4x4 matrix = 16 floats = 64 bytes */
        /* Store in transform matrix field */
        JavaArray* matrix = jvm_new_array(jvm, T_FLOAT, 16, NULL);
        if (matrix) {
            float* m = (float*)array_data(matrix);
            for (int i = 0; i < 16; i++) {
                m[i] = m3g_read_float(data, pos, data_size);
            }
            m3g_set_ref_field(obj, "transform", (JavaObject*)matrix);
        } else {
            *pos += 64;  /* Skip if can't allocate */
        }
    }
}

/* Read Node data after Transformable data */
static void m3g_read_node_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos) {
    /* renderingEnable (boolean) */
    uint8_t rendering_enable = m3g_read_u8(data, pos, data_size);
    m3g_set_int_field(obj, "renderingEnable", rendering_enable);

    /* pickingEnable (boolean) */
    uint8_t picking_enable = m3g_read_u8(data, pos, data_size);
    m3g_set_int_field(obj, "pickingEnable", picking_enable);

    /* alphaFactor (byte) - stored as float 0.0-1.0 */
    uint8_t alpha_factor = m3g_read_u8(data, pos, data_size);
    m3g_set_float_field(obj, "alphaFactor", alpha_factor / 255.0f);

    /* scope (uint32) */
    uint32_t scope = m3g_read_u32(data, pos, data_size);
    m3g_set_int_field(obj, "scope", scope);

    /* hasAlignment (boolean) */
    uint8_t has_alignment = m3g_read_u8(data, pos, data_size);
    if (has_alignment) {
        /* Skip alignment for now */
        m3g_read_u8(data, pos, data_size);  /* zTarget */
        m3g_read_u8(data, pos, data_size);  /* yTarget */
        m3g_read_u32(data, pos, data_size); /* zReference */
        m3g_read_u32(data, pos, data_size); /* yReference */
    }

    GFX_DEBUG("M3G: Node rendering=%d picking=%d alpha=%.2f scope=%u",
             rendering_enable, picking_enable, alpha_factor / 255.0f, scope);
}

/* Read Group data after Node data, store child refs for later linking */
static void m3g_read_group_data(JavaObject* obj, const uint8_t* data, size_t data_size, size_t* pos, JVM* jvm) {
    /* child count */
    uint32_t child_count = m3g_read_u32(data, pos, data_size);

    /* Store child count for linking */
    m3g_set_int_field(obj, "childCount", child_count);

    /* Create children array to store refs temporarily */
    if (child_count > 0) {
        JavaArray* child_refs = jvm_new_array(jvm, T_INT, child_count, NULL);
        if (child_refs) {
            jint* refs = (jint*)array_data(child_refs);
            for (uint32_t i = 0; i < child_count; i++) {
                refs[i] = (jint)m3g_read_u32(data, pos, data_size);
            }
            m3g_set_ref_field(obj, "_childRefs", (JavaObject*)child_refs);  /* Temporary storage */
        }
    }

    GFX_DEBUG("M3G: Group childCount=%u", child_count);
}

/* Parse a single M3G object (obj_type already read, read data only) */
/* Returns object or NULL (for unimplemented/failed parsing) */
/* Objects are stored at their file position index; reference N = objects[N] */
static JavaObject* m3g_parse_object(JVM* jvm, M3GParseContext* ctx,
                                    const uint8_t* data, size_t data_size,
                                    size_t* pos, uint8_t obj_type, uint32_t obj_length) {
    if (*pos >= data_size) return NULL;

    (void)obj_length;  /* Used by caller to skip */
    GFX_DEBUG("M3G: Parsing object type=%d at pos=%zu", obj_type, *pos);

    /* Read userID first - ALL M3G objects start with this (4 bytes) */
    uint32_t user_id = m3g_read_u32(data, pos, data_size);
    GFX_DEBUG("M3G: Object type=%d userID=%u", obj_type, user_id);

    switch (obj_type) {
        case M3G_OBJ_HEADER: {
            /* Header object - version info (already read in section parsing) */
            /* Skip rest of header - it was already processed */
            GFX_DEBUG("M3G: Header object (internal, not stored)");
            return NULL;  /* Header is NOT stored in objects array */
        }

        case M3G_OBJ_WORLD: {
            JavaClass* world_class = jvm_load_class(jvm, "javax/microedition/m3g/World");
            if (!world_class) return NULL;

            JavaObject* world = jvm_new_object(jvm, world_class);
            if (world) {
                m3g_set_int_field(world, "userID", user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Group -> World */
                m3g_read_object3d_data(world, data, data_size, pos, ctx);
                m3g_read_transformable_data(world, data, data_size, pos, jvm);
                m3g_read_node_data(world, data, data_size, pos);
                m3g_read_group_data(world, data, data_size, pos, jvm);

                /* World-specific: activeCamera and background references */
                uint32_t camera_ref = m3g_read_u32(data, pos, data_size);
                uint32_t bg_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(world, "activeCameraRef", camera_ref);
                m3g_set_int_field(world, "backgroundRef", bg_ref);

                ctx->world = world;
                GFX_DEBUG("M3G: Created World userID=%u cameraRef=%u bgRef=%u", user_id, camera_ref, bg_ref);
            }
            return world;
        }

        case M3G_OBJ_CAMERA: {
            JavaClass* camera_class = jvm_load_class(jvm, "javax/microedition/m3g/Camera");
            if (!camera_class) return NULL;

            JavaObject* camera = jvm_new_object(jvm, camera_class);
            if (camera) {
                m3g_set_int_field(camera, "userID", user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Camera */
                m3g_read_object3d_data(camera, data, data_size, pos, ctx);
                m3g_read_transformable_data(camera, data, data_size, pos, jvm);
                m3g_read_node_data(camera, data, data_size, pos);

                /* Camera-specific: projection */
                uint8_t proj_type = m3g_read_u8(data, pos, data_size);
                m3g_set_int_field(camera, "projectionType", proj_type);

                if (proj_type == 48) { /* GENERIC */
                    /* 4x4 matrix = 16 floats */
                    for (int i = 0; i < 16; i++) {
                        m3g_read_float(data, pos, data_size);
                    }
                } else if (proj_type == 50) { /* PERSPECTIVE */
                    float fov = m3g_read_float(data, pos, data_size);
                    float aspect = m3g_read_float(data, pos, data_size);
                    float near = m3g_read_float(data, pos, data_size);
                    float far = m3g_read_float(data, pos, data_size);
                    m3g_set_float_field(camera, "fov", fov);
                    m3g_set_float_field(camera, "near", near);
                    m3g_set_float_field(camera, "far", far);
                    (void)aspect;
                } else if (proj_type == 49) { /* PARALLEL */
                    float width = m3g_read_float(data, pos, data_size);
                    float height = m3g_read_float(data, pos, data_size);
                    float near = m3g_read_float(data, pos, data_size);
                    float far = m3g_read_float(data, pos, data_size);
                    m3g_set_float_field(camera, "near", near);
                    m3g_set_float_field(camera, "far", far);
                    (void)width; (void)height;
                }

                ctx->camera = camera;
                GFX_DEBUG("M3G: Created Camera userID=%u proj=%d", user_id, proj_type);
            }
            return camera;
        }

        case M3G_OBJ_LIGHT: {
            JavaClass* light_class = jvm_load_class(jvm, "javax/microedition/m3g/Light");
            if (!light_class) return NULL;

            JavaObject* light = jvm_new_object(jvm, light_class);
            if (light) {
                m3g_set_int_field(light, "userID", user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Light */
                m3g_read_object3d_data(light, data, data_size, pos, ctx);
                m3g_read_transformable_data(light, data, data_size, pos, jvm);
                m3g_read_node_data(light, data, data_size, pos);

                /* Light-specific: attenuation, color, mode, intensity, spot */
                float att0 = m3g_read_float(data, pos, data_size);
                float att1 = m3g_read_float(data, pos, data_size);
                float att2 = m3g_read_float(data, pos, data_size);
                uint32_t color = m3g_read_u32(data, pos, data_size);
                uint8_t mode = m3g_read_u8(data, pos, data_size);
                float intensity = m3g_read_float(data, pos, data_size);
                float spot_angle = m3g_read_float(data, pos, data_size);
                float spot_exp = m3g_read_float(data, pos, data_size);

                m3g_set_int_field(light, "lightType", mode);
                m3g_set_int_field(light, "color", color);
                m3g_set_float_field(light, "intensity", intensity);
                (void)att0; (void)att1; (void)att2;
                (void)spot_angle; (void)spot_exp;

                ctx->light = light;
                GFX_DEBUG("M3G: Created Light userID=%u mode=%d color=0x%08X", user_id, mode, color);
            }
            return light;
        }

        case M3G_OBJ_BACKGROUND: {
            JavaClass* bg_class = jvm_load_class(jvm, "javax/microedition/m3g/Background");
            if (!bg_class) return NULL;

            JavaObject* bg = jvm_new_object(jvm, bg_class);
            if (bg) {
                m3g_set_int_field(bg, "userID", user_id);

                /* Object3D data */
                m3g_read_object3d_data(bg, data, data_size, pos, ctx);

                /* Background-specific */
                uint32_t bg_color = m3g_read_u32(data, pos, data_size);
                uint32_t image_ref = m3g_read_u32(data, pos, data_size);
                uint8_t mode_x = m3g_read_u8(data, pos, data_size);
                uint8_t mode_y = m3g_read_u8(data, pos, data_size);
                int32_t crop_x = m3g_read_u32(data, pos, data_size);  /* signed */
                int32_t crop_y = m3g_read_u32(data, pos, data_size);
                int32_t crop_w = m3g_read_u32(data, pos, data_size);
                int32_t crop_h = m3g_read_u32(data, pos, data_size);
                uint8_t depth_clear = m3g_read_u8(data, pos, data_size);
                uint8_t color_clear = m3g_read_u8(data, pos, data_size);

                m3g_set_int_field(bg, "clearColor", bg_color);
                m3g_set_int_field(bg, "imageRef", image_ref);
                m3g_set_int_field(bg, "depthClearEnable", depth_clear);
                m3g_set_int_field(bg, "colorClearEnable", color_clear);
                (void)mode_x; (void)mode_y;
                (void)crop_x; (void)crop_y; (void)crop_w; (void)crop_h;

                ctx->background = bg;
                GFX_DEBUG("M3G: Created Background userID=%u color=0x%08X", user_id, bg_color);
            }
            return bg;
        }

        case M3G_OBJ_MESH: {
            JavaClass* mesh_class = jvm_load_class(jvm, "javax/microedition/m3g/Mesh");
            if (!mesh_class) return NULL;

            JavaObject* mesh = jvm_new_object(jvm, mesh_class);
            if (mesh) {
                m3g_set_int_field(mesh, "userID", user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Mesh */
                m3g_read_object3d_data(mesh, data, data_size, pos, ctx);
                m3g_read_transformable_data(mesh, data, data_size, pos, jvm);
                m3g_read_node_data(mesh, data, data_size, pos);

                /* Mesh-specific: vertexBuffer ref, then submeshCount, indexBuffer/appearance refs */
                uint32_t vb_ref = m3g_read_u32(data, pos, data_size);
                uint32_t submesh_count = m3g_read_u32(data, pos, data_size);

                m3g_set_int_field(mesh, "vertexBufferRef", vb_ref);
                m3g_set_int_field(mesh, "submeshCount", submesh_count);

                /* Read index buffer and appearance refs for each submesh */
                /* Store first submesh refs for linking */
                uint32_t ib_ref = 0, app_ref = 0;
                for (uint32_t i = 0; i < submesh_count; i++) {
                    uint32_t this_ib = m3g_read_u32(data, pos, data_size);
                    uint32_t this_app = m3g_read_u32(data, pos, data_size);
                    if (i == 0) {
                        ib_ref = this_ib;
                        app_ref = this_app;
                    }
                }
                m3g_set_int_field(mesh, "indexBufferRef", ib_ref);
                m3g_set_int_field(mesh, "appearanceRef", app_ref);

                ctx->mesh = mesh;
                GFX_DEBUG("M3G: Created Mesh userID=%u vbRef=%u ibRef=%u appRef=%u submeshCount=%u",
                         user_id, vb_ref, ib_ref, app_ref, submesh_count);
            }
            return mesh;
        }

        case M3G_OBJ_VERTEXBUFFER: {
            JavaClass* vb_class = jvm_load_class(jvm, "javax/microedition/m3g/VertexBuffer");
            if (!vb_class) return NULL;

            JavaObject* vb = jvm_new_object(jvm, vb_class);
            if (vb) {
                m3g_set_int_field(vb, "userID", user_id);

                /* Object3D data */
                m3g_read_object3d_data(vb, data, data_size, pos, ctx);

                /* VertexBuffer-specific */
                uint32_t default_color = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(vb, "defaultColor", default_color);

                /* Positions: ref + scale + bias */
                uint32_t pos_ref = m3g_read_u32(data, pos, data_size);
                float scale = m3g_read_float(data, pos, data_size);
                float bias_x = m3g_read_float(data, pos, data_size);
                float bias_y = m3g_read_float(data, pos, data_size);
                float bias_z = m3g_read_float(data, pos, data_size);

                m3g_set_int_field(vb, "positionsRef", pos_ref);
                m3g_set_float_field(vb, "positionScale", scale);
                m3g_set_float_field(vb, "biasX", bias_x);
                m3g_set_float_field(vb, "biasY", bias_y);
                m3g_set_float_field(vb, "biasZ", bias_z);

                /* Normals ref */
                uint32_t norm_ref = m3g_read_u32(data, pos, data_size);
                m3g_set_int_field(vb, "normalsRef", norm_ref);

                /* Colors ref */
                uint32_t color_ref = m3g_read_u32(data, pos, data_size);
                (void)color_ref;

                /* TexCoord arrays */
                uint32_t tex_count = m3g_read_u32(data, pos, data_size);
                for (uint32_t i = 0; i < tex_count; i++) {
                    m3g_read_u32(data, pos, data_size);  /* texCoord ref */
                    m3g_read_float(data, pos, data_size);  /* scale */
                    m3g_read_float(data, pos, data_size);  /* bias x */
                    m3g_read_float(data, pos, data_size);  /* bias y */
                    m3g_read_float(data, pos, data_size);  /* bias z (usually 0) */
                }

                ctx->vertex_buffer = vb;
                GFX_DEBUG("M3G: Created VertexBuffer userID=%u posRef=%u normRef=%u",
                         user_id, pos_ref, norm_ref);
            }
            return vb;
        }

        case M3G_OBJ_VERTEXARRAY: {
            JavaClass* va_class = jvm_load_class(jvm, "javax/microedition/m3g/VertexArray");
            if (!va_class) return NULL;

            JavaObject* va = jvm_new_object(jvm, va_class);
            if (va) {
                m3g_set_int_field(va, "userID", user_id);

                /* Object3D data */
                m3g_read_object3d_data(va, data, data_size, pos, ctx);

                /* VertexArray-specific */
                uint8_t component_count = m3g_read_u8(data, pos, data_size);
                uint8_t component_size = m3g_read_u8(data, pos, data_size);
                uint8_t encoding = m3g_read_u8(data, pos, data_size);
                uint16_t vertex_count = m3g_read_u16(data, pos, data_size);

                /* Sanity checks */
                if (component_count > 4) component_count = 4;
                if (component_size > 2) component_size = 2;

                int data_size_total = (int)vertex_count * component_count * component_size;
                if (data_size_total <= 0 || data_size_total > M3G_MAX_VERTEX_COUNT * 4 * 2) {
                    GFX_DEBUG("M3G: VertexArray data_size invalid: %d", data_size_total);
                    return va;
                }

                m3g_set_int_field(va, "componentCount", component_count);
                m3g_set_int_field(va, "componentSize", component_size);
                m3g_set_int_field(va, "vertexCount", vertex_count);

                /* Create data array */
                JavaArray* arr = jvm_new_array(jvm, component_size == 1 ? T_BYTE : T_SHORT,
                                                data_size_total, NULL);
                if (arr) {
                    m3g_set_ref_field(va, "data", (JavaObject*)arr);
                    void* dst = array_data(arr);

                    if (encoding == 0) { /* Raw */
                        memcpy(dst, &data[*pos], data_size_total);
                    } else { /* Delta encoding */
                        /* Skip for now - complex encoding */
                    }
                }
                *pos += data_size_total;

                GFX_DEBUG("M3G: Created VertexArray userID=%u %d vertices, %d components",
                         user_id, vertex_count, component_count);
            }
            return va;
        }

        case M3G_OBJ_TRIANGLESTRIPARRAY: {
            JavaClass* ib_class = jvm_load_class(jvm, "javax/microedition/m3g/TriangleStripArray");
            if (!ib_class) return NULL;

            JavaObject* ib = jvm_new_object(jvm, ib_class);
            if (ib) {
                m3g_set_int_field(ib, "userID", user_id);

                /* Object3D data */
                m3g_read_object3d_data(ib, data, data_size, pos, ctx);

                /* TriangleStripArray-specific: encoding, then indices */
                uint8_t encoding = m3g_read_u8(data, pos, data_size);

                uint32_t first_index = 0;
                uint32_t strip_count = 0;

                switch (encoding) {
                    case 0:  /* Explicit first index */
                        first_index = m3g_read_u32(data, pos, data_size);
                        break;
                    case 1:
                        first_index = m3g_read_u8(data, pos, data_size);
                        break;
                    case 2:
                        first_index = m3g_read_u16(data, pos, data_size);
                        break;
                    case 128: /* Array indices */
                    case 129:
                    case 130:
                        {
                            uint32_t count = m3g_read_u32(data, pos, data_size);
                            for (uint32_t i = 0; i < count; i++) {
                                if (encoding == 128) m3g_read_u32(data, pos, data_size);
                                else if (encoding == 129) m3g_read_u8(data, pos, data_size);
                                else m3g_read_u16(data, pos, data_size);
                            }
                        }
                        break;
                }

                /* Strip lengths */
                strip_count = m3g_read_u32(data, pos, data_size);
                for (uint32_t i = 0; i < strip_count; i++) {
                    m3g_read_u32(data, pos, data_size);  /* strip length */
                }

                ctx->index_buffer = ib;
                GFX_DEBUG("M3G: Created TriangleStripArray userID=%u encoding=%d strips=%u",
                         user_id, encoding, strip_count);
            }
            return ib;
        }

        case M3G_OBJ_APPEARANCE: {
            JavaClass* app_class = jvm_load_class(jvm, "javax/microedition/m3g/Appearance");
            if (!app_class) return NULL;

            JavaObject* app = jvm_new_object(jvm, app_class);
            if (app) {
                m3g_set_int_field(app, "userID", user_id);

                /* Object3D data */
                m3g_read_object3d_data(app, data, data_size, pos, ctx);

                /* Appearance-specific */
                uint8_t layer = m3g_read_u8(data, pos, data_size);
                m3g_set_int_field(app, "layer", layer);

                /* References: compositingMode, fog, polygonMode, material */
                m3g_read_u32(data, pos, data_size);  /* compositingMode */
                m3g_read_u32(data, pos, data_size);  /* fog */
                m3g_read_u32(data, pos, data_size);  /* polygonMode */
                m3g_read_u32(data, pos, data_size);  /* material */

                /* Textures */
                uint32_t tex_count = m3g_read_u32(data, pos, data_size);
                for (uint32_t i = 0; i < tex_count; i++) {
                    m3g_read_u32(data, pos, data_size);  /* texture ref */
                }

                ctx->appearance = app;
                GFX_DEBUG("M3G: Created Appearance userID=%u layer=%d texCount=%u",
                         user_id, layer, tex_count);
            }
            return app;
        }

        case M3G_OBJ_GROUP: {
            JavaClass* group_class = jvm_load_class(jvm, "javax/microedition/m3g/Group");
            if (!group_class) return NULL;

            JavaObject* group = jvm_new_object(jvm, group_class);
            if (group) {
                m3g_set_int_field(group, "userID", user_id);

                /* Read full hierarchy: Object3D -> Transformable -> Node -> Group */
                m3g_read_object3d_data(group, data, data_size, pos, ctx);
                m3g_read_transformable_data(group, data, data_size, pos, jvm);
                m3g_read_node_data(group, data, data_size, pos);
                m3g_read_group_data(group, data, data_size, pos, jvm);

                GFX_DEBUG("M3G: Created Group userID=%u", user_id);
            }
            return group;
        }

        default:
            /* Skip unknown object types */
            GFX_DEBUG("M3G: Skipping unknown object type %d userID=%u", obj_type, user_id);
            return NULL;
    }
}

/* Loader.load(String name) - M3G file loading with correct section parsing */
/* FIX: Completely rewritten to match JSR-184 M3G specification */
static JavaValue native_loader_load(JVM* jvm, JavaThread* thread,
                                     JavaValue* args, int arg_count) {
    (void)thread; (void)arg_count;
    JavaString* name_str = (JavaString*)args[0].ref;

    /* Resources that need cleanup */
    uint8_t* data = NULL;
    uint8_t* decompressed = NULL;
    JavaObject** objects = NULL;
    JavaArray* result = NULL;

    /* Result variables */
    JavaClass* world_class = NULL;
    JavaClass* camera_class = NULL;
    JavaClass* bg_class = NULL;
    JavaClass* light_class = NULL;

    /* Parse context - objects stored sequentially, M3G refs are: ref-2 = array index */
    M3GParseContext ctx = {0};
    ctx.object_count = 0;     /* Objects stored sequentially starting at index 0 */
    ctx.object_capacity = 256;
    ctx.objects = calloc(ctx.object_capacity, sizeof(JavaObject*));
    objects = ctx.objects;  /* Track for cleanup */

    if (!ctx.objects) {
        GFX_DEBUG("Loader.load: Failed to allocate objects array");
        goto cleanup_error;
    }

    if (!name_str) {
        GFX_DEBUG("Loader.load: null name string");
        goto cleanup_error;
    }

    const char* name = string_utf8(jvm, name_str);
    GFX_DEBUG("Loader.load: loading '%s'", name ? name : "NULL");

    if (!name) {
        goto cleanup_error;
    }

    /* Skip leading slash if present */
    const char* resource_name = name;
    if (resource_name[0] == '/') {
        resource_name++;
    }

    /* Try to load from JAR */
    size_t data_size;
    data = load_jar_resource(resource_name, &data_size);

    if (!data) {
        GFX_DEBUG("Loader.load: file '%s' not found in JAR", resource_name);
        fprintf(stderr, "[M3G] File '%s' not found in JAR\n", resource_name);
        /* Still create a World even if file not found - game might use default */
    } else {
        GFX_DEBUG("Loader.load: loaded %zu bytes from '%s'", data_size, resource_name);
        fprintf(stderr, "[M3G] Loaded '%s' (%zu bytes)\n", resource_name, data_size);
    }

    /* Parse M3G file if we have data */
    if (data && data_size >= 12) {
        /* Check M3G magic: 0xAB 'J' 'S' 'R' '1' '8' '4' 0xBB 0x0D 0x0A 0x1A 0x0A */
        if (data[0] == M3G_MAGIC1 && 
            strncmp((char*)&data[1], "JSR184", 6) == 0 && 
            data[7] == M3G_MAGIC2 &&
            data[8] == 0x0D && data[9] == 0x0A &&
            data[10] == 0x1A && data[11] == 0x0A) {
            
            GFX_DEBUG("Loader.load: Valid M3G file detected, size=%zu", data_size);
            
            size_t file_pos = 12;  /* Start after magic identifier */
            int section_count = 0;
            uint32_t total_file_size = 0;
            
            /* Parse sections according to M3G spec */
            while (file_pos + 13 <= data_size && section_count < 100) {
                /* Read section header */
                uint8_t compression_scheme = data[file_pos++];
                uint32_t total_section_length = data[file_pos] | (data[file_pos+1] << 8) | 
                                                (data[file_pos+2] << 16) | (data[file_pos+3] << 24);
                file_pos += 4;
                uint32_t uncompressed_length = data[file_pos] | (data[file_pos+1] << 8) | 
                                               (data[file_pos+2] << 16) | (data[file_pos+3] << 24);
                file_pos += 4;
                
                GFX_DEBUG("M3G: Section %d: compression=%d, totalLen=%u, uncompressedLen=%u",
                         section_count, compression_scheme, total_section_length, uncompressed_length);
                
                /* Sanity check: section length must be reasonable */
                if (total_section_length < 13 || total_section_length > data_size) {
                    GFX_DEBUG("M3G: Invalid section length %u, stopping", total_section_length);
                    break;
                }
                
                /* Calculate section data boundaries */
                size_t section_data_start = file_pos;
                size_t section_data_size = total_section_length - 13;  /* Minus header and checksum */
                
                /* Get section data (decompress if needed) */
                uint8_t* section_data;
                size_t section_data_len;
                
                if (compression_scheme == 0) {
                    /* Uncompressed section */
                    section_data = &data[section_data_start];
                    section_data_len = section_data_size;
                } else if (compression_scheme == 1) {
                    /* Zlib compressed section */
                    section_data = m3g_decompress(&data[section_data_start], section_data_size, &section_data_len);
                    decompressed = section_data;  /* Track for cleanup */
                    
                    if (!section_data || section_data_len != uncompressed_length) {
                        GFX_DEBUG("M3G: Decompression failed or size mismatch (got %zu, expected %u)",
                                 section_data_len, uncompressed_length);
                        if (section_data) {
                            free(section_data);
                            decompressed = NULL;
                        }
                        goto next_section;
                    }
                } else {
                    GFX_DEBUG("M3G: Unknown compression scheme %d", compression_scheme);
                    goto next_section;
                }
                
                /* Parse objects within section */
                if (section_data && section_data_len > 0) {
                    size_t obj_pos = 0;
                    
                    while (obj_pos < section_data_len) {
                        /* Read object type and length */
                        if (obj_pos + 5 > section_data_len) break;
                        
                        uint8_t obj_type = section_data[obj_pos++];
                        uint32_t obj_length = section_data[obj_pos] | (section_data[obj_pos+1] << 8) |
                                            (section_data[obj_pos+2] << 16) | (section_data[obj_pos+3] << 24);
                        obj_pos += 4;
                        
                        GFX_DEBUG("M3G: Object type=%d length=%u at pos=%zu", 
                                 obj_type, obj_length, obj_pos - 5);
                        
                        /* Validate object length */
                        if (obj_length == 0 || obj_pos + obj_length > section_data_len) {
                            GFX_DEBUG("M3G: Invalid object length %u, skipping", obj_length);
                            break;
                        }
                        
                        /* Parse object based on type */
                        size_t obj_start = obj_pos;
                        
                        GFX_DEBUG("M3G: Object type=%d len=%u at offset %zu", 
                                 obj_type, obj_length, obj_start);
                        
                        switch (obj_type) {
                            case 0:  /* Header Object (inside first section) */
                                if (obj_length >= 7) {
                                    uint8_t version_major = section_data[obj_pos++];
                                    uint8_t version_minor = section_data[obj_pos++];
                                    /* hasExternalReferences */ obj_pos++;
                                    total_file_size = section_data[obj_pos] | (section_data[obj_pos+1] << 8) |
                                                     (section_data[obj_pos+2] << 16) | (section_data[obj_pos+3] << 24);
                                    obj_pos += 4;
                                    /* approximateContentSize */ obj_pos += 4;
                                    /* authoringField (string) - skip */
                                    GFX_DEBUG("M3G: Header v%d.%d totalSize=%u",
                                             version_major, version_minor, total_file_size);
                                }
                                /* CRITICAL: Store NULL for header to preserve indices */
                                /* Header is at index 0, making ref 1 invalid (points to header) */
                                if (ctx.object_count < ctx.object_capacity) {
                                    ctx.objects[ctx.object_count] = NULL;  /* Header placeholder */
                                    ctx.object_count++;
                                }
                                break;
                                
                            case 255:  /* External Reference */
                                GFX_DEBUG("M3G: External reference, skipping %u bytes", obj_length);
                                obj_pos += obj_length;
                                /* External references are NOT stored in the objects array */
                                break;
                                
                            case M3G_OBJ_ANIMATIONCONTROLLER:
                            case M3G_OBJ_ANIMATIONTRACK:
                            case M3G_OBJ_KEYFRAMESEQUENCE:
                                /* Animation objects - skip parsing but STORE NULL placeholder */
                                GFX_DEBUG("M3G: Animation obj %d at index %d (storing NULL placeholder)",
                                         obj_type, ctx.object_count);
                                obj_pos += obj_length;
                                if (ctx.object_count < ctx.object_capacity) {
                                    ctx.objects[ctx.object_count] = NULL;  /* Placeholder */
                                    ctx.object_count++;
                                }
                                break;

                            default: {
                                /* Parse object - returns object or NULL */
                                size_t saved_pos = obj_pos;
                                JavaObject* parsed = m3g_parse_object(jvm, &ctx, section_data, section_data_len, &obj_pos, obj_type, obj_length);
                                if (!parsed) {
                                    /* If parsing failed, skip the object data */
                                    obj_pos = saved_pos + obj_length;
                                }
                                /* CRITICAL: Always increment count to preserve indices */
                                /* Store object (or NULL if parsing failed) */
                                if (ctx.object_count < ctx.object_capacity) {
                                    ctx.objects[ctx.object_count] = parsed;  /* May be NULL */
                                    ctx.object_count++;
                                    GFX_DEBUG("M3G: Stored %s at array[%d] (M3G ref=%d) -> %p",
                                             parsed ? "object" : "NULL", ctx.object_count - 1, 
                                             ctx.object_count + 1, (void*)parsed);
                                }
                                break;
                            }
                        }
                        
                        /* Always ensure we move past this object */
                        obj_pos = obj_start + obj_length;
                        
                        /* Safety check */
                        if (obj_pos > section_data_len) {
                            GFX_DEBUG("M3G: obj_pos %zu > section_data_len %zu, breaking", 
                                     obj_pos, section_data_len);
                            break;
                        }
                    }
                }
                
                /* Free decompressed data if we allocated it */
                if (compression_scheme == 1 && section_data) {
                    free(section_data);
                    decompressed = NULL;
                }
                
            next_section:
                /* Move to next section (skip checksum at end) */
                file_pos = section_data_start + section_data_size + 4;  /* +4 for checksum */
                section_count++;
            }
            
            GFX_DEBUG("M3G: Parsed %d sections, %d objects", section_count, ctx.object_count);
            fprintf(stderr, "[M3G] Parsed %d sections, %d objects\n", section_count, ctx.object_count);
        } else {
            GFX_DEBUG("Loader.load: Invalid M3G magic, creating default World");
            fprintf(stderr, "[M3G] Invalid M3G magic, will create default World\n");
        }
    } else if (data) {
        fprintf(stderr, "[M3G] Data too small (%zu bytes), creating default World\n", data_size);
    } else {
        fprintf(stderr, "[M3G] No data loaded, creating default World\n");
    }

    /* Link objects by indices */
    /* M3G reference system: ref 0 = null, ref N = objects[N] (direct index)
     * Objects are stored at their file position index (including NULL for header/skipped)
     * So a reference of 5 points directly to objects[5]
     */
    GFX_DEBUG("Loader.load: Linking %d objects...", ctx.object_count);
    for (int i = 0; i < ctx.object_count; i++) {
        JavaObject* obj = ctx.objects[i];
        if (!obj || !obj->header.clazz) continue;

        const char* class_name = obj->header.clazz->class_name;

        /* Link Mesh to VertexBuffer, IndexBuffer, Appearance */
        if (strstr(class_name, "Mesh")) {
            int vb_ref = m3g_get_int_field(obj, "vertexBufferRef", 0);
            int ib_ref = m3g_get_int_field(obj, "indexBufferRef", 0);
            int app_ref = m3g_get_int_field(obj, "appearanceRef", 0);

            /* M3G reference: ref N = objects[N] (direct index) */
            if (vb_ref > 0 && vb_ref < ctx.object_count && ctx.objects[vb_ref]) {
                m3g_set_ref_field(obj, "vertexBuffer", ctx.objects[vb_ref]);
                GFX_DEBUG("M3G: Linked Mesh VB[ref=%d] -> %p", vb_ref, ctx.objects[vb_ref]);
            }
            if (ib_ref > 0 && ib_ref < ctx.object_count && ctx.objects[ib_ref]) {
                m3g_set_ref_field(obj, "indexBuffer", ctx.objects[ib_ref]);
                GFX_DEBUG("M3G: Linked Mesh IB[ref=%d] -> %p", ib_ref, ctx.objects[ib_ref]);
            }
            if (app_ref > 0 && app_ref < ctx.object_count && ctx.objects[app_ref]) {
                m3g_set_ref_field(obj, "appearance", ctx.objects[app_ref]);
                GFX_DEBUG("M3G: Linked Mesh App[ref=%d] -> %p", app_ref, ctx.objects[app_ref]);
            }
        }

        /* Link VertexBuffer to VertexArrays */
        if (strstr(class_name, "VertexBuffer")) {
            int pos_ref = m3g_get_int_field(obj, "positionsRef", 0);
            int norm_ref = m3g_get_int_field(obj, "normalsRef", 0);

            if (pos_ref > 0 && pos_ref < ctx.object_count && ctx.objects[pos_ref]) {
                m3g_set_ref_field(obj, "positions", ctx.objects[pos_ref]);
                GFX_DEBUG("M3G: Linked VertexBuffer positions[ref=%d]", pos_ref);
            }
            if (norm_ref > 0 && norm_ref < ctx.object_count && ctx.objects[norm_ref]) {
                m3g_set_ref_field(obj, "normals", ctx.objects[norm_ref]);
            }
        }

        /* Resolve Group child references from _childRefs */
        if (strstr(class_name, "Group") || strstr(class_name, "World")) {
            JavaArray* child_refs = (JavaArray*)m3g_get_ref_field(obj, "_childRefs");
            if (child_refs && child_refs->element_type == T_INT) {
                jint* refs = (jint*)array_data(child_refs);
                int child_count = child_refs->length;

                /* Create children array if needed */
                JavaArray* children = (JavaArray*)m3g_get_ref_field(obj, "children");
                if (!children) {
                    children = jvm_new_array(jvm, DESC_OBJECT, child_count > 0 ? child_count : 16, NULL);
                    if (children) {
                        m3g_set_ref_field(obj, "children", (JavaObject*)children);
                    }
                }

                if (children && children->element_type == DESC_OBJECT) {
                    JavaObject** child_arr = (JavaObject**)array_data(children);
                    int added = 0;

                    for (int c = 0; c < child_count && added < children->length; c++) {
                        int child_ref = refs[c];
                        /* M3G reference: ref N = objects[N] (direct index) */
                        if (child_ref > 0 && child_ref < ctx.object_count && ctx.objects[child_ref]) {
                            child_arr[added++] = ctx.objects[child_ref];
                            GFX_DEBUG("M3G: Linked Group child[%d] = ref %d -> %p",
                                     added - 1, child_ref, ctx.objects[child_ref]);
                        }
                    }
                }

                /* Clear temporary storage */
                m3g_set_ref_field(obj, "_childRefs", NULL);
            }
        }

        /* Add Mesh to World if we have both */
        if (strstr(class_name, "Mesh") && ctx.world) {
            /* Add to World's children array */
            JavaArray* children = (JavaArray*)m3g_get_ref_field(ctx.world, "children");
            if (!children) {
                children = jvm_new_array(jvm, DESC_OBJECT, 16, NULL);
                if (children) {
                    m3g_set_ref_field(ctx.world, "children", (JavaObject*)children);
                }
            }
            if (children) {
                /* Find empty slot */
                JavaObject** arr = (JavaObject**)array_data(children);
                for (jsize j = 0; j < children->length; j++) {
                    if (!arr[j]) {
                        arr[j] = obj;
                        GFX_DEBUG("M3G: Added Mesh to World children[%d]", j);
                        break;
                    }
                }
            }
        }
    }

    /* Resolve World's activeCamera and background references */
    if (ctx.world) {
        int camera_ref = m3g_get_int_field(ctx.world, "activeCameraRef", 0);
        int bg_ref = m3g_get_int_field(ctx.world, "backgroundRef", 0);

        if (camera_ref > 0 && camera_ref < ctx.object_count && ctx.objects[camera_ref]) {
            m3g_set_ref_field(ctx.world, "activeCamera", ctx.objects[camera_ref]);
            GFX_DEBUG("M3G: Linked World activeCamera[ref=%d] -> %p", camera_ref, ctx.objects[camera_ref]);
        }
        if (bg_ref > 0 && bg_ref < ctx.object_count && ctx.objects[bg_ref]) {
            m3g_set_ref_field(ctx.world, "background", ctx.objects[bg_ref]);
            GFX_DEBUG("M3G: Linked World background[ref=%d] -> %p", bg_ref, ctx.objects[bg_ref]);
        }
    }

    /* Create World object if not found during parsing */
    world_class = jvm_load_class(jvm, "javax/microedition/m3g/World");
    if (!world_class) {
        GFX_DEBUG("Loader.load: World class not found");
        goto cleanup_error;
    }

    if (!ctx.world) {
        ctx.world = jvm_new_object(jvm, world_class);
        if (ctx.world) {
            m3g_set_int_field(ctx.world, "scope", -1);
        }
    }

    if (!ctx.world) {
        GFX_DEBUG("Loader.load: failed to create World");
        goto cleanup_error;
    }

    /* Create and attach Camera if not found during parsing */
    if (!ctx.camera) {
        camera_class = jvm_load_class(jvm, "javax/microedition/m3g/Camera");
        if (camera_class) {
            ctx.camera = jvm_new_object(jvm, camera_class);
            if (ctx.camera) {
                m3g_set_int_field(ctx.camera, "projectionType", 1);  /* Perspective */
                m3g_set_float_field(ctx.camera, "fov", 60.0f);
                m3g_set_float_field(ctx.camera, "near", 1.0f);
                m3g_set_float_field(ctx.camera, "far", 1000.0f);
                GFX_DEBUG("Loader.load: created default Camera");
            }
        }
    }

    /* Set active camera on world */
    if (ctx.camera) {
        m3g_set_ref_field(ctx.world, "activeCamera", ctx.camera);
    }

    /* Create Background if not found */
    if (!ctx.background) {
        bg_class = jvm_load_class(jvm, "javax/microedition/m3g/Background");
        if (bg_class) {
            ctx.background = jvm_new_object(jvm, bg_class);
            if (ctx.background) {
                m3g_set_int_field(ctx.background, "clearColor", 0xFF202020);
            }
        }
    }

    if (ctx.background) {
        m3g_set_ref_field(ctx.world, "background", ctx.background);
    }

    /* Create default Light if not found */
    if (!ctx.light) {
        light_class = jvm_load_class(jvm, "javax/microedition/m3g/Light");
        if (light_class) {
            ctx.light = jvm_new_object(jvm, light_class);
            if (ctx.light) {
                m3g_set_int_field(ctx.light, "lightType", 2);  /* Directional */
                m3g_set_int_field(ctx.light, "color", 0xFFFFFFFF);
                m3g_set_float_field(ctx.light, "intensity", 1.0f);
                GFX_DEBUG("Loader.load: created default Light");
            }
        }
    }

    /* Success: prepare result */
    /* The returned array should contain only non-null objects for game compatibility.
     * Reference resolution is done internally using ctx.objects[] with correct indices.
     * Games typically access objects[0] as World, or use World.find(userID).
     */

    /* Count non-null objects for result array */
    int valid_count = 0;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i]) valid_count++;
    }

    /* Ensure we include World */
    bool world_in_objects = false;
    for (int i = 0; i < ctx.object_count; i++) {
        if (ctx.objects[i] == ctx.world) {
            world_in_objects = true;
            break;
        }
    }
    if (ctx.world && !world_in_objects) valid_count++;

    /* Ensure at least 1 slot if we have a world */
    if (valid_count == 0 && ctx.world) valid_count = 1;

    GFX_DEBUG("Loader.load: %d objects stored, %d valid, world=%p",
             ctx.object_count, valid_count, (void*)ctx.world);

    result = jvm_new_array(jvm, DESC_OBJECT, valid_count, NULL);
    if (result) {
        JavaObject** arr = (JavaObject**)array_data(result);
        int idx = 0;

        /* Add non-null objects to result array */
        for (int i = 0; i < ctx.object_count && idx < valid_count; i++) {
            if (ctx.objects[i]) {
                arr[idx++] = ctx.objects[i];
                GFX_DEBUG("Loader.load: result[%d] = %p (file index %d)",
                         idx - 1, (void*)ctx.objects[i], i);
            }
        }

        /* Add world if not already included */
        if (ctx.world && !world_in_objects && idx < valid_count) {
            arr[idx++] = ctx.world;
            GFX_DEBUG("Loader.load: result[%d] = %p (created World)",
                     idx - 1, (void*)ctx.world);
        }
    }

    fprintf(stderr, "[M3G] Returning array[%d] with World=%p\n", valid_count, (void*)ctx.world);

    /* Cleanup and return success */
    if (data) free(data);
    if (objects) free(objects);
    return NATIVE_RETURN_OBJECT(result);

cleanup_error:
    /* FIX: Centralized cleanup for all error paths */
    if (data) free(data);
    if (decompressed) free(decompressed);
    if (objects) free(objects);
    return NATIVE_RETURN_NULL();
}

/* Loader.load(byte[] data, int offset) - Load from byte array */
static JavaValue native_loader_load_bytes(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaArray* data = (JavaArray*)args[0].ref;
    jint offset = args[1].i;
    
    if (!data) {
        GFX_DEBUG("Loader.load: null data");
        return NATIVE_RETURN_NULL();
    }
    
    GFX_DEBUG("Loader.load: byte[%d] at offset %d (M3G parsing not yet implemented)", 
            data->length, offset);
    
    /* TODO: Implement M3G binary file parsing */
    /* M3G file format is a binary format with sections for:
     * - Header
     * - External objects (textures, etc.)
     * - Scene graph objects
     * - Animation data
     */
    
    return NATIVE_RETURN_NULL();
}

/* RayIntersection methods for picking */
static JavaValue native_rayintersection_getDistance(JVM* jvm, JavaThread* thread,
                                                    JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_FLOAT(0.0f);
    
    /* Get distance from field */
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "distance") == 0) {
            return NATIVE_RETURN_FLOAT(obj->fields[i].f);
        }
    }
    
    return NATIVE_RETURN_FLOAT(0.0f);
}

static JavaValue native_rayintersection_getIntersected(JVM* jvm, JavaThread* thread,
                                                        JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    
    if (!obj) return NATIVE_RETURN_NULL();
    
    JavaClass* clazz = obj->header.clazz;
    for (int i = 0; i < clazz->fields_count; i++) {
        if (clazz->fields[i].name && strcmp(clazz->fields[i].name, "intersected") == 0) {
            return NATIVE_RETURN_OBJECT(obj->fields[i].ref);
        }
    }
    
    return NATIVE_RETURN_NULL();
}

/* Graphics3D.addLight(Light, Transform) */
static JavaValue native_graphics3d_addLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    JavaObject* light = (JavaObject*)args[1].ref;
    JavaObject* transform = (JavaObject*)args[2].ref;
    (void)g3d; (void)transform;
    
    if (!light) return NATIVE_RETURN_VOID();
    
    /* Add light to context */
    if (g_m3g.light_count < 8) {
        /* Get light properties from object */
        int idx = g_m3g.light_count++;
        memset(&g_m3g.lights[idx], 0, sizeof(M3GLight));
        
        JavaClass* light_class = light->header.clazz;
        for (int i = 0; i < light_class->fields_count; i++) {
            if (!light_class->fields[i].name) continue;
            if (strcmp(light_class->fields[i].name, "type") == 0) {
                g_m3g.lights[idx].type = light->fields[i].i;
            } else if (strcmp(light_class->fields[i].name, "color") == 0) {
                int argb = light->fields[i].i;
                g_m3g.lights[idx].color[0] = ((argb >> 16) & 0xFF) / 255.0f;
                g_m3g.lights[idx].color[1] = ((argb >> 8) & 0xFF) / 255.0f;
                g_m3g.lights[idx].color[2] = (argb & 0xFF) / 255.0f;
            } else if (strcmp(light_class->fields[i].name, "intensity") == 0) {
                g_m3g.lights[idx].color[3] = light->fields[i].f;
            }
        }
        
        GFX_DEBUG("Graphics3D.addLight: type=%d (idx=%d)", g_m3g.lights[idx].type, idx);
    }
    
    return NATIVE_RETURN_VOID();
}

/* Graphics3D.setLight(int index, Light, Transform) */
static JavaValue native_graphics3d_setLight(JVM* jvm, JavaThread* thread,
                                             JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* g3d = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    JavaObject* light = (JavaObject*)args[2].ref;
    JavaObject* transform = (JavaObject*)args[3].ref;
    (void)g3d; (void)transform;
    
    if (index < 0 || index >= 8) return NATIVE_RETURN_VOID();
    
    if (light) {
        /* Update light at index */
        memset(&g_m3g.lights[index], 0, sizeof(M3GLight));
        
        JavaClass* light_class = light->header.clazz;
        for (int i = 0; i < light_class->fields_count; i++) {
            if (!light_class->fields[i].name) continue;
            if (strcmp(light_class->fields[i].name, "type") == 0) {
                g_m3g.lights[index].type = light->fields[i].i;
            }
        }
        
        GFX_DEBUG("Graphics3D.setLight: index=%d", index);
    } else {
        /* Remove light */
        if (index < g_m3g.light_count) {
            g_m3g.lights[index].type = 0;
        }
    }
    
    return NATIVE_RETURN_VOID();
}

/* AnimationTrack methods */
static JavaValue native_animationtrack_setController(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* track = (JavaObject*)args[0].ref;
    JavaObject* controller = (JavaObject*)args[1].ref;
    (void)track; (void)controller;
    
    GFX_DEBUG("AnimationTrack.setController");
    return NATIVE_RETURN_VOID();
}

/* KeyframeSequence methods */
static JavaValue native_keyframesequence_setKeyframe(JVM* jvm, JavaThread* thread,
                                                      JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* seq = (JavaObject*)args[0].ref;
    jint index = args[1].i;
    jint time = args[2].i;
    JavaArray* values = (JavaArray*)args[3].ref;
    (void)seq; (void)index; (void)time; (void)values;
    
    GFX_DEBUG("KeyframeSequence.setKeyframe: index=%d, time=%d", index, time);
    return NATIVE_RETURN_VOID();
}

/* Sprite3D methods */
static JavaValue native_sprite3d_init(JVM* jvm, JavaThread* thread,
                                       JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    jboolean scaled = args[1].i;
    JavaObject* image = (JavaObject*)args[2].ref;
    JavaObject* appearance = (JavaObject*)args[3].ref;
    (void)obj; (void)scaled; (void)image; (void)appearance;
    
    GFX_DEBUG("Sprite3D.<init>");
    return NATIVE_RETURN_VOID();
}

static JavaValue native_sprite3d_setImage(JVM* jvm, JavaThread* thread,
                                           JavaValue* args, int arg_count) {
    (void)jvm; (void)thread; (void)arg_count;
    JavaObject* obj = (JavaObject*)args[0].ref;
    JavaObject* image = (JavaObject*)args[1].ref;
    (void)obj; (void)image;
    
    GFX_DEBUG("Sprite3D.setImage");
    return NATIVE_RETURN_VOID();
}

/* ============================================================================
 * Stub Class Registration for M3G Classes
 * ============================================================================ */

/* Additional stub classes for M3G */
static const struct {
    const char* name;
    const char* super;
    uint16_t flags;
} m3g_stub_classes[] = {
    /* Core M3G classes */
    { "javax/microedition/m3g/Graphics3D", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Object3D", "java/lang/Object", 1 | 1024 },
    { "javax/microedition/m3g/Transform", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Node", "javax/microedition/m3g/Object3D", 1 | 1024 },
    { "javax/microedition/m3g/Group", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/World", "javax/microedition/m3g/Group", 1 },
    { "javax/microedition/m3g/Camera", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Mesh", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Sprite3D", "javax/microedition/m3g/Node", 1 },
    { "javax/microedition/m3g/Light", "javax/microedition/m3g/Node", 1 },
    
    /* Vertex data */
    { "javax/microedition/m3g/VertexArray", "java/lang/Object", 1 },
    { "javax/microedition/m3g/VertexBuffer", "java/lang/Object", 1 },
    { "javax/microedition/m3g/IndexBuffer", "java/lang/Object", 1 | 1024 },
    { "javax/microedition/m3g/TriangleStripArray", "javax/microedition/m3g/IndexBuffer", 1 },
    
    /* Appearance */
    { "javax/microedition/m3g/Appearance", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Material", "java/lang/Object", 1 },
    { "javax/microedition/m3g/Texture2D", "javax/microedition/m3g/Object3D", 1 },
    { "javax/microedition/m3g/CompositingMode", "java/lang/Object", 1 },
    { "javax/microedition/m3g/PolygonMode", "java/lang/Object", 1 },
    
    /* Image and background */
    { "javax/microedition/m3g/Image2D", "javax/microedition/m3g/Object3D", 1 },
    { "javax/microedition/m3g/Background", "javax/microedition/m3g/Object3D", 1 },
    
    /* Animation */
    { "javax/microedition/m3g/AnimationController", "java/lang/Object", 1 },
    { "javax/microedition/m3g/AnimationTrack", "java/lang/Object", 1 },
    { "javax/microedition/m3g/KeyframeSequence", "java/lang/Object", 1 },
    
    /* Morphing and skinning */
    { "javax/microedition/m3g/MorphingMesh", "javax/microedition/m3g/Mesh", 1 },
    { "javax/microedition/m3g/SkinnedMesh", "javax/microedition/m3g/Mesh", 1 },
    
    /* Loader and picking */
    { "javax/microedition/m3g/Loader", "java/lang/Object", 1 },
    { "javax/microedition/m3g/RayIntersection", "java/lang/Object", 1 },
    
    { NULL, NULL, 0 }
};

/* Register M3G stub classes */
int init_m3g_stub_classes(JVM* jvm) {
    if (!jvm) return 0;
    
    int count = 0;
    
    /* Use get_or_create_stub_class from stubs.c to create classes */
    extern JavaClass* get_or_create_stub_class(JVM* jvm, const char* class_name);
    
    for (int i = 0; m3g_stub_classes[i].name != NULL; i++) {
        /* get_or_create_stub_class will check if already loaded */
        JavaClass* stub = get_or_create_stub_class(jvm, m3g_stub_classes[i].name);
        if (!stub) continue;
        
        count++;
    }
    
    GFX_DEBUG("Registered %d M3G stub classes", count);
    return count;
}

/* ============================================================================
 * Native Method Registration
 * ============================================================================ */

void init_javax_microedition_m3g(JVM* jvm) {
    NativeMethodEntry methods[] = {
        /* Graphics3D */
        {"javax/microedition/m3g/Graphics3D", "getInstance", "()Ljavax/microedition/m3g/Graphics3D;", native_graphics3d_getInstance},
        {"javax/microedition/m3g/Graphics3D", "bindTarget", "(Ljavax/microedition/m3g/Image2D;)V", native_graphics3d_bindTarget},
        {"javax/microedition/m3g/Graphics3D", "releaseTarget", "()V", native_graphics3d_releaseTarget},
        {"javax/microedition/m3g/Graphics3D", "clear", "(Ljavax/microedition/m3g/Background;)V", native_graphics3d_clear},
        {"javax/microedition/m3g/Graphics3D", "setViewport", "(IIII)V", native_graphics3d_setViewport},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/World;)V", native_graphics3d_renderWorld},
        {"javax/microedition/m3g/Graphics3D", "render", "(Ljavax/microedition/m3g/Node;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_render_node},
        {"javax/microedition/m3g/Graphics3D", "addLight", "(Ljavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_addLight},
        {"javax/microedition/m3g/Graphics3D", "setLight", "(ILjavax/microedition/m3g/Light;Ljavax/microedition/m3g/Transform;)V", native_graphics3d_setLight},
        
        /* Transform */
        {"javax/microedition/m3g/Transform", "<init>", "()V", native_transform_init},
        {"javax/microedition/m3g/Transform", "<init>", "(Ljavax/microedition/m3g/Transform;)V", native_transform_init_copy},
        {"javax/microedition/m3g/Transform", "setIdentity", "()V", native_transform_setIdentity},
        {"javax/microedition/m3g/Transform", "postMultiply", "(Ljavax/microedition/m3g/Transform;)V", native_transform_postMultiply},
        {"javax/microedition/m3g/Transform", "postTranslate", "(FFF)V", native_transform_postTranslate},
        {"javax/microedition/m3g/Transform", "postRotate", "(FFFF)V", native_transform_postRotate},
        {"javax/microedition/m3g/Transform", "postScale", "(FFF)V", native_transform_postScale},
        {"javax/microedition/m3g/Transform", "invert", "()V", native_transform_invert},
        {"javax/microedition/m3g/Transform", "transform", "([F)V", native_transform_transform},
        
        /* VertexArray */
        {"javax/microedition/m3g/VertexArray", "<init>", "(III)V", native_vertexarray_init},
        {"javax/microedition/m3g/VertexArray", "set", "(II[B)V", native_vertexarray_set_byte},
        {"javax/microedition/m3g/VertexArray", "set", "(II[S)V", native_vertexarray_set_short},
        
        /* VertexBuffer */
        {"javax/microedition/m3g/VertexBuffer", "<init>", "()V", native_vertexbuffer_init},
        {"javax/microedition/m3g/VertexBuffer", "setPositions", "(Ljavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setPositions},
        {"javax/microedition/m3g/VertexBuffer", "setNormals", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setNormals},
        {"javax/microedition/m3g/VertexBuffer", "setTexCoords", "(ILjavax/microedition/m3g/VertexArray;F[F)V", native_vertexbuffer_setTexCoords},
        {"javax/microedition/m3g/VertexBuffer", "setColors", "(Ljavax/microedition/m3g/VertexArray;)V", native_vertexbuffer_setColors},
        
        /* Camera */
        {"javax/microedition/m3g/Camera", "setPerspective", "(FFFF)V", native_camera_setPerspective},
        {"javax/microedition/m3g/Camera", "setParallel", "(FFFF)V", native_camera_setParallel},
        {"javax/microedition/m3g/Camera", "setGeneric", "(Ljavax/microedition/m3g/Transform;)V", native_camera_setGeneric},
        {"javax/microedition/m3g/Camera", "lookAt", "(FFFFFFFFF)V", native_camera_lookAt},
        
        /* Light */
        {"javax/microedition/m3g/Light", "setType", "(I)V", native_light_setType},
        {"javax/microedition/m3g/Light", "setColor", "(I)V", native_light_setColor},
        {"javax/microedition/m3g/Light", "setIntensity", "(F)V", native_light_setIntensity},
        {"javax/microedition/m3g/Light", "setDirection", "(FFF)V", native_light_setDirection},
        
        /* Material */
        {"javax/microedition/m3g/Material", "setColor", "(II)V", native_material_setColor},
        {"javax/microedition/m3g/Material", "setShininess", "(F)V", native_material_setShininess},
        
        /* Appearance */
        {"javax/microedition/m3g/Appearance", "setMaterial", "(Ljavax/microedition/m3g/Material;)V", native_appearance_setMaterial},
        {"javax/microedition/m3g/Appearance", "setTexture", "(ILjavax/microedition/m3g/Texture2D;)V", native_appearance_setTexture},
        
        /* Texture2D */
        {"javax/microedition/m3g/Texture2D", "<init>", "(Ljavax/microedition/m3g/Image2D;)V", native_texture2d_init},
        {"javax/microedition/m3g/Texture2D", "setFiltering", "(I)V", native_texture2d_setFiltering},
        {"javax/microedition/m3g/Texture2D", "setWrapping", "(II)V", native_texture2d_setWrapping},
        
        /* Mesh */
        {"javax/microedition/m3g/Mesh", "<init>", "(Ljavax/microedition/m3g/VertexBuffer;Ljavax/microedition/m3g/IndexBuffer;Ljavax/microedition/m3g/Appearance;)V", native_mesh_init},
        {"javax/microedition/m3g/Mesh", "setVertexBuffer", "(ILjavax/microedition/m3g/VertexArray;)V", native_mesh_setVertexBuffer},
        
        /* TriangleStripArray */
        {"javax/microedition/m3g/TriangleStripArray", "<init>", "(I[I)V", native_trianglestrip_init},
        
        /* Node */
        {"javax/microedition/m3g/Node", "setScale", "(FFF)V", native_node_setScale},
        {"javax/microedition/m3g/Node", "setTranslation", "(FFF)V", native_node_setTranslation},
        {"javax/microedition/m3g/Node", "setRotation", "(FFFF)V", native_node_setRotation},
        {"javax/microedition/m3g/Node", "getTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_getTransform},
        {"javax/microedition/m3g/Node", "setTransform", "(Ljavax/microedition/m3g/Transform;)V", native_node_setTransform},
        {"javax/microedition/m3g/Node", "setAlphaFactor", "(F)V", native_node_setAlphaFactor},
        
        /* Group */
        {"javax/microedition/m3g/Group", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_group_addChild},
        {"javax/microedition/m3g/Group", "removeChild", "(Ljavax/microedition/m3g/Node;)V", native_group_removeChild},
        {"javax/microedition/m3g/Group", "getChild", "(I)Ljavax/microedition/m3g/Node;", native_group_getChild},
        
        /* World */
        {"javax/microedition/m3g/World", "addCamera", "(Ljavax/microedition/m3g/Camera;)V", native_world_addCamera},
        {"javax/microedition/m3g/World", "setBackground", "(Ljavax/microedition/m3g/Background;)V", native_world_setBackground},
        {"javax/microedition/m3g/World", "addChild", "(Ljavax/microedition/m3g/Node;)V", native_world_addChild},
        {"javax/microedition/m3g/World", "getActiveCamera", "()Ljavax/microedition/m3g/Camera;", native_world_getActiveCamera},
        
        /* Object3D */
        {"javax/microedition/m3g/Object3D", "find", "(I)Ljavax/microedition/m3g/Object3D;", native_object3d_find},
        {"javax/microedition/m3g/Object3D", "getUserID", "()I", native_object3d_getUserID},
        {"javax/microedition/m3g/Object3D", "setUserID", "(I)V", native_object3d_setUserID},
        {"javax/microedition/m3g/Object3D", "duplicate", "()Ljavax/microedition/m3g/Object3D;", native_object3d_duplicate},
        
        /* Background */
        {"javax/microedition/m3g/Background", "setColor", "(I)V", native_background_setColor},
        
        /* Image2D */
        {"javax/microedition/m3g/Image2D", "<init>", "(III)V", native_image2d_init},
        {"javax/microedition/m3g/Image2D", "<init>", "(ILjava/lang/Object;)V", native_image2d_init_from_image},
        {"javax/microedition/m3g/Image2D", "set", "(IIII[B)V", native_image2d_set},
        
        /* CompositingMode */
        {"javax/microedition/m3g/CompositingMode", "setBlending", "(I)V", native_compositingmode_setBlending},
        
        /* PolygonMode */
        {"javax/microedition/m3g/PolygonMode", "setCulling", "(I)V", native_polygonmode_setCulling},
        
        /* Loader */
        {"javax/microedition/m3g/Loader", "load", "(Ljava/lang/String;)[Ljavax/microedition/m3g/Object3D;", native_loader_load},
        {"javax/microedition/m3g/Loader", "load", "([BI)[Ljavax/microedition/m3g/Object3D;", native_loader_load_bytes},
        
        /* RayIntersection */
        {"javax/microedition/m3g/RayIntersection", "getDistance", "()F", native_rayintersection_getDistance},
        {"javax/microedition/m3g/RayIntersection", "getIntersected", "()Ljavax/microedition/m3g/Node;", native_rayintersection_getIntersected},
        
        /* AnimationTrack */
        {"javax/microedition/m3g/AnimationTrack", "setController", "(Ljavax/microedition/m3g/AnimationController;)V", native_animationtrack_setController},
        
        /* KeyframeSequence */
        {"javax/microedition/m3g/KeyframeSequence", "setKeyframe", "(II[F)V", native_keyframesequence_setKeyframe},
        
        /* Sprite3D */
        {"javax/microedition/m3g/Sprite3D", "<init>", "(ZLjavax/microedition/m3g/Image2D;Ljavax/microedition/m3g/Appearance;)V", native_sprite3d_init},
        {"javax/microedition/m3g/Sprite3D", "setImage", "(Ljavax/microedition/m3g/Image2D;)V", native_sprite3d_setImage},
    };
    
    native_register_methods(jvm, methods, sizeof(methods) / sizeof(methods[0]));
    
    /* Register stub classes */
    init_m3g_stub_classes(jvm);
    
    GFX_DEBUG("Registered %zu native methods for JSR 184", 
            sizeof(methods) / sizeof(methods[0]));
}
