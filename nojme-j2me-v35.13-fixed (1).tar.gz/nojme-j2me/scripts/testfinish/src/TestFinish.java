import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/* TestFinish — v34.72 "MIDlet finished screen" selftest.
 *
 * Shows a blue Canvas; FIRE (joypad A) calls notifyDestroyed(). The core
 * must then keep presenting an explicit BLACK "MIDlet finished" screen
 * (instead of a frozen last game frame) for every following retro_run().
 *
 * Expected SYSOUT sequence:
 *   FINISH-START
 *   FINISH-KEY <keyCode>
 *   FINISH-DESTROYED (from destroyApp — proves the AMS delivered it)
 */
public class TestFinish extends MIDlet {
    private Display display;
    private Canvas canvas;

    public TestFinish() {
        canvas = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 255);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(255, 255, 0);
                g.fillRect(10, 10, 60, 60);
                g.fillRect(170, 250, 60, 60);
            }
            protected void keyPressed(int keyCode) {
                if (keyCode == FIRE || keyCode == '5') {
                    p("FINISH-KEY " + keyCode);
                    notifyDestroyed();
                }
            }
        };
    }

    protected void startApp() {
        p("FINISH-START");
        if (display == null) display = Display.getDisplay(this);
        display.setCurrent(canvas);
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) {
        p("FINISH-DESTROYED");
    }

    private static void p(String s) {
        System.out.println("[SYSOUT] " + s);
    }
}
