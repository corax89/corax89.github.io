import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/* TestBack — v34.72 "Cancel exits the list, not the application" selftest.
 *
 * MAIN list  : commands Open(SCREEN)+Open2(SCREEN), listener attached.
 *              Left soft = Open -> SUB, right soft = Open2 -> SUB2.
 * SUB list   : single command Cancel(BACK), listener attached; the
 *              listener handles it by returning to MAIN. Pre-v34.72 the
 *              emulator killed the VM right after this listener ran
 *              (BACK was in the stop-list) — the app "terminated" on
 *              Cancel. Now the app must survive.
 * SUB2 list  : single command Cancel(BACK), NO listener — a dead Cancel.
 *              Pre-v34.72 this did nothing at all; now the emulator
 *              emulates the phone back key (history stack) and returns
 *              to MAIN.
 *
 * Expected SYSOUT sequence for the standard run:
 *   BACK-START
 *   BACK-OPEN-SUB
 *   BACK-CANCEL-HANDLED       (listener path; VM must survive!)
 *   BACK-AT-MAIN
 *   BACK-OPEN-SUB2
 *   BACK-EMULATED             (dead-cancel path -> emulator back-nav)
 *   BACK-ALIVE-AT-END         (final probe: VM still running at frame N)
 */
public class TestBack extends MIDlet implements CommandListener {
    private Display display;
    private List main, sub, sub2;
    private Command openCmd, open2Cmd, cancelCmd;

    protected void startApp() {
        p("BACK-START");
        if (display == null) display = Display.getDisplay(this);

        main = new List("MAIN", List.IMPLICIT);
        main.append("Go SUB", null);
        main.append("Go SUB2", null);
        openCmd = new Command("Open", Command.SCREEN, 1);
        open2Cmd = new Command("Open2", Command.SCREEN, 2);
        main.addCommand(openCmd);
        main.addCommand(open2Cmd);
        main.setCommandListener(this);

        sub = new List("SUB", List.IMPLICIT);
        sub.append("item", null);
        cancelCmd = new Command("Cancel", Command.BACK, 1);
        sub.addCommand(cancelCmd);
        sub.setCommandListener(this);

        sub2 = new List("SUB2", List.IMPLICIT);
        sub2.append("item", null);
        sub2.addCommand(new Command("Cancel", Command.BACK, 1));
        /* NOTE: no setCommandListener here — dead Cancel on purpose. */

        display.setCurrent(main);
    }

    public void commandAction(Command c, Displayable d) {
        if (c == openCmd) {
            p("BACK-OPEN-SUB");
            display.setCurrent(sub);
        } else if (c == open2Cmd) {
            p("BACK-OPEN-SUB2");
            display.setCurrent(sub2);
        } else if (c == cancelCmd) {
            p("BACK-CANCEL-HANDLED");
            display.setCurrent(main);
            p("BACK-AT-MAIN");
        }
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) {
        p("BACK-DESTROYED (should NOT happen in this test!)");
    }

    private static void p(String s) {
        System.out.println("[SYSOUT] " + s);
    }
}
