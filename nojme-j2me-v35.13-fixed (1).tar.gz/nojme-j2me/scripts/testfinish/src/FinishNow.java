import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/* FinishNow — the midlet finishes INSIDE startApp (notifyDestroyed before
 * the event loop starts). Pre-v34.72 main.c force-revived the VM here and
 * the app sat on a frozen screen forever. Now the loop must exit and the
 * explicit finished screen must be drawn. */
public class FinishNow extends MIDlet {
    protected void startApp() {
        System.out.println("[SYSOUT] NOW-START");
        notifyDestroyed();
    }
    protected void pauseApp() {}
    protected void destroyApp(boolean u) {
        System.out.println("[SYSOUT] NOW-DESTROYED");
    }
}
