#!/bin/bash
# Build TestFinish.jar + TestBack.jar — v34.72 selftests:
#  * finished-screen (notifyDestroyed -> explicit black screen, no freeze)
#  * cancel-exits-list-not-app (BACK/CANCEL never terminate; dead Cancel
#    emulates phone back-navigation)
# Class version 48 (no stack maps); only the test classes are packaged —
# the emulator supplies the midlet/lcdui classes at runtime.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestFinish.java" \
    "$D/src/TestBack.java" \
    "$D/src/FinishNow.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

make_jar() {
    local NAME="$1"
    local PKG="$OUT/pkg_$NAME"
    rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
    printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , %s\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' "$NAME" \
        > "$PKG/META-INF/MANIFEST.MF"
    # include INNER classes too: NAME.class, NAME$1.class, ...
    cp "$OUT/$NAME"*.class "$PKG/"
    # NOTE: this zip build does not expand quoted patterns the way one
    # would expect for '*.class' (verified empirically) — list the files
    # explicitly: shell glob expansion happens outside of zip.
    ( cd "$PKG" && zip -q -r "$D/$NAME.jar" META-INF && zip -q "$D/$NAME.jar" *.class )
}

make_jar TestFinish
make_jar TestBack
make_jar FinishNow
echo "built: $D/TestFinish.jar $D/TestBack.jar"
