import javax.microedition.midlet.*;

/* TestDosWrite — v34.84 selftest for DataOutputStream.write([BII)V.
 *
 * v34.83 evidence: a midlet wrote 240x320 RGB565 video frames via
 * dos.write(buf, 0, 153600) — every call hit [INVOKE-MISSING] and the
 * whole frame was silently dropped (stub no-op). This test exercises the
 * 3-arg write and the exact byte contract around it:
 *
 *   dos.write(buf, 64, 100)   -> bytes 64..163 first (THE FIX)
 *   dos.writeInt(0x11223344)  -> 11 22 33 44 right after the range
 *   dos.write(buf)            -> full 256-byte copy (v34.6 regression)
 *   dos.write(42)             -> trailing single byte (v34.47 regression)
 *
 * Expected total: 100 + 4 + 256 + 1 = 361 bytes, content checked byte
 * for byte. Success prints "TDW:DONE ALL DOS CHECKS PASSED".
 */
public class TestDosWrite extends MIDlet {
    protected void startApp() {
        int errs = 0;
        try {
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
            java.io.DataOutputStream dos = new java.io.DataOutputStream(baos);

            byte[] buf = new byte[256];
            for (int i = 0; i < 256; i++) buf[i] = (byte) i;

            dos.write(buf, 64, 100);
            dos.writeInt(0x11223344);
            dos.write(buf);
            dos.write(42);
            dos.flush();

            byte[] out = baos.toByteArray();
            int n = out.length;
            if (n != 361) {
                System.out.println("TDW:FAIL length=" + n + " (want 361)");
                errs++;
            }
            for (int i = 0; i < 100; i++) {
                if (out[i] != (byte) (64 + i)) {
                    errs++;
                    if (errs < 5) System.out.println("TDW:FAIL off-copy at " + i + " got " + (out[i] & 0xFF));
                }
            }
            if (out[100] != 0x11 || out[101] != 0x22 || out[102] != 0x33 || out[103] != 0x44) {
                System.out.println("TDW:FAIL writeInt after offset-write: "
                        + (out[100] & 0xFF) + " " + (out[101] & 0xFF) + " "
                        + (out[102] & 0xFF) + " " + (out[103] & 0xFF));
                errs++;
            }
            for (int i = 0; i < 256; i++) {
                if (out[104 + i] != (byte) i) {
                    errs++;
                    if (errs < 5) System.out.println("TDW:FAIL full-copy at " + i + " got " + (out[104 + i] & 0xFF));
                }
            }
            if (out.length > 360 && out[360] != 42) {
                System.out.println("TDW:FAIL trailing byte got " + (out[360] & 0xFF));
                errs++;
            }

            /* Offset-write at the tail boundary: len shorter than the array,
             * must not touch bytes beyond off+len. */
            java.io.ByteArrayOutputStream b2 = new java.io.ByteArrayOutputStream();
            java.io.DataOutputStream d2 = new java.io.DataOutputStream(b2);
            d2.write(buf, 200, 56); /* exactly to the end of the array */
            byte[] o2 = b2.toByteArray();
            if (o2.length != 56) {
                System.out.println("TDW:FAIL tail-boundary length=" + o2.length + " (want 56)");
                errs++;
            } else {
                for (int i = 0; i < 56; i++) {
                    if (o2[i] != (byte) (200 + i)) {
                        errs++;
                        if (errs < 5) System.out.println("TDW:FAIL tail-boundary at " + i);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("TDW:EXCEPTION " + e);
            errs++;
        }
        System.out.println(errs == 0 ? "TDW:DONE ALL DOS CHECKS PASSED" : ("TDW:FAILED " + errs + " errors"));
        notifyDestroyed();
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) {}
}
