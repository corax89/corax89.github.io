#!/bin/bash
# Build TestDosWrite.jar — v34.84 selftest for the
# DataOutputStream.write(byte[],int,int) registration (was INVOKE-MISSING).
#
# Run:  ./bin/j2me-headless scripts/testdosw/TestDosWrite.jar
# Expect SYSOUT: "TDW:DONE ALL DOS CHECKS PASSED"
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestDosWrite.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestDosWrite\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/TestDosWrite"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestDosWrite.jar" META-INF && zip -q "$D/TestDosWrite.jar" *.class )
echo "built: $D/TestDosWrite.jar"
