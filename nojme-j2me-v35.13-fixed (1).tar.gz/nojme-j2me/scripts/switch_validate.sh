#!/bin/bash
# v34.87 Switch portability validation - REAL newlib/libnx header surface.
#
# Why this exists: the v34.86 validation compiled the Switch source set with
# the HOST gcc, whose glibc headers silently declare everything glibc has
# (e.g. the SVID `timezone` global). devkitA64's newlib does NOT declare it -
# the user's real build failed on exactly that gap. This script compiles
# every Switch source against the EXACT header surface devkitA64 sees:
#
#   - devkitPro newlib fork headers (github.com/devkitPro/newlib, branch
#     "devkitPro": libc/include + machine/aarch64/{sys,machine} overlays),
#     emulating the toolchain's <prefix>/aarch64-none-elf/include tree
#   - libnx headers (github.com/switchbrew/libnx, nx/include)
#   - an aarch64 cross gcc with -nostdinc (xPack aarch64-none-elf-gcc 14.2,
#     same GCC generation as devkitA64) + its internal include dir
#
# It also audits the LINK surface: every undefined symbol in the produced
# .o files must be satisfied by newlib's libc/libm or by libgloss/libsysbase
# (devkitPro's pthread layer, libgloss/libsysbase/pthread.c), modulo SDL2_*
# (the real switch-SDL2 portlib is not available for this check).
#
# All paths are env-overridable; defaults point at the sandbox layout.
set -u
T=${T:-/home/z/my-project/work/v3489/nojme-j2me}
V3487=${V3487:-/home/z/my-project/work/v3487}
CROSS=${CROSS:-$V3487/xpack/bin/aarch64-none-elf-gcc}
INTINC=${INTINC:-$V3487/xpack/lib/gcc/aarch64-none-elf/14.2.1/include}
NEWLIB_INC=${NEWLIB_INC:-$V3487/nlincl}
LIBNX_INC=${LIBNX_INC:-$V3487/libnx-master/nx/include}
SDL2_INC=${SDL2_INC:-$V3487/sdl2inc}
OUT=${OUT:-$V3487/valobj}
LIBC_A=${LIBC_A:-$V3487/xpack/aarch64-none-elf/lib/libc.a}
LIBM_A=${LIBM_A:-$V3487/xpack/aarch64-none-elf/lib/libm.a}
LIBSYSBASE_C=${LIBSYSBASE_C:-$V3487/newlib-devkitPro/libgloss/libsysbase/pthread.c}

mkdir -p "$OUT/core" "$OUT/nro"
FAIL=0

# NOTE: -mtp=soft is a devkitPro PATCH to their GCC (vanilla aarch64 gcc
# rejects it: "valid arguments are el0..el3/tpidr_*"); it only selects the
# thread-pointer access model, irrelevant for header-surface validation.
CC_BASE="-nostdinc -isystem $INTINC -isystem $NEWLIB_INC -Wall -Wextra -std=c11 \
-I$T/include -I$T/src -I$T/src/include -D__SWITCH__ -D_GNU_SOURCE -DJ2ME_DEBUG=0 \
-O1 -march=armv8-a+crc+crypto -mtune=cortex-a57 -fPIE \
-fno-strict-aliasing -fno-strict-overflow -fno-delete-null-pointer-checks \
-fno-ipa-pure-const -ffunction-sections -fdata-sections"

CORE_FLAGS="$CC_BASE -DLIBRETRO -DHAVE_LIBNX -I$LIBNX_INC"
NRO_FLAGS="$CC_BASE -I$LIBNX_INC -I$SDL2_INC"

AMRINC="-I$T/src/amr -I$T/src/amr/oscl \
-I$T/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/common/include \
-I$T/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/include \
-I$T/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src \
-I$T/src/amr/opencore/codecs_v2/audio/gsm_amr/common/dec/include"

compile_one() { # $1=flags $2=src $3=obj
    if ! $CROSS $1 -c "$2" -o "$3" 2> /tmp/val_err.txt; then
        echo "FAIL: $2"
        head -12 /tmp/val_err.txt
        FAIL=1
        return 1
    fi
    if [ -s /tmp/val_err.txt ]; then
        echo "WARN: $2"
        head -6 /tmp/val_err.txt
    fi
    return 0
}

echo "=== 1) libretro CORE source set (real newlib+libnx headers) ==="
n=0
for f in $T/src/jvm/*.c $T/src/midp/*.c $T/src/render/*.c $T/src/utils/*.c \
         $T/src/midi/*.c $T/src/libretro/*.c $T/src/switch/switch_ucontext.c; do
    compile_one "$CORE_FLAGS" "$f" "$OUT/core/$(basename $f .c).o" && n=$((n+1))
done
echo "core: $n files OK"

echo "=== 1b) AMR decoder (core flags) ==="
for f in $T/src/amr/amr_nb_dec.c \
         $T/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/common/src/*.c \
         $T/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/*.c; do
    compile_one "$CORE_FLAGS $AMRINC" "$f" "$OUT/core/amr_$(basename $f .c).o" || true
done
echo "amr done"

echo "=== 2) NRO source set (ALL_APP_SRCS + src/switch/*.c + SDL2 headers) ==="
m=0
for f in $T/src/jvm/*.c $T/src/midp/*.c $T/src/render/*.c $T/src/utils/*.c \
         $T/src/midi/*.c $T/src/sdl/sdl_graphics.c $T/src/main.c $T/src/switch/*.c; do
    compile_one "$NRO_FLAGS" "$f" "$OUT/nro/$(basename $f .c).o" && m=$((m+1))
done
echo "nro: $m files OK"

echo "=== 3) LINK-surface audit (undefined symbols vs devkitA64 providers) ==="
if [ $FAIL -eq 0 ]; then
    # Undefined symbols across all objects (core + NRO).
    nm -o $OUT/core/*.o $OUT/nro/*.o 2>/dev/null | awk '$2=="U"{print $3}' | sort -u > /tmp/val_undef.txt
    # 3a) newlib libc/libm + libgcc (atomics/emutls) from the cross gcc.
    nm --defined-only "$LIBC_A" "$LIBM_A" \
        $V3487/xpack/lib/gcc/aarch64-none-elf/14.2.1/libgcc.a 2>/dev/null \
        | awk '{print $NF}' | sed 's/.*://' | sort -u > /tmp/val_prov.txt
    # 3b) devkitPro additions: libgloss/libsysbase (pthread layer, clocks,
    #     nanosleep, usleep, utime, mkdir, fsync, _exit, syscall shims) and
    #     the fork's libc/posix dirent family. Compiled from the fork tree.
    LSB=$V3487/newlib-devkitPro/libgloss/libsysbase
    POS=$V3487/newlib-devkitPro/newlib/libc/posix
    ls /tmp/val_dkp_*.o 2>/dev/null | xargs -r rm -f
    # config.h is generated during the real libsysbase build; an empty one
    # satisfies the vendored sources for the symbol-existence check.
    mkdir -p /tmp/val_cfg && : > /tmp/val_cfg/config.h
    for f in $LSB/pthread.c $LSB/clocks.c $LSB/nanosleep.c $LSB/usleep.c \
             $LSB/utime.c $LSB/mkdir.c $LSB/fsync.c $LSB/_exit.c \
             $LSB/syscall_support.c $LSB/dirent.c \
             $POS/opendir.c $POS/readdir.c $POS/closedir.c; do
        $CROSS -nostdinc -isystem "$INTINC" -isystem "$NEWLIB_INC" \
               -I"$LSB" -I/tmp/val_cfg -D_BUILDING_LIBSYSBASE -O1 -c "$f" -o /tmp/val_dkp_$(basename $f .c).o 2>/dev/null \
            || echo "NOTE: $f not standalone-compilable (ok - symbol grep used)"
    done
    if ls /tmp/val_dkp_*.o >/dev/null 2>&1; then
        nm --defined-only /tmp/val_dkp_*.o 2>/dev/null | awk '{print $NF}' | sort -u >> /tmp/val_prov.txt
    fi
    # 3c) symbols defined by the project objects themselves (cross-TU calls).
    nm --defined-only $OUT/core/*.o $OUT/nro/*.o 2>/dev/null | awk '{print $NF}' | sort -u >> /tmp/val_prov.txt
    sort -u /tmp/val_prov.txt -o /tmp/val_prov.txt
    # Residual = undefined minus providers minus SDL2 (the real switch-SDL2
    # portlib cannot be compiled here; NRO externals are SDL2_* only).
    comm -23 /tmp/val_undef.txt /tmp/val_prov.txt | grep -v '^SDL' > /tmp/val_resid.txt
    cnt=$(wc -l < /tmp/val_resid.txt)
    if [ "$cnt" -gt 0 ]; then
        echo "UNRESOLVED ($cnt) - must be checked manually:"
        cat /tmp/val_resid.txt
        FAIL=1
    else
        echo "link surface: fully covered by newlib+libgcc+libsysbase+posix-fork+project (SDL2_* excluded by design)"
    fi
fi

if [ $FAIL -eq 0 ]; then
    echo "=== ALL v34.87 SWITCH-PORTABILITY CHECKS PASSED (real newlib headers) ==="
else
    echo "=== FAILURES FOUND ==="
fi
exit $FAIL
