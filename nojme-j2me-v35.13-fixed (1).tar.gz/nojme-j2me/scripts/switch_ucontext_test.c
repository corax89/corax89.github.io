/* switch_ucontext_test.c — v34.87
 *
 * FUNCTIONAL test for src/switch/switch_ucontext.c (the vendored aarch64
 * ucontext used by the Switch port's cooperative scheduler).
 *
 * It is built freestanding (aarch64 cross-gcc, -nostdlib, own _start) and
 * executed under qemu-aarch64; all I/O goes through raw Linux syscalls
 * (svc #0), so the binary needs neither newlib nor a hosted environment.
 * This file is never compiled into the emulator - it is a test harness.
 *
 * Verified properties:
 *   [r0] SP is 16-byte aligned at the makecontext entry point
 *   [r1] x19 == the ucontext pointer at thread entry (makecontext contract)
 *   [r2] d8 (callee-saved FP) survives a context round-trip while the
 *        other context clobbers it
 *   [r3] x19 set inside the thread survives a round-trip
 *   [r4] the starter's x19/d8 are not leaked into / corrupted by the
 *        thread across switches
 *   [r5] getcontext + setcontext re-entry returns 0 on the resumed pass
 *        (the thread-exit path in threads.c relies on this)
 *   [r6] a returning thread lands in uc_link via the exit trampoline
 *
 * Exit code: 0 = all passed, 1 = failures (each check prints OK/FAIL).
 */
#include <stdint.h>
#include <stddef.h>
#include "switch/switch_ucontext.h"

/* ---------------- freestanding runtime ---------------- */

static long sys_write(const char *buf, long len)
{
    register long x8 __asm__("x8") = 64;          /* write */
    register long x0 __asm__("x0") = 1;           /* stdout */
    register long x1 __asm__("x1") = (long)buf;
    register long x2 __asm__("x2") = len;
    __asm__ volatile("svc #0" : "+r"(x0)
                    : "r"(x8), "r"(x1), "r"(x2) : "memory");
    return x0;
}

static void sys_exit(int code) __attribute__((noreturn));
static void sys_exit(int code)
{
    register long x8 __asm__("x8") = 93;          /* exit */
    register long x0 __asm__("x0") = (long)code;
    __asm__ volatile("svc #0" : : "r"(x8), "r"(x0) : "memory");
    __builtin_unreachable();
}

/* satisfy switch_ucontext.c (built -nostdlib together with this test) */
void *memset(void *s, int c, size_t n)
{
    unsigned char *p = (unsigned char *)s;
    while (n--) *p++ = (unsigned char)c;
    return s;
}
void abort(void)
{
    sys_write("ABORT\n", 6);
    sys_exit(99);
}

static void puts_(const char *s)
{
    long n = 0;
    while (s[n]) n++;
    sys_write(s, n);
}

/* ---------------- register poke helpers ---------------- */

static inline void wr_x19(uint64_t v)
{
    __asm__ volatile("mov x19, %0" : : "r"(v) : "x19");
}
static inline uint64_t rd_x19(void)
{
    uint64_t v;
    __asm__ volatile("mov %0, x19" : "=r"(v));
    return v;
}
static inline void wr_d8(uint64_t v)
{
    /* FMOV Dd, Xn - moves the GPR into the low 64 bits of d8 */
    __asm__ volatile("fmov d8, %0" : : "r"(v));
}
static inline uint64_t rd_d8(void)
{
    uint64_t v;
    __asm__ volatile("fmov %0, d8" : "=r"(v));
    return v;
}

/* ---------------- the test ---------------- */

static ucontext_t g_main, g_co, g_direct;
static uint64_t   g_co_stack[8192 / 8];           /* 8 KB coop stack */

static volatile uint64_t g_r[8];                  /* results: 1 = pass */
static volatile int      g_step = 0;
static volatile int      g_visited = 0;
static volatile int      g_co_finished = 0;
static volatile uint64_t g_co_sp_at_entry = 1;

#define D8_MAGIC_CO    0x4242424242424242ULL
#define D8_MAGIC_MAIN  0x1122334455667788ULL
#define X19_MAGIC_CO   0x77ULL
#define X19_MAGIC_MAIN 0x99ULL

static void co_entry(void)
{
    g_visited++;

    uint64_t sp;
    __asm__ volatile("mov %0, sp" : "=r"(sp));
    g_co_sp_at_entry = sp;
    g_r[0] = (sp & 15ULL) == 0 ? 1 : 0;           /* [r0] SP alignment */

    g_r[1] = (rd_x19() == (uint64_t)&g_co) ? 1 : 0; /* [r1] x19 = self */

    wr_d8(D8_MAGIC_CO);
    swapcontext(&g_co, &g_main);                  /* -> main step 1 */

    g_visited++;
    g_r[2] = (rd_d8() == D8_MAGIC_CO) ? 1 : 0;    /* [r2] d8 preserved */

    wr_x19(X19_MAGIC_CO);
    swapcontext(&g_co, &g_main);                  /* -> main step 2 */

    g_visited++;
    g_r[3] = (rd_x19() == X19_MAGIC_CO) ? 1 : 0;  /* [r3] x19 preserved */

    g_co_finished = 1;
    /* return -> exit trampoline -> setcontext(g_co.uc_link) -> main step 3 */
}

void _start(void)
{
    g_co.uc_link = &g_main;
    g_co.uc_stack.ss_sp  = g_co_stack;
    g_co.uc_stack.ss_size = sizeof(g_co_stack);
    makecontext(&g_co, co_entry, 0);

    wr_x19(X19_MAGIC_MAIN);
    wr_d8(D8_MAGIC_MAIN);

    for (;;) {
        swapcontext(&g_main, &g_co);
        g_step++;

        if (g_step == 1) {
            /* [r4] starter's x19/d8 untouched by the thread's excursion */
            g_r[4] = (rd_x19() == X19_MAGIC_MAIN && rd_d8() == D8_MAGIC_MAIN) ? 1 : 0;
            wr_d8(0);                             /* clobber the thread's d8 */
        } else if (g_step == 2) {
            g_r[5] = (rd_x19() == X19_MAGIC_MAIN) ? 1 : 0;
            wr_x19(0x88);                         /* clobber the thread's x19 */
        } else {
            break;                                /* step 3: thread returned */
        }
    }

    /* [r6] the return went through uc_link with the thread fully finished */
    g_r[6] = (g_co_finished && g_visited == 3 && g_step == 3) ? 1 : 0;

    /* [r7] getcontext/setcontext re-entry: the resumed pass must observe
     * rc == 0 and locals held in callee-saved registers intact */
    {
        volatile int round = 0;
        int rc = getcontext(&g_direct);
        if (round == 0) {
            round = 1;
            setcontext(&g_direct);
        }
        g_r[7] = (rc == 0 && round == 1) ? 1 : 0;
    }

    /* ---------------- report ---------------- */
    static const char names[8][26] = {
        "sp-align-at-entry      ",
        "x19-self-at-entry      ",
        "d8-roundtrip           ",
        "x19-roundtrip          ",
        "starter-regs-untouched ",
        "starter-x19-2nd-switch ",
        "uclink-trampoline      ",
        "getcontext-setcontext  ",
    };
    int fails = 0;
    for (int i = 0; i < 8; i++) {
        puts_(g_r[i] ? "OK   " : "FAIL ");
        puts_(names[i]);
        puts_(g_r[i] ? "\n" : "  <- BROKEN\n");
        if (!g_r[i]) fails++;
    }
    if (g_co_sp_at_entry == 1) { puts_("FAIL sp never captured\n"); fails++; }

    sys_exit(fails ? 1 : 0);
}
