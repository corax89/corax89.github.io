#!/usr/bin/env python3
"""Extract all method/field refs to javax/microedition/lcdui/game/* from class files."""
import sys, struct

def parse_cpool(data):
    if data[:4] != b'\xca\xfe\xba\xbe':
        raise ValueError('not a class file')
    minor, major = struct.unpack('>HH', data[4:8])
    cp_count = struct.unpack('>H', data[8:10])[0]
    cp = [None] * cp_count  # 1-indexed
    i = 1
    while i < cp_count:
        tag = data[10 + 0] if False else None
        # We need an offset tracker; redo with offsets
        break
    # proper parse
    off = 10
    i = 1
    while i < cp_count:
        tag = data[off]; off += 1
        if tag == 1:  # Utf8
            ln = struct.unpack('>H', data[off:off+2])[0]; off += 2
            cp[i] = ('utf8', data[off:off+ln].decode('utf-8', 'replace')); off += ln
        elif tag == 3:  # Integer
            cp[i] = ('int', struct.unpack('>i', data[off:off+4])[0]); off += 4
        elif tag == 4:  # Float
            cp[i] = ('float', struct.unpack('>f', data[off:off+4])[0]); off += 4
        elif tag == 5:  # Long
            cp[i] = ('long',); off += 8; i += 1
        elif tag == 6:  # Double
            cp[i] = ('double',); off += 8; i += 1
        elif tag == 7:  # Class
            cp[i] = ('class', struct.unpack('>H', data[off:off+2])[0]); off += 2
        elif tag == 8:  # String
            cp[i] = ('string', struct.unpack('>H', data[off:off+2])[0]); off += 2
        elif tag == 9:  # Fieldref
            cp[i] = ('fieldref', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 10:  # Methodref
            cp[i] = ('methodref', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 11:  # InterfaceMethodref
            cp[i] = ('imethodref', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 12:  # NameAndType
            cp[i] = ('nat', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 15:  # MethodHandle
            cp[i] = ('mh', data[off], struct.unpack('>H', data[off+1:off+3])[0]); off += 3
        elif tag == 16:  # MethodType
            cp[i] = ('mt', struct.unpack('>H', data[off:off+2])[0]); off += 2
        elif tag == 17:  # Dynamic
            cp[i] = ('dyn', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 18:  # InvokeDynamic
            cp[i] = ('indy', struct.unpack('>HH', data[off:off+4])); off += 4
        elif tag == 19:  # Module
            cp[i] = ('module', struct.unpack('>H', data[off:off+2])[0]); off += 2
        elif tag == 20:  # Package
            cp[i] = ('pkg', struct.unpack('>H', data[off:off+2])[0]); off += 2
        else:
            raise ValueError('unknown tag %d at %d' % (tag, off))
        i += 1
    return cp, off

def utf8(cp, idx):
    return cp[idx][1]

def main(paths):
    for path in paths:
        data = open(path, 'rb').read()
        cp, end = parse_cpool(data)
        print('== %s ==' % path)
        refs = set()
        for entry in cp:
            if entry and entry[0] in ('methodref', 'imethodref', 'fieldref'):
                _, cls_idx, nat_idx = entry[1] if False else (entry[0], entry[1][0], entry[1][1])
                cls_name = utf8(cp, cp[cls_idx][1])
                if 'lcdui/game' in cls_name:
                    nat = cp[nat_idx]
                    name = utf8(cp, nat[1][0])
                    desc = utf8(cp, nat[1][1])
                    kind = 'M' if entry[0] != 'fieldref' else 'F'
                    refs.add('%s %s.%s %s' % (kind, cls_name, name, desc))
        for r in sorted(refs):
            print(r)
        print()

if __name__ == '__main__':
    main(sys.argv[1:])
