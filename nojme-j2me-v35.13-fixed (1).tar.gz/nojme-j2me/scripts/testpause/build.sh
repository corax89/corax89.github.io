#!/bin/bash
# Build TestPause.jar — the v34.81 frontend-pause selftest midlet.
# Requires: JRE (java) + ECJ (ecj.jar).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestPause.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestPause\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/TestPause.class" "$OUT/pkg/" "$OUT/TestPause\$1.class" "$OUT/pkg/" 2>/dev/null || cp "$OUT/TestPause.class" "$OUT/pkg/"
( cd "$OUT/pkg" && zip -q -r "$D/TestPause.jar" META-INF TestPause.class 'TestPause$1.class' 2>/dev/null || zip -q -r "$D/TestPause.jar" META-INF TestPause.class )
echo "built: $D/TestPause.jar"
