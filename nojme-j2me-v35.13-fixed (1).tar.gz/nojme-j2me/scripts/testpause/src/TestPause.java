/* TestPause — v34.81 frontend-pause selftest.
 *
 * startApp() returns immediately; the ticker is a real Java pthread
 * runner (Thread.start -> native.c pthread) — exactly the execution that
 * used to keep running while RetroArch's menu held the core paused.
 * Every 200 ms it prints the currentTimeMillis delta since start: under
 * LR_MENU_GAP_MS=3000 the delta must freeze (virtual clock) and the
 * prints must stop for the gap (thread parked). Without the fix the
 * ticker happily advances dtime by the whole gap.
 */
import javax.microedition.midlet.MIDlet;

public class TestPause extends MIDlet implements Runnable {
    static long t0;

    public TestPause() {}

    public void startApp() {
        t0 = System.currentTimeMillis();
        Thread worker = new Thread(this);
        worker.start();
        /* return at once: the rest of the test runs on the runner thread */
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}

    public void run() {
        for (int i = 0; i < 40; i++) {          /* 40 * 200ms = 8 s */
            try { Thread.sleep(200); } catch (InterruptedException e) { return; }
            long d = System.currentTimeMillis() - t0;
            System.out.println("PAUSECHK tick=" + i + " dtime=" + d);
        }
        System.out.println("PAUSECHK done");
        notifyDestroyed();
    }
}
