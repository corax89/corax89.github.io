/* shim_strcmp.c — v34.80 ARMv7 crash-forensics tool (diagnostic only,
 * NOT part of the core).
 *
 * During the v34.80 session an intermittent SIGSEGV (PC inside libc
 * strcmp, r0 = garbage like 0x19/0x65) was reproduced under qemu-arm
 * with the m17 cross-build (Stalker, ~40-60% of runs). glibc's
 * backtrace() cannot unwind from the corrupted context, so the call
 * site was localized by interposing strcmp:
 *
 *   arm-...-gcc -shared -fPIC -O1 -std=c11 scripts/shim_strcmp.c \
 *       -o /tmp/shim_strcmp.so
 *   qemu-arm -L <sysroot> -E LD_PRELOAD=/tmp/shim_strcmp.so \
 *       ./bin/lr_run ./bin/nojme_libretro.so games/Stalker.jar \
 *       2000 <out_dir> 1
 *
 * On a bad (<64KB) pointer it prints both arguments plus the REAL
 * caller return address (taken at shim entry, before any register
 * clobber) and exits 97 — resolve the caller against an unstripped
 * core via nm (offset = caller - core_load_base). Self-contained
 * byte-loop compare: no dlsym (dlsym itself calls strcmp and would
 * recurse into this shim). Threshold rationale: nothing legitimate is
 * ever allocated below the mmap floor, so any such pointer is garbage.
 *
 * Findings produced with this tool are recorded in FIXES.txt,
 * СЕССИЯ 80. */
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

static int bad_ptr(const void* p) {
    return p && (uintptr_t)p < 0x10000u;
}

int strcmp(const char* a, const char* b) {
    if (bad_ptr(a) || bad_ptr(b)) {
        fprintf(stderr, "[SHIM] BAD strcmp(%p, %p) caller=%p\n",
                (void*)a, (void*)b, __builtin_return_address(0));
        fflush(stderr);
        _exit(97);
    }
    while (*a && *a == *b) { a++; b++; }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}
