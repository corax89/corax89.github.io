#!/usr/bin/env python3
"""v37 shadow-fix verification: A (fixed) vs B (legacy rowvector = old bug)
vs C (shadow skipped). For matching frame numbers:
  - diff A vs C  -> shadow footprint in FIXED render (expect: compact dark
    region right under the car, flat on the road)
  - diff B vs C  -> shadow footprint in BUGGY render (expect: the black
    wedge — large region, extends upward/in front of the car at angles)
  - diff A vs B  -> overall effect of the fix
"""
import os, sys
from PIL import Image

BASE = "/home/z/my-project/j2me-analysis/work/v37_race"

def load(run):
    d = {}
    for f in os.listdir(os.path.join(BASE, run)):
        if f.endswith(".ppm"):
            n = int(f.split("_")[-1].split(".")[0])
            d[n] = Image.open(os.path.join(BASE, run, f)).convert("RGB")
    return d

def diff_mask(a, b, thresh=28):
    """pixels where RGB distance > thresh"""
    pa, pb = a.load(), b.load()
    W, H = a.size
    mask = [[0]*W for _ in range(H)]
    cnt = 0
    for y in range(H):
        for x in range(W):
            r1,g1,b1 = pa[x,y]; r2,g2,b2 = pb[x,y]
            if abs(r1-r2)+abs(g1-g2)+abs(b1-b2) > thresh:
                mask[y][x] = 1; cnt += 1
    return mask, cnt

def black_frac(img, region):
    """fraction of near-black pixels in region (x0,y0,x1,y1)"""
    p = img.load()
    x0,y0,x1,y1 = region
    tot = blk = 0
    for y in range(y0,y1):
        for x in range(x0,x1):
            r,g,b = p[x,y]
            tot += 1
            if r < 30 and g < 30 and b < 30:
                blk += 1
    return blk, tot

def bbox(mask):
    W = len(mask[0]); H = len(mask)
    xs = [x for y in range(H) for x in range(W) if mask[y][x]]
    if not xs: return None
    ys = [y for y in range(H) for x in range(W) if mask[y][x]]
    return min(xs), min(ys), max(xs), max(ys), len(xs)

def connected_max(mask):
    """largest 4-connected component size (BFS)"""
    W = len(mask[0]); H = len(mask)
    seen = [[False]*W for _ in range(H)]
    best = 0
    from collections import deque
    for y in range(H):
        for x in range(W):
            if mask[y][x] and not seen[y][x]:
                q = deque([(x,y)]); seen[y][x]=True; sz=0
                while q:
                    cx,cy = q.popleft(); sz+=1
                    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                        nx,ny = cx+dx, cy+dy
                        if 0<=nx<W and 0<=ny<H and mask[ny][nx] and not seen[ny][nx]:
                            seen[ny][nx]=True; q.append((nx,ny))
                best = max(best, sz)
    return best

A, B, C = load("A"), load("B"), load("C")
common = sorted(set(A) & set(B) & set(C))
print(f"frames: A={len(A)} B={len(B)} C={len(C)} common={len(common)}: {common[:20]}")
print()
print(f"{'frame':>6} | {'A-C shadow px':>13} {'bbox A-C (x0,y0,x1,y1,px)':>28} {'maxblob A-C':>11} | {'B-C shadow px':>13} {'bbox B-C':>28} {'maxblob B-C':>11}")
for n in common:
    if n < 400:  # race starts ~400
        continue
    mA, cA = diff_mask(A[n], C[n])
    mB, cB = diff_mask(B[n], C[n])
    bA = bbox(mA); bB = bbox(mB)
    la = connected_max(mA); lb = connected_max(mB)
    print(f"{n:>6} | {cA:>13} {str(bA):>28} {la:>11} | {cB:>13} {str(bB):>28} {lb:>11}")

# near-black wedge detector on full frames (lower 2/3 where road+car live)
print()
print("near-black pixel counts (region y=100..320, whole width):")
print(f"{'frame':>6} | {'A(black/total)':>16} | {'B(black/total)':>16} | {'C(black/total)':>16}")
for n in common:
    if n < 400: continue
    aB,aT = black_frac(A[n], (0,100,240,320))
    bB,bT = black_frac(B[n], (0,100,240,320))
    cB,cT = black_frac(C[n], (0,100,240,320))
    print(f"{n:>6} | {aB:>6}/{aT:<9} | {bB:>6}/{bT:<9} | {cB:>6}/{cT:<9}")
