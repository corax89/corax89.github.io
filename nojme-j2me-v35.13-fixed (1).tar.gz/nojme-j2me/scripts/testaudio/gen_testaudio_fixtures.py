#!/usr/bin/env python3
"""v34.73 TestAudio fixtures — generate every JSR-135-relevant C-decodable
audio format the core supports, for the E2E playback/mixer verification:

  t1.wav  PCM 16-bit mono    22050 Hz, 440 Hz sine, amp 12000, 0.6 s
  t2.wav  PCM 16-bit stereo  44100 Hz, L=880 Hz / R=1320 Hz, amp 9000, 0.6 s
  t3.wav  PCM  8-bit mono    11025 Hz, 220 Hz sine, 0.6 s
  t4.wav  IMA ADPCM (fmt 17) mono 22050 Hz, 440 Hz, 0.6 s
  t5.wav  A-law   (fmt 6)    8000  Hz, 440 Hz, 0.6 s   (v34.73 A-law fix)
  t6.wav  mu-law  (fmt 7)    8000  Hz, 440 Hz, 0.6 s   (v34.73 format-map fix)
  t7.wav  PCM 16-bit mono 22050 Hz, 440 Hz, amp 20000  (mixer/saturation pair)
  t8.wav  PCM 16-bit mono 22050 Hz, 660 Hz, amp 20000  (played WITH t7)
  t9.mid  MIDI: single A4 (note 69) 600 ms

G.711 encoders are built as a 256-entry nearest-match LUT derived from the
SAME decode formulas the C core uses (round-trip consistency by
construction — no second transcription to get wrong).
IMA ADPCM follows the standard block layout the C decoder parses
(4-byte header: predictor int16 LE, index u8, reserved u8; nibbles
low-first; header predictor = first sample of the block).
"""
import math
import os
import struct
import sys

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "testaudio", "res")
os.makedirs(OUT, exist_ok=True)


def sine(freq, seconds, rate, amp):
    n = int(seconds * rate)
    return [amp * math.sin(2.0 * math.pi * freq * i / rate) for i in range(n)]


def write_wav(path, fmt, channels, rate, bits, data_bytes,
              block_align=None, byte_rate=None):
    if block_align is None:
        block_align = channels * bits // 8
    if byte_rate is None:
        byte_rate = rate * block_align
    hdr = struct.pack("<4sI4s", b"RIFF", 36 + len(data_bytes), b"WAVE")
    hdr += struct.pack("<4sIHHIIHH", b"fmt ", 16, fmt, channels, rate,
                       byte_rate, block_align, bits)
    hdr += struct.pack("<4sI", b"data", len(data_bytes))
    with open(path, "wb") as f:
        f.write(hdr + data_bytes)
    print(f"  {os.path.basename(path)}: fmt={fmt} ch={channels} rate={rate} "
          f"bits={bits} bytes={len(data_bytes)}")


# ---------- G.711: LUT built from the core's own decode formulas ----------
def c_mulaw_to_pcm16(u):
    BIAS = 0x84
    u = (~u) & 0xFF
    t = ((u & 0x0F) << 3) + BIAS
    t <<= (u & 0x70) >> 4
    return (BIAS - t) if (u & 0x80) else (t - BIAS)


def c_alaw_to_pcm16(a):  # v34.73 final shape: per-segment shift (full scale)
    a ^= 0x55
    t = (a & 0x0F) << 4
    seg = (a & 0x70) >> 4
    if seg == 0:
        t += 8
    else:
        t = (t + 0x108) << (seg - 1)
    return t if (a & 0x80) else -t


def encode_g711(samples, decoder):
    lut = [decoder(i) for i in range(256)]
    out = bytearray()
    for s in samples:
        s = max(-32768, min(32767, int(s)))
        best, best_d = 0, 1 << 30
        for code, val in enumerate(lut):
            d = abs(val - s)
            if d < best_d:
                best, best_d = code, d
        out.append(best)
    return bytes(out)


# ---------- IMA ADPCM ----------
IMA_STEP = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34,
            37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143,
            157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494,
            544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552,
            1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428,
            4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487,
            12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086,
            29794, 32767]
IMA_IDX = [-1, -1, -1, -1, 2, 4, 6, 8,
           -1, -1, -1, -1, 2, 4, 6, 8]


def encode_ima_adpcm(samples, block_size=256):
    """Standard IMA blocks; header predictor = block's first sample,
    nibbles encode the remaining samples, low nibble first."""
    out = bytearray()
    n = 0
    spb = (block_size - 4) * 2 + 1  # standard samples per block (incl. header sample)
    while n < len(samples):
        block = samples[n:n + spb]
        n += spb
        while len(block) < spb:
            block.append(block[-1] if block else 0)
        predictor = max(-32768, min(32767, int(block[0])))
        index = 0
        out += struct.pack("<hBB", predictor, index, 0)
        acc = 0
        nib_cnt = 0
        for s in block[1:]:
            s = max(-32768, min(32767, int(s)))
            diff = s - predictor
            code = 0
            if diff < 0:
                code = 8
                diff = -diff
            step = IMA_STEP[index]
            if diff >= step:
                code |= 4
                diff -= step
            if diff >= step >> 1:
                code |= 2
                diff -= step >> 1
            if diff >= step >> 2:
                code |= 1
            diffq = step >> 3
            if code & 4:
                diffq += step
            if code & 2:
                diffq += step >> 1
            if code & 1:
                diffq += step >> 2
            predictor += -diffq if (code & 8) else diffq
            predictor = max(-32768, min(32767, predictor))
            index = max(0, min(88, index + IMA_IDX[code]))
            if nib_cnt % 2 == 0:
                acc = code & 0x0F
            else:
                out.append((acc & 0x0F) | ((code & 0x0F) << 4))
            nib_cnt += 1
        if nib_cnt % 2 == 1:
            out.append(acc & 0x0F)
        # pad block to block_size if nibbles ran short
        while (len(out) % block_size) != 0:
            out.append(0)
    return bytes(out)


# ---------- MIDI ----------
def write_midi(path, note=69, ms=600):
    division = 96               # ticks per quarter
    us_per_quarter = 500000     # default tempo 120 BPM
    ticks = int(round(ms * 1000.0 / us_per_quarter * division))
    trk = bytearray()
    trk += bytes([0x00, 0xC0, 0x50])          # delta 0: program change ch0
    trk += bytes([0x00, 0x90, note, 100])     # delta 0: note on
    # variable-length quantity for the note-off delta
    v = ticks
    vlq = []
    while True:
        vlq.insert(0, v & 0x7F)
        v >>= 7
        if v == 0:
            break
    for i, b in enumerate(vlq):
        trk.append(b | (0x80 if i < len(vlq) - 1 else 0))
    trk += bytes([note, 0])                   # note off
    trk += bytes([0x00, 0xFF, 0x2F, 0x00])    # end of track
    with open(path, "wb") as f:
        f.write(struct.pack(">4sIHHh", b"MThd", 6, 0, 1, division))
        f.write(struct.pack(">4sI", b"MTrk", len(trk)))
        f.write(bytes(trk))
    print(f"  {os.path.basename(path)}: note={note} ticks={ticks}")


def main():
    print("TestAudio fixtures ->", OUT)

    # t1: 16-bit mono 22050
    s = sine(440, 0.6, 22050, 12000)
    write_wav(os.path.join(OUT, "t1.wav"), 1, 1, 22050, 16,
              struct.pack("<%dh" % len(s), *[int(x) for x in s]))

    # t2: 16-bit stereo 44100 (L=880, R=1320)
    sl = sine(880, 0.6, 44100, 9000)
    sr = sine(1320, 0.6, 44100, 9000)
    inter = []
    for a, b in zip(sl, sr):
        inter += [int(a), int(b)]
    write_wav(os.path.join(OUT, "t2.wav"), 1, 2, 44100, 16,
              struct.pack("<%dh" % len(inter), *inter))

    # t3: 8-bit mono 11025
    s = sine(220, 0.6, 11025, 120)
    write_wav(os.path.join(OUT, "t3.wav"), 1, 1, 11025, 8,
              bytes([(int(x) + 128) & 0xFF for x in s]))

    # t4: IMA ADPCM mono 22050 (fmt 17), block_align 256
    s = sine(440, 0.6, 22050, 12000)
    write_wav(os.path.join(OUT, "t4.wav"), 17, 1, 22050, 4,
              encode_ima_adpcm(s, 256), block_align=256,
              byte_rate=22050 * 256 // 505)

    # t5: A-law (fmt 6) mono 8000
    s = sine(440, 0.6, 8000, 32000)
    write_wav(os.path.join(OUT, "t5.wav"), 6, 1, 8000, 8,
              encode_g711(s, c_alaw_to_pcm16))

    # t6: mu-law (fmt 7) mono 8000
    s = sine(440, 0.6, 8000, 32000)
    write_wav(os.path.join(OUT, "t6.wav"), 7, 1, 8000, 8,
              encode_g711(s, c_mulaw_to_pcm16))

    # t7/t8: loud pair for the mixer saturation test
    s = sine(440, 0.6, 22050, 20000)
    write_wav(os.path.join(OUT, "t7.wav"), 1, 1, 22050, 16,
              struct.pack("<%dh" % len(s), *[int(x) for x in s]))
    s = sine(660, 0.6, 22050, 20000)
    write_wav(os.path.join(OUT, "t8.wav"), 1, 1, 22050, 16,
              struct.pack("<%dh" % len(s), *[int(x) for x in s]))

    # t9: MIDI single note
    write_midi(os.path.join(OUT, "t9.mid"), note=69, ms=600)

    print("done")


if __name__ == "__main__":
    main()
