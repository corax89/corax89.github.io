package javax.microedition.media;

public class Manager {
    public static final String TONE_DEVICE = "device://tone";
    public static final String MIDI_DEVICE = "device://midi";

    public static Player createPlayer(String locator) throws MediaException { return null; }
    public static Player createPlayer(java.io.InputStream stream, String type) throws MediaException { return null; }
    public static void playTone(int note, int duration, int volume) throws MediaException {}
    public static String[] getSupportedContentTypes(String protocol) { return new String[0]; }
    public static String[] getSupportedProtocols(String content_type) { return new String[0]; }
}
