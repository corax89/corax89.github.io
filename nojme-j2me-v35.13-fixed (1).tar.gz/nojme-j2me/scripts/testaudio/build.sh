#!/bin/bash
# Build TestAudio.jar — v34.73 selftest: WAV (PCM 8/16-bit, mono/stereo,
# 11/22/44 kHz), IMA ADPCM, A-law, mu-law, MIDI, playTone and the saturating
# two-player mixer. Class version 48 (no stack maps); only the test classes
# are packaged — the emulator supplies the midlet/lcdui/media classes at
# runtime. Audio resources (scripts/testaudio/res) are packed into the JAR.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestAudio.java" \
    "$D/stubs/javax/microedition/media/"*.java \
    "$D/../testfinish/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: TA, , TestAudio\r\nMIDlet-Name: TestAudio\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT"/TestAudio*.class "$PKG/"
cp "$D"/res/t*.wav "$D"/res/t9.mid "$PKG/"

( cd "$PKG" && zip -q -r "$D/TestAudio.jar" META-INF && zip -q "$D/TestAudio.jar" *.class t1.wav t2.wav t3.wav t4.wav t5.wav t6.wav t7.wav t8.wav t9.mid )

echo "built: $D/TestAudio.jar"
