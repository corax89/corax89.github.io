#!/usr/bin/env python3
"""Check the KeyframeSequence encoding byte + layout dialect of any .m3g file.
Walks objects; for each KEYFRAMESEQ prints interp/repeat/enc/dur/vr/comp and
probes the byte pattern right after componentCount to classify the layout."""
import struct, sys, zlib
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_hexdump import sections_of, objects_of

TRANSFORMABLE = {14, 15, 16, 9, 22, 5, 12, 18}
NODE = {14, 15, 16, 9, 22, 5, 12, 18}

def analyze(path):
    objs = objects_of(sections_of(path))
    nkfs = 0
    for i, (t, body) in enumerate(objs):
        if t != 19:
            continue
        nkfs += 1
        p = 4
        ntc = struct.unpack('<I', body[p:p+4])[0]; p += 4 + 4 * ntc
        nuo = struct.unpack('<I', body[p:p+4])[0]; p += 4
        for _ in range(nuo):
            ln = struct.unpack('<I', body[p+4:p+8])[0]; p += 8 + ln
        if p + 23 > len(body):
            print('  [%d] KFS too small'); continue
        interp, repeat, enc = body[p], body[p+1], body[p+2]
        dur, vrF, vrL, comp = struct.unpack('<IIII', body[p+3:p+19])
        rest = len(body) - (p + 19)
        # peek after compCount
        peek = struct.unpack('<I', body[p+19:p+23])[0]
        # try dialects:
        a = 'flat(u32kf,float)'
        b = 'spec(csz+kf)'
        c = 'enc1(kf,bias,scale,i8)'
        lines = []
        # dialect C: kfCount u32, bias/scale f32*2c, kf = 4+c bytes
        kfC = peek
        needC = 4 + 8 * comp + kfC * (4 + comp)
        # dialect A: kfCount u32 then floats
        needA = 4 + kfC * (4 + 4 * comp)
        okA = needA <= rest and kfC >= 1 and kfC < 65536
        okC = needC <= rest and kfC >= 1 and kfC < 65536
        print('  [%3d] interp=%3d repeat=%3d enc=%d dur=%d vr=[%d,%d] comp=%d rest=%d peek=%d okA=%s(ok=%d) okC=%s(need=%d)'
              % (i, interp, repeat, enc, dur, vrF, vrL, comp, rest, peek,
                 okA, needA if okA else -1, okC, needC if okC else -1))
    print('%s: %d KFS objects' % (path, nkfs))

for p in sys.argv[1:]:
    analyze(p)
