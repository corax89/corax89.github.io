#!/bin/bash
# Build MonLeakTest.jar — v34.99 MONITOR-UNWIND selftest.
# Run:  timeout 30 ./bin/j2me-headless scripts/monleak/MonLeakTest.jar
# Expect SYSOUT: "MONLEAK:DONE n=120 ... PASSED" and a [MON-UNWIND] line.
# Pre-fix behavior: hangs at n=30 (monitor leaked by the exception) — the
# timeout kill is the FAIL signal.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/MonLeakTest.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: M, , MonLeakTest\r\nMIDlet-Name: M\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/MonLeakTest"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/MonLeakTest.jar" META-INF && zip -q "$D/MonLeakTest.jar" *.class )
echo "built: $D/MonLeakTest.jar"
