import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;

/**
 * v34.99 MONITOR-UNWIND selftest (the countdown-freeze root cause).
 *
 * Reproduces the exact field scenario in miniature:
 *   1. a game (runner) thread takes a monitor via monitorenter,
 *   2. an exception unwinds OUT of the synchronized block (caught upstream),
 *   3. the SAME monitor is then acquired by Canvas.paint() executed on the
 *      FRONTEND/MAIN pump thread (repaint() serviced by the main loop —
 *      a different OS pthread, so no reentrancy rescue).
 *
 * Pre-v34.99 the interpreter never released block-level monitors on unwind:
 * step 2 leaked the monitor (entry_count stuck at 1) and step 3 blocked on
 * the entry condvar FOREVER — the standalone "freeze right after the
 * countdown" signature (m frozen at one pc, game thread spinning, CPU 100%,
 * M3G locks free, libretro immune via its single-threaded retro_run).
 *
 * PASS criteria: the loop reaches MONLEAK:DONE with n=TOTAL and the log
 * contains [MON-UNWIND]. Pre-fix, this test HANGS at LEAK_AT (kill by
 * timeout = FAIL).
 */
public class MonLeakTest extends MIDlet implements Runnable {
    static final Object LOCK = new Object();
    static final int LEAK_AT = 30;
    static final int TOTAL = 120;

    volatile boolean stop = false;
    volatile int done = 0;
    Canvas c;

    protected void startApp() {
        c = new Canvas() {
            protected void paint(Graphics g) {
                /* Serviced by the MAIN pump thread (only repaint() is used,
                 * never serviceRepaints(), so nothing runs inline here). */
                synchronized (LOCK) {           /* would block forever pre-v34.99 */
                    g.setColor(0x404040);
                    g.fillRect(0, 0, c.getWidth(), c.getHeight());
                    g.drawString("n=" + done, 4, 8, Graphics.LEFT | Graphics.TOP);
                }
            }
        };
        Display.getDisplay(this).setCurrent(c);
        new Thread(this, "leaker").start();
        System.out.println("MONLEAK: started");
    }

    public void run() {
        int probes = 0;
        for (int n = 1; n <= TOTAL && !stop; n++) {
            try {
                synchronized (LOCK) {           /* monitorenter on runner thread */
                    if (n == LEAK_AT) {
                        throw new RuntimeException("monleak-probe");
                    }
                }                               /* monitorexit on the normal path */
            } catch (RuntimeException e) {
                /* swallowed — pre-v34.99 this LEAKED the LOCK monitor */
                probes++;
                System.out.println("MONLEAK: probe exception fired at n=" + n);
            }
            done = n;
            c.repaint();
            try { Thread.sleep(20); } catch (InterruptedException ie) { return; }
        }
        System.out.println("MONLEAK:DONE n=" + done + " probes=" + probes
                + " => " + (done >= TOTAL ? "PASSED" : "PARTIAL"));
        notifyDestroyed();
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) { stop = true; }
}
