/*
 * gc_stress.c — v34.58 standalone size-class allocator stress test.
 * nojme-j2me (J2ME emulator). НЕ входит в сборку ядра — отдельный
 * инструмент разработчика, как verify_v*.sh.
 *
 * Сборка (из корня nojme-j2me):
 *   gcc -O2 -std=c11 -Iinclude -Isrc -Isrc/include -DJ2ME_DEBUG=0 \
 *       scripts/gc_stress.c src/jvm/heap.c -lm -pthread -o /tmp/gc_stress
 *   /tmp/gc_stress
 *
 * Проверяет инварианты нового аллокатора (v34.58) без всей VM:
 *  1. Целостность данных объектов через GC-циклы (паттерны).
 *  2. Фрагментационный churn по всем size-классам (bucket misfit,
 *     remainder-сплиты, coalescing).
 *  3. Сохранение ЁМКОСТИ кучи через многократные GC — включая
 *     СРЕДНЕКУШНЫЕ ДЫРЫ (регрессия старого дефекта: блоки, свободные
 *     ДО GC, выпадали из free list навсегда).
 *  4. Переиспользование блоков одного бакета под запросы другого
 *     размера того же бакета.
 *  5. Крупные блоки (large-список) + чередование с мелкими.
 *  6. Линейный обход кучи согласован с учётом теста (size-chain
 *     цел: каждый блок начинается с валидного заголовка).
 *
 * heap.c компилируется прямо в тест как translation unit; все внешние
 * зависимости (native.c / threads.c / mobile3d.c / debug_var.c)
 * заменены минимальными стабами ниже.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>
#include <pthread.h>
#include <sched.h>

#include "jvm.h"
#include "heap.h"
#include "midp.h"

/* ====================================================================
 * STUBS: символы, которые heap.c ждёт из других единиц VM.
 * Тест однопоточный: safepoint-механика вырождена (expected=0).
 * ==================================================================== */
volatile int g_gc_safepoint_request = 0;
volatile int g_jvm_main_thread_executing = 0;
int g_j2me_runtime_debug = 0;

int g_hashtable_count = 0;                      /* heap.c читает при >0 только */
bool g_hashtable_peer_alive[4096];
char g_hashtables[4096 * 32];                   /* peer-массив (не читается) */

void* intern_pool[1024];                        /* JavaString* (не читается) */
int intern_pool_count = 0;

int j2me_log_enabled(void) { return 0; }
int j2me_log_ungated(const char* fmt, ...) { (void)fmt; return 0; }
int j2me_fprintf_gate(FILE* stream, const char* fmt, ...) {
    (void)stream; (void)fmt; return 0;
}

void jvm_gc_safepoint_park(void) {}
void jvm_gc_safepoint_release(void) {}
void jvm_gc_safepoint_wake_sleepers(void) {}   /* v34.59: heap.c broadcast hook */
void jvm_gc_safepoint_wake_monitors(void) {}   /* v34.65: heap.c monitor-waiter wake hook (threads.c in the real build) */
int  jvm_gc_safepoint_wait_arrivals(int expected, int timeout_ms) {
    (void)timeout_ms; return expected;   /* "все прибыли" мгновенно */
}
int  jvm_live_vm_thread_count(void) { return 0; }
int  jvm_current_os_thread_is_vm_runner(void) { return 0; }
int  jvm_os_thread_is_main_java(void) { return 0; }   /* v34.71: TLAB main-thread gate hook (threads.c in the real build) */
void jvm_dump_all_threads(void) {}
JavaThread* thread_current(JVM* jvm) { (void)jvm; return NULL; }

void native_gc_notify(void) {}
int  native_get_string_value_slot(JVM* jvm) { (void)jvm; return -1; }
int  native_get_string_count_slot(JVM* jvm) { (void)jvm; return -1; }
int  native_get_string_hash_slot(JVM* jvm) { (void)jvm; return -1; }
JavaValue native_get_field_value(JavaObject* o, const char* n) {
    (void)o; (void)n;
    JavaValue v; memset(&v, 0, sizeof v); return v;
}
JavaClass* jvm_load_class(JVM* jvm, const char* name) {
    (void)jvm; (void)name; return NULL;
}
const char* classfile_get_class_name(JavaClass* c, int idx) {
    (void)c; (void)idx; return NULL;
}
void hashtable_free_peer(int idx) { (void)idx; }
JavaObject** m3g_registry_get_objects(int* out_count) {
    if (out_count) *out_count = 0;
    return NULL;
}
JavaObject*** m3g_gc_extra_roots(int* out_count) {
    if (out_count) *out_count = 0;
    return NULL;
}

/* ====================================================================
 * Test framework
 * ==================================================================== */
static int g_failures = 0;
static int g_checks = 0;
#define CHECK(cond, msg, ...) do { \
    g_checks++; \
    if (!(cond)) { \
        g_failures++; \
        printf("FAIL: " msg " (%s:%d)\n", ##__VA_ARGS__, __FILE__, __LINE__); \
    } \
} while (0)

/* ====================================================================
 * JVM-контекст: пустой (0 потоков, 0 классов — GC ходит только по roots)
 * ==================================================================== */
static JVM jvm_storage;
static JVM* jvm = &jvm_storage;

#define NROOTS 20000
static void* roots[NROOTS];

/* Паттерн байта объекта i, позиция j */
static inline uint8_t pat(int i, size_t j) {
    return (uint8_t)((unsigned)i * 41u + (unsigned)j * 89u + 0x5Au);
}

/* Паттерн пишется ПОСЛЕ ObjectHeader (первые байты payload —
 * VM-внутренние поля clazz/hashcode — GC их разыменовывает!). */
static void fill_pattern(int i, void* p, size_t payload_total) {
    uint8_t* b = (uint8_t*)p + sizeof(ObjectHeader);
    size_t n = (payload_total > sizeof(ObjectHeader))
             ? payload_total - sizeof(ObjectHeader) : 0;
    for (size_t j = 0; j < n; j++) b[j] = pat(i, j);
}
static int verify_pattern(int i, const void* p, size_t payload_total) {
    const uint8_t* b = (const uint8_t*)p + sizeof(ObjectHeader);
    size_t n = (payload_total > sizeof(ObjectHeader))
             ? payload_total - sizeof(ObjectHeader) : 0;
    for (size_t j = 0; j < n; j++) {
        if (b[j] != pat(i, j)) return (int)j + 1;
    }
    return 0;
}

static size_t live_count(void) {
    size_t n = 0;
    for (int i = 0; i < NROOTS; i++) if (roots[i]) n++;
    return n;
}

/* Линейный обход кучи: сумма занятых блоков. -1 = повреждённая size-цепь.
 * v34.59: СВОБОДНЫЙ блок, пересекающий walk_end (хвост закрытого TLAB-
 * чанка или большой коалесц-регион после полной гибели) — не ошибка:
 * он не участвует в учёте занятых; останавливаем обход на нём. */
static long heap_walk_used(size_t* blocks, uint8_t* walk_end) {
    long used = 0;
    size_t n = 0;
    uint8_t* p = (uint8_t*)g_heap_start;
    GCObjectHeader* h;
    while (p < walk_end) {
        h = (GCObjectHeader*)p;
        if (h->size == 0 || h->size > (1u << 26)) return -1;
        if (p + h->size > walk_end) {
            if (h->type == OBJ_TYPE_FREE) break;   /* хвост TLAB — ок */
            return -1;
        }
        if (h->type != OBJ_TYPE_FREE) { used += h->size; n++; }
        p += h->size;
    }
    *blocks = n;
    return used;
}

/* Максимальный адрес, до которого доросли наши аллокации (для walk) */
static uint8_t* g_max_alloc_end = NULL;
static void* xalloc(size_t size) {
    void* p = heap_alloc(jvm, size, NULL, OBJ_TYPE_OBJECT);
    if (p) {
        GCObjectHeader* h = (GCObjectHeader*)p - 1;
        uint8_t* end = (uint8_t*)h + h->size;
        if (end > g_max_alloc_end) g_max_alloc_end = end;
    }
    return p;
}

/* Аллоцировать до OOM объектами size байт (payload); вернуть количество */
static size_t alloc_until_oom(size_t size, size_t limit) {
    size_t n = 0;
    while (n < limit) {
        void* p = xalloc(size);
        if (!p) break;
        n++;
    }
    return n;
}

/* ==== P8f: воркер TLAB-churn'а (struct + функция — до main) ====
 * Как игровой поток 3D-игры: churn мелочи в СВОЁМ чанке + удержание
 * подмножества живыми. Паттерны проверяются ДО выхода — ловят
 * перекрытие чанков двух потоков (double-carve). Bounded churn —
 * GC не запускаем (однопоточные стабы safepoint). */
struct P8Warg { int id; unsigned seed; long kept; long allocs; };
static struct P8Warg g_p8_wargs[4];

static void* p8_worker(void* arg) {
    struct P8Warg* wa = (struct P8Warg*)arg;
    unsigned seed = wa->seed;
    enum { WKEEP = 512, WITER = 12000 };   /* ~2.6 МБ/воркер: без auto-GC */
    static void* wkeep[4][WKEEP];      /* per-worker, без гонок */
    static size_t wksz[4][WKEEP];
    void** keep = wkeep[wa->id];
    size_t* ksz = wksz[wa->id];
    for (int i = 0; i < WITER; i++) {
        size_t sz = 24 + (size_t)(rand_r(&seed) % 300);
        void* p = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
        if (!p) break;
        wa->allocs++;
        if ((i & 15) == 0 && (i >> 4) < WKEEP) {
            GCObjectHeader* h = (GCObjectHeader*)p - 1;
            size_t pl = h->size - sizeof(GCObjectHeader);
            fill_pattern((wa->id << 20) + (i >> 4), p, pl);
            keep[i >> 4] = p;
            ksz[i >> 4] = pl;
        }
    }
    /* проверка ДО закрытия чанка: паттерны живых не побиты чужим потоком */
    for (int i = 0; i < WKEEP; i++) {
        if (keep[i] &&
            verify_pattern((wa->id << 20) + i, keep[i], ksz[i]) != 0) {
            printf("FAIL: P8f worker %d pattern broken at %d (%s:%d)\n",
                   wa->id, i, __FILE__, __LINE__);
            g_failures++;
            break;
        }
    }
    wa->kept = WKEEP;
    /* как продакшн pthread_thread_runner v34.59: закрыть чанк ДО смерти */
    heap_tlab_flush_self();
    /* живые объекты воркера больше не нужны (не в roots — умрут в GC) */
    return NULL;
}

static void kill_all_roots(void) {
    for (int i = 0; i < NROOTS; i++) roots[i] = NULL;
}

int main(void) {
    memset(&jvm_storage, 0, sizeof jvm_storage);
    srand(20260914);

    CHECK(heap_init(jvm, 16u << 20, 16u << 20) == JNI_OK, "heap_init");
    for (int i = 0; i < NROOTS; i++) gc_add_root(jvm, &roots[i]);

    /* ============ PHASE 1: базовая целостность через GC ============ */
    printf("[P1] basic integrity ...\n");
    for (int i = 0; i < 6000; i++) {
        size_t sz = 88 + (size_t)(rand() % 2048);   /* >= ObjectHeader */
        void* p = xalloc(sz);
        CHECK(p != NULL, "P1 alloc %d", i);
        if (!p) break;
        fill_pattern(i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i] = p;
    }
    for (int i = 0; i < 6000 && roots[i]; i++) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P1 verify pre-GC obj %d", i);
    }
    for (int i = 0; i < 6000; i += 2) roots[i] = NULL;   /* половина умирает */
    gc_collect(jvm);
    for (int i = 1; i < 6000 && roots[i]; i += 2) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P1 verify post-GC survivor %d", i);
    }
    /* пере-заполняем убитые слоты — должны браться из освободившихся блоков */
    for (int i = 0; i < 6000; i += 2) {
        size_t sz = 8 + (size_t)(rand() % 2048);
        void* p = xalloc(sz);
        CHECK(p != NULL, "P1 realloc %d", i);
        if (!p) break;
        fill_pattern(i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i] = p;
    }
    for (int i = 0; i < 6000 && roots[i]; i++) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P1 verify after reuse %d", i);
    }
    printf("     live=%zu\n", live_count());

    /* ============ PHASE 2: фрагментационный churn (ring) ============ */
    printf("[P2] fragmentation churn ...\n");
    kill_all_roots();          /* P1-объекты не должны съедать ёмкость */
    gc_collect(jvm);
    {
        int ring = 0;
        const int RING = 1200;   /* живых не больше ~1200 (~7МБ худший случай: case-4 средний ~20КБ) */
        for (int round = 0; round < 300; round++) {
            for (int k = 0; k < 50; k++) {
                size_t sz;
                switch (k % 5) {
                    case 0:  sz = 88 + 8 * (size_t)(rand() % 120);   break; /* мелкие */
                    case 1:  sz = 128 + 8 * (size_t)(rand() % 112); break; /* средние */
                    case 2:  sz = 88 + 8 * (size_t)(rand() % 1020); break; /* разброс */
                    case 3:  sz = 1024 + 8 * (size_t)(rand() % 512);break; /* > SC_SMALL_MAX */
                    default: sz = 4096 + 8 * (size_t)(rand() % 4096); break; /* large */
                }
                int slot = ring++ % RING;
                void* p = xalloc(sz);
                CHECK(p != NULL, "P2 alloc round=%d k=%d", round, k);
                if (!p) break;
                fill_pattern(slot, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));   /* тот же тег, что и слот */
                roots[slot] = p;             /* вытесняет прежний объект */
            }
            if (round % 8 == 7) {
                gc_collect(jvm);
                for (int s = 0; s < 30; s++) {
                    int slot = rand() % RING;
                    if (!roots[slot]) continue;
                    GCObjectHeader* h = (GCObjectHeader*)roots[slot] - 1;
                    CHECK(verify_pattern(slot, roots[slot],
                                         h->size - sizeof(GCObjectHeader)) == 0,
                          "P2 verify slot=%d round=%d", slot, round);
                }
            }
        }
        printf("     live=%zu\n", live_count());
    }

    /* ============ PHASE 3: сохранение ёмкости кучи через GC ============
     * 3a: после полной гибели + GC (top-rewind) крупноблочная ёмкость
     *     обязана восстановиться до того же числа (три раза подряд).
     * 3b: СРЕДНЕКУШНЫЕ ДЫРЫ (регрессия v34.58): живые и мусорные объекты
     * чередуются; после GC мусор = дыры в середине кучи. Двойной GC
     * (второй ничего не освобождает, но РАНЬШЕ терял уже-свободные
     * блоки из списка!). Затем занимаем bump-top ЖИВЫМИ большими
     * кусками — и требуем, что дыры переиспользуются. Все объекты,
     * от которых зависит исход, — в roots (auto-GC внутри heap_alloc
     * ничего не может «найти» и освободить) — счётчики точные. */
    printf("[P3] capacity preservation ...\n");
    kill_all_roots();
    gc_collect(jvm);   /* всё мертво -> единый регион -> current откатился */

    {
        /* 3a: крупноблочная ёмкость x3 (все 1MB-объекты — ЖИВЫЕ, в roots) */
        size_t caps[3];
        for (int t = 0; t < 3; t++) {
            size_t n = 0;
            while (n < 24) {
                void* p = xalloc(1u << 20);
                if (!p) break;
                roots[19000 + n] = p;   /* живые: GC не может их освободить */
                n++;
            }
            caps[t] = n;
            for (size_t i = 0; i < n; i++) roots[19000 + i] = NULL;
            gc_collect(jvm);
        }
        printf("     1MB-block capacity: %zu / %zu / %zu\n", caps[0], caps[1], caps[2]);
        CHECK(caps[1] == caps[0], "P3a capacity degraded 0->1: %zu -> %zu", caps[0], caps[1]);
        CHECK(caps[2] == caps[0], "P3a capacity degraded 0->2: %zu -> %zu", caps[0], caps[2]);
        CHECK(caps[0] >= 14, "P3a suspiciously low capacity: %zu", caps[0]);
    }

    /* 3b: среднекушные дыры */
    kill_all_roots();
    gc_collect(jvm);
    {
        const int NHOLE = 6000;
        const int RKEEP = 0;        /* roots[RKEEP .. RKEEP+NHOLE) — живые */
        const int RBIG  = 8000;    /* roots[RBIG .. RBIG+64) — 1MB-заполнение */
        const int RFILL = 9000;    /* roots[RFILL .. RFILL+6000) — refill */
        for (int i = 0; i < NHOLE; i++) {
            /* живой (в root) + мусор (не в root) чередуются в памяти */
            void* keep = xalloc(136);
            CHECK(keep != NULL, "P3 keep alloc %d", i);
            if (!keep) break;
            fill_pattern(i, keep, ((GCObjectHeader*)keep - 1)->size - sizeof(GCObjectHeader));
            roots[RKEEP + i] = keep;
            void* garbage = xalloc(96);   /* hsize=136: дыра под refill 88 */
            CHECK(garbage != NULL, "P3 garbage alloc %d", i);
            if (!garbage) break;
        }
        gc_collect(jvm);   /* мусор -> ~NHOLE дыр по ~136 байт */
        gc_collect(jvm);    /* ПОВТОРНЫЙ GC: старые свободные блоки обязаны выжить */
        /* занимаем весь bump-top ЖИВЫМИ большими кусками */
        size_t big = 0;
        while (big < 64) {
            void* p = xalloc(1u << 20);
            if (!p) break;
            roots[RBIG + big] = p;
            big++;
        }
        printf("     top filled with %zu x 1MB (live)\n", big);
        /* теперь единственный источник памяти — СРЕДНЕКУШНЫЕ ДЫРЫ;
         * refill-объекты тоже живые (в roots) — auto-GC бессилен */
        size_t refill = 0;
        while (refill < 6000) {
            void* p = xalloc(88);
            if (!p) break;
            roots[RFILL + refill] = p;
            refill++;
        }
        printf("     mid-hole refill: %zu x 88B (holes expected >= %d)\n",
               refill, NHOLE);
        CHECK(refill >= (size_t)NHOLE, "P3b mid-heap holes LOST: only %zu of %d",
              refill, NHOLE);
        kill_all_roots();
        gc_collect(jvm);
    }

    /* ============ PHASE 4: misfit внутри одного бакета ============ */
    printf("[P4] bucket misfit ...\n");
    kill_all_roots();
    gc_collect(jvm);
    for (int i = 0; i < 4000; i++) {
        void* p = xalloc(136);      /* bucket (128,160] */
        CHECK(p != NULL, "P4 alloc 136 #%d", i);
        fill_pattern(i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i] = p;
    }
    for (int i = 0; i < 4000; i += 2) roots[i] = NULL;
    gc_collect(jvm);
    /* просим 152 из того же бакета: 136-блоки меньше и не подходят —
     * их обойдёт поиск; главное — целостность и отсутствие дыр */
    for (int i = 0; i < 2000; i++) {
        void* p = xalloc(152);
        CHECK(p != NULL, "P4 alloc 152 #%d", i);
        fill_pattern(5000 + i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i * 2] = p;
    }
    for (int i = 1; i < 4000; i += 2) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P4 survivor 136 #%d", i);
    }
    for (int i = 0; i < 2000; i++) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i * 2] - 1;
        CHECK(verify_pattern(5000 + i, roots[i * 2], h->size - sizeof(GCObjectHeader)) == 0,
              "P4 new 152 #%d", i);
    }

    /* ============ PHASE 5: крупные блоки + чередование ============ */
    printf("[P5] large blocks ...\n");
    kill_all_roots();
    gc_collect(jvm);
    for (int i = 0; i < 120; i++) {
        void* p = xalloc(65536);
        CHECK(p != NULL, "P5 large alloc #%d", i);
        fill_pattern(i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i] = p;
        void* q = xalloc(88);       /* мелочь вперемешку */
        CHECK(q != NULL, "P5 small alloc #%d", i);
        fill_pattern(1000 + i, q, ((GCObjectHeader*)q - 1)->size - sizeof(GCObjectHeader));
        roots[200 + i] = q;
    }
    for (int i = 0; i < 120; i++) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P5 large verify #%d", i);
    }
    for (int i = 0; i < 120; i += 2) roots[i] = NULL;   /* половину крупных долой */
    gc_collect(jvm);
    for (int i = 1; i < 120; i += 2) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
        CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
              "P5 large survivor #%d", i);
    }
    for (int i = 0; i < 60; i++) {   /* освободившиеся 64KB переиспользуются */
        void* p = xalloc(65536);
        CHECK(p != NULL, "P5 large realloc #%d", i);
        fill_pattern(2000 + i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
        roots[i * 2] = p;
    }
    for (int i = 0; i < 60; i++) {
        GCObjectHeader* h = (GCObjectHeader*)roots[i * 2] - 1;
        CHECK(verify_pattern(2000 + i, roots[i * 2], h->size - sizeof(GCObjectHeader)) == 0,
              "P5 large re-verify #%d", i);
    }

    /* ============ PHASE 6: линейный обход vs учёт теста ============ */
    printf("[P6] heap linear walk ...\n");
    {
        kill_all_roots();
        gc_collect(jvm);
        g_max_alloc_end = NULL;   /* walk только по объектам этой фазы */
        size_t total = 0;
        for (int i = 0; i < 3000; i++) {
            size_t sz = 88 + 8 * (size_t)(rand() % 400);
            void* p = xalloc(sz);
            CHECK(p != NULL, "P6 alloc #%d", i);
            fill_pattern(i, p, ((GCObjectHeader*)p - 1)->size - sizeof(GCObjectHeader));
            roots[i] = p;
        }
        gc_collect(jvm);   /* никто не умер, но mark/sweep прогнали */
        for (int i = 0; i < 3000; i++) {
            GCObjectHeader* h = (GCObjectHeader*)roots[i] - 1;
            CHECK(verify_pattern(i, roots[i], h->size - sizeof(GCObjectHeader)) == 0,
                  "P6 verify #%d", i);
            total += h->size;
        }
        size_t blocks = 0;
        long walked = heap_walk_used(&blocks, g_max_alloc_end);
        CHECK(walked >= 0, "P6 heap walk chain corrupted (rc=%ld)", walked);
        if (walked >= 0) {
            CHECK(blocks == 3000, "P6 block count %zu != 3000", blocks);
            CHECK((size_t)walked == total, "P6 used bytes %ld != %zu", walked, total);
        }
        printf("     blocks=%zu used=%ld (own total=%zu)\n", blocks, walked, total);
    }

    /* ============ PHASE 7: кэш разметки классов + полевые графы (v34.59) ============
     * Проверяет новый пер-классовый кэш разметки GC:
     *  7a. White-box: gc_ref_slots каждого класса совпадает с независимо
     *      посчитанными ожидаемыми индексами (арифметика слотов с
     *      J/D=2 слота, nativePeer-исключением, иерархией).
     *  7b. Полевой граф: объекты связаны ссылками через поля; часть
     *      живая (корни), часть мусор; после GC связи живых обязаны
     *      уцелеть, мусор — освободиться (ёмкость восстанавливается).
     *  7c. Спец-пути семейств: Hashtable$Entry (первые 4 слота) и
     *      java/util/Vector (все слоты с валидацией).
     */
    printf("[P7] class layout + field graphs ...\n");
    kill_all_roots();
    gc_collect(jvm);
    {
        /* --- 7.0 фейковые классы (calloc: gc_kind=0, слоты NULL) --- */
        static char D_REF[]  = "Lbench/Node;";
        static char D_ARR[]  = "[Lbench/Node;";
        static char D_INT[]  = "I";
        static char D_LONG[] = "J";
        static char D_DBL[]  = "D";

        /* Alpha: a:ref0, nativePeer:ref(EXCL), x:I, l:J(2), b:arr(5), d:D(2), c:ref8, y:I -> слоты 10, ссылки {0,5,8} */
        JavaField alpha_f[8] = {0};
        alpha_f[0].descriptor = D_REF;  alpha_f[0].name = "a";
        alpha_f[1].descriptor = D_REF;  alpha_f[1].name = "nativePeer";   /* должен быть ИСКЛЮЧЁН */
        alpha_f[2].descriptor = D_INT;  alpha_f[2].name = "x";
        alpha_f[3].descriptor = D_LONG; alpha_f[3].name = "l";
        alpha_f[4].descriptor = D_ARR;  alpha_f[4].name = "b";
        alpha_f[5].descriptor = D_DBL;  alpha_f[5].name = "d";
        alpha_f[6].descriptor = D_REF;  alpha_f[6].name = "c";
        alpha_f[7].descriptor = D_INT;  alpha_f[7].name = "y";

        /* Beta extends Alpha: m:ref(10), n:J(11,12) -> слоты 13, ссылки {0,5,8,10} */
        JavaField beta_f[2] = {0};
        beta_f[0].descriptor = D_REF;  beta_f[0].name = "m";
        beta_f[1].descriptor = D_LONG; beta_f[1].name = "n";

        /* Gamma: без ссылок -> слоты 5, ссылки {} */
        JavaField gamma_f[3] = {0};
        gamma_f[0].descriptor = D_INT;  gamma_f[0].name = "g1";
        gamma_f[1].descriptor = D_LONG; gamma_f[1].name = "g2";
        gamma_f[2].descriptor = D_DBL;  gamma_f[2].name = "g3";

        /* Entry ( Hashtable$Entry substring match ): key/value/next/hI -> слоты 4, ссылки {0,1,2} */
        JavaField entry_f[4] = {0};
        entry_f[0].descriptor = D_REF; entry_f[0].name = "key";
        entry_f[1].descriptor = D_REF; entry_f[1].name = "value";
        entry_f[2].descriptor = D_REF; entry_f[2].name = "next";
        entry_f[3].descriptor = D_INT; entry_f[3].name = "hash";

        /* Vector (точное имя): elementData:arr, elementCount:I, capacityIncrement:I -> слоты 3, ссылки {0} */
        JavaField vec_f[3] = {0};
        vec_f[0].descriptor = D_ARR; vec_f[0].name = "elementData";
        vec_f[1].descriptor = D_INT; vec_f[1].name = "elementCount";
        vec_f[2].descriptor = D_INT; vec_f[2].name = "capacityIncrement";

        JavaClass* k_alpha = (JavaClass*)calloc(1, sizeof(JavaClass));
        JavaClass* k_beta  = (JavaClass*)calloc(1, sizeof(JavaClass));
        JavaClass* k_gamma = (JavaClass*)calloc(1, sizeof(JavaClass));
        JavaClass* k_entry = (JavaClass*)calloc(1, sizeof(JavaClass));
        JavaClass* k_vec   = (JavaClass*)calloc(1, sizeof(JavaClass));
        CHECK(k_alpha && k_beta && k_gamma && k_entry && k_vec, "P7 class alloc");

        k_alpha->class_name = "bench/Alpha";  k_alpha->fields = alpha_f; k_alpha->fields_count = 8;
        k_beta->class_name  = "bench/Beta";   k_beta->fields  = beta_f;  k_beta->fields_count  = 2;
        k_beta->super_class = k_alpha;
        k_gamma->class_name = "bench/Gamma";  k_gamma->fields = gamma_f; k_gamma->fields_count = 3;
        k_entry->class_name = "bench/Hashtable$Entry"; k_entry->fields = entry_f; k_entry->fields_count = 4;
        k_vec->class_name   = "java/util/Vector";      k_vec->fields   = vec_f;   k_vec->fields_count   = 3;

        const int SLOTS_ALPHA = 10, SLOTS_BETA = 13, SLOTS_GAMMA = 5, SLOTS_ENTRY = 4, SLOTS_VEC = 3;
        k_alpha->instance_size = sizeof(ObjectHeader) + (size_t)SLOTS_ALPHA * sizeof(JavaValue);
        k_beta->instance_size  = sizeof(ObjectHeader) + (size_t)SLOTS_BETA  * sizeof(JavaValue);
        k_gamma->instance_size= sizeof(ObjectHeader) + (size_t)SLOTS_GAMMA * sizeof(JavaValue);
        k_entry->instance_size= sizeof(ObjectHeader) + (size_t)SLOTS_ENTRY * sizeof(JavaValue);
        k_vec->instance_size  = sizeof(ObjectHeader) + (size_t)SLOTS_VEC   * sizeof(JavaValue);

        /* --- 7a: white-box разметка (после первого GC с объектами) --- */
        #define N7 6000
        static JavaObject* objs[N7];
        for (int i = 0; i < N7; i++) {
            JavaClass* k = (i % 5 == 4) ? k_gamma
                        : (i % 5 == 3) ? k_entry
                        : (i % 5 == 2) ? k_vec
                        : (i % 2) ? k_beta : k_alpha;
            void* p = heap_alloc(jvm, k->instance_size, k, OBJ_TYPE_OBJECT);
            CHECK(p != NULL, "P7 alloc %d", i);
            if (!p) break;
            objs[i] = (JavaObject*)p;
            /* связи: на более ранние объекты (детерминированно) */
            if (i >= 7) {
                if (k == k_alpha || k == k_beta) {
                    int base = (k == k_beta) ? 10 : 5;
                    ((JavaObject*)p)->fields[0].ref  = objs[i - 7];
                    ((JavaObject*)p)->fields[5].ref  = objs[i - 3];
                    ((JavaObject*)p)->fields[8].ref  = objs[(i - base + N7) % i];
                    if (k == k_beta) ((JavaObject*)p)->fields[10].ref = objs[i - 1];
                } else if (k == k_entry) {
                    ((JavaObject*)p)->fields[0].ref = objs[i - 1];
                    ((JavaObject*)p)->fields[1].ref = objs[i - 2];
                    ((JavaObject*)p)->fields[2].ref = objs[i - 4];
                } else if (k == k_vec) {
                    ((JavaObject*)p)->fields[0].ref = objs[i - 5];
                }
                /* gamma: полей-ссылок нет; int-поля не трогаем (ноль) */
            }
            if ((i % 5) == 0) roots[i / 5] = p;   /* каждый 5-й — корень */
        }
        /* сэмплы связей для пост-GC проверки: ИСТОЧНИКИ — только корневые
         * объекты (гарантированно живые). Значение указателя в поле при
         * mark-sweep без уплотнения не меняется — проверяем и указатель,
         * и то, что ЦЕЛЬ не была помечена свободной. */
        struct { JavaObject* obj; int slot; void* expect; } snap[512];
        int nsnap = 0;
        for (int i = 10; i < N7 && nsnap < 512; i += 5) {
            snap[nsnap].obj = objs[i];
            snap[nsnap].slot = 5;
            snap[nsnap].expect = objs[i - 3];
            nsnap++;
        }
        gc_collect(jvm);

        /* 7a: разметка построена и совпадает с ожидаемой */
        CHECK((k_alpha->gc_kind & 0x01u) != 0, "P7 alpha layout READY");
        CHECK((k_beta->gc_kind & 0x01u)  != 0, "P7 beta layout READY");
        CHECK((k_gamma->gc_kind & 0x01u) != 0, "P7 gamma layout READY");
        {
            static const uint16_t exp_alpha[] = {0, 5, 8};
            static const uint16_t exp_beta[]  = {0, 5, 8, 10};
            static const uint16_t exp_entry[] = {0, 1, 2};
            static const uint16_t exp_vec[]   = {0};
            struct { JavaClass* k; const uint16_t* exp; int n; } lt[4] = {
                {k_alpha, exp_alpha, 3}, {k_beta, exp_beta, 4},
                {k_entry, exp_entry, 3}, {k_vec, exp_vec, 1},
            };
            for (int t = 0; t < 4; t++) {
                CHECK(lt[t].k->gc_ref_slot_count == lt[t].n,
                      "P7 layout count %s: %u != %d", lt[t].k->class_name,
                      (unsigned)lt[t].k->gc_ref_slot_count, lt[t].n);
                for (int j = 0; j < lt[t].n && j < (int)lt[t].k->gc_ref_slot_count; j++) {
                    CHECK(lt[t].k->gc_ref_slots[j] == lt[t].exp[j],
                          "P7 layout slot %s[%d]: %u != %u", lt[t].k->class_name, j,
                          (unsigned)lt[t].k->gc_ref_slots[j], (unsigned)lt[t].exp[j]);
                }
            }
            CHECK(k_gamma->gc_ref_slot_count == 0, "P7 gamma layout empty");
            CHECK(k_gamma->gc_kind & 0x01u, "P7 gamma READY(empty)");
            /* родительская разметка не смешалась с дочерней */
            CHECK(k_beta->gc_ref_slot_count == 4, "P7 beta not aliased to alpha");
        }

        /* 7b: связи живых уцелели; цели связей из живых корней — живы
         * (если разметка пропустит слот 5, цель умрёт и проверка это поймает). */
        for (int s = 0; s < nsnap; s++) {
            CHECK(snap[s].obj->fields[snap[s].slot].ref == snap[s].expect,
                  "P7 field link broken snap=%d", s);
            void* tgt = snap[s].obj->fields[snap[s].slot].ref;
            if (tgt) {
                CHECK(((GCObjectHeader*)tgt - 1)->type != OBJ_TYPE_FREE,
                      "P7 link target freed snap=%d", s);
            }
        }
        /* только alpha/beta-корни (у них слот 5 валиден): f5-цели живы */
        for (int i = 10; i < N7; i += 5) {
            JavaObject* o = objs[i];
            CHECK(o != NULL, "P7 root obj %d", i);
            if (!o) break;
            void* r5 = o->fields[5].ref;   /* класс i%5==0 -> alpha/beta, слот 5 валиден */
            if (r5) {
                CHECK(((GCObjectHeader*)r5 - 1)->type != OBJ_TYPE_FREE,
                      "P7 live->freed ref i=%d", i);
            }
        }
        /* churn мусора того же профиля + повторные GC: связи не рвутся */
        for (int round = 0; round < 4; round++) {
            for (int g = 0; g < 800; g++) {
                void* p = heap_alloc(jvm, k_alpha->instance_size, k_alpha, OBJ_TYPE_OBJECT);
                CHECK(p != NULL, "P7 garbage alloc r=%d g=%d", round, g);
                if (!p) break;
                ((JavaObject*)p)->fields[0].ref = objs[(g * 13) % N7];  /* мёртвая ссылка на живое */
            }
            gc_collect(jvm);
            for (int s = 0; s < nsnap; s++) {
                CHECK(snap[s].obj->fields[snap[s].slot].ref == snap[s].expect,
                      "P7 field link broken churn snap=%d r=%d", s, round);
            }
        }
        /* 7c: полная гибель -> ёмкость восстановилась */
        {
            for (int i = 0; i < N7; i += 5) roots[i / 5] = NULL;
            gc_collect(jvm);
            size_t got = 0;
            while (got < 20000) {
                void* p = heap_alloc(jvm, 88, NULL, OBJ_TYPE_OBJECT);
                if (!p) break;
                roots[15000 + (got % 4000)] = p;   /* живые, чтобы не мешать auto-GC */
                got++;
            }
            printf("     post-graph capacity: %zu x 88B\n", got);
            CHECK(got > 15000, "P7 capacity after graph: %zu", got);
            for (size_t i = 0; i < 4000; i++) roots[15000 + i] = NULL;
            gc_collect(jvm);
        }
        /* очистка корней фазы и классов (кучу не трогаем — она уничтожается heap_destroy) */
        kill_all_roots();
        gc_collect(jvm);
        free(k_alpha); free(k_beta); free(k_gamma); free(k_entry); free(k_vec);
    }

    /* ============ PHASE 8: TLAB (v34.59) ============
     * Инварианты потоковых аллокационных буферов:
     *  a) fast path активен на мелких размерах (heap_tlab_stats);
     *  b) целостность данных живых объектов, рождённых в чанках,
     *     через GC-циклы (паттерны);
     *  c) учёт: линейный обход == heap.allocated после GC — атомарные
     *     инкременты TLAB-пути точно сходятся с вычетами sweep;
     *  d) граничные размеры: total == 1024 (последний влезающий в
     *     TLAB) и 1032 (первый мимо fast path);
     *  e) ёмкость: после полного churn+GC большие блоки снова
     *     аллоцируются (остатки чанков не теряются);
     *  f) смерть потока с активным чанком: 4 воркера churn'ят мелочь
     *     в своих чанках и выходят; после join — gc_collect (sweep
     *     обязан пережить закрытые чанки) и walk-проверка.
     * Воркеры НЕ запускают GC (bounded churn в 64 МБ куче) — обычные
     * однопоточные стабы safepoint'а корректны. */
    printf("[P8] TLAB invariants ...\n");
    {
        /* 8a: мелкий churn — fast path обязан работать */
        {
            uint64_t c0 = 0, f0 = 0, c1 = 0, f1 = 0;
            heap_tlab_stats(&c0, &f0);
            for (int i = 0; i < 300000; i++) {
                size_t sz = 24 + (size_t)(rand() % 200);
                void* p = xalloc(sz);
                if (!p) { CHECK(0, "P8a OOM at %d", i); break; }
                roots[i % NROOTS] = p;
            }
            heap_tlab_stats(&c1, &f1);
            CHECK(f1 > f0, "P8a fast path used (f0=%llu f1=%llu)",
                  (unsigned long long)f0, (unsigned long long)f1);
            CHECK(c1 > c0, "P8a chunks carved (c0=%llu c1=%llu)",
                  (unsigned long long)c0, (unsigned long long)c1);
        }

        /* 8b+8d: живые в чанках + границы TLAB_MAX_TOTAL */
        {
            /* заполняем паттернами, включая граничные total = 1024 (984+40)
             * и total = 1032 (992+40 — уже мимо fast path) */
            static void* keep[4096];
            static size_t ksz[4096];
            const size_t bnd[] = { 984, 992, 24, 64, 120, 200, 480, 984, 992, 56 };
            int nk = 0;
            for (int r = 0; r < 8 && nk < 4096; r++) {
                for (size_t k = 0; k < sizeof bnd / sizeof bnd[0] && nk < 4096; k++) {
                    void* p = xalloc(bnd[k]);
                    if (!p) break;
                    GCObjectHeader* h = (GCObjectHeader*)p - 1;
                    size_t pl = h->size - sizeof(GCObjectHeader);
                    fill_pattern(nk, p, pl);
                    keep[nk] = p; ksz[nk] = pl;
                    roots[10000 + nk] = p;   /* ДЕРЖИМ ЖИВЫМИ (иначе умрут!) */
                    nk++;
                }
            }
            for (int r = 0; r < 6; r++) {
                /* мусор между GC — чанки вырезаются и закрываются */
                for (int i = 0; i < 50000; i++) {
                    void* p = xalloc(24 + (size_t)(rand() % 300));
                    if (!p) break;
                }
                gc_collect(jvm);
                for (int i = 0; i < nk; i++) {
                    CHECK(verify_pattern(i, keep[i], ksz[i]) == 0,
                          "P8b pattern broken r=%d i=%d", r, i);
                }
            }
            /* 8c: учёт после GC — обход согласован с heap.allocated */
            {
                HeapStats st = heap_get_stats(jvm);
                size_t blocks = 0;
                /* после полной гибели top-rewind опускает current ниже
                 * g_max_alloc_end — обход выше current читает девственную
                 * память (нули). Ограничиваем границей кучи. */
                uint8_t* we8c = g_max_alloc_end;
                void* top8c = heap_top_ptr();
                if (top8c && (uint8_t*)top8c < we8c) we8c = (uint8_t*)top8c;
                long used = heap_walk_used(&blocks, we8c);
                CHECK(used >= 0, "P8c walk valid");
                CHECK((size_t)used == st.used_size,
                      "P8c accounting: walk=%ld stats=%zu",
                      used, st.used_size);
            }
            /* 8e: ёмкость — большой блок после churn */
            {
                for (int i = 0; i < NROOTS; i++) roots[i] = NULL;   /* и keep[] в 10000.. */
                gc_collect(jvm);
                void* big = xalloc(1u << 20);
                CHECK(big != NULL, "P8e 1MB block after TLAB churn");
                gc_collect(jvm);
            }
            (void)keep; (void)ksz;
        }

        /* 8f: потоки с активными чанками рождаются и умирают */
        {
            pthread_t th[4];
            for (int w = 0; w < 4; w++) {
                g_p8_wargs[w].id = w;
                g_p8_wargs[w].seed = 9000u + (unsigned)w;
                g_p8_wargs[w].kept = 0;
                g_p8_wargs[w].allocs = 0;
                pthread_create(&th[w], NULL, p8_worker, &g_p8_wargs[w]);
            }
            for (int w = 0; w < 4; w++) pthread_join(th[w], NULL);
            long total_w = 0;
            for (int w = 0; w < 4; w++) {
                total_w += g_p8_wargs[w].allocs;
                CHECK(g_p8_wargs[w].allocs > 10000,
                      "P8f worker %d churned enough (%ld)",
                      w, g_p8_wargs[w].allocs);
            }
            /* маленький churn в главном потоке — его чанк тоже откроется/закроется */
            for (int i = 0; i < 100000; i++) {
                if (!xalloc(24 + (size_t)(rand() % 300))) break;
            }
            heap_tlab_flush_self();   /* как GC-коллектор */
            gc_collect(jvm);
            HeapStats st = heap_get_stats(jvm);
            size_t blocks = 0;
            uint8_t* we8f = g_max_alloc_end;   /* как P8c: clamp по current */
            void* top8f = heap_top_ptr();
            if (top8f && (uint8_t*)top8f < we8f) we8f = (uint8_t*)top8f;
            long used = heap_walk_used(&blocks, we8f);
            CHECK(used >= 0, "P8f walk after thread churn");
            CHECK((size_t)used == st.used_size,
                  "P8f accounting after threads: walk=%ld stats=%zu",
                  used, st.used_size);
            printf("     P8f: 4 workers x ~%ld allocs, walk=%ld used, %zu blocks\n",
                   total_w / 4, used, blocks);
        }
        kill_all_roots();
        gc_collect(jvm);
    }

    /* ============ Итог ============ */
    heap_destroy(jvm);
    printf("\n==== gc_stress: %d checks, %d failures ====\n", g_checks, g_failures);
    return g_failures ? 1 : 0;
}
