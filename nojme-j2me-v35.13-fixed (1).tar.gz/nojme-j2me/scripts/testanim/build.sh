#!/bin/bash
# Build TestAnim.jar — JSR-184 M3G animation spec-compliance selftest (v34.74).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestAnim.java" \
    "$D/stubs/javax/microedition/m3g/"*.java \
    "$D/stubs/javax/microedition/midlet/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestAnim\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/TestAnim.jar" META-INF && zip -q "$D/TestAnim.jar" *.class )
echo "built: $D/TestAnim.jar"
