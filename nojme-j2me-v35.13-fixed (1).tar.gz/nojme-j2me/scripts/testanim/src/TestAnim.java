import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.m3g.AnimationController;
import javax.microedition.m3g.AnimationTrack;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.KeyframeSequence;
import javax.microedition.m3g.Node;
import javax.microedition.m3g.World;

/* TestAnim — JSR-184 (M3G) animation spec-compliance suite (v34.74).
 * Prints "M:<id> PASS/FAIL <detail>" lines and a final ANIM:DONE marker.
 * Covers: LINEAR/STEP/SLERP interpolation, CONSTANT/LOOP repeat, clamp,
 * controller speed/position/active-interval/weight, track weight default,
 * weighted blending normalization, null controller, float sampling time,
 * animate() validity, subtree propagation.
 */
public class TestAnim extends MIDlet {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("M:" + id + " PASS " + detail); }
        else      { fail++; System.out.println("M:" + id + " FAIL " + detail); }
    }

    /* Two-key translation sequence: (0,0,0)@0 -> (100,0,0)@100 */
    static KeyframeSequence linSeq(int interp) {
        KeyframeSequence ks = new KeyframeSequence(2, 3, interp);
        ks.setKeyframe(0, 0, new float[] { 0f, 0f, 0f });
        ks.setKeyframe(1, 100, new float[] { 100f, 0f, 0f });
        ks.setDuration(100);
        ks.setRepeatMode(KeyframeSequence.CONSTANT);
        ks.setValidRange(0, 1);
        return ks;
    }

    protected void startApp() throws MIDletStateChangeException {
        System.out.println("ANIM-TEST-START");

        /* M1: LINEAR midpoint */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M1", Math.abs(tr[0] - 50f) < 0.01f, "LINEAR mid: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M1", false, "exc " + e);
        }

        /* M2: CONSTANT clamps past the end */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            n.addAnimationTrack(t);
            n.animate(150);
            float[] tr = new float[3];
            n.getTranslation(tr);
            boolean clamped = Math.abs(tr[0] - 100f) < 0.01f;
            n.animate(-10);
            n.getTranslation(tr);
            chk("M2", clamped && Math.abs(tr[0] - 0f) < 0.01f,
                "CONSTANT clamp: end=" + clamped + " before=" + tr[0]);
        } catch (Throwable e) {
            chk("M2", false, "exc " + e);
        }

        /* M3: STEP holds the keyframe value between keys */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.STEP), AnimationTrack.TRANSLATION);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            boolean hold = Math.abs(tr[0]) < 0.01f;
            n.animate(100);
            n.getTranslation(tr);
            chk("M3", hold && Math.abs(tr[0] - 100f) < 0.01f,
                "STEP: @50=" + tr[0] + " hold=" + hold);
        } catch (Throwable e) {
            chk("M3", false, "exc " + e);
        }

        /* M4: LOOP wraps */
        try {
            KeyframeSequence ks = linSeq(KeyframeSequence.LINEAR);
            ks.setRepeatMode(KeyframeSequence.LOOP);
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(ks, AnimationTrack.TRANSLATION);
            n.addAnimationTrack(t);
            n.animate(150);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M4", Math.abs(tr[0] - 50f) < 0.01f, "LOOP @150: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M4", false, "exc " + e);
        }

        /* M5: controller speed 0.5 halves the sampled time */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            c.setSpeed(0.5f, 0);
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(100);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M5", Math.abs(tr[0] - 50f) < 0.01f, "speed .5 @100: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M5", false, "exc " + e);
        }

        /* M6: setPosition shifts the mapping */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            c.setPosition(50f, 0);
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(0);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M6", Math.abs(tr[0] - 50f) < 0.01f, "pos=50 @0: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M6", false, "exc " + e);
        }

        /* M7: fresh AnimationTrack weight defaults to 1.0 */
        try {
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            float w = t.getWeight();
            boolean apiDead;
            {
                Node n = new Node();
                n.addAnimationTrack(t); /* no controller: identity mapping */
                n.animate(50);
                float[] tr = new float[3];
                n.getTranslation(tr);
                apiDead = Math.abs(tr[0]) < 0.01f;
            }
            chk("M7", Math.abs(w - 1.0f) < 0.001f && !apiDead,
                "fresh track: weight=" + w + " (moves=" + (!apiDead) + ")");
        } catch (Throwable e) {
            chk("M7", false, "exc " + e);
        }

        /* M8: single track with controller weight 0.5 -> normalized to full */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            c.setWeight(0.5f);
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M8", Math.abs(tr[0] - 50f) < 0.01f,
                "weight .5 single: x=" + tr[0] + " (weighted avg => full)");
        } catch (Throwable e) {
            chk("M8", false, "exc " + e);
        }

        /* M9: two same-property tracks blend (average), not add */
        try {
            Node n = new Node();
            KeyframeSequence kx = new KeyframeSequence(2, 3, KeyframeSequence.LINEAR);
            kx.setKeyframe(0, 0, new float[] { 100f, 0f, 0f });
            kx.setKeyframe(1, 100, new float[] { 100f, 0f, 0f });
            kx.setValidRange(0, 1);
            KeyframeSequence ky = new KeyframeSequence(2, 3, KeyframeSequence.LINEAR);
            ky.setKeyframe(0, 0, new float[] { 0f, 100f, 0f });
            ky.setKeyframe(1, 100, new float[] { 0f, 100f, 0f });
            ky.setValidRange(0, 1);
            AnimationTrack tx = new AnimationTrack(kx, AnimationTrack.TRANSLATION);
            AnimationTrack ty = new AnimationTrack(ky, AnimationTrack.TRANSLATION);
            n.addAnimationTrack(tx);
            n.addAnimationTrack(ty);
            n.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M9", Math.abs(tr[0] - 50f) < 0.01f && Math.abs(tr[1] - 50f) < 0.01f,
                "blend 2 tracks: x=" + tr[0] + " y=" + tr[1] + " (avg, not sum)");
        } catch (Throwable e) {
            chk("M9", false, "exc " + e);
        }

        /* M10: track with null controller = identity mapping (world time) */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            t.setController(null);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M10", Math.abs(tr[0] - 50f) < 0.01f, "null controller: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M10", false, "exc " + e);
        }

        /* M11: inactive controller leaves the property untouched */
        try {
            Node n = new Node();
            n.setTranslation(200f, 0f, 0f);
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            c.setActiveInterval(0, 100);
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(200);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M11", Math.abs(tr[0] - 200f) < 0.01f, "inactive ctrl: x=" + tr[0]);
        } catch (Throwable e) {
            chk("M11", false, "exc " + e);
        }

        /* M12: animate() validity is finite for a live track */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            n.addAnimationTrack(t);
            int v = n.animate(50);
            chk("M12", v > 0 && v < 0x7FFFFFFF, "validity=" + v);
        } catch (Throwable e) {
            chk("M12", false, "exc " + e);
        }

        /* M13: SLERP orientation mid-quat = 45 deg about Y */
        try {
            Node n = new Node();
            KeyframeSequence ks = new KeyframeSequence(2, 4, KeyframeSequence.SLERP);
            ks.setKeyframe(0, 0, new float[] { 0f, 0f, 0f, 1f });
            ks.setKeyframe(1, 100, new float[] { 0f, 0.70710678f, 0f, 0.70710678f });
            ks.setValidRange(0, 1);
            AnimationTrack t = new AnimationTrack(ks, AnimationTrack.ORIENTATION);
            AnimationController c = new AnimationController();
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] oa = new float[4];
            n.getOrientation(oa);
            chk("M13", Math.abs(oa[0] - 45f) < 1.0f && Math.abs(oa[2] - 1f) < 0.1f,
                "SLERP mid: angle=" + oa[0] + " axis=(" + oa[1] + "," + oa[2] + "," + oa[3] + ")");
        } catch (Throwable e) {
            chk("M13", false, "exc " + e);
        }

        /* M14: SCALE interpolation */
        try {
            Node n = new Node();
            KeyframeSequence ks = new KeyframeSequence(2, 1, KeyframeSequence.LINEAR);
            ks.setKeyframe(0, 0, new float[] { 1f });
            ks.setKeyframe(1, 100, new float[] { 2f });
            ks.setValidRange(0, 1);
            AnimationTrack t = new AnimationTrack(ks, AnimationTrack.SCALE);
            n.addAnimationTrack(t);
            n.animate(50);
            float[] sc = new float[3];
            n.getScale(sc);
            chk("M14", Math.abs(sc[0] - 1.5f) < 0.01f, "SCALE mid: s=" + sc[0]);
        } catch (Throwable e) {
            chk("M14", false, "exc " + e);
        }

        /* M15: VISIBILITY step track toggles rendering.
         * STEP holds key0 (=1, visible) on [0,100); at t=100 the value
         * becomes 0; CONSTANT (NO_REPEAT) clamps past the end at 0. */
        try {
            Node n = new Node();
            KeyframeSequence ks = new KeyframeSequence(2, 1, KeyframeSequence.STEP);
            ks.setKeyframe(0, 0, new float[] { 1f });
            ks.setKeyframe(1, 100, new float[] { 0f });
            ks.setValidRange(0, 1);
            AnimationTrack t = new AnimationTrack(ks, AnimationTrack.VISIBILITY);
            n.addAnimationTrack(t);
            n.animate(50);
            boolean visibleMid = n.isRenderingEnabled();
            n.animate(150);
            boolean hiddenAfter = !n.isRenderingEnabled();
            chk("M15", visibleMid && hiddenAfter,
                "VISIBILITY step: @50 visible=" + visibleMid + " @150 hidden=" + hiddenAfter);
        } catch (Throwable e) {
            chk("M15", false, "exc " + e);
        }

        /* M16: float sampling time (speed 0.5, t=101 -> 50.5) */
        try {
            Node n = new Node();
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            AnimationController c = new AnimationController();
            c.setSpeed(0.5f, 0);
            t.setController(c);
            n.addAnimationTrack(t);
            n.animate(101);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M16", Math.abs(tr[0] - 50.5f) < 0.1f, "float time: x=" + tr[0] + " (want 50.5)");
        } catch (Throwable e) {
            chk("M16", false, "exc " + e);
        }

        /* M17: subtree propagation — world.animate reaches the child */
        try {
            World w = new World();
            Group g = new Group();
            Node n = new Node();
            g.addChild(n);
            w.addChild(g);
            AnimationTrack t = new AnimationTrack(linSeq(KeyframeSequence.LINEAR), AnimationTrack.TRANSLATION);
            n.addAnimationTrack(t);
            w.animate(50);
            float[] tr = new float[3];
            n.getTranslation(tr);
            chk("M17", Math.abs(tr[0] - 50f) < 0.01f, "subtree: child x=" + tr[0]);
        } catch (Throwable e) {
            chk("M17", false, "exc " + e);
        }

        /* M18: controller getPosition math (ref + speed*delta).
         * setSpeed(2,10) preserves the position at wt=10 (which is 10 for a
         * fresh controller), so getPosition(60) = 10 + 2*(60-10) = 110. */
        try {
            AnimationController c = new AnimationController();
            c.setSpeed(2.0f, 10);
            float p = c.getPosition(60);
            chk("M18", Math.abs(p - 110f) < 0.01f, "getPosition: " + p);
        } catch (Throwable e) {
            chk("M18", false, "exc " + e);
        }

        System.out.println("ANIM:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    protected void pauseApp() { }
    protected void destroyApp(boolean u) throws MIDletStateChangeException { }
}
