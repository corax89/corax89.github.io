package javax.microedition.m3g;

public class Background extends Object3D {
    public void setColor(int argb) { }
    public int getColor() { return 0; }
}
