package javax.microedition.m3g;

public class World extends Group {
    public void setBackground(Background background) { }
}
