package javax.microedition.m3g;

public class AnimationController extends Object3D {
    public void setActiveInterval(int worldStartTime, int worldEndTime) { }
    public int getActiveIntervalStart() { return 0; }
    public int getActiveIntervalEnd() { return 0; }
    public void setSpeed(float factor, int worldTime) { }
    public float getSpeed() { return 1.0f; }
    public void setPosition(float sequenceTime, int worldTime) { }
    public float getPosition(int worldTime) { return 0.0f; }
    public void setWeight(float weight) { }
    public float getWeight() { return 1.0f; }
    public int getRefWorldTime() { return 0; }
}
