package javax.microedition.m3g;

public class Group extends Node {
    public void addChild(Node child) { }
    public void removeChild(Node child) { }
}
