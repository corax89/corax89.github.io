package javax.microedition.m3g;

public class Transformable extends Object3D {
    public void setTranslation(float tx, float ty, float tz) { }
    public void getTranslation(float[] translation) { }
    public void setScale(float sx, float sy, float sz) { }
    public void getScale(float[] scale) { }
    public void setOrientation(float angle, float ax, float ay, float az) { }
    public void getOrientation(float[] angleAxis) { }
}
