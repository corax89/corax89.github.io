package javax.microedition.m3g;

public class Object3D {
    public void addAnimationTrack(AnimationTrack animationTrack) { }
    public void removeAnimationTrack(AnimationTrack animationTrack) { }
    public int getAnimationTrackCount() { return 0; }
    public AnimationTrack getAnimationTrack(int index) { return null; }
    public int animate(int worldTime) { return 0; }
    public int getUserID() { return 0; }
    public void setUserID(int userID) { }
}
