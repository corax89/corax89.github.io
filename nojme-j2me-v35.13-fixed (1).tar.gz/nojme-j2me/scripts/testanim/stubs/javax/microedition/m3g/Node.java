package javax.microedition.m3g;

public class Node extends Transformable {
    public boolean isRenderingEnabled() { return true; }
    public void setRenderingEnable(boolean state) { }
    public float getAlphaFactor() { return 1.0f; }
    public void setAlphaFactor(float alphaFactor) { }
}
