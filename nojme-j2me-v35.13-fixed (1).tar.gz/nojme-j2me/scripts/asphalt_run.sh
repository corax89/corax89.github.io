#!/bin/bash
# Run Asphalt 3 3D headless with snapshots to inspect rendering
cd /home/z/my-project/j2me-analysis
JAR="Asphalt 3 3D (1.1.5).jar"
OUT=work/asphalt_check
mkdir -p $OUT
rm -f /tmp/j2me_frame_*.ppm
NOJME_HEADLESS_MAX_MS=60000 \
NOJME_HEADLESS_KEYSEQ="5,-5" \
NOJME_HEADLESS_KEYSEQ_EVERY=200 \
NOJME_HEADLESS_SNAP_FRAMES=1,300,600,1200,2000,3000,4000,5000 \
./bin/j2me-headless "$JAR" > $OUT/run.log 2>&1
echo "exit=$?"
# Convert snapshots to PNG
for f in /tmp/j2me_frame_*.ppm; do
  [ -f "$f" ] || continue
  n=$(basename "$f" .ppm | sed 's/j2me_frame_//')
  python3 -c "
from PIL import Image
img = Image.open('$f')
img.save('$OUT/frame_$n.png')
" 2>/dev/null || convert "$f" "$OUT/frame_$n.png" 2>/dev/null
done
ls -la $OUT/
