#!/usr/bin/env python3
"""Insert the __SWITCH__ main() into src/main.c:
  - guards the existing desktop main() with #ifndef __SWITCH__
  - adds the Switch frontend loop: menu -> game -> teardown -> menu
  - exports j2me_core_build_id() for the menu header

Run: python3 scripts/switch_patch_main.py
"""

PATH = "src/main.c"
src = open(PATH, encoding="utf-8").read()

def replace_once(s, old, new, what):
    assert old in s, "anchor missing: " + what
    assert s.count(old) == 1, "anchor not unique: " + what
    return s.replace(old, new)

# ------------------------------------------------------------------
# 1. guard the existing main()
# ------------------------------------------------------------------
src = replace_once(src,
"""int main(int argc, char** argv) {
    /* v38: [V37-DIAG] main() breadcrumb removed (quiet-by-default). */
    fflush(stderr);
""",
"""#ifndef __SWITCH__
int main(int argc, char** argv) {
    /* v38: [V37-DIAG] main() breadcrumb removed (quiet-by-default). */
    fflush(stderr);
""", "guard main head")

# ------------------------------------------------------------------
# 2. close the guard + add the Switch main at the file end
# ------------------------------------------------------------------
src = src.rstrip() + """

#else /* __SWITCH__ — Nintendo Switch frontend (v34.84) */

/* Core build id for the menu header (switch_ui.c). */
const char* j2me_core_build_id(void) { return CORE_BUILD_ID; }

/*
 * Switch entry point: no command line — an in-app menu (game browser +
 * settings, src/switch/switch_ui.c) drives everything. Each selected JAR
 * runs a full emulator session (init_emulator -> run_midlet -> teardown)
 * on the SHARED SDL window; after the game ends control returns to the
 * menu so the user can open another game without restarting the app.
 */
int main(int argc, char** argv) {
    (void)argc; (void)argv;
    fflush(stderr);
    log_mutex_init();

    if (getenv("NOJME_NEON_SELFTEST")) {
        int st_fails = render_neon_selftest();
        if (strcmp(getenv("NOJME_NEON_SELFTEST"), "run") != 0) {
            return st_fails ? 1 : 0;
        }
    }

    LOG_SAFE("=== J2ME Emulator (Switch) — core %s ===\\n", CORE_BUILD_ID);

    if (sdl_switch_platform_init() != 0) {
        LOG_SAFE("[SWITCH] platform init failed, exiting\\n");
        return 1;
    }

    for (;;) {
        char jar_path[1024];
        if (!switch_ui_pick_game(jar_path, sizeof(jar_path))) {
            LOG_SAFE("[SWITCH] menu exit — shutting down\\n");
            break;
        }

        Options opts;
        memset(&opts, 0, sizeof(opts));
        opts.width = MIDP_DEFAULT_WIDTH;
        opts.height = MIDP_DEFAULT_HEIGHT;
        opts.explicit_size = false;
        opts.scale = 1; /* presentation is rect-based on the fixed screen */
        opts.heap_size_mb = 64;
        opts.jar_file = jar_path;

        /* manifest resolution hint (mirrors the desktop main) */
        {
            size_t peek_size = 0;
            uint8_t* peek = load_jar_file(opts.jar_file, &peek_size);
            if (peek) {
                int hint_w = 0, hint_h = 0;
                if (jar_detect_screen_size(peek, peek_size, &hint_w, &hint_h)) {
                    opts.width = hint_w;
                    opts.height = hint_h;
                    LOG_SAFE("[SWITCH] auto resolution: manifest hint -> %dx%d\\n",
                             hint_w, hint_h);
                }
                free(peek);
            }
        }

        /* settings -> VM knobs (mirrors the libretro j2me_vm_speed
         * semantics: original=15000, fast=90000, turbo=0 budget) */
        {
            extern long g_jvm_thread_budget;
            const SwitchSettings* st = switch_settings_get();
            switch (st->vm_speed) {
                case NOJME_VM_SPEED_ORIGINAL: g_jvm_thread_budget = 15000; break;
                case NOJME_VM_SPEED_TURBO:    g_jvm_thread_budget = 0;      break;
                default:                      g_jvm_thread_budget = 90000;  break;
            }
            LOG_SAFE("[SWITCH] session: %s (%dx%d), budget=%ld, audio=%d\\n",
                     jar_path, opts.width, opts.height, g_jvm_thread_budget,
                     st->audio_enabled);
        }

        if (!init_emulator(&opts)) {
            LOG_SAFE("[SWITCH] init_emulator failed — back to menu\\n");
            cleanup();
            g_jar_data = NULL;
            g_jar_size = 0;
            continue;
        }

        /* v34.81 pause watchdog: the in-game MINUS menu blocks the frame
         * loop; VM threads park after the stall threshold and virtual
         * time freezes until the menu closes. */
        {
            extern void jvm_frontend_pause_enable(int on);
            jvm_frontend_pause_enable(1);
        }

        (void)run_midlet(&opts);

        /* teardown: wait briefly for lingering Java threads, then clean.
         * If threads refuse to die, cleanup() _exit(0)s to HBmenu rather
         * than tearing the heap under a running thread (house rule). */
        {
            extern bool vm_threads_busy(void);
            int waited_ms = 0;
            while (vm_threads_busy() && waited_ms < 2000) {
                struct timespec ts = { .tv_sec = 0, .tv_nsec = 50 * 1000000L };
                nanosleep(&ts, NULL);
                waited_ms += 50;
            }
        }
        cleanup();
        g_jar_data = NULL;
        g_jar_size = 0;
        LOG_SAFE("[SWITCH] session complete — back to menu\\n");
    }

    sdl_switch_platform_shutdown();
    return 0;
}

#endif /* !__SWITCH__ */
"""

# include the switch headers at the top (after sdl_backend.h include)
src = replace_once(src,
'#include "sdl_backend.h"\n#include "debug.h"\n',
'#include "sdl_backend.h"\n#include "debug.h"\n#ifdef __SWITCH__\n#include "switch/switch_glue.h"\n#include "switch/switch_common.h"\n#include "switch/switch_ui.h"\n#endif\n', "switch includes")

open(PATH, "w", encoding="utf-8").write(src)
print("main.c patched OK")
