#!/usr/bin/env python3
"""Deep analysis of 3D Solid Weapon M3G character files:
- full transformables (translation + orientation angle/axis + scale) per Group
- animation track bindings (which track targets which object)
- keyframe decode sanity (bbox of animated values, both raw and /127)
- vertex bbox raw vs normalized"""
import struct, sys, zlib
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_hexdump import sections_of, objects_of

TYPE = {0:'HEADER', 1:'ANIMCONTROLLER', 2:'ANIMTRACK', 3:'APPEARANCE', 4:'BACKGROUND',
        5:'CAMERA', 6:'COMPOSITINGMODE', 7:'FOG', 8:'POLYGONMODE', 9:'GROUP',
        10:'IMAGE2D', 11:'TRIANGLESTRIPARRAY', 12:'LIGHT', 13:'MATERIAL', 14:'MESH',
        15:'MORPHINGMESH', 16:'SKINNEDMESH', 17:'TEXTURE2D', 18:'SPRITE3D',
        19:'KEYFRAMESEQ', 20:'VERTEXARRAY', 21:'VERTEXBUFFER', 22:'WORLD', 255:'EXTERNALREF'}

class R:
    def __init__(self, b, p=0):
        self.b = b; self.p = p
    def u8(self):
        v = self.b[self.p]; self.p += 1; return v
    def u16(self):
        v = struct.unpack('<H', self.b[self.p:self.p+2])[0]; self.p += 2; return v
    def i16(self):
        v = struct.unpack('<h', self.b[self.p:self.p+2])[0]; self.p += 2; return v
    def u32(self):
        v = struct.unpack('<I', self.b[self.p:self.p+4])[0]; self.p += 4; return v
    def f32(self):
        v = struct.unpack('<f', self.b[self.p:self.p+4])[0]; self.p += 4; return v
    def f32n(self, n):
        return [self.f32() for _ in range(n)]

def parse(path):
    objs = objects_of(sections_of(path))
    parsed = []
    for si_body in objs:
        t, body = si_body
        r = R(body)
        info = {'type': TYPE.get(t, str(t))}
        if t not in (0, 255):
            info['uid'] = r.u32()
            n = r.u32()
            info['tracks'] = [r.u32() for _ in range(n)]
            n = r.u32()
            for _ in range(n):
                r.u32(); ln = r.u32(); r.p += ln
            # transformable
            if t in (14, 15, 16, 9, 22, 5, 12, 18):
                if r.u8():
                    info['t'] = tuple(r.f32n(3))
                    info['s'] = tuple(r.f32n(3))
                    info['o'] = tuple(r.f32n(4))  # angle,ax,ay,az
                if r.u8():
                    info['g'] = r.f32n(16)
                # node
                info['ren'] = r.u8(); info['pick'] = r.u8()
                info['alpha'] = r.u8(); info['scope'] = r.u32()
                if r.u8():
                    r.u8(); r.u8(); r.u32(); r.u32()
        if t == 9 or t == 22:
            cc = r.u32()
            info['children'] = [r.u32() for _ in range(cc)]
        elif t == 16:
            info['vb_ref'] = r.u32()
            info['submeshes'] = [(r.u32(), r.u32()) for _ in range(r.u32())]
            info['skeleton_ref'] = r.u32()
            n = r.u32()
            info['bones'] = [(r.u32(), r.u32(), r.u32(), r.u32()) for _ in range(n)]
        elif t == 2:  # ANIMTRACK
            info['seq_ref'] = r.u32()
            info['ctrl_ref'] = r.u32()
            info['property'] = r.u32()
        elif t == 21:  # VERTEXBUFFER
            r.u8(); r.u8(); r.u8(); r.u8()
            info['pos_ref'] = r.u32(); info['bias'] = r.f32n(3); info['scale'] = r.f32()
        elif t == 19:  # KEYFRAMESEQ
            info['interp'] = r.u8(); info['repeat'] = r.u8(); info['enc'] = r.u8()
            info['dur'] = r.u32(); info['vrF'] = r.u32(); info['vrL'] = r.u32()
            info['comp'] = r.u32()
            cc = info['comp']
            info['kfCount'] = r.u32()
            # read all kfs raw (defensive)
            kfs = []
            if info['enc'] == 1:
                # real layout: kfCount first, THEN bias/scale arrays
                info['bias'] = r.f32n(cc)
                info['scale'] = r.f32n(cc)
                try:
                    for _ in range(info['kfCount']):
                        tm = r.u32()
                        vals = [struct.unpack('<b', r.b[c1:c1+1])[0]
                                for c1 in range(r.p, r.p + cc)]
                        r.p += cc
                        kfs.append((tm, vals))
                except Exception as e:
                    info['kf_err'] = str(e)
            info['kfs'] = kfs
        info['leftover'] = len(body) - r.p
        parsed.append(info)
    return parsed

def track_uid_map(parsed):
    m = {}
    for i, o in enumerate(parsed):
        if o['type'] == 'ANIMTRACK':
            m[i + 1] = o.get('uid')   # 1-based file ref -> uid
    return m

if __name__ == '__main__':
    path = sys.argv[1]
    parsed = parse(path)
    tum = track_uid_map(parsed)
    print('=== ANIMTRACKS ===')
    for i, o in enumerate(parsed):
        if o['type'] == 'ANIMTRACK':
            print('  file#%d uid=%d: seq#%d prop=%s ctrl#%d' % (
                i + 1, o['uid'], o['seq_ref'], o['property'], o['ctrl_ref']))
    print('=== KEYFRAMESEQS ===')
    for i, o in enumerate(parsed):
        if o['type'] == 'KEYFRAMESEQ':
            print('  file#%d uid=%d interp=%d repeat=%d enc=%d dur=%d vr=[%d,%d] comp=%d kfs=%d bias=%s scale=%s leftover=%d' % (
                i + 1, o['uid'], o['interp'], o['repeat'], o['enc'], o['dur'], o['vrF'], o['vrL'],
                o['comp'], o['kfCount'],
                ['%.2f' % b for b in o.get('bias', [])],
                ['%.2f' % s for s in o.get('scale', [])], o['leftover']))
            if o['enc'] == 1 and o['kfs']:
                # decode both ways, show bbox + first/last keys
                for mode in ('norm', 'raw'):
                    mn = [1e30] * o['comp']; mx = [-1e30] * o['comp']
                    for tm, vals in o['kfs']:
                        for c, v in enumerate(vals):
                            x = o['bias'][c] + o['scale'][c] * (v / 127.0 if mode == 'norm' else v)
                            mn[c] = min(mn[c], x); mx[c] = max(mx[c], x)
                    print('      %s bbox=[%s..%s]' % (mode,
                        ['%.1f' % m for m in mn], ['%.1f' % m for m in mx]))
                print('      times: %s ... %s' % (
                    [k[0] for k in o['kfs'][:8]], o['kfs'][-1][0]))
    print('=== BONES (Groups with transforms + tracks) ===')
    for i, o in enumerate(parsed):
        if o['type'] in ('GROUP', 'CAMERA', 'LIGHT', 'WORLD'):
            line = '  file#%d %s uid=%s' % (i + 1, o['type'], o.get('uid'))
            if 't' in o:
                line += ' t=(%s)' % ','.join('%.1f' % x for x in o['t'])
                if any(o['o'][1:]):
                    line += ' o=(ang=%.1f ax=%.2f,%.2f,%.2f)' % tuple(o['o'])
                if 's' in o and o['s'] != (1.0, 1.0, 1.0):
                    line += ' s=%s' % (tuple(round(x, 3) for x in o['s']),)
            if 'g' in o:
                line += ' GEN-MAT'
            if o.get('tracks'):
                line += ' TRACKS->%s (uids %s)' % (o['tracks'],
                        [tum.get(r, '?') for r in o['tracks']])
            if 'children' in o:
                line += ' children=%s' % o['children']
            print(line)
    print('=== SKINNEDMESH ===')
    for i, o in enumerate(parsed):
        if o['type'] == 'SKINNEDMESH':
            print('  file#%d uid=%s skel#%d vb#%d bones=%d' % (
                i + 1, o['uid'], o['skeleton_ref'], o['vb_ref'], len(o['bones'])))
    print('=== VERTEXBUFFER ===')
    for i, o in enumerate(parsed):
        if o['type'] == 'VERTEXBUFFER':
            print('  file#%d uid=%s posVA#%d bias=%s scale=%.4f' % (
                i + 1, o['uid'], o['pos_ref'], ['%.2f' % b for b in o['bias']], o['scale']))
            # decode vertex bbox
            va = parsed[o['pos_ref'] - 1]
            body = objects_of(sections_of(path))[o['pos_ref'] - 1][1]
            r = R(body)
            r.p += 4
            ntc = r.u32()
            for _ in range(ntc): r.u32()
            nuo = r.u32()
            for _ in range(nuo): r.u32(); ln = r.u32(); r.p += ln
            cs = r.u8(); cc = r.u8(); enc = r.u8(); vc = r.u16()
            data = [struct.unpack('<b', r.b[r.p + (v * cc + c):r.p + (v * cc + c) + 1])[0]
                    for v in range(vc) for c in range(cc)]
            for mode in ('raw', 'norm'):
                mn = [1e30] * 3; mx = [-1e30] * 3
                for v in range(vc):
                    for c in range(3):
                        x = o['bias'][c] + o['scale'] * (data[v * 3 + c] if mode == 'raw'
                            else data[v * 3 + c] / 127.0)
                        mn[c] = min(mn[c], x); mx[c] = max(mx[c], x)
                print('      verts=%d %s bbox=[%s]..[%s]' % (vc, mode,
                    ['%.1f' % m for m in mn], ['%.1f' % m for m in mx]))
