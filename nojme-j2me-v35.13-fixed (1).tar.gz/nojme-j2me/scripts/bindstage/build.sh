#!/bin/bash
# Build BindStageTest.jar — v35.00 bind-path selftest.
# Run:  timeout 60 ./bin/j2me-headless scripts/bindstage/BindStageTest.jar
# Expect SYSOUT: "BINDSTAGE:DONE n=1200 ... PASSED".
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../ecj.jar}"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT"

java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/BindStageTest.java" \
    "$D/stubs/javax/microedition/midlet/"*.java \
    "$D/stubs/javax/microedition/lcdui/"*.java \
    "$D/stubs/javax/microedition/m3g/"*.java

PKG="$OUT/pkg"
rm -rf "$PKG"; mkdir -p "$PKG/META-INF"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: B, , BindStageTest\r\nMIDlet-Name: B\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$PKG/META-INF/MANIFEST.MF"
cp "$OUT/BindStageTest"*.class "$PKG/"
( cd "$PKG" && zip -q -r "$D/BindStageTest.jar" META-INF && zip -q "$D/BindStageTest.jar" *.class )
echo "built: $D/BindStageTest.jar"
