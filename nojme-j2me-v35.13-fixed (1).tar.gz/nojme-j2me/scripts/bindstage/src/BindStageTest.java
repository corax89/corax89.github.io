import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Display;
import javax.microedition.m3g.Graphics3D;

/* v35.00 bind-path selftest: hammers Graphics3D.bindTarget(3-arg) +
 * releaseTarget from the paint callback (the exact call shape of the
 * frozen games: paint -> bind -> release), 1200 frames at ~50 fps.
 * Exercises the CAS lock init, the stage gauge and both bind forms.
 * Expected SYSOUT tail: "BINDSTAGE:DONE n=1200 ... PASSED". */
public class BindStageTest extends MIDlet {

    static class C extends Canvas {
        int frames;
        Graphics3D g3d;

        C() {
            g3d = Graphics3D.getInstance();
        }

        protected void paint(Graphics g) {
            frames++;
            g.setColor(0x203040);
            g.fillRect(0, 0, getWidth(), getHeight());
            try {
                Object t = g3d.bindTarget(g, true, 0);
                if (t == null && frames < 5) {
                    System.out.println("BINDSTAGE: bindTarget returned null at " + frames);
                }
                g3d.releaseTarget();
            } catch (Throwable th) {
                System.out.println("BINDSTAGE: EXC at " + frames + ": " + th);
            }
            if (frames == 1200) {
                System.out.println("BINDSTAGE:DONE n=" + frames + " PASSED");
            }
        }
    }

    C c;

    public void startApp() {
        System.out.println("BINDSTAGE: startApp");
        c = new C();
        c.setFullScreenMode(true);
        Display.getDisplay(this).setCurrent(c);
        Thread t = new Thread() {
            public void run() {
                System.out.println("BINDSTAGE: loop start");
                try {
                    for (int i = 0; i < 1200; i++) {
                        c.repaint();
                        c.serviceRepaints();
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException e) {
                        }
                    }
                } catch (Throwable th) {
                    System.out.println("BINDSTAGE: LOOP EXC: " + th);
                }
                System.out.println("BINDSTAGE:LOOP-EXIT");
            }
        };
        t.start();
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }
}
