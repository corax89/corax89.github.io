package javax.microedition.lcdui;
public class Alert extends Displayable {
    public Alert(String title) {}
    public Alert(String title, String text, Image image, AlertType type) {}
    public void setTimeout(int ms) {}
}
