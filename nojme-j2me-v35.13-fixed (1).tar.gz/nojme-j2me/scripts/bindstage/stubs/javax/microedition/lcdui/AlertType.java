package javax.microedition.lcdui;
public class AlertType { public static final AlertType INFO = new AlertType(); }
