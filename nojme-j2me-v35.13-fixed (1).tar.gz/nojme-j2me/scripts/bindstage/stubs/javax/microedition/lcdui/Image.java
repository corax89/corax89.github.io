package javax.microedition.lcdui;
public class Image { public static Image createImage(String name) throws java.io.IOException { return null; } }
