package javax.microedition.lcdui;
public class Displayable {
    public void addCommand(Command cmd) {}
    public void removeCommand(Command cmd) {}
    public void setCommandListener(CommandListener l) {}
    public String getTitle() { return null; }
    public void setTitle(String t) {}
    public boolean isShown() { return false; }
}
