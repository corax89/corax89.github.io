#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 0a. TestFinish: finished screen is explicit, black, with text ----------
note "0a) TestFinish: FIRE -> notifyDestroyed -> black finished screen"
rm -rf /tmp/reg73/tf; mkdir -p /tmp/reg73/tf
NOJME_LOG=1 KEYSEQ="8" KEYSEQ_EVERY=200 KEYSEQ_LEN=10 \
  timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestFinish.jar 400 /tmp/reg73/tf 0 > /tmp/reg73/tf/run.log 2>&1
rc=$?
seq_ok=$(grep -c "FINISH-START\|FINISH-KEY -5\|FINISH-DESTROYED" /tmp/reg73/tf/run.log || true)
[ $rc -ne 0 ] && fail "TestFinish rc=$rc"
[ "$seq_ok" -ne 3 ] && fail "TestFinish SYSOUT sequence incomplete ($seq_ok/3)"
python3 - <<'EOF' || fail "TestFinish finished-screen pixels"
d=open('/tmp/reg73/tf/lr_last.ppm','rb').read()
parts=d.split(b'\n',3)
w,h=map(int,parts[1].split())
px=parts[3]
black=white=0
for i in range(0,w*h*3,3):
    r,g,b=px[i],px[i+1],px[i+2]
    if r<12 and g<12 and b<12: black+=1
    elif r>200 and g>200 and b>200: white+=1
assert black/(w*h) > 0.9, f"not a black screen ({black/(w*h)*100:.1f}%)"
assert white > 50, f"no white title text ({white} px)"
print(f"[REG] TestFinish: black={black/(w*h)*100:.1f}% white_title_px={white} OK")
EOF

# ---------- 0b. TestBack: cancel exits the list, app survives ----------
note "0b) TestBack: Cancel -> back to MAIN, app keeps running (v34.72 semantics)"
rm -rf /tmp/reg73/tb; mkdir -p /tmp/reg73/tb
NOJME_LOG=1 KEYSEQ="2,2,3,2,2" KEYSEQ_EVERY=100 KEYSEQ_LEN=8 SNAP_EVERY=100 \
  timeout 180 ./bin/lr_run ./bin/nojme_libretro.so games/TestBack.jar 520 /tmp/reg73/tb 0 > /tmp/reg73/tb/run.log 2>&1
rc=$?
n_cancel=$(grep -c "BACK-CANCEL-HANDLED" /tmp/reg73/tb/run.log || true)
n_after=$(grep -c "BACK-OPEN-SUB2\|BACK-OPEN-SUB" /tmp/reg73/tb/run.log || true)
n_destroyed=$(grep -c "BACK-DESTROYED" /tmp/reg73/tb/run.log || true)
[ $rc -ne 0 ] && fail "TestBack rc=$rc"
[ "$n_cancel" -lt 2 ] && fail "TestBack: expected >=2 handled cancels, got $n_cancel"
[ "$n_after" -lt 4 ] && fail "TestBack: app did not stay interactive after cancel ($n_after opens)"
[ "$n_destroyed" -ne 0 ] && fail "TestBack: destroyApp ran — cancel TERMINATED the app"

# ---------- 0c. NEW: TestAudio E2E — the whole pure-C audio pipeline ----------
note "0c) TestAudio E2E: WAV x6 formats + mixer + MIDI + tone, spectral checks"
rm -rf /tmp/reg73/ta; mkdir -p /tmp/reg73/ta
PACED=1 NOJME_LOG=1 NOJME_AUDIO_DUMP=/tmp/reg73/ta/dump.wav \
  timeout 180 ./bin/lr_run ./bin/nojme_libretro.so games/TestAudio.jar 800 /tmp/reg73/ta 0 > /tmp/reg73/ta/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestAudio lr_run rc=$rc"
grep -q "TA:DONE" /tmp/reg73/ta/run.log || fail "TestAudio: midlet did not complete"
python3 scripts/analyze_testaudio.py /tmp/reg73/ta/dump.wav > /tmp/reg73/ta/analysis.log 2>&1 || fail "TestAudio spectral analysis"
tail -1 /tmp/reg73/ta/analysis.log

# ---------- 0d. NEW: Makefile stale-.d self-heal ----------
note "0d) Makefile self-heal: pre-v34.69 C++ leftovers must be purged"
SELFT=/tmp/reg73/mkself
rm -rf "$SELFT"; mkdir -p "$SELFT/obj/libretro/amr"
cp Makefile "$SELFT/"
cp -r src "$SELFT/" 2>/dev/null
# v34.74 battery fix: tier-2 self-heal invokes scripts/stale_dep_check.sh
# relative to the make CWD — the temp tree must mirror the overlay layout.
mkdir -p "$SELFT/scripts"
cp scripts/stale_dep_check.sh "$SELFT/scripts/"
# plant BOTH stale forms: orphaned name (sp_dec.d) and same-name-as-C (amr_nb_dec.d)
printf 'obj/libretro/amr/amr_nb_dec.o: src/amr/amr_nb_dec.cpp include/amr_nb_dec.h\n' > "$SELFT/obj/libretro/amr/amr_nb_dec.d"
printf 'obj/libretro/amr/sp_dec.o: src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/sp_dec.cpp\n' > "$SELFT/obj/libretro/amr/sp_dec.d"
touch "$SELFT/obj/libretro/amr/amr_nb_dec.o" "$SELFT/obj/libretro/amr/sp_dec.o"
OUT=$( cd "$SELFT" && make platform=linux -n libretro 2>&1 )
echo "$OUT" | grep -q "No rule to make target" && fail "self-heal: make still aborts on stale .d"
[ -e "$SELFT/obj/libretro/amr/amr_nb_dec.d" ] && fail "self-heal: same-name stale .d survived"
[ -e "$SELFT/obj/libretro/amr/sp_dec.d" ] && fail "self-heal: orphaned stale .d survived"
echo "$OUT" | grep -q "tier 1" && echo "$OUT" | grep -q "tier 2" || fail "self-heal: no purge notes emitted"
note "self-heal: both tiers purged, make parses clean"

# ---------- 0e. NEW: TestRMS E2E — the JSR 118 spec suite ----------
note "0e) TestRMS E2E: 33 spec checks (enumeration peek, null data, authmode, getSize)"
rm -rf /tmp/reg74/trms; mkdir -p /tmp/reg74/trms
PACED=1 NOJME_LOG=1 timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestRMS.jar 200 /tmp/reg74/trms 0 > /tmp/reg74/trms/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestRMS lr_run rc=$rc"
grep -q "RMS:DONE 33/0" /tmp/reg74/trms/run.log || fail "TestRMS: $(grep -c ' FAIL ' /tmp/reg74/trms/run.log) failing checks"
note "TestRMS: $(grep 'RMS:DONE' /tmp/reg74/trms/run.log | tail -1 | sed 's/.*SYSOUT\] //')"

# ---------- 0f. NEW: TestAnim E2E — the JSR-184 animation suite ----------
note "0f) TestAnim E2E: 18 spec checks (weight, blending, controllers, validity)"
rm -rf /tmp/reg74/tanim; mkdir -p /tmp/reg74/tanim
PACED=1 NOJME_LOG=1 timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestAnim.jar 200 /tmp/reg74/tanim 0 > /tmp/reg74/tanim/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestAnim lr_run rc=$rc"
grep -q "ANIM:DONE 18/0" /tmp/reg74/tanim/run.log || fail "TestAnim: $(grep -c ' FAIL ' /tmp/reg74/tanim/run.log) failing checks"
note "TestAnim: $(grep 'ANIM:DONE' /tmp/reg74/tanim/run.log | tail -1 | sed 's/.*SYSOUT\] //')"

# ---------- 0g. NEW: frame limit — live j2me_fps switch pushes AV info ----------
note "0g) Frame limit: live j2me_fps 30->60 must push SET_SYSTEM_AV_INFO"
rm -rf /tmp/reg74/fps; mkdir -p /tmp/reg74/fps
LRVAR_j2me_fps=30 LRVAR_j2me_fps2=60 LR_FPS_SWITCH=100 PACED=1 \
  timeout 90 ./bin/lr_run ./bin/nojme_libretro.so games/TestBack.jar 250 /tmp/reg74/fps 0 > /tmp/reg74/fps/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "frame-limit lr_run rc=$rc"
grep -q "SET_SYSTEM_AV_INFO: fps=60.000" /tmp/reg74/fps/run.log || fail "frame limit: SET_SYSTEM_AV_INFO(60) not received by frontend"
grep -q "simulating j2me_fps option update" /tmp/reg74/fps/run.log || fail "frame limit: harness did not flip the option"
note "frame limit: 30->60 at frame 100, frontend accepted SET_SYSTEM_AV_INFO (fps=60, rate, geometry)"

# ---------- 1. headless smoke: games ----------
note "1) headless smoke (10 games, 30s cap each)"
GAMES=("3DFerrariExperience.jar" "Asphalt 3 3D (1.1.5).jar" "Assassin's Creed (1.1.0).jar" "Assassin's Creed 2 (1.0.1).jar" "BlackShark3D.jar" "Gish - Reloaded [Rus].jar" "Nescube_V_2.3.jar" "Quake Plus 3D (M3GWORKS)[a2].jar" "Treasure Towers (1.3)[128x160].jar" "fmx.jar")
for g in "${GAMES[@]}"; do
  rm -rf /tmp/reg73/rms; mkdir -p /tmp/reg73/rms
  NOJME_RMS_DIR=/tmp/reg73/rms NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=200 \
    timeout 30 ./bin/j2me-headless --headless "games/$g" > /tmp/reg73/"$g".log 2>&1
  rc=$?
  fatal=$(grep -c "FATAL\|SIGSEGV\|double free\|corrupt" /tmp/reg73/"$g".log || true)
  if [ $rc -eq 124 ] || [ $rc -eq 0 ]; then
    if [ "$fatal" -gt 0 ]; then fail "$g: fatal markers=$fatal (rc=$rc)"; else note "$g: OK (rc=$rc)"; fi
  else
    fail "$g: rc=$rc fatal=$fatal"
  fi
done

# ---------- 2. self-tests: SYSOUT vs stock v34.71 ----------
note "2) test49 + test58 (SYSOUT diff vs v34.71 stock)"
if [ -x "$AB_HEADLESS" ]; then
  for t in test49.jar test58.jar; do
    rm -rf /tmp/reg73/r1 /tmp/reg73/r2; mkdir -p /tmp/reg73/r1 /tmp/reg73/r2
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/r1 timeout 90 ./bin/j2me-headless --headless "games/$t" > /tmp/reg73/mine.log 2>&1
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/r2 timeout 90 "$AB_HEADLESS" --headless "games/$t" > /tmp/reg73/ab.log 2>&1
    if diff <(grep -E "SYSOUT|Loaded store" /tmp/reg73/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg73/ab.log) > /dev/null; then
      note "$t: IDENTICAL ($(grep -cE 'SYSOUT|Loaded store' /tmp/reg73/mine.log) lines)"
    else
      fail "$t: SYSOUT differs from v34.71"
      diff <(grep -E "SYSOUT|Loaded store" /tmp/reg73/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg73/ab.log) | head -6
    fi
  done
else
  note "2) skipped (no AB headless at $AB_HEADLESS)"
fi

# ---------- 3. Nescube ChoiceGroup E2E (pixel-exact checkbox toggle) ----------
note "3) Nescube ChoiceGroup E2E + RMS persistence"
rm -rf /tmp/reg73/rmsn /tmp/j2me_frame_*.ppm; mkdir -p /tmp/reg73/rmsn
NOJME_RMS_DIR=/tmp/reg73/rmsn NOJME_LOG=1 NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
  NOJME_HEADLESS_KEYSCRIPT="100:-5;500:-2;900:-5;1300:-5;2200:-5" \
  NOJME_HEADLESS_SNAP_FRAMES="2000,2600" \
  timeout 90 ./bin/j2me-headless --headless games/Nescube_V_2.3.jar > /tmp/reg73/nescube.log 2>&1
python3 - <<'EOF'
from PIL import Image, ImageChops
import sys, os
try:
    a = Image.open('/tmp/j2me_frame_02000.ppm').convert('RGB')
    b = Image.open('/tmp/j2me_frame_02600.ppm').convert('RGB')
    diff = ImageChops.difference(a, b)
    bbox = diff.getbbox()
    n = sum(1 for p in diff.getdata() if sum(p) > 30)
    print(f"[REG] Nescube FIRE diff bbox={bbox} pixels={n}")
    if bbox and bbox[0] < 20 and bbox[1] < 60 and n < 200:
        print("[REG] Nescube ChoiceGroup toggle: OK")
    else:
        print("[REG][FAIL] Nescube ChoiceGroup toggle unexpected diff")
        sys.exit(1)
    rms_dir = '/tmp/reg73/rmsn/Nescube_V_2.3'
    files = [f for f in os.listdir(rms_dir) if f.endswith('.rms')] if os.path.isdir(rms_dir) else []
    print(f"[REG] Nescube RMS stores on disk: {files}")
    if not files:
        print("[REG][FAIL] no RMS store persisted")
        sys.exit(1)
except Exception as e:
    print("[REG][FAIL] Nescube E2E:", e)
    sys.exit(1)
EOF
[ $? -ne 0 ] && fail "Nescube E2E"

# ---------- 4. Asphalt 3 3D lr_run + FRAME_DIFF (thread sanity) ----------
note "4) Asphalt lr_run 900 frames, FRAME_DIFF (PACED)"
rm -rf /tmp/reg73/asph; mkdir -p /tmp/reg73/asph
PACED=1 FRAME_DIFF=1 timeout 150 ./bin/lr_run ./bin/nojme_libretro.so "games/Asphalt 3 3D (1.1.5).jar" 900 /tmp/reg73/asph 0 > /tmp/reg73/asph/run.log 2>&1
rc=$?
ok=$(grep -c "CAUGHT SIGNAL\|FATAL" /tmp/reg73/asph/run.log || true)
note "Asphalt: rc=$rc crash-markers=$ok $(grep FRAMEDIFF /tmp/reg73/asph/run.log | head -1)"
[ $rc -ne 0 ] && fail "Asphalt lr_run rc=$rc"
[ "$ok" -gt 0 ] && fail "Asphalt crash markers"

# ---------- 5. fmx A/B vs stock (thread interaction parity) ----------
if [ -x "$AB_HEADLESS" ]; then
  note "5) fmx A/B instructions (mine vs v34.71 stock, clean RMS each)"
  for tag in mine ab; do
    rm -rf /tmp/reg73/rmsf; mkdir -p /tmp/reg73/rmsf
    if [ "$tag" = "mine" ]; then BIN=./bin/j2me-headless; else BIN="$AB_HEADLESS"; fi
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/rmsf NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
      timeout 150 $BIN --headless games/fmx.jar > /tmp/reg73/fmx_$tag.log 2>&1
    grep -oE "instructions=[0-9]+" /tmp/reg73/fmx_$tag.log | tail -1 | sed "s/^/[$tag] /"
  done
else
  note "5) skipped (no AB headless at $AB_HEADLESS)"
fi

# ---------- 6. gc_stress (heap churn + concurrency) ----------
note "6) gc_stress"
gcc -O2 -std=c11 -Iinclude -Isrc -Isrc/include -DJ2ME_DEBUG=0 \
    scripts/gc_stress.c src/jvm/heap.c -lm -pthread -o /tmp/reg73/gc_stress 2> /tmp/reg73/gc_stress_build.log
timeout 300 /tmp/reg73/gc_stress > /tmp/reg73/gc_stress.log 2>&1
rc=$?
note "gc_stress: rc=$rc $(tail -2 /tmp/reg73/gc_stress.log | head -1)"
[ $rc -ne 0 ] && fail "gc_stress rc=$rc"
grep -q "corrupt" /tmp/reg73/gc_stress.log && fail "gc_stress: corruption markers"

# ---------- 7. AMR selfcheck (C decoder bit-exactness) ----------
note "7) AMR selfcheck (C decoder from the packaged tree)"
bash scripts/amr_selfcheck.sh > /tmp/reg73/amr.log 2>&1
rc=$?
tail -3 /tmp/reg73/amr.log
[ $rc -ne 0 ] && fail "amr_selfcheck rc=$rc"

# ---------- 8. corrupted-magic sweep over the whole battery ----------
note "8) corrupted-magic sweep (/tmp/reg73)"
n_magic=$(grep -rc "CORRUPTION_MAGIC\|CORRUPTION_FATAL\|corrupted magic" /tmp/reg73/*.log 2>/dev/null | awk -F: '{s+=$2} END {print s+0}')
note "corruption markers across battery logs: $n_magic"
[ "$n_magic" -ne 0 ] && fail "corrupted-magic markers present"

echo "[REG] === battery result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
