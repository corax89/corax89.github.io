#!/usr/bin/env python3
"""Determine the SkinnedMesh vertex space (bind-world vs bone-local) and the
correct encoding==1 decode formula for 3D Solid Weapon N_2.m3g:
 1. Build skeleton hierarchy + bind world matrices (angle/axis + translation).
 2. Decode ORIENTATION kf0 both as u/255 (unsigned) and s/127 (signed),
    compare to each bone's bind orientation quaternion.
 3. For each bone binding, compare the centroid of its vertex range with the
    bone's bind world position.
"""
import struct, sys, math
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_hexdump import sections_of, objects_of

class R:
    def __init__(self, b, p=0):
        self.b = b; self.p = p
    def u8(self):
        v = self.b[self.p]; self.p += 1; return v
    def u16(self):
        v = struct.unpack('<H', self.b[self.p:self.p+2])[0]; self.p += 2; return v
    def i16(self):
        v = struct.unpack('<h', self.b[self.p:self.p+2])[0]; self.p += 2; return v
    def u32(self):
        v = struct.unpack('<I', self.b[self.p:self.p+4])[0]; self.p += 4; return v
    def f32(self):
        v = struct.unpack('<f', self.b[self.p:self.p+4])[0]; self.p += 4; return v
    def f32n(self, n):
        return [self.f32() for _ in range(n)]

TYPE = {0:'HEADER',1:'ANIMCONTROLLER',2:'ANIMTRACK',3:'APPEARANCE',4:'BACKGROUND',
        5:'CAMERA',6:'COMPOSITINGMODE',7:'FOG',8:'POLYGONMODE',9:'GROUP',10:'IMAGE2D',
        11:'TRIANGLESTRIPARRAY',12:'LIGHT',13:'MATERIAL',14:'MESH',15:'MORPHINGMESH',
        16:'SKINNEDMESH',17:'TEXTURE2D',18:'SPRITE3D',19:'KEYFRAMESEQ',20:'VERTEXARRAY',
        21:'VERTEXBUFFER',22:'WORLD',255:'EXTERNALREF'}

# ---------- matrix helpers (row-major 4x4 lists) ----------
def mat_identity():
    m = [[0.0]*4 for _ in range(4)]
    for i in range(4): m[i][i] = 1.0
    return m

def mat_mul(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]

def axis_angle_to_mat(angle_deg, ax, ay, az):
    n = math.sqrt(ax*ax+ay*ay+az*az)
    if n < 1e-9: return mat_identity()
    ax, ay, az = ax/n, ay/n, az/n
    a = math.radians(angle_deg)
    c, s = math.cos(a), math.sin(a)
    t = 1-c
    return [
        [t*ax*ax+c,    t*ax*ay-s*az, t*ax*az+s*ay, 0],
        [t*ax*ay+s*az, t*ay*ay+c,    t*ay*az-s*ax, 0],
        [t*ax*az-s*ay, t*ay*az+s*ax, t*az*az+c,    0],
        [0,0,0,1]]

def scale_mat(sx, sy, sz):
    return [[sx,0,0,0],[0,sy,0,0],[0,0,sz,0],[0,0,0,1]]

def trans_mat(tx, ty, tz):
    m = mat_identity()
    m[0][3], m[1][3], m[2][3] = tx, ty, tz
    return m

def mat_to_pos(m):
    return (m[0][3], m[1][3], m[2][3])

def axis_angle_to_quat(angle_deg, ax, ay, az):
    n = math.sqrt(ax*ax+ay*ay+az*az)
    if n < 1e-9: return (0.0,0.0,0.0,1.0)
    a = math.radians(angle_deg)/2
    s = math.sin(a)
    return (ax/n*s, ay/n*s, az/n*s, math.cos(a))

def quat_to_axis_angle(q):
    x,y,z,w = q
    n = math.sqrt(x*x+y*y+z*z+w*w)
    if n < 1e-9: return (0.0,0.0,1.0,0.0)
    x,y,z,w = x/n,y/n,z/n,w/n
    if w < 0: x,y,z,w = -x,-y,-z,-w   # shortest arc
    sin2 = math.sqrt(x*x+y*y+z*z)
    if sin2 < 1e-9: return (0.0,0.0,1.0,0.0)
    ang = 2*math.degrees(math.acos(min(1.0,w)))
    return (ang, x/sin2, y/sin2, z/sin2)

def quat_dist(q1, q2):
    d = abs(q1[0]*q2[0]+q1[1]*q2[1]+q1[2]*q2[2]+q1[3]*q2[3])
    d = min(1.0, d)
    return 2*math.degrees(math.acos(d))  # angular distance

def parse(path):
    objs = objects_of(sections_of(path))
    parsed = []
    for t, body in objs:
        r = R(body)
        info = {'type': t, 'typename': TYPE.get(t, str(t))}
        if t in (0, 255):
            parsed.append(info); continue
        info['uid'] = r.u32()
        n = r.u32()
        info['tracks'] = [r.u32() for _ in range(n)]
        n = r.u32()
        for _ in range(n):
            r.u32(); ln = r.u32(); r.p += ln
        if t in (14,15,16,9,22,5,12,18):
            if r.u8():
                info['t'] = tuple(r.f32n(3))
                info['s'] = tuple(r.f32n(3))
                info['o'] = tuple(r.f32n(4))   # angle, ax, ay, az
            if r.u8():
                info['g'] = r.f32n(16)
            info['ren'] = r.u8(); info['pick'] = r.u8()
            info['alpha'] = r.u8(); info['scope'] = r.u32()
            if r.u8():
                r.u8(); r.u8(); r.u32(); r.u32()
        if t == 9 or t == 22:
            cc = r.u32()
            info['children'] = [r.u32() for _ in range(cc)]
        elif t == 16:
            info['vb_ref'] = r.u32()
            info['submeshes'] = [(r.u32(), r.u32()) for _ in range(r.u32())]
            info['skeleton_ref'] = r.u32()
            nb = r.u32()
            info['bones'] = [(r.u32(), r.u32(), r.u32(), r.u32()) for _ in range(nb)]
        elif t == 2:
            info['seq_ref'] = r.u32(); info['ctrl_ref'] = r.u32(); info['property'] = r.u32()
        elif t == 21:
            r.u8(); r.u8(); r.u8(); r.u8()
            info['pos_ref'] = r.u32(); info['bias'] = r.f32n(3); info['scale'] = r.f32()
        elif t == 19:
            info['interp'] = r.u8(); info['repeat'] = r.u8(); info['enc'] = r.u8()
            info['dur'] = r.u32(); info['vrF'] = r.u32(); info['vrL'] = r.u32()
            info['comp'] = r.u32()
            cc = info['comp']
            info['kfCount'] = r.u32()
            kfs = []
            if info['enc'] == 1:
                info['bias'] = r.f32n(cc)
                info['scale'] = r.f32n(cc)
                for _ in range(info['kfCount']):
                    tm = r.u32()
                    vals = list(r.b[r.p:r.p+cc]); r.p += cc
                    kfs.append((tm, vals))
            info['kfs'] = kfs
        parsed.append(info)
    return parsed, objs

def decode_kf(kf, bias, scale, mode):
    out = []
    for c, v in enumerate(kf):
        if mode == 'u255':
            out.append(bias[c] + scale[c]*(v/255.0))
        else:  # s127: signed byte
            sv = v-256 if v > 127 else v
            out.append(bias[c] + scale[c]*(sv/127.0))
    return out

def main(path):
    parsed, objs = parse(path)
    n = len(parsed)
    def obj(i):  # 1-based file ref -> parsed entry
        return parsed[i-1] if 0 < i <= n else None

    # ---- collect skeleton nodes (Groups) ----
    groups = {i+1: o for i, o in enumerate(parsed) if o['typename'] == 'GROUP'}
    sm = next(o for o in parsed if o['typename'] == 'SKINNEDMESH')
    print('SkinnedMesh: skel#%d vb#%d bones=%d' % (sm['skeleton_ref'], sm['vb_ref'], len(sm['bones'])))

    # bind local matrices for every group
    local = {}
    for idx, g in groups.items():
        if 'g' in g:
            m = [[g['g'][r*4+c] for c in range(4)] for r in range(4)]
        else:
            t = g.get('t', (0,0,0)); s = g.get('s', (1,1,1)); o = g.get('o', (0,0,0,1))
            m = mat_mul(trans_mat(*t), mat_mul(scale_mat(*s), axis_angle_to_mat(o[0], o[1], o[2], o[3])))
        local[idx] = m

    # build world matrices from roots (groups not appearing as a child)
    children_map = {}
    is_child = set()
    for idx, g in groups.items():
        for c in g.get('children', []):
            children_map.setdefault(idx, []).append(c)
            is_child.add(c)
    roots = [i for i in groups if i not in is_child]
    world = {}
    stack = [(r, mat_identity()) for r in roots]
    while stack:
        idx, pm = stack.pop()
        wm = mat_mul(pm, local[idx])
        world[idx] = wm
        for c in children_map.get(idx, []):
            if c in groups:
                stack.append((c, wm))
    print('groups=%d roots=%s covered=%d' % (len(groups), roots, len(world)))

    # ---- animations: map track property -> group, decode kf0 ----
    tr_by_file = {i+1: o for i, o in enumerate(parsed) if o['typename'] == 'ANIMTRACK'}
    PROP = {256:'SCALE',268:'ORIENTATION',275:'TRANSLATION'}
    orient_kf0 = {}   # group file# -> (mode -> quat)
    transl_kf0 = {}
    for gi, g in groups.items():
        for tr_ref in g.get('tracks', []):
            tr = obj(tr_ref) if tr_ref else None
            if not tr or tr['typename'] != 'ANIMTRACK': continue
            seq = obj(tr['seq_ref'])
            if not seq or seq['typename'] != 'KEYFRAMESEQ': continue
            if not seq['kfs']: continue
            prop = tr['property']
            if prop == 268 and seq['comp'] == 4:
                orient_kf0[gi] = {m: decode_kf(seq['kfs'][0][1], seq['bias'], seq['scale'], m)
                                   for m in ('u255','s127')}
            elif prop == 275 and seq['comp'] == 3:
                transl_kf0[gi] = {m: decode_kf(seq['kfs'][0][1], seq['bias'], seq['scale'], m)
                                   for m in ('u255','s127')}

    # ---- compare bind orientation vs kf0 (both modes) ----
    print('\n=== ORIENTATION kf0 vs bind (angle dist deg) ===')
    tot = {'u255':0.0,'s127':0.0}; cnt = 0
    for gi, modes in sorted(orient_kf0.items()):
        g = groups[gi]
        if 'o' not in g: continue
        bind_q = axis_angle_to_quat(*g['o'])
        d = {m: quat_dist(tuple(modes[m]), bind_q) for m in ('u255','s127')}
        tot['u255'] += d['u255']; tot['s127'] += d['s127']; cnt += 1
        if cnt <= 12 or gi in list(sorted(orient_kf0))[:0]:
            print('  grp#%d uid=%s bind_o=(%.0f,%.2f,%.2f,%.2f) u255=%.1f s127=%.1f' % (
                gi, g.get('uid'), g['o'][0], g['o'][1], g['o'][2], g['o'][3], d['u255'], d['s127']))
    if cnt:
        print('  MEAN over %d bones: u255=%.2f deg  s127=%.2f deg' % (cnt, tot['u255']/cnt, tot['s127']/cnt))

    print('\n=== TRANSLATION kf0 vs bind (dist) ===')
    tot = {'u255':0.0,'s127':0.0}; cnt = 0
    for gi, modes in sorted(transl_kf0.items()):
        g = groups[gi]
        bt = g.get('t', (0,0,0))
        d = {}
        for m in ('u255','s127'):
            v = modes[m]
            d[m] = math.sqrt(sum((v[i]-bt[i])**2 for i in range(3)))
        tot['u255'] += d['u255']; tot['s127'] += d['s127']; cnt += 1
        if cnt <= 12:
            print('  grp#%d bind_t=(%.2f,%.2f,%.2f) u255=(%.2f,%.2f,%.2f) d=%.3f | s127=(%.2f,%.2f,%.2f) d=%.3f' % (
                gi, *bt, *modes['u255'], d['u255'], *modes['s127'], d['s127']))
    if cnt:
        print('  MEAN over %d: u255=%.3f  s127=%.3f' % (cnt, tot['u255']/cnt, tot['s127']/cnt))

    # ---- vertices ----
    vb = obj(sm['vb_ref'])
    va = obj(vb['pos_ref'])
    t, body = objs[vb['pos_ref']-1]
    r = R(body)
    r.p += 4
    ntc = r.u32()
    for _ in range(ntc): r.u32()
    nuo = r.u32()
    for _ in range(nuo): r.u32(); ln = r.u32(); r.p += ln
    cs = r.u8(); cc = r.u8(); enc = r.u8(); vc = r.u16()
    raw = [struct.unpack('<b', body[r.p + (v*cc+c):r.p + (v*cc+c)+1])[0] for v in range(vc) for c in range(cc)]
    # core dialect: value = bias + scale * (i8 / 127)
    verts = []
    for v in range(vc):
        verts.append(tuple(vb["bias"][c] + vb["scale"]*raw[v*3+c] for c in range(3)))
    print('\nverts=%d enc=%d compSize=%d bias=%s scale=%.4f' % (
        vc, enc, cs, ['%.2f'%b for b in vb['bias']], vb['scale']))
    allc = [sum(p[c] for p in verts)/vc for c in range(3)]
    print('vertex global centroid: (%.2f, %.2f, %.2f)' % tuple(allc))

    # ---- binding analysis: centroid vs bone world pos ----
    print('\n=== BINDINGS: vertex-range centroid vs bone bind world pos ===')
    shown = 0; near_w = near_0 = other = 0
    for bi, (bref, first, cnt, wgt) in enumerate(sm['bones']):
        if bref not in world or first >= vc or cnt <= 0: continue
        sub = verts[first:first+min(cnt, vc-first)]
        c = [sum(p[k] for p in sub)/len(sub) for k in range(3)]
        bp = mat_to_pos(world[bref])
        dw = math.sqrt(sum((c[k]-bp[k])**2 for k in range(3)))
        d0 = math.sqrt(sum(x*x for x in c))
        if dw < d0: near_w += 1
        else: near_0 += 1
        if shown < 15 and bi % max(1, len(sm['bones'])//15) == 0:
            print('  bone[%d] grp#%d range=[%d..%d) w=%d centroid=(%.1f,%.1f,%.1f) bonepos=(%.1f,%.1f,%.1f) d_bone=%.1f d_origin=%.1f' % (
                bi, bref, first, first+cnt, wgt, *c, *bp, dw, d0))
        shown += 1
    print('ranges closer to BONE world pos: %d; closer to ORIGIN: %d (of %d)' % (near_w, near_0, shown))

if __name__ == '__main__':
    main(sys.argv[1])
