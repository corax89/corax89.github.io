#!/bin/bash
# v34.51 verification: pink-underlay fix + SSE2 A/B against v34.50.
# For each game: run OLD (v34.50) and NEW (v34.51) headless with identical
# key sequences, grab identical snapshot frames, count magenta pixels
# (color-key leak detector), and diff the frames.
cd /home/z/my-project/j2me-analysis
OLD=/tmp/v50/nojme-j2me/bin/linux/j2me-headless
NEW=./bin/j2me-headless
OUT=work/pink51/ab
mkdir -p $OUT

run_one() { # $1=tag $2=jar $3=keys $4=every $5=maxms $6=frames
    local TAG=$1 JAR=$2 KEYS=$3 EVERY=$4 MAXMS=$5 FRAMES=$6
    for VER in old new; do
        BIN=$OLD; [ $VER = new ] && BIN=$NEW
        rm -f /tmp/j2me_frame_*.ppm
        NOJME_HEADLESS_MAX_MS=$MAXMS \
        NOJME_HEADLESS_KEYSEQ="$KEYS" \
        NOJME_HEADLESS_KEYSEQ_EVERY=$EVERY \
        NOJME_HEADLESS_SNAP_FRAMES="$FRAMES" \
        $BIN "$JAR" > $OUT/${TAG}_$VER.log 2>&1
        for f in /tmp/j2me_frame_*.ppm; do
            [ -f "$f" ] || continue
            n=$(basename "$f" .ppm | sed 's/j2me_frame_//')
            cp "$f" $OUT/${TAG}_${VER}_f${n}.ppm
        done
    done
    # magenta count + frame compare
    python3 - "$OUT" "$TAG" <<'EOF'
import sys, os, glob
outdir, tag = sys.argv[1], sys.argv[2]
def load(p):
    with open(p,'rb') as f:
        assert f.readline().strip()==b'P6'
        while True:
            l=f.readline()
            if not l.startswith(b'#'): break
        w,h=map(int,l.split()); f.readline()
        return f.read(), w, h
def magenta(data):
    n=0
    for i in range(0,len(data),3):
        r,g,b=data[i],data[i+1],data[i+2]
        if r>230 and g<80 and b>230: n+=1
    return n
olds=sorted(glob.glob(f"{outdir}/{tag}_old_f*.ppm"))
tot_m_old=tot_m_new=0; ident=0; diffs=[]
for o in olds:
    n=o.split('_f')[-1][:-4]
    nw=f"{outdir}/{tag}_new_f{n}.ppm"
    if not os.path.exists(nw): continue
    do,_,_=load(o); dn,_,_=load(nw)
    mo, mn = magenta(do), magenta(dn)
    tot_m_old+=mo; tot_m_new+=mn
    if do==dn: ident+=1
    else: diffs.append((n,mo,mn))
print(f"[{tag}] frames={len(olds)} identical={ident} magenta_old={tot_m_old} magenta_new={tot_m_new}")
for n,mo,mn in diffs:
    print(f"    frame {n}: magenta {mo} -> {mn}")
EOF
}

# 3D race with throttle held
run_one asph "Asphalt 3 3D (1.1.5).jar" "5,-5" 200 40000 1200,3000,6000
# 2D platformers (menus + first scenes)
run_one ac2 "Assassin's Creed 2 (1.0.1).jar" "" 0 20000 200,500,1000
run_one ac1 "Assassin's Creed (1.1.0).jar" "" 0 20000 200,500,1000
# 3D misc
run_one quake "Quake Plus 3D (M3GWORKS)[a2].jar" "" 0 20000 200,500,1000
run_one bs "BlackShark3D.jar" "" 0 20000 200,500,1000
run_one fmx "fmx.jar" "" 0 20000 200,500,1000
run_one ferr "work/pink51/ferrari/3DFerrariExperience (1).jar" "" 0 20000 200,500,1000
echo "=== done ==="
