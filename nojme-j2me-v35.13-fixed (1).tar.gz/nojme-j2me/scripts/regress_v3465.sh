#!/bin/bash
# v34.65 regression battery — runs against the freshly built tree in the CWD.
# Usage: bash scripts/regress_v3465.sh
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS=/tmp/v3461/nojme-j2me/bin/j2me-headless

# ---------- 1. headless smoke: games ----------
note "1) headless smoke (10 games, 30s cap each)"
GAMES=("3DFerrariExperience.jar" "Asphalt 3 3D (1.1.5).jar" "Assassin's Creed (1.1.0).jar" "Assassin's Creed 2 (1.0.1).jar" "BlackShark3D.jar" "Gish - Reloaded [Rus].jar" "Nescube_V_2.3.jar" "Quake Plus 3D (M3GWORKS)[a2].jar" "Treasure Towers (1.3)[128x160].jar" "fmx.jar")
mkdir -p /tmp/reg65; rm -f /tmp/reg65/*.log
for g in "${GAMES[@]}"; do
  rm -rf /tmp/reg65/rms; mkdir -p /tmp/reg65/rms
  NOJME_RMS_DIR=/tmp/reg65/rms NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=200 \
    timeout 30 ./bin/j2me-headless --headless "games/$g" > /tmp/reg65/"$g".log 2>&1
  rc=$?
  fatal=$(grep -c "FATAL\|SIGSEGV\|double free\|corrupt" /tmp/reg65/"$g".log || true)
  if [ $rc -eq 124 ] || [ $rc -eq 0 ]; then
    if [ "$fatal" -gt 0 ]; then fail "$g: fatal markers=$fatal (rc=$rc)"; else note "$g: OK (rc=$rc)"; fi
  else
    fail "$g: rc=$rc fatal=$fatal"
  fi
done

# ---------- 2. self-tests: byte-identical SYSOUT vs stock v34.61 ----------
note "2) test49 + test58 (SYSOUT diff vs v34.61 stock)"
for t in test49.jar test58.jar; do
  rm -rf /tmp/reg65/r1 /tmp/reg65/r2; mkdir -p /tmp/reg65/r1 /tmp/reg65/r2
  NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg65/r1 timeout 90 ./bin/j2me-headless --headless "games/$t" > /tmp/reg65/mine.log 2>&1
  NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg65/r2 timeout 90 "$AB_HEADLESS" --headless "games/$t" > /tmp/reg65/ab.log 2>&1
  if diff <(grep -E "SYSOUT|Loaded store" /tmp/reg65/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg65/ab.log) > /dev/null; then
    note "$t: IDENTICAL ($(grep -cE 'SYSOUT|Loaded store' /tmp/reg65/mine.log) lines)"
  else
    fail "$t: SYSOUT differs from v34.61"
    diff <(grep -E "SYSOUT|Loaded store" /tmp/reg65/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg65/ab.log) | head -6
  fi
done

# ---------- 3. Nescube ChoiceGroup E2E (pixel-exact checkbox toggle) ----------
note "3) Nescube ChoiceGroup E2E + RMS persistence"
rm -rf /tmp/reg65/rmsn /tmp/j2me_frame_*.ppm; mkdir -p /tmp/reg65/rmsn
NOJME_RMS_DIR=/tmp/reg65/rmsn NOJME_LOG=1 NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
  NOJME_HEADLESS_KEYSCRIPT="100:-5;500:-2;900:-5;1300:-5;2200:-5" \
  NOJME_HEADLESS_SNAP_FRAMES="2000,2600" \
  timeout 90 ./bin/j2me-headless --headless games/Nescube_V_2.3.jar > /tmp/reg65/nescube.log 2>&1
python3 - <<'EOF'
from PIL import Image, ImageChops
import sys, os
try:
    a = Image.open('/tmp/j2me_frame_02000.ppm').convert('RGB')
    b = Image.open('/tmp/j2me_frame_02600.ppm').convert('RGB')
    diff = ImageChops.difference(a, b)
    bbox = diff.getbbox()
    n = sum(1 for p in diff.getdata() if sum(p) > 30)
    print(f"[REG] Nescube FIRE diff bbox={bbox} pixels={n}")
    if bbox and bbox[0] < 20 and bbox[1] < 60 and n < 200:
        print("[REG] Nescube ChoiceGroup toggle: OK")
    else:
        print("[REG][FAIL] Nescube ChoiceGroup toggle unexpected diff")
        sys.exit(1)
    # RMS store must exist after the settings change (real-game E2E
    # persistence — replaces the lost make_test_rms.py harness)
    rms_dir = '/tmp/reg65/rmsn/Nescube_V_2.3'
    files = [f for f in os.listdir(rms_dir) if f.endswith('.rms')] if os.path.isdir(rms_dir) else []
    print(f"[REG] Nescube RMS stores on disk: {files}")
    if not files:
        print("[REG][FAIL] no RMS store persisted")
        sys.exit(1)
except Exception as e:
    print("[REG][FAIL] Nescube E2E:", e)
    sys.exit(1)
EOF
[ $? -ne 0 ] && fail "Nescube E2E"

# ---------- 4. Asphalt 3 3D lr_run + FRAME_DIFF (thread sanity) ----------
note "4) Asphalt lr_run 900 frames, FRAME_DIFF (PACED)"
rm -rf /tmp/reg65/asph; mkdir -p /tmp/reg65/asph
PACED=1 FRAME_DIFF=1 timeout 150 ./bin/lr_run ./bin/nojme_libretro.so "games/Asphalt 3 3D (1.1.5).jar" 900 /tmp/reg65/asph 0 > /tmp/reg65/asph/run.log 2>&1
rc=$?
ok=$(grep -c "CAUGHT SIGNAL\|FATAL" /tmp/reg65/asph/run.log || true)
note "Asphalt: rc=$rc crash-markers=$ok $(grep FRAMEDIFF /tmp/reg65/asph/run.log | head -1)"
[ $rc -ne 0 ] && fail "Asphalt lr_run rc=$rc"
[ "$ok" -gt 0 ] && fail "Asphalt crash markers"

# ---------- 5. fmx A/B vs stock v34.61 (thread interaction parity) ----------
if [ -x "$AB_HEADLESS" ]; then
  note "5) fmx A/B instructions (mine vs v34.61 stock, clean RMS each)"
  for tag in mine ab; do
    rm -rf /tmp/reg65/rmsf; mkdir -p /tmp/reg65/rmsf
    if [ "$tag" = "mine" ]; then BIN=./bin/j2me-headless; else BIN="$AB_HEADLESS"; fi
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg65/rmsf NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
      timeout 150 $BIN --headless games/fmx.jar > /tmp/reg65/fmx_$tag.log 2>&1
    grep -oE "instructions=[0-9]+" /tmp/reg65/fmx_$tag.log | tail -1 | sed "s/^/[$tag] /"
  done
else
  note "5) skipped (no AB headless at $AB_HEADLESS)"
fi

echo "[REG] === battery result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
