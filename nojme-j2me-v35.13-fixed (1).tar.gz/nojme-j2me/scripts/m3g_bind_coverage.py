#!/usr/bin/env python3
"""Check SkinnedMesh binding coverage: which vertices have no binding."""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_skin_space import parse

for path in sys.argv[1:]:
    parsed, objs = parse(path)
    sm = next(o for o in parsed if o['typename'] == 'SKINNEDMESH')
    vb = next(o for o in parsed if o['typename'] == 'VERTEXBUFFER')
    t, body = objs[vb['pos_ref'] - 1]
    p = 4
    ntc = struct.unpack('<I', body[p:p+4])[0]; p += 4
    p += 4 * ntc
    nuo = struct.unpack('<I', body[p:p+4])[0]; p += 4
    for _ in range(nuo):
        p += 4; ln = struct.unpack('<I', body[p:p+4])[0]; p += 4 + ln
    cs = body[p]; cc = body[p+1]; enc = body[p+2]
    vc = struct.unpack('<H', body[p+3:p+5])[0]
    covered = [0] * vc
    for (bref, first, cnt, w) in sm['bones']:
        for v in range(first, min(first + cnt, vc)):
            covered[v] += 1
    unc = [i for i, c in enumerate(covered) if c == 0]
    multi = sum(1 for c in covered if c > 1)
    print('%s: verts=%d bindings=%d uncovered=%d %s multicover=%d' % (
        path.split('/')[-1], vc, len(sm['bones']), len(unc), unc[:24], multi))
    rs = sorted((f, f+c, b, w) for (b, f, c, w) in sm['bones'])
    print('  first ranges:', rs[:4])
    print('  last ranges:  ', rs[-4:])
