import javax.microedition.midlet.MIDlet;

/* v34.84 selftest: worst-case shutdown. One thread parked in a LONG
 * Thread.sleep (10 s = the emulator cap), one in untimed Object.wait().
 * Before the fix retro_deinit waited the full 3 s timeout and leaked;
 * after: both abort within one sleep chunk (~50 ms / 250 ms). */
public class TestShut extends MIDlet {
    Object monitor = new Object();
    Thread sleeper;
    Thread waiter;
    boolean started;

    public void startApp() {
        if (started) return;
        started = true;
        sleeper = new Thread(new Runnable() {
            public void run() {
                try { Thread.sleep(10000L); }
                catch (InterruptedException e) {}
            }
        });
        waiter = new Thread(new Runnable() {
            public void run() {
                synchronized (monitor) {
                    try { monitor.wait(); }
                    catch (InterruptedException e) {}
                }
            }
        });
        sleeper.start();
        waiter.start();
        System.out.println("TS:STARTED");
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
