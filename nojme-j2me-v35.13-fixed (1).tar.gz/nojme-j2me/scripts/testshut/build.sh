#!/bin/bash
# Build TestShut.jar — the v34.81 frontend-pause selftest midlet.
# Requires: JRE (java) + ECJ (ecj.jar).
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestShut.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestShut\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/TestShut.class" "$OUT/pkg/" "$OUT/TestShut\$1.class" "$OUT/pkg/" 2>/dev/null || cp "$OUT/TestShut.class" "$OUT/pkg/"
( cd "$OUT/pkg" && zip -q -r "$D/TestShut.jar" META-INF TestShut.class 'TestShut$1.class' 2>/dev/null || zip -q -r "$D/TestShut.jar" META-INF TestShut.class )
echo "built: $D/TestShut.jar"
