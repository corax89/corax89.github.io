#!/usr/bin/env python3
"""Generate switch/icon.jpg — 256x256 NRO icon: dark blue tile with a
stylized phone silhouette + 'J2ME' caption drawn with PIL.
Run: python3 scripts/switch_icon.py
"""
import os
from PIL import Image, ImageDraw, ImageFont

W = H = 256
img = Image.new("RGB", (W, H), (16, 19, 30))
d = ImageDraw.Draw(img)

# soft rounded background
d.rounded_rectangle([8, 8, W - 8, H - 8], radius=28, fill=(22, 27, 46),
                    outline=(46, 124, 246), width=4)

# phone body
d.rounded_rectangle([88, 56, 168, 200], radius=14, fill=(232, 236, 244),
                    outline=(30, 34, 48), width=3)
# screen
d.rectangle([98, 76, 158, 168], fill=(46, 124, 246))
# speaker + home key
d.rounded_rectangle([116, 62, 140, 68], radius=3, fill=(120, 126, 140))
d.ellipse([120, 176, 136, 192], fill=(120, 126, 140))
# keypad dots
for row in range(3):
    for col in range(3):
        cx = 105 + col * 23
        cy = 186 + row * 4  # not used; keypad below screen instead
# simple keypad bars under screen? keep minimal: skip

# caption
try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
except Exception:
    font = ImageFont.load_default()
d.text((W // 2, 218), "J2ME", font=font, fill=(46, 124, 246), anchor="mm")

out = os.path.join(os.path.dirname(__file__), "..", "switch", "icon.jpg")
os.makedirs(os.path.dirname(out), exist_ok=True)
img.save(out, "JPEG", quality=90)
print("wrote", os.path.normpath(out))
