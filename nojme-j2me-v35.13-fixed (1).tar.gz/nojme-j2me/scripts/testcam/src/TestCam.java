import javax.microedition.midlet.*;
import javax.microedition.m3g.*;

/* Deterministic reproduction of the Stalker (Qplaze) camera pattern:
 * JSR-184 spec: postRotate/preRotate multiply the ORIENTATION COMPONENT,
 * setOrientation/setTranslation set components absolutely. Composite =
 * T * R * S * M. Per-frame repetition must therefore be STABLE.
 *
 * Prints matrix elements as (value*1000) integers, 8 per line.
 */
public class TestCam extends MIDlet {

    private static String tag;

    private static void p(String s) {
        System.out.println(s);
    }

    private static void dump(Transform t, String name) {
        float[] m = new float[16];
        t.get(m);
        p(name + " " + i(m[0]) + "," + i(m[1]) + "," + i(m[2]) + "," + i(m[3])
              + " " + i(m[4]) + "," + i(m[5]) + "," + i(m[6]) + "," + i(m[7]));
        p(name + " " + i(m[8]) + "," + i(m[9]) + "," + i(m[10]) + "," + i(m[11])
              + " " + i(m[12]) + "," + i(m[13]) + "," + i(m[14]) + "," + i(m[15]));
    }

    private static int i(float f) {
        return (int)(f * 1000.0f);
    }

    private static void pErr(String s) { p("ERR " + s); }

    public void startApp() {
        /* T1: Stalker gameplay camera — setTranslation + setOrientation +
         * postRotate, repeated (the per-frame sequence). SPEC: composite
         * constant = T(10,20,30) * Ry(90) * Rx(30) every iteration. */
        {
            Camera c = new Camera();
            Transform t = new Transform();
            for (int k = 1; k <= 5; k++) {
                c.setTranslation(10f, 20f, 30f);
                c.setOrientation(90f, 0f, 1f, 0f);
                c.postRotate(30f, 1f, 0f, 0f);
                c.getCompositeTransform(t);
                dump(t, "T1#" + k);
            }
        }

        /* T2: Stalker shake path — setOrientation(0) + preRotate(X) +
         * preRotate(Y), repeated. SPEC: composite = Ry(90)*Rx(30) const. */
        {
            Camera c = new Camera();
            Transform t = new Transform();
            for (int k = 1; k <= 4; k++) {
                c.setOrientation(0f, 0f, 0f, 0f);
                c.preRotate(30f, 1f, 0f, 0f);
                c.preRotate(90f, 0f, 1f, 0f);
                c.getCompositeTransform(t);
                dump(t, "T2#" + k);
            }
        }

        /* T3: getOrientation after setOrientation+postRotate — must
         * decompose the EFFECTIVE orientation R = Ry(90)*Rx(30). */
        {
            Camera c = new Camera();
            float[] oa = new float[4];
            c.setOrientation(90f, 0f, 1f, 0f);
            c.postRotate(30f, 1f, 0f, 0f);
            c.getOrientation(oa);
            p("T3 angle=" + i(oa[0]) + " axis=" + i(oa[1]) + "," + i(oa[2]) + "," + i(oa[3]));
            /* repeat: must stay identical */
            c.setTranslation(1f, 2f, 3f);
            c.postRotate(30f, 1f, 0f, 0f); /* R := Ry90*Rx30*Rx30 */
            c.getOrientation(oa);
            p("T3b angle=" + i(oa[0]) + " axis=" + i(oa[1]) + "," + i(oa[2]) + "," + i(oa[3]));
        }

        /* T4: generic matrix (setTransform) must survive postRotate and
         * component setters: composite = T(1,2,3) * Rx(30) * S(2). */
        {
            Camera c = new Camera();
            Transform t = new Transform();
            Transform g = new Transform();
            float[] gm = new float[16];
            for (int j = 0; j < 16; j++) gm[j] = 0f;
            gm[0] = 2f; gm[5] = 2f; gm[10] = 2f; gm[15] = 1f;
            g.set(gm);
            c.setTransform(g);
            for (int k = 1; k <= 3; k++) {
                c.setTranslation(1f, 2f, 3f);
                c.setOrientation(0f, 0f, 0f, 0f);
                c.postRotate(30f, 1f, 0f, 0f);
                c.getCompositeTransform(t);
                dump(t, "T4#" + k);
            }
            /* generic matrix itself must be untouched */
            c.getTransform(g);
            g.get(gm);
            p("T4 generic=" + i(gm[0]) + "," + i(gm[5]) + "," + i(gm[10]) + "," + i(gm[15]));
        }

        /* T5: translate()/scale() component ops. */
        {
            Camera c = new Camera();
            Transform t = new Transform();
            c.translate(1f, 2f, 3f);
            c.translate(1f, 2f, 3f);
            c.scale(2f, 2f, 2f);
            c.getCompositeTransform(t);
            dump(t, "T5");
            float[] tr = new float[3];
            c.getTranslation(tr);
            p("T5 translation=" + i(tr[0]) + "," + i(tr[1]) + "," + i(tr[2]));
        }

        /* ===== v34.69: spec-compliance audit additions ===== */

        /* T6: VertexArray spec getters. */
        {
            VertexArray va = new VertexArray(4, 3, 2);
            p("T6 v=" + va.getVertexCount()
              + " c=" + va.getComponentCount()
              + " t=" + va.getComponentType());
        }

        /* T7: Transform.transform(VertexArray, float[], boolean W) —
         * W=true applies translation to points; W=false leaves directions
         * unaffected by translation; 2-component input gets Z=0. */
        {
            VertexArray va = new VertexArray(2, 3, 2);
            short[] d = new short[] { 1, 2, 3, 4, 5, 6 };
            va.set(0, 2, d);
            Transform t = new Transform();
            t.postTranslate(10f, 20f, 30f);
            float[] out = new float[8];
            t.transform(va, out, true);
            p("T7 W1 v0=" + i(out[0]) + "," + i(out[1]) + "," + i(out[2]) + "," + i(out[3]));
            p("T7 W1 v1=" + i(out[4]) + "," + i(out[5]) + "," + i(out[6]) + "," + i(out[7]));
            t.transform(va, out, false);
            p("T7 W0 v0=" + i(out[0]) + "," + i(out[1]) + "," + i(out[2]) + "," + i(out[3]));
            VertexArray va2 = new VertexArray(1, 2, 2);
            short[] d2 = new short[] { 1, 2 };
            va2.set(0, 1, d2);
            float[] out2 = new float[4];
            t.transform(va2, out2, true);
            p("T7 C2 v0=" + i(out2[0]) + "," + i(out2[1]) + "," + i(out2[2]) + "," + i(out2[3]));
        }

        /* T8: Graphics3D spec getters. */
        {
            Graphics3D g = Graphics3D.getInstance();
            g.setViewport(5, 6, 100, 200);
            g.setDepthRange(0.25f, 0.75f);
            p("T8 vp=" + g.getViewportX() + "," + g.getViewportY()
              + "," + g.getViewportWidth() + "," + g.getViewportHeight());
            p("T8 dr=" + i(g.getDepthRangeNear()) + "," + i(g.getDepthRangeFar()));
            p("T8 tgt=" + (g.getTarget() == null ? 0 : 1) + " hints=" + g.getHints());
        }

        /* T9: CompositingMode depth offset getters. */
        {
            CompositingMode cm = new CompositingMode();
            cm.setDepthOffset(2.5f, 3.5f);
            p("T9 dof=" + i(cm.getDepthOffsetFactor()) + " dou=" + i(cm.getDepthOffsetUnits()));
        }

        /* T10: Texture2D individual getters. */
        {
            Image2D img = new Image2D(Image2D.RGB, 4, 4, new byte[48]);
            Texture2D tx = new Texture2D(img);
            tx.setFiltering(Texture2D.FILTER_LINEAR, Texture2D.FILTER_NEAREST);
            tx.setWrapping(Texture2D.WRAP_REPEAT, Texture2D.WRAP_CLAMP);
            p("T10 f=" + tx.getLevelFilter() + "," + tx.getImageFilter()
              + " w=" + tx.getWrappingS() + "," + tx.getWrappingT());
        }

        /* T11: PolygonMode.isPerspectiveCorrectionEnabled. */
        {
            PolygonMode pm = new PolygonMode();
            pm.setPerspectiveCorrectionEnable(true);
            p("T11 pce=" + (pm.isPerspectiveCorrectionEnabled() ? 1 : 0));
        }

        /* T12: MorphingMesh.getWeights(float[]) — spec void form. */
        {
            VertexArray pv = new VertexArray(3, 3, 2);
            short[] pd = new short[] { 0, 0, 0, 10, 0, 0, 0, 10, 0 };
            pv.set(0, 3, pd);
            VertexBuffer vb = new VertexBuffer();
            vb.setPositions(pv, 1f, null);
            VertexBuffer t1 = new VertexBuffer();
            t1.setPositions(pv, 1f, null);
            IndexBuffer ib = new TriangleStripArray(0, new int[] { 3 });
            MorphingMesh mm = new MorphingMesh(vb, new VertexBuffer[] { t1 }, ib, null);
            mm.setWeights(new float[] { 0.25f });
            float[] w = new float[1];
            mm.getWeights(w);
            p("T12 w=" + i(w[0]));
        }

        /* T13: pick descriptors — both spec overloads must RESOLVE (the
         * old registrations could never match a spec call site). Empty
         * world: both return false, printed as 0. */
        {
            World w = new World();
            Camera c = new Camera();
            w.addChild(c);
            w.setActiveCamera(c);
            RayIntersection ri = new RayIntersection();
            boolean r1 = w.pick(-1, 0f, 0f, 0f, 0f, 0f, -1f, ri);
            boolean r2 = w.pick(-1, 10f, 10f, c, ri);
            p("T13 r1=" + (r1 ? 1 : 0) + " r2=" + (r2 ? 1 : 0));
        }

        /* T14: Image2D palette constructor. */
        {
            Image2D pimg = new Image2D(Image2D.RGB, 2, 2,
                new byte[] { 0, 1, 2, 3 },
                new byte[] { 10, 20, 30, 40, 50, 60, 70, 80, 90 });
            p("T14 wh=" + pimg.getWidth() + "," + pimg.getHeight()
              + " fmt=" + pimg.getFormat());
        }

        /* T15: Transformable-typed receiver — methodrefs compiled against
         * the SPEC-DECLARING class (exact-class dispatch). Two identical
         * iterations must produce identical composites. */
        {
            Transformable tr = new Camera();
            Transform t = new Transform();
            for (int k = 1; k <= 2; k++) {
                tr.setTranslation(5f, 6f, 7f);
                tr.setScale(1f, 1f, 1f);
                tr.setOrientation(0f, 0f, 0f, 0f);
                tr.postRotate(90f, 0f, 1f, 0f);
                tr.preRotate(30f, 1f, 0f, 0f);
                tr.translate(1f, 1f, 1f);
                tr.scale(2f, 2f, 2f);
                tr.getCompositeTransform(t);
                dump(t, "T15#" + k);
            }
        }

        /* T16: SkinnedMesh.getBoneVertices(Node, int[], float[]) — spec
         * form; single bone with weight 1.0 covers 3 vertices. */
        {
            VertexArray pv = new VertexArray(3, 3, 2);
            short[] pd = new short[] { 0, 0, 0, 10, 0, 0, 0, 10, 0 };
            pv.set(0, 3, pd);
            VertexBuffer vb = new VertexBuffer();
            vb.setPositions(pv, 1f, null);
            IndexBuffer ib = new TriangleStripArray(0, new int[] { 3 });
            Group skeleton = new Group();
            SkinnedMesh sm = new SkinnedMesh(vb, ib, null, skeleton);
            Group bone = new Group();
            skeleton.addChild(bone);
            sm.addTransform(bone, 0, 3, 1.0f);
            int[] idx = new int[3];
            float[] wgt = new float[3];
            int n = sm.getBoneVertices(bone, idx, wgt);
            p("T16 n=" + n + " i0=" + idx[0] + " w0=" + i(wgt[0]));
        }

        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) {}
}
