package javax.microedition.m3g;

public class KeyframeSequence extends Object3D {
    public KeyframeSequence(int numKeyframes, int numComponents, int interpolation) {}
}
