package javax.microedition.m3g;

public class AnimationTrack extends Object3D {
    public AnimationTrack(KeyframeSequence sequence, int property) {}
}
