package javax.microedition.m3g;

public class VertexBuffer extends Object3D {
    public VertexBuffer() {}
    public void setPositions(VertexArray positions, float scale, float[] bias) {}
}
