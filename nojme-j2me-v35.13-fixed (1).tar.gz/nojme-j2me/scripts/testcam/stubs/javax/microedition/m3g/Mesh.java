package javax.microedition.m3g;

public class Mesh extends Node {
    public Mesh() {}
    public Mesh(VertexBuffer vertices, IndexBuffer triangles, Appearance appearance) {}
}
