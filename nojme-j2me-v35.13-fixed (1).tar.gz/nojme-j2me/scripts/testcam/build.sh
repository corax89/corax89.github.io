#!/bin/bash
# Build TestCam.jar — the JSR-184 Transformable rotation-semantics selftest.
#
# Reproduces the Stalker (Qplaze) per-frame camera pattern:
#   setTranslation(eye); setOrientation(yaw, 0,1,0); postRotate(pitch, 1,0,0)
# JSR-184 spec: postRotate/preRotate multiply the ORIENTATION COMPONENT
# (R := R*Rnew / R := Rnew*R), setOrientation sets it absolutely. Composite
# C = T*R*S*M must be IDENTICAL on every iteration. Pre-v34.68 the fold
# into the generic matrix accumulated T and R of every frame — the camera
# flew away spinning (user report).
#
# Requires: JRE (java) + ECJ (ecj.jar, e.g. scripts/.. or $ECJ path).
# Class version 48 (no stack maps), only TestCam.class packaged — the
# emulator supplies the m3g/midlet stub classes at runtime.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestCam.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java" \
    "$D/stubs/javax/microedition/m3g/"*.java
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestCam\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/TestCam.class" "$OUT/pkg/"
( cd "$OUT/pkg" && zip -q -r "$D/TestCam.jar" META-INF TestCam.class )
echo "built: $D/TestCam.jar"
echo "run:   ./bin/j2me-headless --headless games/TestCam.jar  (NOJME_LOG=1)"
echo "expect: T1#1..T1#5, T2#1..T2#4, T4#1..T4#3 all IDENTICAL; T3 angle=93840 axis=250,935,-250"
