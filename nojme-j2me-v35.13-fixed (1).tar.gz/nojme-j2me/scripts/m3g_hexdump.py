#!/usr/bin/env python3
"""Hex-dump specific objects from a .m3g file (3D Solid Weapon dialect).
Usage: m3g_hexdump.py <file.m3g> <obj_index_0based> [maxbytes]
Also shows float32/u32 decodes of the first bytes after the Object3D header."""
import struct, sys, zlib

def sections_of(path):
    data = open(path, 'rb').read()
    assert data[0] == 0xAB and data[1:7] == b'JSR184'
    out, fp = [], 12
    while fp + 13 <= len(data):
        comp = data[fp]
        tl = struct.unpack('<I', data[fp+1:fp+5])[0]
        if tl < 13 or fp + tl > len(data): break
        sd = data[fp+9:fp+tl-4]
        if comp == 1: sd = zlib.decompress(sd)
        out.append(sd)
        fp += tl
    return out

def objects_of(secs):
    objs = []
    for sd in secs:
        op = 0
        while op + 5 <= len(sd):
            t = sd[op]
            ln = struct.unpack('<I', sd[op+1:op+5])[0]
            op += 5
            if ln == 0 or op + ln > len(sd): break
            objs.append((t, sd[op:op+ln]))
            op += ln
    return objs

def hexdump(b, start=0, per=16):
    for i in range(0, len(b), per):
        chunk = b[i:i+per]
        hexs = ' '.join('%02x' % c for c in chunk)
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in chunk)
        print('  %04x  %-47s  %s' % (start + i, hexs, txt))

if __name__ == '__main__':
    path, idx = sys.argv[1], int(sys.argv[2])
    maxb = int(sys.argv[3]) if len(sys.argv) > 3 else 256
    objs = objects_of(sections_of(path))
    t, body = objs[idx]
    print('object #%d type=%d len=%d' % (idx, t, len(body)))
    print('--- first %d bytes (from uid):' % min(maxb, len(body)))
    hexdump(body[:maxb])
    # decode Object3D header: uid, trackCount+refs, userObjCount+entries
    p = 4
    ntc = struct.unpack('<I', body[p:p+4])[0]; p += 4
    refs = []
    for _ in range(ntc):
        refs.append(struct.unpack('<I', body[p:p+4])[0]); p += 4
    uoc = struct.unpack('<I', body[p:p+4])[0]; p += 4
    uos = []
    for _ in range(uoc):
        oid = struct.unpack('<I', body[p:p+4])[0]; ln = struct.unpack('<I', body[p+4:p+8])[0]
        uos.append((oid, ln)); p += 8 + ln
    print('uid=%d tracks=%s userObjs=%s obj3d_hdr_consumed=%d body_left=%d'
          % (struct.unpack('<I', body[:4])[0], refs, uos, p, len(body) - p))
    rest = body[p:]
    # decode as u32s
    print('--- u32 stream after obj3d header (first 32):')
    for i in range(0, min(len(rest), 128), 4):
        u = struct.unpack('<I', rest[i:i+4])[0]
        f = struct.unpack('<f', rest[i:i+4])[0]
        print('  +%03d  u32=%-12u  f32=%g' % (i, u, f))
    # u8 stream decode attempt
    print('--- u8 stream (first 32):')
    print('  ' + ' '.join('%02x' % c for c in rest[:32]))
