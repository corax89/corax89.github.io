#!/bin/bash
# Final v34.40 verification: FM X (ported fix) + Asphalt (v36/v37 fixes intact)
# + Quake (regression) + quiet-by-default policy.
set -u
cd /home/z/my-project/j2me-analysis
OUT=/home/z/my-project/work/v44-verify
mkdir -p "$OUT"

echo "=== [1] FM X: motorcycle + road (ported world_synthetic fix) ==="
rm -f /tmp/j2me_frame_*.ppm
NOJME_LOG=1 NOJME_HEADLESS_MAX_MS=120000 NOJME_HEADLESS_KEYSEQ=53 \
  NOJME_HEADLESS_KEYSEQ_EVERY=90 NOJME_HEADLESS_SNAP_FRAMES=6000,10000 \
  ./bin/j2me-headless games/fmx.jar > "$OUT/fmx.log" 2>&1
echo -n "  roots-only results: "; grep -c "fabricated, roots-only result" "$OUT/fmx.log"
echo -n "  render(Node):        "; grep -c "M3G-RENDER-NODE" "$OUT/fmx.log"
echo -n "  renderMesh:          "; grep -c "renderMesh" "$OUT/fmx.log"
echo -n "  INVOKE-MISSING:      "; grep -c "INVOKE-MISSING" "$OUT/fmx.log"
for ppm in /tmp/j2me_frame_*.ppm; do
  [ -f "$ppm" ] || continue
  n=$(basename "$ppm" .ppm | sed 's/j2me_frame_//')
  python3 -c "from PIL import Image; Image.open('$ppm').save('$OUT/fmx_$n.png')" 2>/dev/null
done
ls "$OUT"/fmx_*.png 2>/dev/null

echo ""
echo "=== [2] Asphalt 3 3D: textures (v36) + flat shadow (v37) intact ==="
rm -f /tmp/j2me_frame_*.ppm
NOJME_LOG=1 NOJME_HEADLESS_MAX_MS=100000 NOJME_HEADLESS_KEYSEQ="5,-5" \
  NOJME_HEADLESS_KEYSEQ_EVERY=200 NOJME_HEADLESS_SNAP_FRAMES=4000,7000,10000,13000 \
  ./bin/j2me-headless "games/Asphalt 3 3D (1.1.5).jar" > "$OUT/asphalt.log" 2>&1
echo -n "  renderMesh:     "; grep -c "renderMesh" "$OUT/asphalt.log"
echo -n "  setImage calls: "; grep -c "SETIMG" "$OUT/asphalt.log" || true
echo -n "  INVOKE-MISSING: "; grep -c "INVOKE-MISSING" "$OUT/asphalt.log"
for ppm in /tmp/j2me_frame_*.ppm; do
  [ -f "$ppm" ] || continue
  n=$(basename "$ppm" .ppm | sed 's/j2me_frame_//')
  python3 -c "from PIL import Image; Image.open('$ppm').save('$OUT/asphalt_$n.png')" 2>/dev/null
done
ls "$OUT"/asphalt_*.png 2>/dev/null

echo ""
echo "=== [3] Quake Plus 3D: no regression ==="
rm -f /tmp/j2me_frame_*.ppm
NOJME_LOG=1 NOJME_HEADLESS_MAX_MS=45000 NOJME_HEADLESS_KEYSEQ="-1,-1,5,-5,-1,-1" \
  NOJME_HEADLESS_KEYSEQ_EVERY=120 NOJME_HEADLESS_SNAP_FRAMES=4000,8000 \
  ./bin/j2me-headless "games/Quake Plus 3D (M3GWORKS)[a2].jar" > "$OUT/quake.log" 2>&1
echo -n "  renderWorld:    "; grep -c "renderWorld" "$OUT/quake.log"
echo -n "  Loader.load:    "; grep -c "Loader.load:" "$OUT/quake.log"
echo -n "  fabricated:     "; grep -c "fabricated" "$OUT/quake.log" || true
for ppm in /tmp/j2me_frame_*.ppm; do
  [ -f "$ppm" ] || continue
  n=$(basename "$ppm" .ppm | sed 's/j2me_frame_//')
  python3 -c "from PIL import Image; Image.open('$ppm').save('$OUT/quake_$n.png')" 2>/dev/null
done
ls "$OUT"/quake_*.png 2>/dev/null

echo ""
echo "=== [4] Quiet policy: logs OFF by default (FM X 10s, no env) ==="
NOJME_HEADLESS_MAX_MS=10000 ./bin/j2me-headless games/fmx.jar > "$OUT/quiet.log" 2>&1
echo -n "  total non-empty lines: "; grep -vc "^$" "$OUT/quiet.log" || true
echo -n "  [M3G] debug lines:     "; grep -c "^\[M3G" "$OUT/quiet.log" || true
echo -n "  INVOKE-MISSING lines:  "; grep -c "INVOKE-MISSING" "$OUT/quiet.log" || true
echo "  (CANVAS TEXT / banner / [Headless] harness lines are headless-build-only,"
echo "   not part of libretro core; core keeps INVOKE-MISSING + BUILD banner)"

echo ""
echo "=== [5] BlackShark3D — already verified separately ==="
echo "  3D gameplay confirmed (v40_bs_game.log): render(Node) 769, Loader 3,"
echo "  mission loading passed, VLM: green 3D scene + water + HUD + radar."
echo "DONE."
