import sys
from PIL import Image
import struct
def readppm(p):
    d = open(p, 'rb').read()
    parts = d.split(b'\n', 3)
    w, h = map(int, parts[1].split())
    return Image.frombytes('RGB', (w, h), parts[3])
img = readppm(sys.argv[1])
img.save(sys.argv[2])
print("saved", sys.argv[2], img.size)
