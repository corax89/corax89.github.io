#!/bin/bash
# Build the LIBRETRO CORE for ARMv7+NEON with the exact m17 target flags
# (incl. -flto), plus the lr_run frontend harness, both runnable under qemu.
set -e
# v34.60: paths are now SCRIPT-RELATIVE - the tree can be unpacked anywhere
# (was: hardcoded /tmp/my-project of the original build machine).
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
R="$ROOT/../armtc/sysroot"
D="$ROOT"
CC="$ROOT/../armtc/cc-armv7"

LIBRETRO_SRCS="$D/src/jvm/classfile.c $D/src/jvm/debug_var.c $D/src/jvm/execute.c \
$D/src/jvm/heap.c $D/src/jvm/jvm.c $D/src/jvm/method_cache.c $D/src/jvm/native.c \
$D/src/jvm/nokia_m3d.c $D/src/jvm/opcodes.c $D/src/jvm/stubs.c $D/src/jvm/threads.c \
$D/src/jvm/charset.c \
$D/src/midp/display.c $D/src/midp/form.c $D/src/midp/graphics.c $D/src/midp/media.c \
$D/src/midp/mobile3d.c $D/src/midp/mascot3d.c $D/src/midp/rms.c \
$D/src/render/render.c \
$D/src/utils/miniz.c $D/src/utils/jar_reader.c $D/src/utils/stb_image_impl.c \
$D/src/utils/utils.c $D/src/jvm/drm_bypass.c \
$D/src/midi/midi.c \
$D/src/libretro/libretro.c $D/src/libretro/sdl_backend_stubs.c"

# v34.69: AMR-NB decoder (opencore-amrnb) — now plain C, no C++ toolchain.
# Compiled WITHOUT -flto (same as before: keeps the object cache simple);
# mixed C-LTO + plain C objects link fine with -fuse-linker-plugin.
AMR_C="$D/src/amr/amr_nb_dec.c $(find $D/src/amr/opencore -name '*.c' | sort)"
AMR_INCS="-I$D/src/amr -I$D/src/amr/oscl \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/common/include \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/include \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src \
-I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/common/dec/include"
AMR_FLAGS="-Wall -std=c11 -I$D/include -I$D/src -I$D/src/include \
-O3 -fno-stack-protector -fomit-frame-pointer -fmerge-all-constants -fno-math-errno \
-marm -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=hard \
$AMR_INCS"

# exact m17 CFLAGS from the Makefile (v41: -O3, no fast-math)
FLAGS="-Wall -Wextra -std=c11 \
-I$D/include -I$D/src -I$D/src/include -I$D/src/jvm -I$D/src/midp \
-I$D/src/utils -I$D/src/libretro \
-DLIBRETRO -DARM -D_GNU_SOURCE -DJ2ME_DEBUG=0 -DOPT_NO_BOUNDS_CHECK \
-O3 -fPIC \
-fdata-sections -ffunction-sections \
-fno-stack-protector -fomit-frame-pointer \
-fmerge-all-constants -fno-math-errno \
-marm -mtune=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=hard \
-flto -ftree-vectorize -fipa-cp-clone -finline-functions-called-once \
-DHAVE_NEON=1"

AMROBJ=$D/obj/arm_amr_libretro

case "$1" in
core)
    mkdir -p $AMROBJ
    # v34.69: stale C++-era object names differ; cache keyed by source name.
    for f in $AMR_C; do
        o=$AMROBJ/$(echo "${f#$D/src/amr/}" | tr / _).o
        if [ ! -f "$o" ] || [ "$f" -nt "$o" ]; then
            echo "  CC(arm) ${f##*/}"
            $CC $AMR_FLAGS -c "$f" -o "$o"
        fi
    done
    time $CC $FLAGS $LIBRETRO_SRCS $AMROBJ/*.o -o $D/bin/nojme_libretro_armv7.so \
        -shared -Wl,--no-undefined -Wl,--gc-sections \
        -Wl,--version-script=$D/src/libretro/link.T \
        -flto -fuse-linker-plugin \
        -lm -pthread
    file $D/bin/nojme_libretro_armv7.so
    echo "CORE OK: $D/bin/nojme_libretro_armv7.so"
    ;;
front)
    $CC -O1 -std=c11 -marm -mfpu=neon-vfpv4 -mfloat-abi=hard \
        $D/scripts/lr_run.c -o $D/bin/lr_run_armv7 \
        -ldl -lm -pthread
    file $D/bin/lr_run_armv7
    echo "FRONT OK: $D/bin/lr_run_armv7"
    ;;
esac
