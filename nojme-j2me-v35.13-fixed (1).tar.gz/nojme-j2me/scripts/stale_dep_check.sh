#!/bin/sh
# v34.73 Makefile self-heal helper — prints stale .d dependency files.
#
# A .d file is stale when:
#  (a) it references a .cpp source anywhere (pre-v34.69 C++ build leftovers;
#      the tree contains no C++ sources at all), or
#  (b) its FIRST (primary) prerequisite no longer exists on disk.
#      With -MMD the first prerequisite is the compiled source; -MP adds
#      phony rules only for header deps, never for the source — so a .d
#      whose primary source is gone is a leftover from an older build and
#      make would abort on its dangling edge ("No rule to make target").
#
# Continuation-safe: GCC wraps long lines with backslash-newline — for the
# vendored AMR paths the first line ends right after "target:\" — so the
# first LOGICAL line is assembled before parsing (v34.73 rev.2: the initial
# one-liner awk false-flagged every deep opencore .d as stale).
#
# Performance: ONE awk process joins/checks the whole tree; ONE batched grep
# handles the .cpp sweep. Safe on MSYS2 (no per-file process spawns).
#
# Usage: sh scripts/stale_dep_check.sh [objdir]     (default: obj)
dir="${1:-obj}"
[ -d "$dir" ] || exit 0

# (a) any .cpp reference — catches every C++-era leftover
find "$dir" -name '*.d' -exec grep -l '\.cpp' {} + 2>/dev/null

# (b) primary prerequisite missing (continuation-joined first line)
find "$dir" -name '*.d' -exec awk '
  FNR == 1 { buf = ""; done1 = 0 }
  {
    if (done1) next
    buf = buf $0
    if (buf ~ /\\$/) { sub(/\\$/, "", buf); next }
    done1 = 1
    n = index(buf, ":")
    if (n > 0) {
      rest = substr(buf, n + 1)
      sub(/^[ \t]+/, "", rest)
      split(rest, w, /[ \t]/)
      src = w[1]
      if (src != "" && src !~ /^\\/ && (getline _line < src) < 0) print FILENAME
      if (src != "") close(src)
    }
  }
' {} + 2>/dev/null

exit 0
