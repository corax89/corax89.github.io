#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 0e. NEW: TestRMS E2E — the JSR 118 spec suite ----------
note "0e) TestRMS E2E: 33 spec checks (enumeration peek, null data, authmode, getSize)"
rm -rf /tmp/reg74/trms; mkdir -p /tmp/reg74/trms
PACED=1 NOJME_LOG=1 timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestRMS.jar 200 /tmp/reg74/trms 0 > /tmp/reg74/trms/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestRMS lr_run rc=$rc"
grep -q "RMS:DONE 33/0" /tmp/reg74/trms/run.log || fail "TestRMS: $(grep -c ' FAIL ' /tmp/reg74/trms/run.log) failing checks"
note "TestRMS: $(grep 'RMS:DONE' /tmp/reg74/trms/run.log | tail -1 | sed 's/.*SYSOUT\] //')"

# ---------- 0f. NEW: TestAnim E2E — the JSR-184 animation suite ----------
note "0f) TestAnim E2E: 18 spec checks (weight, blending, controllers, validity)"
rm -rf /tmp/reg74/tanim; mkdir -p /tmp/reg74/tanim
PACED=1 NOJME_LOG=1 timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestAnim.jar 200 /tmp/reg74/tanim 0 > /tmp/reg74/tanim/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestAnim lr_run rc=$rc"
grep -q "ANIM:DONE 18/0" /tmp/reg74/tanim/run.log || fail "TestAnim: $(grep -c ' FAIL ' /tmp/reg74/tanim/run.log) failing checks"
note "TestAnim: $(grep 'ANIM:DONE' /tmp/reg74/tanim/run.log | tail -1 | sed 's/.*SYSOUT\] //')"

# ---------- 0g. NEW: frame limit — live j2me_fps switch pushes AV info ----------
note "0g) Frame limit: live j2me_fps 30->60 must push SET_SYSTEM_AV_INFO"
rm -rf /tmp/reg74/fps; mkdir -p /tmp/reg74/fps
LRVAR_j2me_fps=30 LRVAR_j2me_fps2=60 LR_FPS_SWITCH=100 PACED=1 \
  timeout 90 ./bin/lr_run ./bin/nojme_libretro.so games/TestBack.jar 250 /tmp/reg74/fps 0 > /tmp/reg74/fps/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "frame-limit lr_run rc=$rc"
grep -q "SET_SYSTEM_AV_INFO: fps=60.000" /tmp/reg74/fps/run.log || fail "frame limit: SET_SYSTEM_AV_INFO(60) not received by frontend"
grep -q "simulating j2me_fps option update" /tmp/reg74/fps/run.log || fail "frame limit: harness did not flip the option"
note "frame limit: 30->60 at frame 100, frontend accepted SET_SYSTEM_AV_INFO (fps=60, rate, geometry)"

# ---------- 1. headless smoke: games ----------
note "1) headless smoke (10 games, 30s cap each)"
GAMES=("3DFerrariExperience.jar" "Asphalt 3 3D (1.1.5).jar" "Assassin's Creed (1.1.0).jar" "Assassin's Creed 2 (1.0.1).jar" "BlackShark3D.jar" "Gish - Reloaded [Rus].jar" "Nescube_V_2.3.jar" "Quake Plus 3D (M3GWORKS)[a2].jar" "Treasure Towers (1.3)[128x160].jar" "fmx.jar")
for g in "${GAMES[@]}"; do
  rm -rf /tmp/reg73/rms; mkdir -p /tmp/reg73/rms
  NOJME_RMS_DIR=/tmp/reg73/rms NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=200 \
    timeout 30 ./bin/j2me-headless --headless "games/$g" > /tmp/reg73/"$g".log 2>&1
  rc=$?
  fatal=$(grep -c "FATAL\|SIGSEGV\|double free\|corrupt" /tmp/reg73/"$g".log || true)
  if [ $rc -eq 124 ] || [ $rc -eq 0 ]; then
    if [ "$fatal" -gt 0 ]; then fail "$g: fatal markers=$fatal (rc=$rc)"; else note "$g: OK (rc=$rc)"; fi
  else
    fail "$g: rc=$rc fatal=$fatal"
  fi
done

echo "[REG] === reg_chunk2 result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
