#!/usr/bin/env python3
"""Generate Test58 J2ME midlet — v34.58 selftest.

Exercises the newly-registered boxed-value constructors + identity methods:
  new Byte(b).toString()/byteValue()/hashCode()/equals()
  new Short(s).toString()/shortValue()/hashCode()/equals()
  new Character(c).toString()/charValue()/equals()
  new Integer(i).toString() (sanity: the old registered ctor must stay)
  Hashtable with Short keys (equals/hashCode through the real API)

Expected SYSOUT sequence:
  100, -6, 17000, -300, Z, 1234, 1, 0, 1, 1, 42, AB, 9, -6
"""
import struct, zipfile

class CP:
    def __init__(self):
        self.entries = [None]
    def _next_index(self):
        return len(self.entries)
    def utf8(self, s):
        b = s.encode('utf-8')
        raw = b'\x01' + struct.pack('>H', len(b)) + b
        for i, e in enumerate(self.entries):
            if e and e[0] == raw:
                return i
        idx = self._next_index()
        self.entries.append((raw, 1))
        return idx
    def str_(self, s):
        ni = self.utf8(s)
        raw = b'\x08' + struct.pack('>H', ni)
        for i, e in enumerate(self.entries):
            if e and e[0] == raw:
                return i
        idx = self._next_index()
        self.entries.append((raw, 1))
        return idx
    def cls(self, name):
        ni = self.utf8(name)
        raw = b'\x07' + struct.pack('>H', ni)
        for i, e in enumerate(self.entries):
            if e and e[0] == raw:
                return i
        idx = self._next_index()
        self.entries.append((raw, 1))
        return idx
    def nat(self, name, desc):
        ni, di = self.utf8(name), self.utf8(desc)
        raw = b'\x0c' + struct.pack('>HH', ni, di)
        for i, e in enumerate(self.entries):
            if e and e[0] == raw:
                return i
        idx = self._next_index()
        self.entries.append((raw, 1))
        return idx
    def mref(self, cls, name, desc):
        ci = self.cls(cls)
        nti = self.nat(name, desc)
        idx = self._next_index()
        self.entries.append((b'\x0a' + struct.pack('>HH', ci, nti), 1))
        return idx
    def fref(self, cls, name, desc):
        ci = self.cls(cls)
        nti = self.nat(name, desc)
        idx = self._next_index()
        self.entries.append((b'\x09' + struct.pack('>HH', ci, nti), 1))
        return idx
    def bytes(self):
        out = struct.pack('>H', len(self.entries))
        for e in self.entries:
            if e: out += e[0]
        return out

cp = CP()
THIS = cp.cls('Test58')
SUPER = cp.cls('javax/microedition/midlet/MIDlet')

MIDLET_INIT = cp.mref('javax/microedition/midlet/MIDlet', '<init>', '()V')
SYS_OUT = cp.fref('java/lang/System', 'out', 'Ljava/io/PrintStream;')
PRINTLN_I = cp.mref('java/io/PrintStream', 'println', '(I)V')
PRINTLN_S = cp.mref('java/io/PrintStream', 'println', '(Ljava/lang/String;)V')

BYTE_C = cp.cls('java/lang/Byte')
SHORT_C = cp.cls('java/lang/Short')
CHAR_C = cp.cls('java/lang/Character')
INT_C = cp.cls('java/lang/Integer')
HT_C = cp.cls('java/util/Hashtable')
STR_C = cp.cls('java/lang/String')

BYTE_INIT = cp.mref('java/lang/Byte', '<init>', '(B)V')
SHORT_INIT = cp.mref('java/lang/Short', '<init>', '(S)V')
CHAR_INIT = cp.mref('java/lang/Character', '<init>', '(C)V')
INT_INIT = cp.mref('java/lang/Integer', '<init>', '(I)V')
HT_INIT = cp.mref('java/util/Hashtable', '<init>', '()V')
HT_PUT = cp.mref('java/util/Hashtable', 'put', '(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;')
HT_GET = cp.mref('java/util/Hashtable', 'get', '(Ljava/lang/Object;)Ljava/lang/Object;')

TO_STR = lambda cls: cp.mref(cls, 'toString', '()Ljava/lang/String;')
BYTE_TOSTR = TO_STR('java/lang/Byte')
SHORT_TOSTR = TO_STR('java/lang/Short')
CHAR_TOSTR = TO_STR('java/lang/Character')
INT_TOSTR = TO_STR('java/lang/Integer')
BYTE_BYTEVAL = cp.mref('java/lang/Byte', 'byteValue', '()B')
SHORT_SHORTVAL = cp.mref('java/lang/Short', 'shortValue', '()S')
CHAR_CHARVAL = cp.mref('java/lang/Character', 'charValue', '()C')
SHORT_HASH = cp.mref('java/lang/Short', 'hashCode', '()I')
BYTE_HASH = cp.mref('java/lang/Byte', 'hashCode', '()I')
OBJ_EQUALS = lambda cls: cp.mref(cls, 'equals', '(Ljava/lang/Object;)Z')
SHORT_EQ = OBJ_EQUALS('java/lang/Short')
BYTE_EQ = OBJ_EQUALS('java/lang/Byte')
CHAR_EQ = OBJ_EQUALS('java/lang/Character')
AB_STR = cp.str_('AB')

def u2(v): return struct.pack('>H', v)
def u4(v): return struct.pack('>I', v)

code_attr_name = cp.utf8('Code')
init_name = cp.utf8('<init>')
sa_name = cp.utf8('startApp')
void_desc = cp.utf8('()V')

init_code = bytes([0x2a]) + b'\xb7' + u2(MIDLET_INIT) + bytes([0xb1])

c = bytearray()
def emit(*bs):
    for b in bs: c.append(b)
def u2e(v): c.extend(struct.pack('>H', v))
def inv(op, idx):
    emit(op); u2e(idx)

def box_int(value, cls_idx, init_idx, kind='auto'):
    """push new <Box>(const) — auto-selects iconst/bipush/sipush"""
    if kind == 'auto':
        if 0 <= value <= 5: kind = 'i'
        elif -128 <= value <= 127: kind = 'b'
        else: kind = 's'
    emit(0xbb); u2e(cls_idx); emit(0x59)
    if kind == 'i':
        emit(0x03 + value)                  # iconst_n (0..5 only!)
    elif kind == 'b':
        emit(0x10, value & 0xff)            # bipush
    else:
        c.extend(bytes([0x11])); c.extend(struct.pack('>h', value))  # sipush
    emit(0xb7); u2e(init_idx)

def println_i():
    emit(0xb6); u2e(PRINTLN_I)

def println_s():
    emit(0xb6); u2e(PRINTLN_S)

def out():
    emit(0xb2); u2e(SYS_OUT)

# T1: new Byte(100).toString() -> "100"
out(); box_int(100, BYTE_C, BYTE_INIT); inv(0xb6, BYTE_TOSTR); println_s()
# T2: new Byte(-6).byteValue() -> -6
out(); box_int(-6, BYTE_C, BYTE_INIT); inv(0xb6, BYTE_BYTEVAL); println_i()
# T3: new Short(17000).toString() -> "17000"
out(); box_int(17000, SHORT_C, SHORT_INIT); inv(0xb6, SHORT_TOSTR); println_s()
# T4: new Short(-300).shortValue() -> -300
out(); box_int(-300, SHORT_C, SHORT_INIT); inv(0xb6, SHORT_SHORTVAL); println_i()
# T5: new Character(90).toString() -> "Z"
out(); box_int(90, CHAR_C, CHAR_INIT); inv(0xb6, CHAR_TOSTR); println_s()
# T6: new Character(1234).charValue() -> 1234
out(); box_int(1234, CHAR_C, CHAR_INIT); inv(0xb6, CHAR_CHARVAL); println_i()
# T7: new Short(5).equals(new Short(5)) -> 1
out(); box_int(5, SHORT_C, SHORT_INIT); box_int(5, SHORT_C, SHORT_INIT); inv(0xb6, SHORT_EQ); println_i()
# T8: new Short(5).equals(new Short(6)) -> 0
out(); box_int(5, SHORT_C, SHORT_INIT); box_int(6, SHORT_C, SHORT_INIT); inv(0xb6, SHORT_EQ); println_i()
# T9: new Byte(7).equals(new Byte(7)) -> 1
out(); box_int(7, BYTE_C, BYTE_INIT); box_int(7, BYTE_C, BYTE_INIT); inv(0xb6, BYTE_EQ); println_i()
# T10: new Character(65).equals(new Character(65)) -> 1
out(); box_int(65, CHAR_C, CHAR_INIT); box_int(65, CHAR_C, CHAR_INIT); inv(0xb6, CHAR_EQ); println_i()
# T11: new Integer(42).toString() -> "42" (old ctor must keep working)
out(); box_int(42, INT_C, INT_INIT); inv(0xb6, INT_TOSTR); println_s()
# T12: Hashtable: put(new Short(9),"AB"); out; ht.get(new Short(9)) -> "AB"
emit(0xbb); u2e(HT_C); emit(0x59); emit(0xb7); u2e(HT_INIT); emit(0x4c)  # astore_1
emit(0x2b)                                                                 # aload_1 (ht)
box_int(9, SHORT_C, SHORT_INIT)
emit(0x12); c.append(AB_STR)                                               # ldc "AB"
emit(0xb6); u2e(HT_PUT); emit(0x57)                                        # put; pop returned
out()
emit(0x2b)
box_int(9, SHORT_C, SHORT_INIT)
emit(0xb6); u2e(HT_GET)                                                    # get -> Object
emit(0xc0); u2e(STR_C)                                                     # checkcast String
println_s()
# T13: new Short(9).hashCode() -> 9
out(); box_int(9, SHORT_C, SHORT_INIT); inv(0xb6, SHORT_HASH); println_i()
# T14: new Byte(-6).hashCode() -> -6
out(); box_int(-6, BYTE_C, BYTE_INIT); inv(0xb6, BYTE_HASH); println_i()
emit(0xb1)  # return

start_code = bytes(c)

def method(access, name_i, desc_i, code, max_stack, max_locals):
    # method_info: access(u2) name(u2) desc(u2) attrs_count(u2) + Code attr
    attr_len = 2 + 2 + 4 + len(code) + 2 + 2
    attr = u2(code_attr_name) + u4(attr_len)
    attr += u2(max_stack) + u2(max_locals) + u4(len(code)) + code
    attr += u2(0)  # exception_table_length
    attr += u2(0)  # attributes_count
    return u2(access) + u2(name_i) + u2(desc_i) + u2(1) + attr

cls = (bytes([0xca, 0xfe, 0xba, 0xbe]) + u2(0) + u2(48) +
       cp.bytes() + u2(0x0021) + u2(THIS) + u2(SUPER) +
       u2(0) + u2(0) + u2(2) +
       method(0x01, init_name, void_desc, init_code, 1, 1) +
       method(0x04, sa_name, void_desc, start_code, 6, 2) +
       u2(0))

manifest = (
    "MIDlet-1: T, , Test58\r\n"
    "MIDlet-Name: T\r\n"
    "MIDlet-Version: 1.0\r\n"
    "MIDlet-Vendor: T\r\n"
    "MicroEdition-Configuration: CLDC-1.1\r\n"
    "MicroEdition-Profile: MIDP-2.0\r\n")

out_path = '/tmp/my-project/j2me-analysis/work/test58.jar'
with zipfile.ZipFile(out_path, 'w') as z:
    z.writestr('META-INF/MANIFEST.MF', manifest)
    z.writestr('Test58.class', bytes(cls))
print('written', out_path, len(cls), 'bytes class')
