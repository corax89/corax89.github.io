#!/usr/bin/env python3
"""Simulate the full skinning pipeline in Python (same math as the core):
bind snapshot + invBind + animated bone matrices, at kf0 (bind) and at a
mid-animation keyframe. Verifies:
  - kf0: skinned == original (identity skin matrices)
  - mid-anim: mesh coherence (per-triangle stretch factor)
"""
import struct, sys, math
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_skin_space import parse, mat_identity, mat_mul, axis_angle_to_mat, scale_mat, trans_mat, decode_kf, axis_angle_to_quat, quat_to_axis_angle, quat_dist

def mat_mul_point(m, v):
    x, y, z, w = v
    return (m[0][0]*x+m[0][1]*y+m[0][2]*z+m[0][3]*w,
            m[1][0]*x+m[1][1]*y+m[1][2]*z+m[1][3]*w,
            m[2][0]*x+m[2][1]*y+m[2][2]*z+m[2][3]*w)

def mat_invert(m):
    n = 4
    a = [row[:] for row in m]
    inv = [[1.0 if i == j else 0.0 for j in range(4)] for i in range(4)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[piv][col]) < 1e-12: return None
        a[col], a[piv] = a[piv], a[col]
        inv[col], inv[piv] = inv[piv], inv[col]
        d = a[col][col]
        a[col] = [x/d for x in a[col]]; inv[col] = [x/d for x in inv[col]]
        for r in range(n):
            if r == col: continue
            f = a[r][col]
            if f != 0:
                a[r] = [x-f*y for x, y in zip(a[r], a[col])]
                inv[r] = [x-f*y for x, y in zip(inv[r], inv[col])]
    return inv

def quat_slerp(p, q, t):
    d = sum(p[i]*q[i] for i in range(4))
    if d < 0:
        q = [-x for x in q]; d = -d
    if d > 0.9995:
        r = [(1-t)*p[i]+t*q[i] for i in range(4)]
    else:
        th = math.acos(d)
        s = math.sin(th)
        r = [math.sin((1-t)*th)/s*p[i]+math.sin(t*th)/s*q[i] for i in range(4)]
    n = math.sqrt(sum(x*x for x in r))
    return [x/n for x in r]

def lerp(a, b, t):
    return [a[i]+(b[i]-a[i])*t for i in range(len(a))]

def main(path, probe_times=(0, 60, 120, 200)):
    parsed, objs = parse(path)
    groups = {i+1: o for i, o in enumerate(parsed) if o['typename'] == 'GROUP'}
    sm = next(o for o in parsed if o['typename'] == 'SKINNEDMESH')
    # --- vertices
    vb = parsed[sm['vb_ref']-1]
    tv, vbody = objs[vb['pos_ref']-1]
    q = 4
    ntc = struct.unpack('<I', vbody[q:q+4])[0]; q += 4
    q += 4*ntc
    nuo = struct.unpack('<I', vbody[q:q+4])[0]; q += 4
    for _ in range(nuo):
        q += 4; ln = struct.unpack('<I', vbody[q:q+4])[0]; q += 4+ln
    cs, cc, enc = vbody[q], vbody[q+1], vbody[q+2]
    vc = struct.unpack('<H', vbody[q+3:q+5])[0]
    raw = [struct.unpack('<b', vbody[q+5+(v*cc+c):q+5+(v*cc+c)+1])[0] for v in range(vc) for c in range(cc)]
    verts = [tuple(vb['bias'][c] + vb['scale']*raw[v*3+c] for c in range(3)) for v in range(vc)]
    # --- animations
    tr_by_file = {i+1: o for i, o in enumerate(parsed) if o['typename'] == 'ANIMTRACK'}
    PROP = {256:'SCALE', 268:'ORI', 275:'TRA'}
    anim = {}  # grp -> {'ORI': (seq), 'TRA': (seq)}
    for gi, g in groups.items():
        for tr_ref in g.get('tracks', []):
            tr = parsed[tr_ref-1] if tr_ref else None
            if not tr or tr['typename'] != 'ANIMTRACK': continue
            seq = parsed[tr['seq_ref']-1]
            if seq['typename'] != 'KEYFRAMESEQ' or not seq.get('kfs'): continue
            pn = PROP.get(tr['property'])
            if pn:
                anim.setdefault(gi, {})[pn] = seq
    def local_matrix(gi, t):
        g = groups[gi]
        an = anim.get(gi, {})
        # translation
        if 'TRA' in an and an['TRA']['comp'] >= 3:
            seq = an['TRA']
            kfs = seq['kfs']
            k = 0
            while k < len(kfs)-1 and kfs[k+1][0] <= t: k += 1
            if k == len(kfs)-1:
                vals = decode_kf(kfs[k][1], seq['bias'], seq['scale'], 'u255')
            else:
                t0, t1 = kfs[k][0], kfs[k+1][0]
                f = (t-t0)/(t1-t0) if t1 > t0 else 0.0
                v0 = decode_kf(kfs[k][1], seq['bias'], seq['scale'], 'u255')
                v1 = decode_kf(kfs[k+1][1], seq['bias'], seq['scale'], 'u255')
                vals = lerp(v0, v1, f)
            tr = vals
        else:
            tr = list(g.get('t', (0, 0, 0)))
        # orientation (quat slerp)
        if 'ORI' in an and an['ORI']['comp'] == 4:
            seq = an['ORI']
            kfs = seq['kfs']
            k = 0
            while k < len(kfs)-1 and kfs[k+1][0] <= t: k += 1
            def dq(kk): return decode_kf(kfs[kk][1], seq['bias'], seq['scale'], 'u255')
            if k == len(kfs)-1:
                quat = dq(k)
            else:
                t0, t1 = kfs[k][0], kfs[k+1][0]
                f = (t-t0)/(t1-t0) if t1 > t0 else 0.0
                quat = quat_slerp(dq(k), dq(k+1), f)
            ang, ax, ay, az = quat_to_axis_angle(quat)
        else:
            o4 = g.get('o', (0, 0, 0, 1))
            ang, ax, ay, az = o4
        s = list(g.get('s', (1, 1, 1)))
        if s == [0, 0, 0]: s = [1, 1, 1]
        m = mat_mul(trans_mat(*tr), mat_mul(axis_angle_to_mat(ang, ax, ay, az), scale_mat(*s)))
        if 'g' in g:
            gm = [[g['g'][r*4+c] for c in range(4)] for r in range(4)]
            m = mat_mul(m, gm)
        return m

    children_map = {}; is_child = set()
    for idx, g in groups.items():
        for c in g.get('children', []):
            children_map.setdefault(idx, []).append(c); is_child.add(c)
    roots = [i for i in groups if i not in is_child]

    def world_mats(t):
        world = {}
        stack = [(r, mat_identity()) for r in roots]
        while stack:
            idx, pm = stack.pop()
            wm = mat_mul(pm, local_matrix(idx, t))
            world[idx] = wm
            for c in children_map.get(idx, []):
                if c in groups:
                    stack.append((c, wm))
        return world

    # bind snapshot
    bind = world_mats(0)  # kf0 == bind (validated)
    inv = {}
    for gi, m in bind.items():
        iv = mat_invert(m)
        inv[gi] = iv if iv else mat_identity()

    bones = sm['bones']  # (bone_file#, first, count, weight)
    def skin(t):
        world = world_mats(t)
        acc = [[0.0]*3 for _ in range(vc)]
        wsum = [0.0]*vc
        for (bref, first, cnt, w) in bones:
            if bref not in world: continue
            sm_m = mat_mul(world[bref], inv[bref])
            wgt = w/1000.0 if w else 1.0
            for v in range(first, min(first+cnt, vc)):
                p = mat_mul_point(sm_m, (verts[v][0], verts[v][1], verts[v][2], 1.0))
                for c in range(3): acc[v][c] += wgt*p[c]
                wsum[v] += wgt
        out = []
        for v in range(vc):
            if wsum[v] > 1e-9:
                out.append(tuple(acc[v][c]/wsum[v] for c in range(3)))
            else:
                out.append(verts[v])
        return out

    print('== %s: %d verts, %d bindings, %d animated groups' % (path.split('/')[-1], vc, len(bones), len(anim)))
    for t in probe_times:
        sk = skin(t)
        if t == 0:
            err = max(math.sqrt(sum((sk[v][c]-verts[v][c])**2 for c in range(3))) for v in range(vc))
            print('  t=%3d (bind): max |skinned-original| = %.4f' % (t, err))
        else:
            disp = [math.sqrt(sum((sk[v][c]-verts[v][c])**2 for c in range(3))) for v in range(vc)]
            disp.sort()
            print('  t=%3d: displacement median=%.1f p90=%.1f max=%.1f  bbox=%s..%s' % (
                t, disp[vc//2], disp[int(vc*0.9)], disp[-1],
                ['%.0f'%min(s[c] for s in sk) for c in range(3)],
                ['%.0f'%max(s[c] for s in sk) for c in range(3)]))

if __name__ == '__main__':
    main(sys.argv[1])
