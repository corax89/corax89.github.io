#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 2. self-tests: SYSOUT vs stock v34.71 ----------
note "2) test49 + test58 (SYSOUT diff vs v34.71 stock)"
if [ -x "$AB_HEADLESS" ]; then
  for t in test49.jar test58.jar; do
    rm -rf /tmp/reg73/r1 /tmp/reg73/r2; mkdir -p /tmp/reg73/r1 /tmp/reg73/r2
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/r1 timeout 90 ./bin/j2me-headless --headless "games/$t" > /tmp/reg73/mine.log 2>&1
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/r2 timeout 90 "$AB_HEADLESS" --headless "games/$t" > /tmp/reg73/ab.log 2>&1
    if diff <(grep -E "SYSOUT|Loaded store" /tmp/reg73/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg73/ab.log) > /dev/null; then
      note "$t: IDENTICAL ($(grep -cE 'SYSOUT|Loaded store' /tmp/reg73/mine.log) lines)"
    else
      fail "$t: SYSOUT differs from v34.71"
      diff <(grep -E "SYSOUT|Loaded store" /tmp/reg73/mine.log) <(grep -E "SYSOUT|Loaded store" /tmp/reg73/ab.log) | head -6
    fi
  done
else
  note "2) skipped (no AB headless at $AB_HEADLESS)"
fi

# ---------- 3. Nescube ChoiceGroup E2E (pixel-exact checkbox toggle) ----------
note "3) Nescube ChoiceGroup E2E + RMS persistence"
rm -rf /tmp/reg73/rmsn /tmp/j2me_frame_*.ppm; mkdir -p /tmp/reg73/rmsn
NOJME_RMS_DIR=/tmp/reg73/rmsn NOJME_LOG=1 NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
  NOJME_HEADLESS_KEYSCRIPT="100:-5;500:-2;900:-5;1300:-5;2200:-5" \
  NOJME_HEADLESS_SNAP_FRAMES="2000,2600" \
  timeout 90 ./bin/j2me-headless --headless games/Nescube_V_2.3.jar > /tmp/reg73/nescube.log 2>&1
python3 - <<'EOF'
from PIL import Image, ImageChops
import sys, os
try:
    a = Image.open('/tmp/j2me_frame_02000.ppm').convert('RGB')
    b = Image.open('/tmp/j2me_frame_02600.ppm').convert('RGB')
    diff = ImageChops.difference(a, b)
    bbox = diff.getbbox()
    n = sum(1 for p in diff.getdata() if sum(p) > 30)
    print(f"[REG] Nescube FIRE diff bbox={bbox} pixels={n}")
    if bbox and bbox[0] < 20 and bbox[1] < 60 and n < 200:
        print("[REG] Nescube ChoiceGroup toggle: OK")
    else:
        print("[REG][FAIL] Nescube ChoiceGroup toggle unexpected diff")
        sys.exit(1)
    rms_dir = '/tmp/reg73/rmsn/Nescube_V_2.3'
    files = [f for f in os.listdir(rms_dir) if f.endswith('.rms')] if os.path.isdir(rms_dir) else []
    print(f"[REG] Nescube RMS stores on disk: {files}")
    if not files:
        print("[REG][FAIL] no RMS store persisted")
        sys.exit(1)
except Exception as e:
    print("[REG][FAIL] Nescube E2E:", e)
    sys.exit(1)
EOF
[ $? -ne 0 ] && fail "Nescube E2E"

echo "[REG] === reg_chunk3 result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
