#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 4. Asphalt 3 3D lr_run + FRAME_DIFF (thread sanity) ----------
note "4) Asphalt lr_run 900 frames, FRAME_DIFF (PACED)"
rm -rf /tmp/reg73/asph; mkdir -p /tmp/reg73/asph
PACED=1 FRAME_DIFF=1 timeout 150 ./bin/lr_run ./bin/nojme_libretro.so "games/Asphalt 3 3D (1.1.5).jar" 900 /tmp/reg73/asph 0 > /tmp/reg73/asph/run.log 2>&1
rc=$?
ok=$(grep -c "CAUGHT SIGNAL\|FATAL" /tmp/reg73/asph/run.log || true)
note "Asphalt: rc=$rc crash-markers=$ok $(grep FRAMEDIFF /tmp/reg73/asph/run.log | head -1)"
[ $rc -ne 0 ] && fail "Asphalt lr_run rc=$rc"
[ "$ok" -gt 0 ] && fail "Asphalt crash markers"

# ---------- 5. fmx A/B vs stock (thread interaction parity) ----------
if [ -x "$AB_HEADLESS" ]; then
  note "5) fmx A/B instructions (mine vs v34.71 stock, clean RMS each)"
  for tag in mine ab; do
    rm -rf /tmp/reg73/rmsf; mkdir -p /tmp/reg73/rmsf
    if [ "$tag" = "mine" ]; then BIN=./bin/j2me-headless; else BIN="$AB_HEADLESS"; fi
    NOJME_LOG=1 NOJME_RMS_DIR=/tmp/reg73/rmsf NOJME_HEADLESS_NOKEYS=1 NOJME_HEADLESS_IDLE=100 \
      timeout 150 $BIN --headless games/fmx.jar > /tmp/reg73/fmx_$tag.log 2>&1
    grep -oE "instructions=[0-9]+" /tmp/reg73/fmx_$tag.log | tail -1 | sed "s/^/[$tag] /"
  done
else
  note "5) skipped (no AB headless at $AB_HEADLESS)"
fi

echo "[REG] === reg_chunk4 result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
