#!/usr/bin/env python3
"""Software-render the N_2.m3g character (skinned, textured) from a side
angle at a given animation time, to visually verify the pose."""
import struct, sys, math
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_skin_space import parse, mat_identity, mat_mul, axis_angle_to_mat, scale_mat, trans_mat, decode_kf, quat_to_axis_angle

def mat_mul_point3(m, x, y, z):
    return (m[0][0]*x+m[0][1]*y+m[0][2]*z+m[0][3],
            m[1][0]*x+m[1][1]*y+m[1][2]*z+m[1][3],
            m[2][0]*x+m[2][1]*y+m[2][2]*z+m[2][3])

def mat_invert(m):
    a = [row[:] for row in m]
    inv = [[1.0 if i == j else 0.0 for j in range(4)] for i in range(4)]
    for col in range(4):
        piv = max(range(col, 4), key=lambda r: abs(a[r][col]))
        if abs(a[piv][col]) < 1e-12: return None
        a[col], a[piv] = a[piv], a[col]
        inv[col], inv[piv] = inv[piv], inv[col]
        d = a[col][col]
        a[col] = [x/d for x in a[col]]; inv[col] = [x/d for x in inv[col]]
        for r in range(4):
            if r != col and a[r][col] != 0:
                f = a[r][col]
                a[r] = [x-f*y for x, y in zip(a[r], a[col])]
                inv[r] = [x-f*y for x, y in zip(inv[r], inv[col])]
    return inv

def quat_slerp(p, q, t):
    d = sum(p[i]*q[i] for i in range(4))
    if d < 0:
        q = [-x for x in q]; d = -d
    if d > 0.9995:
        r = [(1-t)*p[i]+t*q[i] for i in range(4)]
    else:
        th = math.acos(d); s = math.sin(th)
        r = [math.sin((1-t)*th)/s*p[i]+math.sin(t*th)/s*q[i] for i in range(4)]
    n = math.sqrt(sum(x*x for x in r))
    return [x/n for x in r]

def lerp(a, b, t):
    return [a[i]+(b[i]-a[i])*t for i in range(len(a))]

def build(path, t):
    parsed, objs = parse(path)
    groups = {i+1: o for i, o in enumerate(parsed) if o['typename'] == 'GROUP'}
    sm = next(o for o in parsed if o['typename'] == 'SKINNEDMESH')
    vb = parsed[sm['vb_ref']-1]
    tv, vbody = objs[vb['pos_ref']-1]
    q = 4
    ntc = struct.unpack('<I', vbody[q:q+4])[0]; q += 4; q += 4*ntc
    nuo = struct.unpack('<I', vbody[q:q+4])[0]; q += 4
    for _ in range(nuo):
        q += 4; ln = struct.unpack('<I', vbody[q:q+4])[0]; q += 4+ln
    cs, cc, enc = vbody[q], vbody[q+1], vbody[q+2]
    vc = struct.unpack('<H', vbody[q+3:q+5])[0]
    raw = [struct.unpack('<b', vbody[q+5+(v*cc+c):q+5+(v*cc+c)+1])[0] for v in range(vc) for c in range(cc)]
    verts = [tuple(vb['bias'][c] + vb['scale']*raw[v*3+c] for c in range(3)) for v in range(vc)]

    PROP = {256:'SCALE', 268:'ORI', 275:'TRA'}
    anim = {}
    for gi, g in groups.items():
        for tr_ref in g.get('tracks', []):
            tr = parsed[tr_ref-1] if tr_ref else None
            if not tr or tr['typename'] != 'ANIMTRACK': continue
            seq = parsed[tr['seq_ref']-1]
            if seq['typename'] != 'KEYFRAMESEQ' or not seq.get('kfs'): continue
            pn = PROP.get(tr['property'])
            if pn: anim.setdefault(gi, {})[pn] = seq

    def local_matrix(gi, tt):
        g = groups[gi]
        an = anim.get(gi, {})
        if 'TRA' in an and an['TRA']['comp'] >= 3:
            seq = an['TRA']; kfs = seq['kfs']
            k = 0
            while k < len(kfs)-1 and kfs[k+1][0] <= tt: k += 1
            if k == len(kfs)-1:
                vals = decode_kf(kfs[k][1], seq['bias'], seq['scale'], 'u255')
            else:
                t0, t1 = kfs[k][0], kfs[k+1][0]
                f = (tt-t0)/(t1-t0) if t1 > t0 else 0.0
                vals = lerp(decode_kf(kfs[k][1], seq['bias'], seq['scale'], 'u255'),
                            decode_kf(kfs[k+1][1], seq['bias'], seq['scale'], 'u255'), f)
            tr = vals
        else:
            tr = list(g.get('t', (0, 0, 0)))
        if 'ORI' in an and an['ORI']['comp'] == 4:
            seq = an['ORI']; kfs = seq['kfs']
            k = 0
            while k < len(kfs)-1 and kfs[k+1][0] <= tt: k += 1
            def dq(kk): return decode_kf(kfs[kk][1], seq['bias'], seq['scale'], 'u255')
            if k == len(kfs)-1:
                quat = dq(k)
            else:
                t0, t1 = kfs[k][0], kfs[k+1][0]
                f = (tt-t0)/(t1-t0) if t1 > t0 else 0.0
                quat = quat_slerp(dq(k), dq(k+1), f)
            ang, ax, ay, az = quat_to_axis_angle(quat)
        else:
            ang, ax, ay, az = g.get('o', (0, 0, 0, 1))
        s = list(g.get('s', (1, 1, 1)))
        if s == [0, 0, 0]: s = [1, 1, 1]
        m = mat_mul(trans_mat(*tr), mat_mul(axis_angle_to_mat(ang, ax, ay, az), scale_mat(*s)))
        if 'g' in g:
            gm = [[g['g'][r*4+c] for c in range(4)] for r in range(4)]
            m = mat_mul(m, gm)
        return m

    children_map = {}; is_child = set()
    for idx, g in groups.items():
        for c in g.get('children', []):
            children_map.setdefault(idx, []).append(c); is_child.add(c)
    roots = [i for i in groups if i not in is_child]

    def world_mats(tt):
        world = {}
        stack = [(r, mat_identity()) for r in roots]
        while stack:
            idx, pm = stack.pop()
            world[idx] = mat_mul(pm, local_matrix(idx, tt))
            for c in children_map.get(idx, []):
                if c in groups: stack.append((c, world[idx]))
        return world

    bind = world_mats(0)
    inv = {gi: (mat_invert(m) or mat_identity()) for gi, m in bind.items()}

    world = world_mats(t)
    acc = [[0.0]*3 for _ in range(vc)]
    wsum = [0.0]*vc
    for (bref, first, cnt, w) in sm['bones']:
        if bref not in world: continue
        smat = mat_mul(world[bref], inv[bref])
        wgt = w/1000.0 if w else 1.0
        for v in range(first, min(first+cnt, vc)):
            p = mat_mul_point3(smat, *verts[v])
            for c in range(3): acc[v][c] += wgt*p[c]
            wsum[v] += wgt
    sk = [tuple(acc[v][c]/wsum[v] for c in range(3)) if wsum[v] > 1e-9 else verts[v] for v in range(vc)]

    # triangles from submesh TSAs (core dialect: encoding u8; 128/129/130 =
    # explicit u32/u8/u16 indices; then stripCount u32 + strip lengths u32;
    # implicit = firstIndex + running offset)
    tris = []
    for (ib_ref, app_ref) in sm['submeshes']:
        ti, ibody = objs[ib_ref - 1]
        q2 = 4
        ntc2 = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4; q2 += 4*ntc2
        nuo2 = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
        for _ in range(nuo2):
            q2 += 4; ln = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4+ln
        ienc = ibody[q2]; q2 += 1
        explicit = None
        first_index = 0
        if ienc in (128, 129, 130):
            cnt = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
            wd = {128: 4, 129: 1, 130: 2}[ienc]
            fmt = {128: '<I', 129: '<B', 130: '<H'}[ienc]
            explicit = [struct.unpack(fmt, ibody[q2+wd*k:q2+wd*k+wd])[0] for k in range(cnt)]
            q2 += wd*cnt
        elif ienc == 0:
            first_index = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
        elif ienc == 1:
            first_index = ibody[q2]; q2 += 1
        elif ienc == 2:
            first_index = struct.unpack('<H', ibody[q2:q2+2])[0]; q2 += 2
        strip_count = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
        strips = [struct.unpack('<I', ibody[q2+4*s:q2+4*s+4])[0] for s in range(strip_count)]
        voff = 0
        for slen in strips:
            if slen >= 3:
                for k in range(slen-2):
                    if explicit is not None:
                        i0, i1, i2 = explicit[voff+k], explicit[voff+k+1], explicit[voff+k+2]
                    else:
                        i0, i1, i2 = first_index+voff+k, first_index+voff+k+1, first_index+voff+k+2
                    tris.append((i0, i1, i2) if k % 2 == 0 else (i0, i2, i1))
            voff += slen
    return sk, tris, groups, world, inv

def render(path, t, out_png, yaw=90, pitch=15, W=400, H=500):
    from PIL import Image, ImageDraw
    sk, tris, groups, world, inv = build(path, t)
    # camera: rotate yaw around Y, pitch around X
    cy, sy = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    def proj(p):
        x, y, z = p
        x, z = x*cy - z*sy, x*sy + z*cy
        y, z2 = y*cp - z*sp, y*sp + z*cp
        d = 260.0
        if z2 >= d*0.9: z2 = d*0.9
        s = d/(d - z2)
        return (W/2 + x*s*2.2, H/2 - y*s*2.2)
    img = Image.new('RGB', (W, H), (30, 30, 40))
    dr = ImageDraw.Draw(img)
    # painter: sort by depth
    def depth(p):
        x, y, z = p
        x, z = x*cy - z*sy, x*sy + z*cy
        return y*sp + z*cp
    order = sorted(range(len(tris)), key=lambda i: -sum(depth(sk[v]) for v in tris[i])/3)
    for i in order:
        a, b, c = tris[i]
        pa, pb, pc = proj(sk[a]), proj(sk[b]), proj(sk[c])
        col = (140 + (i*7) % 60, 130 + (i*13) % 60, 120 + (i*29) % 60)
        dr.polygon([pa, pb, pc], fill=col, outline=(20, 20, 20))
    img.save(out_png)
    print('wrote %s (%d tris, t=%d)' % (out_png, len(tris), t))

if __name__ == '__main__':
    path = sys.argv[1]
    t = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    yaw = int(sys.argv[3]) if len(sys.argv) > 3 else 90
    out = sys.argv[4] if len(sys.argv) > 4 else '/tmp/char.png'
    render(path, t, out, yaw)
