/* A/B equivalence harness: decode 3GPP storage-format AMR-NB files with the
 * nojme_amrnb_* facade and dump raw PCM. Mirrors the frame walk in
 * src/midp/media.c amr_decode_to_wav() (same TOC parse, same bfi rule).
 *
 * Pass 1: real game files (BlackShark3D .amr resources).
 * Pass 2: synthetic deterministic frames covering FT 0..8, erasures,
 *         NO_DATA and invalid FTs — full decoder state-machine coverage.
 *
 * Usage: amr_ab <out.pcm> <in1.amr> [in2.amr ...]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "amr_nb_dec.h"

static const uint8_t amrnb_ft_payload[16] = {
    12, 13, 15, 17, 19, 20, 26, 31, 5, 0, 0, 0, 0, 0, 0, 0
};

static uint64_t fnv1a(const uint8_t* p, size_t n) {
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
    return h;
}

static void decode_file(const char* path, FILE* out) {
    FILE* f = fopen(path, "rb");
    if (!f) { perror(path); exit(2); }
    fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t* data = malloc(sz);
    if (fread(data, 1, sz, f) != (size_t)sz) { perror("fread"); exit(2); }
    fclose(f);

    if (sz < 7 || memcmp(data, "#!AMR", 5) != 0) {
        fprintf(stderr, "%s: bad magic\n", path); exit(1);
    }

    void* dec = nojme_amrnb_dec_init();
    if (!dec) { fprintf(stderr, "dec_init failed\n"); exit(1); }

    uint32_t pos = 6, frames = 0, bfi = 0;
    short pcm[NOJME_AMRNB_PCMDIM];

    while (pos < (uint32_t)sz) {
        uint8_t toc = data[pos];
        uint8_t ft = (toc >> 3) & 0x0F;
        uint32_t payload = (ft <= 8) ? amrnb_ft_payload[ft] : 0;
        if (pos + 1 + payload > (uint32_t)sz) break; /* truncated tail */
        int b = (ft >= 9 && ft <= 14) ? 1 : 0;   /* media.c rule */
        nojme_amrnb_decode(dec, &data[pos], pcm, b);
        fwrite(pcm, sizeof(short), NOJME_AMRNB_PCMDIM, out);
        pos += 1 + payload;
        frames++; bfi += (uint32_t)b;
    }
    nojme_amrnb_dec_exit(dec);
    printf("%-22s %6ld B  %4u frames (%u bfi)  src=%016llx\n",
           path, sz, frames, bfi, (unsigned long long)fnv1a(data, (size_t)sz));
    free(data);
}

/* Deterministic synthetic stream: 6 rounds over FT 0..8 (100 frames each),
 * with periodic erasure (bfi=1) and invalid-FT (9..14 -> NO_DATA path)
 * sprinkled in. Exercises every codec mode + DTX + concealment. */
static void decode_synth(FILE* out) {
    static uint32_t lcg = 0x12345678u;
    void* dec = nojme_amrnb_dec_init();
    if (!dec) { fprintf(stderr, "synth dec_init failed\n"); exit(1); }

    short pcm[NOJME_AMRNB_PCMDIM];
    uint8_t frame[32];
    uint32_t n = 0;

    for (int round = 0; round < 6; round++) {
        for (int ft = 0; ft <= 8; ft++) {
            for (int k = 0; k < 100; k++) {
                uint32_t payload = amrnb_ft_payload[ft];
                /* TOC: F=0, FT, Q=1, pad 0 */
                frame[0] = (uint8_t)((ft << 3) | 0x04);
                for (uint32_t i = 0; i < payload; i++) {
                    lcg = lcg * 1103515245u + 12345u;
                    frame[1 + i] = (uint8_t)(lcg >> 16);
                }
                /* every 7th frame: simulate erasure (bfi=1) */
                int b = ((n % 7) == 3) ? 1 : 0;
                nojme_amrnb_decode(dec, frame, pcm, b);
                fwrite(pcm, sizeof(short), NOJME_AMRNB_PCMDIM, out);
                n++;
            }
        }
        /* invalid FT 9..14 as erasure frames (media.c rule), FT 15 NO_DATA */
        for (int ft = 9; ft <= 15; ft++) {
            frame[0] = (uint8_t)((ft << 3) | 0x04);
            nojme_amrnb_decode(dec, frame, pcm, (ft >= 9 && ft <= 14) ? 1 : 0);
            fwrite(pcm, sizeof(short), NOJME_AMRNB_PCMDIM, out);
            n++;
        }
    }
    nojme_amrnb_dec_exit(dec);
    printf("synthetic:             %u frames (FT0..8 x600, invalid/NO_DATA)\n", n);
}

int main(int argc, char** argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s out.pcm in.amr...\n", argv[0]); return 2; }

    FILE* out = fopen(argv[1], "wb");
    if (!out) { perror("fopen out"); return 2; }

    for (int a = 2; a < argc; a++) decode_file(argv[a], out);
    decode_synth(out);
    fclose(out);

    FILE* pf = fopen(argv[1], "rb");
    fseek(pf, 0, SEEK_END); long pn = ftell(pf); fseek(pf, 0, SEEK_SET);
    uint8_t* pcm_all = malloc(pn ? pn : 1);
    if (fread(pcm_all, 1, pn, pf) != (size_t)pn) { perror("fread pcm"); return 2; }
    fclose(pf);
    printf("PCM: %ld bytes total\n", pn);
    printf("PCM FNV-1a: %016llx\n", (unsigned long long)fnv1a(pcm_all, (size_t)pn));
    free(pcm_all);
    return 0;
}
