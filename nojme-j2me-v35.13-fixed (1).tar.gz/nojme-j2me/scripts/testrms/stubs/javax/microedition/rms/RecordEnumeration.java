package javax.microedition.rms;

public interface RecordEnumeration {
    void destroy();
    boolean hasNextElement();
    boolean hasPreviousElement();
    boolean isKeptUpdated();
    void keepUpdated(boolean keepUpdated);
    byte[] nextRecord() throws RecordStoreException, InvalidRecordIDException;
    int nextRecordId() throws RecordStoreException, InvalidRecordIDException;
    int numRecords();
    byte[] previousRecord() throws RecordStoreException, InvalidRecordIDException;
    int previousRecordId() throws RecordStoreException, InvalidRecordIDException;
    void rebuild();
    void reset();
}
