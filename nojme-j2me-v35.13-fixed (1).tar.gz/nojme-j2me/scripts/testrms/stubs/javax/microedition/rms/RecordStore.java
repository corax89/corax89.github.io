package javax.microedition.rms;

public class RecordStore {
    public static final int AUTHMODE_PRIVATE = 0;
    public static final int AUTHMODE_ANY = 1;

    public static RecordStore openRecordStore(String recordStoreName, boolean createIfNecessary)
        throws RecordStoreException, RecordStoreNotFoundException { return null; }
    public static RecordStore openRecordStore(String recordStoreName, boolean createIfNecessary,
        int authmode, boolean writable)
        throws RecordStoreException, RecordStoreNotFoundException { return null; }
    public static RecordStore openRecordStore(String recordStoreName, String vendorName, String suiteName)
        throws RecordStoreException, RecordStoreNotFoundException { return null; }
    public static String[] listRecordStores() { return null; }
    public static void deleteRecordStore(String recordStoreName)
        throws RecordStoreException, RecordStoreNotFoundException { }

    public void closeRecordStore() throws RecordStoreException, RecordStoreNotOpenException { }
    public String getName() throws RecordStoreException, RecordStoreNotOpenException { return null; }
    public int addRecord(byte[] data, int offset, int numBytes)
        throws RecordStoreException, RecordStoreNotOpenException, RecordStoreFullException { return 0; }
    public void setRecord(int recordId, byte[] newData, int offset, int numBytes)
        throws RecordStoreException, RecordStoreNotOpenException, InvalidRecordIDException { }
    public void deleteRecord(int recordId)
        throws RecordStoreException, RecordStoreNotOpenException, InvalidRecordIDException { }
    public byte[] getRecord(int recordId)
        throws RecordStoreException, RecordStoreNotOpenException, InvalidRecordIDException { return null; }
    public int getRecord(int recordId, byte[] buffer, int offset)
        throws RecordStoreException, RecordStoreNotOpenException, InvalidRecordIDException { return 0; }
    public int getRecordSize(int recordId)
        throws RecordStoreException, RecordStoreNotOpenException, InvalidRecordIDException { return 0; }
    public int getNextRecordID() throws RecordStoreException, RecordStoreNotOpenException { return 0; }
    public int getNumRecords() throws RecordStoreException, RecordStoreNotOpenException { return 0; }
    public long getSize() throws RecordStoreException, RecordStoreNotOpenException { return 0L; }
    public int getSizeAvailable() throws RecordStoreException, RecordStoreNotOpenException { return 0; }
    public long getLastModified() throws RecordStoreException, RecordStoreNotOpenException { return 0L; }
    public int getVersion() throws RecordStoreException, RecordStoreNotOpenException { return 0; }
    public void setMode(int authmode, boolean writable)
        throws RecordStoreException, RecordStoreNotOpenException { }
    public void addRecordListener(RecordListener listener) { }
    public void removeRecordListener(RecordListener listener) { }
    public RecordEnumeration enumerateRecords(RecordFilter filter, RecordComparator comparator,
        boolean keepUpdated) throws RecordStoreException { return null; }
}
