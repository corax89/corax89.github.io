import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.rms.RecordComparator;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordFilter;
import javax.microedition.rms.RecordListener;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreFullException;
import javax.microedition.rms.RecordStoreNotFoundException;
import javax.microedition.rms.RecordStoreNotOpenException;
import javax.microedition.rms.InvalidRecordIDException;

/* TestRMS — JSR 118 (MIDP 2.0) RMS spec-compliance suite.
 * Prints "R:<id> PASS/FAIL <detail>" lines and a final RMS:DONE marker.
 * Phases: A basic ops, B open/close/refcount, C enumeration (the critical
 * nextRecordId/nextRecord semantics), D keepUpdated/listeners/store delete.
 */
public class TestRMS extends MIDlet implements RecordListener {
    static int pass = 0, fail = 0;

    static void chk(String id, boolean cond, String detail) {
        if (cond) { pass++; System.out.println("R:" + id + " PASS " + detail); }
        else      { fail++; System.out.println("R:" + id + " FAIL " + detail); }
    }

    static String cls(Throwable t) {
        String c = t.getClass().getName();
        int d = c.lastIndexOf('.');
        return d >= 0 ? c.substring(d + 1) : c;
    }

    /* listener counters */
    int evAdded = 0, evChanged = 0, evDeleted = 0, evLastId = -1;

    public void recordAdded(RecordStore rs, int id)   { evAdded++;   evLastId = id; }
    public void recordChanged(RecordStore rs, int id) { evChanged++; evLastId = id; }
    public void recordDeleted(RecordStore rs, int id) { evDeleted++; evLastId = id; }

    static byte[] b(String s) { return s.getBytes(); }
    static String s(byte[] d) { return d == null ? "<null>" : new String(d); }

    protected void startApp() throws MIDletStateChangeException {
        System.out.println("RMS-TEST-START");
        phaseA();
        phaseB();
        phaseC();
        phaseD();
        System.out.println("RMS:DONE " + pass + "/" + fail);
        notifyDestroyed();
    }

    protected void pauseApp() { }
    protected void destroyApp(boolean u) throws MIDletStateChangeException { }

    /* ---------- Phase A: basic operations ---------- */
    void phaseA() {
        try {
            RecordStore.deleteRecordStore("TRS");
        } catch (Exception e) { }

        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore("TRS", true);
        } catch (Exception e) {
            System.out.println("R:A0 FAIL open " + cls(e));
            return;
        }
        try {
            // A1: fresh store
            chk("A1", rs.getNextRecordID() == 1 && rs.getNumRecords() == 0,
                "fresh: nextId=" + rs.getNextRecordID() + " num=" + rs.getNumRecords());

            // A2: three records
            int id1 = rs.addRecord(b("uno"), 0, 3);
            int id2 = rs.addRecord(b("two"), 0, 3);
            int id3 = rs.addRecord(b("three"), 0, 5);
            chk("A2", id1 == 1 && id2 == 2 && id3 == 3 && rs.getNumRecords() == 3
                    && rs.getNextRecordID() == 4,
                "ids " + id1 + "," + id2 + "," + id3 + " num=" + rs.getNumRecords()
                + " nextId=" + rs.getNextRecordID());

            // A3: roundtrip
            byte[] g = rs.getRecord(2);
            chk("A3", g != null && g.length == 3 && s(g).equals("two") && rs.getRecordSize(2) == 3,
                "getRecord(2)='" + s(g) + "' size=" + rs.getRecordSize(2));

            // A4: null data with numBytes==0 -> empty record (spec allows)
            int id4 = -1;
            String a4e = "-";
            try { id4 = rs.addRecord(null, 0, 0); }
            catch (Throwable t) { a4e = cls(t); }
            byte[] g4 = null;
            int sz4 = -1;
            try { g4 = rs.getRecord(id4); sz4 = rs.getRecordSize(id4); } catch (Throwable t) { }
            chk("A4", a4e.equals("-") && id4 == 4 && g4 != null && g4.length == 0 && sz4 == 0,
                "addRecord(null,0,0): id=" + id4 + " exc=" + a4e
                + " len=" + (g4 == null ? -1 : g4.length) + " size=" + sz4);

            // A5: setRecord replace
            rs.setRecord(1, b("new"), 0, 3);
            byte[] g1 = rs.getRecord(1);
            chk("A5", g1 != null && s(g1).equals("new"), "setRecord(1)='" + s(g1) + "'");

            // A6: setRecord(id, null, 0, 0) -> empty
            String a6e = "-";
            try { rs.setRecord(4, null, 0, 0); } catch (Throwable t) { a6e = cls(t); }
            byte[] g4b = null;
            try { g4b = rs.getRecord(4); } catch (Throwable t) { }
            chk("A6", a6e.equals("-") && g4b != null && g4b.length == 0,
                "setRecord(4,null,0,0): exc=" + a6e + " len=" + (g4b == null ? -1 : g4b.length));

            // A7: delete + InvalidRecordIDException on stale id
            int v0 = rs.getVersion();
            rs.deleteRecord(2);
            String e1 = "-", e2 = "-", e3 = "-", e4 = "-";
            try { rs.getRecord(2); } catch (Throwable t) { e1 = cls(t); }
            try { rs.getRecordSize(2); } catch (Throwable t) { e2 = cls(t); }
            try { rs.setRecord(2, b("x"), 0, 1); } catch (Throwable t) { e3 = cls(t); }
            try { rs.deleteRecord(2); } catch (Throwable t) { e4 = cls(t); }
            chk("A7", rs.getNumRecords() == 3 && e1.equals("InvalidRecordIDException")
                    && e2.equals("InvalidRecordIDException") && e3.equals("InvalidRecordIDException")
                    && e4.equals("InvalidRecordIDException"),
                "del: num=" + rs.getNumRecords() + " get=" + e1 + " size=" + e2
                + " set=" + e3 + " del=" + e4);

            // A8: IDs never reused
            int id5 = rs.addRecord(b("five"), 0, 4);
            chk("A8", id5 == 5, "addRecord after delete -> id " + id5 + " (never reuse 2)");

            // A9: getRecord(id, buffer, offset)
            byte[] buf = new byte[16];
            int n = rs.getRecord(5, buf, 2);
            String got = new String(buf, 2, n);
            String a9e = "-";
            try { rs.getRecord(5, new byte[2], 0); } catch (Throwable t) { a9e = cls(t); }
            String a9n = "-";
            try { rs.getRecord(5, null, 0); } catch (Throwable t) { a9n = cls(t); }
            chk("A9", n == 4 && got.equals("five") && a9e.equals("ArrayIndexOutOfBoundsException")
                    && a9n.equals("NullPointerException"),
                "copy: n=" + n + " '" + got + "' small=" + a9e + " null=" + a9n);

            // A10: version increments on add/set/delete only
            int v1 = rs.getVersion();
            rs.setRecord(1, b("NEW"), 0, 3);
            rs.addRecord(b("six"), 0, 3);
            rs.deleteRecord(6);
            int v2 = rs.getVersion();
            chk("A10", (v1 - v0) >= 1 && (v2 - v1) == 3,
                "version: v0=" + v0 + " v1=" + v1 + " v2=" + v2 + " (delta add/set/del=3)");

            // A11: metadata
            long lm = rs.getLastModified();
            long size = rs.getSize();
            int avail = rs.getSizeAvailable();
            String nm = rs.getName();
            chk("A11", lm > 0 && size > 0 && avail > 0 && "TRS".equals(nm),
                "meta: lm=" + lm + " size=" + size + " avail=" + avail + " name=" + nm);

            // release this handle so Phase B refcounting starts from zero
            rs.closeRecordStore();
        } catch (Throwable t) {
            System.out.println("R:AX FAIL unexpected " + cls(t) + " " + t.getMessage());
        }
    }

    /* ---------- Phase B: close / reopen / refcount ---------- */
    void phaseB() {
        try {
            // B1: two handles, close one
            RecordStore rs1 = RecordStore.openRecordStore("TRS", true);
            RecordStore rs2 = RecordStore.openRecordStore("TRS", true);
            rs1.closeRecordStore();
            String b1e = "-";
            try { rs2.addRecord(b("still-open"), 0, 10); }
            catch (Throwable t) { b1e = cls(t); }
            chk("B1", b1e.equals("-"), "after close(rs1): rs2 addRecord exc=" + b1e);

            // B2: close last -> closed (id8: six=6 was added+deleted in A10,
            // still-open=7, so this one is 8 — IDs are never reused)
            int id8 = -1;
            try { id8 = rs2.addRecord(b("last"), 0, 4); } catch (Throwable t) { }
            rs2.closeRecordStore();
            String b2e = "-";
            try { rs2.addRecord(b("x"), 0, 1); } catch (Throwable t) { b2e = cls(t); }
            String b2c = "-";
            try { rs2.closeRecordStore(); } catch (Throwable t) { b2c = cls(t); }
            chk("B2", id8 == 8 && b2e.equals("RecordStoreNotOpenException")
                    && b2c.equals("RecordStoreNotOpenException"),
                "closed: id8=" + id8 + " add=" + b2e + " dblclose=" + b2c);

            // B3: reopen without create -> data intact, ids monotonic
            RecordStore rs = RecordStore.openRecordStore("TRS", false);
            byte[] g5 = rs.getRecord(5);
            int nid = rs.getNextRecordID();
            chk("B3", rs.getNumRecords() == 6 && g5 != null && s(g5).equals("five") && nid == 9,
                "reopen: num=" + rs.getNumRecords() + " rec5='" + s(g5) + "' nextId=" + nid);

            // B4: missing store, create=false
            String b4e = "-";
            try { RecordStore.openRecordStore("NOSUCH", false); }
            catch (Throwable t) { b4e = cls(t); }
            chk("B4", b4e.equals("RecordStoreNotFoundException"), "open(NOSUCH,false) -> " + b4e);

            // B5: bad names
            String b5a = "-", b5b = "-", b5c = "-";
            try { RecordStore.openRecordStore("0123456789012345678901234567890123", true); }
            catch (Throwable t) { b5a = cls(t); }
            try { RecordStore.openRecordStore("", true); }
            catch (Throwable t) { b5b = cls(t); }
            try { RecordStore.openRecordStore(null, true); }
            catch (Throwable t) { b5c = cls(t); }
            chk("B5", b5a.equals("RecordStoreException") && b5b.equals("RecordStoreException")
                    && b5c.equals("NullPointerException"),
                "names: long33=" + b5a + " empty=" + b5b + " null=" + b5c);

            // B6: listRecordStores
            String[] names = RecordStore.listRecordStores();
            boolean found = false;
            if (names != null) {
                for (int i = 0; i < names.length; i++) if ("TRS".equals(names[i])) found = true;
            }
            chk("B6", found, "listRecordStores contains TRS: " + found);

            // B7: authmode overload does not clobber writable of an EXISTING store
            RecordStore rsr = null;
            String b7e = "-";
            try {
                rsr = RecordStore.openRecordStore("TRS", true, RecordStore.AUTHMODE_PRIVATE, false);
            } catch (Throwable t) { b7e = cls(t); }
            String b7w = "-";
            try { rsr.setRecord(5, b("five"), 0, 4); } catch (Throwable t) { b7w = cls(t); }
            chk("B7", b7e.equals("-") && b7w.equals("-"),
                "authmode-open(existing): open=" + b7e + " setRecord=" + b7w
                + " (spec: mode args apply only at creation)");
            try { rsr.closeRecordStore(); } catch (Throwable t) { }
            // close the Phase-B "rs" handle so Phase D starts from refcount 0
            try { rs.closeRecordStore(); } catch (Throwable t) { }
        } catch (Throwable t) {
            System.out.println("R:BX FAIL unexpected " + cls(t) + " " + t.getMessage());
        }
    }

    /* ---------- Phase C: RecordEnumeration ---------- */
    void phaseC() {
        try {
            RecordStore rs = RecordStore.openRecordStore("TRS", false);
            // store state: ids 1(NEW),3(three),4(),5(five),7(last) + "still-open"=id6? see B1
            int num = rs.getNumRecords();

            // C1: THE canonical idiom — id/data must pair up, every record visited
            RecordEnumeration e = rs.enumerateRecords(null, null, false);
            int seen = 0;
            boolean pairsOk = true;
            StringBuilder idsS = new StringBuilder();
            while (e.hasNextElement()) {
                int id = e.nextRecordId();
                byte[] d = e.nextRecord();
                idsS.append(id).append(' ');
                seen++;
                boolean ok = false;
                try { ok = s(rs.getRecord(id)).equals(s(d)); } catch (Throwable t) { }
                if (!ok) pairsOk = false;
            }
            chk("C1", seen == num && pairsOk,
                "canonical loop: seen " + seen + "/" + num + " pairsOk=" + pairsOk
                + " ids=[" + idsS + "]");

            // C2: nextRecordId is a PEEK (does not advance)
            RecordEnumeration e2 = rs.enumerateRecords(null, null, false);
            int a = e2.nextRecordId();
            int bb = e2.nextRecordId();
            chk("C2", a == bb, "peek: 1st=" + a + " 2nd=" + bb + " (must be equal)");

            // C3: nextRecord()-only loop
            RecordEnumeration e3 = rs.enumerateRecords(null, null, false);
            int seen3 = 0;
            int firstId = -1;
            while (e3.hasNextElement()) {
                int id = e3.nextRecordId();
                byte[] d = e3.nextRecord();
                if (firstId < 0) firstId = id;
                seen3++;
            }
            chk("C3", seen3 == num && firstId == 1, "nextRecord loop: seen=" + seen3
                + " firstId=" + firstId);

            // C4: filter
            RecordEnumeration e4 = rs.enumerateRecords(new RecordFilter() {
                public boolean matches(byte[] c) { return c != null && c.length > 3; }
            }, null, false);
            int fseen = 0;
            while (e4.hasNextElement()) { e4.nextRecord(); fseen++; }
            chk("C4", f4Expected(num) == fseen, "filter len>3: seen=" + fseen + " expected=" + f4Expected(num));

            // C5: comparator (descending first byte)
            RecordEnumeration e5 = rs.enumerateRecords(null, new RecordComparator() {
                public int compare(byte[] r1, byte[] r2) {
                    int a1 = (r1 != null && r1.length > 0) ? (r1[0] & 0xFF) : 0;
                    int b1 = (r2 != null && r2.length > 0) ? (r2[0] & 0xFF) : 0;
                    if (a1 == b1) return RecordComparator.EQUIVALENT;
                    return (b1 > a1) ? RecordComparator.FOLLOWS : RecordComparator.PRECEDES;
                }
            }, false);
            int prevFirst = 256;
            boolean desc = true;
            int cseen = 0;
            while (e5.hasNextElement()) {
                byte[] d = e5.nextRecord();
                int f = (d != null && d.length > 0) ? (d[0] & 0xFF) : 0;
                if (f > prevFirst) desc = false;
                prevFirst = f;
                cseen++;
            }
            chk("C5", desc && cseen == num, "comparator desc: seen=" + cseen + " desc=" + desc);

            // C6: exhaustion throws
            RecordEnumeration e6 = rs.enumerateRecords(null, null, false);
            while (e6.hasNextElement()) e6.nextRecord();
            String c6a = "-", c6b = "-";
            try { e6.nextRecord(); } catch (Throwable t) { c6a = cls(t); }
            try { e6.nextRecordId(); } catch (Throwable t) { c6b = cls(t); }
            chk("C6", c6a.equals("InvalidRecordIDException") && c6b.equals("InvalidRecordIDException"),
                "exhausted: next=" + c6a + " nextId=" + c6b);

            // C7: previousRecord / reset / hasPreviousElement
            // (after next,next the cursor is past BOTH records; previousRecord
            //  returns the record just before the cursor = the SECOND one)
            RecordEnumeration e7 = rs.enumerateRecords(null, null, false);
            int fId = e7.nextRecordId();
            e7.nextRecord();
            int sId = e7.nextRecordId();
            e7.nextRecord();
            byte[] pv = e7.previousRecord();
            boolean pvOk = false;
            try { pvOk = s(rs.getRecord(sId)).equals(s(pv)); } catch (Throwable t) { }
            boolean hasPrevAtStart = false;
            e7.reset();
            hasPrevAtStart = e7.hasPreviousElement();
            int rId = e7.nextRecordId();
            chk("C7", pvOk && !hasPrevAtStart && rId == fId,
                "prev: back-step ok=" + pvOk + " hasPrev@start=" + hasPrevAtStart
                + " after reset nextId=" + rId);

            // C8: numRecords
            RecordEnumeration e8 = rs.enumerateRecords(null, null, false);
            chk("C8", e8.numRecords() == num, "numRecords=" + e8.numRecords() + "/" + num);

            // C9: previousRecordId peek
            RecordEnumeration e9 = rs.enumerateRecords(null, null, false);
            e9.nextRecord(); /* consume 1st */
            int p1 = e9.previousRecordId();
            int p2 = e9.previousRecordId();
            byte[] pd = e9.previousRecord();
            boolean pOk = false;
            try { pOk = s(rs.getRecord(p1)).equals(s(pd)); } catch (Throwable t) { }
            chk("C9", p1 == p2 && pOk, "prevId peek: " + p1 + "/" + p2 + " pairOk=" + pOk);

            rs.closeRecordStore();
        } catch (Throwable t) {
            System.out.println("R:CX FAIL unexpected " + cls(t) + " " + t.getMessage());
        }
    }

    int f4Expected(int num) {
        // records with length>3: NEW(3, no) three(5, yes) four-empty(0, no) five(4, yes)
        // still-open(10, yes) last(4, yes)  -> depends on live set; count live long ones
        return 4; // three, five, still-open, last
    }

    /* ---------- Phase D: keepUpdated / listeners / deleteRecordStore ---------- */
    void phaseD() {
        try {
            RecordStore rs = RecordStore.openRecordStore("TRS", false);
            int num = rs.getNumRecords();

            // D1: snapshot enumeration (keepUpdated=false)
            RecordEnumeration e = rs.enumerateRecords(null, null, false);
            int idX = rs.addRecord(b("zz-extra"), 0, 8);
            chk("D1", e.numRecords() == num, "snapshot: enum num=" + e.numRecords()
                + " (store now " + rs.getNumRecords() + ")");
            rs.deleteRecord(idX); // cleanup

            // D2: keepUpdated=true reflects mutation
            RecordEnumeration e2 = rs.enumerateRecords(null, null, true);
            int idY = rs.addRecord(b("zz-live"), 0, 7);
            boolean grew = e2.numRecords() == num + 1;
            rs.deleteRecord(idY);
            boolean shrunk = e2.numRecords() == num;
            chk("D2", grew && shrunk, "keepUpdated: grew=" + grew + " shrunk=" + shrunk);
            e2.destroy();

            // D3: listeners ("zz-l"/"zz-m"/"zz-x" are 4 bytes)
            rs.addRecordListener(this);
            int idZ = rs.addRecord(b("zz-l"), 0, 4);
            rs.setRecord(idZ, b("zz-m"), 0, 4);
            rs.deleteRecord(idZ);
            rs.removeRecordListener(this);
            int idZ2 = rs.addRecord(b("zz-x"), 0, 4); // must NOT fire after remove
            rs.deleteRecord(idZ2);
            chk("D3", evAdded == 1 && evChanged == 1 && evDeleted == 1 && evLastId == idZ,
                "listener: add=" + evAdded + " chg=" + evChanged + " del=" + evDeleted
                + " lastId=" + evLastId);

            // D4: deleteRecordStore while open -> RecordStoreException
            String d4e = "-";
            try { RecordStore.deleteRecordStore("TRS"); } catch (Throwable t) { d4e = cls(t); }
            rs.closeRecordStore();
            String d4ok = "-";
            try { RecordStore.deleteRecordStore("TRS"); d4ok = "OK"; } catch (Throwable t) { d4ok = cls(t); }
            String d4gone = "-";
            try { RecordStore.openRecordStore("TRS", false); }
            catch (Throwable t) { d4gone = cls(t); }
            chk("D4", d4e.equals("RecordStoreException") && d4ok.equals("OK")
                    && d4gone.equals("RecordStoreNotFoundException"),
                "deleteStore: open=" + d4e + " closed=" + d4ok + " after=" + d4gone);

            // D5: delete of a missing store
            String d5e = "-";
            try { RecordStore.deleteRecordStore("TRS-GONE"); } catch (Throwable t) { d5e = cls(t); }
            chk("D5", d5e.equals("RecordStoreNotFoundException"), "delete missing -> " + d5e);

            // D6: fresh store after delete: next id restarts at 1 (new store)
            RecordStore rs2 = RecordStore.openRecordStore("TRS2", true);
            int nid = rs2.getNextRecordID();
            int nidAdd = rs2.addRecord(b("q"), 0, 1);
            rs2.closeRecordStore();
            RecordStore.deleteRecordStore("TRS2");
            chk("D6", nid == 1 && nidAdd == 1, "recreated store: nextId=" + nid + " first=" + nidAdd);
        } catch (Throwable t) {
            System.out.println("R:DX FAIL unexpected " + cls(t) + " " + t.getMessage());
        }
    }
}
