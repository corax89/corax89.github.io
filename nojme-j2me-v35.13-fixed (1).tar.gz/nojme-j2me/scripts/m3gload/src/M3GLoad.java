import javax.microedition.midlet.*;
import javax.microedition.m3g.*;
import java.io.InputStream;

/* M3G file-loader audit selftest (v34.70).
 * Loads REAL game-exported .m3g files packaged in this jar through BOTH
 * spec entry points — Loader.load(String) and Loader.load(byte[], int) —
 * and prints a deterministic structural digest (floats printed as
 * (int)(f*1000), like TestCam):
 *   /bs.m3g     BlackShark3D assets.m3g  (H3T, zlib sections, 15 SkinnedMesh,
 *                                         156 Groups, palette Image2D, TSA enc 129/130)
 *   /pers.m3g   Stalker pers.m3g         (H3T, 2 unresolved external refs)
 *   /forest.m3g Stalker ForestDecors.m3g (H3T, Background with color R=60,G=106,B=199)
 *   /role.m3g   Quake role.m3g           (H3T, uncompressed sections, ext ref, 1 SkinMesh)
 *   /r103.bin   FMX M3GToolkit model     (mesh-only file: fabricated World,
 *                                         roots must contain the Mesh, NOT a World)
 * The byte[] path must print the SAME structural facts as the String path.
 */
public class M3GLoad extends MIDlet {

    private static void p(String s) { System.out.println(s); }
    private static int i(float f) { return (int)(f * 1000.0f); }

    public void startApp() {
        p("M3GLOAD v1");
        try { test("/bs.m3g"); } catch (Throwable t) { p("ERR bs " + t); }
        try { test("/pers.m3g"); } catch (Throwable t) { p("ERR pers " + t); }
        try { test("/forest.m3g"); } catch (Throwable t) { p("ERR forest " + t); }
        try { test("/role.m3g"); } catch (Throwable t) { p("ERR role " + t); }
        try { test("/r103.bin"); } catch (Throwable t) { p("ERR r103 " + t); }
        try { testBytes("/bs.m3g"); } catch (Throwable t) { p("ERR bsbytes " + t); }
        try { testBytes("/role.m3g"); } catch (Throwable t) { p("ERR rolebytes " + t); }
        try { testBytes("/forest.m3g"); } catch (Throwable t) { p("ERR forestbytes " + t); }
        p("M3GLOAD DONE");
        notifyDestroyed();
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}

    private static String cls(Object o) {
        String s = o.getClass().getName();
        int d = s.lastIndexOf('.');
        return d >= 0 ? s.substring(d + 1) : s;
    }

    private void test(String name) {
        Object3D[] roots = Loader.load(name);
        if (roots == null) { p(name + " roots=null"); return; }
        p(name + " roots=" + roots.length);
        for (int i = 0; i < roots.length; i++)
            p("  root" + i + " " + cls(roots[i]) + " uid=" + roots[i].getUserID());

        World w = null;
        for (int i = 0; i < roots.length; i++)
            if (roots[i] instanceof World) { w = (World) roots[i]; break; }
        if (w == null) { p("  noworld children=-1"); if (roots.length > 0) dumpMeshish(roots[0]); return; }

        p("  children=" + w.getChildCount());
        Camera c = w.getActiveCamera();
        if (c != null) {
            float[] pr = new float[4];
            int pt = c.getProjection(pr);
            p("  cam uid=" + c.getUserID() + " proj=" + pt + " p0=" + i(pr[0])
              + " p2=" + i(pr[2]) + " p3=" + i(pr[3]));
        } else p("  cam=null");

        Background bg = w.getBackground();
        if (bg != null) {
            p("  bg uid=" + bg.getUserID() + " color=0x" + Integer.toHexString(bg.getColor())
              + " modeX=" + bg.getImageModeX() + " crop=" + bg.getCropX() + "," + bg.getCropY()
              + "," + bg.getCropWidth() + "," + bg.getCropHeight());
        } else p("  bg=null");

        dumpMeshish(w);

        if (w.getChildCount() > 0) {
            Node n0 = w.getChild(0);
            int tc = n0.getAnimationTrackCount();
            p("  child0 " + cls(n0) + " uid=" + n0.getUserID() + " tracks=" + tc);
            for (int i = 0; i < 2 && i < tc; i++) dumpTrack(n0.getAnimationTrack(i), "   t" + i);
        }
        /* find the AnimationController by userID range: H3T corpus has exactly
         * one AC per file; scan world children deep is overkill — use find()
         * on a few plausible IDs, print the first that resolves. */
        for (int uid = 1; uid < 400; uid++) {
            Object3D o = w.find(uid);
            if (o instanceof AnimationController) {
                AnimationController ac = (AnimationController) o;
                p("  ac uid=" + uid + " speed=" + i(ac.getSpeed()) + " weight=" + i(ac.getWeight())
                  + " refwt=" + ac.getRefWorldTime());
                break;
            }
        }
    }

    private void dumpMeshish(Object root) {
        /* Mesh facts from the first Mesh we can reach (root itself, or first
         * world child, or first SkinnedMesh in the roots). */
        Mesh m = null;
        if (root instanceof Mesh) m = (Mesh) root;
        else if (root instanceof World) {
            World w = (World) root;
            for (int i = 0; i < w.getChildCount() && m == null; i++) {
                Node n = w.getChild(i);
                if (n instanceof Mesh) m = (Mesh) n;
                else if (n instanceof Group) {
                    Group g = (Group) n;
                    for (int j = 0; j < g.getChildCount() && m == null; j++)
                        if (g.getChild(j) instanceof Mesh) m = (Mesh) g.getChild(j);
                }
            }
        }
        if (m == null) { p("  nomesh"); return; }
        VertexBuffer vb = m.getVertexBuffer();
        float[] sb = new float[4];
        VertexArray va = vb.getPositions(sb);
        p("  mesh " + cls(m) + " uid=" + m.getUserID() + " submesh=" + m.getSubmeshCount()
          + " verts=" + (va != null ? va.getVertexCount() : -1)
          + " bias=" + i(sb[0]) + "," + i(sb[1]) + "," + i(sb[2]) + " scale=" + i(sb[3])
          + " defcolor=0x" + Integer.toHexString(vb.getDefaultColor()));
        IndexBuffer ib = m.getIndexBuffer(0);
        int cnt = ib.getIndexCount();
        int[] idx = new int[cnt > 8 ? cnt : 8];
        int got = ib.getIndices(idx);
        StringBuffer sbf = new StringBuffer();
        for (int k = 0; k < 6 && k < got; k++) sbf.append(idx[k]).append(' ');
        p("  ib0 n=" + cnt + " got=" + got + " first=[" + sbf.toString().trim() + "]");
        if (m instanceof SkinnedMesh) {
            SkinnedMesh sm = (SkinnedMesh) m;
            Group sk = sm.getSkeleton();
            p("  skin bones=" + sm.getBoneCount() + " skel=" + (sk != null ? cls(sk) : "null")
              + " skelchildren=" + (sk != null ? "" + sk.getChildCount() : "-1"));
        }
        /* tracks on the mesh itself (H3T attaches ORIENTATION/TRANSLATION here) */
        int tc = m.getAnimationTrackCount();
        p("  meshtracks=" + tc);
        for (int i = 0; i < 2 && i < tc; i++) dumpTrack(m.getAnimationTrack(i), "   mt" + i);
    }

    private void dumpTrack(AnimationTrack tr, String tag) {
        if (tr == null) { p(tag + " null"); return; }
        KeyframeSequence ks = tr.getKeyframeSequence();
        if (ks == null) { p(tag + " prop=" + tr.getTargetProperty() + " ks=null"); return; }
        float[] v = new float[8];
        int time = ks.getKeyframe(0, v);
        p(tag + " prop=" + tr.getTargetProperty() + " w=" + i(tr.getWeight())
          + " kf=" + ks.getKeyframeCount() + " comp=" + ks.getComponentCount()
          + " dur=" + ks.getDuration() + " interp=" + ks.getInterpolationType()
          + " rep=" + ks.getRepeatMode() + " t0=" + time
          + " v0=" + i(v[0]) + "," + i(v[1]) + "," + i(v[2]) + "," + i(v[3]));
        AnimationController ac = tr.getController();
        if (ac != null)
            p(tag + " ctrl speed=" + i(ac.getSpeed()) + " w=" + i(ac.getWeight())
              + " refwt=" + ac.getRefWorldTime());
    }

    private void testBytes(String name) throws Exception {
        byte[] bytes = readRes(name);
        if (bytes == null) { p("BYTES " + name + " res=null"); return; }
        Object3D[] a = Loader.load(bytes, 0);
        Object3D[] b = Loader.load(name);
        p("BYTES " + name + " len=" + bytes.length
          + " roots=" + (a != null ? "" + a.length : "null")
          + " (str=" + (b != null ? "" + b.length : "null") + ")");
        if (a != null) for (int i = 0; i < a.length; i++)
            p("  broot" + i + " " + cls(a[i]) + " uid=" + a[i].getUserID());
        World wa = null, wb = null;
        if (a != null) for (int i = 0; i < a.length; i++)
            if (a[i] instanceof World) { wa = (World) a[i]; break; }
        if (b != null) for (int i = 0; i < b.length; i++)
            if (b[i] instanceof World) { wb = (World) b[i]; break; }
        p("  children=" + (wa != null ? "" + wa.getChildCount() : "nw")
          + "/" + (wb != null ? "" + wb.getChildCount() : "nw"));
        Camera ca = wa != null ? wa.getActiveCamera() : null;
        p("  cam=" + (ca != null ? "" + ca.getUserID() : "null"));
        Background bga = wa != null ? wa.getBackground() : null;
        p("  bg=" + (bga != null ? "0x" + Integer.toHexString(bga.getColor()) : "null"));
        if (wa != null) dumpMeshish(wa);
    }

    private byte[] readRes(String name) throws Exception {
        InputStream is = getClass().getResourceAsStream(name);
        if (is == null) return null;
        byte[] buf = new byte[4096];
        int total = 0;
        for (;;) {
            if (total == buf.length) {
                byte[] nb = new byte[buf.length * 2];
                System.arraycopy(buf, 0, nb, 0, total);
                buf = nb;
            }
            int n = is.read(buf, total, buf.length - total);
            if (n <= 0) break;
            total += n;
        }
        try { is.close(); } catch (Exception e) {}
        byte[] out = new byte[total];
        System.arraycopy(buf, 0, out, 0, total);
        return out;
    }
}
