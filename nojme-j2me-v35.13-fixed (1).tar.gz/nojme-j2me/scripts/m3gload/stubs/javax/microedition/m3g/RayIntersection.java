package javax.microedition.m3g;

public class RayIntersection extends Object3D {
    public RayIntersection() {}
    public Node getIntersected() { return null; }
}
