package javax.microedition.m3g;

public abstract class Object3D {
    public int getUserID() { return 0; }
    public void setUserID(int id) {}
    public Object3D duplicate() { return null; }
    public Object3D find(int userId) { return null; }
    public void addAnimationTrack(AnimationTrack track) {}
    public int getAnimationTrackCount() { return 0; }
    public AnimationTrack getAnimationTrack(int index) { return null; }
}
