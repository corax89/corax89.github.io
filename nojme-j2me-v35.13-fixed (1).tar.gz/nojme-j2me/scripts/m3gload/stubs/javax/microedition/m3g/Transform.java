package javax.microedition.m3g;

public class Transform {
    public Transform() {}
    public Transform(float[] matrix) {}
    public void setIdentity() {}
    public void postMultiply(Transform other) {}
    public void postTranslate(float tx, float ty, float tz) {}
    public void postRotate(float angle, float ax, float ay, float az) {}
    public void postScale(float sx, float sy, float sz) {}
    public void invert() {}
    public void transpose() {}
    public void set(float[] matrix) {}
    public void get(float[] matrix) {}
    public void transform(VertexArray in, float[] out, boolean W) {}
}
