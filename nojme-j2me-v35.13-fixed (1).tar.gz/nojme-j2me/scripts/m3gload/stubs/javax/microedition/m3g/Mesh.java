package javax.microedition.m3g;

public class Mesh extends Node {
    public Mesh() {}
    public Mesh(VertexBuffer vertices, IndexBuffer triangles, Appearance appearance) {}
    public int getSubmeshCount() { return 0; }
    public VertexBuffer getVertexBuffer() { return null; }
    public IndexBuffer getIndexBuffer(int index) { return null; }
    public Appearance getAppearance(int index) { return null; }
}
