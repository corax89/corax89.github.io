package javax.microedition.m3g;

public class Background extends Object3D {
    public Background() {}
    public void setColor(int argb) {}
    public int getColor() { return 0; }
    public int getImageModeX() { return 0; }
    public int getImageModeY() { return 0; }
    public int getCropX() { return 0; }
    public int getCropY() { return 0; }
    public int getCropWidth() { return 0; }
    public int getCropHeight() { return 0; }
}
