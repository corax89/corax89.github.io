package javax.microedition.m3g;

public class SkinnedMesh extends Mesh {
    public SkinnedMesh(VertexBuffer base, IndexBuffer triangles, Appearance appearance, Group skeleton) {}
    public void addTransform(Node bone, int firstVertex, int numVertices, float weight) {}
    public int getBoneCount() { return 0; }
    public int getBoneVertices(Node bone, int[] indices, float[] weights) { return 0; }
    public Group getSkeleton() { return null; }
}
