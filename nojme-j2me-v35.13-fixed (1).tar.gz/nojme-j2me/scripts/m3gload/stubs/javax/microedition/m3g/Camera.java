package javax.microedition.m3g;

public class Camera extends Node {
    public Camera() {}
    public void setPerspective(float fovy, float aspect, float near, float far) {}
    public void setParallel(float height, float aspect, float near, float far) {}
    public void lookAt(float fx, float fy, float fz, float ax, float ay, float az, float ux, float uy, float uz) {}
    public int getProjection(float[] params) { return 0; }
}
