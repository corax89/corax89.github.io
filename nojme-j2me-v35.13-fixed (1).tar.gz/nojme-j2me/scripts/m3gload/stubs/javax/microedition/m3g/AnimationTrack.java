package javax.microedition.m3g;

public class AnimationTrack extends Object3D {
    public AnimationTrack(KeyframeSequence sequence, int property) {}
    public int getTargetProperty() { return 0; }
    public float getWeight() { return 1.0f; }
    public KeyframeSequence getKeyframeSequence() { return null; }
    public AnimationController getController() { return null; }
}
