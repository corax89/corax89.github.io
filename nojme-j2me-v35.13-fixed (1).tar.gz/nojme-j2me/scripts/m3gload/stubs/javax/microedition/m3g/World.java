package javax.microedition.m3g;

public class World extends Group {
    public World() {}
    public void setActiveCamera(Camera camera) {}
    public Camera getActiveCamera() { return null; }
    public Background getBackground() { return null; }
}
