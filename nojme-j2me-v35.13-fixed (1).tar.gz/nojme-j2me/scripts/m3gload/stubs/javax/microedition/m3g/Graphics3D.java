package javax.microedition.m3g;

public class Graphics3D {
    public static Graphics3D getInstance() { return null; }
    public void setViewport(int x, int y, int width, int height) {}
    public int getViewportX() { return 0; }
    public int getViewportY() { return 0; }
    public int getViewportWidth() { return 0; }
    public int getViewportHeight() { return 0; }
    public void setDepthRange(float near, float far) {}
    public float getDepthRangeNear() { return 0f; }
    public float getDepthRangeFar() { return 0f; }
    public Object getTarget() { return null; }
    public int getHints() { return 0; }
    public void releaseTarget() {}
}
