package javax.microedition.m3g;

public class AnimationController extends Object3D {
    public AnimationController() {}
    public float getSpeed() { return 1.0f; }
    public float getWeight() { return 1.0f; }
    public int getRefWorldTime() { return 0; }
}
