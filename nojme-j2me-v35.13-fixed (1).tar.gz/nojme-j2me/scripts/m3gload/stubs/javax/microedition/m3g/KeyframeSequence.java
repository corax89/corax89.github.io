package javax.microedition.m3g;

public class KeyframeSequence extends Object3D {
    public KeyframeSequence(int numKeyframes, int numComponents, int interpolation) {}
    public int getKeyframeCount() { return 0; }
    public int getComponentCount() { return 0; }
    public int getDuration() { return 0; }
    public int getInterpolationType() { return 0; }
    public int getRepeatMode() { return 0; }
    public int getKeyframe(int index, float[] value) { return 0; }
}
