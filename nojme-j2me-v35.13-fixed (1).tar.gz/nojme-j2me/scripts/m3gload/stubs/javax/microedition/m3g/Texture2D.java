package javax.microedition.m3g;

public class Texture2D extends Transformable {
    public static final int FILTER_LINEAR = 209;
    public static final int FILTER_NEAREST = 210;
    public static final int WRAP_CLAMP = 240;
    public static final int WRAP_REPEAT = 241;
    public Texture2D(Image2D image) {}
    public void setFiltering(int levelFilter, int imageFilter) {}
    public int getLevelFilter() { return 0; }
    public int getImageFilter() { return 0; }
    public void setWrapping(int wrapS, int wrapT) {}
    public int getWrappingS() { return 0; }
    public int getWrappingT() { return 0; }
}
