package javax.microedition.m3g;

public class MorphingMesh extends Mesh {
    public MorphingMesh(VertexBuffer base, VertexBuffer[] targets, IndexBuffer triangles, Appearance appearance) {}
    public void setWeights(float[] weights) {}
    public void getWeights(float[] weights) {}
    public int getMorphTargetCount() { return 0; }
}
