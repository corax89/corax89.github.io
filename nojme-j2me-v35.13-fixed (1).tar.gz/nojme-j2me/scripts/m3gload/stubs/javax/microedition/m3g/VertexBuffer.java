package javax.microedition.m3g;

public class VertexBuffer extends Object3D {
    public VertexBuffer() {}
    public void setPositions(VertexArray positions, float scale, float[] bias) {}
    public VertexArray getPositions(float[] scaleBias) { return null; }
    public int getDefaultColor() { return 0; }
}
