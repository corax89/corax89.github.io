package javax.microedition.m3g;

public class Image2D extends Object3D {
    public static final int RGB = 99;
    public Image2D(int format, int width, int height) {}
    public Image2D(int format, int width, int height, byte[] image) {}
    public Image2D(int format, int width, int height, byte[] image, byte[] palette) {}
    public int getWidth() { return 0; }
    public int getHeight() { return 0; }
    public int getFormat() { return 0; }
}
