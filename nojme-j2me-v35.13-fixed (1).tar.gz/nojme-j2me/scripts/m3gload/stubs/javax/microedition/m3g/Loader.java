package javax.microedition.m3g;

public class Loader {
    public static Object3D[] load(String name) { return null; }
    public static Object3D[] load(byte[] data, int offset) { return null; }
}
