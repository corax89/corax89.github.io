package javax.microedition.m3g;

public class TriangleStripArray extends IndexBuffer {
    public TriangleStripArray(int firstIndex, int[] stripLengths) {}
}
