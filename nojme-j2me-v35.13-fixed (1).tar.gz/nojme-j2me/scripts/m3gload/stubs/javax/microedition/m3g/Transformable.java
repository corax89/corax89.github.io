package javax.microedition.m3g;

public abstract class Transformable extends Object3D {
    public void setTranslation(float tx, float ty, float tz) {}
    public void getTranslation(float[] xyz) {}
    public void setScale(float sx, float sy, float sz) {}
    public void getScale(float[] xyz) {}
    public void setOrientation(float angle, float ax, float ay, float az) {}
    public void getOrientation(float[] angleAxis) {}
    public void preRotate(float angle, float ax, float ay, float az) {}
    public void postRotate(float angle, float ax, float ay, float az) {}
    public void translate(float tx, float ty, float tz) {}
    public void scale(float sx, float sy, float sz) {}
    public void setTransform(Transform transform) {}
    public void getTransform(Transform transform) {}
    public void getCompositeTransform(Transform transform) {}
}
