package javax.microedition.m3g;

public class PolygonMode extends Object3D {
    public PolygonMode() {}
    public void setPerspectiveCorrectionEnable(boolean enable) {}
    public boolean isPerspectiveCorrectionEnabled() { return false; }
}
