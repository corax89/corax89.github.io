package javax.microedition.m3g;

public abstract class Node extends Transformable {
    public void setAlphaFactor(float factor) {}
    public void setRenderingEnable(boolean enable) {}
    public boolean isRenderingEnabled() { return true; }
}
