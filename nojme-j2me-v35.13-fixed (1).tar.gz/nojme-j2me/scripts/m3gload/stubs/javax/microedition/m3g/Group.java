package javax.microedition.m3g;

public class Group extends Node {
    public Group() {}
    public void addChild(Node child) {}
    public void removeChild(Node child) {}
    public int getChildCount() { return 0; }
    public Node getChild(int index) { return null; }
    public boolean pick(int scope, float ox, float oy, float oz,
                        float dx, float dy, float dz, RayIntersection ri) { return false; }
    public boolean pick(int scope, float x, float y, Camera camera,
                        RayIntersection ri) { return false; }
}
