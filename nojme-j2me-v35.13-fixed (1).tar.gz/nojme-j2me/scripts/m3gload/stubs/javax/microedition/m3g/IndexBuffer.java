package javax.microedition.m3g;

public abstract class IndexBuffer extends Object3D {
    public int getIndexCount() { return 0; }
    public int getIndices(int[] indicesOut) { return 0; }
}
