package javax.microedition.m3g;

public class VertexArray {
    public VertexArray(int numVertices, int numComponents, int componentSize) {}
    public void set(int firstVertex, int numVertices, short[] values) {}
    public void set(int firstVertex, int numVertices, byte[] values) {}
    public int getVertexCount() { return 0; }
    public int getComponentCount() { return 0; }
    public int getComponentType() { return 0; }
}
