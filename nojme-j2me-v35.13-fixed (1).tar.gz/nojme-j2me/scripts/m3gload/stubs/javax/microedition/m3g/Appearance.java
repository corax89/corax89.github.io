package javax.microedition.m3g;

public class Appearance extends Object3D {
    public Appearance() {}
}
