package javax.microedition.m3g;

public class CompositingMode extends Object3D {
    public CompositingMode() {}
    public void setDepthOffset(float factor, float units) {}
    public float getDepthOffsetFactor() { return 0f; }
    public float getDepthOffsetUnits() { return 0f; }
}
