#!/bin/bash
# Build M3GLoad.jar — the M3G file-loader audit selftest (v34.70).
# Packages four REAL game-exported .m3g files (H3T + M3GToolkit dialects)
# and loads them through BOTH Loader.load(String) and Loader.load(byte[],int).
# Sources for the .m3g fixtures (extracted with python zipfile):
#   bs.m3g     <- BlackShark3D.jar m3g/assets.m3g
#   pers.m3g   <- stalker.jar pers.m3g
#   forest.m3g <- stalker.jar ForestDecors.m3g
#   role.m3g   <- Quake Plus 3D res/role/role.m3g
#   r103.bin   <- fmx.jar res/r103.bin (M3GToolkit mesh-only model)
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
FIX="$D/../../../m3gaudit"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }
[ -f "$FIX/blackshark.m3g" ] || { echo "fixtures missing: $FIX (extract game .m3g first)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/M3GLoad.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java" \
    "$D/stubs/javax/microedition/m3g/"*.java
printf 'Manifest-Version: 1.0\r\nMIDlet-1: M, , M3GLoad\r\nMIDlet-Name: M\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/M3GLoad.class" "$OUT/pkg/"
cp "$FIX/blackshark.m3g"        "$OUT/pkg/bs.m3g"
cp "$FIX/stalker_pers.m3g"      "$OUT/pkg/pers.m3g"
cp "$FIX/stalker_forest.m3g"    "$OUT/pkg/forest.m3g"
cp "$FIX/quake_role.m3g"      "$OUT/pkg/role.m3g"
cp "$FIX/fmx_r103.m3g"  "$OUT/pkg/r103.bin"
( cd "$OUT/pkg" && zip -q -r "$D/M3GLoad.jar" META-INF M3GLoad.class bs.m3g pers.m3g forest.m3g role.m3g r103.bin )
echo "built: $D/M3GLoad.jar"
echo "run:   NOJME_LOG=1 ./bin/j2me-headless --headless games/M3GLoad.jar"
