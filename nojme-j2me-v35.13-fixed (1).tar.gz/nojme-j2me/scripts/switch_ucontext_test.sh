#!/bin/bash
# switch_ucontext_test.sh — v34.87
# Builds and runs the functional test for the vendored Switch ucontext
# (src/switch/switch_ucontext.c): freestanding aarch64 binary + qemu-user.
#
# Env-overridable paths (defaults = sandbox layout):
#   V3487   - work dir holding xpack/, qemu-aarch64-static
#   T       - project tree (defaults to ../.. from this script)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
T=${T:-$(dirname "$HERE")}
V3487=${V3487:-/home/z/my-project/work/v3487}
CROSS=$V3487/xpack/bin/aarch64-none-elf-gcc
INTINC=$V3487/xpack/lib/gcc/aarch64-none-elf/14.2.1/include
QEMU=$V3487/qemu-aarch64-static
OUT=/tmp/switch_ucontext_test

CFLAGS="-nostdinc -isystem $INTINC -isystem $V3487/nlincl -I$T/src -D__SWITCH__ -std=c11 -Wall -Wextra -O2 -fno-builtin -ffreestanding"

echo "== building (aarch64 cross-gcc, freestanding) =="
$CROSS $CFLAGS -c "$HERE/switch_ucontext_test.c" -o $OUT.test.o || exit 1
$CROSS $CFLAGS -c "$T/src/switch/switch_ucontext.c" -o $OUT.impl.o || exit 1
$CROSS -nostdlib -static $OUT.test.o $OUT.impl.o -o $OUT.elf -Wl,-e,_start || exit 1

echo "== running under qemu-aarch64 =="
$QEMU $OUT.elf
rc=$?
if [ $rc -eq 0 ]; then
    echo "== switch_ucontext: ALL FUNCTIONAL CHECKS PASSED =="
else
    echo "== switch_ucontext: FAILED (exit $rc) =="
fi
exit $rc
