#!/usr/bin/env python3
"""For each SkinnedMesh in the file: its OWN VertexBuffer vertex count,
binding coverage, and which indices the submesh TriangleStripArrays use."""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from m3g_skin_space import parse

for path in sys.argv[1:]:
    parsed, objs = parse(path)
    print('==== %s' % path.split('/')[-1])
    for si, o in enumerate(parsed):
        if o['typename'] != 'SKINNEDMESH':
            continue
        vb = parsed[o['vb_ref'] - 1]
        t, body = objs[o['vb_ref'] - 1]
        # VB: header(4) + tracks + uo, then 4 u8 flags, posRef, bias, scale...
        p = 4
        ntc = struct.unpack('<I', body[p:p+4])[0]; p += 4
        p += 4 * ntc
        nuo = struct.unpack('<I', body[p:p+4])[0]; p += 4
        for _ in range(nuo):
            p += 4; ln = struct.unpack('<I', body[p:p+4])[0]; p += 4 + ln
        p += 4  # encoding u32? per dumper: u8*4? -> recheck below
        # dumper read: r.u8() x4 then pos_ref u32 bias f32x3 scale f32
        p -= 4
        p += 4  # four u8 flags
        pos_ref = struct.unpack('<I', body[p:p+4])[0]; p += 4
        # vertex array
        tv, vbody = objs[pos_ref - 1]
        q = 4
        ntc2 = struct.unpack('<I', vbody[q:q+4])[0]; q += 4
        q += 4 * ntc2
        nuo2 = struct.unpack('<I', vbody[q:q+4])[0]; q += 4
        for _ in range(nuo2):
            q += 4; ln = struct.unpack('<I', vbody[q:q+4])[0]; q += 4 + ln
        cs = vbody[q]; cc = vbody[q+1]; enc = vbody[q+2]
        vc = struct.unpack('<H', vbody[q+3:q+5])[0]

        covered = [0] * vc
        for (bref, first, cnt, w) in o['bones']:
            for v in range(first, min(first + cnt, vc)):
                covered[v] += 1
        unc = [i for i, c in enumerate(covered) if c == 0]

        # submesh indices
        used = [0] * vc
        for (ib_ref, app_ref) in o['submeshes']:
            ti, ibody = objs[ib_ref - 1]
            # TSA: header(4)+tracks+uo, then encoding u8, then indices
            q2 = 4
            ntc3 = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
            q2 += 4 * ntc3
            nuo3 = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4
            for _ in range(nuo3):
                q2 += 4; ln = struct.unpack('<I', ibody[q2:q2+4])[0]; q2 += 4 + ln
            ienc = ibody[q2]; q2 += 1
            # read u32s to end of object as indices (core dialect)
            n_idx_left = (len(ibody) - q2) // 4
            for k in range(n_idx_left):
                idx = struct.unpack('<I', ibody[q2 + 4*k:q2 + 4*k + 4])[0]
                if 0 <= idx < vc:
                    used[idx] += 1
        unc_used = [i for i in unc if used[i] > 0]
        print(' SM#%d uid=%s verts=%d bindings=%d uncovered=%d used_in_ib=%d -> %s' % (
            si + 1, o.get('uid'), vc, len(o['bones']), len(unc), len(unc_used), unc_used[:20]))
