/*
 * test_switch_scaling.c — unit tests for the pure Switch frontend math
 * (switch_scaling.c) + the embedded bitmap font (switch_font.c).
 * Builds on any host: gcc -I src -I include ...
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "switch/switch_scaling.h"
#include "switch/switch_common.h"
#include "switch/switch_font.h"

static int g_fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { g_fails++; printf("FAIL: " __VA_ARGS__); printf(" (%s:%d)\n", __FILE__, __LINE__); } \
} while (0)

static void test_game_rect(void) {
    int x, y, w, h;

    /* STRETCH: whole screen */
    switch_scaling_game_rect(NOJME_SCALE_STRETCH, 240, 320, 1280, 720, &x, &y, &w, &h);
    CHECK(x == 0 && y == 0 && w == 1280 && h == 720, "stretch fills screen, got %d,%d %dx%d", x, y, w, h);

    /* FIT 240x320 (3:4) on 1280x720 (16:9): height-limited -> 540x720 centered */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 240, 320, 1280, 720, &x, &y, &w, &h);
    CHECK(h == 720 && w == 540, "fit height-limited 540x720, got %dx%d", w, h);
    CHECK(x == (1280 - 540) / 2 && y == 0, "fit centered x=%d y=%d", x, y);
    double ar = (double)w / h, want = 240.0 / 320.0;
    CHECK(ar > want * 0.99 && ar < want * 1.01, "aspect preserved %.4f vs %.4f", ar, want);

    /* FIT wide canvas 320x240 -> width-limited 1280x960? no: 960 height fits */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLUR, 320, 240, 1280, 720, &x, &y, &w, &h);
    CHECK(w == 960 && h == 720, "fit width-limited 960x720, got %dx%d", w, h);
    CHECK(x == (1280 - 960) / 2 && y == 0, "fit wide centered");

    /* degenerate: 1x1 */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 1, 1, 1280, 720, &x, &y, &w, &h);
    CHECK(w >= 1 && h >= 1 && x >= 0 && y >= 0, "1x1 valid rect %d,%d %dx%d", x, y, w, h);

    /* extreme aspect 1000x10 */
    switch_scaling_game_rect(NOJME_SCALE_FIT_BLACK, 1000, 10, 1280, 720, &x, &y, &w, &h);
    CHECK(w <= 1280 && h <= 720, "extreme clamped %dx%d", w, h);
}

static void test_bg_size(void) {
    int bw, bh;
    switch_scaling_bg_size(240, 320, &bw, &bh);
    CHECK(bw == 30 && bh == 40, "bg 240x320 -> 30x40, got %dx%d", bw, bh);
    switch_scaling_bg_size(16, 16, &bw, &bh);
    CHECK(bw == 8 && bh == 8, "bg min 8x8, got %dx%d", bw, bh);
    switch_scaling_bg_size(3, 3, &bw, &bh);
    CHECK(bw == 3 && bh == 3, "bg tiny clamped to src, got %dx%d", bw, bh);
}

static void test_blur(void) {
    /* constant color stays constant through downsample + blur */
    enum { SW = 64, SH = 64, BW = 8, BH = 8 };
    uint32_t src[SW * SH], bg[BW * BH];
    for (int i = 0; i < SW * SH; i++) src[i] = 0xFF336699u;
    switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 3);
    for (int i = 0; i < BW * BH; i++) {
        CHECK(bg[i] == 0xFF336699u, "const frame -> const bg[%d]=0x%08X", i, bg[i]);
    }

    /* left half red / right half blue (split at ODD x so the boundary
     * is NOT aligned with the 8-wide box grid -> transition box mixes) */
    for (int y = 0; y < SH; y++)
        for (int x = 0; x < SW; x++)
            src[y * SW + x] = (x < 33) ? 0xFFFF0000u : 0xFF0000FFu;
    switch_scaling_blur_bg(src, SW, SH, bg, BW, BH, 0); /* downsample only */
    CHECK(((bg[0] >> 16) & 0xFF) == 0xFF && (bg[0] & 0xFF) == 0x00, "left edge pure red");
    CHECK((bg[BW - 1] & 0xFF) == 0xFF && ((bg[BW - 1] >> 16) & 0xFF) == 0x00, "right edge pure blue");
    /* transition column (covers x=32..39: 1 red + 7 blue): both channels present */
    {
        uint32_t mid = bg[4];
        int has_r = ((mid >> 16) & 0xFF) > 0, has_b = (mid & 0xFF) > 0;
        CHECK(has_r && has_b, "transition box mixes channels, got 0x%08X", mid);
    }
    /* alpha always opaque */
    for (int i = 0; i < BW * BH; i++)
        CHECK((bg[i] & 0xFF000000u) == 0xFF000000u, "alpha opaque");

    /* degenerate sizes must not crash */
    switch_scaling_blur_bg(src, SW, SH, bg, 1, 1, 2);
    switch_scaling_blur_bg(NULL, 0, 0, bg, BW, BH, 2);
    switch_scaling_blur_bg(src, SW, SH, NULL, BW, BH, 2);
    printf("PASS-CHECK degenerate blur no crash\n");
}

static void test_font(void) {
    CHECK(switch_font_w() == 8 && switch_font_h() == 16, "cell metrics 8x16");
    CHECK(switch_font_text_width("AB", 1) == 16, "width AB=16");
    CHECK(switch_font_text_width("Ёё", 2) == 32, "cyrillic width scale2=32");

    uint32_t cv[160 * 60];
    memset(cv, 0, sizeof(cv));
    int end = switch_font_draw_text(cv, 160, 60, 4, 4, "Привет, J2ME!", 0xFFFFFFFF, 0, 2);
    CHECK(end > 4, "draw advanced x=%d", end);
    int lit = 0;
    for (int i = 0; i < 160 * 60; i++) if (cv[i]) lit++;
    CHECK(lit > 100, "ink pixels > 100, got %d", lit);

    /* clipping: far off-canvas must not crash */
    switch_font_draw_text(cv, 160, 60, 10000, 10000, "X", 0xFFFFFFFF, 0, 2);
    printf("PASS-CHECK font clipping no crash\n");
}

int main(void) {
    test_game_rect();
    test_bg_size();
    test_blur();
    test_font();
    if (g_fails == 0) {
        printf("SWITCH-SCALING/FONT UNIT: ALL %s\n", "PASS");
        return 0;
    }
    printf("SWITCH-SCALING/FONT UNIT: %d FAILS\n", g_fails);
    return 1;
}
