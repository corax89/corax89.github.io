/* TurboBench — v34.83 selftest for the v41 thread-budget / turbo paths.
 *
 * Models the user's diagnosis: Gameloft-style worker threads re-hosted on a
 * fast host. Phase layout (all rates printed as SYSOUT once a second):
 *
 *   W1, W2   — Thread.start() runner pthreads, 10 s burn loops. These are
 *              what g_jvm_thread_budget (execute.c) paces; turbo must lift
 *              the throttle entirely. TWO threads prove the budget is
 *              per-thread, not a shared pool.
 *   MAIN-load — 1.5 s burn on the AMS thread inside startApp. Documents the
 *              load-time path: execute_method runs it free-run, no mode
 *              paces it (by design since v41 — the frontend isn't pumping
 *              frames yet).
 *   exit     — the SECOND worker to finish calls notifyDestroyed().
 *
 * Workers outlive retro_load_game on purpose: ~8.5 s of their run happens
 * under retro_run frames, so a live j2me_vm_speed flip (LR_SPEED_SWITCH)
 * lands mid-burn and the rate step is visible in the same log.
 *
 * The burn loop is the classic ~11-bytecode inner iteration; acc is a
 * deterministic checksum (identical in every speed mode).
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class TurboBench extends MIDlet {
    static volatile int workers_done = 0;
    static volatile boolean started = false;

    public TurboBench() {}

    static long burn(long acc) {
        for (int i = 0; i < 10000; i++) {
            acc += i * 3 + 7;
        }
        return acc;
    }

    public void startApp() throws MIDletStateChangeException {
        final long RUN_MS = 10000;
        final long MAIN_MS = 1500;
        System.out.println("TURBOBENCH start");

        /* Two runner pthreads — the g_jvm_thread_budget audience. */
        for (int w = 1; w <= 2; w++) {
            final String tag = "W" + w;
            Thread t = new Thread(new Runnable() {
                public void run() {
                    long t0 = System.currentTimeMillis();
                    long iters = 0, acc = 0;
                    long next = t0 + 1000;
                    while (true) {
                        acc = burn(acc);
                        iters += 10000;
                        long now = System.currentTimeMillis();
                        if (now - t0 >= RUN_MS) break;
                        if (now >= next) {
                            long kps = (now > t0) ? (iters * 1000L) / (now - t0) : 0;
                            System.out.println("TURBOBENCH WORKER " + tag
                                    + " iters/s=" + kps + " (inst=" + iters + ")");
                            next = now + 1000;
                        }
                    }
                    long ms = System.currentTimeMillis() - t0;
                    long kps = ms > 0 ? (iters * 1000L) / ms : 0;
                    System.out.println("TURBOBENCH WORKER " + tag + "-done"
                            + " total_iters=" + iters + " ms=" + ms
                            + " k_iters/s=" + kps + " acc=" + acc);
                    if (++workers_done == 2) {
                        System.out.println("TURBOBENCH end");
                        notifyDestroyed();
                    }
                }
            });
            t.start();
        }
        started = true;

        /* MAIN-load: free-run path (execute_method at load). */
        long t0 = System.currentTimeMillis();
        long iters = 0, acc = 0;
        long next = t0 + 1000;
        while (true) {
            acc = burn(acc);
            iters += 10000;
            long now = System.currentTimeMillis();
            if (now - t0 >= MAIN_MS) break;
            if (now >= next) {
                long kps = (now > t0) ? (iters * 1000L) / (now - t0) : 0;
                System.out.println("TURBOBENCH MAIN-load iters/s=" + kps
                        + " (inst=" + iters + ")");
                next = now + 1000;
            }
        }
        long ms = System.currentTimeMillis() - t0;
        long kps = ms > 0 ? (iters * 1000L) / ms : 0;
        System.out.println("TURBOBENCH MAIN-load-done total_iters=" + iters
                + " ms=" + ms + " k_iters/s=" + kps + " acc=" + acc);
        /* startApp returns; workers keep burning across retro_run frames. */
    }

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) throws MIDletStateChangeException {}
}
