#!/bin/bash
# Build TurboBench.jar — thread-budget/turbo selftest MIDlet (v34.83).
# Same pipeline as scripts/testcam/build.sh: ECJ with -source 1.4 (class
# version 48, no stack maps); only TurboBench*.class packaged — the
# emulator supplies the midlet/lcdui classes at runtime.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TurboBench.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java"
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TurboBench\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT"/TurboBench*.class "$OUT/pkg/"
( cd "$OUT/pkg" && zip -q -r "$D/TurboBench.jar" META-INF TurboBench*.class )
echo "built: $D/TurboBench.jar"
echo "run:   PACED=1 ./bin/lr_run ./bin/nojme_libretro.so scripts/turbobench/TurboBench.jar 900 /tmp/tb 0"
