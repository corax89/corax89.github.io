#!/usr/bin/env python3
"""v34.73 TestAudio dump analyzer — verifies the core's mixed output.

Reads the WAV written by lr_run's NOJME_AUDIO_DUMP (16-bit stereo, default
frontend rate 22050), segments it into non-silent windows, and checks each
expected phase:

  P1 440 Hz (L=R, mono)          P5 A-law 440 Hz
  P2 L=880 R=1320 (stereo)       P6 mu-law 440 Hz
  P3 220 Hz (8-bit)              P7 mixer: 440 AND 660, clipped at +-32767,
  P4 IMA ADPCM 440 Hz               no wrap (adjacent |diff| < 45000)
  P8 MIDI 440 Hz (top-3 peak)    P9 playTone 440 Hz

Exit code 0 = all checks passed; 1 = failures (printed).
"""
import struct
import sys

import numpy as np

def load_wav(path):
    with open(path, "rb") as f:
        data = f.read()
    assert data[:4] == b"RIFF" and data[8:12] == b"WAVE", "not a RIFF/WAVE"
    pos = 12
    fmt = channels = rate = bits = None
    pcm = None
    while pos + 8 <= len(data):
        cid = data[pos:pos + 4]
        csz = struct.unpack("<I", data[pos + 4:pos + 8])[0]
        body = data[pos + 8:pos + 8 + csz]
        if cid == b"fmt ":
            fmt, channels, rate = struct.unpack("<HHI", body[:8])
            bits = struct.unpack("<H", body[14:16])[0]
        elif cid == b"data":
            pcm = body
        pos += 8 + csz + (csz & 1)
    assert fmt == 1 and bits == 16, f"unexpected fmt {fmt}/{bits}"
    n = len(pcm) // 4
    arr = np.frombuffer(pcm[:n * 4], dtype="<i2").reshape(n, 2)
    return arr.astype(np.float64), rate


def segments(sig, rate, win_ms=40, thresh=250.0):
    """Contiguous non-silent runs; returns list of (start, end) sample idx."""
    w = int(rate * win_ms / 1000)
    rms = [float(np.sqrt(np.mean(sig[i:i + w] ** 2))) if i + w <= len(sig) else 0.0
           for i in range(0, len(sig), w)]
    runs, s = [], None
    for i, r in enumerate(rms):
        if r > thresh and s is None:
            s = i * w
        elif r <= thresh and s is not None:
            runs.append((s, i * w))
            s = None
    if s is not None:
        runs.append((s, len(sig)))
    # merge runs separated by < 80 ms (gaps inside a phase)
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] < int(0.08 * rate):
            merged[-1] = (merged[-1][0], r[1])
        else:
            merged.append(list(r))
    return [tuple(m) for m in merged if m[1] - m[0] > int(0.15 * rate)]


def top_peaks(x, rate, k=5, lo=80.0, hi=2500.0):
    seg = x * np.hanning(len(x))
    sp = np.abs(np.fft.rfft(seg))
    freqs = np.fft.rfftfreq(len(x), 1.0 / rate)
    mask = (freqs >= lo) & (freqs <= hi)
    idx = np.argsort(sp * mask)[::-1][:k]
    # dedupe peaks closer than 15 Hz
    out = []
    for i in sorted(idx, key=lambda j: -sp[j]):
        f = freqs[i]
        if all(abs(f - g) > 15 for g, _ in out):
            out.append((f, float(sp[i])))
        if len(out) >= k:
            break
    return out


def has_peak(peaks, target, tol):
    return any(abs(f - target) <= tol for f, _ in peaks)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "ta3.wav"
    sig, rate = load_wav(path)
    mono = sig.mean(axis=1)
    print(f"dump: {len(sig)} frames @ {rate} Hz ({len(sig)/rate:.2f} s)")

    segs = segments(mono, rate)
    print(f"segments: {len(segs)} -> " +
          ", ".join(f"[{a/rate:.2f}s..{b/rate:.2f}s]" for a, b in segs))

    fails = []

    def check(cond, msg):
        print(("  OK   " if cond else "  FAIL ") + msg)
        if not cond:
            fails.append(msg)

    if len(segs) != 9:
        check(False, f"expected 9 phase segments, got {len(segs)}")
        print("NOTE: dumping 20ms windows per segment for debugging")
        for a, b in segs:
            pk = top_peaks(mono[a:b], rate, 4)
            print(f"   [{a/rate:5.2f}..{b/rate:5.2f}] " +
                  " ".join(f"{f:.0f}Hz({m:.2e})" for f, m in pk))
        sys.exit(1)

    for i, (a, b) in enumerate(segs, 1):
        L, R = sig[a:b, 0], sig[a:b, 1]
        pkL = top_peaks(L, rate, 4)
        pkR = top_peaks(R, rate, 4)
        print(f"P{i} [{a/rate:.2f}s..{b/rate:.2f}s] "
              f"L:{' '.join(f'{f:.0f}' for f,_ in pkL[:3])} "
              f"R:{' '.join(f'{f:.0f}' for f,_ in pkR[:3])}")
        tol = max(12.0, 0.02 * 440)
        if i == 1:
            check(has_peak(pkL, 440, 25) and has_peak(pkR, 440, 25), "P1 mono 440 Hz both channels")
        elif i == 2:
            check(has_peak(pkL, 880, 30), "P2 stereo L=880 Hz")
            check(has_peak(pkR, 1320, 40), "P2 stereo R=1320 Hz")
        elif i == 3:
            check(has_peak(pkL, 220, 15) and has_peak(pkR, 220, 15), "P3 8-bit 220 Hz")
        elif i == 4:
            check(has_peak(pkL, 440, 25), "P4 IMA ADPCM 440 Hz")
        elif i == 5:
            check(has_peak(pkL, 440, 25), "P5 A-law 440 Hz")
        elif i == 6:
            check(has_peak(pkL, 440, 25), "P6 mu-law 440 Hz")
        elif i == 7:
            check(has_peak(pkL, 440, 25) and has_peak(pkL, 660, 30),
                  "P7 mixer: both 440 and 660 present")
            mx = float(np.max(sig[a:b]))
            mn = float(np.min(sig[a:b]))
            adj = float(np.max(np.abs(np.diff(mono[a:b]))))
            check(mx >= 32000, f"P7 saturation: max={mx:.0f} near +32767")
            check(adj < 45000, f"P7 no wrap: max adjacent diff={adj:.0f}")
            check(mn <= -32000, f"P7 symmetric clip: min={mn:.0f}")
        elif i == 8:
            check(has_peak(pkL, 440, 25), "P8 MIDI A4 440 Hz")
        elif i == 9:
            check(has_peak(pkL, 440, 25), "P9 playTone 440 Hz")

    print()
    if fails:
        print(f"{len(fails)} FAILURE(S)")
        sys.exit(1)
    print("ALL AUDIO CHECKS PASSED")


if __name__ == "__main__":
    main()
