#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 0a. TestFinish: finished screen is explicit, black, with text ----------
note "0a) TestFinish: FIRE -> notifyDestroyed -> black finished screen"
rm -rf /tmp/reg73/tf; mkdir -p /tmp/reg73/tf
NOJME_LOG=1 KEYSEQ="8" KEYSEQ_EVERY=200 KEYSEQ_LEN=10 \
  timeout 120 ./bin/lr_run ./bin/nojme_libretro.so games/TestFinish.jar 400 /tmp/reg73/tf 0 > /tmp/reg73/tf/run.log 2>&1
rc=$?
seq_ok=$(grep -c "FINISH-START\|FINISH-KEY -5\|FINISH-DESTROYED" /tmp/reg73/tf/run.log || true)
[ $rc -ne 0 ] && fail "TestFinish rc=$rc"
[ "$seq_ok" -ne 3 ] && fail "TestFinish SYSOUT sequence incomplete ($seq_ok/3)"
python3 - <<'EOF' || fail "TestFinish finished-screen pixels"
d=open('/tmp/reg73/tf/lr_last.ppm','rb').read()
parts=d.split(b'\n',3)
w,h=map(int,parts[1].split())
px=parts[3]
black=white=0
for i in range(0,w*h*3,3):
    r,g,b=px[i],px[i+1],px[i+2]
    if r<12 and g<12 and b<12: black+=1
    elif r>200 and g>200 and b>200: white+=1
assert black/(w*h) > 0.9, f"not a black screen ({black/(w*h)*100:.1f}%)"
assert white > 50, f"no white title text ({white} px)"
print(f"[REG] TestFinish: black={black/(w*h)*100:.1f}% white_title_px={white} OK")
EOF

# ---------- 0b. TestBack: cancel exits the list, app survives ----------
note "0b) TestBack: Cancel -> back to MAIN, app keeps running (v34.72 semantics)"
rm -rf /tmp/reg73/tb; mkdir -p /tmp/reg73/tb
NOJME_LOG=1 KEYSEQ="2,2,3,2,2" KEYSEQ_EVERY=100 KEYSEQ_LEN=8 SNAP_EVERY=100 \
  timeout 180 ./bin/lr_run ./bin/nojme_libretro.so games/TestBack.jar 520 /tmp/reg73/tb 0 > /tmp/reg73/tb/run.log 2>&1
rc=$?
n_cancel=$(grep -c "BACK-CANCEL-HANDLED" /tmp/reg73/tb/run.log || true)
n_after=$(grep -c "BACK-OPEN-SUB2\|BACK-OPEN-SUB" /tmp/reg73/tb/run.log || true)
n_destroyed=$(grep -c "BACK-DESTROYED" /tmp/reg73/tb/run.log || true)
[ $rc -ne 0 ] && fail "TestBack rc=$rc"
[ "$n_cancel" -lt 2 ] && fail "TestBack: expected >=2 handled cancels, got $n_cancel"
[ "$n_after" -lt 4 ] && fail "TestBack: app did not stay interactive after cancel ($n_after opens)"
[ "$n_destroyed" -ne 0 ] && fail "TestBack: destroyApp ran — cancel TERMINATED the app"

# ---------- 0c. NEW: TestAudio E2E — the whole pure-C audio pipeline ----------
note "0c) TestAudio E2E: WAV x6 formats + mixer + MIDI + tone, spectral checks"
rm -rf /tmp/reg73/ta; mkdir -p /tmp/reg73/ta
PACED=1 NOJME_LOG=1 NOJME_AUDIO_DUMP=/tmp/reg73/ta/dump.wav \
  timeout 180 ./bin/lr_run ./bin/nojme_libretro.so games/TestAudio.jar 800 /tmp/reg73/ta 0 > /tmp/reg73/ta/run.log 2>&1
rc=$?
[ $rc -ne 0 ] && fail "TestAudio lr_run rc=$rc"
grep -q "TA:DONE" /tmp/reg73/ta/run.log || fail "TestAudio: midlet did not complete"
python3 scripts/analyze_testaudio.py /tmp/reg73/ta/dump.wav > /tmp/reg73/ta/analysis.log 2>&1 || fail "TestAudio spectral analysis"
tail -1 /tmp/reg73/ta/analysis.log

# ---------- 0d. NEW: Makefile stale-.d self-heal ----------
note "0d) Makefile self-heal: pre-v34.69 C++ leftovers must be purged"
SELFT=/tmp/reg73/mkself
rm -rf "$SELFT"; mkdir -p "$SELFT/obj/libretro/amr"
cp Makefile "$SELFT/"
cp -r src "$SELFT/" 2>/dev/null
# v34.74 battery fix: tier-2 self-heal invokes scripts/stale_dep_check.sh
# relative to the make CWD — the temp tree must mirror the overlay layout.
mkdir -p "$SELFT/scripts"
cp scripts/stale_dep_check.sh "$SELFT/scripts/"
# plant BOTH stale forms: orphaned name (sp_dec.d) and same-name-as-C (amr_nb_dec.d)
printf 'obj/libretro/amr/amr_nb_dec.o: src/amr/amr_nb_dec.cpp include/amr_nb_dec.h\n' > "$SELFT/obj/libretro/amr/amr_nb_dec.d"
printf 'obj/libretro/amr/sp_dec.o: src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src/sp_dec.cpp\n' > "$SELFT/obj/libretro/amr/sp_dec.d"
touch "$SELFT/obj/libretro/amr/amr_nb_dec.o" "$SELFT/obj/libretro/amr/sp_dec.o"
OUT=$( cd "$SELFT" && make platform=linux -n libretro 2>&1 )
echo "$OUT" | grep -q "No rule to make target" && fail "self-heal: make still aborts on stale .d"
[ -e "$SELFT/obj/libretro/amr/amr_nb_dec.d" ] && fail "self-heal: same-name stale .d survived"
[ -e "$SELFT/obj/libretro/amr/sp_dec.d" ] && fail "self-heal: orphaned stale .d survived"
echo "$OUT" | grep -q "tier 1" && echo "$OUT" | grep -q "tier 2" || fail "self-heal: no purge notes emitted"
note "self-heal: both tiers purged, make parses clean"
echo "[REG] === reg_chunk1 result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
