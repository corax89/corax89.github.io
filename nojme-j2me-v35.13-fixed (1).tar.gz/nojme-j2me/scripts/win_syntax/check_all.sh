#!/bin/bash
# Syntax-check every libretro-target file with the user's Windows flags
# against the win_syntax stubs (catches unknown types/implicit decls in
# _WIN32 branches without a mingw cross-compiler).
# v34.21: added src/render/, warnings are now counted and reported too.
cd "$(dirname "$0")/../.."
FLAGS="-Wall -Wextra -std=c11 -Iinclude -Isrc -Isrc/include -DLIBRETRO -DWIN32 -D_WIN32 -D_GNU_SOURCE -DJ2ME_DEBUG=0 -MMD -MP -D__USE_MINGW_ANSI_STDIO=1"
STUB="-Iscripts/win_syntax -include scripts/win_syntax/windows.h -include scripts/win_syntax/direct.h"
fail=0
warn_total=0
for f in src/jvm/*.c src/midp/*.c src/render/*.c src/libretro/*.c src/midi/*.c src/utils/*.c src/main.c; do
  if ! gcc $FLAGS $STUB -fsyntax-only "$f" 2>/tmp/winsyn_err.txt; then
    echo "FAIL: $f"; head -8 /tmp/winsyn_err.txt; fail=1
  fi
  w=$(grep -c "warning:" /tmp/winsyn_err.txt 2>/dev/null || true)
  if [ "${w:-0}" != "0" ]; then
    echo "WARN($w): $f"
    grep "warning:" /tmp/winsyn_err.txt | head -5
    warn_total=$((warn_total + w))
  fi
done
echo "total warnings: $warn_total"
[ $fail -eq 0 ] && [ $warn_total -eq 0 ] && echo "ALL WIN32 SYNTAX CHECKS PASSED (0 warnings)"
exit $fail
