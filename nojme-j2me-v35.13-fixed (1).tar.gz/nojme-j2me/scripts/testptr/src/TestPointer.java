/* TestPointer — v34.81 touch-emulation selftest.
 *
 * A plain Canvas printing every pointer event with coordinates plus every
 * key event (to prove suppression). Driven from lr_run with:
 *   LRVAR_j2me_touch_mode=dpad  + KEYSEQ_HOLD="6" (RIGHT) + KEYSEQ="0" (B)
 *   LRVAR_j2me_touch_mode=stick + LR_ANALOG_X=20000 + KEYSEQ="8" (A)
 * Expect: PTR P/R lines with the cursor x marching right from center,
 * zero PTR KEY lines while the cursor is active.
 */
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;

public class TestPointer extends MIDlet implements Runnable {
    public void startApp() {
        Canvas c = new Canvas() {
            protected void paint(Graphics g) {
                g.setColor(0, 0, 0);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
            protected void pointerPressed(int x, int y)  { System.out.println("PTR P " + x + "," + y); }
            protected void pointerReleased(int x, int y) { System.out.println("PTR R " + x + "," + y); }
            protected void pointerDragged(int x, int y)  { System.out.println("PTR D " + x + "," + y); }
            protected void keyPressed(int k)             { System.out.println("PTR KEY " + k); }
            protected void keyReleased(int k)            { }
        };
        Display.getDisplay(this).setCurrent(c);
        new Thread(this).start();
    }
    public void pauseApp() {}
    public void destroyApp(boolean u) {}
    public void run() {
        try { Thread.sleep(6000); } catch (InterruptedException e) {}
        System.out.println("PTR done");
        notifyDestroyed();
    }
}
