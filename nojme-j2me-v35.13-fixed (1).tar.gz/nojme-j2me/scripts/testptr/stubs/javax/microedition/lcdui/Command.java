package javax.microedition.lcdui;
public class Command {
    public static final int SCREEN = 1, OK = 4, CANCEL = 3, EXIT = 7, BACK = 2, STOP = 6;
    public Command(String label, int type, int priority) {}
    public String getLabel() { return null; }
    public int getCommandType() { return SCREEN; }
}
