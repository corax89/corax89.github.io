package javax.microedition.lcdui;
public class Displayable {
    public void addCommand(Command c) {}
    public void setCommandListener(CommandListener l) {}
    public boolean isShown() { return false; }
    public String getTitle() { return null; }
    public void setTitle(String t) {}
}
