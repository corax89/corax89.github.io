package javax.microedition.lcdui;
public abstract class Canvas extends Displayable {
    protected abstract void paint(Graphics g);
    protected void keyPressed(int keyCode) {}
    protected void keyReleased(int keyCode) {}
    protected void keyRepeated(int keyCode) {}
    protected void pointerPressed(int x, int y) {}
    protected void pointerReleased(int x, int y) {}
    protected void pointerDragged(int x, int y) {}
    public int getWidth() { return 240; }
    public int getHeight() { return 320; }
    public void setFullScreenMode(boolean mode) {}
    protected void showNotify() {}
    protected void hideNotify() {}
    public void repaint() {}
    public void serviceRepaints() {}
}
