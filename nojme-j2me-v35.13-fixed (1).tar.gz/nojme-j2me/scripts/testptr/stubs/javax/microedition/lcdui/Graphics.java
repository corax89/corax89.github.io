package javax.microedition.lcdui;
public class Graphics {
    public void setColor(int rgb) {}
    public void setColor(int r, int g, int b) {}
    public void fillRect(int x, int y, int w, int h) {}
    public void drawString(String s, int x, int y, int anchor) {}
    public void fillRoundRect(int x, int y, int w, int h, int aw, int ah) {}
}
