#!/bin/bash
# Build TestSprite.jar — the RI-exact Sprite3D sizing selftest (v34.78 Bug 1).
#
# Scene: fov=45/aspect=0.75 camera, two 64x64 sprites with node scale 12 at
# z=40 and z=72 (the Ops Sniper BGE "tree" configuration). The core's
# [M3G-SPRITE] trace prints dst=[l,t..r,b]; expected widths ~116px / ~64px.
#
# Requires: JRE (java) + ECJ (ecj.jar).
# Class version 48 (no stack maps), only TestSprite.class packaged — the
# emulator supplies the m3g/midlet stub classes at runtime.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/out"
ECJ="${ECJ:-$D/../../ecj.jar}"
[ -f "$ECJ" ] || ECJ="$D/../ecj.jar"
[ -f "$ECJ" ] || { echo "ecj.jar not found (set ECJ=/path/to/ecj.jar)"; exit 1; }

rm -rf "$OUT"; mkdir -p "$OUT/pkg/META-INF"
java -jar "$ECJ" -source 1.4 -target 1.4 -nowarn -d "$OUT" \
    "$D/src/TestSprite.java" \
    "$D/stubs/javax/microedition/midlet/MIDlet.java" \
    "$D/stubs/javax/microedition/midlet/MIDletStateChangeException.java" \
    "$D/stubs/javax/microedition/m3g/"*.java
printf 'Manifest-Version: 1.0\r\nMIDlet-1: T, , TestSprite\r\nMIDlet-Name: T\r\nMIDlet-Version: 1.0\r\nMIDlet-Vendor: T\r\nMicroEdition-Profile: MIDP-2.0\r\nMicroEdition-Configuration: CLDC-1.1\r\n' \
    > "$OUT/pkg/META-INF/MANIFEST.MF"
cp "$OUT/TestSprite.class" "$OUT/pkg/"
( cd "$OUT/pkg" && zip -q -r "$D/TestSprite.jar" META-INF TestSprite.class )
echo "built: $D/TestSprite.jar"
echo "run:   NOJME_LOG=1 ./bin/lr_run ./bin/nojme_libretro.so scripts/testsprite/TestSprite.jar 200 /tmp/spr 0"
echo "expect: [M3G-SPRITE] dst widths ~116px (z=40) and ~64px (z=72), scale=(12.0,12.0)"
