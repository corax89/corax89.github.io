import javax.microedition.midlet.*;
import javax.microedition.m3g.*;

/* TestSprite — RI-exact Sprite3D sizing selftest (v34.78, Bug 1).
 *
 * Scene: perspective camera (fovy=45, aspect=0.75, 240x320 viewport),
 * two 64x64 Sprite3D billboards with node scale 12 — the exact Ops Sniper
 * BGE tree configuration — at view depths z=40 and z=72.
 *
 * JSR-184 (Nokia RI): a Sprite3D is a 1x1 world-unit quad scaled by the
 * node scale. Projection: screen_w = scale * P00 * (viewport_w/2) / w,
 * P00 = 1/(tan(22.5)*0.75) = 3.21895 -> expected on-screen widths:
 *   near (z=40):  12 * 3.21895 * 120 / 40  ~ 115.9 px
 *   far  (z=72):  12 * 3.21895 * 120 / 72  ~  64.4 px
 * The core's [M3G-SPRITE] trace prints dst=[l,t..r,b] for the first draws;
 * the harness asserts the widths from the trace. (The pre-v34.78 heuristic
 * pinned BOTH at the 240px half-screen clamp.)
 */
public class TestSprite extends MIDlet {

    private static void p(String s) {
        System.out.println(s);
    }

    public void startApp() {
        World world = new World();

        Camera cam = new Camera();
        cam.setPerspective(45f, 0.75f, 1f, 1000f);
        world.addChild(cam);
        world.setActiveCamera(cam);

        Image2D tex = new Image2D(Image2D.RGB, 64, 64);

        Sprite3D near = new Sprite3D(true, tex, null);
        near.setScale(12f, 12f, 12f);
        near.setTranslation(0f, 0f, -40f);
        world.addChild(near);

        Sprite3D far = new Sprite3D(true, tex, null);
        far.setScale(12f, 12f, 12f);
        far.setTranslation(-20f, 0f, -72f);
        world.addChild(far);

        p("SPR-SETUP fov=45 aspect=0.75 vp=240x320 tex=64x64 scale=12 near z=40 far z=72");
        p("SPR-EXPECT near ~116px far ~64px (RI 1x1 world quad * node scale)");

        Image2D target = new Image2D(Image2D.RGB, 240, 320);
        Graphics3D g3d = Graphics3D.getInstance();
        g3d.bindTarget(target);
        g3d.setViewport(0, 0, 240, 320);
        g3d.render(world);
        g3d.releaseTarget();
        p("SPR-DONE");
    }

    public void pauseApp() {}

    public void destroyApp(boolean unconditional) {}
}
