package javax.microedition.m3g;

/* Minimal Sprite3D API surface used by TestSprite (RI-size selftest). */
public class Sprite3D extends Node {
    public Sprite3D(boolean isScaled, Image2D image, Appearance appearance) {}
    public boolean isScaled() { return true; }
    public void setImage(Image2D image) {}
    public Image2D getImage() { return null; }
    public void setAppearance(Appearance appearance) {}
    public void setCrop(int cropX, int cropY, int cropWidth, int cropHeight) {}
    public int getCropX() { return 0; }
    public int getCropY() { return 0; }
    public int getCropWidth() { return 0; }
    public int getCropHeight() { return 0; }
}
