package javax.microedition.m3g;

public class Background extends Object3D {
    public static final int BORDER = 33;
    public static final int REPEAT = 32;
    public Background() {}
    public void setColor(int argb) {}
    public int getColor() { return 0; }
    public void setImage(Image2D image) {}
    public void setImage(Image2D image, int modeX, int modeY) {}
    public Image2D getImage() { return null; }
    public void setImageMode(int modeX, int modeY) {}
    public int getImageModeX() { return 32; }
    public int getImageModeY() { return 32; }
    public void setCrop(int cropX, int cropY, int cropWidth, int cropHeight) {}
    public int getCropX() { return 0; }
    public int getCropY() { return 0; }
    public int getCropWidth() { return 0; }
    public int getCropHeight() { return 0; }
    public void setColorClearEnable(boolean enable) {}
    public void setDepthClearEnable(boolean enable) {}
}
