package javax.microedition.m3g;

public class Graphics3D {
    public static Graphics3D getInstance() { return null; }
    public void setViewport(int x, int y, int width, int height) {}
    public int getViewportX() { return 0; }
    public int getViewportY() { return 0; }
    public int getViewportWidth() { return 0; }
    public int getViewportHeight() { return 0; }
    public void setDepthRange(float near, float far) {}
    public float getDepthRangeNear() { return 0f; }
    public float getDepthRangeFar() { return 0f; }
    public Object getTarget() { return null; }
    public int getHints() { return 0; }
    public void releaseTarget() {}
    public void bindTarget(Object target) {}
    public void bindTarget(Object target, boolean depthBuffer, int hints) {}
    public void render(World world) {}
    public void render(World world, Transform transform) {}
    public void render(Node node, Transform transform) {}
    public void clear(Background background) {}
    public int addLight(Light light, Transform transform) { return 0; }
}
