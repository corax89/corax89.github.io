package javax.microedition.m3g;

public class Light extends Node {
    public static final int AMBIENT = 128;
    public static final int DIRECTIONAL = 129;
    public static final int SPOT = 130;
    public Light() {}
    public void setMode(int mode) {}
    public int getMode() { return 129; }
    public void setColor(int rgb) {}
    public void setIntensity(float intensity) {}
}
