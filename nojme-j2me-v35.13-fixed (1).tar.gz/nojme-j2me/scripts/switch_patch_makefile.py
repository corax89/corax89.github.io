#!/usr/bin/env python3
"""Add `platform=switch` (devkitPro NRO build) and the `switchui`
(Linux SDL2 verification build of the same frontend) targets to the
Makefile. TAB-SAFE: patches with python, never with the Edit tool.

Run: python3 scripts/switch_patch_makefile.py
"""

PATH = "Makefile"
src = open(PATH, encoding="utf-8").read()

def replace_once(s, old, new, what):
    assert old in s, "anchor missing: " + what
    assert s.count(old) == 1, "anchor not unique: " + what
    return s.replace(old, new)

T = "\t"

# ------------------------------------------------------------------
# 1. platform=switch branch — insert BEFORE `else ifeq ($(platform), linux)`
# ------------------------------------------------------------------
switch_branch = """ifeq ($(platform), switch)
\t# ==============================================
\t# Nintendo Switch (devkitPro: devkitA64 + libnx + switch-SDL2)
\t# ==============================================
\t# Prerequisites (devkitPro pacman):
\t#   switch-dev pacman group  -> devkitA64, libnx, general-tools
\t#   switch-SDL2              -> $(PORTLIBS)/lib/libSDL2.a + headers
\t# Build:      make platform=switch
\t# Output:     bin/nojme.nro (+ bin/nojme_switch.elf/.nacp)
\t# Install:    copy nojme.nro to sdmc:/switch/j2me/nojme.nro
\tDEVKITPRO ?= /opt/devkitpro
\tDEVKITA64  := $(DEVKITPRO)/devkitA64
\tLIBNX      := $(DEVKITPRO)/libnx
\tPORTLIBS   := $(DEVKITPRO)/portlibs

\tSWITCH_APP_TITLE  ?= J2ME Emulator
\tSWITCH_APP_AUTHOR ?= nojme
\tSWITCH_APP_VER    ?= 1.0.0

\tCC  := $(DEVKITA64)/bin/aarch64-none-elf-gcc
\tCXX := $(DEVKITA64)/bin/aarch64-none-elf-g++
\tAR  := $(DEVKITA64)/bin/aarch64-none-elf-ar
\tSTRIP := $(DEVKITA64)/bin/aarch64-none-elf-strip
\tNACPTOOL := $(DEVKITPRO)/tools/bin/nacptool
\tELF2NRO  := $(DEVKITPRO)/tools/bin/elf2nro

\tCFLAGS := -Wall -Wextra -std=c11 \\
\t-I$(INCDIR) -I$(SRCDIR) -I$(SRCDIR)/include \\
\t-D__SWITCH__ -D_GNU_SOURCE -DJ2ME_DEBUG=0 \\
\t-O2 -MMD -MP \\
\t-march=armv8-a+crc+crypto -mtune=cortex-a57 \\
\t-fno-strict-aliasing -ffunction-sections -fdata-sections \\
\t-I$(LIBNX)/include -I$(PORTLIBS)/include -I$(PORTLIBS)/include/SDL2

\tLDFLAGS := -specs=$(LIBNX)/switch.specs \\
\t-L$(PORTLIBS)/lib -lSDL2 \\
\t-Wl,--gc-sections \\
\t-lm

\tSWITCH_SRCS := $(ALL_APP_SRCS) \\
\t\t$(SRCDIR)/switch/switch_ui.c \\
\t\t$(SRCDIR)/switch/switch_font.c \\
\t\t$(SRCDIR)/switch/switch_scaling.c

\tSWITCH_OBJS := $(patsubst $(SRCDIR)/%.c,$(OBJDIR)/switch/%.o,$(SWITCH_SRCS))
\tSWITCH_OBJS += $(patsubst $(SRCDIR)/amr/%.c,$(OBJDIR)/switch/amr/%.o,$(AMR_C_SRCS))

\tSWITCH_ELF := $(BINDIR)/nojme_switch.elf
\tSWITCH_NACP := $(BINDIR)/nojme_switch.nacp
\tSWITCH_NRO := $(BINDIR)/nojme.nro
\tTARGET := $(SWITCH_NRO)
\tARCH = aarch64
\tPLATFORM_NAME = Nintendo Switch (devkitPro)

else ifeq ($(platform), linux)
"""

src = replace_once(src, "ifeq ($(platform), linux)\n", switch_branch, "switch platform branch")


# ------------------------------------------------------------------
# 2. switch target rules — insert before the "Utility targets" section
# ------------------------------------------------------------------
switch_rules = """
# ==============================================
# Nintendo Switch NRO build (platform=switch)
# ==============================================
switch: switch-dirs $(SWITCH_NRO)
\t@echo ""
\t@echo "============================================"
\t@echo "Switch NRO built successfully!"
\t@echo "============================================"
\t@echo "Output:  $(SWITCH_NRO)"
\t@echo "Install: copy to sdmc:/switch/j2me/ and run via HBmenu"
\t@ls -lh $(SWITCH_NRO)

switch-dirs:
\t@mkdir -p $(OBJDIR)/switch/jvm $(OBJDIR)/switch/midp $(OBJDIR)/switch/render \\
\t$(OBJDIR)/switch/utils $(OBJDIR)/switch/midi $(OBJDIR)/switch/sdl \\
\t$(OBJDIR)/switch/switch $(BINDIR)

$(SWITCH_ELF): $(SWITCH_OBJS)
\t@echo "  LD  $(SWITCH_ELF)"
\t$(CC) $^ -o $@ $(LDFLAGS)

$(SWITCH_NACP):
\t@echo "  NACP $(SWITCH_NACP)"
\t$(NACPTOOL) --create "$(SWITCH_APP_TITLE)" "$(SWITCH_APP_AUTHOR)" "$(SWITCH_APP_VER)" $@

$(SWITCH_NRO): $(SWITCH_ELF) $(SWITCH_NACP) switch/icon.jpg
\t@echo "  NRO  $(SWITCH_NRO)"
\t$(ELF2NRO) $(SWITCH_ELF) $@ --icon=switch/icon.jpg --nacp=$(SWITCH_NACP)

$(OBJDIR)/switch/%.o: $(SRCDIR)/%.c
\t@mkdir -p $(dir $@)
\t@echo "  CC  $<"
\t$(CC) $(CFLAGS) -c $< -o $@

$(OBJDIR)/switch/amr/%.o: $(SRCDIR)/amr/%.c
\t@mkdir -p $(dir $@)
\t@echo "  CC  $<"
\t$(CC) $(CFLAGS) $(AMR_INCS) -c $< -o $@

.PHONY: switch switch-dirs

# ==============================================
# switchui — Linux SDL2 VERIFICATION build of the Switch frontend
# (same sources, same -D__SWITCH__; for sandbox/host verification only)
# ==============================================
SWITCHUI_TARGET := $(BINDIR)/switchui-verify
SWITCHUI_SRCS := $(ALL_APP_SRCS) \\
\t$(SRCDIR)/switch/switch_ui.c \\
\t$(SRCDIR)/switch/switch_font.c \\
\t$(SRCDIR)/switch/switch_scaling.c
SWITCHUI_OBJS := $(patsubst $(SRCDIR)/%.c,$(OBJDIR)/switchui/%.o,$(SWITCHUI_SRCS))
SWITCHUI_OBJS += $(patsubst $(SRCDIR)/amr/%.c,$(OBJDIR)/switchui/amr/%.o,$(AMR_C_SRCS))
SWITCHUI_CC ?= gcc
# SDL2 discovery: pkg-config, else override via env:
#   SWITCHUI_SDL_CFLAGS / SWITCHUI_SDL_LIBS
SWITCHUI_SDL_CFLAGS ?= $(shell pkg-config --cflags sdl2 2>/dev/null)
SWITCHUI_SDL_LIBS ?= $(shell pkg-config --libs sdl2 2>/dev/null || echo -lSDL2)

SWITCHUI_CFLAGS := -Wall -Wextra -std=c11 -O2 \\
\t-I$(INCDIR) -I$(SRCDIR) -I$(SRCDIR)/include \\
\t-D__SWITCH__ -D_GNU_SOURCE -DJ2ME_DEBUG=0 \\
\t$(SWITCHUI_SDL_CFLAGS) -MMD -MP

SWITCHUI_LDFLAGS := -lm -pthread $(SWITCHUI_SDL_LIBS)

switchui: switchui-dirs $(SWITCHUI_TARGET)
\t@echo ""
\t@echo "Switch-frontend verification binary built: $(SWITCHUI_TARGET)"

switchui-dirs:
\t@mkdir -p $(OBJDIR)/switchui/jvm $(OBJDIR)/switchui/midp $(OBJDIR)/switchui/render \\
\t$(OBJDIR)/switchui/utils $(OBJDIR)/switchui/midi $(OBJDIR)/switchui/sdl \\
\t$(OBJDIR)/switchui/switch $(BINDIR)

$(SWITCHUI_TARGET): $(SWITCHUI_OBJS)
\t$(SWITCHUI_CC) $^ -o $@ $(SWITCHUI_LDFLAGS)

$(OBJDIR)/switchui/%.o: $(SRCDIR)/%.c
\t@mkdir -p $(dir $@)
\t@echo "  CC  $<"
\t$(SWITCHUI_CC) $(SWITCHUI_CFLAGS) -c $< -o $@

$(OBJDIR)/switchui/amr/%.o: $(SRCDIR)/amr/%.c
\t@mkdir -p $(dir $@)
\t@echo "  CC  $<"
\t$(SWITCHUI_CC) $(SWITCHUI_CFLAGS) $(AMR_INCS) -c $< -o $@

.PHONY: switchui switchui-dirs

# ==============================================
# Utility targets
# ==============================================
"""

src = replace_once(src, "\n# ==============================================\n# Utility targets\n# ==============================================\n", switch_rules, "switch target rules")

# ------------------------------------------------------------------
# 3. BUILD_OBJS self-heal coverage for the new object sets
# ------------------------------------------------------------------
src = replace_once(src,
    "BUILD_OBJS := $(ALL_LIBRETRO_OBJS) $(APP_OBJS) $(HEADLESS_OBJS)",
    "BUILD_OBJS := $(ALL_LIBRETRO_OBJS) $(APP_OBJS) $(HEADLESS_OBJS) $(SWITCH_OBJS) $(SWITCHUI_OBJS)",
    "BUILD_OBJS coverage")

open(PATH, "w", encoding="utf-8").write(src)
print("Makefile patched OK")
