#!/usr/bin/env python3
"""Minimal M3G file dumper (JSR-184). Dumps object table with references."""
import struct, sys

OBJ_NAMES = {
    0: 'Header', 1: 'AnimationController', 2: 'AnimationTrack', 3: 'KeyframeSequence',
    5: 'CompositingMode', 6: 'Fog', 8: 'Camera', 9: 'Light', 10: 'Mesh',
    11: 'MorphingMesh', 12: 'SkinnedMesh', 13: 'Texture2D', 14: 'Material',
    15: 'PolygonMode', 16: 'Appearance', 17: 'Group', 18: 'World', 19: 'Background',
    20: 'Sprite3D', 21: 'Image2D', 22: 'VertexArray', 23: 'VertexBuffer',
    24: 'IndexBuffer(TriangleStripArray)', 32: 'ExternalReference',
    255: 'ExternalReference(alt)',
}

def read_u8(d, p): return d[p], p+1
def read_u16(d, p): return struct.unpack_from('>H', d, p)[0], p+2
def read_u32(d, p): return struct.unpack_from('>I', d, p)[0], p+4
def read_i32(d, p): return struct.unpack_from('>i', d, p)[0], p+4

def dump(path):
    data = open(path, 'rb').read()
    p = 0
    ver, export = data[0], data[1]
    fsize, objcount = struct.unpack_from('>II', data, 2)
    print(f'File: {path} version=0x{ver:02x} export={export} fsize={fsize} objcount={objcount} actual={len(data)}')
    p = 10
    total_objects = 0
    obj_idx = 0
    while p < len(data) - 8:
        comp = data[p]
        sec_len, unclen = struct.unpack_from('>II', data, p+1)
        if sec_len == 0 or p + sec_len > len(data):
            print(f'  bad section at {p}: len={sec_len}')
            break
        print(f'Section at 0x{p:x}: comp={comp} len={sec_len} unclen={unclen} objects={objcount}')
        sec = data[p+12:p+sec_len]
        if comp == 1:
            # zlib
            import zlib
            try:
                sec = zlib.decompress(sec)
            except Exception as e:
                print('  zlib error:', e)
                p += sec_len
                continue
        sp = 0
        objs_in_sec = []
        while sp < len(sec) and obj_idx < objcount + 16:
            if sp + 5 > len(sec): break
            otype = sec[sp]
            olen = struct.unpack_from('>I', sec, sp+1)[0]
            body = sec[sp+5:sp+5+olen]
            objs_in_sec.append((obj_idx, otype, olen, body[:24].hex()))
            # parse user ID / references quickly for interesting types
            extra = ''
            try:
                if otype == 17 or otype == 18:  # Group/World
                    uid = struct.unpack_from('>i', body, 0)[0]
                    extra = f' userID={uid}'
                elif otype == 10:  # Mesh
                    extra = f' body0-16={body[:16].hex()}'
                elif otype == 32 or otype == 255:
                    # ExternalReference: length + URI bytes
                    ulen = struct.unpack_from('>I', body, 0)[0]
                    uri = body[4:4+ulen].decode('utf8', 'replace')
                    extra = f' URI="{uri}"'
                elif otype == 8:  # Camera
                    extra = f' body={body[:32].hex()}'
                elif otype == 13:  # Texture2D
                    extra = ''
                elif otype == 21:  # Image2D
                    fmt = body[0]
                    w, h = struct.unpack_from('>HH', body, 1)
                    extra = f' format={fmt} {w}x{h}'
            except Exception:
                pass
            name = OBJ_NAMES.get(otype, f'?{otype}')
            print(f'  [{obj_idx}] {name} len={olen}{extra} head={body[:20].hex()}')
            obj_idx += 1
            sp += 5 + olen
        p += sec_len
    print(f'total objects dumped: {obj_idx}')

if __name__ == '__main__':
    dump(sys.argv[1])
