#!/bin/bash
# v34.69: AMR-NB decoder self-check. Builds scripts/amr_ab.c against the
# tree's src/amr (pure C), decodes the .amr resources from
# games/BlackShark3D.jar + a deterministic synthetic pass (all FT modes,
# erasures), and compares the FNV-1a of the PCM stream against the
# reference recorded during the v34.69 C++->C migration (the C++
# opencore-amrnb decoder produced the bit-identical PCM).
#
# Reference PCM FNV-1a: 39e97312c8e5c449  (1 935 360 bytes)
# The synthetic frames are LCG-deterministic, so the hash is exact.
set -e
D="$(cd "$(dirname "$0")/.." && pwd)"
T=/tmp/amr_selfcheck
mkdir -p $T/data $T/obj
rm -rf $T/data/snd $T/obj/*
[ -f "$D/games/BlackShark3D.jar" ] || { echo "no BlackShark3D.jar in games/"; exit 2; }
unzip -o -q "$D/games/BlackShark3D.jar" 'snd/*.amr' -d $T/data

INCS="-I$D/src/amr -I$D/src/amr/oscl \
 -I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/common/include \
 -I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/include \
 -I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/amr_nb/dec/src \
 -I$D/src/amr/opencore/codecs_v2/audio/gsm_amr/common/dec/include"

echo "== compiling AMR-NB decoder (plain C) =="
n=0
for f in $D/src/amr/amr_nb_dec.c $(find $D/src/amr/opencore -name '*.c' | sort); do
  n=$((n+1))
  gcc -O2 -Wall $INCS -c "$f" -o $T/obj/$(printf '%03d' $n).o
done
gcc -O2 -Wall $INCS -c $D/scripts/amr_ab.c -o $T/obj/amr_ab.o
gcc $T/obj/*.o -o $T/amr_ab -lm
echo "== decoding (${n} C files + harness) =="
$T/amr_ab $T/out.pcm $T/data/snd/*.amr | tail -3
hash=$($T/amr_ab $T/out2.pcm $T/data/snd/*.amr | grep 'FNV-1a' | grep -oE '[0-9a-f]{16}$')
echo "== PCM hash: $hash (reference: 39e97312c8e5c449) =="
if [ "$hash" = "39e97312c8e5c449" ]; then
  echo "AMR-NB DECODER SELF-CHECK PASSED (bit-identical to the v34.68 C++ build)"
else
  echo "AMR-NB DECODER SELF-CHECK FAILED"
  exit 1
fi
