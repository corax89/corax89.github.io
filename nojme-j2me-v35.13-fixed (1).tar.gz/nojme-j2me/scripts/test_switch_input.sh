#!/bin/bash
# v34.90 Switch SINGLE-PUMP input + i18n — FUNCTIONAL test runner.
#
# Compiles scripts/test_switch_input.c (white-box: #includes sdl_graphics.c
# with -D__SWITCH__) against the SDL2 header snapshot + the system SDL2
# runtime, LINKING the real switch_ui.c / switch_font.c / switch_scaling.c
# (compiled WITHOUT -D__SWITCH__ so settings.ini lands in NOJME_SWITCH_UI_DIR).
# Then runs it with the dummy video/audio drivers and a REAL SDL2 virtual
# joystick: taps, held-state persistence, event-loss resilience, the
# single-pump no-steal rule, hotplug, RU/EN toggle + ini persistence and a
# full autotest-driven menu session.
#
# Requirements: host gcc, SDL2 runtime (libSDL2-2.0.so.0), SDL2 headers
# (any >= 2.24 with the virtual-joystick API; work/v3487/sdl2inc = 2.30.12).
set -u
T=${T:-$(cd "$(dirname "$0")/.." && pwd)}
SDL2_INC=${SDL2_INC:-/home/z/my-project/work/sdl2-headers}
OUT=${OUT:-/tmp/test_switch_input}
OBJS=${OBJS:-/tmp/tsi_objs}

# link against the runtime-only system SDL2 (symlink libSDL2.so)
LINKDIR=$(mktemp -d)
ln -sf "$(ldconfig -p | awk '/libSDL2-2\.0\.so\.0/{print $NF; exit}')" "$LINKDIR/libSDL2.so"
trap 'rm -rf "$LINKDIR"' EXIT

mkdir -p "$OBJS"
CFLAGS="-D_GNU_SOURCE -DJ2ME_DEBUG=0 -I$T/include -I$T/src -I$T/src/include -I$SDL2_INC -Wall"

# TU 1: the white-box test (sdl_graphics.c inside) — WITH __SWITCH__
if ! gcc -c "$T/scripts/test_switch_input.c" -D__SWITCH__ $CFLAGS -o "$OBJS/tsi_main.o" 2>/tmp/tsi_err.txt; then
    echo "COMPILE FAILED (test TU):"; head -30 /tmp/tsi_err.txt; exit 2
fi
# TU 2..5: the REAL frontend — WITHOUT __SWITCH__ (host paths for ini);
# switch_ui.c + switch_trace.c get -DNOJME_SWITCH_TRACE so the v34.91
# freeze-triage breadcrumbs/log are exercised (log -> $NOJME_SWITCH_UI_DIR).
for f in switch/switch_ui.c switch/switch_font.c switch/switch_scaling.c switch/switch_trace.c; do
    o="$OBJS/$(basename "$f" .c).o"
    case "$f" in
        switch/switch_ui.c|switch/switch_trace.c) extra="-DNOJME_SWITCH_TRACE" ;;
        *) extra="" ;;
    esac
    if ! gcc -c "$T/src/$f" $CFLAGS $extra -o "$o" 2>/tmp/tsi_err.txt; then
        echo "COMPILE FAILED ($f):"; head -30 /tmp/tsi_err.txt; exit 2
    fi
done

# v34.98: switch_ui.c calls jvm_frontend_pause_begin/end (v34.97) and the
# trace beat weak-links jvm_frontend_pause_snapshot — the white-box build
# has no JVM, so link throwaway no-op stubs.
cat > "$OBJS/tsi_stubs.c" <<'EOF'
void jvm_frontend_pause_begin(void) { }
void jvm_frontend_pause_end(void) { }
int  jvm_frontend_pause_snapshot(void) { return 0; }
EOF
gcc -c "$OBJS/tsi_stubs.c" -o "$OBJS/tsi_stubs.o" || { echo "STUB COMPILE FAILED"; exit 2; }

if ! gcc -o "$OUT" "$OBJS/tsi_main.o" "$OBJS/switch_ui.o" "$OBJS/switch_font.o" \
        "$OBJS/switch_scaling.o" "$OBJS/switch_trace.o" "$OBJS/tsi_stubs.o" -L"$LINKDIR" -lSDL2 -lm -pthread 2>/tmp/tsi_err.txt; then
    echo "LINK FAILED:"; head -30 /tmp/tsi_err.txt; exit 2
fi

SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy timeout 240 "$OUT" 2>/tmp/tsi_run.log
rc=$?
if [ $rc -ne 0 ]; then
    echo "RUN FAILED (rc=$rc):"; tail -30 /tmp/tsi_run.log; exit $rc
fi
echo "switch-input functional test: ALL PASSED"
