/*
 * gc_bench.c — v34.58/v34.59 детерминированный бенчмарк аллокатора/GC.
 * Сборка (из корня nojme-j2me):
 *   gcc -O2 -std=c11 -Iinclude -Isrc -Isrc/include -DJ2ME_DEBUG=0 \
 *       scripts/gc_bench.c src/jvm/heap.c -lm -pthread -o /tmp/gc_bench
 * (стабы те же, что в gc_stress.c)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <time.h>
#include <pthread.h>

#include "jvm.h"
#include "heap.h"
#include "opcodes.h"   /* T_FLOAT для float[]-churn фазы 2 */
#include "midp.h"

volatile int g_gc_safepoint_request = 0;
volatile int g_jvm_main_thread_executing = 0;
int g_j2me_runtime_debug = 0;
int g_hashtable_count = 0;
bool g_hashtable_peer_alive[4096];
char g_hashtables[4096 * 32];
void* intern_pool[1024];
int intern_pool_count = 0;
int j2me_log_enabled(void) { return 0; }
int j2me_log_ungated(const char* fmt, ...) { (void)fmt; return 0; }
int j2me_fprintf_gate(FILE* s, const char* f, ...) { (void)s; (void)f; return 0; }

/* ==== v34.59 мини-safepoint для 2-поточной фазы P4: точная копия ====
 * продакшн-контракта (threads.c), но на spin/yield: park flush'ит свой
 * TLAB-чанк ДО arrival-count; wait_arrivals реально ждёт прибытия;
 * release снимает запрос. Однопоточные фазы это не трогают (workers=0). */
#include <sched.h>
static volatile int g_bench_arrived = 0;
static volatile int g_bench_workers = 0;

void jvm_gc_safepoint_park(void) {
    if (g_gc_safepoint_request) {
        heap_tlab_flush_self();            /* как продакшн threads.c v34.59 */
        __sync_fetch_and_add(&g_bench_arrived, 1);
        while (g_gc_safepoint_request) sched_yield();
        __sync_fetch_and_sub(&g_bench_arrived, 1);
    }
}
void jvm_gc_safepoint_release(void) {
    g_gc_safepoint_request = 0;
    __sync_synchronize();
}
void jvm_gc_safepoint_wake_sleepers(void) {}   /* v34.59: heap.c broadcast hook */
int  jvm_gc_safepoint_wait_arrivals(int expected, int timeout_ms) {
    (void)timeout_ms;
    /* Ограниченное ожидание (как продакшн 2s): страховка от гонки
     * «census прочитал 1, воркер уже вышел» — таймаут уводит GC в
     * SAFE ABORT, следующий gc_collect видит workers=0. */
    long spins = 0;
    while (g_bench_arrived < expected && spins < 200000000L) {
        sched_yield();
        spins++;
    }
    return g_bench_arrived;
}
int  jvm_live_vm_thread_count(void) { return g_bench_workers; }
int  jvm_current_os_thread_is_vm_runner(void) { return 0; }
void jvm_dump_all_threads(void) {}
JavaThread* thread_current(JVM* jvm) { (void)jvm; return NULL; }
void native_gc_notify(void) {}
int  native_get_string_value_slot(JVM* j) { (void)j; return -1; }
int  native_get_string_count_slot(JVM* j) { (void)j; return -1; }
int  native_get_string_hash_slot(JVM* j) { (void)j; return -1; }
JavaValue native_get_field_value(JavaObject* o, const char* n) { (void)o; (void)n; JavaValue v; memset(&v,0,sizeof v); return v; }
JavaClass* jvm_load_class(JVM* j, const char* n) { (void)j; (void)n; return NULL; }
const char* classfile_get_class_name(JavaClass* c, int i) { (void)c; (void)i; return NULL; }
void hashtable_free_peer(int idx) { (void)idx; }
JavaObject** m3g_registry_get_objects(int* c) { if(c)*c=0; return NULL; }
JavaObject*** m3g_gc_extra_roots(int* c) { if(c)*c=0; return NULL; }

static JVM jvm_storage;
static JVM* jvm = &jvm_storage;

#define RING 2048
static void* ring[RING];

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

/* P4: воркер мелкого churn — как игровой поток 3D-игры. */
static volatile long g_w_allocs = 0;
static void* worker_churn(void* arg) {
    (void)arg;
    g_bench_workers = 1;
    unsigned seed = 12345;
    for (int i = 0; i < 4000000; i++) {
        size_t sz = 24 + (size_t)(rand_r(&seed) & 31) * 8;
        void* p = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
        if (!p) break;   /* heap-давление — main перезапустит GC */
        g_w_allocs++;
    }
    /* как продакшн pthread_thread_runner v34.59: закрыть чанк ДО смерти */
    heap_tlab_flush_self();
    g_bench_workers = 0;
    return NULL;
}

int main(void) {
    memset(&jvm_storage, 0, sizeof jvm_storage);
    srand(777);
    if (heap_init(jvm, 16u << 20, 16u << 20) != JNI_OK) { printf("init fail\n"); return 1; }
    for (int i = 0; i < RING; i++) gc_add_root(jvm, &ring[i]);

    /* ================= PHASE 0: чистая скорость аллокатора (v34.59) =================
     * Изоляция СТОИМОСТИ ПУТИ АЛЛОКАЦИИ — проверка гипотезы о 3D-играх:
     * «постоянное выделение маленьких кусочков для передачи координат».
     * Все объекты УДЕРЖИВАЮТСЯ (мусора нет — GC не запускается вообще),
     * поэтому фаза меряет ровно одну вещь: наносекунды на аллокацию.
     * v34.58: ticket-lock + pop бакета на каждую мелочь.
     * v34.59: bump в TLAB-чанке без блокировок. */
    printf("P0 pure alloc rate (no GC) ...\n");
    {
        const size_t prof0[] = { 24, 40, 56, 64, 80, 96, 112, 128, 160, 224, 288, 416, 976 };
        const int NP0 = (int)(sizeof prof0 / sizeof prof0[0]);
        enum { P0N = 48000 };                 /* ~11.8 МБ < 16 МБ кучи */
        static void* keep[P0N];
        double t0 = now_ms();
        for (int i = 0; i < P0N; i++) {
            size_t sz = prof0[i % NP0] + (size_t)(rand() & 3) * 8;
            keep[i] = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
            if (!keep[i]) { printf("P0 unexpected OOM at %d\n", i); break; }
        }
        double t1 = now_ms();
        printf("P0 pure alloc:   allocs=%d wall=%.1fms  => %.2f Mallocs/s (%.0f ns/alloc)\n",
               P0N, t1 - t0, P0N / (t1 - t0) / 1000.0,
               (t1 - t0) * 1e6 / P0N);
        memset(keep, 0, sizeof keep);
        gc_collect(jvm);
    }

    /* Профиль размеров: имитация стринг-churn игр — мелкие доминируют */
    const size_t profile[] = { 88, 104, 120, 136, 168, 200, 264, 392, 520,
                               88, 104, 120, 136, 88, 104, 96, 112, 128,
                               1032, 2056, 88, 104, 520, 264, 136 };
    const int NP = (int)(sizeof profile / sizeof profile[0]);

    long total_allocs = 0;
    long gc_count = 0;
    double t0 = now_ms();

    /* ~4 млн аллокаций; 1/8 живёт в ring (вытеснение), GC каждые 16384 */
    for (long i = 0; i < 4200000; i++) {
        size_t sz = profile[i % NP] + (size_t)(rand() & 7) * 8;
        void* p = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
        if (!p) {
            /* ой: heap полон живыми? ring держит ~1.3МБ — быть не может */
            printf("unexpected OOM at %ld\n", i);
            break;
        }
        ring[i % RING] = p;
        total_allocs++;
        if ((i & 16383) == 16383) {
            gc_collect(jvm);
            gc_count++;
        }
    }
    double t1 = now_ms();
    gc_collect(jvm);
    gc_count++;

    printf("P1 flat churn:   allocs=%ld gc_count=%ld wall=%.1fms  => %.2f Mallocs/s, %.3f ms/GC\n",
           total_allocs, gc_count, t1 - t0,
           total_allocs / (t1 - t0) / 1000.0,
           (t1 - t0) / (double)gc_count);

    /* ================= PHASE 2: полевой граф + churn (v34.59) =================
     * Имитация 3D-игры (Asphalt-профиль): живой граф объектов со ссылочными
     * полями (Node/Transform-подобные) + постоянный мусор такого же профиля.
     * Измеряем прежде всего СТОИМОСТЬ GC-паузы (mark по живому графу +
     * sweep по мусору) — до/после пер-классового кэша разметки. */
    printf("P2 field graph + churn ...\n");
    {
        /* Класс Node: 6 ссылок, 1 long, 1 int -> 9 слотов, ссылки {0,2,4,6,7,8} */
        static char D_REF[] = "Lbench/Node;";
        static char D_LNG[] = "J";
        static char D_INT[] = "I";
        JavaField nf[8];
        memset(nf, 0, sizeof nf);
        nf[0].descriptor = D_REF; nf[0].name = "r0";
        nf[1].descriptor = D_INT; nf[1].name = "i0";
        nf[2].descriptor = D_REF; nf[2].name = "r1";
        nf[3].descriptor = D_LNG; nf[3].name = "l0";   /* слоты 3,4 */
        nf[4].descriptor = D_REF; nf[4].name = "r2";
        nf[5].descriptor = D_INT; nf[5].name = "i1";
        nf[6].descriptor = D_REF; nf[6].name = "r3";
        nf[7].descriptor = D_REF; nf[7].name = "r4";
        /* слоты: r0=0 i0=1 r1=2 l0=3+4 r2=5 i1=6 r3=7 r4=8 -> всего 9, ссылки {0,2,5,7,8}... */
        /* пересчёт: порядок [r0,i0,r1,l0,r2,i1,r3,r4]:
         * r0@0, i0@1, r1@2, l0@3..4, r2@5, i1@6, r3@7, r4@8 => ссылки {0,2,5,7,8} */

        JavaClass* k_node = (JavaClass*)calloc(1, sizeof(JavaClass));
        k_node->class_name = "bench/Node";
        k_node->fields = nf;
        k_node->fields_count = 8;
        const int NODE_SLOTS = 9;
        k_node->instance_size = sizeof(ObjectHeader) + (size_t)NODE_SLOTS * sizeof(JavaValue);
        static const int node_ref_slots[5] = {0, 2, 5, 7, 8};

        /* живой граф: цепочка + поперечные связи */
        enum { LIVE = 60000 };
        static JavaObject* live[LIVE];
        for (int i = 0; i < LIVE; i++) {
            void* p = heap_alloc(jvm, k_node->instance_size, k_node, OBJ_TYPE_OBJECT);
            if (!p) { printf("P2 OOM building graph at %d\n", i); break; }
            live[i] = (JavaObject*)p;
            if (i > 0) {
                live[i]->fields[node_ref_slots[0]].ref = live[i - 1];          /* цепь */
                live[i]->fields[node_ref_slots[1]].ref = live[i / 2];          /* дерево */
                live[i]->fields[node_ref_slots[2]].ref = live[(i * 7) % (i + 1)];
                live[i]->fields[node_ref_slots[3]].ref = live[i >= 4 ? i - 4 : 0];
                live[i]->fields[node_ref_slots[4]].ref = live[(i * 13) % (i + 1)];
            }
        }
        for (int i = 0; i < LIVE; i += 64) ring[i % RING] = live[i];  /* корни */
        gc_collect(jvm);   /* прогрев: разметка класса строится здесь же */

        /* churn: мусор того же класса (недостижим) + float[]/int[] массивы;
         * каждый 8192-й шаг — gc_collect с замером паузы */
        long p2_allocs = 0;
        long p2_gcs = 0;
        double p2_gc_ms = 0.0, p2_gc_max = 0.0;
        double p2_t0 = now_ms();
        for (long i = 0; i < 600000; i++) {
            void* p;
            if ((i & 1) == 0) {
                p = heap_alloc(jvm, k_node->instance_size, k_node, OBJ_TYPE_OBJECT);
                if (p) {
                    JavaObject* o = (JavaObject*)p;
                    /* мёртвые поля ссылаются на живое — реалистично и не спасает */
                    o->fields[node_ref_slots[0]].ref = live[i % LIVE];
                    o->fields[node_ref_slots[2]].ref = live[(i * 3) % LIVE];
                }
            } else {
                p = heap_alloc_array(jvm, 6 /* T_FLOAT */, (jsize[]){3, 4, 16, 64}[i & 3], NULL);
            }
            if (!p) { printf("P2 OOM at %ld\n", i); break; }
            p2_allocs++;

            if ((i & 8191) == 8191) {
                double g0 = now_ms();
                gc_collect(jvm);
                double g1 = now_ms();
                double d = g1 - g0;
                p2_gc_ms += d;
                if (d > p2_gc_max) p2_gc_max = d;
                p2_gcs++;
            }
        }
        double p2_t1 = now_ms();
        /* контроль: связи живого графа не порваны (выборочно) */
        int bad_links = 0;
        for (int i = 1; i < LIVE; i += 997) {
            if (live[i]->fields[node_ref_slots[0]].ref != live[i - 1]) bad_links++;
            if (((GCObjectHeader*)live[i] - 1)->type == OBJ_TYPE_FREE) bad_links++;
        }
        printf("P2 field graph:  allocs=%ld gcs=%ld alloc_rate=%.2f M/s\n"
               "                 GC pause: avg=%.3f ms max=%.3f ms (live=%d objs, ~%zu KB), bad_links=%d\n",
               p2_allocs, p2_gcs, p2_allocs / (p2_t1 - p2_t0) / 1000.0,
               p2_gc_ms / (p2_gcs ? p2_gcs : 1), p2_gc_max,
               LIVE, (size_t)LIVE * (k_node->instance_size + sizeof(GCObjectHeader)) / 1024,
               bad_links);
        free(k_node);
    }

    /* ================= PHASE 3: TLAB — мелкий 3D-churn (v34.59) =================
     * Профиль «передачи координат»: маленькие массивы и объекты
     * (float[3]/float[16]/векторы), 7/8 мусор, живые — в маленьком ring.
     * Здесь доминирует стоимость пути аллокации: v34.58 брал ticket-lock
     * на каждую мелочь, v34.59 — раз на чанк (TLAB). */
    printf("P3 tlab small churn ...\n");
    {
        const size_t prof3[] = { 24, 40, 56, 64, 80, 96, 112, 128, 160, 224, 288, 416, 976 };
        const int NP3 = (int)(sizeof prof3 / sizeof prof3[0]);
        void* ring3[256];
        memset(ring3, 0, sizeof ring3);
        long a = 0; long g = 0;
        double t0 = now_ms();
        for (long i = 0; i < 8000000L; i++) {
            size_t sz = prof3[i % NP3] + (size_t)(rand() & 3) * 8;
            void* p = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
            if (!p) { printf("P3 unexpected OOM at %ld\n", i); break; }
            ring3[i & 255] = p;   /* 1/256 живёт, остальные — мусор */
            a++;
            if ((i & 16383) == 16383) { gc_collect(jvm); g++; }  /* ~4 МБ мусора на интервал — без auto-GC */
        }
        double t1 = now_ms();
        gc_collect(jvm); g++;
        printf("P3 tlab churn:    allocs=%ld gc_count=%ld wall=%.1fms  => %.2f Mallocs/s, %.3f ms/GC\n",
               a, g, t1 - t0, a / (t1 - t0) / 1000.0, (t1 - t0) / (double)g);
        memset(ring3, 0, sizeof ring3);
        gc_collect(jvm);
    }

    /* ================= PHASE 4: TLAB — 2 потока (v34.59) =================
     * Многопоточный мелкий churn: главный поток + pthread. В v34.58 оба
     * потока дрались за один ticket-lock на каждую мелочь; в v34.59 у
     * каждого свой чанк. GC по-прежнему из главного потока. */
    printf("P4 tlab 2-thread churn ...\n");
    {
        struct timespec ts0, ts1;
        clock_gettime(CLOCK_MONOTONIC, &ts0);
        pthread_t th;
        pthread_create(&th, NULL, worker_churn, NULL);
        long a = 0, g = 0;
        for (long i = 0; i < 4000000L; i++) {
            size_t sz = 24 + (size_t)(rand() & 31) * 8;
            void* p = heap_alloc(jvm, sz, NULL, OBJ_TYPE_OBJECT);
            if (!p) { printf("P4 unexpected OOM at %ld\n", i); break; }
            a++;
            if ((i & 16383) == 16383) { gc_collect(jvm); g++; }  /* обе нити: ~4 МБ на интервал */
        }
        pthread_join(th, NULL);
        clock_gettime(CLOCK_MONOTONIC, &ts1);
        double ms = (ts1.tv_sec - ts0.tv_sec) * 1000.0 + (ts1.tv_nsec - ts0.tv_nsec) / 1e6;
        gc_collect(jvm); g++;
        printf("P4 2-thread:     allocs=%ld(+%ld worker) gc_count=%ld wall=%.1fms  => %.2f Mallocs/s\n",
               a, g_w_allocs, g, ms, (a + g_w_allocs) / ms / 1000.0);
    }

    {
        uint64_t carves = 0, fast = 0;
        heap_tlab_stats(&carves, &fast);
        printf("TLAB stats: carves=%llu fast_allocs=%llu\n",
               (unsigned long long)carves, (unsigned long long)fast);
    }

    heap_destroy(jvm);
    return 0;
}
