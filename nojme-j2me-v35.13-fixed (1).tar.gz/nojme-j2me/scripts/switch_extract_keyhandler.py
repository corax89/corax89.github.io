#!/usr/bin/env python3
"""Extract the SDL_KEYDOWN/UP case body of sdl_process_events() into a
standalone sdl_handle_key_event() (see header comment in the generated
code). Exact-string surgery (no index math) + loop-aware break/return
conversion.

Run: python3 scripts/switch_extract_keyhandler.py
"""
import re

PATH = "src/sdl/sdl_graphics.c"
src = open(PATH, encoding="utf-8").read()

CASE_HEAD = "            case SDL_KEYDOWN:\n            case SDL_KEYUP:\n                {\n"
CASE_TAIL = "\n                }\n                break;\n"

i = src.find(CASE_HEAD)
assert i >= 0, "case header not found"
# ensure it's the sdl_process_events one (first occurrence is)
j = src.find(CASE_TAIL, i)
assert j >= 0, "case tail not found"
body = src[i + len(CASE_HEAD):j]

# ---- re-indent: strip 16 leading spaces ----
lines = [(ln[16:] if ln.startswith(" " * 16) else ln) for ln in body.split("\n")]

# ---- break->return via loop-stack scanner (comment-tolerant) ----
stack = []
out = []
for ln in lines:
    stripped = ln.strip()
    m = re.match(r"^(for|while)\s*\(.*\{", stripped)
    if m and stripped.endswith("{"):
        stack.append("loop"); out.append(ln); continue
    if re.match(r"^(if|else)\b.*\{\s*(/\*.*\*/)?\s*$", stripped) or stripped == "} else {":
        stack.append("block"); out.append(ln); continue
    if stripped.startswith("}"):
        if stack: stack.pop()
        out.append(ln); continue
    if stripped.startswith("break;"):
        if "loop" in stack:
            out.append(ln)
        else:
            out.append(re.sub(r"^(\s*)break;", r"\1return;", ln))
        continue
    out.append(ln)
body2 = "\n".join(out)
n_returns = body2.count("return;")
assert n_returns >= 4, "expected >=4 converted breaks, got %d" % n_returns

body2 = body2.replace("event.key.repeat", "is_repeat")

# drop the old local declarations (now function params)
body2 = body2.replace("    bool pressed = (event.type == SDL_KEYDOWN);\n", "")
body2 = body2.replace("    SDL_Keycode key = event.key.keysym.sym;\n", "")

func = """/*
 * sdl_handle_key_event — the shared SDL_KEYDOWN/UP body (extracted v34.84
 * so the __SWITCH__ gamepad path can re-dispatch synthesized keyboard
 * events through the identical logic: repeat bookkeeping, soft buttons,
 * command-menu navigation, ESC/F12 handling).
 */
static void sdl_handle_key_event(SdlContext* ctx, SDL_Keycode key, bool pressed,
                                 bool is_repeat) {
""" + body2 + "}\n"

case_new = """            case SDL_KEYDOWN:
            case SDL_KEYUP:
                sdl_handle_key_event(ctx, event.key.keysym.sym,
                                     event.type == SDL_KEYDOWN,
                                     event.key.repeat ? true : false);
                break;
"""

# ---- 1. replace the case (on the ORIGINAL text) ----
src = src[:i] + case_new + src[j + len(CASE_TAIL):]

# ---- 2. insert the function before sdl_process_events ----
anchor = "\n/* Process events */\nvoid sdl_process_events(SdlContext* ctx) {"
k = src.find(anchor)
if k < 0:
    anchor = "\nvoid sdl_process_events(SdlContext* ctx) {"
    k = src.find(anchor)
assert k >= 0, "sdl_process_events anchor not found"
src = src[:k] + "\n" + func + src[k:]

open(PATH, "w", encoding="utf-8").write(src)
print("extracted OK: body %d lines, %d break->return" % (len(lines), n_returns))
