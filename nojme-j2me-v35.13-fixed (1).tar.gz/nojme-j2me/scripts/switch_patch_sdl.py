#!/usr/bin/env python3
"""Apply the __SWITCH__ modifications to src/sdl/sdl_graphics.c.

Inserts scripts/switch_glue_impl.txt (the whole switch glue block) and
makes the six surgical, __SWITCH__-guarded modifications:
  1. sdl_init        — early branch: game session instead of window creation
  2. sdl_destroy     — per-game teardown, window survives for the menu
  3. sdl_present     — scaling modes (stretch / letterbox / blur bg)
  4. sdl_process_events — gamepad, analog stick, touch, pause menu (MINUS)
  5. audio init      — settings gate (Звук: Вкл/Выкл)
  6. windowed loop   — pause-watchdog frame ticks + finished-screen wait

All exact-string replacements assert their anchor; nothing is touched on
platforms without __SWITCH__.

Run: python3 scripts/switch_patch_sdl.py
"""

PATH = "src/sdl/sdl_graphics.c"
GLUE = open("scripts/switch_glue_impl.txt", encoding="utf-8").read()

src = open(PATH, encoding="utf-8").read()

def replace_once(s, old, new, what):
    assert old in s, "anchor missing: " + what
    assert s.count(old) == 1, "anchor not unique: " + what
    return s.replace(old, new)

# ------------------------------------------------------------------
# 0. insert the glue block after the key-repeat section's #endif,
#    right before the "Initialize SDL" comment for sdl_init.
# ------------------------------------------------------------------
anchor0 = "\n#endif /* SDL2_AVAILABLE */\n\n/* Initialize SDL */\nint sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {"
src = replace_once(src, anchor0,
    "\n#endif /* SDL2_AVAILABLE */\n\n" + GLUE + "\n\n/* Initialize SDL */\nint sdl_init(JVM* jvm, int width, int height, int scale, bool headless) {",
    "glue block insert")

# ------------------------------------------------------------------
# 1. sdl_init: switch early branch (after the headless early return)
# ------------------------------------------------------------------
old1 = """    if (headless) {
        DEBUG_LOG("[SDL] Headless mode - skipping SDL window creation");
        return 0;
    }
"""
new1 = old1 + """
#ifdef __SWITCH__
    /* v34.84 Switch frontend: the window/renderer/UI texture already
     * exist (sdl_switch_platform_init, called from the menu bootstrap);
     * a game session only adds the canvas texture (+ blur bg). */
    if (sdl_switch_game_begin(width, height) != 0) {
        free(ctx->framebuffer);
        ctx->framebuffer = NULL;
        return -1;
    }
    return 0;
#endif
"""
src = replace_once(src, old1, new1, "sdl_init switch branch")

# ------------------------------------------------------------------
# 2. sdl_destroy: keep the window on Switch (menu reuses it)
# ------------------------------------------------------------------
old2 = """void sdl_destroy(SdlContext* ctx) {
#if SDL2_AVAILABLE
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
#endif
"""
new2 = """void sdl_destroy(SdlContext* ctx) {
#if SDL2_AVAILABLE
#ifdef __SWITCH__
    /* v34.84: per-GAME teardown only — the shared window/renderer/UI
     * texture live until sdl_switch_platform_shutdown() at app exit. */
    sdl_switch_game_end();
#else
    if (g_audio_dev) {
        SDL_CloseAudioDevice(g_audio_dev);
        g_audio_dev = 0;
    }
    if (g_texture) { SDL_DestroyTexture(g_texture); g_texture = NULL; }
    if (g_renderer) { SDL_DestroyRenderer(g_renderer); g_renderer = NULL; }
    if (g_window) { SDL_DestroyWindow(g_window); g_window = NULL; }
    SDL_Quit();
#endif
#endif
"""
src = replace_once(src, old2, new2, "sdl_destroy switch branch")

# ------------------------------------------------------------------
# 3. sdl_present: scaling modes on Switch
# ------------------------------------------------------------------
old3 = """void sdl_present(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) {
        GFX_DEBUG("[SDL] present: invalid context or texture");
        return;
    }
"""
new3 = """void sdl_present(SdlContext* ctx) {
    (void)ctx;  /* used only in the SDL2 backend path */
#if SDL2_AVAILABLE
    if (!ctx || !ctx->framebuffer || !g_texture || !g_renderer) {
        GFX_DEBUG("[SDL] present: invalid context or texture");
        return;
    }
#ifdef __SWITCH__
    SDL_LOCK();
    sdl_switch_present_game(ctx);
    SDL_UNLOCK();
    return;
#endif
"""
src = replace_once(src, old3, new3, "sdl_present switch branch")

# ------------------------------------------------------------------
# 4. sdl_process_events: gamepad / stick / touch / MINUS cases
# ------------------------------------------------------------------
old4 = """            case SDL_WINDOWEVENT:
"""
new4 = """#ifdef __SWITCH__
            case SDL_CONTROLLERBUTTONDOWN:
            case SDL_CONTROLLERBUTTONUP:
                {
                    bool pressed = (event.type == SDL_CONTROLLERBUTTONDOWN);
                    SDL_GameControllerButton b =
                        (SDL_GameControllerButton)event.cbutton.button;
                    if (b == SDL_CONTROLLER_BUTTON_BACK && pressed) {
                        /* MINUS — in-game pause menu (VM parks via the
                         * v34.81 watchdog; virtual time freezes). */
                        sdl_switch_pause_menu(ctx);
                        break;
                    }
                    SDL_Keycode mapped = switch_pad_button_to_keycode(b);
                    if (mapped) {
                        /* re-dispatch through the shared keyboard path:
                         * soft buttons, menu navigation and key repeat
                         * bookkeeping all come along for free. */
                        sdl_handle_key_event(ctx, mapped, pressed, false);
                    }
                }
                break;

            case SDL_CONTROLLERAXISMOTION:
                sdl_switch_stick_update(ctx, &event);
                break;

            case SDL_FINGERDOWN:
            case SDL_FINGERUP:
            case SDL_FINGERMOTION:
                sdl_switch_finger_event(ctx, &event);
                break;
#endif /* __SWITCH__ */

            case SDL_WINDOWEVENT:
"""
src = replace_once(src, old4, new4, "process_events gamepad cases")

# 4b. skip synthesized mouse events from touch (double-fire guard)
old4b = """            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
                {
                    bool pressed = (event.type == SDL_MOUSEBUTTONDOWN);
"""
new4b = """            case SDL_MOUSEBUTTONDOWN:
            case SDL_MOUSEBUTTONUP:
                {
#ifdef __SWITCH__
                    if (event.button.which == SDL_TOUCH_MOUSEID) {
                        /* touch already delivered via SDL_FINGER* */
                        break;
                    }
#endif
                    bool pressed = (event.type == SDL_MOUSEBUTTONDOWN);
"""
src = replace_once(src, old4b, new4b, "mouse touch guard")

# ------------------------------------------------------------------
# 5. audio gates
# ------------------------------------------------------------------
old5a = """int sdl_audio_init(SdlContext* ctx, int frequency, int channels, int samples) {
"""
new5a = old5a + """#if defined(__SWITCH__) && SDL2_AVAILABLE
    if (!switch_settings_get()->audio_enabled) return -1; /* Звук: Выкл */
#endif
"""
src = replace_once(src, old5a, new5a, "audio gate A")

old5b = """int sdl_audio_init_simple(uint32_t sample_rate) {
#if SDL2_AVAILABLE
    if (g_audio_dev) return 0;  /* Already initialized */
"""
new5b = """int sdl_audio_init_simple(uint32_t sample_rate) {
#if SDL2_AVAILABLE
    if (g_audio_dev) return 0;  /* Already initialized */
#ifdef __SWITCH__
    if (!switch_settings_get()->audio_enabled) return -1; /* Звук: Выкл */
#endif
"""
src = replace_once(src, old5b, new5b, "audio gate B")

# ------------------------------------------------------------------
# 6a. windowed loop: pause-watchdog frame ticks
# ------------------------------------------------------------------
old6a = """    int loop_count = 0;
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        loop_count++;
"""
new6a = """    int loop_count = 0;
    while (ctx->running && ctx->jvm && ctx->jvm->running) {
        loop_count++;
#ifdef __SWITCH__
        /* v34.81 pause watchdog: fresh frame timestamp each iteration;
         * when the pause menu blocks this loop, VM threads park after
         * the stall threshold and virtual time freezes. */
        {
            extern void jvm_frontend_frame_tick(void);
            extern void jvm_frontend_run_exit(void);
            jvm_frontend_frame_tick();
            jvm_frontend_run_exit();
        }
#endif
"""
src = replace_once(src, old6a, new6a, "frame ticks")

# ------------------------------------------------------------------
# 6b. finished screen: Switch waits for A/B or 3 s, then returns to menu
# ------------------------------------------------------------------
old6b = """        for (;;) {
            SDL_Event ev;
            bool quit = false;
            while (SDL_PollEvent(&ev)) {
                if (ev.type == SDL_QUIT) quit = true;
                if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) quit = true;
            }
            if (quit) break;
            SDL_Delay(16);
        }
"""
new6b = """#ifdef __SWITCH__
        /* Switch: show the finished screen until A/B or 3 s, then fall
         * through — control returns to the frontend menu (switch main). */
        {
            uint64_t t0 = SDL_GetTicks();
            for (;;) {
                SDL_Event ev;
                bool quit = false;
                while (SDL_PollEvent(&ev)) {
                    if (ev.type == SDL_QUIT) quit = true;
                    if (ev.type == SDL_CONTROLLERBUTTONDOWN &&
                        (ev.cbutton.button == SDL_CONTROLLER_BUTTON_A ||
                         ev.cbutton.button == SDL_CONTROLLER_BUTTON_B)) quit = true;
                    if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) quit = true;
                }
                if (quit || SDL_GetTicks() - t0 > 3000) break;
                SDL_Delay(16);
            }
        }
#else
        for (;;) {
            SDL_Event ev;
            bool quit = false;
            while (SDL_PollEvent(&ev)) {
                if (ev.type == SDL_QUIT) quit = true;
                if (ev.type == SDL_KEYDOWN && ev.key.keysym.sym == SDLK_ESCAPE) quit = true;
            }
            if (quit) break;
            SDL_Delay(16);
        }
#endif
"""
src = replace_once(src, old6b, new6b, "finished screen switch wait")

open(PATH, "w", encoding="utf-8").write(src)
print("patched OK: 8 replacements applied")
