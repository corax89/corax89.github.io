#!/bin/bash
# FM X II I Hardcore 3D NH (I-play) — diagnostic harness
# Phase A: get past I-play age gate into the main menu, then into a level.
# The gate: o.t() reads 5 ints from res.bin -> fails -> high score entry
# (first rider) -> o.b(9,...) -> menu. Workaround: NOJME unprotect write
# (see hook in execute.c) makes the read succeed -> direct gate pass.
cd /home/z/my-project/j2me-analysis
OUT=work/fmx
mkdir -p $OUT
rm -f /tmp/j2me_frame_*.ppm /tmp/bounce_framebuffer.ppm

# I-play gate emulator: auto-press '5' every 1500 frames
NOJME_HEADLESS_MAX_MS=180000 \
NOJME_HEADLESS_IDLE_TIMEOUT=4000 \
NOJME_HEADLESS_KEYSEQ="5" \
NOJME_HEADLESS_KEYSEQ_EVERY=1500 \
NOJME_HEADLESS_SNAP_FRAMES=100,700,1500,3000,4500,6000,8000,10000,12000,15000,18000,22000,26000 \
./bin/j2me-headless fmx.jar > $OUT/diag.log 2>&1
echo "exit=$?"

for f in /tmp/j2me_frame_*.ppm; do
  [ -f "$f" ] || continue
  n=$(basename "$f" .ppm | sed 's/j2me_frame_//')
  python3 -c "from PIL import Image; Image.open('$f').save('$OUT/f_$n.png')" 2>/dev/null
done
ls -la $OUT/*.png 2>/dev/null
grep -cE "INVOKE-MISSING" $OUT/diag.log
tail -5 $OUT/diag.log
