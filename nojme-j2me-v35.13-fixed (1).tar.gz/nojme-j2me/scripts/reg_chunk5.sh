#!/bin/bash
# v34.74 regression battery — runs against the freshly built tree in the CWD.
# Everything from the v34.73 battery plus the v34.74 deliverables:
#   * TestRMS E2E   — JSR 118 RMS spec suite (33 checks): nextRecordId peek
#                     semantics, null-data empty records, authmode-at-create,
#                     getSize()J, deleteRecordStore disk-only stores, ...
#   * TestAnim E2E  — JSR-184 M3G animation suite (18 checks): track weight
#                     default, weighted-average blending, null controller,
#                     float sampling time, validity, LINEAR/STEP/SLERP/LOOP
#   * Frame limit   — live j2me_fps 30->60 switch must push
#                     SET_SYSTEM_AV_INFO (frontend re-pacing)
#   * TestAudio E2E   — WAV (PCM 8/16-bit, mono/stereo, 11/22/44 kHz),
#                       IMA ADPCM, A-law, mu-law, MIDI, playTone, saturating
#                       mixer: spectral analysis of the dumped mixed output
#   * Makefile self-heal — stale pre-v34.69 C++ .d artifacts are detected
#                       and purged; the old failure mode ("No rule to make
#                       target 'src/amr/amr_nb_dec.cpp'") cannot reproduce
# A/B baseline: stock upstream v34.71 tree (with the C++ AMR).
# Usage: bash scripts/regress_v3474.sh [path-to-v34.71-headless]
set -u
cd "$(dirname "$0")/.."
R=0
note() { echo "[REG] $*"; }
fail() { echo "[REG][FAIL] $*"; R=1; }

AB_HEADLESS="${1:-/home/z/my-project/tmp/v371/tree/bin/j2me-headless}"

# ---------- 6. gc_stress (heap churn + concurrency) ----------
note "6) gc_stress"
gcc -O2 -std=c11 -Iinclude -Isrc -Isrc/include -DJ2ME_DEBUG=0 \
    scripts/gc_stress.c src/jvm/heap.c -lm -pthread -o /tmp/reg73/gc_stress 2> /tmp/reg73/gc_stress_build.log
timeout 300 /tmp/reg73/gc_stress > /tmp/reg73/gc_stress.log 2>&1
rc=$?
note "gc_stress: rc=$rc $(tail -2 /tmp/reg73/gc_stress.log | head -1)"
[ $rc -ne 0 ] && fail "gc_stress rc=$rc"
grep -q "corrupt" /tmp/reg73/gc_stress.log && fail "gc_stress: corruption markers"

# ---------- 7. AMR selfcheck (C decoder bit-exactness) ----------
note "7) AMR selfcheck (C decoder from the packaged tree)"
bash scripts/amr_selfcheck.sh > /tmp/reg73/amr.log 2>&1
rc=$?
tail -3 /tmp/reg73/amr.log
[ $rc -ne 0 ] && fail "amr_selfcheck rc=$rc"

# ---------- 8. corrupted-magic sweep over the whole battery ----------
note "8) corrupted-magic sweep (/tmp/reg73)"
n_magic=$(grep -rc "CORRUPTION_MAGIC\|CORRUPTION_FATAL\|corrupted magic" /tmp/reg73/*.log 2>/dev/null | awk -F: '{s+=$2} END {print s+0}')
note "corruption markers across battery logs: $n_magic"
[ "$n_magic" -ne 0 ] && fail "corrupted-magic markers present"

echo "[REG] === battery result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
echo "[REG] === reg_chunk5 result: $([ $R -eq 0 ] && echo ALL-OK || echo HAS-FAILURES) ==="
exit $R
