/*
 * switch_glue.h — the seam between the SDL backend (sdl_graphics.c, owns
 * the window/renderer/textures) and the pure menu logic (switch_ui.c).
 *
 * switch_ui.c contains NO SDL calls: it draws into a raw ARGB8888 canvas
 * and consumes abstract key events, which makes the whole menu system
 * compilable and testable on any host (Makefile target `switchui`).
 * sdl_graphics.c implements these functions next to its other
 * __SWITCH__-guarded sections.
 */
#ifndef SWITCH_GLUE_H
#define SWITCH_GLUE_H

#include <stdint.h>

/* ---- Menu key model (bitmask, edge-triggered presses) ---- */
#define SWK_UP    (1u << 0)
#define SWK_DOWN  (1u << 1)
#define SWK_LEFT  (1u << 2)
#define SWK_RIGHT (1u << 3)
#define SWK_A     (1u << 4)  /* выбрать */
#define SWK_B     (1u << 5)  /* назад */
#define SWK_EXIT  (1u << 6)  /* закрыть приложение (SDL_QUIT / «Выход») */
#define SWK_MINUS (1u << 7)  /* v34.90: edge MINUS - switch menu language */

/* Menu canvas the UI draws into (SWITCH_UI_WIDTH x SWITCH_UI_HEIGHT,
 * ARGB8888). Valid until sdl_switch_platform_shutdown(). */
uint32_t* sdl_switch_ui_canvas(void);

/* Pump SDL events and return the menu keys PRESSED this call (edges only).
 * Translates raw joystick buttons (SDL_JOY*, v34.89), keyboard
 * arrows/Enter/Escape and SDL_QUIT. v34.90: also SWK_MINUS on a MINUS
 * press edge, and HELD keys (sdl_switch_ui_held_keys) now reflect the
 * LIVE pad state across calls (not just the pump that saw the event). */
unsigned sdl_switch_ui_pump_keys(void);

/* Keys currently HELD (for auto-repeat in long lists). */
unsigned sdl_switch_ui_held_keys(void);

/* Upload the menu canvas and flip. */
void sdl_switch_ui_present(void);

/* Millisecond monotonic clock (SDL_GetPerformanceCounter based). */
uint64_t sdl_switch_ui_ticks_ms(void);

/* Sleep (pumping nothing — menus are event-driven). */
void sdl_switch_ui_wait(uint32_t ms);

/* ---- One-time platform bootstrap (before any game / menu): ----
 * SDL_Init(VIDEO|AUDIO|JOYSTICK|EVENTS), 1280x720 window, renderer,
 * UI texture, up to 4 raw joysticks opened. v34.89: raw SDL_JOY* input
 * replaces the GameController API — SDL_CONTROLLER* events never fire
 * on switch-SDL2 setups without a controller mapping, which left the
 * frontend dead. v34.90: SINGLE-PUMP rule - see switch_input_pump() in
 * sdl_graphics.c; the game thread (Thread.sleep / thread_yield) never
 * drains the SDL event queue on __SWITCH__.
 * Returns 0 on success. Idempotent (second call is a no-op returning 0). */
int sdl_switch_platform_init(void);

/* Final shutdown at app exit (destroy window/renderer, SDL_Quit). */
void sdl_switch_platform_shutdown(void);

/* ---- Game-session lifecycle (called around init_emulator/run_midlet) ----
 * Prepare/teardown per-game textures on the SAME window. sdl_init() on
 * __SWITCH__ delegates here. */
int sdl_switch_game_begin(int fb_w, int fb_h);
void sdl_switch_game_end(void);

#endif /* SWITCH_GLUE_H */
