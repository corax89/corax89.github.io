/*
 * switch_trace.c — v34.91 freeze-triage implementation. See switch_trace.h
 * for the design. Linked into the Switch NRO and the host verification
 * builds only (never into the linux desktop app / libretro core).
 *
 * Log line format: "<ticks-ms> <text>\n" — one open(O_APPEND)+write+close
 * per line (stdio buffers would lose the tail exactly when it matters: a
 * hard hang or a crash). A first failure permanently disables file logging.
 */
#include "switch/switch_trace.h"

#if defined(__SWITCH__) || defined(NOJME_SWITCH_TRACE)

#include "switch/switch_glue.h"
#include "switch/switch_common.h" /* SWITCH_UI_WIDTH/HEIGHT */
#include "switch/switch_font.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h> /* v35.03: CLOCK_MONOTONIC for the [GC-SLOW] recency check */

/* v34.94: heap counters for the diag line (JVM linked into every build
 * that links this file). include/ is on the include path (-I$(INCDIR)). */
#include "jvm.h"
#include "heap.h"

/* SDL headers (same discovery order as sdl_graphics.c): switch portlibs
 * expose both layouts, host pkg-config adds -I.../SDL2, the sandbox test
 * snapshot has SDL.h at its root. */
#if defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    include <SDL2/SDL.h>
#  elif __has_include(<SDL.h>)
#    include <SDL.h>
#  endif
#else
#  include <SDL.h>
#endif

#define TRACE_LINE_CAP 320
#define TRACE_LOG_CAP  (1024 * 1024)   /* v34.95: 1 MB — the per-second thread dump eats budget */

/* ========================================================================
 * v34.94 DIAG counters + logging gate.
 * ======================================================================== */

/* --- logging gate (v34.92 feature recreated): default OFF, the settings
 * row "Лог" flips it; the enable/disable event itself always reaches the
 * log so the user can see WHEN it was toggled. Implemented in switch_ui.c. */
extern int switch_settings_logging_flag(void);

static int g_logging = -1;   /* -1 = not probed yet (reads settings) */

static int logging_on(void) {
    if (g_logging < 0) {
        /* First use: NOJME_LOGGING=1|0 env wins (host verification builds
         * run the __SWITCH__ code path where settings.ini lives under
         * sdmc: and is unreadable); otherwise the settings toggle. */
        const char* e = getenv("NOJME_LOGGING");
        if (e && e[0]) {
            g_logging = (strcmp(e, "0") == 0) ? 0 : 1;
        } else {
            g_logging = switch_settings_logging_flag() ? 1 : 0;
        }
    }
    return g_logging;
}

int sw_logging_enabled(void) { return logging_on(); }

/* Live toggle from the settings screen (persisted there via settings.ini). */
void sw_logging_set(int on) {
    g_logging = on ? 1 : 0;
}

/* --- diag counters (see switch_trace.h for semantics) --- */
volatile uint32_t g_sd_loop = 0, g_sd_pr = 0, g_sd_skip = 0, g_sd_pump = 0;
volatile uint32_t g_sd_stl_ms = 0, g_sd_sr_ms = 0, g_sd_fl = 0;
volatile uint32_t g_sd_vs = 0;
volatile uint32_t g_sd_pv_ms = 0, g_sd_pv_ms_max = 0, g_sd_pw_ms_max = 0;
volatile uint32_t g_sd_iter_ms_max = 0;
/* v35.02 logic-heartbeat: pp = repaint pumps COMPLETED (took the lock),
 * psk = pumps skipped (UI lock busy), cs = callSerially game-logic Runnables
 * executed on the frontend thread. The v35.01 field analysis pinned the
 * "race crawls ~1 Hz then freezes" on the callSerially drain starvation —
 * cs is ITS pulse: healthy = roughly one third of loop (30/s at 30 fps
 * game), crawl = cs collapsing to single digits, freeze = cs == 0 while
 * bn keeps counting (renders alive, logic dead). */
volatile uint32_t g_sd_pp = 0, g_sd_pump_skip = 0, g_sd_csq = 0;
volatile const char* g_sd_loop_stage = NULL;
volatile uint64_t g_sd_loop_ms = 0;

/* v35.01: session-high watermark of alive VM runners (written by the beat
 * callback; a drop below it = a thread DIED) + the stall-log throttle.
 * File scope so sw_diag_session_reset can clear the watermark per session. */
static int s_live_hwm = 0;
static uint64_t s_last_stall_log = 0;
static long long s_last_gcslow_log = 0; /* v35.03: [GC-SLOW] throttle (mono ms) */
static int s_slow_beats = 0; /* v35.03: sustained ~1 Hz crawl counter (1 s per beat) */
static void s_live_hwm_reset(void) { s_live_hwm = 0; }

#define SW_DIAG_PERIOD_MS 5000
static uint64_t g_sd_period_t0 = 0;
static uint32_t g_sd_gc_base = 0;
static uint32_t g_sd_top_sample = 0;
static JVM* g_sd_jvm = NULL;   /* set by the frontend once per session */

void sw_diag_set_jvm(void* jvm) { g_sd_jvm = (JVM*)jvm; }

/* Forward decls (defined below) */
static void trace_emit_impl(const char* text, int force);
void sw_trace_force(const char* fmt, ...);

/* Weak lookups: the white-box input test links this file WITHOUT the JVM —
 * every JVM symbol below must be null-checked. */
extern uint64_t g_gc_collections __attribute__((weak));
extern HeapStats heap_get_stats(JVM* jvm) __attribute__((weak));

/* Session-monotonic allocation watermark ("top="), sampled every frame —
 * matches the v34.93 diag semantics (top only ever grew within a run). */
static uint32_t g_sd_top_hwm = 0;

static void diag_emit(void) {
    uint32_t loop = g_sd_loop, pr = g_sd_pr, skip = g_sd_skip, pump = g_sd_pump;
    uint32_t stl = g_sd_stl_ms, sr = g_sd_sr_ms, fl = g_sd_fl, vs = g_sd_vs;
    g_sd_loop = 0; g_sd_pr = 0; g_sd_skip = 0; g_sd_pump = 0;
    g_sd_stl_ms = 0; g_sd_sr_ms = 0; g_sd_fl = 0; g_sd_vs = 0;

    uint32_t gc = 0;
    if (g_sd_jvm && &g_gc_collections) {
        uint64_t c = g_gc_collections;
        gc = (uint32_t)(c > g_sd_gc_base ? (c - g_sd_gc_base) : 0);
        g_sd_gc_base = (uint32_t)c;
    }

    uint32_t heap = 0, top = 0, sb = 0;
    if (g_sd_jvm && heap_get_stats) {
        HeapStats hs = heap_get_stats(g_sd_jvm);
        heap = (uint32_t)hs.used_size;
        top = g_sd_top_hwm;
    }
    {
        extern size_t sdl_audio_queued_bytes(void);
        sb = (uint32_t)sdl_audio_queued_bytes();
    }

    /* v34.98: M3G bind pace — bn = binds this period, bd = slowest single
     * bind's buffer work (ms). A bd that climbs toward hundreds/thousands
     * of ms is the slow-bind degradation that precedes the freeze.
     * Weak + address-checked: the white-box input test links this file
     * without the JVM/M3G objects. */
    {
        extern volatile uint32_t g_sd_m3g_binds __attribute__((weak));
        extern volatile uint32_t g_sd_m3g_bind_ms_max __attribute__((weak));
        uint32_t bn = 0, bd = 0;
        if (&g_sd_m3g_binds && &g_sd_m3g_bind_ms_max) {
            bn = g_sd_m3g_binds; bd = g_sd_m3g_bind_ms_max;
            g_sd_m3g_binds = 0; g_sd_m3g_bind_ms_max = 0;
        }
        /* v35.01: game-thread liveness (tn/ta) + bind age (ma) + present
         * costs (pv/pk/pw) + worst iteration (mx). The v35.00 field trace
         * caught the NEW freeze form with the frontend loop ALIVE — the
         * frozen state itself was invisible (no STUCK, td gated by the
         * logging toggle). These forced fields make it self-reporting:
         *   tn drop  = a VM thread DIED (e.g. unhandled exception)
         *   ta large = a RUN-able thread stopped dispatching natives
         *   ma large = the paint path stopped completing binds
         *   pk/pw/mx large = the stall lives in the frontend present/loop */
        int tn = -1, tatid = -1, tw = -1;
        long long ta = -1;
        {
            extern void jvm_thread_liveness(void*, int*, long long*, int*, int*)
                __attribute__((weak));
            if (jvm_thread_liveness)
                jvm_thread_liveness((void*)g_sd_jvm, &tn, &ta, &tatid, &tw);
        }
        uint32_t ma = 0;
        {
            extern uint32_t m3g_bind_age_ms(void) __attribute__((weak));
            if (m3g_bind_age_ms) ma = m3g_bind_age_ms();
        }
        uint32_t pv = g_sd_pv_ms, pk = g_sd_pv_ms_max, pw = g_sd_pw_ms_max,
                 mx = g_sd_iter_ms_max;
        g_sd_pv_ms = 0; g_sd_pv_ms_max = 0; g_sd_pw_ms_max = 0;
        g_sd_iter_ms_max = 0;
        uint32_t pp = g_sd_pp, psk = g_sd_pump_skip, cs = g_sd_csq;
        g_sd_pp = 0; g_sd_pump_skip = 0; g_sd_csq = 0;
        /* v35.03: GC-паузы — gms = последняя сборка, мс; gxm = худшая за
         * период. gc=0 всю сессию + первая сборка на границе круга =
         * кандидат в «внезапный 1 fps»: пара строк в логе это докажут
         * или исключат. */
        uint32_t gms = 0, gxm = 0;
        {
            extern volatile uint32_t g_gc_last_ms __attribute__((weak));
            extern volatile uint32_t g_gc_worst_ms __attribute__((weak));
            if (&g_gc_last_ms && &g_gc_worst_ms) {
                gms = g_gc_last_ms; gxm = g_gc_worst_ms;
                g_gc_worst_ms = 0;
            }
        }
        sw_trace_force("diag: loop=%u pr=%u stl=%u vs=%u gc=%u heap=%u top=%u skip=%u pump=%u sr=%u fl=%u sb=%u bn=%u bd=%u tn=%d ta=%lld/t%d tw=%d ma=%u pv=%u pk=%u pw=%u mx=%u pp=%u psk=%u cs=%u gms=%u gxm=%u",
                       loop, pr, stl, vs, gc, heap, top, skip, pump, sr, fl, sb, bn, bd,
                       tn, ta, tatid, tw, ma, pv, pk, pw, mx, pp, psk, cs, gms, gxm);
    }
}

void sw_diag_tick(void) {
    uint64_t now = sdl_switch_ui_ticks_ms();
    g_sd_loop_ms = now;
    /* v34.94: sample the allocation watermark every frame (cheap: one
     * stats walk is NOT cheap — only every 64th call). */
    if (g_sd_jvm && heap_get_stats && ((++g_sd_top_sample & 63) == 0)) {
        HeapStats hs = heap_get_stats(g_sd_jvm);
        uint32_t used = (uint32_t)hs.used_size;
        if (used > g_sd_top_hwm) g_sd_top_hwm = used;
    }
    if (!g_sd_period_t0) g_sd_period_t0 = now;
    if (now - g_sd_period_t0 >= SW_DIAG_PERIOD_MS) {
        g_sd_period_t0 = now;
        diag_emit();
    }
}

void sw_diag_session_reset(void) {
    g_sd_gc_base = 0;
    g_sd_period_t0 = 0;
    g_sd_top_hwm = 0;
    g_sd_top_sample = 0;
    g_sd_loop = 0; g_sd_pr = 0; g_sd_skip = 0; g_sd_pump = 0;
    g_sd_stl_ms = 0; g_sd_sr_ms = 0; g_sd_fl = 0; g_sd_vs = 0;
    g_sd_pv_ms = 0; g_sd_pv_ms_max = 0; g_sd_pw_ms_max = 0;
    g_sd_iter_ms_max = 0;
    g_sd_loop_stage = NULL; /* no game session: the STUCK watchdog idles */
    g_sd_loop_ms = 0;
    /* v35.01: the alive-runner watermark is session-scoped — a NEW game
     * starts with a fresh thread census (the old session's high must not
     * fire [THREAD-EXIT] against the next session's teardown). */
    s_live_hwm_reset();
}

static char g_line[TRACE_LINE_CAP];      /* on-screen status line */
static int  g_log_fd = -2;               /* -2 not probed, -1 disabled, >=0 fd */
static uint64_t g_bytes = 0;             /* bytes written (cap guard) */
static int  g_beat_on = 0;
static int  g_beat_alt = 0;              /* v34.95: alive every 2nd 1-s beat */
static int  g_banner_done = 0;
static SDL_TimerID g_beat_id = 0;        /* v34.95: removed at shutdown */
static volatile int g_beat_stop = 0;     /* v34.95: shutdown flag for the cb */

/* Log path: sdmc:/switch/j2me/log.txt on the Switch (the settings dir —
 * proven writable: every MINUS toggle saves settings.ini there); the
 * NOJME_SWITCH_UI_DIR verification dir on host builds; stderr only when
 * neither applies. */
static const char* trace_log_path(char* buf, size_t cap) {
    /* v34.94: verification dir wins on EVERY platform (host verify builds
     * compile with -D__SWITCH__ but have no sdmc:). */
    const char* env = getenv("NOJME_SWITCH_UI_DIR");
    if (env && env[0]) {
        snprintf(buf, cap, "%s/log.txt", env);
        return buf;
    }
#ifdef __SWITCH__
    (void)buf; (void)cap;
    return "sdmc:/switch/j2me/log.txt";
#else
    (void)buf; (void)cap;
    return NULL;
#endif
}

static void trace_log_write(const char* s, size_t n) {
    if (g_log_fd == -1 || g_bytes >= TRACE_LOG_CAP) return;

    if (g_log_fd == -2) {
        g_log_fd = -1; /* pessimistic default until the open succeeds */
        char pbuf[512];
        const char* p = trace_log_path(pbuf, sizeof(pbuf));
        if (p) {
#ifdef __SWITCH__
            mkdir("sdmc:/switch", 0777);
            mkdir("sdmc:/switch/j2me", 0777);
#endif
            /* First open per process TRUNCATES (one run = one log);
             * O_APPEND afterwards makes every write atomic-at-end, so
             * heartbeat lines from the SDL timer thread cannot clobber
             * lines written by the main thread. */
            int fd = open(p, O_WRONLY | O_APPEND | O_CREAT | O_TRUNC, 0666);
            if (fd >= 0) g_log_fd = fd;
        }
    }
    if (g_log_fd >= 0) {
        ssize_t w = write(g_log_fd, s, n);
        if (w > 0) {
            g_bytes += (uint64_t)w;
        } else if (w < 0) {
            close(g_log_fd);        /* broken card / removed dir: stop trying */
            g_log_fd = -1;
        }
    }
}

static void trace_emit_impl(const char* text, int force) {
    char out[TRACE_LINE_CAP + 64];
    uint64_t t = sdl_switch_ui_ticks_ms();
    int n = snprintf(out, sizeof(out), "%llu %s\n",
                     (unsigned long long)t, text);
    if (n > 0) {
        if ((size_t)n >= sizeof(out)) n = (int)sizeof(out) - 1;
        trace_log_write(out, (size_t)n);
        fprintf(stderr, "[TRACE] %s\n", text);
        fflush(stderr);
    }
    (void)force;
}

/* Forced line: bypasses the logging gate (diag, settings events, STUCK).
 * Also refreshes the on-screen status line. */
void sw_trace_force(const char* fmt, ...) {
    char text[TRACE_LINE_CAP];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(text, sizeof(text), fmt, ap);
    va_end(ap);
    snprintf(g_line, sizeof(g_line), "%s", text);
    trace_emit_impl(text, 1);
}

void sw_trace(const char* fmt, ...) {
    char text[TRACE_LINE_CAP];

    /* One-time banner on first use (NOT a constructor: this must run after
     * SDL/env setup, and it proves WHICH build is actually running — the
     * whole point of CORE_BUILD_ID). The banner always reaches the log so
     * "trace start" keeps proving the build even with logging disabled. */
    if (!g_banner_done) {
        g_banner_done = 1;
        extern const char* j2me_core_build_id(void);
        char b[128];
        snprintf(b, sizeof(b), "nojme %s trace start", j2me_core_build_id());
        trace_emit_impl(b, 1);
    }

    /* v34.92 logging gate (recreated): with the toggle OFF only the banner
     * and forced lines (settings events, STUCK watchdog) reach the log. */
    if (!logging_on()) return;

    va_list ap;
    va_start(ap, fmt);
    vsnprintf(text, sizeof(text), fmt, ap);
    va_end(ap);

    /* on-screen line: single writer (main thread); benign torn reads from
     * the heartbeat timer at worst garble one log line. */
    snprintf(g_line, sizeof(g_line), "%s", text);
    trace_emit_impl(text, 0);
}

const char* sw_trace_line(void) { return g_line; }

void sw_trace_flush(void) {
    uint32_t* cv = sdl_switch_ui_canvas();
    if (!cv || !g_line[0]) return;

    /* dark screen + centered stage line, presented immediately: if the code
     * right after this call hangs, the user SEES which stage did it. */
    const uint32_t bg = 0xFF0A0C10u;
    const uint32_t fg = 0xFFE8ECF4u;
    const int n = SWITCH_UI_WIDTH * SWITCH_UI_HEIGHT;
    for (int i = 0; i < n; i++) cv[i] = bg;
    switch_font_draw_text(cv, SWITCH_UI_WIDTH, SWITCH_UI_HEIGHT,
                          32, SWITCH_UI_HEIGHT / 2 - 16,
                          g_line, fg, 0, 2);
    sdl_switch_ui_present();
}

static Uint32 trace_beat_cb(Uint32 interval, void* param) {
    (void)param;
    /* v34.95: app is shutting down — return 0 (do NOT reschedule) and
     * never touch stderr/file: SDL_Quit joins this callback's thread, and
     * a callback racing the teardown (fprintf/stdio locks, open/write)
     * is exactly the "hang after 'menu exit — shutting down'" signature
     * seen on the host verify build with logging enabled. */
    if (g_beat_stop) return 0;
    char text[TRACE_LINE_CAP];

    /* v34.94 STUCK watchdog: when a game session is on (a stage marker
     * exists) and the main loop has not completed an iteration for >5 s,
     * say WHERE it is stuck. This line bypasses the logging gate — a
     * frozen user should not also lose the diagnosis because the toggle
     * was off.
     * v34.95: STUCK also carries sp= (GC safepoint request pending — a
     * stuck collector freezes EVERY VM thread at its next poll) and sb=
     * (queued audio bytes — whether the audio thread still produces). */
    const char* stage = (const char*)(uintptr_t)g_sd_loop_stage;
    uint64_t now = sdl_switch_ui_ticks_ms();
    uint64_t last = g_sd_loop_ms;
    int stuck = (stage && last && now > last + 5000);
    if (stuck) {
        int sp = 0;
        {
            extern volatile int g_gc_safepoint_request __attribute__((weak));
            if (&g_gc_safepoint_request) sp = g_gc_safepoint_request;
        }
        extern size_t sdl_audio_queued_bytes(void);
        uint32_t sb = (uint32_t)sdl_audio_queued_bytes();
        /* v34.98 forensics: pause state, settled-frame age, M3G target size
         * and the period's bind counters — one line answers "frontend parked
         * (pause?), game not completing frames (seqage), or wedged inside a
         * slow bind (bd/m3g)". All weak-linked: the input test build has no
         * JVM/display layer. */
        int pause = -1;
        {
            extern int jvm_frontend_pause_snapshot(void) __attribute__((weak));
            if (jvm_frontend_pause_snapshot) pause = jvm_frontend_pause_snapshot();
        }
        uint32_t seq = 0; uint64_t seqage = 0;
        {
            extern uint32_t midp_present_stable_seq(void) __attribute__((weak));
            extern uint64_t midp_present_stable_age_ms(void) __attribute__((weak));
            if (midp_present_stable_seq) seq = midp_present_stable_seq();
            if (midp_present_stable_age_ms) seqage = midp_present_stable_age_ms();
        }
        int mw = 0, mh = 0;
        {
            extern void m3g_target_size(int*, int*) __attribute__((weak));
            if (m3g_target_size) m3g_target_size(&mw, &mh);
        }
        uint32_t binds = 0, bdmax = 0;
        {
            extern volatile uint32_t g_sd_m3g_binds, g_sd_m3g_bind_ms_max;
            binds = g_sd_m3g_binds; bdmax = g_sd_m3g_bind_ms_max;
        }
        snprintf(text, sizeof(text),
                 "STUCK: stage=%.40s idle=%llu ms sp=%d sb=%u pause=%d seq=%u seqage=%llu ms m3g=%dx%d bn=%u bd=%u last=%.24s",
                 stage, (unsigned long long)(now - last), sp, sb,
                 pause, seq, (unsigned long long)seqage, mw, mh,
                 binds, bdmax, g_line);
        trace_emit_impl(text, 1);
    }

    /* v35.01 [T-STALL]/[THREAD-EXIT]: the v35.00 field trace caught the NEW
     * freeze form — the frontend loop stayed ALIVE (loop=222, no STUCK,
     * menu exit worked) while the game world froze, and with the logging
     * toggle off (the default) that state had ZERO log visibility (td
     * dumps are gated by the toggle; STUCK only watches the frontend
     * loop). This channel works regardless of the toggle: every beat
     * checks VM-thread liveness and, when a RUN-able thread stops
     * dispatching for >5 s OR the alive-runner count drops below its
     * session high, emits a forced dump of all threads (deep=0 — legal
     * from the timer thread; the frontend is NOT provably blocked here). */
    int stall_alarm = 0;
    if (stage && g_sd_jvm && !stuck) {
        extern void jvm_thread_liveness(void*, int*, long long*, int*, int*)
            __attribute__((weak));
        if (jvm_thread_liveness) {
            int live = 0, waiting = 0, worst_tid = -1;
            long long worst = -1;
            jvm_thread_liveness((void*)g_sd_jvm, &live, &worst, &worst_tid, &waiting);
            if (live > s_live_hwm) s_live_hwm = live;
            const char* why = NULL;
            if (s_live_hwm > 0 && live < s_live_hwm)
                why = "THREAD-EXIT";
            else if (worst > 5000)
                why = "T-STALL";
            /* v35.03 SLOWLOGIC: логика ползёт на ~1 Гц — worst_age стоит в
             * полосе 0.4..5 с — это НЕВИДИМО для T-STALL (порог 5 с) и не
             * даёт STUCK (фронтенд жив). Полевой отчёт v35.02: круг на
             * полной скорости, затем игра падает до ~1 к/с; между ударами
             * сторожа поток "прогрессирует", поэтому тишина. Устойчивое
             * (3 удара подряд) нахождение в полосе = принудительный дамп. */
            else if (worst > 400) {
                s_slow_beats++;
                if (s_slow_beats >= 3) why = "SLOWLOGIC";
            } else {
                s_slow_beats = 0; /* healthy beat — reset the sustained band */
            }
            if (why) {
                uint64_t now2 = sdl_switch_ui_ticks_ms();
                if (now2 - s_last_stall_log >= 5000) {
                    s_last_stall_log = now2;
                    /* v35.03: контекст в самой строке — GC-пауза (gms) и
                     * возраст бинда (ma): отличают GC-шторм (gms велик) от
                     * ступора потока игры (ma велик, gms мал) с одного
                     * взгляда на лог. */
                    uint32_t gms = 0, ma2 = 0;
                    {
                        extern volatile uint32_t g_gc_last_ms __attribute__((weak));
                        if (&g_gc_last_ms) gms = g_gc_last_ms;
                    }
                    {
                        extern uint32_t m3g_bind_age_ms(void) __attribute__((weak));
                        if (m3g_bind_age_ms) ma2 = m3g_bind_age_ms();
                    }
                    char text2[TRACE_LINE_CAP];
                    snprintf(text2, sizeof(text2),
                             "[%s] live=%d (hwm %d) waiting=%d worst_age=%lld ms (t%d) gms=%u ma=%u — frontend loop alive, dumping VM threads",
                             why, live, s_live_hwm, waiting,
                             (long long)worst, worst_tid, gms, ma2);
                    trace_emit_impl(text2, 1);
                    stall_alarm = 1;
                }
            } else {
                s_last_stall_log = 0; /* re-arm the throttle after recovery */
            }
        }
    }

    /* v35.03 [GC-SLOW]: длинная GC-пауза — главный подозреваемый отчёта
     * «внезапный 1 fps после круга» (Gameloft-игры зовут System.gc() на
     * границах кругов/уровней; первая в сессии сборка при gc=0 обязана
     * пройтись по ВСЕМ объектам, накопленным с момента старта — на Switch
     * это сотни мс, а при повторных вызовах игры — кадр в секунду).
     * Принудительный канал: виден при выключенном тумблере лога.
     * Recency по CLOCK_MONOTONIC — тот же источник, что g_gc_last_end_ms. */
    if (g_sd_jvm && !stuck) {
        extern volatile long long g_gc_last_end_ms __attribute__((weak));
        extern volatile uint32_t g_gc_last_ms __attribute__((weak));
        if (&g_gc_last_end_ms && &g_gc_last_ms) {
            struct timespec gcts;
            clock_gettime(CLOCK_MONOTONIC, &gcts);
            long long now_ms = (long long)gcts.tv_sec * 1000LL + gcts.tv_nsec / 1000000LL;
            long long age = now_ms - g_gc_last_end_ms;
            if (g_gc_last_ms > 300 && age >= 0 && age < 2000 &&
                now_ms - s_last_gcslow_log >= 5000) {
                s_last_gcslow_log = now_ms;
                char gtext[192];
                snprintf(gtext, sizeof(gtext),
                         "[GC-SLOW] last GC pause %u ms (ended %lld ms ago) — watch gms=/gxm= in diag; repeat pauses = GC storm",
                         g_gc_last_ms, age);
                trace_emit_impl(gtext, 1);
                stall_alarm = 1; /* + дамп потоков: кто паркируется в safepoint */
            }
        }
    }

    /* v34.95: per-second THREAD DUMP while a game session is on (the
     * user's "раз в секунду показывать информацию о работающих и спящих
     * потоках"). Gated by the logging toggle; during a STUCK it fires
     * regardless of the gate and walks the main thread's Java frames
     * (deep=1 — legal only while the frontend is provably blocked).
     * Weak-linked: the white-box input test builds this file without the
     * JVM, so the symbol may be absent. */
    if (stage && g_sd_jvm && (logging_on() || stuck || stall_alarm)) {
        extern void jvm_threads_dump_snprint(void* jvm, char* buf, size_t cap, int deep)
            __attribute__((weak));
        if (jvm_threads_dump_snprint) {
            char dbuf[1024];   /* v34.96: 640 -> 1024 — wider nat names + td m3g line */
            dbuf[0] = '\0';
            jvm_threads_dump_snprint((void*)g_sd_jvm, dbuf, sizeof(dbuf), stuck);
            char* cur = dbuf;
            while (cur && *cur) {
                char* nl = strchr(cur, '\n');
                if (nl) *nl = '\0';
                if (cur[0]) trace_emit_impl(cur, stuck || stall_alarm);
                cur = nl ? nl + 1 : NULL;
            }
        }
    }

    if (stuck) return interval;

    if (!logging_on()) return interval; /* v34.92 gate */
    /* alive line every 2 s (every 2nd beat since v34.95): the per-second
     * dump made the 2 s cadence redundant on even beats. */
    g_beat_alt = !g_beat_alt;
    if (g_beat_alt) return interval;
    snprintf(text, sizeof(text), "alive: %.100s", g_line);
    trace_emit_impl(text, 0);
    return interval; /* keep firing */
}

void sw_trace_heartbeat(void) {
    if (g_beat_on) return;
    g_beat_on = 1;
    /* v34.95: 1 s beat — the user asked for a per-second thread dump, and
     * the STUCK watchdog now detects within 1 s instead of 2 s. */
    g_beat_id = SDL_AddTimer(1000, trace_beat_cb, NULL);
}

/* v34.95: deterministic shutdown — stop the heartbeat BEFORE the app tears
 * down SDL. Removes the timer (cancels pending fires), then waits for an
 * in-flight callback to observe g_beat_stop and leave. */
void sw_trace_shutdown(void) {
    g_beat_stop = 1;
    if (g_beat_id) {
        SDL_RemoveTimer(g_beat_id);
        g_beat_id = 0;
    }
    /* SDL_RemoveTimer synchronizes with the timer thread internally
     * (cancels + joins), so after it returns no callback is running or
     * pending. The flag guards the tiny window before removal. */
}

#endif /* __SWITCH__ || NOJME_SWITCH_TRACE */
