/*
 * switch_scaling.h — pure (SDL-free) display scaling math + background
 * blur downsample for the Nintendo Switch frontend.
 *
 * Kept free of any SDL/libnx dependency so it is unit-testable on any
 * host (scripts/test_switch_scaling.c) and reusable by any presenter.
 */
#ifndef SWITCH_SCALING_H
#define SWITCH_SCALING_H

#include <stdint.h>

/* Destination rectangle of the game canvas on the Switch screen for the
 * given scaling mode. mode NOJME_SCALE_STRETCH fills the screen (aspect
 * ignored); the two FIT modes letterbox centered. */
void switch_scaling_game_rect(int scale_mode,
                              int fb_w, int fb_h,
                              int screen_w, int screen_h,
                              int* x, int* y, int* w, int* h);

/* Downsample src (fb_w x fb_h ARGB8888) into dst (dst_w x dst_h) with
 * box averaging, then apply `passes` 3x3 box-blur rounds on the small
 * buffer. dst is uploaded as a texture and linearly stretched to the
 * whole screen by the presenter — the classic "blurred background fill"
 * behind a letterboxed game. Cost: O(dst pixels) per frame, tiny. */
void switch_scaling_blur_bg(const uint32_t* src, int src_w, int src_h,
                            uint32_t* dst, int dst_w, int dst_h,
                            int passes);

/* Recommended background buffer dimensions for a game canvas: ~1/8 of the
 * canvas, min 8x8. */
void switch_scaling_bg_size(int fb_w, int fb_h, int* bg_w, int* bg_h);

#endif /* SWITCH_SCALING_H */
