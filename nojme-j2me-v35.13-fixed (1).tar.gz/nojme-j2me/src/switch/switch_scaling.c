/*
 * switch_scaling.c — pure scaling math + blur background for the Switch
 * frontend. No SDL, no libnx: unit-testable everywhere (see
 * scripts/test_switch_scaling.c).
 */
#include "switch/switch_scaling.h"
#include "switch/switch_common.h"

#include <stdlib.h>
#include <string.h>

void switch_scaling_game_rect(int scale_mode,
                              int fb_w, int fb_h,
                              int screen_w, int screen_h,
                              int* x, int* y, int* w, int* h) {
    if (x) *x = 0;
    if (y) *y = 0;
    if (w) *w = screen_w;
    if (h) *h = screen_h;
    if (fb_w <= 0 || fb_h <= 0 || screen_w <= 0 || screen_h <= 0) return;

    if (scale_mode == NOJME_SCALE_STRETCH) return; /* full screen */

    /* FIT (both variants): largest centered rect preserving fb aspect. */
    double s = (double)screen_w / (double)fb_w;
    if ((double)screen_h / (double)fb_h < s) s = (double)screen_h / (double)fb_h;

    int rw = (int)((double)fb_w * s + 0.5);
    int rh = (int)((double)fb_h * s + 0.5);
    if (rw < 1) rw = 1;
    if (rh < 1) rh = 1;
    if (rw > screen_w) rw = screen_w;
    if (rh > screen_h) rh = screen_h;

    if (x) *x = (screen_w - rw) / 2;
    if (y) *y = (screen_h - rh) / 2;
    if (w) *w = rw;
    if (h) *h = rh;
}

void switch_scaling_bg_size(int fb_w, int fb_h, int* bg_w, int* bg_h) {
    int w = fb_w / 8;
    int h = fb_h / 8;
    if (w < 8) w = 8;
    if (h < 8) h = 8;
    if (w > fb_w) w = fb_w;
    if (h > fb_h) h = fb_h;
    if (bg_w) *bg_w = w;
    if (bg_h) *bg_h = h;
}

void switch_scaling_blur_bg(const uint32_t* src, int src_w, int src_h,
                            uint32_t* dst, int dst_w, int dst_h,
                            int passes) {
    if (!src || !dst || src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0)
        return;

    /* ---- Pass 1: box-average downsample (area averaging) ----
     * For each destination pixel, average the source rectangle it covers.
     * Integer accumulation; alpha forced opaque. */
    for (int dy = 0; dy < dst_h; dy++) {
        int y0 = (int)((int64_t)dy * src_h / dst_h);
        int y1 = (int)((int64_t)(dy + 1) * src_h / dst_h);
        if (y1 <= y0) y1 = y0 + 1;
        if (y1 > src_h) y1 = src_h;
        for (int dx = 0; dx < dst_w; dx++) {
            int x0 = (int)((int64_t)dx * src_w / dst_w);
            int x1 = (int)((int64_t)(dx + 1) * src_w / dst_w);
            if (x1 <= x0) x1 = x0 + 1;
            if (x1 > src_w) x1 = src_w;

            uint32_t rs = 0, gs = 0, bs = 0, n = 0;
            const uint32_t* row = src + (size_t)y0 * src_w;
            for (int sy = y0; sy < y1; sy++, row += src_w) {
                for (int sx = x0; sx < x1; sx++) {
                    uint32_t p = row[sx];
                    rs += (p >> 16) & 0xFF;
                    gs += (p >> 8) & 0xFF;
                    bs += p & 0xFF;
                    n++;
                }
            }
            if (n == 0) n = 1;
            dst[(size_t)dy * dst_w + dx] = 0xFF000000u |
                    ((rs / n) << 16) | ((gs / n) << 8) | (bs / n);
        }
    }

    /* ---- Pass 2: 3x3 box blur rounds (in place, two saved source rows) ----
     * Operating on the tiny dst buffer. Row y-1 must be read in its
     * ORIGINAL (pre-blur) form while dst row y is being overwritten, so
     * the two previous source rows are kept in side buffers; row y+1 is
     * still untouched in dst at the time row y is computed. */
    if (passes <= 0) return;

    uint32_t* prev_orig = (uint32_t*)malloc((size_t)dst_w * sizeof(uint32_t));
    uint32_t* cur_orig = (uint32_t*)malloc((size_t)dst_w * sizeof(uint32_t));
    uint32_t* out = (uint32_t*)malloc((size_t)dst_w * sizeof(uint32_t));
    if (!prev_orig || !cur_orig || !out) {
        free(prev_orig); free(cur_orig); free(out);
        return; /* blur is cosmetic — flat downsample is acceptable */
    }

    for (int p = 0; p < passes; p++) {
        for (int y = 0; y < dst_h; y++) {
            uint32_t* dst_row = dst + (size_t)y * dst_w;
            const uint32_t* row_above = (y > 0) ? prev_orig : NULL;
            const uint32_t* row_below = (y + 1 < dst_h) ? dst + (size_t)(y + 1) * dst_w : NULL;
            memcpy(cur_orig, dst_row, (size_t)dst_w * sizeof(uint32_t));

            for (int x = 0; x < dst_w; x++) {
                uint32_t rs = 0, gs = 0, bs = 0, n = 0;
                for (int kx = -1; kx <= 1; kx++) {
                    int xx = x + kx;
                    if (xx < 0 || xx >= dst_w) continue;
                    for (int ky = -1; ky <= 1; ky++) {
                        uint32_t px;
                        if (ky < 0) {
                            if (!row_above) continue;
                            px = row_above[xx];
                        } else if (ky > 0) {
                            if (!row_below) continue;
                            px = row_below[xx];
                        } else {
                            px = cur_orig[xx];
                        }
                        rs += (px >> 16) & 0xFF;
                        gs += (px >> 8) & 0xFF;
                        bs += px & 0xFF;
                        n++;
                    }
                }
                out[x] = 0xFF000000u |
                        ((rs / n) << 16) | ((gs / n) << 8) | (bs / n);
            }
            memcpy(dst_row, out, (size_t)dst_w * sizeof(uint32_t));
            /* cur_orig becomes the previous original row for y+1 */
            uint32_t* t = prev_orig; prev_orig = cur_orig; cur_orig = t;
        }
    }
    free(prev_orig); free(cur_orig); free(out);
}
