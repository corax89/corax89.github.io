render.o: src/render/render.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/midp.h include/jvm.h include/jvm.h src/render/render.h \
 src/midp/bitmap_font.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/midp.h:
include/jvm.h:
include/jvm.h:
src/render/render.h:
src/midp/bitmap_font.h:
