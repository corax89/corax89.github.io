jar_reader.o: src/utils/jar_reader.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h include/miniz.h \
 include/jar_reader.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
include/miniz.h:
include/jar_reader.h:
