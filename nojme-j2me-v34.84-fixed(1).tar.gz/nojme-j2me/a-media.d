media.o: src/midp/media.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 src/include/win_thread_shim.h include/jvm.h include/native.h \
 include/jvm.h include/midi.h include/heap.h include/opcodes.h \
 src/amr/amr_nb_dec.h scripts/win_syntax/windows.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
src/include/win_thread_shim.h:
include/jvm.h:
include/native.h:
include/jvm.h:
include/midi.h:
include/heap.h:
include/opcodes.h:
src/amr/amr_nb_dec.h:
scripts/win_syntax/windows.h:
