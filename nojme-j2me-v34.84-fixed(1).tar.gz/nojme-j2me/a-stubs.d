stubs.o: src/jvm/stubs.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/jvm.h include/classfile.h \
 include/jvm.h include/native.h include/opcodes.h include/debug.h \
 src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/native.h:
include/opcodes.h:
include/debug.h:
src/include/debug_macros.h:
