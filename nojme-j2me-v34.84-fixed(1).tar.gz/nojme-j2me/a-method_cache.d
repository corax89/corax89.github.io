method_cache.o: src/jvm/method_cache.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/jvm.h include/classfile.h \
 include/jvm.h include/debug.h src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/debug.h:
src/include/debug_macros.h:
