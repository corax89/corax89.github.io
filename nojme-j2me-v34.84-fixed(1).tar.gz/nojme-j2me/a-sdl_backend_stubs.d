sdl_backend_stubs.o: src/libretro/sdl_backend_stubs.c \
 scripts/win_syntax/windows.h scripts/win_syntax/direct.h \
 src/include/win_thread_shim.h include/debug.h src/include/debug_macros.h \
 include/libretro.h include/sdl_backend.h include/jvm.h include/midp.h \
 include/midp.h include/jar_reader.h include/miniz.h \
 src/libretro/../midp/bitmap_font.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
src/include/win_thread_shim.h:
include/debug.h:
src/include/debug_macros.h:
include/libretro.h:
include/sdl_backend.h:
include/jvm.h:
include/midp.h:
include/midp.h:
include/jar_reader.h:
include/miniz.h:
src/libretro/../midp/bitmap_font.h:
