main.o: src/main.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h scripts/win_syntax/windows.h include/miniz.h \
 include/core_version.h include/jvm.h include/classfile.h include/jvm.h \
 include/opcodes.h include/heap.h include/native.h include/midp.h \
 src/render/render.h include/sdl_backend.h include/midp.h include/debug.h \
 src/include/debug_macros.h include/jar_reader.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
scripts/win_syntax/windows.h:
include/miniz.h:
include/core_version.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/opcodes.h:
include/heap.h:
include/native.h:
include/midp.h:
src/render/render.h:
include/sdl_backend.h:
include/midp.h:
include/debug.h:
src/include/debug_macros.h:
include/jar_reader.h:
