core_options.o: src/libretro/core_options.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/libretro.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/libretro.h:
