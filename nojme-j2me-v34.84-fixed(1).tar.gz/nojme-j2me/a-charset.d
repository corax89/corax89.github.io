charset.o: src/jvm/charset.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/charset.h include/heap.h \
 include/jvm.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/charset.h:
include/heap.h:
include/jvm.h:
