midi.o: src/midi/midi.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/midi.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/midi.h:
