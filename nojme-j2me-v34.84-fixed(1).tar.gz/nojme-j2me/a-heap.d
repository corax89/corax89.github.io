heap.o: src/jvm/heap.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h scripts/win_syntax/windows.h include/heap.h \
 include/jvm.h include/jvm.h include/opcodes.h include/classfile.h \
 include/debug.h src/include/debug_macros.h include/native.h \
 include/midp.h include/threads.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
scripts/win_syntax/windows.h:
include/heap.h:
include/jvm.h:
include/jvm.h:
include/opcodes.h:
include/classfile.h:
include/debug.h:
src/include/debug_macros.h:
include/native.h:
include/midp.h:
include/threads.h:
