utils.o: src/utils/utils.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/jvm.h include/heap.h include/jvm.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/jvm.h:
include/heap.h:
include/jvm.h:
