classfile.o: src/jvm/classfile.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/classfile.h include/jvm.h include/jvm.h include/opcodes.h \
 include/native.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/classfile.h:
include/jvm.h:
include/jvm.h:
include/opcodes.h:
include/native.h:
