native.o: src/jvm/native.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h scripts/win_syntax/windows.h \
 src/include/win_thread_shim.h include/native.h include/jvm.h \
 include/jvm.h include/heap.h include/charset.h include/heap.h \
 include/threads.h include/opcodes.h include/classfile.h \
 include/sdl_backend.h include/midp.h include/midp.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
scripts/win_syntax/windows.h:
src/include/win_thread_shim.h:
include/native.h:
include/jvm.h:
include/jvm.h:
include/heap.h:
include/charset.h:
include/heap.h:
include/threads.h:
include/opcodes.h:
include/classfile.h:
include/sdl_backend.h:
include/midp.h:
include/midp.h:
