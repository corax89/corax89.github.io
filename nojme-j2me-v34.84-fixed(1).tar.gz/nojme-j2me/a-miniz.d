miniz.o: src/utils/miniz.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/miniz.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/miniz.h:
