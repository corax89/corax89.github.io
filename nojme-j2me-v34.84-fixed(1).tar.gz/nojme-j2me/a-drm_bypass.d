drm_bypass.o: src/jvm/drm_bypass.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h src/include/drm_bypass.h include/debug.h \
 src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
src/include/drm_bypass.h:
include/debug.h:
src/include/debug_macros.h:
