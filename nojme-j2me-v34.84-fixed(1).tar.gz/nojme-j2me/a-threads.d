threads.o: src/jvm/threads.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h scripts/win_syntax/windows.h \
 src/include/win_thread_shim.h include/threads.h include/jvm.h \
 include/jvm.h include/debug.h src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
scripts/win_syntax/windows.h:
src/include/win_thread_shim.h:
include/threads.h:
include/jvm.h:
include/jvm.h:
include/debug.h:
src/include/debug_macros.h:
