opcodes.o: src/jvm/opcodes.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/core_version.h include/opcodes.h \
 include/jvm.h include/classfile.h include/jvm.h include/heap.h \
 include/native.h src/include/drm_bypass.h include/threads.h \
 include/debug.h src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/core_version.h:
include/opcodes.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/heap.h:
include/native.h:
src/include/drm_bypass.h:
include/threads.h:
include/debug.h:
src/include/debug_macros.h:
