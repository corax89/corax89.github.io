display.o: src/midp/display.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/midp.h include/jvm.h \
 src/render/render.h include/jvm.h include/native.h include/heap.h \
 include/sdl_backend.h include/midp.h include/threads.h include/opcodes.h \
 include/debug.h src/midp/bitmap_font.h include/jar_reader.h \
 scripts/win_syntax/windows.h src/include/win_thread_shim.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/midp.h:
include/jvm.h:
src/render/render.h:
include/jvm.h:
include/native.h:
include/heap.h:
include/sdl_backend.h:
include/midp.h:
include/threads.h:
include/opcodes.h:
include/debug.h:
src/midp/bitmap_font.h:
include/jar_reader.h:
scripts/win_syntax/windows.h:
src/include/win_thread_shim.h:
