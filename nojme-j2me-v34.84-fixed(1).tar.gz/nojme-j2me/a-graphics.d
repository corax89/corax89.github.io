graphics.o: src/midp/graphics.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/midp.h include/jvm.h include/jvm.h src/midp/bitmap_font.h \
 include/stb_image.h src/render/render.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/midp.h:
include/jvm.h:
include/jvm.h:
src/midp/bitmap_font.h:
include/stb_image.h:
src/render/render.h:
