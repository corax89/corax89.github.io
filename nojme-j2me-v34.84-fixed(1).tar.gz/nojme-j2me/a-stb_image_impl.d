stb_image_impl.o: src/utils/stb_image_impl.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/stb_image.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/stb_image.h:
