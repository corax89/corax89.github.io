nokia_m3d.o: src/jvm/nokia_m3d.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/native.h include/jvm.h include/jvm.h \
 include/heap.h include/midp.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/native.h:
include/jvm.h:
include/jvm.h:
include/heap.h:
include/midp.h:
