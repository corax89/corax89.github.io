libretro.o: src/libretro/libretro.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/core_version.h include/libretro.h src/libretro/libretro_shared.h \
 include/jvm.h include/midp.h include/jvm.h src/render/render.h \
 include/native.h include/opcodes.h include/sdl_backend.h include/midp.h \
 include/miniz.h include/jar_reader.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/core_version.h:
include/libretro.h:
src/libretro/libretro_shared.h:
include/jvm.h:
include/midp.h:
include/jvm.h:
src/render/render.h:
include/native.h:
include/opcodes.h:
include/sdl_backend.h:
include/midp.h:
include/miniz.h:
include/jar_reader.h:
