debug_var.o: src/jvm/debug_var.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h scripts/win_syntax/windows.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
scripts/win_syntax/windows.h:
