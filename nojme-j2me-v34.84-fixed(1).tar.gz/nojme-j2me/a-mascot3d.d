mascot3d.o: src/midp/mascot3d.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/jvm.h include/native.h include/jvm.h \
 include/heap.h include/opcodes.h include/midp.h include/sdl_backend.h \
 include/midp.h src/render/render.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/jvm.h:
include/native.h:
include/jvm.h:
include/heap.h:
include/opcodes.h:
include/midp.h:
include/sdl_backend.h:
include/midp.h:
src/render/render.h:
