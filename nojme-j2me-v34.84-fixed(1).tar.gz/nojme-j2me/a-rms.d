rms.o: src/midp/rms.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 scripts/win_syntax/windows.h scripts/win_syntax/direct.h include/midp.h \
 include/jvm.h include/jvm.h include/native.h include/heap.h \
 include/opcodes.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/midp.h:
include/jvm.h:
include/jvm.h:
include/native.h:
include/heap.h:
include/opcodes.h:
