jvm.o: src/jvm/jvm.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/miniz.h include/jvm.h \
 include/classfile.h include/jvm.h include/heap.h include/threads.h \
 include/opcodes.h include/native.h include/debug.h \
 src/include/debug_macros.h include/jar_reader.h \
 src/include/win_thread_shim.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/miniz.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/heap.h:
include/threads.h:
include/opcodes.h:
include/native.h:
include/debug.h:
src/include/debug_macros.h:
include/jar_reader.h:
src/include/win_thread_shim.h:
