form.o: src/midp/form.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h include/debug.h src/include/debug_macros.h \
 include/midp.h include/jvm.h include/jvm.h include/native.h \
 include/heap.h include/sdl_backend.h include/midp.h include/threads.h \
 include/opcodes.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
include/debug.h:
src/include/debug_macros.h:
include/midp.h:
include/jvm.h:
include/jvm.h:
include/native.h:
include/heap.h:
include/sdl_backend.h:
include/midp.h:
include/threads.h:
include/opcodes.h:
