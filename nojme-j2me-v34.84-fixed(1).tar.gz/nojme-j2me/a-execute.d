execute.o: src/jvm/execute.c scripts/win_syntax/windows.h \
 scripts/win_syntax/direct.h scripts/win_syntax/windows.h include/jvm.h \
 include/classfile.h include/jvm.h include/opcodes.h include/heap.h \
 include/threads.h include/native.h include/debug.h \
 src/include/debug_macros.h
scripts/win_syntax/windows.h:
scripts/win_syntax/direct.h:
scripts/win_syntax/windows.h:
include/jvm.h:
include/classfile.h:
include/jvm.h:
include/opcodes.h:
include/heap.h:
include/threads.h:
include/native.h:
include/debug.h:
src/include/debug_macros.h:
