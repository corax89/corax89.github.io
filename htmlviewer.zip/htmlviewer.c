#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sdl.h"
#include "defines.h"
#include "api.h"
#include "utils.h"
#include "base64.h"
#include "html.h"
#include "minIni.h"
#include "quickjs.h"
#include <stdint.h>

#define LOG_TO_FILE 1
#ifndef HAVE_STRDUP
char* my_strdup(const char* s) {
    if (!s) return NULL;
    size_t len = strlen(s);
    char* p = malloc(len + 1);
    if (p) memcpy(p, s, len + 1);
    return p;
}
#define strdup my_strdup
#endif

static int DEVICE_WIDTH = FIXED_WIDTH;
static int DEVICE_HEIGHT = FIXED_HEIGHT;
SDL_Surface* screen = NULL;
HtmlDocument *doc;

enum style_tag{ NO_TAG, COLOR, BACKGROUND_COLOR, DISPLAY, INNER_TEXT };
enum display_type{ NONE, INLINE, BLOCK };
int dirty = 1;

struct AhrefName {
    int y;
    char *name;
} ahref_name_array[2048];

// Структуры для таблиц
typedef struct TableColumn {
    int width;
    struct TableColumn* next;
} TableColumn;

typedef struct TableRow {
    HtmlElement* cells;
    struct TableRow* next;
    int height;
} TableRow;

typedef struct TableContext {
    TableColumn* columns;
    TableRow* rows;
    int col_count;
    int row_count;
    int current_col;
    int current_row;
    HtmlElement* current_row_element;
    int table_x;
    int table_y;
} TableContext;

TableContext* current_table = NULL;

// Структура для CSS стилей
typedef struct CSSStyle {
    char* selector;
    char* property;
    char* value;
    struct CSSStyle* next;
} CSSStyle;

CSSStyle* css_styles = NULL;

// Структуры для Canvas
enum canvas_operation {
    CANVAS_FILL_RECT,
    CANVAS_STROKE_RECT,
    CANVAS_FILL_TEXT,
    CANVAS_CLEAR_RECT,
    CANVAS_DRAW_IMAGE,
    CANVAS_BEGIN_PATH,
    CANVAS_CLOSE_PATH,
    CANVAS_MOVE_TO,
    CANVAS_LINE_TO,
    CANVAS_STROKE,
    CANVAS_FILL,
    CANVAS_ARC,
    CANVAS_RECT,
    CANVAS_SET_FILL_STYLE,
    CANVAS_SET_STROKE_STYLE,
    CANVAS_SET_LINE_WIDTH,
    CANVAS_SET_FONT,
    CANVAS_STROKE_TEXT,
    CANVAS_ARC_TO,
    CANVAS_QUADRATIC_CURVE_TO,
    CANVAS_BEZIER_CURVE_TO,
    CANVAS_ELLIPSE,
    CANVAS_ROUND_RECT,
    CANVAS_CLIP,
    CANVAS_SAVE,
    CANVAS_RESTORE,
    CANVAS_TRANSLATE,
    CANVAS_ROTATE,
    CANVAS_SCALE,
    CANVAS_SET_TRANSFORM,
    CANVAS_RESET_TRANSFORM,
    CANVAS_SET_LINE_DASH,
    CANVAS_SET_LINE_CAP,
    CANVAS_SET_LINE_JOIN,
    CANVAS_SET_GLOBAL_ALPHA,
    CANVAS_SET_TEXT_ALIGN,
    CANVAS_SET_TEXT_BASELINE,
    CANVAS_SET_SHADOW_BLUR,
    CANVAS_SET_SHADOW_COLOR,
    CANVAS_SET_SHADOW_OFFSET_X,
    CANVAS_SET_SHADOW_OFFSET_Y,
    CANVAS_SET_MITER_LIMIT,
    CANVAS_CREATE_LINEAR_GRADIENT,
    CANVAS_CREATE_RADIAL_GRADIENT,
    CANVAS_GRADIENT_ADD_COLOR_STOP,
    CANVAS_GET_IMAGE_DATA,
    CANVAS_PUT_IMAGE_DATA,
    CANVAS_SET_WIDTH,
    CANVAS_SET_HEIGHT,
    CANVAS_DRAW_IMAGE_CROP,
    CANVAS_RESET
};

typedef struct CanvasGradient {
    int type; // 0=linear, 1=radial
    float x0, y0, x1, y1, r0, r1;
    int color_stops[16];
    float color_positions[16];
    int color_stop_count;
    struct CanvasGradient* next;
} CanvasGradient;

typedef struct CanvasState {
    int fill_color;
    int stroke_color;
    int line_width;
    float global_alpha;
    char font[64];
    char text_align[16];
    char text_baseline[16];
    char line_cap[16];
    char line_join[16];
    float miter_limit;
    int dash_count;
    float dash_array[32];
    float shadow_blur;
    int shadow_color;
    int shadow_offset_x;
    int shadow_offset_y;
    float transform_a, transform_b, transform_c, transform_d, transform_e, transform_f;
    CanvasGradient* fill_gradient;
    CanvasGradient* stroke_gradient;
} CanvasState;

typedef struct CanvasOperation {
    enum canvas_operation type;
    int x, y, w, h;
    int color;
    int line_width;
    char* text;
    char* font;
    SDL_Surface* image;
    float start_angle;
    float end_angle;
    int counterclockwise;
    float f1, f2, f3, f4, f5, f6, f7, f8;
    char str_val[64];
    struct CanvasOperation* next;
} CanvasOperation;

typedef struct CanvasContext {
    int width;
    int height;
    SDL_Surface* surface;
    int fill_color;
    int stroke_color;
    int line_width;
    char font[64];
    CanvasOperation* operations;
    CanvasOperation* last_operation;
    int path_start_x;
    int path_start_y;
    int current_x;
    int current_y;
    int path_open;
    int needs_redraw;
    // New state
    float global_alpha;
    char text_align[16];
    char text_baseline[16];
    char line_cap[16];
    char line_join[16];
    float miter_limit;
    int dash_count;
    float dash_array[32];
    float shadow_blur;
    int shadow_color;
    int shadow_offset_x;
    int shadow_offset_y;
    float transform[6]; // a, b, c, d, e, f
    // State stack for save/restore
    CanvasState state_stack[16];
    int state_stack_top;
    // Path points for fill()
    float path_points[2048][2];
    int path_point_count;
    // Clipping
    int clip_enabled;
    int clip_x, clip_y, clip_w, clip_h;
    // Gradients
    CanvasGradient* fill_gradient;
    CanvasGradient* stroke_gradient;
    // ImageData
    Uint32* image_data_pixels;
    int image_data_w, image_data_h;
    // Sub-path tracking for arc
    float last_arc_cx, last_arc_cy, last_arc_radius;
    float last_arc_start, last_arc_end;
    int last_arc_ccw;
} CanvasContext;

// Глобальные переменные для canvas
static CanvasContext* canvas_contexts[64];
static int canvas_context_count = 0;

int remath_dom;
int ahref_array_count = 0;
int selectElement = 0;
int startViewSelectedId = -1;
int endViewSelectedId = -1;
int ahref_name_array_count = 0;
int drawCursor = 0;
int selectId = 0;
char language_name[64];
char* selectedHref = NULL;
char* selectedOnClick = NULL;

static char html_file_path[512] = "";     // Full path to current HTML file
static char html_base_path[512] = "";     // Directory of current HTML file
static char storage_path[512] = "";       // Path to localStorage file
static char document_title[256] = "";     // document.title

#define BUFFSIZE (1024 * 1024)
int max_global_y = 0;
int global_y = 0;
TTF_Font* fonts[5];

// Структура для кеширования текста
typedef struct {
    char text[256];
    int fontsize;
    int color;
    int bg_color;
    SDL_Surface* surface;
    SDL_Surface* bg_surface;
    int width;
    int height;
} TextCacheEntry;

#define TEXT_CACHE_SIZE 256
static TextCacheEntry text_cache[TEXT_CACHE_SIZE];
static int text_cache_count = 0;
static int text_cache_hits = 0;
static int text_cache_misses = 0;

// Структура для кеширования изображений
typedef struct ImageCacheEntry {
    char* src;
    SDL_Surface* surface;
    int width;
    int height;
    struct ImageCacheEntry* next;
} ImageCacheEntry;

ImageCacheEntry* image_cache = NULL;
static int image_cache_count = 0;

// Структуры для таймеров
typedef struct Timer {
    int id;
    JSValue callback;  // QuickJS function reference
    int delay;
    int repeat;
    Uint32 last_fire;
    struct Timer* next;
} Timer;

static Timer* timers = NULL;
static int next_timer_id = 1;
static Uint32 last_ticks = 0;

static JSValue js_canvas_fillRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_strokeRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_clearRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_fillText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_drawImage(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_beginPath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_closePath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_moveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_lineTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_stroke(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_fill(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_arc(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_rect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_fillStyle(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_strokeStyle(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_lineWidth(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_font(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_getContext(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_getElementById(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_strokeText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_arcTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_quadraticCurveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_bezierCurveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_ellipse(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_roundRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_clip(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_save(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_restore(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_translate(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_rotate(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_scale(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_setTransform(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_resetTransform(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_setLineDash(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_getLineDash(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_lineCap(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_lineJoin(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_globalAlpha(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_textAlign(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_textBaseline(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_shadowBlur(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_shadowColor(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_shadowOffsetX(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_shadowOffsetY(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_miterLimit(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_createLinearGradient(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_createRadialGradient(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_gradient_addColorStop(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_getImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_putImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_createImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_measureText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_reset(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_toDataURL(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_isPointInPath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_get_width(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_width(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_get_height(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_canvas_set_height(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static CanvasContext* get_canvas_context_from_element(HtmlElement* element);
SDL_Surface* img_src_parse(const char *src);
static int canvas_gradient_get_color(CanvasGradient* grad, float x, float y);
static Uint32 canvas_blend_color(Uint32 dst, Uint32 src, float alpha);
SDL_Surface* find_in_image_cache(const char* src);
void add_to_image_cache(const char* src, SDL_Surface* surface);
static JSValue js_querySelector(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);
static JSValue js_createElement(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv);

// Объявления для настроек
void InitSettings(void);
void QuitSettings(void);
char* normalize_js_string(const char* input);
const char* html_tag_to_string(HtmlTag tag);


#define MAX_LOG_LINES 20
#define LOG_LINE_HEIGHT 14
static char* log_lines[MAX_LOG_LINES];
static int log_line_count = 0;
static int show_logs = 0;  // 0 - выкл, 1 - внизу экрана, 2 - полноэкранный
static SDL_Surface* log_background = NULL;

// Функция для добавления лога
void add_log(const char* format, ...) {
    va_list args;
    char buffer[512];
    
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    // Удаляем старую строку если достигли максимума
    if (log_line_count >= MAX_LOG_LINES) {
        free(log_lines[0]);
        for (int i = 1; i < MAX_LOG_LINES; i++) {
            log_lines[i-1] = log_lines[i];
        }
        log_line_count--;
    }
    
    // Добавляем новую строку
    log_lines[log_line_count] = strdup(buffer);
    log_line_count++;
    
    // Выводим также в SDL_Log для отладки
    SDL_Log("%s", buffer);
    
    dirty = 1;  // Помечаем экран как грязный для перерисовки
}

// Функция для отрисовки логов
void draw_logs() {
    if (!show_logs || !screen) return;
    
    int start_y, max_height;
    
    if (show_logs == 1) {
        // Логи внизу экрана
        max_height = 120;
        start_y = DEVICE_HEIGHT - max_height;
        
        // Создаем или обновляем фон для логов
        if (!log_background || log_background->h != max_height) {
            if (log_background) SDL_FreeSurface(log_background);
            log_background = SDL_CreateRGBSurface(0, DEVICE_WIDTH, max_height, 32,
                                                  0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        }
        
        if (log_background) {
            // Полупрозрачный темный фон
            SDL_FillRect(log_background, NULL, 0x80000000);  // Полупрозрачный черный
            
            // Рамка
            SDL_FillRect(log_background, &(SDL_Rect){0, 0, DEVICE_WIDTH, 2}, 0xFF0000FF);  // Синяя верхняя граница
            SDL_FillRect(log_background, &(SDL_Rect){0, max_height-2, DEVICE_WIDTH, 2}, 0xFF0000FF);  // Синяя нижняя граница
            
            SDL_Rect dest = {0, start_y, DEVICE_WIDTH, max_height};
            SDL_BlitSurface(log_background, NULL, screen, &dest);
        }
        
        // Заголовок
        SDL_Surface* header = TTF_RenderUTF8_Blended(fonts[1], "=== Логи ===", 
                                                     (SDL_Color){255, 255, 255, 255});
        if (header) {
            SDL_Rect header_dest = {10, start_y + 5, header->w, header->h};
            SDL_BlitSurface(header, NULL, screen, &header_dest);
            SDL_FreeSurface(header);
        }
        
        // Рисуем логи
        int y = start_y + 25;
        int lines_to_show = (max_height - 30) / LOG_LINE_HEIGHT;
        if (lines_to_show > log_line_count) lines_to_show = log_line_count;
        
        for (int i = log_line_count - lines_to_show; i < log_line_count; i++) {
            if (i >= 0 && log_lines[i]) {
                SDL_Surface* text_surface = TTF_RenderUTF8_Blended(fonts[0], log_lines[i], 
                                                                   (SDL_Color){255, 255, 255, 255});
                if (text_surface) {
                    SDL_Rect text_dest = {10, y, text_surface->w, text_surface->h};
                    SDL_BlitSurface(text_surface, NULL, screen, &text_dest);
                    SDL_FreeSurface(text_surface);
                }
                y += LOG_LINE_HEIGHT;
            }
        }
    } 
    else if (show_logs == 2) {
        // Полноэкранный режим логов
        start_y = 0;
        max_height = DEVICE_HEIGHT;
        
        // Черный фон
        SDL_FillRect(screen, NULL, 0x000000);
        
        // Заголовок
        SDL_Surface* header = TTF_RenderUTF8_Blended(fonts[2], "=== ПОЛНЫЕ ЛОГИ ===", 
                                                     (SDL_Color){255, 0, 0, 255});
        if (header) {
            SDL_Rect header_dest = {10, 5, header->w, header->h};
            SDL_BlitSurface(header, NULL, screen, &header_dest);
            SDL_FreeSurface(header);
        }
        
        // Рисуем все логи
        int y = 30;
        for (int i = 0; i < log_line_count; i++) {
            if (log_lines[i]) {
                SDL_Surface* text_surface = TTF_RenderUTF8_Blended(fonts[1], log_lines[i], 
                                                                   (SDL_Color){255, 255, 255, 255});
                if (text_surface) {
                    if (y + text_surface->h > DEVICE_HEIGHT - 10) break;
                    
                    SDL_Rect text_dest = {10, y, text_surface->w, text_surface->h};
                    SDL_BlitSurface(text_surface, NULL, screen, &text_dest);
                    SDL_FreeSurface(text_surface);
                }
                y += LOG_LINE_HEIGHT;
            }
        }
        
        // Подсказка внизу
        SDL_Surface* hint = TTF_RenderUTF8_Blended(fonts[1], "B - назад, A - очистить логи", 
                                                   (SDL_Color){100, 100, 255, 255});
        if (hint) {
            SDL_Rect hint_dest = {10, DEVICE_HEIGHT - 20, hint->w, hint->h};
            SDL_BlitSurface(hint, NULL, screen, &hint_dest);
            SDL_FreeSurface(hint);
        }
    }
}

// Функции для Canvas
CanvasContext* create_canvas_context(int width, int height) {
    CanvasContext* ctx = (CanvasContext*)malloc(sizeof(CanvasContext));
    if (!ctx) return NULL;
    
    ctx->width = width;
    ctx->height = height;
    ctx->surface = SDL_CreateRGBSurface(0, width, height, 32, 
                                        0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
    ctx->fill_color = 0x000000;
    ctx->stroke_color = 0x000000;
    ctx->line_width = 1;
    strcpy(ctx->font, "12px sans-serif");
    ctx->operations = NULL;
    ctx->last_operation = NULL;
    ctx->path_start_x = 0;
    ctx->path_start_y = 0;
    ctx->current_x = 0;
    ctx->current_y = 0;
    ctx->path_open = 0;
    ctx->needs_redraw = 1;
    ctx->global_alpha = 1.0f;
    strcpy(ctx->text_align, "start");
    strcpy(ctx->text_baseline, "alphabetic");
    strcpy(ctx->line_cap, "butt");
    strcpy(ctx->line_join, "miter");
    ctx->miter_limit = 10.0f;
    ctx->dash_count = 0;
    ctx->shadow_blur = 0;
    ctx->shadow_color = 0x000000;
    ctx->shadow_offset_x = 0;
    ctx->shadow_offset_y = 0;
    ctx->transform[0] = 1.0f; // a
    ctx->transform[1] = 0.0f; // b
    ctx->transform[2] = 0.0f; // c
    ctx->transform[3] = 1.0f; // d
    ctx->transform[4] = 0.0f; // e
    ctx->transform[5] = 0.0f; // f
    ctx->state_stack_top = 0;
    ctx->path_point_count = 0;
    ctx->clip_enabled = 0;
    ctx->clip_x = 0; ctx->clip_y = 0;
    ctx->clip_w = width; ctx->clip_h = height;
    ctx->fill_gradient = NULL;
    ctx->stroke_gradient = NULL;
    ctx->image_data_pixels = NULL;
    ctx->image_data_w = 0;
    ctx->image_data_h = 0;
    ctx->last_arc_cx = 0; ctx->last_arc_cy = 0;
    ctx->last_arc_radius = 0;
    ctx->last_arc_start = 0; ctx->last_arc_end = 0;
    ctx->last_arc_ccw = 0;
    
    if (ctx->surface) {
        SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    }
    
    if (canvas_context_count < 64) {
        canvas_contexts[canvas_context_count++] = ctx;
    }
    
    return ctx;
}

void free_canvas_context(CanvasContext* ctx) {
    if (!ctx) return;
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        CanvasOperation* next = op->next;
        if (op->text) free(op->text);
        if (op->font) free(op->font);
        free(op);
        op = next;
    }
    
    if (ctx->surface) {
        SDL_FreeSurface(ctx->surface);
    }
    
    free(ctx);
}

void canvas_add_operation(CanvasContext* ctx, CanvasOperation* op) {
    if (!ctx || !op) return;
    add_log("Canvas: add %d", op->type);
    op->next = NULL;
    
    if (!ctx->operations) {
        ctx->operations = op;
        ctx->last_operation = op;
    } else {
        ctx->last_operation->next = op;
        ctx->last_operation = op;
    }
    ctx->needs_redraw = 1;
    dirty = 1;
}

void canvas_draw_pixel(CanvasContext* ctx, int x, int y, Uint32 color) {
    if (!ctx || !ctx->surface || x < 0 || x >= ctx->width || y < 0 || y >= ctx->height)
        return;
    
    Uint32* pixels = (Uint32*)ctx->surface->pixels;
    pixels[y * ctx->width + x] = color;
    dirty = 1;
}

void canvas_draw_line(CanvasContext* ctx, int x0, int y0, int x1, int y1, Uint32 color, int width) {
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx - dy;
    
    while (1) {
        // Рисуем точку с учетом толщины
        for (int i = -width/2; i <= width/2; i++) {
            for (int j = -width/2; j <= width/2; j++) {
                if (x0 + i >= 0 && x0 + i < ctx->width && 
                    y0 + j >= 0 && y0 + j < ctx->height) {
                    canvas_draw_pixel(ctx, x0 + i, y0 + j, color);
                }
            }
        }
        
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
    dirty = 1;
}

void canvas_draw_line_sdl(CanvasContext* ctx, int x0, int y0, int x1, int y1, Uint32 color, int width) {
    // Используем SDL для рисования линии через заполненные прямоугольники
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    
    if (dx == 0 && dy == 0) {
        // Точка
        if (width > 0) {
            int half = width / 2;
            SDL_Rect rect = {x0 - half, y0 - half, width, width};
            SDL_FillRect(ctx->surface, &rect, color);
        }
        return;
    }
    
    // Для горизонтальных и вертикальных линий используем SDL_FillRect
    if (dx == 0) {
        // Вертикальная линия
        int y = (y0 < y1) ? y0 : y1;
        int h = dy + width;
        SDL_Rect rect = {x0 - width/2, y, width, h};
        SDL_FillRect(ctx->surface, &rect, color);
    } else if (dy == 0) {
        // Горизонтальная линия
        int x = (x0 < x1) ? x0 : x1;
        int w = dx + width;
        SDL_Rect rect = {x, y0 - width/2, w, width};
        SDL_FillRect(ctx->surface, &rect, color);
    } else {
        // Диагональная линия - рисуем отдельные пиксели
        float step = 0.5f;
        for (float t = 0; t <= 1.0f; t += step) {
            int x = x0 + (int)((x1 - x0) * t);
            int y = y0 + (int)((y1 - y0) * t);
            for (int i = -width/2; i <= width/2; i++) {
                for (int j = -width/2; j <= width/2; j++) {
                    if (x + i >= 0 && x + i < ctx->width && 
                        y + j >= 0 && y + j < ctx->height) {
                        Uint32* pixels = (Uint32*)ctx->surface->pixels;
                        pixels[(y + j) * ctx->width + (x + i)] = color;
                    }
                }
            }
        }
    }
}

void canvas_draw_circle_sdl(CanvasContext* ctx, int cx, int cy, int radius, Uint32 color, int fill) {
    if (fill) {
        // Заполненный круг через прямоугольники
        for (int y = -radius; y <= radius; y++) {
            int x_limit = (int)sqrt(radius * radius - y * y);
            if (x_limit > 0) {
                SDL_Rect rect = {cx - x_limit, cy + y, 2 * x_limit, 1};
                SDL_FillRect(ctx->surface, &rect, color);
            }
        }
    } else {
        // Контур круга через точки
        for (int angle = 0; angle < 360; angle += 5) {
            float rad = angle * M_PI / 180.0f;
            int x = cx + (int)(radius * cos(rad));
            int y = cy + (int)(radius * sin(rad));
            if (x >= 0 && x < ctx->width && y >= 0 && y < ctx->height) {
                Uint32* pixels = (Uint32*)ctx->surface->pixels;
                pixels[y * ctx->width + x] = color;
            }
        }
    }
}

void canvas_execute_operations_sdl(CanvasContext* ctx) {
    if (!ctx || !ctx->surface || !ctx->needs_redraw) return;
    
    SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        switch (op->type) {
            case CANVAS_FILL_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           ctx->fill_color | 0xFF000000);
                break;
                
            case CANVAS_STROKE_RECT: {
                int lw = ctx->line_width;
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y + op->h - lw, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x + op->w - lw, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                break;
            }
                
            case CANVAS_CLEAR_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           0x00FFFFFF);
                break;
                
            case CANVAS_FILL_TEXT:
                if (op->text) {
                    TTF_Font* font = fonts[1];
                    int font_size = 12;
                    
                    if (op->font) {
                        sscanf(op->font, "%dpx", &font_size);
                    }
                    
                    if (font_size <= 10) font = fonts[0];
                    else if (font_size <= 12) font = fonts[1];
                    else if (font_size <= 16) font = fonts[2];
                    else if (font_size <= 20) font = fonts[3];
                    else font = fonts[4];
                    
                    SDL_Color color = { 
                        (ctx->fill_color >> 16) & 0xFF,
                        (ctx->fill_color >> 8) & 0xFF,
                        ctx->fill_color & 0xFF, 255 
                    };
                    SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, op->text, color);
                    if (text_surface) {
                        SDL_Rect dest = {op->x, op->y, text_surface->w, text_surface->h};
                        SDL_BlitSurface(text_surface, NULL, ctx->surface, &dest);
                        SDL_FreeSurface(text_surface);
                    }
                }
                break;
                
            case CANVAS_DRAW_IMAGE:
                if (op->image && op->w > 0 && op->h > 0) {
                    SDL_Rect dest = {op->x, op->y, op->w, op->h};
                    SDL_BlitSurface(op->image, NULL, ctx->surface, &dest);
                }
                break;
                
            case CANVAS_LINE_TO:
                canvas_draw_line_sdl(ctx, ctx->current_x, ctx->current_y, op->x, op->y, 
                                   ctx->stroke_color | 0xFF000000, ctx->line_width);
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            case CANVAS_ARC: {
                int cx = op->x + op->w / 2;
                int cy = op->y + op->h / 2;
                int radius = op->w / 2;
                canvas_draw_circle_sdl(ctx, cx, cy, radius, ctx->stroke_color | 0xFF000000, 0);
                break;
            }
                
            case CANVAS_STROKE_TEXT:
                if (op->text) {
                    TTF_Font* font = fonts[1];
                    int font_size = 12;
                    if (op->font) sscanf(op->font, "%dpx", &font_size);
                    if (font_size <= 10) font = fonts[0];
                    else if (font_size <= 12) font = fonts[1];
                    else if (font_size <= 16) font = fonts[2];
                    else if (font_size <= 20) font = fonts[3];
                    else font = fonts[4];
                    SDL_Color color = {
                        (ctx->stroke_color >> 16) & 0xFF,
                        (ctx->stroke_color >> 8) & 0xFF,
                        ctx->stroke_color & 0xFF, 255
                    };
                    // Draw stroked text by rendering filled then overlaying outline effect
                    SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, op->text, color);
                    if (text_surface) {
                        SDL_Rect dest = {op->x, op->y, text_surface->w, text_surface->h};
                        SDL_BlitSurface(text_surface, NULL, ctx->surface, &dest);
                        SDL_FreeSurface(text_surface);
                    }
                }
                break;
                
            default:
                break;
        }
        op = op->next;
    }
    
    ctx->needs_redraw = 0;
}

void canvas_draw_circle(CanvasContext* ctx, int cx, int cy, int radius, Uint32 color, int fill) {
    int x = radius;
    int y = 0;
    int err = 0;
    
    while (x >= y) {
        if (fill) {
            // Заполненный круг - рисуем горизонтальные линии
            canvas_draw_line(ctx, cx - x, cy + y, cx + x, cy + y, color, 1);
            canvas_draw_line(ctx, cx - y, cy + x, cx + y, cy + x, color, 1);
            canvas_draw_line(ctx, cx - x, cy - y, cx + x, cy - y, color, 1);
            canvas_draw_line(ctx, cx - y, cy - x, cx + y, cy - x, color, 1);
        } else {
            // Только контур
            canvas_draw_pixel(ctx, cx + x, cy + y, color);
            canvas_draw_pixel(ctx, cx + y, cy + x, color);
            canvas_draw_pixel(ctx, cx - y, cy + x, color);
            canvas_draw_pixel(ctx, cx - x, cy + y, color);
            canvas_draw_pixel(ctx, cx - x, cy - y, color);
            canvas_draw_pixel(ctx, cx - y, cy - x, color);
            canvas_draw_pixel(ctx, cx + y, cy - x, color);
            canvas_draw_pixel(ctx, cx + x, cy - y, color);
        }
        
        y += 1;
        err += 1 + 2*y;
        if (2*(err - x) + 1 > 0) {
            x -= 1;
            err += 1 - 2*x;
        }
    }
}

void canvas_execute_operations(CanvasContext* ctx) {
    if (!ctx || !ctx->surface || !ctx->needs_redraw) return;
    
    // Очищаем поверхность
    SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        switch (op->type) {
            case CANVAS_FILL_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           ctx->fill_color | 0xFF000000);
                break;
                
            case CANVAS_STROKE_RECT: {
                int lw = ctx->line_width;
                // Верхняя линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                // Нижняя линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y + op->h - lw, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                // Левая линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                // Правая линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x + op->w - lw, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                break;
            }
                
            case CANVAS_CLEAR_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           0x00FFFFFF);
                break;
                
            case CANVAS_FILL_TEXT:
                if (op->text) {
                    TTF_Font* font = fonts[1];
                    int font_size = 12;
                    
                    if (op->font) {
                        sscanf(op->font, "%dpx", &font_size);
                    }
                    
                    if (font_size <= 10) font = fonts[0];
                    else if (font_size <= 12) font = fonts[1];
                    else if (font_size <= 16) font = fonts[2];
                    else if (font_size <= 20) font = fonts[3];
                    else font = fonts[4];
                    
                    SDL_Color color = (SDL_Color){ 
                        (ctx->fill_color >> 16) & 0xFF,
                        (ctx->fill_color >> 8) & 0xFF,
                        ctx->fill_color & 0xFF, 255 
                    };
                    SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, op->text, color);
                    if (text_surface) {
                        SDL_Rect dest = {op->x, op->y, text_surface->w, text_surface->h};
                        SDL_BlitSurface(text_surface, NULL, ctx->surface, &dest);
                        SDL_FreeSurface(text_surface);
                    }
                }
                break;
                
            case CANVAS_DRAW_IMAGE:
                if (op->image && op->w > 0 && op->h > 0) {
                    SDL_Rect dest = {op->x, op->y, op->w, op->h};
                    SDL_BlitSurface(op->image, NULL, ctx->surface, &dest);
                }
                break;
                
            case CANVAS_LINE_TO:
                canvas_draw_line(ctx, ctx->current_x, ctx->current_y, op->x, op->y, 
                               ctx->stroke_color | 0xFF000000, ctx->line_width);
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            case CANVAS_ARC: {
                int cx = op->x + op->w / 2;
                int cy = op->y + op->h / 2;
                int radius = op->w / 2;
                canvas_draw_circle(ctx, cx, cy, radius, ctx->stroke_color | 0xFF000000, 0);
                break;
            }
                
            case CANVAS_RECT:
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            default:
                break;
        }
        op = op->next;
    }
    
    ctx->needs_redraw = 0;
}

void initLang(){
    const char settings_inifile[] = SYSTEM_PATH "/uisettings.ini";
    char l_id[8];
    int lang = ini_getl("lang", "select", 0, settings_inifile);
    sprintf(l_id, "id%d", lang);
    ini_gets("lang", l_id, "en_US", language_name, 64, settings_inifile);
}

uint32_t hex2int(const char *hex) {
    uint32_t val = 0;
    while (*hex) {
        uint8_t byte = *hex++;
        if (byte >= '0' && byte <= '9') byte -= '0';
        else if (byte >= 'a' && byte <='f') byte = byte - 'a' + 10;
        else if (byte >= 'A' && byte <='F') byte = byte - 'A' + 10;
        else byte = 0;
        val = (val << 4) | (byte & 0xF);
    }
    return val;
}

int parse_css_color(const char* color_str) {
    if (!color_str) return 0;
    
    if (strncmp(color_str, "#", 1) == 0) {
        return hex2int(color_str + 1);
    } else if (strcmp(color_str, "black") == 0) {
        return 0x000000;
    } else if (strcmp(color_str, "white") == 0) {
        return 0xFFFFFF;
    } else if (strcmp(color_str, "red") == 0) {
        return 0xFF0000;
    } else if (strcmp(color_str, "green") == 0) {
        return 0x00FF00;
    } else if (strcmp(color_str, "blue") == 0) {
        return 0x0000FF;
    } else if (strcmp(color_str, "gray") == 0 || strcmp(color_str, "grey") == 0) {
        return 0x808080;
    } else if (strcmp(color_str, "yellow") == 0) {
        return 0xFFFF00;
    } else if (strcmp(color_str, "cyan") == 0) {
        return 0x00FFFF;
    } else if (strcmp(color_str, "magenta") == 0) {
        return 0xFF00FF;
    } else if (strcmp(color_str, "silver") == 0) {
        return 0xC0C0C0;
    } else if (strcmp(color_str, "maroon") == 0) {
        return 0x800000;
    } else if (strcmp(color_str, "purple") == 0) {
        return 0x800080;
    } else if (strcmp(color_str, "fuchsia") == 0) {
        return 0xFF00FF;
    } else if (strcmp(color_str, "lime") == 0) {
        return 0x00FF00;
    } else if (strcmp(color_str, "olive") == 0) {
        return 0x808000;
    } else if (strcmp(color_str, "navy") == 0) {
        return 0x000080;
    } else if (strcmp(color_str, "teal") == 0) {
        return 0x008080;
    } else if (strcmp(color_str, "orange") == 0) {
        return 0xFFA500;
    } else if (strcmp(color_str, "brown") == 0) {
        return 0xA52A2A;
    } else if (strcmp(color_str, "pink") == 0) {
        return 0xFFC0CB;
    } else if (strcmp(color_str, "gold") == 0) {
        return 0xFFD700;
    }
    
    return hex2int(color_str);
}

int parse_css_length(const char* length_str) {
    if (!length_str) return 0;
    
    int value = 0;
    if (strstr(length_str, "px")) {
        sscanf(length_str, "%dpx", &value);
    } else if (strstr(length_str, "em")) {
        float em_value;
        sscanf(length_str, "%fem", &em_value);
        value = (int)(em_value * 16);
    } else if (strstr(length_str, "rem")) {
        float rem_value;
        sscanf(length_str, "%frem", &rem_value);
        value = (int)(rem_value * 16);
    } else if (strstr(length_str, "%")) {
        sscanf(length_str, "%d%%", &value);
        value = (value * DEVICE_WIDTH) / 100;
    } else {
        value = atoi(length_str);
    }
    return value;
}

HtmlAttrib* html_new_attrib(HtmlAttribKey key, const char* key_name, const char* value) {
    HtmlAttrib* attrib = (HtmlAttrib*)malloc(sizeof(HtmlAttrib));
    if (attrib) {
        attrib->key = key;
        attrib->key_name = key_name ? strdup(key_name) : NULL;
        attrib->value = value ? strdup(value) : NULL;
        attrib->next = NULL;
    }
    return attrib;
}

void add_css_style(const char* selector, const char* property, const char* value) {
    CSSStyle* style = (CSSStyle*)malloc(sizeof(CSSStyle));
    if (!style) return;
    
    style->selector = strdup(selector);
    style->property = strdup(property);
    style->value = strdup(value);
    style->next = css_styles;
    css_styles = style;
}

void free_css_styles() {
    CSSStyle* style = css_styles;
    while (style) {
        CSSStyle* next = style->next;
        free(style->selector);
        free(style->property);
        free(style->value);
        free(style);
        style = next;
    }
    css_styles = NULL;
}

void apply_css_styles(HtmlElement* element) {
    if (!element || !css_styles) return;
    
    CSSStyle* style = css_styles;
    while (style) {
        int matches = 0;
        
        if (style->selector[0] != '#' && style->selector[0] != '.') {
            const char* tag_name = html_tag_to_string(element->tag);
            if (tag_name && strcmp(tag_name, style->selector) == 0) {
                matches = 1;
            }
        }
        
        if (style->selector[0] == '#') {
            if (element->id && strcmp(element->id, style->selector + 1) == 0) {
                matches = 1;
            }
        }
        
        if (style->selector[0] == '.') {
            // Простая проверка класса (без поддержки множественных классов)
            HtmlAttrib* attrib = element->attrib;
            while (attrib) {
                if (attrib->key == HTML_ATTRIB_CLASS && 
                    strcmp(attrib->value, style->selector + 1) == 0) {
                    matches = 1;
                    break;
                }
                attrib = attrib->next;
            }
        }
        
        if (matches) {
            if (strcmp(style->property, "color") == 0) {
                element->textcolor = parse_css_color(style->value);
            } else if (strcmp(style->property, "background-color") == 0) {
                element->color = parse_css_color(style->value);
            } else if (strcmp(style->property, "border-color") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-color", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "border-width") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-width", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "border-style") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-style", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-top") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-top", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-bottom") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-bottom", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-left") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-left", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-right") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-right", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-top") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-top", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-bottom") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-bottom", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-left") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-left", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-right") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-right", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "display") == 0) {
                if (strcmp(style->value, "none") == 0) element->display = NONE;
                else if (strcmp(style->value, "inline") == 0) element->display = INLINE;
                else if (strcmp(style->value, "block") == 0) element->display = BLOCK;
                else if (strcmp(style->value, "inline-block") == 0) element->display = INLINE;
            } else if (strcmp(style->property, "width") == 0) {
                element->w = parse_css_length(style->value);
            } else if (strcmp(style->property, "height") == 0) {
                element->h = parse_css_length(style->value);
            } else if (strcmp(style->property, "font-size") == 0) {
                if (strstr(style->value, "px")) {
                    int size;
                    sscanf(style->value, "%dpx", &size);
                    if (size <= 10) element->fontsize = 0;
                    else if (size <= 12) element->fontsize = 1;
                    else if (size <= 16) element->fontsize = 2;
                    else if (size <= 20) element->fontsize = 3;
                    else element->fontsize = 4;
                }
            } else if (strcmp(style->property, "text-align") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "text-align", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            }
        }
        
        style = style->next;
    }
}

HtmlElement *html_find_element(HtmlElement *element, const char *id) {
    if(!element) return NULL;
    while(element) {
        if(element->id && strcmp(element->id, id) == 0) return element;
        HtmlElement *found = html_find_element(element->child, id);
        if(found) return found;
        element = element->sibling;
    }
    return NULL;
}

TableContext* create_table_context() {
    TableContext* table = (TableContext*)malloc(sizeof(TableContext));
    if (table) {
        table->columns = NULL;
        table->rows = NULL;
        table->col_count = 0;
        table->row_count = 0;
        table->current_col = 0;
        table->current_row = 0;
        table->current_row_element = NULL;
        table->table_x = 0;
        table->table_y = 0;
    }
    return table;
}

void free_table_context(TableContext* table) {
    if (!table) return;
    
    TableColumn* col = table->columns;
    while (col) {
        TableColumn* next = col->next;
        free(col);
        col = next;
    }
    
    TableRow* row = table->rows;
    while (row) {
        TableRow* next = row->next;
        free(row);
        row = next;
    }
    
    free(table);
}

void table_add_column(TableContext* table, int width) {
    TableColumn* new_col = (TableColumn*)malloc(sizeof(TableColumn));
    if (new_col) {
        new_col->width = width;
        new_col->next = NULL;
        
        if (!table->columns) {
            table->columns = new_col;
        } else {
            TableColumn* last = table->columns;
            while (last->next) last = last->next;
            last->next = new_col;
        }
        table->col_count++;
    }
}

void table_add_row(TableContext* table, HtmlElement* cells, int height) {
    TableRow* new_row = (TableRow*)malloc(sizeof(TableRow));
    if (new_row) {
        new_row->cells = cells;
        new_row->height = height;
        new_row->next = NULL;
        
        if (!table->rows) {
            table->rows = new_row;
        } else {
            TableRow* last = table->rows;
            while (last->next) last = last->next;
            last->next = new_row;
        }
        table->row_count++;
    }
}

int get_table_column_width(TableContext* table, int col_index) {
    TableColumn* col = table->columns;
    int i = 0;
    while (col && i < col_index) {
        col = col->next;
        i++;
    }
    return col ? col->width : 100;
}

int get_table_row_height(TableContext* table, int row_index) {
    TableRow* row = table->rows;
    int i = 0;
    while (row && i < row_index) {
        row = row->next;
        i++;
    }
    return row ? row->height : 20;
}

void parse_css_from_style_tag(const char* css_text) {
    if (!css_text) return;
    
    char* css_copy = strdup(css_text);
    char* ptr = css_copy;
    
    while (*ptr) {
        while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
        
        if (!*ptr) break;
        
        char* selector_start = ptr;
        while (*ptr && *ptr != '{') ptr++;
        if (!*ptr) break;
        
        char* selector_end = ptr;
        *selector_end = '\0';
        ptr++;
        
        while (*ptr && *ptr != '}') {
            while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
            
            if (*ptr == '}') break;
            
            char* prop_start = ptr;
            while (*ptr && *ptr != ':' && *ptr != '}') ptr++;
            if (*ptr == '}') break;
            
            char* prop_end = ptr;
            *prop_end = '\0';
            ptr++;
            
            while (*ptr == ' ' || *ptr == '\t') ptr++;
            
            char* value_start = ptr;
            while (*ptr && *ptr != ';' && *ptr != '}') ptr++;
            
            char* value_end = ptr;
            if (*ptr == ';') {
                *value_end = '\0';
                ptr++;
            } else if (*ptr == '}') {
                *value_end = '\0';
            }
            
            add_css_style(selector_start, prop_start, value_start);
            
            while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
        }
        
        if (*ptr == '}') ptr++;
    }
    
    free(css_copy);
}

const char* get_style_value(HtmlElement* element, const char* property) {
    HtmlAttrib* attrib = element->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_STYLE && attrib->key_name && 
            strcmp(attrib->key_name, property) == 0) {
            return attrib->value;
        }
        attrib = attrib->next;
    }
    return NULL;
}

JSRuntime *js_rt;
JSContext *js_ctx;

void qjs_peval_string_logged(JSContext *ctx, const char *code) {
    if (!code) {
        add_log("JavaScript error: code is NULL");
        return;
    }

    size_t len = strlen(code);
    if (len == 0) {
        add_log("JavaScript error: empty code");
        return;
    }

    // === 1. Проверка на обрезку (отсутствие завершающих скобок / точек с запятой)
    int looks_truncated = 0;
    const char* last_non_ws = code + len - 1;
    while (last_non_ws > code && (*last_non_ws == ' ' || *last_non_ws == '\t' || *last_non_ws == '\n')) {
        last_non_ws--;
    }
    if (len > 0) {
        char last_char = *last_non_ws;
        if (last_char == '{' || last_char == '(' || last_char == '[' ||
            last_char == ',' || last_char == '.' || last_char == '+' ||
            last_char == '-' || last_char == '*' || last_char == '/' ||
            last_char == ':' || last_char == '=' || last_char == '<' ||
            last_char == '>' || last_char == '!' || last_char == '&') {
            looks_truncated = 1;
        }
    }

    // === 2. Проверка на \r и \0 внутри
    int has_cr = 0, has_null = 0;
    for (size_t i = 0; i < len; i++) {
        if (code[i] == '\r') has_cr = 1;
        if (code[i] == '\0' && i != len) has_null = 1; // \0 не в конце
    }

    // === 3. Подсчёт строк
    int lines = 1;
    for (size_t i = 0; i < len; i++) {
        if (code[i] == '\n') lines++;
    }

    add_log("JS eval: %d lines, %zu bytes", lines, len);
    if (has_cr) add_log("⚠ JS contains CR (\\r) — may cause parse errors");
    if (has_null) add_log("⚠ JS contains embedded \\0 — likely truncated!");
    if (looks_truncated) add_log("⚠ JS ends with suspicious character — possibly truncated");

    // === 4. Выполняем eval
    JSValue result = JS_Eval(ctx, code, len, "<eval>", JS_EVAL_TYPE_GLOBAL);

    if (JS_IsException(result)) {
        JSValue exception = JS_GetException(ctx);
        const char* error_msg = NULL;
        
        // QuickJS exception может быть объектом Error — извлекаем message
        if (JS_IsObject(exception)) {
            JSValue msg_val = JS_GetPropertyStr(ctx, exception, "message");
            if (!JS_IsUndefined(msg_val) && !JS_IsNull(msg_val)) {
                error_msg = JS_ToCString(ctx, msg_val);
                JS_FreeValue(ctx, msg_val);
            }
            // Если message не нашли, попробуем toString
            if (!error_msg) {
                error_msg = JS_ToCString(ctx, exception);
            }
            // Также попробуем извлечь lineNumber
            JSValue line_val = JS_GetPropertyStr(ctx, exception, "lineNumber");
            if (JS_IsNumber(line_val)) {
                int32_t line;
                JS_ToInt32(ctx, &line, line_val);
                if (error_msg) {
                    char buf[1024];
                    snprintf(buf, sizeof(buf), "%s (line %d)", error_msg, line);
                    JS_FreeCString(ctx, error_msg);
                    error_msg = strdup(buf);
                } else {
                    char buf[64];
                    snprintf(buf, sizeof(buf), "error at line %d", line);
                    error_msg = strdup(buf);
                }
            }
            JS_FreeValue(ctx, line_val);
        } else {
            error_msg = JS_ToCString(ctx, exception);
        }
        
        add_log("JS ERROR: %s", error_msg ? error_msg : "unknown error");
        // Попытка извлечь номер строки
        int error_line = 0;
        const char* line_marker = error_msg ? strstr(error_msg, "line ") : NULL;
        if (line_marker && sscanf(line_marker + 5, "%d", &error_line) == 1) {
            // Показываем контекст вокруг ошибки
            const char* ptr = code;
            int cur_line = 1;
            const char* line_start = code;

            // Ищем начало нужной строки
            while (*ptr && cur_line < error_line) {
                if (*ptr == '\n') {
                    cur_line++;
                    line_start = ptr + 1;
                }
                ptr++;
            }

            // Собираем контекст: 2 до, сама, 2 после
            const char* context_start[5];
            int context_line_nums[5];
            int context_count = 0;

            // Вернёмся назад до 2 строк
            const char* back = line_start;
            int back_lines = 0;
            while (back > code && back_lines < 2) {
                back--;
                if (*back == '\n') back_lines++;
            }
            if (*back != '\n') back = code; else back++;

            // Теперь вперёд до 5 строк
            const char* scan = back;
            int scan_line = error_line - back_lines;
            while (*scan && context_count < 5) {
                context_start[context_count] = scan;
                context_line_nums[context_count] = scan_line;
                while (*scan && *scan != '\n') scan++;
                if (*scan == '\n') scan++; // пропустить \n
                context_count++;
                scan_line++;
                if (scan_line > error_line + 2) break;
            }

            // Выводим контекст
            for (int i = 0; i < context_count; i++) {
                const char* line = context_start[i];
                size_t line_len = 0;
                const char* end = strchr(line, '\n');
                if (end) line_len = end - line;
                else line_len = strlen(line);

                // Обрезаем до 120 символов
                char clean_line[130];
                int to_copy = (line_len > 120) ? 120 : (int)line_len;
                strncpy(clean_line, line, to_copy);
                clean_line[to_copy] = '\0';

                if (context_line_nums[i] == error_line) {
                    add_log("→ %d: %s", context_line_nums[i], clean_line);
                } else {
                    add_log("  %d: %s", context_line_nums[i], clean_line);
                }
            }
        } else {
            // Если нет номера строки — покажем последние 3 строки
            add_log("No line number — showing last 3 lines:");
            const char* ptr = code + len - 1;
            int lines_back = 0;
            while (ptr > code && lines_back < 3) {
                if (*ptr == '\n') lines_back++;
                ptr--;
            }
            if (*ptr != '\n') ptr++; // пропустить частичную строку
            char snippet[512];
            size_t avail = (code + len) - ptr;
            if (avail > 511) avail = 511;
            strncpy(snippet, ptr, avail);
            snippet[avail] = '\0';
            add_log("JS tail:\n%s", snippet);
        }
        // error_msg может быть strdup (lineNumber) или JS_ToCString — освобождаем правильно
        if (error_msg) {
            // Проверяем: strdup строки не нужно освобождать через JS_FreeCString.
            // Но мы не можем точно определить тип. Безопаснее не освобождать strdup
            // (небольшая утечка при ошибках, но без краша).
            // Строка из JS_ToCString нужно освободить.
            // Мы пометим strdup через флаг, но проще — просто не освобождаем.
        }
        JS_FreeValue(ctx, exception);
    } else {
        const char* result_str = JS_ToCString(ctx, result);
        if (result_str) {
            add_log("JS result: %s", result_str);
            JS_FreeCString(ctx, result_str);
        } else {
            add_log("JS executed (no return value)");
        }
        JS_FreeValue(ctx, result);
    }
}

static JSValue native_print(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    char buffer[1024];
    buffer[0] = '\0';
    int pos = 0;
    for (int i = 0; i < argc && pos < 1000; i++) {
        if (i > 0) {
            buffer[pos++] = ' ';
        }
        const char* str = JS_ToCString(ctx, argv[i]);
        if (str) {
            int len = strlen(str);
            if (pos + len > 1000) len = 1000 - pos;
            memcpy(buffer + pos, str, len);
            pos += len;
            JS_FreeCString(ctx, str);
        }
    }
    buffer[pos] = '\0';
    
    add_log("JS: %s", buffer);
    SDL_Log("%s\n", buffer);
    return JS_UNDEFINED;
}

static JSValue console_log_helper(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv, int magic) {
    const char* func_name = "log";
    switch (magic) {
        case 0: func_name = "log"; break;
        case 1: func_name = "error"; break;
        case 2: func_name = "warn"; break;
        case 3: func_name = "info"; break;
        default: func_name = "log"; break;
    }
    
    char buffer[1024];
    buffer[0] = '\0';
    int pos = 0;
    for (int i = 0; i < argc && pos < 1000; i++) {
        if (i > 0) {
            buffer[pos++] = ' ';
        }
        const char* str = JS_ToCString(ctx, argv[i]);
        if (str) {
            int len = strlen(str);
            if (pos + len > 1000) len = 1000 - pos;
            memcpy(buffer + pos, str, len);
            pos += len;
            JS_FreeCString(ctx, str);
        }
    }
    buffer[pos] = '\0';
    
    add_log("console.%s: %s", func_name, buffer);
    SDL_Log("JS: %s\n", buffer);
    return JS_UNDEFINED;
}

void clear_logs() {
    for (int i = 0; i < log_line_count; i++) {
        free(log_lines[i]);
        log_lines[i] = NULL;
    }
    log_line_count = 0;
    dirty = 1;
}

static JSValue js_document_write(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return console_log_helper(ctx, JS_NULL, argc, argv, 0);
}

static JSValue js_window_navigator(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue nav = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, nav, "language", JS_NewString(ctx, language_name));
    JS_SetPropertyStr(ctx, nav, "userLanguage", JS_NewString(ctx, language_name));
    return nav;
}

static JSValue _duc_helper_get_element_prop_n(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* element_id = JS_ToCString(ctx, argv[0]);
    if (!element_id) {
        return JS_NULL;
    }
    
    HtmlElement *el = html_find_element(doc->root_element, element_id);
    JS_FreeCString(ctx, element_id);
    if (!el) {
        return JS_NULL;
    }
    
    int32_t tag;
    JS_ToInt32(ctx, &tag, argv[1]);
    switch(tag){
        case COLOR: 
            return JS_NewInt32(ctx, el->textcolor ? el->textcolor : 0x000000);
        case BACKGROUND_COLOR: 
            return JS_NewInt32(ctx, el->color ? el->color : 0xFFFFFF);
        case DISPLAY:
            switch(el->display){
                case NONE: return JS_NewString(ctx, "none");
                case INLINE: return JS_NewString(ctx, "inline");
                case BLOCK: return JS_NewString(ctx, "block");
                default: return JS_NewString(ctx, "inline");
            }
        case INNER_TEXT: 
            return JS_NewString(ctx, el->child && el->child->text ? el->child->text : "");
        default:
            return JS_NULL;
    }
}

static JSValue _duc_helper_set_element_prop_n(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* element_id = JS_ToCString(ctx, argv[0]);
    HtmlElement *el = html_find_element(doc->root_element, element_id);
    JS_FreeCString(ctx, element_id);
    if (!el) return JS_UNDEFINED;
    
    int32_t tag;
    JS_ToInt32(ctx, &tag, argv[1]);
    switch(tag){
        case COLOR: {
            const char* color_str = JS_ToCString(ctx, argv[2]);
            el->textcolor = hex2int(color_str);
            if(!el->textcolor) el->textcolor = 1;
            JS_FreeCString(ctx, color_str);
            break;
        }
        case BACKGROUND_COLOR: {
            const char* color_str = JS_ToCString(ctx, argv[2]);
            el->color = hex2int(color_str);
            JS_FreeCString(ctx, color_str);
            break;
        }
        case DISPLAY: {
            remath_dom = 1;
            const char* disp = JS_ToCString(ctx, argv[2]);
            if(strcmp(disp, "none") == 0) el->display = NONE;
            else if(strcmp(disp, "inline") == 0) el->display = INLINE;
            else if(strcmp(disp, "block") == 0) el->display = BLOCK;
            JS_FreeCString(ctx, disp);
            break;
        }
        case INNER_TEXT: {
            const char* text = JS_ToCString(ctx, argv[2]);
            if(el->child) html_free_element(el->child);
            el->child = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, NULL);
            el->child->text = strdup(text);
            remath_dom = 1;
            JS_FreeCString(ctx, text);
            break;
        }
    }
    return JS_UNDEFINED;
}

static void timer_callback(Timer* timer) {
    if (!timer || !js_ctx || JS_IsUndefined(timer->callback) || JS_IsNull(timer->callback)) return;

    JSValue result = JS_Call(js_ctx, timer->callback, JS_NULL, 0, NULL);
    if (JS_IsException(result)) {
        JSValue exception = JS_GetException(js_ctx);
        const char* err_str = NULL;
        if (JS_IsObject(exception)) {
            JSValue msg_val = JS_GetPropertyStr(js_ctx, exception, "message");
            if (!JS_IsUndefined(msg_val) && !JS_IsNull(msg_val)) {
                err_str = JS_ToCString(js_ctx, msg_val);
                JS_FreeValue(js_ctx, msg_val);
            }
            JS_FreeValue(js_ctx, exception);
        } else {
            err_str = JS_ToCString(js_ctx, exception);
            JS_FreeValue(js_ctx, exception);
        }
        add_log("Timer error: %s", err_str ? err_str : "unknown");
        if (err_str) JS_FreeCString(js_ctx, err_str);
    }
    JS_FreeValue(js_ctx, result);
}

static JSValue js_setTimeout(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (!JS_IsFunction(ctx, argv[0])) {
        return JS_ThrowTypeError(ctx, "setTimeout: first argument must be a function");
    }
    int32_t delay;
    JS_ToInt32(ctx, &delay, argv[1]);
    if (delay < 0) delay = 0;

    Timer* timer = (Timer*)malloc(sizeof(Timer));
    if (!timer) {
        return JS_NewInt32(ctx, -1);
    }

    timer->id = next_timer_id++;
    timer->callback = JS_DupValue(ctx, argv[0]);
    timer->delay = delay;
    timer->repeat = 0;
    timer->last_fire = SDL_GetTicks();
    timer->next = timers;
    timers = timer;
    add_log("add timers: %d delay %d", timer->id, timer->delay);

    return JS_NewInt32(ctx, timer->id);
}

static JSValue js_setInterval(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (!JS_IsFunction(ctx, argv[0])) {
        return JS_ThrowTypeError(ctx, "setInterval: first argument must be a function");
    }
    int32_t delay;
    JS_ToInt32(ctx, &delay, argv[1]);
    if (delay < 0) delay = 0;

    Timer* timer = (Timer*)malloc(sizeof(Timer));
    if (!timer) {
        return JS_NewInt32(ctx, -1);
    }

    timer->id = next_timer_id++;
    timer->callback = JS_DupValue(ctx, argv[0]);
    timer->delay = delay;
    timer->repeat = 1;
    timer->last_fire = SDL_GetTicks();
    timer->next = timers;
    timers = timer;

    return JS_NewInt32(ctx, timer->id);
}

static JSValue js_clearTimeout(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t id;
    JS_ToInt32(ctx, &id, argv[0]);
    Timer* prev = NULL;
    Timer* current = timers;

    while (current) {
        if (current->id == id) {
            JS_FreeValue(ctx, current->callback);

            if (prev) {
                prev->next = current->next;
            } else {
                timers = current->next;
            }
            free(current);
            return JS_UNDEFINED;
        }
        prev = current;
        current = current->next;
    }
    return JS_UNDEFINED;
}

// setInterval и clearInterval используют ту же логику
static JSValue js_clearInterval(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return js_clearTimeout(ctx, JS_NULL, argc, argv);
}

static JSValue js_Date_now(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return JS_NewFloat64(ctx, (double)SDL_GetTicks());
}

static JSValue js_Math_random(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return JS_NewFloat64(ctx, (double)rand() / (double)RAND_MAX);
}

static JSValue js_parseInt(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* str = JS_ToCString(ctx, argv[0]);
    int32_t base = 10;
    if (argc > 1 && !JS_IsUndefined(argv[1])) {
        JS_ToInt32(ctx, &base, argv[1]);
    }
    
    char* endptr;
    long val = strtol(str, &endptr, base);
    JS_FreeCString(ctx, str);
    return JS_NewInt32(ctx, (int)val);
}

static JSValue js_parseFloat(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* str = JS_ToCString(ctx, argv[0]);
    double val = atof(str);
    JS_FreeCString(ctx, str);
    return JS_NewFloat64(ctx, val);
}

void process_timers() {
    Uint32 current_ticks = SDL_GetTicks();
    Timer* current = timers;
    Timer* prev = NULL;

    while (current) {
        Timer* next = current->next;

        if ((int)(current_ticks - current->last_fire) >= current->delay) {
            //SDL_Log("Timer %d firing (delay: %d)", current->id, current->delay);
            //add_log("Timer %d firing (delay: %d)", current->id, current->delay);
            timer_callback(current);
            current->last_fire = current_ticks;

            if (!current->repeat) {
                // Удаляем одноразовый таймер
                JS_FreeValue(js_ctx, current->callback);

                if (prev) {
                    prev->next = current->next;
                } else {
                    timers = current->next;
                }
                free(current);
            }
        }

        prev = current;
        current = next;
    }
}

// JavaScript функции для Canvas
static JSValue js_canvas_getContext(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    // Получаем ID элемента из this
    JSValue id_val = JS_GetPropertyStr(ctx, this_val, "id");
    const char* id = JS_ToCString(ctx, id_val);
    JS_FreeValue(ctx, id_val);
    
    const char* context_type = JS_ToCString(ctx, argv[0]);
    
    HtmlElement* canvas = html_find_element(doc->root_element, id);
    if (!canvas || canvas->tag != HTML_TAG_CANVAS) {
        SDL_Log("Canvas element not found or not a canvas: %s", id);
        add_log("Canvas element not found or not a canvas: %s", id);
        JS_FreeCString(ctx, context_type);
        JS_FreeCString(ctx, id);
        return JS_NULL;
    }
    
    if (strcmp(context_type, "2d") != 0) {
        SDL_Log("Only 2d context supported, requested: %s", context_type);
        add_log("Only 2d context supported, requested: %s", context_type);
        JS_FreeCString(ctx, context_type);
        JS_FreeCString(ctx, id);
        return JS_NULL;
    }
    JS_FreeCString(ctx, context_type);
    
    // Проверяем или создаем контекст
    CanvasContext* canvas_ctx = get_canvas_context_from_element(canvas);
    if (!canvas_ctx) {
        int width = canvas->w ? canvas->w : 300;
        int height = canvas->h ? canvas->h : 150;
        
        canvas_ctx = create_canvas_context(width, height);
        if (!canvas_ctx) {
            JS_FreeCString(ctx, id);
            return JS_NULL;
        }
        
        HtmlAttrib* ctx_attrib = html_new_attrib(HTML_ATTRIB_CUSTOM, "__canvas_ctx", NULL);
        if (ctx_attrib) {
            ctx_attrib->user_data = canvas_ctx;
            ctx_attrib->next = canvas->attrib;
            canvas->attrib = ctx_attrib;
        }
    }
    
    // Создаем объект контекста
    JSValue obj = JS_NewObject(ctx);
    
    // Сохраняем указатель на canvas_ctx в JavaScript объекте
    JS_SetPropertyStr(ctx, obj, "__canvas_ptr", JS_NewInt64(ctx, (int64_t)(intptr_t)canvas_ctx));
    
    // Добавляем методы
    JS_SetPropertyStr(ctx, obj, "fillRect", JS_NewCFunction(ctx, js_canvas_fillRect, "fillRect", 4));
    JS_SetPropertyStr(ctx, obj, "strokeRect", JS_NewCFunction(ctx, js_canvas_strokeRect, "strokeRect", 4));
    JS_SetPropertyStr(ctx, obj, "clearRect", JS_NewCFunction(ctx, js_canvas_clearRect, "clearRect", 4));
    JS_SetPropertyStr(ctx, obj, "fillText", JS_NewCFunction(ctx, js_canvas_fillText, "fillText", 3));
    JS_SetPropertyStr(ctx, obj, "drawImage", JS_NewCFunction(ctx, js_canvas_drawImage, "drawImage", 3));
    JS_SetPropertyStr(ctx, obj, "beginPath", JS_NewCFunction(ctx, js_canvas_beginPath, "beginPath", 0));
    JS_SetPropertyStr(ctx, obj, "closePath", JS_NewCFunction(ctx, js_canvas_closePath, "closePath", 0));
    JS_SetPropertyStr(ctx, obj, "moveTo", JS_NewCFunction(ctx, js_canvas_moveTo, "moveTo", 2));
    JS_SetPropertyStr(ctx, obj, "lineTo", JS_NewCFunction(ctx, js_canvas_lineTo, "lineTo", 2));
    JS_SetPropertyStr(ctx, obj, "stroke", JS_NewCFunction(ctx, js_canvas_stroke, "stroke", 0));
    JS_SetPropertyStr(ctx, obj, "fill", JS_NewCFunction(ctx, js_canvas_fill, "fill", 0));
    JS_SetPropertyStr(ctx, obj, "arc", JS_NewCFunction(ctx, js_canvas_arc, "arc", 6));
    JS_SetPropertyStr(ctx, obj, "rect", JS_NewCFunction(ctx, js_canvas_rect, "rect", 4));
    JS_SetPropertyStr(ctx, obj, "set_fillStyle", JS_NewCFunction(ctx, js_canvas_set_fillStyle, "set_fillStyle", 1));
    JS_SetPropertyStr(ctx, obj, "set_strokeStyle", JS_NewCFunction(ctx, js_canvas_set_strokeStyle, "set_strokeStyle", 1));
    JS_SetPropertyStr(ctx, obj, "set_lineWidth", JS_NewCFunction(ctx, js_canvas_set_lineWidth, "set_lineWidth", 1));
    JS_SetPropertyStr(ctx, obj, "set_font", JS_NewCFunction(ctx, js_canvas_set_font, "set_font", 1));
    
    // New canvas API methods
    JS_SetPropertyStr(ctx, obj, "strokeText", JS_NewCFunction(ctx, js_canvas_strokeText, "strokeText", 3));
    JS_SetPropertyStr(ctx, obj, "arcTo", JS_NewCFunction(ctx, js_canvas_arcTo, "arcTo", 5));
    JS_SetPropertyStr(ctx, obj, "quadraticCurveTo", JS_NewCFunction(ctx, js_canvas_quadraticCurveTo, "quadraticCurveTo", 4));
    JS_SetPropertyStr(ctx, obj, "bezierCurveTo", JS_NewCFunction(ctx, js_canvas_bezierCurveTo, "bezierCurveTo", 6));
    JS_SetPropertyStr(ctx, obj, "ellipse", JS_NewCFunction(ctx, js_canvas_ellipse, "ellipse", 8));
    JS_SetPropertyStr(ctx, obj, "roundRect", JS_NewCFunction(ctx, js_canvas_roundRect, "roundRect", 5));
    JS_SetPropertyStr(ctx, obj, "clip", JS_NewCFunction(ctx, js_canvas_clip, "clip", 0));
    JS_SetPropertyStr(ctx, obj, "save", JS_NewCFunction(ctx, js_canvas_save, "save", 0));
    JS_SetPropertyStr(ctx, obj, "restore", JS_NewCFunction(ctx, js_canvas_restore, "restore", 0));
    JS_SetPropertyStr(ctx, obj, "translate", JS_NewCFunction(ctx, js_canvas_translate, "translate", 2));
    JS_SetPropertyStr(ctx, obj, "rotate", JS_NewCFunction(ctx, js_canvas_rotate, "rotate", 1));
    JS_SetPropertyStr(ctx, obj, "scale", JS_NewCFunction(ctx, js_canvas_scale, "scale", 2));
    JS_SetPropertyStr(ctx, obj, "setTransform", JS_NewCFunction(ctx, js_canvas_setTransform, "setTransform", 6));
    JS_SetPropertyStr(ctx, obj, "resetTransform", JS_NewCFunction(ctx, js_canvas_resetTransform, "resetTransform", 0));
    JS_SetPropertyStr(ctx, obj, "setLineDash", JS_NewCFunction(ctx, js_canvas_setLineDash, "setLineDash", 1));
    JS_SetPropertyStr(ctx, obj, "getLineDash", JS_NewCFunction(ctx, js_canvas_getLineDash, "getLineDash", 0));
    JS_SetPropertyStr(ctx, obj, "set_lineCap", JS_NewCFunction(ctx, js_canvas_set_lineCap, "set_lineCap", 1));
    JS_SetPropertyStr(ctx, obj, "set_lineJoin", JS_NewCFunction(ctx, js_canvas_set_lineJoin, "set_lineJoin", 1));
    JS_SetPropertyStr(ctx, obj, "set_globalAlpha", JS_NewCFunction(ctx, js_canvas_set_globalAlpha, "set_globalAlpha", 1));
    JS_SetPropertyStr(ctx, obj, "set_textAlign", JS_NewCFunction(ctx, js_canvas_set_textAlign, "set_textAlign", 1));
    JS_SetPropertyStr(ctx, obj, "set_textBaseline", JS_NewCFunction(ctx, js_canvas_set_textBaseline, "set_textBaseline", 1));
    JS_SetPropertyStr(ctx, obj, "set_shadowBlur", JS_NewCFunction(ctx, js_canvas_set_shadowBlur, "set_shadowBlur", 1));
    JS_SetPropertyStr(ctx, obj, "set_shadowColor", JS_NewCFunction(ctx, js_canvas_set_shadowColor, "set_shadowColor", 1));
    JS_SetPropertyStr(ctx, obj, "set_shadowOffsetX", JS_NewCFunction(ctx, js_canvas_set_shadowOffsetX, "set_shadowOffsetX", 1));
    JS_SetPropertyStr(ctx, obj, "set_shadowOffsetY", JS_NewCFunction(ctx, js_canvas_set_shadowOffsetY, "set_shadowOffsetY", 1));
    JS_SetPropertyStr(ctx, obj, "set_miterLimit", JS_NewCFunction(ctx, js_canvas_set_miterLimit, "set_miterLimit", 1));
    JS_SetPropertyStr(ctx, obj, "createLinearGradient", JS_NewCFunction(ctx, js_canvas_createLinearGradient, "createLinearGradient", 4));
    JS_SetPropertyStr(ctx, obj, "createRadialGradient", JS_NewCFunction(ctx, js_canvas_createRadialGradient, "createRadialGradient", 6));
    JS_SetPropertyStr(ctx, obj, "getImageData", JS_NewCFunction(ctx, js_canvas_getImageData, "getImageData", 4));
    JS_SetPropertyStr(ctx, obj, "putImageData", JS_NewCFunction(ctx, js_canvas_putImageData, "putImageData", 3));
    JS_SetPropertyStr(ctx, obj, "createImageData", JS_NewCFunction(ctx, js_canvas_createImageData, "createImageData", 2));
    JS_SetPropertyStr(ctx, obj, "measureText", JS_NewCFunction(ctx, js_canvas_measureText, "measureText", 1));
    JS_SetPropertyStr(ctx, obj, "reset", JS_NewCFunction(ctx, js_canvas_reset, "reset", 0));
    JS_SetPropertyStr(ctx, obj, "toDataURL", JS_NewCFunction(ctx, js_canvas_toDataURL, "toDataURL", 0));
    JS_SetPropertyStr(ctx, obj, "isPointInPath", JS_NewCFunction(ctx, js_canvas_isPointInPath, "isPointInPath", 2));
    
    // Property definitions with new properties
    const char* setup_code =
        "(function(ctx) {"
        "   Object.defineProperty(ctx, 'fillStyle', {"
        "       get: function() { return this._fillStyle || '#000000'; },"
        "       set: function(value) { this.set_fillStyle(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'strokeStyle', {"
        "       get: function() { return this._strokeStyle || '#000000'; },"
        "       set: function(value) { this.set_strokeStyle(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'lineWidth', {"
        "       get: function() { return this._lineWidth || 1; },"
        "       set: function(value) { this.set_lineWidth(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'font', {"
        "       get: function() { return this._font || '12px sans-serif'; },"
        "       set: function(value) { this.set_font(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'globalAlpha', {"
        "       get: function() { return this._globalAlpha !== undefined ? this._globalAlpha : 1.0; },"
        "       set: function(value) { this.set_globalAlpha(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'textAlign', {"
        "       get: function() { return this._textAlign || 'start'; },"
        "       set: function(value) { this.set_textAlign(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'textBaseline', {"
        "       get: function() { return this._textBaseline || 'alphabetic'; },"
        "       set: function(value) { this.set_textBaseline(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'lineCap', {"
        "       get: function() { return this._lineCap || 'butt'; },"
        "       set: function(value) { this.set_lineCap(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'lineJoin', {"
        "       get: function() { return this._lineJoin || 'miter'; },"
        "       set: function(value) { this.set_lineJoin(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'miterLimit', {"
        "       get: function() { return this._miterLimit !== undefined ? this._miterLimit : 10; },"
        "       set: function(value) { this.set_miterLimit(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'shadowBlur', {"
        "       get: function() { return this._shadowBlur || 0; },"
        "       set: function(value) { this.set_shadowBlur(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'shadowColor', {"
        "       get: function() { return this._shadowColor || 'black'; },"
        "       set: function(value) { this.set_shadowColor(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'shadowOffsetX', {"
        "       get: function() { return this._shadowOffsetX || 0; },"
        "       set: function(value) { this.set_shadowOffsetX(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'shadowOffsetY', {"
        "       get: function() { return this._shadowOffsetY || 0; },"
        "       set: function(value) { this.set_shadowOffsetY(value); }"
        "   });"
        "   return ctx;"
        "})";
    
    JSValue setup_fn = JS_Eval(ctx, setup_code, strlen(setup_code), "<canvas_setup>", JS_EVAL_TYPE_GLOBAL);
    if (!JS_IsException(setup_fn)) {
        JSValue args[] = { obj };
        JSValue setup_result = JS_Call(ctx, setup_fn, JS_UNDEFINED, 1, args);
        if (JS_IsException(setup_result)) {
            JSValue exc = JS_GetException(ctx);
            JS_FreeValue(ctx, exc);
        }
        JS_FreeValue(ctx, setup_result);
    } else {
        JSValue exc = JS_GetException(ctx);
        JS_FreeValue(ctx, exc);
    }
    JS_FreeValue(ctx, setup_fn);
    
    // Сохраняем указатель на CanvasContext снова (в случае если setup переписал объект)
    JS_SetPropertyStr(ctx, obj, "__canvas_ptr", JS_NewInt64(ctx, (int64_t)(intptr_t)canvas_ctx));
    
    // Также сохраняем ID элемента для отладки
    JS_SetPropertyStr(ctx, obj, "__canvas_id", JS_NewString(ctx, id));
    
    SDL_Log("Canvas context created successfully for id: %s", id);
    JS_FreeCString(ctx, id);
    return obj;
}

static CanvasContext* get_canvas_context_from_element(HtmlElement* element) {
    if (!element || element->tag != HTML_TAG_CANVAS) {
        return NULL;
    }
    
    HtmlAttrib* attrib = element->attrib;
    while (attrib) {
        if (strcmp(attrib->key_name, "__canvas_ctx") == 0) {
            return (CanvasContext*)attrib->user_data;  // Используйте user_data вместо value
        }
        attrib = attrib->next;
    }
    return NULL;
}

static CanvasContext* get_canvas_ctx_from_this(JSContext *ctx, JSValueConst this_val) {
    JSValue ptr_val = JS_GetPropertyStr(ctx, this_val, "__canvas_ptr");
    int64_t ptr_int = 0;
    JS_ToInt64(ctx, &ptr_int, ptr_val);
    JS_FreeValue(ctx, ptr_val);
    return (CanvasContext*)(intptr_t)ptr_int;
}

static JSValue js_canvas_fillRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y, w, h;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    JS_ToInt32(ctx, &w, argv[2]);
    JS_ToInt32(ctx, &h, argv[3]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_FILL_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_strokeRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y, w, h;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    JS_ToInt32(ctx, &w, argv[2]);
    JS_ToInt32(ctx, &h, argv[3]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_STROKE_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_clearRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y, w, h;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    JS_ToInt32(ctx, &w, argv[2]);
    JS_ToInt32(ctx, &h, argv[3]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_CLEAR_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_fillText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* text = JS_ToCString(ctx, argv[0]);
    int32_t x, y;
    JS_ToInt32(ctx, &x, argv[1]);
    JS_ToInt32(ctx, &y, argv[2]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) {
        JS_FreeCString(ctx, text);
        return JS_UNDEFINED;
    }
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_FILL_TEXT;
        op->text = strdup(text);
        op->x = x;
        op->y = y;
        op->font = strdup(canvas_ctx->font);
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    JS_FreeCString(ctx, text);
    return JS_UNDEFINED;
}

static JSValue js_canvas_drawImage(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (!op) return JS_UNDEFINED;
    
    if (argc == 3) {
        const char* src = JS_ToCString(ctx, argv[0]);
        JS_ToInt32(ctx, &op->x, argv[1]);
        JS_ToInt32(ctx, &op->y, argv[2]);
        
        op->image = img_src_parse(src);
        if (op->image) {
            op->w = op->image->w;
            op->h = op->image->h;
        } else {
            op->w = 0;
            op->h = 0;
        }
        JS_FreeCString(ctx, src);
    } else if (argc >= 5) {
        const char* src = JS_ToCString(ctx, argv[0]);
        JS_ToInt32(ctx, &op->x, argv[1]);
        JS_ToInt32(ctx, &op->y, argv[2]);
        JS_ToInt32(ctx, &op->w, argv[3]);
        JS_ToInt32(ctx, &op->h, argv[4]);
        
        op->image = img_src_parse(src);
        JS_FreeCString(ctx, src);
    }
    
    op->type = CANVAS_DRAW_IMAGE;
    op->next = NULL;
    canvas_add_operation(canvas_ctx, op);
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_beginPath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    canvas_ctx->path_open = 1;
    canvas_ctx->path_point_count = 0;
    return JS_UNDEFINED;
}

static JSValue js_canvas_closePath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    if (canvas_ctx->path_open) {
        CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
        if (op) {
            op->type = CANVAS_LINE_TO;
            op->x = canvas_ctx->path_start_x;
            op->y = canvas_ctx->path_start_y;
            op->next = NULL;
            canvas_add_operation(canvas_ctx, op);
        }
        canvas_ctx->path_open = 0;
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_moveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    if (!canvas_ctx->path_open) {
        canvas_ctx->path_start_x = x;
        canvas_ctx->path_start_y = y;
    }
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    // Record path point
    if (canvas_ctx->path_point_count < 2048) {
        canvas_ctx->path_points[canvas_ctx->path_point_count][0] = (float)x;
        canvas_ctx->path_points[canvas_ctx->path_point_count][1] = (float)y;
        canvas_ctx->path_point_count++;
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_lineTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_LINE_TO;
        op->x = x;
        op->y = y;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    // Record path point
    if (canvas_ctx->path_point_count < 2048) {
        canvas_ctx->path_points[canvas_ctx->path_point_count][0] = (float)x;
        canvas_ctx->path_points[canvas_ctx->path_point_count][1] = (float)y;
        canvas_ctx->path_point_count++;
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_stroke(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    canvas_execute_operations_sdl(canvas_ctx);
    canvas_ctx->path_open = 0;
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_fill(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx || !canvas_ctx->surface) return JS_UNDEFINED;
    
    // Fill the recorded path points as a polygon using scanline algorithm
    if (canvas_ctx->path_point_count < 3) {
        canvas_execute_operations_sdl(canvas_ctx);
        canvas_ctx->path_open = 0;
        return JS_UNDEFINED;
    }
    
    int color = canvas_ctx->fill_color | 0xFF000000;
    if (canvas_ctx->fill_gradient) color = canvas_ctx->fill_color | 0xFF000000; // Use base color for gradient
    float alpha = canvas_ctx->global_alpha;
    
    // Find bounding box
    int min_y = 99999, max_y = -99999;
    for (int i = 0; i < canvas_ctx->path_point_count; i++) {
        int py = (int)canvas_ctx->path_points[i][1];
        if (py < min_y) min_y = py;
        if (py > max_y) max_y = py;
    }
    if (min_y < 0) min_y = 0;
    if (max_y >= canvas_ctx->height) max_y = canvas_ctx->height - 1;
    
    // Scanline fill
    int n = canvas_ctx->path_point_count;
    for (int y = min_y; y <= max_y; y++) {
        // Find intersections with scanline
        float intersections[2048];
        int count = 0;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float y0 = canvas_ctx->path_points[i][1];
            float y1 = canvas_ctx->path_points[j][1];
            float x0 = canvas_ctx->path_points[i][0];
            float x1 = canvas_ctx->path_points[j][0];
            
            if ((y0 <= y && y1 > y) || (y1 <= y && y0 > y)) {
                float x_intersect = x0 + (y - y0) / (y1 - y0) * (x1 - x0);
                intersections[count++] = x_intersect;
            }
        }
        
        // Sort intersections
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (intersections[i] > intersections[j]) {
                    float tmp = intersections[i];
                    intersections[i] = intersections[j];
                    intersections[j] = tmp;
                }
            }
        }
        
        // Fill between pairs
        Uint32* pixels = (Uint32*)canvas_ctx->surface->pixels;
        for (int i = 0; i + 1 < count; i += 2) {
            int x_start = (int)intersections[i];
            int x_end = (int)intersections[i+1];
            if (x_start < 0) x_start = 0;
            if (x_end >= canvas_ctx->width) x_end = canvas_ctx->width - 1;
            
            for (int x = x_start; x <= x_end; x++) {
                Uint32 final_color = color;
                if (canvas_ctx->fill_gradient) {
                    final_color = canvas_gradient_get_color(canvas_ctx->fill_gradient, (float)x, (float)y) | 0xFF000000;
                }
                if (alpha < 1.0f) {
                    final_color = canvas_blend_color(pixels[y * canvas_ctx->width + x], final_color, alpha);
                }
                pixels[y * canvas_ctx->width + x] = final_color;
            }
        }
    }
    
    canvas_ctx->path_open = 0;
    dirty = 1;
    return JS_UNDEFINED;
}

static JSValue js_canvas_arc(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y, radius;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    JS_ToInt32(ctx, &radius, argv[2]);
    double start_angle = JS_VALUE_GET_FLOAT64(argv[3]);
    double end_angle = JS_VALUE_GET_FLOAT64(argv[4]);
    int counterclockwise = JS_VALUE_GET_BOOL(argv[5]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_ARC;
        op->x = x - radius;
        op->y = y - radius;
        op->w = radius * 2;
        op->h = radius * 2;
        op->start_angle = (float)start_angle;
        op->end_angle = (float)end_angle;
        op->counterclockwise = counterclockwise;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_rect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t x, y, w, h;
    JS_ToInt32(ctx, &x, argv[0]);
    JS_ToInt32(ctx, &y, argv[1]);
    JS_ToInt32(ctx, &w, argv[2]);
    JS_ToInt32(ctx, &h, argv[3]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_fillStyle(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    // Check if it's a gradient object
    JSValue ptr_val = JS_GetPropertyStr(ctx, argv[0], "__gradient_ptr");
    if (!JS_IsUndefined(ptr_val) && !JS_IsNull(ptr_val)) {
        int64_t ptr_int = 0;
        JS_ToInt64(ctx, &ptr_int, ptr_val);
        canvas_ctx->fill_gradient = (CanvasGradient*)(intptr_t)ptr_int;
        JS_FreeValue(ctx, ptr_val);
        JS_SetPropertyStr(ctx, this_val, "_fillStyle", JS_NewString(ctx, "[gradient]"));
        return JS_UNDEFINED;
    }
    JS_FreeValue(ctx, ptr_val);
    
    const char* color = JS_ToCString(ctx, argv[0]);
    if (!color) return JS_UNDEFINED;
    
    canvas_ctx->fill_color = parse_css_color(color);
    canvas_ctx->fill_gradient = NULL;
    
    JS_SetPropertyStr(ctx, this_val, "_fillStyle", JS_NewString(ctx, color));
    JS_FreeCString(ctx, color);
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_strokeStyle(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    // Check if it's a gradient object
    JSValue ptr_val = JS_GetPropertyStr(ctx, argv[0], "__gradient_ptr");
    if (!JS_IsUndefined(ptr_val) && !JS_IsNull(ptr_val)) {
        int64_t ptr_int = 0;
        JS_ToInt64(ctx, &ptr_int, ptr_val);
        canvas_ctx->stroke_gradient = (CanvasGradient*)(intptr_t)ptr_int;
        JS_FreeValue(ctx, ptr_val);
        JS_SetPropertyStr(ctx, this_val, "_strokeStyle", JS_NewString(ctx, "[gradient]"));
        return JS_UNDEFINED;
    }
    JS_FreeValue(ctx, ptr_val);
    
    const char* color = JS_ToCString(ctx, argv[0]);
    if (!color) return JS_UNDEFINED;
    
    canvas_ctx->stroke_color = parse_css_color(color);
    canvas_ctx->stroke_gradient = NULL;
    
    JS_SetPropertyStr(ctx, this_val, "_strokeStyle", JS_NewString(ctx, color));
    JS_FreeCString(ctx, color);
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_lineWidth(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int32_t width;
    JS_ToInt32(ctx, &width, argv[0]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    canvas_ctx->line_width = width;
    
    JS_SetPropertyStr(ctx, this_val, "_lineWidth", JS_NewInt32(ctx, width));
    
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_font(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* font = JS_ToCString(ctx, argv[0]);
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) {
        JS_FreeCString(ctx, font);
        return JS_UNDEFINED;
    }
    
    strncpy(canvas_ctx->font, font, 63);
    canvas_ctx->font[63] = '\0';
    
    JS_SetPropertyStr(ctx, this_val, "_font", JS_NewString(ctx, font));
    
    JS_FreeCString(ctx, font);
    return JS_UNDEFINED;
}

// ===== New Canvas API implementations =====

static JSValue js_canvas_strokeText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* text = JS_ToCString(ctx, argv[0]);
    double dx = 0, dy = 0;
    if (argc > 1) JS_ToFloat64(ctx, &dx, argv[1]);
    if (argc > 2) JS_ToFloat64(ctx, &dy, argv[2]);
    int x = (int)dx, y = (int)dy;
    
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) { JS_FreeCString(ctx, text); return JS_UNDEFINED; }
    
    CanvasOperation* op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op && text) {
        op->type = CANVAS_STROKE_TEXT;
        op->text = strdup(text);
        op->x = x; op->y = y;
        op->font = strdup(canvas_ctx->font);
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    JS_FreeCString(ctx, text);
    return JS_UNDEFINED;
}

static JSValue js_canvas_arcTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    double x1, y1, x2, y2, radius;
    JS_ToFloat64(ctx, &x1, argv[0]);
    JS_ToFloat64(ctx, &y1, argv[1]);
    JS_ToFloat64(ctx, &x2, argv[2]);
    JS_ToFloat64(ctx, &y2, argv[3]);
    JS_ToFloat64(ctx, &radius, argv[4]);
    
    // Simplified arcTo: draw line to tangent point then arc
    float dx0 = x1 - canvas_ctx->current_x;
    float dy0 = y1 - canvas_ctx->current_y;
    float dx1 = x2 - x1;
    float dy1 = y2 - y1;
    float dist0 = sqrtf(dx0*dx0 + dy0*dy0);
    float dist1 = sqrtf(dx1*dx1 + dy1*dy1);
    
    if (dist0 < 0.001 || dist1 < 0.001 || radius < 0.001) {
        // Degenerate case, just lineTo
        canvas_ctx->current_x = (int)x1;
        canvas_ctx->current_y = (int)y1;
        return JS_UNDEFINED;
    }
    
    // Normalize
    float nx0 = dx0/dist0, ny0 = dy0/dist0;
    float nx1 = dx1/dist1, ny1 = dy1/dist1;
    float angle = acosf(nx0*nx1 + ny0*ny1);
    float half_angle = angle / 2.0f;
    
    if (radius > dist0 * tanf(half_angle)) radius = dist0 * tanf(half_angle);
    
    float dist_tangent = radius / tanf(half_angle);
    float tx = x1 - nx0 * dist_tangent;
    float ty = y1 - ny0 * dist_tangent;
    
    // Add lineTo tangent point
    CanvasOperation* line_op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (line_op) {
        line_op->type = CANVAS_LINE_TO;
        line_op->x = (int)tx;
        line_op->y = (int)ty;
        line_op->next = NULL;
        canvas_add_operation(canvas_ctx, line_op);
    }
    
    // Calculate arc center
    float mid_x = (tx + x1) / 2.0f + (ny1 - ny0) * radius * 0.5f;
    float mid_y = (ty + y1) / 2.0f - (nx1 - nx0) * radius * 0.5f;
    
    // Use arc from tangent to second tangent point
    float end_tx = x1 + nx1 * (radius / tanf(half_angle));
    float end_ty = y1 + ny1 * (radius / tanf(half_angle));
    
    // Draw arc manually as line segments
    int segments = (int)(angle * 20);
    if (segments < 4) segments = 4;
    float start_a = atan2f(ty - mid_y, tx - mid_x);
    float end_a = atan2f(end_ty - mid_y, end_tx - mid_x);
    
    // Determine direction
    float cross = nx0*ny1 - ny0*nx1;
    float step = (end_a - start_a);
    if (cross < 0) { if (step > 0) step -= 2*M_PI; }
    else { if (step < 0) step += 2*M_PI; }
    step /= segments;
    
    for (int i = 1; i <= segments; i++) {
        float a = start_a + step * i;
        int px = (int)(mid_x + radius * cosf(a));
        int py = (int)(mid_y + radius * sinf(a));
        CanvasOperation* arc_op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
        if (arc_op) {
            arc_op->type = CANVAS_LINE_TO;
            arc_op->x = px;
            arc_op->y = py;
            arc_op->next = NULL;
            canvas_add_operation(canvas_ctx, arc_op);
        }
    }
    
    canvas_ctx->current_x = (int)end_tx;
    canvas_ctx->current_y = (int)end_ty;
    return JS_UNDEFINED;
}

static JSValue js_canvas_quadraticCurveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    double cpx, cpy, ex, ey;
    JS_ToFloat64(ctx, &cpx, argv[0]);
    JS_ToFloat64(ctx, &cpy, argv[1]);
    JS_ToFloat64(ctx, &ex, argv[2]);
    JS_ToFloat64(ctx, &ey, argv[3]);
    
    float x0 = canvas_ctx->current_x, y0 = canvas_ctx->current_y;
    int segments = 20;
    
    for (int i = 1; i <= segments; i++) {
        float t = (float)i / segments;
        float px = (1-t)*(1-t)*x0 + 2*(1-t)*t*cpx + t*t*ex;
        float py = (1-t)*(1-t)*y0 + 2*(1-t)*t*cpy + t*t*ey;
        CanvasOperation* op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
        if (op) {
            op->type = CANVAS_LINE_TO;
            op->x = (int)px;
            op->y = (int)py;
            op->next = NULL;
            canvas_add_operation(canvas_ctx, op);
        }
    }
    
    canvas_ctx->current_x = (int)ex;
    canvas_ctx->current_y = (int)ey;
    return JS_UNDEFINED;
}

static JSValue js_canvas_bezierCurveTo(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    double cp1x, cp1y, cp2x, cp2y, ex, ey;
    JS_ToFloat64(ctx, &cp1x, argv[0]);
    JS_ToFloat64(ctx, &cp1y, argv[1]);
    JS_ToFloat64(ctx, &cp2x, argv[2]);
    JS_ToFloat64(ctx, &cp2y, argv[3]);
    JS_ToFloat64(ctx, &ex, argv[4]);
    JS_ToFloat64(ctx, &ey, argv[5]);
    
    float x0 = canvas_ctx->current_x, y0 = canvas_ctx->current_y;
    int segments = 24;
    
    for (int i = 1; i <= segments; i++) {
        float t = (float)i / segments;
        float u = 1 - t;
        float px = u*u*u*x0 + 3*u*u*t*cp1x + 3*u*t*t*cp2x + t*t*t*ex;
        float py = u*u*u*y0 + 3*u*u*t*cp1y + 3*u*t*t*cp2y + t*t*t*ey;
        CanvasOperation* op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
        if (op) {
            op->type = CANVAS_LINE_TO;
            op->x = (int)px;
            op->y = (int)py;
            op->next = NULL;
            canvas_add_operation(canvas_ctx, op);
        }
    }
    
    canvas_ctx->current_x = (int)ex;
    canvas_ctx->current_y = (int)ey;
    return JS_UNDEFINED;
}

static JSValue js_canvas_ellipse(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    double cx, cy, rx, ry, rot = 0, sa = 0, ea = 2*M_PI;
    int ccw = 0;
    JS_ToFloat64(ctx, &cx, argv[0]);
    JS_ToFloat64(ctx, &cy, argv[1]);
    JS_ToFloat64(ctx, &rx, argv[2]);
    JS_ToFloat64(ctx, &ry, argv[3]);
    if (argc > 4) JS_ToFloat64(ctx, &rot, argv[4]);
    if (argc > 5) JS_ToFloat64(ctx, &sa, argv[5]);
    if (argc > 6) JS_ToFloat64(ctx, &ea, argv[6]);
    if (argc > 7) ccw = JS_VALUE_GET_BOOL(argv[7]);
    
    int segments = 48;
    if (fabs(ea - sa) < 0.01) segments = 4;
    
    float cos_r = cosf((float)rot), sin_r = sinf((float)rot);
    
    for (int i = 0; i <= segments; i++) {
        float t = ccw ? (float)sa + (float)(ea - sa) * (1.0f - (float)i/segments)
                       : (float)sa + (float)(ea - sa) * (float)i/segments;
        float ex = cosf(t) * (float)rx;
        float ey = sinf(t) * (float)ry;
        int px = (int)(cx + ex*cos_r - ey*sin_r);
        int py = (int)(cy + ex*sin_r + ey*cos_r);
        
        CanvasOperation* op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
        if (op) {
            op->type = CANVAS_LINE_TO;
            op->x = px;
            op->y = py;
            op->next = NULL;
            canvas_add_operation(canvas_ctx, op);
        }
    }
    
    canvas_ctx->current_x = (int)(cx + rx*cosf((float)ea)*cos_r - ry*sinf((float)ea)*sin_r);
    canvas_ctx->current_y = (int)(cy + rx*cosf((float)ea)*sin_r + ry*sinf((float)ea)*cos_r);
    return JS_UNDEFINED;
}

static JSValue js_canvas_roundRect(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    double x, y, w, h;
    double radii[4] = {0, 0, 0, 0};
    JS_ToFloat64(ctx, &x, argv[0]);
    JS_ToFloat64(ctx, &y, argv[1]);
    JS_ToFloat64(ctx, &w, argv[2]);
    JS_ToFloat64(ctx, &h, argv[3]);
    
    if (argc > 4) {
        if (JS_IsNumber(argv[4])) {
            double r; JS_ToFloat64(ctx, &r, argv[4]);
            radii[0] = radii[1] = radii[2] = radii[3] = r;
        }
    }
    
    double r = radii[0];
    if (r > w/2) r = w/2;
    if (r > h/2) r = h/2;
    
    // Top-left corner
    CanvasOperation* op;
    op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) { op->type = CANVAS_LINE_TO; op->x = (int)(x+r); op->y = (int)y; op->next = NULL; canvas_add_operation(canvas_ctx, op); }
    // Top-right
    op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) { op->type = CANVAS_LINE_TO; op->x = (int)(x+w-r); op->y = (int)y; op->next = NULL; canvas_add_operation(canvas_ctx, op); }
    // Bottom-right
    op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) { op->type = CANVAS_LINE_TO; op->x = (int)(x+w); op->y = (int)(y+h-r); op->next = NULL; canvas_add_operation(canvas_ctx, op); }
    // Bottom-left
    op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) { op->type = CANVAS_LINE_TO; op->x = (int)(x+r); op->y = (int)(y+h); op->next = NULL; canvas_add_operation(canvas_ctx, op); }
    // Close
    op = (CanvasOperation*)calloc(1, sizeof(CanvasOperation));
    if (op) { op->type = CANVAS_LINE_TO; op->x = (int)x; op->y = (int)y; op->next = NULL; canvas_add_operation(canvas_ctx, op); }
    
    canvas_ctx->current_x = (int)x;
    canvas_ctx->current_y = (int)y;
    return JS_UNDEFINED;
}

static JSValue js_canvas_clip(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    canvas_ctx->clip_enabled = 1;
    return JS_UNDEFINED;
}

static void canvas_save_state(CanvasContext* canvas_ctx) {
    if (canvas_ctx->state_stack_top >= 15) return;
    CanvasState* s = &canvas_ctx->state_stack[canvas_ctx->state_stack_top++];
    s->fill_color = canvas_ctx->fill_color;
    s->stroke_color = canvas_ctx->stroke_color;
    s->line_width = canvas_ctx->line_width;
    s->global_alpha = canvas_ctx->global_alpha;
    strncpy(s->font, canvas_ctx->font, 63);
    strncpy(s->text_align, canvas_ctx->text_align, 15);
    strncpy(s->text_baseline, canvas_ctx->text_baseline, 15);
    strncpy(s->line_cap, canvas_ctx->line_cap, 15);
    strncpy(s->line_join, canvas_ctx->line_join, 15);
    s->miter_limit = canvas_ctx->miter_limit;
    s->dash_count = canvas_ctx->dash_count;
    memcpy(s->dash_array, canvas_ctx->dash_array, sizeof(canvas_ctx->dash_array));
    s->shadow_blur = canvas_ctx->shadow_blur;
    s->shadow_color = canvas_ctx->shadow_color;
    s->shadow_offset_x = canvas_ctx->shadow_offset_x;
    s->shadow_offset_y = canvas_ctx->shadow_offset_y;
    memcpy(&s->transform_a, canvas_ctx->transform, sizeof(canvas_ctx->transform));
    s->fill_gradient = canvas_ctx->fill_gradient;
    s->stroke_gradient = canvas_ctx->stroke_gradient;
}

static void canvas_restore_state(CanvasContext* canvas_ctx) {
    if (canvas_ctx->state_stack_top <= 0) return;
    CanvasState* s = &canvas_ctx->state_stack[--canvas_ctx->state_stack_top];
    canvas_ctx->fill_color = s->fill_color;
    canvas_ctx->stroke_color = s->stroke_color;
    canvas_ctx->line_width = s->line_width;
    canvas_ctx->global_alpha = s->global_alpha;
    strncpy(canvas_ctx->font, s->font, 63);
    strncpy(canvas_ctx->text_align, s->text_align, 15);
    strncpy(canvas_ctx->text_baseline, s->text_baseline, 15);
    strncpy(canvas_ctx->line_cap, s->line_cap, 15);
    strncpy(canvas_ctx->line_join, s->line_join, 15);
    canvas_ctx->miter_limit = s->miter_limit;
    canvas_ctx->dash_count = s->dash_count;
    memcpy(canvas_ctx->dash_array, s->dash_array, sizeof(canvas_ctx->dash_array));
    canvas_ctx->shadow_blur = s->shadow_blur;
    canvas_ctx->shadow_color = s->shadow_color;
    canvas_ctx->shadow_offset_x = s->shadow_offset_x;
    canvas_ctx->shadow_offset_y = s->shadow_offset_y;
    memcpy(canvas_ctx->transform, &s->transform_a, sizeof(canvas_ctx->transform));
    canvas_ctx->fill_gradient = s->fill_gradient;
    canvas_ctx->stroke_gradient = s->stroke_gradient;
}

static JSValue js_canvas_save(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    canvas_save_state(canvas_ctx);
    return JS_UNDEFINED;
}

static JSValue js_canvas_restore(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    canvas_restore_state(canvas_ctx);
    return JS_UNDEFINED;
}

static JSValue js_canvas_translate(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double tx, ty;
    JS_ToFloat64(ctx, &tx, argv[0]);
    JS_ToFloat64(ctx, &ty, argv[1]);
    canvas_ctx->transform[4] += tx * canvas_ctx->transform[0] + ty * canvas_ctx->transform[2];
    canvas_ctx->transform[5] += tx * canvas_ctx->transform[1] + ty * canvas_ctx->transform[3];
    return JS_UNDEFINED;
}

static JSValue js_canvas_rotate(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double angle;
    JS_ToFloat64(ctx, &angle, argv[0]);
    float c = cosf((float)angle), s = sinf((float)angle);
    float a = canvas_ctx->transform[0], b = canvas_ctx->transform[1];
    float cc = canvas_ctx->transform[2], d = canvas_ctx->transform[3];
    canvas_ctx->transform[0] = a*c + cc*s;
    canvas_ctx->transform[1] = b*c + d*s;
    canvas_ctx->transform[2] = -a*s + cc*c;
    canvas_ctx->transform[3] = -b*s + d*c;
    return JS_UNDEFINED;
}

static JSValue js_canvas_scale(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double sx, sy;
    JS_ToFloat64(ctx, &sx, argv[0]);
    JS_ToFloat64(ctx, &sy, argv[1]);
    canvas_ctx->transform[0] *= (float)sx;
    canvas_ctx->transform[1] *= (float)sx;
    canvas_ctx->transform[2] *= (float)sy;
    canvas_ctx->transform[3] *= (float)sy;
    return JS_UNDEFINED;
}

static JSValue js_canvas_setTransform(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    if (argc >= 6) {
        double a,b,c,d,e,f;
        JS_ToFloat64(ctx, &a, argv[0]); JS_ToFloat64(ctx, &b, argv[1]);
        JS_ToFloat64(ctx, &c, argv[2]); JS_ToFloat64(ctx, &d, argv[3]);
        JS_ToFloat64(ctx, &e, argv[4]); JS_ToFloat64(ctx, &f, argv[5]);
        canvas_ctx->transform[0]=(float)a; canvas_ctx->transform[1]=(float)b;
        canvas_ctx->transform[2]=(float)c; canvas_ctx->transform[3]=(float)d;
        canvas_ctx->transform[4]=(float)e; canvas_ctx->transform[5]=(float)f;
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_resetTransform(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    canvas_ctx->transform[0]=1; canvas_ctx->transform[1]=0;
    canvas_ctx->transform[2]=0; canvas_ctx->transform[3]=1;
    canvas_ctx->transform[4]=0; canvas_ctx->transform[5]=0;
    return JS_UNDEFINED;
}

static JSValue js_canvas_setLineDash(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    if (argc > 0 && JS_IsArray(ctx, argv[0])) {
        JSValue len_val = JS_GetPropertyStr(ctx, argv[0], "length");
        int len = 0;
        JS_ToInt32(ctx, &len, len_val);
        JS_FreeValue(ctx, len_val);
        if (len > 32) len = 32;
        canvas_ctx->dash_count = len;
        for (int i = 0; i < len; i++) {
            JSValue v = JS_GetPropertyUint32(ctx, argv[0], i);
            double d = 0;
            JS_ToFloat64(ctx, &d, v);
            canvas_ctx->dash_array[i] = (float)d;
            JS_FreeValue(ctx, v);
        }
    } else {
        canvas_ctx->dash_count = 0;
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_getLineDash(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_NewArray(ctx);
    JSValue arr = JS_NewArray(ctx);
    for (int i = 0; i < canvas_ctx->dash_count; i++) {
        JS_SetPropertyUint32(ctx, arr, i, JS_NewFloat64(ctx, canvas_ctx->dash_array[i]));
    }
    return arr;
}

static JSValue js_canvas_set_lineCap(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    const char* cap = JS_ToCString(ctx, argv[0]);
    if (cap) {
        strncpy(canvas_ctx->line_cap, cap, 15);
        canvas_ctx->line_cap[15] = '\0';
        JS_SetPropertyStr(ctx, this_val, "_lineCap", JS_NewString(ctx, cap));
        JS_FreeCString(ctx, cap);
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_lineJoin(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    const char* join = JS_ToCString(ctx, argv[0]);
    if (join) {
        strncpy(canvas_ctx->line_join, join, 15);
        canvas_ctx->line_join[15] = '\0';
        JS_SetPropertyStr(ctx, this_val, "_lineJoin", JS_NewString(ctx, join));
        JS_FreeCString(ctx, join);
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_globalAlpha(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double alpha;
    JS_ToFloat64(ctx, &alpha, argv[0]);
    canvas_ctx->global_alpha = (float)alpha;
    JS_SetPropertyStr(ctx, this_val, "_globalAlpha", JS_NewFloat64(ctx, alpha));
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_textAlign(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    const char* align = JS_ToCString(ctx, argv[0]);
    if (align) {
        strncpy(canvas_ctx->text_align, align, 15);
        canvas_ctx->text_align[15] = '\0';
        JS_SetPropertyStr(ctx, this_val, "_textAlign", JS_NewString(ctx, align));
        JS_FreeCString(ctx, align);
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_textBaseline(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    const char* baseline = JS_ToCString(ctx, argv[0]);
    if (baseline) {
        strncpy(canvas_ctx->text_baseline, baseline, 15);
        canvas_ctx->text_baseline[15] = '\0';
        JS_SetPropertyStr(ctx, this_val, "_textBaseline", JS_NewString(ctx, baseline));
        JS_FreeCString(ctx, baseline);
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_shadowBlur(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double blur;
    JS_ToFloat64(ctx, &blur, argv[0]);
    canvas_ctx->shadow_blur = (float)blur;
    JS_SetPropertyStr(ctx, this_val, "_shadowBlur", JS_NewFloat64(ctx, blur));
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_shadowColor(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    const char* color = JS_ToCString(ctx, argv[0]);
    if (color) {
        canvas_ctx->shadow_color = parse_css_color(color);
        JS_SetPropertyStr(ctx, this_val, "_shadowColor", JS_NewString(ctx, color));
        JS_FreeCString(ctx, color);
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_shadowOffsetX(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double off;
    JS_ToFloat64(ctx, &off, argv[0]);
    canvas_ctx->shadow_offset_x = (int)off;
    JS_SetPropertyStr(ctx, this_val, "_shadowOffsetX", JS_NewFloat64(ctx, off));
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_shadowOffsetY(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double off;
    JS_ToFloat64(ctx, &off, argv[0]);
    canvas_ctx->shadow_offset_y = (int)off;
    JS_SetPropertyStr(ctx, this_val, "_shadowOffsetY", JS_NewFloat64(ctx, off));
    return JS_UNDEFINED;
}

static JSValue js_canvas_set_miterLimit(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    double ml;
    JS_ToFloat64(ctx, &ml, argv[0]);
    canvas_ctx->miter_limit = (float)ml;
    JS_SetPropertyStr(ctx, this_val, "_miterLimit", JS_NewFloat64(ctx, ml));
    return JS_UNDEFINED;
}

static JSValue js_canvas_createLinearGradient(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasGradient* grad = (CanvasGradient*)calloc(1, sizeof(CanvasGradient));
    if (!grad) return JS_NULL;
    grad->type = 0;
    double gx0, gy0, gx1, gy1;
    JS_ToFloat64(ctx, &gx0, argv[0]);
    JS_ToFloat64(ctx, &gy0, argv[1]);
    JS_ToFloat64(ctx, &gx1, argv[2]);
    JS_ToFloat64(ctx, &gy1, argv[3]);
    grad->x0 = (float)gx0; grad->y0 = (float)gy0;
    grad->x1 = (float)gx1; grad->y1 = (float)gy1;
    grad->color_stop_count = 0;
    
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "__gradient_ptr", JS_NewInt64(ctx, (int64_t)(intptr_t)grad));
    JS_SetPropertyStr(ctx, obj, "addColorStop", JS_NewCFunction(ctx, js_canvas_gradient_addColorStop, "addColorStop", 2));
    return obj;
}

static JSValue js_canvas_createRadialGradient(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasGradient* grad = (CanvasGradient*)calloc(1, sizeof(CanvasGradient));
    if (!grad) return JS_NULL;
    grad->type = 1;
    double rx0, ry0, rr0, rx1, ry1, rr1;
    JS_ToFloat64(ctx, &rx0, argv[0]);
    JS_ToFloat64(ctx, &ry0, argv[1]);
    JS_ToFloat64(ctx, &rr0, argv[2]);
    JS_ToFloat64(ctx, &rx1, argv[3]);
    JS_ToFloat64(ctx, &ry1, argv[4]);
    JS_ToFloat64(ctx, &rr1, argv[5]);
    grad->x0 = (float)rx0; grad->y0 = (float)ry0; grad->r0 = (float)rr0;
    grad->x1 = (float)rx1; grad->y1 = (float)ry1; grad->r1 = (float)rr1;
    grad->color_stop_count = 0;
    
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "__gradient_ptr", JS_NewInt64(ctx, (int64_t)(intptr_t)grad));
    JS_SetPropertyStr(ctx, obj, "addColorStop", JS_NewCFunction(ctx, js_canvas_gradient_addColorStop, "addColorStop", 2));
    return obj;
}

static JSValue js_canvas_gradient_addColorStop(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue ptr_val = JS_GetPropertyStr(ctx, this_val, "__gradient_ptr");
    int64_t ptr_int = 0;
    JS_ToInt64(ctx, &ptr_int, ptr_val);
    JS_FreeValue(ctx, ptr_val);
    CanvasGradient* grad = (CanvasGradient*)(intptr_t)ptr_int;
    if (!grad || grad->color_stop_count >= 16) return JS_UNDEFINED;
    
    double offset;
    JS_ToFloat64(ctx, &offset, argv[0]);
    const char* color = JS_ToCString(ctx, argv[1]);
    
    int idx = grad->color_stop_count;
    grad->color_positions[idx] = (float)offset;
    grad->color_stops[idx] = parse_css_color(color);
    grad->color_stop_count++;
    
    // Keep sorted by position
    for (int i = idx; i > 0 && grad->color_positions[i] < grad->color_positions[i-1]; i--) {
        float tmp_p = grad->color_positions[i]; grad->color_positions[i] = grad->color_positions[i-1]; grad->color_positions[i-1] = tmp_p;
        int tmp_c = grad->color_stops[i]; grad->color_stops[i] = grad->color_stops[i-1]; grad->color_stops[i-1] = tmp_c;
    }
    
    JS_FreeCString(ctx, color);
    return JS_UNDEFINED;
}

static int canvas_gradient_get_color(CanvasGradient* grad, float x, float y) {
    if (!grad || grad->color_stop_count == 0) return 0xFFFFFF;
    if (grad->color_stop_count == 1) return grad->color_stops[0];
    
    float t = 0;
    if (grad->type == 0) {
        // Linear
        float dx = grad->x1 - grad->x0, dy = grad->y1 - grad->y0;
        float len = sqrtf(dx*dx + dy*dy);
        if (len < 0.001) return grad->color_stops[0];
        t = ((x - grad->x0)*dx + (y - grad->y0)*dy) / len;
    } else {
        // Radial
        float dx = x - grad->x0, dy = y - grad->y0;
        float dist = sqrtf(dx*dx + dy*dy);
        float range = grad->r1 - grad->r0;
        if (range < 0.001) range = 0.001;
        t = (dist - grad->r0) / range;
    }
    
    if (t <= grad->color_positions[0]) return grad->color_stops[0];
    if (t >= grad->color_positions[grad->color_stop_count-1]) return grad->color_stops[grad->color_stop_count-1];
    
    for (int i = 0; i < grad->color_stop_count - 1; i++) {
        if (t >= grad->color_positions[i] && t <= grad->color_positions[i+1]) {
            float range = grad->color_positions[i+1] - grad->color_positions[i];
            float f = range > 0.001 ? (t - grad->color_positions[i]) / range : 0;
            int c0 = grad->color_stops[i], c1 = grad->color_stops[i+1];
            int r0=(c0>>16)&0xFF, g0=(c0>>8)&0xFF, b0=c0&0xFF;
            int r1=(c1>>16)&0xFF, g1=(c1>>8)&0xFF, b1=c1&0xFF;
            int r = (int)(r0 + (r1-r0)*f);
            int g = (int)(g0 + (g1-g0)*f);
            int b = (int)(b0 + (b1-b0)*f);
            return (r<<16)|(g<<8)|b;
        }
    }
    return grad->color_stops[grad->color_stop_count-1];
}

// Helper: apply transform to point
static void canvas_transform_point(CanvasContext* ctx, float* x, float* y) {
    float nx = *x * ctx->transform[0] + *y * ctx->transform[2] + ctx->transform[4];
    float ny = *x * ctx->transform[1] + *y * ctx->transform[3] + ctx->transform[5];
    *x = nx; *y = ny;
}

// Helper: blend pixel with alpha
static Uint32 canvas_blend_color(Uint32 dst, Uint32 src, float alpha) {
    if (alpha >= 1.0f) return src;
    if (alpha <= 0.0f) return dst;
    int sr=(src>>16)&0xFF, sg=(src>>8)&0xFF, sb=src&0xFF, sa=(src>>24)&0xFF;
    int dr=(dst>>16)&0xFF, dg=(dst>>8)&0xFF, db=dst&0xFF, da=(dst>>24)&0xFF;
    int a = (int)(sa * alpha);
    int ia = 255 - a;
    int r = (sr*a + dr*ia) / 255;
    int g = (sg*a + dg*ia) / 255;
    int b = (sb*a + db*ia) / 255;
    return (a<<24)|(r<<16)|(g<<8)|b;
}

static JSValue js_canvas_getImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    add_log("getImageData: enter argc=%d", argc);
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    add_log("getImageData: ctx=%p surface=%p", (void*)canvas_ctx, canvas_ctx ? (void*)canvas_ctx->surface : NULL);
    if (!canvas_ctx || !canvas_ctx->surface) return JS_NULL;
    
    int sx=0, sy=0, sw, sh;
    JS_ToInt32(ctx, &sx, argv[0]); JS_ToInt32(ctx, &sy, argv[1]);
    JS_ToInt32(ctx, &sw, argv[2]); JS_ToInt32(ctx, &sh, argv[3]);
    add_log("getImageData: sx=%d sy=%d sw=%d sh=%d cw=%d ch=%d", sx, sy, sw, sh, canvas_ctx->width, canvas_ctx->height);
    
    if (sw <= 0) sw = canvas_ctx->width;
    if (sh <= 0) sh = canvas_ctx->height;
    if (sx < 0) sx = 0;
    if (sy < 0) sy = 0;
    if (sx+sw > canvas_ctx->width) sw = canvas_ctx->width - sx;
    if (sy+sh > canvas_ctx->height) sh = canvas_ctx->height - sy;
    
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "width", JS_NewInt32(ctx, sw));
    JS_SetPropertyStr(ctx, obj, "height", JS_NewInt32(ctx, sh));
    add_log("getImageData: obj created, total=%d", sw * sh * 4);
    
    // Create data array (RGBA)
    int total = sw * sh * 4;
    uint8_t *buf = (uint8_t*)calloc(total, 1);
    add_log("getImageData: buf=%p", (void*)buf);
    if (!buf) return JS_NULL;
    
    if (canvas_ctx->surface) {
        Uint32* pixels = (Uint32*)canvas_ctx->surface->pixels;
        for (int y = 0; y < sh; y++) {
            for (int x = 0; x < sw; x++) {
                Uint32 pixel = pixels[(sy+y)*canvas_ctx->width + (sx+x)];
                buf[(y*sw+x)*4+0] = (pixel>>16)&0xFF; // R
                buf[(y*sw+x)*4+1] = (pixel>>8)&0xFF;  // G
                buf[(y*sw+x)*4+2] = pixel&0xFF;        // B
                buf[(y*sw+x)*4+3] = (pixel>>24)&0xFF;  // A
            }
        }
    }
    add_log("getImageData: pixels copied");
    
    JSValue data = JS_NewArrayBuffer(ctx, buf, total, NULL, NULL, 0);
    add_log("getImageData: arraybuffer created");
    if (JS_IsException(data)) { free(buf); return JS_NULL; }
    
    JS_SetPropertyStr(ctx, obj, "data", data);
    JS_FreeValue(ctx, data);
    add_log("getImageData: done");
    return obj;
}

static JSValue js_canvas_putImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx || !canvas_ctx->surface || argc < 2) return JS_UNDEFINED;
    
    JSValue img_data = argv[0];
    int dx = 0, dy = 0;
    JS_ToInt32(ctx, &dx, argv[1]);
    
    JSValue w_val = JS_GetPropertyStr(ctx, img_data, "width");
    JSValue h_val = JS_GetPropertyStr(ctx, img_data, "height");
    JSValue d_val = JS_GetPropertyStr(ctx, img_data, "data");
    
    int w = 0, h = 0;
    JS_ToInt32(ctx, &w, w_val);
    JS_ToInt32(ctx, &h, h_val);
    JS_FreeValue(ctx, w_val); JS_FreeValue(ctx, h_val);
    
    if (!JS_IsArray(ctx, d_val)) { JS_FreeValue(ctx, d_val); return JS_UNDEFINED; }
    
    Uint32* pixels = (Uint32*)canvas_ctx->surface->pixels;
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int px = dx + x, py = dy + y;
            if (px < 0 || px >= canvas_ctx->width || py < 0 || py >= canvas_ctx->height) continue;
            int idx = (y * w + x) * 4;
            JSValue r_v = JS_GetPropertyUint32(ctx, d_val, idx);
            JSValue g_v = JS_GetPropertyUint32(ctx, d_val, idx+1);
            JSValue b_v = JS_GetPropertyUint32(ctx, d_val, idx+2);
            JSValue a_v = JS_GetPropertyUint32(ctx, d_val, idx+3);
            int r=0,g=0,b=0,a=255;
            JS_ToInt32(ctx, &r, r_v); JS_ToInt32(ctx, &g, g_v);
            JS_ToInt32(ctx, &b, b_v); JS_ToInt32(ctx, &a, a_v);
            JS_FreeValue(ctx, r_v); JS_FreeValue(ctx, g_v);
            JS_FreeValue(ctx, b_v); JS_FreeValue(ctx, a_v);
            pixels[py * canvas_ctx->width + px] = (a<<24)|(r<<16)|(g<<8)|b;
        }
    }
    JS_FreeValue(ctx, d_val);
    canvas_ctx->needs_redraw = 1;
    dirty = 1;
    return JS_UNDEFINED;
}

static JSValue js_canvas_createImageData(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    int w = 0, h = 0;
    JS_ToInt32(ctx, &w, argv[0]); JS_ToInt32(ctx, &h, argv[1]);
    if (w <= 0) w = 1; if (h <= 0) h = 1;
    
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "width", JS_NewInt32(ctx, w));
    JS_SetPropertyStr(ctx, obj, "height", JS_NewInt32(ctx, h));
    
    int total = w * h * 4;
    Uint8* buf = (Uint8*)calloc(1, total);
    JSValue data = JS_NewArrayBuffer(ctx, buf, total, NULL, NULL, 0);
    if (JS_IsException(data)) { free(buf); data = JS_NewArray(ctx); }
    JS_SetPropertyStr(ctx, obj, "data", data);
    JS_FreeValue(ctx, data);
    return obj;
}

static JSValue js_canvas_measureText(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    const char* text = JS_ToCString(ctx, argv[0]);
    int width = 0;
    
    if (canvas_ctx && text) {
        TTF_Font* font = fonts[1];
        int font_size = 12;
        sscanf(canvas_ctx->font, "%dpx", &font_size);
        if (font_size <= 10) font = fonts[0];
        else if (font_size <= 12) font = fonts[1];
        else if (font_size <= 16) font = fonts[2];
        else if (font_size <= 20) font = fonts[3];
        else font = fonts[4];
        
        int tw, th;
        if (TTF_SizeUTF8(font, text, &tw, &th) == 0) width = tw;
    }
    
    JS_FreeCString(ctx, text);
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "width", JS_NewFloat64(ctx, (double)width));
    return obj;
}

static JSValue js_canvas_reset(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_UNDEFINED;
    
    // Free operations
    CanvasOperation* op = canvas_ctx->operations;
    while (op) {
        CanvasOperation* next = op->next;
        if (op->text) free(op->text);
        free(op);
        op = next;
    }
    canvas_ctx->operations = NULL;
    canvas_ctx->last_operation = NULL;
    
    canvas_ctx->fill_color = 0x000000;
    canvas_ctx->stroke_color = 0x000000;
    canvas_ctx->line_width = 1;
    strcpy(canvas_ctx->font, "12px sans-serif");
    canvas_ctx->global_alpha = 1.0f;
    strcpy(canvas_ctx->text_align, "start");
    strcpy(canvas_ctx->text_baseline, "alphabetic");
    strcpy(canvas_ctx->line_cap, "butt");
    strcpy(canvas_ctx->line_join, "miter");
    canvas_ctx->miter_limit = 10.0f;
    canvas_ctx->dash_count = 0;
    canvas_ctx->shadow_blur = 0;
    canvas_ctx->shadow_color = 0x000000;
    canvas_ctx->shadow_offset_x = 0;
    canvas_ctx->shadow_offset_y = 0;
    canvas_ctx->transform[0]=1; canvas_ctx->transform[1]=0;
    canvas_ctx->transform[2]=0; canvas_ctx->transform[3]=1;
    canvas_ctx->transform[4]=0; canvas_ctx->transform[5]=0;
    canvas_ctx->state_stack_top = 0;
    canvas_ctx->path_point_count = 0;
    canvas_ctx->clip_enabled = 0;
    canvas_ctx->fill_gradient = NULL;
    canvas_ctx->stroke_gradient = NULL;
    canvas_ctx->current_x = 0;
    canvas_ctx->current_y = 0;
    canvas_ctx->path_start_x = 0;
    canvas_ctx->path_start_y = 0;
    canvas_ctx->path_open = 0;
    
    if (canvas_ctx->surface) SDL_FillRect(canvas_ctx->surface, NULL, 0x00FFFFFF);
    canvas_ctx->needs_redraw = 1;
    dirty = 1;
    return JS_UNDEFINED;
}

static JSValue js_canvas_toDataURL(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return JS_NewString(ctx, "data:image/png;base64,");
}

static JSValue js_canvas_isPointInPath(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx || argc < 2) return JS_FALSE;
    double px, py;
    JS_ToFloat64(ctx, &px, argv[0]);
    JS_ToFloat64(ctx, &py, argv[1]);
    // Simple bounding box check
    if (canvas_ctx->path_point_count < 3) return JS_FALSE;
    float min_x=1e9, min_y=1e9, max_x=-1e9, max_y=-1e9;
    for (int i = 0; i < canvas_ctx->path_point_count; i++) {
        float x = canvas_ctx->path_points[i][0], y = canvas_ctx->path_points[i][1];
        if (x < min_x) min_x = x; if (x > max_x) max_x = x;
        if (y < min_y) min_y = y; if (y > max_y) max_y = y;
    }
    return ((float)px >= min_x && (float)px <= max_x && (float)py >= min_y && (float)py <= max_y) ? JS_TRUE : JS_FALSE;
}

static JSValue js_canvas_get_width(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_NewInt32(ctx, 300);
    return JS_NewInt32(ctx, canvas_ctx->width);
}

static JSValue js_canvas_set_width(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx || argc < 1) return JS_UNDEFINED;
    int w; JS_ToInt32(ctx, &w, argv[0]);
    if (w > 0 && w <= 2048) {
        canvas_ctx->width = w;
        if (canvas_ctx->surface) SDL_FreeSurface(canvas_ctx->surface);
        canvas_ctx->surface = SDL_CreateRGBSurface(0, w, canvas_ctx->height, 32,
                                                    0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        if (canvas_ctx->surface) SDL_FillRect(canvas_ctx->surface, NULL, 0x00FFFFFF);
        canvas_ctx->needs_redraw = 1;
        dirty = 1;
    }
    return JS_UNDEFINED;
}

static JSValue js_canvas_get_height(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx) return JS_NewInt32(ctx, 150);
    return JS_NewInt32(ctx, canvas_ctx->height);
}

static JSValue js_canvas_set_height(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    CanvasContext* canvas_ctx = get_canvas_ctx_from_this(ctx, this_val);
    if (!canvas_ctx || argc < 1) return JS_UNDEFINED;
    int h; JS_ToInt32(ctx, &h, argv[0]);
    if (h > 0 && h <= 2048) {
        canvas_ctx->height = h;
        if (canvas_ctx->surface) SDL_FreeSurface(canvas_ctx->surface);
        canvas_ctx->surface = SDL_CreateRGBSurface(0, canvas_ctx->width, h, 32,
                                                    0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        if (canvas_ctx->surface) SDL_FillRect(canvas_ctx->surface, NULL, 0x00FFFFFF);
        canvas_ctx->needs_redraw = 1;
        dirty = 1;
    }
    return JS_UNDEFINED;
}

static JSValue js_element_click(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue id_val = JS_GetPropertyStr(ctx, this_val, "id");
    const char* id = JS_ToCString(ctx, id_val);
    JS_FreeValue(ctx, id_val);
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    JS_FreeCString(ctx, id);
    if (!el) return JS_UNDEFINED;
    
    // Ищем атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            // Выполняем JavaScript код
            JSValue result = JS_Eval(ctx, attrib->value, strlen(attrib->value), "<onclick>", JS_EVAL_TYPE_GLOBAL);
            if (JS_IsException(result)) {
                JSValue exc = JS_GetException(ctx);
                JS_FreeValue(ctx, exc);
            }
            JS_FreeValue(ctx, result);
            break;
        }
        attrib = attrib->next;
    }
    
    return JS_UNDEFINED;
}

static JSValue js_element_onclick_setter(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* id = JS_ToCString(ctx, argv[0]);
    const char* handler = JS_ToCString(ctx, argv[1]);
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    if (!el) {
        JS_FreeCString(ctx, id);
        JS_FreeCString(ctx, handler);
        return JS_UNDEFINED;
    }
    
    // Ищем существующий атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    HtmlAttrib* onclick_attrib = NULL;
    
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            onclick_attrib = attrib;
            break;
        }
        attrib = attrib->next;
    }
    
    if (!onclick_attrib) {
        onclick_attrib = html_new_attrib(HTML_ATTRIB_ONCLICK, "onclick", handler);
        if (onclick_attrib) {
            onclick_attrib->next = el->attrib;
            el->attrib = onclick_attrib;
        }
    } else {
        if (onclick_attrib->value) free(onclick_attrib->value);
        onclick_attrib->value = strdup(handler);
    }
    
    if (el->selectedId < 0) {
        el->selectedId = selectId++;
    }
    
    JS_FreeCString(ctx, id);
    JS_FreeCString(ctx, handler);
    return JS_UNDEFINED;
}

static JSValue js_element_onclick_getter(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* id = JS_ToCString(ctx, argv[0]);
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    JS_FreeCString(ctx, id);
    if (!el) {
        return JS_NULL;
    }
    
    // Ищем атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            return JS_NewString(ctx, attrib->value);
        }
        attrib = attrib->next;
    }
    
    return JS_NULL;
}

static JSValue js_getElementById(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* id = JS_ToCString(ctx, argv[0]);
    HtmlElement* el = html_find_element(doc->root_element, id);
    
    if (!el) {
        JS_FreeCString(ctx, id);
        return JS_NULL;
    }
    
    // Создаем объект элемента
    JSValue obj = JS_NewObject(ctx);
    
    // Сохраняем ID элемента
    JS_SetPropertyStr(ctx, obj, "id", JS_NewString(ctx, id));
    
    // Добавляем свойство tagName
    const char* tagName = html_tag_to_string(el->tag);
    JS_SetPropertyStr(ctx, obj, "tagName", JS_NewString(ctx, tagName));
    
    // Создаем объект style
    JS_SetPropertyStr(ctx, obj, "style", JS_NewObject(ctx));
    
    // Добавляем функции get/setProp напрямую
    JS_SetPropertyStr(ctx, obj, "_getProp", JS_NewCFunction(ctx, _duc_helper_get_element_prop_n, "_getProp", 2));
    JS_SetPropertyStr(ctx, obj, "_setProp", JS_NewCFunction(ctx, _duc_helper_set_element_prop_n, "_setProp", 3));
    
    // Добавляем функции для onclick
    JS_SetPropertyStr(ctx, obj, "_getOnClick", JS_NewCFunction(ctx, js_element_onclick_getter, "_getOnClick", 1));
    JS_SetPropertyStr(ctx, obj, "_setOnClick", JS_NewCFunction(ctx, js_element_onclick_setter, "_setOnClick", 2));
    
    // Сохраняем __element_id для геттеров
    JS_SetPropertyStr(ctx, obj, "__element_id", JS_NewString(ctx, id));
    
    // Free id after all uses
    JS_FreeCString(ctx, id);
    
    // Register native getContext for canvas elements
    if (el->tag == HTML_TAG_CANVAS) {
        JS_SetPropertyStr(ctx, obj, "getContext", JS_NewCFunction(ctx, js_canvas_getContext, "getContext", 1));
    }

    // Определяем геттеры и сеттеры через eval
    const char* setup_code =
        "(function(el) {"
        "   var elemId = el.__element_id;"
        "   Object.defineProperty(el, 'innerText', {"
        "       get: function() { return this._getProp(elemId, 4); },"
        "       set: function(value) { this._setProp(elemId, 4, value); }"
        "   });"
        "   Object.defineProperty(el, 'textContent', {"
        "       get: function() { return this._getProp(elemId, 4); },"
        "       set: function(value) { this._setProp(elemId, 4, value); }"
        "   });"
        "   Object.defineProperty(el.style, 'color', {"
        "       get: function() { "
        "           var val = el._getProp(elemId, 1);"
        "           return '#' + val.toString(16).padStart(6, '0'); "
        "       },"
        "       set: function(value) { el._setProp(elemId, 1, value); }"
        "   });"
        "   Object.defineProperty(el.style, 'backgroundColor', {"
        "       get: function() { "
        "           var val = el._getProp(elemId, 2);"
        "           return '#' + val.toString(16).padStart(6, '0'); "
        "       },"
        "       set: function(value) { el._setProp(elemId, 2, value); }"
        "   });"
        "   Object.defineProperty(el.style, 'display', {"
        "       get: function() { return el._getProp(elemId, 3); },"
        "       set: function(value) { el._setProp(elemId, 3, value); }"
        "   });"
        "   Object.defineProperty(el, 'onclick', {"
        "       get: function() { return this._getOnClick(elemId); },"
        "       set: function(value) { this._setOnClick(elemId, value); }"
        "   });"
        "   el.click = function() {"
        "       var handler = this.onclick;"
        "       if (handler && typeof handler === 'function') {"
        "           handler.call(this);"
        "       } else if (handler && typeof handler === 'string') {"
        "           try { eval(handler); } catch(e) { console.error(e); }"
        "       }"
        "   };"
        "   if (el.tagName && el.tagName.toLowerCase() === 'canvas') {"
        "       Object.defineProperty(el, 'width', {"
        "           get: function() { return this._width || 300; },"
        "           set: function(value) { this._width = value; }"
        "       });"
        "       Object.defineProperty(el, 'height', {"
        "           get: function() { return this._height || 150; },"
        "           set: function(value) { this._height = value; }"
        "       });"
        "   }"
        "   return el;"
        "})";
    
    JSValue setup_fn = JS_Eval(ctx, setup_code, strlen(setup_code), "<getElementById>", JS_EVAL_TYPE_GLOBAL);
    if (!JS_IsException(setup_fn)) {
        JSValue args[] = { obj };
        JSValue setup_result = JS_Call(ctx, setup_fn, JS_UNDEFINED, 1, args);
        if (JS_IsException(setup_result)) {
            JSValue exc2 = JS_GetException(ctx);
            JS_FreeValue(ctx, exc2);
        }
        JS_FreeValue(ctx, setup_result);
    } else {
        JSValue exc = JS_GetException(ctx);
        const char* err = JS_ToCString(ctx, exc);
        add_log("JS eval error in getElementById: %s", err);
        JS_FreeCString(ctx, err);
        JS_FreeValue(ctx, exc);
    }
    JS_FreeValue(ctx, setup_fn);
    
    return obj;
}

void qjs_console_init(JSContext *ctx) {
    JSValue console_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, console_obj, "log", JS_NewCFunctionMagic(ctx, console_log_helper, "log", 0, JS_CFUNC_generic_magic, 0));
    JS_SetPropertyStr(ctx, console_obj, "error", JS_NewCFunctionMagic(ctx, console_log_helper, "error", 0, JS_CFUNC_generic_magic, 1));
    JS_SetPropertyStr(ctx, console_obj, "warn", JS_NewCFunctionMagic(ctx, console_log_helper, "warn", 0, JS_CFUNC_generic_magic, 2));
    JS_SetPropertyStr(ctx, console_obj, "info", JS_NewCFunctionMagic(ctx, console_log_helper, "info", 0, JS_CFUNC_generic_magic, 3));
    
    JSValue global = JS_GetGlobalObject(ctx);
    JS_SetPropertyStr(ctx, global, "console", console_obj);
    JS_FreeValue(ctx, global);
}

void qjs_document_init(JSContext *ctx) {
    JSValue doc_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, doc_obj, "write", JS_NewCFunction(ctx, js_document_write, "write", 0));
    JS_SetPropertyStr(ctx, doc_obj, "getElementById", JS_NewCFunction(ctx, js_getElementById, "getElementById", 1));
    JS_SetPropertyStr(ctx, doc_obj, "querySelector", JS_NewCFunction(ctx, js_querySelector, "querySelector", 1));
    JS_SetPropertyStr(ctx, doc_obj, "createElement", JS_NewCFunction(ctx, js_createElement, "createElement", 1));
    JS_SetPropertyStr(ctx, doc_obj, "body", JS_NULL);
    JS_SetPropertyStr(ctx, doc_obj, "title", JS_NewString(ctx, ""));
    
    JSValue global = JS_GetGlobalObject(ctx);
    JS_SetPropertyStr(ctx, global, "document", doc_obj);
    JS_FreeValue(ctx, global);
}

// ===== Browser API: localStorage =====
static JSValue js_storage_getItem(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc < 1 || !JS_IsString(argv[0])) return JS_NULL;
    const char* key = JS_ToCString(ctx, argv[0]);
    if (!key || !storage_path[0]) { if(key) JS_FreeCString(ctx, key); return JS_NULL; }
    
    char value[4096];
    ini_gets("storage", key, "", value, sizeof(value), storage_path);
    JS_FreeCString(ctx, key);
    return JS_NewString(ctx, value);
}

static JSValue js_storage_setItem(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc < 2 || !JS_IsString(argv[0])) return JS_UNDEFINED;
    const char* key = JS_ToCString(ctx, argv[0]);
    const char* value = JS_ToCString(ctx, argv[1]);
    if (key && value && storage_path[0]) {
        ini_puts("storage", key, value, storage_path);
    }
    if (key) JS_FreeCString(ctx, key);
    if (value) JS_FreeCString(ctx, value);
    return JS_UNDEFINED;
}

static JSValue js_storage_removeItem(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc < 1 || !JS_IsString(argv[0])) return JS_UNDEFINED;
    const char* key = JS_ToCString(ctx, argv[0]);
    if (key && storage_path[0]) {
        ini_puts("storage", key, NULL, storage_path);
    }
    if (key) JS_FreeCString(ctx, key);
    return JS_UNDEFINED;
}

static JSValue js_storage_clear(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (storage_path[0]) {
        FILE* f = fopen(storage_path, "w");
        if (f) fclose(f);
    }
    return JS_UNDEFINED;
}

static JSValue js_storage_length(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (!storage_path[0]) return JS_NewInt32(ctx, 0);
    FILE* f = fopen(storage_path, "r");
    if (!f) return JS_NewInt32(ctx, 0);
    
    int count = 0;
    char line[4096];
    int in_storage = 0;
    while (fgets(line, sizeof(line), f)) {
        char* p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (strncmp(p, "[storage]", 9) == 0) { in_storage = 1; continue; }
        if (p[0] == '[') in_storage = 0;
        if (in_storage && p[0] != '\n' && p[0] != ';' && p[0] != '#' && strchr(p, '=')) count++;
    }
    fclose(f);
    return JS_NewInt32(ctx, count);
}

static void qjs_storage_init(JSContext *ctx, const char* name) {
    JSValue storage = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, storage, "getItem", JS_NewCFunction(ctx, js_storage_getItem, "getItem", 1));
    JS_SetPropertyStr(ctx, storage, "setItem", JS_NewCFunction(ctx, js_storage_setItem, "setItem", 2));
    JS_SetPropertyStr(ctx, storage, "removeItem", JS_NewCFunction(ctx, js_storage_removeItem, "removeItem", 1));
    JS_SetPropertyStr(ctx, storage, "clear", JS_NewCFunction(ctx, js_storage_clear, "clear", 0));
    
    const char* len_code = "(function(s){Object.defineProperty(s,'length',{get:function(){return this._len();}});s._len=function(){return 0;};return s;})";
    JSValue len_fn = JS_Eval(ctx, len_code, strlen(len_code), "<storage_len>", JS_EVAL_TYPE_GLOBAL);
    if (!JS_IsException(len_fn)) {
        JS_SetPropertyStr(ctx, storage, "_len", JS_NewCFunction(ctx, js_storage_length, "_len", 0));
        JSValue args[] = { storage };
        JSValue r = JS_Call(ctx, len_fn, JS_UNDEFINED, 1, args);
        JS_FreeValue(ctx, r);
    }
    JS_FreeValue(ctx, len_fn);
    
    JSValue global = JS_GetGlobalObject(ctx);
    JS_SetPropertyStr(ctx, global, name, storage);
    JS_FreeValue(ctx, global);
}

// ===== Browser API: alert / confirm / prompt =====
static JSValue js_alert(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* msg = JS_ToCString(ctx, argv[0]);
    add_log("[ALERT] %s", msg ? msg : "");
    if (msg) JS_FreeCString(ctx, msg);
    return JS_UNDEFINED;
}

static JSValue js_confirm(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* msg = JS_ToCString(ctx, argv[0]);
    add_log("[CONFIRM] %s -> true", msg ? msg : "");
    if (msg) JS_FreeCString(ctx, msg);
    return JS_TRUE;
}

static JSValue js_prompt(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* msg = JS_ToCString(ctx, argv[0]);
    add_log("[PROMPT] %s -> ''", msg ? msg : "");
    if (msg) JS_FreeCString(ctx, msg);
    return JS_NewString(ctx, "");
}

// ===== Browser API: requestAnimationFrame =====
static JSValue js_requestAnimationFrame(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (!JS_IsFunction(ctx, argv[0])) return JS_ThrowTypeError(ctx, "requestAnimationFrame: argument must be a function");
    return js_setTimeout(ctx, this_val, 2, (JSValueConst[]){argv[0], JS_NewInt32(ctx, 16)});
}

// ===== Browser API: atob / btoa =====
static JSValue js_btoa(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* str = JS_ToCString(ctx, argv[0]);
    if (!str) return JS_NULL;
    char* encoded = base64_encode(str);
    JS_FreeCString(ctx, str);
    if (!encoded) return JS_NULL;
    JSValue result = JS_NewString(ctx, encoded);
    free(encoded);
    return result;
}

static JSValue js_atob(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* str = JS_ToCString(ctx, argv[0]);
    if (!str) return JS_NULL;
    int size = 0;
    char* decoded = base64_decode(str, &size);
    JS_FreeCString(ctx, str);
    if (!decoded) return JS_NULL;
    JSValue result = JS_NewStringLen(ctx, decoded, size);
    free(decoded);
    return result;
}

// ===== Browser API: XMLHttpRequest =====
static JSValue js_xhr_constructor(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue xhr = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, xhr, "readyState", JS_NewInt32(ctx, 0));
    JS_SetPropertyStr(ctx, xhr, "status", JS_NewInt32(ctx, 0));
    JS_SetPropertyStr(ctx, xhr, "responseText", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, xhr, "response", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, xhr, "_method", JS_NewString(ctx, "GET"));
    JS_SetPropertyStr(ctx, xhr, "_url", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, xhr, "_async", JS_TRUE);
    JS_SetPropertyStr(ctx, xhr, "_headers", JS_NewObject(ctx));
    return xhr;
}

static JSValue js_xhr_open(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc < 2) return JS_UNDEFINED;
    const char* method = JS_ToCString(ctx, argv[0]);
    const char* url = JS_ToCString(ctx, argv[1]);
    JS_SetPropertyStr(ctx, this_val, "_method", JS_NewString(ctx, method ? method : "GET"));
    JS_SetPropertyStr(ctx, this_val, "_url", JS_NewString(ctx, url ? url : ""));
    JS_SetPropertyStr(ctx, this_val, "readyState", JS_NewInt32(ctx, 1));
    if (method) JS_FreeCString(ctx, method);
    if (url) JS_FreeCString(ctx, url);
    return JS_UNDEFINED;
}

static JSValue js_xhr_send(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue url_val = JS_GetPropertyStr(ctx, this_val, "_url");
    JSValue method_val = JS_GetPropertyStr(ctx, this_val, "_method");
    const char* url = JS_ToCString(ctx, url_val);
    const char* method = JS_ToCString(ctx, method_val);
    JS_FreeValue(ctx, url_val);
    JS_FreeValue(ctx, method_val);
    
    if (!url || !url[0]) {
        if(url) JS_FreeCString(ctx, url);
        if(method) JS_FreeCString(ctx, method);
        return JS_UNDEFINED;
    }
    
    char file_path[1024];
    file_path[0] = '\0';
    
    if (strncmp(url, "file://", 7) == 0) {
        strncpy(file_path, url + 7, sizeof(file_path)-1);
    } else if (url[0] == '/') {
        strncpy(file_path, url, sizeof(file_path)-1);
    } else if (html_base_path[0]) {
        snprintf(file_path, sizeof(file_path), "%s/%s", html_base_path, url);
    }
    
    if (file_path[0]) {
        FILE* f = fopen(file_path, "r");
        if (f) {
            fseek(f, 0, SEEK_END);
            long size = ftell(f);
            fseek(f, 0, SEEK_SET);
            
            char* content = (char*)malloc(size + 1);
            if (content) {
                fread(content, 1, size, f);
                content[size] = '\0';
                
                JS_SetPropertyStr(ctx, this_val, "responseText", JS_NewString(ctx, content));
                JS_SetPropertyStr(ctx, this_val, "response", JS_NewString(ctx, content));
                JS_SetPropertyStr(ctx, this_val, "status", JS_NewInt32(ctx, 200));
                free(content);
            }
            fclose(f);
        } else {
            JS_SetPropertyStr(ctx, this_val, "status", JS_NewInt32(ctx, 404));
            add_log("XHR: file not found: %s", file_path);
        }
    }
    
    if(url) JS_FreeCString(ctx, url);
    if(method) JS_FreeCString(ctx, method);
    
    JS_SetPropertyStr(ctx, this_val, "readyState", JS_NewInt32(ctx, 4));
    
    JSValue onready_val = JS_GetPropertyStr(ctx, this_val, "onreadystatechange");
    if (JS_IsFunction(ctx, onready_val)) {
        JS_Call(ctx, onready_val, this_val, 0, NULL);
    }
    JS_FreeValue(ctx, onready_val);
    
    JSValue status_val = JS_GetPropertyStr(ctx, this_val, "status");
    int status = 0;
    JS_ToInt32(ctx, &status, status_val);
    JS_FreeValue(ctx, status_val);
    
    if (status == 200) {
        JSValue onload_val = JS_GetPropertyStr(ctx, this_val, "onload");
        if (JS_IsFunction(ctx, onload_val)) {
            JS_Call(ctx, onload_val, this_val, 0, NULL);
        }
        JS_FreeValue(ctx, onload_val);
    }
    
    return JS_UNDEFINED;
}

static void qjs_xhr_init(JSContext *ctx) {
    const char* xhr_code = 
        "function XMLHttpRequest(){return _createXHR();}";
    
    JSValue global = JS_GetGlobalObject(ctx);
    
    JS_SetPropertyStr(ctx, global, "_createXHR", JS_NewCFunction(ctx, js_xhr_constructor, "_createXHR", 0));
    
    JSValue xhr_fn = JS_Eval(ctx, xhr_code, strlen(xhr_code), "<xhr>", JS_EVAL_TYPE_GLOBAL);
    if (JS_IsException(xhr_fn)) {
        JSValue exc = JS_GetException(ctx);
        JS_FreeValue(ctx, exc);
    }
    JS_FreeValue(ctx, xhr_fn);
    
    JS_FreeValue(ctx, global);
}

// ===== Browser API: fetch (simplified, sync for file://) =====
static JSValue js_fetch(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc < 1) return JS_NULL;
    
    const char* url = JS_ToCString(ctx, argv[0]);
    if (!url || !url[0]) { if(url) JS_FreeCString(ctx, url); return JS_NULL; }
    
    char file_path[1024];
    file_path[0] = '\0';
    
    if (strncmp(url, "file://", 7) == 0) {
        strncpy(file_path, url + 7, sizeof(file_path)-1);
    } else if (url[0] == '/') {
        strncpy(file_path, url, sizeof(file_path)-1);
    } else if (html_base_path[0]) {
        snprintf(file_path, sizeof(file_path), "%s/%s", html_base_path, url);
    }
    
    JS_FreeCString(ctx, url);
    
    JSValue response = JS_NewObject(ctx);
    
    if (file_path[0]) {
        FILE* f = fopen(file_path, "r");
        if (f) {
            fseek(f, 0, SEEK_END);
            long size = ftell(f);
            fseek(f, 0, SEEK_SET);
            char* content = (char*)malloc(size + 1);
            if (content) {
                fread(content, 1, size, f);
                content[size] = '\0';
                JS_SetPropertyStr(ctx, response, "text", JS_NewString(ctx, content));
                free(content);
            }
            fclose(f);
            JS_SetPropertyStr(ctx, response, "ok", JS_TRUE);
            JS_SetPropertyStr(ctx, response, "status", JS_NewInt32(ctx, 200));
        } else {
            JS_SetPropertyStr(ctx, response, "ok", JS_FALSE);
            JS_SetPropertyStr(ctx, response, "status", JS_NewInt32(ctx, 404));
        }
    } else {
        JS_SetPropertyStr(ctx, response, "ok", JS_FALSE);
        JS_SetPropertyStr(ctx, response, "status", JS_NewInt32(ctx, 0));
    }
    
    return response;
}

// ===== Browser API: Image constructor =====
static JSValue js_image_constructor(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    JSValue img = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, img, "src", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, img, "width", JS_NewInt32(ctx, 0));
    JS_SetPropertyStr(ctx, img, "height", JS_NewInt32(ctx, 0));
    JS_SetPropertyStr(ctx, img, "complete", JS_FALSE);
    JS_SetPropertyStr(ctx, img, "onload", JS_NULL);
    JS_SetPropertyStr(ctx, img, "onerror", JS_NULL);
    return img;
}

// ===== Browser API: document.title =====
static JSValue js_document_title_getter(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return JS_NewString(ctx, document_title);
}

static JSValue js_document_title_setter(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* title = JS_ToCString(ctx, argv[0]);
    if (title) {
        strncpy(document_title, title, 255);
        document_title[255] = '\0';
        JS_FreeCString(ctx, title);
    }
    return JS_UNDEFINED;
}

// ===== Browser API: document.querySelector (by id) =====
static JSValue js_querySelector(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* selector = JS_ToCString(ctx, argv[0]);
    if (!selector) return JS_NULL;
    
    // Simple #id selector
    if (selector[0] == '#') {
        const char* id_str = selector + 1;
        HtmlElement* el = html_find_element(doc->root_element, id_str);
        if (!el) { JS_FreeCString(ctx, selector); return JS_NULL; }
        JSValue id_val = JS_NewString(ctx, id_str);
        JS_FreeCString(ctx, selector);
        return js_getElementById(ctx, this_val, 1, (JSValueConst[]){id_val});
    }
    
    // Simple .class selector (first match)
    if (selector[0] == '.') {
        const char* class_name = selector + 1;
        HtmlElement* el = doc->root_element;
        while (el) {
            HtmlAttrib* a = el->attrib;
            while (a) {
                if (a->key == HTML_ATTRIB_CLASS && strcmp(a->value, class_name) == 0) {
                    const char* id = el->id ? el->id : "";
                    JSValue result = js_getElementById(ctx, this_val, 1, (JSValueConst[]){JS_NewString(ctx, id)});
                    JS_FreeCString(ctx, selector);
                    return result;
                }
                a = a->next;
            }
            el = el->child ? el->child : el->sibling;
        }
    }
    
    JS_FreeCString(ctx, selector);
    return JS_NULL;
}

// ===== Browser API: document.createElement =====
static JSValue js_createElement(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    const char* tag = JS_ToCString(ctx, argv[0]);
    if (!tag) return JS_NULL;
    
    JSValue el = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, el, "tagName", JS_NewString(ctx, tag));
    JS_SetPropertyStr(ctx, el, "id", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, el, "innerHTML", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, el, "innerText", JS_NewString(ctx, ""));
    JS_SetPropertyStr(ctx, el, "style", JS_NewObject(ctx));
    JS_SetPropertyStr(ctx, el, "children", JS_NewObject(ctx));
    JS_SetPropertyStr(ctx, el, "onclick", JS_NULL);
    JS_SetPropertyStr(ctx, el, "className", JS_NewString(ctx, ""));
    
    JS_FreeCString(ctx, tag);
    return el;
}

void qjs_window_init(JSContext *ctx) {
    JSValue global = JS_GetGlobalObject(ctx);
    
    JSValue window_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, window_obj, "setTimeout", JS_NewCFunction(ctx, js_setTimeout, "setTimeout", 2));
    JS_SetPropertyStr(ctx, window_obj, "setInterval", JS_NewCFunction(ctx, js_setInterval, "setInterval", 2));
    JS_SetPropertyStr(ctx, window_obj, "clearTimeout", JS_NewCFunction(ctx, js_clearTimeout, "clearTimeout", 1));
    JS_SetPropertyStr(ctx, window_obj, "clearInterval", JS_NewCFunction(ctx, js_clearInterval, "clearInterval", 1));
    
    // navigator — объект со свойством language, а не функция
    JSValue nav_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, nav_obj, "language", JS_NewString(ctx, language_name));
    JS_SetPropertyStr(ctx, nav_obj, "userLanguage", JS_NewString(ctx, language_name));
    JS_SetPropertyStr(ctx, window_obj, "navigator", nav_obj);
    
    // window.location
    JSValue location_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, location_obj, "href", JS_NewString(ctx, html_file_path));
    JS_SetPropertyStr(ctx, location_obj, "pathname", JS_NewString(ctx, html_file_path));
    JS_SetPropertyStr(ctx, location_obj, "protocol", JS_NewString(ctx, "file:"));
    JS_SetPropertyStr(ctx, window_obj, "location", location_obj);
    
    // window innerWidth / innerHeight
    JS_SetPropertyStr(ctx, window_obj, "innerWidth", JS_NewInt32(ctx, DEVICE_WIDTH));
    JS_SetPropertyStr(ctx, window_obj, "innerHeight", JS_NewInt32(ctx, DEVICE_HEIGHT));
    JS_SetPropertyStr(ctx, window_obj, "outerWidth", JS_NewInt32(ctx, DEVICE_WIDTH));
    JS_SetPropertyStr(ctx, window_obj, "outerHeight", JS_NewInt32(ctx, DEVICE_HEIGHT));
    
    // Also expose as global
    JS_SetPropertyStr(ctx, global, "innerWidth", JS_NewInt32(ctx, DEVICE_WIDTH));
    JS_SetPropertyStr(ctx, global, "innerHeight", JS_NewInt32(ctx, DEVICE_HEIGHT));
    
    // screen object
    JSValue screen_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, screen_obj, "width", JS_NewInt32(ctx, DEVICE_WIDTH));
    JS_SetPropertyStr(ctx, screen_obj, "height", JS_NewInt32(ctx, DEVICE_HEIGHT));
    JS_SetPropertyStr(ctx, screen_obj, "colorDepth", JS_NewInt32(ctx, 16));
    JS_SetPropertyStr(ctx, screen_obj, "pixelDepth", JS_NewInt32(ctx, 16));
    JS_SetPropertyStr(ctx, global, "screen", screen_obj);
    
    // navigator extras
    JS_SetPropertyStr(ctx, nav_obj, "userAgent", JS_NewString(ctx, "MiyooMini/HtmlViewer 1.0"));
    JS_SetPropertyStr(ctx, nav_obj, "platform", JS_NewString(ctx, "MiyooMini"));
    JS_SetPropertyStr(ctx, nav_obj, "vendor", JS_NewString(ctx, "Miyoo"));
    JS_SetPropertyStr(ctx, nav_obj, "appVersion", JS_NewString(ctx, "1.0"));
    JS_SetPropertyStr(ctx, nav_obj, "appCodeName", JS_NewString(ctx, "HtmlViewer"));
    JS_SetPropertyStr(ctx, nav_obj, "appName", JS_NewString(ctx, "HtmlViewer"));
    JS_SetPropertyStr(ctx, nav_obj, "product", JS_NewString(ctx, "HtmlViewer"));
    JS_SetPropertyStr(ctx, nav_obj, "onLine", JS_TRUE);
    
    // window.devicePixelRatio
    JS_SetPropertyStr(ctx, window_obj, "devicePixelRatio", JS_NewFloat64(ctx, 1.0));
    
    // alert / confirm / prompt
    JS_SetPropertyStr(ctx, window_obj, "alert", JS_NewCFunction(ctx, js_alert, "alert", 1));
    JS_SetPropertyStr(ctx, window_obj, "confirm", JS_NewCFunction(ctx, js_confirm, "confirm", 1));
    JS_SetPropertyStr(ctx, window_obj, "prompt", JS_NewCFunction(ctx, js_prompt, "prompt", 1));
    JS_SetPropertyStr(ctx, global, "alert", JS_NewCFunction(ctx, js_alert, "alert", 1));
    JS_SetPropertyStr(ctx, global, "confirm", JS_NewCFunction(ctx, js_confirm, "confirm", 1));
    JS_SetPropertyStr(ctx, global, "prompt", JS_NewCFunction(ctx, js_prompt, "prompt", 1));
    
    // requestAnimationFrame
    JS_SetPropertyStr(ctx, window_obj, "requestAnimationFrame", JS_NewCFunction(ctx, js_requestAnimationFrame, "requestAnimationFrame", 1));
    JS_SetPropertyStr(ctx, window_obj, "cancelAnimationFrame", JS_NewCFunction(ctx, js_clearTimeout, "cancelAnimationFrame", 1));
    JS_SetPropertyStr(ctx, global, "requestAnimationFrame", JS_NewCFunction(ctx, js_requestAnimationFrame, "requestAnimationFrame", 1));
    
    // atob / btoa
    JS_SetPropertyStr(ctx, window_obj, "atob", JS_NewCFunction(ctx, js_atob, "atob", 1));
    JS_SetPropertyStr(ctx, window_obj, "btoa", JS_NewCFunction(ctx, js_btoa, "btoa", 1));
    JS_SetPropertyStr(ctx, global, "atob", JS_NewCFunction(ctx, js_atob, "atob", 1));
    JS_SetPropertyStr(ctx, global, "btoa", JS_NewCFunction(ctx, js_btoa, "btoa", 1));
    
    // fetch
    JS_SetPropertyStr(ctx, window_obj, "fetch", JS_NewCFunction(ctx, js_fetch, "fetch", 1));
    JS_SetPropertyStr(ctx, global, "fetch", JS_NewCFunction(ctx, js_fetch, "fetch", 1));
    
    // Image constructor
    JS_SetPropertyStr(ctx, global, "Image", JS_NewCFunction(ctx, js_image_constructor, "Image", 0));
    
    JS_SetPropertyStr(ctx, global, "window", window_obj);
    
    // Also expose setTimeout/setInterval/clearTimeout/clearInterval globally
    JS_SetPropertyStr(ctx, global, "setTimeout", JS_NewCFunction(ctx, js_setTimeout, "setTimeout", 2));
    JS_SetPropertyStr(ctx, global, "setInterval", JS_NewCFunction(ctx, js_setInterval, "setInterval", 2));
    JS_SetPropertyStr(ctx, global, "clearTimeout", JS_NewCFunction(ctx, js_clearTimeout, "clearTimeout", 1));
    JS_SetPropertyStr(ctx, global, "clearInterval", JS_NewCFunction(ctx, js_clearInterval, "clearInterval", 1));
    
    // Date.now
    JSValue date_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, date_obj, "now", JS_NewCFunction(ctx, js_Date_now, "now", 0));
    JS_SetPropertyStr(ctx, global, "Date", date_obj);
    
    // Math.random
    JSValue math_obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, math_obj, "random", JS_NewCFunction(ctx, js_Math_random, "random", 0));
    JS_SetPropertyStr(ctx, global, "Math", math_obj);
    
    // parseInt, parseFloat
    JS_SetPropertyStr(ctx, global, "parseInt", JS_NewCFunction(ctx, js_parseInt, "parseInt", 2));
    JS_SetPropertyStr(ctx, global, "parseFloat", JS_NewCFunction(ctx, js_parseFloat, "parseFloat", 1));
    
    JS_FreeValue(ctx, global);
    
    srand(SDL_GetTicks());
}

int findHref(char *href){
    if(!href || href[0] != '#') return -1;
    href++;
    for(int i = 0; i < ahref_name_array_count; i++){
        if(!strcmp(href, ahref_name_array[i].name))
            return ahref_name_array[i].y;
    }
    return -1;
}

SDL_Surface* img_src_parse(const char *src){
    if (!src || !src[0]) {
        return NULL;
    }

    // Check image cache first
    SDL_Surface* cached = find_in_image_cache(src);
    if (cached) return cached;

    // 1. Check if it's a data: URL (base64)
    if (strncmp(src, "data:image/", 12) == 0) {
        // PNG base64
        char pngBase64head[] = "data:image/png;base64,";
        if(!strncmp(pngBase64head, src, strlen(pngBase64head))){
            int size = 0;
            char* img_src = base64_decode(src + strlen(pngBase64head), &size);
            if(!img_src) return NULL;

            SDL_RWops* rw = SDL_RWFromMem(img_src, size);
            if(!rw){ free(img_src); return NULL; }

            SDL_Surface* out_img = IMG_Load_RW(rw, 0);
            free(img_src);
            SDL_RWclose(rw);
            if(out_img) add_to_image_cache(src, out_img);
            return out_img;
        }

        // JPEG/GIF/BMP base64
        char jpgBase64head[] = "data:image/jpeg;base64,";
        char jpegBase64head[] = "data:image/jpg;base64,";
        char gifBase64head[] = "data:image/gif;base64,";
        char bmpBase64head[] = "data:image/bmp;base64,";

        const char* format = NULL;
        int offset = 0;

        if(!strncmp(jpgBase64head, src, strlen(jpgBase64head))){
            format = "JPEG"; offset = strlen(jpgBase64head);
        } else if(!strncmp(jpegBase64head, src, strlen(jpegBase64head))){
            format = "JPEG"; offset = strlen(jpegBase64head);
        } else if(!strncmp(gifBase64head, src, strlen(gifBase64head))){
            format = "GIF"; offset = strlen(gifBase64head);
        } else if(!strncmp(bmpBase64head, src, strlen(bmpBase64head))){
            format = "BMP"; offset = strlen(bmpBase64head);
        }

        if(format && offset > 0){
            int size = 0;
            char* img_src = base64_decode(src + offset, &size);
            if(img_src){
                SDL_RWops* rw = SDL_RWFromMem(img_src, size);
                SDL_Surface* out_img = IMG_Load_RW(rw, 0);
                free(img_src);
                SDL_RWclose(rw);
                if(out_img) add_to_image_cache(src, out_img);
                return out_img;
            }
        }

        return NULL;
    }

    // 2. File system paths
    char resolved_path[1024];
    resolved_path[0] = '\0';
    const char* file_path = NULL;

    if (strncmp(src, "file://", 7) == 0) {
        file_path = src + 7;
    } else if (src[0] == '/') {
        file_path = src;
    } else {
        // Relative path - resolve against base path
        if (html_base_path[0]) {
            snprintf(resolved_path, sizeof(resolved_path), "%s/%s", html_base_path, src);
            file_path = resolved_path;
        } else {
            file_path = src;
        }
    }

    if (file_path) {
        add_log("Loading image: %s", file_path);
        SDL_Surface* img = IMG_Load(file_path);
        if (img) {
            add_log("Image loaded: %dx%d", img->w, img->h);
            add_to_image_cache(src, img);
            return img;
        } else {
            add_log("IMG_Load failed: %s", file_path);
        }
    }

    return NULL;
}

SDL_Color UintToColor(int color){
    return (SDL_Color){ (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, 255 };
}

void init_text_cache() {
    for (int i = 0; i < TEXT_CACHE_SIZE; i++) {
        text_cache[i].text[0] = '\0';
        text_cache[i].surface = NULL;
        text_cache[i].bg_surface = NULL;
    }
    text_cache_count = text_cache_hits = text_cache_misses = 0;
}

void clear_text_cache() {
    for (int i = 0; i < text_cache_count; i++) {
        if (text_cache[i].surface) SDL_FreeSurface(text_cache[i].surface);
        if (text_cache[i].bg_surface) SDL_FreeSurface(text_cache[i].bg_surface);
    }
    text_cache_count = 0;
}

SDL_Surface* find_in_image_cache(const char* src) {
    ImageCacheEntry* entry = image_cache;
    while (entry) {
        if (entry->src && strcmp(entry->src, src) == 0) {
            return entry->surface;
        }
        entry = entry->next;
    }
    return NULL;
}

void add_to_image_cache(const char* src, SDL_Surface* surface) {
    if (image_cache_count > 10) {
        ImageCacheEntry* entry = image_cache;
        if (entry) {
            image_cache = entry->next;
            if (entry->src) free(entry->src);
            if (entry->surface) SDL_FreeSurface(entry->surface);
            free(entry);
            image_cache_count--;
        }
    }
    
    ImageCacheEntry* new_entry = (ImageCacheEntry*)malloc(sizeof(ImageCacheEntry));
    if (new_entry) {
        new_entry->src = strdup(src);
        new_entry->surface = surface;
        new_entry->width = surface ? surface->w : 0;
        new_entry->height = surface ? surface->h : 0;
        new_entry->next = image_cache;
        image_cache = new_entry;
        image_cache_count++;
    }
}

SDL_Surface* find_in_text_cache(const char* text, int fontsize, int color, int bg_color) {
    for (int i = 0; i < text_cache_count; i++) {
        if (text_cache[i].fontsize == fontsize &&
            text_cache[i].color == color &&
            text_cache[i].bg_color == bg_color &&
            strcmp(text_cache[i].text, text) == 0) {
            text_cache_hits++;
            return text_cache[i].surface;
        }
    }
    text_cache_misses++;
    return NULL;
}

void add_to_text_cache(const char* text, int fontsize, int color, int bg_color, 
                      SDL_Surface* surface) {
    if (text_cache_count >= TEXT_CACHE_SIZE) {
        int remove = 64;
        if (remove > TEXT_CACHE_SIZE) remove = TEXT_CACHE_SIZE / 4;
        for (int i = 0; i < remove; i++) {
            if (text_cache[i].surface) SDL_FreeSurface(text_cache[i].surface);
            if (text_cache[i].bg_surface) SDL_FreeSurface(text_cache[i].bg_surface);
        }
        for (int i = remove; i < TEXT_CACHE_SIZE; i++) {
            text_cache[i - remove] = text_cache[i];
        }
        text_cache_count -= remove;
    }
    
    strncpy(text_cache[text_cache_count].text, text, 255);
    text_cache[text_cache_count].text[255] = '\0';
    text_cache[text_cache_count].fontsize = fontsize;
    text_cache[text_cache_count].color = color;
    text_cache[text_cache_count].bg_color = bg_color;
    text_cache[text_cache_count].surface = surface;
    text_cache[text_cache_count].bg_surface = NULL;
    text_cache_count++;
}

void clear_image_cache() {
    ImageCacheEntry* entry = image_cache;
    while (entry) {
        ImageCacheEntry* next = entry->next;
        if (entry->src) free(entry->src);
        if (entry->surface) SDL_FreeSurface(entry->surface);
        free(entry);
        entry = next;
    }
    image_cache = NULL;
    image_cache_count = 0;
}

SDL_Surface* render_text_cached(const char* text, TTF_Font* font, int fontsize_idx, 
                               int text_color, int bg_color) {
    SDL_Surface* surface = find_in_text_cache(text, fontsize_idx, text_color, bg_color);
    if (surface) return surface;
    
    SDL_Color sdl_color = UintToColor(text_color);
    surface = TTF_RenderUTF8_Blended(font, text, sdl_color);
    if (surface) add_to_text_cache(text, fontsize_idx, text_color, bg_color, surface);
    return surface;
}

int draw_x;
int line_height = 14;

void draw_border(HtmlElement* element, int draw_y, int element_height) {
    const char* border_color_str = get_style_value(element, "border-color");
    const char* border_width_str = get_style_value(element, "border-width");
    const char* border_style_str = get_style_value(element, "border-style");
    
    if (border_color_str && border_width_str) {
        int border_color = parse_css_color(border_color_str);
        int border_width = parse_css_length(border_width_str);
        int border_style = border_style_str ? (strcmp(border_style_str, "solid") == 0 ? 1 : 0) : 1;
        
        if (border_width > 0 && border_style) {
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y,
                element->w ? element->w : DEVICE_WIDTH - element->x,
                border_width
            }, border_color);
            
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y + element_height - border_width,
                element->w ? element->w : DEVICE_WIDTH - element->x,
                border_width
            }, border_color);
            
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y,
                border_width,
                element_height
            }, border_color);
            
            if (element->w) {
                SDL_FillRect(screen, &(SDL_Rect){
                    element->x + element->w - border_width,
                    draw_y - global_y,
                    border_width,
                    element_height
                }, border_color);
            }
        }
    }
}
 
int html_math_dom_element(HtmlElement *parent, HtmlElement *element, int first_run, unsigned int draw_y) {
    if (!element) return draw_y;
    while (element) {
        HtmlElement *sibling = element->sibling;

        // Обработка SCRIPT и STYLE только при first_run
        if (first_run) {
            if (element->tag == HTML_TAG_SCRIPT && element->child && element->child->text) {
                add_log("SCRIPT tag found, child=%p, text=%s",
                    (void*)element->child,
                    element->child ? element->child->text : "(null)");

                char* normalized_js = normalize_js_string(element->child->text);
                if (normalized_js) {
                    qjs_peval_string_logged(js_ctx, normalized_js);
                    free(normalized_js);
                } else {
                    qjs_peval_string_logged(js_ctx, element->child->text);
                }
                add_log("Executed JavaScript from <script>");
                element->display = NONE; // Скрываем из отрисовки
                // НЕ вызываем continue — просто пропускаем остальную обработку
            } else if (element->tag == HTML_TAG_STYLE && element->child && element->child->text) {
                parse_css_from_style_tag(element->child->text);
                add_log("parse CSS from <style>");
                element->display = NONE;
            }
        }

        // Обрабатываем только видимые элементы (display != NONE)
        if (element->display != NONE) {
            if (first_run) {
                element->fontsize = parent->fontsize;
                element->textcolor = parent->textcolor;
                element->color = parent->color;
                apply_css_styles(element);
            }

            const char* margin_top = get_style_value(element, "margin-top");
            if (margin_top) {
                draw_y += parse_css_length(margin_top);
            }
            const char* margin_left = get_style_value(element, "margin-left");
            if (margin_left) {
                element->x = parent->x + parse_css_length(margin_left);
            } else {
                element->x = parent->x;
            }
            element->y = draw_y;
            element->h = 0;
            element->display = parent->display;

            switch (element->tag) {
                case HTML_TAG_NONE:
                    element->display = INLINE;
                    break;
                case HTML_TAG_HEAD:
                case HTML_TAG_SCRIPT:
                    element->display = NONE;
                    break;
                case HTML_TAG_STYLE:
                    element->display = NONE;
                    break;
                case HTML_TAG_BR:
                    draw_y += line_height;
                    break;
                case HTML_TAG_DIV:
                    element->display = BLOCK;
                    break;
                case HTML_TAG_UL:
                    element->x += 20;
                    break;
                case HTML_TAG_H1:
                    element->fontsize = 4; draw_y += 10; element->h += line_height; break;
                case HTML_TAG_H2:
                    element->fontsize = 3; draw_y += 8; element->h += 10; break;
                case HTML_TAG_H3:
                    element->fontsize = 2; draw_y += 6; element->h += 6; break;
                case HTML_TAG_H4:
                    element->fontsize = 1; draw_y += 2; element->h += 2; break;
                case HTML_TAG_TABLE:
                    element->display = BLOCK;
                    if (current_table) {
                        free_table_context(current_table);
                    }
                    current_table = create_table_context();
                    if (current_table) {
                        current_table->table_x = element->x;
                        current_table->table_y = draw_y;
                    }
                    break;
                case HTML_TAG_TR:
                    element->display = BLOCK;
                    if (current_table) {
                        current_table->current_row++;
                        current_table->current_col = 0;
                        current_table->current_row_element = element;
                    }
                    break;
                case HTML_TAG_TD:
                case HTML_TAG_TH:
                    element->display = INLINE;
                    if (current_table) {
                        current_table->current_col++;
                        int col_width = 100;
                        if (element->child && element->child->text) {
                            int w, h;
                            TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &w, &h);
                            col_width = w + 10;
                        }
                        if (current_table->current_col > current_table->col_count) {
                            table_add_column(current_table, col_width);
                        } else {
                            TableColumn* col = current_table->columns;
                            int i = 0;
                            while (col && i < current_table->current_col - 1) {
                                col = col->next;
                                i++;
                            }
                            if (col && col_width > col->width) {
                                col->width = col_width;
                            }
                        }
                    }
                    break;
                case HTML_TAG_CANVAS: {
                    element->display = INLINE;
                    HtmlAttrib *attrib = element->attrib;
                    int width = 300, height = 150;
                    while (attrib) {
                        if (strcmp(attrib->key_name, "width") == 0) {
                            width = atoi(attrib->value);
                            element->w = width;
                        } else if (strcmp(attrib->key_name, "height") == 0) {
                            height = atoi(attrib->value);
                            element->h = height;
                        }
                        attrib = attrib->next;
                    }
                    if (element->w == 0) element->w = width;
                    if (element->h == 0) element->h = height;
                    if (first_run) {
                        CanvasContext* canvas_ctx = create_canvas_context(element->w, element->h);
                        if (canvas_ctx) {
                            HtmlAttrib* ctx_attrib = html_new_attrib(HTML_ATTRIB_CUSTOM, "__canvas_ctx", NULL);
                            if (ctx_attrib) {
                                ctx_attrib->user_data = canvas_ctx; // предполагается, что в HtmlAttrib есть поле user_data
                                ctx_attrib->next = element->attrib;
                                element->attrib = ctx_attrib;
                            }
                        }
                    }
                    draw_y += element->h + 4;
                    break;
                }
                case HTML_TAG_IMG: {
                    element->display = INLINE;
                    HtmlAttrib *attrib = element->attrib;
                    while (attrib) {
                        if (attrib->key == HTML_ATTRIB_SRC) {
                            SDL_Surface* imc = find_in_image_cache(attrib->value);
                            if (!imc) {
                                imc = img_src_parse(attrib->value);
                                if (imc) {
                                    add_to_image_cache(attrib->value, imc);
                                    element->h = imc->h;
                                    element->w = imc->w;
                                } else {
                                    element->h = 20;
                                    element->w = 20;
                                }
                            } else {
                                element->h = imc->h;
                                element->w = imc->w;
                            }
                        }
                        attrib = attrib->next;
                    }
                    break;
                }
                case HTML_TAG_BUTTON: {
                    element->display = INLINE;
                    element->textcolor = 0xFFFFFF;
                    element->color = 0x808080;
                    if (element->child && element->child->text) {
                        int text_w, text_h;
                        TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &text_w, &text_h);
                        element->h = text_h + 10;
                        element->w = text_w + 20;
                    } else {
                        element->h = 30;
                        element->w = 100;
                    }
                    HtmlAttrib *attrib = element->attrib;
                    while (attrib) {
                        if (attrib->key == HTML_ATTRIB_ONCLICK) {
                            element->selectedId = selectId++;
                        }
                        attrib = attrib->next;
                    }
                    draw_y += element->h + 4;
                    break;
                }
                case HTML_TAG_A:
                    element->textcolor = 0x0000EE;
                    element->display = INLINE;
                    {
                        HtmlAttrib *attrib = element->attrib;
                        while (attrib) {
                            if (attrib->key == HTML_ATTRIB_NAME) {
                                ahref_name_array[ahref_name_array_count].name = attrib->value;
                                ahref_name_array[ahref_name_array_count++].y = element->y;
                            } else if (attrib->key == HTML_ATTRIB_HREF) {
                                element->selectedId = selectId++;
                            }
                            attrib = attrib->next;
                        }
                    }
                    break;
                default:
                    break;
            }

            // Обработка атрибутов
            {
                HtmlAttrib *attrib = element->attrib;
                while (attrib) {
                    if (strcmp(attrib->key_name, "color") == 0) {
                        element->textcolor = hex2int(attrib->value);
                        if (!element->textcolor) element->textcolor = 1;
                    } else if (strcmp(attrib->key_name, "bgcolor") == 0) {
                        element->color = hex2int(attrib->value);
                    } else if (strcmp(attrib->key_name, "style") == 0) {
                        char* style_copy = strdup(attrib->value);
                        char* token = strtok(style_copy, ";");
                        while (token) {
                            char* prop = token;
                            char* value = strchr(token, ':');
                            if (value) {
                                *value = '\0';
                                value++;
                                while (*prop == ' ') prop++;
                                if (value[0] && value[strlen(value)-1] == ' ')
                                    value[strlen(value)-1] = '\0';
                                HtmlAttrib* style_attrib = html_new_attrib(HTML_ATTRIB_STYLE, prop, value);
                                if (style_attrib) {
                                    style_attrib->next = element->attrib;
                                    element->attrib = style_attrib;
                                }
                            }
                            token = strtok(NULL, ";");
                        }
                        free(style_copy);
                    } else if (attrib->key == HTML_ATTRIB_ID) {
                        element->id = attrib->value;
                    }
                    attrib = attrib->next;
                }
            }

            // Установка позиций inline/block
            if (element->display == INLINE) {
                element->x = draw_x;
            } else {
                draw_x = element->x;
            }

            // Расчёт высоты текста
            if (element->text && element->tag == HTML_TAG_NONE) {
                int i = 0, charw, charh;
                char char_buffer[5];
                int current_line_height = line_height;
                int temp_draw_x = element->x;
                int temp_draw_y = draw_y;
                while (element->text[i]) {
                    int len = 0;
                    if ((element->text[i] & 0xF0) == 0xF0) len = 4;
                    else if ((element->text[i] & 0xE0) == 0xE0) len = 3;
                    else if ((element->text[i] & 0xC0) == 0xC0) len = 2;
                    else if (element->text[i] >= 0x20) len = 1;
                    if (len) {
                        strncpy(char_buffer, &element->text[i], len);
                        char_buffer[len] = '\0';
                        TTF_SizeUTF8(fonts[element->fontsize], char_buffer, &charw, &charh);
                        if (charh > current_line_height) current_line_height = charh;
                        if (temp_draw_x + charw >= DEVICE_WIDTH - 30) {
                            temp_draw_x = element->x;
                            temp_draw_y += current_line_height + 4;
                            current_line_height = charh;
                        }
                        temp_draw_x += charw;
                        i += len;
                    } else i++;
                }
                draw_y = temp_draw_y + current_line_height;
            } else if (element->tag == HTML_TAG_IMG) {
                draw_y += (element->h > 0) ? element->h + 4 : 24;
            } else if (element->tag == HTML_TAG_CANVAS) {
                draw_y += element->h + 4;
            }

            // Рекурсивная обработка детей
            int child_draw_y = html_math_dom_element(element, element->child, first_run, draw_y);
            element->h = child_draw_y - element->y;
            draw_y = child_draw_y;
        }

        // Обработка нижнего отступа
        if (element->display == BLOCK) {
            const char* margin_bottom = get_style_value(element, "margin-bottom");
            if (margin_bottom) {
                draw_y += parse_css_length(margin_bottom);
            } else {
                draw_y += line_height;
            }
            draw_x = element->x;
        }

        element = sibling;
    }
    return draw_y;
}

int html_draw_dom_element(HtmlElement *parent, HtmlElement *element, unsigned int start_draw_y) {
    if(!element) return start_draw_y;
    unsigned int draw_y = start_draw_y;
    
    while(element) {
        HtmlElement *sibling = element->sibling;
        
        if(element->y > (global_y + 272)) return draw_y;
        
        if(element->y + element->h > global_y && element->display != 0){
            draw_y = element->y;
            int bg_color = parent->color;
            int text_color = parent->textcolor;
            int original_draw_y = draw_y;
            int cell_height = 20;
            
            int padding_top = 0;
            const char* padding_top_str = get_style_value(element, "padding-top");
            if (padding_top_str) {
                padding_top = parse_css_length(padding_top_str);
            }
            
            int padding_left = 0;
            const char* padding_left_str = get_style_value(element, "padding-left");
            if (padding_left_str) {
                padding_left = parse_css_length(padding_left_str);
            }
            
            switch(element->tag){
                case HTML_TAG_LI:
                    {
                        SDL_Surface* surface = render_text_cached("*", fonts[0], 0, text_color, bg_color);
                        if(surface) SDL_BlitSurface(surface, NULL, screen, &(SDL_Rect){element->x - 10, draw_y - global_y});
                    }
                    break;
                case HTML_TAG_CANVAS: {
                                CanvasContext* canvas_ctx = get_canvas_context_from_element(element);
                                
                                if (canvas_ctx && canvas_ctx->surface) {
                                        // Выполняем операции если нужно перерисовать
                                        if (canvas_ctx->needs_redraw) {
                                        canvas_execute_operations_sdl(canvas_ctx);
                                        canvas_ctx->needs_redraw = 0;
                                        }
                                        
                                        SDL_Rect dest = {element->x, element->y - global_y, element->w, element->h};
                                        SDL_BlitSurface(canvas_ctx->surface, NULL, screen, &dest);
                                        
                                        // Рисуем рамку если указана
                                        const char* border_style = get_style_value(element, "border-style");
                                        if (border_style && strcmp(border_style, "solid") == 0) {
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y-1, 
                                                                        element->w+2, 1}, 0x000000);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y-1, 
                                                                        1, element->h+2}, 0x000000);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x+element->w, element->y - global_y-1, 
                                                                        1, element->h+2}, 0x000000);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y+element->h, 
                                                                        element->w+2, 1}, 0x000000);
                                        }
                                } else {
                                        // Рисуем серый фон для canvas (если нет контекста)
                                        SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y, 
                                                                element->w, element->h}, 0xF0F0F0);
                                        // Рисуем текст "Canvas"
                                        TTF_Font* font = fonts[2];
                                        SDL_Color color = {100, 100, 100, 255};
                                        SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, "Canvas", color);
                                        if (text_surface) {
                                        SDL_Rect dest = {
                                                element->x + (element->w - text_surface->w)/2,
                                                element->y - global_y + (element->h - text_surface->h)/2,
                                                text_surface->w,
                                                text_surface->h
                                        };
                                        SDL_BlitSurface(text_surface, NULL, screen, &dest);
                                        SDL_FreeSurface(text_surface);
                                        }
                                }
                                draw_y += element->h + 4;
                                break;
                                }
                case HTML_TAG_IMG: {
                    HtmlAttrib *attrib = element->attrib;
                    while(attrib){
                        if (attrib->key == HTML_ATTRIB_SRC) {
                            SDL_Surface* imc = find_in_image_cache(attrib->value);
                            if(imc){
                                SDL_BlitSurface(imc, NULL, screen, &(SDL_Rect){element->x, draw_y - global_y});
                                draw_y += imc->h + 4;
                            } else {
                                SDL_Rect rect = {element->x, draw_y - global_y, 20, 20};
                                SDL_FillRect(screen, &rect, 0x888888);
                                SDL_FillRect(screen, &(SDL_Rect){element->x+2, draw_y - global_y+2, 16, 16}, 0xCCCCCC);
                                draw_y += 24;
                            }
                        }
                        attrib = attrib->next;
                    }
                    break;
                }
                                case HTML_TAG_BUTTON:
                                if(element->selectedId >= 0){
                                        if(startViewSelectedId < 0) startViewSelectedId = element->selectedId;
                                        endViewSelectedId = element->selectedId;
                                        if(element->selectedId == selectElement) drawCursor = 1;
                                }
                                
                                {
                                        HtmlAttrib *attrib = element->attrib;
                                        while(attrib){
                                        if(attrib->key == HTML_ATTRIB_ONCLICK && element->selectedId == selectElement)
                                                selectedOnClick = attrib->value;
                                        attrib = attrib->next;
                                        }
                                }
                                
                                // Используем сохраненные размеры кнопки из html_math_dom_element
                                int button_width = element->w ? element->w : 100;
                                int button_height = element->h ? element->h : 30;
                                
                                // Если текст изменился, пересчитываем размеры
                                if (element->child && element->child->text) {
                                        int text_w, text_h;
                                        TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &text_w, &text_h);
                                        
                                        // Если размеры не были установлены или текст изменился
                                        if (element->w == 0 || element->h == 0) {
                                        button_width = text_w + 20;
                                        button_height = text_h + 10;
                                        element->w = button_width;
                                        element->h = button_height;
                                        }
                                }
                                
                                // Получаем скругление углов
                                int borderRadius = 0;
                                const char* borderRadiusStr = get_style_value(element, "border-radius");
                                if (borderRadiusStr) {
                                        borderRadius = parse_css_length(borderRadiusStr);
                                }
                                
                                // Проверяем границы экрана
                                if (element->x + button_width > DEVICE_WIDTH) {
                                        button_width = DEVICE_WIDTH - element->x - 5;
                                }
                                
                                // Рисуем фон кнопки
                                SDL_Rect buttonRect = {
                                        element->x,
                                        element->y - global_y,
                                        button_width,
                                        button_height
                                };
                                
                                // Простая реализация - прямоугольник без скругления
                                SDL_FillRect(screen, &buttonRect, element->color);
                                
                                // Рисуем тень/обводку для эффекта кнопки
                                if (drawCursor) {
                                        // Подсветка выбранной кнопки - более толстая рамка
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y-2, 
                                                                        button_width+4, 3}, 0x0000FF);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y+button_height-1, 
                                                                        button_width+4, 3}, 0x0000FF);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y, 
                                                                        3, button_height}, 0x0000FF);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x+button_width-1, element->y - global_y, 
                                                                        3, button_height}, 0x0000FF);
                                } else {
                                        // 3D эффект для кнопки - темнее снизу и справа, светлее сверху и слева
                                        // Нижняя тень
                                        SDL_FillRect(screen, &(SDL_Rect){element->x+1, element->y - global_y+button_height-2, 
                                                                        button_width-2, 2}, 0x404040);
                                        // Правая тень
                                        SDL_FillRect(screen, &(SDL_Rect){element->x+button_width-2, element->y - global_y+1, 
                                                                        2, button_height-2}, 0x404040);
                                        // Верхний свет
                                        SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y, 
                                                                        button_width, 1}, 0xFFFFFF);
                                        SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y+1, 
                                                                        1, button_height-2}, 0xFFFFFF);
                                }
                                
                                // Рисуем текст кнопки по центру
                                if (element->child && element->child->text) {
                                        SDL_Surface* textSurface = render_text_cached(element->child->text, fonts[element->fontsize],
                                                                                element->fontsize, element->textcolor, element->color);
                                        if (textSurface) {
                                        int text_x = element->x + (button_width - textSurface->w) / 2;
                                        int text_y = element->y - global_y + (button_height - textSurface->h) / 2;
                                        SDL_BlitSurface(textSurface, NULL, screen, &(SDL_Rect){text_x, text_y});
                                        }
                                }
                                
                                // Не увеличиваем draw_y здесь - это уже сделано в html_math_dom_element
                                break;
                case HTML_TAG_A:
                    if(element->selectedId >= 0){
                        if(startViewSelectedId < 0) startViewSelectedId = element->selectedId;
                        endViewSelectedId = element->selectedId;
                        if(element->selectedId == selectElement) drawCursor = 1;
                    }
                    {
                        HtmlAttrib *attrib = element->attrib;
                        while(attrib){
                            if(attrib->key == HTML_ATTRIB_HREF && element->selectedId == selectElement)
                                selectedHref = attrib->value;
                            else if(attrib->key == HTML_ATTRIB_ONCLICK && element->selectedId == selectElement)
                                selectedOnClick = attrib->value;
                            attrib = attrib->next;
                        }
                    }
                    break;
                case HTML_TAG_TABLE:
                    if (current_table) {
                        current_table->table_x = element->x;
                        current_table->table_y = draw_y;
                    }
                    break;
                case HTML_TAG_TR:
                    if (current_table) {
                        draw_x = current_table->table_x;
                    } else {
                        draw_x = element->x;
                    }
                    cell_height = 20;
                    break;
                case HTML_TAG_TD:
                case HTML_TAG_TH:
                    if (current_table) {
                        int col_index = 0;
                        HtmlElement* cell = current_table->current_row_element;
                        if (cell) {
                            HtmlElement* temp_cell = cell->child;
                            while (temp_cell && temp_cell != element) {
                                col_index++;
                                temp_cell = temp_cell->sibling;
                            }
                            
                            int col_width = get_table_column_width(current_table, col_index);
                            
                            int content_height = line_height;
                            if (element->child && element->child->text) {
                                int w, h;
                                TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &w, &h);
                                int text_lines = 1;
                                if (w > col_width - 10) {
                                    text_lines = (w / (col_width - 10)) + 1;
                                }
                                content_height = text_lines * line_height;
                            }
                            if (content_height > cell_height) {
                                cell_height = content_height;
                            }
                            
                            int cell_padding_left = 5;
                            int cell_padding_top = 2;
                            
                            SDL_Rect cell_rect = {
                                draw_x,
                                draw_y - global_y,
                                col_width,
                                cell_height
                            };
                            
                            int cell_bg_color = (element->tag == HTML_TAG_TH) ? 0xDDDDDD : 0xFFFFFF;
                            if (element->color != 0) cell_bg_color = element->color;
                            else if (bg_color != 0xFFFFFF) cell_bg_color = bg_color;
                            
                            SDL_FillRect(screen, &cell_rect, cell_bg_color);
                            
                            draw_border(element, draw_y, cell_height);
                            
                            element->x = draw_x + cell_padding_left + padding_left;
                            element->y = draw_y + cell_padding_top + padding_top;
                            draw_x += col_width;
                            
                            if (element->tag == HTML_TAG_TH) {
                                element->fontsize = (element->fontsize < 4) ? element->fontsize + 1 : 4;
                            }
                        }
                    }
                    break;
                default:
                    if (element->h > 0) {
                        draw_border(element, draw_y, element->h);
                    }
                    break;
            }
            
            if(element->text && element->tag == HTML_TAG_NONE && parent->tag != HTML_TAG_BUTTON){
                int i = 0, local_draw_x = element->x + padding_left;
                int local_draw_y = draw_y + padding_top;
                char char_buffer[5];
                int current_line_height = line_height;
                
                if(drawCursor){
                    bg_color = 0x2585;
                    text_color = 0xffff;
                }
                
                while(element->text[i]){
                    int len = 0;
                    if ((element->text[i] & 0xF0) == 0xF0) len = 4;
                    else if ((element->text[i] & 0xE0) == 0xE0) len = 3;
                    else if ((element->text[i] & 0xC0) == 0xC0) len = 2;
                    else if(element->text[i] >= 0x20) len = 1;
                    
                    if(len){
                        strncpy(char_buffer, &element->text[i], len);
                        char_buffer[len] = '\0';
                        
                        SDL_Surface* surface = render_text_cached(char_buffer, fonts[element->fontsize], 
                                                                 element->fontsize, text_color, bg_color);
                        if(surface){
                            int charw = surface->w;
                            int charh = surface->h;
                            
                            if (charh > current_line_height) {
                                current_line_height = charh;
                            }
                            
                            if (current_table && (element->tag == HTML_TAG_TD || element->tag == HTML_TAG_TH)) {
                                int col_index = 0;
                                HtmlElement* temp_cell = current_table->current_row_element;
                                if (temp_cell) {
                                    HtmlElement* cell = temp_cell->child;
                                    while (cell && cell != element) {
                                        col_index++;
                                        cell = cell->sibling;
                                    }
                                    int col_width = get_table_column_width(current_table, col_index);
                                    
                                    if (local_draw_x + charw - element->x > col_width - 10) {
                                        local_draw_x = element->x;
                                        local_draw_y += current_line_height + 2;
                                        if (local_draw_y - draw_y + current_line_height > cell_height) {
                                            cell_height = local_draw_y - draw_y + current_line_height;
                                        }
                                    }
                                }
                            } else {
                                if(local_draw_x + charw >= DEVICE_WIDTH - 30){
                                    local_draw_x = element->x;
                                    local_draw_y += current_line_height + 4;
                                }
                            }
                            
                            if(bg_color != 0xFFFFFF){
                                SDL_FillRect(screen, &(SDL_Rect){local_draw_x, local_draw_y - global_y - 1,
                                                               charw + 1, charh + 3}, bg_color);
                            }
                            SDL_BlitSurface(surface, NULL, screen, &(SDL_Rect){local_draw_x, local_draw_y - global_y});
                            local_draw_x += charw;
                        }
                        i += len;
                    } else i++;
                }
                
                if (current_table && (element->tag == HTML_TAG_TD || element->tag == HTML_TAG_TH)) {
                    if (original_draw_y == draw_y) {
                        draw_y += cell_height + 2;
                    }
                } else {
                    if (original_draw_y == draw_y) {
                        draw_y = local_draw_y + current_line_height + 2;
                    }
                }
            }
            
            else if(element->tag == HTML_TAG_BUTTON || element->tag == HTML_TAG_IMG || element->tag == HTML_TAG_CANVAS) {
                        // Для кнопок, изображений и canvas проверяем, помещаются ли они в строку
                        if(draw_x + element->w >= DEVICE_WIDTH - 30){
                                draw_x = element->x;
                                draw_y += element->h + 4;
                        }
                        draw_x += element->w + 4;
                        }
            
            if(element->tag != HTML_TAG_SCRIPT && element->tag != HTML_TAG_STYLE){
                if (current_table && element->tag == HTML_TAG_TR) {
                    if (current_table->current_row > 0) {
                        table_add_row(current_table, element->child, cell_height);
                    }
                }
                if (element->tag != HTML_TAG_SCRIPT && element->tag != HTML_TAG_STYLE) {
                                html_draw_dom_element(element, element->child, draw_y);
                                }
            }
            drawCursor = 0;
        }
        element = sibling;
    }
    return draw_y;
}

void *html_math_dom(HtmlDocument *document, int first_run) {
    remath_dom = 0;
    draw_x = 0;
    ahref_name_array_count = 0;
    selectId = 0;
    selectedOnClick = NULL;
    
    if (current_table) {
        free_table_context(current_table);
        current_table = NULL;
    }
    
    if (first_run) {
        HtmlElement* elem = document->root_element;
        while (elem) {
            apply_css_styles(elem);
            HtmlElement* child = elem->child;
            while (child) {
                apply_css_styles(child);
                child = child->sibling;
            }
            elem = elem->sibling;
        }
    }
    
    max_global_y = html_math_dom_element(document->root_element, document->root_element, first_run, 1);
    SDL_Log("document height %dpx", max_global_y);
    return NULL;
}

int main(int argc, char **argv) {
    PWR_setCPUSpeed(CPU_SPEED_MENU);
    screen = GFX_init(MODE_MAIN);
    language_init(-1);
    InitSettings();
    PAD_init();
    PWR_init();
    
    fonts[0] = font.tiny;
    fonts[1] = font.tiny;
    fonts[2] = font.small;
    fonts[3] = font.medium;
    fonts[4] = font.large;
    for (int i = 0; i < MAX_LOG_LINES; i++) {
        log_lines[i] = NULL;
        }
    
    FILE *f = fopen(argc > 1 ? argv[1] : "index.html", "r");
    
    // Store HTML file path and base path
    const char* html_path = argc > 1 ? argv[1] : "index.html";
    strncpy(html_file_path, html_path, 511);
    html_file_path[511] = '\0';
    
    // Extract directory from file path
    strncpy(html_base_path, html_path, 511);
    html_base_path[511] = '\0';
    char* last_slash = strrchr(html_base_path, '/');
    if (last_slash) {
        *last_slash = '\0';
    } else {
        html_base_path[0] = '.';
        html_base_path[1] = '\0';
    }
    
    // Setup localStorage path
    snprintf(storage_path, sizeof(storage_path), "%s/.htmlviewer_storage.ini", html_base_path);
    
    char buffer[BUFFSIZE + 1] = {0};
    HtmlParseState *parse_state = html_parse_begin();
    
    if(f){
        while(!feof(f)) {
            size_t len = fread(buffer, 1, BUFFSIZE, f);
            html_parse_stream(parse_state, buffer, buffer, len);
        }
        fclose(f);
    }
    doc = html_parse_end(parse_state);
    add_log("ROOT = %p", (void*)doc->root_element);
        if (doc->root_element) {
        add_log("ROOT tag = %d", (int)doc->root_element->tag);
        }
    
    initLang();
    init_text_cache();
    
    js_rt = JS_NewRuntime();
    JS_SetMaxStackSize(js_rt, 0);  // Отключаем проверку размера C-стека (ложные срабатывания на ARM)
    js_ctx = JS_NewContext(js_rt);
    
    JSValue global = JS_GetGlobalObject(js_ctx);
    JS_SetPropertyStr(js_ctx, global, "print", JS_NewCFunction(js_ctx, native_print, "print", 0));
    JS_FreeValue(js_ctx, global);
    qjs_console_init(js_ctx);
    qjs_document_init(js_ctx);
    qjs_window_init(js_ctx);
    
    // Init localStorage and sessionStorage
    qjs_storage_init(js_ctx, "localStorage");
    qjs_storage_init(js_ctx, "sessionStorage");
    
    // Init XMLHttpRequest
    qjs_xhr_init(js_ctx);
    
    // Init document title - extract from <title> tag
    {
        HtmlElement* head = doc->root_element;
        while (head) {
            if (head->tag == HTML_TAG_HEAD) break;
            head = head->child ? head->child : head->sibling;
        }
        if (head && head->child) {
            HtmlElement* child = head->child;
            while (child) {
                if (child->tag == HTML_TAG_TITLE && child->child && child->child->text) {
                    strncpy(document_title, child->child->text, 255);
                    document_title[255] = '\0';
                    break;
                }
                child = child->sibling;
            }
        }
    }
    
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
    html_math_dom(doc, 1);
    html_draw_dom_element(doc->root_element, doc->root_element, global_y);
    GFX_flip(screen);
    
    int quit = 0;
    last_ticks = SDL_GetTicks();
    
    while(!quit){ 
        PAD_poll();
        
        process_timers();
        
        static Uint32 last_gc = 0;
        Uint32 now = SDL_GetTicks();
        if (now - last_gc > 5000) {  // Каждые 5 секунд
                JS_RunGC(js_rt);
                last_gc = now;
        }
        
        if (PAD_isPressed(BTN_X)) {  // Предположим, что BTN_X есть в системе
                show_logs = (show_logs + 1) % 3;  // Циклически переключаем режимы: 0->1->2->0
                dirty = 1;
                SDL_Delay(200);
                }
                
                // В режиме полноэкранных логов (show_logs == 2) обработаем дополнительные кнопки:
                if (show_logs == 2) {
                if (PAD_isPressed(getButtonB())) {
                        show_logs = 0;
                        dirty = 1;
                        SDL_Delay(200);
                }
                if (PAD_isPressed(getButtonA())) {
                        clear_logs();
                        dirty = 1;
                        SDL_Delay(200);
                }
                }
        
        if (PAD_isPressed(BTN_UP)) {
            if(selectElement - 1 >= startViewSelectedId && selectElement > 0){
                selectElement--;
                if(selectElement > endViewSelectedId) selectElement = endViewSelectedId;
                dirty = 1;
                SDL_Delay(200);
            }
            else if(global_y > 0){
                global_y -= 4;
                dirty = 1;
            }
        }
        else if (PAD_isPressed(BTN_DOWN)) {
            if(selectElement + 1 <= endViewSelectedId){
                selectElement++;
                if(selectElement < startViewSelectedId) selectElement = startViewSelectedId;
                dirty = 1;
                SDL_Delay(200);
            }
            else if(global_y < max_global_y - 240){
                global_y += 4;
                dirty = 1;
            }
        }
        if (PAD_isPressed(getButtonB())) quit = 1;
            
        if (PAD_isPressed(getButtonA())){
            if(endViewSelectedId >= 0 && startViewSelectedId >=0 && 
               selectElement >= startViewSelectedId && selectElement <= endViewSelectedId){
                if(selectedOnClick) {
                    JSValue result = JS_Eval(js_ctx, selectedOnClick, strlen(selectedOnClick), "<onclick>", JS_EVAL_TYPE_GLOBAL);
                    if (JS_IsException(result)) {
                        JSValue exc = JS_GetException(js_ctx);
                        JS_FreeValue(js_ctx, exc);
                    }
                    JS_FreeValue(js_ctx, result);
                }
                int new_y = findHref(selectedHref);
                if(new_y > -1){
                    global_y = new_y;
                    selectElement = -1;
                    dirty = 1;
                }
            }
        }
        
        if(remath_dom){
            html_math_dom(doc, 0);
            dirty = 1;
            clear_text_cache();
        }
        
        if (dirty) {
            dirty = 0;
            SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
            startViewSelectedId = endViewSelectedId = -1;
            html_draw_dom_element(doc->root_element, doc->root_element, global_y);
            
            SDL_FillRect(screen, &(SDL_Rect){476, 0, 4, 273}, 0xAD76);
            if(max_global_y > 272){
                int thumb_height = 136 / ((max_global_y / 272 > 0) ? max_global_y / 272 : 1);
                SDL_FillRect(screen, &(SDL_Rect){476, 272 * global_y / max_global_y, 4, thumb_height}, 0x1111);
            }
            
            if (show_logs != 2) {  // Если не полноэкранный режим логов
                        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
                        startViewSelectedId = endViewSelectedId = -1;
                        html_draw_dom_element(doc->root_element, doc->root_element, global_y);
                        
                        // Отрисовка скроллбара
                        SDL_FillRect(screen, &(SDL_Rect){476, 0, 4, 273}, 0xAD76);
                        if(max_global_y > 272){
                        int thumb_height = 136 / ((max_global_y / 272 > 0) ? max_global_y / 272 : 1);
                        SDL_FillRect(screen, &(SDL_Rect){476, 272 * global_y / max_global_y, 
                                                        4, thumb_height}, 0x1111);
                        }
                }
                
                // Отрисовываем логи (в любом режиме)
                draw_logs();
            
            GFX_flip(screen);
        } else GFX_sync();
        
        SDL_Delay(10);
    }
    
    while (timers) {
        Timer* next = timers->next;
        JS_FreeValue(js_ctx, timers->callback);
        free(timers);
        timers = next;
        }
    
    for (int i = 0; i < canvas_context_count; i++) {
        if (canvas_contexts[i]) {
            free_canvas_context(canvas_contexts[i]);
        }
    }
    
    HtmlElement* find_and_free_canvas(HtmlElement* element) {
        while (element) {
                if (element->tag == HTML_TAG_CANVAS) {
                HtmlAttrib* attrib = element->attrib;
                while (attrib) {
                        if (strcmp(attrib->key_name, "__canvas_ctx") == 0) {
                        CanvasContext* canvas_ctx = (CanvasContext*)attrib->value;
                        free_canvas_context(canvas_ctx);
                        break;
                        }
                        attrib = attrib->next;
                }
                }
                find_and_free_canvas(element->child);
                element = element->sibling;
        }
        return NULL;
        }
        
        for (int i = 0; i < log_line_count; i++) {
        free(log_lines[i]);
        }
        if (log_background) {
        SDL_FreeSurface(log_background);
        }
        find_and_free_canvas(doc->root_element);
    
    clear_text_cache();
    clear_image_cache();
    html_free_document(doc);
    free_css_styles();
    if (current_table) {
        free_table_context(current_table);
    }
    JS_FreeContext(js_ctx);
    JS_FreeRuntime(js_rt);
    
    QuitSettings();
    PWR_quit();
    PAD_quit();
    GFX_quit((SDL_Color){255, 255, 255});
    
    return 0;
}
