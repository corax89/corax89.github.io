/*
 * html - a simple html parser lacking a better name 
 * The contents of this file is licensed under the MIT License,
 * see the file COPYING or http://opensource.org/licenses/MIT
 */

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "util.h"

char* normalize_js_string(const char* input) {
    if (!input) return NULL;
    size_t len = strlen(input);
    char* out = (char*)malloc(len + 1);
    if (!out) return NULL;
    for (size_t i = 0; i < len; i++) {
        if (input[i] == '\r') {
            out[i] = '\n';
        } else {
            out[i] = input[i];
        }
    }
    out[len] = '\0';
    return out;
}

int stringcompare(const char *s1, const char *s2, size_t length) {
	int diff, i;
	for(i = 0; ; i++) {
		if(i >= length) {
			if(!s2[i])
				return 0;
			return -1;
		}
		diff = tolower(s1[i]) - tolower(s2[i]);
		if(diff)
			return diff;
		if(!s1[i]) {
			if(!s2[i])
				return 0;
			else
				return -1;
		}
		if(!s2[i]) {
			if(!s1[i])
				return 0;
			else
				return 1;
		}
	}
}

char *stringduplicate_length(const char *string, size_t len) {
	char *ret;
	size_t i, j;
	char space = 0;
	
	if(!(string && len))
		return NULL;
	if(!(ret = malloc(len + 1)))
		return NULL;
	for(i = 0, j = 0; j < len; i++) {
		if(isspace(string[i])) {
			if(space)
				continue;
			space = 1;
		} else
			space = 0;
		ret[j++] = string[i];
	}
	ret[len] = 0;
	return ret;
}

const char *stringtrim_l(const char *string) {
	if(!string)
		return NULL;
	while(*string && isspace(*string))
		string++;
	
	return string;
}
