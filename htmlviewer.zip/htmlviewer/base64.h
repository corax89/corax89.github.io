    /***********************************************************
    * Base64 library                                           *
    * @author Ahmed Elzoughby                                  *
    * @date July 23, 2017                                      *
    * Purpose: encode and decode base64 format                 *
    ***********************************************************/

#ifndef BASE64_H
#define BASE64_H

#ifdef __cplusplus
extern "C" {
#endif

char* base64_encode(const char* plain);
char* base64_decode(const char* cipher, int *size);

#ifdef __cplusplus
}
#endif

#endif /* BASE64_H */
