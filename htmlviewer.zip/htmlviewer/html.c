/*
 * html - a simple html parser lacking a better name 
 * The contents of this file is licensed under the MIT License,
 * see the file COPYING or http://opensource.org/licenses/MIT
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>

/* Explicitly expose internal structures */
#define HTML_PARSE_STATE_TYPE struct HtmlParseState

#include "stack.h"
#include "attrib.h"
#include "html.h"
#include "util.h"

#define CASE_SPACE case ' ': case '\r': case '\n': case '\t'

enum State {
    STATE_CHILD,
    STATE_OPEN,
    STATE_DECLARATION,
    STATE_BEGIN,
    STATE_END,
    STATE_ATTRIB,
    STATE_ATTRIB_KEY,
    STATE_ATTRIB_VALUE,
    STATE_ATTRIB_QUOTEVALUE_A,
    STATE_ATTRIB_QUOTEVALUE_B,
    STATE_CLOSE,
    STATE_SELFCLOSE,
    STATE_END_CLOSE,
    STATE_ENTITY,
    
    /*This is silly*/
    STATE_COMMENT_BEGIN,
    STATE_COMMENT,
    STATE_COMMENT_END1,
    STATE_COMMENT_END2,
    
    /* Special state for script/style content */
    STATE_SCRIPT_TEXT,
    
    STATES,
};

struct HtmlParseState {
    HtmlDocument *document;
    Stack *stack;
    HtmlElement *elem;
    HtmlTag tag;
    char *tag_name;
    
    HtmlAttrib *attrib;
    HtmlAttribKey attrib_key;
    char *attrib_key_name;
    
    enum State state;
    
    /* Used for stripping out spaces */
    size_t stringlen;
    char space;
    
    /* For tracking script/style tags */
    HtmlTag current_script_style_tag;
};

static int findtag(void *elem, void *tag) {
    if(((HtmlElement *) elem)->tag == *((int *) tag))
        return 1;
    return 0;
}

const char* html_tag_to_string(HtmlTag tag) {
    switch (tag) {
        case HTML_TAG_NONE:       return "";
        case HTML_TAG_UNKNOWN:    return "";
        case HTML_TAG_COMMENT:    return "!--";
        case HTML_TAG_DOCTYPE:    return "!doctype";

        case HTML_TAG_A:          return "a";
        case HTML_TAG_ABBR:       return "abbr";
        case HTML_TAG_ACRONYM:    return "acronym";
        case HTML_TAG_ADDRESS:    return "address";
        case HTML_TAG_APPLET:     return "applet";
        case HTML_TAG_AREA:       return "area";

        case HTML_TAG_B:          return "b";
        case HTML_TAG_BASE:       return "base";
        case HTML_TAG_BASEFONT:   return "basefont";
        case HTML_TAG_BDO:        return "bdo";
        case HTML_TAG_BIG:        return "big";
        case HTML_TAG_BLOCKQUOTE: return "blockquote";
        case HTML_TAG_BODY:       return "body";
        case HTML_TAG_BR:         return "br";
        case HTML_TAG_BUTTON:     return "button";

        case HTML_TAG_CANVAS:     return "canvas";
        case HTML_TAG_CAPTION:    return "caption";
        case HTML_TAG_CENTER:     return "center";
        case HTML_TAG_CITE:       return "cite";
        case HTML_TAG_CODE:       return "code";
        case HTML_TAG_COL:        return "col";
        case HTML_TAG_COLGROUP:   return "colgroup";
        case HTML_TAG_DD:         return "dd";
        case HTML_TAG_DEL:        return "del";

        case HTML_TAG_DFN:        return "dfn";
        case HTML_TAG_DIR:        return "dir";
        case HTML_TAG_DIV:        return "div";
        case HTML_TAG_DL:         return "dl";
        case HTML_TAG_DT:         return "dt";

        case HTML_TAG_EM:         return "em";
        case HTML_TAG_FIELDSET:   return "fieldset";
        case HTML_TAG_FONT:       return "font";
        case HTML_TAG_FORM:       return "form";
        case HTML_TAG_FRAME:      return "frame";
        case HTML_TAG_FRAMESET:   return "frameset";

        case HTML_TAG_H1:         return "h1";
        case HTML_TAG_H2:         return "h2";
        case HTML_TAG_H3:         return "h3";
        case HTML_TAG_H4:         return "h4";
        case HTML_TAG_H5:         return "h5";
        case HTML_TAG_H6:         return "h6";
        case HTML_TAG_HEAD:       return "head";
        case HTML_TAG_HR:         return "hr";
        case HTML_TAG_HTML:       return "html";

        case HTML_TAG_I:          return "i";
        case HTML_TAG_IFRAME:     return "iframe";
        case HTML_TAG_IMG:        return "img";
        case HTML_TAG_INPUT:      return "input";
        case HTML_TAG_INS:        return "ins";

        case HTML_TAG_KBD:        return "kbd";

        case HTML_TAG_LABEL:      return "label";
        case HTML_TAG_LEGEND:     return "legend";
        case HTML_TAG_LI:         return "li";
        case HTML_TAG_LINK:       return "link";

        case HTML_TAG_MAP:        return "map";
        case HTML_TAG_MENU:       return "menu";
        case HTML_TAG_META:       return "meta";

        case HTML_TAG_NOFRAMES:   return "noframes";
        case HTML_TAG_NOSCRIPT:   return "noscript";

        case HTML_TAG_OBJECT:     return "object";
        case HTML_TAG_OL:         return "ol";
        case HTML_TAG_OPTGROUP:   return "optgroup";
        case HTML_TAG_OPTION:     return "option";

        case HTML_TAG_P:          return "p";
        case HTML_TAG_PARAM:      return "param";
        case HTML_TAG_PRE:        return "pre";

        case HTML_TAG_Q:          return "q";

        case HTML_TAG_S:          return "s";
        case HTML_TAG_SAMP:       return "samp";
        case HTML_TAG_SCRIPT:     return "script";
        case HTML_TAG_SELECT:     return "select";
        case HTML_TAG_SMALL:      return "small";
        case HTML_TAG_SPAN:       return "span";
        case HTML_TAG_STRIKE:     return "strike";
        case HTML_TAG_STRONG:     return "strong";
        case HTML_TAG_STYLE:      return "style";
        case HTML_TAG_SUB:        return "sub";
        case HTML_TAG_SUP:        return "sup";

        case HTML_TAG_TABLE:      return "table";
        case HTML_TAG_TBODY:      return "tbody";
        case HTML_TAG_TD:         return "td";
        case HTML_TAG_TEXTAREA:   return "textarea";
        case HTML_TAG_TFOOT:      return "tfoot";
        case HTML_TAG_TH:         return "th";
        case HTML_TAG_THEAD:      return "thead";
        case HTML_TAG_TITLE:      return "title";
        case HTML_TAG_TR:         return "tr";
        case HTML_TAG_TT:         return "tt";

        case HTML_TAG_U:          return "u";
        case HTML_TAG_UL:         return "ul";

        case HTML_TAG_VAR:        return "var";

        default:                  return "unknown";
    }
}

int html_tag_is_script(HtmlTag tag) {
    switch(tag) {
        case HTML_TAG_SCRIPT:
        case HTML_TAG_STYLE:
            return 1;
        default:
            return 0;
    }
}

int html_tag_is_selfclose(HtmlTag tag) {
    switch(tag) {
        case HTML_TAG_BASE:
        case HTML_TAG_BASEFONT:
        case HTML_TAG_FRAME:
        case HTML_TAG_LINK:
        case HTML_TAG_META:
        case HTML_TAG_AREA:
        case HTML_TAG_BR:
        case HTML_TAG_COL:
        case HTML_TAG_CANVAS:
        case HTML_TAG_HR:
        case HTML_TAG_IMG:
        case HTML_TAG_INPUT:
        case HTML_TAG_PARAM:
            return 1;
        default:
            return 0;
    }
}

HtmlAttribKey html_lookup_length_attrib_key(const char *string, size_t length) {
    int i, imin = 0, imax = HTML_ATTRIB_KEYS, res;
    
    while(imax >= imin) {
        i = (imax - imin)/2 + imin;
        if (i==HTML_ATTRIB_KEYS)
            break;
        res = stringcompare(string, html_attrib[i], length);
        if(res < 0)
            imax = i - 1;
        else if(res > 0)
            imin = i + 1;
        else
            return i;
    }
    return HTML_ATTRIB_UNKNOWN;
}

HtmlTag html_lookup_length_tag(const char *string, size_t length) {
    //TODO: optimize string compare for binary tree search (no "restarts")
    int i, imin = 0, imax = HTML_TAGS, res;

    while(imax >= imin) {
        i = (imax - imin)/2 + imin;
        if (i==HTML_TAGS)
            break;
        res = stringcompare(string, html_tag[i], length);
        if(res < 0)
            imax = i - 1;
        else if(res > 0)
            imin = i + 1;
        else
            return i;
    }

    return HTML_TAG_UNKNOWN;
}

HtmlTag html_lookup_tag(const char *string) {
    int i, imin = 0, imax = HTML_TAGS, res;
    
    while(imax >= imin) {
        i = (imax - imin)/2 + imin;
        if (i==HTML_TAGS)
            break;
        res = stringcompare(string, html_tag[i], ~0);
        if(res < 0)
            imax = i - 1;
        else if(res > 0)
            imin = i + 1;
        else
            return i;
    }
    return HTML_TAG_UNKNOWN;
}

HtmlAttrib *html_new_element_attrib(enum HtmlAttribKey key, char *key_name, const char* value, size_t length) {
    HtmlAttrib *attrib;
    if(!(attrib = malloc(sizeof(HtmlAttrib))))
        return NULL;
    
    attrib->key = key;
    attrib->key_name = key_name;
    if (length > 0) {
        attrib->value = malloc(length + 1);
        if (!attrib->value) {
            free(attrib);
            return NULL;
        }
        memcpy(attrib->value, value, length);
        attrib->value[length] = '\0';
    } else {
        attrib->value = NULL;
    }
    attrib->next = NULL;
    
    return attrib;
}

HtmlElement *html_new_element(HtmlTag tag, char *tag_name, HtmlAttrib *attrib, HtmlElement *child, HtmlElement *sibling, char *text) {
    HtmlElement *elem = malloc(sizeof(HtmlElement));
    if (!elem) return NULL;

    elem->x = 0;
    elem->y = 0;
    elem->w = 0;
    elem->h = 0;
    elem->display = 2;
    elem->color = 0xffffff;
    elem->textcolor = 0x010101;
    elem->fontsize = 1;
    elem->selectedId = -1;
    elem->id = NULL;
    elem->text = text;
    elem->tag = tag;
    elem->tag_name = tag_name;
    elem->attrib = attrib;
    
    // 🔥 КРИТИЧЕСКИ ВАЖНО: не доверяйте входным child/sibling для текстовых узлов
    if (tag == HTML_TAG_NONE) {
        elem->child = NULL;      // ← текст не может иметь детей
        elem->sibling = NULL;    // ← sibling устанавливается позже, но не здесь
    } else {
        elem->child = child;
        elem->sibling = sibling;
    }

    return elem;
}

HtmlParseState *html_parse_begin() {
    HtmlParseState *state;
    if(!(state = malloc(sizeof(HtmlParseState))))
        return NULL;
    
    state->document = NULL;
    state->stack = NULL;
    state->elem = NULL;
    state->tag = 0;
    state->attrib_key = 0;
    state->state = STATE_CHILD;
    state->stringlen = 0;
    state->space = 0;
    state->current_script_style_tag = HTML_TAG_UNKNOWN;
    state->attrib = NULL;
    
    if(!(state->document = malloc(sizeof(HtmlDocument))))
        goto error;
    if(!(state->elem = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, NULL)))
        goto error;
    if(!stack_push(&state->stack, state->elem))
        goto error;
    
    state->document->root_element = state->elem;
    state->elem = NULL;
    
    return state;
    
    error:
    free(state->document);
    free(state->elem);
    while(stack_pop(&state->stack));
    free(state);
    
    return NULL;
}

/* Helper function to check if we're at a closing tag */
static int is_closing_tag(const char *stream, size_t remaining, HtmlTag expected_tag) {
    if(remaining < 2) {
        return 0;
    }
    
    if(stream[0] != '/') {
        return 0;
    }
    
    const char *tag_name;
    size_t tag_len;
    
    if(expected_tag == HTML_TAG_SCRIPT) {
        tag_name = "script";
        tag_len = 6;
    } else if(expected_tag == HTML_TAG_STYLE) {
        tag_name = "style";
        tag_len = 5;
    } else {
        return 0;
    }
    
    /* Check we have enough characters */
    if(remaining < tag_len + 2) {
        return 0;
    }
    
    /* Case-insensitive comparison for tag name */
    for(size_t j = 0; j < tag_len; j++) {
        char expected = tag_name[j];
        char actual = tolower(stream[j + 1]);
        if(actual != expected) {
            return 0;
        }
    }
    
    size_t pos = tag_len + 1;
    
    /* Skip whitespace after tag name */
    while(pos < remaining && 
          (stream[pos] == ' ' || stream[pos] == '\t' || 
           stream[pos] == '\n' || stream[pos] == '\r')) {
        pos++;
    }
    
    /* Check for closing '>' */
    if(pos < remaining && stream[pos] == '>') {
        return pos + 1;
    }
    
    return 0;
}

const char *html_parse_stream(HtmlParseState *state, const char *stream, const char *token, size_t len) {
    #define ADVANCE_TOKEN token = stream; \
        state->stringlen = 0; \
        state->space = 0
    
    char c;
    char *text;
    
    HtmlElement *elem_tmp;
    HtmlAttrib *attrib_tmp;

    
    if(!(state && stream && len))
        return NULL;
    
    const char* end = stream + len;
	while (stream < end) {
    	c = *stream++;
        reswitch:
        switch(state->state) {
            case STATE_CHILD:
    			switch(c) {
        			case '<':
            			/* Add containing text */
            			if(state->stringlen) {
                			if(state->stringlen > 1 || !isspace(*token)) {
                    			text = malloc(state->stringlen + 1);
                    			if (!text) goto error;
                    			memcpy(text, token, state->stringlen);
                    			text[state->stringlen] = '\0';
                    			
                    			if(!(elem_tmp = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, text)))
                        			goto error;
                    			if(state->elem) {
                        			state->elem->sibling = elem_tmp;
                        			state->elem = elem_tmp;
                    			} else {
                        			state->elem = stack_peek(&state->stack);
                        			state->elem->child = elem_tmp;
                        			state->elem = elem_tmp;
                    			}
                			}
            			}
            			ADVANCE_TOKEN;
            			state->state = STATE_OPEN;
            			continue;
        			CASE_SPACE:
            			if(!state->space) {
                			state->space = 1;
                			state->stringlen++;
            			}
            			continue;
        			default:
            			state->space = 0;
            			state->stringlen++;
            			continue;
    			}
            case STATE_SCRIPT_TEXT:{
    			switch(c) {
        			case '<': {
            			size_t current_stringlen = state->stringlen;  // ← Теперь в блоке!
			
            			/* Check if this is a closing tag for the current script/style */
            			if(state->current_script_style_tag != HTML_TAG_UNKNOWN) {
                			size_t remaining = end - stream;
			
                			if(remaining > 0 && stream[0] == '/') {
                    			int closing_len = is_closing_tag(stream, remaining, state->current_script_style_tag);
			
                    			if(closing_len > 0) {
                        			if(current_stringlen > 0) {
                            			text = malloc(current_stringlen + 1);
                            			if (!text) goto error;
                            			memcpy(text, token, current_stringlen);
                            			text[current_stringlen] = '\0';
			
                            			if(!(elem_tmp = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, text)))
                                			goto error;
                            			if(state->elem) {
                                			state->elem->sibling = elem_tmp;
                                			state->elem = elem_tmp;
                            			} else {
                                			state->elem = stack_peek(&state->stack);
                                			state->elem->child = elem_tmp;
                                			state->elem = elem_tmp;
                            			}
                        			}
			
                        			stream += closing_len;
			
                        			token = stream;
                        			state->stringlen = 0;
                        			state->space = 0;
			
                        			if(stack_find(&state->stack, findtag, &state->current_script_style_tag)) {
                            			do {
                                			elem_tmp = stack_pop(&state->stack);
                            			} while(elem_tmp && elem_tmp->tag != state->current_script_style_tag);
			
                            			if(elem_tmp) {
                                			state->elem = elem_tmp;
                            			}
                        			}
			
                        			state->current_script_style_tag = HTML_TAG_UNKNOWN;
                        			state->state = STATE_CHILD;
                        			continue;
                    			}
                			}
            			}
			
            			state->space = 0;
            			state->stringlen++;
            			continue;
        			}
			
        			default:
            			state->space = 0;
            			state->stringlen++;
            			continue;
    			}
    			break;
    		}
            case STATE_OPEN:
                switch(c) {
                    CASE_SPACE:
                        ADVANCE_TOKEN;
                        continue;
                    
                    /*Comments, doctypes, xml-stuff and other crap we don't care about*/
                    case '!':
                        ADVANCE_TOKEN;
                        state->state = STATE_DECLARATION;
                        continue;
                    case '?':
                        state->state = STATE_BEGIN;
                        continue;
                    
                    case '/':
                        ADVANCE_TOKEN;
                        state->state = STATE_END;
                        continue;
                    default:
                        state->state = STATE_BEGIN;
                        continue;
                }
            case STATE_DECLARATION:
                ADVANCE_TOKEN;
                switch(c) {
                    case '-':
                        state->state = STATE_COMMENT_BEGIN;
                        continue;
                    default:
                        state->state = STATE_END_CLOSE;
                        continue;
                }
            case STATE_COMMENT_BEGIN:
                ADVANCE_TOKEN;
                state->state = STATE_COMMENT;
                continue;
            case STATE_COMMENT:
            case STATE_COMMENT_END1:
                ADVANCE_TOKEN;
                switch(c) {
                    case '-':
                        state->state++;
                        continue;
                    default:
                        state->state = STATE_COMMENT;
                        continue;
                }
            case STATE_COMMENT_END2:
                ADVANCE_TOKEN;
                switch(c) {
                    case '>':
                        state->state = STATE_CHILD;
                        continue;
                    default:
                        state->state = STATE_COMMENT;
                        continue;
                }
            case STATE_BEGIN:
                switch(c) {
                    CASE_SPACE:
                        state->tag = html_lookup_length_tag(token, (stream - 1) - token);
                        state->tag_name = stringduplicate_length(token, (stream - 1) - token);
                        state->state = STATE_ATTRIB;
                        ADVANCE_TOKEN;
                        continue;
                    case '>':
                        state->tag = html_lookup_length_tag(token, (stream - 1) - token);
                        state->tag_name = stringduplicate_length(token, (stream - 1) - token);
                        state->state = STATE_CLOSE;
                        ADVANCE_TOKEN;
                        goto reswitch;
                    case '/':
                        state->tag = html_lookup_length_tag(token, (stream - 1) - token);
                        state->tag_name = stringduplicate_length(token, (stream - 1) - token);
                        state->state = STATE_SELFCLOSE;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_ATTRIB:
                switch(c) {
                    CASE_SPACE:
                        ADVANCE_TOKEN;
                        continue;
                    case '/':
                        state->state = STATE_SELFCLOSE;
                        ADVANCE_TOKEN;
                        continue;
                    case '?':
                        ADVANCE_TOKEN;
                    case '>':
                        state->state = STATE_CLOSE;
                        ADVANCE_TOKEN;
                        goto reswitch;
                    default:
                        state->state = STATE_ATTRIB_KEY;
                        continue;
                }
            case STATE_ATTRIB_KEY:
                switch(c) {
                    CASE_SPACE:
                        state->attrib_key = html_lookup_length_attrib_key(token, (stream - 1) - token);
                        state->attrib_key_name = stringduplicate_length(token, (stream - 1) - token);
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, NULL, 0);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_ATTRIB;
                        ADVANCE_TOKEN;
                        continue;
                    case '>':
                        state->attrib_key = html_lookup_length_attrib_key(token, (stream - 1) - token);
                        state->attrib_key_name = stringduplicate_length(token, (stream - 1) - token);
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, NULL, 0);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_CLOSE;
                        ADVANCE_TOKEN;
                        goto reswitch;
                    case '/':
                        state->attrib_key = html_lookup_length_attrib_key(token, (stream - 1) - token);
                        state->attrib_key_name = stringduplicate_length(token, (stream - 1) - token);
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, NULL, 0);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_SELFCLOSE;
                        ADVANCE_TOKEN;
                        continue;
                    case '=':
                        state->attrib_key = html_lookup_length_attrib_key(token, (stream - 1) - token);
                        state->attrib_key_name = stringduplicate_length(token, (stream - 1) - token);
                        state->state = STATE_ATTRIB_VALUE;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_ATTRIB_QUOTEVALUE_A:
                switch(c) {
                    case '\'':
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, token, (stream - 1) - token);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_ATTRIB;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_ATTRIB_QUOTEVALUE_B:
                switch(c) {
                    case '"':
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, token, (stream - 1) - token);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_ATTRIB;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_ATTRIB_VALUE:
                switch(c) {
                    CASE_SPACE:
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, token, (stream - 1) - token);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_ATTRIB;
                        ADVANCE_TOKEN;
                        continue;
                    case '>':
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, token, (stream - 1) - token);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_CLOSE;
                        ADVANCE_TOKEN;
                        goto reswitch;
                    case '"':
                        state->state = STATE_ATTRIB_QUOTEVALUE_B;
                        ADVANCE_TOKEN;
                        continue;
                    case '\'':
                        state->state = STATE_ATTRIB_QUOTEVALUE_A;
                        ADVANCE_TOKEN;
                        continue;
                    case '/':
                        attrib_tmp = html_new_element_attrib(state->attrib_key, state->attrib_key_name, token, (stream - 1) - token);
                        attrib_append(&state->attrib, attrib_tmp);
                        attrib_tmp = NULL;
                        
                        state->state = STATE_SELFCLOSE;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_CLOSE:
                switch(c) {
                    case '>':
                        ADVANCE_TOKEN;
                        
                        // Check if this is a script/style tag
                        if(html_tag_is_script(state->tag)) {
                            state->current_script_style_tag = state->tag;
                        }
                        
                        // Add element to DOM
                        if(!(elem_tmp = html_new_element(state->tag, state->tag_name, state->attrib, NULL, NULL, NULL)))
                            goto error;
                        if(state->elem) {
                            state->elem->sibling = elem_tmp;
                            state->elem = elem_tmp;
                        } else {
                            state->elem = stack_peek(&state->stack);
                            state->elem->child = elem_tmp;
                            state->elem = elem_tmp;
                        }
                        
                        if(!html_tag_is_selfclose(state->tag)) {
                            stack_push(&state->stack, state->elem);
                            state->elem = NULL;
                        }
                        
                        // Set next state based on tag type
                        if(html_tag_is_script(state->tag)) {
                            state->state = STATE_SCRIPT_TEXT;
                        } else {
                            state->state = STATE_CHILD;
                        }
                        
                        state->tag = 0;
                        state->tag_name = 0;
                        state->attrib = 0;
                        state->attrib_key_name = 0;
                        
                        continue;
                    default:
                        ADVANCE_TOKEN;
                        continue;
                }
            case STATE_SELFCLOSE:
                switch(c) {
                    case '>':
                        ADVANCE_TOKEN;
                        // Self-closing tags cannot be script/style (per spec)
                        
                        // Add element to DOM
                        if(!(elem_tmp = html_new_element(state->tag, state->tag_name, state->attrib, NULL, NULL, NULL)))
                            goto error;
                        if(state->elem) {
                            state->elem->sibling = elem_tmp;
                            state->elem = elem_tmp;
                        } else {
                            state->elem = stack_peek(&state->stack);
                            state->elem->child = elem_tmp;
                            state->elem = elem_tmp;
                        }
                        
                        state->tag = 0;
                        state->attrib = 0;
                        state->attrib_key_name = 0;
                        
                        state->state = STATE_CHILD;
                        continue;
                    default:
                        ADVANCE_TOKEN;
                        continue;
                }
            case STATE_END:
                switch(c) {
                    CASE_SPACE:
                        if((state->tag = html_lookup_length_tag(token, (stream - 1) - token)) < 0)
                            state->tag = state->elem->tag;
                        
                        ADVANCE_TOKEN;
                        if(!stack_find(&state->stack, findtag, &state->tag)) {
                            state->state = STATE_CHILD;
                            continue;
                        }
                        
                        do {
                            elem_tmp = stack_pop(&state->stack);
                        } while(elem_tmp && elem_tmp->tag != state->tag);
                        
                        if(elem_tmp) {
                            state->elem = elem_tmp;
                        }
                        
                        state->state = STATE_END_CLOSE;
                        continue;
                    case '>':
                        if((state->tag = html_lookup_length_tag(token, (stream - 1) - token)) < 0)
                            state->tag = state->elem->tag;
                        
                        ADVANCE_TOKEN;
                        if(!stack_find(&state->stack, findtag, &state->tag)) {
                            state->state = STATE_CHILD;
                            continue;
                        }
                        
                        do {
                            elem_tmp = stack_pop(&state->stack);
                        } while(elem_tmp && elem_tmp->tag != state->tag);
                        
                        if(elem_tmp) {
                            state->elem = elem_tmp;
                        }
                        state->tag = 0;
                        state->attrib = 0;
                        state->attrib_key_name = 0;
                        
                        state->state = STATE_CHILD;
                        continue;
                    default:
                        continue;
                }
            case STATE_END_CLOSE:
                switch(c) {
                    case '>':
                        state->state = STATE_CHILD;
                        ADVANCE_TOKEN;
                        continue;
                    default:
                        continue;
                }
            case STATE_ENTITY:
            case STATES:
                break;
        }
    }
    
    /* If we're still in SCRIPT_TEXT state at end of stream, save accumulated text */
    if(state->state == STATE_SCRIPT_TEXT && state->stringlen > 0) {
        text = malloc(state->stringlen + 1);
        if (!text) goto error;
        memcpy(text, token, state->stringlen);
        text[state->stringlen] = '\0';
        
        if(!(elem_tmp = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, text)))
            goto error;
        if(state->elem) {
            state->elem->sibling = elem_tmp;
            state->elem = elem_tmp;
        } else {
            state->elem = stack_peek(&state->stack);
            state->elem->child = elem_tmp;
            state->elem = elem_tmp;
        }
    }
    
    return token;
    
    error:
    return NULL;
    
    #undef ADVANCE_TOKEN
}

HtmlDocument *html_parse_end(HtmlParseState *state) {
    HtmlDocument *document;
    
    if(!state)
        return NULL;
    
    document = state->document;
    while(stack_pop(&state->stack));
    free(state);
    html_print_dom(document);
    
    return document;
}

void *html_print_dom_element(HtmlElement *element, int level) {
    // Защита от мусорных указателей
    if ((uintptr_t)element < 0x1000) {
        SDL_Log("ERROR: Invalid element pointer %p", (void*)element);
        return NULL;
    }
    if (!element) return NULL;

    while (element) {
        HtmlElement *sibling = element->sibling;

        // Формируем отступ
        char tabs[64];
        int indent = (level < 31) ? level : 31;
        for (int i = 0; i < indent; i++) tabs[i] = '-';
        tabs[indent] = '\0';

        // Определяем имя тега
        const char* tag_name = html_tag_to_string(element->tag);
        if (!tag_name) tag_name = "unknown";

        // Основной заголовок элемента
        if (element->tag == HTML_TAG_NONE) {
            if (element->text) {
                SDL_Log("%s[text: \"%s\"]", tabs, stringtrim_l(element->text));
            } else {
                SDL_Log("%s[text: (null)]", tabs);
            }
        } else {
            SDL_Log("%s<%s> (tag=%d, ptr=%p)", tabs, tag_name, (int)element->tag, (void*)element);
        }
 
        // Дополнительные поля (всегда выводим, даже если нулевые)
        SDL_Log("%s  pos=(%d,%d) size=(%d,%d) display=%d fontsize=%d",
                tabs, element->x, element->y, element->w, element->h, element->display, element->fontsize);
        SDL_Log("%s  colors: text=0x%06X, bg=0x%06X", tabs, element->textcolor, element->color);
        if (element->id) {
            SDL_Log("%s  id=\"%s\"", tabs, element->id);
        }
        if (element->selectedId >= 0) {
            SDL_Log("%s  selectedId=%d", tabs, element->selectedId);
        }

        // Атрибуты
        if (element->attrib) {
            SDL_Log("%s  attributes:", tabs);
            HtmlAttrib *attrib = element->attrib;
            while (attrib) {
                const char* key_name = (attrib->key != HTML_ATTRIB_UNKNOWN && html_attrib[attrib->key][0])
                    ? html_attrib[attrib->key]
                    : attrib->key_name;
                const char* value = attrib->value ? attrib->value : "(null)";
                SDL_Log("%s    %s=\"%s\"", tabs, key_name ? key_name : "(unknown)", value);
                attrib = attrib->next;
            }
        }

        // Рекурсивный обход потомков
        if (element->child) {
    		// Защита от повреждённой памяти
    		if ((uintptr_t)element->child < 0x1000) {
        		SDL_Log("%s  [children: INVALID POINTER %p]", tabs, (void*)element->child);
        		return NULL;
    		}
    		SDL_Log("%s  [children:]", tabs);
    		html_print_dom_element(element->child, level + 1);
		}

        element = sibling;
    }
    return NULL;
}

void *html_print_dom(HtmlDocument *document) {
    html_print_dom_element(document->root_element, 0);
    SDL_Log("== END PRINT DOM ==");
    return NULL;
}

void *html_free_attrib(HtmlAttrib *attrib) {
    if(!attrib)
        return NULL;
    html_free_attrib(attrib->next);
    attrib->key = HTML_ATTRIB_NONE;
    free(attrib->key_name);
    free(attrib->value);
    free(attrib->next);
    return NULL;
}

void *html_free_element(HtmlElement *element) {
    void *sibling;
    
    if(!element)
        return NULL;
    while(element) {
        html_free_attrib(element->attrib);
        free(element->attrib);
        if(element->tag_name) {
            free(element->tag_name);
        }
        if(element->text) {
            free(element->text);
        }
        html_free_element(element->child);
        sibling = element->sibling;
        free(element);
        element = sibling;
    }
    return NULL;
}

void *html_free_document(HtmlDocument *document) {
    if(!document)
        return NULL;
    html_free_element(document->root_element);
    free(document);
    return NULL;
}
