#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sdl.h"
#include "defines.h"
#include "api.h"
#include "utils.h"
#include "base64.h"
#include "html.h"
#include "minIni.h"
#include "duktape.h"

#define LOG_TO_FILE 1
#ifndef HAVE_STRDUP
char* my_strdup(const char* s) {
    if (!s) return NULL;
    size_t len = strlen(s);
    char* p = malloc(len + 1);
    if (p) memcpy(p, s, len + 1);
    return p;
}
#define strdup my_strdup
#endif

static int DEVICE_WIDTH = FIXED_WIDTH;
static int DEVICE_HEIGHT = FIXED_HEIGHT;
SDL_Surface* screen = NULL;
HtmlDocument *doc;

enum style_tag{ NO_TAG, COLOR, BACKGROUND_COLOR, DISPLAY, INNER_TEXT };
enum display_type{ NONE, INLINE, BLOCK };
int dirty = 1;

struct AhrefName {
    int y;
    char *name;
} ahref_name_array[2048];

// Структуры для таблиц
typedef struct TableColumn {
    int width;
    struct TableColumn* next;
} TableColumn;

typedef struct TableRow {
    HtmlElement* cells;
    struct TableRow* next;
    int height;
} TableRow;

typedef struct TableContext {
    TableColumn* columns;
    TableRow* rows;
    int col_count;
    int row_count;
    int current_col;
    int current_row;
    HtmlElement* current_row_element;
    int table_x;
    int table_y;
} TableContext;

TableContext* current_table = NULL;

// Структура для CSS стилей
typedef struct CSSStyle {
    char* selector;
    char* property;
    char* value;
    struct CSSStyle* next;
} CSSStyle;

CSSStyle* css_styles = NULL;

// Структуры для Canvas
enum canvas_operation {
    CANVAS_FILL_RECT,
    CANVAS_STROKE_RECT,
    CANVAS_FILL_TEXT,
    CANVAS_CLEAR_RECT,
    CANVAS_DRAW_IMAGE,
    CANVAS_BEGIN_PATH,
    CANVAS_CLOSE_PATH,
    CANVAS_MOVE_TO,
    CANVAS_LINE_TO,
    CANVAS_STROKE,
    CANVAS_FILL,
    CANVAS_ARC,
    CANVAS_RECT,
    CANVAS_SET_FILL_STYLE,
    CANVAS_SET_STROKE_STYLE,
    CANVAS_SET_LINE_WIDTH,
    CANVAS_SET_FONT
};

typedef struct CanvasOperation {
    enum canvas_operation type;
    int x, y, w, h;
    int color;
    int line_width;
    char* text;
    char* font;
    SDL_Surface* image;
    float start_angle;
    float end_angle;
    int counterclockwise;
    struct CanvasOperation* next;
} CanvasOperation;

typedef struct CanvasContext {
    int width;
    int height;
    SDL_Surface* surface;
    int fill_color;
    int stroke_color;
    int line_width;
    char font[64];
    CanvasOperation* operations;
    CanvasOperation* last_operation;
    int path_start_x;
    int path_start_y;
    int current_x;
    int current_y;
    int path_open;
    int needs_redraw;
} CanvasContext;

// Глобальные переменные для canvas
static CanvasContext* canvas_contexts[10];
static int canvas_context_count = 0;

int remath_dom;
int ahref_array_count = 0;
int selectElement = 0;
int startViewSelectedId = -1;
int endViewSelectedId = -1;
int ahref_name_array_count = 0;
int drawCursor = 0;
int selectId = 0;
char language_name[64];
char* selectedHref = NULL;
char* selectedOnClick = NULL;

#define BUFFSIZE (1024 * 1024)
int max_global_y = 0;
int global_y = 0;
TTF_Font* fonts[5];

// Структура для кеширования текста
typedef struct {
    char text[256];
    int fontsize;
    int color;
    int bg_color;
    SDL_Surface* surface;
    SDL_Surface* bg_surface;
    int width;
    int height;
} TextCacheEntry;

#define TEXT_CACHE_SIZE 256
static TextCacheEntry text_cache[TEXT_CACHE_SIZE];
static int text_cache_count = 0;
static int text_cache_hits = 0;
static int text_cache_misses = 0;

// Структура для кеширования изображений
typedef struct ImageCacheEntry {
    char* src;
    SDL_Surface* surface;
    int width;
    int height;
    struct ImageCacheEntry* next;
} ImageCacheEntry;

ImageCacheEntry* image_cache = NULL;
static int image_cache_count = 0;

// Структуры для таймеров
typedef struct Timer {
    int id;
    char* callback_key;  // Ключ в глобальном объекте, например "__timer_123"
    int delay;
    int repeat;
    Uint32 last_fire;
    struct Timer* next;
} Timer;

static Timer* timers = NULL;
static int next_timer_id = 1;
static Uint32 last_ticks = 0;

static duk_ret_t js_canvas_fillRect(duk_context *ctx);
static duk_ret_t js_canvas_strokeRect(duk_context *ctx);
static duk_ret_t js_canvas_clearRect(duk_context *ctx);
static duk_ret_t js_canvas_fillText(duk_context *ctx);
static duk_ret_t js_canvas_drawImage(duk_context *ctx);
static duk_ret_t js_canvas_beginPath(duk_context *ctx);
static duk_ret_t js_canvas_closePath(duk_context *ctx);
static duk_ret_t js_canvas_moveTo(duk_context *ctx);
static duk_ret_t js_canvas_lineTo(duk_context *ctx);
static duk_ret_t js_canvas_stroke(duk_context *ctx);
static duk_ret_t js_canvas_fill(duk_context *ctx);
static duk_ret_t js_canvas_arc(duk_context *ctx);
static duk_ret_t js_canvas_rect(duk_context *ctx);
static duk_ret_t js_canvas_set_fillStyle(duk_context *ctx);
static duk_ret_t js_canvas_set_strokeStyle(duk_context *ctx);
static duk_ret_t js_canvas_set_lineWidth(duk_context *ctx);
static duk_ret_t js_canvas_set_font(duk_context *ctx);
static duk_ret_t js_canvas_getContext(duk_context *ctx);
static duk_ret_t js_getElementById(duk_context *ctx);
static CanvasContext* get_canvas_context_from_element(HtmlElement* element);
SDL_Surface* img_src_parse(const char *src);

// Объявления для настроек
void InitSettings(void);
void QuitSettings(void);
char* normalize_js_string(const char* input);
const char* html_tag_to_string(HtmlTag tag);


#define MAX_LOG_LINES 20
#define LOG_LINE_HEIGHT 14
static char* log_lines[MAX_LOG_LINES];
static int log_line_count = 0;
static int show_logs = 0;  // 0 - выкл, 1 - внизу экрана, 2 - полноэкранный
static SDL_Surface* log_background = NULL;

// Функция для добавления лога
void add_log(const char* format, ...) {
    va_list args;
    char buffer[512];
    
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    // Удаляем старую строку если достигли максимума
    if (log_line_count >= MAX_LOG_LINES) {
        free(log_lines[0]);
        for (int i = 1; i < MAX_LOG_LINES; i++) {
            log_lines[i-1] = log_lines[i];
        }
        log_line_count--;
    }
    
    // Добавляем новую строку
    log_lines[log_line_count] = strdup(buffer);
    log_line_count++;
    
    // Выводим также в SDL_Log для отладки
    SDL_Log("%s", buffer);
    
    dirty = 1;  // Помечаем экран как грязный для перерисовки
}

// Функция для отрисовки логов
void draw_logs() {
    if (!show_logs || !screen) return;
    
    int start_y, max_height;
    
    if (show_logs == 1) {
        // Логи внизу экрана
        max_height = 120;
        start_y = DEVICE_HEIGHT - max_height;
        
        // Создаем или обновляем фон для логов
        if (!log_background || log_background->h != max_height) {
            if (log_background) SDL_FreeSurface(log_background);
            log_background = SDL_CreateRGBSurface(0, DEVICE_WIDTH, max_height, 32,
                                                  0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
        }
        
        if (log_background) {
            // Полупрозрачный темный фон
            SDL_FillRect(log_background, NULL, 0x80000000);  // Полупрозрачный черный
            
            // Рамка
            SDL_FillRect(log_background, &(SDL_Rect){0, 0, DEVICE_WIDTH, 2}, 0xFF0000FF);  // Синяя верхняя граница
            SDL_FillRect(log_background, &(SDL_Rect){0, max_height-2, DEVICE_WIDTH, 2}, 0xFF0000FF);  // Синяя нижняя граница
            
            SDL_Rect dest = {0, start_y, DEVICE_WIDTH, max_height};
            SDL_BlitSurface(log_background, NULL, screen, &dest);
        }
        
        // Заголовок
        SDL_Surface* header = TTF_RenderUTF8_Blended(fonts[1], "=== Логи ===", 
                                                     (SDL_Color){255, 255, 255, 255});
        if (header) {
            SDL_Rect header_dest = {10, start_y + 5, header->w, header->h};
            SDL_BlitSurface(header, NULL, screen, &header_dest);
            SDL_FreeSurface(header);
        }
        
        // Рисуем логи
        int y = start_y + 25;
        int lines_to_show = (max_height - 30) / LOG_LINE_HEIGHT;
        if (lines_to_show > log_line_count) lines_to_show = log_line_count;
        
        for (int i = log_line_count - lines_to_show; i < log_line_count; i++) {
            if (i >= 0 && log_lines[i]) {
                SDL_Surface* text_surface = TTF_RenderUTF8_Blended(fonts[0], log_lines[i], 
                                                                   (SDL_Color){255, 255, 255, 255});
                if (text_surface) {
                    SDL_Rect text_dest = {10, y, text_surface->w, text_surface->h};
                    SDL_BlitSurface(text_surface, NULL, screen, &text_dest);
                    SDL_FreeSurface(text_surface);
                }
                y += LOG_LINE_HEIGHT;
            }
        }
    } 
    else if (show_logs == 2) {
        // Полноэкранный режим логов
        start_y = 0;
        max_height = DEVICE_HEIGHT;
        
        // Черный фон
        SDL_FillRect(screen, NULL, 0x000000);
        
        // Заголовок
        SDL_Surface* header = TTF_RenderUTF8_Blended(fonts[2], "=== ПОЛНЫЕ ЛОГИ ===", 
                                                     (SDL_Color){255, 0, 0, 255});
        if (header) {
            SDL_Rect header_dest = {10, 5, header->w, header->h};
            SDL_BlitSurface(header, NULL, screen, &header_dest);
            SDL_FreeSurface(header);
        }
        
        // Рисуем все логи
        int y = 30;
        for (int i = 0; i < log_line_count; i++) {
            if (log_lines[i]) {
                SDL_Surface* text_surface = TTF_RenderUTF8_Blended(fonts[1], log_lines[i], 
                                                                   (SDL_Color){255, 255, 255, 255});
                if (text_surface) {
                    if (y + text_surface->h > DEVICE_HEIGHT - 10) break;
                    
                    SDL_Rect text_dest = {10, y, text_surface->w, text_surface->h};
                    SDL_BlitSurface(text_surface, NULL, screen, &text_dest);
                    SDL_FreeSurface(text_surface);
                }
                y += LOG_LINE_HEIGHT;
            }
        }
        
        // Подсказка внизу
        SDL_Surface* hint = TTF_RenderUTF8_Blended(fonts[1], "B - назад, A - очистить логи", 
                                                   (SDL_Color){100, 100, 255, 255});
        if (hint) {
            SDL_Rect hint_dest = {10, DEVICE_HEIGHT - 20, hint->w, hint->h};
            SDL_BlitSurface(hint, NULL, screen, &hint_dest);
            SDL_FreeSurface(hint);
        }
    }
}

// Функции для Canvas
CanvasContext* create_canvas_context(int width, int height) {
    CanvasContext* ctx = (CanvasContext*)malloc(sizeof(CanvasContext));
    if (!ctx) return NULL;
    
    ctx->width = width;
    ctx->height = height;
    ctx->surface = SDL_CreateRGBSurface(0, width, height, 32, 
                                        0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);
    ctx->fill_color = 0x000000;
    ctx->stroke_color = 0x000000;
    ctx->line_width = 1;
    strcpy(ctx->font, "12px sans-serif");
    ctx->operations = NULL;
    ctx->last_operation = NULL;
    ctx->path_start_x = 0;
    ctx->path_start_y = 0;
    ctx->current_x = 0;
    ctx->current_y = 0;
    ctx->path_open = 0;
    ctx->needs_redraw = 1;
    
    if (ctx->surface) {
        SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    }
    
    if (canvas_context_count < 10) {
        canvas_contexts[canvas_context_count++] = ctx;
    }
    
    return ctx;
}

void free_canvas_context(CanvasContext* ctx) {
    if (!ctx) return;
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        CanvasOperation* next = op->next;
        if (op->text) free(op->text);
        if (op->font) free(op->font);
        free(op);
        op = next;
    }
    
    if (ctx->surface) {
        SDL_FreeSurface(ctx->surface);
    }
    
    free(ctx);
}

void canvas_add_operation(CanvasContext* ctx, CanvasOperation* op) {
    if (!ctx || !op) return;
    add_log("Canvas: add %d", op->type);
    op->next = NULL;
    
    if (!ctx->operations) {
        ctx->operations = op;
        ctx->last_operation = op;
    } else {
        ctx->last_operation->next = op;
        ctx->last_operation = op;
    }
    ctx->needs_redraw = 1;
    dirty = 1;
}

void canvas_draw_pixel(CanvasContext* ctx, int x, int y, Uint32 color) {
    if (!ctx || !ctx->surface || x < 0 || x >= ctx->width || y < 0 || y >= ctx->height)
        return;
    
    Uint32* pixels = (Uint32*)ctx->surface->pixels;
    pixels[y * ctx->width + x] = color;
    dirty = 1;
}

void canvas_draw_line(CanvasContext* ctx, int x0, int y0, int x1, int y1, Uint32 color, int width) {
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx - dy;
    
    while (1) {
        // Рисуем точку с учетом толщины
        for (int i = -width/2; i <= width/2; i++) {
            for (int j = -width/2; j <= width/2; j++) {
                if (x0 + i >= 0 && x0 + i < ctx->width && 
                    y0 + j >= 0 && y0 + j < ctx->height) {
                    canvas_draw_pixel(ctx, x0 + i, y0 + j, color);
                }
            }
        }
        
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
    dirty = 1;
}

void canvas_draw_line_sdl(CanvasContext* ctx, int x0, int y0, int x1, int y1, Uint32 color, int width) {
    // Используем SDL для рисования линии через заполненные прямоугольники
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    
    if (dx == 0 && dy == 0) {
        // Точка
        if (width > 0) {
            int half = width / 2;
            SDL_Rect rect = {x0 - half, y0 - half, width, width};
            SDL_FillRect(ctx->surface, &rect, color);
        }
        return;
    }
    
    // Для горизонтальных и вертикальных линий используем SDL_FillRect
    if (dx == 0) {
        // Вертикальная линия
        int y = (y0 < y1) ? y0 : y1;
        int h = dy + width;
        SDL_Rect rect = {x0 - width/2, y, width, h};
        SDL_FillRect(ctx->surface, &rect, color);
    } else if (dy == 0) {
        // Горизонтальная линия
        int x = (x0 < x1) ? x0 : x1;
        int w = dx + width;
        SDL_Rect rect = {x, y0 - width/2, w, width};
        SDL_FillRect(ctx->surface, &rect, color);
    } else {
        // Диагональная линия - рисуем отдельные пиксели
        float step = 0.5f;
        for (float t = 0; t <= 1.0f; t += step) {
            int x = x0 + (int)((x1 - x0) * t);
            int y = y0 + (int)((y1 - y0) * t);
            for (int i = -width/2; i <= width/2; i++) {
                for (int j = -width/2; j <= width/2; j++) {
                    if (x + i >= 0 && x + i < ctx->width && 
                        y + j >= 0 && y + j < ctx->height) {
                        Uint32* pixels = (Uint32*)ctx->surface->pixels;
                        pixels[(y + j) * ctx->width + (x + i)] = color;
                    }
                }
            }
        }
    }
}

void canvas_draw_circle_sdl(CanvasContext* ctx, int cx, int cy, int radius, Uint32 color, int fill) {
    if (fill) {
        // Заполненный круг через прямоугольники
        for (int y = -radius; y <= radius; y++) {
            int x_limit = (int)sqrt(radius * radius - y * y);
            if (x_limit > 0) {
                SDL_Rect rect = {cx - x_limit, cy + y, 2 * x_limit, 1};
                SDL_FillRect(ctx->surface, &rect, color);
            }
        }
    } else {
        // Контур круга через точки
        for (int angle = 0; angle < 360; angle += 5) {
            float rad = angle * M_PI / 180.0f;
            int x = cx + (int)(radius * cos(rad));
            int y = cy + (int)(radius * sin(rad));
            if (x >= 0 && x < ctx->width && y >= 0 && y < ctx->height) {
                Uint32* pixels = (Uint32*)ctx->surface->pixels;
                pixels[y * ctx->width + x] = color;
            }
        }
    }
}

void canvas_execute_operations_sdl(CanvasContext* ctx) {
    if (!ctx || !ctx->surface || !ctx->needs_redraw) return;
    
    SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        switch (op->type) {
            case CANVAS_FILL_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           ctx->fill_color | 0xFF000000);
                break;
                
            case CANVAS_STROKE_RECT: {
                int lw = ctx->line_width;
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y + op->h - lw, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x + op->w - lw, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                break;
            }
                
            case CANVAS_CLEAR_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           0x00FFFFFF);
                break;
                
            case CANVAS_FILL_TEXT:
                if (op->text) {
                    TTF_Font* font = fonts[1];
                    int font_size = 12;
                    
                    if (op->font) {
                        sscanf(op->font, "%dpx", &font_size);
                    }
                    
                    if (font_size <= 10) font = fonts[0];
                    else if (font_size <= 12) font = fonts[1];
                    else if (font_size <= 16) font = fonts[2];
                    else if (font_size <= 20) font = fonts[3];
                    else font = fonts[4];
                    
                    SDL_Color color = { 
                        (ctx->fill_color >> 16) & 0xFF,
                        (ctx->fill_color >> 8) & 0xFF,
                        ctx->fill_color & 0xFF, 255 
                    };
                    SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, op->text, color);
                    if (text_surface) {
                        SDL_Rect dest = {op->x, op->y, text_surface->w, text_surface->h};
                        SDL_BlitSurface(text_surface, NULL, ctx->surface, &dest);
                        SDL_FreeSurface(text_surface);
                    }
                }
                break;
                
            case CANVAS_DRAW_IMAGE:
                if (op->image && op->w > 0 && op->h > 0) {
                    SDL_Rect dest = {op->x, op->y, op->w, op->h};
                    SDL_BlitSurface(op->image, NULL, ctx->surface, &dest);
                }
                break;
                
            case CANVAS_LINE_TO:
                canvas_draw_line_sdl(ctx, ctx->current_x, ctx->current_y, op->x, op->y, 
                                   ctx->stroke_color | 0xFF000000, ctx->line_width);
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            case CANVAS_ARC: {
                int cx = op->x + op->w / 2;
                int cy = op->y + op->h / 2;
                int radius = op->w / 2;
                canvas_draw_circle_sdl(ctx, cx, cy, radius, ctx->stroke_color | 0xFF000000, 0);
                break;
            }
                
            default:
                break;
        }
        op = op->next;
    }
    
    ctx->needs_redraw = 0;
}

void canvas_draw_circle(CanvasContext* ctx, int cx, int cy, int radius, Uint32 color, int fill) {
    int x = radius;
    int y = 0;
    int err = 0;
    
    while (x >= y) {
        if (fill) {
            // Заполненный круг - рисуем горизонтальные линии
            canvas_draw_line(ctx, cx - x, cy + y, cx + x, cy + y, color, 1);
            canvas_draw_line(ctx, cx - y, cy + x, cx + y, cy + x, color, 1);
            canvas_draw_line(ctx, cx - x, cy - y, cx + x, cy - y, color, 1);
            canvas_draw_line(ctx, cx - y, cy - x, cx + y, cy - x, color, 1);
        } else {
            // Только контур
            canvas_draw_pixel(ctx, cx + x, cy + y, color);
            canvas_draw_pixel(ctx, cx + y, cy + x, color);
            canvas_draw_pixel(ctx, cx - y, cy + x, color);
            canvas_draw_pixel(ctx, cx - x, cy + y, color);
            canvas_draw_pixel(ctx, cx - x, cy - y, color);
            canvas_draw_pixel(ctx, cx - y, cy - x, color);
            canvas_draw_pixel(ctx, cx + y, cy - x, color);
            canvas_draw_pixel(ctx, cx + x, cy - y, color);
        }
        
        y += 1;
        err += 1 + 2*y;
        if (2*(err - x) + 1 > 0) {
            x -= 1;
            err += 1 - 2*x;
        }
    }
}

void canvas_execute_operations(CanvasContext* ctx) {
    if (!ctx || !ctx->surface || !ctx->needs_redraw) return;
    
    // Очищаем поверхность
    SDL_FillRect(ctx->surface, NULL, 0x00FFFFFF);
    
    CanvasOperation* op = ctx->operations;
    while (op) {
        switch (op->type) {
            case CANVAS_FILL_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           ctx->fill_color | 0xFF000000);
                break;
                
            case CANVAS_STROKE_RECT: {
                int lw = ctx->line_width;
                // Верхняя линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                // Нижняя линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y + op->h - lw, op->w, lw}, 
                           ctx->stroke_color | 0xFF000000);
                // Левая линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                // Правая линия
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x + op->w - lw, op->y, lw, op->h}, 
                           ctx->stroke_color | 0xFF000000);
                break;
            }
                
            case CANVAS_CLEAR_RECT:
                SDL_FillRect(ctx->surface, &(SDL_Rect){op->x, op->y, op->w, op->h}, 
                           0x00FFFFFF);
                break;
                
            case CANVAS_FILL_TEXT:
                if (op->text) {
                    TTF_Font* font = fonts[1];
                    int font_size = 12;
                    
                    if (op->font) {
                        sscanf(op->font, "%dpx", &font_size);
                    }
                    
                    if (font_size <= 10) font = fonts[0];
                    else if (font_size <= 12) font = fonts[1];
                    else if (font_size <= 16) font = fonts[2];
                    else if (font_size <= 20) font = fonts[3];
                    else font = fonts[4];
                    
                    SDL_Color color = (SDL_Color){ 
                        (ctx->fill_color >> 16) & 0xFF,
                        (ctx->fill_color >> 8) & 0xFF,
                        ctx->fill_color & 0xFF, 255 
                    };
                    SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, op->text, color);
                    if (text_surface) {
                        SDL_Rect dest = {op->x, op->y, text_surface->w, text_surface->h};
                        SDL_BlitSurface(text_surface, NULL, ctx->surface, &dest);
                        SDL_FreeSurface(text_surface);
                    }
                }
                break;
                
            case CANVAS_DRAW_IMAGE:
                if (op->image && op->w > 0 && op->h > 0) {
                    SDL_Rect dest = {op->x, op->y, op->w, op->h};
                    SDL_BlitSurface(op->image, NULL, ctx->surface, &dest);
                }
                break;
                
            case CANVAS_LINE_TO:
                canvas_draw_line(ctx, ctx->current_x, ctx->current_y, op->x, op->y, 
                               ctx->stroke_color | 0xFF000000, ctx->line_width);
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            case CANVAS_ARC: {
                int cx = op->x + op->w / 2;
                int cy = op->y + op->h / 2;
                int radius = op->w / 2;
                canvas_draw_circle(ctx, cx, cy, radius, ctx->stroke_color | 0xFF000000, 0);
                break;
            }
                
            case CANVAS_RECT:
                ctx->current_x = op->x;
                ctx->current_y = op->y;
                break;
                
            default:
                break;
        }
        op = op->next;
    }
    
    ctx->needs_redraw = 0;
}

void initLang(){
    const char settings_inifile[] = SYSTEM_PATH "/uisettings.ini";
    char l_id[8];
    int lang = ini_getl("lang", "select", 0, settings_inifile);
    sprintf(l_id, "id%d", lang);
    ini_gets("lang", l_id, "en_US", language_name, 64, settings_inifile);
}

uint32_t hex2int(const char *hex) {
    uint32_t val = 0;
    while (*hex) {
        uint8_t byte = *hex++;
        if (byte >= '0' && byte <= '9') byte -= '0';
        else if (byte >= 'a' && byte <='f') byte = byte - 'a' + 10;
        else if (byte >= 'A' && byte <='F') byte = byte - 'A' + 10;
        else byte = 0;
        val = (val << 4) | (byte & 0xF);
    }
    return val;
}

int parse_css_color(const char* color_str) {
    if (!color_str) return 0;
    
    if (strncmp(color_str, "#", 1) == 0) {
        return hex2int(color_str + 1);
    } else if (strcmp(color_str, "black") == 0) {
        return 0x000000;
    } else if (strcmp(color_str, "white") == 0) {
        return 0xFFFFFF;
    } else if (strcmp(color_str, "red") == 0) {
        return 0xFF0000;
    } else if (strcmp(color_str, "green") == 0) {
        return 0x00FF00;
    } else if (strcmp(color_str, "blue") == 0) {
        return 0x0000FF;
    } else if (strcmp(color_str, "gray") == 0 || strcmp(color_str, "grey") == 0) {
        return 0x808080;
    } else if (strcmp(color_str, "yellow") == 0) {
        return 0xFFFF00;
    } else if (strcmp(color_str, "cyan") == 0) {
        return 0x00FFFF;
    } else if (strcmp(color_str, "magenta") == 0) {
        return 0xFF00FF;
    } else if (strcmp(color_str, "silver") == 0) {
        return 0xC0C0C0;
    } else if (strcmp(color_str, "maroon") == 0) {
        return 0x800000;
    } else if (strcmp(color_str, "purple") == 0) {
        return 0x800080;
    } else if (strcmp(color_str, "fuchsia") == 0) {
        return 0xFF00FF;
    } else if (strcmp(color_str, "lime") == 0) {
        return 0x00FF00;
    } else if (strcmp(color_str, "olive") == 0) {
        return 0x808000;
    } else if (strcmp(color_str, "navy") == 0) {
        return 0x000080;
    } else if (strcmp(color_str, "teal") == 0) {
        return 0x008080;
    } else if (strcmp(color_str, "orange") == 0) {
        return 0xFFA500;
    } else if (strcmp(color_str, "brown") == 0) {
        return 0xA52A2A;
    } else if (strcmp(color_str, "pink") == 0) {
        return 0xFFC0CB;
    } else if (strcmp(color_str, "gold") == 0) {
        return 0xFFD700;
    }
    
    return hex2int(color_str);
}

int parse_css_length(const char* length_str) {
    if (!length_str) return 0;
    
    int value = 0;
    if (strstr(length_str, "px")) {
        sscanf(length_str, "%dpx", &value);
    } else if (strstr(length_str, "em")) {
        float em_value;
        sscanf(length_str, "%fem", &em_value);
        value = (int)(em_value * 16);
    } else if (strstr(length_str, "rem")) {
        float rem_value;
        sscanf(length_str, "%frem", &rem_value);
        value = (int)(rem_value * 16);
    } else if (strstr(length_str, "%")) {
        sscanf(length_str, "%d%%", &value);
        value = (value * DEVICE_WIDTH) / 100;
    } else {
        value = atoi(length_str);
    }
    return value;
}

HtmlAttrib* html_new_attrib(HtmlAttribKey key, const char* key_name, const char* value) {
    HtmlAttrib* attrib = (HtmlAttrib*)malloc(sizeof(HtmlAttrib));
    if (attrib) {
        attrib->key = key;
        attrib->key_name = key_name ? strdup(key_name) : NULL;
        attrib->value = value ? strdup(value) : NULL;
        attrib->next = NULL;
    }
    return attrib;
}

void add_css_style(const char* selector, const char* property, const char* value) {
    CSSStyle* style = (CSSStyle*)malloc(sizeof(CSSStyle));
    if (!style) return;
    
    style->selector = strdup(selector);
    style->property = strdup(property);
    style->value = strdup(value);
    style->next = css_styles;
    css_styles = style;
}

void free_css_styles() {
    CSSStyle* style = css_styles;
    while (style) {
        CSSStyle* next = style->next;
        free(style->selector);
        free(style->property);
        free(style->value);
        free(style);
        style = next;
    }
    css_styles = NULL;
}

void apply_css_styles(HtmlElement* element) {
    if (!element || !css_styles) return;
    
    CSSStyle* style = css_styles;
    while (style) {
        int matches = 0;
        
        if (style->selector[0] != '#' && style->selector[0] != '.') {
            const char* tag_name = html_tag_to_string(element->tag);
            if (tag_name && strcmp(tag_name, style->selector) == 0) {
                matches = 1;
            }
        }
        
        if (style->selector[0] == '#') {
            if (element->id && strcmp(element->id, style->selector + 1) == 0) {
                matches = 1;
            }
        }
        
        if (style->selector[0] == '.') {
            // Простая проверка класса (без поддержки множественных классов)
            HtmlAttrib* attrib = element->attrib;
            while (attrib) {
                if (attrib->key == HTML_ATTRIB_CLASS && 
                    strcmp(attrib->value, style->selector + 1) == 0) {
                    matches = 1;
                    break;
                }
                attrib = attrib->next;
            }
        }
        
        if (matches) {
            if (strcmp(style->property, "color") == 0) {
                element->textcolor = parse_css_color(style->value);
            } else if (strcmp(style->property, "background-color") == 0) {
                element->color = parse_css_color(style->value);
            } else if (strcmp(style->property, "border-color") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-color", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "border-width") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-width", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "border-style") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "border-style", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-top") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-top", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-bottom") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-bottom", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-left") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-left", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "margin-right") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "margin-right", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-top") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-top", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-bottom") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-bottom", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-left") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-left", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "padding-right") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "padding-right", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            } else if (strcmp(style->property, "display") == 0) {
                if (strcmp(style->value, "none") == 0) element->display = NONE;
                else if (strcmp(style->value, "inline") == 0) element->display = INLINE;
                else if (strcmp(style->value, "block") == 0) element->display = BLOCK;
                else if (strcmp(style->value, "inline-block") == 0) element->display = INLINE;
            } else if (strcmp(style->property, "width") == 0) {
                element->w = parse_css_length(style->value);
            } else if (strcmp(style->property, "height") == 0) {
                element->h = parse_css_length(style->value);
            } else if (strcmp(style->property, "font-size") == 0) {
                if (strstr(style->value, "px")) {
                    int size;
                    sscanf(style->value, "%dpx", &size);
                    if (size <= 10) element->fontsize = 0;
                    else if (size <= 12) element->fontsize = 1;
                    else if (size <= 16) element->fontsize = 2;
                    else if (size <= 20) element->fontsize = 3;
                    else element->fontsize = 4;
                }
            } else if (strcmp(style->property, "text-align") == 0) {
                HtmlAttrib* attrib = html_new_attrib(HTML_ATTRIB_STYLE, "text-align", style->value);
                if (attrib) {
                    attrib->next = element->attrib;
                    element->attrib = attrib;
                }
            }
        }
        
        style = style->next;
    }
}

HtmlElement *html_find_element(HtmlElement *element, const char *id) {
    if(!element) return NULL;
    while(element) {
        if(element->id && strcmp(element->id, id) == 0) return element;
        HtmlElement *found = html_find_element(element->child, id);
        if(found) return found;
        element = element->sibling;
    }
    return NULL;
}

TableContext* create_table_context() {
    TableContext* table = (TableContext*)malloc(sizeof(TableContext));
    if (table) {
        table->columns = NULL;
        table->rows = NULL;
        table->col_count = 0;
        table->row_count = 0;
        table->current_col = 0;
        table->current_row = 0;
        table->current_row_element = NULL;
        table->table_x = 0;
        table->table_y = 0;
    }
    return table;
}

void free_table_context(TableContext* table) {
    if (!table) return;
    
    TableColumn* col = table->columns;
    while (col) {
        TableColumn* next = col->next;
        free(col);
        col = next;
    }
    
    TableRow* row = table->rows;
    while (row) {
        TableRow* next = row->next;
        free(row);
        row = next;
    }
    
    free(table);
}

void table_add_column(TableContext* table, int width) {
    TableColumn* new_col = (TableColumn*)malloc(sizeof(TableColumn));
    if (new_col) {
        new_col->width = width;
        new_col->next = NULL;
        
        if (!table->columns) {
            table->columns = new_col;
        } else {
            TableColumn* last = table->columns;
            while (last->next) last = last->next;
            last->next = new_col;
        }
        table->col_count++;
    }
}

void table_add_row(TableContext* table, HtmlElement* cells, int height) {
    TableRow* new_row = (TableRow*)malloc(sizeof(TableRow));
    if (new_row) {
        new_row->cells = cells;
        new_row->height = height;
        new_row->next = NULL;
        
        if (!table->rows) {
            table->rows = new_row;
        } else {
            TableRow* last = table->rows;
            while (last->next) last = last->next;
            last->next = new_row;
        }
        table->row_count++;
    }
}

int get_table_column_width(TableContext* table, int col_index) {
    TableColumn* col = table->columns;
    int i = 0;
    while (col && i < col_index) {
        col = col->next;
        i++;
    }
    return col ? col->width : 100;
}

int get_table_row_height(TableContext* table, int row_index) {
    TableRow* row = table->rows;
    int i = 0;
    while (row && i < row_index) {
        row = row->next;
        i++;
    }
    return row ? row->height : 20;
}

void parse_css_from_style_tag(const char* css_text) {
    if (!css_text) return;
    
    char* css_copy = strdup(css_text);
    char* ptr = css_copy;
    
    while (*ptr) {
        while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
        
        if (!*ptr) break;
        
        char* selector_start = ptr;
        while (*ptr && *ptr != '{') ptr++;
        if (!*ptr) break;
        
        char* selector_end = ptr;
        *selector_end = '\0';
        ptr++;
        
        while (*ptr && *ptr != '}') {
            while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
            
            if (*ptr == '}') break;
            
            char* prop_start = ptr;
            while (*ptr && *ptr != ':' && *ptr != '}') ptr++;
            if (*ptr == '}') break;
            
            char* prop_end = ptr;
            *prop_end = '\0';
            ptr++;
            
            while (*ptr == ' ' || *ptr == '\t') ptr++;
            
            char* value_start = ptr;
            while (*ptr && *ptr != ';' && *ptr != '}') ptr++;
            
            char* value_end = ptr;
            if (*ptr == ';') {
                *value_end = '\0';
                ptr++;
            } else if (*ptr == '}') {
                *value_end = '\0';
            }
            
            add_css_style(selector_start, prop_start, value_start);
            
            while (*ptr == ' ' || *ptr == '\n' || *ptr == '\t' || *ptr == '\r') ptr++;
        }
        
        if (*ptr == '}') ptr++;
    }
    
    free(css_copy);
}

const char* get_style_value(HtmlElement* element, const char* property) {
    HtmlAttrib* attrib = element->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_STYLE && attrib->key_name && 
            strcmp(attrib->key_name, property) == 0) {
            return attrib->value;
        }
        attrib = attrib->next;
    }
    return NULL;
}

duk_context *ctx;
 
static void my_fatal(void *udata, const char *msg) {
    SDL_Log("*** FATAL ERROR: %s\n", msg ? msg : "no message");
    abort();
}

void duk_peval_string_logged(duk_context *ctx, const char *code) {
    if (!code) {
        add_log("JavaScript error: code is NULL");
        return;
    }

    size_t len = strlen(code);
    if (len == 0) {
        add_log("JavaScript error: empty code");
        return;
    }

    // === 1. Проверка на обрезку (отсутствие завершающих скобок / точек с запятой)
    int looks_truncated = 0;
    const char* last_non_ws = code + len - 1;
    while (last_non_ws > code && (*last_non_ws == ' ' || *last_non_ws == '\t' || *last_non_ws == '\n')) {
        last_non_ws--;
    }
    if (len > 0) {
        char last_char = *last_non_ws;
        if (last_char == '{' || last_char == '(' || last_char == '[' ||
            last_char == ',' || last_char == '.' || last_char == '+' ||
            last_char == '-' || last_char == '*' || last_char == '/' ||
            last_char == ':' || last_char == '=' || last_char == '<' ||
            last_char == '>' || last_char == '!' || last_char == '&') {
            looks_truncated = 1;
        }
    }

    // === 2. Проверка на \r и \0 внутри
    int has_cr = 0, has_null = 0;
    for (size_t i = 0; i < len; i++) {
        if (code[i] == '\r') has_cr = 1;
        if (code[i] == '\0' && i != len) has_null = 1; // \0 не в конце
    }

    // === 3. Подсчёт строк
    int lines = 1;
    for (size_t i = 0; i < len; i++) {
        if (code[i] == '\n') lines++;
    }

    add_log("JS eval: %d lines, %zu bytes", lines, len);
    if (has_cr) add_log("⚠ JS contains CR (\\r) — may cause parse errors");
    if (has_null) add_log("⚠ JS contains embedded \\0 — likely truncated!");
    if (looks_truncated) add_log("⚠ JS ends with suspicious character — possibly truncated");

    // === 4. Выполняем eval
    duk_push_lstring(ctx, code, len); // lstring чтобы не зависеть от \0
    duk_int_t ret = duk_peval(ctx);

    if (ret != DUK_EXEC_SUCCESS) {
        const char* error_msg = duk_safe_to_string(ctx, -1);
        add_log("JS ERROR: %s", error_msg);

        // Попытка извлечь номер строки
        int error_line = 0;
        const char* line_marker = strstr(error_msg, "line ");
        if (line_marker && sscanf(line_marker + 5, "%d", &error_line) == 1) {
            // Показываем контекст вокруг ошибки
            const char* start = code;
            const char* ptr = code;
            int cur_line = 1;
            const char* line_start = code;
            const char* lines_to_show[5] = {0};
            int line_offsets[5] = {0};

            // Ищем начало нужной строки
            while (*ptr && cur_line < error_line) {
                if (*ptr == '\n') {
                    cur_line++;
                    line_start = ptr + 1;
                }
                ptr++;
            }

            // Собираем контекст: 2 до, сама, 2 после
            const char* context_start[5];
            int context_line_nums[5];
            int context_count = 0;

            // Вернёмся назад до 2 строк
            const char* back = line_start;
            int back_lines = 0;
            while (back > code && back_lines < 2) {
                back--;
                if (*back == '\n') back_lines++;
            }
            if (*back != '\n') back = code; else back++;

            // Теперь вперёд до 5 строк
            const char* scan = back;
            int scan_line = error_line - back_lines;
            while (*scan && context_count < 5) {
                context_start[context_count] = scan;
                context_line_nums[context_count] = scan_line;
                while (*scan && *scan != '\n') scan++;
                if (*scan == '\n') scan++; // пропустить \n
                context_count++;
                scan_line++;
                if (scan_line > error_line + 2) break;
            }

            // Выводим контекст
            for (int i = 0; i < context_count; i++) {
                const char* line = context_start[i];
                size_t line_len = 0;
                const char* end = strchr(line, '\n');
                if (end) line_len = end - line;
                else line_len = strlen(line);

                // Обрезаем до 120 символов
                char clean_line[130];
                int to_copy = (line_len > 120) ? 120 : (int)line_len;
                strncpy(clean_line, line, to_copy);
                clean_line[to_copy] = '\0';

                if (context_line_nums[i] == error_line) {
                    add_log("→ %d: %s", context_line_nums[i], clean_line);
                } else {
                    add_log("  %d: %s", context_line_nums[i], clean_line);
                }
            }
        } else {
            // Если нет номера строки — покажем последние 3 строки
            add_log("No line number — showing last 3 lines:");
            const char* ptr = code + len - 1;
            int lines_back = 0;
            while (ptr > code && lines_back < 3) {
                if (*ptr == '\n') lines_back++;
                ptr--;
            }
            if (*ptr != '\n') ptr++; // пропустить частичную строку
            char snippet[512];
            size_t avail = (code + len) - ptr;
            if (avail > 511) avail = 511;
            strncpy(snippet, ptr, avail);
            snippet[avail] = '\0';
            add_log("JS tail:\n%s", snippet);
        }

        duk_pop(ctx);
    } else {
        if (duk_get_top(ctx) > 0) {
            const char* result = duk_safe_to_string(ctx, -1);
            add_log("JS result: %s", result ? result : "(null)");
            duk_pop(ctx);
        } else {
            add_log("JS executed (no return value)");
        }
    }
}

static duk_ret_t native_print(duk_context *ctx) {
    duk_push_string(ctx, " ");
    duk_insert(ctx, 0);
    duk_join(ctx, duk_get_top(ctx) - 1);
    const char* msg = duk_safe_to_string(ctx, -1);
    
    // Записываем в логи
    add_log("JS: %s", msg);
    
    // Также выводим в SDL_Log
    SDL_Log("%s\n", msg);
    return 0;
}

static duk_ret_t console_log_helper(duk_context *ctx) {
    duk_idx_t n = duk_get_top(ctx);
    duk_push_string(ctx, " ");
    duk_insert(ctx, 0);
    duk_join(ctx, n);
    const char* msg = duk_to_string(ctx, -1);
    
    // Определяем тип лога по имени функции
    const char* func_name = "log";
    if (duk_is_string(ctx, -3)) {  // Проверяем имя функции
        func_name = duk_to_string(ctx, -3);
    }
    
    add_log("console.%s: %s", func_name, msg);
    SDL_Log("JS: %s\n", msg);
    return 0;
}

void clear_logs() {
    for (int i = 0; i < log_line_count; i++) {
        free(log_lines[i]);
        log_lines[i] = NULL;
    }
    log_line_count = 0;
    dirty = 1;
}

static duk_ret_t duk__document_write(duk_context *ctx) {
    return console_log_helper(ctx);
}

static duk_ret_t duk__window_navigator(duk_context *ctx) {
    return console_log_helper(ctx);
}

static duk_ret_t _duc_helper_get_element_prop_n(duk_context *ctx) {
    const char* element_id = duk_safe_to_string(ctx, 0);
    if (!element_id) {
        duk_push_null(ctx);
        return 1;
    }
    
    HtmlElement *el = html_find_element(doc->root_element, element_id);
    if (!el) {
        duk_push_null(ctx);
        return 1;
    }
    
    int tag = duk_to_int(ctx, 1); // enum style_tag как число
    switch(tag){
        case COLOR: 
            duk_push_number(ctx, el->textcolor ? el->textcolor : 0x000000); 
            break;
        case BACKGROUND_COLOR: 
            duk_push_number(ctx, el->color ? el->color : 0xFFFFFF); 
            break;
        case DISPLAY:
            switch(el->display){
                case NONE: duk_push_string(ctx, "none"); break;
                case INLINE: duk_push_string(ctx, "inline"); break;
                case BLOCK: duk_push_string(ctx, "block"); break;
                default: duk_push_string(ctx, "inline");
            }
            break;
        case INNER_TEXT: 
            duk_push_string(ctx, el->child && el->child->text ? el->child->text : ""); 
            break;
        default:
            duk_push_null(ctx);
    }
    return 1;
}

static duk_ret_t _duc_helper_set_element_prop_n(duk_context *ctx) {
    const char* element_id = duk_safe_to_string(ctx, 0);
    HtmlElement *el = html_find_element(doc->root_element, element_id);
    if (!el) return 0;
    
    int tag = duk_to_int(ctx, 1);
    switch(tag){
        case COLOR:
            el->textcolor = hex2int(duk_safe_to_string(ctx, 2));
            if(!el->textcolor) el->textcolor = 1;
            break;
        case BACKGROUND_COLOR:
            el->color = hex2int(duk_safe_to_string(ctx, 2));
            break;
        case DISPLAY:
            remath_dom = 1;
            const char* disp = duk_safe_to_string(ctx, 2);
            if(strcmp(disp, "none") == 0) el->display = NONE;
            else if(strcmp(disp, "inline") == 0) el->display = INLINE;
            else if(strcmp(disp, "block") == 0) el->display = BLOCK;
            break;
        case INNER_TEXT:
            if(el->child) html_free_element(el->child);
            el->child = html_new_element(HTML_TAG_NONE, NULL, NULL, NULL, NULL, NULL);
            el->child->text = strdup(duk_safe_to_string(ctx, 2));
            remath_dom = 1;
            break;
    }
    return 0;
}

static void timer_callback(Timer* timer) {
    if (!timer || !timer->callback_key) return;

    // Получаем глобальный объект
    duk_push_global_object(ctx);

    // Пытаемся получить функцию по ключу
    if (duk_get_prop_string(ctx, -1, timer->callback_key)) {
        if (duk_is_function(ctx, -1)) {
            // Вызываем функцию БЕЗ this (просто как функцию)
            if (duk_pcall(ctx, 0) != 0) {
                SDL_Log("Timer callback error: %s", duk_safe_to_string(ctx, -1));
            }
            // Убираем результат или ошибку
            duk_pop(ctx);
        } else {
            SDL_Log("Timer callback is not a function: %s", timer->callback_key);
            duk_pop(ctx);
        }
    } else {
        SDL_Log("Timer callback not found: %s", timer->callback_key);
    }

    // Убираем глобальный объект
    duk_pop(ctx);
}

static duk_ret_t js_setTimeout(duk_context *ctx) {
    if (!duk_is_function(ctx, 0)) {
        return DUK_RET_TYPE_ERROR;
    }
    int delay = duk_to_int(ctx, 1);
    if (delay < 0) delay = 0;

    Timer* timer = (Timer*)malloc(sizeof(Timer));
    if (!timer) {
        duk_push_int(ctx, -1);
        return 1;
    }

    timer->id = next_timer_id++;
    timer->delay = delay;
    timer->repeat = 0;
    timer->last_fire = SDL_GetTicks();

    // Сохраняем функцию в глобальном объекте
    char key[32];
    snprintf(key, sizeof(key), "__timer_%d", timer->id);
    duk_dup(ctx, 0);  // Дублируем функцию
    duk_put_global_string(ctx, key);  // Сохраняем в глобальной области

    timer->callback_key = strdup(key);
    timer->next = timers;
    timers = timer;
    add_log("add timers: %d delay %d", timer->id, timer->delay);

    duk_push_int(ctx, timer->id);
    return 1;
}

static duk_ret_t js_setInterval(duk_context *ctx) {
    if (!duk_is_function(ctx, 0)) {
        return DUK_RET_TYPE_ERROR;
    }
    int delay = duk_to_int(ctx, 1);
    if (delay < 0) delay = 0;

    Timer* timer = (Timer*)malloc(sizeof(Timer));
    if (!timer) {
        duk_push_int(ctx, -1);
        return 1;
    }

    timer->id = next_timer_id++;
    timer->delay = delay;
    timer->repeat = 1;
    timer->last_fire = SDL_GetTicks();

    char key[32];
    snprintf(key, sizeof(key), "__timer_%d", timer->id);
    duk_dup(ctx, 0);
    duk_put_global_string(ctx, key);

    timer->callback_key = strdup(key);
    timer->next = timers;
    timers = timer;

    duk_push_int(ctx, timer->id);
    return 1;
}

static duk_ret_t js_clearTimeout(duk_context *ctx) {
    int id = duk_to_int(ctx, 0);
    Timer* prev = NULL;
    Timer* current = timers;

    while (current) {
        if (current->id == id) {
            // Удаляем из глобального объекта
            duk_push_global_object(ctx);
            duk_del_prop_string(ctx, -1, current->callback_key);
            duk_pop(ctx);  // Убираем глобальный объект

            free(current->callback_key);

            if (prev) {
                prev->next = current->next;
            } else {
                timers = current->next;
            }
            free(current);
            return 0;
        }
        prev = current;
        current = current->next;
    }
    return 0;
}

// setInterval и clearInterval используют ту же логику
static duk_ret_t js_clearInterval(duk_context *ctx) {
    return js_clearTimeout(ctx);
}

static duk_ret_t js_Date_now(duk_context *ctx) {
    duk_push_number(ctx, (double)SDL_GetTicks());
    return 1;
}

static duk_ret_t js_Math_random(duk_context *ctx) {
    duk_push_number(ctx, (double)rand() / (double)RAND_MAX);
    return 1;
}

static duk_ret_t js_parseInt(duk_context *ctx) {
    const char* str = duk_to_string(ctx, 0);
    int base = duk_is_undefined(ctx, 1) ? 10 : duk_to_int(ctx, 1);
    
    char* endptr;
    long val = strtol(str, &endptr, base);
    duk_push_int(ctx, (int)val);
    return 1;
}

static duk_ret_t js_parseFloat(duk_context *ctx) {
    const char* str = duk_to_string(ctx, 0);
    duk_push_number(ctx, atof(str));
    return 1;
}

void process_timers() {
    Uint32 current_ticks = SDL_GetTicks();
    Timer* current = timers;
    Timer* prev = NULL;

    while (current) {
        Timer* next = current->next;

        if ((int)(current_ticks - current->last_fire) >= current->delay) {
            //SDL_Log("Timer %d firing (delay: %d)", current->id, current->delay);
            //add_log("Timer %d firing (delay: %d)", current->id, current->delay);
            timer_callback(current);
            current->last_fire = current_ticks;

            if (!current->repeat) {
                // Удаляем одноразовый таймер
                duk_push_global_object(ctx);
                duk_del_prop_string(ctx, -1, current->callback_key);
                duk_pop(ctx);  // Убираем глобальный объект

                free(current->callback_key);

                if (prev) {
                    prev->next = current->next;
                } else {
                    timers = current->next;
                }
                free(current);
            }
        }

        prev = current;
        current = next;
    }
}

// JavaScript функции для Canvas
static duk_ret_t js_canvas_getContext(duk_context *ctx) {
    // Получаем canvas элемент (this)
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "id");  // Получаем ID элемента
    const char* id = duk_to_string(ctx, -1);
    duk_pop_2(ctx);  // Убираем this и id
    
    const char* context_type = duk_to_string(ctx, 0);
    
    HtmlElement* canvas = html_find_element(doc->root_element, id);
    if (!canvas || canvas->tag != HTML_TAG_CANVAS) {
        SDL_Log("Canvas element not found or not a canvas: %s", id);
        add_log("Canvas element not found or not a canvas: %s", id);
        duk_push_null(ctx);
        return 1;
    }
    
    if (strcmp(context_type, "2d") != 0) {
        SDL_Log("Only 2d context supported, requested: %s", context_type);
        add_log("Only 2d context supported, requested: %s", context_type);
        duk_push_null(ctx);
        return 1;
    }
    
    // Проверяем или создаем контекст
    CanvasContext* canvas_ctx = get_canvas_context_from_element(canvas);
    if (!canvas_ctx) {
        // Создаем новый контекст
        int width = canvas->w ? canvas->w : 300;
        int height = canvas->h ? canvas->h : 150;
        
        canvas_ctx = create_canvas_context(width, height);
        if (!canvas_ctx) {
            duk_push_null(ctx);
            return 1;
        }
        
        // Сохраняем указатель непосредственно (не как строку)
        HtmlAttrib* ctx_attrib = html_new_attrib(HTML_ATTRIB_CUSTOM, "__canvas_ctx", NULL);
        if (ctx_attrib) {
            // Сохраняем как указатель в user_data или специальное поле
            ctx_attrib->user_data = canvas_ctx;  // Добавьте это поле в структуру HtmlAttrib
            ctx_attrib->next = canvas->attrib;
            canvas->attrib = ctx_attrib;
        }
    }
    
    // Создаем объект контекста
    duk_push_object(ctx);
    
    // Сохраняем указатель на canvas_ctx в JavaScript объекте
    duk_push_pointer(ctx, canvas_ctx);
    duk_put_prop_string(ctx, -2, "__canvas_ptr");
    
    // Добавляем методы
    duk_push_c_function(ctx, js_canvas_fillRect, 4);
    duk_put_prop_string(ctx, -2, "fillRect");
    
    duk_push_c_function(ctx, js_canvas_strokeRect, 4);
    duk_put_prop_string(ctx, -2, "strokeRect");
    
    duk_push_c_function(ctx, js_canvas_clearRect, 4);
    duk_put_prop_string(ctx, -2, "clearRect");
    
    duk_push_c_function(ctx, js_canvas_fillText, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "fillText");
    
    duk_push_c_function(ctx, js_canvas_drawImage, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "drawImage");
    
    duk_push_c_function(ctx, js_canvas_beginPath, 0);
    duk_put_prop_string(ctx, -2, "beginPath");
    
    duk_push_c_function(ctx, js_canvas_closePath, 0);
    duk_put_prop_string(ctx, -2, "closePath");
    
    duk_push_c_function(ctx, js_canvas_moveTo, 2);
    duk_put_prop_string(ctx, -2, "moveTo");
    
    duk_push_c_function(ctx, js_canvas_lineTo, 2);
    duk_put_prop_string(ctx, -2, "lineTo");
    
    duk_push_c_function(ctx, js_canvas_stroke, 0);
    duk_put_prop_string(ctx, -2, "stroke");
    
    duk_push_c_function(ctx, js_canvas_fill, 0);
    duk_put_prop_string(ctx, -2, "fill");
    
    duk_push_c_function(ctx, js_canvas_arc, 6);
    duk_put_prop_string(ctx, -2, "arc");
    
    duk_push_c_function(ctx, js_canvas_rect, 4);
    duk_put_prop_string(ctx, -2, "rect");
    
    // Добавляем сеттеры/геттеры как свойства
    duk_push_c_function(ctx, js_canvas_set_fillStyle, 1);
    duk_put_prop_string(ctx, -2, "set_fillStyle");
    
    duk_push_c_function(ctx, js_canvas_set_strokeStyle, 1);
    duk_put_prop_string(ctx, -2, "set_strokeStyle");
    
    duk_push_c_function(ctx, js_canvas_set_lineWidth, 1);
    duk_put_prop_string(ctx, -2, "set_lineWidth");
    
    duk_push_c_function(ctx, js_canvas_set_font, 1);
    duk_put_prop_string(ctx, -2, "set_font");
    
    // Создаем геттеры и сеттеры для свойств
    duk_eval_string(ctx,
        "(function(ctx) {"
        "   Object.defineProperty(ctx, 'fillStyle', {"
        "       get: function() { return this._fillStyle || '#000000'; },"
        "       set: function(value) { this.set_fillStyle(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'strokeStyle', {"
        "       get: function() { return this._strokeStyle || '#000000'; },"
        "       set: function(value) { this.set_strokeStyle(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'lineWidth', {"
        "       get: function() { return this._lineWidth || 1; },"
        "       set: function(value) { this.set_lineWidth(value); }"
        "   });"
        "   Object.defineProperty(ctx, 'font', {"
        "       get: function() { return this._font || '12px sans-serif'; },"
        "       set: function(value) { this.set_font(value); }"
        "   });"
        "   return ctx;"
        "})"
    );
    
    duk_dup(ctx, -2); // Дублируем объект ctx
    duk_call(ctx, 1); // Вызываем функцию с объектом ctx как аргументом
    duk_replace(ctx, -2); // Заменяем старый объект новым
    
    // Сохраняем указатель на CanvasContext в JavaScript объекте
    duk_push_pointer(ctx, canvas_ctx);
    duk_put_prop_string(ctx, -2, "__canvas_ptr");
    
    // Также сохраняем ID элемента для отладки
    duk_push_string(ctx, id);
    duk_put_prop_string(ctx, -2, "__canvas_id");
    
    SDL_Log("Canvas context created successfully for id: %s", id);
    return 1;
}

static CanvasContext* get_canvas_context_from_element(HtmlElement* element) {
    if (!element || element->tag != HTML_TAG_CANVAS) {
        return NULL;
    }
    
    HtmlAttrib* attrib = element->attrib;
    while (attrib) {
        if (strcmp(attrib->key_name, "__canvas_ctx") == 0) {
            return (CanvasContext*)attrib->user_data;  // Используйте user_data вместо value
        }
        attrib = attrib->next;
    }
    return NULL;
}

static duk_ret_t js_canvas_fillRect(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    int w = duk_to_int(ctx, 2);
    int h = duk_to_int(ctx, 3);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_FILL_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return 0;
}

static duk_ret_t js_canvas_strokeRect(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    int w = duk_to_int(ctx, 2);
    int h = duk_to_int(ctx, 3);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_STROKE_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return 0;
}

static duk_ret_t js_canvas_clearRect(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    int w = duk_to_int(ctx, 2);
    int h = duk_to_int(ctx, 3);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_CLEAR_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return 0;
}

static duk_ret_t js_canvas_fillText(duk_context *ctx) {
    const char* text = duk_to_string(ctx, 0);
    int x = duk_to_int(ctx, 1);
    int y = duk_to_int(ctx, 2);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_FILL_TEXT;
        op->text = strdup(text);
        op->x = x;
        op->y = y;
        op->font = strdup(canvas_ctx->font);
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return 0;
}

static duk_ret_t js_canvas_drawImage(duk_context *ctx) {
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    int arg_count = duk_get_top(ctx);
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (!op) return 0;
    
    if (arg_count == 3) {
        const char* src = duk_to_string(ctx, 0);
        op->x = duk_to_int(ctx, 1);
        op->y = duk_to_int(ctx, 2);
        
        op->image = img_src_parse(src);
        if (op->image) {
            op->w = op->image->w;
            op->h = op->image->h;
        } else {
            op->w = 0;
            op->h = 0;
        }
    } else if (arg_count == 5) {
        const char* src = duk_to_string(ctx, 0);
        op->x = duk_to_int(ctx, 1);
        op->y = duk_to_int(ctx, 2);
        op->w = duk_to_int(ctx, 3);
        op->h = duk_to_int(ctx, 4);
        
        op->image = img_src_parse(src);
    }
    
    op->type = CANVAS_DRAW_IMAGE;
    op->next = NULL;
    canvas_add_operation(canvas_ctx, op);
    
    return 0;
}

static duk_ret_t js_canvas_beginPath(duk_context *ctx) {
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    canvas_ctx->path_open = 1;
    return 0;
}

static duk_ret_t js_canvas_closePath(duk_context *ctx) {
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    if (canvas_ctx->path_open) {
        CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
        if (op) {
            op->type = CANVAS_LINE_TO;
            op->x = canvas_ctx->path_start_x;
            op->y = canvas_ctx->path_start_y;
            op->next = NULL;
            canvas_add_operation(canvas_ctx, op);
        }
        canvas_ctx->path_open = 0;
    }
    
    return 0;
}

static duk_ret_t js_canvas_moveTo(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    if (!canvas_ctx->path_open) {
        canvas_ctx->path_start_x = x;
        canvas_ctx->path_start_y = y;
    }
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    return 0;
}

static duk_ret_t js_canvas_lineTo(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_LINE_TO;
        op->x = x;
        op->y = y;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    return 0;
}

static duk_ret_t js_canvas_stroke(duk_context *ctx) {
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    canvas_execute_operations_sdl(canvas_ctx);
    canvas_ctx->path_open = 0;
    
    return 0;
}

static duk_ret_t js_canvas_fill(duk_context *ctx) {
    // Для простоты пока не реализуем fill для сложных путей
    return 0;
}

static duk_ret_t js_canvas_arc(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    int radius = duk_to_int(ctx, 2);
    float start_angle = (float)duk_to_number(ctx, 3);
    float end_angle = (float)duk_to_number(ctx, 4);
    int counterclockwise = duk_to_boolean(ctx, 5);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_ARC;
        op->x = x - radius;
        op->y = y - radius;
        op->w = radius * 2;
        op->h = radius * 2;
        op->start_angle = start_angle;
        op->end_angle = end_angle;
        op->counterclockwise = counterclockwise;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    return 0;
}

static duk_ret_t js_canvas_rect(duk_context *ctx) {
    int x = duk_to_int(ctx, 0);
    int y = duk_to_int(ctx, 1);
    int w = duk_to_int(ctx, 2);
    int h = duk_to_int(ctx, 3);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    CanvasOperation* op = (CanvasOperation*)malloc(sizeof(CanvasOperation));
    if (op) {
        op->type = CANVAS_RECT;
        op->x = x;
        op->y = y;
        op->w = w;
        op->h = h;
        op->next = NULL;
        canvas_add_operation(canvas_ctx, op);
    }
    
    canvas_ctx->current_x = x;
    canvas_ctx->current_y = y;
    
    return 0;
}

static duk_ret_t js_canvas_set_fillStyle(duk_context *ctx) {
    const char* color = duk_to_string(ctx, 0);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    canvas_ctx->fill_color = parse_css_color(color);
    
    duk_push_this(ctx);
    duk_push_string(ctx, color);
    duk_put_prop_string(ctx, -2, "_fillStyle");
    duk_pop(ctx);
    
    return 0;
}

static duk_ret_t js_canvas_set_strokeStyle(duk_context *ctx) {
    const char* color = duk_to_string(ctx, 0);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    canvas_ctx->stroke_color = parse_css_color(color);
    
    duk_push_this(ctx);
    duk_push_string(ctx, color);
    duk_put_prop_string(ctx, -2, "_strokeStyle");
    duk_pop(ctx);
    
    return 0;
}

static duk_ret_t js_canvas_set_lineWidth(duk_context *ctx) {
    int width = duk_to_int(ctx, 0);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    canvas_ctx->line_width = width;
    
    duk_push_this(ctx);
    duk_push_int(ctx, width);
    duk_put_prop_string(ctx, -2, "_lineWidth");
    duk_pop(ctx);
    
    return 0;
}

static duk_ret_t js_canvas_set_font(duk_context *ctx) {
    const char* font = duk_to_string(ctx, 0);
    
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "__canvas_ptr");
    CanvasContext* canvas_ctx = (CanvasContext*)duk_to_pointer(ctx, -1);
    duk_pop_2(ctx);
    
    if (!canvas_ctx) return 0;
    
    strncpy(canvas_ctx->font, font, 63);
    canvas_ctx->font[63] = '\0';
    
    duk_push_this(ctx);
    duk_push_string(ctx, font);
    duk_put_prop_string(ctx, -2, "_font");
    duk_pop(ctx);
    
    return 0;
}

static duk_ret_t js_element_click(duk_context *ctx) {
    duk_push_this(ctx);
    duk_get_prop_string(ctx, -1, "id");
    const char* id = duk_to_string(ctx, -1);
    duk_pop_2(ctx);  // Убираем this и id
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    if (!el) return 0;
    
    // Ищем атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            // Выполняем JavaScript код
            duk_eval_string(ctx, attrib->value);
            duk_pop(ctx);  // Убираем результат
            break;
        }
        attrib = attrib->next;
    }
    
    return 0;
}

static duk_ret_t js_element_onclick_setter(duk_context *ctx) {
    const char* id = duk_to_string(ctx, 0);  // ID элемента
    const char* handler = duk_to_string(ctx, 1);  // JavaScript код обработчика
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    if (!el) return 0;
    
    // Ищем существующий атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    HtmlAttrib* onclick_attrib = NULL;
    
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            onclick_attrib = attrib;
            break;
        }
        attrib = attrib->next;
    }
    
    // Если атрибут не найден, создаем новый
    if (!onclick_attrib) {
        onclick_attrib = html_new_attrib(HTML_ATTRIB_ONCLICK, "onclick", handler);
        if (onclick_attrib) {
            onclick_attrib->next = el->attrib;
            el->attrib = onclick_attrib;
        }
    } else {
        // Обновляем существующий атрибут
        if (onclick_attrib->value) free(onclick_attrib->value);
        onclick_attrib->value = strdup(handler);
    }
    
    // Устанавливаем selectedId для навигации, если еще не установлен
    if (el->selectedId < 0) {
        el->selectedId = selectId++;
    }
    
    return 0;
}

static duk_ret_t js_element_onclick_getter(duk_context *ctx) {
    const char* id = duk_to_string(ctx, 0);
    
    HtmlElement* el = html_find_element(doc->root_element, id);
    if (!el) {
        duk_push_null(ctx);
        return 1;
    }
    
    // Ищем атрибут onclick
    HtmlAttrib* attrib = el->attrib;
    while (attrib) {
        if (attrib->key == HTML_ATTRIB_ONCLICK) {
            duk_push_string(ctx, attrib->value);
            return 1;
        }
        attrib = attrib->next;
    }
    
    duk_push_null(ctx);
    return 1;
}

static duk_ret_t js_getElementById(duk_context *ctx) {
    const char* id = duk_to_string(ctx, 0);
    HtmlElement* el = html_find_element(doc->root_element, id);
    
    if (!el) {
        duk_push_null(ctx);
        return 1;
    }
    
    // Создаем объект элемента
    duk_idx_t obj_idx = duk_push_object(ctx);
    
    // Сохраняем ID элемента
    duk_push_string(ctx, id);
    duk_put_prop_string(ctx, obj_idx, "id");
    
    // Добавляем свойство tagName
    const char* tagName = html_tag_to_string(el->tag);
    duk_push_string(ctx, tagName);
    duk_put_prop_string(ctx, obj_idx, "tagName");
    
    // Создаем объект style
    duk_push_object(ctx);
    duk_put_prop_string(ctx, obj_idx, "style");
    
    // Добавляем функции get/setProp напрямую
    duk_push_c_function(ctx, _duc_helper_get_element_prop_n, 2);
    duk_put_prop_string(ctx, obj_idx, "_getProp");
    
    duk_push_c_function(ctx, _duc_helper_set_element_prop_n, 3);
    duk_put_prop_string(ctx, obj_idx, "_setProp");
    
    // Добавляем функции для onclick
    duk_push_c_function(ctx, js_element_onclick_getter, 1);
    duk_put_prop_string(ctx, obj_idx, "_getOnClick");
    
    duk_push_c_function(ctx, js_element_onclick_setter, 2);
    duk_put_prop_string(ctx, obj_idx, "_setOnClick");
    
    // Теперь определяем геттеры и сеттеры через eval
    // Используем правильный метод: сначала помещаем код, затем вызываем
    duk_push_string(ctx, id);
    duk_put_prop_string(ctx, obj_idx, "__element_id");
    
    // Используем peval_string для выполнения кода
    duk_push_string(ctx, 
        "(function(el) {\n"
        "   // Создаем обертки для вызова методов\n"
        "   var elemId = el.__element_id;\n"
        "   \n"
        "   // Определяем innerText\n"
        "   Object.defineProperty(el, 'innerText', {\n"
        "       get: function() { return this._getProp(elemId, 4); },\n"
        "       set: function(value) { this._setProp(elemId, 4, value); }\n"
        "   });\n"
        "   \n"
        "   // Определяем textContent\n"
        "   Object.defineProperty(el, 'textContent', {\n"
        "       get: function() { return this._getProp(elemId, 4); },\n"
        "       set: function(value) { this._setProp(elemId, 4, value); }\n"
        "   });\n"
        "   \n"
        "   // Определяем свойства style\n"
        "   Object.defineProperty(el.style, 'color', {\n"
        "       get: function() { \n"
        "           var val = el._getProp(elemId, 1);\n"
        "           return '#' + val.toString(16).padStart(6, '0'); \n"
        "       },\n"
        "       set: function(value) { el._setProp(elemId, 1, value); }\n"
        "   });\n"
        "   \n"
        "   Object.defineProperty(el.style, 'backgroundColor', {\n"
        "       get: function() { \n"
        "           var val = el._getProp(elemId, 2);\n"
        "           return '#' + val.toString(16).padStart(6, '0'); \n"
        "       },\n"
        "       set: function(value) { el._setProp(elemId, 2, value); }\n"
        "   });\n"
        "   \n"
        "   Object.defineProperty(el.style, 'display', {\n"
        "       get: function() { return el._getProp(elemId, 3); },\n"
        "       set: function(value) { el._setProp(elemId, 3, value); }\n"
        "   });\n"
        "   \n"
        "   // Определяем onclick\n"
        "   Object.defineProperty(el, 'onclick', {\n"
        "       get: function() { return this._getOnClick(elemId); },\n"
        "       set: function(value) { this._setOnClick(elemId, value); }\n"
        "   });\n"
        "   \n"
        "   // Добавляем метод click\n"
        "   el.click = function() {\n"
        "       var handler = this.onclick;\n"
        "       if (handler && typeof handler === 'function') {\n"
        "           handler.call(this);\n"
        "       } else if (handler && typeof handler === 'string') {\n"
        "           try { eval(handler); } catch(e) { console.error(e); }\n"
        "       }\n"
        "   };\n"
        "   \n"
        "   // Обработка canvas\n"
        "   if (el.tagName && el.tagName.toLowerCase() === 'canvas') {\n"
        "       el.getContext = function(type) {\n"
        "           // Нужно будет имплементировать эту функцию\n"
        "           return null;\n"
        "       };\n"
        "       \n"
        "       Object.defineProperty(el, 'width', {\n"
        "           get: function() { return this._width || 300; },\n"
        "           set: function(value) { this._width = value; }\n"
        "       });\n"
        "       \n"
        "       Object.defineProperty(el, 'height', {\n"
        "           get: function() { return this._height || 150; },\n"
        "           set: function(value) { this._height = value; }\n"
        "       });\n"
        "   }\n"
        "   \n"
        "   return el;\n"
        "})"
    );
    
    // Компилируем функцию
    if (duk_peval(ctx) != 0) {
        const char* error = duk_safe_to_string(ctx, -1);
        add_log("JS eval error in getElementById: %s", error);
        duk_pop(ctx); // убираем ошибку
        return 1; // возвращаем объект как есть
    }
    
    // Теперь на вершине стека - функция, вызываем ее с элементом
    duk_dup(ctx, obj_idx); // Дублируем объект элемента
    if (duk_pcall(ctx, 1) != 0) {
        const char* error = duk_safe_to_string(ctx, -1);
        add_log("JS call error in getElementById: %s", error);
        duk_pop(ctx); // убираем ошибку
    } else {
        // Заменяем старый объект результатом
        duk_replace(ctx, obj_idx);
    }
    
    return 1;
}

void duk_console_init(duk_context *ctx) {
    duk_push_object(ctx);
    duk_push_c_function(ctx, console_log_helper, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "log");
    duk_push_c_function(ctx, console_log_helper, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "error");
    duk_push_c_function(ctx, console_log_helper, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "warn");
    duk_push_c_function(ctx, console_log_helper, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "info");
    duk_put_global_string(ctx, "console");
}

void duk_document_init(duk_context *ctx) {
    duk_push_object(ctx);
    duk_push_c_function(ctx, duk__document_write, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "write");
    
    duk_push_c_function(ctx, js_getElementById, 1);
    duk_put_prop_string(ctx, -2, "getElementById");
    
    duk_put_global_string(ctx, "document");
}

void duk_window_init(duk_context *ctx) {
    char buffer[256];
    duk_push_object(ctx);
    
    duk_push_c_function(ctx, js_setTimeout, 2);
    duk_put_prop_string(ctx, -2, "setTimeout");
    
    duk_push_c_function(ctx, js_setInterval, 2);
    duk_put_prop_string(ctx, -2, "setInterval");
    
    duk_push_c_function(ctx, js_clearTimeout, 1);
    duk_put_prop_string(ctx, -2, "clearTimeout");
    
    duk_push_c_function(ctx, js_clearInterval, 1);
    duk_put_prop_string(ctx, -2, "clearInterval");
    
    duk_push_object(ctx);
    duk_push_c_function(ctx, js_Date_now, 0);
    duk_put_prop_string(ctx, -2, "now");
    duk_put_prop_string(ctx, -2, "Date");
    
    duk_push_object(ctx);
    duk_push_c_function(ctx, js_Math_random, 0);
    duk_put_prop_string(ctx, -2, "random");
    duk_put_prop_string(ctx, -2, "Math");
    
    duk_push_c_function(ctx, js_parseInt, 2);
    duk_put_global_string(ctx, "parseInt");
    
    duk_push_c_function(ctx, js_parseFloat, 1);
    duk_put_global_string(ctx, "parseFloat");
    
    duk_push_c_function(ctx, duk__window_navigator, DUK_VARARGS);
    duk_put_prop_string(ctx, -2, "navigator");
    
    duk_put_global_string(ctx, "window");
    
    duk_get_global_string(ctx, "window");
	
	duk_get_prop_string(ctx, -1, "setTimeout");
	duk_put_global_string(ctx, "setTimeout");
	
	duk_get_prop_string(ctx, -1, "setInterval");
	duk_put_global_string(ctx, "setInterval");
	
	duk_get_prop_string(ctx, -1, "clearTimeout");
	duk_put_global_string(ctx, "clearTimeout");
	
	duk_get_prop_string(ctx, -1, "clearInterval");
	duk_put_global_string(ctx, "clearInterval");
	
	duk_pop(ctx); // убираем window
    
    sprintf(buffer,"window.navigator.language='%s'",language_name);
    duk_eval_string(ctx, buffer);
    
    srand(SDL_GetTicks());
}

int findHref(char *href){
    if(!href || href[0] != '#') return -1;
    href++;
    for(int i = 0; i < ahref_name_array_count; i++){
        if(!strcmp(href, ahref_name_array[i].name))
            return ahref_name_array[i].y;
    }
    return -1;
}

SDL_Surface* img_src_parse(const char *src){
    if (!src) {
        SDL_Log("img_src_parse: NULL source");
        return NULL;
    }
    
    char pngBase64head[] = "data:image/png;base64,";
    if(!strncmp(pngBase64head, src, strlen(pngBase64head))){
        SDL_Log("Found PNG base64 image (length: %zu)", strlen(src));
        int size = 0;
        char* img_src = base64_decode(src + strlen(pngBase64head), &size);
        if(!img_src){
            SDL_Log("base64_decode failed");
            return NULL;
        }
        
        SDL_Log("Base64 decoded: %d bytes", size);
        SDL_RWops* rw = SDL_RWFromMem(img_src, size);
        if(!rw){
            SDL_Log("SDL_RWFromMem failed");
            free(img_src);
            return NULL;
        }
        
        SDL_Surface* out_img = IMG_Load_RW(rw, 0);
        if(!out_img){
            SDL_Log("IMG_Load_RW failed: %s", IMG_GetError());
        } else {
            SDL_Log("Image loaded: %dx%d", out_img->w, out_img->h);
        }
        
        free(img_src);
        SDL_RWclose(rw);
        return out_img;
    }
    
    char jpgBase64head[] = "data:image/jpeg;base64,";
    char jpegBase64head[] = "data:image/jpg;base64,";
    char gifBase64head[] = "data:image/gif;base64,";
    char bmpBase64head[] = "data:image/bmp;base64,";
    
    const char* format = NULL;
    int offset = 0;
    
    if(!strncmp(jpgBase64head, src, strlen(jpgBase64head))){
        format = "JPEG";
        offset = strlen(jpgBase64head);
    } else if(!strncmp(jpegBase64head, src, strlen(jpegBase64head))){
        format = "JPEG";
        offset = strlen(jpegBase64head);
    } else if(!strncmp(gifBase64head, src, strlen(gifBase64head))){
        format = "GIF";
        offset = strlen(gifBase64head);
    } else if(!strncmp(bmpBase64head, src, strlen(bmpBase64head))){
        format = "BMP";
        offset = strlen(bmpBase64head);
    }
    
    if(format){
        SDL_Log("Found %s base64 image", format);
        int size = 0;
        char* img_src = base64_decode(src + offset, &size);
        if(img_src){
            SDL_RWops* rw = SDL_RWFromMem(img_src, size);
            SDL_Surface* out_img = IMG_Load_RW(rw, 0);
            if(out_img){
                SDL_Log("%s image loaded: %dx%d", format, out_img->w, out_img->h);
            }
            free(img_src);
            SDL_RWclose(rw);
            return out_img;
        }
    }
    
    SDL_Log("Unsupported image format or not base64");
    return NULL;
}

SDL_Color UintToColor(int color){
    return (SDL_Color){ (color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, 255 };
}

void init_text_cache() {
    for (int i = 0; i < TEXT_CACHE_SIZE; i++) {
        text_cache[i].text[0] = '\0';
        text_cache[i].surface = NULL;
        text_cache[i].bg_surface = NULL;
    }
    text_cache_count = text_cache_hits = text_cache_misses = 0;
}

void clear_text_cache() {
    for (int i = 0; i < text_cache_count; i++) {
        if (text_cache[i].surface) SDL_FreeSurface(text_cache[i].surface);
        if (text_cache[i].bg_surface) SDL_FreeSurface(text_cache[i].bg_surface);
    }
    text_cache_count = 0;
}

SDL_Surface* find_in_image_cache(const char* src) {
    ImageCacheEntry* entry = image_cache;
    while (entry) {
        if (entry->src && strcmp(entry->src, src) == 0) {
            return entry->surface;
        }
        entry = entry->next;
    }
    return NULL;
}

void add_to_image_cache(const char* src, SDL_Surface* surface) {
    if (image_cache_count > 10) {
        ImageCacheEntry* entry = image_cache;
        if (entry) {
            image_cache = entry->next;
            if (entry->src) free(entry->src);
            if (entry->surface) SDL_FreeSurface(entry->surface);
            free(entry);
            image_cache_count--;
        }
    }
    
    ImageCacheEntry* new_entry = (ImageCacheEntry*)malloc(sizeof(ImageCacheEntry));
    if (new_entry) {
        new_entry->src = strdup(src);
        new_entry->surface = surface;
        new_entry->width = surface ? surface->w : 0;
        new_entry->height = surface ? surface->h : 0;
        new_entry->next = image_cache;
        image_cache = new_entry;
        image_cache_count++;
    }
}

SDL_Surface* find_in_text_cache(const char* text, int fontsize, int color, int bg_color) {
    for (int i = 0; i < text_cache_count; i++) {
        if (text_cache[i].fontsize == fontsize &&
            text_cache[i].color == color &&
            text_cache[i].bg_color == bg_color &&
            strcmp(text_cache[i].text, text) == 0) {
            text_cache_hits++;
            return text_cache[i].surface;
        }
    }
    text_cache_misses++;
    return NULL;
}

void add_to_text_cache(const char* text, int fontsize, int color, int bg_color, 
                      SDL_Surface* surface) {
    if (text_cache_count >= TEXT_CACHE_SIZE) {
        int remove = 64;
        if (remove > TEXT_CACHE_SIZE) remove = TEXT_CACHE_SIZE / 4;
        for (int i = 0; i < remove; i++) {
            if (text_cache[i].surface) SDL_FreeSurface(text_cache[i].surface);
            if (text_cache[i].bg_surface) SDL_FreeSurface(text_cache[i].bg_surface);
        }
        for (int i = remove; i < TEXT_CACHE_SIZE; i++) {
            text_cache[i - remove] = text_cache[i];
        }
        text_cache_count -= remove;
    }
    
    strncpy(text_cache[text_cache_count].text, text, 255);
    text_cache[text_cache_count].text[255] = '\0';
    text_cache[text_cache_count].fontsize = fontsize;
    text_cache[text_cache_count].color = color;
    text_cache[text_cache_count].bg_color = bg_color;
    text_cache[text_cache_count].surface = surface;
    text_cache[text_cache_count].bg_surface = NULL;
    text_cache_count++;
}

void clear_image_cache() {
    ImageCacheEntry* entry = image_cache;
    while (entry) {
        ImageCacheEntry* next = entry->next;
        if (entry->src) free(entry->src);
        if (entry->surface) SDL_FreeSurface(entry->surface);
        free(entry);
        entry = next;
    }
    image_cache = NULL;
    image_cache_count = 0;
}

SDL_Surface* render_text_cached(const char* text, TTF_Font* font, int fontsize_idx, 
                               int text_color, int bg_color) {
    SDL_Surface* surface = find_in_text_cache(text, fontsize_idx, text_color, bg_color);
    if (surface) return surface;
    
    SDL_Color sdl_color = UintToColor(text_color);
    surface = TTF_RenderUTF8_Blended(font, text, sdl_color);
    if (surface) add_to_text_cache(text, fontsize_idx, text_color, bg_color, surface);
    return surface;
}

int draw_x;
int line_height = 14;

void draw_border(HtmlElement* element, int draw_y, int element_height) {
    const char* border_color_str = get_style_value(element, "border-color");
    const char* border_width_str = get_style_value(element, "border-width");
    const char* border_style_str = get_style_value(element, "border-style");
    
    if (border_color_str && border_width_str) {
        int border_color = parse_css_color(border_color_str);
        int border_width = parse_css_length(border_width_str);
        int border_style = border_style_str ? (strcmp(border_style_str, "solid") == 0 ? 1 : 0) : 1;
        
        if (border_width > 0 && border_style) {
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y,
                element->w ? element->w : DEVICE_WIDTH - element->x,
                border_width
            }, border_color);
            
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y + element_height - border_width,
                element->w ? element->w : DEVICE_WIDTH - element->x,
                border_width
            }, border_color);
            
            SDL_FillRect(screen, &(SDL_Rect){
                element->x,
                draw_y - global_y,
                border_width,
                element_height
            }, border_color);
            
            if (element->w) {
                SDL_FillRect(screen, &(SDL_Rect){
                    element->x + element->w - border_width,
                    draw_y - global_y,
                    border_width,
                    element_height
                }, border_color);
            }
        }
    }
}
 
int html_math_dom_element(HtmlElement *parent, HtmlElement *element, int first_run, unsigned int draw_y) {
    if (!element) return draw_y;
    while (element) {
        HtmlElement *sibling = element->sibling;

        // Обработка SCRIPT и STYLE только при first_run
        if (first_run) {
            if (element->tag == HTML_TAG_SCRIPT && element->child && element->child->text) {
                add_log("SCRIPT tag found, child=%p, text=%s",
                    (void*)element->child,
                    element->child ? element->child->text : "(null)");

                char* normalized_js = normalize_js_string(element->child->text);
                if (normalized_js) {
                    duk_peval_string_logged(ctx, normalized_js);
                    free(normalized_js);
                } else {
                    duk_peval_string_logged(ctx, element->child->text);
                }
                add_log("Executed JavaScript from <script>");
                element->display = NONE; // Скрываем из отрисовки
                // НЕ вызываем continue — просто пропускаем остальную обработку
            } else if (element->tag == HTML_TAG_STYLE && element->child && element->child->text) {
                parse_css_from_style_tag(element->child->text);
                add_log("parse CSS from <style>");
                element->display = NONE;
            }
        }

        // Обрабатываем только видимые элементы (display != NONE)
        if (element->display != NONE) {
            if (first_run) {
                element->fontsize = parent->fontsize;
                element->textcolor = parent->textcolor;
                element->color = parent->color;
                apply_css_styles(element);
            }

            const char* margin_top = get_style_value(element, "margin-top");
            if (margin_top) {
                draw_y += parse_css_length(margin_top);
            }
            const char* margin_left = get_style_value(element, "margin-left");
            if (margin_left) {
                element->x = parent->x + parse_css_length(margin_left);
            } else {
                element->x = parent->x;
            }
            element->y = draw_y;
            element->h = 0;
            element->display = parent->display;

            switch (element->tag) {
                case HTML_TAG_NONE:
                    element->display = INLINE;
                    break;
                case HTML_TAG_HEAD:
                case HTML_TAG_SCRIPT:
                    element->display = NONE;
                    break;
                case HTML_TAG_STYLE:
                    element->display = NONE;
                    break;
                case HTML_TAG_BR:
                    draw_y += line_height;
                    break;
                case HTML_TAG_DIV:
                    element->display = BLOCK;
                    break;
                case HTML_TAG_UL:
                    element->x += 20;
                    break;
                case HTML_TAG_H1:
                    element->fontsize = 4; draw_y += 10; element->h += line_height; break;
                case HTML_TAG_H2:
                    element->fontsize = 3; draw_y += 8; element->h += 10; break;
                case HTML_TAG_H3:
                    element->fontsize = 2; draw_y += 6; element->h += 6; break;
                case HTML_TAG_H4:
                    element->fontsize = 1; draw_y += 2; element->h += 2; break;
                case HTML_TAG_TABLE:
                    element->display = BLOCK;
                    if (current_table) {
                        free_table_context(current_table);
                    }
                    current_table = create_table_context();
                    if (current_table) {
                        current_table->table_x = element->x;
                        current_table->table_y = draw_y;
                    }
                    break;
                case HTML_TAG_TR:
                    element->display = BLOCK;
                    if (current_table) {
                        current_table->current_row++;
                        current_table->current_col = 0;
                        current_table->current_row_element = element;
                    }
                    break;
                case HTML_TAG_TD:
                case HTML_TAG_TH:
                    element->display = INLINE;
                    if (current_table) {
                        current_table->current_col++;
                        int col_width = 100;
                        if (element->child && element->child->text) {
                            int w, h;
                            TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &w, &h);
                            col_width = w + 10;
                        }
                        if (current_table->current_col > current_table->col_count) {
                            table_add_column(current_table, col_width);
                        } else {
                            TableColumn* col = current_table->columns;
                            int i = 0;
                            while (col && i < current_table->current_col - 1) {
                                col = col->next;
                                i++;
                            }
                            if (col && col_width > col->width) {
                                col->width = col_width;
                            }
                        }
                    }
                    break;
                case HTML_TAG_CANVAS: {
                    element->display = INLINE;
                    HtmlAttrib *attrib = element->attrib;
                    int width = 300, height = 150;
                    while (attrib) {
                        if (strcmp(attrib->key_name, "width") == 0) {
                            width = atoi(attrib->value);
                            element->w = width;
                        } else if (strcmp(attrib->key_name, "height") == 0) {
                            height = atoi(attrib->value);
                            element->h = height;
                        }
                        attrib = attrib->next;
                    }
                    if (element->w == 0) element->w = width;
                    if (element->h == 0) element->h = height;
                    if (first_run) {
                        CanvasContext* canvas_ctx = create_canvas_context(element->w, element->h);
                        if (canvas_ctx) {
                            HtmlAttrib* ctx_attrib = html_new_attrib(HTML_ATTRIB_CUSTOM, "__canvas_ctx", NULL);
                            if (ctx_attrib) {
                                ctx_attrib->user_data = canvas_ctx; // предполагается, что в HtmlAttrib есть поле user_data
                                ctx_attrib->next = element->attrib;
                                element->attrib = ctx_attrib;
                            }
                        }
                    }
                    draw_y += element->h + 4;
                    break;
                }
                case HTML_TAG_IMG: {
                    element->display = INLINE;
                    HtmlAttrib *attrib = element->attrib;
                    while (attrib) {
                        if (attrib->key == HTML_ATTRIB_SRC) {
                            SDL_Surface* imc = find_in_image_cache(attrib->value);
                            if (!imc) {
                                imc = img_src_parse(attrib->value);
                                if (imc) {
                                    add_to_image_cache(attrib->value, imc);
                                    element->h = imc->h;
                                    element->w = imc->w;
                                } else {
                                    element->h = 20;
                                    element->w = 20;
                                }
                            } else {
                                element->h = imc->h;
                                element->w = imc->w;
                            }
                        }
                        attrib = attrib->next;
                    }
                    break;
                }
                case HTML_TAG_BUTTON: {
                    element->display = INLINE;
                    element->textcolor = 0xFFFFFF;
                    element->color = 0x808080;
                    if (element->child && element->child->text) {
                        int text_w, text_h;
                        TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &text_w, &text_h);
                        element->h = text_h + 10;
                        element->w = text_w + 20;
                    } else {
                        element->h = 30;
                        element->w = 100;
                    }
                    HtmlAttrib *attrib = element->attrib;
                    while (attrib) {
                        if (attrib->key == HTML_ATTRIB_ONCLICK) {
                            element->selectedId = selectId++;
                        }
                        attrib = attrib->next;
                    }
                    draw_y += element->h + 4;
                    break;
                }
                case HTML_TAG_A:
                    element->textcolor = 0x0000EE;
                    element->display = INLINE;
                    {
                        HtmlAttrib *attrib = element->attrib;
                        while (attrib) {
                            if (attrib->key == HTML_ATTRIB_NAME) {
                                ahref_name_array[ahref_name_array_count].name = attrib->value;
                                ahref_name_array[ahref_name_array_count++].y = element->y;
                            } else if (attrib->key == HTML_ATTRIB_HREF) {
                                element->selectedId = selectId++;
                            }
                            attrib = attrib->next;
                        }
                    }
                    break;
                default:
                    break;
            }

            // Обработка атрибутов
            {
                HtmlAttrib *attrib = element->attrib;
                while (attrib) {
                    if (strcmp(attrib->key_name, "color") == 0) {
                        element->textcolor = hex2int(attrib->value);
                        if (!element->textcolor) element->textcolor = 1;
                    } else if (strcmp(attrib->key_name, "bgcolor") == 0) {
                        element->color = hex2int(attrib->value);
                    } else if (strcmp(attrib->key_name, "style") == 0) {
                        char* style_copy = strdup(attrib->value);
                        char* token = strtok(style_copy, ";");
                        while (token) {
                            char* prop = token;
                            char* value = strchr(token, ':');
                            if (value) {
                                *value = '\0';
                                value++;
                                while (*prop == ' ') prop++;
                                if (value[0] && value[strlen(value)-1] == ' ')
                                    value[strlen(value)-1] = '\0';
                                HtmlAttrib* style_attrib = html_new_attrib(HTML_ATTRIB_STYLE, prop, value);
                                if (style_attrib) {
                                    style_attrib->next = element->attrib;
                                    element->attrib = style_attrib;
                                }
                            }
                            token = strtok(NULL, ";");
                        }
                        free(style_copy);
                    } else if (attrib->key == HTML_ATTRIB_ID) {
                        element->id = attrib->value;
                    }
                    attrib = attrib->next;
                }
            }

            // Установка позиций inline/block
            if (element->display == INLINE) {
                element->x = draw_x;
            } else {
                draw_x = element->x;
            }

            // Расчёт высоты текста
            if (element->text && element->tag == HTML_TAG_NONE) {
                int i = 0, charw, charh;
                char char_buffer[5];
                int current_line_height = line_height;
                int temp_draw_x = element->x;
                int temp_draw_y = draw_y;
                while (element->text[i]) {
                    int len = 0;
                    if ((element->text[i] & 0xF0) == 0xF0) len = 4;
                    else if ((element->text[i] & 0xE0) == 0xE0) len = 3;
                    else if ((element->text[i] & 0xC0) == 0xC0) len = 2;
                    else if (element->text[i] >= 0x20) len = 1;
                    if (len) {
                        strncpy(char_buffer, &element->text[i], len);
                        char_buffer[len] = '\0';
                        TTF_SizeUTF8(fonts[element->fontsize], char_buffer, &charw, &charh);
                        if (charh > current_line_height) current_line_height = charh;
                        if (temp_draw_x + charw >= DEVICE_WIDTH - 30) {
                            temp_draw_x = element->x;
                            temp_draw_y += current_line_height + 4;
                            current_line_height = charh;
                        }
                        temp_draw_x += charw;
                        i += len;
                    } else i++;
                }
                draw_y = temp_draw_y + current_line_height;
            } else if (element->tag == HTML_TAG_IMG) {
                draw_y += (element->h > 0) ? element->h + 4 : 24;
            } else if (element->tag == HTML_TAG_CANVAS) {
                draw_y += element->h + 4;
            }

            // Рекурсивная обработка детей
            int child_draw_y = html_math_dom_element(element, element->child, first_run, draw_y);
            element->h = child_draw_y - element->y;
            draw_y = child_draw_y;
        }

        // Обработка нижнего отступа
        if (element->display == BLOCK) {
            const char* margin_bottom = get_style_value(element, "margin-bottom");
            if (margin_bottom) {
                draw_y += parse_css_length(margin_bottom);
            } else {
                draw_y += line_height;
            }
            draw_x = element->x;
        }

        element = sibling;
    }
    return draw_y;
}

int html_draw_dom_element(HtmlElement *parent, HtmlElement *element, unsigned int start_draw_y) {
    if(!element) return start_draw_y;
    unsigned int draw_y = start_draw_y;
    
    while(element) {
        HtmlElement *sibling = element->sibling;
        
        if(element->y > (global_y + 272)) return draw_y;
        
        if(element->y + element->h > global_y && element->display != 0){
            draw_y = element->y;
            int bg_color = parent->color;
            int text_color = parent->textcolor;
            int original_draw_y = draw_y;
            int cell_height = 20;
            
            int padding_top = 0;
            const char* padding_top_str = get_style_value(element, "padding-top");
            if (padding_top_str) {
                padding_top = parse_css_length(padding_top_str);
            }
            
            int padding_left = 0;
            const char* padding_left_str = get_style_value(element, "padding-left");
            if (padding_left_str) {
                padding_left = parse_css_length(padding_left_str);
            }
            
            switch(element->tag){
                case HTML_TAG_LI:
                    {
                        SDL_Surface* surface = render_text_cached("*", fonts[0], 0, text_color, bg_color);
                        if(surface) SDL_BlitSurface(surface, NULL, screen, &(SDL_Rect){element->x - 10, draw_y - global_y});
                    }
                    break;
                case HTML_TAG_CANVAS: {
    				CanvasContext* canvas_ctx = get_canvas_context_from_element(element);
    				
    				if (canvas_ctx && canvas_ctx->surface) {
        				// Выполняем операции если нужно перерисовать
        				if (canvas_ctx->needs_redraw) {
            				canvas_execute_operations_sdl(canvas_ctx);
            				canvas_ctx->needs_redraw = 0;
        				}
        				
        				SDL_Rect dest = {element->x, element->y - global_y, element->w, element->h};
        				SDL_BlitSurface(canvas_ctx->surface, NULL, screen, &dest);
        				
        				// Рисуем рамку если указана
        				const char* border_style = get_style_value(element, "border-style");
        				if (border_style && strcmp(border_style, "solid") == 0) {
            				SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y-1, 
                                           				element->w+2, 1}, 0x000000);
            				SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y-1, 
                                           				1, element->h+2}, 0x000000);
            				SDL_FillRect(screen, &(SDL_Rect){element->x+element->w, element->y - global_y-1, 
                                           				1, element->h+2}, 0x000000);
            				SDL_FillRect(screen, &(SDL_Rect){element->x-1, element->y - global_y+element->h, 
                                           				element->w+2, 1}, 0x000000);
        				}
    				} else {
        				// Рисуем серый фон для canvas (если нет контекста)
        				SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y, 
                                       				element->w, element->h}, 0xF0F0F0);
        				// Рисуем текст "Canvas"
        				TTF_Font* font = fonts[2];
        				SDL_Color color = {100, 100, 100, 255};
        				SDL_Surface* text_surface = TTF_RenderUTF8_Blended(font, "Canvas", color);
        				if (text_surface) {
            				SDL_Rect dest = {
                				element->x + (element->w - text_surface->w)/2,
                				element->y - global_y + (element->h - text_surface->h)/2,
                				text_surface->w,
                				text_surface->h
            				};
            				SDL_BlitSurface(text_surface, NULL, screen, &dest);
            				SDL_FreeSurface(text_surface);
        				}
    				}
    				draw_y += element->h + 4;
    				break;
				}
                case HTML_TAG_IMG: {
                    HtmlAttrib *attrib = element->attrib;
                    while(attrib){
                        if (attrib->key == HTML_ATTRIB_SRC) {
                            SDL_Surface* imc = find_in_image_cache(attrib->value);
                            if(imc){
                                SDL_BlitSurface(imc, NULL, screen, &(SDL_Rect){element->x, draw_y - global_y});
                                draw_y += imc->h + 4;
                            } else {
                                SDL_Rect rect = {element->x, draw_y - global_y, 20, 20};
                                SDL_FillRect(screen, &rect, 0x888888);
                                SDL_FillRect(screen, &(SDL_Rect){element->x+2, draw_y - global_y+2, 16, 16}, 0xCCCCCC);
                                draw_y += 24;
                            }
                        }
                        attrib = attrib->next;
                    }
                    break;
                }
				case HTML_TAG_BUTTON:
    				if(element->selectedId >= 0){
        				if(startViewSelectedId < 0) startViewSelectedId = element->selectedId;
        				endViewSelectedId = element->selectedId;
        				if(element->selectedId == selectElement) drawCursor = 1;
    				}
    				
    				{
        				HtmlAttrib *attrib = element->attrib;
        				while(attrib){
            				if(attrib->key == HTML_ATTRIB_ONCLICK && element->selectedId == selectElement)
                				selectedOnClick = attrib->value;
            				attrib = attrib->next;
        				}
    				}
    				
    				// Используем сохраненные размеры кнопки из html_math_dom_element
    				int button_width = element->w ? element->w : 100;
    				int button_height = element->h ? element->h : 30;
    				
    				// Если текст изменился, пересчитываем размеры
    				if (element->child && element->child->text) {
        				int text_w, text_h;
        				TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &text_w, &text_h);
        				
        				// Если размеры не были установлены или текст изменился
        				if (element->w == 0 || element->h == 0) {
            				button_width = text_w + 20;
            				button_height = text_h + 10;
            				element->w = button_width;
            				element->h = button_height;
        				}
    				}
    				
    				// Получаем скругление углов
    				int borderRadius = 0;
    				const char* borderRadiusStr = get_style_value(element, "border-radius");
    				if (borderRadiusStr) {
        				borderRadius = parse_css_length(borderRadiusStr);
    				}
    				
    				// Проверяем границы экрана
    				if (element->x + button_width > DEVICE_WIDTH) {
        				button_width = DEVICE_WIDTH - element->x - 5;
    				}
    				
    				// Рисуем фон кнопки
    				SDL_Rect buttonRect = {
        				element->x,
        				element->y - global_y,
        				button_width,
        				button_height
    				};
    				
    				// Простая реализация - прямоугольник без скругления
    				SDL_FillRect(screen, &buttonRect, element->color);
    				
    				// Рисуем тень/обводку для эффекта кнопки
    				if (drawCursor) {
        				// Подсветка выбранной кнопки - более толстая рамка
        				SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y-2, 
                                        				button_width+4, 3}, 0x0000FF);
        				SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y+button_height-1, 
                                        				button_width+4, 3}, 0x0000FF);
        				SDL_FillRect(screen, &(SDL_Rect){element->x-2, element->y - global_y, 
                                        				3, button_height}, 0x0000FF);
        				SDL_FillRect(screen, &(SDL_Rect){element->x+button_width-1, element->y - global_y, 
                                        				3, button_height}, 0x0000FF);
    				} else {
        				// 3D эффект для кнопки - темнее снизу и справа, светлее сверху и слева
        				// Нижняя тень
        				SDL_FillRect(screen, &(SDL_Rect){element->x+1, element->y - global_y+button_height-2, 
                                        				button_width-2, 2}, 0x404040);
        				// Правая тень
        				SDL_FillRect(screen, &(SDL_Rect){element->x+button_width-2, element->y - global_y+1, 
                                        				2, button_height-2}, 0x404040);
        				// Верхний свет
        				SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y, 
                                        				button_width, 1}, 0xFFFFFF);
        				SDL_FillRect(screen, &(SDL_Rect){element->x, element->y - global_y+1, 
                                        				1, button_height-2}, 0xFFFFFF);
    				}
    				
    				// Рисуем текст кнопки по центру
    				if (element->child && element->child->text) {
        				SDL_Surface* textSurface = render_text_cached(element->child->text, fonts[element->fontsize],
                                                     				element->fontsize, element->textcolor, element->color);
        				if (textSurface) {
            				int text_x = element->x + (button_width - textSurface->w) / 2;
            				int text_y = element->y - global_y + (button_height - textSurface->h) / 2;
            				SDL_BlitSurface(textSurface, NULL, screen, &(SDL_Rect){text_x, text_y});
        				}
    				}
    				
    				// Не увеличиваем draw_y здесь - это уже сделано в html_math_dom_element
    				break;
                case HTML_TAG_A:
                    if(element->selectedId >= 0){
                        if(startViewSelectedId < 0) startViewSelectedId = element->selectedId;
                        endViewSelectedId = element->selectedId;
                        if(element->selectedId == selectElement) drawCursor = 1;
                    }
                    {
                        HtmlAttrib *attrib = element->attrib;
                        while(attrib){
                            if(attrib->key == HTML_ATTRIB_HREF && element->selectedId == selectElement)
                                selectedHref = attrib->value;
                            else if(attrib->key == HTML_ATTRIB_ONCLICK && element->selectedId == selectElement)
                                selectedOnClick = attrib->value;
                            attrib = attrib->next;
                        }
                    }
                    break;
                case HTML_TAG_TABLE:
                    if (current_table) {
                        current_table->table_x = element->x;
                        current_table->table_y = draw_y;
                    }
                    break;
                case HTML_TAG_TR:
                    if (current_table) {
                        draw_x = current_table->table_x;
                    } else {
                        draw_x = element->x;
                    }
                    cell_height = 20;
                    break;
                case HTML_TAG_TD:
                case HTML_TAG_TH:
                    if (current_table) {
                        int col_index = 0;
                        HtmlElement* cell = current_table->current_row_element;
                        if (cell) {
                            HtmlElement* temp_cell = cell->child;
                            while (temp_cell && temp_cell != element) {
                                col_index++;
                                temp_cell = temp_cell->sibling;
                            }
                            
                            int col_width = get_table_column_width(current_table, col_index);
                            
                            int content_height = line_height;
                            if (element->child && element->child->text) {
                                int w, h;
                                TTF_SizeUTF8(fonts[element->fontsize], element->child->text, &w, &h);
                                int text_lines = 1;
                                if (w > col_width - 10) {
                                    text_lines = (w / (col_width - 10)) + 1;
                                }
                                content_height = text_lines * line_height;
                            }
                            if (content_height > cell_height) {
                                cell_height = content_height;
                            }
                            
                            int cell_padding_left = 5;
                            int cell_padding_top = 2;
                            
                            SDL_Rect cell_rect = {
                                draw_x,
                                draw_y - global_y,
                                col_width,
                                cell_height
                            };
                            
                            int cell_bg_color = (element->tag == HTML_TAG_TH) ? 0xDDDDDD : 0xFFFFFF;
                            if (element->color != 0) cell_bg_color = element->color;
                            else if (bg_color != 0xFFFFFF) cell_bg_color = bg_color;
                            
                            SDL_FillRect(screen, &cell_rect, cell_bg_color);
                            
                            draw_border(element, draw_y, cell_height);
                            
                            element->x = draw_x + cell_padding_left + padding_left;
                            element->y = draw_y + cell_padding_top + padding_top;
                            draw_x += col_width;
                            
                            if (element->tag == HTML_TAG_TH) {
                                element->fontsize = (element->fontsize < 4) ? element->fontsize + 1 : 4;
                            }
                        }
                    }
                    break;
                default:
                    if (element->h > 0) {
                        draw_border(element, draw_y, element->h);
                    }
                    break;
            }
            
            if(element->text && element->tag == HTML_TAG_NONE && parent->tag != HTML_TAG_BUTTON){
                int i = 0, local_draw_x = element->x + padding_left;
                int local_draw_y = draw_y + padding_top;
                char char_buffer[5];
                int current_line_height = line_height;
                
                if(drawCursor){
                    bg_color = 0x2585;
                    text_color = 0xffff;
                }
                
                while(element->text[i]){
                    int len = 0;
                    if ((element->text[i] & 0xF0) == 0xF0) len = 4;
                    else if ((element->text[i] & 0xE0) == 0xE0) len = 3;
                    else if ((element->text[i] & 0xC0) == 0xC0) len = 2;
                    else if(element->text[i] >= 0x20) len = 1;
                    
                    if(len){
                        strncpy(char_buffer, &element->text[i], len);
                        char_buffer[len] = '\0';
                        
                        SDL_Surface* surface = render_text_cached(char_buffer, fonts[element->fontsize], 
                                                                 element->fontsize, text_color, bg_color);
                        if(surface){
                            int charw = surface->w;
                            int charh = surface->h;
                            
                            if (charh > current_line_height) {
                                current_line_height = charh;
                            }
                            
                            if (current_table && (element->tag == HTML_TAG_TD || element->tag == HTML_TAG_TH)) {
                                int col_index = 0;
                                HtmlElement* temp_cell = current_table->current_row_element;
                                if (temp_cell) {
                                    HtmlElement* cell = temp_cell->child;
                                    while (cell && cell != element) {
                                        col_index++;
                                        cell = cell->sibling;
                                    }
                                    int col_width = get_table_column_width(current_table, col_index);
                                    
                                    if (local_draw_x + charw - element->x > col_width - 10) {
                                        local_draw_x = element->x;
                                        local_draw_y += current_line_height + 2;
                                        if (local_draw_y - draw_y + current_line_height > cell_height) {
                                            cell_height = local_draw_y - draw_y + current_line_height;
                                        }
                                    }
                                }
                            } else {
                                if(local_draw_x + charw >= DEVICE_WIDTH - 30){
                                    local_draw_x = element->x;
                                    local_draw_y += current_line_height + 4;
                                }
                            }
                            
                            if(bg_color != 0xFFFFFF){
                                SDL_FillRect(screen, &(SDL_Rect){local_draw_x, local_draw_y - global_y - 1,
                                                               charw + 1, charh + 3}, bg_color);
                            }
                            SDL_BlitSurface(surface, NULL, screen, &(SDL_Rect){local_draw_x, local_draw_y - global_y});
                            local_draw_x += charw;
                        }
                        i += len;
                    } else i++;
                }
                
                if (current_table && (element->tag == HTML_TAG_TD || element->tag == HTML_TAG_TH)) {
                    if (original_draw_y == draw_y) {
                        draw_y += cell_height + 2;
                    }
                } else {
                    if (original_draw_y == draw_y) {
                        draw_y = local_draw_y + current_line_height + 2;
                    }
                }
            }
            
            else if(element->tag == HTML_TAG_BUTTON || element->tag == HTML_TAG_IMG || element->tag == HTML_TAG_CANVAS) {
    			// Для кнопок, изображений и canvas проверяем, помещаются ли они в строку
    			if(draw_x + element->w >= DEVICE_WIDTH - 30){
        			draw_x = element->x;
        			draw_y += element->h + 4;
    			}
    			draw_x += element->w + 4;
			}
            
            if(element->tag != HTML_TAG_SCRIPT && element->tag != HTML_TAG_STYLE){
                if (current_table && element->tag == HTML_TAG_TR) {
                    if (current_table->current_row > 0) {
                        table_add_row(current_table, element->child, cell_height);
                    }
                }
                if (element->tag != HTML_TAG_SCRIPT && element->tag != HTML_TAG_STYLE) {
    				html_draw_dom_element(element, element->child, draw_y);
				}
            }
            drawCursor = 0;
        }
        element = sibling;
    }
    return draw_y;
}

void *html_math_dom(HtmlDocument *document, int first_run) {
    remath_dom = 0;
    draw_x = 0;
    ahref_name_array_count = 0;
    selectId = 0;
    selectedOnClick = NULL;
    
    if (current_table) {
        free_table_context(current_table);
        current_table = NULL;
    }
    
    if (first_run) {
        HtmlElement* elem = document->root_element;
        while (elem) {
            apply_css_styles(elem);
            HtmlElement* child = elem->child;
            while (child) {
                apply_css_styles(child);
                child = child->sibling;
            }
            elem = elem->sibling;
        }
    }
    
    max_global_y = html_math_dom_element(document->root_element, document->root_element, first_run, 1);
    SDL_Log("document height %dpx", max_global_y);
    return NULL;
}

int main(int argc, char **argv) {
    PWR_setCPUSpeed(CPU_SPEED_MENU);
    screen = GFX_init(MODE_MAIN);
    language_init(-1);
    InitSettings();
    PAD_init();
    PWR_init();
    
    fonts[0] = font.tiny;
    fonts[1] = font.tiny;
    fonts[2] = font.small;
    fonts[3] = font.medium;
    fonts[4] = font.large;
    for (int i = 0; i < MAX_LOG_LINES; i++) {
    	log_lines[i] = NULL;
	}
    
    FILE *f = fopen(argc > 1 ? argv[1] : "index.html", "r");
    char buffer[BUFFSIZE + 1] = {0};
    HtmlParseState *parse_state = html_parse_begin();
    
    if(f){
        while(!feof(f)) {
            size_t len = fread(buffer, 1, BUFFSIZE, f);
            html_parse_stream(parse_state, buffer, buffer, len);
        }
        fclose(f);
    }
    doc = html_parse_end(parse_state);
    add_log("ROOT = %p", (void*)doc->root_element);
	if (doc->root_element) {
    	add_log("ROOT tag = %d", (int)doc->root_element->tag);
	}
    
    initLang();
    init_text_cache();
    
    ctx = duk_create_heap(NULL, NULL, NULL, NULL, my_fatal);
    duk_push_c_function(ctx, native_print, DUK_VARARGS);
    duk_put_global_string(ctx, "print");
    duk_console_init(ctx);
    duk_document_init(ctx);
    duk_window_init(ctx);
    
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
    html_math_dom(doc, 1);
    html_draw_dom_element(doc->root_element, doc->root_element, global_y);
    GFX_flip(screen);
    
    int quit = 0;
    last_ticks = SDL_GetTicks();
    
    while(!quit){ 
        PAD_poll();
        
        process_timers();
        
        static Uint32 last_gc = 0;
    	Uint32 now = SDL_GetTicks();
    	if (now - last_gc > 5000) {  // Каждые 5 секунд
        	duk_gc(ctx, 0);
        	last_gc = now;
    	}
        
        if (PAD_isPressed(BTN_X)) {  // Предположим, что BTN_X есть в системе
    		show_logs = (show_logs + 1) % 3;  // Циклически переключаем режимы: 0->1->2->0
    		dirty = 1;
    		SDL_Delay(200);
		}
		
		// В режиме полноэкранных логов (show_logs == 2) обработаем дополнительные кнопки:
		if (show_logs == 2) {
    		if (PAD_isPressed(getButtonB())) {
        		show_logs = 0;
        		dirty = 1;
        		SDL_Delay(200);
    		}
    		if (PAD_isPressed(getButtonA())) {
        		clear_logs();
        		dirty = 1;
        		SDL_Delay(200);
    		}
		}
        
        if (PAD_isPressed(BTN_UP)) {
            if(selectElement - 1 >= startViewSelectedId && selectElement > 0){
                selectElement--;
                if(selectElement > endViewSelectedId) selectElement = endViewSelectedId;
                dirty = 1;
                SDL_Delay(200);
            }
            else if(global_y > 0){
                global_y -= 4;
                dirty = 1;
            }
        }
        else if (PAD_isPressed(BTN_DOWN)) {
            if(selectElement + 1 <= endViewSelectedId){
                selectElement++;
                if(selectElement < startViewSelectedId) selectElement = startViewSelectedId;
                dirty = 1;
                SDL_Delay(200);
            }
            else if(global_y < max_global_y - 240){
                global_y += 4;
                dirty = 1;
            }
        }
        if (PAD_isPressed(getButtonB())) quit = 1;
            
        if (PAD_isPressed(getButtonA())){
            if(endViewSelectedId >= 0 && startViewSelectedId >=0 && 
               selectElement >= startViewSelectedId && selectElement <= endViewSelectedId){
                if(selectedOnClick) duk_peval_string_noresult(ctx, selectedOnClick);
                int new_y = findHref(selectedHref);
                if(new_y > -1){
                    global_y = new_y;
                    selectElement = -1;
                    dirty = 1;
                }
            }
        }
        
        if(remath_dom){
            html_math_dom(doc, 0);
            dirty = 1;
            clear_text_cache();
        }
        
        if (dirty) {
            dirty = 0;
            SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
            startViewSelectedId = endViewSelectedId = -1;
            html_draw_dom_element(doc->root_element, doc->root_element, global_y);
            
            SDL_FillRect(screen, &(SDL_Rect){476, 0, 4, 273}, 0xAD76);
            if(max_global_y > 272){
                int thumb_height = 136 / ((max_global_y / 272 > 0) ? max_global_y / 272 : 1);
                SDL_FillRect(screen, &(SDL_Rect){476, 272 * global_y / max_global_y, 4, thumb_height}, 0x1111);
            }
            
            if (show_logs != 2) {  // Если не полноэкранный режим логов
        		SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
        		startViewSelectedId = endViewSelectedId = -1;
        		html_draw_dom_element(doc->root_element, doc->root_element, global_y);
        		
        		// Отрисовка скроллбара
        		SDL_FillRect(screen, &(SDL_Rect){476, 0, 4, 273}, 0xAD76);
        		if(max_global_y > 272){
            		int thumb_height = 136 / ((max_global_y / 272 > 0) ? max_global_y / 272 : 1);
            		SDL_FillRect(screen, &(SDL_Rect){476, 272 * global_y / max_global_y, 
                                           		4, thumb_height}, 0x1111);
        		}
    		}
    		
    		// Отрисовываем логи (в любом режиме)
    		draw_logs();
            
            GFX_flip(screen);
        } else GFX_sync();
        
        SDL_Delay(10);
    }
    
    while (timers) {
    	Timer* next = timers->next;
    	free(timers);
    	timers = next;
	}
    
    for (int i = 0; i < canvas_context_count; i++) {
        if (canvas_contexts[i]) {
            free_canvas_context(canvas_contexts[i]);
        }
    }
    
    HtmlElement* find_and_free_canvas(HtmlElement* element) {
    	while (element) {
        	if (element->tag == HTML_TAG_CANVAS) {
            	HtmlAttrib* attrib = element->attrib;
            	while (attrib) {
                	if (strcmp(attrib->key_name, "__canvas_ctx") == 0) {
                    	CanvasContext* canvas_ctx = (CanvasContext*)attrib->value;
                    	free_canvas_context(canvas_ctx);
                    	break;
                	}
                	attrib = attrib->next;
            	}
        	}
        	find_and_free_canvas(element->child);
        	element = element->sibling;
    	}
    	return NULL;
	}
	
	for (int i = 0; i < log_line_count; i++) {
    	free(log_lines[i]);
	}
	if (log_background) {
    	SDL_FreeSurface(log_background);
	}
	find_and_free_canvas(doc->root_element);
    
    clear_text_cache();
    clear_image_cache();
    html_free_document(doc);
    free_css_styles();
    if (current_table) {
        free_table_context(current_table);
    }
    duk_destroy_heap(ctx);
    
    QuitSettings();
    PWR_quit();
    PAD_quit();
    GFX_quit((SDL_Color){255, 255, 255});
    
    return 0;
}
