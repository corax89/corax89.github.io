/* Runtime font verification: render settings strings through the REAL
 * switch_font_draw_text() and dump a PPM. Confirms the v35.14 table
 * (no clipped glyphs) in the exact C code path used by the Switch UI. */
#include "switch/switch_font.h"
#include <stdio.h>
#include <stdlib.h>

#define W 640
#define H 460
#define SCALE 2

static void write_ppm(const char* path, const uint32_t* px, int w, int h) {
    FILE* f = fopen(path, "wb");
    if (!f) { perror("ppm"); exit(1); }
    fprintf(f, "P6\n%d %d\n255\n", w, h);
    for (int i = 0; i < w * h; i++) {
        uint32_t c = px[i];
        fputc((c >> 16) & 0xFF, f);
        fputc((c >> 8) & 0xFF, f);
        fputc(c & 0xFF, f);
    }
    fclose(f);
}

static const char* LINES[] = {
    "Настройки",
    "НАСТРОЙКИ ИГРЫ",
    "Масштаб изображения",
    "Фильтр изображения",
    "Сглаженный  Пиксельный",
    "Быстрая  Турбо (без лимита)",
    "Сохранить и выйти",
    "Предпросмотр: Глобальный флип 3D",
    "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ",
    "абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
};
#define NLINES (int)(sizeof(LINES) / sizeof(LINES[0]))

int main(void) {
    uint32_t* cv = malloc(W * H * sizeof(uint32_t));
    for (int i = 0; i < W * H; i++) cv[i] = 0xFF10131A; /* UI bg */

    /* glyph sanity: every glyph cell must fit: ink only inside 8x16 */
    for (int y = 0; y < 16; y++) {
        for (int x = 0; x < 8; x++) {
            (void)x; (void)y;
        }
    }

    int y = 8;
    for (int i = 0; i < NLINES; i++) {
        switch_font_draw_text(cv, W, H, 12, y, LINES[i], 0xFFE8ECF4, 0, SCALE);
        y += 16 * SCALE + 8;
    }
    /* also the badge line at scale 1 to test small size */
    switch_font_draw_text(cv, W, H, 12, y + 2, "Язык: Русский  минус = English", 0xFF8A93A6, 0, 1);

    write_ppm("/tmp/nojme_font_runtime.ppm", cv, W, H);
    printf("width(НАСТРОЙКИ ИГРЫ, x2) = %d px, font cell %dx%d\n",
           switch_font_text_width("НАСТРОЙКИ ИГРЫ", SCALE),
           switch_font_w(), switch_font_h());
    free(cv);
    return 0;
}
