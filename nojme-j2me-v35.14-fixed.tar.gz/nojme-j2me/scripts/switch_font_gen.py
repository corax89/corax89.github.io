#!/usr/bin/env python3
"""Generate src/switch/switch_font.c — embedded 8x16 1bpp bitmap font
(Latin + Cyrillic) rendered from DejaVu Sans.

Coverage:
  U+0020..U+007E  ASCII
  U+0401, U+0451   Ё ё
  U+0410..U+044F   А..я

Glyph storage: 16 bytes per glyph (8 wide x 16 tall, MSB-first rows).
The C file contains a lookup sorted by codepoint; switch_font_draw()
decodes UTF-8 and binary-searches the table.

v35.14 FIX — no more clipped glyphs: the old generator drew every glyph
into the final 8x16 canvas, so DejaVu Sans glyphs WIDER than 8px (Ш Щ Ы
Ц Ю Ж Ф Д М, lowercase ж ш щ ю ы ф, Latin @ M W m w ...) silently lost
their overflowing columns — «Ы» lost the right side of its bowl (looked
like «Ь»), «Ш»/«Щ» lost the middle stem, «Ю» lost the right half of the
ring, etc. Now every glyph is first measured on a generous canvas:
  * fits into 8x16  -> produced by the ORIGINAL draw path (byte-identical
    to the old table, zero regression for the good glyphs);
  * too wide        -> ink is CENTERED if it still fits after shifting,
    otherwise horizontally squeezed (LANCZOS on the anti-aliased render,
    then threshold) — all strokes survive, nothing is cut off;
  * vertical overflow (none at size 12, but guarded) -> shifted up/down
    to keep the baseline as close as possible.

Regenerate:  python3 scripts/switch_font_gen.py
"""
from PIL import Image, ImageDraw, ImageFont
import os

W, H = 8, 16
SRC = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
THRESHOLD = 128          # squeeze binarization level (L mode 0..255)

CHARS = [chr(c) for c in range(0x20, 0x7F)] + ["Ё", "ё"] + [chr(c) for c in range(0x410, 0x450)]

# v35.14: hand-tuned canonical shapes for the handful of glyphs where the
# automatic squeeze left artifacts (unconnected bars / lost hairlines).
# Each row is one byte, MSB = leftmost column, 16 rows top->bottom.
_O = lambda *rows: list(rows)
OVERRIDE = {
    # Ы: two full stems + mid bar + baseline bar (classic tiny-font shape)
    0x042B: _O(0,0,0, 0x82,0x82,0x82,0x82, 0xFE, 0x82,0x82,0x82, 0xFE, 0,0,0,0),
    # ы: same construction at x-height (rows 5..11)
    0x044B: _O(0,0,0,0,0, 0x82,0x82,0x82, 0xFE, 0x82,0x82, 0xFE, 0,0,0,0),
    # Ж: central stem restored + 4 arms
    0x0416: _O(0,0,0, 0x92,0x92, 0x54,0x38, 0x10, 0x38,0x54, 0x92,0x92, 0,0,0,0),
    # ж
    0x0436: _O(0,0,0,0,0, 0x92, 0x54,0x38, 0x10, 0x38,0x54, 0x92, 0,0,0,0),
    # ю: crossbar must reach the ring (cols 0..3 + right side col 6)
    0x044E: _O(0,0,0,0,0, 0x9C, 0x8A,0x8A, 0xF2, 0x8A,0x8A, 0x9C, 0,0,0,0),
    # Д: left leg below the baseline restored (cols 1 and 7 descend)
    0x0414: _O(0,0,0, 0x3C,0x44,0x44,0x44,0x44,0x44,0x44, 0x46, 0xFE, 0x82,0x82, 0,0),
}

# generous measuring canvas; cell origin is at (PAD_X, PAD_Y) inside it
PAD_X, PAD_Y = 16, 8
MEAS_W, MEAS_H = 64, 40


def rows_from_1bit(img):
    """Original extraction path: mode-1 image of size 8x16."""
    px = img.load()
    rows = []
    for y in range(H):
        b = 0
        for x in range(W):
            if px[x, y]:
                b |= 0x80 >> x
        rows.append(b)
    return rows


def rows_from_gray(img, cx0, cy0):
    """Binarize an L-mode image whose cell origin is (cx0, cy0) and extract
    the 8x16 cell rows."""
    px = img.load()
    rows = []
    for y in range(H):
        b = 0
        for x in range(W):
            gx, gy = x + cx0, y + cy0
            if 0 <= gx < img.width and 0 <= gy < img.height and px[gx, gy] >= THRESHOLD:
                b |= 0x80 >> x
        rows.append(b)
    return rows


def render(ch, font):
    """Return (rows, mode) for one char. mode: 'native' | 'shift' | 'squeeze'.
    Glyphs that fit keep the original pixel layout; the rest are fitted
    without losing any ink."""
    meas = Image.new("L", (MEAS_W, MEAS_H), 0)
    ImageDraw.Draw(meas).text((PAD_X, PAD_Y), ch, font=font, fill=255)
    bb = meas.getbbox()
    if bb is None:
        return [0] * H, "blank"
    mx0, my0, mx1, my1 = bb
    cx0, cy0, cx1, cy1 = mx0 - PAD_X, my0 - PAD_Y, mx1 - PAD_X, my1 - PAD_Y
    iw, ih = cx1 - cx0, cy1 - cy0

    # vertical placement: keep the ink top row where the measurement put it,
    # but clamp so nothing pokes out of the 16-row cell
    vy = cy0
    if cy1 > H:
        vy = H - ih            # shift up (keep descenders? keep whole ink inside)
    if vy < 0:
        vy = 0

    if 0 <= cx0 and cx1 <= W and 0 <= vy == cy0:
        # fits exactly as drawn -> original path (byte-identical table rows)
        img = Image.new("1", (W, H), 0)
        d = ImageDraw.Draw(img)
        try:
            d.text((0, 0), ch, font=font, fill=1)
        except Exception:
            pass
        return rows_from_1bit(img), "native"

    # ---- needs fitting ----
    ink = meas.crop((mx0, my0, mx1, my1))          # grayscale ink patch, iw x ih
    if iw <= W:
        # still fits after a shift -> center horizontally, keep glyph weight
        xoff = (W - iw) // 2
        img = Image.new("L", (W, H), 0)
        img.paste(ink, (xoff, vy))
        return rows_from_gray(img, 0, 0), "shift"

    # too wide even alone -> horizontal squeeze (LANCZOS keeps strokes)
    sq = ink.resize((W, ih), Image.LANCZOS)
    img = Image.new("L", (W, H), 0)
    img.paste(sq, (0, vy))
    return rows_from_gray(img, 0, 0), "squeeze"


def main():
    font = ImageFont.truetype(SRC, 12)
    out = []
    stats = {"native": 0, "shift": 0, "squeeze": 0, "blank": 0}
    squeezed = []
    for ch in CHARS:
        rows, mode = render(ch, font)
        if ord(ch) in OVERRIDE:
            rows = OVERRIDE[ord(ch)][:]
            mode = "hand"
        out.append((ord(ch), rows))
        stats[mode] = stats.get(mode, 0) + 1
        if mode in ("shift", "squeeze", "hand"):
            squeezed.append((ch, mode))
    out.sort(key=lambda t: t[0])

    print("fit stats:", stats)
    for ch, m in squeezed:
        print(f"  refit U+{ord(ch):04X} {ch!r}: {m}")

    dst = os.path.join(os.path.dirname(__file__), "..", "src", "switch", "switch_font.c")
    with open(dst, "w", encoding="utf-8") as f:
        f.write("/* AUTO-GENERATED by scripts/switch_font_gen.py — DO NOT EDIT.\n")
        f.write(" * 8x16 1bpp bitmap font (DejaVu Sans): ASCII + Cyrillic.\n")
        f.write(" * v35.14: wide glyphs are centered/squeezed to fit — NO clipped\n")
        f.write(" * columns (was: Ы Ш Щ Ц Ю Ж ... lost their right/middle parts).\n")
        f.write(" * Regenerate: python3 scripts/switch_font_gen.py */\n")
        f.write("#include \"switch/switch_font.h\"\n\n")
        f.write("#include <stdint.h>\n#include <stddef.h>\n\n")
        f.write("typedef struct { uint16_t cp; uint8_t rows[%d]; } FontGlyph;\n\n" % H)
        f.write("static const FontGlyph g_font[%d] = {\n" % len(out))
        for cp, rows in out:
            hexrows = ",".join("0x%02x" % r for r in rows)
            f.write("    {0x%04x,{%s}},\n" % (cp, hexrows))
        f.write("};\n\n")
        f.write("""#define GLYPH_COUNT (sizeof(g_font)/sizeof(g_font[0]))

int switch_font_w(void) { return %d; }
int switch_font_h(void) { return %d; }

static const uint8_t* glyph_for(uint32_t cp) {
    /* binary search: table sorted by codepoint */
    size_t lo = 0, hi = GLYPH_COUNT;
    while (lo < hi) {
        size_t mid = (lo + hi) / 2;
        if (g_font[mid].cp == cp) return g_font[mid].rows;
        if (g_font[mid].cp < cp) lo = mid + 1; else hi = mid;
    }
    return NULL; /* .notdef -> blank cell */
}

/* Decode one UTF-8 codepoint; advances *pp. Returns 0xFFFD on garbage. */
static uint32_t utf8_next(const char** pp) {
    const unsigned char* s = (const unsigned char*)*pp;
    unsigned char c = *s;
    if (c < 0x80) { (*pp)++; return c; }
    uint32_t cp = 0; int extra = 0;
    if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; extra = 1; }
    else if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; extra = 2; }
    else if ((c & 0xF8) == 0xF0) { cp = c & 0x07; extra = 3; }
    else { (*pp)++; return 0xFFFD; }
    s++;
    for (int i = 0; i < extra; i++, s++) {
        if ((*s & 0xC0) != 0x80) { (*pp)++; return 0xFFFD; }
        cp = (cp << 6) | (*s & 0x3F);
    }
    *pp = (const char*)(s);
    return cp;
}

int switch_font_draw_text(uint32_t* dst, int dst_w, int dst_h,
                          int x, int y, const char* utf8,
                          uint32_t fg, uint32_t bg, int scale) {
    if (!dst || !utf8 || scale < 1) return x;
    const char* p = utf8;
    int cx = x;
    while (*p) {
        uint32_t cp = utf8_next(&p);
        const uint8_t* rows = glyph_for(cp);
        for (int gy = 0; gy < %d; gy++) {
            uint8_t bits = rows ? rows[gy] : 0;
            for (int gx = 0; gx < %d; gx++) {
                int on = (bits >> (7 - gx)) & 1;
                uint32_t color = on ? fg : bg;
                if (color == 0x00000000u && !on && bg == 0x00000000u) continue; /* transparent bg */
                for (int sy = 0; sy < scale; sy++) {
                    for (int sx = 0; sx < scale; sx++) {
                        int px = cx + gx * scale + sx;
                        int py = y + gy * scale + sy;
                        if (px >= 0 && px < dst_w && py >= 0 && py < dst_h)
                            dst[py * dst_w + px] = color;
                    }
                }
            }
        }
        cx += %d * scale;
        if (cx >= dst_w) break;
    }
    return cx;
}

int switch_font_text_width(const char* utf8, int scale) {
    if (!utf8) return 0;
    int n = 0;
    const char* p = utf8;
    while (*p) { utf8_next(&p); n++; }
    return n * %d * scale;
}
""" % (W, H, H, W, W, W))
    print("wrote %s: %d glyphs" % (dst, len(out)))


if __name__ == "__main__":
    main()
