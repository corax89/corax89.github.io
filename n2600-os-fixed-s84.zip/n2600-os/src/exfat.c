/* exfat.c — чтение и ЗАПИСЬ exFAT (сессия 75).
 *
 * Запрос пользователя: «добавь чтение и запись exFat». Модуль подключён
 * как «личность» (personality) fat32.c: mount-путь FAT32 распознаёт
 * сигнатуру "EXFAT   " в VBR и все операции fat32_* на таком томе
 * прозрачно уходят сюда (файловый менеджер/диалоги/Настройки не менялись).
 * Все публичные операции сериализуются fat32_io_lock со стороны fat32.c.
 *
 * ГЕОМЕТРИЯ И ФОРМАТ (смещения VBR — ПО СПЕЦИФИКАЦИИ exFAT, сессия 84;
 *   сверено дампом реального mkfs.exfat 1.2.9 и fsck.exfat 1.2.9)
 *   VBR: 64 PartitionOffset(u64) 72 VolumeLength(u64, секторов)
 *        80 FatOffset(u32) 84 FatLength(u32) 88 ClusterHeapOffset(u32)
 *        92 ClusterCount(u32) 96 RootDirFirstCluster(u32)
 *        100 VolumeSerialNumber(u32) 104 FileSystemRevision(u16)
 *        106 VolumeFlags(u16; бит0=активная FAT, бит1=dirty)
 *        108 BytesPerSectorShift(u8) 109 SectorsPerClusterShift(u8)
 *        110 NumberOfFats(u8) 111 DriveSelect(u8) 112 PercentInUse(u8).
 *   [СЕССИЯ 84 / FIX VBR-OFFSETS]: прежде поля после MustBeZero
 *   читались со сдвигом −8 байт (пропущено PartitionOffset@64):
 *   bps-shift брался с bs[100], где у реального тома лежит МЛАДШИЙ
 *   БАЙТ СЕРИЙНОГО НОМЕРА -> «bps shift вне 9..12» — флешка Windows
 *   не монтировалась ВООБЩЕ. Тесты s75-s83 оставались зелёными:
 *   mkexfat.py писал ту же ошибочную раскладку (согласованная пара).
 *   Сектора тома могут быть 512/1024/2048/4096 байт — слой IO читает
 *   ФИЗИЧЕСКИЕ 512-байтные секторы и склеивает их (rd_sec/wr_sec).
 *   Кластеры поддержаны до 1 МиБ (буфер malloc'уется на mount).
 *
 * FAT: полные 32-битные записи; 0 = свободен, >= 0xFFFFFFF8 = EOC.
 * Цепочки: обычные (по FAT) и NoFatChain (непрерывные, FAT не ведётся) —
 * читатель определяет режим по первой FAT-записи (0/EOC => непрерывный).
 * Запись создаёт ТОЛЬКО FAT-цепочки (максимальная совместимость).
 *
 * КАТАЛОГ: наборы записей 0x85 File + 0xC0 Stream + N x 0xC1 Name.
 *   СЕССИЯ 84 [FIX ENTRY-OFFSETS]: у записей 0x81/0x82/0xC0 поля
 *   FirstCluster@20..23 и DataLength@24..31 (сверено с реальным
 *   mkfs.exfat; UpCase TableChecksum — u32 @4..7, тот же rotl31-add).
 *   Прежде читались first@16/длина@8 (спецы) и first@16/dlen@20 (0xC0)
 *   — снова согласованная пара с mkexfat.py: на томах Windows/mkfs.exfat
 *   файлы получали бы нулевой кластер и мусорную длину.
 *   ValidDataLength 0xC0 — @8..15, метка 0x83 — u16 с байта 2 (было верно).
 * Бит 0x80 в типе = InUse; удаление = снятие бита у всего набора.
 * Служебные записи корня: 0x81 Bitmap, 0x82 UpCase, 0x83 VolumeLabel.
 * Имена — UTF-16; сравнение регистронезависимое через UpCase-таблицу
 * с тома (запасной встроенный апкейс: ASCII, латиница-1, кириллица,
 * греческий, Latin Ext-A, 0xB5/0xFF). Хэш имени — по спецификации:
 * на каждый u16-символ ДВА шага rotate+add (младший и старший байты
 * отдельно — как в exfatprogs/Linux, сверено fsck.exfat 1.2.9).
 */
#include "exfat.h"
#include "string.h"
#include "sync.h"
#include "mem.h"

extern void serial_puts(const char *s);
extern void rtc_get_time(int *hours, int *mins, int *secs);
extern void rtc_get_date(int *year, int *month, int *day);

/* ================= состояние тома ================= */
static int  ready = 0;
static u32  g_bps        = 512;   /* байт на сектор тома (1<<shift)      */
static u32  g_spc        = 1;     /* секторов тома на кластер            */
static u32  g_fat_off    = 0;     /* первый сектор FAT                   */
static u32  g_fat_len    = 0;     /* длина FAT в секторах                */
static u32  g_heap_off   = 0;     /* первый сектор кластерной кучи       */
static u32  g_clusters   = 0;     /* число кластеров                     */
static u32  g_root       = 4;     /* первый кластер корня                */
static u32  g_nfat       = 1;
static u32  g_fat_active = 0;     /* СЕССИЯ 84: 0/1 — активная FAT (TexFAT) */
static u32  g_cluster_size = 0;
static char g_label[16];

static int  (*ex_rd)(u32 lba, void *buf) = 0;
static int  (*ex_wr)(u32 lba, const void *buf) = 0;

static u8 *g_cbuf = NULL;               /* буфер кластера (cluster_size) */
static u8 *g_fbuf = NULL;               /* буфер сектора FAT (bps)       */

/* UpCase-таблица с тома (необязательна) */
static u16 *g_upcase = NULL;
static u32  g_upcase_n = 0;

/* Битовая карта занятости (необязательна; иначе скан FAT) */
static u8  *g_bitmap = NULL;
static u32  g_bitmap_bytes = 0;
static u32  g_bitmap_cluster = 0;
static u32  g_bitmap_flags = 0;
static u32  g_bm_hint = 0;              /* скользящий курсор поиска      */

static u32  g_free_hint = 2;

/* СЕССИЯ 83 [FIX NoFatChain]: чтение файла шло ВСЕГДА по FAT-цепочке
 * (exfat_read_file передавал sflags=0), а Windows/mkfs.exfat пишут
 * непрерывные файлы с битом NoFatChain (0x02) и НЕ поддерживают FAT
 * для них — FAT-записи нулевые. Чтение обрывалось на ПЕРВОМ кластере
 * («флешка не читается»: файлы >1 кластера — мусор/пусто).
 * Проблема интерфейса: fat32_read_file(first, size, buf, max) НЕ
 * переносит флаги Stream-записи. Решение — кэш first->sflags: любой
 * список/поиск каталога заполняет его (реальные флаги из 0xC0-записи),
 * чтение поднимает их оттуда; при промахе — проба FAT (0/1 => считаем
 * непрерывным — та же эвристика, что у обхода каталогов выше). */
#define EX_FL_CACHE 32
static struct { u32 first; u32 sflags; } g_flcache[EX_FL_CACHE];
static u32 g_flcache_pos = 0;

static void ex_flcache_add(u32 first, u32 sflags)
{
    if (first < 2) return;
    for (u32 i = 0; i < EX_FL_CACHE; i++) {
        if (g_flcache[i].first == first) { g_flcache[i].sflags = sflags; return; }
    }
    g_flcache[g_flcache_pos].first = first;
    g_flcache[g_flcache_pos].sflags = sflags;
    g_flcache_pos = (g_flcache_pos + 1) % EX_FL_CACHE;
}

static u32 ex_flcache_get(u32 first)
{
    for (u32 i = 0; i < EX_FL_CACHE; i++)
        if (g_flcache[i].first == first) return g_flcache[i].sflags;
    return 0xFFFFFFFFu;   /* нет записи */
}
            /* курсор скана FAT              */

/* ================= низкий слой IO ================= */

/* Прочитать сектор тома g_bps байт (bps/512 физических секторов). */
static int rd_sec(u32 lba, u8 *buf)
{
    u32 n = g_bps >> 9;
    for (u32 i = 0; i < n; i++) {
        if (!ex_rd(lba * n + i, buf + i * 512)) return 0;
    }
    return 1;
}

static int wr_sec(u32 lba, const u8 *buf)
{
    u32 n = g_bps >> 9;
    for (u32 i = 0; i < n; i++) {
        if (!ex_wr(lba * n + i, buf + i * 512)) return 0;
    }
    return 1;
}

static u32 cluster_lba(u32 c)
{
    return g_heap_off + (c - 2) * g_spc;
}

/* Кэш последнего прочитанного кластера (только для g_cbuf): обходы
 * каталогов и последовательное чтение файлов читают кластер один раз.
 * Безопасно: операции serialized fat32_io_lock, вложенных g_cbuf-пользова-
 * телей нет; любая запись в кэшированный кластер инвалидирует кэш. */
static u32 g_cc_no = 0;
static int  g_cc_ok = 0;

static int rd_cluster(u32 c, u8 *buf)
{
    if (c < 2 || c >= g_clusters + 2) return 0;
    if (buf == g_cbuf && g_cc_ok && g_cc_no == c) return 1;
    if (!rd_sec(cluster_lba(c), buf)) return 0;
    for (u32 s = 1; s < g_spc; s++) {
        if (!rd_sec(cluster_lba(c) + s, buf + s * g_bps)) return 0;
    }
    if (buf == g_cbuf) { g_cc_no = c; g_cc_ok = 1; }
    return 1;
}

static int wr_cluster(u32 c, const u8 *buf)
{
    if (c < 2 || c >= g_clusters + 2) return 0;
    for (u32 s = 0; s < g_spc; s++) {
        if (!wr_sec(cluster_lba(c) + s, buf + s * g_bps)) return 0;
    }
    if (buf == g_cbuf && g_cc_no == c) g_cc_ok = 0;   /* кэш устарел */
    return 1;
}

/* ================= FAT ================= */

static u32 le32(const u8 *p)
{
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}

static u64 le64(const u8 *p)
{
    return (u64)le32(p) | ((u64)le32(p + 4) << 32);
}

static u32 fat_raw(u32 c)
{
    if (c < 2 || c >= g_clusters + 2) return 0xFFFFFFFFu;
    u32 off = c * 4;
    /* СЕССИЯ 84: читаем АКТИВНУЮ FAT (VolumeFlags бит 0 @106 при
     * NumberOfFats=2); set_fat по-прежнему зеркалит ВСЕ копии. */
    u32 sect = g_fat_off + g_fat_active * g_fat_len + off / g_bps;
    u32 e    = off % g_bps;
    if (!rd_sec(sect, g_fbuf)) return 0xFFFFFFFFu;
    return le32(g_fbuf + e);
}

/* Следующий кластер цепочки: 0 = конец (EOC/свободен/мусор). */
static u32 next_cluster(u32 c)
{
    u32 v = fat_raw(c);
    if (v < 2 || v > g_clusters + 1) return 0;   /* 0, 1, EOC, плохое */
    return v;
}

static int set_fat(u32 c, u32 val)
{
    if (c < 2 || c >= g_clusters + 2) return 0;
    u32 off = c * 4;
    u32 sect = g_fat_off + off / g_bps;
    u32 e    = off % g_bps;
    if (!rd_sec(sect, g_fbuf)) return 0;
    g_fbuf[e]     = (u8)(val & 0xFF);
    g_fbuf[e + 1] = (u8)((val >> 8) & 0xFF);
    g_fbuf[e + 2] = (u8)((val >> 16) & 0xFF);
    g_fbuf[e + 3] = (u8)((val >> 24) & 0xFF);
    for (u32 i = 0; i < g_nfat; i++) {
        if (!wr_sec(g_fat_off + i * g_fat_len + off / g_bps, g_fbuf))
            return 0;
    }
    return 1;
}

/* ================= UpCase и хэш имени ================= */

static u16 upcase_char(u16 c)
{
    if (g_upcase) {
        if (c < g_upcase_n) return g_upcase[c];
        return c;
    }
    /* встроенный запасной апкейс */
    if (c >= 'a' && c <= 'z') return (u16)(c - 32);
    if (c >= 0xE0 && c <= 0xFE && c != 0xF7) return (u16)(c - 32);  /* Latin-1 */
    if (c == 0xFF) return 0x178;
    if (c == 0xB5) return 0x39C;
    if (c == 0x17F) return 'S';
    if (c >= 0x100 && c <= 0x137 && (c & 1)) return (u16)(c - 1);   /* LatExtA */
    if (c >= 0x13A && c <= 0x148 && !(c & 1)) return (u16)(c - 1);
    if (c >= 0x14B && c <= 0x177 && (c & 1)) return (u16)(c - 1);
    if (c >= 0x17A && c <= 0x17E && !(c & 1)) return (u16)(c - 1);
    if (c >= 0x430 && c <= 0x44F) return (u16)(c - 32);             /* кириллица */
    if (c >= 0x450 && c <= 0x45F) return (u16)(c - 80);             /* ґ..џ */
    if (c >= 0x3B1 && c <= 0x3B9 && (c & 1)) return (u16)(c - 32);  /* греческий */
    if (c >= 0x3B2 && c <= 0x3BA && !(c & 1)) return (u16)(c - 32);
    if (c >= 0x3C3 && c <= 0x3CB && (c & 1)) return (u16)(c - 32);
    if (c >= 0x3C4 && c <= 0x3CC && !(c & 1)) return (u16)(c - 32);
    return c;
}

/* Хэш имени по spec: СЕССИЯ 84 — на каждый u16-символ ДВА шага rotate+add
 * (младший байт, затем старший), как в референсных exfatprogs/Linux
 * (exfat_dir.c exfat_calc_name_hash); сверено fsck.exfat — прежняя
 * схема «один шаг на u16» давала неверный NameHash для ВСЕХ имён. */
static u16 exfat_name_hash(const u16 *name, int n)
{
    u16 h = 0;
    for (int i = 0; i < n; i++) {
        u16 c = upcase_char(name[i]);
        h = (u16)(((h << 15) | (h >> 1)) + (c & 0xFF));   /* младший байт */
        h = (u16)(((h << 15) | (h >> 1)) + (c >> 8));     /* старший байт */
    }
    return h;
}

/* ================= UTF-8 <-> UTF-16 =================
 * Локальные копии (fat32.c держит свои — модуль самодостаточен). */

static int ex_utf8_to_utf16(const char *in, u16 *out, int out_max)
{
    int n = 0;
    const unsigned char *p = (const unsigned char *)in;
    while (*p && n < out_max) {
        u32 c; int len;
        if (p[0] < 0x80) { c = p[0]; len = 1; }
        else if ((p[0] & 0xE0) == 0xC0) { c = p[0] & 0x1F; len = 2; }
        else if ((p[0] & 0xF0) == 0xE0) { c = p[0] & 0x0F; len = 3; }
        else { c = '?'; len = 1; }
        int ok = 1;
        for (int k = 1; k < len; k++) {
            if ((p[k] & 0xC0) != 0x80) { ok = 0; break; }
            c = (c << 6) | (p[k] & 0x3F);
        }
        if (!ok || (len > 1 && c < 0x80)) c = '?';
        out[n++] = (u16)(c & 0xFFFF);
        p += len;
    }
    return n;
}

static void ex_u16_to_u8(const u16 *in, int n, char *out, int outmax)
{
    int o = 0;
    for (int i = 0; i < n && in[i]; i++) {
        u32 c = in[i];
        if (c < 0x80) {
            if (o + 1 >= outmax) break;
            out[o++] = (char)c;
        } else if (c < 0x800) {
            if (o + 2 >= outmax) break;
            out[o++] = (char)(0xC0 | (c >> 6));
            out[o++] = (char)(0x80 | (c & 0x3F));
        } else {
            if (o + 3 >= outmax) break;
            out[o++] = (char)(0xE0 | (c >> 12));
            out[o++] = (char)(0x80 | ((c >> 6) & 0x3F));
            out[o++] = (char)(0x80 | (c & 0x3F));
        }
    }
    out[o] = 0;
}

/* Сравнение имён без учёта регистра (UTF-8 вход, апкейс побайтно
 * прост ASCII + кириллица в UTF-8 сравниваются через u16). */
static int ex_name_eq(const char *a, const char *b)
{
    u16 ua[260], ub[260];
    int na = ex_utf8_to_utf16(a, ua, 260);
    int nb = ex_utf8_to_utf16(b, ub, 260);
    if (na != nb) return 0;
    for (int i = 0; i < na; i++)
        if (upcase_char(ua[i]) != upcase_char(ub[i])) return 0;
    return 1;
}

/* ================= метки времени (формат FAT, RTC) ================= */

static void ex_fat_datetime(u16 *date, u16 *time, u8 *tsec)
{
    int h = 0, m = 0, s = 0, y = 2025, mo = 1, d = 1;
    rtc_get_time(&h, &m, &s);
    rtc_get_date(&y, &mo, &d);
    if (y < 1980) y = 1980;
    if (y > 2107) y = 2107;
    *date = (u16)(((y - 1980) << 9) | (mo << 5) | d);
    *time = (u16)((h << 11) | (m << 5) | (s >> 1));
    if (tsec) *tsec = (u8)((s & 1) * 100);      /* 10-мс инкремент, грубо */
}

/* ================= чтение данных (файлы/UpCase/битовая карта) ======
 * Универсальный читатель: цепочка по FAT либо непрерывная (флаг
 * NoFatChain из Stream-записи). skip — сколько байт пропустить. */

static u32 rd_data(u32 first, u32 sflags, u32 skip, u8 *dst, u32 len)
{
    if (!len || first < 2) return 0;
    int contig = (sflags & 2) ? 1 : 0;            /* NoFatChain */
    u32 c = first;
    u32 guard = g_clusters + 4;

    /* пропустить ЦЕЛЫЕ кластеры; остаток — смещение внутри кластера */
    while (skip >= g_cluster_size && c >= 2 && guard-- > 0) {
        skip -= g_cluster_size;
        if (contig) c++;
        else {
            c = next_cluster(c);
            if (!c) return 0;
        }
    }

    u32 done = 0;
    guard = g_clusters + 4;
    while (done < len && c >= 2 && guard-- > 0) {
        if (!rd_cluster(c, g_cbuf)) break;
        u32 in_off = (done == 0) ? skip : 0;      /* смещение старта */
        u32 avail = g_cluster_size - in_off;
        u32 n = (len - done < avail) ? (len - done) : avail;
        memcpy(dst + done, g_cbuf + in_off, n);
        done += n;
        if (done >= len) break;
        if (contig) c++;
        else {
            c = next_cluster(c);
            if (!c) break;
        }
    }
    return done;
}

/* Запись данных (используется битовой картой). Частичные кластеры —
 * read-modify-write. */
static u32 wr_data(u32 first, u32 sflags, u32 off, const u8 *src, u32 len)
{
    if (!len || first < 2) return 0;
    int contig = (sflags & 2) ? 1 : 0;
    u32 c = first;
    u32 guard = g_clusters + 4;

    while (off >= g_cluster_size && c >= 2 && guard-- > 0) {
        off -= g_cluster_size;
        if (contig) c++;
        else {
            c = next_cluster(c);
            if (!c) return 0;
        }
    }

    u32 done = 0;
    guard = g_clusters + 4;
    while (done < len && c >= 2 && guard-- > 0) {
        u32 in_off = (done == 0) ? off : 0;
        u32 avail = g_cluster_size - in_off;
        u32 chunk = (len - done < avail) ? (len - done) : avail;
        if (in_off != 0 || chunk != g_cluster_size) {
            if (!rd_cluster(c, g_cbuf)) break;
            memcpy(g_cbuf + in_off, src + done, chunk);
            if (!wr_cluster(c, g_cbuf)) break;
        } else {
            if (!wr_cluster(c, src + done)) break;
        }
        done += chunk;
        if (done >= len) break;
        if (contig) c++;
        else {
            c = next_cluster(c);
            if (!c) break;
        }
    }
    return done;
}


/* ================= обход каталога =================
 * Позиция в потоке каталога: (кластер, смещение). Режим цепочки
 * определяется ПРОБой первой FAT-записи: 0/EOC => непрерывный
 * (NoFatChain), иначе по FAT. Конец каталога — тип 0x00. */

typedef struct {
    u32 cluster;
    u32 off;
    int contig;
    u32 guard;
    u32 cur_cl;        /* позиция ЗАПИСИ, возвращённой dp_read32 */
    u32 cur_off;
} dirpos_t;

static int dp_init(dirpos_t *p, u32 dir_cluster)
{
    if (dir_cluster < 2 || dir_cluster >= g_clusters + 2) return 0;
    p->cluster = dir_cluster;
    p->off = 0;
    u32 v = fat_raw(dir_cluster);
    p->contig = (v < 2) ? 1 : 0;          /* 0/1/EOC/мусор < 2 => непрерывный */
    p->guard = g_clusters + 2;
    return 1;
}

/* Прочитать следующую 32-байтную запись; 1 = ок, 0 = конец потока.
 * cur_cl/cur_off — позиция ВОЗВРАЩЁННОЙ записи (до продвижения). */
static int dp_read32(dirpos_t *p, u8 *e32)
{
    while (p->guard-- > 0) {
        if (p->cluster < 2 || p->cluster >= g_clusters + 2) return 0;
        if (!rd_cluster(p->cluster, g_cbuf)) return 0;
        while (p->off + 32 <= g_cluster_size) {
            p->cur_cl  = p->cluster;
            p->cur_off = p->off;
            memcpy(e32, g_cbuf + p->off, 32);
            u32 nxt = p->off + 32;
            if (nxt >= g_cluster_size) {
                p->off = 0;
                /* к следующему кластеру */
                if (p->contig) p->cluster++;
                else {
                    u32 nx = next_cluster(p->cluster);
                    if (!nx) return 0;
                    p->cluster = nx;
                }
            } else {
                p->off = nxt;
            }
            return 1;
        }
        /* p->off выровнялся — цикл продолжится с новым кластером */
    }
    return 0;
}

/* Прочитать len байт из потока каталога с позиции (cl,off) — для набора
 * записей, пересекающего границу кластера. */
static int dir_read_at(u32 dir_cluster, u32 cl, u32 off, u8 *buf, u32 len)
{
    dirpos_t p;
    if (!dp_init(&p, dir_cluster)) return 0;
    p.cluster = cl;
    p.off = off;
    u32 done = 0;
    while (done < len) {
        if (p.cluster < 2 || p.cluster >= g_clusters + 2) break;
        if (!rd_cluster(p.cluster, g_cbuf)) break;
        u32 n = g_cluster_size - p.off;
        if (n > len - done) n = len - done;
        memcpy(buf + done, g_cbuf + p.off, n);
        done += n;
        p.off += n;
        if (p.off >= g_cluster_size) {
            p.off = 0;
            if (p.contig) p.cluster++;
            else {
                u32 nx = next_cluster(p.cluster);
                if (!nx) break;
                p.cluster = nx;
            }
        }
    }
    return done == len;
}

/* Записать len байт в поток каталога с позиции (cl,off). */
static int dir_write_at(u32 dir_cluster, u32 cl, u32 off, const u8 *buf, u32 len)
{
    dirpos_t p;
    if (!dp_init(&p, dir_cluster)) return 0;
    p.cluster = cl;
    p.off = off;
    u32 done = 0;
    while (done < len) {
        if (p.cluster < 2 || p.cluster >= g_clusters + 2) break;
        if (!rd_cluster(p.cluster, g_cbuf)) break;
        u32 n = g_cluster_size - p.off;
        if (n > len - done) n = len - done;
        memcpy(g_cbuf + p.off, buf + done, n);
        if (!wr_cluster(p.cluster, g_cbuf)) break;
        done += n;
        p.off += n;
        if (p.off >= g_cluster_size) {
            p.off = 0;
            if (p.contig) p.cluster++;
            else {
                u32 nx = next_cluster(p.cluster);
                if (!nx) break;
                p.cluster = nx;
            }
        }
    }
    return done == len;
}

/* ================= сборщик набора записей ================= */

typedef struct {
    int  state;            /* -1 = ждём 0x85; >0 — осталось secondary */
    u32  attr;
    u32  first;
    u32  sflags;
    u64  dlen;
    u64  vlen;
    int  name_len;
    u16  name_hash;
    u16  name[256];
    int  name_pos;
    u32  fe_cluster, fe_off;   /* позиция записи 0x85 */
    int  sec_count;
} setacc_t;

static void set_reset(setacc_t *a)
{
    memset(a, 0, sizeof(*a));
    a->state = -1;
}

/* Скормить 32-байтную запись. Возвращает 1 = набор ЗАВЕРШЁН (полный). */
static int set_feed(setacc_t *a, const u8 *e, u32 cl, u32 off)
{
    u8 t = e[0];
    if (a->state < 0) {
        if (t == 0x00) return -1;                 /* конец каталога */
        if (t != 0x85) return 0;                  /* служебные/мусор */
        a->sec_count = e[1];
        a->attr      = le32(e + 4);
        a->fe_cluster = cl;
        a->fe_off    = off;
        if (a->sec_count < 2 || a->sec_count > 18) { a->state = -1; return 0; }
        a->state = a->sec_count;
        a->name_pos = 0;
        a->name_len = 0;
        return 0;
    }
    if (t == 0xC0 && a->state == a->sec_count) {
        a->sflags     = e[1];
        a->name_len   = e[3];
        a->name_hash  = (u16)(e[4] | (e[5] << 8));
        a->vlen       = le64(e + 8);      /* ValidDataLength @8..15 */
        /* СЕССИЯ 84 [FIX ENTRY-OFFSETS]: FirstCluster@20..23, DataLength
         * @24..31 (сверено с реальным mkfs.exfat; прежние 16/20 —
         * согласовано с mkexfat.py, но не со спецификацией). */
        a->first      = le32(e + 20);
        a->dlen       = le64(e + 24);
        a->state--;
        return 0;
    }
    if (t == 0xC1 && a->name_pos + 15 <= 256) {
        /* ms-fscc FileNameEntry: 15 UTF-16 символов с байта 2 (по 31) */
        for (int i = 0; i < 15; i++)
            a->name[a->name_pos + i] = (u16)e[2 + i * 2] |
                                       ((u16)e[3 + i * 2] << 8);
        a->name_pos += 15;
        a->state--;
        if (a->state == 0 && a->name_pos >= a->name_len) return 1;
        if (a->state == 0) a->state = -1;         /* несогласованный набор */
        return 0;
    }
    a->state = -1;                                /* сбой набора — рестарт */
    if (t == 0x85) return set_feed(a, e, cl, off);
    return 0;
}

/* ================= список и поиск ================= */

int exfat_list(u32 dir_cluster, fat32_dirent_t *out, int max)
{
    if (!ready) return 0;
    if (dir_cluster < 2) dir_cluster = g_root;

    setacc_t acc;
    set_reset(&acc);
    dirpos_t p;
    if (!dp_init(&p, dir_cluster)) return 0;

    int n = 0;
    u8 e[32];
    while (dp_read32(&p, e)) {
        int rc = set_feed(&acc, e, p.cur_cl, p.cur_off);
        if (rc < 0) break;                        /* конец каталога */
        if (rc == 1) {
            fat32_dirent_t tmp;
            memset(&tmp, 0, sizeof(tmp));
            int lim = acc.name_len;
            if (lim > 255) lim = 255;
            ex_u16_to_u8(acc.name, lim, tmp.name, FAT32_NAME_MAX);
            tmp.attr = (acc.attr & 0x10) ? 0x10 : 0x20;
            tmp.size = (u32)acc.dlen;
            tmp.first_cluster = acc.first;
            ex_flcache_add(acc.first, acc.sflags);   /* СЕССИЯ 83 */
            if (n < max) out[n++] = tmp;
            set_reset(&acc);
        }
    }
    return n;
}

/* Слот записи (для записи/удаления). */
typedef struct {
    u32 fe_cluster, fe_off;
    u32 sec_count;
    u32 first, sflags;
    u64 dlen;
    u32 attr;
    int found;
} exslot_t;

static int exfat_find_slot(u32 dir_cluster, const char *name, exslot_t *out)
{
    if (dir_cluster < 2) dir_cluster = g_root;
    memset(out, 0, sizeof(*out));

    setacc_t acc;
    set_reset(&acc);
    dirpos_t p;
    if (!dp_init(&p, dir_cluster)) return 0;

    u8 e[32];
    while (dp_read32(&p, e)) {
        int rc = set_feed(&acc, e, p.cur_cl, p.cur_off);
        if (rc < 0) break;
        if (rc == 1) {
            char nm[FAT32_NAME_MAX + 1];
            int lim = acc.name_len;
            if (lim > FAT32_NAME_MAX) lim = FAT32_NAME_MAX;
            ex_u16_to_u8(acc.name, lim, nm, FAT32_NAME_MAX);
            if (ex_name_eq(nm, name)) {
                out->fe_cluster = acc.fe_cluster;
                out->fe_off     = acc.fe_off;
                out->sec_count  = acc.sec_count;
                out->first      = acc.first;
                out->sflags     = acc.sflags;
                out->dlen       = acc.dlen;
                out->attr       = acc.attr;
                out->found      = 1;
                ex_flcache_add(acc.first, acc.sflags);   /* СЕССИЯ 83 */
                return 1;
            }
            set_reset(&acc);
        }
    }
    return 0;
}

int exfat_find_entry(u32 dir_cluster, const char *name, fat32_dirent_t *out)
{
    exslot_t s;
    if (!ready) return 0;
    if (!exfat_find_slot(dir_cluster, name, &s) || !out) return 0;
    memset(out, 0, sizeof(*out));
    strncpy(out->name, name, FAT32_NAME_MAX);
    out->name[FAT32_NAME_MAX] = 0;
    out->attr = (s.attr & 0x10) ? 0x10 : 0x20;
    out->size = (u32)s.dlen;
    out->first_cluster = s.first;
    return 1;
}

u32 exfat_read_file(u32 first_cluster, u32 size, void *buf, u32 max)
{
    if (!ready) return 0;
    if (size > max) size = max;
    if (size == 0) return 0;
    /* СЕССИЯ 83 [FIX NoFatChain]: флаги Stream-записи (бит 0x02 =
     * NoFatChain: файл непрерывен, FAT для него НЕ поддерживается)
     * поднимаем из кэша list/find; промах -> проба FAT первой записи
     * (0/1 => цепочки нет => непрерывный). Прежде sflags был всегда 0:
     * NoFatChain-файлы (штатная флешка Windows/mkfs.exfat) читались
     * только до конца ПЕРВОГО кластера. */
    u32 sflags = ex_flcache_get(first_cluster);
    if (sflags == 0xFFFFFFFFu) {
        u32 v = fat_raw(first_cluster);
        sflags = (v < 2) ? 2 : 0;    /* 0/1 => NoFatChain-семантика */
    }
    return rd_data(first_cluster, sflags, 0, (u8 *)buf, size);
}

/* ================= монтирование ================= */

int exfat_probe(const u8 *bs512)
{
    if (!bs512) return 0;
    if (bs512[510] != 0x55 || bs512[511] != 0xAA) return 0;
    return memcmp(bs512 + 3, "EXFAT   ", 8) == 0;
}

/* Найти в корне служебную запись: 0x81/0x82/0x83. */
static int root_find_special(u8 type, u32 *first, u32 *flags, u64 *size,
                             u32 *chk32, u16 *text, int text_max)
{
    dirpos_t p;
    if (!dp_init(&p, g_root)) return 0;
    u8 e[32];
    while (dp_read32(&p, e)) {
        if (e[0] == 0x00) break;
        if (e[0] != type) continue;
        if (!(e[0] & 0x80)) continue;             /* удалённая */
        /* СЕССИЯ 84 [FIX ENTRY-OFFSETS]: у служебных записей FirstCluster
         * и DataLength — на смещениях 20..23 и 24..31 (сверено дампом
         * реального mkfs.exfat; прежде читались 16 и 8 — согласовано с
         * mkexfat.py, но не со спецификацией). */
        if (first)    *first = le32(e + 20);
        if (flags)    *flags = e[1];
        if (size)     *size  = le64(e + 24);
        if (chk32)    *chk32 = le32(e + 4);   /* UpCase TableChecksum @4..7 */
        if (text && type == 0x83) {
            int cnt = e[1];
            if (cnt > 11) cnt = 11;
            if (cnt > text_max - 1) cnt = text_max - 1;
            for (int i = 0; i < cnt; i++)
                text[i] = (u16)e[2 + i * 2] | ((u16)e[3 + i * 2] << 8);
            text[cnt] = 0;
        }
        return 1;
    }
    return 0;
}

static void upcase_load(u32 first, u32 flags, u64 size, u32 chk32)
{
    if (!first || first < 2) return;
    u64 bytes = size;
    if (bytes == 0 || bytes > 128ull * 1024ull) bytes = 128ull * 1024ull;
    u32 n = (u32)(bytes / 2);
    if (n == 0) return;
    /* СЕССИЯ 84: у служебных записей FAT может не вестись (NoFatChain,
     * FAT-записи нулевые — как у файлов s83): проба первой записи. */
    if (fat_raw(first) < 2) flags |= 2;
    u16 *t = (u16 *)malloc(n * 2);
    if (!t) return;
    u32 got = rd_data(first, flags, 0, (u8 *)t, n * 2);
    if (got != n * 2) { free(t); return; }
    /* СЕССИЯ 84: TableChecksum (u32 @4 записи 0x82, тот же rotl31-add,
     * что boot-checksum; сверено с mkfs.exfat) — расхождение = битая
     * таблица -> встроенный запасной апкейс. */
    {
        u32 c = 0;
        for (u32 i = 0; i < n * 2; i++) {
            c = (c << 31) | (c >> 1);
            c += ((u8 *)t)[i];
        }
        if (chk32 && c != chk32) {
            char b[112];
            snprintf(b, sizeof(b),
                     "[exfat] UpCase: сумма %08x != %08x — встроенный апкейс\n",
                     c, chk32);
            serial_puts(b);
            free(t);
            return;
        }
    }
    g_upcase = t;
    g_upcase_n = n;
}

static void bitmap_load(u32 first, u32 flags, u64 size)
{
    if (!first || first < 2) return;
    /* СЕССИЯ 84: NoFatChain-семантика и для битовой карты (проба FAT). */
    if (fat_raw(first) < 2) flags |= 2;
    u64 bytes = (u64)((g_clusters + 7) / 8);
    if (size && size < bytes) bytes = size;
    if (bytes > 1024ull * 1024ull) return;        /* слишком велик — скан FAT */
    u8 *b = (u8 *)malloc((u32)bytes);
    if (!b) return;
    u32 got = rd_data(first, flags, 0, b, (u32)bytes);
    if (got != (u32)bytes) { free(b); return; }
    g_bitmap = b;
    g_bitmap_bytes = (u32)bytes;
    g_bitmap_cluster = first;
    g_bitmap_flags = flags;
}

int exfat_mount(int (*rd)(u32 lba, void *buf),
                int (*wr)(u32 lba, const void *buf))
{
    exfat_detach();
    ex_rd = rd;
    ex_wr = wr;
    if (!ex_rd || !ex_wr) return 0;

    u8 bs[512];
    if (!ex_rd(0, bs)) {
        serial_puts("[exfat] LBA0 не читается\n");
        return 0;
    }
    if (!exfat_probe(bs)) {
        serial_puts("[exfat] сигнатура EXFAT не найдена\n");
        return 0;
    }

    /* СЕССИЯ 84 [FIX VBR-OFFSETS]: смещения полей VBR — ПО СПЕЦИФИКАЦИИ
     * exFAT (сверено дампом реального mkfs.exfat 1.2.9: BytesPerSectorShift
     * @108, VolumeSerialNumber @100...). Прежде поля после MustBeZero
     * читались со сдвигом −8 (пропущено PartitionOffset@64): bps-shift
     * брался с bs[100] — МЛАДШИЙ БАЙТ СЕРИЙНОГО НОМЕРА реального тома
     * -> «bps shift вне 9..12» на ЛЮБОЙ флешке Windows/mkfs.exfat.
     * Хост-тесты s75-s83 оставались зелёными: mkexfat.py писал той же
     * ошибочной раскладкой (согласованная пара ошибок). */
    u64 vol_len   = le64(bs + 72);
    u32 vflags    = (u32)bs[106] | ((u32)bs[107] << 8);
    u32 bps_shift = bs[108];
    u32 spc_shift = bs[109];
    g_nfat        = bs[110] ? bs[110] : 1;
    g_fat_active  = (g_nfat == 2 && (vflags & 1)) ? 1u : 0u;
    g_fat_off     = le32(bs + 80);
    g_fat_len     = le32(bs + 84);
    g_heap_off    = le32(bs + 88);
    g_clusters    = le32(bs + 92);
    g_root        = le32(bs + 96);

    /* запрос пользователя: «добавь больше логов» — диагностический дамп
     * полей VBR печатается ДО валидации: даже если том будет отвергнут,
     * в serial видна вся раскладка реального носителя. */
    {
        char b[160];
        snprintf(b, sizeof(b),
                 "[exfat] VBR: vol=%u сект., FAT@%u+%u%s, heap@%u, "
                 "clus=%u, root=%u, bps=2^%u, spc=2^%u, nfat=%u%s\n",
                 (u32)vol_len, g_fat_off, g_fat_len,
                 g_fat_active ? " (активная #2)" : "",
                 g_heap_off, g_clusters, g_root,
                 bps_shift, spc_shift, g_nfat,
                 (vflags & 2) ? ", dirty" : "");
        serial_puts(b);
    }

    if (bps_shift < 9 || bps_shift > 12) {
        char b[80];
        snprintf(b, sizeof(b),
                 "[exfat] bps shift %u вне 9..12 (VBR+108)\n", bps_shift);
        serial_puts(b);
        return 0;
    }
    if (bps_shift + spc_shift > 20) {   /* кластер 2^20 = 1 МиБ — лимит ОС */
        char b[96];
        snprintf(b, sizeof(b),
                 "[exfat] кластер 2^%u+2^%u > 1 МиБ не поддержан (VBR+109)\n",
                 bps_shift, spc_shift);
        serial_puts(b);
        return 0;
    }
    if (g_nfat < 1 || g_nfat > 2) {
        char b[80];
        snprintf(b, sizeof(b),
                 "[exfat] NumberOfFats %u не 1/2 (VBR+110)\n", g_nfat);
        serial_puts(b);
        return 0;
    }
    if (g_fat_off < 24) {               /* спека: загрузочная область — 24 сектора */
        char b[96];
        snprintf(b, sizeof(b),
                 "[exfat] FatOffset %u < 24 (VBR+80) — некорректный VBR\n",
                 g_fat_off);
        serial_puts(b);
        return 0;
    }
    g_bps = 1u << bps_shift;
    g_spc = 1u << spc_shift;

    if (g_fat_len == 0 || g_heap_off == 0 || g_clusters < 3 ||
        g_root < 2 || g_root > g_clusters + 1) {
        serial_puts("[exfat] некорректные поля VBR\n");
        return 0;
    }
    if (g_heap_off < g_fat_off + g_fat_len * g_nfat) {
        char b[112];
        snprintf(b, sizeof(b),
                 "[exfat] heap@%u раньше конца FAT@%u — некорректный VBR\n",
                 g_heap_off, g_fat_off + g_fat_len * g_nfat);
        serial_puts(b);
        return 0;
    }
    if ((u64)g_fat_len * g_bps < (u64)(g_clusters + 2) * 4) {
        serial_puts("[exfat] FAT короче кластерного счёта\n");
        return 0;
    }
    if (vol_len &&
        (u64)g_heap_off + (u64)g_clusters * g_spc > vol_len) {
        char b[112];
        snprintf(b, sizeof(b),
                 "[exfat] куча %u+%u*%u сект. длиннее тома %u сект.\n",
                 g_heap_off, g_clusters, g_spc, (u32)vol_len);
        serial_puts(b);
        return 0;
    }

    g_cluster_size = g_bps * g_spc;
    g_cbuf = (u8 *)malloc(g_cluster_size);
    g_fbuf = (u8 *)malloc(g_bps);
    if (!g_cbuf || !g_fbuf) {
        serial_puts("[exfat] нет памяти под буферы\n");
        return 0;
    }

    ready = 1;

    /* служебные записи корня: метка, UpCase, битовая карта */
    u16 lbl[12];
    if (root_find_special(0x83, NULL, NULL, NULL, NULL, lbl, 12)) {
        ex_u16_to_u8(lbl, 11, g_label, sizeof(g_label) - 1);
    }
    {
        u32 uf = 0, ufl = 0;
        u64 usz = 0;
        u32 uck = 0;
        if (root_find_special(0x82, &uf, &ufl, &usz, &uck, NULL, 0))
            upcase_load(uf, ufl, usz, uck);
    }
    {
        u32 bf = 0, bfl = 0;
        u64 bsz = 0;
        if (root_find_special(0x81, &bf, &bfl, &bsz, NULL, NULL, 0))
            bitmap_load(bf, bfl, bsz);
    }

    {
        char b[128];
        snprintf(b, sizeof(b),
                 "[exfat] смонтирован: %u кластеров x %u байт, FAT@%u+%u, "
                 "heap@%u, root=%u%s\n",
                 g_clusters, g_cluster_size, g_fat_off, g_fat_len,
                 g_heap_off, g_root,
                 g_bitmap ? ", bitmap" : ", скан FAT");
        serial_puts(b);
    }
    return 1;
}

void exfat_detach(void)
{
    ready = 0;
    if (g_cbuf)    { free(g_cbuf);    g_cbuf = NULL; }
    if (g_fbuf)    { free(g_fbuf);    g_fbuf = NULL; }
    if (g_upcase)  { free(g_upcase);  g_upcase = NULL; g_upcase_n = 0; }
    if (g_bitmap)  { free(g_bitmap);  g_bitmap = NULL; g_bitmap_bytes = 0; }
    g_bitmap_cluster = 0;
    g_bitmap_flags = 0;
    g_cc_no = 0;
    g_cc_ok = 0;
    g_fat_active = 0;        /* СЕССИЯ 84: активная FAT сбрасывается */
    ex_rd = 0;
    ex_wr = 0;
    g_label[0] = 0;
    g_free_hint = 2;
    g_bm_hint = 0;
    memset(g_flcache, 0, sizeof(g_flcache));   /* СЕССИЯ 83: кэш флагов */
    g_flcache_pos = 0;
}

int  exfat_ready(void)          { return ready; }
u32  exfat_root_cluster(void)   { return ready ? g_root : 0; }
const char *exfat_label(void)   { return g_label; }
int  exfat_writable(void)       { return ready && ex_wr != NULL; }

/* ================= выделение / освобождение кластеров ================= */

/* Битовая карта: бит N соответствует кластеру N+2. 0 = свободен. */
static int bm_sync_sector(u32 idx_byte)
{
    u32 off = idx_byte - (idx_byte % g_bps);
    u32 n = g_bps;
    if (off + n > g_bitmap_bytes) n = g_bitmap_bytes - off;
    u32 got = wr_data(g_bitmap_cluster, g_bitmap_flags, off,
                      g_bitmap + off, n);
    return got == n;
}

static int bm_set(u32 c, int val)
{
    if (!g_bitmap) return 0;
    u32 idx = c - 2;
    if (idx / 8 >= g_bitmap_bytes) return 0;
    u8 *b = &g_bitmap[idx >> 3];
    if (val) {
        if (!((*b >> (idx & 7)) & 1)) {
            *b |= (u8)(1u << (idx & 7));
            return bm_sync_sector((u32)(idx >> 3));
        }
        return 1;
    }
    if ((*b >> (idx & 7)) & 1) {
        *b &= (u8)~(1u << (idx & 7));
        return bm_sync_sector((u32)(idx >> 3));
    }
    return 1;
}

/* Выделить кластер: сначала битовая карта, иначе скан FAT.
 * Возвращает номер кластера (2..) с EOC в FAT и битом занятости, 0 = нет. */
static u32 alloc_cluster(void)
{
    if (g_bitmap) {
        u32 total_bits = g_bitmap_bytes * 8;
        if (total_bits > g_clusters) total_bits = g_clusters;
        for (u32 t = 0; t < total_bits; t++) {
            u32 i = g_bm_hint + t;
            if (i >= total_bits) i -= total_bits;
            if (!(g_bitmap[i >> 3] & (1u << (i & 7)))) {
                u32 c = i + 2;
                if (!set_fat(c, 0xFFFFFFFFu)) return 0;
                if (!bm_set(c, 1)) return 0;
                g_bm_hint = (i + 1) % total_bits;
                return c;
            }
        }
        return 0;
    }
    /* запасной путь: скан FAT */
    u32 total = g_clusters;
    for (u32 t = 0; t < total; t++) {
        u32 c = g_free_hint + t;
        if (c < 2 || c >= total + 2) c = 2 + ((c - 2) % total);
        if (fat_raw(c) == 0) {
            if (!set_fat(c, 0xFFFFFFFFu)) return 0;
            g_free_hint = c + 1;
            return c;
        }
    }
    return 0;
}

/* Освободить цепочку (FAT + биты карты). */
static void free_chain(u32 first)
{
    if (first < 2) return;
    u32 guard = g_clusters + 2;
    u32 c = first;
    while (c >= 2 && c < g_clusters + 2 && guard-- > 0) {
        u32 nx = next_cluster(c);
        set_fat(c, 0);
        if (g_bitmap) bm_set(c, 0);
        if (nx == 0) break;
        c = nx;
    }
}

/* Выделить цепочку из need кластеров (EOC на конце, биты карты выставлены). */
static int alloc_chain(u32 need, u32 *out_first)
{
    if (need == 0) { *out_first = 0; return 1; }
    u32 head = 0, prev = 0;
    for (u32 i = 0; i < need; i++) {
        u32 c = alloc_cluster();
        if (!c) {
            if (head) free_chain(head);
            return 0;
        }
        if (prev) set_fat(prev, c);   /* связать (на c уже EOC) */
        else head = c;
        prev = c;
    }
    *out_first = head;
    return 1;
}

/* ================= служебные записи набора ================= */

/* Контрольная сумма набора: по всем байтам всех записей, кроме двух
 * байтов SetChecksum самой первой (0x85). */
static u16 set_checksum(const u8 *set, int n_entries)
{
    u16 sum = 0;
    int total = n_entries * 32;
    for (int i = 0; i < total; i++) {
        if (i == 2 || i == 3) continue;
        sum = (u16)(((sum << 15) | (sum >> 1)) + set[i]);
    }
    return sum;
}

/* Записать готовый набор (уже с контрольной суммой) в поток каталога. */
static int dir_set_write(u32 dir, u32 cl, u32 off,
                         const u8 *set, int n_entries)
{
    /* контрольная сумма поверх собранного набора */
    u8 tmp[20 * 32];
    if (n_entries < 2 || n_entries > 18) return 0;
    memcpy(tmp, set, (u32)n_entries * 32);
    u16 cs = set_checksum(tmp, n_entries);
    tmp[2] = (u8)(cs & 0xFF);
    tmp[3] = (u8)(cs >> 8);
    return dir_write_at(dir, cl, off, tmp, (u32)n_entries * 32);
}

/* Найти подряд need свободных 32-байтных слотов в каталоге (свободны
 * типы 0x00 и снятый InUse: 0x05/0x40/0x41), при нехватке — РОСТИ. */
static int find_free_run(u32 dir, int need, u32 *out_cl, u32 *out_off)
{
    if (dir < 2) dir = g_root;
    dirpos_t p;
    if (!dp_init(&p, dir)) return 0;

    u8 e[32];
    int run = 0;
    u32 run_cl = 0, run_off = 0;
    while (dp_read32(&p, e)) {
        u8 t = e[0];
        int free_slot = (t == 0x00) || !(t & 0x80);
        if (free_slot) {
            /* Забег обязан быть НЕПРЕРЫВНЫМ по смещению — это заодно
             * запрещает пересекать границу кластера (в contig-режиме
             * dp_read32 идёт и в соседние кластеры — туда «лезть»
             * с записью набора нельзя). */
            if (run == 0 || p.cur_cl != run_cl ||
                p.cur_off != run_off + (u32)run * 32) {
                run = 1;
                run_cl = p.cur_cl;
                run_off = p.cur_off;
            } else {
                run++;
            }
            if (run == need) {
                *out_cl  = run_cl;
                *out_off = run_off;
                return 1;
            }
        } else {
            run = 0;
        }
    }
    /* не нашли — рост каталога: добавить кластер и взять начало */
    u32 nc = alloc_cluster();
    if (!nc) return 0;
    memset(g_cbuf, 0, g_cluster_size);
    if (!wr_cluster(nc, g_cbuf)) { free_chain(nc); return 0; }
    /* привязать к хвосту цепочки каталога */
    {
        u32 c = dir, guard = g_clusters + 2;
        while (c >= 2 && guard-- > 0) {
            u32 nx = next_cluster(c);
            if (!nx) {
                if (c != nc && !set_fat(c, nc)) { free_chain(nc); return 0; }
                break;
            }
            c = nx;
        }
    }
    *out_cl = nc;
    *out_off = 0;
    return 1;
}

/* Собрать набор записей (0x85 + 0xC0 + N x 0xC1) в буфер. */
static int build_entry_set(const char *name, u32 attr, u32 first,
                           u64 dlen, u8 *set, int *out_n)
{
    u16 name16[256];
    int nl = ex_utf8_to_utf16(name, name16, 255);
    if (nl <= 0) return 0;

    int nname = (nl + 14) / 15;
    int n = 2 + nname;

    memset(set, 0, (u32)n * 32);

    /* --- 0x85 File --- */
    {
        u8 *e = set;
        u16 d = 0, t = 0;
        u8 ts = 0;
        ex_fat_datetime(&d, &t, &ts);
        e[0] = 0x85;
        e[1] = (u8)(n - 1);                       /* SecondaryCount */
        /* SetChecksum [2..3] — заполнит dir_set_write */
        e[4] = (u8)(attr & 0xFF);                 /* FileAttributes */
        e[5] = (u8)((attr >> 8) & 0xFF);
        /* ms-fscc FileDirectoryEntry: Create@12, LastModified@16,
         * 10ms-инкременты/UTC@20-23, LastAccess@24-27, Reserved@28-31 */
        e[12] = (u8)(d & 0xFF); e[13] = (u8)(d >> 8);      /* Create      */
        e[14] = (u8)(t & 0xFF); e[15] = (u8)(t >> 8);
        e[16] = (u8)(d & 0xFF); e[17] = (u8)(d >> 8);      /* LastModified */
        e[18] = (u8)(t & 0xFF); e[19] = (u8)(t >> 8);
        e[20] = ts;                                        /* Modified10ms */
        e[21] = ts;                                        /* Create10ms  */
        e[22] = 0x00;                                      /* UTC: UTC    */
        e[23] = 0x00;
        e[24] = (u8)(d & 0xFF); e[25] = (u8)(d >> 8);      /* LastAccess  */
        e[26] = (u8)(t & 0xFF); e[27] = (u8)(t >> 8);
    }

    /* --- 0xC0 Stream --- */
    {
        u8 *e = set + 32;
        u16 h = exfat_name_hash(name16, nl);
        e[0] = 0xC0;
        e[1] = 0x01;                              /* AllocationPossible */
        e[2] = 0x00;
        e[3] = (u8)nl;                            /* NameLength */
        e[4] = (u8)(h & 0xFF);                    /* NameHash */
        e[5] = (u8)(h >> 8);
        /* ValidDataLength [8..15] */
        e[8]  = (u8)(dlen & 0xFF);
        e[9]  = (u8)((dlen >> 8) & 0xFF);
        e[10] = (u8)((dlen >> 16) & 0xFF);
        e[11] = (u8)((dlen >> 24) & 0xFF);
        /* СЕССИЯ 84 [FIX ENTRY-OFFSETS]: FirstCluster [20..23],
         * DataLength [24..31] — по спецификации (сверено mkfs.exfat). */
        e[20] = (u8)(first & 0xFF);
        e[21] = (u8)((first >> 8) & 0xFF);
        e[22] = (u8)((first >> 16) & 0xFF);
        e[23] = (u8)((first >> 24) & 0xFF);
        e[24] = (u8)(dlen & 0xFF);
        e[25] = (u8)((dlen >> 8) & 0xFF);
        e[26] = (u8)((dlen >> 16) & 0xFF);
        e[27] = (u8)((dlen >> 24) & 0xFF);
    }

    /* --- 0xC1 Name x nname --- */
    for (int k = 0; k < nname; k++) {
        u8 *e = set + (u32)(2 + k) * 32;
        e[0] = 0xC1;
        e[1] = 0x00;
        /* символы имени — с байта 2 (15 UTF-16 кодовых единиц) */
        for (int i = 0; i < 15; i++) {
            int ci = k * 15 + i;
            u16 ch = (ci < nl) ? name16[ci] : 0x0000;
            e[2 + i * 2]     = (u8)(ch & 0xFF);
            e[2 + i * 2 + 1] = (u8)(ch >> 8);
        }
    }

    *out_n = n;
    return 1;
}

/* Вставить набор записей. Возвращает позицию 0x85. */
static int exfat_insert(u32 dir, const char *name, u32 attr, u32 first,
                        u64 dlen, u32 *out_cl, u32 *out_off)
{
    if (!name || !name[0] || strchr(name, '/')) return 0;
    u8 set[20 * 32];
    int n = 0;
    if (!build_entry_set(name, attr, first, dlen, set, &n)) return 0;

    u32 cl, off;
    if (!find_free_run(dir, n, &cl, &off)) return 0;
    if (!dir_set_write(dir, cl, off, set, n)) return 0;
    if (out_cl)   *out_cl  = cl;
    if (out_off)  *out_off = off;
    return 1;
}

/* Патч Stream-записи существующего набора (после перезаписи файла).
 * ВАЖНО: SecondaryCount НЕ учитывает саму File-запись — полный набор
 * занимает (sec_count + 1) записей. */
static int patch_stream(u32 dir, const exslot_t *s, u32 first, u64 dlen)
{
    u8 set[20 * 32];
    int total = s->sec_count + 1;
    if (total < 2 || total > 19) return 0;
    if (!dir_read_at(dir, s->fe_cluster, s->fe_off, set,
                     (u32)total * 32)) return 0;
    u8 *e = set + 32;                             /* Stream */
    if (e[0] != 0xC0) return 0;
    e[1] = 0x01;                                  /* AllocationPossible */
    e[8]  = (u8)(dlen & 0xFF);                    /* ValidDataLength */
    e[9]  = (u8)((dlen >> 8) & 0xFF);
    e[10] = (u8)((dlen >> 16) & 0xFF);
    e[11] = (u8)((dlen >> 24) & 0xFF);
    /* СЕССИЯ 84 [FIX ENTRY-OFFSETS]: FirstCluster [20..23],
     * DataLength [24..31] — как в build_entry_set (по спецификации). */
    e[20] = (u8)(first & 0xFF);
    e[21] = (u8)((first >> 8) & 0xFF);
    e[22] = (u8)((first >> 16) & 0xFF);
    e[23] = (u8)((first >> 24) & 0xFF);
    e[24] = (u8)(dlen & 0xFF);
    e[25] = (u8)((dlen >> 8) & 0xFF);
    e[26] = (u8)((dlen >> 16) & 0xFF);
    e[27] = (u8)((dlen >> 24) & 0xFF);
    return dir_set_write(dir, s->fe_cluster, s->fe_off, set, total);
}

/* ================= публичные операции записи ================= */

int exfat_create_file(u32 dir_cluster, const char *name)
{
    if (!ready) return 0;
    exslot_t s;
    if (exfat_find_slot(dir_cluster, name, &s)) return 0;   /* занято */
    return exfat_insert(dir_cluster, name, 0x20, 0, 0, NULL, NULL);
}

int exfat_mkdir(u32 dir_cluster, const char *name)
{
    if (!ready) return 0;
    if (dir_cluster < 2) dir_cluster = g_root;
    exslot_t s;
    if (exfat_find_slot(dir_cluster, name, &s)) return 0;   /* занято */

    u32 nc = alloc_cluster();
    if (!nc) return 0;
    memset(g_cbuf, 0, g_cluster_size);
    if (!wr_cluster(nc, g_cbuf)) { free_chain(nc); return 0; }
    /* СЕССИЯ 84: DataLength каталога = числу кластеров * размер кластера
     * (спека; fsck.exfat бракует каталоги с нулевым размером). */
    if (!exfat_insert(dir_cluster, name, 0x10, nc, g_cluster_size,
                      NULL, NULL)) {
        free_chain(nc);
        return 0;
    }
    return 1;
}

u32 exfat_write_file(u32 dir_cluster, const char *name,
                     const void *buf, u32 len)
{
    if (!ready) return 0;
    if (dir_cluster < 2) dir_cluster = g_root;
    if (!name || !name[0] || strchr(name, '/')) return 0;
    if (len > 4u * 1024u * 1024u) return 0;

    exslot_t s;
    int existed = exfat_find_slot(dir_cluster, name, &s);
    if (!existed) {
        if (!exfat_insert(dir_cluster, name, 0x20, 0, 0, NULL, NULL))
            return 0;
        if (!exfat_find_slot(dir_cluster, name, &s)) return 0;
    }

    if ((s.attr & 0x10)) return 0;                /* это каталог */

    /* освободить старую цепочку (только FAT-управляемую) */
    if ((s.sflags & 1) && !(s.sflags & 2) && s.first >= 2)
        free_chain(s.first);

    u32 first = 0;
    if (len > 0) {
        u32 need = (len + g_cluster_size - 1) / g_cluster_size;
        if (need > g_clusters) return 0;
        if (!alloc_chain(need, &first)) return 0;
        /* записать данные кластерами */
        const u8 *src = (const u8 *)buf;
        u32 done = 0;
        u32 c = first;
        while (done < len && c >= 2) {
            u32 n = (len - done > g_cluster_size) ? g_cluster_size : (len - done);
            memset(g_cbuf, 0, g_cluster_size);
            memcpy(g_cbuf, src + done, n);
            if (!wr_cluster(c, g_cbuf)) {
                free_chain(first);
                return 0;
            }
            done += n;
            if (done >= len) break;
            c = next_cluster(c);
            if (!c && done < len) { free_chain(first); return 0; }
        }
    }

    if (!patch_stream(dir_cluster, &s, first, len)) {
        if (first) free_chain(first);
        return 0;
    }
    return len;
}

/* Каталог пуст? (нет ни одной InUse-записи, кроме метки/карты/UpCase) */
static int exfat_dir_empty(u32 dir_cluster)
{
    if (dir_cluster < 2) dir_cluster = g_root;
    dirpos_t p;
    if (!dp_init(&p, dir_cluster)) return 0;
    u8 e[32];
    while (dp_read32(&p, e)) {
        u8 t = e[0];
        if (t == 0x00) return 1;
        if (!(t & 0x80)) continue;                /* удалённая/свободная */
        if (t == 0x83) continue;                  /* метка тома (в корне) */
        return 0;
    }
    return 1;
}

int exfat_delete(u32 dir_cluster, const char *name)
{
    if (!ready) return 0;
    if (dir_cluster < 2) dir_cluster = g_root;
    exslot_t s;
    if (!exfat_find_slot(dir_cluster, name, &s)) return 0;

    int is_dir = (s.attr & 0x10) ? 1 : 0;
    if (is_dir) {
        if (s.first < 2) return 0;
        if (!exfat_dir_empty(s.first)) return 0;
        /* корень удалить нельзя */
        if (s.first == g_root) return 0;
    }

    /* освободить цепочку (FAT-управляемую) */
    if ((s.sflags & 1) && !(s.sflags & 2) && s.first >= 2)
        free_chain(s.first);
    /* NoFatChain-каталог: кластеры освобождаем по счёту размера? длина
     * каталога не хранится — такие каталоги Windows не создаёт; файлы
     * NoFatChain при удалении: битовая карта неактуальна (FAT-скан при
     * следующем монтировании всё равно не правит карту) — пометим биты
     * свободными по dlen (если карта есть). */
    if ((s.sflags & 2) && s.first >= 2 && !is_dir && g_bitmap) {
        u64 bytes = s.dlen;
        u32 n = (u32)((bytes + g_cluster_size - 1) / g_cluster_size);
        for (u32 i = 0; i < n && s.first + i < g_clusters + 2; i++)
            bm_set(s.first + i, 0);
    }

    /* снять InUse (бит 0x80) у ВСЕХ записей набора — полный набор
     * занимает (sec_count + 1) записей (File + все secondary) */
    {
        u8 set[20 * 32];
        int total = (int)s.sec_count + 1;
        if (total < 2 || total > 19) return 0;
        if (!dir_read_at(dir_cluster, s.fe_cluster, s.fe_off, set,
                         (u32)total * 32)) return 0;
        for (int k = 0; k < total; k++)
            set[k * 32] &= 0x7F;
        if (!dir_write_at(dir_cluster, s.fe_cluster, s.fe_off, set,
                          (u32)total * 32)) return 0;
    }
    return 1;
}
