/* mquickjs_api.c — мост между MicroQuickJS и API N2600-OS.
 *
 * ЗАМЕНЯЕТ cmscript_api.c: реализует все host-функции бывшего
 * CMScript-моста как нативные функции QuickJS. Имена и семантика —
 * те же (см. mqjs_os.h); регистрация выполняется автоматически при
 * создании контекста через сгенерированный src/mqjs_stdlib_os.h
 * (бывший CDM_RegisterHostFuncEx не нужен).
 *
 * Здесь же:
 *   - запуск скриптов (mquickjs_run — бывший cmscript_run);
 *   - REPL для терминала (mqjs_repl_* — команда `js`);
 *   - кооперативные setTimeout/clearTimeout + Date/performance.now;
 *   - SCRIPT GUI: окна/кнопки/картинки из скрипта (sg_* — перенос из
 *     cmscript_api.c без изменений семантики);
 *   - c4k_* + c4_gui_init — GUI-мост для c4 (использовался
 *     cmscript_api.c, перенесён сюда без изменений).
 *
 * Отличия от CMScript-моста (сознательные):
 *   - каждый запуск получает СОБСТВЕННЫЙ контекст JS ( CMScript был
 *     глобальным и сериализовался спинлоком) — параллельные скрипты
 *     независимы; общий состояние (sg_* окна, imgsvc, ramfs) как и
 *     раньше под спинлоками;
 *   - print() пишет аргументы без завершающего '\n' (как в CMScript),
 *     console.log() — с '\n';
 *   - malloc/free/memset/memcmp работают с числовыми дескрипторами
 *     (в JS нет указателей); ramfs_read(name) без дескриптора
 *     возвращает содержимое строкой;
 *   - строка-исключение/ошибка печатается в тот же буфер out.
 */
#include "mqjs_os.h"
#include "mquickjs.h"
#include "sync.h"
#include "types.h"
#include "mem.h"
#include "string.h"
#include "fb.h"
#include "wm.h"       /* окна из скрипта: win_create/win_invalidate/... */
#include "mouse.h"    /* MSB_LEFT */
#include "timer.h"
#include "task.h"
#include "ramfs.h"
#include "imgsvc.h"   /* картинки (stb_image) */

#ifndef NULL
#define NULL ((void*)0)
#endif

/* кооперативные таймеры (реализация в секции таймеров ниже) */
void mqjs_pump_timers(JSContext *ctx);

/* Прототипы host-функций: на них ссылается сгенерированная таблица
 * стдлиба (mqjs_stdlib_os.h), поэтому она подключается после них. */
static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_console_log(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_print_int(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_screen_width(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_screen_height(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_fill_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_draw_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_get_color(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_clear_screen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_flip(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_delay(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_uptime(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_strlen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_malloc_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_free_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_memset_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_memcmp_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_ramfs_read(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_heap_used(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_heap_size(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_ramfs_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_ramfs_list(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_open(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_close(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_alive(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_clear(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_update(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_btn_add(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_btn_clicked(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_btn_set_label(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_free(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_w(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_pixel(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_draw(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_img_draw_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_img(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_win_img_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);
static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv);

/* Таблица стдлиба ОС (сгенерирована scripts/make_os_stdlib.py):
 * атомы + глобальные объекты + все host-функции выше.
 * Два варианта разметки ROM-таблицы: 32-бит (ядро N2600-OS, JSW=4) и
 * 64-бит (только хост-тесты моста, JSW=8). */
#if defined(JS_PTR64)
#include "mqjs_stdlib_os64.h"
#else
#include "mqjs_stdlib_os.h"
#endif

/* ==================== состояние вывода контекста ==================== */

#define MQJS_MAX_TIMERS 16

typedef struct {
    /* вывод print/console.log/ошибок (принадлежит запускающей задаче) */
    char *out;
    u32   out_pos;
    u32   out_max;
    int   out_owned;      /* 1 = буфер выделен мостом (REPL), 0 = внешний */
    /* кооперативные таймеры (JSGCRef принадлежит этому контексту) */
    struct {
        int       used;
        JSGCRef   func;
        long long timeout;      /* ms с загрузки */
    } timers[MQJS_MAX_TIMERS];
} mqjs_state_t;

static void mqjs_state_write(mqjs_state_t *st, const char *buf, u32 len)
{
    if (!st || !st->out) return;
    if (st->out_pos + len > st->out_max - 1)
        len = (st->out_max > st->out_pos + 1) ? st->out_max - 1 - st->out_pos : 0;
    memcpy(st->out + st->out_pos, buf, len);
    st->out_pos += len;
    st->out[st->out_pos] = 0;
}

/* log-func движка: сюда попадают JS_PrintValueF (ошибки, REPL-результат) */
static void mqjs_log_write(void *opaque, const void *buf, size_t buf_len)
{
    mqjs_state_write((mqjs_state_t *)opaque, (const char *)buf, (u32)buf_len);
}

/* ms с загрузки (1 тик = 1 мс, сессия 33) */
static long long mqjs_now_ms(void)
{
    return (long long)(u64)timer_ticks();
}

/* ==================== чтение аргументов ==================== */

static int jarg_int(JSContext *ctx, JSValue *v, int def)
{
    int i = def;
    if (JS_ToInt32Sat(ctx, &i, *v)) {
        /* исключение (NaN и т.п.) не считаем фатальной ошибкой вызова */
        JS_GetException(ctx);
        return def;
    }
    return i;
}

/* JS-строка -> C-строка в буфере ВЫЗЫВАЮЩЕГО.
 *
 * SAFETY (фикс «вопросиков» калькулятора): JS_ToCString для коротких
 * строк (JS_TAG_STRING_CHAR, в т.ч. все 1-символьные литералы и
 * результаты String(n) из одной цифры) пишет в переданный JSCStringBuf
 * и возвращает указатель ВНУТРЬ него. Буфер живёт только до возврата
 * из этого helper'а, поэтому возвращать указатель наружу нельзя:
 * use-after-scope — первый же вызов затирает кадр, и на -m32 -Os
 * лейблы кнопок/дисплей превращались в "8?"/"0?}4" (на -m64 раскладка
 * стека маскировала порчу). Копируем немедленно. */
static void jarg_str_buf(char *dst, int cap, JSContext *ctx, JSValue *v,
                         const char *def)
{
    JSCStringBuf sb;
    const char *s = JS_ToCString(ctx, *v, &sb);
    int i = 0;
    if (!s) {
        JS_GetException(ctx);            /* снять исключение */
        s = def;
    }
    if (s) {
        for (; s[i] && i < cap - 1; i++) dst[i] = s[i];
    }
    dst[i] = 0;
}

/* JSValue из int: вне short-range уходит в heap-двойник (нужен ctx) */
static JSValue jint(JSContext *ctx, int v)
{
    return JS_NewInt32(ctx, v);
}

/* ==================== вывод / экран ==================== */

/* print(...args) — как в CMScript без завершающего '\n';
 * несколько аргументов разделяются пробелом (как в mqjs/console) */
static JSValue js_print(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    char nbuf[32];
    for (int i = 0; i < argc; i++) {
        if (i != 0) mqjs_state_write(st, " ", 1);
        if (JS_IsString(ctx, argv[i])) {
            JSCStringBuf sb;
            size_t len = 0;
            const char *s = JS_ToCStringLen(ctx, &len, argv[i], &sb);
            if (s) mqjs_state_write(st, s, (u32)len);
        } else if (JS_IsNumber(ctx, argv[i])) {
            double d;
            if (!JS_ToNumber(ctx, &d, argv[i])) {
                if (d == (long long)d && d >= -2147483648.0 && d <= 2147483647.0)
                    snprintf(nbuf, sizeof(nbuf), "%d", (int)d);
                else
                    snprintf(nbuf, sizeof(nbuf), "%g", d);
                mqjs_state_write(st, nbuf, (u32)strlen(nbuf));
            }
        } else if (JS_IsUndefined(argv[i])) {
            mqjs_state_write(st, "undefined", 9);
        } else if (JS_IsNull(argv[i])) {
            mqjs_state_write(st, "null", 4);
        } else if (JS_IsBool(argv[i])) {
            mqjs_state_write(st, JS_IsBool(argv[i]) == 1 ? "true" : "false", 4);
        } else {
            /* объекты — как в mqjs: дамп значения */
            JS_PrintValueF(ctx, argv[i], JS_DUMP_LONG);
        }
    }
    return JS_UNDEFINED;
}

/* console.log(...args) — как print, но с '\n' */
static JSValue js_console_log(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    JSValue r = js_print(ctx, this_val, argc, argv);
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    mqjs_state_write(st, "\n", 1);
    return r;
}

static JSValue js_print_int(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    char b[16];
    snprintf(b, sizeof(b), "%d", jarg_int(ctx, &argv[0], 0));
    mqjs_state_write(st, b, (u32)strlen(b));
    return JS_UNDEFINED;
}

static JSValue js_screen_width(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return jint(ctx, (int)fb_width());
}

static JSValue js_screen_height(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return jint(ctx, (int)fb_height());
}

static JSValue js_fill_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    fb_fill_rect(jarg_int(ctx, &argv[0], 0), jarg_int(ctx, &argv[1], 0),
                 jarg_int(ctx, &argv[2], 0), jarg_int(ctx, &argv[3], 0),
                 (u32)jarg_int(ctx, &argv[4], 0));
    return JS_UNDEFINED;
}

static JSValue js_draw_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    char text[256];                  /* SAFETY: копия строки (см. jarg_str_buf) */
    int x, y;
    (void)this_val; (void)argc;
    x = jarg_int(ctx, &argv[0], 0);
    y = jarg_int(ctx, &argv[1], 0);
    jarg_str_buf(text, (int)sizeof(text), ctx, &argv[2], "");
    fb_text(x, y, text, (u32)jarg_int(ctx, &argv[3], 0), -1);
    return JS_UNDEFINED;
}

static JSValue js_get_color(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    return jint(ctx, (int)fb_rgb((u8)jarg_int(ctx, &argv[0], 0),
                                 (u8)jarg_int(ctx, &argv[1], 0),
                                 (u8)jarg_int(ctx, &argv[2], 0)));
}

static JSValue js_clear_screen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    fb_fill_screen((u32)jarg_int(ctx, &argv[0], 0));
    return JS_UNDEFINED;
}

static JSValue js_flip(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc; (void)argv;
    fb_touch_all();
    fb_flush();
    mqjs_pump_timers(ctx);
    return JS_UNDEFINED;
}

static JSValue js_delay(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    u32 start = timer_ticks();
    u32 need = (u32)jarg_int(ctx, &argv[0], 0);   /* 1 тик = 1 мс */
    if (need == 0) need = 1;
    while (timer_ticks() - start < need) {
        task_yield();
        mqjs_pump_timers(ctx);
    }
    return JS_UNDEFINED;
}

static JSValue js_uptime(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    mqjs_pump_timers(ctx);
    return jint(ctx, (int)uptime_sec());
}

/* ==================== информация о хипе ==================== */
/* heap_used() — сколько байт JS-хипа занято сейчас (включая мусор,
 *   который уберёт следующий gc()); heap_size() — суммарная ёмкость
 *   (основной пул, включая область стека значений, + закреплённые
 *   сегменты). В сочетании с gc() позволяют скрипту следить за
 *   памятью. */

static JSValue js_heap_used(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return jint(ctx, (int)JS_GetHeapUsed(ctx));
}

static JSValue js_heap_size(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return jint(ctx, (int)JS_GetHeapCapacity(ctx));
}

/* ==================== strlen / память по дескрипторам ==================== */

static JSValue js_strlen(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    JSCStringBuf sb;
    size_t len = 0;
    const char *s;
    (void)this_val; (void)argc;
    /* SAFETY: длина берётся сразу (plen), без strlen по висячему
     * указателю; длинные строки JS_ToCStringLen отдаёт из хипа. */
    s = JS_ToCStringLen(ctx, &len, argv[0], &sb);
    if (!s) {
        JS_GetException(ctx);
        return jint(ctx, 0);
    }
    return jint(ctx, (int)len);
}

#define MQ_MAX_HANDLES 64
typedef struct { u8 used; void *ptr; u32 size; } mq_handle_t;
static mq_handle_t g_handles[MQ_MAX_HANDLES];

static void *handle_ptr(int h, u32 *psize)
{
    if (h <= 0 || h > MQ_MAX_HANDLES) return NULL;
    mq_handle_t *hd = &g_handles[h - 1];
    if (!hd->used) return NULL;
    if (psize) *psize = hd->size;
    return hd->ptr;
}

static JSValue js_malloc_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    u32 n = (u32)jarg_int(ctx, &argv[0], 0);
    if (n == 0) return jint(ctx, 0);
    for (int i = 0; i < MQ_MAX_HANDLES; i++) {
        if (!g_handles[i].used) {
            void *p = malloc(n ? n : 1);
            if (!p) return jint(ctx, 0);
            g_handles[i].used = 1;
            g_handles[i].ptr = p;
            g_handles[i].size = n;
            return jint(ctx, i + 1);
        }
    }
    return jint(ctx, 0);
}

static JSValue js_free_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    int h = jarg_int(ctx, &argv[0], 0);
    if (h > 0 && h <= MQ_MAX_HANDLES && g_handles[h - 1].used) {
        free(g_handles[h - 1].ptr);
        g_handles[h - 1].used = 0;
        g_handles[h - 1].ptr = NULL;
        g_handles[h - 1].size = 0;
    }
    return JS_UNDEFINED;
}

static JSValue js_memset_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    u32 size = 0;
    void *p = handle_ptr(jarg_int(ctx, &argv[0], 0), &size);
    if (p) {
        u32 n = (u32)jarg_int(ctx, &argv[2], 0);
        if (n > size) n = size;
        memset(p, jarg_int(ctx, &argv[1], 0), n);
    }
    return JS_UNDEFINED;
}

static JSValue js_memcmp_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    u32 s1 = 0, s2 = 0;
    void *p1 = handle_ptr(jarg_int(ctx, &argv[0], 0), &s1);
    void *p2 = handle_ptr(jarg_int(ctx, &argv[1], 0), &s2);
    if (!p1 || !p2) return jint(ctx, -1);
    u32 n = (u32)jarg_int(ctx, &argv[2], 0);
    if (n > s1) n = s1;
    if (n > s2) n = s2;
    return jint(ctx, memcmp(p1, p2, n));
}

/* ==================== RAM disk ==================== */

/* ramfs_read(name)            -> содержимое строкой (или null)
 * ramfs_read(name, h, max)    -> записать в дескриптор, вернуть длину */
static JSValue js_ramfs_read(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    char name[RAMFS_NAME_MAX + 2];   /* SAFETY: копия имени (см. jarg_str_buf) */
    (void)this_val;
    jarg_str_buf(name, (int)sizeof(name), ctx, &argv[0], "");
    if (!name[0]) return JS_NULL;

    if (argc >= 3) {
        /* SAFETY: запись строго в пределах блока дескриптора. Раньше max
         * шёл из скрипта без клампа — злонамеренный/ошибочный скрипт мог
         * затереть кучу ядра (ramfs_read пишет min(размер_файла, max)). */
        u32 hsize = 0;
        void *p = handle_ptr(jarg_int(ctx, &argv[1], 0), &hsize);
        if (!p) return jint(ctx, 0);
        u32 max = (u32)jarg_int(ctx, &argv[2], 0);
        if (max > hsize) max = hsize;
        return jint(ctx, (int)ramfs_read(name, p, max));
    }

    ramfs_dirent_t ent;
    if (!ramfs_stat_ci(name, &ent) || ent.is_dir) return JS_NULL;
    if (ent.size == 0)
        return JS_NewStringLen(ctx, "", 0);
    char *buf = (char *)malloc(ent.size + 1);
    if (!buf) return JS_NULL;
    u32 got = ramfs_read(name, buf, ent.size);
    /* файлы в этой ОС пишутся NUL-терминированными (ramfs_write len+1):
     * завершающий NUL не является частью содержимого строки */
    if (got > 0 && buf[got - 1] == 0) got--;
    buf[got] = 0;
    JSValue r = JS_NewStringLen(ctx, buf, got);
    free(buf);
    return r;
}

/* ramfs_write(name, str[, len]) -> 0|1 */
static JSValue js_ramfs_write(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    char name[RAMFS_NAME_MAX + 2];   /* SAFETY: копия имени */
    char sshort[24];                 /* SAFETY: копия короткой строки (sb-путь) */
    (void)this_val; (void)argc;
    jarg_str_buf(name, (int)sizeof(name), ctx, &argv[0], "");
    if (!name[0]) return jint(ctx, 0);

    if (JS_IsString(ctx, argv[1])) {
        JSCStringBuf sb;
        size_t slen = 0;
        const char *s = JS_ToCStringLen(ctx, &slen, argv[1], &sb);
        if (!s) return jint(ctx, 0);
        if (s == (const char *)sb.buf) {
            /* короткая строка лежит в sb этого кадра — ниже идут вызовы
             * (jarg_int/ramfs_*), затирающие кадр: копируем немедленно. */
            u32 n = (u32)slen;
            if (n > sizeof(sshort) - 1) n = sizeof(sshort) - 1;
            memcpy(sshort, sb.buf, n);
            sshort[n] = 0;
            s = sshort;
        }
        u32 len = (u32)slen;
        if (argc >= 3 && jarg_int(ctx, &argv[2], 0) >= 0 &&
            (u32)jarg_int(ctx, &argv[2], 0) < len)
            len = (u32)jarg_int(ctx, &argv[2], 0);
        ramfs_delete(name);
        if (!ramfs_create(name, len + 1)) return jint(ctx, 0);
        return jint(ctx, ramfs_write(name, s, len + 1) ? 1 : 0);
    }

    /* legacy: ramfs_write(name, h, len) — из дескриптора */
    u32 size = 0;
    void *p = handle_ptr(jarg_int(ctx, &argv[1], 0), &size);
    if (!p) return jint(ctx, 0);
    u32 len = (u32)jarg_int(ctx, &argv[2], 0);
    if (len > size) len = size;
    ramfs_delete(name);
    if (!ramfs_create(name, len + 1)) return jint(ctx, 0);
    return jint(ctx, ramfs_write(name, p, len + 1) ? 1 : 0);
}

static JSValue js_ramfs_list(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    ramfs_dirent_t ents[RAMFS_MAX_FILES];
    int n = ramfs_list(ents, RAMFS_MAX_FILES);
    JSValue arr = JS_NewArray(ctx, n);
    for (int i = 0; i < n; i++)
        JS_SetPropertyUint32(ctx, arr, i, JS_NewString(ctx, ents[i].name));
    return arr;
}

/* ==================== SCRIPT GUI: окна и кнопки ====================
 * Перенос из cmscript_api.c без изменений семантики.
 *
 * Дескрипторы — индексы в статической таблице (без heap). Окно рисуется
 * колбэком sg_draw (фон + список примитивов + кнопки), клики от мыши
 * ловит sg_mouse, Esc закрывает окно. Скрипт опрашивает btn_clicked()
 * в цикле while (win_alive(id)) { ... delay(30); }.
 *
 * Потоки: sg_draw/sg_mouse/sg_key зовутся из задачи WM, js_win_* — из
 * задачи скрипта/REPL. Общий доступ к таблице сериализуется
 * s_lock(sg_lock); отрисовка идёт без блокировки — допускаем мгновенный
 * "рваный" кадр, но не дедлок.
 *
 * ВАЖНО: win_close()/win_create() вызываются ВНЕ блокировки — WM может
 * вызвать sg_close синхронно, и вложенный s_lock заклинил бы спинлок. */

/* СЕССИЯ 82 [SG-REAP]: было 4 — ГЛОБАЛЬНЫЙ пул на всю ОС (не на
 * процесс!): пятый калькулятор получал -1 и печатал «Нет свободных
 * окон» (жалоба пользователя: «лимит окон при <20 задачах»; в логах —
 * «done rc=0, 61 мс» сразу после запуска). Теперь 32 = WM_MAX_WINDOWS:
 * каждое sg-окно и так занимает слот WM, больше системного лимита
 * скрипту всё равно не дадут. Утечку слотов (после закрытия окна
 * used оставался =1 навсегда — 4 запуска ЖИЗНЬ ОС, даже с закрытием!)
 * лечит трио [SG-REAP]: owner + ленивое освобождение (sg_slot_reclaimable)
 * + уборка при смерти задачи-владельца (sg_win_release_owner/
 * sg_reap_dead). */
#define SG_MAX_WINS   32
#define SG_MAX_BTNS   16
#define SG_MAX_OPS    64
#define SG_TITLE_MAX  48
#define SG_LABEL_MAX  24
#define SG_TEXT_MAX   40

typedef struct {
    int  type;                      /* 0 = rect, 1 = text,
                                     * 2 = img (дескриптор imgsvc),
                                     * 3 = img_scaled (свой буфер ptr) */
    int  x, y, w, h;
    u32  color;
    char text[SG_TEXT_MAX];
    int  img_id;                    /* type 2: дескриптор imgsvc */
    void *ptr;                      /* type 3: буфер RGBA (владелец — op) */
} sg_op_t;

typedef struct {
    int  used;
    int  x, y, w, h;
    char label[SG_LABEL_MAX];
    int  hot;
    int  pressed;
} sg_btn_t;

typedef struct {
    int        used;
    int        owner;              /* СЕССИЯ 82 [SG-REAP]: задача, открывшая
                                     * окно (для уборки слотов после её смерти;
                                     * во время резерва слота — это ЖИВОЙ
                                     * вызывающий, так что reclaim его не
                                     * тронет); 0/-1 = «никто» = мёртв) */
    window_t  *win;                 /* NULL после закрытия */
    int        want_close;
    u32        bg;
    char       title[SG_TITLE_MAX];
    sg_btn_t   btns[SG_MAX_BTNS];
    sg_op_t    ops[SG_MAX_OPS];
    int        op_count;
    int        last_click;          /* номер нажатой кнопки или -1 */
} sg_win_t;

static sg_win_t g_sgw[SG_MAX_WINS];
static volatile int sg_lock = 0;

static sg_win_t *sg_lock_win(int id) {
    if (id < 0 || id >= SG_MAX_WINS) return NULL;
    s_lock(&sg_lock);
    if (!g_sgw[id].used) { s_unlock(&sg_lock); return NULL; }
    return &g_sgw[id];
}
static void sg_unlock_win(void) {
    s_unlock(&sg_lock);
}
static void sg_repaint(sg_win_t *g) {
    if (g && g->win) win_invalidate(g->win);
}
static void sg_copy_str(char *dst, int cap, const char *src) {
    int i = 0;
    if (src) for (; src[i] && i < cap - 1; i++) dst[i] = src[i];
    dst[i] = 0;
}

static void sg_free_ops(sg_win_t *g) {
    for (int i = 0; i < g->op_count && i < SG_MAX_OPS; i++) {
        sg_op_t *o = &g->ops[i];
        if (o->type == 3 && o->ptr) { free(o->ptr); o->ptr = NULL; }
        else if (o->type == 2 && o->img_id > 0) {
            img_release(o->img_id);
            o->img_id = 0;
        }
    }
    g->op_count = 0;
}

/* ---------- СЕССИЯ 82 [SG-REAP]: владение и уборка слотов ----------
 *
 * КОРЕНЬ жалобы «лимит окон при <20 задачах»: пул g_sgw[] — ГЛОБАЛЬНЫЙ
 * (4 слота на всю ОС), а слот ПОСЛЕ закрытия окна оставался used=1
 * навсегда (sg_close сознательно держал дескриптор для win_alive).
 * Итог: 4 запуска калькулятора (даже с закрытием!) — и пятый получает
 * «Нет свободных окон», rc=0 за 61–112 мс — ровно строки лога.
 *
 * Правила (без гонок с отрисовкой):
 *   - окно СЧИТАЕТСЯ закрытым только когда win==NULL И окно не в фазе
 *     резерва (owner резерва жив — его reclaim не тронет);
 *   - слот с закрытым окном и мёртвым владельцем освобождается
 *     ЛЕНИВО при следующем win_open (sg_slot_reclaimable);
 *   - при завершении задачи-скрипта её ещё открытые окна закрываются
 *     явно (sg_win_release_owner): want_close=1 + win_close; сам слот
 *     освободится лениво после фактического закрытия;
 *   - teardown REPL подметает ВСЕ слоты мёртвых владельцев
 *     (sg_reap_dead): REPL-окна переживают свою задачу eval по
 *     дизайну, но не должны переживать сам сеанс REPL.
 *
 * Ограничение: id владельца может быть переиспользован новой задачей
 * (слот таблицы задач перезаписан) — тогда слот УДЕРЖИВАЕТСЯ лишнее
 * время (безопасно, самозаживляется после смерти новой задачи). */
static int sg_owner_dead(int tid)
{
    if (tid <= 0 || tid >= MAX_TASKS) return 1;
    return !task_used(tid) || task_finished(tid);
}

/* Слот можно занять: свободен ИЛИ (окно закрыто + владелец мёртв).
 * Возвращает 1 и фактически освобождает слот. Вызывать под sg_lock. */
static int sg_slot_reclaimable(sg_win_t *g)
{
    if (!g->used) return 1;
    if (g->win != NULL) return 0;         /* окно живо — не трогаем */
    if (!sg_owner_dead(g->owner)) return 0;
    sg_free_ops(g);                       /* type-2/3 ресурсы ops */
    memset(g, 0, sizeof(*g));
    return 1;
}

/* Завершается задача tid — её окна-«зомби» должны уйти вместе с ней.
 * Открытые окна закрываются через штатный pending_close (сам слот
 * освобождается лениво: memset при живом окне НЕЛЬЗЯ — sg_draw/sg_key
 * работают через w->data = g до самого закрытия). */
void sg_win_release_owner(int tid)
{
    window_t *toclose[SG_MAX_WINS];
    int nclose = 0;
    if (tid <= 0) return;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++) {
        sg_win_t *g = &g_sgw[k];
        if (!g->used || g->owner != tid) continue;
        if (g->win) {
            g->want_close = 1;
            toclose[nclose++] = g->win;
        } else {
            /* окно уже закрыто (или резерва не случилось), а владелец
             * умирает сейчас — слот можно освободить немедленно */
            sg_slot_reclaimable(g);
        }
    }
    s_unlock(&sg_lock);
    for (int k = 0; k < nclose; k++) win_close(toclose[k]);  /* вне sg_lock */
}

/* Подметалка ВСЕХ слотов мёртвых владельцев (teardown REPL): окна,
 * пережившие свою задачу eval, закрываются; закрытые слоты — в пул.
 * Вызывается из потока терминала, когда REPL-сеанс завершён. */
static void sg_reap_dead(void)
{
    window_t *toclose[SG_MAX_WINS];
    int nclose = 0;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++) {
        sg_win_t *g = &g_sgw[k];
        if (!g->used || !sg_owner_dead(g->owner)) continue;
        if (g->win) {
            g->want_close = 1;
            toclose[nclose++] = g->win;
        } else {
            sg_slot_reclaimable(g);      /* немедленно в пул */
        }
    }
    s_unlock(&sg_lock);
    for (int k = 0; k < nclose; k++) win_close(toclose[k]);
}

/* ---------- колбэки окна (задача WM) ---------- */

static void sg_draw(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    int cw = win_content_w(w), ch = win_content_h(w);
    fb_fill_rect(0, 0, cw, ch, g->bg);

    /* снимок списка ops под sg_lock (см. cmscript_api.c: скриптовая
     * задача перестраивает список параллельно отрисовке).
     * СЕССИЯ 79 [BND-TRY]: ограниченное ожидание — скрипт, зависший
     * с sg_lock (или долго перестраивающий список), больше НЕ висит
     * потоком окна: рисуем фон/кнопки, кадр догоним на следующем
     * обновлении (win_update у скрипта частый). */
    sg_op_t snap[SG_MAX_OPS];
    int snap_n = 0;
    if (s_trylock_ms(&sg_lock, 30)) {
        snap_n = g->op_count;
        if (snap_n > SG_MAX_OPS) snap_n = SG_MAX_OPS;
        for (int i = 0; i < snap_n; i++) snap[i] = g->ops[i];
        s_unlock(&sg_lock);
    }

    for (int i = 0; i < snap_n; i++) {
        sg_op_t *o = &snap[i];
        if (o->type == 0) {
            int x = o->x, y = o->y, ww = o->w, hh = o->h;
            if (x < 0) { ww += x; x = 0; }
            if (y < 0) { hh += y; y = 0; }
            if (x + ww > cw) ww = cw - x;
            if (y + hh > ch) hh = ch - y;
            if (ww > 0 && hh > 0) fb_fill_rect(x, y, ww, hh, o->color);
        } else if (o->type == 1) {
            if (o->y > -16 && o->y < ch && o->x < cw)
                fb_text(o->x, o->y, o->text, o->color, -1);
        } else if (o->type == 2 && o->img_id > 0) {
            img_t t;
            if (img_retain(o->img_id) == 0 && img_get(o->img_id, &t) == 0) {
                if (t.rgba && t.w > 0 && t.h > 0)
                    fb_blit_rgba(t.rgba, t.w, t.h, o->x, o->y, t.w, t.h);
                img_release(o->img_id);
            }
        } else if (o->type == 3 && o->ptr) {
            if (o->w > 0 && o->h > 0)
                fb_blit_rgba((const u8 *)o->ptr, o->w, o->h,
                             o->x, o->y, o->w, o->h);
        }
    }

    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (!b->used) continue;
        u32 bgc = b->pressed ? fb_rgb(0x4A, 0x7F, 0xB0)
                : b->hot     ? fb_rgb(0x32, 0x60, 0x8E)
                : fb_rgb(0x25, 0x4A, 0x70);
        fb_fill_rect(b->x, b->y, b->w, b->h, bgc);
        fb_rect(b->x, b->y, b->w, b->h, wm_theme_accent());
        int tw = (int)strlen(b->label) * 8;
        int tx = (tw > b->w - 4) ? b->x + 2 : b->x + (b->w - tw) / 2;
        int ty = b->y + (b->h - 16) / 2 + 1;
        fb_text(tx, ty, b->label, wm_theme_text(), -1);
    }
}

static void sg_key(window_t *w, const key_event_t *ev) {
    if (ev->flags & KF_RELEASED) return;
    if (ev->ch == 0x1B || ev->code == 0x01) {   /* Esc */
        sg_win_t *g = (sg_win_t *)w->data;
        if (g) g->want_close = 1;
        win_close(w);
    }
}

static void sg_mouse(window_t *w, int mx, int my, u8 buttons, u8 changed) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;

    int btn = -1;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        if (b->used && mx >= b->x && mx < b->x + b->w &&
            my >= b->y && my < b->y + b->h) { btn = i; break; }
    }

    int redraw = 0;
    for (int i = 0; i < SG_MAX_BTNS; i++) {
        sg_btn_t *b = &g->btns[i];
        int h2 = (i == btn) ? 1 : 0;
        int p2 = (i == btn && (buttons & MSB_LEFT)) ? 1 : 0;
        if (b->hot != h2 || b->pressed != p2) {
            b->hot = h2; b->pressed = p2; redraw = 1;
        }
    }

    if ((changed & MSB_LEFT) && !(buttons & MSB_LEFT) && btn >= 0) {
        /* [BND-TRY]: клик теряется только если скрипт держит sg_lock
         * дольше 20 мс — вместо заморозки потока окна. */
        if (s_trylock_ms(&sg_lock, 20)) {
            g->last_click = btn;        /* ждёт btn_clicked() скрипта */
            s_unlock(&sg_lock);
        }
    }
    if (redraw) win_invalidate(w);
}

static void sg_close(window_t *w) {
    sg_win_t *g = (sg_win_t *)w->data;
    if (!g) return;
    s_lock(&sg_lock);
    /* СЕССИЯ 82: guard от НОВОЙ жизни слота — между постановкой
     * pending_close и его обработкой в kmain слот мог быть освобождён
     * и ЗАНЯТ другим скриптом; чужой слот трогать нельзя. */
    if (g->win == w) {
        g->win = NULL;
        g->want_close = 1;
    }
    s_unlock(&sg_lock);
    /* слот остаётся used до уборки [SG-REAP]: дескриптор скрипта
     * остаётся валидным для win_alive/btn_clicked (вернут 0/-1),
     * а после смерти владельца его подберёт sg_slot_reclaimable */
}

/* ---------- скриптовые функции (задача скрипта/REPL) ---------- */

static JSValue js_win_open(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    char title[SG_TITLE_MAX];        /* SAFETY: копия заголовка */
    int x, y, w, h;
    (void)ctx; (void)this_val; (void)argc;
    jarg_str_buf(title, (int)sizeof(title), ctx, &argv[0], "Script window");
    x = jarg_int(ctx, &argv[1], 100); y = jarg_int(ctx, &argv[2], 80);
    w = jarg_int(ctx, &argv[3], 240); h = jarg_int(ctx, &argv[4], 200);
    if (w < 60) w = 60;
    if (h < 40) h = 40;
    if (w > 800) w = 800;
    if (h > 600) h = 600;

    /* СЕССИЯ 79 [SG-ABBA-FIX]: win_create — СТРОГО ВНЕ sg_lock!
     * Дизайн (шапка секции): win_close/win_create зовутся вне
     * блокировки. Фактический код держал sg_lock и внутри брал
     * wm_glock (win_create) — цикл блокировок с композитором:
     *   поток окна: rlock -> sg_draw -> ждёт sg_lock
     *   kmain:     wm_glock (composite) -> отрисовки окон
     *   скрипт:    sg_lock -> win_create -> ждёт wm_glock
     * При пересечении — классический ABBA: скрипт (на AP) держит
     * sg_lock и ждёт wm_glock, поток окна держит rlock и ждёт
     * sg_lock — композитор/окна замирают до 20-с отбора замка,
     * потом «прорыв» в чужие секции = порча состояния. Это и был
     * «скрипт на одном ядре вешает окно из другого ядра».
     * Теперь: слот резервируем под sg_lock (used=1, win=NULL —
     * колбэки по нему ещё не приходят, окна нет), отпускаем,
     * создаём окно (только wm_glock), затем фиксируем win под
     * sg_lock. */
    int id = -1;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++)
        if (sg_slot_reclaimable(&g_sgw[k])) { id = k; break; }  /* [SG-REAP] */
    if (id >= 0) {
        sg_win_t *g = &g_sgw[id];
        memset(g, 0, sizeof(*g));
        g->used = 1;                 /* резерв слота: win==NULL */
        g->owner = task_current();   /* [SG-REAP]: живой резерв — не трогать */
        g->last_click = -1;
        g->bg = wm_theme_win_bg();
        sg_copy_str(g->title, SG_TITLE_MAX, title);
    }
    s_unlock(&sg_lock);

    if (id >= 0) {
        window_t *wn = win_create(g_sgw[id].title, x, y, w, h,
                                  sg_draw, sg_key, sg_mouse, NULL, sg_close,
                                  &g_sgw[id]);
        s_lock(&sg_lock);
        if (wn) g_sgw[id].win = wn;
        else    { g_sgw[id].used = 0; g_sgw[id].owner = 0; id = -1; }
        s_unlock(&sg_lock);
    }
    if (id < 0) {
        /* СЕССИЯ 82 [SG-DIAG]: отказ win_open раньше был НЕЛЬМОЙ —
         * единственным признаком было поведение скрипта (жалоба
         * «почему сообщение о лимите окон...»). Теперь причина видна
         * в serial рядом с [MQJS-LOG] строкой запуска. */
        extern void serial_puts(const char *s);
        char b[96];
        snprintf(b, sizeof(b),
                 "[mqjs] win_open: ОТКАЗ (нет слота sg/WM), задача %d '%s'\n",
                 task_current(), task_name(task_current()));
        serial_puts(b);
    }
    return jint(ctx, id);
}

static JSValue js_win_close(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    window_t *w = NULL;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used) {
        g_sgw[id].want_close = 1;
        w = g_sgw[id].win;
    }
    s_unlock(&sg_lock);
    if (w) win_close(w);            /* ВНЕ блокировки — см. шапку секции */
    return JS_UNDEFINED;
}

static JSValue js_win_alive(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int alive = 0;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used &&
        g_sgw[id].win && !g_sgw[id].want_close)
        alive = 1;
    s_unlock(&sg_lock);
    return jint(ctx, alive);
}

static JSValue js_win_clear(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        g->bg = (u32)jarg_int(ctx, &argv[1], 0);
        sg_free_ops(g);
        g->last_click = -1;
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

static JSValue js_win_rect(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 0;
            o->x = jarg_int(ctx, &argv[1], 0);
            o->y = jarg_int(ctx, &argv[2], 0);
            o->w = jarg_int(ctx, &argv[3], 0);
            o->h = jarg_int(ctx, &argv[4], 0);
            o->color = (u32)jarg_int(ctx, &argv[5], 0);
            o->img_id = 0; o->ptr = NULL; o->text[0] = 0;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

static JSValue js_win_text(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 1;
            o->x = jarg_int(ctx, &argv[1], 0);
            o->y = jarg_int(ctx, &argv[2], 0);
            o->w = o->h = 0;
            o->color = (u32)jarg_int(ctx, &argv[4], 0);
            jarg_str_buf(o->text, SG_TEXT_MAX, ctx, &argv[3], "");
            o->img_id = 0; o->ptr = NULL;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

static JSValue js_win_update(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    sg_win_t *g = sg_lock_win(id);
    window_t *w = NULL;
    if (g) { w = g->win; sg_unlock_win(); }
    if (w) win_invalidate(w);
    return JS_UNDEFINED;
}

static JSValue js_btn_add(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int ret = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        for (int i = 0; i < SG_MAX_BTNS; i++) {
            if (!g->btns[i].used) {
                sg_btn_t *b = &g->btns[i];
                b->used = 1;
                b->x = jarg_int(ctx, &argv[1], 0);
                b->y = jarg_int(ctx, &argv[2], 0);
                b->w = jarg_int(ctx, &argv[3], 20);
                b->h = jarg_int(ctx, &argv[4], 16);
                if (b->w < 8) b->w = 8;
                if (b->h < 8) b->h = 8;
                jarg_str_buf(b->label, SG_LABEL_MAX, ctx, &argv[5], "?");
                b->hot = 0;
                b->pressed = 0;
                ret = i;
                break;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return jint(ctx, ret);
}

static JSValue js_btn_clicked(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int r = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        r = g->last_click;
        g->last_click = -1;         /* pop: читается один раз */
        sg_unlock_win();
    }
    return jint(ctx, r);
}

static JSValue js_btn_set_label(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int bi = jarg_int(ctx, &argv[1], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (bi >= 0 && bi < SG_MAX_BTNS && g->btns[bi].used) {
            jarg_str_buf(g->btns[bi].label, SG_LABEL_MAX,
                         ctx, &argv[2], "?");
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

/* ==================== КАРТИНКИ (stb_image через imgsvc) ==================== */

/* img_load(path) -> дескриптор или -1. path — имя файла RAM disk или
 * http(s)://адрес. ВНИМАНИЕ: сетевая загрузка блокирующая (до 15 с),
 * как и вся сеть в этой ОС — скриптовая задача на это время спит. */
static JSValue js_img_load(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    char path[512];                  /* SAFETY: копия пути/URL (см. jarg_str_buf) */
    img_t t;
    (void)this_val; (void)argc;
    jarg_str_buf(path, (int)sizeof(path), ctx, &argv[0], "");
    if (!path[0] || img_decode_url(path, NULL, &t) != 0)
        return jint(ctx, -1);
    int id = img_open(&t);          /* владение rgba переходит дескриптору */
    if (id < 0) img_dispose(&t);
    return jint(ctx, id);
}

static JSValue js_img_free(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_release(jarg_int(ctx, &argv[0], -1));
    return JS_UNDEFINED;
}

static JSValue js_img_w(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(jarg_int(ctx, &argv[0], -1), &t) != 0) return jint(ctx, 0);
    return jint(ctx, t.w);
}

static JSValue js_img_h(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(jarg_int(ctx, &argv[0], -1), &t) != 0) return jint(ctx, 0);
    return jint(ctx, t.h);
}

/* img_pixel(id,x,y) -> 0xRRGGBB (альфа отброшена) или -1 */
static JSValue js_img_pixel(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    int x = jarg_int(ctx, &argv[1], 0), y = jarg_int(ctx, &argv[2], 0);
    if (img_get(jarg_int(ctx, &argv[0], -1), &t) != 0 || !t.rgba)
        return jint(ctx, -1);
    if (x < 0 || y < 0 || x >= t.w || y >= t.h)
        return jint(ctx, -1);
    const u8 *p = t.rgba + ((u32)y * (u32)t.w + (u32)x) * 4;
    return jint(ctx, ((int)p[0] << 16) | ((int)p[1] << 8) | (int)p[2]);
}

/* img_draw(id,x,y) — оригинальный размер, в текущую цель fb
 * (та же семантика, что у fill_rect/draw_text) */
static JSValue js_img_draw(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    if (img_get(jarg_int(ctx, &argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     jarg_int(ctx, &argv[1], 0), jarg_int(ctx, &argv[2], 0),
                     t.w, t.h);
    }
    return JS_UNDEFINED;
}

/* img_draw_scaled(id,x,y,w,h) — масштаб (nearest, целочисленный) */
static JSValue js_img_draw_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    img_t t;
    int w = jarg_int(ctx, &argv[3], 0), h = jarg_int(ctx, &argv[4], 0);
    if (img_get(jarg_int(ctx, &argv[0], -1), &t) == 0 && t.rgba &&
        t.w > 0 && t.h > 0 && w > 0 && h > 0 && w <= 4096 && h <= 4096) {
        fb_blit_rgba(t.rgba, t.w, t.h,
                     jarg_int(ctx, &argv[1], 0), jarg_int(ctx, &argv[2], 0), w, h);
    }
    return JS_UNDEFINED;
}

/* win_img(id, img_id, x, y) — картинка в окно (op держит ссылку
 * img_retain; img_free скриптом до win_clear просто оставит дырку) */
static JSValue js_win_img(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int iid = jarg_int(ctx, &argv[1], -1);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && img_retain(iid) == 0) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 2;
            o->x = jarg_int(ctx, &argv[2], 0);
            o->y = jarg_int(ctx, &argv[3], 0);
            o->w = o->h = 0;
            o->color = 0;
            o->text[0] = 0;
            o->img_id = iid;
            o->ptr = NULL;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

/* win_img_scaled(id, img_id, x, y, w, h) — op владеет масштабированной
 * копией (билинейной, под локом imgsvc) — оригинал можно img_free */
static JSValue js_win_img_scaled(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)ctx; (void)this_val; (void)argc;
    int id = jarg_int(ctx, &argv[0], -1);
    int iid = jarg_int(ctx, &argv[1], -1);
    int w = jarg_int(ctx, &argv[4], 0), h = jarg_int(ctx, &argv[5], 0);
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS && w > 0 && h > 0 &&
            w <= 4096 && h <= 4096) {
            img_t t, s;
            if (img_get(iid, &t) == 0 && t.rgba &&
                img_scale(&t, w, h, &s) == 0) {
                sg_op_t *o = &g->ops[g->op_count++];
                o->type = 3;
                o->x = jarg_int(ctx, &argv[2], 0);
                o->y = jarg_int(ctx, &argv[3], 0);
                o->w = s.w;
                o->h = s.h;
                o->color = 0;
                o->text[0] = 0;
                o->img_id = 0;
                o->ptr = s.rgba;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return JS_UNDEFINED;
}

/* ==================== таймеры, Date, gc ==================== */

/* кооперативные таймеры: прокачиваются из delay()/flip()/uptime() и
 * из poll'а REPL — движок остаётся однопоточным. */
void mqjs_pump_timers(JSContext *ctx)
{
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    if (!st) return;
    long long now = mqjs_now_ms();
    for (int i = 0; i < MQJS_MAX_TIMERS; i++) {
        if (!st->timers[i].used) continue;
        if (st->timers[i].timeout > now) continue;
        /* вынуть таймер ДО вызова (колбэк может поставить новый) */
        JSValue fn = st->timers[i].func.val;
        JS_DeleteGCRef(ctx, &st->timers[i].func);
        st->timers[i].used = 0;

        if (JS_StackCheck(ctx, 3)) {
            JS_GetException(ctx);       /* стек переполнен — таймер теряем */
            continue;
        }
        JS_PushArg(ctx, fn);            /* func */
        JS_PushArg(ctx, JS_NULL);       /* this */
        JSValue ret = JS_Call(ctx, 0);
        if (JS_IsException(ret)) {
            /* ошибка в колбэке — печатаем в вывод и продолжаем */
            JSValue e = JS_GetException(ctx);
            JS_PrintValueF(ctx, e, JS_DUMP_LONG);
            mqjs_state_write(st, "\n", 1);
        }
    }
}

static JSValue js_setTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    if (!st) return JS_ThrowInternalError(ctx, "no context state");
    if (!JS_IsFunction(ctx, argv[0]))
        return JS_ThrowTypeError(ctx, "not a function");
    int delay = jarg_int(ctx, &argv[1], 0);
    for (int i = 0; i < MQJS_MAX_TIMERS; i++) {
        if (!st->timers[i].used) {
            JSValue *p = JS_AddGCRef(ctx, &st->timers[i].func);
            *p = argv[0];
            st->timers[i].timeout = mqjs_now_ms() + delay;
            st->timers[i].used = 1;
            return jint(ctx, i);
        }
    }
    return JS_ThrowInternalError(ctx, "too many timers");
}

static JSValue js_clearTimeout(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc;
    mqjs_state_t *st = (mqjs_state_t *)JS_GetContextOpaque(ctx);
    int id = jarg_int(ctx, &argv[0], -1);
    if (st && id >= 0 && id < MQJS_MAX_TIMERS && st->timers[id].used) {
        JS_DeleteGCRef(ctx, &st->timers[id].func);
        st->timers[id].used = 0;
    }
    return JS_UNDEFINED;
}

static void mqjs_free_state(JSContext *ctx, mqjs_state_t *st)
{
    if (!st) return;
    for (int i = 0; i < MQJS_MAX_TIMERS; i++) {
        if (st->timers[i].used) {
            JS_DeleteGCRef(ctx, &st->timers[i].func);
            st->timers[i].used = 0;
        }
    }
    if (st->out && st->out_owned) { free(st->out); st->out = NULL; }
    free(st);
}

/* Date: без настенных часов — считаем от загрузки (как uptime) */
static JSValue js_date_constructor(JSContext *ctx, JSValue *this_val,
                                   int argc, JSValue *argv)
{
    double val;
    argc &= ~FRAME_CF_CTOR;
    if (argc == 0) {
        val = (double)mqjs_now_ms();
    } else if (argc == 1 && JS_IsNumber(ctx, argv[0])) {
        if (JS_ToNumber(ctx, &val, argv[0]))
            return JS_EXCEPTION;
    } else {
        return JS_ThrowTypeError(ctx, "unsupported Date() parameter");
    }
    return JS_NewDate(ctx, val);
}

static JSValue js_date_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt64(ctx, mqjs_now_ms());
}

static JSValue js_performance_now(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    return JS_NewInt64(ctx, mqjs_now_ms());
}

static JSValue js_gc(JSContext *ctx, JSValue *this_val, int argc, JSValue *argv)
{
    (void)this_val; (void)argc; (void)argv;
    JS_GC(ctx);
    return JS_UNDEFINED;
}

/* ==================== прерывание (Ctrl+C в REPL) ==================== */

static volatile int g_mqjs_abort = 0;    /* 1 = бросить "interrupted" */

static int mqjs_interrupt_handler(JSContext *ctx, void *opaque)
{
    (void)ctx; (void)opaque;
    /* кооперативность: не держим процессор monopolно при плотных циклах */
    task_yield();
    return g_mqjs_abort;
}

/* ==================== ЗАЩИТА ПАМЯТИ (safety) ====================
 *
 * Требование: затирание памяти со стороны JS (даже в случае бага
 * движка или злонамеренного скрипта) НЕ должно затрагивать ядро и
 * ронять ОС — гибнет только JS-программа. Слои защиты:
 *
 *   1. Канарейки вокруг пула движка: линейный выход за границы пула
 *      бьёт по магии ДО соседних блоков кучи ядра. Обнаружили порчу —
 *      НЕ ходим JS_FreeContext по испорченному контексту, а делаем
 *      raw-free пула и сегментов (free ядра сам валидирует заголовки).
 *   2. Реестр сессий (g_sessions): пул + все динамические сегменты хипа
 *      известны мосту независимо от состояния движка -> raw-free
 *      возможен всегда.
 *   3. mqjs_engine_fatal (вызывается из abort() движка): диагностика,
 *      raw-free сессии текущей задачи, task_exit(). Раньше abort был
 *      hlt-циклом — замораживал всю ОС.
 *   4. Перехват CPU-исключений (как у нативных c4-программ, loader.c):
 *      #UD/#GP/#DE в движке -> exc_panic делает longjmp в задачу,
 *      задача гибнет, ядро живёт.
 *   5. C-stack guard (JS_SetStackGuard): движок бросает исключение
 *      раньше, чем рекурсия C-стека задачи дойдёт до его низа
 *      (канарейка стека задачи — последний рубеж).
 *   6. Жнецы: память задач jsfile/jsrepl, убитых ватчдогом/kill/фаталом,
 *      освобождается raw-free (mquickjs_sessions_reap из главного цикла
 *      раз в секунду; REPL самолечится при следующем eval/poll/stop). */

#define MQJS_GUARD_WORDS 16
#define MQJS_GUARD_MAGIC 0xA5C0FFEEu
#define MQJS_MAX_SESSIONS 8
#define MQJS_SESS_RUN   1      /* mquickjs_run: живёт, пока работает задача */
#define MQJS_SESS_REPL  2      /* REPL: живёт до .exit / фатала / порчи   */

typedef struct {
    int  used;
    int  kind;
    int  task;                 /* RUN: задача-владелец; REPL: задача eval (-1 = нет) */
    u32 *guard_lo;             /* канарейки перед пулом */
    u32 *guard_hi;             /* канарейки после пула  */
    void *pool_raw;            /* весь malloc-блок (для raw-free) */
    mqjs_state_t *st;          /* вывод (для raw-free при фатале) */
    void *segs[24];            /* трекинг динамических сегментов хипа */
    int   nsegs;
} mqjs_session_t;

static mqjs_session_t g_sessions[MQJS_MAX_SESSIONS];
static volatile int g_sess_lock = 0;
/* hook REPL-сброса при фатале (устанавливается в mqjs_repl_start) */
static void (*mqjs_repl_fatal_hook)(void) = NULL;

/* ---------- перехват CPU-исключений (loader.c, песочница c4) ---------- */
#if !defined(__STDC_HOSTED__) || !__STDC_HOSTED__
#define MQJS_EXC_GUARD 1
extern void **loader_get_app_jmp(void);
extern void  loader_set_app_active(int active, u32 exc_num);
#endif

static u32 mqjs_guard_word(int i)
{
    return MQJS_GUARD_MAGIC ^ (u32)(0x9E3779B9u * (u32)(i + 1));
}

static void mqjs_guard_fill(u32 *g)
{
    for (int i = 0; i < MQJS_GUARD_WORDS; i++) g[i] = mqjs_guard_word(i);
}

static int mqjs_guard_ok(const u32 *g)
{
    for (int i = 0; i < MQJS_GUARD_WORDS; i++)
        if (g[i] != mqjs_guard_word(i)) return 0;
    return 1;
}

static void mqjs_report_corruption(const char *where)
{
    extern void serial_puts(const char *s);
    serial_puts("[mqjs] ЗАТИРАНИЕ ПАМЯТИ (");
    serial_puts(where);
    serial_puts("): канарейки пула побиты — задача гибнет, ОС продолжает работу\n");
}

static void mqjs_report_kill(const char *where)
{
    extern void serial_puts(const char *s);
    serial_puts("[mqjs] задача (");
    serial_puts(where);
    serial_puts(") убята во время исполнения JS — память освобождена, ОС продолжает работу\n");
}

/* выделить пул с канарейками по обоим краям */
static int mqjs_sess_alloc_pool(mqjs_session_t *se, u32 size)
{
    u32 words = size / (u32)sizeof(u32);
    u32 *raw = (u32 *)malloc(size + 2 * MQJS_GUARD_WORDS * (u32)sizeof(u32));
    if (!raw) return -1;
    se->pool_raw = raw;
    mqjs_guard_fill(raw);
    se->guard_lo = raw;
    se->guard_hi = raw + MQJS_GUARD_WORDS + words;
    mqjs_guard_fill(se->guard_hi);
    return 0;
}

/* указатель, который получает движок (внутри канареек) */
static void *mqjs_sess_pool(mqjs_session_t *se)
{
    return (void *)(se->guard_lo + MQJS_GUARD_WORDS);
}

static int mqjs_sess_pool_ok(mqjs_session_t *se)
{
    return mqjs_guard_ok(se->guard_lo) && mqjs_guard_ok(se->guard_hi);
}

static mqjs_session_t *mqjs_sess_alloc(int kind, int task, mqjs_state_t *st)
{
    s_lock(&g_sess_lock);
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++) {
        mqjs_session_t *se = &g_sessions[i];
        if (se->used) continue;
        memset(se, 0, sizeof(*se));
        se->used = 1;
        se->kind = kind;
        se->task = task;
        se->st = st;
        s_unlock(&g_sess_lock);
        return se;
    }
    s_unlock(&g_sess_lock);
    return NULL;
}

static mqjs_session_t *mqjs_sess_find(int kind)
{
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++)
        if (g_sessions[i].used && g_sessions[i].kind == kind)
            return &g_sessions[i];
    return NULL;
}

/* RAW-FREE: не трогаем структуры движка (они могут быть испорчены).
 * free() ядра сам валидирует заголовки блоков и отказывается от диких
 * указателей — порча не распространяется. */
static void mqjs_sess_release(mqjs_session_t *se)
{
    s_lock(&g_sess_lock);
    for (int k = 0; k < se->nsegs; k++) free(se->segs[k]);
    se->nsegs = 0;
    if (se->pool_raw) { free(se->pool_raw); se->pool_raw = NULL; }
    if (se->st) {
        if (se->st->out && se->st->out_owned) { free(se->st->out); se->st->out = NULL; }
        free(se->st);
        se->st = NULL;
    }
    se->used = 0;
    se->task = -1;
    s_unlock(&g_sess_lock);
}

/* трекинг динамических сегментов хипа (по задаче-владельцу; сегменты,
 * выделенные при создании контекста REPL, цепляются к REPL-сессии) */
static void mqjs_sess_track_seg(int task, void *p)
{
    if (!p) return;
    s_lock(&g_sess_lock);
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++) {
        mqjs_session_t *se = &g_sessions[i];
        if (!se->used) continue;
        int mine = (se->kind == MQJS_SESS_RUN && se->task == task) ||
                   (se->kind == MQJS_SESS_REPL &&
                    (se->task == task || se->task == -1));
        if (!mine) continue;
        if (se->nsegs < (int)(sizeof(se->segs) / sizeof(se->segs[0])))
            se->segs[se->nsegs++] = p;
        /* таблица полна: сегмент живёт без трекинга — при фатале
           останется утечкой (не порчей) */
        s_unlock(&g_sess_lock);
        return;
    }
    s_unlock(&g_sess_lock);
}

static void mqjs_sess_untrack_seg(void *p)
{
    if (!p) return;
    s_lock(&g_sess_lock);
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++) {
        mqjs_session_t *se = &g_sessions[i];
        if (!se->used) continue;
        for (int k = 0; k < se->nsegs; k++) {
            if (se->segs[k] == p) {
                se->segs[k] = se->segs[--se->nsegs];
                s_unlock(&g_sess_lock);
                return;
            }
        }
    }
    s_unlock(&g_sess_lock);
}

/* фатальный обработчик движка (abort() в OS-сборке больше НЕ замораживает
 * ОС: освобождаем память сессии текущей задачи raw-free и завершаем
 * задачу — ядро и остальные задачи продолжают работу) */
void mqjs_engine_fatal(const char *reason) __attribute__((noreturn));
void mqjs_engine_fatal(const char *reason)
{
    extern void serial_puts(const char *s);
    int t = task_current();
    s_lock(&g_sess_lock);
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++) {
        mqjs_session_t *se = &g_sessions[i];
        if (se->used && se->task == t) {
            mqjs_sess_release(se);      /* raw-free пула и сегментов */
        }
    }
    s_unlock(&g_sess_lock);
    /* REPL: если фатал случился в задаче eval — сбросить её состояние
       (hook устанавливает mqjs_repl_start) */
    if (mqjs_repl_fatal_hook) mqjs_repl_fatal_hook();
    serial_puts("[mqjs] FATAL: ");
    serial_puts(reason);
    serial_puts(" — задача завершена, ОС продолжает работу\n");
    task_exit();
    for (;;) { }                    /* noreturn */
}

/* перехват CPU-исключений: *crash_flag = 1 при исключении.
 * crash_flag — volatile: локальные volatile-переменные переживают
 * longjmp (регистры после __builtin_setjmp не сохраняются). */
#ifdef MQJS_EXC_GUARD
static void mqjs_protect(void (*body)(void *), void *arg, volatile int *crash_flag)
{
    loader_set_app_active(1, 0);
    void **jb = loader_get_app_jmp();
    if (!jb) {
        body(arg);                  /* защиты нет — как есть */
        loader_set_app_active(0, 0);
        return;
    }
    if (__builtin_setjmp(jb) == 0) {
        body(arg);
        loader_set_app_active(0, 0);
    } else {
        /* longjmp из exc_panic (#UD/#GP/#DE...): сегменты на всякий
           случай возвращаем в ядерные (для JS-задач они и так ядерные) */
        __asm__ __volatile__(
            "movw $0x10, %%ax\n\t"
            "movw %%ax, %%ds\n\t"
            "movw %%ax, %%es\n\t"
            "movw %%ax, %%ss\n\t"
            ::: "eax", "memory");
        loader_set_app_active(0, 0);
        *crash_flag = 1;
    }
}
#endif

/* C-stack guard: движок получает чистое исключение раньше, чем
 * переполнит стек задачи (32 КиБ). Запас 4 КиБ — служебные кадры и
 * канарейки остаются живыми. */
static void mqjs_apply_stack_guard(JSContext *ctx)
{
    u32 lo, hi;
    if (task_stack_range(&lo, &hi)) {
        JS_SetStackGuard(ctx, (void *)(unsigned long)(lo + 4096));
    }
}

/* жнец: raw-free памяти RUN-сессий, чьи задачи погибли (ватчдог/kill).
 * Вызывается из главного цикла раз в секунду. */
void mquickjs_sessions_reap(void)
{
    s_lock(&g_sess_lock);
    for (int i = 0; i < MQJS_MAX_SESSIONS; i++) {
        mqjs_session_t *se = &g_sessions[i];
        if (!se->used || se->kind != MQJS_SESS_RUN) continue;
        if (se->task > 0 && task_finished(se->task))
            mqjs_sess_release(se);
    }
    s_unlock(&g_sess_lock);
}

/* ==================== запуск скриптов ==================== */

/* Размер пула контекста. Движок living целиком в нём (heap+stack значений).
 * 256 КиБ хватает с запасом для GUI-скриптов; при нехватке JS бросает
 * OutOfMemory и скрипт завершается с ошибкой — не падаем. */
#define MQJS_RUN_POOL   (256 * 1024)

static void mqjs_dump_exception(JSContext *ctx, mqjs_state_t *st)
{
    JSValue e = JS_GetException(ctx);
    JS_PrintValueF(ctx, e, JS_DUMP_LONG);
    mqjs_state_write(st, "\n", 1);
}

/* аллокатор для расширяемого хипа (динамические сегменты) — с трекингом
 * для raw-free при фатале/убийстве задачи */
static void *mqjs_heap_alloc(size_t size)
{
    void *p = malloc((u32)size);
    if (p) mqjs_sess_track_seg(task_current(), p);
    return p;
}

static void mqjs_heap_free(void *ptr)
{
    if (!ptr) return;
    mqjs_sess_untrack_seg(ptr);
    free(ptr);
}

/* тело защищённого выполнения (обёрнуто в mqjs_protect) */
typedef struct {
    JSContext    *ctx;
    const char   *src;
    size_t        len;
    mqjs_state_t *st;
    int           flags;
    const char   *name;
    int           repl;            /* 1 = печать результата/ошибки REPL */
    int           threw;           /* out: JS-исключение (не фатал) */
} mqjs_evaljob_t;

static void mqjs_evaljob_body(void *a)
{
    mqjs_evaljob_t *j = (mqjs_evaljob_t *)a;
    JSValue val = JS_Eval(j->ctx, j->src, j->len, j->name, j->flags);
    j->threw = 0;
    if (JS_IsException(val)) {
        j->threw = 1;
        if (j->repl) {
            mqjs_dump_exception(j->ctx, j->st);
        } else {
            mqjs_state_write(j->st, "Ошибка: ", 7);
            mqjs_dump_exception(j->ctx, j->st);
        }
    } else if (j->repl && !JS_IsUndefined(val)) {
        JS_PrintValueF(j->ctx, val, JS_DUMP_LONG);
        mqjs_state_write(j->st, "\n", 1);
    }
    mqjs_pump_timers(j->ctx);
}

/* ==================== [MQJS-LOG] сессия 78: диагностика запусков ====================
 * Пользовательский фидбек: «некоторые запуски JS работают, некоторые
 * висят, некоторые исчерпывают окна». Раньше запуск не оставлял в
 * serial НИ СЛЕДА — искать виновника было нечем. Теперь каждый eval
 * пишет строку старта (задача, размер, поколение) и строку финиша
 * (rc, длительность): зависший запуск виден как старт без финиша. */
static volatile u32 mqjs_run_gen = 0;

static void mqjs_diag_run_start(const char *kind, u32 len)
{
    extern void serial_puts(const char *s);
    char b[96];
    u32 gen = ++mqjs_run_gen;
    snprintf(b, sizeof(b), "[mqjs] run %s: задача %d '%s', %u байт, gen %u\n",
             kind, task_current(), task_name(task_current()),
             (unsigned)len, (unsigned)gen);
    serial_puts(b);
}

static void mqjs_diag_run_end(const char *kind, u32 start_tick, int rc)
{
    extern void serial_puts(const char *s);
    char b[96];
    u32 ms = timer_ticks() - start_tick;
    snprintf(b, sizeof(b), "[mqjs] done %s: задача %d, rc=%d, %u мс\n",
             kind, task_current(), rc, (unsigned)ms);
    serial_puts(b);
}

int mquickjs_run(const char *src, char *out, u32 out_max)
{
    mqjs_state_t *st = (mqjs_state_t *)malloc(sizeof(mqjs_state_t));
    mqjs_session_t *se;
    JSContext *ctx;
    int rc = -1;
    u32 diag_t0 = timer_ticks();   /* [MQJS-LOG] */

    if (!st) return -1;
    memset(st, 0, sizeof(*st));
    st->out = out;
    st->out_pos = 0;
    st->out_max = out_max;
    if (out && out_max) out[0] = 0;

    /* [MQJS-LOG] старт eval: задача/размер/поколение. Зависший запуск
     * виден в логе как строка run без парной done. */
    mqjs_diag_run_start("file", (u32)strlen(src));

    se = mqjs_sess_alloc(MQJS_SESS_RUN, task_current(), st);
    if (!se) { mqjs_diag_run_end("file", diag_t0, -2); free(st); return -1; }
    if (mqjs_sess_alloc_pool(se, MQJS_RUN_POOL) != 0) {
        mqjs_sess_release(se);
        mqjs_diag_run_end("file", diag_t0, -2);
        return -1;
    }
    ctx = JS_NewContext(mqjs_sess_pool(se), MQJS_RUN_POOL, &js_stdlib);
    if (!ctx) {
        mqjs_state_write(st, "mquickjs: не удалось создать контекст\n", 38);
        mqjs_sess_release(se);
        mqjs_diag_run_end("file", diag_t0, -3);
        return -1;
    }
    /* расширяемый хип: основной пул 256К, далее аллокации уходят в
       динамические сегменты по 64К (до 1М сверху) */
    JS_EnableHeapGrowth(ctx, 64 * 1024, 1024 * 1024, mqjs_heap_alloc, mqjs_heap_free);
    JS_SetContextOpaque(ctx, st);
    JS_SetLogFunc(ctx, mqjs_log_write);
    JS_SetInterruptHandler(ctx, mqjs_interrupt_handler);
    JS_SetRandomSeed(ctx, (u64)timer_ticks() | 1);
    mqjs_apply_stack_guard(ctx);

    /* ЗАЩИТА: eval + прокачка таймеров под перехватом CPU-исключений */
    {
        mqjs_evaljob_t job;
        volatile int crashed = 0;
        memset(&job, 0, sizeof(job));
        job.ctx = ctx; job.src = src; job.len = strlen(src);
        job.st = st; job.flags = 0; job.name = "script"; job.repl = 0;
#ifdef MQJS_EXC_GUARD
        mqjs_protect(mqjs_evaljob_body, &job, &crashed);
#else
        mqjs_evaljob_body(&job);
#endif
        rc = job.threw ? -1 : 0;
        if (crashed) {
            /* CPU-исключение в движке: состояние произвольно — raw-free */
            extern void serial_puts(const char *s);
            serial_puts("[mqjs] CPU-исключение в скрипте — задача завершена, ОС жива\n");
            mqjs_state_write(st, "[mqjs] внутренняя ошибка движка (CPU exception)\n", 45);
            mqjs_sess_release(se);
            mqjs_diag_run_end("file", diag_t0, -4);
            return -1;
        }
    }

    /* СЕССИЯ 82 [SG-ORPHAN]: eval завершён (нормально или аварией) —
     * окна, оставшиеся открытыми, уходят вместе с задачей: без этого
     * окно-зомби висело до ручного Esc, а слот g_sgw утекал навсегда. */
    sg_win_release_owner(task_current());

    /* канарейки: порча за границами пула? */
    if (!mqjs_sess_pool_ok(se)) {
        mqjs_report_corruption("run");
        mqjs_state_write(st, "[mqjs] обнаружено затирание памяти у пула JS\n", 45);
        mqjs_sess_release(se);      /* контекст испорчен: без JS_FreeContext */
        mqjs_diag_run_end("file", diag_t0, -5);
        return -1;
    }

    mqjs_free_state(ctx, st);
    st = NULL;
    se->st = NULL;
    JS_FreeContext(ctx);
    free(se->pool_raw);
    se->pool_raw = NULL;
    se->used = 0;
    mqjs_diag_run_end("file", diag_t0, rc);
    return rc;
}

/* ==================== REPL (команда `js` в терминале) ==================== */

#define MQJS_REPL_POOL  (512 * 1024)
#define MQJS_REPL_OUT   8192
#define MQJS_REPL_INPUT_MAX 4096

static struct {
    JSContext     *ctx;
    void          *pool;
    mqjs_state_t  *st;             /* вывод текущего выполнения */
    /* вывод завершённой строки (забирается mqjs_repl_poll из WM) */
    char          *out;
    int            out_len;
    int            running;        /* задача eval активна */
    int            stop_requested; /* .exit при активной строке: задача
                                    * завершится и освободит всё сама */
    int            abort_pending;
    /* накопление многострочного ввода */
    char          *pending;
    int            pending_len;
    window_t      *term_win;       /* для win_invalidate по завершении */
    int            eval_task;      /* tid задачи eval (-1 = нет); для
                                    * обнаружения её смерти (ватчдог/kill) */
} g_repl;

void mqjs_repl_set_window(struct window *w)
{
    g_repl.term_win = (window_t *)w;
}

int mqjs_repl_busy(void) { return g_repl.running; }
int mqjs_repl_pending(void) { return g_repl.pending_len > 0; }

/* Незакрытые скобки/строки в накопленном вводе? Грубый сканер:
 * учитывает 'string', "string", `template`, // комментарии, block-комменты. */
static int mqjs_input_balanced(const char *s)
{
    int depth = 0;
    enum { CODE, LINE_COMMENT, BLOCK_COMMENT, SQ, DQ, TQ } st = CODE;
    for (; *s; s++) {
        switch (st) {
        case CODE:
            if (s[0] == '/' && s[1] == '/') { st = LINE_COMMENT; s++; }
            else if (s[0] == '/' && s[1] == '*') { st = BLOCK_COMMENT; s++; }
            else if (*s == '\'') st = SQ;
            else if (*s == '"') st = DQ;
            else if (*s == '`') st = TQ;
            else if (*s == '(' || *s == '[' || *s == '{') depth++;
            else if (*s == ')' || *s == ']' || *s == '}') depth--;
            break;
        case LINE_COMMENT:
            if (*s == '\n') st = CODE;
            break;
        case BLOCK_COMMENT:
            if (s[0] == '*' && s[1] == '/') { st = CODE; s++; }
            break;
        case SQ:
            if (*s == '\\') s++;
            else if (*s == '\'' || *s == '\n') st = CODE;
            break;
        case DQ:
            if (*s == '\\') s++;
            else if (*s == '"' || *s == '\n') st = CODE;
            break;
        case TQ:
            if (*s == '\\') s++;
            else if (*s == '`') st = CODE;
            break;
        }
    }
    return depth <= 0 && st != BLOCK_COMMENT && st != SQ && st != DQ && st != TQ;
}

/* ЖЁСТКИЙ сброс REPL: движок в произвольном состоянии (убит/фатал/порча)
 * — только raw-free без JS_FreeContext. */
static void mqjs_repl_hard_reset(void)
{
    mqjs_session_t *se = mqjs_sess_find(MQJS_SESS_REPL);
    if (se) mqjs_sess_release(se);
    g_repl.ctx = NULL;
    g_repl.pool = NULL;
    g_repl.st = NULL;
    if (g_repl.pending) { free(g_repl.pending); g_repl.pending = NULL; }
    g_repl.pending_len = 0;
    if (g_repl.out) { free(g_repl.out); g_repl.out = NULL; }
    g_repl.out_len = 0;
    g_mqjs_abort = 0;
    g_repl.stop_requested = 0;
    g_repl.running = 0;
    g_repl.eval_task = -1;
    sg_reap_dead();   /* СЕССИЯ 82 [SG-REAP]: слоты погибших eval-задач */
}

/* Задача eval умерла, не завершив строку (ватчдог/kill/фатал)? Лечим:
 * raw-free и чистое состояние — REPL продолжит работу со следующей строки. */
static void mqjs_repl_check_alive(void)
{
    if (!g_repl.running) return;
    int t = g_repl.eval_task;
    if (t > 0 && task_finished(t)) {
        mqjs_report_kill("REPL");
        mqjs_repl_hard_reset();
    }
}

/* Полный teardown контекста REPL (вызывается из терминала, когда
 * ничего не исполняется, ЛИБО из задачи eval по stop_requested). */
static void mqjs_repl_teardown(void)
{
    mqjs_session_t *se = mqjs_sess_find(MQJS_SESS_REPL);
    if (g_repl.ctx && se && se->pool_raw && mqjs_sess_pool_ok(se)) {
        /* движок здоров — обычная разборка с обходом контекста */
        mqjs_free_state(g_repl.ctx, g_repl.st);
        g_repl.st = NULL;
        se->st = NULL;
        JS_FreeContext(g_repl.ctx);
        g_repl.ctx = NULL;
        free(se->pool_raw);
        se->pool_raw = NULL;
        se->used = 0;
    } else {
        /* нет сессии/пула или канарейки побиты — только raw-free */
        if (se && se->pool_raw && !mqjs_sess_pool_ok(se))
            mqjs_report_corruption("REPL teardown");
        mqjs_repl_hard_reset();
        return;
    }
    g_repl.pool = NULL;
    if (g_repl.pending) { free(g_repl.pending); g_repl.pending = NULL; }
    g_repl.pending_len = 0;
    if (g_repl.out) { free(g_repl.out); g_repl.out = NULL; }
    g_repl.out_len = 0;
    g_mqjs_abort = 0;
    g_repl.stop_requested = 0;
    g_repl.running = 0;
    g_repl.eval_task = -1;
    sg_reap_dead();   /* СЕССИЯ 82 [SG-REAP]: REPL-окна переживают задачу
                         * eval, но не сеанс REPL */
}

/* задача исполнения строки REPL: контекст общий, активность одна */
static void mqjs_repl_task(void *arg)
{
    (void)arg;
    JSContext *ctx = g_repl.ctx;
    mqjs_state_t *st = g_repl.st;

    int flags = JS_EVAL_RETVAL | JS_EVAL_REPL;
    mqjs_apply_stack_guard(ctx);   /* guard СВОЕЙ задачи (старт был из терминала) */
    mqjs_evaljob_t job;
    volatile int crashed = 0;
    memset(&job, 0, sizeof(job));
    job.ctx = ctx;
    job.src = g_repl.pending;
    job.len = (size_t)g_repl.pending_len;
    job.st = st;
    job.flags = flags;
    job.name = "<repl>";
    job.repl = 1;
    /* [MQJS-LOG] строка REPL под тем же протоколом run/done */
    mqjs_diag_run_start("repl", (u32)g_repl.pending_len);
    u32 diag_t0 = timer_ticks();
#ifdef MQJS_EXC_GUARD
    mqjs_protect(mqjs_evaljob_body, &job, &crashed);
#else
    mqjs_evaljob_body(&job);
#endif
    g_repl.pending[0] = 0;
    g_repl.pending_len = 0;

    if (crashed) {
        /* CPU-исключение в движке: контекст в произвольном состоянии */
        mqjs_state_write(st, "[mqjs] внутренняя ошибка движка — контекст сброшен\n", 54);
        /* вывод ошибки — в буфер poll'а (как у обычной строки) */
        g_repl.out = (char *)malloc(MQJS_REPL_OUT);
        if (g_repl.out) {
            u32 n = st->out_pos;
            if (n > MQJS_REPL_OUT - 1) n = MQJS_REPL_OUT - 1;
            memcpy(g_repl.out, st->out, n);
            g_repl.out[n] = 0;
            g_repl.out_len = (int)n;
        }
        mqjs_diag_run_end("repl", diag_t0, -1);
        mqjs_repl_hard_reset();
        if (g_repl.term_win)
            win_invalidate(g_repl.term_win);
        task_exit();
    }

    /* pump_timers уже вызван внутри mqjs_evaljob_body (под защитой) */
    if (g_repl.stop_requested) {
        mqjs_diag_run_end("repl", diag_t0, -2);
        mqjs_repl_teardown();       /* .exit при активной строке */
        task_exit();
    }

    /* результат — в буфер poll'а; WM разбудим перерисовкой */
    g_repl.out = (char *)malloc(MQJS_REPL_OUT);
    if (g_repl.out) {
        u32 n = st->out_pos;
        if (n > MQJS_REPL_OUT - 1) n = MQJS_REPL_OUT - 1;
        memcpy(g_repl.out, st->out, n);
        g_repl.out[n] = 0;
        g_repl.out_len = (int)n;
    }
    st->out_pos = 0;
    st->out[0] = 0;

    g_mqjs_abort = 0;
    g_repl.running = 0;
    g_repl.eval_task = -1;
    mqjs_diag_run_end("repl", diag_t0, 0);
    {
        mqjs_session_t *se = mqjs_sess_find(MQJS_SESS_REPL);
        if (se) se->task = -1;
    }
    if (g_repl.term_win)
        win_invalidate(g_repl.term_win);   /* кросс-задачно, как sg_repaint */
    task_exit();
}

int mqjs_repl_start(void)
{
    if (g_repl.ctx) return 0;              /* уже запущен */
    memset(&g_repl, 0, sizeof(g_repl));
    g_repl.eval_task = -1;
    g_repl.st = (mqjs_state_t *)malloc(sizeof(mqjs_state_t));
    g_repl.out = NULL;
    g_repl.pending = (char *)malloc(MQJS_REPL_INPUT_MAX);
    if (!g_repl.st || !g_repl.pending) {
        if (g_repl.st) free(g_repl.st);
        if (g_repl.pending) free(g_repl.pending);
        memset(&g_repl, 0, sizeof(g_repl));
        g_repl.eval_task = -1;
        return -1;
    }
    memset(g_repl.st, 0, sizeof(*g_repl.st));
    g_repl.st->out_owned = 1;      /* буфер REPL принадлежит мосту */
    g_repl.st->out = (char *)malloc(MQJS_REPL_OUT);
    if (!g_repl.st->out) {
        free(g_repl.st); free(g_repl.pending);
        memset(&g_repl, 0, sizeof(g_repl));
        g_repl.eval_task = -1;
        return -1;
    }
    g_repl.st->out_max = MQJS_REPL_OUT;
    g_repl.st->out[0] = 0;
    g_repl.pending[0] = 0;

    /* сессия REPL: пул с канарейками + трекинг сегментов */
    {
        mqjs_session_t *se = mqjs_sess_alloc(MQJS_SESS_REPL, task_current(), g_repl.st);
        if (!se || mqjs_sess_alloc_pool(se, MQJS_REPL_POOL) != 0) {
            if (se) mqjs_sess_release(se);
            free(g_repl.st->out); free(g_repl.st);
            free(g_repl.pending);
            memset(&g_repl, 0, sizeof(g_repl));
            g_repl.eval_task = -1;
            return -1;
        }
        se->task = -1;             /* во время setup сегменты цепляются к REPL-сессии */
        g_repl.pool = mqjs_sess_pool(se);
    }
    g_repl.ctx = JS_NewContext(g_repl.pool, MQJS_REPL_POOL, &js_stdlib);
    if (!g_repl.ctx) {
        mqjs_session_t *se = mqjs_sess_find(MQJS_SESS_REPL);
        if (se) mqjs_sess_release(se);
        free(g_repl.st->out); free(g_repl.st);
        free(g_repl.pending);
        memset(&g_repl, 0, sizeof(g_repl));
        g_repl.eval_task = -1;
        return -1;
    }
    mqjs_repl_fatal_hook = mqjs_repl_hard_reset;
    /* расширяемый хип REPL: пул 512К + сегменты по 128К до 2М сверху */
    JS_EnableHeapGrowth(g_repl.ctx, 128 * 1024, 2 * 1024 * 1024,
                        mqjs_heap_alloc, mqjs_heap_free);
    JS_SetContextOpaque(g_repl.ctx, g_repl.st);
    JS_SetLogFunc(g_repl.ctx, mqjs_log_write);
    JS_SetInterruptHandler(g_repl.ctx, mqjs_interrupt_handler);
    JS_SetRandomSeed(g_repl.ctx, (u64)timer_ticks() | 1);
    return 0;
}

void mqjs_repl_stop(void)
{
    if (!g_repl.ctx) return;
    mqjs_repl_check_alive();       /* задача eval умерла? — лечим */
    if (g_repl.running) {
        /* строка ещё исполняется: прервать; контекст освободит задача
         * при выходе (mqjs_repl_teardown из mqjs_repl_task) */
        g_repl.stop_requested = 1;
        g_mqjs_abort = 1;
        return;
    }
    mqjs_repl_teardown();
}

int mqjs_repl_eval(const char *line)
{
    mqjs_repl_check_alive();       /* задача eval умерла? — лечим */
    if (!g_repl.ctx) {
        /* REPL не запущен либо погиб вместе с задачей — перезапуск */
        if (mqjs_repl_start() != 0) return -1;
    }
    if (g_repl.running) return 1;

    size_t ll = strlen(line);
    if (g_repl.pending_len + (int)ll + 2 > MQJS_REPL_INPUT_MAX - 1) {
        g_repl.pending[0] = 0;
        g_repl.pending_len = 0;
        return -1;
    }
    memcpy(g_repl.pending + g_repl.pending_len, line, ll);
    g_repl.pending_len += (int)ll;
    g_repl.pending[g_repl.pending_len++] = '\n';
    g_repl.pending[g_repl.pending_len] = 0;

    if (!mqjs_input_balanced(g_repl.pending))
        return 2;                        /* нужен ещё ввод */

    g_repl.running = 1;
    int tid = task_spawn("jsrepl", mqjs_repl_task, NULL);
    if (tid < 0) {
        g_repl.running = 0;
        g_repl.pending[0] = 0;
        g_repl.pending_len = 0;
        return -1;
    }
    g_repl.eval_task = tid;        /* для обнаружения смерти задачи */
    {
        mqjs_session_t *se = mqjs_sess_find(MQJS_SESS_REPL);
        if (se) se->task = tid;    /* fatal-обработчик найдёт сессию по задаче */
    }
    return 0;
}

int mqjs_repl_poll(char *out, u32 out_max)
{
    /* ВАЖНО: забираем и ПУСТОЙ вывод (например, после объявления
     * функции) — иначе буфер публикации утекает. */
    mqjs_repl_check_alive();       /* задача eval умерла? — лечим */
    if (g_repl.running || !g_repl.out)
        return 0;
    u32 n = (u32)g_repl.out_len;
    if (n > out_max - 1) n = out_max - 1;
    memcpy(out, g_repl.out, n);
    out[n] = 0;
    free(g_repl.out);
    g_repl.out = NULL;
    g_repl.out_len = 0;
    return (int)n;
}

void mqjs_repl_abort(void)
{
    if (g_repl.running)
        g_mqjs_abort = 1;                /* бросит "interrupted" в движке */
}

void mqjs_repl_reset_input(void)
{
    g_repl.pending[0] = 0;
    g_repl.pending_len = 0;
}

/* ==================== c4 GUI (перенос из cmscript_api.c) ====================
 *
 * Те же окна, что у SCRIPT GUI выше (sg_*), но с ПРЯМЫМИ C-сигнатурами:
 * адреса этих функций идут
 *   - в kapi_t.win_open..btn_set_label (native-путь: c4_x86 эмитит
 *     call [edi+KAPI_WIN_*]),
 *   - в таблицу c4_gui_api (VM-путь c4.c, интерпретатор).
 * Вызываются из задачи программы (loader_task_fn) — та же модель
 * потоков, что у js_win_*: таблица под s_lock, win_create/win_close —
 * ВНЕ блокировки. */

#include "kapi.h"   /* декларации c4k_* (и для kapi_fill в loader.c) */
#include "c4.h"     /* c4_gui_api_t: таблица VM-пути c4.c */

int c4k_win_open(const char *title, int x, int y, int w, int h)
{
    if (w < 60) w = 60;
    if (h < 40) h = 40;
    if (w > 800) w = 800;
    if (h > 600) h = 600;

    /* СЕССИЯ 79 [SG-ABBA-FIX]: как js_win_open — win_create ВНЕ sg_lock
     * (иначе цикл sg_lock -> wm_glock с композитором = дедлок). */
    int id = -1;
    s_lock(&sg_lock);
    for (int k = 0; k < SG_MAX_WINS; k++)
        if (sg_slot_reclaimable(&g_sgw[k])) { id = k; break; }  /* [SG-REAP] */
    if (id >= 0) {
        sg_win_t *g = &g_sgw[id];
        memset(g, 0, sizeof(*g));
        g->used = 1;                 /* резерв слота: win==NULL */
        g->owner = task_current();   /* [SG-REAP]: живой резерв — не трогать */
        g->last_click = -1;
        g->bg = wm_theme_win_bg();
        sg_copy_str(g->title, SG_TITLE_MAX, title ? title : "c4");
    }
    s_unlock(&sg_lock);

    if (id >= 0) {
        window_t *wn = win_create(g_sgw[id].title, x, y, w, h,
                                  sg_draw, sg_key, sg_mouse, NULL, sg_close,
                                  &g_sgw[id]);
        s_lock(&sg_lock);
        if (wn) g_sgw[id].win = wn;
        else    { g_sgw[id].used = 0; g_sgw[id].owner = 0; id = -1; }
        s_unlock(&sg_lock);
    }
    if (id < 0) {
        /* СЕССИЯ 82 [SG-DIAG]: как js_win_open — отказ не молчит */
        extern void serial_puts(const char *s);
        char b[96];
        snprintf(b, sizeof(b),
                 "[c4k] win_open: ОТКАЗ (нет слота sg/WM), задача %d '%s'\n",
                 task_current(), task_name(task_current()));
        serial_puts(b);
    }
    return id;
}

void c4k_win_close(int id)
{
    window_t *w = NULL;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used) {
        g_sgw[id].want_close = 1;
        w = g_sgw[id].win;
    }
    s_unlock(&sg_lock);
    if (w) win_close(w);            /* ВНЕ блокировки — см. шапку секции */
}

int c4k_win_alive(int id)
{
    int alive = 0;
    s_lock(&sg_lock);
    if (id >= 0 && id < SG_MAX_WINS && g_sgw[id].used &&
        g_sgw[id].win && !g_sgw[id].want_close)
        alive = 1;
    s_unlock(&sg_lock);
    return alive;
}

void c4k_win_clear(int id, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        g->bg = color;
        sg_free_ops(g);
        g->last_click = -1;
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_rect(int id, int x, int y, int w, int h, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 0;
            o->x = x; o->y = y; o->w = w; o->h = h;
            o->color = color;
            o->img_id = 0; o->ptr = NULL; o->text[0] = 0;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_text(int id, int x, int y, const char *s, u32 color)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (g->op_count < SG_MAX_OPS) {
            sg_op_t *o = &g->ops[g->op_count++];
            o->type = 1;
            o->x = x; o->y = y;
            o->w = o->h = 0;
            o->color = color;
            sg_copy_str(o->text, SG_TEXT_MAX, s ? s : "");
            o->img_id = 0; o->ptr = NULL;
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

void c4k_win_update(int id)
{
    sg_win_t *g = sg_lock_win(id);
    window_t *w = NULL;
    if (g) { w = g->win; sg_unlock_win(); }
    if (w) win_invalidate(w);
}

int c4k_btn_add(int id, int x, int y, int w, int h, const char *label)
{
    int ret = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        for (int i = 0; i < SG_MAX_BTNS; i++) {
            if (!g->btns[i].used) {
                sg_btn_t *b = &g->btns[i];
                b->used = 1;
                b->x = x; b->y = y;
                b->w = w > 0 ? w : 20;
                b->h = h > 0 ? h : 16;
                if (b->w < 8) b->w = 8;
                if (b->h < 8) b->h = 8;
                sg_copy_str(b->label, SG_LABEL_MAX, label ? label : "?");
                b->hot = 0;
                b->pressed = 0;
                ret = i;
                break;
            }
        }
        sg_unlock_win();
        sg_repaint(g);
    }
    return ret;
}

int c4k_btn_clicked(int id)
{
    int r = -1;
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        r = g->last_click;
        g->last_click = -1;         /* pop: читается один раз */
        sg_unlock_win();
    }
    return r;
}

void c4k_btn_set_label(int id, int btn, const char *label)
{
    sg_win_t *g = sg_lock_win(id);
    if (g) {
        if (btn >= 0 && btn < SG_MAX_BTNS && g->btns[btn].used) {
            sg_copy_str(g->btns[btn].label, SG_LABEL_MAX, label ? label : "?");
        }
        sg_unlock_win();
        sg_repaint(g);
    }
}

/* Таблица для VM-пути c4.c (интерпретатор): c4_gui_api глобально
 * инициализируется в kapi_fill (loader.c). */
static c4_gui_api_t g_c4_gui = {
    c4k_win_open, c4k_win_close, c4k_win_alive, c4k_win_clear,
    c4k_win_rect, c4k_win_text, c4k_win_update,
    c4k_btn_add, c4k_btn_clicked, c4k_btn_set_label
};

void c4_gui_init(void)
{
    c4_gui_api = &g_c4_gui;
}
