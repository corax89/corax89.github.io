/* task.c — вытесняющая многозадачность N2600-OS.
 *
 * Архитектура переключения контекста:
 *   1. PIT генерирует IRQ0 каждые 1 мс (СЕССИЯ 33: 1000 Гц — было 100 Гц).
 *      Зачем: точные короткие паузы (task_msleep(1) раньше длил 10 мс —
 *      все тайминги USB/WiFi/скана раздувались кратно), плавнее UI,
 *      быстрее реакция горячей замены задач.
 *   2. CPU входит в irq_stub_0 (naked-функция), который:
 *        pusha                  — сохраняет 8 general regs в стеке текущей задачи;
 *        cld; pushl %esp; call _task_schedule
 *                               — передаёт C-функции указатель на pusha-кадр;
 *        movl %eax, %esp        — переключает стек на сохранённый кадр новой задачи;
 *        popa; iret             — восстанавливает regs и EIP/CS/EFLAGS новой задачи.
 *
 *   3. task_schedule():
 *        - инкрементирует системные тики (ticks);
 *        - шлёт EOI master PIC;
 *        - сохраняет tasks[cur].esp = saved_esp;
 *        - инкрементирует uptime задачи, которая только что работала;
 *        - round-robin выбирает следующую активную задачу;
 *        - возвращает tasks[next].esp.
 *
 * Для новой задачи fabricate-стек: на вершине выделенного стека
 * кладётся фейковый кадр iret (EIP=task_trampoline, CS=0x08, EFLAGS=IF=1)
 * и под ним — pusha-кадр из нулей. Первое переключение на новую задачу
 * popa-нет нули и iret-ом прыгает в task_trampoline, который зовёт fn(arg).
 *
 * Главная задача (kmain) — task[0]; её стек не fabricate-ится, так как
 * она уже работает на системном стеке _stack_top.
 *
 * Лимит задач: 256 (увеличен с 8). Каждый слот задаёт имя, статус,
 * стек (16 КиБ), uptime (число тиков, в которых задача исполнялась).
 */
#include "task.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"
#include "fb.h"
#include "gdt.h"   /* песочница: gdt_clear_task_region при переиспользовании слота */
#include "timer.h" /* сессия 78: pit2-дедлайны для KLOCK-STALE (работают под cli) */

extern void serial_puts(const char *s);   /* сессия 78: diag-логи klock/spawn */

#define TASK_STACK_SIZE (32 * 1024)
/* Сессия 13: 16 -> 32 КиБ. КОРНЕВАЯ ПРИЧИНА порчи кучи (см. apps.c):
 * кадр term_exec (ramtree: ents[128]=9.7КБ + cc: src_buf[8КБ]) плюс
 * loader_load (ents[64]=4.8КБ) переваливали за 16КБ — поток писал ниже
 * своего стекового блока в кучу, затирая заголовок соседнего блока
 * (size=0 -> malloc зависал под cli). 32КБ даёт запас; большие массивы
 * к тому же уведены со стека (apps.c: static). */

/* СЕССИЯ 59: КАНАРЕЙКИ СТЕКОВ. Порча кучи вернулась (лог fixed58:
 * «ПОРЧА КУЧИ: блок size=0» — заголовок блока, ИДУЩЕГО СРАЗУ ЗА
 * чьим-то стеком, побит значениями {4,0}). Стек растёт ВНИЗ, поэтому
 * переполнение пишёт сначала в СВОИ нижние байты, потом в заголовок
 * соседнего блока. Канарейка в нижних 8 байтах ЛОВИТ переполнение
 * ДО порчи кучи и называет задачу по имени. */
#define TASK_STACK_CANARY0 0xC7194A5Bu
#define TASK_STACK_CANARY1 0x5BA419C7u

/* Селектор данных ядра (flat 4 ГБ) — синхронизирован с gdt.c */
#define KERNEL_DS 0x10

/* Таймаут по умолчанию для IRQ-ватчдога: 5 секунд (5000 тиков по 1 мс).
 * Должен быть определён ДО task_schedule() (используется там). */
#define TASK_WATCHDOG_TICKS 5000

typedef struct {
    int  used;
    int  finished;
    u32 *esp;
    u8  *stack;
    u32  stack_size;
    char name[16];
    void (*fn)(void *);
    void *arg;
    u32  uptime;
    u32  last_active_tick;  /* последний тик, когда задача работала */
    u32  watchdog_timeout;  /* 0 = нет ватчдога, иначе макс тиков без активности */
    u32  last_uptime;       /* предыдущее значение uptime (для детекции зависания) */
    int  waiting;           /* 1 = задача спит, ждёт события (не «зависла») */
    int  system;            /* 1 = системная задача (ramfs-сервер и т.п.):
                              * kill запрещён — иначе умрёт подсистема ОС */
    int  lock_wait;         /* 1 = задача ждёт блокировку в s_lock (sync.h):
                              * ватчдог такие НЕ убивает — ими управляет
                              * таймаут отбора зависшей блокировки (20 с) */
    int  prio;              /* СЕССИЯ 34: приоритет (0=UI, 1=NORMAL, 2=BG) */
    int  canary;            /* СЕССИЯ 59: 1 = в НИЖНИЕ 8 байт стека записана
                              * канарейка (только собственные стеки; у
                              * песочницы stack = регион — там kapi-копия) */
    /* СЕССИЯ 75 (многоядерность):
     * cpu         — ядро, на которое назначена задача (0 = BSP);
     * on_cpu      — 1 = задача исполняется/переключается на AP
     *               (планировщик BSP такие пропускает — защита от
     *               двойного исполнения);
     * migrating   — 1 = задача «в перелёте» AP->BSP: BSP НЕ планирует
     *               её, пока AP не сохранит контекст и не снимет флаг;
     * holds_klock — 1 = задача держит ядровый замок (smp.h): замок
     *               ПЕРЕДАЁТСЯ при переключении контекста (без
     *               unlock/lock), флаг — координация с post-hlt
     *               захватом и источник правды «кто держит». */
    int  cpu;
    int  on_cpu;
    int  migrating;
    int  holds_klock;
} task_t;

static task_t tasks[MAX_TASKS];

static inline int task_prio_of(int i, u32 now)
{
    /* Эффективный приоритет: задача, не получавшая CPU дольше
     * TASK_STARVE_TICKS, временно планируется как UI (анти-голодание
     * фона при постоянной готовности UI-задач). */
    int p = tasks[i].prio;
    if (p < 0) p = 0;
    if (p >= TASK_PRIO_LEVELS) p = TASK_PRIO_LEVELS - 1;
    if (p > 0 && (u32)(now - tasks[i].last_active_tick) > TASK_STARVE_TICKS)
        p = 0;
    return p;
}
/* Защита памяти (песочница нативных c4-программ): линейная база региона
 * задачи; 0 = обычная задача ядра (сегменты flat). Массив НЕ static — на
 * него ссылается irq_stub_0 (пересчёт ESP при смене базы SS), поэтому
 * менять тип/порядок нельзя. */
u32 task_region_base[MAX_TASKS];
int cur_task = 0;   /* глобальный: читается из irq_stub_0 (asm) — ТОЛЬКО BSP */
static int   n_tasks  = 0;

/* ---- многоядерность (сессия 75) ----
 * g_ap_cur_task/core — исполняющаяся на AP задача (-1 = ни одной).
 * Пишутся ТОЛЬКО из task_ap_schedule (контекст LAPIC-таймера AP под
 * IF=0; одновременно исполняется максимум одна AP-задача — замок).
 * task_current()/task_exec_core() читают их для «кто исполняется».
 * g_ap_slice — непрерывный стаж исполнения AP-задач (fair-share).
 * s_rr_cursor — round-robin среди одинаково нагруженных AP. */
static volatile int g_ap_cur_task = -1;
static volatile int g_ap_cur_core = -1;
static volatile u32 g_ap_slice    = 0;
static u32          s_rr_cursor   = 0;

#include "smp.h"   /* ядровый замок: smp_klock_try/unlock, PIC-маска */

/* Захват замка от лица AP-исполнителя (+ маска PIC: драйверные IRQ
 * приходят только на BSP и не должны пересекаться с кодом задачи). */
static int klock_acq_ap(void)
{
    if (!smp_klock_try()) return 0;
    smp_pic_mask();
    return 1;
}

/* Освобождение замка AP-исполнителем (+ восстановление PIC). */
static void klock_rel_ap(void)
{
    smp_pic_restore();
    smp_klock_unlock();
}

/* Хук очистки слота: вызывается при переиспользовании слота задачи,
 * у которой был регион песочницы (kill/ватчдог — loader_task_fn не
 * дошёл до своего free). Loader устанавливает. */
static void (*task_slot_cleanup_cb)(int tid);

void task_set_slot_cleanup_hook(void (*cb)(int tid)) { task_slot_cleanup_cb = cb; }

u32 task_get_region_base(int tid)
{
    return (tid >= 0 && tid < MAX_TASKS) ? task_region_base[tid] : 0;
}

void task_set_region_base(int tid, u32 base)
{
    if (tid >= 0 && tid < MAX_TASKS) task_region_base[tid] = base;
}
static u32   last_sched_tick = 0;   /* тик, когда последний раз вызывался scheduler */

/* Системные тики — теперь инкрементируются из task_schedule (раньше timer_irq). */
static volatile u32 ticks = 0;

u32 timer_ticks(void) { return ticks; }
u32 uptime_sec(void)  { return ticks / 1000; }   /* СЕССИЯ 33: 1 тик = 1 мс */

extern void task_trampoline(void);

/* ---------- IRQ0 stub: переключение контекста ----------
 *
 * Защита памяти: кадр задачи теперь включает DS/ES/SS — задача,
 * работающая в песочнице (сегментный лимит, см. loader.c/gdt.c),
 * после вытеснения продолжает с СВОИМИ сегментами. Планировщик
 * работает с сегментами ядра (flat): задачи с лимитами не могут
 * покалечить таблицу tasks[] через чужое прерывание. */
__attribute__((naked, used)) void irq_stub_0(void)
{
    __asm__ __volatile__(
        "pusha\n\t"                  /* сохранить EAX,ECX,EDX,EBX,ESP_orig,EBP,ESI,EDI */
        "pushl %ss\n\t"             /* сегменты прерванной задачи (в её стеке) */
        "pushl %ds\n\t"
        "pushl %es\n\t"
        /* ЗАЩИТА ПАМЯТИ: сначала сегменты ДАННЫХ на ядро (читать
         * cur_task под песочницей нельзя — #GP), и лишь потом
         * пересчёт ESP. ECX после pusha мёртв. */
        "movl $0x10, %ecx\n\t"
        "movw %cx, %ds\n\t"
        "movw %cx, %es\n\t"
        /* Если прервана задача в песочнице: её SS имеет базу = регион,
         * ESP — смещение. Переводим ESP в абсолютный (регистр), чтобы
         * после смены SS планировщик работал на том же линейном стеке. */
        "movl cur_task, %eax\n\t"
        "movl task_region_base(,%eax,4), %eax\n\t"
        "addl %eax, %esp\n\t"
        "movw %cx, %ss\n\t"
        "cld\n\t"
        "pushl %esp\n\t"             /* arg: указатель на кадр (es,ds,ss,pusha) */
        "call _task_schedule\n\t"   /* планировщик: вернуть новый ESP в %eax */
        "movl %eax, %esp\n\t"        /* переключение стека (абсолютный адрес кадра) */
        /* DS здесь ещё ядро: читаем регион НОВОЙ задачи до восстановления
         * её сегментов (после popl %ds чтение ядра станет невозможным). */
        "movl cur_task, %eax\n\t"   /* scheduler уже обновил cur_task */
        "movl task_region_base(,%eax,4), %ecx\n\t"
        "popl %es\n\t"               /* сегменты НОВОЙ задачи */
        "popl %ds\n\t"
        "popl %eax\n\t"              /* слот SS новой задачи */
        "movw %ax, %ss\n\t"          /* SS = сегмент новой задачи (база региона) */
        "subl %ecx, %esp\n\t"       /* ESP = смещение в регионе (ядро: -0) */
        "popa\n\t"                   /* восстановить regs новой задачи */
        "iret\n\t"                   /* EIP/CS/EFLAGS новой задачи */
    );
}

/* ---------- планировщик ---------- */

/* FIX [T3]: вызывается из task_schedule (IRQ0-контекст) — см. ниже */
int task_watchdog_irq(u32 timeout_ticks);

u32 *task_schedule(u32 *saved_esp)
{
    u32 now = ticks + 1;
    ticks = now;
    outb(0x20, 0x20);                /* EOI master PIC (IRQ0 — на master) */

    if (n_tasks == 0) return saved_esp;   /* задач нет — остаёмся */

    /* Сохранить контекст текущей задачи */
    tasks[cur_task].esp = saved_esp;

    /* Инкремент uptime и обновление last_active_tick */
    u32 delta = now - last_sched_tick;
    tasks[cur_task].uptime += delta;
    tasks[cur_task].last_active_tick = now;
    last_sched_tick = now;

    /* FIX [T3]: ВАТЧДОГ В КОНТЕКСТЕ ПРЕРЫВАНИЯ. Раньше task_watchdog()
     * вызывался только из главного цикла kmain — если kmain зависал
     * (все приложения выполняются в task[0]!), ватчдог вообще не
     * запускался и зависала ВСЯ система. Здесь мы в IRQ0: прерывания
     * уже запрещены (interrupt gate), поэтому доступ к таблице задач
     * и куче атомарен по определению. Проверяем каждые 512 тиков (~0.5 с). */
    if ((now & 511u) == 0) {         /* ~ каждые 512 тиков (~0.5 с при 1000 Гц) */
        task_watchdog_irq(TASK_WATCHDOG_TICKS);
    }

    /* СЕССИЯ 75: ЯДРОВЫЙ ЗАМОК. Если текущая задача держит замок
     * (holds_klock — она была прервана mid-code) — передаём его следующей
     * напрямую, без unlock/lock. Если не держит (спала в hlt, замок
     * отпущен) — пробуем захватить: неудача = на другом ядре исполняется
     * AP-задача; НЕ переключаемся (вернёмся в текущий кадр — он сам
     * захватит замок после своего hlt). Так замок остаётся непрерывно
     * у «исполняющейся задачи», а кли()-секции сохраняют смысл. */
    int held = tasks[cur_task].holds_klock;
    if (!held && !smp_klock_try()) return saved_esp;

    /* Поиск следующей активной задачи. СЕССИЯ 34: приоритетное
     * планирование — среди готовых выбираем минимальный эффективный
     * приоритет (с учётом анти-голодания), внутри уровня — round-robin
     * (пропуская завершённые и СПЯЩИЕ). СЕССИЯ 75: только задачи с
     * cpu==0, не исполняющиеся на AP (on_cpu) и не «в перелёте»
     * (migrating — их контекст ещё не сохранён AP-ядром). */
    int next = cur_task;
    int found = 0;
    {
        int best = TASK_PRIO_LEVELS;
        for (int i = 0; i < MAX_TASKS; i++) {
            if (!tasks[i].used || tasks[i].finished || tasks[i].waiting)
                continue;
            if (tasks[i].cpu != 0 || tasks[i].on_cpu || tasks[i].migrating)
                continue;
            int p = task_prio_of(i, now);
            if (p < best) best = p;
            if (best == 0) break;
        }
        if (best < TASK_PRIO_LEVELS) {
            for (int t = 0; t < MAX_TASKS; t++) {
                int j = (cur_task + 1 + t) % MAX_TASKS;
                if (!tasks[j].used || tasks[j].finished || tasks[j].waiting)
                    continue;
                if (tasks[j].cpu != 0 || tasks[j].on_cpu || tasks[j].migrating)
                    continue;
                if (task_prio_of(j, now) == best) {
                    next = j;
                    found = 1;
                    break;
                }
            }
        }
    }
    if (!found) {
        /* Все задачи BSP завершены/спят — продолжаем текущую
         * (task[0]/kmain). Защита от невозможного состояния (task 0
         * ушла на AP) — просто остаёмся в текущем кадре. ВАЖНО: если
         * мы захватили замок выше (!held), приписываем его текущей
         * задаче — иначе её post-hlt захват закрутится в спине на
         * «чужом» замке. */
        next = 0;
        if (tasks[next].cpu != 0 || tasks[next].on_cpu || tasks[next].migrating
            || tasks[next].finished || !tasks[next].used) {
            tasks[cur_task].holds_klock = 1;
            return saved_esp;
        }
    }

    /* Передача замка: старый держатель -> новая задача (замок остаётся
     * захваченным; флаги переносят «право владения»). */
    tasks[cur_task].holds_klock = 0;
    tasks[next].holds_klock = 1;

    /* FIX (многопоточный WM): подкачать контекст рендера fb новой задачи
     * (canvas окна или экран). Вызов из IRQ0 — атомарен по определению. */
    fb_task_switch(cur_task, next);
    cur_task = next;
    return tasks[cur_task].esp;
}

/* ================= МНОГОЯДЕРНОСТЬ (сессия 75) ================= */

/* Готовая задача для ядра cpu: round-robin от start_after (-1 = с начала).
 * Пропускаем finished/waiting/migrating (у «перелётных» ещё не сохранён
 * контекст — их подхватит BSP после снятия флага AP-ядром). */
static int ap_pick(int cpu, int start_after)
{
    for (int t = 0; t < MAX_TASKS; t++) {
        int j = (start_after + 1 + t) % MAX_TASKS;
        if (j == 0) continue;                       /* kmain — только BSP */
        task_t *tk = &tasks[j];
        if (!tk->used || tk->finished || tk->waiting) continue;
        if (tk->cpu != cpu || tk->migrating) continue;
        return j;
    }
    return -1;
}

/* Планировщик AP-ядра (зовётся из ap_timer_irq_c, IF=0, по LAPIC-таймеру
 * 1000 Гц). Логика зеркальна task_schedule:
 *   - прервана задача этого ядра: сохранить контекст; выбрать следующую
 *     задачу ядра (замок ПЕРЕДАЁТСЯ) либо уйти в idle (замок ОТПУСТИТЬ —
 *     его подхватит BSP или другое ядро);
 *   - прерван idle: запомнить кадр; есть задача и замок свободен —
 *     захватить (+ маска PIC) и войти в задачу;
 *   - fair-share: после SMP_FAIR_TICKS непрерывных тиков — принудительный
 *     уход в idle на один тик (BSP разбирает прерывания/таймеры). */
u32 task_ap_schedule(u32 saved_esp, int core, volatile u32 *idle_esp)
{
    /* СЕССИЯ 77 [SMP-BOOT-GATE]: до smp_tasks_enable() (конец загрузки)
     * AP не получает задач — BSP грузит систему в одиночку, как в
     * до-SMP ядре. Иначе фоновые задачи стартуют на AP посреди boot-лога
     * и вешают BSP в s_lock (sti;hlt при замаскированном IRQ0). */
    if (!smp_tasks_enabled()) return saved_esp;

    int cur = g_ap_cur_task;

    if (cur < 0) {
        /* Ядро было в idle: сохранить кадр idle-цикла */
        *idle_esp = saved_esp;
        int next = ap_pick(core, (int)s_rr_cursor);
        if (next < 0 || !klock_acq_ap()) {
            g_ap_slice = 0;
            return saved_esp;                       /* остаёмся в idle */
        }
        tasks[next].on_cpu = 1;
        tasks[next].holds_klock = 1;
        tasks[next].last_active_tick = ticks;
        fb_task_switch_ap(-1, next, core);
        g_ap_cur_task = next;
        g_ap_cur_core = core;
        return (u32)(unsigned long)tasks[next].esp;
    }

    /* Прервана задача этого ядра: сохранить контекст и учёт */
    tasks[cur].esp = (u32 *)saved_esp;
    tasks[cur].uptime += 1;                         /* 1 тик (1000 Гц) */
    tasks[cur].last_active_tick = ticks;
    tasks[cur].on_cpu = 0;
    /* СЕССИЯ 78 [MIG-FIX]: migrating снимается при СОХРАНЕНИИ кадра —
     * в обеих ветках (idle и задача->задача). Раньше флаг сбрасывался
     * только в ветке ухода в idle: «перелётная» задача, прерванная
     * переходом на другую задачу, навсегда оставалась migrating и
     * выпадала из планирования (её не брал ни BSP, ни AP). */
    tasks[cur].migrating = 0;

    /* СЕССИЯ 79 [KLOCK-PASS-FIX]: замок могли ОТОбРАТЬ у cur, пока он
     * исполнялся (klock_steal с другого ядра — держатель завис в
     * cli-секции). Передать его следующей задаче «по наследству»
     * НЕЛЬЗЯ — физического владения уже нет. Передаём только если
     * флаг ещё наш; иначе захватываем заново (неудача — idle). */
    int klocked = tasks[cur].holds_klock;

    int force_idle = (g_ap_slice >= SMP_FAIR_TICKS);
    g_ap_slice++;

    int next = force_idle ? -1 : ap_pick(core, cur);
    if (next < 0) {
        /* Уход в idle: отпустить замок (только если он у нас) */
        if (klocked) {
            klock_rel_ap();
            tasks[cur].holds_klock = 0;
        }
        tasks[cur].migrating = 0;                   /* контекст сохранён */
        fb_task_switch_ap(cur, -1, core);
        g_ap_cur_task = -1;
        g_ap_cur_core = -1;
        g_ap_slice = 0;
        return *idle_esp;
    }

    if (klocked) {
        /* Задача -> задача того же ядра: передача замка без unlock/lock */
        tasks[cur].holds_klock = 0;
        tasks[next].holds_klock = 1;
    } else {
        /* Замок отобран у cur: физически владения нет — захват для next.
         * Конкурент (BSP/другое ядро) успел раньше — уходим в idle
         * на тик (без unlock — не наш замок). */
        if (!klock_acq_ap()) {
            tasks[cur].migrating = 0;
            fb_task_switch_ap(cur, -1, core);
            g_ap_cur_task = -1;
            g_ap_cur_core = -1;
            g_ap_slice = 0;
            return *idle_esp;
        }
        tasks[next].holds_klock = 1;
    }
    tasks[next].on_cpu = 1;
    tasks[next].last_active_tick = ticks;
    if (next != cur) {
        fb_task_switch_ap(cur, next, core);
        g_ap_cur_task = next;
        g_ap_cur_core = core;
    }
    return (u32)(unsigned long)tasks[next].esp;
}

/* Размещение новой задачи: наименее нагруженное онлайн-ядро.
 * score(ядро) = число готовых (не finished/waiting) задач на нём.
 * При равенстве предпочтение AP (реальный параллелизм) с round-robin
 * среди них. UI-задачи (отзывчивость) и песочницы (сегментная
 * механика irq_stub_0) — всегда на BSP. */
static int task_pick_core(int prio, int is_sandbox)
{
    /* СЕССИЯ 77 [SMP-BOOT-GATE]: во время загрузки всё — на BSP.
     * После smp_tasks_enable() новые задачи размещаются как обычно. */
    if (!smp_tasks_enabled()) return 0;
    if (prio <= TASK_PRIO_UI) return 0;
    if (is_sandbox) return 0;
    int online = smp_online_count();
    if (online <= 1) return 0;
    if (online > SMP_MAX_CPUS) online = SMP_MAX_CPUS;

    int score[SMP_MAX_CPUS];
    for (int c = 0; c < online; c++) {
        int n = 0;
        for (int i = 1; i < MAX_TASKS; i++) {
            if (!tasks[i].used || tasks[i].finished || tasks[i].waiting)
                continue;
            if (tasks[i].cpu == c) n++;
        }
        score[c] = n;
    }
    int best = score[0];
    for (int c = 1; c < online; c++)
        if (score[c] < best) best = score[c];

    int cands[SMP_MAX_CPUS];
    int nc = 0;
    for (int c = 1; c < online; c++)                 /* AP при равенстве */
        if (score[c] == best) cands[nc++] = c;
    if (nc == 0) return 0;                           /* BSP строго свободнее */
    s_rr_cursor++;
    return cands[s_rr_cursor % (u32)nc];
}

/* ---- операции с ядровым замком от лица задачи ----
 * cli-окна в release/acquire обязательны: между «снять флаг» и
 * «unlock» (и наоборот) не должен вклиниться AP-планировщик — иначе
 * замок «потеряется» (останется захваченным без держателя) или
 * снимется дважды. */

void task_klock_release_me(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && tasks[me].holds_klock) {
        tasks[me].holds_klock = 0;
        if (me == g_ap_cur_task) klock_rel_ap();     /* AP: + распаковка PIC */
        else smp_klock_unlock();
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* ================== СЕССИЯ 78 [KLOCK-STALE] ==================
 * Смертельный сценарий из лога пользователя (JS-запуск повесил ВСЮ
 * систему): AP-задача зависает, владея ядровым замком (cli-секция,
 * тихое зависание — не exc_panic), а BSP навсегда крутится в спине
 * task_klock_acquire_me под cli. Прерываний нет ни у кого: LAPIC-таймер
 * AP не вытесняет (IF=0 у зависшего), IRQ0 BSP блокирован тем же cli —
 * ватчдог стоит, справиться некому.
 *
 * Лечение (по разбору, п.1/п.2):
 *   - ожидание замка ОГРАНИЧЕНО: пауза-спин batch'ами; живой держатель
 *     на другом ядре отпускает замок за миллисекунды (fair-share),
 *     зависший — отбирается по pit2-дедлайну (KLOCK_STALE_US, реальное
 *     время — работает и под cli, и до sti на этапе загрузки);
 *   - мёртвый держатель (finished) отбирается НЕМЕДЛЕННО;
 *   - «потерянный» замок (занят, держателя нет) восстанавливается;
 *   - каждый отбор — громкая строка в serial: кто, кого, сколько ждали. */
#define KLOCK_SPIN_BATCH 2000u          /* pause-итераций между проверками */
#define KLOCK_STALE_US   5000000u       /* 5 с — отбор у живого, но «вечного» */

/* Кто держит замок сейчас (для диагностики/отбора): приоритет — задача,
 * исполняющаяся на AP (on_cpu). Консистентность не атомарна, но истина
 * нужна только на медленном пути ожидания (>KLOCK_SPIN_BATCH пауз). */
static int klock_owner_scan(void)
{
    int cand = -1;
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished || !tasks[i].holds_klock)
            continue;
        if (tasks[i].on_cpu) return i;
        if (cand < 0) cand = i;
    }
    return cand;
}

/* Принудительный отбор замка. owner >= 0: задача-держатель помечается
 * погибшей (как task_ap_panic_orphan) — исполняться она больше не будет
 * (зависла либо убита), а слот/стек корректно освободит task_spawn.
 * owner < 0: «потерянный» замок — только физическое освобождение.
 *
 * СЕССИЯ 79 [ZOMBIE-FIX]: НЕ трогаем g_ap_cur_task/cur_core/slice!
 * Раньше отбор СБРАСЫВАЛ g_ap_cur_task=-1, пока украденная задача ЕЩЁ
 * ИСПОЛНЯЕТСЯ на AP (до своего следующего LAPIC-тика). Следующий тик
 * AP видел «idle» и сохранял кадр ЗАМЕРШЕГО ЗАДАЧИ как idle-кадр — AP
 * «оживал» в мёртвом коде (зомби-воскресение): исполнение на чужом/
 * освобождённом стеке → invalid opcode (#6) → паника ядра в логе
 * пользователя. Теперь g_ap_cur_task остаётся: свой тик AP корректно
 * СОХРАНИТ кадр в tasks[owner].esp (задача finished — её больше не
 * выберут) и чисто уйдёт в idle. holds_klock уже снят — двойного
 * unlock не будет (ветка idle проверяет флаг). */
static void klock_steal(int owner, u32 waited_us)
{
    char b[96];
    if (owner >= 0 && owner < MAX_TASKS && tasks[owner].used) {
        /* СЕССИЯ 79 [STEAL-SYS]: СИСТЕМНЫЕ задачи (ramfs-сервер, wifi,
         * sata) отбор НЕ убивает — их смерть намертво блокирует
         * подсистемы ОС (лог пользователя: [klock] ОТБОР у 'wifi' —
         * и wifi-драйвер «пал»). У системной задачи снимается только
         * флаг: спящая перезахватит замок сама при пробуждении,
         * зависшая — перестаёт владеть замком, но подсистема жива
         * (wifi после respawn поднимет донгл заново). Несистемные
         * гибнут как раньше. */
        int is_system = tasks[owner].system;
        snprintf(b, sizeof(b),
                 "[klock] ОТБОР замка у задачи %d '%s' (ждали %u мс)%s\n",
                 owner, tasks[owner].name, waited_us / 1000u,
                 is_system ? " [СИСТЕМНАЯ — не убита]" : "");
        serial_puts(b);
        tasks[owner].holds_klock = 0;
        if (is_system) {
            /* on_cpu/g_ap_cur_task НЕ трогаем: задача может исполняться
             * на AP прямо сейчас — её следующий LAPIC-тик сам сохранит
             * кадр и перезахватит замок по-честному (см. ZOMBIE-FIX). */
        } else {
            tasks[owner].on_cpu = 0;
            if (owner != 0 && !tasks[owner].finished) {
                tasks[owner].finished = 1;   /* зависший держатель — сирота */
                if (n_tasks > 0) n_tasks--;
            }
            /* g_ap_cur_task/g_ap_cur_core/g_ap_slice — НЕ трогаем [ZOMBIE-FIX] */
        }
    } else {
        snprintf(b, sizeof(b),
                 "[klock] потерянный замок восстановлен (ждали %u мс)\n",
                 waited_us / 1000u);
        serial_puts(b);
    }
    smp_pic_restore();
    smp_klock_unlock();
}

/* Милость для «потерянного» замка: между физическим smp_klock_try и
 * установкой holds-флага (klock_acq_ap на AP / передача в task_schedule
 * на BSP) есть МИКРОСЕКУНДНОЕ окно «замок занят, владельца-флага нет».
 * Мгновенный «ремонт» отбирал замок у только что вошедшей задачи →
 * два ядра одновременно в kernel-коде (гонки, порча, #UD). Настоящий
 * потерянный замок остаётся бесхозным ВЕЧНО — грейс его всё равно
 * словит, а транзитное окно закрывается за микросекунды. */
#define KLOCK_LOST_GRACE_US 10000u   /* 10 мс */

void task_klock_acquire_me(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && !tasks[me].holds_klock) {
        u32 wait_start = 0;
        int  timed     = 0;
        u32  lost_deadline = 0;
        int  lost_timed    = 0;
        u32  spins     = 0;
        while (!smp_klock_try()) {
            if (++spins < KLOCK_SPIN_BATCH) {
                __asm__ __volatile__("pause");
                continue;
            }
            spins = 0;
            /* медленный путь: держатель должен прогрессировать */
            int owner = klock_owner_scan();
            if (owner < 0) {
                /* замок занят, держателя нет — ТРАНЗИТНОЕ окно захвата
                 * или настоящий «потерянный» замок. Чиним только после
                 * грейса [LOST-GRACE]. */
                if (!lost_timed) {
                    lost_deadline = timer_poll_deadline();
                    lost_timed = 1;
                    continue;
                }
                if (!timer_poll_expired(lost_deadline, KLOCK_LOST_GRACE_US))
                    continue;
                klock_steal(-1, KLOCK_LOST_GRACE_US);
                timed = 0;
                lost_timed = 0;
                continue;   /* замок свободен: try на следующей итерации */
            }
            lost_timed = 0;    /* владелец появился — окно закрылось */
            if (tasks[owner].finished) {
                /* держатель УБИТ, владея замком — немедленный отбор */
                klock_steal(owner, 0);
                timed = 0;
                continue;   /* см. выше: физически ПЕРЕЗАХВАТЫВАЕМ */
            }
            if (!timed) {
                wait_start = timer_poll_deadline();   /* pit2: живёт под cli */
                timed = 1;
            } else if (timer_poll_expired(wait_start, KLOCK_STALE_US)) {
                /* держатель жив, но 5 с не отдаёт замок: завис в cli-
                 * секции / тихо погиб. Система важнее инварианта. */
                klock_steal(owner, KLOCK_STALE_US);
                timed = 0;  /* новый держатель получает полные 5 с */
                continue;   /* физически перезахватываем освобождённый */
            }
        }
        if (me == g_ap_cur_task) smp_pic_mask();
        tasks[me].holds_klock = 1;
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

/* Сон задачи с отпуском замка: БЕЗ этого AP-задачи никогда не получили
 * бы CPU (BSP-задача висела бы держателем), а сон AP-задачи не
 * освобождал бы её ядро для остальных. Вызывается ВМЕСТО голого hlt
 * во ВСЕХ точках сна задач (task_yield/msleep, sync.h, wm, ramfs,
 * драйверные ожидания, главный цикл kmain). */
void task_hlt_idle(void)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0" : "=r"(if_had) :: "memory");
    /* СЕССИЯ 77 [SMP-HLT]: сон = sti+hlt. Под cli (IF=0 — фаза загрузки,
     * когда IRQ0 на BSP ещё замаскирован, или драйверная критическая
     * секция) hlt — это ВЕЧНЫЙ сон без источника прерываний. Раньше
     * «спящий» навсегда держал и ядровый замок. Теперь под cli сон
     * невозможен — выходим, вызывающий продолжит крутить свой цикл
     * (ожидание с опросом). Замок при этом НЕ трогаем: cli-секция
     * обязана сохранить владение. */
    if (!(if_had & 0x200)) return;
    task_klock_release_me();
    __asm__ __volatile__("sti\n\thlt" ::: "memory");
    __asm__ __volatile__("cli" ::: "memory");
    task_klock_acquire_me();
    __asm__ __volatile__("sti" ::: "memory");
}

/* Терминальный сон (task_exit / kill себя): отпустить замок навсегда. */
void task_idle_release(void)
{
    task_klock_release_me();
}

/* ---------- API ---------- */

void task_init(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].used = 0;
        tasks[i].finished = 0;
        tasks[i].esp = NULL;
        tasks[i].stack = NULL;
        tasks[i].stack_size = 0;
        tasks[i].name[0] = 0;
        tasks[i].fn = NULL;
        tasks[i].arg = NULL;
        tasks[i].uptime = 0;
        tasks[i].system = 0;
        tasks[i].lock_wait = 0;
        tasks[i].cpu = 0;
        tasks[i].on_cpu = 0;
        tasks[i].migrating = 0;
        tasks[i].holds_klock = 0;
    }
    /* task[0] — главная задача (контекст kmain), стек — системный */
    tasks[0].used = 1;
    tasks[0].finished = 0;
    tasks[0].stack = NULL;
    tasks[0].esp = NULL;
    tasks[0].fn = NULL;
    tasks[0].arg = NULL;
    tasks[0].uptime = 0;
    tasks[0].prio = TASK_PRIO_UI;   /* kmain — отзывчивость интерфейса */
    strncpy(tasks[0].name, "main", sizeof(tasks[0].name) - 1);
    tasks[0].name[sizeof(tasks[0].name) - 1] = 0;

    cur_task = 0;
    n_tasks = 1;
    last_sched_tick = 0;
}

static int task_spawn_impl(const char *name, void (*fn)(void *), void *arg,
                           u8 *stack_mem, u32 stack_size, int spawn_prio)
{
    /* Сохраняем IF: task_spawn теперь вызывается и ДО sti() в kmain
     * (создание окон на этапе загрузки) — не должен включать прерывания
     * раньше времени. */
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");

    /* Ищем свободный слот (1..MAX_TASKS-1; 0 — главная задача) */
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
        return -1;
    }

    /* Освобождаем память, если слот уже использовался (завершённая задача).
     * Для внешних стеков (песочница) это ВЕСЬ регион задачи — освобождение
     * отложено до переиспользования слота, потому что задача ещё может
     * стоять на этом стеке в hlt-цикле task_exit().
     * Песочница (kill/ватчдог): loader_task_fn не дошёл до своего free —
     * регион чистим хуком, GDT-запись гасим здесь же. */
    /* СЕССИЯ 77 [SPAWN-GATE] (1/2): если завершённая задача ЕЩЁ НА AP
     * (g_ap_cur_task == slot: finished уже выставлен, но кадр AP сохранит
     * только своим следующим тиком, ≤1 мс) — ждём её снятия под pause.
     * СЕССИЯ 78 [SPAWN-GATE-TMO]: ожидание ОГРАНИЧЕНО (~0.4-1 c). Раньше
     * зависшее ядро AP (не сохранившее кадр) навсегда вешало ЛЮБОЙ
     * spawn на BSP: вечный pause-спин под cli — без тиков, без ватчдога.
     * По таймауту слот принудительно освобождается (AP-владелец —
     * сирота, его хвосты подберут KLOCK-STALE/ватчдог). */
    {
        u32 gate_spins = 0;
        while (g_ap_cur_task == slot) {
            if (++gate_spins > 20000000u) {
                char b[80];
                snprintf(b, sizeof(b),
                         "[smp] spawn: слот %d застрял на AP — "
                         "принудительный сброс\n", slot);
                serial_puts(b);
                if (g_ap_cur_task >= 0 && g_ap_cur_task < MAX_TASKS)
                    tasks[g_ap_cur_task].on_cpu = 0;
                g_ap_cur_task = -1;
                g_ap_cur_core = -1;
                g_ap_slice    = 0;
                break;
            }
            __asm__ __volatile__("pause" ::: "memory");
        }
    }
    /* СЕССИЯ 77 [SPAWN-GATE] (2/2): гейт публикации. migrating=1 держим
     * ВСЁ заполнение слота — оба планировщика (BSP task_schedule и
     * AP ap_pick) пропускают migrating-задачи; снимаем флаг ОДНОЙ строкой
     * в самом конце, когда used/esp/cpu/имя уже согласованы. */
    tasks[slot].migrating = 1;
    if (tasks[slot].stack) {
        free(tasks[slot].stack);
        tasks[slot].stack = NULL;
    }
    if (task_region_base[slot]) {
        gdt_clear_task_region(slot);
        task_region_base[slot] = 0;
        if (task_slot_cleanup_cb) task_slot_cleanup_cb(slot);
    }

    u8 *stack = stack_mem;
    if (!stack) {
        stack = (u8 *)malloc(TASK_STACK_SIZE);
        if (!stack) {
            if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
            return -1;
        }
        stack_size = TASK_STACK_SIZE;
    }
    if (stack_size == 0) stack_size = TASK_STACK_SIZE;

    /* СЕССИЯ 59: канарейки в НИЖНИЕ 8 байт собственного стека
     * (только для malloc-стеков: у песочницы stack = регион,
     * там по смещению 0 лежит kapi-копия). */
    if (!stack_mem && stack_size >= 16) {
        ((u32 *)stack)[0] = TASK_STACK_CANARY0;
        ((u32 *)stack)[1] = TASK_STACK_CANARY1;
        tasks[slot].canary = 1;
    } else {
        tasks[slot].canary = 0;
    }

    /* Строим кадр: iret (EFLAGS, CS, EIP) + pusha (8 regs) + ss/ds/es.
     * Стек растёт вниз, поэтому кладём с вершины.
     * Сегменты новой задачи — ЯДРА (flat): песочницу (если нужно)
     * loader включает только вокруг вызова entry() — см. sandbox_call. */
    u32 *sp = (u32 *)(stack + stack_size);
    sp -= 1; *sp = 0x00000202;                       /* EFLAGS: reserved bit + IF=1 */
    sp -= 1; *sp = 0x08;                             /* CS */
    sp -= 1; *sp = (u32)(unsigned long)task_trampoline;  /* EIP */
    /* pusha order: EAX, ECX, EDX, EBX, ESP_orig, EBP, ESI, EDI */
    sp -= 1; *sp = 0;                                /* EAX */
    sp -= 1; *sp = 0;                                /* ECX */
    sp -= 1; *sp = 0;                                /* EDX */
    sp -= 1; *sp = 0;                                /* EBX */
    sp -= 1; *sp = (u32)(unsigned long)sp;            /* ESP_orig (игнорируется popa) */
    sp -= 1; *sp = 0;                                /* EBP */
    sp -= 1; *sp = 0;                                /* ESI */
    sp -= 1; *sp = 0;                                /* EDI */
    sp -= 1; *sp = KERNEL_DS;                        /* SS (восстановит stub) */
    sp -= 1; *sp = KERNEL_DS;                        /* DS */
    sp -= 1; *sp = KERNEL_DS;                        /* ES — после fabricate ESP указывает сюда */

    tasks[slot].used = 1;
    tasks[slot].finished = 0;
    tasks[slot].esp = sp;
    tasks[slot].stack = stack;
    tasks[slot].stack_size = stack_size;
    tasks[slot].fn = fn;
    tasks[slot].arg = arg;
    tasks[slot].uptime = 0;
    tasks[slot].last_active_tick = ticks;
    tasks[slot].watchdog_timeout = 0;
    tasks[slot].last_uptime = 0;
    tasks[slot].waiting = 0;
    tasks[slot].system = 0;
    tasks[slot].lock_wait = 0;
    tasks[slot].prio = spawn_prio;
    /* СЕССИЯ 75: размещение по наименее нагруженному ядру.
     * UI-задачи и песочницы (внешний стек) — всегда BSP. */
    tasks[slot].cpu = task_pick_core(spawn_prio, stack_mem != NULL);
    tasks[slot].on_cpu = 0;
    /* migrating остаётся 1 — гейт публикации [SPAWN-GATE], снимается
     * ОДНОЙ строкой в конце task_spawn_impl (см. ниже). */
    tasks[slot].holds_klock = 0;
    strncpy(tasks[slot].name, name ? name : "?", sizeof(tasks[slot].name) - 1);
    tasks[slot].name[sizeof(tasks[slot].name) - 1] = 0;
    /* Учёт памяти: стек выделен в контексте ПОРОЖДАЮЩЕЙ задачи —
     * переносим владение на новую (диспетчер задач покажет честные цифры) */
    mem_reassign(stack, slot);
    n_tasks++;

    /* СЕССИЯ 77 [SPAWN-GATE]: ПУБЛИКАЦИЯ — последняя операция. До этой
     * строки оба планировщика видят слот как migrating (пропускают):
     * гонки «used=1 при ещё старом esp/cpu» больше нет. */
    __asm__ __volatile__("" ::: "memory");
    tasks[slot].migrating = 0;

    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return slot;
}

void task_yield(void)
{
    /* Простая уступка: спим до следующего IRQ0, отпустив ядровый замок
     * (иначе AP-задачи не получили бы CPU, пока мы «уступаем»). */
    task_hlt_idle();
}

/* Сон на ms миллисекунд с уступкой CPU (СЕССИЯ 33: 1 тик = 1 мс при
 * 1000 Гц — точность ±1 мс вместо ±10 мс).
 * Экспортируется в приложения через kapi->msleep — это честная
 * семантика kdelay(ms) из c4 VM (раньше native-кодогенератор
 * эмитил один task_yield и анимации превращались в один кадр). */
void task_msleep(u32 ms)
{
    u32 start = timer_ticks();
    u32 need = ms;                   /* 1 тик = 1 мс (PIT 1000 Гц) */
    if (need == 0) need = 1;
    while ((timer_ticks() - start) < need) {
        task_hlt_idle();             /* сон с отпуском ядрового замка */
    }
}

int task_spawn_ext(const char *name, void (*fn)(void *), void *arg,
                   u8 *stack_mem, u32 stack_size)
{
    return task_spawn_impl(name, fn, arg, stack_mem, stack_size,
                           TASK_PRIO_NORMAL);
}

int task_spawn(const char *name, void (*fn)(void *), void *arg)
{
    return task_spawn_impl(name, fn, arg, NULL, 0, TASK_PRIO_NORMAL);
}

/* СЕССИЯ 34: spawn с приоритетом (wifi/usb/sata/netmon = BG,
 * потоки окон WM = UI). Приложениям и ramfs — обычный task_spawn. */
int task_spawn_prio(const char *name, void (*fn)(void *), void *arg, int prio)
{
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) prio = TASK_PRIO_NORMAL;
    return task_spawn_impl(name, fn, arg, NULL, 0, prio);
}

void task_set_priority(int idx, int prio)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    if (prio < 0 || prio >= TASK_PRIO_LEVELS) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    tasks[idx].prio = prio;
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int task_priority(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return TASK_PRIO_NORMAL;
    if (!tasks[idx].used) return TASK_PRIO_NORMAL;
    return tasks[idx].prio;
}

void task_exit(void)
{
    /* СЕССИЯ 75: «я» — ИСПОЛНЯЮЩАЯСЯ задача (на AP cur_task — чужой).
     * СЕССИЯ 79 [T0-GUARD]: НИКОГДА не помечаем задачу 0 (kmain)
     * завершённой. Раньше при инвертированном task_current (см.
     * [ROOT-FIX] в smp.c) trampoline на AP считал себя kmain и одним
     * task_exit() УБИВАЛ весь рабочий стол (мышь/клавиатура/композитинг
     * — всё исполняется в kmain). Даже при ошибке идентификации ядра
     * гибель kmain недопустима: молча остаёмся живыми. */
    int me = task_current();
    cli();
    if (me > 0 && me < MAX_TASKS && tasks[me].used && !tasks[me].finished) {
        tasks[me].finished = 1;
        if (n_tasks > 0) n_tasks--;
    }
    sti();
    /* Отпустить ядровый замок — иначе он останется у мёртвой задачи
     * и вся ОС встанет (никто не сможет войти в kernel-код).
     * [T0-GUARD]: если «мы» по ошибке kmain — замок НЕ отпускаем
     * THIRD-PARTY: task_klock_release_me снимет флаг ТОЛЬКО если он наш. */
    task_idle_release();
    /* Больше не вернёмся — ждём переключения на другую задачу. */
    for (;;) __asm__ __volatile__("hlt");
}

/* Завершить задачу по индексу. Если задача уже не используется или это
 * текущая задача — для текущей работает как task_exit().
 * Параметр idx может быть любым (проверяется валидность слота).
 * Возвращает 1 при успехе, 0 если слот не используется или задача уже завершена.
 * Стек задачи будет освобождён при следующем task_spawn() в этот слот.
 * СИСТЕМНЫЕ задачи (ramfs-сервер) убивать НЕЛЬЗЯ — их смерть намертво
 * блокирует файловые операции всей ОС; task_kill возвращает 0. */
int task_kill(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (idx == 0) return 0;             /* главную задачу (kmain) убивать нельзя */
    if (!tasks[idx].used) return 0;
    if (tasks[idx].finished) return 0;
    if (tasks[idx].system) return 0;    /* системная задача — под защитой */

    cli();
    tasks[idx].finished = 1;
    if (n_tasks > 0) n_tasks--;
    /* СЕССИЯ 78 [KLOCK-REL]: убитая задача могла владеть ядровым замком
     * (например, спала внутри cli-секции после захвата). Раньше замок
     * оставался «висеть» на мёртвом флаге holds_klock до отбора по 5-с
     * таймауту [KLOCK-STALE] — теперь освобождаем сразу, если задача
     * НЕ исполняется на AP прямо сейчас (там замок корректно передаст
     * AP-планировщик при сохранении кадра). */
    if (tasks[idx].holds_klock && !tasks[idx].on_cpu) {
        tasks[idx].holds_klock = 0;
        char b[80];
        snprintf(b, sizeof(b),
                 "[klock] замок убитой задачи %d '%s' освобождён\n",
                 idx, tasks[idx].name);
        serial_puts(b);
        smp_pic_restore();
        smp_klock_unlock();
    }
    /* Если убили текущую — уступить CPU. СЕССИЯ 75: замок у убитой
     * задачи подхватит планировщик при следующем переключении
     * (передача holds-флага). */
    if (idx == cur_task) {
        sti();
        task_idle_release();
        for (;;) __asm__ __volatile__("hlt");
    }
    sti();
    return 1;
}

int task_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].used && !tasks[i].finished) n++;
    return n;
}

/* СЕССИЯ 75: «текущая» задача = ИСПОЛНЯЮЩАЯСЯ.
 *
 * СЕССИЯ 78 [TASKC-CPU]: СЕМЕЙСТВО ЗАВИСАНИЙ ИЗ ЛОГА ПОЛЬЗОВАТЕЛЯ
 * («ПОВТОРНЫЙ вход задачи 10 в блокировку», пустые окна, зависание
 * после JS) имело корень ЗДЕСЬ. Раньше: g_ap_cur_task >= 0 заставлял
 * ЛЮБОЙ код считать себя AP-задачей:
 *   - BSP (kmain) при task_klock_acquire_me видел «себя» AP-задачу с
 *     holds_klock=1 и ПРОПУСКАЛ захват замка — главный цикл шёл
 *     ПАРАЛЛЕЛЬНО AP-задаче (две задачи в критических секциях: порча
 *     wins[], очередей, кучи);
 *   - s_lock записывал владельцем ЧУЖУЮ AP-задачу, а её собственный
 *     следующий вход определялся как «реентерабельность»;
 *   - task_klock_release_me на BSP мог «отпустить» ЧУЖОЙ замок
 *     (klock_rel_ap → PIC распакован, AP продолжает без замка).
 * Теперь ядро-исполнитель определяется честно: на AP (LAPIC включён —
 * MSR 0x1B бит 8; у BSP он выключен с smp_init) возвращается
 * g_ap_cur_task, на BSP — cur_task. До smp_init / до запуска AP
 * g_ap_cur_task == -1, ветка не срабатывает вовсе. */
int task_current(void)
{
    if (g_ap_cur_task >= 0 && smp_this_cpu_is_ap()) return g_ap_cur_task;
    return cur_task;
}

/* Ядро-исполнитель ТЕКУЩЕГО кода (0 = BSP, 1..N = AP). Вызывается из
 * задач и из fb-примитивов (выбор per-core набора fb-контекстов).
 * СЕССИЯ 78 [TASKC-CPU]: та же логика, что task_current — раньше BSP
 * при активной AP-задаче рисовал в НАБОР КОНТЕКСТОВ AP (fb_task_switch
 * уводил canvas BSP-задачи на чужой набор — артефакты/пустые окна). */
int task_exec_core(void)
{
    if (g_ap_cur_task >= 0 && smp_this_cpu_is_ap()) return g_ap_cur_core;
    return 0;
}

int task_cpu(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return -1;
    if (!tasks[idx].used) return -1;
    return tasks[idx].cpu;
}

int task_ap_is_idle(void)
{
    return g_ap_cur_task < 0;
}

/* СЕССИЯ 79 [PANIC-TASK]: CPU-исключение в ЗАДАЧЕ (не в kmain) —
 * задача снимается, ядро продолжает работать. Вызывается exc_panic
 * (idt.c) на BSP: помечаем ИСПОЛНЯЮЩУЮСЯ задачу погибшей, снимаем
 * её флаги, отпускаем ядровый замок (если числится за ней) и снимаем
 * PIC-маску. Блокировки s_lock, оставшиеся за задачей, восстановит
 * sync.h (мёртвый владелец освобождается ждущим). Возвращает 1, если
 * исключение изолировано (можно продолжать), 0 — виновник kmain/
 * загрузка (нужна полная паника). */
int task_panic_kill_current(void)
{
    int me = task_current();
    if (me <= 0 || me >= MAX_TASKS) return 0;
    if (!tasks[me].used) return 0;
    if (!tasks[me].finished) {
        tasks[me].finished = 1;
        tasks[me].on_cpu = 0;
        tasks[me].waiting = 0;
        tasks[me].lock_wait = 0;
        if (n_tasks > 0) n_tasks--;
    }
    if (tasks[me].holds_klock) {
        tasks[me].holds_klock = 0;
        smp_pic_restore();
        smp_klock_unlock();
    }
    return 1;
}

/* СЕССИЯ 76: паника на AP (зовётся из exc_panic, idt.c, в контексте
 * исключения AP, IF=0). Лог пользователя: #13 на AP при первом
 * переключении idle->задача — замок уже был у погибшего ядра и PIC
 * замаскирован, поэтому BSP замерзал намертво (нет IRQ0, нет тиков).
 * Здесь: задача, исполнявшаяся на AP, помечается погибшей (её код не
 * был запущен / контекст уже не вернуть), замок и PIC-маска
 * отпускаются — BSP продолжает работать, потеряв только это ядро и
 * одну задачу. Сам AP после этого уходит в hlt навсегда (cli). */
void task_ap_panic_orphan(void)
{
    int t = g_ap_cur_task;
    if (t >= 0 && t < MAX_TASKS && tasks[t].used && !tasks[t].finished) {
        tasks[t].finished = 1;
        tasks[t].on_cpu = 0;
        tasks[t].holds_klock = 0;
        if (n_tasks > 0) n_tasks--;
        /* стек не освобождаем (esp задачи мог указывать в него) —
         * блок отдаст task_spawn при переиспользовании слота */
    }
    g_ap_cur_task = -1;
    g_ap_cur_core = -1;
    g_ap_slice    = 0;
    smp_pic_restore();
    smp_klock_unlock();
}

/* Границы стека ТЕКУЩЕЙ задачи — для C-stack guard'а JS-движка
 * (mquickjs_api.c ставит JS_SetStackGuard на lo + запас).
 * Возвращает 1 для задач с собственным стеком (malloc-стек или песочница);
 * 0 для task[0] (kmain на системном стеке — движок там не исполняется,
 * guard остаётся выключенным). */
int task_stack_range(u32 *lo, u32 *hi)
{
    /* СЕССИЯ 75: границы стека ИСПОЛНЯЮЩЕЙСЯ задачи (JS на AP — свой стек) */
    int t = task_current();
    if (t < 0 || t >= MAX_TASKS) return 0;
    if (!tasks[t].used || !tasks[t].stack || tasks[t].stack_size < 256) return 0;
    if (lo) *lo = (u32)(unsigned long)tasks[t].stack;
    if (hi) *hi = (u32)(unsigned long)tasks[t].stack + tasks[t].stack_size;
    return 1;
}

/* Пометить задачу как системную (kill запрещён, ватчдог не трогает).
 * Используется для ramfs-сервера и других подсистем ядра. */
void task_set_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].system = 1;
}

int task_is_system(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].system;
}

const char *task_name(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return "";
    if (!tasks[idx].used) return "";
    return tasks[idx].name;
}

int task_used(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].used;
}

int task_finished(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 1;
    return tasks[idx].finished;
}

u32 task_uptime(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].uptime;
}

/* ---------- trampoline для новых задач ---------- */

void task_trampoline(void)
{
    /* СЕССИЯ 75: fn/arg своей задачи — через исполняющуюся (на AP
     * cur_task чужой — задача могла стартовать на другом ядре).
     * СЕССИЯ 79 [ROOT-FIX]: task_current() теперь честен на обоих
     * ядрах (см. smp_this_cpu_is_ap) — trampoline видит СВОЮ задачу. */
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS && tasks[me].fn)
        tasks[me].fn(tasks[me].arg);
    task_exit();
    for (;;) __asm__ __volatile__("hlt");
}

/* ---------------- сон и пробуждение (многопоточный WM) ---------------- */

/* Пометить задачу как спящую (вызывается ПОД cli из task_wait_event). */
void task_set_waiting_me(void)
{
    /* СЕССИЯ 75: «я» — исполняющаяся задача (на AP это не cur_task) */
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS)
        tasks[me].waiting = 1;
}

/* Разбудить задачу по индексу: снять waiting — следующий тик IRQ0
 * вернёт её в планирование. Безопасно из любого контекста.
 * FIX (ватчдог убивал разбуженные задачи): одновременно ОБНУЛЯЕМ
 * last_active_tick. Сценарий бага: задача спала 20 с (например, пока
 * держатель блокировки завис) — kmain будит её (waiting=0), но до
 * первого слота планировщика ватчдог видел «не планировалась 20 с»
 * и УБИВАЛ её. Теперь будение = отсчёт простоя заново (5 с форы,
 * а полный цикл планировщика ≤ 256×10 мс = 2.6 с). */
void task_wake(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used || tasks[idx].finished) return;
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    if (tasks[idx].used && !tasks[idx].finished) {
        tasks[idx].waiting = 0;
        tasks[idx].last_active_tick = ticks;   /* сброс счётчика простоя */
    }
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
}

int task_is_waiting(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].waiting;
}

/* Пометить/снять признак «жду блокировку» для ТЕКУЩЕЙ задачи.
 * Вызывается из s_lock (sync.h) ПОД cli — атомарно. Задача в ожидании
 * блокировки — НЕ «зависла»: ватчдог её не трогает, её судьбу решает
 * таймаут отбора блокировки (SLOCK_STALE_TICKS). Иначе ватчдог убивал
 * ждущие задачи через 5 с — и при зависании держателя выкашивал все
 * окна ДО срабатывания отбора блокировки. */
void task_set_lockwait_me(int on)
{
    int me = task_current();
    if (me >= 0 && me < MAX_TASKS)
        tasks[me].lock_wait = on ? 1 : 0;
}

int task_is_lockwait(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].lock_wait;
}

/* ---------- Ватчдог ---------- */

void task_set_watchdog(int idx, u32 timeout_ticks)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].watchdog_timeout = timeout_ticks;
    tasks[idx].last_uptime = tasks[idx].uptime;
}

u32 task_get_watchdog(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].watchdog_timeout;
}

/* FIX [T3b]: версия для вызова ИЗ ПРЕРЫВАНИЯ (уже с IF=0 — без cli/sti).
 * Критерий: задача не получала CPU дольше limit тиков. Заметим честно:
 * задача, зависшая в плотном цикле while(1){} БЕЗ hlt, всё равно
 * получает CPU по round-robin и этим критерием не ловится — для этого
 * нужны счётчики команд/привилегии (нет в x86 без MMU/PIT-профилирования).
 * Но главный сценарий пользователя (зависает kmain с приложениями,
 * либо задача навсегда теряет CPU) теперь отрабатывается: если task[0]
 * (kmain с браузером/терминалом) не планировался дольше таймаута —
 * зависшие вложенные задачи убиваются, система продолжает жить.
 * Стек НЕ освобождаем немедленно (esp задачи может указывать в него,
 * а free() из IRQ-контекста опасен) — отложено до task_spawn в этот слот. */
int task_watchdog_irq(u32 timeout_ticks)
{
    int killed = 0;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) continue;
        /* Системные задачи (ramfs-сервер) ватчдог НЕ убивает: их гибель
         * блокирует файловые операции навсегда. Они почти всегда спят
         * (waiting), а активными бывают microseconds при копировании. */
        if (tasks[i].system) continue;
        /* FIX (многопоточный WM): спящая задача (waiting) — это НЕ
         * зависание: она ждёт события. Иначе ватчдог убивал бы каждое
         * простаивающее окно через 5 секунд. */
        if (tasks[i].waiting) continue;
        /* Задача в ожидании блокировки (s_lock) — тоже НЕ зависание:
         * пока держатель жив, ждущий честно спит в hlt. Раньше ватчдог
         * убивал такие задачи через 5 с — и при 20-секундном зависании
         * держателя выкашивал ВСЕ окна до отбора блокировки. */
        if (tasks[i].lock_wait) continue;

        u32 idle = ticks - tasks[i].last_active_tick;
        u32 limit = tasks[i].watchdog_timeout ? tasks[i].watchdog_timeout
                                              : timeout_ticks;
        if (limit == 0) continue;

        /* СЕССИЯ 75: МИГРАЦИЯ голодающей AP-задачи на BSP. Задача на
         * AP, не получавшая CPU > 300 мс (замок прочно у BSP либо AP
         * перегружен), переезжает на BSP — fair-play и защита от
         * ватчдога.
         * СЕССИЯ 78 [MIG-FIX]: флаг migrating здесь НЕ ставится. Он
         * означает «контекст ещё не сохранён AP-ядром», но мигрируем мы
         * ТОЛЬКО задачи с on_cpu==0 — их кадр уже сохранён (esp валиден),
         * и ни одно ядро их не исполняет. С migrating=1 такую задачу
         * пропускали ОБА планировщика и никто не снимал флаг (его чистит
         * только ветка сохранения кадра cur в task_ap_schedule) — задача
         * НАВСЕГДА выпадала из планирования (лог: «запуски JS висят»).
         * Гонка «BSP ставит cpu=0 / AP подхватывает задачу в этот же
         * тик» самозалечивается: AP исполняет её один тик, при следующем
         * сохранении кадра on_cpu сбрасывается, BSP подхватывает. */
        if (tasks[i].cpu > 0 && !tasks[i].on_cpu && !tasks[i].migrating &&
            idle > 300) {
            int old_core = tasks[i].cpu;
            tasks[i].cpu = 0;
            {
                extern void serial_puts(const char *s);
                char b[80];
                /* СЕССИЯ 82: без #индекса две ОДНОВРЕМЕННЫЕ миграции
                 * (две задачи с одинаковым голодом в одном проходе
                 * ватчдога — как в логах пользователя) выглядели как
                 * задвоенная печать ОДНОЙ; теперь видно, что их две. */
                snprintf(b, sizeof(b),
                         "[smp] миграция: задача #%d '%s' AP%d -> BSP "
                         "(голода %u мс)\n",
                         i, tasks[i].name, old_core, idle);
                serial_puts(b);
            }
            continue;
        }

        if (idle > limit) {
            /* диагностика в serial: КТО убит (имя + возраст) */
            {
                extern void serial_puts(const char *s);
                char b[64];
                snprintf(b, sizeof(b), "[watchdog] kill #%d '%s' idle=%u\n",
                         i, tasks[i].name, idle);
                serial_puts(b);
            }
            tasks[i].finished = 1;
            if (n_tasks > 0) n_tasks--;
            /* СЕССИЯ 78 [KLOCK-REL]: убитая задача могла владеть ядровым
             * замком. Если она НЕ исполняется на AP прямо сейчас — замок
             * ничей навсегда (флаг передачи снять некому): освобождаем
             * немедленно, иначе ждущие вянут до отбора [KLOCK-STALE]. */
            if (tasks[i].holds_klock && !tasks[i].on_cpu) {
                tasks[i].holds_klock = 0;
                serial_puts("[watchdog] замок убитой задачи освобождён\n");
                smp_pic_restore();
                smp_klock_unlock();
            }
            killed++;
            /* Стек НЕ трогаем: tasks[i].stack освобождается в task_spawn() */
        }
    }
    return killed;
}

/* Публичная версия — с защитой cli/sti (FIX [T3c]: раньше меняла
 * таблицу задач и звала free() без запрета прерываний — гонка с IRQ0
 * и порча кучи). */
int task_watchdog(u32 timeout_ticks)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int killed = task_watchdog_irq(timeout_ticks);
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return killed;
}

/* СЕССИЯ 59: проверка канареек стеков (зовётся раз в секунду из
 * главного цикла). Переполнение стека задачи — единственный известный
 * механизм порчи кучи «заголовок соседнего блока» (сессии 13 и 59);
 * канарейка бьётся РАНЬШЕ заголовка и называет виновника. */
void task_check_stack_canaries(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].canary != 1 || !tasks[i].stack) continue;
        u32 c0 = ((u32 *)tasks[i].stack)[0];
        u32 c1 = ((u32 *)tasks[i].stack)[1];
        if (c0 == TASK_STACK_CANARY0 && c1 == TASK_STACK_CANARY1) continue;
        tasks[i].canary = 2;              /* доложить ОДИН раз */
        extern void serial_puts(const char *s);
        char b[96];
        snprintf(b, sizeof(b),
                 "[task] СТЕК ПЕРЕПОЛНЕН: #%d '%s' — кадр ушёл ниже блока "
                 "(портит кучу)\n", i, tasks[i].name);
        serial_puts(b);
    }
}
