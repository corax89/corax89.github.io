/* test_exfat_host.c — хост-харнесс для exfat.c (сессия 75).
 *
 * Компилируется вместе с src/exfat.c на хосте (64-битный gcc):
 *   gcc -Isrc -Dmalloc=exfat_hmalloc -Dfree=exfat_hfree ...
 * Заглушки: чтение/запись 512-байтных секторов из файла-образа
 * (строит mkexfat.py), RTC — фиксированное время.
 *
 * Проверяет: монтирование, список корня/каталога, чтение файлов
 * (ASCII/кириллица), поиск без учёта регистра, создание, запись
 * (создание+перезапись), mkdir, удаление (в т.ч. отказ на непустом
 * каталоге), перемонтирование с сохранением состояния.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- замена malloc/free ядра (exfat.c включает mem.h с u32-сигнатурой).
 * -Dmalloc=exfat_hmalloc переименовывает и обращения в ЭТОМ файле —
 * тело зовёт __builtin_malloc (макросом не подменяется). */
void *exfat_hmalloc(__SIZE_TYPE__ n) { return __builtin_malloc(n); }
void  exfat_hfree(void *p)           { __builtin_free(p); }

/* ---- заглушки ОС ---- */
void serial_puts(const char *s) { fputs(s, stdout); }

/* ---- заглушки RTC ---- */
void rtc_get_time(int *h, int *m, int *s) { *h = 12; *m = 34; *s = 56; }
void rtc_get_date(int *y, int *mo, int *d) { *y = 2025; *mo = 10; *d = 21; }

#include "exfat.h"

/* ---- образ ---- */
static unsigned char *g_img = NULL;
static unsigned long  g_img_size = 0;

static int host_rd(u32 lba, void *buf)
{
    unsigned long off = (unsigned long)lba * 512;
    if (off + 512 > g_img_size) return 0;
    memcpy(buf, g_img + off, 512);
    return 1;
}

static int host_wr(u32 lba, const void *buf)
{
    unsigned long off = (unsigned long)lba * 512;
    if (off + 512 > g_img_size) return 0;
    memcpy(g_img + off, buf, 512);
    return 1;
}

static int fails = 0;
#define CHECK(cond, msg) do { if (cond) printf("ok: %s\n", msg); \
    else { printf("FAIL: %s\n", msg); fails++; } } while (0)

static int load_image(const char *path)
{
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    g_img = malloc((size_t)n);
    if (!g_img) { fclose(f); return 0; }
    g_img_size = (unsigned long)n;
    size_t got = fread(g_img, 1, (size_t)n, f);
    fclose(f);
    return got == (size_t)n;
}

static int find_in_list(const fat32_dirent_t *ents, int n,
                        const char *name, u32 *size, u32 *cluster, u8 *attr)
{
    for (int i = 0; i < n; i++) {
        if (strcmp(ents[i].name, name) == 0) {
            if (size) *size = ents[i].size;
            if (cluster) *cluster = ents[i].first_cluster;
            if (attr) *attr = ents[i].attr;
            return 1;
        }
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: %s image [--mkfs out]\n", argv[0]); return 2; }
    if (!load_image(argv[1])) { printf("FAIL: образ не читается\n"); return 2; }

    /* СЕССИЯ 84: режим кросс-валидации с mkfs.exfat — том создан
     * НАСТОЯЩИМ форматтером (exfatprogs). Проверяем: probe, монтирование
     * (сюда входят чтение полной UpCase-таблицы и битовой карты), список
     * корня, ЗАПИСЬ файла и чтение назад. Образ сохраняется для fsck.exfat:
     * если fsck подтверждает том после записи — драйвер пишет по спеке. */
    if (argc >= 3 && strcmp(argv[2], "--mkfs") == 0) {
        CHECK(exfat_probe(g_img) == 1, "probe распознал exFAT (том mkfs.exfat)");
        CHECK(exfat_mount(host_rd, host_wr) == 1,
              "монтирование тома mkfs.exfat (VBR по спецификации)");
        CHECK(exfat_ready() == 1, "ready после mount");
        fat32_dirent_t ents[32];
        int n = exfat_list(0, ents, 32);
        CHECK(n == 0, "корень пустого тома mkfs.exfat — 0 файлов");
        const char *msg = "written by N2600-OS exFAT driver\n";
        u32 len = (u32)strlen(msg);
        u32 rc = exfat_write_file(0, "oswrite.txt", msg, len);
        CHECK(rc == len, "запись oswrite.txt в том mkfs.exfat");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "oswrite.txt", &e) == 1 && e.size == len,
              "oswrite.txt виден после записи");
        char rbuf[128];
        u32 got = exfat_read_file(e.first_cluster, e.size, rbuf, sizeof(rbuf) - 1);
        rbuf[got] = 0;
        CHECK(got == len && memcmp(rbuf, msg, len) == 0,
              "прочитано ровно то, что записали");
        if (argc >= 4) {
            FILE *o = fopen(argv[3], "wb");
            if (o) { fwrite(g_img, 1, g_img_size, o); fclose(o); }
        }
        printf(fails ? "\nИТОГ: %d ПРОВАЛ(ОВ)\n" : "\nИТОГ: ВСЕ ТЕСТЫ ПРОШЛИ\n",
               fails);
        return fails ? 1 : 0;
    }

    CHECK(exfat_probe(g_img) == 1, "probe распознал exFAT");

    CHECK(exfat_mount(host_rd, host_wr) == 1, "монтирование");
    CHECK(exfat_ready() == 1, "ready после mount");
    CHECK(strcmp(exfat_label(), "TESTVOL") == 0, "метка тома TESTVOL");

    /* ---- список корня ---- */
    fat32_dirent_t ents[32];
    int n = exfat_list(0, ents, 32);
    CHECK(n == 6, "в корне 6 объектов (hello, данные, chain, nofat, big, docs)");
    u32 sz = 0, cl = 0, data_cl = 0; u8 attr = 0;
    CHECK(find_in_list(ents, n, "hello.txt", &sz, &cl, &attr) && sz == 56,
          "hello.txt в списке, размер 56");
    CHECK(find_in_list(ents, n, "данные.dat", &sz, &data_cl, &attr) && sz == 5000,
          "данные.dat в списке (кириллица), размер 5000");
    CHECK(find_in_list(ents, n, "docs", &sz, &cl, &attr) && (attr & 0x10),
          "docs — каталог (attr 0x10)");

    /* ---- чтение ---- */
    {
        u8 buf[6000];
        u32 got = exfat_read_file(data_cl, 5000, buf, sizeof(buf));
        CHECK(got == 5000, "данные.dat прочитан целиком");
        int eq = got == 5000;
        for (u32 i = 0; eq && i < 5000; i++)
            if (buf[i] != (u8)((i * 7 + 3) & 0xFF)) eq = 0;
        CHECK(eq, "содержимое данные.dat совпадает байт-в-байт");
    }
    /* СЕССИЯ 83 [FIX NoFatChain]: много-кластерные чтения.
     * chain.bin — 3 кластера по FAT-цепочке; nofat.bin — 2+ кластера
     * NoFatChain (FAT-записи НУЛЕВЫЕ, как у Windows/mkfs.exfat).
     * Прежний exfat_read_file (sflags=0) обрывал nofat.bin на первом
     * кластере и отдавал 4096 байт вместо 8269. */
    {
        u32 chain_cl = 0, nofat_cl = 0, chain_sz = 0, nofat_sz = 0; u8 a2 = 0;
        CHECK(find_in_list(ents, n, "chain.bin", &chain_sz, &chain_cl, &a2) &&
              chain_sz == 12165, "chain.bin в списке, размер 12165");
        CHECK(find_in_list(ents, n, "nofat.bin", &nofat_sz, &nofat_cl, &a2) &&
              nofat_sz == 8269, "nofat.bin в списке, размер 8269");
        if (chain_cl) {
            static u8 b1[12165];
            u32 got = exfat_read_file(chain_cl, chain_sz, b1, sizeof(b1));
            CHECK(got == chain_sz, "chain.bin (FAT-цепочка) прочитан целиком");
            int eq = (got == chain_sz);
            for (u32 i = 0; eq && i < chain_sz; i++)
                if (b1[i] != (u8)((i * 13 + 5) & 0xFF)) eq = 0;
            CHECK(eq, "содержимое chain.bin совпадает байт-в-байт");
        }
        if (nofat_cl) {
            static u8 b2[8269];
            u32 got = exfat_read_file(nofat_cl, nofat_sz, b2, sizeof(b2));
            CHECK(got == nofat_sz, "nofat.bin (NoFatChain) прочитан ЦЕЛИКОМ, а не до 1-го кластера");
            int eq = (got == nofat_sz);
            for (u32 i = 0; eq && i < nofat_sz; i++)
                if (b2[i] != (u8)((i * 11 + 7) & 0xFF)) eq = 0;
            CHECK(eq, "содержимое nofat.bin совпадает байт-в-байт");
        }
    }
    {
        fat32_dirent_t h;
        CHECK(exfat_find_entry(0, "HELLO.TXT", &h) == 1,
              "поиск HELLO.TXT без учёта регистра");
        char buf[128];
        u32 got = exfat_read_file(h.first_cluster, h.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 56 && memcmp(buf, "Hello, exFAT!\n", 14) == 0,
              "содержимое hello.txt корректно");
    }

    /* ---- каталог docs ---- */
    {
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "docs", &d) == 1 && (d.attr & 0x10),
              "docs найден");
        fat32_dirent_t sub[8];
        int sn = exfat_list(d.first_cluster, sub, 8);
        CHECK(sn == 1 && strcmp(sub[0].name, "readme.md") == 0,
              "docs содержит readme.md");
    }

    /* ---- создание + запись нового файла ---- */
    {
        const char *msg = "Файл создан из N2600-OS (запись в exFAT).\n";
        u32 len = (u32)strlen(msg);
        u32 rc = exfat_write_file(0, "new.txt", msg, len);
        CHECK(rc == len, "запись new.txt (создание)");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "new.txt", &e) == 1 && e.size == len,
              "new.txt присутствует с верным размером");
        char buf[128];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == len && memcmp(buf, msg, len) == 0,
              "прочитано ровно то, что записано");
    }

    /* ---- перезапись существующего ---- */
    {
        const char *msg2 = "Overwritten!";
        u32 rc = exfat_write_file(0, "hello.txt", msg2, 12);
        CHECK(rc == 12, "перезапись hello.txt");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "hello.txt", &e) == 1 && e.size == 12,
              "hello.txt имеет новый размер 12");
        char buf[32];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 12 && strcmp(buf, "Overwritten!") == 0,
              "содержимое после перезаписи верно");
    }

    /* ---- mkdir + файл в подкаталоге ---- */
    {
        CHECK(exfat_mkdir(0, "sub") == 1, "mkdir sub");
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "sub", &d) == 1 && (d.attr & 0x10),
              "sub найден как каталог");
        u32 rc = exfat_write_file(d.first_cluster, "вложенный.txt",
                                  "nested", 6);
        CHECK(rc == 6, "запись в подкаталог (вложенный.txt)");
        fat32_dirent_t sub[8];
        int sn = exfat_list(d.first_cluster, sub, 8);
        CHECK(sn == 1 && strcmp(sub[0].name, "вложенный.txt") == 0,
              "вложенный.txt виден в списке sub");
    }

    /* ---- удаление ---- */
    {
        CHECK(exfat_delete(0, "new.txt") == 1, "удаление new.txt");
        fat32_dirent_t ents2[32];
        int n2 = exfat_list(0, ents2, 32);
        CHECK(!find_in_list(ents2, n2, "new.txt", NULL, NULL, NULL),
              "new.txt исчез из списка");
        CHECK(exfat_delete(0, "docs") == 0, "непустой docs удалить НЕЛЬЗЯ");
        fat32_dirent_t d;
        CHECK(exfat_find_entry(0, "docs", &d) == 1, "docs остался на месте");
        fat32_dirent_t r;
        CHECK(exfat_find_entry(d.first_cluster, "readme.md", &r) == 1 &&
              exfat_delete(d.first_cluster, "readme.md") == 1,
              "удаление readme.md внутри docs");
        CHECK(exfat_delete(0, "docs") == 1, "теперь пустой docs удаляется");
    }

    /* ---- перемонтирование: состояние на диске консистентно ---- */
    {
        exfat_detach();
        CHECK(exfat_mount(host_rd, host_wr) == 1, "перемонтирование после записи");
        fat32_dirent_t ents3[32];
        int n3 = exfat_list(0, ents3, 32);
        CHECK(find_in_list(ents3, n3, "hello.txt", NULL, NULL, NULL),
              "после ремоунта hello.txt на месте");
        CHECK(find_in_list(ents3, n3, "sub", NULL, NULL, NULL),
              "после ремоунта sub на месте");
        CHECK(!find_in_list(ents3, n3, "new.txt", NULL, NULL, NULL),
              "после ремоунта new.txt удалён");
        fat32_dirent_t e;
        CHECK(exfat_find_entry(0, "hello.txt", &e) == 1 && e.size == 12,
              "размер hello.txt после ремоунта = 12");
        char buf[32];
        u32 got = exfat_read_file(e.first_cluster, e.size, buf, sizeof(buf) - 1);
        buf[got] = 0;
        CHECK(got == 12 && strcmp(buf, "Overwritten!") == 0,
              "содержимое hello.txt после ремоунта верно");
    }

    /* сохранить итоговый образ для питон-проверок структур на диске */
    if (argc >= 3) {
        FILE *o = fopen(argv[2], "wb");
        if (o) {
            fwrite(g_img, 1, g_img_size, o);
            fclose(o);
        }
    }

    printf(fails ? "\nИТОГ: %d ПРОВАЛ(ОВ)\n" : "\nИТОГ: ВСЕ ТЕСТЫ ПРОШЛИ\n",
           fails);
    return fails ? 1 : 0;
}
