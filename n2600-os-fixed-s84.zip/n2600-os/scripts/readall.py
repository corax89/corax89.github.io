#!/usr/bin/env python3
"""readall.py — прочитать все выровненные текстовые строки скриншота.
Кэширует битовую плоскость один раз (быстро)."""
import sys
sys.path.insert(0, '/home/z/my-project/n2600-src/n2600-os/scripts')
from qmon import read_ppm, load_glyphs, cp_of_glyph

G = load_glyphs()
GC = {tuple(g): cp for g, cp in zip(G, [cp_of_glyph(i) for i in range(len(G))]) if cp}
PATH = sys.argv[1]
w, h, img = read_ppm(PATH)
# bit plane
bp = bytearray(w * h)
for i in range(w * h):
    p = img[i*3:i*3+3]
    bp[i] = 1 if (p[0] + p[1] + p[2]) > 400 else 0

# rows with bright content
rows = []
for y in range(h - 16):
    s = sum(bp[y*w:(y+1)*w])
    if s >= 8:
        rows.append(y)

def line(ytop, xo, n=95):
    out = []
    for c in range(n):
        x = xo + c * 8
        if x + 8 > w or ytop + 16 > h:
            out.append(" "); continue
        pat = []
        for ry in range(16):
            b = 0
            base = (ytop + ry) * w + x
            for rx in range(8):
                if bp[base + rx]:
                    b |= 0x80 >> rx
            pat.append(b)
        t = tuple(pat)
        if any(pat):
            cp = GC.get(t)
            out.append(chr(cp) if cp else "?")
        else:
            out.append(" ")
    return "".join(out)

printed = set()
for y in rows:
    if y - 1 in printed or y - 2 in printed:
        continue
    best = (0, None, None)
    for xo in range(8):
        t = line(y, xo)
        s = sum(1 for ch in t if ch not in ('?', ' '))
        if s > best[0]:
            best = (s, t, xo)
    if best[0] >= 6:
        print(f"y={y} xo={best[2]}: {best[1].rstrip()[:90]!r}")
        printed.add(y)
