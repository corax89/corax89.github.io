#!/usr/bin/env python3
# test_smp_host.py — структурные проверки SMP-поддержки (сессия 74).
#
# Хост не умеет запускать x86-ядро (unicorn покрывает только загрузчик,
# останавливаясь на точке входа), поэтому критичные инварианты SMP
# проверяются прямо по исходникам и собранному kernel.bin:
#
#   1. Трамплин в kernel.bin: lgdtl [0x7108] + far jump с магией
#      0xDEADBEEF, которая БУКВАЛЬНО присутствует в образе (её ищет
#      BSP побайтово — если сборка её выкинула, SMP не стартует).
#   2. 32-битный вход AP: чтение стека/индекса из 0x7100/0x7104 и
#      call _smp_ap_main.
#   3. Разделение баз LAPIC: AP-код пользуется ТОЛЬКО g_apic_base_ap
#      (BSP обнуляет свою базу при выключении LAPIC — гонка с AP
#      означала бы запись MMIO по адресу 0).
#   4. IPI-последовательность INIT(0x4500) -> SIPI(0x4600) с ожиданием
#      online-флага, а не безусловное продолжение.
#   5. Обработчик LAPIC-таймера всегда шлёт EOI (иначе после первого
#      тика LAPIC замирает — ISR-бит остаётся взведённым).
#   6. Учёт загрузки: in_hlt -> idle_acc, иначе busy_acc; окно
#      SMP_LOAD_WINDOW пересчитывает load_pct и ОБНУЛЯЕТ счётчики.
#   7. IDT: векторы 0x60 (таймер AP) и 0xEF (spurious) установлены,
#      idt_load_ap объявлен в idt.h (smp.c зовёт его на каждом AP).
#   8. linker.ld: алиасы _smp_ap_main/_ap_timer_irq_c (asm-вызовы из
#      трамплина и стаба под ELF-тулчейном).
#   9. kernel.c зовёт smp_init(mb) после PIT/мыши (нужны pit2-таймауты
#      и векторы IDT), ДО sti.
#  10. Диспетчер задач: smp.h подключён, проценты ядер рисуются
#      цифрами (smp_cpu_load), hit-тест мыши использует ту же
#      динамическую верхнюю границу списка (tm_list_y0).
#
# Запуск: python3 scripts/test_smp_host.py

import os, re, struct, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE) if os.path.isdir(os.path.join(os.path.dirname(HERE), "boot")) \
    else os.path.join(os.path.dirname(HERE), "n2600-os")

FAILS = []
def scheck(cond, what):
    print(("  [OK]   " if cond else "  [FAIL] ") + what)
    if not cond:
        FAILS.append(what)

def src(name):
    with open(os.path.join(ROOT, "src", name), "rb") as f:
        return f.read().decode("utf-8", "replace")

smp_c  = src("smp.c")
smp_h  = src("smp.h")
idt_c  = src("idt.c")
idt_h  = src("idt.h")
ker_c  = src("kernel.c")
tm_c   = src("apps_taskmgr.c")
ld     = open(os.path.join(ROOT, "linker.ld")).read()

print("--- исходники: smp.c")

# 3. две независимые базы LAPIC
scheck("g_lapic_base" in smp_c and "g_apic_base_ap" in smp_c,
       "разделены база LAPIC BSP и база AP")
scheck(re.search(r"static inline u32 lapic_read_ap.*?\{.*?g_apic_base_ap", smp_c, re.S) is not None,
       "lapic_read_ap читает только g_apic_base_ap")
scheck(re.search(r"void lapic_bsp_disable.*?\{(.*?)\n\}", smp_c, re.S).group(1).find("g_apic_base_ap") == -1,
       "lapic_bsp_disable НЕ трогает базу AP (нет гонки с AP)")
scheck(re.search(r"g_apic_base_ap = \(u32\)\(msr_read\(0x1B\).*?FFFFF000", smp_c) is not None,
       "база AP ставится ДО первого SIPI из MSR BSP")

# 4. IPI-последовательность
scheck("0x4500u" in smp_c.replace("LAPIC_ICR_INIT   0x4500u", ""), False) if False else None
scheck("LAPIC_ICR_INIT   0x4500u" in smp_c and "LAPIC_ICR_SIPI   0x4600u" in smp_c,
       "константы INIT 0x4500 / SIPI 0x4600")
scheck(re.search(r"LAPIC_ICR_LO, LAPIC_ICR_INIT\);.*pit_wait_ms\(10\)", smp_c, re.S) is not None,
       "после INIT выдержка 10 мс")
scheck(re.search(r"for \(int attempt = 0; attempt < 2; attempt\+\+\)", smp_c) is not None,
       "SIPI с двумя попытками (рекомендация SDM)")
scheck(re.search(r"wait_online\(idx, 200\)", smp_c) is not None,
       "ожидание online-флага с таймаутом, а не безусловное продолжение")

# 5. EOI в обработчике таймера (сессия 75: сигнатура с ESP-параметром)
scheck(re.search(r"u32 ap_timer_irq_c\(u32 saved_esp\).*?lapic_write_ap\(LAPIC_EOI, 0\)", smp_c, re.S) is not None,
       "обработчик LAPIC-таймера всегда шлёт EOI")

# 6. учёт загрузки
scheck(re.search(r"if \(c->in_hlt\) c->idle_acc\+\+; else c->busy_acc\+\+;", smp_c) is not None,
       "учёт: in_hlt -> idle, иначе busy")
scheck(re.search(r"if \(tot >= SMP_LOAD_WINDOW\) \{.*?load_pct = c->busy_acc \* 100u / tot;.*?busy_acc = 0;.*?idle_acc = 0;", smp_c, re.S) is not None,
       "окно SMP_LOAD_WINDOW: load_pct + сброс счётчиков")
scheck(re.search(r"#define SMP_LOAD_WINDOW\s+1000u", smp_c) is not None,
       "окно учёта = 1000 тиков (1 с при 1000 Гц)")

# калибровка
scheck(re.search(r"LAPIC_ICOUNT, 0xFFFFFFFFu\)", smp_c) is not None and
       re.search(r"timer_poll_expired\(t0, 10000\)", smp_c) is not None,
       "калибровка LAPIC-таймера по pit2 (10 мс, one-shot 0xFFFFFFFF)")

# x2APIC и ExtINT
scheck("1ULL << 10" in smp_c and "0xC00" in smp_c,
       "x2APIC-режим возвращается в xAPIC (MSR 0x1B биты 11/10)")
scheck("lapic_write_bsp(LAPIC_LVT_LINT0, 0x700)" in smp_c,
       "LINT0 на BSP = ExtINT, пока LAPIC включён (PIC жив)")
scheck(re.search(r"lapic_bsp_disable.*?msr_write\(0x1B, msr & ~\(u64\)0x800\)", smp_c, re.S) is not None,
       "LAPIC BSP выключается после SIPI — путь прерываний как до SMP")

# MADT
scheck("'R' && p[1] == 'S' && p[2] == 'D'" in smp_c,
       "поиск RSDP по сигнатуре «RSD PTR » (EBDA + 0xE0000..0xFFFFF)")
scheck('find_table(' in smp_c and '"APIC"' in smp_c,
       "MADT ищется в RSDT (u32) и XSDT (u64)")
scheck(re.search(r"starts\[2\] = \{ 44, 40 \}", smp_c) is not None,
       "начало записей MADT валидируется для ACPI 1.0 (40) и 2.0+ (44)")
scheck(re.search(r"if \(\(flags & 1\) && n < max\)", smp_c) is not None,
       "берутся только ВКЛЮЧЁННЫЕ LAPIC-записи MADT")
scheck(re.search(r"if \(bpos > 0\) \{\s*u8 t = ids\[0\]; ids\[0\] = ids\[bpos\];", smp_c) is not None,
       "BSP переставляется на индекс 0 списка APIC ID")

# MTRR
scheck("mtrr_ap_copy" in smp_c and "0x2FF" in smp_c and "msr_read(0xFE)" in smp_c,
       "MTRR BSP копируются на AP (fixed + variable + DEFTYPE)")

print("--- исходники: idt.c/h, linker.ld, kernel.c")
scheck("set_gate(0x60, ap_timer_stub);" in idt_c and "set_gate(0xEF, ap_spurious_stub);" in idt_c,
       "IDT: векторы 0x60 (таймер AP) и 0xEF (spurious) установлены")
scheck("void idt_load_ap(void)" in idt_c and "void idt_load_ap(void);" in idt_h,
       "idt_load_ap определён и объявлен в idt.h")
scheck("_smp_ap_main   = smp_ap_main" in ld and "_ap_timer_irq_c = ap_timer_irq_c" in ld,
       "linker.ld: алиасы _smp_ap_main/_ap_timer_irq_c для asm-вызовов")
scheck('#include "smp.h"' in ker_c and re.search(r"smp_init\(mb\);", ker_c) is not None,
       "kernel.c: smp_init(mb) вызывается")
scheck(ker_c.find("smp_init(mb);") > ker_c.find("timer_init(1000);"),
       "smp_init после timer_init (нужны pit2-таймауты)")
scheck(ker_c.find("smp_init(mb);") < ker_c.find("sti();"),
       "smp_init до sti (однопоточно, PIC замаскирован)")

print("--- СЕССИЯ 75: многозадачность на AP (ядровый замок) ---")
task_c = src("task.c")
task_h = src("task.h")
fb_c   = src("fb.c")

# klock: cmpxchg-спинлок + переменная
scheck("extern volatile int smp_klock" in smp_h and
       "smp_klock_try" in smp_h and "smp_klock_unlock" in smp_h,
       "API ядрового замка в smp.h (cmpxchg try/unlock)")
scheck("volatile int smp_klock = 0" in smp_c,
       "переменная замка определена в smp.c")
scheck("smp_pic_mask" in smp_c and "smp_pic_restore" in smp_c and
       "0x21" in smp_c and "0xA1" in smp_c,
       "PIC-маска на время исполнения AP-задачи (IMR 0x21/0xA1)")

# AP-планировщик: стаб с переключением ESP
scheck("pushl %esp" in smp_c and "call _ap_timer_irq_c" in smp_c and
       "movl %eax, %esp" in smp_c,
       "ap_timer_stub: сохранение кадра + переключение ESP от планировщика")
scheck(re.search(r"task_ap_schedule\(saved_esp, my_core", smp_c) is not None,
       "ap_timer_irq_c вызывает планировщик AP (task_ap_schedule)")
scheck("task_ap_is_idle" in task_h and "task_ap_schedule" in task_h,
       "task.h: API планировщика AP объявлен")

# СЕССИЯ 76 (FIX паники #13): кадр ap_timer_stub обязан совпадать с
# кадром irq_stub_0/задач: pusha + SS + DS + ES (и зеркальные pops).
ap_stub = smp_c[smp_c.index("void ap_timer_stub(void)"):] if "void ap_timer_stub(void)" in smp_c else ""
ap_stub = ap_stub[:ap_stub.index("}")] if ap_stub and "}" in ap_stub else ""
scheck("pusha" in ap_stub and "pushl %ss" in ap_stub and
       "pushl %ds" in ap_stub and "pushl %es" in ap_stub,
       "FIX #13: ap_timer_stub сохраняет SS/DS/ES (кадр как у irq_stub_0)")
scheck("popl %es" in ap_stub and "popl %ds" in ap_stub and
       "movw %ax, %ss" in ap_stub,
       "FIX #13: ap_timer_stub восстанавливает сегменты в том же порядке")
scheck(ap_stub.index("pushl %ss") < ap_stub.index("pushl %esp") and
       ap_stub.index("movl %eax, %esp") < ap_stub.index("popl %es"),
       "FIX #13: порядок кадра — сегменты до передачи ESP планировщику")

# СЕССИЯ 76: паника на AP не замораживает систему
scheck("smp_this_cpu_is_ap" in smp_c and "smp_this_cpu_is_ap" in smp_h,
       "smp_this_cpu_is_ap: определение текущего ядра (MSR 0x1B бит 8)")
scheck("task_ap_panic_orphan" in task_c and "task_ap_panic_orphan" in task_h,
       "task_ap_panic_orphan: снять задачу AP, отпустить замок+PIC")
_orphan_pos = task_c.find("void task_ap_panic_orphan")
scheck(_orphan_pos >= 0 and
       "smp_pic_restore" in task_c[_orphan_pos:_orphan_pos + 700] and
       "smp_klock_unlock" in task_c[_orphan_pos:_orphan_pos + 700],
       "orphan AP-задачи восстанавливает PIC-маску + замок (BSP получает IRQ0)")
scheck("smp_this_cpu_is_ap" in idt_c and "task_ap_panic_orphan" in idt_c,
       "exc_panic различает BSP/AP (longjmp только на BSP)")
scheck(re.search(r"on_ap[^{]*\{[^}]*hlt", idt_c, re.S) is not None or
       "ПАНИКА ЯДРА на AP" in idt_c,
       "паника на AP: serial-диагностика + hlt, экран не трогаем")
# EXC_STUB: адденд из сохранённого SS (не из cur_task — IDT общий)
exc_stub_txt = idt_c[idt_c.index("#define EXC_STUB"):] if "#define EXC_STUB" in idt_c else ""
scheck("pushl %ss" in exc_stub_txt and "movl 8(%esp), %eax" in exc_stub_txt
       and "cmpl $0x18, %eax" in exc_stub_txt and "shrl $3, %eax" in exc_stub_txt,
       "EXC_STUB: адденд ESP из сохранённого SS (CPU-независимо)")
scheck("leal 44(%esp)" in exc_stub_txt,
       "EXC_STUB: кадр диагностики с учётом SS (44 = pusha+ss+ds+es)")
scheck("frame[-11]" in idt_c and "frame[-10]" in idt_c and "frame[-9]" in idt_c,
       "диагностика приложения: es/ds/ss из кадра с SS")

# task.c: per-task поля и логика
scheck("int  cpu;" in task_c and "on_cpu" in task_c and "migrating" in task_c
       and "holds_klock" in task_c,
       "task_t: cpu/on_cpu/migrating/holds_klock")
scheck(re.search(r"task_pick_core\(int prio, int is_sandbox\)", task_c) is not None,
       "размещение по наименее нагруженному ядру (task_pick_core)")
scheck("prio <= TASK_PRIO_UI) return 0" in task_c.replace("if (prio <= TASK_PRIO_UI) return 0;",
      "prio <= TASK_PRIO_UI) return 0"),
       "UI-задачи всегда на BSP")
scheck("is_sandbox) return 0" in task_c,
       "песочницы (внешний стек) всегда на BSP")
scheck(re.search(r"tasks\[i\]\.cpu > 0 && !tasks\[i\]\.on_cpu && !tasks\[i\]\.migrating", task_c) is not None
       and "migrating = 1" in task_c,
       "миграция голодающей AP-задачи на BSP (>300 мс)")
scheck("task_hlt_idle" in task_h and "task_idle_release" in task_h,
       "task.h: hlt-обёртки с отпуском замка")
scheck(task_c.count("task_hlt_idle();") >= 2,
       "task_yield/task_msleep спят через task_hlt_idle")

# hlt-точки задач обёрнуты во всех подсистемах
scheck("task_klock_release_me" in open(os.path.join(ROOT, "src", "sync.h")).read(),
       "sync.h: ожидание s_lock отпускает ядровый замок")
scheck("task_klock_release_me" in src("wm.c") and "task_klock_acquire_me" in src("wm.c"),
       "wm.c: сон потока окна с отпуском замка")
scheck(src("ramfs.c").count("task_klock_release_me") >= 2,
       "ramfs.c: ожидание IPC и сон сервера отпускают замок")
scheck("task_klock_release_me" in src("usb_ehci.c"),
       "usb_ehci.c: ehci_wait_pause отпускает замок")
scheck("task_hlt_idle()" in src("kernel.c"),
       "kernel.c: главный цикл kmain спит с отпуском замка")

# fb: per-core контексты
scheck("g_rtctx[SMP_MAX_CPUS]" in fb_c and "fb_task_switch_ap" in fb_c,
       "fb.c: per-core наборы активных контекстов + fb_task_switch_ap")
scheck("fb_sched_lock" in fb_c,
       "fb.c: спинлок планировщиков (переключения ядер атомарны)")
scheck("task_exec_core" in task_h,
       "task.h: task_exec_core() — ядро-исполнитель")

# taskmgr: ядро задачи в статусе
scheck("task_cpu(slot)" in tm_c and "@%d" in tm_c,
       "диспетчер задач: ядро задачи в колонке статуса («idle@1»)")

print("--- исходники: диспетчер задач (apps_taskmgr.c)")
scheck('#include "smp.h"' in tm_c, "taskmgr включает smp.h")
scheck("smp_cpu_load(" in tm_c and "smp_cpu_count(" in tm_c,
       "проценты ядер берутся из smp_cpu_load/smp_cpu_count")
scheck("tm_draw_cores" in tm_c and "Ядра, %" in tm_c,
       "блок «Ядра, %: N:MM» рисуется цифрами")
# СЕССИЯ 75: блок ядер перенесён ПОД ГРАФИКИ — верх списка статичен
scheck("#define TM_LIST_Y0  (TM_HDR_H + 18)" in tm_c,
       "TM_LIST_Y0 статичен (ядра переехали под графики)")
scheck(tm_c.count("TM_LIST_Y0") >= 3,
       "верх списка един для отрисовки И hit-теста мыши")
scheck("tm_plural(" in tm_c, "топология в шапке с правильными падежами")

print("--- исходники: smp.h")
scheck("smp_cpu_load" in smp_h and "smp_spin_lock" in smp_h and "SMP_MAX_CPUS 8" in smp_h,
       "API smp.h: счётчики/загрузка/спин-блокировки")
scheck("lock cmpxchgl" in smp_h,
       "спин-блокировка на lock cmpxchg (межъядерная атомарность)")

print("--- СЕССИЯ 77: гейт загрузки (SMP-BOOT-GATE / SPAWN-GATE / SMP-HLT)")

# G1. API гейта объявлен в smp.h и реализован в smp.c
scheck("void smp_tasks_enable(void);" in smp_h and
       "int  smp_tasks_enabled(void);" in smp_h,
       "smp.h: объявления smp_tasks_enable/smp_tasks_enabled")
scheck("s_tasks_go" in smp_c and
       re.search(r"int\s+smp_tasks_enabled\(void\)\s*\{[^}]*return s_tasks_go", smp_c) is not None,
       "smp.c: smp_tasks_enabled читает s_tasks_go")

# G2. AP-планировщик не получает задач до конца загрузки
_ap_sched_pos = task_c.find("u32 task_ap_schedule")
scheck(_ap_sched_pos >= 0 and
       "smp_tasks_enabled()" in task_c[_ap_sched_pos:_ap_sched_pos + 400],
       "task.c: task_ap_schedule выходит до smp_tasks_enable (AP в idle при загрузке)")

# G3. размещение при загрузке — только BSP
_pick_pos = task_c.find("static int task_pick_core")
scheck(_pick_pos >= 0 and
       "smp_tasks_enabled()" in task_c[_pick_pos:_pick_pos + 300],
       "task.c: task_pick_core при загрузке возвращает BSP (0)")

# G4. kmain включает планирование на AP только после «Загрузка завершена»
_done_pos = ker_c.find('klog_puts("Загрузка завершена')
scheck(_done_pos >= 0 and
       "smp_tasks_enable()" in ker_c[_done_pos:_done_pos + 900],
       "kernel.c: smp_tasks_enable() после «Загрузка завершена»")

# G5. SPAWN-GATE: публикация задачи — последней операцией
_spawn_pos = task_c.find("static int task_spawn_impl")
_spawn_body = task_c[_spawn_pos:_spawn_pos + 9000] if _spawn_pos >= 0 else ""
scheck("while (g_ap_cur_task == slot)" in _spawn_body,
       "task.c: spawn ждёт снятия старой задачи с AP (гонка переиспользования слота)")
scheck(re.search(r"tasks\[slot\]\.migrating = 1;", _spawn_body) is not None,
       "task.c: spawn ставит migrating=1 гейт в начале заполнения")
_pub = _spawn_body.find("SPAWN-GATE")
scheck(_pub >= 0 and
       _spawn_body.find("tasks[slot].migrating = 0;", _pub) > _spawn_body.find("n_tasks++;"),
       "task.c: публикация (migrating=0) после n_tasks++ — последняя операция")
scheck(_spawn_body.count("tasks[slot].migrating = 0;") == 1,
       "task.c: migrating=0 в spawn встречается ровно один раз (в публикации)")

# G6. SMP-HLT: s_lock под cli НЕ делает sti;hlt (вечный сон при
# замаскированном IRQ0) — крутится на pause. СЕССИЯ 78: в else-ветке
# ДОБАВЛЕН pit2-дедлайн отбора (SLOCK_STALE_CLI_US) — sti там по-прежнему
# запрещён, pause обязателен.
_sync_h = src("sync.h")
_wait_pos = _sync_h.find("task_set_lockwait_me(1);")
_wait_body = _sync_h[_wait_pos:_wait_pos + 3200] if _wait_pos >= 0 else ""
scheck(re.search(r"if \(if_had & 0x200\) \{[^}]*sti\\n\\thlt", _wait_body, re.S) is not None,
       "sync.h: s_lock при IF=1 спит sti;hlt (как раньше)")
_else_pos = _wait_body.find("} else {")
# парная скобка ветки else (учёт вложенности — внутри if(!cli_timed))
_else_end = -1
if _else_pos >= 0:
    _depth = 0
    for _i in range(_else_pos + 8, len(_wait_body)):
        if _wait_body[_i] == "{":
            _depth += 1
        elif _wait_body[_i] == "}":
            if _depth == 0:
                _else_end = _i
                break
            _depth -= 1
_else_branch = _wait_body[_else_pos:_else_end] if _else_pos >= 0 and _else_end > _else_pos else ""
scheck(_else_branch and "pause" in _else_branch and "sti" not in _else_branch,
       "sync.h: s_lock при IF=0 (загрузка) крутится на pause без hlt")
scheck("SLOCK_STALE_CLI_US" in _sync_h and "timer_poll_expired(cli_start" in _sync_h,
       "sync.h: cli-ожидание ограничено (pit2-отбор SLOCK_STALE_CLI_US)")
scheck("slock_diag_dec" in _sync_h and "slock_diag_hex" in _sync_h,
       "sync.h: диагностика реентерабельности (№ задачи + адрес замка)")

# ===================== СЕССИЯ 78 =====================
print("--- СЕССИЯ 78: per-CPU task_current / KLOCK-STALE / KLOCK-REL / MIG-FIX / диагност.")

# S78.1. task_current/task_exec_core — per-CPU (ядро-исполнитель по MSR 0x1B)
_cur_pos = task_c.find("int task_current(void)")
_cur_body = task_c[_cur_pos:_cur_pos + 500] if _cur_pos >= 0 else ""
scheck("smp_this_cpu_is_ap()" in _cur_body and "g_ap_cur_task >= 0" in _cur_body,
       "task.c: task_current per-CPU (smp_this_cpu_is_ap + g_ap_cur_task>=0)")
_ecore_pos = task_c.find("int task_exec_core(void)")
_ecore_body = task_c[_ecore_pos:_ecore_pos + 400] if _ecore_pos >= 0 else ""
scheck("smp_this_cpu_is_ap()" in _ecore_body,
       "task.c: task_exec_core per-CPU (BSP не рисует в контекстах AP)")

# S78.2. PIC-маска сохраняет IRQ0 (тик BSP живёт под AP-задачей)
_pic_pos = smp_c.find("void smp_pic_mask(void)")
_pic_body = smp_c[_pic_pos:_pic_pos + 400] if _pic_pos >= 0 else ""
scheck("| 0xFE" in _pic_body,
       "smp.c: smp_pic_mask не маскирует IRQ0 (master IMR = saved | 0xFE)")
scheck("outb(0xA1, 0xFF)" in _pic_body,
       "smp.c: slave PIC маскируется целиком (драйверные IRQ только на BSP)")

# S78.3. KLOCK-STALE: ограниченное ожидание + отбор замка
_acq_pos = task_c.find("void task_klock_acquire_me(void)")
_acq_body = task_c[_acq_pos:_acq_pos + 2600] if _acq_pos >= 0 else ""
scheck("KLOCK_SPIN_BATCH" in _acq_body and "timer_poll_expired" in _acq_body,
       "task.c: захват klock ограничен (batch + pit2-дедлайн)")
scheck("klock_steal" in _acq_body and "tasks[owner].finished" in _acq_body,
       "task.c: немедленный отбор у мёртвого держателя")
_steal_pos = task_c.find("static void klock_steal")
_steal_body = task_c[_steal_pos:_steal_pos + 2400] if _steal_pos >= 0 else ""
scheck("smp_pic_restore()" in _steal_body and "smp_klock_unlock()" in _steal_body,
       "task.c: klock_steal физически отпускает замок (+PIC)")
# СЕССИЯ 79 [ZOMBIE-FIX]: отбор БОЛЬШЕ НЕ сиротит AP-исполнителя —
# прежний g_ap_cur_task=-1 при ещё-живой украденной задаче давал
# «зомби-воскресение» на чужом стеке → invalid opcode (#6) → паника.
# Теперь тик AP сам сохраняет кадр finished-задачи и уходит в idle.
scheck("g_ap_cur_task = -1" not in _steal_body,
       "task.c: klock_steal НЕ сиротит AP-исполнителя [ZOMBIE-FIX: g_ap_cur_task жив]")

# S78.4. KLOCK-REL: kill/ватчдог отпускают замок убитой задачи
_kill_pos = task_c.find("int task_kill(int idx)")
_kill_body = task_c[_kill_pos:_kill_pos + 2200] if _kill_pos >= 0 else ""
scheck("holds_klock" in _kill_body and "smp_klock_unlock()" in _kill_body,
       "task.c: task_kill отпускает замок убитой задачи (не on_cpu)")
_wd_kill = task_c.find('serial_puts("[watchdog] замок убитой задачи освобождён')
scheck(_wd_kill > 0 and task_c.find("smp_klock_unlock", _wd_kill) > 0,
       "task.c: ватчдог отпускает замок убитой задачи")

# S78.5. MIG-FIX: миграция ватчдогом без смертельного migrating=1
_mig_pos = task_c.find("[smp] миграция:")
_mig_body = task_c[_mig_pos - 1200:_mig_pos + 400] if _mig_pos >= 0 else ""
scheck("tasks[i].migrating = 1" not in _mig_body,
       "task.c: миграция (!on_cpu) не ставит migrating=1 (задача не теряется)")
_apsave_pos = task_c.find("tasks[cur].on_cpu = 0;")
_apsave_body = task_c[_apsave_pos:_apsave_pos + 500] if _apsave_pos >= 0 else ""
scheck("tasks[cur].migrating = 0;" in _apsave_body,
       "task.c: migrating снимается при сохранении кадра (обе ветки AP-планировщика)")

# S78.6. SPAWN-GATE-TMO: ожидание слота ограничено
scheck("застрял на AP" in _spawn_body and "gate_spins" in _spawn_body,
       "task.c: SPAWN-GATE с таймаутом (зависшее ядро не вешает spawn)")

# S78.7. SER-TMO: serial_putc с дедлайном
putc_pos = ker_c.find("void serial_putc(char c)")
putc_body = ker_c[putc_pos:putc_pos + 600] if putc_pos >= 0 else ""
scheck("timer_poll_expired" in putc_body,
       "kernel.c: serial_putc с таймаутом (вечный спин под cli устранён)")

# S78.8. MQJS-LOG: протокол run/done для запусков JS
mq_c = src("mquickjs_api.c")
scheck("mqjs_diag_run_start" in mq_c and "mqjs_diag_run_end" in mq_c,
       "mquickjs_api.c: хелперы run/done диагностики")
scheck(mq_c.count('mqjs_diag_run_start("file"') == 1 and
       mq_c.count('mqjs_diag_run_end("file"') >= 1,
       "mquickjs_api.c: mquickjs_run пишет run/done")
scheck('mqjs_diag_run_start("repl"' in mq_c,
       "mquickjs_api.c: REPL-строка пишет run/done")

# S78.9. WM-DIAG: лимит окон докладывает в serial
wm_c2 = src("wm.c")
scheck("ЛИМИТ ОКОН" in wm_c2,
       "wm.c: исчерпание окон логируется в serial (кто запросил)")

# G7. task_hlt_idle под cli — безопасный выход (сон невозможен)
_hlt_pos = task_c.find("void task_hlt_idle")
_hlt_body = task_c[_hlt_pos:_hlt_pos + 700] if _hlt_pos >= 0 else ""
scheck("if (!(if_had & 0x200)) return;" in _hlt_body,
       "task.c: task_hlt_idle под cli возвращается без hlt")

# ===================== СЕССИЯ 79 [KLOCK-PASS-FIX] =====================
# Корень «запуск JS вешает систему + гибнет wifi» (лог: [klock] ОТБОР у
# 'wifi' и 'mquickjs'): AP-планировщик передавал holds_klock=1 задаче,
# прерванной ВО СНЕ в task_hlt_idle (замок уже физически отпущен) —
# задача продолжала код ядра БЕЗ физического захвата. Инвариант:
# ФЛАГ передаётся только при had_lock; иначе честный перезахват.
print("--- СЕССИЯ 79 [KLOCK-PASS-FIX]: условная передача замка AP/STEAL-SYS/WIFI-RESPAWN")

_aps_pos = task_c.find("u32 task_ap_schedule")
_aps_body = task_c[_aps_pos:_aps_pos + 9000] if _aps_pos >= 0 else ""
_pass_pos = _aps_body.find("KLOCK-PASS-FIX")
_pass_body = _aps_body[_pass_pos:_pass_pos + 3000] if _pass_pos >= 0 else ""

# S79.1. передача флага — ТОЛЬКО если прерванная держала замок
# (сессия 80 переформулировала тот же инвариант: снапшот klocked в начале
# task_ap_schedule; флаг next ставится только в ветке klocked или после
# УСПЕШНОГО klock_acq_ap — безусловной передачи больше нет)
scheck("int klocked = tasks[cur].holds_klock;" in _pass_body,
       "task.c: AP-планировщик фиксирует klocked прерванной задачи")
scheck("if (klocked) {" in _pass_body and
       "tasks[cur].holds_klock = 0;" in _pass_body and
       "tasks[next].holds_klock = 1;" in _pass_body,
       "task.c: флаг передаётся ТОЛЬКО если прерванная держала замок")
# S79.2. спавшая задача НЕ получает флаг «задаром» — только реальный захват
_kl_else = _pass_body.find("if (!klock_acq_ap())")
_kl_flag = _pass_body.find("tasks[next].holds_klock = 1;", _kl_else)
scheck(_kl_else >= 0 and _kl_flag > _kl_else and
       "return *idle_esp;" in _pass_body[_kl_else:_kl_flag],
       "task.c: next без замка: флаг только после успешного klock_acq_ap (иначе idle)")
# S79.3. переход к другой задаче от СПАВШЕЙ — только с реальным захватом
scheck("klock_acq_ap()" in _pass_body and
       "return *idle_esp;" in _pass_body,
       "task.c: next!=cur от спавшей: klock_acq_ap или честный idle")
# S79.4. нет безусловной передачи (старый баг: флаг всем подряд)
_sch_pos = task_c.find("u32 *task_schedule")
_sch_body = task_c[_sch_pos:_sch_pos + 3000] if _sch_pos >= 0 else ""
scheck("int held = tasks[cur_task].holds_klock;" in _sch_body and
       "if (!held && !smp_klock_try())" in _sch_body,
       "task.c: BSP-планировщик передаёт флаг по-прежнему честно (held||try)")
# S79.5. STEAL-SYS: системные задачи отбор не убивает
scheck("int is_system = tasks[owner].system;" in _steal_body and
       "СИСТЕМНАЯ — не убита" in _steal_body,
       "task.c: klock_steal НЕ убивает системные задачи (wifi/ramfs/sata)")
_sys_pos = _steal_body.find("if (is_system)")
_sys_body = _steal_body[_sys_pos:_sys_pos + 500] if _sys_pos >= 0 else ""
_sys_only = _sys_body.split("} else {")[0] if _sys_pos >= 0 else ""
scheck("finished = 1" not in _sys_only,
       "task.c: klock_steal: системной задаче не ставится finished")
# S79.6. WIFI-RESPAWN: задача wifi возрождается без wifi_present()
_wifi_resp_pos = ker_c.find("WIFI-RESPAWN")
_wifi_resp_body = ker_c[_wifi_resp_pos - 200:_wifi_resp_pos + 700] if _wifi_resp_pos >= 0 else ""
scheck("if (!wifi_ready() && !g_wifi_spawn_pending && g_wifi_task_alive == 0)" in _wifi_resp_body,
       "kernel.c: wifi-задача возрождается БЕЗ wifi_present() (hot-plug жив после гибели)")
scheck("wifi_present() && !wifi_ready()" not in _wifi_resp_body,
       "kernel.c: старое условие respawn (wifi_present && !ready) удалено")

# ===================== СЕССИЯ 80 =====================
# Хвост нагрузочных тестов пользователя: (1) грейс-период «потерянного
# замка» — окно между физическим захватом klock и установкой флага на AP
# давало ложный «бесхозный» замок и лишний отбор; (2) WM переживает
# ВЕЧНЫЙ захват wm_glock: композитор — bounded-trylock (кадр пропускает),
# через WM_GLOCK_SEIZE_MS замок отбирается, задача-виновник снимается,
# рендер восстанавливается; (3) pit2-дедлайны атомарны между ядрами —
# ложный «истёк» означал бы преждевременный отбор замка у ЖИВОГО владельца;
# (4) честный serial-лог при SMP=1 (AP-ядер нет).
print("--- СЕССИЯ 80: LOST-GRACE / WM-NOSTALL+SEIZE / PIT2-XCORE / SMP1-MSG")

# S80.1. LOST-GRACE: «потерянный» замок сначала получает грейс-период
_acq80_pos = task_c.find("void task_klock_acquire_me(void)")
_acq80_body = task_c[_acq80_pos:_acq80_pos + 4500] if _acq80_pos >= 0 else ""
scheck("KLOCK_LOST_GRACE_US" in task_c and "LOST-GRACE" in task_c,
       "task.c: грейс-период KLOCK_LOST_GRACE_US для «потерянного» замка")
scheck("lost_deadline" in _acq80_body and
       "timer_poll_expired(lost_deadline, KLOCK_LOST_GRACE_US)" in _acq80_body,
       "task.c: отбор потерянного замка только после истечения грейса")

# S80.2. WM-NOSTALL: композитор не ждёт зависшего держателя вечно
_wmframe_pos = wm_c2.find("void wm_frame(void)")
_wmframe_body = wm_c2[_wmframe_pos:_wmframe_pos + 9000] if _wmframe_pos >= 0 else ""
scheck(_wmframe_body.count("wl_trylock_ms(&wm_glock") >= 3,
       "wm.c: все входы в wm_frame под glock — bounded-trylock (закрытие/anim/композит)")
scheck("система жива" in _wmframe_body,
       "wm.c: stall-диагностика композитора (кадр пропущен, система жива)")

# S80.3. WM-SEIZE: самовосстановление после вечного захвата wm_glock
scheck("WM_GLOCK_SEIZE_MS" in wm_c2 and "wm_glock_stall_t0" in wm_c2,
       "wm.c: порог отбора wm_glock по непрерывному простою (SEIZE_MS + stall_t0)")
scheck("рендер восстановлен" in _wmframe_body and "task_kill(owner)" in _wmframe_body,
       "wm.c: отбор wm_glock: виновник снимается, рендер восстанавливается")
scheck("wm_glock = 0;" in _wmframe_body,
       "wm.c: физический отбор (wm_glock=0) в seizure-ветке")

# S80.4. Буферы stall-сообщений не режут текст (было b[96] -> «система жи»)
# (строка в исходнике разбита на два литерала — ищем хвостовой «система жива»)
_stall_msg_pos = wm_c2.find("система жива")
scheck("char b[160]" in wm_c2[_stall_msg_pos - 300:_stall_msg_pos],
       "wm.c: буфер stall-сообщения увеличен (b[160])")
_seiz_msg_pos = wm_c2.find("рендер восстановлен")
scheck("char b[192]" in wm_c2[_seiz_msg_pos - 300:_seiz_msg_pos],
       "wm.c: буфер seizure-сообщения увеличен (b[192])")

# S80.5. PIT2-XCORE: чтения pit2 атомарны между ядрами, fallback монотонен
tm_c = src("timer.c")
_gt_pos = tm_c.find("static u32 pit2_gticks(void)")
_gt_body = tm_c[_gt_pos:_gt_pos + 1200] if _gt_pos >= 0 else ""
scheck("s_pit2_lk" in _gt_body and "lock cmpxchgl" in _gt_body,
       "timer.c: pit2_gticks под межъядерным cmpxchg-замком")
scheck("return s_pit2_last + 1u;" in _gt_body,
       "timer.c: fallback без замка — монотонный кэш +1 (никогда не назад)")
scheck("s_pit2_on" in _gt_body or "s_pit2_on" in tm_c[tm_c.find("static void pit2_lazy_init"):][:900],
       "timer.c: pit2_lazy_init под тем же замком (нет повторного программирования)")
_probe_pos = tm_c.find("u32 timer_pit2_probe(void)")
scheck("pit2_gticks()" in tm_c[_probe_pos:_probe_pos + 400] if _probe_pos >= 0 else False,
       "timer.c: зонд pit2 читает через атомарный pit2_gticks (не сырой latch)")

# S80.6. SMP1-MSG: честная строка при одном ядре
_smp1_pos = ker_c.find("smp_cpu_count() > 1")
scheck(_smp1_pos > 0 and "AP-ядер нет (SMP=1)" in ker_c[_smp1_pos - 200:_smp1_pos + 300],
       "kernel.c: при SMP=1 лог честно пишет «AP-ядер нет — все задачи на BSP»")

# ===================== СЕССИЯ 82 =====================
# Жалобы пользователя: (1) «сообщение о лимите окон при <20 задачах» —
# корень: ГЛОБАЛЬНЫЙ пул g_sgw[4] на всю ОС + слот после закрытия окна
# оставался used=1 НАВСЕГДА (4 запуска калькулятора за жизнь системы,
# даже с закрытием!); (2) подложка под «Ядра, %» + по строке на ядро;
# (3) дубли сообщений о миграции — это ДВЕ задачи с равным голодом,
# теперь у сообщения есть #индекс; (4) диспетчер задач: деления-#0 нет,
# но дельта uptime при смерти задачи заворачивала u32.
print("--- СЕССИЯ 82: SG-REAP / SG-DIAG / TM-DELTA / TM-CORES / MIG-IDX / TERM-SPAWN")

mq_c = src("mquickjs_api.c")
ldr_c = src("loader.c")
tm_c2 = src("apps_taskmgr.c")
apps_c2 = src("apps.c")

# S82.1. [SG-REAP]: пул 32 = WM_MAX_WINDOWS (каждое sg-окно и так ест
# слот WM — больше системного лимита не нужно), владелец слота, ленивое
# освобождение, уборка при смерти владельца
scheck("#define SG_MAX_WINS   32" in mq_c,
       "mquickjs_api.c: SG_MAX_WINS = 32 (= WM_MAX_WINDOWS, было 4 — ГЛОБАЛЬНО на всю ОС)")
scheck("int        owner;" in mq_c,
       "mquickjs_api.c: sg_win_t.owner — задача-владелец слота")
scheck("static int sg_owner_dead(int tid)" in mq_c and
       "!task_used(tid) || task_finished(tid)" in mq_c,
       "mquickjs_api.c: sg_owner_dead — смерть владельца по таблице задач")
scheck("static int sg_slot_reclaimable(sg_win_t *g)" in mq_c and
       "if (g->win != NULL) return 0;" in mq_c,
       "mquickjs_api.c: reclaim только закрытых окон (win==NULL), живые не трогаем")
scheck("void sg_win_release_owner(int tid)" in mq_c,
       "mquickjs_api.c: sg_win_release_owner — окна-зомби уходят с задачей")
scheck("static void sg_reap_dead(void)" in mq_c,
       "mquickjs_api.c: sg_reap_dead — подметалка для teardown REPL")
scheck(mq_c.count("sg_slot_reclaimable(&g_sgw[k])") == 2,
       "mquickjs_api.c: оба win_open (js + c4k) занимают слоты через reclaim")
scheck(mq_c.count("g->owner = task_current();") >= 2,
       "mquickjs_api.c: владелец фиксируется в фазе резерва (живой — не reclaim)")
scheck("if (g->win == w) {" in mq_c[mq_c.find("static void sg_close"):][:600],
       "mquickjs_api.c: sg_close guard — не бить НОВУЮ жизнь слота (гонка pending_close)")
scheck("sg_win_release_owner(task_current());" in
       mq_c[mq_c.find("int mquickjs_run"):][:6000],
       "mquickjs_api.c: mquickjs_run — [SG-ORPHAN] после eval (все ветки возврата)")
scheck("sg_reap_dead();   /* СЕССИЯ 82 [SG-REAP]: слоты погибших eval-задач */" in mq_c,
       "mquickjs_api.c: hard_reset REPL подметает слоты погибших eval-задач")
scheck("sg_reap_dead();   /* СЕССИЯ 82 [SG-REAP]: REPL-окна переживают задачу" in mq_c,
       "mquickjs_api.c: teardown REPL — REPL-окна не переживают сеанс")
scheck(ldr_c.count("sg_win_release_owner(task_current());") == 2,
       "loader.c: оба выхода c4-приложения (норма/авария) отпускают sg-окна")
scheck("void sg_win_release_owner(int tid);" in src("kapi.h"),
       "kapi.h: декларация sg_win_release_owner (для loader.c)")

# S82.2. [SG-DIAG]: отказ win_open больше не молчит (жалоба «почему
# сообщение о лимите окон» — теперь причина видна в serial)
scheck("win_open: ОТКАЗ" in mq_c,
       "mquickjs_api.c: отказ win_open пишется в serial ([SG-DIAG])")

# S82.3. [TM-DELTA]: дельты uptime только при монотонном росте
_tm_sample_pos = tm_c2.find("static void tm_sample")
_tm_sample = tm_c2[_tm_sample_pos:_tm_sample_pos + 2600] if _tm_sample_pos >= 0 else ""
scheck("(total >= m->last_total_uptime) ?" in _tm_sample and
       "(idle >= m->last_idle_uptime) ?" in _tm_sample and
       "if (d_idle > d_total) d_idle = d_total;" in _tm_sample,
       "apps_taskmgr.c: [TM-DELTA] u32-дельты без заворота при смерти задачи")

# S82.4. [TM-CORES]: подложка-панель + по строке на ядро + мини-бары
_tm_cores_pos = tm_c2.find("static void tm_draw_cores")
_tm_cores = tm_c2[_tm_cores_pos:_tm_cores_pos + 2600] if _tm_cores_pos >= 0 else ""
scheck("fb_fill_rect(x0, y0, maxw, panel_h, wm_theme_win_bg_alt());" in _tm_cores and
       "fb_rect(x0, y0, maxw, panel_h," in _tm_cores,
       "apps_taskmgr.c: ПОДЛОЖКА панели «Ядра, %» (фон + рамка, стиль графиков)")
scheck('"Ядро %d: %d%%"' in _tm_cores and '"Ядро %d: —"' in _tm_cores,
       "apps_taskmgr.c: ПО ОДНОЙ СТРОКЕ на ядро (запрос пользователя)")
scheck("int fill = pct * bar_w / 100;" in _tm_cores,
       "apps_taskmgr.c: мини-бар загрузки (деление на константу — #0 исключён)")
scheck("int max_lines = (maxh - pad * 2 - line_h) / line_h;" in _tm_cores,
       "apps_taskmgr.c: кламп строк по высоте окна (8 ядер максимум)")
scheck("tm_buf_clamp" not in tm_c2,
       "apps_taskmgr.c: мёртвый tm_buf_clamp удалён (была ошибка единиц: пиксели как строки)")
scheck("tm_draw_cores(m, graph_x, cy, TM_GRAPH_W, avail);" in tm_c2,
       "apps_taskmgr.c: вызов с доступной высотой до подвала")

# S82.5. [MIG-IDX]: миграции различимы — #индекс задачи
scheck('"[smp] миграция: задача #%d \'%s\' AP%d -> BSP "' in task_c,
       "task.c: сообщение о миграции с #индексом (две одновременные != задвоение)")

# S82.6. [TERM-SPAWN]: help обещал «taskmgr sysinfo settings» — теперь
# имена приложений работают напрямую из терминала
scheck("} else if (app_spawn_by_name(c)) {" in apps_c2,
       "apps.c: фолбэк терминала — имя приложения как команда (help больше не врёт)")

# S82.7. [WM-LIM-DYN]: текст про лимит окон синхронен с WM_MAX_WINDOWS
scheck('"Достигнут лимит открытых окон (%d).\\n"' in wm_c2,
       "wm.c: число в сообщении о лимите окон берётся из WM_MAX_WINDOWS (не зашито)")

print("--- kernel.bin (собранный образ)")
kb_path = os.path.join(ROOT, "kernel.bin")
if os.path.exists(kb_path):
    kb = open(kb_path, "rb").read()
    KBASE = 0x100000

    def find_all(pat):
        out, i = [], kb.find(pat)
        while i >= 0:
            out.append(i)
            i = kb.find(pat, i + 1)
        return out

    # 1. трамплин: lgdtl [0x7108] (66 0F 01 16 08 71)
    hits = find_all(bytes([0x66, 0x0F, 0x01, 0x16, 0x08, 0x71]))
    scheck(len(hits) >= 1, "lgdtl [0x7108] присутствует в образе")
    # far jump 66 EA + магия + селектор 0x08
    hits2 = find_all(bytes([0x66, 0xEA, 0xEF, 0xBE, 0xAD, 0xDE, 0x08, 0x00]))
    scheck(len(hits2) == 1,
           "far jump 0x08:<0xDEADBEEF> в образе (ровно один, побайтовый патч найдёт)" +
           (f" @ {hex(hits2[0]+KBASE)}" if len(hits2) == 1 else ""))
    # 2. pm-вход: movl 0x7100,%esp (8B 25 00 71 00 00) и movl 0x7104,%eax (8B 05 04 71 00 00)
    scheck(len(find_all(bytes([0x8B, 0x25, 0x00, 0x71, 0x00, 0x00]))) >= 1,
           "movl 0x7100,%esp — стек AP из патч-области")
    # movl 0x7104,%eax: GAS оптимизирует в moffs-форму A1 04 71 00 00
    # (обычная кодировка 8B 05 04 71 00 00 тоже допустима)
    scheck(len(find_all(bytes([0xA1, 0x04, 0x71, 0x00, 0x00]))) >= 1 or
           len(find_all(bytes([0x8B, 0x05, 0x04, 0x71, 0x00, 0x00]))) >= 1,
           "movl 0x7104,%eax — индекс ядра из патч-области")
else:
    scheck(False, "kernel.bin не найден (сначала запустите build.sh)")

print()
if FAILS:
    print(f"ИТОГ: {len(FAILS)} ПРОВАЛ(ОВ)")
    sys.exit(1)
print("ИТОГ: все проверки пройдены")
