#!/usr/bin/env python3
"""test_exfat_usb.py — exFAT-флешка в QEMU (сессия 83).

Сценарии (каждый — отдельная загрузка ОС с USB-флешкой на EHCI):
  A. Суперфлоппи exFAT: files -> fm_tick автомонтирует exFAT -> [USB]
     -> big.txt (2 кластера NoFatChain) в редакторе: контент виден.
  B. exFAT в MBR-разделе (тип 0x07, LBA 2048) — как штатная флешка
     Windows: fat32_init_usb должен найти раздел (проход 1) и смонтировать.
  C. Регресс FAT32: флешка FAT32 всё ещё монтируется.

OCR: текст ОС рендерится шрифтом 8x16 из font.c, но сетка пикселей
привязана к позиции ОКНА — ищем выравнивание по x-смещению 0..7 и y.
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, "/home/z/my-project/scripts")
import mkexfat
from qemu_test import Vm
from qmon import load_glyphs, cp_of_glyph, read_ppm, norm

ISO = os.path.join(ROOT, "os.iso")
OUT = "/home/z/my-project/n2600-tests/exfat_usb83"
os.makedirs(OUT, exist_ok=True)
GLYPHS = load_glyphs()
GLYPH_SET = {tuple(g) for g in GLYPHS}
GLYPH_CP = {tuple(g): cp for g, cp in zip(GLYPHS,
              [cp_of_glyph(i) for i in range(len(GLYPHS))]) if cp}

fails = 0
def L(msg, ok=None):
    global fails
    mark = ""
    if ok is not None:
        mark = " OK" if ok else " FAIL"
        if not ok:
            fails += 1
    print(f"{msg}{mark}", flush=True)


class Screen:
    """Снимок экрана + быстрая битовая плоскость для OCR 8x16."""

    def __init__(self, vm, name="snap.ppm"):
        self.path = vm.screendump(name)
        self.w, self.h, img = read_ppm(self.path)
        w = self.w
        br = bytearray(w * self.h)
        for i in range(w * self.h):
            p = img[i*3:i*3+3]
            br[i] = 1 if (p[0] + p[1] + p[2]) > 400 else 0
        self.br = br
        self.w = w

    def glyph_at(self, x, y):
        br, w = self.br, self.w
        pat = []
        for ry in range(16):
            b = 0
            row = (y + ry) * w
            base = row + x
            for rx in range(8):
                if br[base + rx]:
                    b |= 0x80 >> rx
            pat.append(b)
        return tuple(pat)

    def read_line(self, ytop, xo, n_cells=96):
        out = []
        for c in range(n_cells):
            x = xo + c * 8
            if x + 8 > self.w or ytop + 16 > self.h:
                out.append(" ")
                continue
            g = self.glyph_at(x, ytop)
            if any(g):
                cp = GLYPH_CP.get(g)
                out.append(chr(cp) if cp else "?")
            else:
                out.append(" ")
        return "".join(out)

    def find(self, needle, y_from, y_to, x_from=8, x_to=None, step=1):
        """Искать подстроку needle (с нормализацией гомоглифов х<->x,
        е<->e и т.п. — DejaVu Mono делает их байт-в-байт одинаковыми):
        вернуть (центр_x, y_center) первого совпадения или None."""
        needle = norm(needle)
        if x_to is None:
            x_to = self.w - 8
        for y in range(y_from, y_to, step):
            for xo in range(x_from, x_from + 8):
                n_cells = (x_to - xo) // 8
                t = norm(self.read_line(y, xo, n_cells))
                if needle in t:
                    i = t.index(needle)
                    cx = xo + (i + len(needle) / 2.0) * 8
                    return (int(cx), y + 8)
        return None


def build_superfloppy():
    data, P = mkexfat.build(None)
    path = os.path.join(OUT, "exfat.img")
    open(path, "wb").write(data)
    return path


def build_mbr_exfat():
    data, P = mkexfat.build(None, part_off=2048)   # СЕССИЯ 84: PartitionOffset по спеке
    img = bytearray(2048 * 512 + len(data))
    mbr = bytearray(512)
    mbr[510:512] = b"\x55\xAA"
    e = 446
    mbr[e + 0] = 0x80
    mbr[e + 4] = 0x07
    mbr[e + 8:e + 12] = (2048).to_bytes(4, "little")
    mbr[e + 12:e + 16] = (len(data) // 512).to_bytes(4, "little")
    img[0:512] = mbr
    img[2048 * 512:2048 * 512 + len(data)] = data
    path = os.path.join(OUT, "exfat_mbr.img")
    open(path, "wb").write(img)
    return path


def build_fat32_stick():
    import struct
    path = os.path.join(OUT, "fat32.img")
    total_secs = 40 * 1024 * 1024 // 512
    spc, rsvd, nfats = 1, 32, 2
    fsz = (total_secs * 4 // 512) + 8
    data_start = rsvd + nfats * fsz
    img = bytearray(total_secs * 512)
    bs = bytearray(512)
    bs[0:3] = b"\xEB\x58\x90"
    bs[3:11] = b"MKFSPY  "
    bs[11:13] = struct.pack("<H", 512)
    bs[13] = spc
    bs[14:16] = struct.pack("<H", rsvd)
    bs[16] = nfats
    bs[19:21] = struct.pack("<H", 0xFF8)
    bs[21] = 0xF8
    bs[32:36] = struct.pack("<I", total_secs)
    bs[36:40] = struct.pack("<I", fsz)
    bs[44:48] = struct.pack("<I", 2)
    bs[510:512] = b"\x55\xAA"
    img[0:512] = bs
    for f in range(nfats):
        off = (rsvd + f * fsz) * 512
        img[off + 8:off + 12] = b"\xFF\xFF\xFF\x0F"
        img[off + 12:off + 16] = b"\xFF\xFF\xFF\x0F"
    content = b"Hello from FAT32 stick!\n"
    dstart = (data_start + (3 - 2) * spc) * 512
    img[dstart:dstart + len(content)] = content
    root_off = (data_start + (2 - 2) * spc) * 512
    de = bytearray(32)
    de[0:11] = b"HELLO   TXT"
    de[11] = 0x20
    de[26:28] = struct.pack("<H", 3)
    de[28:32] = struct.pack("<I", len(content))
    img[root_off:root_off + 32] = de
    open(path, "wb").write(img)
    return path


def boot_with_stick(img_path, tag):
    vm = Vm(ISO, os.path.join(OUT, tag), smp=2,
            extra_args=[
                "-device", "usb-ehci,id=ehci",
                "-device", "usb-storage,bus=ehci.0,drive=usbdisk",
                "-drive", f"if=none,id=usbdisk,file={img_path},format=raw",
            ])
    vm.wait_serial("irq on", 240)
    time.sleep(14)
    return vm


def open_files_app(vm):
    vm.click(420, 39)          # терминал (как в verify82)
    time.sleep(1.0)
    vm.type("\n", delay=0.1)
    time.sleep(0.3)
    vm.type("files\n", delay=0.15)
    time.sleep(2.5)
    # Терминал (20,16,650x434) перекрывает ФМ (30,30,520x380) — ЗАКРЫВАЕМ
    # его ([x] в правом верхнем углу терминала), ФМ остаётся единственным
    # окном и полностью видимым для OCR.
    vm.click(664, 27)
    time.sleep(1.5)


def scenario_A():
    L("=== A: exFAT суперфлоппи ===")
    img = build_superfloppy()
    vm = boot_with_stick(img, "A")
    open_files_app(vm)
    ok = vm.wait_serial("[exfat] смонтирован", 30)
    L("A1. [exfat] смонтирован в serial", ok)
    ser = vm.serial()
    L("A1a. автомонтирование по fm_tick",
      "попытка монтирования" in ser)
    time.sleep(1.5)
    # [USB]-кнопка: геометрия fm_devbar_layout — окно (30,30), девбар
    # x=6..[CD] | тома C:,D: (нет) | [RAM]@60 | [USB]@114, w=50 → центр (169,66).
    # НЕактивные кнопки рисуются dim-цветом (OCR их не видит) — кликаем
    # по расчётной позиции.
    vm.click(169, 66)
    time.sleep(1.5)
    sc2 = Screen(vm, "A_usb_list.ppm")
    hit2 = sc2.find("big.txt", 90, 400)
    L("A3. big.txt в списке (OCR)", hit2 is not None)
    if hit2:
        vm.click(hit2[0], hit2[1])
        time.sleep(0.5)
        vm.click(hit2[0], hit2[1])   # второй клик по выделенной = открыть
        time.sleep(2.0)
    sc3 = Screen(vm, "A_editor.ppm")
    hit3 = sc3.find("N2600-EXFAT", 40, 560, x_from=8, x_to=790)
    L("A4. редактор открыл big.txt (много-кластерный NoFatChain), "
      "контент виден", hit3 is not None)
    ser = vm.serial()
    L("A5. исключений/паник нет",
      "CPU EXCEPTION" not in ser and "PANIC" not in ser)
    vm.key("esc"); time.sleep(0.4)
    vm.key("esc"); time.sleep(0.4)
    vm.kill()
    return ok and hit2 is not None and hit3 is not None


def scenario_B():
    L("=== B: exFAT в MBR-разделе (тип 0x07, как Windows) ===")
    img = build_mbr_exfat()
    vm = boot_with_stick(img, "B")
    open_files_app(vm)
    ok = vm.wait_serial("[exfat] смонтирован", 30)
    ser = vm.serial()
    L("B1. exFAT-раздел смонтирован (перебор MBR)", ok)
    L("B1a. MBR перебор запускался", "MBBR есть" in ser or "MBR есть" in ser
      or "раздел" in ser)
    time.sleep(1.5)
    vm.click(169, 66)      # [USB]: расчётная позиция (см. сценарий A)
    time.sleep(1.5)
    sc2 = Screen(vm, "B_usb_list.ppm")
    hit2 = sc2.find("big.txt", 90, 400)
    L("B3. big.txt в списке", hit2 is not None)
    ser = vm.serial()
    L("B4. исключений нет", "CPU EXCEPTION" not in ser)
    vm.kill()
    return ok and hit2 is not None


def scenario_C():
    L("=== C: регресс FAT32-флешка ===")
    img = build_fat32_stick()
    vm = boot_with_stick(img, "C")
    open_files_app(vm)
    vm.wait_serial("смонтирован", 30)
    ser = vm.serial()
    ok = "[fat32] usb:" in ser
    L("C1. FAT32 монтировалась через usb-путь (serial)", ok)
    vm.click(169, 66)      # [USB]: расчётная позиция
    time.sleep(1.5)
    sc2 = Screen(vm, "C_usb_list.ppm")
    hit2 = sc2.find("HELLO.TXT", 90, 400)
    L("C3. HELLO.TXT в списке", hit2 is not None)
    vm.kill()
    return ok and hit2 is not None


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    rc = True
    if which in ("A", "all"):
        rc &= scenario_A()
    if which in ("B", "all"):
        rc &= scenario_B()
    if which in ("C", "all"):
        rc &= scenario_C()
    print("\nИТОГ:", "ВСЕ СЦЕНАРИИ ОК" if rc else "ЕСТЬ ПРОВАЛЫ",
          f"(fails={fails})")
    sys.exit(0 if rc else 1)
