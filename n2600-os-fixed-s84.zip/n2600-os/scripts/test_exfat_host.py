#!/usr/bin/env python3
# test_exfat_host.py — хост-тест exFAT чтение+запись (сессия 75).
#
# 1. mkexfat.py строит валидный exFAT-образ (VBR/FAT/битовая карта/
#    UpCase/корень с файлами, кириллица, подкаталог).
# 2. Харнесс test_exfat_host.c (+ src/exfat.c) проверяет монтирование,
#    список, чтение, поиск, создание, перезапись, mkdir, удаление,
#    перемонтирование.
# 3. Питон-проверка структур НА ДИСКЕ после записи: контрольная сумма
#    набора записей, хэш имени, EOC-конец FAT-цепочки нового файла,
#    биты карты занятости (создание/удаление), снятие InUse.
#
# Запуск: python3 scripts/test_exfat_host.py
import os, struct, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import mkexfat

TMP = tempfile.mkdtemp(prefix="exfat_")
IMG = os.path.join(TMP, "exfat.img")
BIN = os.path.join(TMP, "exfat_test")
SRC = os.path.join(ROOT, "src")

fails = 0
def check(cond, what):
    global fails
    print(("  [OK]   " if cond else "  [FAIL] ") + what)
    if not cond:
        fails += 1

# ---------- 1. образ ----------
data, P = mkexfat.build(IMG)
check(len(data) == 8388608, "образ 8 МиБ построен")

# ---------- 1a. СЕССИЯ 84: смещения полей VBR ПО СПЕЦИФИКАЦИИ ----------
# Прежний генератор (s75-s83) писал поля со сдвигом −8 (пропущено
# PartitionOffset@64) — fsck.exfat признавал образ битым, а exfat.c
# читал те же смещения: пара «генератор+парсер» проходила тесты, но
# реальная флешка Windows не монтировалась («bps shift вне 9..12» —
# bs[100] у настоящего тома это МЛАДШИЙ БАЙТ СЕРИЙНОГО НОМЕРА).
# Проверки ниже запирают генератор на спека-раскладку (сверено
# дампом реального mkfs.exfat 1.2.9).
def _le(off, n):
    return int.from_bytes(data[off:off + n], "little")

check(data[0:3] == b"\xEB\x76\x90" and data[3:11] == b"EXFAT   ",
      "VBR: JumpBoot EB 76 90 + «EXFAT   » @3")
check(data[11:64] == bytes(53), "VBR: MustBeZero 11..63")
check(_le(64, 8) == 0, "VBR: PartitionOffset@64 = 0 (суперфлоппи)")
check(_le(72, 8) == 16384, "VBR: VolumeLength@72 = 16384 сект.")
check(_le(80, 4) == P["fat_off"], "VBR: FatOffset@80")
check(_le(84, 4) == P["fat_len"], "VBR: FatLength@84")
check(_le(88, 4) == P["heap_off"], "VBR: ClusterHeapOffset@88")
check(_le(92, 4) == P["clusters"], "VBR: ClusterCount@92")
check(_le(96, 4) == P["root"], "VBR: FirstClusterOfRootDir@96")
check(_le(104, 2) == 0x0100, "VBR: FileSystemRevision@104 = 1.00")
check(_le(106, 2) == 0, "VBR: VolumeFlags@106 = 0")
check(_le(108, 1) == 9, "VBR: BytesPerSectorShift@108 = 9")
check(_le(109, 1) == 3, "VBR: SectorsPerClusterShift@109 = 3")
check(_le(110, 1) == 1, "VBR: NumberOfFats@110 = 1")
check(_le(111, 1) == 0x80, "VBR: DriveSelect@111 = 0x80")
check(data[510:512] == b"\x55\xAA", "VBR: 55AA@510")
check(all(data[s * 512 + 510:s * 512 + 512] == b"\x55\xAA" for s in range(1, 9)),
      "boot: ExtendedBoot 1..8 с 55AA в хвосте")
check(data[12 * 512:24 * 512] == data[0:12 * 512],
      "boot: бэкап-регион 12..23 — зеркало 0..11")

# ---------- 2. компиляция и прогон харнесса ----------
cc = ["gcc", "-O2", "-Wall", "-Wno-unused-function",
      "-I" + SRC,
      "-Dmalloc=exfat_hmalloc", "-Dfree=exfat_hfree",
      os.path.join(HERE, "test_exfat_host.c"),
      os.path.join(SRC, "exfat.c"),
      "-o", BIN]
r = subprocess.run(cc, capture_output=True, text=True)
check(r.returncode == 0, "харнесс скомпилирован (exfat.c на хосте)")
if r.returncode != 0:
    print(r.stderr[:2000])
    sys.exit(1)

IMG_OUT = os.path.join(TMP, "exfat-after.img")
r = subprocess.run([BIN, IMG, IMG_OUT], capture_output=True,
                   text=True, errors="replace")
print(r.stdout.rstrip())
c_ok = "ВСЕ ТЕСТЫ ПРОШЛИ" in r.stdout
check(c_ok, "харнесс: все C-тесты прошли")
if not c_ok:
    fails += 1

# ---------- 3. структуры на диске ----------
def root_entries():
    heap = P["heap_off"]
    rootc = P["root"]
    off = (heap + (rootc - 2) * 8) * 512
    out = []
    pos = off
    while True:
        t = data[pos]
        if t == 0 or t == 0x00:
            break
        if (t & 0x7F) == 0x05:            # 0x85 (в т.ч. удалённый 0x05)
            sec = data[pos + 1]
            out.append((pos, sec))
            pos += 32 * sec
            continue
        pos += 32
    return out

def cluster_bytes(c, n=1):
    off = (P["heap_off"] + (c - 2) * 8) * 512
    return data[off:off + n * 4096]

def fat_val(c):
    fo = P["fat_off"] * 512
    return struct.unpack_from("<I", data, fo + c * 4)[0]

data = open(IMG_OUT, 'rb').read()
img = bytearray(data)

def upcase16(c):
    return mkexfat.upcase16(c)

check(len(root_entries()) >= 3, "в корне есть наборы записей (0x85)")

# контрольная сумма + хэш набора hello.txt после перезаписи
fe = None
for pos, sec in root_entries():
    first = 0
    dlen = 0
    chars = []
    for k in range(1, sec + 1):        # файл + все secondary (sec_count+1)
        eb = data[pos + k * 32:pos + k * 32 + 32]
        if eb[0] == 0xC1:
            for i in range(15):
                ch = struct.unpack_from("<H", eb, 2 + i * 2)[0]
                if ch:
                    chars.append(chr(ch))
        elif eb[0] == 0xC0:
            # СЕССИЯ 84: FirstCluster@20, DataLength@24 — по спецификации
            first = struct.unpack_from("<I", eb, 20)[0]
            dlen = struct.unpack_from("<Q", eb, 24)[0]
    name = "".join(chars)
    if name == "hello.txt":
        fe = (pos, sec, first, dlen)

check(fe is not None, "набор hello.txt найден на диске")
if fe:
    pos, sec, first, dlen = fe
    st = data[pos:pos + 32 * (sec + 1)]
    s = 0
    for i, b in enumerate(st):
        if i == 2 or i == 3:
            continue
        s = ((s << 15) | (s >> 1)) & 0xFFFF
        s = (s + b) & 0xFFFF
    stored = struct.unpack_from("<H", st, 2)[0]
    check(stored == s, "контрольная сумма набора hello.txt корректна")
    check(dlen == 12, "DataLength hello.txt = 12 (после перезаписи)")
    u16name = "hello.txt".encode("utf-16-le")
    h = 0
    for (ch,) in struct.iter_unpack("<H", u16name):
        up = upcase16(ch)
        # СЕССИЯ 84: ДВА шага на u16 (младший байт, затем старший) — spec
        h = ((h << 15) | (h >> 1)) & 0xFFFF
        h = (h + (up & 0xFF)) & 0xFFFF
        h = ((h << 15) | (h >> 1)) & 0xFFFF
        h = (h + (up >> 8)) & 0xFFFF
    stored_hash = struct.unpack_from("<H", st, 32 + 4)[0]
    check(stored_hash == h, "NameHash hello.txt совпадает со spec-расчётом")
    # FAT-цепочка: 12 байт = 1 кластер, EOC
    check(fat_val(first) == 0xFFFFFFFF,
          "FAT-цепочка hello.txt заканчивается EOC")

# биты карты: sub(каталог) занят, new.txt свободен
fe_sub = None
for pos, sec in root_entries():
    chars = []
    for k in range(1, sec + 1):
        eb = data[pos + k * 32:pos + k * 32 + 32]
        if eb[0] == 0xC1:
            for i in range(15):
                ch = struct.unpack_from("<H", eb, 2 + i * 2)[0]
                if ch:
                    chars.append(chr(ch))
        elif eb[0] == 0xC0:
            pass
    name = "".join(chars)
    if name == "sub":
        eb = data[pos + 32:pos + 64]
        # СЕССИЯ 84: FirstCluster Stream-записи @20
        fe_sub = struct.unpack_from("<I", eb, 20)[0]
# (имя sub ищется в наборе с range(1, sec+1) выше по тексту — блок ниже)

check(fe_sub is not None and fe_sub >= 2, "каталог sub имеет кластер")
if fe_sub:
    bm_off = 0
    # карта: bit N = cluster N+2
    bit_idx = fe_sub - 2
    bm_byte = data[(P["heap_off"] + 0) * 512 + (P["bm_first"] - 2) * 4096 + (bit_idx >> 3)]
    check((bm_byte >> (bit_idx & 7)) & 1,
          "бит карты занятости выставлен для кластера sub")

# удалённый new.txt: InUse снят у 0x85
found_deleted = False
pos = (P["heap_off"] + (P["root"] - 2) * 8) * 512
while data[pos] != 0:
    t = data[pos]
    if t == 0x05:
        found_deleted = True
        break
    if t == 0x85:
        pos += 32 * data[pos + 1]
        continue
    pos += 32
check(found_deleted, "удалённая запись new.txt: тип 0x05 (InUse снят)")

# ---------- 4. СЕССИЯ 84: кросс-валидация с exfatprogs ----------
# fsck.exfat — НЕЗАВИСИМЫЙ судья: образ после записи ОС-драйвером
# должен проходить проверку настоящего exFAT-инструмента. mkfs.exfat —
# монтирование тома, созданного реальным форматтером (как флешка
# пользователя), + запись в него + повторный fsck.
EXFATPROGS = "/home/z/my-project/exfat-tools/usr/sbin"
fsck = os.path.join(EXFATPROGS, "fsck.exfat")
mkfs = os.path.join(EXFATPROGS, "mkfs.exfat")
if os.path.exists(fsck):
    r = subprocess.run([fsck, IMG_OUT], capture_output=True, text=True,
                       timeout=120)
    check(r.returncode == 0,
          "fsck.exfat: образ mkexfat.py после ЗАПИСИ ОС-драйвера валиден")
    if r.returncode != 0:
        print("    fsck:", (r.stdout + r.stderr)[:400])
if os.path.exists(mkfs):
    real = os.path.join(TMP, "real_mkfs.img")
    with open(real, "wb") as f:
        f.truncate(8 * 1024 * 1024)
    r = subprocess.run([mkfs, "--cluster-size", "4096", real],
                       capture_output=True, text=True, timeout=120)
    check(r.returncode == 0, "mkfs.exfat создал том")
    if r.returncode == 0:
        after = os.path.join(TMP, "real_after.img")
        r2 = subprocess.run([BIN, real, "--mkfs", after],
                            capture_output=True, text=True,
                            errors="replace", timeout=120)
        print(r2.stdout.rstrip())
        check("ВСЕ ТЕСТЫ ПРОШЛИ" in r2.stdout,
              "харнесс: том mkfs.exfat смонтирован + список + запись + чтение")
        if os.path.exists(fsck) and os.path.exists(after):
            r3 = subprocess.run([fsck, after], capture_output=True, text=True,
                                timeout=120)
            check(r3.returncode == 0,
                  "fsck.exfat: том mkfs.exfat после записи ОС остаётся валидным")
            if r3.returncode != 0:
                print("    fsck:", (r3.stdout + r3.stderr)[:400])
else:
    print("  [SKIP] exfatprogs не установлены — кросс-валидация пропущена")

print()
print("ИТОГ: " + ("ВСЕ ПРОВЕРКИ ПРОШЛИ" if fails == 0 else f"{fails} ПРОВАЛ(ОВ)"))
sys.exit(1 if fails else 0)
