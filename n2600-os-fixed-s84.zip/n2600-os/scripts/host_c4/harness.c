/* harness.c — хост-тестбед для нативного c4-кодогенератора (32-бит).
 *
 * Компилирует тест-программы через c4_compile_to_native (тот же код,
 * что в ОС), загружает C4N1 (код+данные+релокации — как loader.c),
 * вызывает entry(kapi, win) как обычную функцию и проверяет результат.
 * Позволяет отлаживать кодогенерацию без QEMU: лестница
 * return 0 → присваивание → printf → цикл → kfill.
 */
/* Freestanding-объявления libc (32-битный тулчейн собран вручную из .deb,
 * bits/-заголовков нет). Строковые/память — из настоящих src/string.h и
 * src/mem.h (ABI i386: size_t == u32). Остальное объявляем руками. */
#include "string.h"
#include "mem.h"
extern int printf(const char *fmt, ...);
extern int fprintf(void *stream, const char *fmt, ...);
extern int fputs(const char *s, void *stream);
extern char *getenv(const char *name);
extern void exit(int code) __attribute__((noreturn));
extern void *stderr;
#define HOST_STDERR (stderr)
extern int fflush(void *f);
#define FLUSH() do { fflush(0); } while (0)


/* сессия 74: FPU-лок (в ядре — imgsvc.c; на хосте — no-op: задачи не
 * вытесняются во время выполнения c4-тестов). Entry-stab native-бинар
 * зовёт их ДО main и ПОСЛЕ (сброс x87) — обязаны быть в kapi_t. */
void img_fpu_lock(void) { }
void img_fpu_unlock(void) { }

typedef unsigned char u8_;
typedef unsigned int size_t;
#include "string.h"
#include "mem.h"
#include "c4.h"
#include "kapi.h"

/* ---------------- shim-реализации ---------------- */
static u32 host_ticks = 0;
u32 timer_ticks(void) { return ++host_ticks; }
void task_yield(void) { }
void task_msleep(u32 ms) { (void)ms; }
int kbd_pop(void *ev) { (void)ev; return 0; }

/* Экран-заглушка: проверяем kfill-вызовы записью в лог */
#define LOG_MAX 64
static char g_log[LOG_MAX][96];
static int g_nlog = 0;
static void log_call(const char *fmt, ...) {
    if (g_nlog >= LOG_MAX) return;
    __builtin_va_list ap; __builtin_va_start(ap, fmt);
    vsnprintf(g_log[g_nlog], 90, fmt, ap);
    __builtin_va_end(ap);
    g_nlog++;
}
void fb_fill_rect(int x, int y, int w, int h, u32 c) {
    log_call("kfill(%d,%d,%d,%d,0x%x)", x, y, w, h, c);
}
void fb_text(int x, int y, const char *s, u32 fg, int bg) {
    log_call("ktext(%d,%d,\"%s\",0x%x,%d)", x, y, s, fg, bg);
}
u32 fb_rgb(u8 r, u8 g, u8 b) { return ((u32)r << 16) | ((u32)g << 8) | b; }
void fb_touch_all(void) { }
void fb_flush(void) { }
int fb_width(void) { return 800; }
int fb_height(void) { return 600; }
void fb_fill_screen(u32 c) { log_call("kclear(0x%x)", c); }
struct window;
void win_invalidate_stub(struct window *w) { (void)w; log_call("kflip()"); }

/* ramfs-заглушки (c4_compile_to_file не используется) */
int ramfs_ready(void) { return 0; }
int ramfs_delete(const char *n) { (void)n; return 0; }
int ramfs_create(const char *n, u32 s) { (void)n; (void)s; return 0; }
int ramfs_write(const char *n, const void *b, u32 s) { (void)n; (void)b; (void)s; return 0; }
u32 ramfs_read(const char *n, void *b, u32 m) { (void)n; (void)b; (void)m; return 0; }

void serial_puts(const char *s) { fputs(s, stderr); }

/* c4gfx-обёртки (VM-опкоды KFILL/KTEXT/... зовут их, не fb_*):
 * логируем в общий лог — формат совпадает с fb_*-обёртками, чтобы
 * expect_calls матчился одинаково для VM и native режимов. */
void c4_gfx_fill_rect(int x, int y, int w, int h, u32 c) {
    log_call("kfill(%d,%d,%d,%d,0x%x)", x, y, w, h, c);
}
void c4_gfx_text(int x, int y, const char *s, u32 fg, int bg) {
    log_call("ktext(%d,%d,\"%s\",0x%x,%d)", x, y, s, fg, bg);
}
void c4_gfx_fill_screen(u32 c) { log_call("kclear(0x%x)", c); }
u32 c4_gfx_width(void) { return 800; }
u32 c4_gfx_height(void) { return 600; }
void c4_gfx_flip(struct window *unused) { (void)unused; log_call("kflip()"); }
int c4_gfx_event_poll(void *buf) { (void)buf; return 0; }

/* ---------------- kapi для запускаемых программ ---------------- */
static char g_out[16384];
static u32 g_out_len = 0;

static void h_print_str(const char *s, u32 len) {
    for (u32 i = 0; i < len && g_out_len + 1 < sizeof(g_out); i++)
        g_out[g_out_len++] = s[i];
    g_out[g_out_len] = 0;
}
static int h_event_poll(void *buf) { (void)buf; return 0; }
static int h_printf_va(const char *fmt, int nargs, int *args_reversed) {
    /* СЕССИЯ 83: прежняя реализация была УСТАРЕВШЕЙ КОПИЕЙ c4_printf_va
     * (без флагов ширины/точности, %f, точного возврата) — тесты native
     * форматирования шли мимо новых фиксов. Теперь — тонкая обёртка над
     * НАСТОЯЩЕЙ c4_printf_va: вывод перенаправляем через c4_capture_*,
     * как это делает loader ОС. */
    extern int c4_printf_va(const char *fmt, int nargs, int *args_reversed);
    extern void c4_capture_begin(char *buf, u32 max);
    extern u32 c4_capture_len(void);
    extern void c4_capture_end(void);
    u32 space = (u32)sizeof(g_out) - (u32)g_out_len;
    if (space < 2) space = 2;
    c4_capture_begin(g_out + g_out_len, space);
    int n = c4_printf_va(fmt, nargs, args_reversed);
    g_out_len += (int)c4_capture_len();
    c4_capture_end();
    return n;
}

/* Дамп кода (для отладки) */
static void dump_code(const u8 *code, u32 n) {
    fprintf(HOST_STDERR, "--- code %u bytes ---\n", n);
    for (u32 i = 0; i < n; i++) {
        fprintf(HOST_STDERR, "%02x ", code[i]);
        if ((i & 15) == 15) fprintf(HOST_STDERR, "\n");
    }
    fprintf(HOST_STDERR, "\n");
}

/* Запуск одной тест-программы: compile → C4N1-load → entry() */
static int failures = 0, passes = 0;

static void run_test(const char *name, const char *src,
                     int expect_rc, const char *expect_out,
                     const char *expect_calls) {
    fprintf(HOST_STDERR, "[dbg] test %s: compile...\n", name);
    char diag[256] = {0};
    static u8 out_buf[256 * 1024];
    u32 out_size = 0;

    int r = c4_compile_to_native(src, diag, sizeof(diag), out_buf, sizeof(out_buf), &out_size);
    if (r != 0) {
        printf("FAIL: compile: %s\n", diag);
        failures++;
        return;
    }
    fprintf(HOST_STDERR, "[dbg] %s: compiled %u bytes, load C4N1...\n", name, out_size);
    extern u8 c4_x86_data_out[65536];
    extern u32 c4_x86_data_out_len;
    extern u32 c4_x86_data_relocs_out[8192];
    extern int c4_x86_n_data_relocs_out;
    u32 data_len = c4_x86_data_out_len;
    u32 n_rel = (u32)c4_x86_n_data_relocs_out;

    if (getenv("C4_DUMP")) dump_code(out_buf, out_size);

    /* Копия кода: mmap RWX (heap имеет NX на хосте; в ОС памятиexecutable) */
    extern void *mmap(void *addr, unsigned long len, int prot, int flags, int fd, long off);
    u8 *code = (u8 *)mmap(0, (out_size + 4095) & ~4095UL, 7 /*RWX*/, 0x22 /*PRIV|ANON*/, -1, 0);
    if ((long)code < 0 && (long)code > -4096) { printf("FAIL: mmap code\n"); failures++; return; }
    memcpy(code, out_buf, out_size);
    u8 *data = data_len ? malloc(data_len) : NULL;
    if (data_len) memcpy(data, c4_x86_data_out, data_len);
    for (u32 i = 0; i < n_rel; i++) {
        u32 off = c4_x86_data_relocs_out[i];
        *(u32 *)(code + off) += (u32)(unsigned long)data;
    }


    /* kapi-таблица */
    kapi_t k;
    memset(&k, 0, sizeof(k));
    k.fb_fill_rect = fb_fill_rect;
    k.fb_text = fb_text;
    k.fb_rgb = fb_rgb;
    k.fb_fill_screen = fb_fill_screen;
    k.win_invalidate = win_invalidate_stub;   /* kflip */
    k.fb_width = (u32 (*)(void))fb_width;
    k.fb_height = (u32 (*)(void))fb_height;
    k.c4_print_str = h_print_str;
    k.c4_event_poll = h_event_poll;
    k.c4_printf_va = h_printf_va;
    k.msleep = task_msleep;
    /* сессия 74: entry-stab зовёт fpu_lock/fpu_unlock — на хосте no-op */
    k.fpu_lock = img_fpu_lock;
    k.fpu_unlock = img_fpu_unlock;

    g_out_len = 0; g_out[0] = 0;
    g_nlog = 0;

    fprintf(HOST_STDERR, "[dbg] %s: calling entry...\n", name);
    int (*entry)(kapi_t *, void *) = (int (*)(kapi_t *, void *))(void *)code;
    int rc = entry(&k, NULL);
    fprintf(HOST_STDERR, "[dbg] %s: entry returned %d\n", name, rc);

    int ok = 1;
    if (rc != expect_rc) {
        printf("FAIL: exit code %d (ожидался %d)\n", rc, expect_rc);
        ok = 0;
    }
    if (expect_out && strcmp(g_out, expect_out) != 0) {
        printf("FAIL: вывод:\n  получен:  \"%s\"\n  ожидался: \"%s\"\n", g_out, expect_out);
        ok = 0;
    }
    /* Проверка вызовов fb: все ожидаемые подстроки в логе */
    if (expect_calls) {
        const char *p = expect_calls;
        while (*p) {
            const char *semi = strchr(p, ';');
            size_t L = semi ? (size_t)(semi - p) : strlen(p);
            int found = 0;
            for (int i = 0; i < g_nlog; i++) {
                if (strncmp(g_log[i], p, L) == 0) { found = 1; break; }
            }
            if (!found) {
                printf("FAIL: вызов \"%.*s\" не найден (лог:\n", (int)L, p);
                for (int i = 0; i < g_nlog; i++) printf("    %s\n", g_log[i]);
                printf(")\n");
                ok = 0;
            }
            if (!semi) break;
            p = semi + 1;
        }
    }
    if (ok) { printf("PASS\n"); passes++; }
    else failures++;
    FLUSH();
    extern int munmap(void *addr, unsigned long len);
    munmap(code, (out_size + 4095) & ~4095UL);
    if (data) free(data);
}

/* VM-тест: тот же исходник через c4_run (интерпретатор) */
void vm_test(const char *name, const char *src, int expect_rc, const char *expect_out) {
    fprintf(HOST_STDERR, "[dbg] VM test %s...\n", name);
    printf("== VM: %s ==\n", name); FLUSH();
    char out[4096];
    int r = c4_run(src, out, sizeof(out));
    int ok = 1;
    if (r != expect_rc) { printf("FAIL: VM exit %d (ожидался %d)\n", r, expect_rc); ok = 0; }
    if (expect_out && strcmp(out, expect_out) != 0) {
        printf("FAIL: VM вывод:\n  получен:  \"%s\"\n  ожидался: \"%s\"\n", out, expect_out);
        ok = 0;
    }
    if (ok) { printf("PASS\n"); passes++; } else failures++; FLUSH();
}

int main(void) {
    /* 1: return 0 */
    run_test("t1 return 0", "int main() { return 0; }", 0, NULL, NULL);

    /* 2: присваивание и арифметика */
    run_test("t2 арифметика",
             "int main() { int a; int b; a = 6; b = 7; return a * b; }",
             42, NULL, NULL);

    /* 2b: вычитание/сдвиги/сравнения — операнды не перепутаны */
    run_test("t2b некоммутативные",
             "int main() { int a; a = 10 - 3; return a * 100 + (2 << 3) + (a > 2) + (a < 2); }",
             717, NULL, NULL);

    /* 3: printf */
    run_test("t3 printf",
             "int main() { printf(\"privet %d\\n\", 42);"
             " printf(\"%s-%s\\n\", \"stroka\", \"test\");"
             " printf(\"char: %c%c%c\\n\", 65, 66, 67); return 3; }",
             3, "privet 42\nstroka-test\nchar: ABC\n", NULL);

    /* 4: циклы */
    run_test("t4 циклы",
             "int main() { int i; int sum; sum = 0;"
             " for (i = 1; i <= 10; i = i + 1) { sum = sum + i; }"
             " printf(\"sum=%d\\n\", sum);"
             " while (sum > 50) { sum = sum - 1; }"
             " printf(\"after=%d\\n\", sum); return sum; }",
             50, "sum=55\nafter=50\n", NULL);

    /* 5: глобалы, массивы, функции, деление */
    run_test("t5 глобалы/массивы",
             "int g; int arr[6];\n"
             "int sq(int x) { return x * x; }\n"
             "int main() { int i; g = 0;"
             " for (i = 0; i < 6; i = i + 1) { arr[i] = sq(i + 1); g = g + arr[i]; }"
             " printf(\"g=%d\\n\", g);"
             " printf(\"arr[3]=%d arr[5]=%d\\n\", arr[3], arr[5]);"
             " printf(\"div=%d mod=%d\\n\", g / 7, g % 7); return g; }",
             91, "g=91\narr[3]=16 arr[5]=36\ndiv=13 mod=0\n", NULL);

    /* 5b: деление на ноль — не должно ронять тестбед */
    run_test("t5b деление на ноль",
             "int main() { int a; a = 5; printf(\"start\\n\");"
             " a = a / 0; printf(\"unreachable %d\\n\", a); return 9; }",
             -1, "start\ndivide by zero\n", NULL);

    /* 6: графика kfill/ktext/krgb + kdelay */
    run_test("t6 графика",
             "int main() {"
             " kfill(560, 0, 240, 90, krgb(255, 0, 0)); kflip();"
             " printf(\"red band\\n\"); kdelay(300);"
             " kfill(560, 90, 240, 90, krgb(0, 200, 0)); kflip(); kdelay(300);"
             " kfill(560, 180, 240, 90, krgb(0, 80, 255));"
             " ktext(570, 200, \"C4 OK\", 0xFFFFFF, -1); kflip(); kdelay(300);"
             " printf(\"graphics done\\n\"); return 6; }",
             6, "red band\ngraphics done\n",
             "kfill(560,0,240,90,0xff0000);kfill(560,90,240,90,0xc800);"
             "kfill(560,180,240,90,0x50ff);ktext(570,200,\"C4 OK\",0xffffff,-1)");

    /* 7: строки: глобальные указатели, индексация */
    run_test("t7 строки",
             "char buf[16];\n"
             "int main() { int i; char *s; s = \"hello\";"
             " for (i = 0; i < 5; i = i + 1) { buf[i] = s[i]; }"
             " buf[5] = 0; printf(\"%s!\\n\", buf); return buf[1]; }",
             101, "hello!\n", NULL);

    /* 8: рекурсия (fib) */
    run_test("t8 рекурсия",
             "int fib(int n) { if (n < 2) return n; return fib(n - 1) + fib(n - 2); }\n"
             "int main() { printf(\"fib10=%d\\n\", fib(10)); return fib(6); }",
             8, "fib10=55\n", NULL);

    /* 9: escape-последовательности C89 */
    run_test("t9 escapes",
             "int main() {"
             " printf(\"A\\tB\\n\");"
             " printf(\"x\\rZ\\n\");"
             " printf(\"\\x41\\x42\\n\");"
             " printf(\"\\101\\102\\n\");"
             " printf(\"q\\\\w\\\"e\\'\\n\");"
             " printf(\"[%d]\\n\", '\\t');"
             " printf(\"[%d]\\n\", '\\x41');"
             " printf(\"[%d]\\n\", '\\101');"
             " printf(\"[%d]\\n\", '\\n');"
             " return 9; }",
             9,
             "A\tB\nx\rZ\nAB\nAB\nq\\w\"e'\n[9]\n[65]\n[65]\n[10]\n",
             NULL);

    /* 10: оператор «запятая» */
    run_test("t10 comma",
             "int main() { int i; int j; int s;"
             " for (i = 0, j = 10; i < j; i = i + 1, j = j - 1) { s = i * 100 + j; }"
             " printf(\"i=%d j=%d s=%d\\n\", i, j, s);"
             " s = (i = 1, j = 2, i + j);"
             " printf(\"s=%d\\n\", s);"
             " return s; }",
             3, "i=5 j=5 s=406\ns=3\n", NULL);

    /* 11: составные присваивания */
    run_test("t11 compound",
             "int main() {"
             " int x; char c; int a[4]; int *p; unsigned int u;"
             " x = 10;"
             " x += 5;  printf(\"%d \", x);"
             " x -= 3;  printf(\"%d \", x);"
             " x *= 4;  printf(\"%d \", x);"
             " x /= 5;  printf(\"%d \", x);"
             " x %= 5;  printf(\"%d \", x);"
             " x <<= 3; printf(\"%d \", x);"
             " x >>= 2; printf(\"%d \", x);"
             " x |= 3;  printf(\"%d \", x);"
             " x &= 12; printf(\"%d \", x);"
             " x ^= 5;  printf(\"%d\\n\", x);"
             " c = 'A'; c += 2; printf(\"%c\\n\", c);"
             " a[0] = 100; a[1] = 200; a[1] += a[0]; printf(\"%d\\n\", a[1]);"
             " p = a; p += 2; *p = 7; *p += 10; printf(\"%d\\n\", a[2]);"
             " u = 0x80000000; u >>= 4; printf(\"%x\\n\", u);"
             " return x; }",
             13,
             "15 12 48 9 4 32 8 11 8 13\nC\n300\n17\n8000000\n",   /* СЕССИЯ 83: %x — минимальные цифры */
             NULL);

    /* 12: unsigned и логический сдвиг */
    run_test("t12 unsigned shift",
             "int main() {"
             " unsigned int u; int s;"
             " u = 0x80000000;"
             " printf(\"u>>4=%x\\n\", u >> 4);"
             " s = -16; printf(\"s>>2=%d\\n\", s >> 2);"
             " u = 1; printf(\"u<<31=%x\\n\", u << 31);"
             " u = 0x80000000; u >>= 31; printf(\"u=%d\\n\", u);"
             " printf(\"cast=%x\\n\", ((unsigned)s) >> 28);"
             " return 0; }",
             0,
             "u>>4=8000000\ns>>2=-4\nu<<31=80000000\nu=1\ncast=f\n",   /* СЕССИЯ 83: %x — минимальные цифры (C89) */
             NULL);

    /* 13: прототипы функций */
    run_test("t13 прототипы",
             "int add(int a, int b);\n"
             "int mul(int a, int b);\n"
             "int main() { printf(\"add=%d mul=%d\\n\", add(40, 2), mul(6, 7)); return add(1, 1); }\n"
             "int add(int a, int b) { return a + b; }\n"
             "int mul(int a, int b) { return a * b; }",
             2, "add=42 mul=42\n", NULL);

    /* 13b: взаимная рекурсия через прототипы */
    run_test("t13b взаимная рекурсия",
             "int odd(int n);\n"
             "int even(int n) { if (n == 0) return 1; return odd(n - 1); }\n"
             "int odd(int n) { if (n == 0) return 0; return even(n - 1); }\n"
             "int main() { printf(\"even10=%d odd7=%d\\n\", even(10), odd(7)); return 0; }",
             0, "even10=1 odd7=1\n", NULL);

    /* 14: switch — базовая диспетчеризация */
    run_test("t14 switch basic",
             "int classify(int x) {\n"
             " switch (x) {\n"
             " case 0: return 100;\n"
             " case 1: return 101;\n"
             " case 2: return 102;\n"
             " case 5: return 105;\n"
             " }\n"
             " return 200;\n"
             "}\n"
             "int main() { printf(\"%d %d %d %d %d\\n\", classify(0), classify(1), classify(2), classify(5), classify(9)); return 0; }",
             0, "100 101 102 105 200\n", NULL);

    /* 15: switch — default в разных позициях, grouped labels, fallthrough */
    run_test("t15 switch default/fallthrough",
             "int main() {\n"
             " int r; int i;\n"
             " r = 0;\n"
             " for (i = -1; i < 4; i = i + 1) {\n"
             "  switch (i) {\n"
             "  case 0: r += 1; break;\n"
             "  case 1: r += 10; break;\n"
             "  case 2: r += 100; break;\n"
             "  default: r += 1000; break;\n"
             "  }\n"
             " }\n"
             " printf(\"A%d\\n\", r);\n"
             " r = 0; switch (3) { default: r += 1; case 10: r += 10; break; case 20: r += 20; break; }\n"
             " printf(\"B%d\\n\", r);\n"
             " r = 0; switch (20) { default: r += 1; case 10: r += 10; break; case 20: r += 20; break; }\n"
             " printf(\"C%d\\n\", r);\n"
             " r = 0; switch (7) { case 1: r += 1; default: r += 2; case 5: r += 5; break; }\n"
             " printf(\"D%d\\n\", r);\n"
             " r = 0; switch (2) { case 1: case 2: case 3: r = 42; break; default: r = 9; }\n"
             " printf(\"E%d\\n\", r);\n"
             " r = 0; switch (1) { case 1: r += 1; case 2: r += 2; case 3: r += 3; }\n"
             " printf(\"F%d\\n\", r);\n"
             " return 0;\n"
             "}",
             0,
             "A2111\nB11\nC20\nD7\nE42\nF6\n",
             NULL);

    /* 16: switch в цикле: break/continue; вложенный switch */
    run_test("t16 switch в цикле/вложенный",
             "int main() {\n"
             " int i; int s; int t;\n"
             " s = 0;\n"
             " for (i = 0; i < 6; i = i + 1) {\n"
             "  switch (i) {\n"
             "  case 0: continue;\n"
             "  case 1: s += 1; break;\n"
             "  case 2:\n"
             "  case 3: s += 10; break;\n"
             "  default:\n"
             "   switch (i) { case 4: s += 100; break; case 5: s += 1000; break; }\n"
             "   break;\n"
             "  }\n"
             "  s += 10000;\n"
             " }\n"
             " printf(\"s=%d\\n\", s);\n"
             " t = 0; switch (-1) { case -1: t = 5; break; default: t = 6; }\n"
             " printf(\"t=%d\\n\", t);\n"
             " return t;\n"
             "}",
             5,
             "s=51121\nt=5\n",
             NULL);

    /* 16b: СЕССИЯ 83 — форматы printf по ревью сессии 74:
     * точный возврат длины, ширина/нули/лево, %x минимальные цифры. */
    run_test("t16b printf форматы",
             "int main() {\n"
             " int n; unsigned u;\n"
             " u = 0xFFFFFFFF;\n"
             " printf(\"[%5d][%-5d][%05d][%d][%-4d|\\n\", 42, 42, 42, 42, 42);\n"
             " printf(\"[%05d][%5d]\\n\", -42, -42);\n"
             " printf(\"[%08x][%x][%u][%-6u|\\n\", 1, 255, u, u);\n"
             " n = printf(\"hi\");\n"
             " printf(\"|%d|\\n\", n);\n"
             " return 0;\n"
             "}",
             0,
             "[   42][42   ][00042][42][42  |\n"
             "[-0042][  -42]\n"
             "[00000001][ff][4294967295][4294967295|\n"   /* %-6u: ширина 6 < 10 цифр — без добивки (C89) */
             "hi|2|\n",
             NULL);

    /* 16c: float/double в native — ширина %f, нули после знака, лево,
     * sqrt по прототипу (конверсия 4.0 -> double), смешанная арифметика */
    run_test("t16c float форматы",
             "#include <math.h>\n"
             "int main() {\n"
             " double d; double e;\n"
             " d = 3.14159;\n"
             " e = 0.0 - d;\n"
             " printf(\"[%10.2f][%-10.2f][%010.2f]\\n\", d, d, e);\n"
             " printf(\"[%f][%.2f][%.0f]\\n\", sqrt(4.0), d * 2.0, d);\n"
             " return 0;\n"
             "}",
             0,
             "[      3.14][3.14      ][-000003.14]\n"
             "[2.000000][6.28][3]\n",
             NULL);

    /* 16d: struct assignment by value (C89 §6.3.2.3) + sizeof подмассивов */
    run_test("t16d struct assign + sizeof",
             "struct Point { int x; int y; };\n"
             "int main() {\n"
             " struct Point p; struct Point q; int m[3][4];\n"
             " q.x = 3; q.y = 4;\n"
             " p = q;\n"
             " printf(\"%d %d %d %d\\n\", p.x, p.y, sizeof(m), sizeof(m[0]));\n"
             " return 0;\n"
             "}",
             0,
             "3 4 48 16\n",
             NULL);

    /* 16e: variadic-функция (va_start/va_arg) — корректный вызов с
     * прототипом; сессия 74 + регресс cdecl-разворота */
    run_test("t16e varargs",
             "#include <stdarg.h>\n"
             "int sum(int n, ...) {\n"
             " va_list ap; int i; int s;\n"
             " va_start(ap, n);\n"
             " s = 0;\n"
             " for (i = 0; i < n; i = i + 1) s += va_arg(ap, int);\n"
             " va_end(ap);\n"
             " return s;\n"
             "}\n"
             "int main() {\n"
             " printf(\"sum=%d\\n\", sum(3, 10, 20, 30));\n"
             " printf(\"w=%d\\n\", sum(2, 100, 5));\n"
             " return 0;\n"
             "}",
             0,
             "sum=60\nw=105\n",
             NULL);

    /* VM-регресс: тот же тест через интерпретатор c4_run */
    vm_test("vm t4 циклы",
             "int main() { int i; int sum; sum = 0;"
             " for (i = 1; i <= 10; i = i + 1) { sum = sum + i; }"
             " printf(\"sum=%d\\n\", sum); return sum; }",
             55, "sum=55\n");
    vm_test("vm sub",
             "int main() { return 10 - 3; }", 7, NULL);
    vm_test("vm escapes",
             "int main() { printf(\"A\\tB\\n\\x43\\n\"); printf(\"[%d]\\n\", '\\t'); return 0; }",
             0, "A\tB\nC\n[9]\n");
    vm_test("vm comma",
             "int main() { int i; int j; int s;"
             " for (i = 0, j = 10; i < j; i = i + 1, j = j - 1) { s = i * 100 + j; }"
             " printf(\"i=%d j=%d s=%d\\n\", i, j, s); return s; }",
             406, "i=5 j=5 s=406\n");
    vm_test("vm compound",
             "int main() { int x; x = 10; x += 5; x *= 3; x >>= 2; x |= 1;"
             " printf(\"x=%d\\n\", x); return x; }",
             11, "x=11\n");
    vm_test("vm unsigned",
             "int main() { unsigned int u; u = 0x80000000;"
             /* СЕССИЯ 83: %x — МИНИМАЛЬНЫЕ цифры (как C89); прежние
              * 8-значные с ведущими нулями — теперь через %08x */
             " printf(\"%08x %x %x\\n\", u >> 4, u >> 4, u >> 31); return 0; }",
             0, "08000000 8000000 1\n");
    vm_test("vm прототипы",
             "int add(int a, int b);\n"
             "int main() { return add(40, 2); }\n"
             "int add(int a, int b) { return a + b; }",
             42, NULL);
    vm_test("vm switch",
             "int main() { int r; r = 0;"
             " switch (3) { case 1: r = 1; break; case 3: r = 3; break; default: r = 9; }"
             " printf(\"r=%d\\n\", r); return r; }",
             3, "r=3\n");
    vm_test("vm switch default-mid",
             "int main() { int r; r = 0;"
             " switch (7) { case 1: r += 1; default: r += 2; case 5: r += 5; break; }"
             " printf(\"r=%d\\n\", r); return r; }",
             7, "r=7\n");

    /* СЕССИЯ 83: VM — те же форматы (единое ядро c4_put_num/c4_fmt_double).
     * Проверяем точный возврат printf (прежде PRTF всегда клал в a 0). */
    vm_test("vm printf форматы",
             "int main() {\n"
             " int n; unsigned u;\n"
             " u = 0xFFFFFFFF;\n"
             " printf(\"[%5d][%-5d][%05d][%d][%-4d|\\n\", 42, 42, 42, 42, 42);\n"
             " printf(\"[%05d][%5d]\\n\", -42, -42);\n"
             " printf(\"[%08x][%x][%u][%-6u|\\n\", 1, 255, u, u);\n"
             " n = printf(\"hi\");\n"
             " printf(\"|%d|\\n\", n);\n"
             " return 0;\n"
             "}",
             0,
             "[   42][42   ][00042][42][42  |\n"
             "[-0042][  -42]\n"
             "[00000001][ff][4294967295][4294967295|\n"   /* %-6u: ширина 6 < 10 цифр — без добивки (C89) */
             "hi|2|\n");

    vm_test("vm float форматы",
            "#include <math.h>\n"
            "int main() {\n"
            " double d; double e;\n"
            " d = 3.14159;\n"
            " e = 0.0 - d;\n"
            " printf(\"[%10.2f][%-10.2f][%010.2f]\\n\", d, d, e);\n"
            " printf(\"[%f][%.2f][%.0f]\\n\", sqrt(4.0), d * 2.0, d);\n"
            " return 0;\n"
            "}",
            0,
            "[      3.14][3.14      ][-000003.14]\n"
            "[2.000000][6.28][3]\n");

    vm_test("vm struct assign + sizeof",
            "struct Point { int x; int y; };\n"
            "int main() {\n"
            " struct Point p; struct Point q; int m[3][4];\n"
            " q.x = 3; q.y = 4;\n"
            " p = q;\n"
            " printf(\"%d %d %d %d\\n\", p.x, p.y, sizeof(m), sizeof(m[0]));\n"
            " return 0;\n"
            "}",
            0,
            "3 4 48 16\n");

    vm_test("vm varargs",
            "#include <stdarg.h>\n"
            "int sum(int n, ...) {\n"
            " va_list ap; int i; int s;\n"
            " va_start(ap, n);\n"
            " s = 0;\n"
            " for (i = 0; i < n; i = i + 1) s += va_arg(ap, int);\n"
            " va_end(ap);\n"
            " return s;\n"
            "}\n"
            "int main() {\n"
            " printf(\"sum=%d\\n\", sum(3, 10, 20, 30));\n"
            " return 0;\n"
            "}",
            0,
            "sum=60\n");

    /* СЕССИЯ 83: диагностика va-вызова без va-прототипа. g объявлена
     * прототипом БЕЗ «...» — вызов в main эмитится без cdecl-разворота
     * (как обычный); определение с «...» переводит callee на va-раскладку
     * (именованные — статические слоты, va_arg — выше их). Раскладки
     * не-va (первый именованный глубоко в bp+3..) и va (первый в bp+2)
     * РАЗЛИЧАЮТСЯ с ≥2 именованных — предупреждаем в момент «...». */
    vm_test("vm va без прототипа — диагностика",
            "#include <stdarg.h>\n"
            "int g(int a, int b);\n"
            "int main() {\n"
            " printf(\"%d\\n\", g(2, 10, 3));\n"
            " return 0;\n"
            "}\n"
            "int g(int a, int b, ...) {\n"
            " va_list ap;\n"
            " va_start(ap, b);\n"
            " return a * 1000 + b * 100 + va_arg(ap, int);\n"
            "}\n",
            0,
            "11: warning: variadic function 'g' called without prototype; "
            "earlier calls were NOT unrolled (C89 requires a prototype)\n"
            "4002\n");

    printf("\n=== %d PASS, %d FAIL ===\n", passes, failures);
    return failures ? 1 : 0;
}

/* Заглушка loader_spawn (c4_x86.c ссылается, но тестбед её не использует) */
struct window;
int loader_spawn(const char *name, struct window *win);
int loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }

