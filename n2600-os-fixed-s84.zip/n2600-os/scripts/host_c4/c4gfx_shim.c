#include "types.h"
void c4_gfx_fill_rect(int x,int y,int w,int h,u32 c){(void)x;(void)y;(void)w;(void)h;(void)c;}
void c4_gfx_text(int x,int y,const char*s,u32 c){(void)x;(void)y;(void)s;(void)c;}
void c4_gfx_flip(int id){(void)id;}
int c4_gfx_event_poll(void*b){(void)b;return 0;}
void c4_gfx_fill_screen(u32 c){(void)c;}
int c4_gfx_width(void){return 800;}
int c4_gfx_height(void){return 600;}
