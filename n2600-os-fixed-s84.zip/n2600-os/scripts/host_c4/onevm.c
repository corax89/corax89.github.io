/* onevm.c — авто-ген: точный источник провалившегося vm-теста. */
#include "string.h"
#include "mem.h"
#include "c4.h"
extern int printf(const char *fmt, ...);
static const char *SRC =
"int main() {\n"
" int n; unsigned u;\n"
" u = 0xFFFFFFFF;\n"
" printf(\"[%5d][%-5d][%05d][%d][%-4d|\\n\", 42, 42, 42, 42, 42);\n"
" printf(\"[%05d][%5d]\\n\", -42, -42);\n"
" printf(\"[%08x][%x][%u][%-6u|\\n\", 1, 255, u, u);\n"
" n = printf(\"hi\");\n"
" printf(\"|%d|\\n\", n);\n"
" return 0;\n"
"}\n";
int main(void) {
    char out[4096];
    int r = c4_run(SRC, out, sizeof(out));
    printf("rc=%d\nOUT=[%s]\n", r, out);
    return 0;
}
