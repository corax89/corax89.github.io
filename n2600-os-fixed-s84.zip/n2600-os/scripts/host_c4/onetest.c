/* onetest.c — одиночный native-тест с источником в теле файла.
 * Копия логики harness run_test (mmap RWX + релокации) — отладка t16c. */
#include "string.h"
#include "mem.h"
#include "c4.h"
#include "kapi.h"
extern int printf(const char *fmt, ...);
extern int fflush(void *);
extern void exit(int) __attribute__((noreturn));
extern int mmap(void *, unsigned long, int, int, int, long);

/* kapi-реализации хоста */
void fb_fill_rect(int x,int y,int w,int h,u32 c){(void)x;(void)y;(void)w;(void)h;(void)c;}
void fb_text(int x,int y,const char*s,u32 fg,int bg){(void)x;(void)y;(void)s;(void)fg;(void)bg;}
u32 fb_rgb(unsigned char r,unsigned char g,unsigned char b){return ((u32)r<<16)|((u32)g<<8)|b;}
void fb_fill_screen(u32 c){(void)c;}
void win_invalidate_stub(int id){(void)id;}
u32 fb_width(void){return 800;}
u32 fb_height(void){return 600;}
static char g_out[65536]; static int g_out_len;
static void h_print_str(const char*s,u32 len){ if(g_out_len+(int)len<(int)sizeof(g_out)){memcpy(g_out+g_out_len,s,len);g_out_len+=(int)len;g_out[g_out_len]=0;} }
static int h_event_poll(void*b){(void)b;return 0;}
void task_msleep(u32 ms){(void)ms;}
void img_fpu_lock(void){ }
void img_fpu_unlock(void){ }
int ramfs_ready(void){return 0;}
int ramfs_delete(const char*n){(void)n;return 0;}
int ramfs_create(const char*n,u32 s){(void)n;(void)s;return 0;}
int ramfs_write(const char*n,const void*b,u32 s){(void)n;(void)b;(void)s;return 0;}
u32 ramfs_read(const char*n,void*b,u32 m){(void)n;(void)b;(void)m;return 0;}
u32 timer_ticks(void){static u32 t;return ++t;}
void task_yield(void){}
int kbd_pop(void*ev){(void)ev;return 0;}
void c4_gfx_fill_rect(int x,int y,int w,int h,u32 c){(void)x;(void)y;(void)w;(void)h;(void)c;}
void c4_gfx_text(int x,int y,const char*s,u32 c){(void)x;(void)y;(void)s;(void)c;}
void c4_gfx_flip(int id){(void)id;}
int c4_gfx_event_poll(void*b){(void)b;return 0;}
void c4_gfx_fill_screen(u32 c){(void)c;}
int c4_gfx_width(void){return 800;}
int c4_gfx_height(void){return 600;}
void serial_puts(const char*s){(void)s;}
struct window;
int loader_spawn(const char*n,struct window*w){(void)n;(void)w;return -1;}

extern u8 c4_x86_data_out[65536];
extern u32 c4_x86_data_out_len;
extern u32 c4_x86_data_relocs_out[8192];
extern int c4_x86_n_data_relocs_out;

/* ============ ТЕСТИРУЕМЫЙ ИСТОЧНИК ============ */
static const char *SRC =
"#include <math.h>\n"
"int main() {\n"
" double d; double e;\n"
" d = 3.14159;\n"
" e = 0.0 - d;\n"
" printf(\"[%10.2f][%-10.2f][%010.2f]\\n\", d, d, e);\n"
" printf(\"[%f][%.2f][%.0f]\\n\", sqrt(4.0), d * 2.0, d);\n"
" return 0;\n"
"}\n";

int main(void) {
    char diag[1024];
    u8 out_buf[262144];
    u32 out_size = 0;
    printf("compile...\n"); fflush(0);
    if (c4_compile_to_native(SRC, diag, sizeof(diag), out_buf, sizeof(out_buf), &out_size)) {
        printf("diag: %s\n", diag);
        return 1;
    }
    printf("compiled %u bytes\n", out_size); fflush(0);
    { extern int write_stub_marker; /* no-op */ }
    { /* дамп кода и данных для дизасма на хосте */
      extern long write(int, const void *, unsigned long);
      write(3, out_buf, out_size);
      extern u8 c4_x86_data_out[65536]; extern u32 c4_x86_data_out_len;
      write(4, c4_x86_data_out, c4_x86_data_out_len);
    }
    u8 *code = (u8 *)mmap(0, (out_size + 4095) & ~4095UL, 7, 0x22, -1, 0);
    if ((long)code < 0 && (long)code > -4096) { printf("mmap fail\n"); return 1; }
    memcpy(code, out_buf, out_size);
    u32 data_len = c4_x86_data_out_len;
    u8 *data = data_len ? malloc(data_len) : 0;
    if (data_len) memcpy(data, c4_x86_data_out, data_len);
    for (int i = 0; i < c4_x86_n_data_relocs_out; i++) {
        u32 off = c4_x86_data_relocs_out[i];
        *(u32 *)(code + off) += (u32)(unsigned long)data;
    }
    kapi_t k;
    memset(&k, 0, sizeof(k));
    k.fb_fill_rect = fb_fill_rect;
    k.fb_text = fb_text;
    k.fb_rgb = fb_rgb;
    k.fb_fill_screen = fb_fill_screen;
    k.win_invalidate = (void (*)(struct window *))win_invalidate_stub;
    k.fb_width = (u32 (*)(void))fb_width;
    k.fb_height = (u32 (*)(void))fb_height;
    k.c4_print_str = h_print_str;
    k.c4_event_poll = h_event_poll;
    k.c4_printf_va = c4_printf_va;
    k.msleep = task_msleep;
    k.fpu_lock = img_fpu_lock;
    k.fpu_unlock = img_fpu_unlock;
    g_out_len = 0; g_out[0] = 0;
    printf("calling entry (code@%p data@%p)...\n", code, data); fflush(0);
    int rc = ((int (*)(kapi_t *, void *))(void *)code)(&k, 0);
    printf("rc=%d\nOUT=[%s]\n", rc, g_out);
    return 0;
}
