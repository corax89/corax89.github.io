#!/bin/sh
# N2600-OS: сборка загрузочного os.iso (Linux, нужны grub-mkimage/xorriso/mtools).
#   Debian/Ubuntu:  apt install grub-pc-bin xorriso mtools
# Скрипт собирает El Torito-образ GRUB вручную — этот рецепт проверен и
# воспроизводим (grub-mkrescue в минимальных окружениях может молчать).
set -e
cd "$(dirname "$0")"

GRUBMOD=""
for d in /home/z/my-project/qemu-pkgs/root-tools/usr/lib/grub/i386-pc /usr/local/lib/grub/i386-pc; do
    [ -d "$d" ] && GRUBMOD="$d" && break
done
[ -n "$GRUBMOD" ] || { echo "Не найдены модули GRUB i386-pc (grub-pc-bin)" >&2; exit 1; }
[ -f kernel.bin ] || { echo "Сначала соберите ядро (build.sh)" >&2; exit 1; }

echo "Модули GRUB: $GRUBMOD"

rm -rf isodir
mkdir -p isodir/boot/grub/i386-pc
cp kernel.bin isodir/boot/kernel.bin
cp grub/grub.cfg isodir/boot/grub/grub.cfg
cp "$GRUBMOD"/*.mod "$GRUBMOD"/*.lst isodir/boot/grub/i386-pc/
# RAM-диск: ядро при загрузке копирует /boot/ramdisk из ISO в RAM disk.
# Без этого шага система стартует с ПУСТЫМ RAM disk (без DEMO.CS и пр.).
mkdir -p isodir/boot/ramdisk
cp ramdisk/* isodir/boot/ramdisk/

# ядро GRUB для CD: cdboot.img + core.img, префикс (cd)/boot/grub
grub-mkimage -O i386-pc -d "$GRUBMOD" -o /tmp/n2600-core.img \
    -p '(cd)/boot/grub' biosdisk iso9660 normal
cat "$GRUBMOD/cdboot.img" /tmp/n2600-core.img > isodir/boot/grub/i386-pc/eltorito.img

xorriso -as mkisofs -o os.iso -R -J -V "N2600-OS" \
    -b boot/grub/i386-pc/eltorito.img -no-emul-boot -boot-load-size 4 -boot-info-table \
    -isohybrid-mbr "$GRUBMOD/boot_hybrid.img" -partition_offset 16 isodir

echo "[OK] Готово: os.iso (CD; можно записать dd на USB — образ гибридный)"
