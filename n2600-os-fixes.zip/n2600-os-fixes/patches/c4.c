/* c4.c — C in four functions (Robert Swierczek, https://github.com/rswier/c4).
 *
 * ПОРТ ДЛЯ N2600-OS (freestanding):
 *   - убран #define int long long (мы 32-битные, int и так вмещает указатель);
 *   - убраны stdio/stdlib/unistd/fcntl, используются наши string.h/mem.h;
 *   - printf() переадресован во внешний буфер (c4_out/c4_out_pos);
 *   - exit() делает __builtin_longjmp обратно в c4_run();
 *   - open/read/close не нужны: исходник передаётся в память;
 *   - точка входа: c4_run(src, out, out_max) вместо main(argc, argv).
 *
 * Поддержано подмножество C: char/int/указатели, if/while/return,
 * выражения, функции; VM-сисколы OPEN/READ/CLOS/PRTF/MALC/FREE/MSET/MCMP/EXIT.
 * Для PRTF поддержаны %d %s %c (по нашему snprintf).
 */

#include "c4.h"
#include "types.h"
#include "string.h"
#include "mem.h"
/* N2600-OS: заголовки для SDL2-подобных сисколов */
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"
#include "ramfs.h"

char *p, *lp, // текущая позиция в исходнике
     *data;   // указатель области data/bss

int *e, *le,  // текущая позиция в эмитируемом коде
    *id,      // разбираемый идентификатор
    *sym,     // таблица символов (простой список идентификаторов)
    tk,       // текущий токен
    ival,     // значение текущего токена
    ty,       // тип текущего выражения
    loc,      // смещение локальной переменной
    line,     // номер строки
    src,      // флаг печати исходника (не используется в нашей сборке)
    debug;    // флаг печати выполняемых инструкций

// токены и классы (операторы — последние, в порядке приоритета)
enum {
  Num = 128, Fun, Sys, Glo, Loc, Id,
  Char, Else, Enum, If, Int, Return, Sizeof, While,
  For, Do, Break, Continue,
  Assign, Cond, Lor, Lan, Or, Xor, And, Eq, Ne, Lt, Gt, Le, Ge, Shl, Shr, Add, Sub, Mul, Div, Mod, Inc, Dec, Brak
};

// опкоды
enum { LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,
       OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,
       OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,
       /* N2600-OS: SDL2-подобные сисколы для c4-программ.
        * Имена: kinit, kquit, kdelay, kfill, ktext, kflip, krgb, kevent,
        *        kclear, kwidth, kheight, kmtime
        * Позволяют писать простые интерактивные программы. */
       KINIT,KQUIT,KDELAY,KFILL,KTEXT,KFLIP,KRGB,KEVENT,KCLEAR,KW,KH,KMTIME,
       /* Строковые операции */
       STRLEN,STRCPY,STRCMP };

// типы
enum { CHAR, INT, PTR };
#define ARR 0x80    /* флаг массива: OR с базовым типом (ARR|INT, ARR|CHAR) */

// смещения в записи идентификатора
enum { Tk, Hash, Name, Class, Type, Val, HClass, HType, HVal, Idsz };

/* ---------- выходной буфер и escape через __builtin_longjmp ---------- */

/* FIX [C1]: пулы для освобождения на ВСЕХ путях выхода. Раньше каждый
 * запуск c4_run (успешный или с ошибкой) протекал 4 x 256К = 1 МиБ:
 * EXIT, longjmp (exit()), все `return -1` парсера и лимит циклов
 * не освобождали пулы. */
static int  *c4_pool_sym   = NULL;
static int  *c4_pool_text  = NULL;
static char *c4_pool_data  = NULL;
static int  *c4_pool_stack = NULL;

static void c4_free_pools(void)
{
    if (c4_pool_sym)   { free(c4_pool_sym);   c4_pool_sym = NULL; }
    if (c4_pool_text)  { free(c4_pool_text);  c4_pool_text = NULL; }
    if (c4_pool_data)  { free(c4_pool_data);  c4_pool_data = NULL; }
    if (c4_pool_stack) { free(c4_pool_stack); c4_pool_stack = NULL; }
}

static char *c4_out = 0;
static u32   c4_out_pos = 0;
static u32   c4_out_max = 0;
static void *c4_jmp[12];
static int   c4_exit_code = 0;

/* Когда не NULL — c4_run сохранит байт-код в RAMFS под этим именем
 * и сразу вернётся (не запуская VM). Формат файла:
 *   char magic[4] = "C4B1"
 *   u32  entry_offset_cells   (смещение main от начала text в int-ячейках)
 *   u32  text_len_cells       (длина text в int-ячейках)
 *   u32  data_len_bytes       (длина data в байтах)
 *   u8   text[text_len_cells * 4]
 *   u8   data[data_len_bytes]
 */
static const char *c4_save_bin_name = NULL;
/* Сохранённое начало data pool (для расчёта data_len при dump в файл) */
static char *data_pool_start = NULL;

/* Compile-only mode: c4_run после парсинга сохраняет байт-код в
 * caller-предоставленные буферы и возвращает без запуска VM. */
static int c4_compile_only = 0;
static u8 *c4_compile_bc_buf = NULL;
static u32  c4_compile_bc_max = 0;
static u32  c4_compile_bc_len_cells = 0;
static u8 *c4_compile_data_buf = NULL;
static u32  c4_compile_data_max = 0;
static u32  c4_compile_data_len = 0;
static u32  c4_compile_entry_cells = 0;
static int *c4_idmain_val_saved = NULL;

static void c4_putc(char c)
{
    if (c4_out_pos + 1 < c4_out_max) c4_out[c4_out_pos++] = c;
}

static void c4_puts(const char *s)
{
    while (*s) c4_putc(*s++);
}

static void c4_putint(int v)
{
    char b[12]; int i = 0;
    int neg = 0;
    unsigned u;
    if (v < 0) { c4_putc('-'); u = (unsigned)(-v); } else u = (unsigned)v;
    if (u == 0) { c4_putc('0'); return; }
    while (u) { b[i++] = (char)('0' + u % 10); u /= 10; }
    while (i--) c4_putc(b[i]);
    (void)neg;
}

static void c4_puthex(unsigned v)
{
    const char *d = "0123456789abcdef";
    for (int i = 28; i >= 0; i -= 4) c4_putc(d[(v >> i) & 0xF]);
}

/* Минимальный printf для исходников c4: %d %s %c %x, без ширины/флагов. */
static int c4_vm_printf(const char *fmt, int a0, int a1, int a2, int a3, int a4, int a5)
{
    int argidx = 0;
    int args[6]; args[0]=a0; args[1]=a1; args[2]=a2; args[3]=a3; args[4]=a4; args[5]=a5;
    while (*fmt) {
        if (*fmt != '%') { c4_putc(*fmt++); continue; }
        fmt++;
        if (*fmt == 'd') { c4_putint(args[argidx++]); fmt++; }
        else if (*fmt == 's') { c4_puts((const char *)(unsigned)args[argidx++]); fmt++; }
        else if (*fmt == 'c') { c4_putc((char)args[argidx++]); fmt++; }
        else if (*fmt == 'x') { c4_puthex((unsigned)args[argidx++]); fmt++; }
        else if (*fmt == '%') { c4_putc('%'); fmt++; }
        else { c4_putc('%'); c4_putc(*fmt++); }
    }
    return 0;
}

/* printf для самого компилятора (диагностика): полностью перекладываем на snprintf. */
static void c4_printf(const char *fmt, ...)
{
    if (c4_out_pos + 1 >= c4_out_max) return;
    int n;
    /* вычисляем через наш snprintf в свой микро-буфер, потом копируем */
    char buf[160];
    /* snprintf из string.h принимает (out, n, fmt, ...) — cdecl, va_list не нужен */
    extern int snprintf(char *out, u32 n, const char *fmt, ...);
    /* Здесь мы не знаем число аргументов заранее — поэтому обрабатываем %d и %s вручную,
       копируя va_list через __builtin_va_arg. Чтобы не усложнять, передаём в snprintf
       только тривиальные случаи. */
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    if (n < 0) return;
    for (int i = 0; i < n && c4_out_pos + 1 < c4_out_max; i++)
        c4_out[c4_out_pos++] = buf[i];
}

#define exit(x) do { c4_exit_code = (x); __builtin_longjmp(c4_jmp, 1); } while (0)
#define printf(...) c4_printf(__VA_ARGS__)

void next()
{
  char *pp;

  while (tk = *p) {
    ++p;
    if (tk == '\n') {
      if (src) {
        printf("%d: %.*s", line, p - lp, lp);
        lp = p;
        while (le < e) {
          printf("%8.4s", &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
                           "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
                           "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[*++le * 5]);
          if (*le <= ADJ) printf(" %d\n", *++le); else printf("\n");
        }
      }
      ++line;
    }
    else if (tk == '#') {
      /* Поддержка #define NAME VALUE — регистрируем NAME как Num в sym table.
       * Остальные #-директивы (#include, #if и т.д.) пропускаем. */
      if (p[0]=='d' && p[1]=='e' && p[2]=='f' && p[3]=='i' && p[4]=='n' && p[5]=='e' && (p[6]==' '||p[6]=='\t')) {
        p += 7;
        while (*p==' ' || *p=='\t') p++;
        /* Хэшируем имя */
        char *dp = p;
        int dh = 0;
        while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p == '_') || (*p >= '0' && *p <= '9'))
          dh = dh * 147 + *p++;
        dh = (dh << 6) + (p - dp);
        int dlen = p - dp;
        while (*p==' ' || *p=='\t') p++;
        /* Парсим значение (число) */
        int dv = 0;
        int dsign = 1;
        if (*p == '-') { dsign = -1; p++; }
        while (*p >= '0' && *p <= '9') { dv = dv * 10 + (*p - '0'); p++; }
        dv *= dsign;
        /* Регистрируем в sym table */
        id = sym;
        while (id[Tk]) {
          if (dh == id[Hash] && !memcmp((char *)id[Name], dp, dlen)) {
            id[Class] = Num; id[Type] = INT; id[Val] = dv; id[Tk] = Num;
            break;
          }
          id = id + Idsz;
        }
        if (!id[Tk]) {
          /* Новая запись */
          id[Name] = (int)(unsigned long)dp;
          id[Hash] = dh;
          id[Class] = Num; id[Type] = INT; id[Val] = dv;
          id[Tk] = Num;
        }
      }
      /* Пропускаем остаток строки */
      while (*p != 0 && *p != '\n') ++p;
    }
    else if ((tk >= 'a' && tk <= 'z') || (tk >= 'A' && tk <= 'Z') || tk == '_') {
      pp = p - 1;
      while ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || *p == '_')
        tk = tk * 147 + *p++;
      tk = (tk << 6) + (p - pp);
      id = sym;
      while (id[Tk]) {
        if (tk == id[Hash] && !memcmp((char *)id[Name], pp, p - pp)) {
          tk = id[Tk];
          if (tk == Num) ival = id[Val];  /* #define'd constant → set ival */
          return;
        }
        id = id + Idsz;
      }
      id[Name] = (int)(unsigned long)pp;
      id[Hash] = tk;
      tk = id[Tk] = Id;
      return;
    }
    else if (tk >= '0' && tk <= '9') {
      if (ival = tk - '0') { while (*p >= '0' && *p <= '9') ival = ival * 10 + *p++ - '0'; }
      else if (*p == 'x' || *p == 'X') {
        while ((tk = *++p) && ((tk >= '0' && tk <= '9') || (tk >= 'a' && tk <= 'f') || (tk >= 'A' && tk <= 'F')))
          ival = ival * 16 + (tk & 15) + (tk >= 'A' ? 9 : 0);
      }
      else { while (*p >= '0' && *p <= '7') ival = ival * 8 + *p++ - '0'; }
      tk = Num;
      return;
    }
    else if (tk == '/') {
      if (*p == '/') {
        ++p;
        while (*p != 0 && *p != '\n') ++p;
      }
      else if (*p == '*') {
        /* Block comment: skip until matching */
        ++p; /* skip '*' */
        while (*p != 0) {
          if (*p == '*' && p[1] == '/') { p += 2; break; }
          ++p;
        }
      }
      else {
        tk = Div;
        return;
      }
    }
    else if (tk == '\'' || tk == '"') {
      pp = data;
      while (*p != 0 && *p != tk) {
        if ((ival = *p++) == '\\') {
          if ((ival = *p++) == 'n') ival = '\n';
        }
        if (tk == '"') *data++ = (char)ival;
      }
      ++p;
      if (tk == '"') ival = (int)(unsigned long)pp; else tk = Num;
      return;
    }
    else if (tk == '=') { if (*p == '=') { ++p; tk = Eq; } else tk = Assign; return; }
    else if (tk == '+') { if (*p == '+') { ++p; tk = Inc; } else tk = Add; return; }
    else if (tk == '-') { if (*p == '-') { ++p; tk = Dec; } else tk = Sub; return; }
    else if (tk == '!') { if (*p == '=') { ++p; tk = Ne; } return; }
    else if (tk == '<') { if (*p == '=') { ++p; tk = Le; } else if (*p == '<') { ++p; tk = Shl; } else tk = Lt; return; }
    else if (tk == '>') { if (*p == '=') { ++p; tk = Ge; } else if (*p == '>') { ++p; tk = Shr; } else tk = Gt; return; }
    else if (tk == '|') { if (*p == '|') { ++p; tk = Lor; } else tk = Or; return; }
    else if (tk == '&') { if (*p == '&') { ++p; tk = Lan; } else tk = And; return; }
    else if (tk == '^') { tk = Xor; return; }
    else if (tk == '%') { tk = Mod; return; }
    else if (tk == '*') { tk = Mul; return; }
    else if (tk == '[') { tk = Brak; return; }
    else if (tk == '?') { tk = Cond; return; }
    else if (tk == '~' || tk == ';' || tk == '{' || tk == '}' || tk == '(' || tk == ')' || tk == ']' || tk == ',' || tk == ':') return;
  }
}

void expr(int lev)
{
  int t, *d;

  if (!tk) { printf("%d: unexpected eof in expression\n", line); exit(-1); }
  else if (tk == Num) { *++e = IMM; *++e = ival; next(); ty = INT; }
  else if (tk == '"') {
    *++e = IMM; *++e = ival; next();
    while (tk == '"') next();
    data = (char *)((int)((unsigned long)data + sizeof(int)) & -sizeof(int)); ty = PTR;
  }
  else if (tk == Sizeof) {
    next(); if (tk == '(') next(); else { printf("%d: open paren expected in sizeof\n", line); exit(-1); }
    ty = INT; if (tk == Int) next(); else if (tk == Char) { next(); ty = CHAR; }
    while (tk == Mul) { next(); ty = ty + PTR; }
    if (tk == ')') next(); else { printf("%d: close paren expected in sizeof\n", line); exit(-1); }
    *++e = IMM; *++e = (ty == CHAR) ? sizeof(char) : sizeof(int);
    ty = INT;
  }
  else if (tk == Id) {
    d = id; next();
    if (tk == '(') {
      next();
      t = 0;
      while (tk != ')') { expr(Assign); *++e = PSH; ++t; if (tk == ',') next(); }
      next();
      if (d[Class] == Sys) *++e = d[Val];
      else if (d[Class] == Fun) { *++e = JSR; *++e = d[Val]; }
      else { printf("%d: bad function call\n", line); exit(-1); }
      if (t) { *++e = ADJ; *++e = t; }
      ty = d[Type];
    }
    else if (d[Class] == Num) { *++e = IMM; *++e = d[Val]; ty = INT; }
    else {
      if (d[Class] == Loc) { *++e = LEA; *++e = loc - d[Val]; }
      else if (d[Class] == Glo) { *++e = IMM; *++e = d[Val]; }
      else { printf("%d: undefined variable\n", line); exit(-1); }
      if (d[Type] & ARR) {
        /* Массив: IMM/LEA уже даёт адрес. Не разыменовываем (нет LI/LC).
         * Преобразуем тип: ARR|INT → PTR+INT, ARR|CHAR → PTR. */
        ty = (d[Type] & ~ARR) + PTR;
      } else {
        *++e = ((ty = d[Type]) == CHAR) ? LC : LI;
      }
    }
  }
  else if (tk == '(') {
    next();
    if (tk == Int || tk == Char) {
      t = (tk == Int) ? INT : CHAR; next();
      while (tk == Mul) { next(); t = t + PTR; }
      if (tk == ')') next(); else { printf("%d: bad cast\n", line); exit(-1); }
      expr(Inc);
      ty = t;
    }
    else {
      expr(Assign);
      if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    }
  }
  else if (tk == Mul) {
    next(); expr(Inc);
    if (ty > INT) ty = ty - PTR; else { printf("%d: bad dereference\n", line); exit(-1); }
    *++e = (ty == CHAR) ? LC : LI;
  }
  else if (tk == And) {
    next(); expr(Inc);
    if (*e == LC || *e == LI) --e; else { printf("%d: bad address-of\n", line); exit(-1); }
    ty = ty + PTR;
  }
  else if (tk == '!') { next(); expr(Inc); *++e = PSH; *++e = IMM; *++e = 0; *++e = EQ; ty = INT; }
  else if (tk == '~') { next(); expr(Inc); *++e = PSH; *++e = IMM; *++e = -1; *++e = XOR; ty = INT; }
  else if (tk == Add) { next(); expr(Inc); ty = INT; }
  else if (tk == Sub) {
    next(); *++e = IMM;
    if (tk == Num) { *++e = -ival; next(); } else { *++e = -1; *++e = PSH; expr(Inc); *++e = MUL; }
    ty = INT;
  }
  else if (tk == Inc || tk == Dec) {
    t = tk; next(); expr(Inc);
    if (*e == LC) { *e = PSH; *++e = LC; }
    else if (*e == LI) { *e = PSH; *++e = LI; }
    else { printf("%d: bad lvalue in pre-increment\n", line); exit(-1); }
    *++e = PSH;
    *++e = IMM; *++e = (ty > PTR) ? sizeof(int) : sizeof(char);
    *++e = (t == Inc) ? ADD : SUB;
    *++e = (ty == CHAR) ? SC : SI;
  }
  else { printf("%d: bad expression\n", line); exit(-1); }

  while (tk >= lev) { // "precedence climbing" or "Top Down Operator Precedence" method
    t = ty;
    if (tk == Assign) {
      next();
      if (*e == LC || *e == LI) *e = PSH; else { printf("%d: bad lvalue in assignment\n", line); exit(-1); }
      expr(Assign); *++e = ((ty = t) == CHAR) ? SC : SI;
    }
    else if (tk == Cond) {
      next();
      *++e = BZ; d = ++e;
      expr(Assign);
      if (tk == ':') next(); else { printf("%d: conditional missing colon\n", line); exit(-1); }
      *d = (int)(e + 3); *++e = JMP; d = ++e;
      expr(Cond);
      *d = (int)(e + 1);
    }
    else if (tk == Lor) { next(); *++e = BNZ; d = ++e; expr(Lan); *d = (int)(e + 1); ty = INT; }
    else if (tk == Lan) { next(); *++e = BZ;  d = ++e; expr(Or);  *d = (int)(e + 1); ty = INT; }
    else if (tk == Or)  { next(); *++e = PSH; expr(Xor); *++e = OR;  ty = INT; }
    else if (tk == Xor) { next(); *++e = PSH; expr(And); *++e = XOR; ty = INT; }
    else if (tk == And) { next(); *++e = PSH; expr(Eq);  *++e = AND; ty = INT; }
    else if (tk == Eq)  { next(); *++e = PSH; expr(Lt);  *++e = EQ;  ty = INT; }
    else if (tk == Ne)  { next(); *++e = PSH; expr(Lt);  *++e = NE;  ty = INT; }
    else if (tk == Lt)  { next(); *++e = PSH; expr(Shl); *++e = LT;  ty = INT; }
    else if (tk == Gt)  { next(); *++e = PSH; expr(Shl); *++e = GT;  ty = INT; }
    else if (tk == Le)  { next(); *++e = PSH; expr(Shl); *++e = LE;  ty = INT; }
    else if (tk == Ge)  { next(); *++e = PSH; expr(Shl); *++e = GE;  ty = INT; }
    else if (tk == Shl) { next(); *++e = PSH; expr(Add); *++e = SHL; ty = INT; }
    else if (tk == Shr) { next(); *++e = PSH; expr(Add); *++e = SHR; ty = INT; }
    else if (tk == Add) {
      next(); *++e = PSH; expr(Mul);
      if ((ty = t) > PTR) { *++e = PSH; *++e = IMM; *++e = sizeof(int); *++e = MUL;  }
      ty = INT;
    }
    else if (tk == Sub) {
      next(); *++e = PSH; expr(Mul);
      if (t == ty && ty > INT) { *++e = SUB; *++e = PSH; *++e = IMM; *++e = sizeof(int); *++e = DIV; ty = INT; }
      else if ((ty = t) > PTR) { *++e = PSH; *++e = IMM; *++e = sizeof(int); *++e = MUL; }
      else ty = INT;
    }
    else if (tk == Mul) { next(); *++e = PSH; expr(Inc); *++e = MUL; ty = INT; }
    /* FIX [C40]: ветки Div/Mod были потеряны при портировании (в оригинале
     * c4.c rswier — строки 259-260). Без них любая программа с '/' или '%'
     * не компилировалась («bad expression»). */
    else if (tk == Div) { next(); *++e = PSH; expr(Inc); *++e = DIV; ty = INT; }
    else if (tk == Mod) { next(); *++e = PSH; expr(Inc); *++e = MOD; ty = INT; }
    else if (tk == Inc) {
      if (*e == LC) { *e = PSH; *++e = LC; }
      else if (*e == LI) { *e = PSH; *++e = LI; }
      else { printf("%d: bad lvalue in post-increment\n", line); exit(-1); }
      *++e = PSH; *++e = IMM; *++e = (ty > PTR) ? sizeof(int) : sizeof(char); *++e = ADD;
      *++e = (ty == CHAR) ? SC : SI;
      next();
    }
    else if (tk == Brak) {
      next(); *++e = PSH; expr(Assign);
      if (tk == ']') next(); else { printf("%d: close bracket expected\n", line); exit(-1); }
      if (t > PTR) { *++e = PSH; *++e = IMM; *++e = sizeof(int); *++e = MUL; *++e = ADD; *++e = (ty = t - PTR) == CHAR ? LC : LI; }
      else if (t == PTR) { *++e = ADD; *++e = (ty = CHAR) ? LC : LI; }
      else { printf("%d: can't index subptr\n", line); exit(-1); }
    }
    else return;
  }
}

/* Break/continue fixup stack: каждый break/continue генерирует JMP с placeholder.
 * После завершения цикла все pending break'и патчатся на адрес выхода,
 * все continue — на адрес следующей итерации. Поддерживает вложенные циклы. */
#define MAX_FIXUPS 64
#define MAX_LOOP_DEPTH 32
static int *break_fixups[MAX_FIXUPS];
static int n_break_fixups;
static int *cont_fixups[MAX_FIXUPS];
static int n_cont_fixups;

static int break_save[MAX_LOOP_DEPTH];
static int cont_save[MAX_LOOP_DEPTH];
static int loop_depth = 0;

static void push_loop(void) {
    if (loop_depth >= MAX_LOOP_DEPTH) return;
    break_save[loop_depth] = n_break_fixups;
    cont_save[loop_depth] = n_cont_fixups;
    loop_depth++;
}
static void patch_continue(int *loop_top) {
    if (loop_depth == 0) return;
    for (int i = cont_save[loop_depth - 1]; i < n_cont_fixups; i++)
        *cont_fixups[i] = (int)loop_top;
    n_cont_fixups = cont_save[loop_depth - 1];
}
static void pop_loop(int *loop_end) {
    if (loop_depth == 0) return;
    loop_depth--;
    for (int i = break_save[loop_depth]; i < n_break_fixups; i++)
        *break_fixups[i] = (int)loop_end;
    n_break_fixups = break_save[loop_depth];
    n_cont_fixups = cont_save[loop_depth];
}

void stmt()
{
  int *a, *b;
  int *c, *d;

  if (tk == If) {
    next();
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BZ; b = ++e;
    stmt();
    if (tk == Else) { next(); *++e = JMP; a = ++e; *b = (int)(e + 1); stmt(); *a = (int)(e + 1); }
    else *b = (int)(e + 1);
  }
  else if (tk == While) {
    next();
    a = e + 1;
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BZ; b = ++e;
    push_loop();
    stmt();
    patch_continue(a);
    *++e = JMP; *++e = (int)a;
    *b = (int)(e + 1);
    pop_loop(e + 1);
  }
  else if (tk == For) {
    next();
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    if (tk != ';') expr(Assign);
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    a = e + 1;
    b = 0;
    if (tk != ';') {
      expr(Assign);
      *++e = BZ; b = ++e;
    }
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    if (tk != ')') {
      *++e = JMP; d = ++e;
      c = e + 1;
      expr(Assign);
      *++e = JMP; *++e = (int)a;
      *d = (int)(e + 1);
    } else { c = 0; d = 0; }
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    push_loop();
    stmt();
    if (c) { *++e = JMP; *++e = (int)c; }
    else { *++e = JMP; *++e = (int)a; }
    if (b) *b = (int)(e + 1);
    if (c) patch_continue(c); else patch_continue(a);
    pop_loop(e + 1);
  }
  else if (tk == Do) {
    next();
    a = e + 1;
    push_loop();
    stmt();
    patch_continue(a);
    if (tk == While) next(); else { printf("%d: while expected\n", line); exit(-1); }
    if (tk == '(') next(); else { printf("%d: open paren expected\n", line); exit(-1); }
    expr(Assign);
    if (tk == ')') next(); else { printf("%d: close paren expected\n", line); exit(-1); }
    *++e = BNZ; *++e = (int)a;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
    pop_loop(e + 1);
  }
  else if (tk == Break) {
    next();
    *++e = JMP;
    break_fixups[n_break_fixups++] = e;  /* запомним адрес для патча */
    *++e = 0;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == Continue) {
    next();
    *++e = JMP;
    cont_fixups[n_cont_fixups++] = e;  /* запомним адрес для патча */
    *++e = 0;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == Return) {
    next();
    if (tk != ';') expr(Assign);
    *++e = LEV;
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
  else if (tk == '{') {
    next();
    while (tk != '}') stmt();
    next();
  }
  else if (tk == ';') {
    next();
  }
  else {
    expr(Assign);
    if (tk == ';') next(); else { printf("%d: semicolon expected\n", line); exit(-1); }
  }
}

int c4_run(const char *src_text, char *out, u32 out_max)
{
  int bt, poolsz, *idmain;
  int *pc, *sp, *bp, a, cycle;
  int i, *t;

  /* Сбрасываем ВСЕ глобальное состояние.
   * Важно: e, le, sym, data, sp могут быть dangling указателями
   * после предыдущего compile_only вызова (который их free()'нул). */
  c4_out = out; c4_out_pos = 0; c4_out_max = out_max;
  if (c4_out && c4_out_max) c4_out[0] = 0;
  c4_exit_code = 0;
  src = 0; debug = 0;
  n_break_fixups = 0;
  n_cont_fixups = 0;
  loop_depth = 0;
  /* Сброс dangling указателей */
  e = le = NULL;
  sym = NULL;
  data = NULL;
  id = NULL;
  tk = 0;
  ival = 0;
  ty = 0;
  loc = 0;
  line = 0;
  loop_depth = 0;

  if (__builtin_setjmp(c4_jmp) != 0) {
    /* сюда попадаем после exit() — возвращаем код.
     * FIX [C1]: освобождаем пулы (раньше — утечка 1 МиБ на каждый exit()). */
    c4_free_pools();
    if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0;
    return c4_exit_code;
  }

  poolsz = 256*1024;
  c4_free_pools();   /* FIX [C1]: страховка от прошлых утечек */
  if (!(c4_pool_sym = sym = malloc(poolsz))) { printf("could not malloc(%d) symbol area\n", poolsz); return -1; }
  if (!(c4_pool_text = le = e = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) text area\n", poolsz); return -1; }
  if (!(c4_pool_data = data = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) data area\n", poolsz); return -1; }
  if (!(c4_pool_stack = sp = malloc(poolsz))) { c4_free_pools(); printf("could not malloc(%d) stack area\n", poolsz); return -1; }
  /* Сохраняем исходное начало data pool — нужно для расчёта data_len
   * при dump байт-кода в файл. */
  data_pool_start = data;

  memset(sym,  0, poolsz);
  memset(e,    0, poolsz);
  memset(data, 0, poolsz);

  p = "char else enum if int return sizeof while "
      "for do break continue "
      "open read close printf malloc free memset memcmp exit "
      "kinit kquit kdelay kfill ktext kflip krgb kevent kclear kw kh kmtime "
      "strlen strcpy strcmp "
      "void main";
  i = Char; while (i <= Continue) { next(); id[Tk] = i++; }
  i = OPEN; while (i <= STRCMP) { next(); id[Class] = Sys; id[Type] = INT; id[Val] = i++; }
  /* void и main — ПОСЛЕ Sys-цикла, чтобы не получить Class=Sys */
  next(); id[Tk] = Char;    /* void → обрабатываем как char */
  next(); idmain = id;       /* main → запоминаем для проверки */

  /* Источник передан в память — не нужен open/read/close */
  lp = p = (char *)(unsigned long)src_text;
  line = 1;
  next();
  while (tk) {
    bt = INT;
    if (tk == Int) next();
    else if (tk == Char) { next(); bt = CHAR; }
    else if (tk == Enum) {
      next();
      if (tk != '{') next();
      if (tk == '{') {
        next();
        i = 0;
        while (tk != '}') {
          if (tk != Id) { printf("%d: bad enum identifier %d\n", line, tk); goto fail; }
          next();
          if (tk == Assign) {
            next();
            if (tk != Num) { printf("%d: bad enum initializer\n", line); goto fail; }
            i = ival;
            next();
          }
          id[Class] = Num; id[Type] = INT; id[Val] = i++;
          if (tk == ',') next();
        }
        next();
      }
    }
    while (tk != ';' && tk != '}') {
      ty = bt;
      while (tk == Mul) { next(); ty = ty + PTR; }
      if (tk != Id) { printf("%d: bad global declaration\n", line); goto fail; }
      if (id[Class]) { printf("%d: duplicate global definition\n", line); goto fail; }
      next();
      id[Type] = ty;
      if (tk == '(') {
        id[Class] = Fun;
        id[Val] = (int)(e + 1);
        next(); i = 0;
        while (tk != ')') {
          ty = INT;
          if (tk == Int) next();
          else if (tk == Char) { next(); ty = CHAR; }
          while (tk == Mul) { next(); ty = ty + PTR; }
          if (tk != Id) { printf("%d: bad parameter declaration\n", line); goto fail; }
          if (id[Class] == Loc) { printf("%d: duplicate parameter definition\n", line); goto fail; }
          id[HClass] = id[Class]; id[Class] = Loc;
          id[HType]  = id[Type];  id[Type] = ty;
          id[HVal]   = id[Val];   id[Val] = i++;
          next();
          if (tk == ',') next();
        }
        next();
        if (tk != '{') { printf("%d: bad function definition\n", line); goto fail; }
        loc = ++i;
        /* FIX [C16]: эмитим ENT (пролог) ПЕРВЫМ, с операндом-заглушкой.
         * Раньше код инициализаторов `int x = expr;` попадал ВЫШЕ ENT и
         * исполнялся с bp ВЫЗЫВАЮЩЕГО: порча кадра вызываемого, локалы
         * оставались мусором, VM сходила с рельсов. Теперь операнд
         * (число слотов) патчится после разбора объявлений. */
        int *fn_ent = e + 1;
        *++e = ENT; *++e = 0;
        next();
        while (tk == Int || tk == Char) {
          bt = (tk == Int) ? INT : CHAR;
          next();
          while (tk != ';') {
            ty = bt;
            while (tk == Mul) { next(); ty = ty + PTR; }
            if (tk != Id) { printf("%d: bad local declaration\n", line); goto fail; }
            if (id[Class] == Loc) { printf("%d: duplicate local definition\n", line); goto fail; }
            id[HClass] = id[Class]; id[Class] = Loc;
            id[HType]  = id[Type];  id[Type] = ty;
            id[HVal]   = id[Val];   id[Val] = ++i;
            /* ВАЖНО: сохраняем указатель на запись массива, т.к. next()
             * ниже (при парсинге [N]) может найти N как #define'Id-константу
             * и переключить глобальный id на запись N. Без этого сохранения
             * флаг ARR записался бы в чужую запись, и массив остался бы без
             * ARR-флага — что вызывает "can't index subptr" при arr[i]. */
            int *arr_id = id;
            next();
            /* Поддержка локальных массивов: int a[10]; */
            if (tk == Brak) {
              next();
              if (tk == Num) {
                i += ival - 1;  /* reserve ival ints on stack */
                next();
              }
              if (tk == ']') next();
              arr_id[Type] = ty | ARR;  /* помечаем как массив */
            }
            if (tk == Assign) {
              /* Local variable initializer: int x = expr;
               * Emits: LEA offset; PSH; <expr>; SI (store int).
               * FIX [C16b]: без PSH адрес из LEA не попадал в стек, и SI
               * писал по мусорному адресу (в случайную память). */
              int offset = loc - i;  /* save before id changes */
              next();
              *++e = LEA; *++e = offset;
              *++e = PSH;
              expr(Assign);
              *++e = SI;
            }
            if (tk == ',') next();
          }
          next();
        }
        fn_ent[1] = i - loc;   /* FIX [C16]: патчим операнд ENT */
        while (tk != '}') stmt();
        *++e = LEV;
        id = sym;
        while (id[Tk]) {
          if (id[Class] == Loc) {
            id[Class] = id[HClass];
            id[Type] = id[HType];
            id[Val] = id[HVal];
          }
          id = id + Idsz;
        }
      }
      else {
        id[Class] = Glo;
        id[Val] = (int)(unsigned long)data;
        /* Сохраняем указатель на запись массива, т.к. next() ниже
         * может переключить id на другую запись (если размер —
         * #define'Id-константа). Без этого флаг ARR запишется не туда. */
        int *glo_id = id;
        /* Поддержка массивов: int a[10]; */
        if (tk == Brak) {
          next();
          if (tk == Num) {
            data = data + sizeof(int) * ival;
            next();
          }
          if (tk == ']') next();
          glo_id[Type] = ty | ARR;  /* помечаем как массив */
        } else {
          data = data + sizeof(int);
        }
      }
      if (tk == ',') next();
    }
    next();
  }

  if (!(pc = (int *)idmain[Val])) { printf("main() not defined\n"); goto fail; }
  if (src) { if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return 0; }


  /* ---------- N2600-OS: compile-only mode (для c4_x86.c) ----------
   * Если выставлен флаг c4_compile_only, мы сохраняем байт-код и сегмент
   * данных в caller-предоставленные буферы и возвращаемся БЕЗ запуска VM.
   * Это позволяет c4_compile() получить IR для дальнейшей обработки. */
  if (c4_compile_only) {
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = ((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int);
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }
    if (c4_compile_bc_buf && c4_compile_bc_max >= text_cells * 4) {
      memcpy(c4_compile_bc_buf, le, text_cells * 4);
      c4_compile_bc_len_cells = text_cells;
    }
    if (c4_compile_data_buf && c4_compile_data_max >= data_len) {
      memcpy(c4_compile_data_buf, data_pool_start, data_len);
      c4_compile_data_len = data_len;
    }
    c4_compile_entry_cells = entry_cells;
    c4_idmain_val_saved = (int *)idmain[Val];
    data_pool_start = NULL;
    c4_free_pools();   /* FIX [C1]: единая точка освобождения */
    return 0;
  }

  /* ---------- N2600-OS: сохранение байт-кода в .bin рядом с .c ---------- */
  if (c4_save_bin_name) {
    /* Точка входа main — абсолютный адрес idmain[Val]. Байт-код начинается
     * с le (pool start). Длина text в int-ячейках: (e - le) + 1.
     * Длина data = текущий data - data_pool_start (исходное начало). */
    u32 text_cells = (u32)((int)(unsigned long)e - (int)(unsigned long)le) / sizeof(int) + 1;
    u32 entry_cells = ((u32)(unsigned long)idmain[Val] - (u32)(unsigned long)le) / sizeof(int);
    u32 data_len = 0;
    if (data_pool_start) {
      data_len = (u32)((unsigned long)data - (unsigned long)data_pool_start);
    }

    u32 total_size = 16 + text_cells * 4 + data_len;
    int saved = 0;
    if (ramfs_ready()) {
      ramfs_delete(c4_save_bin_name);
      if (ramfs_create(c4_save_bin_name, total_size)) {
        u8 *buf = (u8 *)malloc(total_size);
        if (buf) {
          buf[0]='C'; buf[1]='4'; buf[2]='B'; buf[3]='1';
          buf[4] = (u8)(entry_cells & 0xFF);
          buf[5] = (u8)((entry_cells >> 8) & 0xFF);
          buf[6] = (u8)((entry_cells >> 16) & 0xFF);
          buf[7] = (u8)((entry_cells >> 24) & 0xFF);
          buf[8]  = (u8)(text_cells & 0xFF);
          buf[9]  = (u8)((text_cells >> 8) & 0xFF);
          buf[10] = (u8)((text_cells >> 16) & 0xFF);
          buf[11] = (u8)((text_cells >> 24) & 0xFF);
          buf[12] = (u8)(data_len & 0xFF);
          buf[13] = (u8)((data_len >> 8) & 0xFF);
          buf[14] = (u8)((data_len >> 16) & 0xFF);
          buf[15] = (u8)((data_len >> 24) & 0xFF);
          memcpy(buf + 16, le, text_cells * sizeof(int));
          if (data_len > 0 && data_pool_start) {
            memcpy(buf + 16 + text_cells * 4, data_pool_start, data_len);
          }
          ramfs_write(c4_save_bin_name, buf, total_size);
          free(buf);
          saved = 1;
        }
      }
    }
    if (c4_out && c4_out_pos < c4_out_max) {
      if (saved) {
        char msg[96];
        extern int snprintf(char *out, u32 n, const char *fmt, ...);
        snprintf(msg, sizeof(msg),
                 "[c4] compiled OK: %u text cells, %u data bytes, saved as %s",
                 (unsigned)text_cells, (unsigned)data_len, c4_save_bin_name);
        c4_puts(msg);
        c4_putc('\n');
      } else {
        c4_puts("[c4] failed to save binary (RAMFS error)\n");
      }
    }
    c4_save_bin_name = NULL;
    data_pool_start = NULL;
    c4_free_pools();   /* FIX [C1]: единая точка освобождения */
    return 0;
  }

  // setup stack
  bp = sp = (int *)((int)(unsigned long)sp + poolsz);
  *--sp = EXIT;
  *--sp = PSH; t = sp;
  *--sp = 0;
  *--sp = (int)(unsigned long)"";
  *--sp = (int)(unsigned long)t;

  /* run
   * ВАЖНО: после возврата из main() (LEV), pc указывает на СТЕК,
   * где лежат PSH+EXIT (см. setup ниже). Это НЕ байт-код!
   * Поэтому bounds check на pc НЕЛЬЗЯ делать — он даёт ложное срабатывание. */
  cycle = 0;
  while (1) {
    /* Лимит циклов: предотвращаем бесконечный цикл (10 млн) */
    if (cycle > 10000000) {
      printf("cycle limit exceeded (10M)! possible infinite loop\n");
      c4_free_pools();   /* FIX [C1] */
      return -1;
    }
    i = *pc++; ++cycle;
    if (debug) {
      printf("%d> %.4s", cycle,
        &"LEA ,IMM ,JMP ,JSR ,BZ  ,BNZ ,ENT ,ADJ ,LEV ,LI  ,LC  ,SI  ,SC  ,PSH ,"
         "OR  ,XOR ,AND ,EQ  ,NE  ,LT  ,GT  ,LE  ,GE  ,SHL ,SHR ,ADD ,SUB ,MUL ,DIV ,MOD ,"
         "OPEN,READ,CLOS,PRTF,MALC,FREE,MSET,MCMP,EXIT,"[i * 5]);
      if (i <= ADJ) printf(" %d\n", *pc); else printf("\n");
    }
    if      (i == LEA) a = (int)(unsigned long)(bp + *pc++);
    else if (i == IMM) a = *pc++;
    else if (i == JMP) pc = (int *)*pc;
    else if (i == JSR) { *--sp = (int)(unsigned long)(pc + 1); pc = (int *)*pc; }
    else if (i == BZ)  pc = a ? pc + 1 : (int *)*pc;
    else if (i == BNZ) pc = a ? (int *)*pc : pc + 1;
    else if (i == ENT) { *--sp = (int)(unsigned long)bp; bp = sp; sp = sp - *pc++; }
    else if (i == ADJ) sp = sp + *pc++;
    else if (i == LEV) { sp = bp; bp = (int *)*sp++; pc = (int *)*sp++; }
    else if (i == LI)  a = *(int *)a;
    else if (i == LC)  a = *(char *)a;
    else if (i == SI)  *(int *)*sp++ = a;
    else if (i == SC)  a = *(char *)*sp++ = a;
    else if (i == PSH) *--sp = a;

    else if (i == OR)  a = *sp++ |  a;
    else if (i == XOR) a = *sp++ ^  a;
    else if (i == AND) a = *sp++ &  a;
    else if (i == EQ)  a = *sp++ == a;
    else if (i == NE)  a = *sp++ != a;
    else if (i == LT)  a = *sp++ <  a;
    else if (i == GT)  a = *sp++ >  a;
    else if (i == LE)  a = *sp++ <= a;
    else if (i == GE)  a = *sp++ >= a;
    else if (i == SHL) a = *sp++ << a;
    else if (i == SHR) a = *sp++ >> a;
    else if (i == ADD) a = *sp++ +  a;
    else if (i == SUB) a = *sp++ -  a;
    else if (i == MUL) a = *sp++ *  a;
    else if (i == DIV) {
        /* FIX [C35]: деление на ноль в c4-программе вызывало исключение #0
         * CPU -> exc_panic -> ПАНИКА ВСЕЙ СИСТЕМЫ (VM не защищена setjmp).
         * Внимание: делитель — аккумулятор a (правый операнд), делимое в стеке. */
        if (a == 0) { printf("divide by zero\n"); exit(-1); }
        a = *sp++ /  a;
    }
    else if (i == MOD) {
        /* FIX [C35]: аналогично для остатка. */
        if (a == 0) { printf("modulo by zero\n"); exit(-1); }
        a = *sp++ %  a;
    }

    else if (i == OPEN) a = -1; /* не поддерживается */
    else if (i == READ) a = -1;
    else if (i == CLOS) a = 0;
    else if (i == PRTF) { t = sp + pc[1]; a = c4_vm_printf((const char *)(unsigned long)t[-1],
                                t[-2], t[-3], t[-4], t[-5], t[-6], t[-7]); }
    else if (i == MALC) a = (int)(unsigned long)malloc((u32)*sp);
    else if (i == FREE) free((void *)(unsigned long)*sp);
    else if (i == MSET) a = (int)(unsigned long)memset((void *)(unsigned long)sp[2], sp[1], (u32)*sp);
    else if (i == MCMP) a = memcmp((const void *)(unsigned long)sp[2], (const void *)(unsigned long)sp[1], (u32)*sp);
    else if (i == EXIT) { if (c4_out && c4_out_pos < c4_out_max) c4_out[c4_out_pos] = 0; c4_free_pools(); return *sp; } /* FIX [C1] */
    /* ============== N2600-OS: SDL2-подобные сисколы ============== */
    /* Стек c4 после всех PSH: sp[0]=последний аргумент, sp[1]=предыд., ...
     * ADJ потом всё уберет (sp += argcount). */
    else if (i == KINIT)   a = 0;                              /* no-op: контекст уже есть */
    else if (i == KQUIT)   a = 0;                              /* no-op */
    else if (i == KDELAY) {
        /* kdelay(ms): уступить CPU на ms миллисекунд */
        u32 start = timer_ticks();
        u32 need = (u32)*sp / 10u;   /* 1 tick = 10ms (100Hz) */
        while ((timer_ticks() - start) < need) task_yield();
        a = 0;
    }
    else if (i == KFILL) {
        /* kfill(x, y, w, h, color) — заливка прямоугольника */
        fb_fill_rect(sp[4], sp[3], sp[2], sp[1], (u32)sp[0]);
        a = 0;
    }
    else if (i == KTEXT) {
        /* ktext(x, y, s, fg, bg) — вывести строку */
        fb_text(sp[4], sp[3], (const char *)(unsigned long)sp[2],
                (u32)sp[1], (int)sp[0]);
        a = 0;
    }
    else if (i == KFLIP) {
        /* kflip() — перерисовать помеченные области */
        fb_touch_all();
        fb_flush();
        a = 0;
    }
    else if (i == KRGB) {
        /* krgb(r, g, b) — получить цвет; возвращает 32-битное ARGB */
        a = (int)fb_rgb((u8)sp[2], (u8)sp[1], (u8)sp[0]);
    }
    else if (i == KEVENT) {
        /* kevent(out_buf) — получить следующее событие ввода.
         * Возвращает 0=нет события, 1=клавиша, 2=мышь, 3=выход (Esc).
         * Формат буфера для клавиши: buf[0]=ch, buf[1]=code, buf[2]=flags
         * Формат для мыши: buf[0..3]=dx_lo, dx_hi, dy_lo, dy_hi, buf[4]=buttons */
        char *out = (char *)(unsigned long)sp[0];
        if (out) {
            /* Сначала клавиатура */
            key_event_t ev;
            if (kbd_pop(&ev)) {
                out[0] = ev.ch;
                out[1] = (char)ev.code;
                out[2] = (char)ev.flags;
                if (ev.ch == 0x1B || ev.code == 0x01) a = 3;
                else a = 1;
            } else {
                a = 0;
            }
        } else a = 0;
    }
    else if (i == KCLEAR) {
        /* kclear(color) — залить весь экран цветом */
        fb_fill_screen((u32)*sp);
        a = 0;
    }
    else if (i == KW) {
        /* kwidth() — ширина экрана в пикселях */
        a = (int)fb_width();
    }
    else if (i == KH) {
        /* kheight() — высота экрана в пикселях */
        a = (int)fb_height();
    }
    else if (i == KMTIME) {
        /* kmtime() — текущее время в миллисекундах (timer_ticks * 10) */
        a = (int)(timer_ticks() * 10u);
    }
    /* ===== Строковые операции ===== */
    else if (i == STRLEN) {
        /* strlen(s) — длина NUL-terminated строки */
        char *s = (char *)(unsigned long)sp[0];
        int len = 0;
        while (s && s[len]) len++;
        a = len;
    }
    else if (i == STRCPY) {
        /* strcpy(dst, src) — копирование строки */
        char *dst = (char *)(unsigned long)sp[1];
        char *src = (char *)(unsigned long)sp[0];
        if (dst && src) {
            int j = 0;
            while (src[j]) { dst[j] = src[j]; j++; }
            dst[j] = 0;
        }
        a = (int)(unsigned long)dst;
    }
    else if (i == STRCMP) {
        /* strcmp(a, b) — сравнение строк: 0=равны, <0=a<b, >0=a>b */
        char *a_s = (char *)(unsigned long)sp[1];
        char *b_s = (char *)(unsigned long)sp[0];
        a = 0;
        if (a_s && b_s) {
            int j = 0;
            while (a_s[j] && b_s[j] && a_s[j] == b_s[j]) j++;
            a = (int)(unsigned char)a_s[j] - (int)(unsigned char)b_s[j];
        }
    }
    else { printf("unknown instruction = %d! cycle = %d\n", i, cycle); c4_free_pools(); return -1; } /* FIX [C1] */
  }

fail:
  /* FIX [C1]: все ошибки компиляции освобождают пулы (раньше — утечка 1 МиБ).
   * ВАЖНО: метка обязана стоять ПОСЛЕДНЕЙ в c4_run — иначе нормальный путь
   * проваливается в неё. */
  c4_free_pools();
  return -1;
}


/* ---------- N2600-OS: c4_compile — вынести фазу компиляции отдельно ---------- */

/* c4_compile: скомпилировать исходник в байт-код (без запуска VM).
 *   src              — C-исходник (NUL-terminated)
 *   out              — буфер для диагностики ошибок
 *   out_max          — размер out
 *   bytecode         — куда записать пул байт-кода (int-ячейки)
 *   bytecode_max     — ёмкость в байтах
 *   bytecode_len_cells — записанная длина в int-ячейках (вых. параметр)
 *   data_seg         — куда записать сегмент данных
 *   data_seg_max     — ёмкость в байтах
 *   data_seg_len     — записанная длина в байтах (вых. параметр)
 *   entry_offset     — смещение main в int-ячейках от начала bytecode
 * Возвращает: 1 при успехе, 0 при ошибке компиляции. */
int c4_compile(const char *src, char *out, u32 out_max,
               void *bytecode, u32 bytecode_max, u32 *bytecode_len_cells,
               void *data_seg, u32 data_seg_max, u32 *data_seg_len,
               u32 *entry_offset)
{
    /* Настраиваем caller-буферы для c4_run (compile-only mode) */
    c4_compile_only = 1;
    c4_compile_bc_buf = (u8 *)bytecode;
    c4_compile_bc_max = bytecode_max;
    c4_compile_bc_len_cells = 0;
    c4_compile_data_buf = (u8 *)data_seg;
    c4_compile_data_max = data_seg_max;
    c4_compile_data_len = 0;
    c4_compile_entry_cells = 0;

    int r = c4_run(src, out, out_max);

    /* Сбрасываем флаги */
    c4_compile_only = 0;
    c4_compile_bc_buf = NULL;
    c4_compile_bc_max = 0;
    c4_compile_data_buf = NULL;
    c4_compile_data_max = 0;

    if (r != 0) {
        /* ошибка компиляции — c4_run вернул -1, диагностика в out */
        return 0;
    }

    /* Успешная компиляция — возвращаем результаты */
    if (bytecode_len_cells) *bytecode_len_cells = c4_compile_bc_len_cells;
    if (data_seg_len) *data_seg_len = c4_compile_data_len;
    if (entry_offset) *entry_offset = c4_compile_entry_cells;
    return 1;
}

/* c4_print_str: вывод строки в текущий выходной буфер c4 (если есть). */
void c4_print_str(const char *s, u32 len)
{
    if (!s) return;
    for (u32 i = 0; i < len; i++) c4_putc(s[i]);
}

/* c4_event_poll: опрос события ввода для c4-программ (нативных). */
int c4_event_poll(void *out_buf)
{
    if (!out_buf) return 0;
    u8 *out = (u8 *)out_buf;
    key_event_t ev;
    if (kbd_pop(&ev)) {
        out[0] = ev.ch;
        out[1] = (u8)ev.code;
        out[2] = (u8)ev.flags;
        return 1;
    }
    return 0;
}

/* c4_printf_va: formatted print для native c4-программ.
 *   fmt           — форматная строка (с %d/%s/%c/%x)
 *   nargs         — число аргументов ВКЛЮЧАЯ fmt (как в c4 PRTF)
 *   args_reversed — массив аргументов (без fmt) в ОБРАТНОМ порядке
 *                  args_reversed[0] = последний аргумент в source
 *                  args_reversed[actual_args-1] = первый аргумент в source
 * Запись идёт в текущий буфер c4_out. */
void c4_printf_va(const char *fmt, int nargs, int *args_reversed)
{
    if (!fmt) return;
    int actual = nargs - 1;   /* args excluding fmt */
    if (actual < 0) actual = 0;
    int argidx = 0;   /* индекс следующего аргумента в source order */

    while (*fmt) {
        if (*fmt != '%') { c4_putc(*fmt++); continue; }
        fmt++;   /* skip '%' */
        if (*fmt == 'd') {
            if (argidx < actual) {
                /* i-th arg in source = args_reversed[actual-1-argidx] */
                int val = args_reversed[actual - 1 - argidx];
                c4_putint(val);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 's') {
            if (argidx < actual) {
                const char *s = (const char *)(unsigned long)args_reversed[actual - 1 - argidx];
                if (s) c4_puts(s);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 'c') {
            if (argidx < actual) {
                char c = (char)args_reversed[actual - 1 - argidx];
                c4_putc(c);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == 'x') {
            if (argidx < actual) {
                unsigned v = (unsigned)args_reversed[actual - 1 - argidx];
                c4_puthex(v);
                argidx++;
            }
            fmt++;
        }
        else if (*fmt == '%') {
            c4_putc('%');
            fmt++;
        }
        else {
            /* Unknown format spec — output as-is */
            c4_putc('%');
            if (*fmt) { c4_putc(*fmt); fmt++; }
        }
    }
}

