/* task.c — вытесняющая многозадачность N2600-OS.
 *
 * Архитектура переключения контекста:
 *   1. PIT генерирует IRQ0 каждые 10 мс (100 Гц).
 *   2. CPU входит в irq_stub_0 (naked-функция), который:
 *        pusha                  — сохраняет 8 general regs в стеке текущей задачи;
 *        cld; pushl %esp; call _task_schedule
 *                               — передаёт C-функции указатель на pusha-кадр;
 *        movl %eax, %esp        — переключает стек на сохранённый кадр новой задачи;
 *        popa; iret             — восстанавливает regs и EIP/CS/EFLAGS новой задачи.
 *
 *   3. task_schedule():
 *        - инкрементирует системные тики (ticks);
 *        - шлёт EOI master PIC;
 *        - сохраняет tasks[cur].esp = saved_esp;
 *        - инкрементирует uptime задачи, которая только что работала;
 *        - round-robin выбирает следующую активную задачу;
 *        - возвращает tasks[next].esp.
 *
 * Для новой задачи fabricate-стек: на вершине выделенного стека
 * кладётся фейковый кадр iret (EIP=task_trampoline, CS=0x08, EFLAGS=IF=1)
 * и под ним — pusha-кадр из нулей. Первое переключение на новую задачу
 * popa-нет нули и iret-ом прыгает в task_trampoline, который зовёт fn(arg).
 *
 * Главная задача (kmain) — task[0]; её стек не fabricate-ится, так как
 * она уже работает на системном стеке _stack_top.
 *
 * Лимит задач: 256 (увеличен с 8). Каждый слот задаёт имя, статус,
 * стек (16 КиБ), uptime (число тиков, в которых задача исполнялась).
 */
#include "task.h"
#include "io.h"
#include "mem.h"
#include "string.h"
#include "idt.h"

#define TASK_STACK_SIZE (16 * 1024)

typedef struct {
    int  used;
    int  finished;
    u32 *esp;
    u8  *stack;
    u32  stack_size;
    char name[16];
    void (*fn)(void *);
    void *arg;
    u32  uptime;
    u32  last_active_tick;  /* последний тик, когда задача работала */
    u32  watchdog_timeout;  /* 0 = нет ватчдога, иначе макс тиков без активности */
    u32  last_uptime;       /* предыдущее значение uptime (для детекции зависания) */
} task_t;

static task_t tasks[MAX_TASKS];
static int   cur_task = 0;
static int   n_tasks  = 0;
static u32   last_sched_tick = 0;   /* тик, когда последний раз вызывался scheduler */

/* Системные тики — теперь инкрементируются из task_schedule (раньше timer_irq). */
static volatile u32 ticks = 0;

u32 timer_ticks(void) { return ticks; }
u32 uptime_sec(void)  { return ticks / 100; }

extern void task_trampoline(void);

/* ---------- IRQ0 stub: переключение контекста ---------- */

__attribute__((naked, used)) void irq_stub_0(void)
{
    __asm__ __volatile__(
        "pusha\n\t"                  /* сохранить EAX,ECX,EDX,EBX,ESP_orig,EBP,ESI,EDI */
        "cld\n\t"
        "pushl %esp\n\t"             /* arg: указатель на pusha-кадр */
        "call _task_schedule\n\t"   /* планировщик: вернуть новый ESP в %eax */
        "movl %eax, %esp\n\t"        /* переключение стека */
        "popa\n\t"                   /* восстановить regs новой задачи */
        "iret\n\t"                   /* EIP/CS/EFLAGS новой задачи */
    );
}

/* ---------- планировщик ---------- */

/* FIX [T3]: вызывается из task_schedule (IRQ0-контекст) — см. ниже */
int task_watchdog_irq(u32 timeout_ticks);

u32 *task_schedule(u32 *saved_esp)
{
    u32 now = ticks + 1;
    ticks = now;
    outb(0x20, 0x20);                /* EOI master PIC (IRQ0 — на master) */

    if (n_tasks == 0) return saved_esp;   /* задач нет — остаёмся */

    /* Сохранить контекст текущей задачи */
    tasks[cur_task].esp = saved_esp;

    /* Инкремент uptime и обновление last_active_tick */
    u32 delta = now - last_sched_tick;
    tasks[cur_task].uptime += delta;
    tasks[cur_task].last_active_tick = now;
    last_sched_tick = now;

    /* FIX [T3]: ВАТЧДОГ В КОНТЕКСТЕ ПРЕРЫВАНИЯ. Раньше task_watchdog()
     * вызывался только из главного цикла kmain — если kmain зависал
     * (все приложения выполняются в task[0]!), ватчдог вообще не
     * запускался и зависала ВСЯ система. Здесь мы в IRQ0: прерывания
     * уже запрещены (interrupt gate), поэтому доступ к таблице задач
     * и куче атомарен по определению. Проверяем каждые 50 тиков (0.5 с). */
    if ((now & 31u) == 0) {          /* ~ каждые 32 тика (320 мс) */
        task_watchdog_irq(TASK_WATCHDOG_TICKS);
    }

    /* Поиск следующей активной задачи (round-robin, пропуская завершённые) */
    int next = cur_task;
    int found = 0;
    for (int tries = 0; tries < MAX_TASKS; tries++) {
        next = (next + 1) % MAX_TASKS;
        if (tasks[next].used && !tasks[next].finished) {
            found = 1;
            break;
        }
    }
    if (!found) {
        /* Все задачи завершены — продолжаем текущую (должна быть task[0]) */
        next = 0;
    }
    cur_task = next;
    return tasks[cur_task].esp;
}

/* ---------- API ---------- */

void task_init(void)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].used = 0;
        tasks[i].finished = 0;
        tasks[i].esp = NULL;
        tasks[i].stack = NULL;
        tasks[i].stack_size = 0;
        tasks[i].name[0] = 0;
        tasks[i].fn = NULL;
        tasks[i].arg = NULL;
        tasks[i].uptime = 0;
    }
    /* task[0] — главная задача (контекст kmain), стек — системный */
    tasks[0].used = 1;
    tasks[0].finished = 0;
    tasks[0].stack = NULL;
    tasks[0].esp = NULL;
    tasks[0].fn = NULL;
    tasks[0].arg = NULL;
    tasks[0].uptime = 0;
    strncpy(tasks[0].name, "main", sizeof(tasks[0].name) - 1);
    tasks[0].name[sizeof(tasks[0].name) - 1] = 0;

    cur_task = 0;
    n_tasks = 1;
    last_sched_tick = 0;
}

int task_spawn(const char *name, void (*fn)(void *), void *arg)
{
    cli();

    /* Ищем свободный слот (1..MAX_TASKS-1; 0 — главная задача) */
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        sti();
        return -1;
    }

    /* Освобождаем стек, если слот уже использовался (завершённая задача) */
    if (tasks[slot].stack) {
        free(tasks[slot].stack);
        tasks[slot].stack = NULL;
    }

    u8 *stack = (u8 *)malloc(TASK_STACK_SIZE);
    if (!stack) {
        sti();
        return -1;
    }

    /* Строим кадр: iret (EFLAGS, CS, EIP) + pusha (8 regs).
     * Стек растёт вниз, поэтому кладём с вершины. */
    u32 *sp = (u32 *)(stack + TASK_STACK_SIZE);
    sp -= 1; *sp = 0x00000202;                       /* EFLAGS: reserved bit + IF=1 */
    sp -= 1; *sp = 0x08;                             /* CS */
    sp -= 1; *sp = (u32)(unsigned long)task_trampoline;  /* EIP */
    /* pusha order: EAX, ECX, EDX, EBX, ESP_orig, EBP, ESI, EDI */
    sp -= 1; *sp = 0;                                /* EAX */
    sp -= 1; *sp = 0;                                /* ECX */
    sp -= 1; *sp = 0;                                /* EDX */
    sp -= 1; *sp = 0;                                /* EBX */
    sp -= 1; *sp = (u32)(unsigned long)sp;            /* ESP_orig (игнорируется popa) */
    sp -= 1; *sp = 0;                                /* EBP */
    sp -= 1; *sp = 0;                                /* ESI */
    sp -= 1; *sp = 0;                                /* EDI — после fabricate ESP указывает сюда */

    tasks[slot].used = 1;
    tasks[slot].finished = 0;
    tasks[slot].esp = sp;
    tasks[slot].stack = stack;
    tasks[slot].stack_size = TASK_STACK_SIZE;
    tasks[slot].fn = fn;
    tasks[slot].arg = arg;
    tasks[slot].uptime = 0;
    tasks[slot].last_active_tick = ticks;
    tasks[slot].watchdog_timeout = 0;
    tasks[slot].last_uptime = 0;
    strncpy(tasks[slot].name, name ? name : "?", sizeof(tasks[slot].name) - 1);
    tasks[slot].name[sizeof(tasks[slot].name) - 1] = 0;
    n_tasks++;

    sti();
    return slot;
}

void task_yield(void)
{
    /* Простая уступка: ждём следующего IRQ0. */
    __asm__ __volatile__("hlt");
}

void task_exit(void)
{
    cli();
    if (tasks[cur_task].used) {
        tasks[cur_task].finished = 1;
        if (n_tasks > 0) n_tasks--;
    }
    sti();
    /* Больше не вернёмся — ждём переключения на другую задачу. */
    for (;;) __asm__ __volatile__("hlt");
}

/* Завершить задачу по индексу. Если задача уже не используется или это
 * текущая задача — для текущей работает как task_exit().
 * Параметр idx может быть любым (проверяется валидность слота).
 * Возвращает 1 при успехе, 0 если слот не используется или задача уже завершена.
 * Стек задачи будет освобождён при следующем task_spawn() в этот слот. */
int task_kill(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (idx == 0) return 0;             /* главную задачу (kmain) убивать нельзя */
    if (!tasks[idx].used) return 0;
    if (tasks[idx].finished) return 0;

    cli();
    tasks[idx].finished = 1;
    if (n_tasks > 0) n_tasks--;
    /* Если убили текущую — уступить CPU */
    if (idx == cur_task) {
        sti();
        for (;;) __asm__ __volatile__("hlt");
    }
    sti();
    return 1;
}

int task_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].used && !tasks[i].finished) n++;
    return n;
}

int task_current(void) { return cur_task; }

const char *task_name(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return "";
    if (!tasks[idx].used) return "";
    return tasks[idx].name;
}

int task_used(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].used;
}

int task_finished(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 1;
    return tasks[idx].finished;
}

u32 task_uptime(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    if (!tasks[idx].used) return 0;
    return tasks[idx].uptime;
}

/* ---------- trampoline для новых задач ---------- */

void task_trampoline(void)
{
    int me = cur_task;
    if (tasks[me].fn) tasks[me].fn(tasks[me].arg);
    task_exit();
    for (;;) __asm__ __volatile__("hlt");
}

/* ---------- Ватчдог ---------- */

/* Таймаут по умолчанию для IRQ-ватчдога: 5 секунд (500 тиков). */
#define TASK_WATCHDOG_TICKS 500

void task_set_watchdog(int idx, u32 timeout_ticks)
{
    if (idx < 0 || idx >= MAX_TASKS) return;
    if (!tasks[idx].used) return;
    tasks[idx].watchdog_timeout = timeout_ticks;
    tasks[idx].last_uptime = tasks[idx].uptime;
}

u32 task_get_watchdog(int idx)
{
    if (idx < 0 || idx >= MAX_TASKS) return 0;
    return tasks[idx].watchdog_timeout;
}

/* FIX [T3b]: версия для вызова ИЗ ПРЕРЫВАНИЯ (уже с IF=0 — без cli/sti).
 * Критерий: задача не получала CPU дольше limit тиков. Заметим честно:
 * задача, зависшая в плотном цикле while(1){} БЕЗ hlt, всё равно
 * получает CPU по round-robin и этим критерием не ловится — для этого
 * нужны счётчики команд/привилегии (нет в x86 без MMU/PIT-профилирования).
 * Но главный сценарий пользователя (зависает kmain с приложениями,
 * либо задача навсегда теряет CPU) теперь отрабатывается: если task[0]
 * (kmain с браузером/терминалом) не планировался дольше таймаута —
 * зависшие вложенные задачи убиваются, система продолжает жить.
 * Стек НЕ освобождаем немедленно (esp задачи может указывать в него,
 * а free() из IRQ-контекста опасен) — отложено до task_spawn в этот слот. */
int task_watchdog_irq(u32 timeout_ticks)
{
    int killed = 0;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (!tasks[i].used || tasks[i].finished) continue;

        u32 idle = ticks - tasks[i].last_active_tick;
        u32 limit = tasks[i].watchdog_timeout ? tasks[i].watchdog_timeout
                                              : timeout_ticks;
        if (limit == 0) continue;

        if (idle > limit) {
            tasks[i].finished = 1;
            if (n_tasks > 0) n_tasks--;
            killed++;
            /* Стек НЕ трогаем: tasks[i].stack освобождается в task_spawn() */
        }
    }
    return killed;
}

/* Публичная версия — с защитой cli/sti (FIX [T3c]: раньше меняла
 * таблицу задач и звала free() без запрета прерываний — гонка с IRQ0
 * и порча кучи). */
int task_watchdog(u32 timeout_ticks)
{
    int if_had;
    __asm__ __volatile__("pushfl\n\tpopl %0\n\tcli" : "=r"(if_had) :: "memory");
    int killed = task_watchdog_irq(timeout_ticks);
    if (if_had & 0x200) __asm__ __volatile__("sti" ::: "memory");
    return killed;
}
