/* task.h — вытесняющая многозадачность N2600-OS.
 *
 * Реализация: round-robin планировщик на IRQ0 (PIT 100 Гц).
 * Контекст задач сохраняется в обработчике irq_stub_0 (см. task.c):
 *   pusha -> call task_schedule(saved_esp) -> movl ret, %esp -> popa -> iret
 *
 * Каждая задача имеет собственный стек (TASK_STACK_SIZE) из кучи ядра.
 * Главная задача (kmain) — это task[0], её стек не выделяется отдельно
 * (используется системный стек _stack_top из linker-скрипта).
 *
 * Лимит задач: 256 (был 8 — увеличен по запросу для диспетчера задач).
 *
 * API:
 *   task_init()                 — инициализация до sti(); создаёт task[0]
 *   task_spawn(name, fn, arg)   — породить новую задачу, fn(arg) запустится
 *                                  при первом переключении; возвращает индекс >=1
 *                                  или -1 при ошибке
 *   task_yield()                — уступить процессор (hlt до следующего IRQ0)
 *   task_exit()                 — завершить текущую задачу (не возвращает)
 *   task_count()                — число активных (не завершённых) задач
 *   task_current()              — индекс текущей задачи
 *   task_name(i)                — имя задачи (или "")
 *   task_used(i)                — занят ли слот
 *   task_finished(i)            — завершена ли задача
 *   task_uptime(i)              — сколько тиков задача суммарно исполнялась
 */
#ifndef TASK_H
#define TASK_H

#include "types.h"

#define MAX_TASKS 256

void task_init(void);
int  task_spawn(const char *name, void (*fn)(void *), void *arg);
void task_yield(void);
void task_exit(void);
int  task_kill(int idx);          /* завершить задачу по индексу; 1=успех */

int  task_count(void);
int  task_current(void);
const char *task_name(int idx);
int  task_used(int idx);
int  task_finished(int idx);
u32  task_uptime(int idx);

/* Ватчдог: проверяет все задачи на зависание.
 * Задача считается зависшей, если uptime не меняется > timeout_ticks.
 * kill зависших задач. Возвращает число убитых. */
int  task_watchdog(u32 timeout_ticks);

/* FIX [T3]: версия для вызова из IRQ0-контекста (прерывания уже
 * запрещены). Вызывается планировщиком каждые ~320 мс — ватчдог
 * работает ДАЖЕ если главный цикл kmain завис. */
int  task_watchdog_irq(u32 timeout_ticks);

/* Установить/получить таймаут ватчдога для конкретной задачи. */
void task_set_watchdog(int idx, u32 timeout_ticks);
u32  task_get_watchdog(int idx);

/* Внутренняя функция — вызывается из irq_stub_0 (не использовать напрямую). */
u32 *task_schedule(u32 *saved_esp);

#endif /* TASK_H */
