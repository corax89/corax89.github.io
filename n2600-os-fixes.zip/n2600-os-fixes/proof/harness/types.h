/* types.h — stub для host-теста c4 */
#ifndef TYPES_H
#define TYPES_H

typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned           u32;
typedef signed char        i8;
typedef int                i32;
typedef unsigned long long u64;
typedef long long          i64;

#endif
