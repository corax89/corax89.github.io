/* mouse.h — stub для host-теста c4 */
#ifndef MOUSE_H
#define MOUSE_H

#include "types.h"

#endif
