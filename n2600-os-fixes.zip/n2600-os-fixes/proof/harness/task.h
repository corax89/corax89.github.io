/* task.h — stub для host-теста c4 */
#ifndef TASK_H
#define TASK_H

#include "types.h"

void task_yield(void);

#endif
