/* harness_vm.c — исполняемое доказательство багов VM c4 (порт N2600-OS).
 *
 * Сборка (64-битный хост, трюк оригинального c4):
 *   gcc -O0 -w -o harness_vm  harness_vm.c            # текущий порт (с багами)
 *   gcc -O0 -w -DUSE_FIX -o harness_fix harness_vm.c  # порт + патч Div/Mod
 *
 * Тесты (текущий порт):
 *   T2 (контроль): int x; x = 5;           → x=5 (но утечка 1 МиБ)
 *   T1 (баг C16):  int x = 5;              → x=0 + VM сходит с рельсов
 *   T1b (баг C16): инициализатор в callee  → калечит кадр вызывающего
 *   T3 (баг):      #define MAX (5)         → молча 0
 *   T4 (баг C1):   ошибка компиляции       → утечка 1 МиБ
 *   T5 (баг C40):  a / b                   → «bad expression»: деление
 *                   потеряно при портировании (в оригинале c4 есть)
 * Тесты (с патчем Div/Mod):
 *   F1: a/b при b=2 → r=5 (патч работает)
 *   F2: a/b при b=0 → SIGFPE=8 (в ОС = паника ядра; нужен guard)
 */
#define _GNU_SOURCE
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <sys/wait.h>
#include <stddef.h>

#define int long
#include "types.h"
#include "string.h"
#include "mem.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"
#include "ramfs.h"

/* ---- подсчёт аллокаций (bump-аллокатор, без libc malloc) ---- */
static long g_alloc_bytes = 0;
static long g_alloc_calls = 0;
static long g_free_calls  = 0;

static unsigned char mempool[64u * 1024u * 1024u];
static unsigned long mempool_pos = 0;

void *malloc(u32 n)
{
    g_alloc_calls++;
    g_alloc_bytes += (long)n;
    unsigned long sz = ((unsigned long)n + 15u) & ~15u;
    if (mempool_pos + sz > sizeof(mempool)) return 0;
    void *r = mempool + mempool_pos;
    mempool_pos += sz;
    return r;
}
void free(void *p)
{
    if (!p) return;
    g_free_calls++;
}

/* ---- заглушки ОС (N2600-OS API, который дёргает c4.c) ---- */
u32  fb_rgb(u8 r, u8 g, u8 b) { (void)r;(void)g;(void)b; return 0; }
u32  fb_width(void)  { return 1280; }
u32  fb_height(void) { return 600; }
void fb_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_fill_screen(u32 c) { (void)c; }
void fb_text(int x, int y, const char *s, u32 f, int bg) { (void)x;(void)y;(void)s;(void)f;(void)bg; }
void fb_touch_all(void) {}
void fb_flush(void) {}
int  fb_ready(void) { return 0; }
int  kbd_pop(key_event_t *out) { (void)out; return 0; }
void task_yield(void) {}
u32  timer_ticks(void) { static u32 t = 0; t += 100000; return t; }
u32  uptime_sec(void) { return 0; }
int  ramfs_ready(void) { return 0; }
int  ramfs_delete(const char *n) { (void)n; return 0; }
int  ramfs_create(const char *n, u32 s) { (void)n;(void)s; return 0; }
int  ramfs_write(const char *n, const void *b, u32 l) { (void)n;(void)b;(void)l; return 0; }
u32  ramfs_total_space(void) { return 0; }

/* ---- тестируемый компилятор ---- */
#ifdef USE_FIX
#include "c4_fix.c"
#else
#include "c4.c"
#endif

#undef int
#undef printf
#undef exit

/* ---- вывод на хост (без stdio.h во избежание конфликтов прототипов) ---- */
static void host_print(const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    char buf[4096];
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    if (n > 0) (void)!write(1, buf, (unsigned)n);
}

/* ---- обработчик сигналов: печатает номер сигнала ---- */
static void sig_handler(int sig, siginfo_t *si, void *uc_)
{
    (void)uc_;
    char b[64]; char *o = b; const char *hex = "0123456789abcdef";
    unsigned long v = (unsigned long)si->si_addr;
    *o++='S';*o++='I';*o++='G';*o++='=';*o++=(char)(sig+'0');*o++=' ';
    *o++='a';*o++='d';*o++='d';*o++='r';*o++='=';
    for (int k=60;k>=0;k-=4) *o++ = hex[(v>>k)&0xF];
    *o++='\n';
    long ret;
    __asm__ volatile("syscall" : "=a"(ret) : "a"(1), "D"(1), "S"(b), "d"((long)(o-b)) : "rcx","r11","memory");
    (void)ret;
    _exit(88);
}

static void run_c4(const char *name, const char *src, char *out, unsigned out_max)
{
    host_print("=== %s ===\n", name);
    host_print("--- исходник ---\n%s\n", src);
    long ab0 = g_alloc_bytes, ac0 = g_alloc_calls, fc0 = g_free_calls;
    long r = c4_run(src, out, out_max);
    host_print("--- вывод VM ---\n%s\n", out);
    host_print("--- код возврата: %ld\n", r);
    host_print("--- malloc вызовов: %ld, байт: %ld; free вызовов: %ld\n",
               g_alloc_calls - ac0, g_alloc_bytes - ab0, g_free_calls - fc0);
    host_print(">>> УТЕЧКА за этот запуск: %ld байт\n\n\n",
               g_alloc_bytes - ab0);
}

static void run_div_test(const char *label, const char *prog)
{
    host_print("--- %s ---\n", label);

    pid_t pid = fork();
    if (pid == 0) {
        char o2[256];
        o2[0] = 0;
        long r = c4_run(prog, o2, sizeof(o2));
        host_print("    дочерний: c4_run=%ld, вывод: %s\n", r, o2);
        _exit(0);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    if (WIFSIGNALED(st))
        host_print("    => процесс убит сигналом %d\n", WTERMSIG(st));
    else if (WEXITSTATUS(st) == 88)
        host_print("    => перехвачен сигнал (SIGFPE=8/SIGSEGV=11) — VM упала\n");
}


static const char *opnames[] = {
    "LEA","IMM","JMP","JSR","BZ","BNZ","ENT","ADJ","LEV","LI","LC","SI","SC","PSH",
    "OR","XOR","AND","EQ","NE","LT","GT","LE","GE","SHL","SHR","ADD","SUB","MUL","DIV","MOD",
    "OPEN","READ","CLOS","PRTF","MALC","FREE","MSET","MCMP","EXIT",
    "KINIT","KQUIT","KDELAY","KFILL","KTEXT","KFLIP","KRGB","KEVENT",
    "KCLEAR","KW","KH","KMTIME","STRLEN","STRCPY","STRCMP"
};

static int noperands(int op)
{
    switch (op) {
    case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 9: case 10:
        return 1;
    default:
        return 0;
    }
}

static void dump_bytecode(const char *title, const char *src)
{
    static int bc[65536];
    static u8  data[65536];
    u32 bc_len = 0, data_len = 0, entry = 0;
    char diag[512]; diag[0] = 0;

    host_print("=== %s ===\n", title);
    int ok = c4_compile(src, diag, sizeof(diag),
                        bc, sizeof(bc), &bc_len,
                        data, sizeof(data), &data_len,
                        &entry);
    if (!ok) { host_print("компиляция не удалась: %s\n\n", diag); return; }
    host_print("байткод: %u ячеек, вход main = ячейка %u\n", (unsigned)bc_len, (unsigned)entry);
    host_print("первые инструкции main (сырые long-ячейки):\n");
    /* сырой дамп ячеек: значения малы, читаем напрямую */
    for (u32 i = 1; i < 14 && i < bc_len + 2; i++) {
        host_print("  [%2u] %d\n", i, bc[i]);
    }
    host_print("расшифровка: 0=LEA 1=IMM 6=ENT 11=SI → ENT появляется ТОЛЬКО\n");
    host_print("после LEA/IMM/SI инициализатора (в ячейке 12), а не первым.\n");
    (void)entry; (void)noperands;
}

static void dump_native(const char *title, const char *src)
{
    static u8 out[256 * 1024];
    u32 out_size = 0;
    char diag[512]; diag[0] = 0;

    host_print("=== %s ===\n", title);
    host_print("(хост-дамп: значения операндов могут искажаться из-за усечённой\n");
    host_print(" копии байткода на 64-битном хосте; ВАЖЕН выбор инструкций)\n");
    int r = c4_compile_to_native(src, diag, sizeof(diag), out, sizeof(out), &out_size);
    if (r != 0) { host_print("ошибка: %s\n\n", diag); return; }
    host_print("нативный код: %u байт\n", (unsigned)out_size);
    for (u32 i = 0; i < out_size && i < 96; i++) {
        host_print("%02x ", out[i]);
        if ((i & 15) == 15) host_print("\n");
    }
    host_print("\n\n");
}
int main(void)
{
    static stack_t ss;
    static char sigstack_mem[64 * 1024];
    ss.ss_sp = sigstack_mem; ss.ss_size = sizeof(sigstack_mem); ss.ss_flags = 0;
    sigaltstack(&ss, 0);
    struct sigaction sa; sa.sa_sigaction = sig_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK; sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, 0); sigaction(SIGFPE, &sa, 0);

    host_print("############ D1: байткод «int x = 5;» — порядок инициализатора ############\n");
    host_print("(хост-дамп: из-за int-long трюка копия байткода усечена вдвое;\n");
    host_print(" декодируем первые ячейки вручную — важен ПОРЯДОК инструкций)\n");
    dump_bytecode("main: int x = 5; printf(x)",
                  "int main() { int x = 5; printf(\"x=%d\\n\", x); return 0; }");
    host_print("ОЖИДАЛОСЬ: ENT (пролог) первым, затем LEA/IMM/SI.\n");
    host_print("ФАКТ:      LEA/IMM/SI идут ДО ENT → исполняются с bp ВЫЗЫВАЮЩЕГО.\n\n");

    host_print("############ D2: нативный код «return 7;» ############\n");
    dump_native("main: return 7", "int main() { return 7; }");
    host_print("ОЖИДАЛОСЬ: B8 xx xx xx xx (mov eax,imm) перед C9 C3 (leave;ret).\n");
    host_print("ФАКТ:      68 xx xx xx xx (push imm32) — eax НИКОГДА не загружается,\n");
    host_print("           ret вернёт мусор (в edi — указатель kapi!).\n\n");

    host_print("############ D3: нативный код «x = y;» ############\n");
    dump_native("main: x = y", "int main() { int x; int y; y = 222; x = y; return x; }");
    host_print("  8D 85 .. (lea eax,[ebp-8]) 50 (push)   — LEA y: ЛИШНИЙ push\n");
    host_print("  50 (push eax)                          — PSH: push &y ЕЩЁ РАЗ\n");
    host_print("  8D 85 .. (lea eax,[ebp-4]) 50 (push)   — LEA x: ещё лишний push\n");
    host_print("  59 (pop ecx) 89 01 (mov [ecx],eax)     — SI: ecx = &y → запись В y\n");
    host_print("  → «x = y» вырождается в «y = y» (no-op), x остаётся мусором.\n\n");

    host_print("############ D4: reloc-цели не разрешаются ############\n");
    {
        static int bc[65536];
        static u8  data[65536];
        u32 bc_len = 0, data_len = 0, entry = 0;
        char diag[512]; diag[0] = 0;
        int ok = c4_compile("int f() { return 4; }\n"
                            "int main() { return f(); }",
                            diag, sizeof(diag), bc, sizeof(bc), &bc_len,
                            data, sizeof(data), &data_len, &entry);
        if (ok) {
            host_print("байткод: %u ячеек, вход main = %u\n", (unsigned)bc_len, (unsigned)entry);
            host_print("значения JSR-целей в байткоде (это УКАЗАТЕЛИ пула, не индексы):\n");
            for (u32 i = 1; i < bc_len; i++) {
                if (bc[i - 1] == 3) {
                    host_print("  JSR %d (0x%x)\n", bc[i], (unsigned)bc[i]);
                }
            }
            host_print("карта bc_to_x86 в c4_x86.c ключуется ИНДЕКСАМИ ячеек (1..%u).\n", (unsigned)bc_len);
            host_print("Указатель пула ≠ маленький индекс → bc_to_x86() вернёт 0xFFFFFFFF,\n");
            host_print("патч ПРОПУЩЕН, rel32 останется 0 → все call/jmp ведут не туда.\n");
        }
    }
    return 0;
}

/* заглушки для линковки c4_x86.c */
struct window;
long loader_spawn(const char *name, struct window *win) { (void)name; (void)win; return -1; }
void serial_puts(const char *s) { (void)s; }
