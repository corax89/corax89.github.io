/* mem.h — stub для host-теста c4 */
#ifndef MEM_H
#define MEM_H

#include "types.h"

void *malloc(u32 n);
void  free(void *p);

#endif
