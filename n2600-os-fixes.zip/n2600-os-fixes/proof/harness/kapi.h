/* kapi.h — stub для host-теста c4 (c4_x86.c не обращается к полям по имени) */
#ifndef KAPI_H
#define KAPI_H

#include "types.h"

struct window;

typedef struct {
    void *slots[40];
} kapi_t;

#endif
