/* kbd.h — stub для host-теста c4 */
#ifndef KBD_H
#define KBD_H

#include "types.h"

typedef struct {
    u8   code;
    char ch;
    u8   flags;
} key_event_t;

#define KF_RELEASED 0x01

int kbd_pop(key_event_t *out);

#endif
