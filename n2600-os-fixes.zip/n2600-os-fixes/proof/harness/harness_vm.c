/* harness_vm.c — исполняемое доказательство багов VM c4 (порт N2600-OS).
 *
 * Сборка (64-битный хост, трюк оригинального c4):
 *   gcc -O0 -w -o harness_vm  harness_vm.c            # текущий порт (с багами)
 *   gcc -O0 -w -DUSE_FIX -o harness_fix harness_vm.c  # порт + патч Div/Mod
 *
 * Тесты (текущий порт):
 *   T2 (контроль): int x; x = 5;           → x=5 (но утечка 1 МиБ)
 *   T1 (баг C16):  int x = 5;              → x=0 + VM сходит с рельсов
 *   T1b (баг C16): инициализатор в callee  → калечит кадр вызывающего
 *   T3 (баг):      #define MAX (5)         → молча 0
 *   T4 (баг C1):   ошибка компиляции       → утечка 1 МиБ
 *   T5 (баг C40):  a / b                   → «bad expression»: деление
 *                   потеряно при портировании (в оригинале c4 есть)
 * Тесты (с патчем Div/Mod):
 *   F1: a/b при b=2 → r=5 (патч работает)
 *   F2: a/b при b=0 → SIGFPE=8 (в ОС = паника ядра; нужен guard)
 */
#define _GNU_SOURCE
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <sys/wait.h>
#include <stddef.h>

#define int long
#include "types.h"
#include "string.h"
#include "mem.h"
#include "fb.h"
#include "kbd.h"
#include "mouse.h"
#include "task.h"
#include "timer.h"
#include "ramfs.h"

/* ---- подсчёт аллокаций (bump-аллокатор, без libc malloc) ---- */
static long g_alloc_bytes = 0;
static long g_alloc_calls = 0;
static long g_free_calls  = 0;

static unsigned char mempool[64u * 1024u * 1024u];
static unsigned long mempool_pos = 0;

void *malloc(u32 n)
{
    g_alloc_calls++;
    g_alloc_bytes += (long)n;
    unsigned long sz = ((unsigned long)n + 15u) & ~15u;
    if (mempool_pos + sz > sizeof(mempool)) return 0;
    void *r = mempool + mempool_pos;
    mempool_pos += sz;
    return r;
}
void free(void *p)
{
    if (!p) return;
    g_free_calls++;
}

/* ---- заглушки ОС (N2600-OS API, который дёргает c4.c) ---- */
u32  fb_rgb(u8 r, u8 g, u8 b) { (void)r;(void)g;(void)b; return 0; }
u32  fb_width(void)  { return 1280; }
u32  fb_height(void) { return 600; }
void fb_fill_rect(int x, int y, int w, int h, u32 c) { (void)x;(void)y;(void)w;(void)h;(void)c; }
void fb_fill_screen(u32 c) { (void)c; }
void fb_text(int x, int y, const char *s, u32 f, int bg) { (void)x;(void)y;(void)s;(void)f;(void)bg; }
void fb_touch_all(void) {}
void fb_flush(void) {}
int  fb_ready(void) { return 0; }
int  kbd_pop(key_event_t *out) { (void)out; return 0; }
void task_yield(void) {}
u32  timer_ticks(void) { static u32 t = 0; t += 100000; return t; }
u32  uptime_sec(void) { return 0; }
int  ramfs_ready(void) { return 0; }
int  ramfs_delete(const char *n) { (void)n; return 0; }
int  ramfs_create(const char *n, u32 s) { (void)n;(void)s; return 0; }
int  ramfs_write(const char *n, const void *b, u32 l) { (void)n;(void)b;(void)l; return 0; }
u32  ramfs_total_space(void) { return 0; }

/* ---- тестируемый компилятор ---- */
#ifdef USE_FIX
#include "c4_patched.c"
#else
#include "c4.c"
#endif

#undef int
#undef printf
#undef exit

/* ---- вывод на хост (без stdio.h во избежание конфликтов прототипов) ---- */
static void host_print(const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    char buf[4096];
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    __builtin_va_end(ap);
    if (n > 0) (void)!write(1, buf, (unsigned)n);
}

/* ---- обработчик сигналов: печатает номер сигнала ---- */
static void sig_handler(int sig, siginfo_t *si, void *uc_)
{
    (void)uc_;
    char b[64]; char *o = b; const char *hex = "0123456789abcdef";
    unsigned long v = (unsigned long)si->si_addr;
    *o++='S';*o++='I';*o++='G';*o++='=';*o++=(char)(sig+'0');*o++=' ';
    *o++='a';*o++='d';*o++='d';*o++='r';*o++='=';
    for (int k=60;k>=0;k-=4) *o++ = hex[(v>>k)&0xF];
    *o++='\n';
    long ret;
    __asm__ volatile("syscall" : "=a"(ret) : "a"(1), "D"(1), "S"(b), "d"((long)(o-b)) : "rcx","r11","memory");
    (void)ret;
    _exit(88);
}

static void run_c4(const char *name, const char *src, char *out, unsigned out_max)
{
    host_print("=== %s ===\n", name);
    host_print("--- исходник ---\n%s\n", src);
    long ab0 = g_alloc_bytes, ac0 = g_alloc_calls, fc0 = g_free_calls;
    long r = c4_run(src, out, out_max);
    host_print("--- вывод VM ---\n%s\n", out);
    host_print("--- код возврата: %ld\n", r);
    host_print("--- malloc вызовов: %ld, байт: %ld; free вызовов: %ld\n",
               g_alloc_calls - ac0, g_alloc_bytes - ab0, g_free_calls - fc0);
    if (g_free_calls - fc0 == g_alloc_calls - ac0)
        host_print(">>> ПУЛЫ: %ld/%ld (malloc/free) — СБАЛАНСИРОВАНО\n\n\n",
                   g_alloc_calls - ac0, g_free_calls - fc0);
    else
        host_print(">>> УТЕЧКА: malloc=%ld, free=%ld, не освобождено %ld байт\n\n\n",
                   g_alloc_calls - ac0, g_free_calls - fc0, g_alloc_bytes - ab0);
}

static void run_div_test(const char *label, const char *prog)
{
    host_print("--- %s ---\n", label);

    pid_t pid = fork();
    if (pid == 0) {
        char o2[256];
        o2[0] = 0;
        long r = c4_run(prog, o2, sizeof(o2));
        host_print("    дочерний: c4_run=%ld, вывод: %s\n", r, o2);
        _exit(0);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    if (WIFSIGNALED(st))
        host_print("    => процесс убит сигналом %d\n", WTERMSIG(st));
    else if (WEXITSTATUS(st) == 88)
        host_print("    => перехвачен сигнал (SIGFPE=8/SIGSEGV=11) — VM упала\n");
}

int main(void)
{
    static stack_t ss;
    static char sigstack_mem[64 * 1024];
    ss.ss_sp = sigstack_mem; ss.ss_size = sizeof(sigstack_mem); ss.ss_flags = 0;
    sigaltstack(&ss, 0);
    struct sigaction sa; sa.sa_sigaction = sig_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK; sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, 0); sigaction(SIGFPE, &sa, 0);

    static char out[16384];

#ifdef USE_FIX
    host_print("######## СБОРКА С ПОЛНЫМ ПАТЧЕМ c4.c (C16+C1+C35+C40) ########\n\n");
    run_c4("F-T2: int x; x = 5; (контроль)",
           "int main() { int x; x = 5; printf(\"x=%d\\n\", x); return 0; }",
           out, sizeof(out));
    run_c4("F-T1: int x = 5; (фикс C16 — должно быть x=5, без утечки)",
           "int main() { int x = 5; printf(\"x=%d\\n\", x); return 0; }",
           out, sizeof(out));
    run_c4("F-T1b: инициализатор в f() больше не калечит кадр",
           "int f() { int y = 7; return y; }\n"
           "int main() { int a; int b; int r;\n"
           "  a = 111; b = 222; r = f();\n"
           "  printf(\"a=%d b=%d r=%d\\n\", a, b, r); return 0; }",
           out, sizeof(out));
    run_c4("F-T4: ошибка компиляции — БЕЗ утечки (фикс C1)",
           "int main() { int x = ; return 0; }",
           out, sizeof(out));
    run_div_test("F1: деление после патча (b=2)",
        "int main() { int a; int b; a = 10; b = 2; printf(\"r=%d\\n\", a / b); return 0; }");
    run_div_test("F2: деление на ноль — теперь перехват (фикс C35)",
        "int main() { int a; int b; a = 10; b = 0; printf(\"r=%d\\n\", a / b); return 0; }");
    host_print("Вывод: инициализаторы корректны, пулы сбалансированы, деление работает,\n");
    host_print("деление на ноль перехватывается сообщением вместо паники ядра.\n");
#else
    run_c4("T2 (КОНТРОЛЬ): int x; x = 5;",
           "int main() { int x; x = 5; printf(\"x=%d\\n\", x); return 0; }",
           out, sizeof(out));

    run_c4("T1 (БАГ C16): int x = 5;",
           "int main() { int x = 5; printf(\"x=%d\\n\", x); return 0; }",
           out, sizeof(out));

    run_c4("T1b (БАГ C16): инициализатор в f() калечит кадр ВЫЗЫВАЮЩЕГО",
           "int f() { int y = 7; return y; }\n"
           "int main() { int a; int b; int r;\n"
           "  a = 111; b = 222; r = f();\n"
           "  printf(\"a=%d b=%d r=%d\\n\", a, b, r); return 0; }",
           out, sizeof(out));

    run_c4("T3 (БАГ): #define MAX (5) — молча 0",
           "#define MAX (5)\n"
           "int main() { printf(\"MAX=%d\\n\", MAX); return 0; }",
           out, sizeof(out));

    run_c4("T4 (БАГ C1): ошибка компиляции — пулы не освобождаются",
           "int main() { int x = ; return 0; }",
           out, sizeof(out));

    host_print("=======================================================\n");
    host_print("T5 (БАГ C40): деление и остаток потеряны при портировании:\n");
    run_div_test("T5: int a; a = 10 / 2;",
        "int main() { int a; a = 10 / 2; printf(\"a=%d\\n\", a); return 0; }");
    run_div_test("T5: остаток 7 % 3",
        "int main() { int a; a = 7; a = a % 3; printf(\"a=%d\\n\", a); return 0; }");
    host_print("(в оригинальном c4.c rswier строки 259-260 дают tk==Div/tk==Mod,\n");
    host_print(" в порте N2600-OS этих веток в expr() НЕТ — «bad expression»)\n");
#endif
    return 0;
}
