/* timer.h — stub для host-теста c4 */
#ifndef TIMER_H
#define TIMER_H

#include "types.h"

u32 timer_ticks(void);
u32 uptime_sec(void);

#endif
