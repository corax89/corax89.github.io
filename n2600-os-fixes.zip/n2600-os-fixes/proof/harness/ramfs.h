/* ramfs.h — stub для host-теста c4 */
#ifndef RAMFS_H
#define RAMFS_H

#include "types.h"

int  ramfs_ready(void);
int  ramfs_delete(const char *name);
int  ramfs_create(const char *name, u32 size);
int  ramfs_write(const char *name, const void *buf, u32 len);
u32  ramfs_total_space(void);

#endif
