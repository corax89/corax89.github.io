/* string.h — stub для host-теста c4 (реализации в harness) */
#ifndef STRING_H
#define STRING_H

#include "types.h"
#include <stddef.h>

void *memset(void *dst, int c, unsigned n);
void *memcpy(void *dst, const void *src, unsigned n);
int   memcmp(const void *a, const void *b, unsigned n);
unsigned strlen(const char *s);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, unsigned n);
int   strcmp(const char *a, const char *b);
int   strncmp(const char *a, const char *b, unsigned n);
int   snprintf(char *out, unsigned n, const char *fmt, ...);
int   vsnprintf(char *out, unsigned n, const char *fmt, __builtin_va_list ap);

#endif
