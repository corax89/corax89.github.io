/* harness_x86_backend.c — отдельный TU для c4_x86.c (как в ОС) */
#include <stddef.h>
#define int long
#include "types.h"
#include "c4.h"
#include "kapi.h"
#include "string.h"
#include "mem.h"
#include "ramfs.h"
#include "loader.h"
#include "c4_x86.c"
