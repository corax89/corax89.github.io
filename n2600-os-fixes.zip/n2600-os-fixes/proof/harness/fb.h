/* fb.h — stub для host-теста c4 */
#ifndef FB_H
#define FB_H

#include "types.h"

u32  fb_rgb(u8 r, u8 g, u8 b);
u32  fb_width(void);
u32  fb_height(void);
void fb_fill_rect(int x, int y, int w, int h, u32 color);
void fb_fill_screen(u32 color);
void fb_text(int x, int y, const char *s, u32 fg, int bg);
void fb_touch_all(void);
void fb_flush(void);
int  fb_ready(void);

#endif
