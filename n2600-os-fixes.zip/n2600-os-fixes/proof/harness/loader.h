/* loader.h — stub для host-теста c4 */
#ifndef LOADER_H
#define LOADER_H

#include "types.h"

struct window;

int loader_spawn(const char *name, struct window *win);

#endif
